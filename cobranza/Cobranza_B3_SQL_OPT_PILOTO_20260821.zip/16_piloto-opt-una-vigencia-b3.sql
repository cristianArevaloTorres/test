/*
   PILOTO DE RENDIMIENTO OPT PARA UNA SOLA VIGENCIA B3

   Requiere COBRANZA_SQL_OPT_V2=1. Reutiliza los parametros de la ultima cache
   real completa, excluyendo caches creadas por los comparadores 14/15.
   Fuerza la recarga de una sola vigencia y muestra tiempo/filas/ruta.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=186,
        @IdVigencia int=4235,
        @CacheBase bigint,
        @IdSolTipo int,
        @FecIni varchar(16),
        @FecFin varchar(16),
        @IdVencida int,
        @PerfilClave varchar(2000),
        @EsUniverso bit,
        @Inicio datetime2(3),
        @Fin datetime2(3);

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Parametro
    WHERE paIdEmpresa=@IdEmpresa AND paidEstatus=1
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_SQL_OPT_V2'
      AND LTRIM(RTRIM(paValor))='1'
)
    THROW 52800,'B3 no esta en OPT. Ejecute 13 con @Activar=1.',1;

IF OBJECT_DEFINITION(
       OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'))
   NOT LIKE N'%BF3_QUERY_ROUTER_V1%'
    THROW 52801,'No esta instalado el router B3 del script 12.',1;

SELECT TOP (1)
       @CacheBase=CacheId,@IdSolTipo=IdSolTipo,
       @FecIni=FecIni,@FecFin=FecFin,@IdVencida=IdVencida,
       @PerfilClave=PerfilClave,@EsUniverso=EsUniverso
FROM dbo.bf_CobranzaCache_ConsultaV2
WHERE IdEmpresa=@IdEmpresa AND IdVigencia=@IdVigencia
  AND Estado='COMPLETA'
  AND PerfilClave NOT LIKE '%|BF3[_]%COMPARE%'
ORDER BY FechaCargaFin DESC,CacheId DESC;

IF @CacheBase IS NULL
    THROW 52802,'No hay una cache real COMPLETA para tomar parametros.',1;

DECLARE @Perfiles dbo.ListInt;
INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT TRY_CONVERT(int,value)
FROM STRING_SPLIT(@PerfilClave,',')
WHERE TRY_CONVERT(int,value) IS NOT NULL;

IF NOT EXISTS(SELECT 1 FROM @Perfiles)
    THROW 52803,'La cache base no contiene perfiles validos.',1;

SELECT N'ANTES' AS Momento,@CacheBase AS CacheId,@IdEmpresa AS IdEmpresa,
       @IdVigencia AS IdVigencia,@FecIni AS FecIni,@FecFin AS FecFin,
       @PerfilClave AS Perfiles,@EsUniverso AS EsUniverso,
       N'OPT' AS RutaSolicitada;

SET @Inicio=SYSDATETIME();

EXEC dbo.InsertaCobranzaConcentrada_otro_V2_BF3_Cache
     @idEmpresa=@IdEmpresa,
     @idSolTipo=@IdSolTipo,
     @FecIni=@FecIni,
     @FecFin=@FecFin,
     @idVencida=@IdVencida,
     @IdPerfil=@Perfiles,
     @idVIgencia=@IdVigencia,
     @ForzarRecarga=1,
     @PrecargarUltimas4=0,
     @EmitirResultado=1,
     @EsUniverso=@EsUniverso;

SET @Fin=SYSDATETIME();

SELECT N'DESPUES' AS Momento,Q.CacheId,Q.IdEmpresa,Q.IdVigencia,Q.Estado,
       Q.FechaCargaInicio,Q.FechaCargaFin,
       DATEDIFF(SECOND,@Inicio,@Fin) AS SegundosPiloto,
       CAST(DATEDIFF(SECOND,@Inicio,@Fin)/60.0 AS decimal(10,2)) AS MinutosPiloto,
       Q.FilasConcentrada,Q.FilasDesglosada,Q.Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 Q
WHERE Q.CacheId=@CacheBase;

SELECT TOP (10) id,fecha,etapa,detalle
FROM dbo.bf_RepConf_Debug
WHERE etapa IN
      ('cobranza_bf3_ruta_sql','cobranza_desg_pre_division',
       'cobranza_obten_post_desglosada')
ORDER BY id DESC;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.bf_RepConf_Debug
    WHERE etapa='cobranza_bf3_ruta_sql'
      AND detalle LIKE CONCAT('%ruta=OPT; empresa=',@IdEmpresa,
                              '; vigencia=',@IdVigencia,'%')
      AND fecha>=@Inicio
)
    THROW 52804,'La carga termino pero no se encontro evidencia de ruta OPT.',1;
