/*
   COMPARACION EXACTA LEGACY VS OPT, SOLO B3

   Reutiliza como base una cache LEGACY ya COMPLETA y ejecuta una sola vez la
   rama OPT con exactamente los mismos parametros. Compara todas las columnas
   de Concentrada, Desglosada y Banwire mediante EXCEPT.

   No activa COBRANZA_SQL_OPT_V2. La carga OPT se dirige a un CacheId de prueba
   mediante SESSION_CONTEXT. Ejecutar fuera del horario de mayor uso.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;

DECLARE @IdEmpresa int=186,
        @IdVigencia int=4235,
        @CacheBase bigint=NULL,       -- NULL: ultima cache LEGACY completa.
        @ConservarEvidencia bit=1,
        @CacheOpt bigint,
        @IdSolTipo int,
        @FecIni varchar(16),
        @FecFin varchar(16),
        @IdVencida int,
        @PerfilClave varchar(2000),
        @PerfilHash varbinary(32),
        @PerfilHashPrueba varbinary(32),
        @EsUniverso bit,
        @LockName nvarchar(255),
        @LockResult int;

IF OBJECT_DEFINITION(
       OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'))
   NOT LIKE N'%BF3_QUERY_ROUTER_V1%'
    THROW 52600,'Ejecute primero 12_reorganizacion-consultas-solo-b3.sql.',1;

IF @CacheBase IS NULL
BEGIN
    SELECT TOP (1) @CacheBase=CacheId
    FROM dbo.bf_CobranzaCache_ConsultaV2
    WHERE IdEmpresa=@IdEmpresa AND IdVigencia=@IdVigencia
      AND Estado='COMPLETA'
      AND PerfilClave NOT LIKE '%|BF3_OPT_COMPARE%'
    ORDER BY FechaCargaFin DESC,CacheId DESC;
END;

SELECT @IdEmpresa=IdEmpresa,@IdVigencia=IdVigencia,
       @IdSolTipo=IdSolTipo,@FecIni=FecIni,@FecFin=FecFin,
       @IdVencida=IdVencida,@PerfilClave=PerfilClave,
       @PerfilHash=PerfilHash,@EsUniverso=EsUniverso
FROM dbo.bf_CobranzaCache_ConsultaV2
WHERE CacheId=@CacheBase AND Estado='COMPLETA';

IF @PerfilHash IS NULL
    THROW 52601,'No existe la cache base COMPLETA solicitada.',1;

DECLARE @Perfiles dbo.ListInt;
INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT TRY_CONVERT(int,value)
FROM STRING_SPLIT(@PerfilClave,',')
WHERE TRY_CONVERT(int,value) IS NOT NULL;

IF NOT EXISTS(SELECT 1 FROM @Perfiles)
    THROW 52602,'La cache base no contiene perfiles validos.',1;

SET @LockName=CONCAT(N'BF3-CobranzaCache-',@IdEmpresa,N'-',@IdVigencia,N'-',
                     CONVERT(varchar(64),@PerfilHash,2),N'-',@IdVencida);
EXEC @LockResult=sys.sp_getapplock
     @Resource=@LockName,@LockMode='Exclusive',@LockOwner='Session',@LockTimeout=0;
IF @LockResult<0
    THROW 52603,'La cache base esta siendo actualizada. Reintente al finalizar.',1;

SET @PerfilHashPrueba=HASHBYTES(
    'SHA2_256',CONCAT('BF3_OPT_COMPARE_',CONVERT(varchar(36),NEWID())));

BEGIN TRY
    INSERT dbo.bf_CobranzaCache_ConsultaV2
    (IdEmpresa,IdSolTipo,FecIni,FecFin,IdVencida,IdVigencia,
     PerfilClave,PerfilHash,EsTarjeta,EsUniverso,Estado,
     FechaCargaInicio,Mensaje)
    SELECT IdEmpresa,IdSolTipo,FecIni,FecFin,IdVencida,IdVigencia,
           CONCAT(PerfilClave,'|BF3_OPT_COMPARE'),@PerfilHashPrueba,
           EsTarjeta,EsUniverso,'CARGANDO',SYSDATETIME(),
           N'Comparacion exacta B3 LEGACY contra OPT'
    FROM dbo.bf_CobranzaCache_ConsultaV2
    WHERE CacheId=@CacheBase;

    SET @CacheOpt=SCOPE_IDENTITY();

    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=@CacheOpt;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheModo',@value='FULL';
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheCapturar',@value=1;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaSqlOpt',@value=1;

    EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT
         @idEmpresa=@IdEmpresa,@idSolTipo=@IdSolTipo,
         @FecIni=@FecIni,@FecFin=@FecFin,@idVencida=@IdVencida,
         @IdPerfil=@Perfiles,@idVIgencia=@IdVigencia;

    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheCapturar',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheModo',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaSqlOpt',@value=NULL;

    UPDATE dbo.bf_CobranzaCache_ConsultaV2
       SET FechaCargaFin=COALESCE(FechaCargaFin,SYSDATETIME()),
           Mensaje=N'Evidencia temporal comparacion exacta B3 OPT'
     WHERE CacheId=@CacheOpt;

    DECLARE @Resultados TABLE
    (
        Tabla sysname NOT NULL,
        FilasLegacy bigint NOT NULL,
        FilasOpt bigint NOT NULL,
        SoloLegacy bigint NOT NULL,
        SoloOpt bigint NOT NULL
    );

    DECLARE @Tablas TABLE(Orden int IDENTITY(1,1),Tabla sysname);
    INSERT @Tablas(Tabla) VALUES
      (N'bf_CobranzaCache_ConcentradaV2'),
      (N'bf_CobranzaCache_DesglosadaV2'),
      (N'bf_CobranzaCache_BanwireV2');

    DECLARE @i int=1,@n int=(SELECT COUNT(*) FROM @Tablas),
            @Tabla sysname,@Columnas nvarchar(max),@SQL nvarchar(max),
            @FilasLegacy bigint,@FilasOpt bigint,
            @SoloLegacy bigint,@SoloOpt bigint;

    WHILE @i<=@n
    BEGIN
        SELECT @Tabla=Tabla FROM @Tablas WHERE Orden=@i;

        SELECT @Columnas=STUFF
        ((
            SELECT N','+QUOTENAME(C.name)
            FROM sys.columns C
            WHERE C.object_id=OBJECT_ID(N'dbo.'+@Tabla)
              AND C.name<>N'CacheId'
            ORDER BY C.column_id
            FOR XML PATH(''),TYPE
        ).value('.','nvarchar(max)'),1,1,N'');

        SET @SQL=N'
SELECT @FL=COUNT_BIG(*) FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@Base;
SELECT @FO=COUNT_BIG(*) FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@Opt;
SELECT @SL=COUNT_BIG(*) FROM
(
    SELECT '+@Columnas+N' FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@Base
    EXCEPT
    SELECT '+@Columnas+N' FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@Opt
) D;
SELECT @SO=COUNT_BIG(*) FROM
(
    SELECT '+@Columnas+N' FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@Opt
    EXCEPT
    SELECT '+@Columnas+N' FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@Base
) D;';

        EXEC sys.sp_executesql @SQL,
             N'@Base bigint,@Opt bigint,@FL bigint OUTPUT,@FO bigint OUTPUT,
               @SL bigint OUTPUT,@SO bigint OUTPUT',
             @Base=@CacheBase,@Opt=@CacheOpt,
             @FL=@FilasLegacy OUTPUT,@FO=@FilasOpt OUTPUT,
             @SL=@SoloLegacy OUTPUT,@SO=@SoloOpt OUTPUT;

        INSERT @Resultados
        VALUES(@Tabla,@FilasLegacy,@FilasOpt,@SoloLegacy,@SoloOpt);
        SET @i+=1;
    END;

    SELECT @CacheBase AS CacheLegacy,@CacheOpt AS CacheOpt,
           Tabla,FilasLegacy,FilasOpt,SoloLegacy,SoloOpt,
           CASE WHEN FilasLegacy=FilasOpt AND SoloLegacy=0 AND SoloOpt=0
                THEN 'IGUAL' ELSE 'DIFERENTE' END AS Resultado
    FROM @Resultados ORDER BY Tabla;

    IF EXISTS
       (SELECT 1 FROM @Resultados
        WHERE FilasLegacy<>FilasOpt OR SoloLegacy<>0 OR SoloOpt<>0)
    BEGIN
        UPDATE dbo.bf_CobranzaCache_ConsultaV2
           SET Mensaje=N'DIFERENCIAS contra cache LEGACY; no activar OPT'
         WHERE CacheId=@CacheOpt;
        THROW 52604,'La rama OPT produjo diferencias. No active COBRANZA_SQL_OPT_V2.',1;
    END;

    IF @ConservarEvidencia=0
        DELETE dbo.bf_CobranzaCache_ConsultaV2 WHERE CacheId=@CacheOpt;

    EXEC sys.sp_releaseapplock @Resource=@LockName,@LockOwner='Session';
END TRY
BEGIN CATCH
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheCapturar',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheModo',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaSqlOpt',@value=NULL;
    IF @CacheOpt IS NOT NULL
        UPDATE dbo.bf_CobranzaCache_ConsultaV2
           SET Estado='ERROR',FechaCargaFin=SYSDATETIME(),Mensaje=ERROR_MESSAGE()
         WHERE CacheId=@CacheOpt;
    EXEC sys.sp_releaseapplock @Resource=@LockName,@LockOwner='Session';
    THROW;
END CATCH;
