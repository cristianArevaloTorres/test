/* VALIDACION FINAL */
SET NOCOUNT ON;

DECLARE @IdEmpresa int=186;
DECLARE @Errores TABLE (Detalle nvarchar(1000));

/* Objetos obligatorios. */
IF OBJECT_ID(N'dbo.ReporteCobranzaConcentrada_BF3_Cache',N'P') IS NULL
    INSERT @Errores VALUES(N'Falta ReporteCobranzaConcentrada_BF3_Cache.');
IF OBJECT_ID(N'dbo.InsertaCobranzaConcentrada_otro_V2_BF3_Cache',N'P') IS NULL
    INSERT @Errores VALUES(N'Falta InsertaCobranzaConcentrada_otro_V2_BF3_Cache.');
IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_Cache',N'P') IS NULL
    INSERT @Errores VALUES(N'Falta ObtenCobranzaConcentrada_otro_V2_BF3_Cache.');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_ConsultaV2',N'U') IS NULL
    INSERT @Errores VALUES(N'Falta bf_CobranzaCache_ConsultaV2.');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_ConcentradaV2',N'U') IS NULL
    INSERT @Errores VALUES(N'Falta bf_CobranzaCache_ConcentradaV2.');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_DesglosadaV2',N'U') IS NULL
    INSERT @Errores VALUES(N'Falta bf_CobranzaCache_DesglosadaV2.');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_Log',N'U') IS NULL
    INSERT @Errores VALUES(N'Falta bf_CobranzaCache_Log.');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_RegistrarEvento',N'P') IS NULL
    INSERT @Errores VALUES(N'Falta bf_CobranzaCache_RegistrarEvento.');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_MarcarCargasAbandonadas',N'P') IS NULL
    INSERT @Errores VALUES(N'Falta bf_CobranzaCache_MarcarCargasAbandonadas.');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_MonitoreoV2',N'V') IS NULL
    INSERT @Errores VALUES(N'Falta bf_CobranzaCache_MonitoreoV2.');
IF OBJECT_ID(N'dbo.tr_bf_CobranzaCache_Log_Contexto',N'TR') IS NULL
    INSERT @Errores VALUES(N'Falta tr_bf_CobranzaCache_Log_Contexto.');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_Log',N'U') IS NOT NULL
   AND (COL_LENGTH(N'dbo.bf_CobranzaCache_Log',N'CacheId') IS NULL
        OR COL_LENGTH(N'dbo.bf_CobranzaCache_Log',N'IdEmpresa') IS NULL
        OR COL_LENGTH(N'dbo.bf_CobranzaCache_Log',N'IdVigencia') IS NULL
        OR COL_LENGTH(N'dbo.bf_CobranzaCache_Log',N'Estado') IS NULL)
    INSERT @Errores VALUES(N'bf_CobranzaCache_Log no contiene el contexto estructurado de monitoreo.');

/* Integracion del reporte y fuente del Desglosado. */
IF COALESCE(
       OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY')),
       OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3')))
   NOT LIKE N'%BF_CACHE_PERF_SCOPE_EC_AGG_V1%'
    INSERT @Errores VALUES(
        N'Falta ejecutar 08_optimizacion-rendimiento-cobranza.sql.');

IF (SELECT COUNT(*) FROM sys.indexes
    WHERE name IN
          (N'IX_BF_Cobranza_CA_EmpresaPlanConcepto',
           N'IX_BF_Cobranza2_EmpresaSolicitudEmpleado',
           N'IX_BF_Cobranza_EmpresaSolicitudNumero',
           N'IX_BF_POSCob2_EmpresaVigenciaEstatusEmpleado'))<>4
    INSERT @Errores VALUES(
        N'Faltan uno o mas indices de rendimiento instalados por el script 08.');

IF OBJECT_DEFINITION(
       OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR'))
   NOT LIKE N'%BF_CACHE_PERF_DESG_TEMP_INDEX_V1%'
    INSERT @Errores VALUES(
        N'Falta ejecutar 11_optimizacion-desglosada-cobranza.sql.');

IF OBJECT_DEFINITION(
       OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR'))
   NOT LIKE N'%BF_CACHE_PERF_DESG_SOURCE_INDEX_V1%'
   OR OBJECT_DEFINITION(
       OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR'))
   NOT LIKE N'%BF_CACHE_PERF_DESG_RECOMPILE_V1%'
    INSERT @Errores VALUES(
        N'La optimizacion 11 de fuente/recompilacion Desglosada esta incompleta.');

IF (SELECT COUNT(*) FROM sys.indexes
    WHERE name IN
          (N'IX_BF_GMMDesgCob_EmpresaPlanConcepto',
           N'IX_BF_CompPlanOpcion_PlanCompensacion',
           N'IX_BF_Cobranza_EmpresaNumeroCompSolicitud',
           N'IX_BF_ValidaSA_VigenciaEstatusEmpleadoPlan'))<>4
    INSERT @Errores VALUES(
        N'Faltan uno o mas indices de Desglosada instalados por el script 11.');

IF OBJECT_DEFINITION(
       OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'))
   NOT LIKE N'%BF3_QUERY_ROUTER_V1%'
    INSERT @Errores VALUES(
        N'Falta ejecutar 12_reorganizacion-consultas-solo-b3.sql.');

IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY',N'P') IS NULL
   OR OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT',N'P') IS NULL
   OR OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_OPT',N'P') IS NULL
   OR OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_OPT',N'P') IS NULL
    INSERT @Errores VALUES(
        N'Falta una o mas ramas LEGACY/OPT exclusivas de B3.');

IF NOT EXISTS
(
    SELECT 1 FROM dbo.bf_CatReportesSP
    WHERE catReportesId=11
      AND catReportesSPNombre='ReporteCobranzaConcentrada_BF3_Cache'
      AND ISNULL(ESid,1)=1
)
    INSERT @Errores VALUES(N'El reporte 11 no apunta al wrapper de cache.');

IF OBJECT_DEFINITION(
       OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR'))
   NOT LIKE N'%FROM dbo.ff_planopcionseleccionCobranza2 POS WITH (NOLOCK)%'
    INSERT @Errores VALUES(
        N'El Desglosado no consulta ff_PlanOpcionSeleccionCobranza2.');

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Parametro
    WHERE paIdEmpresa=@IdEmpresa AND paidEstatus=1
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE'
      AND LTRIM(RTRIM(paValor))='1'
)
    INSERT @Errores VALUES(N'La empresa no tiene COBRANZA_CACHE=1 activo.');

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Parametro
    WHERE paIdEmpresa=0 AND paidEstatus=1
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE_HORA'
)
    INSERT @Errores VALUES(N'No esta configurado COBRANZA_CACHE_HORA.');

IF
(
    SELECT COUNT(DISTINCT IdVigencia)
    FROM dbo.bf_CobranzaCache_ConsultaV2
    WHERE IdEmpresa=@IdEmpresa
      AND EsUniverso=1
      AND Estado='COMPLETA'
)<>4
    INSERT @Errores VALUES(
        N'Deben existir exactamente cuatro vigencias universo COMPLETAS.');

/* Resumen de las cuatro vigencias cargadas. */
;WITH Ultimas AS
(
    SELECT Q.*,
           ROW_NUMBER() OVER
           (PARTITION BY Q.IdVigencia ORDER BY Q.CacheId DESC) AS rn
    FROM dbo.bf_CobranzaCache_ConsultaV2 Q WITH (NOLOCK)
    WHERE Q.IdEmpresa=@IdEmpresa AND Q.EsUniverso=1
)
SELECT TOP (4)
    CacheId,IdVigencia,FecIni,FecFin,Estado,
    FilasConcentrada,FilasDesglosada,
    (SELECT COUNT_BIG(*) FROM dbo.bf_CobranzaCache_ConcentradaV2 C
      WITH (NOLOCK) WHERE C.CacheId=U.CacheId) AS ConcentradaReal,
    (SELECT COUNT_BIG(*) FROM dbo.bf_CobranzaCache_DesglosadaV2 D
      WITH (NOLOCK) WHERE D.CacheId=U.CacheId) AS DesglosadaReal,
    FechaCargaInicio,FechaCargaFin,Mensaje
FROM Ultimas U
WHERE rn=1
ORDER BY IdVigencia DESC;

/* Aviso explicito si hay fuente activa pero la cache quedo sin detalle. */
IF EXISTS
(
    SELECT 1
    FROM dbo.bf_CobranzaCache_ConsultaV2 Q
    WHERE Q.IdEmpresa=@IdEmpresa AND Q.EsUniverso=1
      AND Q.Estado='COMPLETA' AND Q.FilasDesglosada=0
      AND EXISTS
      (
          SELECT 1 FROM dbo.ff_PlanOpcionSeleccionCobranza2 P
          WHERE P.POidEmpresa=@IdEmpresa
            AND P.POidVigencia=Q.IdVigencia
            AND P.POidEstatus=1
      )
)
    INSERT @Errores VALUES(
        N'Hay una vigencia COMPLETA sin Desglosada aunque Cobranza2 tiene selecciones activas.');

IF EXISTS(SELECT 1 FROM @Errores)
BEGIN
    SELECT N'ERROR' AS Estado,Detalle FROM @Errores;
    THROW 52200,'La validacion final de Cobranza encontro errores.',1;
END;

SELECT N'OK' AS Estado,
       N'Instalacion y configuracion de Cobranza listas para pruebas QA.'
       AS Detalle;
