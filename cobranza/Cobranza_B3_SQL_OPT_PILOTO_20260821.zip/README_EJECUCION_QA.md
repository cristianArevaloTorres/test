# Querys finales de Cobranza

Esta carpeta contiene la secuencia consolidada para instalar el cache de
Cobranza en una base limpia que ya tenga el esquema funcional de FlexiForbes.
No deben mezclarse con los scripts antiguos de la carpeta padre.

## Requisitos

- Respaldar la base antes de la instalación.
- Desplegar la versión actualizada de APIREPORTES junto con estos scripts.
- La base debe contener los procedimientos legacy de Cobranza y `dbo.ListInt`.
- Ejecutar con un usuario autorizado para crear y alterar objetos.

## Orden de ejecución

1. `01_Creacion de objetoss de bd completos para funcionalidad cache.sql`
   Instala objetos V2, integración del reporte, configuración de hojas y
   corrige la fuente Desglosada para usar `ff_PlanOpcionSeleccionCobranza2`.
   También instala el log estructurado y la recuperación segura de cargas que
   quedan en `CARGANDO` después de terminar una sesión.

2. `02_configuracion-empresa-worker.sql`
   Revisar `@IdEmpresa` y `@HoraWorker`. Habilita el cache para la empresa y
   configura el horario diario del worker.

3. `03_configuracion-passwords-excel-opcional.sql`
   Revisar passwords y banderas. Por seguridad, ambos quedan deshabilitados
   inicialmente. Puede omitirse si no se usarán passwords.

3.1. `08_optimizacion-rendimiento-cobranza.sql`
   Ejecutar cuando no exista una carga de Cobranza en curso y antes de `04`.
   Limita el agregado de estados de cuenta a la vigencia actual, activa
   recompilacion por carga e instala los indices de apoyo. Es idempotente.

3.2. `11_optimizacion-desglosada-cobranza.sql`
   Ejecutar despues de `08`, sin una carga de Cobranza en curso y antes de
   `04`. Evita los barridos completos repetidos de la tabla temporal
   Desglosada durante la division de costos e instala indices para sus
   busquedas correlacionadas. Conserva el algoritmo secuencial de B2 y es
   idempotente.

3.3. `12_reorganizacion-consultas-solo-b3.sql`
   Ejecutar despues de `11`, sin cargas activas. Congela la ruta B3 actual en
   `LEGACY`, crea la ruta `OPT` y convierte solamente el punto de entrada B3
   en router. La instalacion queda inicialmente en `LEGACY`; B2 no se altera.

3.4. `14_comparacion-exacta-legacy-vs-opt-b3.sql`
   Antes de activar `OPT`, revisar `@IdEmpresa`, `@IdVigencia` y opcionalmente
   `@CacheBase`. Ejecuta una carga OPT de prueba y compara columna por columna
   Concentrada, Desglosada y Banwire contra una cache LEGACY completa. Las
   tres filas deben terminar en `IGUAL`.

   Si la vigencia completa es demasiado lenta, usar primero
   `15_prueba-rapida-top20-legacy-vs-opt-b3.sql`. Este crea dos rutas TEST con
   los mismos 20 empleados y compara exactamente las tres tablas. No activa
   OPT ni cambia el router productivo. La prueba 14 completa sigue siendo la
   evidencia final recomendada antes de produccion.

3.5. `13_control-ruta-optimizada-solo-b3.sql`
   Solo despues de una comparacion exacta exitosa, cambiar `@Activar=1` para
   habilitar OPT en cache y flujo tradicional B3. Con `@Activar=0` el rollback
   a LEGACY es inmediato y no requiere redespliegue.

3.6. `16_piloto-opt-una-vigencia-b3.sql`
   Con `OPT` ya activo, ejecuta solamente una vigencia real, muestra el tiempo
   total, filas publicadas y comprueba mediante log que la ruta utilizada fue
   OPT. Usar este piloto antes de volver a cargar las cuatro vigencias con 04.

4. `04_carga-inicial-ultimas-4-vigencias.sql`
   Revisar `@IdEmpresa`. Ejecutar fuera del horario de mayor uso; fuerza la
   carga completa de las cuatro vigencias más recientes.

5. `05_validacion-final.sql`
   No modifica información. Debe terminar con estado `OK`.

6. `06_prueba-dummy-y-monitoreo-cache.sql`
   Ejecuta dos simulaciones dentro de una transacción: una carga abandonada y
   una carga activa con `APPLOCK`. Debe terminar con estado `OK` y revierte
   todos los datos dummy. Para recuperar estados reales, cambiar
   `@AplicarRecuperacionReal` a `1` después de revisar el monitor.

7. `07_liberar-cargas-atoradas.sql` (solo recuperación operativa)
   Usar cuando una sesión terminada dejó una partición en `CARGANDO`. Verifica
   el `APPLOCK` y cambia únicamente las cargas abandonadas a `ERROR`; no mata
   sesiones ni elimina datos. La siguiente solicitud ejecutará una carga FULL.

`09_seguimiento-rendimiento-cobranza.sql` es de solo lectura y puede
ejecutarse durante `04`; muestra tiempos por etapa, CPU, lecturas, esperas y
bloqueos de la sesion activa.

Antes de instalar `08`, ejecutar
`10_exportar-linea-base-antes-optimizacion.sql` para conservar en CSV las
cuatro vigencias completas y poder compararlas con la recarga optimizada.

## Pruebas funcionales QA

- Generar Cobranza para cada una de las cuatro vigencias.
- Comprobar que el Excel contiene `Información`, `Concentrada`, `Desglosada`
  y los resúmenes configurados.
- En vigencias con selecciones activas en `Cobranza2`, `Desglosada` debe tener
  filas reales además de la fila de totales.
- Generar dos reportes dentro del mismo minuto y comprobar que las rutas son
  diferentes.
- Probar password habilitado y deshabilitado con solicitudes nuevas.
- Confirmar que `bf_RepConf_Debug` continúa disponible para otros reportes.
- Consultar `bf_CobranzaCache_MonitoreoV2` y confirmar que cada carga termina
  en `COMPLETA` o `ERROR`, nunca indefinidamente en `CARGANDO` sin `APPLOCK`.

## Rollback operativo

Para evitar usar el cache sin borrar objetos:

```sql
UPDATE dbo.ff_Parametro
SET paValor='0',paFechaUmod=GETDATE()
WHERE paIdEmpresa=186
  AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE';
```

La API regresará al flujo legacy. No ejecutar scripts antiguos de eliminación
ni borrar tablas mientras existan reportes en proceso.
