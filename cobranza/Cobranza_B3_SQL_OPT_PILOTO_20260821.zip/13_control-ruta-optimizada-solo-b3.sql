/*
   CONTROL DE LA RUTA SQL OPTIMIZADA, EXCLUSIVO PARA B3.

   @Activar=0 -> B3 usa la copia LEGACY (rollback inmediato).
   @Activar=1 -> cache y flujo tradicional B3 usan la copia OPT.

   Antes de activar para toda la empresa, puede probarse solo en la sesion:
     EXEC sys.sp_set_session_context N'bf_CobranzaSqlOpt',1;
   Al cerrar la conexion desaparece el override.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=186,
        @Activar bit=0,       -- Cambiar a 1 solamente despues de comparar.
        @Usuario int=1,
        @PaId int;

IF OBJECT_DEFINITION(
       OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'))
   NOT LIKE N'%BF3_QUERY_ROUTER_V1%'
    THROW 52500,'Ejecute primero 12_reorganizacion-consultas-solo-b3.sql.',1;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP (1) @PaId=paId
    FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=@IdEmpresa
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))='COBRANZA_SQL_OPT_V2'
    ORDER BY paidEstatus DESC,paId DESC;

    IF @PaId IS NULL
    BEGIN
        SELECT @PaId=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paidEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@PaId,@IdEmpresa,'COBRANZA_SQL_OPT_V2',
         CASE WHEN @Activar=1 THEN '1' ELSE '0' END,
         'Selecciona LEGACY/OPT solo para consultas de Cobranza B3',
         1,@Usuario,GETDATE());
    END
    ELSE
        UPDATE dbo.ff_Parametro WITH (ROWLOCK)
           SET paValor=CASE WHEN @Activar=1 THEN '1' ELSE '0' END,
               paDescripcion='Selecciona LEGACY/OPT solo para consultas de Cobranza B3',
               paidEstatus=1,paUsuarioUmod=@Usuario,paFechaUmod=GETDATE(),
               paFechaDel=NULL,paUsuarioDel=NULL
         WHERE paId=@PaId AND paIdEmpresa=@IdEmpresa;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT paIdEmpresa,LTRIM(RTRIM(paClase)) AS Clase,
       LTRIM(RTRIM(paValor)) AS Valor,
       CASE WHEN LTRIM(RTRIM(paValor))='1' THEN 'OPT' ELSE 'LEGACY' END AS RutaB3,
       paidEstatus
FROM dbo.ff_Parametro
WHERE paId=@PaId;
