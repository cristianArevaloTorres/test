/*
   REORGANIZACION DE CONSULTAS EXCLUSIVA PARA B3

   Objetivos:
     - No alterar ningun procedimiento B2.
     - Conservar intacta una copia LEGACY de la implementacion B3 actual.
     - Crear una rama OPT que precarga las busquedas repetidas de la division
       de costos, sin cambiar formulas, condiciones ni orden de procesamiento.
     - Enrutar cache y flujo tradicional B3 con COBRANZA_SQL_OPT_V2.

   Requisitos: ejecutar 08 y 11 antes de este script y no tener cargas activas.
   La bandera ausente o en 0 conserva la ruta LEGACY.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Main sysname=N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3',
        @MainLegacy sysname=N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY',
        @MainOpt sysname=N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT',
        @Desg sysname=N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR',
        @DesgOpt sysname=N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_OPT',
        @Division sysname=N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR',
        @DivisionOpt sysname=N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_OPT',
        @Def nvarchar(max),
        @Upper nvarchar(max),
        @PosProc int,
        @PosInsert int,
        @PosWhile int,
        @PosIf int,
        @PosBegin int,
        @Bloque nvarchar(max);

IF OBJECT_ID(@Main,N'P') IS NULL OR OBJECT_ID(@Desg,N'P') IS NULL
   OR OBJECT_ID(@Division,N'P') IS NULL
    THROW 52400,'Falta uno o mas procedimientos B3 requeridos.',1;

IF OBJECT_DEFINITION(OBJECT_ID(@Desg))
       NOT LIKE N'%BF_CACHE_PERF_DESG_TEMP_INDEX_V1%'
    THROW 52401,'Ejecute primero 11_optimizacion-desglosada-cobranza.sql.',1;

/* 1. Congelar exactamente la version B3 actual. Nunca se reemplaza al
      reejecutar este instalador, para mantener un rollback estable. */
IF OBJECT_ID(@MainLegacy,N'P') IS NULL
BEGIN
    SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Main));
    IF @Def LIKE N'%BF3_QUERY_ROUTER_V1%'
        THROW 52402,'El router ya existe pero falta su copia LEGACY.',1;

    SET @Def=REPLACE(@Def,N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3]',
                          N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY]');
    SET @Def=REPLACE(@Def,N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3',
                          N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY');
    SET @Upper=UPPER(@Def);
    SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
    IF @PosProc=0 OR @Def NOT LIKE N'%ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY%'
        THROW 52403,'No se pudo construir la copia LEGACY B3.',1;
    SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
    EXEC sys.sp_executesql @Def;
END;

/* 2. Crear la division OPT desde la division B3. Las tablas precargadas
      conservan duplicados y filtros del codigo original; solo evitan leer las
      mismas tablas permanentes por cada plan de cada empleado. */
SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Division));
SET @Def=REPLACE(@Def,N'[dbo].[ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR]',
                      N'[dbo].[ff_ObtenDivisionCtos_Adaptado_bf3_OPT]');
SET @Def=REPLACE(@Def,N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR',
                      N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_OPT');

/* Las consultas escalares siguen siendo las mismas, pero leen un subconjunto
   temporal B3. El reemplazo se hace antes de insertar la carga de ese subset. */
SET @Def=REPLACE(@Def,N'DBO.ff_GMMDesgCob',N'#BF_GMMDesgCob');

SET @Upper=UPPER(@Def);
SET @PosInsert=CHARINDEX(N'IF EXISTS(SELECT TOP 1 * FROM #TABLACOBDESG',@Upper);
IF @PosInsert=0
    THROW 52404,'No se encontro el inicio de la division de costos B3.',1;

SET @Bloque=N'
/* BF3_QUERY_REORG_DIVISION_V1 */
SELECT G.GDidEmpresa,G.GDidConcepto,G.GDidPlanOpcion,G.GDMonto
INTO #BF_GMMDesgCob
FROM dbo.ff_GMMDesgCob G WITH (NOLOCK)
WHERE EXISTS
(
    SELECT 1 FROM #TablaCobDesg D
    WHERE D.EMPRESA=G.GDidEmpresa AND D.CVEPO=G.GDidPlanOpcion
);
CREATE NONCLUSTERED INDEX IX_BF_GMMTemp_EmpresaPlanConcepto
    ON #BF_GMMDesgCob(GDidEmpresa,GDidPlanOpcion,GDidConcepto)
    INCLUDE(GDMonto);

SELECT DISTINCT CP.CPidPlanOpcion,ES.ECNumeroEmpleado,ES.ECidEmpresa
INTO #BF_CompEmpleadoPlan
FROM dbo.ff_CompensacionPlanOpcion CP WITH (NOLOCK)
INNER JOIN dbo.ff_EdoCuentaCobranza ES WITH (NOLOCK)
    ON CP.CPIdCompensacion=ES.ECidCompensacion
WHERE ES.ECidCompensacion IS NOT NULL
  AND EXISTS
  (
      SELECT 1 FROM dbo.ff_solicitud S WITH (NOLOCK)
      WHERE S.SOIdSolicitud=ES.ECidSolicitud
        AND S.SOIdVigencia=@idVigencia
  )
  AND EXISTS
  (
      SELECT 1 FROM #TablaCobDesg D
      WHERE D.EMPRESA=ES.ECidEmpresa
        AND D.NUMEMPLEADO COLLATE DATABASE_DEFAULT=
            ES.ECNumeroEmpleado COLLATE DATABASE_DEFAULT
        AND D.CVEPO=CP.CPidPlanOpcion
  );
CREATE UNIQUE CLUSTERED INDEX IX_BF_CompTemp_EmpleadoPlan
    ON #BF_CompEmpleadoPlan(ECIdEmpresa,ECNumeroEmpleado,CPidPlanOpcion);

';
SET @Def=STUFF(@Def,@PosInsert,0,@Bloque);

/* Sustituir exclusivamente el EXISTS de compensacion del WHILE. */
SET @Upper=UPPER(@Def);
SET @PosWhile=CHARINDEX(N'WHILE @TOTAL_REGISTROS2',@Upper);
SET @PosIf=CHARINDEX(N'IF EXISTS(',@Upper,@PosWhile);
SET @PosBegin=CHARINDEX(N'BEGIN --1',@Upper,@PosIf);
IF @PosWhile=0 OR @PosIf=0 OR @PosBegin=0
    THROW 52405,'No se encontro el EXISTS de compensacion B3.',1;

SET @Bloque=N'IF EXISTS
            (
                SELECT 1
                FROM #BF_CompEmpleadoPlan C
                WHERE C.CPidPlanOpcion=@CVEPO
                  AND C.ECNumeroEmpleado COLLATE DATABASE_DEFAULT=
                      @NumEmpleado COLLATE DATABASE_DEFAULT
                  AND C.ECIdEmpresa=@Empresa
            )
            ';
SET @Def=STUFF(@Def,@PosIf,@PosBegin-@PosIf,@Bloque);

SET @Upper=UPPER(@Def);
SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
IF @PosProc=0 OR @Def NOT LIKE N'%BF3_QUERY_REORG_DIVISION_V1%'
    THROW 52406,'No se pudo construir la division OPT B3.',1;
SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
EXEC sys.sp_executesql @Def;

/* 3. Crear Desglosada OPT. Mantiene el SELECT y todas sus formulas; solamente
      llama a la division reorganizada. */
SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Desg));
SET @Def=REPLACE(@Def,N'[dbo].[ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR]',
                      N'[dbo].[ff_ObtenCobranzaDesg_Adaptada_bf3_OPT]');
SET @Def=REPLACE(@Def,N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR',
                      N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_OPT');
SET @Def=REPLACE(@Def,N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR',
                      N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_OPT');
SET @Def=REPLACE(@Def,N'DBO.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR',
                      N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_OPT');

SET @Upper=UPPER(@Def);
SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
IF @PosProc=0 OR @Def NOT LIKE N'%ff_ObtenDivisionCtos_Adaptado_bf3_OPT%'
    THROW 52407,'No se pudo construir Desglosada OPT B3.',1;
SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
EXEC sys.sp_executesql @Def;

/* 4. Crear el procedimiento principal OPT desde la copia LEGACY congelada. */
SET @Def=OBJECT_DEFINITION(OBJECT_ID(@MainLegacy));
SET @Def=REPLACE(@Def,N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY]',
                      N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_OPT]');
SET @Def=REPLACE(@Def,N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY',
                      N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT');
SET @Def=REPLACE(@Def,N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_nousar',
                      N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_OPT');
SET @Def=REPLACE(@Def,N'DBO.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR',
                      N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_OPT');

SET @Upper=UPPER(@Def);
SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
IF @PosProc=0 OR @Def NOT LIKE N'%ff_ObtenCobranzaDesg_Adaptada_bf3_OPT%'
    THROW 52408,'No se pudo construir el procedimiento principal OPT B3.',1;
SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
EXEC sys.sp_executesql @Def;

/* 5. El nombre consumido por APIREPORTES, WS y cache se convierte en router
      exclusivo B3. SESSION_CONTEXT permite pruebas por sesion sin activar la
      empresa completa. */
EXEC sys.sp_executesql N'
CREATE OR ALTER PROCEDURE dbo.ObtenCobranzaConcentrada_otro_V2_BF3
    @idEmpresa int=0,
    @idSolTipo int=0,
    @FecIni varchar(16)='''',
    @FecFin varchar(16)='''',
    @idVencida int=0,
    @IdPerfil dbo.ListInt READONLY,
    @idVIgencia int=0
AS
BEGIN
    SET NOCOUNT ON;
    /* BF3_QUERY_ROUTER_V1 */
    DECLARE @Override sql_variant=SESSION_CONTEXT(N''bf_CobranzaSqlOpt''),
            @UsarOpt bit;

    IF @Override IS NOT NULL
        SET @UsarOpt=ISNULL(TRY_CONVERT(bit,@Override),0);
    ELSE
        SET @UsarOpt=CASE WHEN EXISTS
        (
            SELECT 1 FROM dbo.ff_Parametro WITH (NOLOCK)
            WHERE paIdEmpresa=@idEmpresa AND paidEstatus=1
              AND UPPER(LTRIM(RTRIM(paClase)))=''COBRANZA_SQL_OPT_V2''
              AND LTRIM(RTRIM(paValor))=''1''
        ) THEN 1 ELSE 0 END;

    BEGIN TRY
        INSERT dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES(''cobranza_bf3_ruta_sql'',
               CONCAT(''ruta='',CASE WHEN @UsarOpt=1 THEN ''OPT'' ELSE ''LEGACY'' END,
                      ''; empresa='',@idEmpresa,''; vigencia='',@idVIgencia));
    END TRY BEGIN CATCH END CATCH;

    IF @UsarOpt=1
        EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT
             @idEmpresa=@idEmpresa,@idSolTipo=@idSolTipo,
             @FecIni=@FecIni,@FecFin=@FecFin,@idVencida=@idVencida,
             @IdPerfil=@IdPerfil,@idVIgencia=@idVIgencia;
    ELSE
        EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY
             @idEmpresa=@idEmpresa,@idSolTipo=@idSolTipo,
             @FecIni=@FecIni,@FecFin=@FecFin,@idVencida=@idVencida,
             @IdPerfil=@IdPerfil,@idVIgencia=@idVIgencia;
END;';

SELECT N'OK' AS Estado,O.name AS Procedimiento
FROM sys.procedures O
WHERE O.object_id IN
      (OBJECT_ID(@Main),OBJECT_ID(@MainLegacy),OBJECT_ID(@MainOpt),
       OBJECT_ID(@Desg),OBJECT_ID(@DesgOpt),
       OBJECT_ID(@Division),OBJECT_ID(@DivisionOpt))
ORDER BY O.name;

SELECT N'LEGACY' AS RutaInicial,
       N'COBRANZA_SQL_OPT_V2 ausente o en 0' AS Condicion,
       N'B2 no fue modificado' AS Alcance;
