/*
   PRUEBA RAPIDA B3: LOS MISMOS 20 EMPLEADOS EN LEGACY Y OPT

   Crea procedimientos TEST aislados, recorta #ff_Empleadotemp despues de su
   carga y antes de calcular Concentrada/Desglosada, ejecuta las dos ramas y
   compara todas las columnas mediante EXCEPT. No modifica B2, no cambia el
   router productivo y no activa COBRANZA_SQL_OPT_V2.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;

DECLARE @IdEmpresa int=186,
        @IdVigencia int=4235,
        @TopEmpleados int=20,
        @CacheReferencia bigint=NULL,
        @ConservarEvidencia bit=1,
        @Def nvarchar(max),@Upper nvarchar(max),
        @PosProc int,@PosAnchor int,@PosFinAnchor int,
        @Bloque nvarchar(max),
        @LegacyTest sysname=N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY_TEST',
        @OptTest sysname=N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT_TEST';

IF @TopEmpleados NOT BETWEEN 1 AND 200
    THROW 52700,'@TopEmpleados debe estar entre 1 y 200.',1;
IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY',N'P') IS NULL
   OR OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT',N'P') IS NULL
    THROW 52701,'Ejecute primero 12_reorganizacion-consultas-solo-b3.sql.',1;

SET @Bloque=N'
/* BF3_QUERY_TOP_TEST_V1 */
DECLARE @BFTopPrueba int=TRY_CONVERT(int,SESSION_CONTEXT(N''bf_CobranzaTopPrueba''));
IF @BFTopPrueba>0
BEGIN
    CREATE TABLE #BF_EmpleadosPrueba
    (
        EMIdEmpresa int NOT NULL,
        EMNumeroEmpleado varchar(20) COLLATE DATABASE_DEFAULT NOT NULL,
        PRIMARY KEY(EMIdEmpresa,EMNumeroEmpleado)
    );

    INSERT TOP (@BFTopPrueba) #BF_EmpleadosPrueba(EMIdEmpresa,EMNumeroEmpleado)
    SELECT E.EMIdEmpresa,E.EMNumeroEmpleado
    FROM #ff_Empleadotemp E
    WHERE E.EMIdParentesco=1
    GROUP BY E.EMIdEmpresa,E.EMNumeroEmpleado
    ORDER BY E.EMIdEmpresa,E.EMNumeroEmpleado;

    IF NOT EXISTS(SELECT 1 FROM #BF_EmpleadosPrueba)
        INSERT TOP (@BFTopPrueba) #BF_EmpleadosPrueba(EMIdEmpresa,EMNumeroEmpleado)
        SELECT E.EMIdEmpresa,E.EMNumeroEmpleado
        FROM #ff_Empleadotemp E
        GROUP BY E.EMIdEmpresa,E.EMNumeroEmpleado
        ORDER BY E.EMIdEmpresa,E.EMNumeroEmpleado;

    DELETE E
    FROM #ff_Empleadotemp E
    WHERE NOT EXISTS
    (
        SELECT 1 FROM #BF_EmpleadosPrueba K
        WHERE K.EMIdEmpresa=E.EMIdEmpresa
          AND K.EMNumeroEmpleado=E.EMNumeroEmpleado
    );

    BEGIN TRY
        INSERT dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES(''cobranza_bf3_top_prueba'',
               CONCAT(''top='',@BFTopPrueba,''; filas_familia='',
                      (SELECT COUNT_BIG(*) FROM #ff_Empleadotemp)));
    END TRY BEGIN CATCH END CATCH;
END;
';

/* Construir LEGACY_TEST. */
SET @Def=OBJECT_DEFINITION(
    OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY'));
SET @Def=REPLACE(@Def,N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY]',
                      N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY_TEST]');
SET @Def=REPLACE(@Def,N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY',
                      N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY_TEST');
SET @Upper=UPPER(@Def);
SET @PosAnchor=CHARINDEX(N'''COBRANZA_OBTEN_POST_EMPLEADOS''',@Upper);
SET @PosFinAnchor=CHARINDEX(N'END CATCH;',@Upper,@PosAnchor);
IF @PosAnchor=0 OR @PosFinAnchor=0
    THROW 52702,'No se encontro el punto de recorte LEGACY_TEST.',1;
SET @Def=STUFF(@Def,@PosFinAnchor+LEN(N'END CATCH;'),0,@Bloque);
SET @Upper=UPPER(@Def);
SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
EXEC sys.sp_executesql @Def;

/* Construir OPT_TEST con exactamente el mismo recorte. */
SET @Def=OBJECT_DEFINITION(
    OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT'));
SET @Def=REPLACE(@Def,N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_OPT]',
                      N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_OPT_TEST]');
SET @Def=REPLACE(@Def,N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT',
                      N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT_TEST');
SET @Upper=UPPER(@Def);
SET @PosAnchor=CHARINDEX(N'''COBRANZA_OBTEN_POST_EMPLEADOS''',@Upper);
SET @PosFinAnchor=CHARINDEX(N'END CATCH;',@Upper,@PosAnchor);
IF @PosAnchor=0 OR @PosFinAnchor=0
    THROW 52703,'No se encontro el punto de recorte OPT_TEST.',1;
SET @Def=STUFF(@Def,@PosFinAnchor+LEN(N'END CATCH;'),0,@Bloque);
SET @Upper=UPPER(@Def);
SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
EXEC sys.sp_executesql @Def;

/* Parametros reales tomados de una cache completa, sin recalcular la vigencia
   completa. */
IF @CacheReferencia IS NULL
    SELECT TOP (1) @CacheReferencia=CacheId
    FROM dbo.bf_CobranzaCache_ConsultaV2
    WHERE IdEmpresa=@IdEmpresa AND IdVigencia=@IdVigencia
      AND Estado='COMPLETA'
      AND PerfilClave NOT LIKE '%|BF3_%COMPARE%'
    ORDER BY FechaCargaFin DESC,CacheId DESC;

DECLARE @IdSolTipo int,@FecIni varchar(16),@FecFin varchar(16),
        @IdVencida int,@PerfilClave varchar(2000),@PerfilHash varbinary(32),
        @EsTarjeta bit,@LockName nvarchar(255),@LockResult int,
        @CacheLegacy bigint,@CacheOpt bigint,
        @InicioLegacy datetime2(3),@FinLegacy datetime2(3),
        @InicioOpt datetime2(3),@FinOpt datetime2(3);

SELECT @IdEmpresa=IdEmpresa,@IdVigencia=IdVigencia,@IdSolTipo=IdSolTipo,
       @FecIni=FecIni,@FecFin=FecFin,@IdVencida=IdVencida,
       @PerfilClave=PerfilClave,@PerfilHash=PerfilHash,@EsTarjeta=EsTarjeta
FROM dbo.bf_CobranzaCache_ConsultaV2
WHERE CacheId=@CacheReferencia AND Estado='COMPLETA';
IF @PerfilHash IS NULL
    THROW 52704,'No existe una cache completa para tomar parametros.',1;

DECLARE @Perfiles dbo.ListInt;
INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT TRY_CONVERT(int,value)
FROM STRING_SPLIT(@PerfilClave,',')
WHERE TRY_CONVERT(int,value) IS NOT NULL;
IF NOT EXISTS(SELECT 1 FROM @Perfiles)
    THROW 52705,'La cache de referencia no contiene perfiles validos.',1;

SET @LockName=CONCAT(N'BF3-CobranzaCache-',@IdEmpresa,N'-',@IdVigencia,N'-',
                     CONVERT(varchar(64),@PerfilHash,2),N'-',@IdVencida);
EXEC @LockResult=sys.sp_getapplock
     @Resource=@LockName,@LockMode='Exclusive',@LockOwner='Session',@LockTimeout=0;
IF @LockResult<0
    THROW 52706,'Hay una carga activa para esa empresa/vigencia.',1;

BEGIN TRY
    INSERT dbo.bf_CobranzaCache_ConsultaV2
    (IdEmpresa,IdSolTipo,FecIni,FecFin,IdVencida,IdVigencia,PerfilClave,
     PerfilHash,EsTarjeta,EsUniverso,Estado,FechaCargaInicio,Mensaje)
    VALUES
    (@IdEmpresa,@IdSolTipo,@FecIni,@FecFin,@IdVencida,@IdVigencia,
     CONCAT(@PerfilClave,'|BF3_TOP_LEGACY_COMPARE'),
     HASHBYTES('SHA2_256',CONCAT('BF3_TOP_LEGACY_',NEWID())),
     @EsTarjeta,0,'CARGANDO',SYSDATETIME(),N'Prueba TOP LEGACY B3');
    SET @CacheLegacy=SCOPE_IDENTITY();

    EXEC sys.sp_set_session_context @key=N'bf_CobranzaTopPrueba',@value=@TopEmpleados;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=@CacheLegacy;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheModo',@value='FULL';
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheCapturar',@value=1;
    SET @InicioLegacy=SYSDATETIME();
    EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY_TEST
         @idEmpresa=@IdEmpresa,@idSolTipo=@IdSolTipo,@FecIni=@FecIni,
         @FecFin=@FecFin,@idVencida=@IdVencida,@IdPerfil=@Perfiles,
         @idVIgencia=@IdVigencia;
    SET @FinLegacy=SYSDATETIME();
    UPDATE dbo.bf_CobranzaCache_ConsultaV2
       SET FechaCargaFin=@FinLegacy,Mensaje=N'Evidencia TOP LEGACY B3'
     WHERE CacheId=@CacheLegacy;

    INSERT dbo.bf_CobranzaCache_ConsultaV2
    (IdEmpresa,IdSolTipo,FecIni,FecFin,IdVencida,IdVigencia,PerfilClave,
     PerfilHash,EsTarjeta,EsUniverso,Estado,FechaCargaInicio,Mensaje)
    VALUES
    (@IdEmpresa,@IdSolTipo,@FecIni,@FecFin,@IdVencida,@IdVigencia,
     CONCAT(@PerfilClave,'|BF3_TOP_OPT_COMPARE'),
     HASHBYTES('SHA2_256',CONCAT('BF3_TOP_OPT_',NEWID())),
     @EsTarjeta,0,'CARGANDO',SYSDATETIME(),N'Prueba TOP OPT B3');
    SET @CacheOpt=SCOPE_IDENTITY();

    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=@CacheOpt;
    SET @InicioOpt=SYSDATETIME();
    EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT_TEST
         @idEmpresa=@IdEmpresa,@idSolTipo=@IdSolTipo,@FecIni=@FecIni,
         @FecFin=@FecFin,@idVencida=@IdVencida,@IdPerfil=@Perfiles,
         @idVIgencia=@IdVigencia;
    SET @FinOpt=SYSDATETIME();
    UPDATE dbo.bf_CobranzaCache_ConsultaV2
       SET FechaCargaFin=@FinOpt,Mensaje=N'Evidencia TOP OPT B3'
     WHERE CacheId=@CacheOpt;

    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheCapturar',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheModo',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaTopPrueba',@value=NULL;

    DECLARE @Resultados TABLE
    (Tabla sysname,FilasLegacy bigint,FilasOpt bigint,SoloLegacy bigint,SoloOpt bigint);
    DECLARE @Tablas TABLE(Orden int IDENTITY,Tabla sysname);
    INSERT @Tablas(Tabla) VALUES
      (N'bf_CobranzaCache_ConcentradaV2'),
      (N'bf_CobranzaCache_DesglosadaV2'),
      (N'bf_CobranzaCache_BanwireV2');

    DECLARE @i int=1,@Tabla sysname,@Columnas nvarchar(max),@SQL nvarchar(max),
            @FL bigint,@FO bigint,@SL bigint,@SO bigint;
    WHILE @i<=3
    BEGIN
        SELECT @Tabla=Tabla FROM @Tablas WHERE Orden=@i;
        SELECT @Columnas=STUFF((SELECT N','+QUOTENAME(C.name)
          FROM sys.columns C WHERE C.object_id=OBJECT_ID(N'dbo.'+@Tabla)
          AND C.name<>N'CacheId' ORDER BY C.column_id
          FOR XML PATH(''),TYPE).value('.','nvarchar(max)'),1,1,N'');
        SET @SQL=N'
SELECT @FL=COUNT_BIG(*) FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@CL;
SELECT @FO=COUNT_BIG(*) FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@CO;
SELECT @SL=COUNT_BIG(*) FROM (SELECT '+@Columnas+N' FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@CL EXCEPT SELECT '+@Columnas+N' FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@CO) X;
SELECT @SO=COUNT_BIG(*) FROM (SELECT '+@Columnas+N' FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@CO EXCEPT SELECT '+@Columnas+N' FROM dbo.'+QUOTENAME(@Tabla)+N' WHERE CacheId=@CL) X;';
        EXEC sys.sp_executesql @SQL,
          N'@CL bigint,@CO bigint,@FL bigint OUTPUT,@FO bigint OUTPUT,@SL bigint OUTPUT,@SO bigint OUTPUT',
          @CL=@CacheLegacy,@CO=@CacheOpt,@FL=@FL OUTPUT,@FO=@FO OUTPUT,
          @SL=@SL OUTPUT,@SO=@SO OUTPUT;
        INSERT @Resultados VALUES(@Tabla,@FL,@FO,@SL,@SO);
        SET @i+=1;
    END;

    SELECT @TopEmpleados AS EmpleadosSolicitados,@CacheLegacy AS CacheLegacy,
           @CacheOpt AS CacheOpt,
           DATEDIFF(SECOND,@InicioLegacy,@FinLegacy) AS SegundosLegacy,
           DATEDIFF(SECOND,@InicioOpt,@FinOpt) AS SegundosOpt,
           Tabla,FilasLegacy,FilasOpt,SoloLegacy,SoloOpt,
           CASE WHEN FilasLegacy=FilasOpt AND SoloLegacy=0 AND SoloOpt=0
                THEN 'IGUAL' ELSE 'DIFERENTE' END Resultado
    FROM @Resultados ORDER BY Tabla;

    IF EXISTS(SELECT 1 FROM @Resultados
              WHERE FilasLegacy<>FilasOpt OR SoloLegacy<>0 OR SoloOpt<>0)
        THROW 52707,'La muestra TOP produjo diferencias. OPT sigue desactivada.',1;

    IF @ConservarEvidencia=0
    BEGIN
        DELETE dbo.bf_CobranzaCache_ConsultaV2
        WHERE CacheId IN(@CacheLegacy,@CacheOpt);
    END;
    EXEC sys.sp_releaseapplock @Resource=@LockName,@LockOwner='Session';
END TRY
BEGIN CATCH
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheCapturar',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheModo',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=NULL;
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaTopPrueba',@value=NULL;
    UPDATE dbo.bf_CobranzaCache_ConsultaV2
       SET Estado='ERROR',FechaCargaFin=SYSDATETIME(),Mensaje=ERROR_MESSAGE()
     WHERE CacheId IN(@CacheLegacy,@CacheOpt);
    EXEC sys.sp_releaseapplock @Resource=@LockName,@LockOwner='Session';
    THROW;
END CATCH;
