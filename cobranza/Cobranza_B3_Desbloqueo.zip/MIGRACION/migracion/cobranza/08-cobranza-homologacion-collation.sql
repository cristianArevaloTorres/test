/*
    Homologacion Cobranza B3
    Hace que las tablas temporales del procedimiento fuente usen la collation
    efectiva de cada base. Evita acoplar el SP a Modern_Spanish_CI_AI cuando
    la instalacion usa otra collation.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

DECLARE @Procedimiento sysname = N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3',
        @Definicion nvarchar(max),
        @PosicionProcedure int;

SET @Definicion = OBJECT_DEFINITION(OBJECT_ID(@Procedimiento, N'P'));
IF @Definicion IS NULL
    THROW 51000, 'No existe dbo.ObtenCobranzaConcentrada_otro_V2_BF3.', 1;

IF @Definicion LIKE N'%COLLATE Modern_Spanish_CI_AI%'
BEGIN
    SET @Definicion = REPLACE(
        @Definicion,
        N'COLLATE Modern_Spanish_CI_AI',
        N'COLLATE DATABASE_DEFAULT');

    SET @PosicionProcedure = CHARINDEX(
        N'PROCEDURE', UPPER(@Definicion) COLLATE Latin1_General_100_CI_AS);
    IF @PosicionProcedure = 0
        THROW 51000, 'La definicion no contiene la palabra PROCEDURE.', 1;

    SET @Definicion = N'ALTER ' + SUBSTRING(
        @Definicion, @PosicionProcedure, LEN(@Definicion));
    EXEC sys.sp_executesql @Definicion;
END;
GO

IF OBJECT_DEFINITION(
        OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3', N'P'))
        LIKE N'%COLLATE Modern_Spanish_CI_AI%'
    THROW 51000, 'Persisten collations fijas en el procedimiento de cobranza.', 1;

SELECT N'OK' AS Estado,
       N'Las temporales de cobranza usan DATABASE_DEFAULT.' AS Detalle;
GO

/*
   #TablaCobDesg puede conservar la collation de las columnas fuente, mientras
   #tablatemp usa DATABASE_DEFAULT. Se hace explicita la collation solamente
   en las dos comparaciones activas entre ambas temporales.
*/
DECLARE @Helper sysname = N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR',
        @DefHelper nvarchar(max),
        @PosicionHelper int;

SET @DefHelper = OBJECT_DEFINITION(OBJECT_ID(@Helper, N'P'));
IF @DefHelper IS NULL
    THROW 51000, 'No existe dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR.', 1;

SET @DefHelper = REPLACE(
    @DefHelper,
    N'a.NUMEMPLEADO=B.NUMEMPLEADO',
    N'a.NUMEMPLEADO COLLATE DATABASE_DEFAULT=B.NUMEMPLEADO COLLATE DATABASE_DEFAULT');
SET @DefHelper = REPLACE(
    @DefHelper,
    N'#TablaCobDesg.NUMEMPLEADO=#tablatemp.NumEMpleado',
    N'#TablaCobDesg.NUMEMPLEADO COLLATE DATABASE_DEFAULT=#tablatemp.NumEMpleado COLLATE DATABASE_DEFAULT');

IF @DefHelper NOT LIKE N'%a.NUMEMPLEADO COLLATE DATABASE_DEFAULT=B.NUMEMPLEADO COLLATE DATABASE_DEFAULT%'
   OR @DefHelper NOT LIKE N'%#TablaCobDesg.NUMEMPLEADO COLLATE DATABASE_DEFAULT=#tablatemp.NumEMpleado COLLATE DATABASE_DEFAULT%'
    THROW 51000, 'No se localizaron las comparaciones esperadas del helper.', 1;

SET @PosicionHelper = CHARINDEX(
    N'PROCEDURE', UPPER(@DefHelper) COLLATE Latin1_General_100_CI_AS);
IF @PosicionHelper = 0
    THROW 51000, 'La definicion del helper no contiene PROCEDURE.', 1;

SET @DefHelper = N'ALTER ' + SUBSTRING(
    @DefHelper, @PosicionHelper, LEN(@DefHelper));
EXEC sys.sp_executesql @DefHelper;
GO

SELECT N'OK' AS Estado,
       N'Comparaciones entre temporales homologadas a DATABASE_DEFAULT.' AS Detalle;
GO

DECLARE @Formato sysname = N'dbo.ff_GeneraFormatoDescuentos_bf3',
        @DefFormato nvarchar(max),
        @PosicionFormato int;

SET @DefFormato = OBJECT_DEFINITION(OBJECT_ID(@Formato, N'P'));
IF @DefFormato IS NULL
    THROW 51000, 'No existe dbo.ff_GeneraFormatoDescuentos_bf3.', 1;

SET @DefFormato = REPLACE(
    @DefFormato,
    N'd.NumEmpleado=C.NumEmpleado',
    N'd.NumEmpleado COLLATE DATABASE_DEFAULT=C.NumEmpleado COLLATE DATABASE_DEFAULT');

IF @DefFormato NOT LIKE N'%d.NumEmpleado COLLATE DATABASE_DEFAULT=C.NumEmpleado COLLATE DATABASE_DEFAULT%'
    THROW 51000, 'No se localizo la comparacion esperada del formato de descuentos.', 1;

SET @PosicionFormato = CHARINDEX(
    N'PROCEDURE', UPPER(@DefFormato) COLLATE Latin1_General_100_CI_AS);
IF @PosicionFormato = 0
    THROW 51000, 'La definicion del formato no contiene PROCEDURE.', 1;

SET @DefFormato = N'ALTER ' + SUBSTRING(
    @DefFormato, @PosicionFormato, LEN(@DefFormato));
EXEC sys.sp_executesql @DefFormato;
GO

SELECT N'OK' AS Estado,
       N'Formato de descuentos homologado a DATABASE_DEFAULT.' AS Detalle;
GO

/* Permite ejecutar el procedimiento clasico de B2 en bases cuya collation no
   es Modern_Spanish_CI_AI, necesario para la prueba comparativa B2/B3. */
DECLARE @DesglosadoB2 sysname = N'dbo.ff_ObtenCobranzaDesg_Adaptada',
        @DefDesglosadoB2 nvarchar(max),
        @PosicionDesglosadoB2 int;

SET @DefDesglosadoB2 = OBJECT_DEFINITION(OBJECT_ID(@DesglosadoB2, N'P'));
IF @DefDesglosadoB2 IS NULL
    THROW 51000, 'No existe dbo.ff_ObtenCobranzaDesg_Adaptada.', 1;

IF @DefDesglosadoB2 LIKE N'%COLLATE Modern_Spanish_CI_AI%'
BEGIN
    SET @DefDesglosadoB2 = REPLACE(
        @DefDesglosadoB2,
        N'COLLATE Modern_Spanish_CI_AI',
        N'COLLATE DATABASE_DEFAULT');

    SET @PosicionDesglosadoB2 = CHARINDEX(
        N'PROCEDURE', UPPER(@DefDesglosadoB2) COLLATE Latin1_General_100_CI_AS);
    IF @PosicionDesglosadoB2 = 0
        THROW 51000, 'La definicion B2 no contiene PROCEDURE.', 1;

    SET @DefDesglosadoB2 = N'ALTER ' + SUBSTRING(
        @DefDesglosadoB2, @PosicionDesglosadoB2, LEN(@DefDesglosadoB2));
    EXEC sys.sp_executesql @DefDesglosadoB2;
END;
GO

SELECT N'OK' AS Estado,
       N'Procedimiento desglosado B2 homologado a DATABASE_DEFAULT.' AS Detalle;
GO

DECLARE @ObjetosB2 TABLE (Nombre sysname PRIMARY KEY);
INSERT @ObjetosB2(Nombre)
VALUES (N'dbo.ObtenCobranzaConcentrada'),
       (N'dbo.ff_ObtenDivisionCtos_Adaptado');

DECLARE @ObjetoB2 sysname,
        @DefObjetoB2 nvarchar(max),
        @PosicionObjetoB2 int;

WHILE EXISTS (SELECT 1 FROM @ObjetosB2)
BEGIN
    SELECT TOP (1) @ObjetoB2=Nombre FROM @ObjetosB2 ORDER BY Nombre;
    SET @DefObjetoB2=OBJECT_DEFINITION(OBJECT_ID(@ObjetoB2,N'P'));
    IF @DefObjetoB2 IS NULL
        THROW 51000, 'Falta un procedimiento clasico requerido por B2.', 1;

    IF @DefObjetoB2 LIKE N'%COLLATE Modern_Spanish_CI_AI%'
    BEGIN
        SET @DefObjetoB2=REPLACE(
            @DefObjetoB2,
            N'COLLATE Modern_Spanish_CI_AI',
            N'COLLATE DATABASE_DEFAULT');
        SET @PosicionObjetoB2=CHARINDEX(
            N'PROCEDURE',UPPER(@DefObjetoB2) COLLATE Latin1_General_100_CI_AS);
        IF @PosicionObjetoB2=0
            THROW 51000, 'Una definicion clasica no contiene PROCEDURE.', 1;

        SET @DefObjetoB2=N'ALTER '+SUBSTRING(
            @DefObjetoB2,@PosicionObjetoB2,LEN(@DefObjetoB2));
        EXEC sys.sp_executesql @DefObjetoB2;
    END;

    DELETE FROM @ObjetosB2 WHERE Nombre=@ObjetoB2;
END;
GO

SELECT N'OK' AS Estado,
       N'Cadena clasica B2 homologada a DATABASE_DEFAULT.' AS Detalle;
GO
