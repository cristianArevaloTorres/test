﻿

CREATE OR ALTER PROCEDURE [dbo].[ObtenCobranzaConcentrada_otro_V2_BF3](
    @idEmpresa INT = 0,
    @idSolTipo INT = 0,
    @FecIni    VARCHAR(16) = '',
    @FecFin    VARCHAR(16) = '',
    @idVencida INT = 0,
    @IdPerfil  AS dbo.ListInt READONLY,
    @idVIgencia INT = 0)
AS
BEGIN



DECLARE @_dbg_etapa   VARCHAR(100),
        @_dbg_detalle NVARCHAR(3800);

-- LOG INICIO ────────────────────────────────────────────────────
SET @_dbg_etapa   = 'cobranza_obten_inicio';
SET @_dbg_detalle = 'idEmpresa='   + CAST(@idEmpresa  AS VARCHAR) +
                    ' idSolTipo='  + CAST(@idSolTipo  AS VARCHAR) +
                    ' FecIni='     + ISNULL(@FecIni,  'NULL')     +
                    ' FecFin='     + ISNULL(@FecFin,  'NULL')     +
                    ' idVencida='  + CAST(@idVencida  AS VARCHAR) +
                    ' idVIgencia=' + CAST(@idVIgencia AS VARCHAR) +
                    ' perfiles='   + CAST((SELECT COUNT(1) FROM @IdPerfil) AS VARCHAR);
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES(@_dbg_etapa,@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
-- ───────────────────────────────────────────────────────────────

DECLARE @FecIniVig DATETIME,
        @FecFinVig DATETIME,
        @intCveEmpl INT = 0,
        @moMontoPeriodo MONEY = 0,
        @NULL_INTEGER INT = 0,
        @id INT = 0,
        @MtoDescMen MONEY = 0,
        @empresa INT = 0,
        @MontoTotalSelecciones MONEY = 0,
        @MontoTotalCreditos MONEY = 0,
        @GPNombre varchar(10) = '',
        @SobranteCreditos MONEY = 0,
        @CoberturaRegalo MONEY = 0,
        @MontoFHMen MONEY = 0,
        @Excedente MONEY = 0,
        @SobExcedentes MONEY = 0,
        @NumEMpleado varchar(20) = '',
        @MesApl INT = datepart(month, @FecFin) -1,
        @AnioApl INT = datepart(year, @FecFin),
        @DEImporte1 MONEY = 0,
        @DEImporte2 MONEY = 0,
        @FecFinHoras VARCHAR(16) = @FecFin,
        @total_registros INT = 0,
        @contador_registros INT = 0,
        @cantidadPagos INT = 12,
        @SOIdEstatus INT,
        @isCorporativo AS INT = 0

CREATE TABLE #ListEmpresas (EMidEmpresa INT)
CREATE TABLE #isEmpresaTC (result INT)
CREATE TABLE #IdPerfilV2 (IdTipoNotificacionCorreo INT)

SELECT @idEmpresa [idEmpresa], @idSolTipo [idSolTipo], @FecIni [FechaIni],
       @FecFin [FechaFin], @idVencida [idVencida], @idVIgencia [idVigencia]
INTO #ParamsIn

INSERT INTO #ListEmpresas
SELECT DISTINCT TOP 1 1 [exists]
FROM ff_Plan PL
INNER JOIN ff_PlanOpcion ON (POidPlan = PLidPlan AND POidEstatus = 1)
INNER JOIN ff_Perfil ON (peidEmpresa = @idEmpresa AND PEIdEstatus = 1)
INNER JOIN ff_PlanOpcionPerfil ON (ppidPerfil = PEIdPerfil AND PPidPlanOpcion = POidPlanOpcion AND PPidEstatus = 1)
INNER JOIN bf_TipoPagoPlan PLTP ON (PL.PLIdTipoPago = PLTP.TPIdTipoPago)
WHERE PLidEstatus = 1 AND PLTP.TPNombre = 'TC'

SELECT @isCorporativo = 1
FROM ff_Empresa
WHERE EMidEmpresa = EMidCorporativo AND EMidEstatus = 1 AND EMidEmpresa = @idEmpresa

IF @isCorporativo = 1
BEGIN
    INSERT INTO #ListEmpresas
    SELECT EMidEmpresa FROM ff_Empresa
    WHERE EMidCorporativo = @idEmpresa AND EMidEstatus = 1 AND EMidEmpresa <> EMidCorporativo

    INSERT INTO #IdPerfilV2 (IdTipoNotificacionCorreo)
    SELECT PEIdPerfil FROM ff_Perfil WHERE PEIdEstatus = 1
    AND PEIdEmpresa IN (SELECT EMidEmpresa FROM #ListEmpresas)

    INSERT INTO #isEmpresaTC
    SELECT DISTINCT TOP 1 1
    FROM ff_Plan PL
    INNER JOIN ff_PlanOpcion ON (POidPlan = PLidPlan AND POidEstatus = 1)
    INNER JOIN ff_Perfil ON (peidEmpresa IN (SELECT EMidEmpresa FROM #ListEmpresas) AND PEIdEstatus = 1)
    INNER JOIN ff_PlanOpcionPerfil ON (ppidPerfil = PEIdPerfil AND PPidPlanOpcion = POidPlanOpcion AND PPidEstatus = 1)
    INNER JOIN bf_TipoPagoPlan PLTP ON (PL.PLIdTipoPago = PLTP.TPIdTipoPago)
    WHERE PLidEstatus = 1 AND PLTP.TPNombre = 'TC'
END
ELSE
BEGIN
    INSERT INTO #ListEmpresas SELECT @idEmpresa

    INSERT INTO #IdPerfilV2
    SELECT IdTipoNotificacionCorreo FROM @IdPerfil

    INSERT INTO #isEmpresaTC
    SELECT DISTINCT TOP 1 1
    FROM ff_Plan PL
    INNER JOIN ff_PlanOpcion ON (POidPlan = PLidPlan AND POidEstatus = 1)
    INNER JOIN ff_Perfil ON (peidEmpresa = @idEmpresa AND PEIdEstatus = 1)
    INNER JOIN ff_PlanOpcionPerfil ON (ppidPerfil = PEIdPerfil AND PPidPlanOpcion = POidPlanOpcion AND PPidEstatus = 1)
    INNER JOIN bf_TipoPagoPlan PLTP ON (PL.PLIdTipoPago = PLTP.TPIdTipoPago)
    WHERE PLidEstatus = 1 AND PLTP.TPNombre = 'TC'
END

IF @MesApl = 0
BEGIN
    SET @MesApl = 12
    SET @AnioApl = datepart(year, @FecFin) - 1
END;

-- LOG PRE-SINCRONIZACION ─────────────────────────────────────
SET @_dbg_etapa = 'cobranza_obten_pre_sinc';
SET @_dbg_detalle = 'isCorporativo=' + CAST(@isCorporativo AS VARCHAR) +
                    ' empresas=' + CAST((SELECT COUNT(1) FROM #ListEmpresas) AS VARCHAR) +
                    ' perfilesV2=' + CAST((SELECT COUNT(1) FROM #IdPerfilV2) AS VARCHAR) +
                    ' isTC=' + CAST((SELECT COUNT(1) FROM #isEmpresaTC) AS VARCHAR);
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES(@_dbg_etapa,@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
-- ─────────────────────────────────────────────────────────────

IF EXISTS(SELECT 1 FROM #isEmpresaTC)
BEGIN
    SELECT RTEIdEmpleadoTitular [idEmpleado],
           SUM(A2.BRMontoPagado) [CobroTarjeta],
           SUM(A2.BRMontoPagado-BRDTotal) [Diferencia]
    INTO #Totales
    FROM bf_RegistroTarjetaEmpleado A1
    INNER JOIN bf_BanwireRecibos A2 ON(A1.RTEIdRegistroTarjeta = A2.BRIdRegistroTarjeta)
    INNER JOIN bf_BanwireRecibosDetalle A3 ON(A3.BRDIddetalle = A2.BRIDDetalle AND A1.RTEIdEmpleadoTitular = A3.BRDIdDelEmpleado)
    WHERE RTEIdVigencia = @idVIgencia
    AND MONTH(BRFechaDeCobro) <= MONTH(@FecFin)
    AND BREstatusDePago = 'Pagado'
    GROUP BY RTEIdEmpleadoTitular

    SELECT DISTINCT
           A1.RTEIdEmpleadoTitular [idEmpleado], A4.CobroTarjeta, A4.Diferencia [Dif],
           COALESCE(BREventoOIdUnicoDeLatransaccion,'NA') [Transaccion],
           COALESCE(CAST(BRFechaDeCobro AS VARCHAR(200)),'NA') [FechaCobro],
           COALESCE(BRCodigoDeAutorizacion,'NA') [CodigoAutorizacion],
           CAST(BRReferencia AS VARCHAR(200)) [Referencia],
           BRConcepto [ext_ref_cliente],
           COALESCE(RTETerminacionTarjeta,'NA') [Card],
           '' [Telefono], '' [mail], 'LOCKTON' [Comercio]
    INTO #CobranzaBanwire
    FROM bf_RegistroTarjetaEmpleado A1
    INNER JOIN bf_BanwireRecibos A2 ON(A1.RTEIdRegistroTarjeta = A2.BRIdRegistroTarjeta)
    INNER JOIN bf_BanwireRecibosDetalle A3 ON(A3.BRDIddetalle = A2.BRIDDetalle AND A1.RTEIdEmpleadoTitular = A3.BRDIdDelEmpleado)
    INNER JOIN #Totales A4 ON(A4.idEmpleado = A1.RTEIdEmpleadoTitular)
    WHERE RTEIdVigencia = @idVIgencia
    AND MONTH(BRFechaDeCobro) <= MONTH(@FecFin)
    AND BREstatusDePago = 'Pagado'
    AND CobroTarjeta IS NOT NULL
    AND BRDIddetalle = 1
END

SELECT @FecIniVig = VIVigenciaIni, @FecFinVig = VIVigenciaFin,
       @SOIdEstatus = CASE WHEN EXISTS (SELECT 'k' FROM ff_Vigencia v2 WHERE v2.VIRenovada = v1.VIidVigencia) THEN 10
                          WHEN VIidEstatus NOT IN (1,6) THEN 10 ELSE 1 END
FROM ff_Vigencia v1
INNER JOIN ff_Empresa WITH (NOLOCK) ON VIidConfiguracion = EMidConfiguracion
WHERE EMidEmpresa = @idEmpresa AND VIidVigencia = @idVigencia AND VITipoNegocio = 1

-- LOG PRE-SINC-EXEC ──────────────────────────────────────────
SET @_dbg_etapa = 'cobranza_obten_pre_sinc_exec';
SET @_dbg_detalle = 'SOIdEstatus=' + CAST(ISNULL(@SOIdEstatus,-1) AS VARCHAR) +
                    ' FecIniVig=' + CONVERT(VARCHAR(20), @FecIniVig, 120) +
                    ' FecFinVig=' + CONVERT(VARCHAR(20), @FecFinVig, 120);
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES(@_dbg_etapa,@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
-- ─────────────────────────────────────────────────────────────

-- Llama SP corregido (ve cobranza-sinc-v3-fix.sql). Cuando se ejecuta desde aquí,
-- #ListEmpresas ya existe y el child SP la usa; @created_list=0 → no la dropea.
EXEC dbo.ff_CobranzaSincronizacion_V3_bf3 @idEmpresa, @idVigencia

-- LOG POST-SINC ──────────────────────────────────────────────
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES('cobranza_obten_post_sinc','sincronizacion completada'); END TRY BEGIN CATCH END CATCH;
-- ─────────────────────────────────────────────────────────────

SELECT @cantidadPagos = PPCantidadPagos
FROM ff_PeriodicidadPago WITH (NOLOCK,READUNCOMMITTED)
WHERE EXISTS (SELECT 1 FROM ff_VigenciaCalendarioPago WHERE PPidPeriodicidadPago = VCidPeriodicidadPago AND VCidVigencia = @IdVigencia AND VCidEstatus = 1)

SET @cantidadPagos = ISNULL(@cantidadPagos, 0)
SET @cantidadPagos = CASE WHEN @cantidadPagos = 0 THEN 12 ELSE @cantidadPagos END

-- Las tablas temp se crean ANTES del EXEC para que ff_ObtenEmpleadosCob_V2_bf3 pueda leerlas/llenarlas
CREATE TABLE #tablatemp (
  [Id_tablatemp] INT IDENTITY(1,1) PRIMARY KEY,
  [empresa] [int] NULL, [NumEMpleado] [varchar](20) COLLATE DATABASE_DEFAULT NULL,
  [CveEmpl] [int] NULL, [Paterno] [varchar](30) COLLATE DATABASE_DEFAULT NULL,
  [MAterno] [varchar](30) COLLATE DATABASE_DEFAULT NULL, [Nombre1] [varchar](30) COLLATE DATABASE_DEFAULT NULL,
  [Nombre2] [varchar](30) COLLATE DATABASE_DEFAULT NULL, [Sexo] [varchar](150) COLLATE DATABASE_DEFAULT NULL,
  [FechaNac] [varchar](10) COLLATE DATABASE_DEFAULT NULL, [Edad] [int] NULL,
  [Confidencial] [varchar](2) COLLATE DATABASE_DEFAULT NULL, [SueldoMensual] [MONEY] NULL,
  [SueldoMensualAnt] [MONEY] NULL, [SueldoMensualDif] [MONEY] NULL, [TRANSFERIDO] [varchar](11) COLLATE DATABASE_DEFAULT NULL,
  [NumSolicitud] [varchar](8) COLLATE DATABASE_DEFAULT NULL, [Perfil] [varchar](50) COLLATE DATABASE_DEFAULT NULL,
  [FechaAutorizacion] [varchar](10) COLLATE DATABASE_DEFAULT NULL, [MontoGMM] [money] NULL,
  [MontoVIDA] [money] NULL, [MontoOTROSPLANES] [money] NULL, [CreditosGMM] [money] NULL,
  [CreditosViDA] [money] NULL, [MontoTotalCreditos] [money] NULL, [MontoTotalCreditosAnt] [money] NULL,
  [DiferenciaCreditos] [money] NULL, [MontoTotalSelecciones] [money] NULL, [MontoTotalSeleccionesAnt] [money] NULL,
  [SobranteCreditos] [money] NULL, [MontoPagCred] [money] NULL, [MontoDescMensual] [money] NULL,
  [MontoDescMensualAnt] [money] NULL, [GrupoParentescoGMM] [varchar](10) NULL, [Excedentes] [money] NULL,
  [ExcedentesAnt] [money] NULL, [MontoFondoAhorroMensual] [money] NULL, [MontoFondoAhorroMensualAnt] [money] NULL,
  [SobranteExcedentes] [money] NULL, [DescuentoEmpleadoFH] [money] NULL, [DescuentoEmpleadoFinal] [money] NULL,
  [SobranteExceFinal] [money] NULL, [CoberturaDesc] [money] NULL, [Q1] [money] NULL, [Q2] [money] NULL,
  [Diferencia] [money] NULL, [CtoEmpleadoNomSeg] [money] NULL, [AplicExcedentes] [money] NULL,
  [NumOficina] [int] NULL, [NomOficina] [varchar](50) NULL, [POFH] [varchar](50) NULL,
  [LocalNumber] [varchar](50) NULL, [PagoEmpresa] [money] NULL, [PagoEmpleado] [money] NULL,
  [CentroCostos] [varchar](100) NULL, [Cobro Tarjeta] [money] NULL
)

CREATE NONCLUSTERED INDEX ix_tablatemp_CveEmpl_empresa ON #tablatemp ([CveEmpl],[empresa]);
CREATE NONCLUSTERED INDEX ix_tablatemp_NumEMpleado ON #tablatemp ([NumEMpleado]);

CREATE TABLE #ff_Empleadotemp (
  [Id_empleado] INT IDENTITY(1,1) PRIMARY KEY,
  [EMId] [int] NOT NULL, [EMIdEmpresa] [int] NOT NULL, [EMIdTitular] [int] NULL,
  [EMIdPerfil] [int] NOT NULL, [EMIdParentesco] [int] NULL, [EMIdSexo] [int] NOT NULL,
  [EMIdEstatus] [int] NOT NULL, [EMFechaEstatus] [datetime] NOT NULL, [EMIdTransferido] [int] NOT NULL,
  [EMNumeroEmpleado] [varchar](20) COLLATE DATABASE_DEFAULT NOT NULL,
  [EMCertificado] [varchar](20) COLLATE DATABASE_DEFAULT NOT NULL,
  [EMApellidoPaterno] [varchar](30) COLLATE DATABASE_DEFAULT NULL,
  [EMApellidoMaterno] [varchar](30) COLLATE DATABASE_DEFAULT NULL,
  [EMNombre1] [varchar](70) COLLATE DATABASE_DEFAULT NOT NULL,
  [EMNombre2] [varchar](30) COLLATE DATABASE_DEFAULT NULL,
  [EMFechaNacimiento] [datetime] NOT NULL, [EMEdad] [int] NOT NULL,
  [EMFechaIngresoEmpresa] [datetime] NULL, [EMFechaBaja] [datetime] NULL,
  [EMFechaAntiguedadGMM] [datetime] NULL, [EMAntiguedadGMM] [decimal](5,2) NOT NULL,
  [EMPuesto] [varchar](100) COLLATE DATABASE_DEFAULT NULL, [EMArea] [int] NULL, [EMOficina] [int] NULL,
  [EMrfc] [varchar](20) COLLATE DATABASE_DEFAULT NULL, [EMIdTipoSalario] [int] NOT NULL,
  [EMIdSalarioConfidencial] [int] NOT NULL, [EMSalarioBase] [money] NOT NULL,
  [EMSalarioIntegrado] [money] NOT NULL, [EMSalarioBruto] [money] NOT NULL,
  [EMSalarioNeto] [money] NOT NULL, [EMDeduccionesM] [money] NOT NULL, [EMDeduccionesP] [decimal](3,2) NOT NULL,
  [EMPrestacionesM] [money] NOT NULL, [EMPrestacionesP] [decimal](3,2) NOT NULL,
  [EMFondoAhorroM] [money] NOT NULL, [EMFondoAhorroP] [decimal](3,2) NOT NULL,
  [EMFondoAhorroAcumulado] [money] NOT NULL, [EMValesM] [money] NOT NULL, [EMValesP] [decimal](3,2) NOT NULL,
  [EMExcedente] [money] NOT NULL, [EMBeneficioMaximoM] [money] NOT NULL, [EMBeneficioMaximoP] [money] NOT NULL,
  [EMBeneFicioOtorgadoM] [money] NOT NULL, [EMBeneFicioOtorgadoP] [decimal](3,2) NOT NULL,
  [EMVIP] [int] NOT NULL, [EMIdRol] [int] NOT NULL, [EMidCentroCostos] [int] NULL,
  [EMNetForbes] [int] NOT NULL, [EMDiasVacacionesporGozar] [int] NULL, [EMMesFechaUmod] [int] NULL,
  [EMAnioFechaUmod] [int] NULL, [EMModificaciones] [int] NULL, [EMAplicacion] [int] NULL,
  [EMMismaEmpresa] [int] NULL, [EMIdEmpresaAnt] [int] NOT NULL, [EMIdAnt] [int] NOT NULL
)

CREATE NONCLUSTERED INDEX ix_ff_empleadotemp_repoCobr ON #ff_empleadotemp ([EMNumeroEmpleado],[emidAnt],[Emidempresa],[EmidParentesco]);

-- LOG PRE-EMPLEADOS ──────────────────────────────────────────
SET @_dbg_etapa = 'cobranza_obten_pre_empleados';
SET @_dbg_detalle = 'cantidadPagos=' + CAST(@cantidadPagos AS VARCHAR) + ' MesApl=' + CAST(@MesApl AS VARCHAR) + ' AnioApl=' + CAST(@AnioApl AS VARCHAR);
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES(@_dbg_etapa,@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
-- ─────────────────────────────────────────────────────────────

EXEC ff_ObtenEmpleadosCob_V2_bf3 @idEmpresa, @FecIni, @FecFinHoras, @idVencida, @IdPerfil

-- LOG POST-EMPLEADOS ─────────────────────────────────────────
SET @_dbg_detalle = 'filas_empleadotemp=' + CAST((SELECT COUNT(1) FROM #ff_Empleadotemp) AS VARCHAR);
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES('cobranza_obten_post_empleados',@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
-- ─────────────────────────────────────────────────────────────

IF EXISTS(SELECT TOP 1 * FROM #ff_Empleadotemp)
BEGIN
    SELECT @empresa = (SELECT TOP 1 EMIDEmpresaAnt FROM #ff_Empleadotemp)

    -- Diagnóstico: cuenta filas por cada filtro para identificar cuál produce 0
    DECLARE @_d1 INT, @_d2 INT, @_d3 INT, @_d4 INT, @_d5 INT, @_d6 INT, @_d7 INT, @_d8 INT, @_d9 INT;
    SELECT @_d1=COUNT(1) FROM dbo.ff_EdoCuentaCobranza WITH(NOLOCK) WHERE ECidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas);
    SELECT @_d2=COUNT(1) FROM dbo.ff_Solicitud WITH(NOLOCK) WHERE SOidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND SOIdVigencia=@idVigencia AND SOidEstatus=@SOIdEstatus;
    SELECT @_d3=COUNT(1) FROM dbo.ff_Solicitud WITH(NOLOCK) WHERE SOidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND SOIdVigencia=@idVigencia AND SOidEstatus=@SOIdEstatus AND SOEstatusSolicitud=1;
    SELECT @_d4=COUNT(1) FROM dbo.ff_Solicitud WITH(NOLOCK) WHERE SOidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND SOIdVigencia=@idVigencia AND SOidEstatus=@SOIdEstatus AND SOIdSolicitudTipo=1;
    SELECT @_d5=COUNT(1) FROM dbo.ff_Solicitud WITH(NOLOCK) WHERE SOidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND SOIdVigencia=@idVigencia AND SOidEstatus=@SOIdEstatus AND ISNULL(SOFechaAprovacion,CAST(GETDATE() AS DATE))>=@FecIni AND ISNULL(SOFechaAprovacion,CAST(GETDATE() AS DATE))<=@FecFinHoras;
    SELECT @_d6=COUNT(DISTINCT S.SOIdSolicitud) FROM dbo.ff_Solicitud S WITH(NOLOCK) INNER JOIN dbo.ff_EdoCuentaCobranza EC WITH(NOLOCK) ON EC.ECidSolicitud=S.SOidSolicitud AND EC.ECidEmpresa=S.SOIdEmpresa WHERE S.SOidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND S.SOIdVigencia=@idVigencia;
    -- Diagnosticos adicionales: cuánto hay en ff_EdoCuenta y ff_EdoCuentaCobranza2
    SELECT @_d7=COUNT(1) FROM dbo.ff_EdoCuenta WITH(NOLOCK) WHERE ECidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND ECIdEstatus <> 10;
    SELECT @_d8=COUNT(1) FROM dbo.ff_EdoCuentaCobranza2 WITH(NOLOCK) WHERE ECidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND ECIdEstatus <> 10;
    SELECT @_d9=COUNT(DISTINCT S.SOIdSolicitud) FROM dbo.ff_Solicitud S WITH(NOLOCK) INNER JOIN dbo.ff_EdoCuentaCobranza2 EC WITH(NOLOCK) ON EC.ECidSolicitud=S.SOidSolicitud AND EC.ECidEmpresa=S.SOIdEmpresa WHERE S.SOidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND S.SOIdVigencia=@idVigencia;
    -- Top 5 vigencias con datos en ff_EdoCuentaCobranza para esta empresa
    DECLARE @_vigencias NVARCHAR(500) = '';
    SELECT @_vigencias = @_vigencias + 'v' + CAST(SOIdVigencia AS VARCHAR(10)) + '=' + CAST(cnt AS VARCHAR(10)) + ' '
    FROM (
        SELECT TOP 5 S.SOIdVigencia, COUNT(DISTINCT EC.ECidSolicitud) AS cnt
        FROM dbo.ff_EdoCuentaCobranza EC WITH(NOLOCK)
        INNER JOIN dbo.ff_Solicitud S WITH(NOLOCK) ON EC.ECidSolicitud=S.SOidSolicitud AND EC.ECidEmpresa=S.SOIdEmpresa
        WHERE EC.ECidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas)
        GROUP BY S.SOIdVigencia
        ORDER BY COUNT(DISTINCT EC.ECidSolicitud) DESC
    ) t;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES('cobranza_obten_vigencias_ec',
        'vigencia_actual='+CAST(@idVigencia AS VARCHAR)+' top5_con_datos: '+ISNULL(@_vigencias,'ninguna'));
    END TRY BEGIN CATCH END CATCH;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES('cobranza_obten_pre_insert_diag',
        'ec_cobranza='+CAST(ISNULL(@_d1,0) AS VARCHAR)+
        ' sol_vig='+CAST(ISNULL(@_d2,0) AS VARCHAR)+
        ' sol_estatus1='+CAST(ISNULL(@_d3,0) AS VARCHAR)+
        ' sol_tipo1='+CAST(ISNULL(@_d4,0) AS VARCHAR)+
        ' sol_rango_fecha='+CAST(ISNULL(@_d5,0) AS VARCHAR)+
        ' join_ec_cobranza='+CAST(ISNULL(@_d6,0) AS VARCHAR)+
        ' ff_EdoCuenta='+CAST(ISNULL(@_d7,0) AS VARCHAR)+
        ' ff_EdoCuentaCobranza2='+CAST(ISNULL(@_d8,0) AS VARCHAR)+
        ' join_ec_cobranza2='+CAST(ISNULL(@_d9,0) AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    -- Una sola pasada sobre ff_EdoCuentaCobranza2 elimina ~10 subconsultas correlacionadas por fila
    CREATE TABLE #ec_agg (ECidSolicitud INT, ECidEmpleado INT, ECidEmpresa INT,
        a_caco1_mv2 DECIMAL(18,4), a_ec2_mv1 DECIMAL(18,4), a_caco5_mv2 DECIMAL(18,4),
        a_caco3_ec1_mv1 DECIMAL(18,4), a_caco4_ec1_mv1 DECIMAL(18,4),
        a_comp DECIMAL(18,4), a_mv2_po DECIMAL(18,4), a_ec6 DECIMAL(18,4), a_ec7_mv1 DECIMAL(18,4));
    INSERT INTO #ec_agg
    SELECT EC.ECidSolicitud, EC.ECidEmpleado, EC.ECidEmpresa,
        SUM(CASE WHEN CA1.CAidPlanOpcion IS NOT NULL AND EC.ECTipoMovto=2 THEN ISNULL(EC.ECCantidad,0) ELSE 0 END),
        SUM(CASE WHEN EC.ECTipoMovto=1 AND EC.ECIdConcepto=2 THEN ISNULL(EC.ECCantidad,0) ELSE 0 END),
        SUM(CASE WHEN CA5.CAidPlanOpcion IS NOT NULL AND EC.ECTipoMovto=2 THEN ISNULL(EC.ECCantidad,0) ELSE 0 END),
        SUM(CASE WHEN CA3.CAidPlanOpcion IS NOT NULL AND EC.ECTipoMovto=1 AND EC.ECIdConcepto=1 THEN ISNULL(EC.ECCantidad,0) ELSE 0 END),
        SUM(CASE WHEN CA4.CAidPlanOpcion IS NOT NULL AND EC.ECTipoMovto=1 AND EC.ECIdConcepto=1 THEN ISNULL(EC.ECCantidad,0) ELSE 0 END),
        SUM(CASE WHEN EC.ecidcompensacion IS NOT NULL AND EC.ecIdConcepto NOT IN(7,6) THEN ISNULL(EC.ECCantidad,0) ELSE 0 END),
        SUM(CASE WHEN EC.ECTipoMovto=2 AND EC.ECidPlanOpcion IS NOT NULL THEN ISNULL(EC.ECCantidad,0) ELSE 0 END),
        SUM(CASE WHEN EC.ECTipoMovto IN(2,1) AND EC.ECidConcepto=6 THEN ISNULL(EC.ECCantidad,0) ELSE 0 END),
        SUM(CASE WHEN EC.ECTipoMovto=1 AND EC.ECidConcepto=7 THEN ISNULL(EC.ECCantidad,0) ELSE 0 END)
    FROM dbo.ff_EdoCuentaCobranza2 EC WITH(NOLOCK)
    LEFT JOIN dbo.ff_ConcepAgrupaCob CA1 WITH(NOLOCK) ON EC.ECidPlanOpcion=CA1.CAidPlanOpcion AND EC.ECidEmpresa=CA1.CAidEmpresa AND CA1.CACOid=1 AND CA1.CAidEstatus=1
    LEFT JOIN dbo.ff_ConcepAgrupaCob CA5 WITH(NOLOCK) ON EC.ECidPlanOpcion=CA5.CAidPlanOpcion AND EC.ECidEmpresa=CA5.CAidEmpresa AND CA5.CACOid=5 AND CA5.CAidEstatus=1
    LEFT JOIN dbo.ff_ConcepAgrupaCob CA3 WITH(NOLOCK) ON EC.ECidPlanOpcion=CA3.CAidPlanOpcion AND EC.ECidEmpresa=CA3.CAidEmpresa AND CA3.CACOid=3 AND CA3.CAidEstatus=1
    LEFT JOIN dbo.ff_ConcepAgrupaCob CA4 WITH(NOLOCK) ON EC.ECidPlanOpcion=CA4.CAidPlanOpcion AND EC.ECidEmpresa=CA4.CAidEmpresa AND CA4.CACOid=4 AND CA4.CAidEstatus=1
    WHERE EC.ECidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas)
    GROUP BY EC.ECidSolicitud, EC.ECidEmpleado, EC.ECidEmpresa;
    CREATE NONCLUSTERED INDEX ix_ec_agg ON #ec_agg(ECidSolicitud, ECidEmpleado, ECidEmpresa);

    INSERT INTO #tablatemp (empresa,NumEMpleado,CveEmpl,Paterno,MAterno,Nombre1,Nombre2,Sexo,FechaNac,Edad,Confidencial,SueldoMensual,SueldoMensualAnt,TRANSFERIDO,NumSolicitud,Perfil,FechaAutorizacion,MontoGMM,MontoVIDA,MontoOTROSPLANES,CreditosGMM,CreditosViDA,MontoTotalCreditos,MontoTotalCreditosAnt,MontoTotalSelecciones,MontoTotalSeleccionesAnt,SobranteCreditos,MontoPagCred,MontoDescMensual,MontoDescMensualAnt,GrupoParentescoGMM,Excedentes,ExcedentesAnt,MontoFondoAhorroMensual,MontoFondoAhorroMensualAnt,SobranteExcedentes,DescuentoEmpleadoFH,DescuentoEmpleadoFinal,SobranteExceFinal,CoberturaDesc,Q1,Q2,Diferencia,CtoEmpleadoNomSeg,AplicExcedentes,NumOficina,NomOficina,POFH,LocalNumber,CentroCostos)
    SELECT
        E.EMIdempresa,RTRIM(E.EMNumeroEmpleado),E.emidAnt,ISNULL(E.EMApellidoPaterno,''),ISNULL(E.EMApellidoMaterno,''),
        ISNULL(E.EMNombre1,''),ISNULL(E.EMNombre2,''),SE.SEDescripcion,CONVERT(VARCHAR(10),E.EMFechaNacimiento,103),
        E.EMEdad,CASE WHEN E.EMIdSalarioConfidencial IS NULL THEN 'NO' WHEN E.EMIdSalarioConfidencial=0 THEN 'NO' ELSE 'SI' END,
        CASE WHEN EMIdSalarioConfidencial IS NULL THEN E.EMSalarioBase WHEN EMIdSalarioConfidencial=0 THEN E.EMSalarioBase ELSE E.EMSalarioBase END,
        SueldoMenAnt=ISNULL((SELECT TOP 1 ccSueldoMensual FROM dbo.ff_CobranzaConcentrada WITH(NOLOCK,READUNCOMMITTED) INNER JOIN #ff_empleadotemp EM WITH(NOLOCK,READUNCOMMITTED) ON EM.EMNumeroEmpleado=ccnumeroempleado WHERE ccidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND EM.Emidempresa=ccidempresa AND ccidempleado=E.emidAnt AND ccaño=@AnioApl AND ccmes=@MesApl),0),
        CASE WHEN E.EMidTransferido IS NULL THEN 'NO' WHEN E.EMidTransferido=0 THEN 'NO' ELSE 'TRANSFERIDO' END,
        CAST(ISNULL(SONumeroSolicitud,'') AS VARCHAR(5))+'-'+CAST(ISNULL(SOAnexoSolicitud,'') AS VARCHAR(2)),
        PENombre,CONVERT(VARCHAR(10),SOFechaAprovacion,103),
        ROUND(ISNULL(MAX(ISNULL(EA.a_caco1_mv2,0))/@cantidadPagos,0),2),
        ROUND(ISNULL(MAX(ISNULL(EA.a_caco1_mv2,0))/@cantidadPagos - ROUND(ISNULL(MAX(ISNULL(EA.a_ec2_mv1,0))/@cantidadPagos,0),2),0),2),
        ROUND(ISNULL(MAX(ISNULL(EA.a_caco5_mv2,0))/@cantidadPagos,0),2),
        ROUND(ISNULL(MAX(ISNULL(EA.a_caco3_ec1_mv1,0))/@cantidadPagos,0),2),
        ROUND(ISNULL(MAX(ISNULL(EA.a_caco4_ec1_mv1,0))/@cantidadPagos,0),2),
        ROUND(ISNULL(MAX(ISNULL(EA.a_comp,0))/@cantidadPagos,0),2),
        (SELECT TOP 1 ISNULL(ccTotalCreditos,0) FROM dbo.ff_CobranzaConcentrada es WITH(NOLOCK,READUNCOMMITTED) INNER JOIN #ff_empleadotemp EM WITH(NOLOCK,READUNCOMMITTED) ON EM.EMNumeroEmpleado=ccnumeroempleado WHERE ccidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND ccidempresa=EM.Emidempresa AND ccidempleado=E.emidAnt AND ccaño=@AnioApl AND ccmes=@MesApl AND es.ccidVigencia=@idVIgencia),
        ROUND(ISNULL(MAX(ISNULL(EA.a_mv2_po,0))/@cantidadPagos - ROUND(ISNULL(MAX(ISNULL(EA.a_ec2_mv1,0))/@cantidadPagos,0),2),0),2),
        (SELECT TOP 1 ISNULL(ccTotalCostos,0) FROM dbo.ff_CobranzaConcentrada es WITH(NOLOCK,READUNCOMMITTED) INNER JOIN #ff_empleadotemp EM WITH(NOLOCK,READUNCOMMITTED) ON EM.EMNumeroEmpleado=ccnumeroempleado WHERE ccidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND ccidempresa=EM.Emidempresa AND ccidempleado=E.emidAnt AND ccaño=@AnioApl AND ccmes=@MesApl AND es.ccidVigencia=@idVIgencia),
        ROUND(ISNULL(MAX(ISNULL(EA.a_ec6,0))/@cantidadPagos,0),2),
        0, 0,
        (SELECT TOP 1 ISNULL(ccDescuentoEmpleado,0) FROM dbo.ff_CobranzaConcentrada es WITH(NOLOCK,READUNCOMMITTED) INNER JOIN #ff_empleadotemp EM WITH(NOLOCK,READUNCOMMITTED) ON em.EMNumeroEmpleado=ccnumeroempleado WHERE ccidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND ccidempresa=EM.Emidempresa AND ccidempleado=e.emidAnt AND ccaño=@AnioApl AND ccmes=@MesApl AND es.ccidVigencia=@idVIgencia),
        (SELECT TOP 1 GP.GPNombre FROM dbo.ff_planopcionseleccionCobranza POS WITH(NOLOCK,READUNCOMMITTED) INNER JOIN dbo.#ff_empleadotemp em WITH(NOLOCK,READUNCOMMITTED) ON em.EMNumeroEmpleado=POS.POnumeroempleado INNER JOIN dbo.ff_ConcepAgrupaCob CAC WITH(NOLOCK,READUNCOMMITTED) ON POS.POidplanopcion=CAC.CAidplanopcion INNER JOIN dbo.ff_GrupoParentesco GP WITH(NOLOCK,READUNCOMMITTED) ON POS.POidGrupoParentesco=GP.GPidGrupoParentesco INNER JOIN dbo.ff_PlanOpcion PO WITH(NOLOCK,READUNCOMMITTED) ON POS.POIdPlanOpcion=PO.POIdPlanOpcion INNER JOIN dbo.ff_Plan P WITH(NOLOCK,READUNCOMMITTED) ON PO.POIdPlan=P.PLIdPlan AND P.PLIdEstatus=1 INNER JOIN dbo.ff_Ramo Ra WITH(NOLOCK,READUNCOMMITTED) ON Ra.RAIdRamo=PLIDRamo WHERE POS.POidEmpresa=CAC.CAidEmpresa AND POS.poidempresa=EM.EMidempresa AND POS.PoidEstatus=@SOIdEstatus AND POS.POidGrupoParentesco IS NOT NULL AND em.emidempresa=E.EMIdempresa AND em.EMNumeroEmpleado=E.emnumeroempleado AND EM.EmidParentesco=1 AND PO.POidestatus=1 AND Ra.RaidRamoForbes=5 AND POS.POIdVigencia=@idVIgencia),
        ROUND(ISNULL((SELECT ISNULL(SUM(CETotalCreditos),0) FROM dbo.ff_compensacionempleado CE WITH(NOLOCK,READUNCOMMITTED) WHERE CE.Ceidempleado=E.emidAnt)/@cantidadPagos,0),2),
        (SELECT TOP 1 ISNULL(ccExcedentes,0) FROM dbo.ff_CobranzaConcentrada WITH(NOLOCK,READUNCOMMITTED) INNER JOIN dbo.#ff_empleadotemp EM WITH(NOLOCK,READUNCOMMITTED) ON EM.EMNumeroEmpleado=ccnumeroempleado WHERE ccidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND ccidempresa=EM.Emidempresa AND ccidempleado=E.emidAnt AND ccaño=@AnioApl AND ccmes=@MesApl AND ccidVigencia=@idVigencia),
        ROUND(ISNULL((SELECT SUM(ISNULL(POTArifaNeta,0)) FROM dbo.ff_planopcionseleccionCobranza POS WITH(NOLOCK,READUNCOMMITTED), dbo.ff_planopcionperfil WITH(NOLOCK,READUNCOMMITTED), dbo.ff_planopcion PO WITH(NOLOCK,READUNCOMMITTED), dbo.ff_plan WITH(NOLOCK,READUNCOMMITTED) WHERE ppidperfil IN(SELECT emidperfil FROM dbo.ff_empleado WITH(NOLOCK,READUNCOMMITTED) WHERE emidtitular=1 AND emidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND emnumeroempleado=E.emnumeroempleado) AND POS.POidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND ponumeroempleado=E.emnumeroempleado AND PLFondodeAhorro=1 AND pos.poidsolicitud=soidsolicitud AND POS.poidplanopcion=ppidplanopcion AND plidplan=PO.poidplan AND POS.POidplanopcion=PO.poidplanopcion AND POS.POidSolicitud=SOIdSolicitud)/@cantidadPagos,0),2),
        (SELECT TOP 1 ISNULL(ccFondoAhorro,0) FROM dbo.ff_CobranzaConcentrada WITH(NOLOCK,READUNCOMMITTED) INNER JOIN #ff_empleadotemp EM WITH(NOLOCK,READUNCOMMITTED) ON EM.EMNumeroEmpleado=ccnumeroempleado WHERE ccidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND EM.Emidempresa=ccidempresa AND ccidempleado=E.emidAnt AND ccaño=@AnioApl AND ccmes=@MesApl AND ccidvigencia=@idVigencia),
        ROUND(ISNULL(MAX(ISNULL(EA.a_ec7_mv1,0))/@cantidadPagos,0),2),
        0, 0, 0,
        ROUND(ISNULL(MAX(ISNULL(EA.a_ec2_mv1,0))/@cantidadPagos,0),2),
        0, 0, 0, 0, 0,
        emOficina,
        (SELECT TOP 1 TEDescripcion FROM ff_TablaEncabezadoDetalle WITH(NOLOCK) INNER JOIN ff_TablaEncabezado WITH(NOLOCK) ON Enclave=teEnclave AND enidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas) AND enEncabezado LIKE '%Oficina%' WHERE teidDetalle=emOficina),
        ISNULL((SELECT TOP 1 PoDescripcion FROM ff_PlanOpcion PO, ff_planOpcionSeleccionCobranza posc, ff_Plan, ff_Empleado WHERE posc.poidplanopcion=PO.poidplanopcion AND posc.poidVigencia=@idVigencia AND plidplan=PO.poidplan AND posc.poidEmpresa=emIdEmpresa AND posc.poNumeroEmpleado=emNumeroEMpleado AND emidParentesco=1 AND PLFondodeAhorro=1 AND posc.poidsolicitud=soidsolicitud AND id=posc.poidEmpleado AND emidEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas)),''),
        ISNULL((SELECT TOP 1 RTRIM(desarrollo) FROM ff_Empleado EE WITH(NOLOCK,READUNCOMMITTED) WHERE EE.ID=E.emidAnt),''),
        ISNULL((SELECT TOP 1 DBO.DescripcionCatalogo(EE.emidempresa,'EMidCentroCostos',EE.EMidCentroCostos) FROM ff_Empleado EE WITH(NOLOCK,READUNCOMMITTED) WHERE EE.ID=E.emidAnt),'')
    FROM dbo.ff_solicitud WITH(NOLOCK,READUNCOMMITTED)
    INNER JOIN dbo.ff_EdoCuentaCobranza2 EC WITH(NOLOCK,READUNCOMMITTED) ON EC.ECidSolicitud=SOidSolicitud AND ECidEmpresa=SOIdEmpresa AND SOIdEmpleado=EC.ECidEmpleado
    INNER JOIN dbo.#ff_empleadotemp E WITH(NOLOCK) ON EC.ECidEmpleado=E.emidAnt
    INNER JOIN dbo.ff_Sexo SE WITH(NOLOCK) ON E.EMIdSexo=SE.SEidSexo
    INNER JOIN dbo.ff_Perfil P WITH(NOLOCK) ON E.EMidPerfil=P.PEidPerfil AND E.EMidEmpresa=P.PEidEmpresa
    INNER JOIN dbo.ff_ConcepAgrupaCob CA WITH(NOLOCK) ON EC.ECidPlanOpcion=CA.CAidPlanOpcion AND EC.ECidEmpresa=CA.CAidEmpresa
    LEFT JOIN #ec_agg EA ON EA.ECidSolicitud=SOIdSolicitud AND EA.ECidEmpleado=EC.ECidEmpleado AND EA.ECidEmpresa=EC.ECidEmpresa
    WHERE SOIdVigencia=@idVigencia AND SOidEstatus=@SOIdEstatus AND SOEstatusSolicitud=1 AND SOIdSolicitudTipo=1
    AND isnull(SOFechaAprovacion,cast(getdate() As Date)) <= @FecFinHoras
    AND isnull(SOFechaAprovacion,cast(getdate() As Date)) >= @FecIni
    AND P.PEidPerfil IN(SELECT IdTipoNotificacionCorreo FROM #IdPerfilV2)
    AND SOidempresa IN(SELECT EMidEmpresa FROM #ListEmpresas)
    GROUP BY EMIdempresa,E.EMNumeroEmpleado,E.EmidAnt,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,SE.SEDescripcion,
             Convert(varchar(10),E.EMFechaNacimiento,103),EMEdad,EMSalarioBase,E.EMIdTransferido,soidsolicitud,
             (CAST(ISNULL(SONumeroSolicitud,'') AS VARCHAR(5))+'-'+CAST(ISNULL(SOAnexoSolicitud,'') AS VARCHAR(2))),
             PENombre,CONVERT(VARCHAR(10),SOFechaAprovacion,103),E.EMIdSalarioConfidencial,E.EMOficina
    ORDER BY E.EmidAnt

END

-- LOG POST-INSERT-TABLATEMP ──────────────────────────────────
SET @_dbg_etapa = 'cobranza_obten_post_insert';
SET @_dbg_detalle = 'filas_tablatemp=' + CAST((SELECT COUNT(1) FROM #tablatemp) AS VARCHAR);
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES(@_dbg_etapa,@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
-- ─────────────────────────────────────────────────────────────

IF EXISTS(SELECT TOP 1 * FROM #tablatemp WITH(NOLOCK))
BEGIN
    SET @total_registros = ISNULL((SELECT COUNT(*) FROM #tablatemp), 0)
    SET @contador_registros = 1

    -- LOG WHILE-INICIO ───────────────────────────────────────
    SET @_dbg_etapa = 'cobranza_obten_while_inicio';
    SET @_dbg_detalle = 'total_registros=' + CAST(@total_registros AS VARCHAR);
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES(@_dbg_etapa,@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
    -- ─────────────────────────────────────────────────────────

    DECLARE @MontoPagCred MONEY = 0,
            @DescuentoEmpleadoFH MONEY = 0,
            @MontoFondoAhorroMensual MONEY = 0,
            @SobranteExcedentes MONEY = 0,
            @DescuentoEmpleadoFinal MONEY = 0,
            @SobranteExcefinal MONEY = 0;

    WHILE @total_registros > 0 AND @contador_registros <= @total_registros
    BEGIN
        -- log cada 50 iteraciones para no saturar la tabla
        IF @contador_registros % 50 = 1
        BEGIN
            SET @_dbg_etapa = 'cobranza_obten_while_iter';
            SET @_dbg_detalle = 'contador=' + CAST(@contador_registros AS VARCHAR) + ' de ' + CAST(@total_registros AS VARCHAR);
            BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES(@_dbg_etapa,@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
        END

        SELECT @empresa = Empresa, @intCveEmpl = CveEmpl,
               @MontoTotalSelecciones = MontoTotalSelecciones,
               @MontoTotalCreditos = MontoTotalCreditos,
               @SobranteCreditos = SobranteCreditos,
               @CoberturaRegalo = CoberturaDesc,
               @MontoFHMen = MontoFondoAhorroMensual,
               @Excedente = Excedentes,
               @SobExcedentes = SobranteExcedentes,
               @NumEMpleado = NumEMpleado,
               @DescuentoEmpleadoFH = DescuentoEmpleadoFH,
               @DescuentoEmpleadoFinal = DescuentoEmpleadoFinal,
               @SobranteExcefinal = SobranteExcefinal
        FROM #tablatemp WITH(NOLOCK)
        WHERE Id_tablatemp = @contador_registros

        SET @MontoFondoAhorroMensual = @MontoFHMen;
        SET @SobranteExcedentes = @SobExcedentes;

        IF @MontoTotalSelecciones > @MontoTotalCreditos
            SET @MontoPagCred = @MontoTotalCreditos - isnull(@SobranteCreditos, 0)
        ELSE
            SET @MontoPagCred = @MontoTotalSelecciones

        SELECT @MtoDescMen = CASE
            WHEN (ISNULL(MontoTotalCreditos,0) - ISNULL(SobranteCreditos,0)) - ISNULL(MontoTotalSelecciones,0) < 0
                THEN ISNULL(MontoTotalSelecciones,0) - (ISNULL(MontoTotalCreditos,0) - ISNULL(SobranteCreditos,0))
            ELSE (ISNULL(MontoTotalCreditos,0) - ISNULL(SobranteCreditos,0)) - ISNULL(MontoTotalSelecciones,0)
            END
        FROM #tablatemp WITH(NOLOCK)
        WHERE CveEmpl = @intCveEmpl AND empresa = @empresa

        IF @Excedente > 0
        BEGIN
            IF (@MontoFHMen = @SobExcedentes) AND (@Excedente > @MtoDescMen)
            BEGIN SET @MontoFondoAhorroMensual = ABS(isnull(@Excedente-@MtoDescMen,0)); SET @SobranteExcedentes = @MtoDescMen; END

            IF (@Excedente < @MtoDescMen) AND (@MontoFHMen = @SobExcedentes) AND (@MontoFHMen > 0)
            BEGIN SET @MontoFondoAhorroMensual = 0; SET @SobranteExcedentes = CASE WHEN @MontoFHMen = 0 THEN @Excedente END; SET @DescuentoEmpleadoFinal = ABS(isnull(@MtoDescMen-@Excedente,0)); SET @SobranteExcefinal = 0; END

            IF (@Excedente > 0) AND (@MontoFHMen <> @SobExcedentes)
            BEGIN
                IF @MontoFHMen > @Excedente
                BEGIN SET @SobranteExcedentes = 0; SET @DescuentoEmpleadoFinal = (@MontoFHMen-@Excedente)+@MtoDescMen; SET @DescuentoEmpleadoFH = (@MontoFHMen-@Excedente); END
                ELSE
                BEGIN
                    SET @SobranteExcedentes = CASE WHEN @Excedente-@MontoFHMen < 0 THEN 0 ELSE @Excedente-@MontoFHMen END;
                    SET @DescuentoEmpleadoFinal = CASE WHEN @Excedente-(@MontoFHMen+@MtoDescMen) < 0 THEN (@MontoFHMen+@MtoDescMen)-@Excedente ELSE 0 END;
                    SET @SobranteExcefinal = CASE WHEN @Excedente-(@MontoFHMen+@MtoDescMen) < 0 THEN 0 ELSE @Excedente-(@MontoFHMen+@MtoDescMen) END;
                    SET @DescuentoEmpleadoFH = CASE WHEN @Excedente-@MontoFHMen < 0 THEN @MontoFHMen-@Excedente ELSE 0 END;
                END
            END

            IF (@Excedente > 0) AND (@MontoFHMen = 0)
            BEGIN
                SET @MontoFondoAhorroMensual = 0;
                SET @SobranteExcedentes = @Excedente;
                SET @DescuentoEmpleadoFinal = CASE WHEN @Excedente-@MtoDescMen > 0 THEN 0 ELSE @MtoDescMen-@Excedente END;
                SET @SobranteExcefinal = CASE WHEN @Excedente-@MtoDescMen > 0 THEN @Excedente-@MtoDescMen ELSE 0 END;
            END
        END
        ELSE
        BEGIN
            SET @SobranteExcedentes = 0;
            SET @DescuentoEmpleadoFinal = ISNULL(@MontoFHMen,0) + ISNULL(@MtoDescMen,0);
            SET @DescuentoEmpleadoFH = ISNULL(@MontoFHMen,0);
        END

        UPDATE #tablatemp
        SET MontoDescMensual = ABS(@MtoDescMen), MontoPagCred = @MontoPagCred,
            DescuentoEmpleadoFH = @DescuentoEmpleadoFH, MontoFondoAhorroMensual = @MontoFondoAhorroMensual,
            SobranteExcedentes = @SobranteExcedentes, DescuentoEmpleadoFinal = @DescuentoEmpleadoFinal,
            SobranteExcefinal = @SobranteExcefinal
        WHERE CveEmpl = @intCveEmpl AND empresa = @empresa

        SELECT @DEImporte1 = (SELECT DISTINCT ISNULL(DescuentoEmpleadoFinal,0) FROM #tablatemp WHERE CveEmpl = @intCveEmpl)
                           - (SELECT DISTINCT ISNULL(DescuentoEmpleadoFH,0)    FROM #tablatemp WHERE CveEmpl = @intCveEmpl)

        UPDATE #tablatemp SET CtoEmpleadoNomSeg = ABS(@DEImporte1) WHERE CveEmpl = @intCveEmpl

        SET @DEImporte1 = 0; SET @DEImporte2 = 0;

        SELECT @DEImporte1 = DEImporte FROM ff_DescuentoEmpleado WITH(NOLOCK)
        WHERE DENumeroEmpleado=@NumEMpleado AND DEIDQuincena=1 AND DEIdAplicacion=1 AND DEIdAno=@AnioApl AND DEidMes=@MesApl

        SELECT @DEImporte2 = DEImporte FROM ff_DescuentoEmpleado WITH(NOLOCK)
        WHERE DENumeroEmpleado=@NumEMpleado AND DEIDQuincena=2 AND DEIdAplicacion=1 AND DEIdAno=@AnioApl AND DEidMes=@MesApl

        UPDATE #tablatemp
        SET Q1 = @DEImporte1, Q2 = @DEImporte2, Diferencia = @MtoDescMen - (@DEImporte1+@DEImporte2)
        WHERE NumEMpleado = @NumEMpleado

        SET @contador_registros = @contador_registros + 1
    END

    -- LOG WHILE-FIN ──────────────────────────────────────────
    SET @_dbg_etapa = 'cobranza_obten_while_fin';
    SET @_dbg_detalle = 'procesados=' + CAST(@contador_registros-1 AS VARCHAR) + ' de ' + CAST(@total_registros AS VARCHAR);
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES(@_dbg_etapa,@_dbg_detalle); END TRY BEGIN CATCH END CATCH;
    -- ─────────────────────────────────────────────────────────
END

UPDATE #tablatemp
SET SueldoMensualDif = SueldoMensual - ISNULL(SueldoMensualAnt,0),
    [DiferenciaCreditos] = isnull([MontoTotalCreditos],0) - ISNULL([MontoTotalCreditosAnt],0)

-- LOG PRE-DESGLOSADA ─────────────────────────────────────────
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES('cobranza_obten_pre_desglosada','Invocando ff_ObtenCobranzaDesg_Adaptada_bf3_nousar'); END TRY BEGIN CATCH END CATCH;
-- ─────────────────────────────────────────────────────────────

EXEC dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_nousar @idEmpresa, @FecIni, @FecFinHoras, @IdPerfil, @idVIgencia

-- LOG FIN ────────────────────────────────────────────────────
BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle) VALUES('cobranza_obten_fin','SP completado'); END TRY BEGIN CATCH END CATCH;
-- ─────────────────────────────────────────────────────────────

END;
GO
