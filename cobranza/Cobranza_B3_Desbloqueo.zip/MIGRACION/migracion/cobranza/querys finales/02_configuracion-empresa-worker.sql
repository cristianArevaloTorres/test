/*
configurar parametros de hoario para el worker 
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int = 186;
DECLARE @HoraWorker varchar(5) = '01:00';
DECLARE @Usuario int = 1;

IF LEN(@HoraWorker)<>5
   OR SUBSTRING(@HoraWorker,3,1)<>':'
   OR TRY_CONVERT(int,LEFT(@HoraWorker,2)) NOT BETWEEN 0 AND 23
   OR TRY_CONVERT(int,RIGHT(@HoraWorker,2)) NOT BETWEEN 0 AND 59
    THROW 52000,
        'La hora del worker debe tener formato HH:mm (00:00 a 23:59).',1;

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @IdCache int;
    SELECT TOP (1) @IdCache=paId
    FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=@IdEmpresa
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))='COBRANZA_CACHE'
    ORDER BY paidEstatus DESC,paId DESC;

    IF @IdCache IS NULL
    BEGIN
        SELECT @IdCache=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paidEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@IdCache,@IdEmpresa,'COBRANZA_CACHE','1',
         'Habilita cache V2 de cobranza para la empresa',
         1,@Usuario,GETDATE());
    END
    ELSE
        UPDATE dbo.ff_Parametro WITH (ROWLOCK)
           SET paClase='COBRANZA_CACHE',paValor='1',
               paDescripcion='Habilita cache V2 de cobranza para la empresa',
               paidEstatus=1,paUsuarioUmod=@Usuario,paFechaUmod=GETDATE(),
               paFechaDel=NULL,paUsuarioDel=NULL
         WHERE paId=@IdCache AND paIdEmpresa=@IdEmpresa;

    DECLARE @IdHora int;
    SELECT TOP (1) @IdHora=paId
    FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=0
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))='COBRANZA_CACHE_HORA'
    ORDER BY paidEstatus DESC,paId DESC;

    IF @IdHora IS NULL
    BEGIN
        SELECT @IdHora=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paidEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@IdHora,0,'COBRANZA_CACHE_HORA',@HoraWorker,
         'Horario diario worker cache cobranza (HH:mm, America/Mexico_City)',
         1,@Usuario,GETDATE());
    END
    ELSE
        UPDATE dbo.ff_Parametro WITH (ROWLOCK)
           SET paClase='COBRANZA_CACHE_HORA',paValor=@HoraWorker,
               paDescripcion='Horario diario worker cache cobranza (HH:mm, America/Mexico_City)',
               paidEstatus=1,paUsuarioUmod=@Usuario,paFechaUmod=GETDATE(),
               paFechaDel=NULL,paUsuarioDel=NULL
         WHERE paId=@IdHora AND paIdEmpresa=0;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT paId,paIdEmpresa,LTRIM(RTRIM(paClase)) AS Clase,
       LTRIM(RTRIM(paValor)) AS Valor,paidEstatus
FROM dbo.ff_Parametro
WHERE (paIdEmpresa=@IdEmpresa
       AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE')
   OR (paIdEmpresa=0
       AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE_HORA')
ORDER BY paClase,paIdEmpresa;

