/*
    PASSWORDS INDEPENDIENTES PARA LOS EXCEL 
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int = 186;
DECLARE @HabilitarSabana bit = 0;
DECLARE @HabilitarCobranza bit = 0;
DECLARE @PasswordSabana varchar(1500) = 'CAMBIAR_PASSWORD_SABANA';
DECLARE @PasswordCobranza varchar(1500) = 'CAMBIAR_PASSWORD_COBRANZA';
DECLARE @Usuario int = 1;

IF @HabilitarSabana=1
   AND NULLIF(LTRIM(RTRIM(@PasswordSabana)),'') IS NULL
    THROW 52100,'El password de Sabana no puede estar vacio.',1;
IF @HabilitarCobranza=1
   AND NULLIF(LTRIM(RTRIM(@PasswordCobranza)),'') IS NULL
    THROW 52101,'El password de Cobranza no puede estar vacio.',1;

DECLARE @Configuracion TABLE
(
    Orden int PRIMARY KEY,
    Clase varchar(30),
    Password varchar(1500),
    Descripcion varchar(200),
    Activo bit
);
INSERT @Configuracion VALUES
(1,'SABANA_EXCEL_PASSWORD',@PasswordSabana,
   'Password Excel Sabana de beneficios',@HabilitarSabana),
(2,'COBRANZA_EXCEL_PASSWORD',@PasswordCobranza,
   'Password Excel Reporte de cobranza',@HabilitarCobranza);

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @Orden int=1,@Clase varchar(30),@Password varchar(1500),
            @Descripcion varchar(200),@Activo bit,@PaId int;
    WHILE @Orden<=2
    BEGIN
        SELECT @Clase=Clase,@Password=Password,
               @Descripcion=Descripcion,@Activo=Activo
        FROM @Configuracion WHERE Orden=@Orden;

        SET @PaId=NULL;
        SELECT TOP (1) @PaId=paId
        FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK)
        WHERE paIdEmpresa=@IdEmpresa
          AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))=@Clase
        ORDER BY paId DESC;

        IF @PaId IS NULL
        BEGIN
            SELECT @PaId=ISNULL(MAX(paId),0)+1
            FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK);
            INSERT dbo.ff_Parametro
            (paId,paIdEmpresa,paClase,paValor,paDescripcion,
             paidEstatus,paUsuarioAdd,paFechaAdd)
            VALUES
            (@PaId,@IdEmpresa,@Clase,@Password,@Descripcion,
             @Activo,@Usuario,GETDATE());
        END
        ELSE
            UPDATE dbo.ff_Parametro WITH (ROWLOCK)
               SET paClase=@Clase,paValor=@Password,
                   paDescripcion=@Descripcion,paidEstatus=@Activo,
                   paUsuarioUmod=@Usuario,paFechaUmod=GETDATE(),
                   paFechaDel=NULL,paUsuarioDel=NULL
             WHERE paId=@PaId AND paIdEmpresa=@IdEmpresa;

        SET @Orden+=1;
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT paId,paIdEmpresa,LTRIM(RTRIM(paClase)) AS Clase,
       paDescripcion,paidEstatus,
       CASE WHEN NULLIF(LTRIM(RTRIM(paValor)),'') IS NULL THEN 0 ELSE 1 END
           AS PasswordConfigurado,
       LEN(RTRIM(paValor)) AS LongitudPassword
FROM dbo.ff_Parametro
WHERE paIdEmpresa=@IdEmpresa
  AND UPPER(LTRIM(RTRIM(paClase))) IN
      ('SABANA_EXCEL_PASSWORD','COBRANZA_EXCEL_PASSWORD')
ORDER BY paClase;

