param(
    [string]$Server = '(LocalDB)\MSSQLLocalDB',
    [string]$Database = 'FlexiForbesv2',
    [int]$IdEmpresa = 1806,
    [int]$IdSolTipo = 1,
    [string]$FecIni = '20260801',
    [string]$FecFin = '20260819',
    [int]$IdVencida = 1,
    [int[]]$IdsPerfil = @(),
    [int]$IdVigencia = 3993,
    [int]$CommandTimeoutSeconds = 900,
    [switch]$CompararB2
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function New-PerfilTable {
    param([int[]]$Perfiles)

    $table = New-Object System.Data.DataTable
    [void]$table.Columns.Add('IdTipoNotificacionCorreo', [int])
    foreach ($perfil in ($Perfiles | Sort-Object -Unique)) {
        [void]$table.Rows.Add($perfil)
    }
    return $table
}

function Invoke-CobranzaProcedure {
    param(
        [System.Data.SqlClient.SqlConnection]$Connection,
        [System.Data.SqlClient.SqlTransaction]$Transaction,
        [string]$ProcedureName
    )

    $command = $Connection.CreateCommand()
    $command.Transaction = $Transaction
    $command.CommandType = [System.Data.CommandType]::StoredProcedure
    $command.CommandText = $ProcedureName
    $command.CommandTimeout = $CommandTimeoutSeconds

    [void]$command.Parameters.Add('@idEmpresa', [System.Data.SqlDbType]::Int)
    [void]$command.Parameters.Add('@idSolTipo', [System.Data.SqlDbType]::Int)
    [void]$command.Parameters.Add('@FecIni', [System.Data.SqlDbType]::VarChar, 16)
    [void]$command.Parameters.Add('@FecFin', [System.Data.SqlDbType]::VarChar, 16)
    [void]$command.Parameters.Add('@idVencida', [System.Data.SqlDbType]::Int)
    $perfilParameter = $command.Parameters.Add(
        '@IdPerfil', [System.Data.SqlDbType]::Structured)
    $perfilParameter.TypeName = 'dbo.ListInt'
    [void]$command.Parameters.Add('@idVIgencia', [System.Data.SqlDbType]::Int)

    $command.Parameters['@idEmpresa'].Value = $IdEmpresa
    $command.Parameters['@idSolTipo'].Value = $IdSolTipo
    $command.Parameters['@FecIni'].Value = $FecIni
    $command.Parameters['@FecFin'].Value = $FecFin
    $command.Parameters['@idVencida'].Value = $IdVencida
    $command.Parameters['@IdPerfil'].Value = New-PerfilTable $IdsPerfil
    $command.Parameters['@idVIgencia'].Value = $IdVigencia

    $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $command
    $dataSet = New-Object System.Data.DataSet
    try {
        [void]$adapter.Fill($dataSet)
    }
    catch [System.Data.SqlClient.SqlException] {
        foreach ($sqlError in $_.Exception.Errors) {
            Write-Error ("SQL {0}, procedimiento {1}, linea {2}: {3}" -f `
                $sqlError.Number, $sqlError.Procedure,
                $sqlError.LineNumber, $sqlError.Message)
        }
        throw
    }
    return $dataSet
}

function Invoke-CobranzaB2Procedure {
    param(
        [System.Data.SqlClient.SqlConnection]$Connection,
        [System.Data.SqlClient.SqlTransaction]$Transaction
    )

    if ($IdsPerfil.Count -gt 1) {
        throw 'B2 solo admite un perfil; use cero o un IdsPerfil para compararlo.'
    }

    $command = $Connection.CreateCommand()
    $command.Transaction = $Transaction
    $command.CommandType = [System.Data.CommandType]::StoredProcedure
    $command.CommandText = 'ObtenCobranzaConcentrada'
    $command.CommandTimeout = $CommandTimeoutSeconds

    foreach ($parameterDefinition in @(
        @('@idEmpresa', [System.Data.SqlDbType]::Int, $IdEmpresa),
        @('@idSolTipo', [System.Data.SqlDbType]::Int, $IdSolTipo),
        @('@FecIni', [System.Data.SqlDbType]::VarChar, $FecIni),
        @('@FecFin', [System.Data.SqlDbType]::VarChar, $FecFin),
        @('@idVencida', [System.Data.SqlDbType]::Int, $IdVencida)
    )) {
        $parameter = $command.Parameters.Add(
            $parameterDefinition[0], $parameterDefinition[1])
        $parameter.Value = $parameterDefinition[2]
    }
    $perfil = $command.Parameters.Add('@IdPerfil', [System.Data.SqlDbType]::Int)
    $perfil.Value = if ($IdsPerfil.Count -eq 1) {
        $IdsPerfil[0]
    } else { [DBNull]::Value }

    $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $command
    $dataSet = New-Object System.Data.DataSet
    [void]$adapter.Fill($dataSet)
    return $dataSet
}

function Convert-CellToText {
    param($Value)

    if ($null -eq $Value -or $Value -is [System.DBNull]) { return '<NULL>' }
    if ($Value -is [datetime]) { return $Value.ToString('o') }
    if ($Value -is [byte[]]) { return [Convert]::ToHexString($Value) }
    if ($Value -is [System.IFormattable]) {
        return $Value.ToString($null, [Globalization.CultureInfo]::InvariantCulture)
    }
    return [string]$Value
}

function Get-BusinessContract {
    param([System.Data.DataSet]$DataSet)

    $groups = @{}
    $tableCount = 0
    $rowCount = 0
    $employeeRows = 0

    foreach ($table in $DataSet.Tables) {
        if ($table.Rows.Count -eq 0) { continue }

        $hasGroup = $table.Columns.Contains('grupo')
        if ($hasGroup -and
            [string]$table.Rows[0]['grupo'] -eq 'Informacion') { continue }

        $columns = @($table.Columns | Where-Object {
            $_.ColumnName -notin @('NombrePestana', 'grupo')
        })
        if ($columns.Count -eq 0) { continue }

        $signature = ($columns | ForEach-Object { $_.ColumnName.ToLowerInvariant() }) -join '|'
        if (-not $groups.ContainsKey($signature)) {
            $groups[$signature] = New-Object System.Collections.Generic.List[string]
        }

        foreach ($row in $table.Rows) {
            $values = foreach ($column in $columns) {
                $text = Convert-CellToText $row[$column.ColumnName]
                '{0}:{1}' -f $text.Length, $text
            }
            $groups[$signature].Add(($values -join '|'))
            $rowCount++

            $employeeColumn = $columns | Where-Object {
                $_.ColumnName -ieq 'NumEMpleado'
            } | Select-Object -First 1
            if ($null -ne $employeeColumn) {
                $employeeNumber = [string]$row[$employeeColumn.ColumnName]
                if (-not $employeeNumber.Trim().StartsWith(
                        'TOTAL', [StringComparison]::OrdinalIgnoreCase)) {
                    $employeeRows++
                }
            }
        }
        $tableCount++
    }

    foreach ($key in @($groups.Keys)) {
        $groups[$key] = @($groups[$key] | Sort-Object)
    }

    [pscustomobject]@{
        Groups = $groups
        Tables = $tableCount
        Rows = $rowCount
        EmployeeRows = $employeeRows
    }
}

function Compare-BusinessContract {
    param($Direct, $Cache)

    $allKeys = @($Direct.Groups.Keys + $Cache.Groups.Keys | Sort-Object -Unique)
    $differences = New-Object System.Collections.Generic.List[string]
    foreach ($key in $allKeys) {
        $directRows = @()
        if ($Direct.Groups.ContainsKey($key)) {
            $directRows = @($Direct.Groups[$key])
        }
        $cacheRows = @()
        if ($Cache.Groups.ContainsKey($key)) {
            $cacheRows = @($Cache.Groups[$key])
        }
        if ($directRows.Count -ne $cacheRows.Count) {
            $differences.Add("Esquema [$key]: directo=$($directRows.Count), cache=$($cacheRows.Count)")
            continue
        }
        for ($i = 0; $i -lt $directRows.Count; $i++) {
            if ($directRows[$i] -cne $cacheRows[$i]) {
                $differences.Add("Esquema [$key]: contenido diferente")
                break
            }
        }
    }
    return $differences
}

$connectionString = "Data Source=$Server;Initial Catalog=$Database;Integrated Security=True;TrustServerCertificate=True;Connect Timeout=10"
$connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
$transaction = $null

try {
    $connection.Open()
    $transaction = $connection.BeginTransaction('CobranzaHomologacionRollback')

    Write-Host 'Ejecutando fuente directa...'
    $directData = Invoke-CobranzaProcedure $connection $transaction `
        'ObtenCobranzaConcentrada_otro_V2_BF3'

    Write-Host 'Ejecutando cache dentro de la transaccion de prueba...'
    $cacheData = Invoke-CobranzaProcedure $connection $transaction `
        'ReporteCobranzaConcentrada_BF3_Cache'

    $b2Data = $null
    if ($CompararB2) {
        Write-Host 'Ejecutando procedimiento clasico B2...'
        $b2Data = Invoke-CobranzaB2Procedure $connection $transaction
    }

    $direct = Get-BusinessContract $directData
    $cache = Get-BusinessContract $cacheData
    $differences = @(Compare-BusinessContract $direct $cache)

    $results = @(
        [pscustomobject]@{
            Flujo = 'Directo B3'
            Resultsets = $direct.Tables
            Filas = $direct.Rows
            FilasEmpleado = $direct.EmployeeRows
            Esquemas = $direct.Groups.Count
        },
        [pscustomobject]@{
            Flujo = 'Cache B3'
            Resultsets = $cache.Tables
            Filas = $cache.Rows
            FilasEmpleado = $cache.EmployeeRows
            Esquemas = $cache.Groups.Count
        }
    )

    $b2Differences = @()
    if ($null -ne $b2Data) {
        $b2 = Get-BusinessContract $b2Data
        $b2Differences = @(Compare-BusinessContract $b2 $direct)
        $results += [pscustomobject]@{
            Flujo = 'Clasico B2'
            Resultsets = $b2.Tables
            Filas = $b2.Rows
            FilasEmpleado = $b2.EmployeeRows
            Esquemas = $b2.Groups.Count
        }
    }

    $results | Format-Table -AutoSize

    if ($differences.Count -gt 0) {
        $differences | ForEach-Object { Write-Error $_ }
        throw "La homologacion fallo con $($differences.Count) diferencia(s)."
    }

    if ($b2Differences.Count -gt 0) {
        $b2Differences | ForEach-Object { Write-Error "B2/B3: $_" }
        throw "La comparacion B2/B3 fallo con $($b2Differences.Count) diferencia(s)."
    }

    Write-Host 'OK: fuente directa y cache contienen el mismo contrato de negocio.'
    if ($CompararB2) {
        Write-Host 'OK: B2 clasico y B3 contienen el mismo contrato de negocio.'
    }
}
finally {
    if ($null -ne $transaction) {
        try { $transaction.Rollback() } catch { Write-Warning $_.Exception.Message }
    }
    $connection.Close()
    Write-Host 'ROLLBACK completado: la prueba no deja cache ni datos persistidos.'
}
