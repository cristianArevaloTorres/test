SET NOCOUNT ON;

/* Consulta de solo lectura. Puede ejecutarse mientras 04 sigue trabajando. */
DECLARE @IdEmpresa int=186;

SELECT CacheId,IdVigencia,Estado,FechaCargaInicio,FechaCargaFin,
       DATEDIFF(MINUTE,FechaCargaInicio,COALESCE(FechaCargaFin,SYSDATETIME()))
           AS MinutosTranscurridos,
       FilasConcentrada,FilasDesglosada,Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (NOLOCK)
WHERE IdEmpresa=@IdEmpresa
ORDER BY CacheId DESC;

;WITH Etapas AS
(
    SELECT L.LogId,L.CacheId,L.IdVigencia,L.Fecha,L.Etapa,L.Detalle,
           LAG(L.Fecha) OVER
               (PARTITION BY L.CacheId ORDER BY L.LogId) AS FechaAnterior
    FROM dbo.bf_CobranzaCache_Log L WITH (NOLOCK)
    WHERE L.IdEmpresa=@IdEmpresa
)
SELECT TOP (200)
       LogId,CacheId,IdVigencia,Fecha,Etapa,
       DATEDIFF(SECOND,FechaAnterior,Fecha) AS SegundosDesdeEtapaAnterior,
       Detalle
FROM Etapas
ORDER BY LogId DESC;

/* CPU, lecturas y espera actual del lote. Requiere VIEW SERVER STATE. */
BEGIN TRY
    SELECT R.session_id,R.status,R.command,
           R.cpu_time/1000.0 AS CpuSegundos,
           R.total_elapsed_time/1000.0 AS SegundosTranscurridos,
           R.reads,R.logical_reads,R.writes,
           R.wait_type,R.wait_time/1000.0 AS EsperaSegundos,
           R.wait_resource,R.blocking_session_id,
           SUBSTRING(T.text,
              (R.statement_start_offset/2)+1,
              ((CASE R.statement_end_offset WHEN -1 THEN DATALENGTH(T.text)
                    ELSE R.statement_end_offset END-R.statement_start_offset)/2)+1)
              AS SentenciaActual
    FROM sys.dm_exec_requests R
    CROSS APPLY sys.dm_exec_sql_text(R.sql_handle) T
    WHERE R.database_id=DB_ID()
      AND R.session_id<>@@SPID
      AND (T.text LIKE N'%Cobranza%' OR T.text LIKE N'%bf_CobranzaCache%')
    ORDER BY R.total_elapsed_time DESC;
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS AvisoDMV;
END CATCH;

/* Tamano aproximado sin contar filas de las tablas. */
SELECT T.name AS Tabla,
       SUM(CASE WHEN P.index_id IN(0,1) THEN P.row_count ELSE 0 END) AS Filas,
       CAST(SUM(P.reserved_page_count)*8.0/1024 AS decimal(18,2)) AS MBReservados
FROM sys.tables T
JOIN sys.dm_db_partition_stats P ON P.object_id=T.object_id
WHERE T.name IN
      (N'ff_EdoCuentaCobranza',N'ff_EdoCuentaCobranza2',
       N'ff_PlanOpcionSeleccionCobranza2',N'ff_ConcepAgrupaCob')
GROUP BY T.name
ORDER BY MBReservados DESC;
GO
