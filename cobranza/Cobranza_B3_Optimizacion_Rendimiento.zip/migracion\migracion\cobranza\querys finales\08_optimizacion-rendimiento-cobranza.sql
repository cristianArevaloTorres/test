SET NOCOUNT ON;
SET XACT_ABORT ON;

/*
   Ejecutar DESPUES de 01 y cuando no exista una carga de cobranza en curso.

   1) Limita #ec_agg a las solicitudes de la vigencia/rango en proceso.
   2) Evita reutilizar un plan compilado para una empresa de cardinalidad distinta.
   3) Agrega indices de acceso usados por concentrada y desglosada.

   No cambia formulas, columnas ni el orden de los resultados.
*/

DECLARE @Def nvarchar(max)=OBJECT_DEFINITION(
            OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3')),
        @Upper nvarchar(max),
        @PosProc int,
        @PosFrom int,
        @PosWhere int,
        @PosIndice int,
        @PosOrden int,
        @PosExecDesg int,
        @FinLinea int,
        @NeedleFrom nvarchar(200)=N'FROM DBO.FF_EDOCUENTACOBRANZA2 EC WITH(NOLOCK)',
        @NeedleWhere nvarchar(300)=N'WHERE EC.ECIDEMPRESA IN(SELECT EMIDEMPRESA FROM #LISTEMPRESAS)',
        @NeedleIndice nvarchar(300)=N'CREATE NONCLUSTERED INDEX IX_EC_AGG ON #EC_AGG(ECIDSOLICITUD, ECIDEMPLEADO, ECIDEMPRESA);';

IF @Def IS NULL
    THROW 51800,
        'No existe dbo.ObtenCobranzaConcentrada_otro_V2_BF3.',1;

IF CHARINDEX(N'BF_CACHE_PERF_SCOPE_EC_AGG_V1',@Def)=0
BEGIN
    SET @Upper=UPPER(@Def) COLLATE Latin1_General_100_CI_AS;

    /* Instalaciones anteriores: incorpora el filtro antes de agregar. */
    IF CHARINDEX(N'INNER JOIN DBO.FF_SOLICITUD SO_SCOPE',@Upper)=0
    BEGIN
        SET @PosFrom=CHARINDEX(@NeedleFrom,@Upper);
        SET @PosWhere=CHARINDEX(@NeedleWhere,@Upper,@PosFrom);
        SET @PosIndice=CHARINDEX(@NeedleIndice,@Upper,@PosWhere);

        IF @PosFrom=0 OR @PosWhere=0 OR @PosIndice=0
            THROW 51801,
                'El bloque #ec_agg no coincide con la version esperada; no se aplico un reemplazo parcial.',1;

        SET @Def=STUFF(
            @Def,
            @PosWhere,
            @PosIndice-@PosWhere,
            N'WHERE SO_SCOPE.SOIdVigencia=@idVigencia
      AND SO_SCOPE.SOidEstatus=@SOIdEstatus
      AND SO_SCOPE.SOEstatusSolicitud=1
      AND SO_SCOPE.SOIdSolicitudTipo=1
      AND ISNULL(SO_SCOPE.SOFechaAprovacion,CAST(GETDATE() AS date))<=@FecFinHoras
      AND ISNULL(SO_SCOPE.SOFechaAprovacion,CAST(GETDATE() AS date))>=@FecIni
      AND SO_SCOPE.SOIdEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas)
    GROUP BY EC.ECidSolicitud, EC.ECidEmpleado, EC.ECidEmpresa
    OPTION (RECOMPILE);
    ');

        SET @Upper=UPPER(@Def) COLLATE Latin1_General_100_CI_AS;
        SET @PosFrom=CHARINDEX(@NeedleFrom,@Upper);
        SET @Def=STUFF(
            @Def,
            @PosFrom+LEN(@NeedleFrom),
            0,
            N'
    /* BF_CACHE_PERF_SCOPE_EC_AGG_V1: agrega solo solicitudes de la carga actual. */
    INNER JOIN dbo.ff_solicitud SO_SCOPE WITH(NOLOCK)
        ON SO_SCOPE.SOIdSolicitud=EC.ECidSolicitud
       AND SO_SCOPE.SOIdEmpresa=EC.ECidEmpresa
       AND SO_SCOPE.SOIdEmpleado=EC.ECidEmpleado');
    END
    ELSE
    BEGIN
        /* La fuente completa ya tiene el ajuste y solo falta la marca idempotente. */
        SET @PosFrom=CHARINDEX(N'INNER JOIN DBO.FF_SOLICITUD SO_SCOPE',@Upper);
        SET @Def=STUFF(
            @Def,@PosFrom,0,
            N'/* BF_CACHE_PERF_SCOPE_EC_AGG_V1: agrega solo solicitudes de la carga actual. */
    ');
    END;

    SET @Upper=UPPER(@Def) COLLATE Latin1_General_100_CI_AS;

    IF CHARINDEX(N'COBRANZA_OBTEN_POST_EC_AGG',@Upper)=0
    BEGIN
        SET @PosIndice=CHARINDEX(@NeedleIndice,@Upper);
        IF @PosIndice=0
            THROW 51802,'No se encontro el indice temporal ix_ec_agg.',1;
        SET @Def=STUFF(
            @Def,@PosIndice+LEN(@NeedleIndice),0,
            N'

    BEGIN TRY
        INSERT INTO dbo.bf_CobranzaCache_Log(etapa,detalle)
        VALUES(''cobranza_obten_post_ec_agg'',
               ''filas_ec_agg='' + CAST((SELECT COUNT_BIG(*) FROM #ec_agg) AS varchar(30)));
    END TRY BEGIN CATCH END CATCH;');
    END;

    SET @Upper=UPPER(@Def) COLLATE Latin1_General_100_CI_AS;
    SET @PosOrden=CHARINDEX(N'ORDER BY E.EMIDANT',@Upper);
    IF @PosOrden>0
       AND CHARINDEX(N'OPTION (RECOMPILE)',
                     SUBSTRING(@Upper,@PosOrden,80))=0
        SET @Def=STUFF(
            @Def,@PosOrden+LEN(N'ORDER BY E.EMIDANT'),0,
            N'
    OPTION (RECOMPILE)');

    SET @Upper=UPPER(@Def) COLLATE Latin1_General_100_CI_AS;
    IF CHARINDEX(N'COBRANZA_OBTEN_POST_DESGLOSADA',@Upper)=0
    BEGIN
        SET @PosExecDesg=CHARINDEX(
            N'EXEC DBO.FF_OBTENCOBRANZADESG_ADAPTADA_BF3_NOUSAR',@Upper);
        IF @PosExecDesg=0
            THROW 51803,'No se encontro la llamada al SP desglosado.',1;

        SET @FinLinea=CHARINDEX(CHAR(10),@Def,@PosExecDesg);
        IF @FinLinea=0 SET @FinLinea=LEN(@Def)+1;

        SET @Def=STUFF(
            @Def,@FinLinea,0,
            N'
BEGIN TRY
    INSERT INTO dbo.bf_CobranzaCache_Log(etapa,detalle)
    VALUES(''cobranza_obten_post_desglosada'',
           ''ff_ObtenCobranzaDesg_Adaptada_bf3_nousar finalizo'');
END TRY BEGIN CATCH END CATCH;
');
    END;

    SET @PosProc=CHARINDEX(N'PROCEDURE',UPPER(@Def));
    IF @PosProc=0
        THROW 51804,'La definicion no contiene PROCEDURE.',1;

    SET @Def=N'ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
    EXEC sys.sp_executesql @Def;
END;
GO

/* Indices compactos para los predicados que dominan ambas consultas. */
IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.ff_ConcepAgrupaCob')
      AND name=N'IX_BF_Cobranza_CA_EmpresaPlanConcepto'
)
    CREATE INDEX IX_BF_Cobranza_CA_EmpresaPlanConcepto
        ON dbo.ff_ConcepAgrupaCob
           (CAidEmpresa,CAidPlanOpcion,CACOid,CAidEstatus);
GO

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.ff_EdoCuentaCobranza2')
      AND name=N'IX_BF_Cobranza2_EmpresaSolicitudEmpleado'
)
    CREATE INDEX IX_BF_Cobranza2_EmpresaSolicitudEmpleado
        ON dbo.ff_EdoCuentaCobranza2
           (ECidEmpresa,ECidSolicitud,ECidEmpleado)
        INCLUDE
           (ECidPlanOpcion,ECTipoMovto,ECidConcepto,
            ECCantidad,ECidCompensacion,ECidEstatus);
GO

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.ff_EdoCuentaCobranza')
      AND name=N'IX_BF_Cobranza_EmpresaSolicitudNumero'
)
    CREATE INDEX IX_BF_Cobranza_EmpresaSolicitudNumero
        ON dbo.ff_EdoCuentaCobranza
           (ECidEmpresa,ECidSolicitud,ECNumeroEmpleado)
        INCLUDE
           (ECidEmpleado,ECidPlanOpcion,ECTipoMovto,ECidConcepto,
            ECCantidad,ECidCompensacion,ECidEstatus);
GO

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.ff_PlanOpcionSeleccionCobranza2')
      AND name=N'IX_BF_POSCob2_EmpresaVigenciaEstatusEmpleado'
)
    CREATE INDEX IX_BF_POSCob2_EmpresaVigenciaEstatusEmpleado
        ON dbo.ff_PlanOpcionSeleccionCobranza2
           (POidEmpresa,POidVigencia,POidEstatus,POidEmpleado,POidSolicitud)
        INCLUDE
           (PONumeroEmpleado,POidPlanOpcion,POidParentesco,POEdad,
            POidGrupoParentesco,POTarifaNeta,POCostoRestante,POAnexo);
GO

SELECT OBJECT_NAME(I.object_id) AS Tabla,I.name AS Indice
FROM sys.indexes I
WHERE I.name IN
(
    N'IX_BF_Cobranza_CA_EmpresaPlanConcepto',
    N'IX_BF_Cobranza2_EmpresaSolicitudEmpleado',
    N'IX_BF_Cobranza_EmpresaSolicitudNumero',
    N'IX_BF_POSCob2_EmpresaVigenciaEstatusEmpleado'
)
ORDER BY Tabla,Indice;

SELECT CASE WHEN OBJECT_DEFINITION(
                    OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'))
                 LIKE N'%BF_CACHE_PERF_SCOPE_EC_AGG_V1%'
            THEN 'OK' ELSE 'FALTA' END AS AjusteAgregadoVigencia;
GO
