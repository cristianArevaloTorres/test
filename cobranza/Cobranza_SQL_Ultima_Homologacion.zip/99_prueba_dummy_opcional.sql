/*
    PRUEBA DUMMY Y MONITOREO DE CACHE DE COBRANZA

    Requisitos:
      - Ejecutar despues de 01_Creacion de objetoss de bd completos para
        funcionalidad cache.sql.
      - La simulacion usa IDs reservados y termina siempre con ROLLBACK.
      - Cambiar @AplicarRecuperacionReal a 1 solamente para convertir cargas
        CARGANDO sin sesion/APPLOCK en ERROR.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @AplicarRecuperacionReal bit=0,
        @EmpresaReal int=NULL,
        @MinutosSinActividad int=15;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_ConsultaV2',N'U') IS NULL
    THROW 52300,'Falta bf_CobranzaCache_ConsultaV2.',1;
IF OBJECT_ID(N'dbo.bf_CobranzaCache_Log',N'U') IS NULL
    THROW 52300,'Falta bf_CobranzaCache_Log.',1;
IF OBJECT_ID(N'dbo.bf_CobranzaCache_RegistrarEvento',N'P') IS NULL
    THROW 52300,'Falta bf_CobranzaCache_RegistrarEvento.',1;
IF OBJECT_ID(N'dbo.bf_CobranzaCache_MarcarCargasAbandonadas',N'P') IS NULL
    THROW 52300,'Falta bf_CobranzaCache_MarcarCargasAbandonadas.',1;
IF OBJECT_ID(N'dbo.bf_CobranzaCache_MonitoreoV2',N'V') IS NULL
    THROW 52300,'Falta bf_CobranzaCache_MonitoreoV2.',1;
IF OBJECT_ID(N'dbo.tr_bf_CobranzaCache_Log_Contexto',N'TR') IS NULL
    THROW 52300,'Falta tr_bf_CobranzaCache_Log_Contexto.',1;

IF @AplicarRecuperacionReal=1
    EXEC dbo.bf_CobranzaCache_MarcarCargasAbandonadas
         @IdEmpresa=@EmpresaReal,
         @MinutosSinActividad=@MinutosSinActividad,
         @EmitirResultado=1;

DECLARE @EmpresaDummy int=2147483000,
        @VigenciaDummy int=2147483001,
        @PerfilDummy varchar(20)='2147483002',
        @PerfilHash varbinary(32),
        @CacheAbandonada bigint,
        @CacheActiva bigint,
        @LockName nvarchar(255),
        @LockResult int=-999,
        @LockTomado bit=0;

SET @PerfilHash=HASHBYTES('SHA2_256',@PerfilDummy);

BEGIN TRY
    BEGIN TRANSACTION;

    /* Caso 1: la sesion murio y el APPLOCK ya no existe. */
    INSERT dbo.bf_CobranzaCache_ConsultaV2
    (IdEmpresa,IdSolTipo,FecIni,FecFin,IdVencida,IdVigencia,
     PerfilClave,PerfilHash,EsTarjeta,Estado,FechaCargaInicio,
     FilasConcentrada,FilasDesglosada,Mensaje)
    VALUES
    (@EmpresaDummy,0,'2099-01-01 00:00','2099-01-31 23:59',1,@VigenciaDummy,
     @PerfilDummy,@PerfilHash,0,'CARGANDO',DATEADD(HOUR,-2,SYSDATETIME()),
     0,0,N'DUMMY: sesion terminada sin ejecutar CATCH');
    SET @CacheAbandonada=SCOPE_IDENTITY();

    EXEC dbo.bf_CobranzaCache_MarcarCargasAbandonadas
         @IdEmpresa=@EmpresaDummy,@MinutosSinActividad=15,@EmitirResultado=0;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.bf_CobranzaCache_ConsultaV2
        WHERE CacheId=@CacheAbandonada AND Estado='ERROR'
    )
        THROW 52301,'La prueba no recupero la carga abandonada.',1;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.bf_CobranzaCache_Log
        WHERE CacheId=@CacheAbandonada
          AND Etapa='CARGA_ABANDONADA' AND Estado='ERROR'
    )
        THROW 52302,'La recuperacion no dejo evento en bf_CobranzaCache_Log.',1;

    /* Caso 2: la carga es antigua, pero su sesion conserva el APPLOCK. */
    INSERT dbo.bf_CobranzaCache_ConsultaV2
    (IdEmpresa,IdSolTipo,FecIni,FecFin,IdVencida,IdVigencia,
     PerfilClave,PerfilHash,EsTarjeta,Estado,FechaCargaInicio,
     FilasConcentrada,FilasDesglosada,Mensaje)
    VALUES
    (@EmpresaDummy,1,'2099-02-01 00:00','2099-02-28 23:59',1,@VigenciaDummy,
     @PerfilDummy,@PerfilHash,0,'CARGANDO',DATEADD(HOUR,-2,SYSDATETIME()),
     0,0,N'DUMMY: sesion activa con APPLOCK');
    SET @CacheActiva=SCOPE_IDENTITY();

    SET @LockName=CONCAT(N'BF3-CobranzaCache-',@EmpresaDummy,N'-',@VigenciaDummy,N'-',
                         CONVERT(varchar(64),@PerfilHash,2),N'-1');
    EXEC @LockResult=sys.sp_getapplock
         @Resource=@LockName,@LockMode='Exclusive',@LockOwner='Session',@LockTimeout=0;
    IF @LockResult<0
        THROW 52303,'La prueba dummy no pudo obtener su APPLOCK.',1;
    SET @LockTomado=1;

    EXEC dbo.bf_CobranzaCache_MarcarCargasAbandonadas
         @IdEmpresa=@EmpresaDummy,@MinutosSinActividad=15,@EmitirResultado=0;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.bf_CobranzaCache_ConsultaV2
        WHERE CacheId=@CacheActiva AND Estado='CARGANDO'
    )
        THROW 52304,'La recuperacion marco por error una carga con sesion activa.',1;

    /* Los INSERT legacy de solo Etapa/Detalle deben heredar el contexto. */
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=@CacheActiva;
    INSERT dbo.bf_CobranzaCache_Log(Etapa,Detalle)
    VALUES('DUMMY_EVENTO_LEGACY',N'Evento sin columnas estructuradas.');
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=NULL;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.bf_CobranzaCache_Log
        WHERE CacheId=@CacheActiva AND IdEmpresa=@EmpresaDummy
          AND IdVigencia=@VigenciaDummy AND SesionId=@@SPID
          AND Etapa='DUMMY_EVENTO_LEGACY'
    )
        THROW 52305,'El trigger no correlaciono el evento legacy con su CacheId.',1;

    SELECT 'OK_DENTRO_TRANSACCION' EstadoPrueba,CacheId,IdEmpresa,IdVigencia,
           Estado,UltimaEtapa,MinutosSinActividad,Mensaje
    FROM dbo.bf_CobranzaCache_MonitoreoV2
    WHERE CacheId IN (@CacheAbandonada,@CacheActiva)
    ORDER BY CacheId;

    EXEC sys.sp_releaseapplock @Resource=@LockName,@LockOwner='Session';
    SET @LockTomado=0;
    ROLLBACK TRANSACTION;

    SELECT 'OK' Estado,
           'La carga abandonada se recupero, la carga activa se respeto y todos los datos dummy fueron revertidos.' Detalle;
END TRY
BEGIN CATCH
    EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=NULL;
    IF @LockTomado=1
        EXEC sys.sp_releaseapplock @Resource=@LockName,@LockOwner='Session';
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

/* Estado real y ultimos eventos: solo lectura. */
SELECT TOP (200) *
FROM dbo.bf_CobranzaCache_MonitoreoV2
WHERE @EmpresaReal IS NULL OR IdEmpresa=@EmpresaReal
ORDER BY CacheId DESC;

SELECT TOP (200)
       LogId,Fecha,CacheId,IdEmpresa,IdVigencia,Estado,SesionId,Etapa,Detalle
FROM dbo.bf_CobranzaCache_Log WITH (NOLOCK)
WHERE @EmpresaReal IS NULL OR IdEmpresa=@EmpresaReal
ORDER BY LogId DESC;
