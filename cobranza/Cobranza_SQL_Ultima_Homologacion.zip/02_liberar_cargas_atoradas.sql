/*
    LIBERAR CARGAS DE CACHE QUE QUEDARON EN CARGANDO

    - No mata sesiones.
    - No elimina filas de cache.
    - Solo cambia a ERROR una carga antigua cuando puede obtener su mismo
      APPLOCK; eso demuestra que ya no existe una sesion procesandola.
    - La siguiente solicitud reutilizara la particion y ejecutara carga FULL.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=186,
        @CacheIdObjetivo bigint=NULL, -- NULL = todas las atoradas de la empresa
        @MinutosParaConsiderarAtorada int=5,
        @Aplicar bit=1;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_ConsultaV2',N'U') IS NULL
    THROW 52500,'Falta dbo.bf_CobranzaCache_ConsultaV2.',1;
IF @MinutosParaConsiderarAtorada<0
    THROW 52500,'MinutosParaConsiderarAtorada no puede ser negativo.',1;

SELECT 'ANTES' Momento,CacheId,IdEmpresa,IdVigencia,FecIni,FecFin,Estado,
       FechaCargaInicio,FechaCargaFin,FilasConcentrada,FilasDesglosada,Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (NOLOCK)
WHERE IdEmpresa=@IdEmpresa
  AND Estado='CARGANDO'
  AND (@CacheIdObjetivo IS NULL OR CacheId=@CacheIdObjetivo)
ORDER BY CacheId;

IF @Aplicar=0
BEGIN
    SELECT 'SOLO_LECTURA' Resultado,
           'Cambie @Aplicar a 1 para recuperar las cargas sin APPLOCK.' Detalle;
    RETURN;
END;

DECLARE @CacheId bigint,@Vigencia int,@Vencida int,@PerfilHash varbinary(32),
        @LockName nvarchar(255),@LockResult int,@Detalle nvarchar(2000),
        @Liberadas int=0,@AunActivas int=0;

DECLARE @Resultado TABLE
(
    CacheId bigint NOT NULL,
    Resultado varchar(30) NOT NULL,
    Detalle nvarchar(2000) NULL
);

DECLARE Cargas CURSOR LOCAL FAST_FORWARD FOR
    SELECT CacheId,IdVigencia,IdVencida,PerfilHash
    FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (READPAST)
    WHERE IdEmpresa=@IdEmpresa
      AND Estado='CARGANDO'
      AND (@CacheIdObjetivo IS NULL OR CacheId=@CacheIdObjetivo)
      AND FechaCargaInicio<=DATEADD(MINUTE,-@MinutosParaConsiderarAtorada,SYSDATETIME());

OPEN Cargas;
FETCH NEXT FROM Cargas INTO @CacheId,@Vigencia,@Vencida,@PerfilHash;
WHILE @@FETCH_STATUS=0
BEGIN
    SET @LockName=CONCAT(N'BF3-CobranzaCache-',@IdEmpresa,N'-',@Vigencia,N'-',
                         CONVERT(varchar(64),@PerfilHash,2),N'-',@Vencida);
    SET @LockResult=-999;

    IF ISNULL(APPLOCK_MODE(N'public',@LockName,'Session'),'NoLock')='NoLock'
        EXEC @LockResult=sys.sp_getapplock
             @Resource=@LockName,@LockMode='Exclusive',
             @LockOwner='Session',@LockTimeout=0;

    IF @LockResult>=0
    BEGIN
        SET @Detalle=CONCAT(
            N'Carga liberada manualmente: la sesion original termino y el APPLOCK ',
            N'ya no estaba retenido. Recurso=',@LockName);

        UPDATE dbo.bf_CobranzaCache_ConsultaV2
           SET Estado='ERROR',FechaCargaFin=SYSDATETIME(),Mensaje=@Detalle
         WHERE CacheId=@CacheId AND IdEmpresa=@IdEmpresa AND Estado='CARGANDO';

        IF @@ROWCOUNT=1
        BEGIN
            SET @Liberadas+=1;
            INSERT @Resultado VALUES(@CacheId,'LIBERADA',@Detalle);

            IF OBJECT_ID(N'dbo.bf_CobranzaCache_Log',N'U') IS NOT NULL
            BEGIN
                EXEC sys.sp_set_session_context
                     @key=N'bf_CobranzaCacheId',@value=@CacheId;
                INSERT dbo.bf_CobranzaCache_Log(Etapa,Detalle)
                VALUES('CARGA_LIBERADA_MANUAL',@Detalle);
                EXEC sys.sp_set_session_context
                     @key=N'bf_CobranzaCacheId',@value=NULL;
            END;
        END;

        EXEC sys.sp_releaseapplock @Resource=@LockName,@LockOwner='Session';
    END
    ELSE
    BEGIN
        SET @AunActivas+=1;
        SET @Detalle=CONCAT(
            N'No se modifico: otra sesion conserva el APPLOCK. Resultado=',
            @LockResult,N'; recurso=',@LockName);
        INSERT @Resultado VALUES(@CacheId,'SESION_ACTIVA',@Detalle);
    END;

    FETCH NEXT FROM Cargas INTO @CacheId,@Vigencia,@Vencida,@PerfilHash;
END;
CLOSE Cargas;
DEALLOCATE Cargas;

EXEC sys.sp_set_session_context @key=N'bf_CobranzaCacheId',@value=NULL;

SELECT * FROM @Resultado ORDER BY CacheId;
SELECT @Liberadas CargasLiberadas,@AunActivas CargasConSesionActiva;

SELECT 'DESPUES' Momento,CacheId,IdEmpresa,IdVigencia,FecIni,FecFin,Estado,
       FechaCargaInicio,FechaCargaFin,FilasConcentrada,FilasDesglosada,Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (NOLOCK)
WHERE IdEmpresa=@IdEmpresa
  AND (@CacheIdObjetivo IS NULL OR CacheId=@CacheIdObjetivo)
ORDER BY CacheId DESC;
