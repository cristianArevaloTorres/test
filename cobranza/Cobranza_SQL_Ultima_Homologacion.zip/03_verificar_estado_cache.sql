SET NOCOUNT ON;

DECLARE @IdEmpresa int=186,
        @MinutosSinActividad int=15,
        @RecuperarAbandonadas bit=0;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_MonitoreoV2',N'V') IS NULL
    THROW 51610,
        'Falta bf_CobranzaCache_MonitoreoV2; aplique el instalador consolidado actual.',1;

/* Activar solo despues de revisar el resultado. Una fila se cambia a ERROR
   unicamente si esta vencida y ya no existe una sesion con el APPLOCK. */
IF @RecuperarAbandonadas=1
    EXEC dbo.bf_CobranzaCache_MarcarCargasAbandonadas
         @IdEmpresa=@IdEmpresa,
         @MinutosSinActividad=@MinutosSinActividad,
         @EmitirResultado=1;

/* Deben aparecer como maximo cuatro vigencias por empresa configurada. */
SELECT
    Q.CacheId,
    Q.IdEmpresa,
    Q.IdVigencia,
    Q.PerfilClave,
    Q.FecIni,
    Q.FecFin,
    Q.EsUniverso,
    Q.Estado,
    Q.FechaCargaInicio,
    Q.FechaCargaFin,
    DATEDIFF(SECOND,Q.FechaCargaInicio,Q.FechaCargaFin) AS SegundosCarga,
    Q.FilasConcentrada,
    Q.FilasDesglosada,
    M.UltimoEvento,
    M.UltimaEtapa,
    M.SesionId,
    M.MinutosSinActividad,
    CASE WHEN M.Estado='CARGANDO'
              AND M.MinutosSinActividad>=@MinutosSinActividad
         THEN 'REVISAR_APPLOCK' ELSE 'OK' END AS EstadoMonitoreo,
    M.Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 Q WITH (NOLOCK)
INNER JOIN dbo.bf_CobranzaCache_MonitoreoV2 M ON M.CacheId=Q.CacheId
WHERE Q.IdEmpresa=@IdEmpresa
ORDER BY Q.EsUniverso DESC,Q.IdVigencia DESC,Q.CacheId DESC;

/* La consulta debe devolver 4 despues de que termine el worker nocturno. */
SELECT COUNT(DISTINCT IdVigencia) AS VigenciasUniversoCompletas
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (NOLOCK)
WHERE IdEmpresa=@IdEmpresa
  AND EsUniverso=1
  AND Estado='COMPLETA';

/* El detalle operativo queda en la propia particion, sin usar el log
   compartido bf_RepConf_Debug. */
SELECT TOP (20) CacheId,IdEmpresa,IdVigencia,Estado,
       FechaCargaInicio,FechaCargaFin,UltimoEvento,UltimaEtapa,
       SesionId,MinutosSinActividad,Mensaje
FROM dbo.bf_CobranzaCache_MonitoreoV2 WITH (NOLOCK)
WHERE IdEmpresa=@IdEmpresa
ORDER BY CacheId DESC;

/* Detalle técnico exclusivo de Cobranza; no bloquea el log compartido. */
SELECT TOP (200) LogId,Fecha,CacheId,IdEmpresa,IdVigencia,
       Estado,SesionId,Etapa,Detalle
FROM dbo.bf_CobranzaCache_Log WITH (NOLOCK)
WHERE IdEmpresa=@IdEmpresa
ORDER BY LogId DESC;
