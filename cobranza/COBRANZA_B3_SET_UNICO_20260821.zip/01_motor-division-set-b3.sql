/*
   MOTOR DE DIVISION DE COSTOS SET-BASED, EXCLUSIVO B3

   Sustituye los ciclos empleado x plan por un maximo de N pasos, donde N es
   la mayor cantidad de planes de un empleado. En cada paso se procesan todos
   los empleados al mismo tiempo. B2 no se consulta ni se modifica.

   Casos atipicos que dependen de efectos laterales del codigo historico
   (importes negativos o llaves duplicadas) regresan automaticamente al motor
   B3 LEGACY para conservar exactamente el resultado.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Origen sysname=N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR',
        @Destino sysname=N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_SET',
        @Def nvarchar(max),
        @Upper nvarchar(max),
        @Inicio int,
        @Cola int,
        @InicioSegundo int,
        @ColaSegundo int,
        @InicioSobrante int,
        @FinSobrante int,
        @Proc int,
        @Bloque nvarchar(max);

IF OBJECT_ID(@Origen,N'P') IS NULL
    THROW 52600,'No existe el procedimiento de division B3 origen.',1;

SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Origen));
SET @Def=REPLACE(@Def,N'[dbo].[ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR]',
                      N'[dbo].[ff_ObtenDivisionCtos_Adaptado_bf3_SET]');
SET @Def=REPLACE(@Def,N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR',
                      N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_SET');
SET @Upper=UPPER(@Def);
SET @Inicio=CHARINDEX(N'IF EXISTS(SELECT TOP 1 * FROM #TABLACOBDESG)',@Upper);
SET @Cola=CHARINDEX(N'UPDATE A SET A.APLICEXCEDENTES',@Upper,@Inicio);

IF @Inicio=0 OR @Cola=0 OR @Cola<=@Inicio
    THROW 52601,'No se localizaron los limites de la division historica B3.',1;

SET @Bloque=N'/* BF3_DIVISION_SET_V1 */
IF EXISTS(SELECT TOP (1) 1 FROM #TablaCobDesg)
BEGIN
    BEGIN TRY
        INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        SELECT ''cobranza_bf3_division_set_inicio'',CONCAT(''filas='',COUNT_BIG(*))
        FROM #TablaCobDesg;
    END TRY BEGIN CATCH END CATCH;
    /*
       El codigo antiguo conserva valores de una iteracion previa cuando hay
       importes negativos. La ruta segura mantiene ese comportamiento exacto.
    */
    IF EXISTS(SELECT 1 FROM #TablaCobDesg WHERE ISNULL(ImportexPeriodo,0)<0)
       OR EXISTS(
            SELECT 1 FROM #tablatemp
            GROUP BY Empresa,NumEmpleado HAVING COUNT_BIG(*)>1
       )
       OR EXISTS(
            SELECT 1 FROM #tablatemp
            GROUP BY CveEmpl HAVING COUNT_BIG(*)>1
       )
       OR EXISTS(
            SELECT 1 FROM #TablaCobDesg
            GROUP BY EMPRESA,idemp,CVEPO,CVEP HAVING COUNT_BIG(*)>1
       )
    BEGIN
        BEGIN TRY
            INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
            VALUES(''cobranza_bf3_division_set_fallback'',
                   ''Motivo=importe negativo o llave historica duplicada'');
        END TRY BEGIN CATCH END CATCH;

        EXEC dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR;
        RETURN;
    END;

    CREATE UNIQUE NONCLUSTERED INDEX IX_BF3_TabTemp_EmpresaEmpleado
        ON #tablatemp(Empresa,NumEmpleado)
        INCLUDE(Transferido,MontoTotalCreditos,SobranteExcedentes);

    /* Una lectura por tabla de referencia, no una lectura por plan. */
    SELECT G.GDIDEmpresa,
           G.GDidPlanOpcion,
           MAX(CASE WHEN G.GDidConcepto=6 THEN ISNULL(G.GDMonto,0) END) AS GMM6,
           MAX(CASE WHEN G.GDidConcepto=7 THEN ISNULL(G.GDMonto,0) END) AS GMM7,
           MAX(CASE WHEN G.GDidConcepto=8 THEN ISNULL(G.GDMonto,0) END) AS GMM8
    INTO #BF3_GMM
    FROM dbo.ff_GMMDesgCob AS G WITH(NOLOCK)
    INNER JOIN (SELECT DISTINCT EMPRESA,CVEPO FROM #TablaCobDesg) AS K
        ON K.EMPRESA=G.GDIDEmpresa AND K.CVEPO=G.GDidPlanOpcion
    WHERE G.GDidConcepto IN(6,7,8)
    GROUP BY G.GDIDEmpresa,G.GDidPlanOpcion;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_GMM ON #BF3_GMM(GDIDEmpresa,GDidPlanOpcion);
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        SELECT ''cobranza_bf3_division_set_gmm'',CONCAT(''filas='',COUNT_BIG(*)) FROM #BF3_GMM;
    END TRY BEGIN CATCH END CATCH;

    /* El procedimiento historico usa @idVigencia=0 en esta validacion. */
    SELECT DISTINCT ES.ECidEmpresa,
           ES.ECNumeroEmpleado,
           CP.CPidPlanOpcion
    INTO #BF3_Compensado
    FROM dbo.ff_EdoCuentaCobranza AS ES WITH(NOLOCK)
    INNER JOIN dbo.ff_CompensacionPlanOpcion AS CP WITH(NOLOCK)
        ON CP.CPIdCompensacion=ES.ECidCompensacion
    INNER JOIN (SELECT DISTINCT Empresa,NumEmpleado FROM #tablatemp) AS E
        ON E.Empresa=ES.ECidEmpresa
       AND E.NumEmpleado COLLATE DATABASE_DEFAULT=ES.ECNumeroEmpleado COLLATE DATABASE_DEFAULT
    INNER JOIN (SELECT DISTINCT EMPRESA,CVEPO FROM #TablaCobDesg) AS P
        ON P.EMPRESA=ES.ECidEmpresa AND P.CVEPO=CP.CPidPlanOpcion
    WHERE ES.ECidCompensacion IS NOT NULL
      AND EXISTS(
          SELECT 1
          FROM dbo.ff_Solicitud AS S WITH(NOLOCK)
          WHERE S.SOIdSolicitud=ES.ECidSolicitud
            AND S.SOIdVigencia=0
      );
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_Compensado
        ON #BF3_Compensado(ECidEmpresa,ECNumeroEmpleado,CPidPlanOpcion);
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        SELECT ''cobranza_bf3_division_set_comp'',CONCAT(''filas='',COUNT_BIG(*)) FROM #BF3_Compensado;
    END TRY BEGIN CATCH END CATCH;

    SELECT D.Id_TablaCobDesg AS RowId,
           D.EMPRESA,
           D.NUMEMPLEADO,
           D.idemp,
           D.CVEPO,
           D.CVEP,
           ROW_NUMBER() OVER(
               PARTITION BY D.EMPRESA,D.NUMEMPLEADO
               ORDER BY ISNULL(D.PLOrdenCobranza,2147483647),D.Id_TablaCobDesg
           ) AS Paso,
           CONVERT(money,ISNULL(D.ImportexPeriodo,0)) AS Importe,
           CONVERT(bit,CASE WHEN C.CPidPlanOpcion IS NULL THEN 0 ELSE 1 END) AS Compensado,
           CONVERT(bit,CASE WHEN T.TRANSFERIDO=''TRANSFERIDO'' THEN 1 ELSE 0 END) AS Transferido,
           CONVERT(money,ISNULL(G.GMM6,0)) AS GMM6,
           CONVERT(money,ISNULL(G.GMM7,0)) AS GMM7,
           CONVERT(money,ISNULL(G.GMM8,0)) AS GMM8,
           CONVERT(money,0) AS CostoEmpresa,
           CONVERT(money,0) AS CtoEmpresaCash,
           CONVERT(money,0) AS CtoEmpresa1erexc,
           CONVERT(money,0) AS CtoEmpresaStoploss,
           CONVERT(money,0) AS CostoEmpleado,
           CONVERT(money,0) AS CtoEmpleadoCash,
           CONVERT(money,0) AS CtoEmpleado1erexc,
           CONVERT(money,0) AS CtoEmpleadoStoploss,
           CONVERT(money,0) AS CostoEmpleadoExcedente,
           CONVERT(money,0) AS CostoEmpleadoReal,
           CONVERT(money,0) AS SobranteExcedentes,
           CONVERT(money,0) AS CreditoDespues,
           CONVERT(money,0) AS ExcedenteDespues
    INTO #BF3_DivisionWork
    FROM #TablaCobDesg AS D
    INNER JOIN #tablatemp AS T
        ON T.Empresa=D.EMPRESA
       AND T.NumEmpleado COLLATE DATABASE_DEFAULT=D.NUMEMPLEADO COLLATE DATABASE_DEFAULT
    LEFT JOIN #BF3_GMM AS G
        ON G.GDIDEmpresa=D.EMPRESA AND G.GDidPlanOpcion=D.CVEPO
    LEFT JOIN #BF3_Compensado AS C
        ON C.ECidEmpresa=D.EMPRESA
       AND C.ECNumeroEmpleado COLLATE DATABASE_DEFAULT=D.NUMEMPLEADO COLLATE DATABASE_DEFAULT
       AND C.CPidPlanOpcion=D.CVEPO;

    CREATE UNIQUE CLUSTERED INDEX CX_BF3_DivisionWork
        ON #BF3_DivisionWork(Paso,EMPRESA,NUMEMPLEADO,RowId);
    CREATE UNIQUE NONCLUSTERED INDEX UX_BF3_DivisionWork_Row
        ON #BF3_DivisionWork(RowId);
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        SELECT ''cobranza_bf3_division_set_work'',CONCAT(''filas='',COUNT_BIG(*)) FROM #BF3_DivisionWork;
    END TRY BEGIN CATCH END CATCH;

    SELECT T.Empresa,
           T.NumEmpleado,
           CONVERT(money,ISNULL(T.MontoTotalCreditos,0)) AS Credito,
           CONVERT(money,ROUND(ISNULL(T.SobranteExcedentes,0),2)) AS Excedente
    INTO #BF3_DivisionState
    FROM #tablatemp AS T;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_DivisionState
        ON #BF3_DivisionState(Empresa,NumEmpleado);

    DECLARE @BF3_Paso int=1,
            @BF3_MaxPaso int=ISNULL((SELECT MAX(Paso) FROM #BF3_DivisionWork),0);

    WHILE @BF3_Paso<=@BF3_MaxPaso
    BEGIN
        UPDATE W
        SET CostoEmpresa = CASE WHEN W.Transferido=1 THEN R.Importe2 ELSE B.CostoEmpresa END,
            CtoEmpresaCash = CASE WHEN W.Transferido=1 THEN ROUND(R.Importe2*W.GMM6,2) ELSE B.CtoEmpresaCash END,
            CtoEmpresa1erexc = CASE WHEN W.Transferido=1 THEN ROUND(R.Importe2*W.GMM7,2) ELSE B.CtoEmpresa1erexc END,
            CtoEmpresaStoploss = CASE WHEN W.Transferido=1 THEN ROUND(R.Importe2*W.GMM8,2) ELSE B.CtoEmpresaStoploss END,
            CostoEmpleado = CASE WHEN W.Transferido=1 THEN 0 ELSE B.CostoEmpleado END,
            CtoEmpleadoCash = CASE WHEN W.Transferido=1 THEN 0 ELSE B.CtoEmpleadoCash END,
            CtoEmpleado1erexc = CASE WHEN W.Transferido=1 THEN 0 ELSE B.CtoEmpleado1erexc END,
            CtoEmpleadoStoploss = CASE WHEN W.Transferido=1 THEN 0 ELSE B.CtoEmpleadoStoploss END,
            CostoEmpleadoExcedente = CASE WHEN W.Transferido=1 THEN 0 ELSE B.CostoEmpleadoExcedente END,
            CostoEmpleadoReal = CASE WHEN W.Transferido=1 THEN 0 ELSE B.CostoEmpleadoReal END,
            SobranteExcedentes = 0,
            CreditoDespues = B.CreditoDespues,
            ExcedenteDespues = CASE WHEN W.Transferido=1 THEN 0 ELSE B.ExcedenteDespues END
        FROM #BF3_DivisionWork AS W
        INNER JOIN #BF3_DivisionState AS S
            ON S.Empresa=W.EMPRESA
           AND S.NumEmpleado COLLATE DATABASE_DEFAULT=W.NUMEMPLEADO COLLATE DATABASE_DEFAULT
        CROSS APPLY(
            SELECT CONVERT(money,ROUND(ISNULL(W.Importe,0),2)) AS Importe2,
                   CONVERT(money,ROUND(ISNULL(S.Credito,0)-ISNULL(W.Importe,0),2)) AS Saldo,
                   CONVERT(money,ABS(ROUND(ISNULL(S.Credito,0)-ISNULL(W.Importe,0),2))) AS Falta,
                   CONVERT(money,ROUND(ISNULL(S.Excedente,0),2)) AS Excedente2
        ) AS R
        CROSS APPLY(
            SELECT
              CONVERT(money,CASE
                WHEN W.Compensado=1 AND R.Saldo>0 THEN R.Importe2
                WHEN W.Compensado=1 AND R.Saldo<=0 AND S.Credito<>0 THEN ROUND(S.Credito,2)
                ELSE 0 END) AS CostoEmpresa,
              CONVERT(money,CASE
                WHEN W.Compensado=1 AND R.Saldo>0 THEN ROUND(R.Importe2*W.GMM6,2)
                WHEN W.Compensado=1 AND R.Saldo<=0 AND S.Credito<>0 AND R.Excedente2<=0 THEN ROUND(S.Credito*W.GMM6,2)
                ELSE 0 END) AS CtoEmpresaCash,
              CONVERT(money,CASE
                WHEN W.Compensado=1 AND R.Saldo>0 THEN ROUND(R.Importe2*W.GMM7,2)
                WHEN W.Compensado=1 AND R.Saldo<=0 AND S.Credito<>0 AND R.Excedente2<=0 THEN ROUND(S.Credito*W.GMM7,2)
                ELSE 0 END) AS CtoEmpresa1erexc,
              CONVERT(money,CASE
                WHEN W.Compensado=1 AND R.Saldo>0 THEN ROUND(R.Importe2*W.GMM8,2)
                WHEN W.Compensado=1 AND R.Saldo<=0 AND S.Credito<>0 AND R.Excedente2<=0 THEN ROUND(S.Credito*W.GMM8,2)
                ELSE 0 END) AS CtoEmpresaStoploss,
              CONVERT(money,CASE
                WHEN W.Compensado=1 AND R.Saldo>0 THEN 0
                WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2<=0 AND S.Credito=0 THEN ABS(R.Importe2)
                WHEN W.Compensado=1 AND R.Saldo<=0 THEN R.Falta
                WHEN W.Compensado=0 THEN ABS(R.Importe2)
                ELSE 0 END) AS CostoEmpleado,
              CONVERT(money,CASE WHEN W.Compensado=0 AND R.Excedente2<=0 THEN ROUND(R.Importe2*W.GMM6,2)
                                 WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2<=0 AND S.Credito<>0 THEN ROUND(R.Falta*W.GMM6,2)
                                 ELSE 0 END) AS CtoEmpleadoCash,
              CONVERT(money,CASE WHEN W.Compensado=0 AND R.Excedente2<=0 THEN ROUND(R.Importe2*W.GMM7,2)
                                 WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2<=0 AND S.Credito<>0 THEN ROUND(R.Falta*W.GMM7,2)
                                 ELSE 0 END) AS CtoEmpleado1erexc,
              CONVERT(money,CASE WHEN W.Compensado=0 AND R.Excedente2<=0 THEN ROUND(R.Importe2*W.GMM8,2)
                                 WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2<=0 AND S.Credito<>0 THEN ROUND(R.Falta*W.GMM8,2)
                                 ELSE 0 END) AS CtoEmpleadoStoploss,
              CONVERT(money,CASE
                WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2>0
                  THEN CASE WHEN R.Falta>R.Excedente2 THEN R.Excedente2 ELSE R.Falta END
                WHEN W.Compensado=0 AND R.Excedente2>0
                  THEN CASE WHEN R.Excedente2>W.Importe THEN R.Importe2 ELSE R.Excedente2 END
                ELSE 0 END) AS CostoEmpleadoExcedente,
              CONVERT(money,CASE
                WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2>0
                  THEN CASE WHEN R.Falta>R.Excedente2 THEN R.Falta-R.Excedente2 ELSE 0 END
                WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2<=0 AND S.Credito=0 THEN R.Importe2
                WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2<=0 THEN R.Falta
                WHEN W.Compensado=0 AND R.Excedente2>0
                  THEN CASE WHEN R.Excedente2>W.Importe THEN 0 ELSE R.Importe2-R.Excedente2 END
                WHEN W.Compensado=0 AND R.Excedente2<=0 THEN R.Importe2
                ELSE 0 END) AS CostoEmpleadoReal,
              CONVERT(money,CASE WHEN W.Compensado=1 THEN CASE WHEN R.Saldo>0 THEN R.Saldo ELSE 0 END
                                 ELSE S.Credito END) AS CreditoDespues,
              CONVERT(money,CASE
                WHEN W.Compensado=1 AND R.Saldo>0 THEN R.Excedente2
                WHEN W.Compensado=1 AND R.Saldo<=0 AND R.Excedente2>0
                  THEN CASE WHEN R.Excedente2-R.Falta<0 THEN 0 ELSE R.Excedente2-R.Falta END
                WHEN W.Compensado=1 AND R.Saldo<=0 THEN 0
                WHEN W.Compensado=0 AND R.Excedente2>0
                  THEN CASE WHEN R.Excedente2-W.Importe<0 THEN 0 ELSE R.Excedente2-W.Importe END
                ELSE 0 END) AS ExcedenteDespues
        ) AS B
        WHERE W.Paso=@BF3_Paso;

        UPDATE S
        SET S.Credito=W.CreditoDespues,
            S.Excedente=W.ExcedenteDespues
        FROM #BF3_DivisionState AS S
        INNER JOIN #BF3_DivisionWork AS W
            ON W.EMPRESA=S.Empresa
           AND W.NUMEMPLEADO COLLATE DATABASE_DEFAULT=S.NumEmpleado COLLATE DATABASE_DEFAULT
           AND W.Paso=@BF3_Paso;

        SET @BF3_Paso+=1;
    END;

    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES(''cobranza_bf3_division_set_pasos'',CONCAT(''pasos='',@BF3_MaxPaso));
    END TRY BEGIN CATCH END CATCH;

    UPDATE W
    SET W.SobranteExcedentes=S.Excedente
    FROM #BF3_DivisionWork AS W
    INNER JOIN #BF3_DivisionState AS S
        ON S.Empresa=W.EMPRESA
       AND S.NumEmpleado COLLATE DATABASE_DEFAULT=W.NUMEMPLEADO COLLATE DATABASE_DEFAULT
    WHERE W.Paso=(
        SELECT MAX(W2.Paso)
        FROM #BF3_DivisionWork AS W2
        WHERE W2.EMPRESA=W.EMPRESA
          AND W2.NUMEMPLEADO COLLATE DATABASE_DEFAULT=W.NUMEMPLEADO COLLATE DATABASE_DEFAULT
    );

    UPDATE D
    SET D.CostoEmpresa=W.CostoEmpresa,
        D.CtoEmpresaCash=W.CtoEmpresaCash,
        D.CtoEmpresa1erexc=W.CtoEmpresa1erexc,
        D.CtoEmpresaStoploss=W.CtoEmpresaStoploss,
        D.CostoEmpleado=W.CostoEmpleado,
        D.CtoEmpleadoCash=W.CtoEmpleadoCash,
        D.CtoEmpleado1erexc=W.CtoEmpleado1erexc,
        D.CtoEmpleadoStoploss=W.CtoEmpleadoStoploss,
        D.CostoEmpleadoExcedente=W.CostoEmpleadoExcedente,
        D.CostoEmpleadoReal=W.CostoEmpleadoReal,
        D.SobranteExcedentes=W.SobranteExcedentes
    FROM #TablaCobDesg AS D
    INNER JOIN #BF3_DivisionWork AS W ON W.RowId=D.Id_TablaCobDesg;

    BEGIN TRY
        INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        SELECT ''cobranza_bf3_division_set_fin'',
               CONCAT(''filas='',COUNT_BIG(*),''; pasos='',@BF3_MaxPaso)
        FROM #BF3_DivisionWork;
    END TRY BEGIN CATCH END CATCH;
END;

';

SET @Def=STUFF(@Def,@Inicio,@Cola-@Inicio,@Bloque);

/* Elimina otra subconsulta correlacionada que se ejecutaba una vez por
   empleado justo antes del segundo ciclo. */
SET @Upper=UPPER(@Def);
SET @InicioSobrante=CHARINDEX(
    N'UPDATE #TABLATEMP SET SOBRANTECREDITOS=',@Upper);
SET @FinSobrante=CHARINDEX(N';',@Def,@InicioSobrante);
IF @InicioSobrante=0 OR @FinSobrante=0
    THROW 52605,'No se localizo el calculo correlacionado de SobranteCreditos.',1;

SET @Bloque=N'/* BF3_SOBRANTE_CREDITO_SET_V1 */
UPDATE T
SET T.SobranteCreditos=T.MontoTotalCreditos-ROUND(D.CostoEmpresa,2)
FROM #tablatemp AS T
INNER JOIN(
    SELECT NUMEMPLEADO,SUM(CostoEmpresa) AS CostoEmpresa
    FROM #TablaCobDesg
    GROUP BY NUMEMPLEADO
) AS D
    ON D.NUMEMPLEADO COLLATE DATABASE_DEFAULT=T.NumEmpleado COLLATE DATABASE_DEFAULT;';
SET @Def=STUFF(@Def,@InicioSobrante,@FinSobrante-@InicioSobrante+1,@Bloque);

/* El segundo ciclo historico vuelve a recorrer cada empleado, aunque todas
   sus formulas dependen solamente de la misma fila. Se reduce a un UPDATE. */
SET @Upper=UPPER(@Def);
SET @InicioSegundo=CHARINDEX(
    N'IF EXISTS(SELECT TOP 1 * FROM #TABLATEMP WITH (NOLOCK))',@Upper);
SET @ColaSegundo=CHARINDEX(
    N'---SELECT  * FROM #TABLATEMP',@Upper,@InicioSegundo);

IF @InicioSegundo=0 OR @ColaSegundo=0 OR @ColaSegundo<=@InicioSegundo
    THROW 52604,'No se localizaron los limites del segundo ciclo B3.',1;

SET @Bloque=N'/* BF3_EMPLEADO_SET_V1 */
IF EXISTS(SELECT TOP (1) 1 FROM #tablatemp)
BEGIN
    UPDATE T
    SET T.MontoPagCred=X.MontoPagCred,
        T.MontoDescMensual=X.MtoDescMen,
        T.MontoFondoAhorroMensual=V.MontoFHFinal,
        T.SobranteExcedentes=V.SobranteExFinal,
        T.DescuentoEmpleadoFinal=V.DescuentoFinal,
        T.DescuentoEmpleadoFH=V.DescuentoFH,
        T.SobranteExceFinal=V.SobranteFinal,
        T.CtoEmpleadoNomSeg=ABS(ISNULL(V.DescuentoFinal,0)-ISNULL(V.DescuentoFH,0))
    FROM #tablatemp AS T
    CROSS APPLY(
        SELECT CONVERT(money,
                   (ISNULL(T.MontoTotalCreditos,0)-ISNULL(T.SobranteCreditos,0))
                    -ISNULL(T.MontoTotalSelecciones,0)) AS DiferenciaCredito,
               CONVERT(money,ABS(
                   (ISNULL(T.MontoTotalCreditos,0)-ISNULL(T.SobranteCreditos,0))
                    -ISNULL(T.MontoTotalSelecciones,0))) AS MtoDescMen,
               CONVERT(money,ISNULL(T.MontoFondoAhorroMensual,0)) AS FH,
               CONVERT(money,ISNULL(T.Excedentes,0)) AS Excedente,
               CONVERT(money,ISNULL(T.SobranteExcedentes,0)) AS SobEx,
               CONVERT(money,CASE
                   WHEN T.MontoTotalSelecciones>T.MontoTotalCreditos
                     THEN T.MontoTotalCreditos-ISNULL(T.SobranteCreditos,0)
                   ELSE T.MontoTotalSelecciones END) AS MontoPagCred
    ) AS X
    CROSS APPLY(
        SELECT
          CONVERT(money,CASE
            WHEN X.Excedente>0 AND X.FH=0 THEN 0
            WHEN X.Excedente>0 AND X.FH=X.SobEx AND X.Excedente<X.MtoDescMen AND X.FH>0 THEN 0
            WHEN X.Excedente>0 AND X.FH=X.SobEx AND X.Excedente>X.MtoDescMen THEN ABS(X.Excedente-X.MtoDescMen)
            ELSE T.MontoFondoAhorroMensual END) AS MontoFHFinal,
          CONVERT(money,CASE
            WHEN X.Excedente<=0 THEN 0
            WHEN X.Excedente>0 AND X.FH=0 THEN X.Excedente
            WHEN X.Excedente>0 AND X.FH<>X.SobEx AND X.FH>X.Excedente THEN 0
            WHEN X.Excedente>0 AND X.FH<>X.SobEx THEN CASE WHEN X.Excedente-X.FH<0 THEN 0 ELSE X.Excedente-X.FH END
            WHEN X.Excedente>0 AND X.FH=X.SobEx AND X.Excedente<X.MtoDescMen AND X.FH>0 THEN NULL
            WHEN X.Excedente>0 AND X.FH=X.SobEx AND X.Excedente>X.MtoDescMen THEN X.MtoDescMen
            ELSE T.SobranteExcedentes END) AS SobranteExFinal,
          CONVERT(money,CASE
            WHEN X.Excedente<=0 THEN X.FH+X.MtoDescMen
            WHEN X.Excedente>0 AND X.FH=0 THEN CASE WHEN X.Excedente-X.MtoDescMen>0 THEN 0 ELSE X.MtoDescMen-X.Excedente END
            WHEN X.Excedente>0 AND X.FH<>X.SobEx AND X.FH>X.Excedente THEN (X.FH-X.Excedente)+X.MtoDescMen
            WHEN X.Excedente>0 AND X.FH<>X.SobEx THEN CASE WHEN X.Excedente-(X.FH+X.MtoDescMen)<0 THEN (X.FH+X.MtoDescMen)-X.Excedente ELSE 0 END
            WHEN X.Excedente>0 AND X.FH=X.SobEx AND X.Excedente<X.MtoDescMen AND X.FH>0 THEN ABS(X.MtoDescMen-X.Excedente)
            ELSE T.DescuentoEmpleadoFinal END) AS DescuentoFinal,
          CONVERT(money,CASE
            WHEN X.Excedente<=0 THEN X.FH
            WHEN X.Excedente>0 AND X.FH<>X.SobEx AND X.FH>X.Excedente THEN X.FH-X.Excedente
            WHEN X.Excedente>0 AND X.FH<>X.SobEx THEN CASE WHEN X.Excedente-X.FH<0 THEN X.FH-X.Excedente ELSE 0 END
            ELSE T.DescuentoEmpleadoFH END) AS DescuentoFH,
          CONVERT(money,CASE
            WHEN X.Excedente>0 AND X.FH=0 THEN CASE WHEN X.Excedente-X.MtoDescMen>0 THEN X.Excedente-X.MtoDescMen ELSE 0 END
            WHEN X.Excedente>0 AND X.FH<>X.SobEx AND X.FH<=X.Excedente THEN CASE WHEN X.Excedente-(X.FH+X.MtoDescMen)<0 THEN 0 ELSE X.Excedente-(X.FH+X.MtoDescMen) END
            WHEN X.Excedente>0 AND X.FH=X.SobEx AND X.Excedente<X.MtoDescMen AND X.FH>0 THEN 0
            ELSE T.SobranteExceFinal END) AS SobranteFinal
    ) AS V;

    BEGIN TRY
        INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        SELECT ''cobranza_bf3_empleado_set_fin'',CONCAT(''filas='',COUNT_BIG(*))
        FROM #tablatemp;
    END TRY BEGIN CATCH END CATCH;
END;

';

SET @Def=STUFF(@Def,@InicioSegundo,@ColaSegundo-@InicioSegundo,@Bloque);
/* Permite que el benchmark local termine antes del generador de planes. La
   llave nunca es establecida por los flujos de aplicacion. */
SET @Def=REPLACE(@Def,
                 N' EXEC DBO.ff_ObtenPlanConcentrado_Adaptado_bf3;',
                 N' IF TRY_CONVERT(bit,SESSION_CONTEXT(N''bf_CobranzaB3Lab''))=1 RETURN;
 EXEC DBO.ff_ObtenPlanConcentrado_Adaptado_bf3;');
SET @Upper=UPPER(@Def);
SET @Proc=CHARINDEX(N'PROCEDURE',@Upper);
IF @Proc=0
    THROW 52602,'No se pudo construir el procedimiento SET B3.',1;

SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@Proc,LEN(@Def));
EXEC sys.sp_executesql @Def;

IF OBJECT_DEFINITION(OBJECT_ID(@Destino)) NOT LIKE N'%BF3_DIVISION_SET_V1%'
    THROW 52603,'El motor SET B3 no quedo instalado.',1;

SELECT N'OK' AS Estado,@Destino AS Objeto,
       N'B3 solamente; B2 intacto; fallback automatico disponible' AS Alcance;
