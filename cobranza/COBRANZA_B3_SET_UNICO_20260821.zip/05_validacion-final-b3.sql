/* Validacion sin ejecutar una carga. Ajustar solamente empresa/vigencia. */
SET NOCOUNT ON;

DECLARE @IdEmpresa int=186,@IdVigencia int=4235,@Ambiguas bigint;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_SET'))
   NOT LIKE N'%BF3_DIVISION_SET_V1%' THROW 52720,'Falta motor Division SET.',1;
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_SET'))
   NOT LIKE N'%BF3_DESGLOSADA_ETAPAS_SET_V1%' THROW 52721,'Falta Desglosada SET.',1;
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET'))
   NOT LIKE N'%BF3_CONCENTRADA_ETAPAS_SET_V1%' THROW 52722,'Falta Concentrada SET.',1;
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'))
   NOT LIKE N'%BF3_FLUJO_UNICO_SET_V1%' THROW 52723,'B3 no usa el punto de entrada unico SET.',1;
IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_CobranzaCache_CargarUnaV2'))
   NOT LIKE N'%ObtenCobranzaConcentrada_otro_V2_BF3%' THROW 52724,'Cache no converge al punto de entrada B3.',1;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada')) LIKE N'%_bf3_SET%'
   OR OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_v3')) LIKE N'%_bf3_SET%'
    THROW 52725,'Se detecto una referencia SET dentro de un objeto B2.',1;

IF EXISTS(
    SELECT 1 FROM dbo.ff_Parametro
    WHERE UPPER(LTRIM(RTRIM(ISNULL(paClase,'')))) IN('COBRANZA_SQL_OPT_V2','COBRANZA_SQL_SET_V3')
      AND LTRIM(RTRIM(ISNULL(paValor,'')))<>'0')
    THROW 52726,'Quedo activa una bandera antigua de version SQL.',1;

SELECT @Ambiguas=COUNT_BIG(*)
FROM(
    SELECT TC.TCIdPlanOpcion,TC.TCIdParentesco,TC.TCEdad,TC.TCIdSexo
    FROM dbo.ff_Tarifa AS T WITH(NOLOCK)
    INNER JOIN dbo.ff_TarifaCosto AS TC WITH(NOLOCK) ON TC.TCIdTarifa=T.TAIdTarifa
    WHERE T.TAIdVigencia=@IdVigencia AND TC.TCIdEstatus=1
      AND TC.TCIdGrupoParentesco IS NULL
    GROUP BY TC.TCIdPlanOpcion,TC.TCIdParentesco,TC.TCEdad,TC.TCIdSexo
    HAVING MIN(ISNULL(TC.TCPrimaNeta,0))<>MAX(ISNULL(TC.TCPrimaNeta,0))
) AS A;
IF @Ambiguas<>0 THROW 52727,'Hay tarifas individuales ambiguas; corregir antes de cargar.',1;

SELECT N'VALIDACION_OK' Estado,@IdEmpresa IdEmpresa,@IdVigencia IdVigencia,
       N'Cache y tradicional -> B3 publico -> SET' Flujo,
       N'B2 intacto' B2,@Ambiguas TarifasAmbiguas;

SELECT O.name Objeto,O.type_desc Tipo,O.modify_date FechaModificacion
FROM sys.objects AS O
WHERE O.object_id IN(
 OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'),
 OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET'),
 OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_SET'),
 OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_SET'))
ORDER BY O.name;
