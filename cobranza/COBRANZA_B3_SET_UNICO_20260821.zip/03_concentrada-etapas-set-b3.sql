/*
   CONCENTRADA POR ETAPAS, EXCLUSIVA B3

   Consolida las lecturas historicas, compensaciones, fondo de ahorro, grupo
   GMM y oficinas antes del INSERT. Evita volver a recorrer tablas completas
   desde subconsultas escalares para cada empleado.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Origen sysname=N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT',
        @Destino sysname=N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET',
        @Def nvarchar(max),@Upper nvarchar(max),@Inicio int,@Cola int,@Proc int,
        @Bloque nvarchar(max);

IF OBJECT_ID(@Origen,N'P') IS NULL OR OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_SET',N'P') IS NULL
    THROW 52680,'Falta la rama OPT o Desglosada SET B3.',1;

/* Siempre reconstruye desde OPT para que el instalador sea repetible. */
SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Origen));
SET @Def=REPLACE(@Def,N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_OPT]',
                      N'[dbo].[ObtenCobranzaConcentrada_otro_V2_BF3_SET]');
SET @Def=REPLACE(@Def,N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_OPT',
                      N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET');
SET @Def=REPLACE(@Def,N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_OPT',
                      N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_SET');
SET @Def=REPLACE(@Def,N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_nousar',
                      N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_SET');
SET @Upper=UPPER(@Def);
SET @Inicio=CHARINDEX(N'INSERT INTO #TABLATEMP (EMPRESA,NUMEMPLEADO',@Upper);
SET @Cola=CHARINDEX(N'-- LOG POST-INSERT-TABLATEMP',@Upper,@Inicio);
IF @Inicio=0 OR @Cola=0 OR @Cola<=@Inicio
    THROW 52681,'No se localizaron los limites del INSERT Concentrada B3.',1;

SET @Bloque=N'/* BF3_CONCENTRADA_ETAPAS_SET_V1 */
    SELECT DISTINCT EC.ECidSolicitud,EC.ECidEmpleado,EC.ECidEmpresa
    INTO #BF3_ECKeys
    FROM dbo.ff_EdoCuentaCobranza2 AS EC WITH(NOLOCK)
    INNER JOIN dbo.ff_Solicitud AS S WITH(NOLOCK)
        ON S.SOIdSolicitud=EC.ECidSolicitud AND S.SOIdEmpresa=EC.ECidEmpresa
       AND S.SOIdEmpleado=EC.ECidEmpleado
    INNER JOIN dbo.ff_ConcepAgrupaCob AS CA WITH(NOLOCK)
        ON CA.CAIdEmpresa=EC.ECidEmpresa AND CA.CAIdPlanOpcion=EC.ECidPlanOpcion
    WHERE S.SOIdVigencia=@idVigencia AND S.SOidEstatus=@SOIdEstatus
      AND S.SOEstatusSolicitud=1 AND S.SOIdSolicitudTipo=1
      AND ISNULL(S.SOFechaAprovacion,CONVERT(date,GETDATE()))<=@FecFinHoras
      AND ISNULL(S.SOFechaAprovacion,CONVERT(date,GETDATE()))>=@FecIni
      AND S.SOIdEmpresa IN(SELECT EMidEmpresa FROM #ListEmpresas);
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_ECKeys
        ON #BF3_ECKeys(ECidEmpresa,ECidSolicitud,ECidEmpleado);

    SELECT CE.CEIdEmpleado,SUM(ISNULL(CE.CETotalCreditos,0)) AS TotalCreditos
    INTO #BF3_CompEmpleado
    FROM dbo.ff_CompensacionEmpleado AS CE WITH(NOLOCK)
    INNER JOIN (SELECT DISTINCT EMIdAnt FROM #ff_Empleadotemp) AS E ON E.EMIdAnt=CE.CEIdEmpleado
    GROUP BY CE.CEIdEmpleado;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_CompEmpleado ON #BF3_CompEmpleado(CEIdEmpleado);

    SELECT POS.POIdEmpresa,POS.PONumeroEmpleado,POS.POIdSolicitud,
           SUM(ISNULL(POS.POTarifaNeta,0)) AS TarifaNeta,
           MAX(PO.PODescripcion) AS PlanFondo
    INTO #BF3_Fondo
    FROM dbo.ff_PlanOpcionSeleccionCobranza AS POS WITH(NOLOCK)
    INNER JOIN dbo.ff_Empleado AS ET WITH(NOLOCK)
        ON ET.EMIdEmpresa=POS.POIdEmpresa
       AND ET.EMNumeroEmpleado COLLATE DATABASE_DEFAULT=POS.PONumeroEmpleado COLLATE DATABASE_DEFAULT
       AND ET.EMIdTitular=1
    INNER JOIN dbo.ff_PlanOpcionPerfil AS PPF WITH(NOLOCK)
        ON PPF.PPIdPerfil=ET.EMIdPerfil AND PPF.PPIdPlanOpcion=POS.POIdPlanOpcion
    INNER JOIN dbo.ff_PlanOpcion AS PO WITH(NOLOCK)
        ON PO.POIdPlanOpcion=POS.POIdPlanOpcion
    INNER JOIN dbo.ff_Plan AS PL WITH(NOLOCK)
        ON PL.PLIdPlan=PO.POIdPlan AND PL.PLFondoDeAhorro=1
    INNER JOIN #BF3_ECKeys AS K
        ON K.ECidEmpresa=POS.POIdEmpresa AND K.ECidSolicitud=POS.POIdSolicitud
       AND K.ECidEmpleado=POS.POIdEmpleado
    WHERE POS.POIdEmpresa IN(SELECT EMIdEmpresa FROM #ListEmpresas)
    GROUP BY POS.POIdEmpresa,POS.PONumeroEmpleado,POS.POIdSolicitud;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_Fondo
        ON #BF3_Fondo(POIdEmpresa,PONumeroEmpleado,POIdSolicitud);

    SELECT POS.POIdEmpresa,POS.PONumeroEmpleado,MAX(GP.GPNombre) AS GPNombre
    INTO #BF3_GrupoGMM
    FROM dbo.ff_PlanOpcionSeleccionCobranza AS POS WITH(NOLOCK)
    INNER JOIN dbo.ff_Empleado AS ET WITH(NOLOCK)
        ON ET.EMIdEmpresa=POS.POIdEmpresa
       AND ET.EMNumeroEmpleado COLLATE DATABASE_DEFAULT=POS.PONumeroEmpleado COLLATE DATABASE_DEFAULT
       AND ET.EMIdParentesco=1
    INNER JOIN dbo.ff_ConcepAgrupaCob AS CAC WITH(NOLOCK)
        ON CAC.CAIdEmpresa=POS.POIdEmpresa AND CAC.CAIdPlanOpcion=POS.POIdPlanOpcion
    INNER JOIN dbo.ff_GrupoParentesco AS GP WITH(NOLOCK)
        ON GP.GPIdGrupoParentesco=POS.POIdGrupoParentesco
    INNER JOIN dbo.ff_PlanOpcion AS PO WITH(NOLOCK)
        ON PO.POIdPlanOpcion=POS.POIdPlanOpcion AND PO.POIdEstatus=1
    INNER JOIN dbo.ff_Plan AS PL WITH(NOLOCK)
        ON PL.PLIdPlan=PO.POIdPlan AND PL.PLIdEstatus=1
    INNER JOIN dbo.ff_Ramo AS RA WITH(NOLOCK)
        ON RA.RAIdRamo=PL.PLIdRamo AND RA.RAIdRamoForbes=5
    WHERE POS.POIdEstatus=@SOIdEstatus AND POS.POIdGrupoParentesco IS NOT NULL
      AND POS.POIdVigencia=@idVigencia
    GROUP BY POS.POIdEmpresa,POS.PONumeroEmpleado;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_GrupoGMM ON #BF3_GrupoGMM(POIdEmpresa,PONumeroEmpleado);

    SELECT TE.TEIdDetalle,MAX(TE.TEDescripcion) AS Descripcion
    INTO #BF3_Oficina
    FROM dbo.ff_TablaEncabezadoDetalle AS TE WITH(NOLOCK)
    INNER JOIN dbo.ff_TablaEncabezado AS EN WITH(NOLOCK)
        ON EN.ENClave=TE.TEEnClave
    WHERE EN.ENIdEmpresa IN(SELECT EMIdEmpresa FROM #ListEmpresas)
      AND EN.ENEncabezado LIKE ''%Oficina%''
    GROUP BY TE.TEIdDetalle;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_Oficina ON #BF3_Oficina(TEIdDetalle);

    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        SELECT ''cobranza_bf3_conc_set_etapas'',
               CONCAT(''keys='',(SELECT COUNT_BIG(*) FROM #BF3_ECKeys),
                      ''; fondo='',(SELECT COUNT_BIG(*) FROM #BF3_Fondo));
    END TRY BEGIN CATCH END CATCH;

    INSERT INTO #tablatemp
    (empresa,NumEMpleado,CveEmpl,Paterno,MAterno,Nombre1,Nombre2,Sexo,FechaNac,Edad,
     Confidencial,SueldoMensual,SueldoMensualAnt,TRANSFERIDO,NumSolicitud,Perfil,
     FechaAutorizacion,MontoGMM,MontoVIDA,MontoOTROSPLANES,CreditosGMM,CreditosViDA,
     MontoTotalCreditos,MontoTotalCreditosAnt,MontoTotalSelecciones,MontoTotalSeleccionesAnt,
     SobranteCreditos,MontoPagCred,MontoDescMensual,MontoDescMensualAnt,GrupoParentescoGMM,
     Excedentes,ExcedentesAnt,MontoFondoAhorroMensual,MontoFondoAhorroMensualAnt,
     SobranteExcedentes,DescuentoEmpleadoFH,DescuentoEmpleadoFinal,SobranteExceFinal,
     CoberturaDesc,Q1,Q2,Diferencia,CtoEmpleadoNomSeg,AplicExcedentes,NumOficina,
     NomOficina,POFH,LocalNumber,CentroCostos)
    SELECT E.EMIdEmpresa,RTRIM(E.EMNumeroEmpleado),E.EMIdAnt,
           ISNULL(E.EMApellidoPaterno,''''),ISNULL(E.EMApellidoMaterno,''''),
           ISNULL(E.EMNombre1,''''),ISNULL(E.EMNombre2,''''),SE.SEDescripcion,
           CONVERT(varchar(10),E.EMFechaNacimiento,103),E.EMEdad,
           CASE WHEN ISNULL(E.EMIdSalarioConfidencial,0)=0 THEN ''NO'' ELSE ''SI'' END,
           E.EMSalarioBase,ISNULL(CCA.ccSueldoMensual,0),
           CASE WHEN ISNULL(E.EMIdTransferido,0)=0 THEN ''NO'' ELSE ''TRANSFERIDO'' END,
           CAST(ISNULL(S.SONumeroSolicitud,'''') AS varchar(5))+''-''+CAST(ISNULL(S.SOAnexoSolicitud,'''') AS varchar(2)),
           P.PENombre,CONVERT(varchar(10),S.SOFechaAprovacion,103),
           ROUND(ISNULL(EA.a_caco1_mv2,0)/@cantidadPagos,2),
           ROUND(ISNULL(EA.a_caco1_mv2,0)/@cantidadPagos-ROUND(ISNULL(EA.a_ec2_mv1,0)/@cantidadPagos,2),2),
           ROUND(ISNULL(EA.a_caco5_mv2,0)/@cantidadPagos,2),
           ROUND(ISNULL(EA.a_caco3_ec1_mv1,0)/@cantidadPagos,2),
           ROUND(ISNULL(EA.a_caco4_ec1_mv1,0)/@cantidadPagos,2),
           ROUND(ISNULL(EA.a_comp,0)/@cantidadPagos,2),ISNULL(CCV.ccTotalCreditos,0),
           ROUND(ISNULL(EA.a_mv2_po,0)/@cantidadPagos-ROUND(ISNULL(EA.a_ec2_mv1,0)/@cantidadPagos,2),2),
           ISNULL(CCV.ccTotalCostos,0),ROUND(ISNULL(EA.a_ec6,0)/@cantidadPagos,2),
           0,0,ISNULL(CCV.ccDescuentoEmpleado,0),GG.GPNombre,
           ROUND(ISNULL(CE.TotalCreditos,0)/@cantidadPagos,2),ISNULL(CCV.ccExcedentes,0),
           ROUND(ISNULL(F.TarifaNeta,0)/@cantidadPagos,2),ISNULL(CCV.ccFondoAhorro,0),
           ROUND(ISNULL(EA.a_ec7_mv1,0)/@cantidadPagos,2),0,0,0,0,0,0,0,0,0,
           E.EMOficina,O.Descripcion,ISNULL(F.PlanFondo,''''),ISNULL(EE.Desarrollo,''''),
           ISNULL(dbo.DescripcionCatalogo(EE.EMIdEmpresa,''EMidCentroCostos'',EE.EMIdCentroCostos),'''')
    FROM dbo.ff_Solicitud AS S WITH(NOLOCK)
    INNER JOIN #BF3_ECKeys AS K
        ON K.ECidEmpresa=S.SOIdEmpresa AND K.ECidSolicitud=S.SOIdSolicitud AND K.ECidEmpleado=S.SOIdEmpleado
    INNER JOIN #ff_Empleadotemp AS E ON E.EMIdAnt=K.ECidEmpleado
    INNER JOIN dbo.ff_Sexo AS SE WITH(NOLOCK) ON SE.SEIdSexo=E.EMIdSexo
    INNER JOIN dbo.ff_Perfil AS P WITH(NOLOCK)
        ON P.PEIdEmpresa=E.EMIdEmpresa AND P.PEIdPerfil=E.EMIdPerfil
    INNER JOIN #ec_agg AS EA
        ON EA.ECidEmpresa=K.ECidEmpresa AND EA.ECidSolicitud=K.ECidSolicitud AND EA.ECidEmpleado=K.ECidEmpleado
    INNER JOIN dbo.ff_Empleado AS EE WITH(NOLOCK) ON EE.Id=E.EMIdAnt
    LEFT JOIN #BF3_CompEmpleado AS CE ON CE.CEIdEmpleado=E.EMIdAnt
    LEFT JOIN #BF3_Fondo AS F
        ON F.POIdEmpresa=E.EMIdEmpresa
       AND F.PONumeroEmpleado COLLATE DATABASE_DEFAULT=E.EMNumeroEmpleado COLLATE DATABASE_DEFAULT
       AND F.POIdSolicitud=S.SOIdSolicitud
    LEFT JOIN #BF3_GrupoGMM AS GG
        ON GG.POIdEmpresa=E.EMIdEmpresa
       AND GG.PONumeroEmpleado COLLATE DATABASE_DEFAULT=E.EMNumeroEmpleado COLLATE DATABASE_DEFAULT
    LEFT JOIN #BF3_Oficina AS O ON O.TEIdDetalle=E.EMOficina
    OUTER APPLY(
        SELECT TOP(1) CC.ccSueldoMensual
        FROM dbo.ff_CobranzaConcentrada AS CC WITH(NOLOCK)
        WHERE CC.ccIdEmpresa=E.EMIdEmpresa AND CC.ccIdEmpleado=E.EMIdAnt
          AND CC.ccAño=@AnioApl AND CC.ccMes=@MesApl
    ) AS CCA
    OUTER APPLY(
        SELECT TOP(1) CC.ccTotalCreditos,CC.ccTotalCostos,CC.ccDescuentoEmpleado,
               CC.ccExcedentes,CC.ccFondoAhorro
        FROM dbo.ff_CobranzaConcentrada AS CC WITH(NOLOCK)
        WHERE CC.ccIdEmpresa=E.EMIdEmpresa AND CC.ccIdEmpleado=E.EMIdAnt
          AND CC.ccAño=@AnioApl AND CC.ccMes=@MesApl AND CC.ccIdVigencia=@idVigencia
    ) AS CCV
    WHERE P.PEIdPerfil IN(SELECT IdTipoNotificacionCorreo FROM #IdPerfilV2)
    ORDER BY E.EMIdAnt
    OPTION(RECOMPILE);
END

';

SET @Def=STUFF(@Def,@Inicio,@Cola-@Inicio,@Bloque);
SET @Def=REPLACE(@Def,N'Invocando ff_ObtenCobranzaDesg_Adaptada_bf3_nousar',
                      N'Invocando ff_ObtenCobranzaDesg_Adaptada_bf3_SET');
SET @Def=REPLACE(@Def,N'ff_ObtenCobranzaDesg_Adaptada_bf3_nousar finalizo',
                      N'ff_ObtenCobranzaDesg_Adaptada_bf3_SET finalizo');
SET @Upper=UPPER(@Def);
SET @Proc=CHARINDEX(N'PROCEDURE',@Upper);
IF @Proc=0 THROW 52682,'No se pudo construir Concentrada SET B3.',1;
SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@Proc,LEN(@Def));
EXEC sys.sp_executesql @Def;

IF OBJECT_DEFINITION(OBJECT_ID(@Destino)) NOT LIKE N'%BF3_CONCENTRADA_ETAPAS_SET_V1%'
    THROW 52683,'Concentrada SET B3 no quedo instalada.',1;

SELECT N'OK' Estado,@Destino Objeto,N'Solo B3; B2 intacto' Alcance;
