/*
   DESGLOSADA POR ETAPAS, EXCLUSIVA B3

   Materializa una vez solicitudes, estado de cuenta, grupos, suma asegurada y
   tarifas. El INSERT final ya no contiene subconsultas correlacionadas por
   cada beneficiario/plan. Al terminar invoca el motor SET del script 18.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Origen sysname=N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR',
        @Destino sysname=N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_SET',
        @Def nvarchar(max),@Upper nvarchar(max),@Inicio int,@Cola int,@Proc int,
        @Bloque nvarchar(max);

IF OBJECT_ID(@Origen,N'P') IS NULL
    THROW 52640,'No existe el procedimiento Desglosada B3 origen.',1;
IF OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado_bf3_SET',N'P') IS NULL
    THROW 52641,'Ejecute primero 18_motor-division-set-solo-b3.sql.',1;

SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Origen));
SET @Def=REPLACE(@Def,N'[dbo].[ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR]',
                      N'[dbo].[ff_ObtenCobranzaDesg_Adaptada_bf3_SET]');
SET @Def=REPLACE(@Def,N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR',
                      N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_SET');
SET @Upper=UPPER(@Def);
SET @Inicio=CHARINDEX(N'/* BF_CACHE_PERF_DESG_SOURCE_INDEX_V1 */',@Upper);
SET @Cola=CHARINDEX(N'--*****************************************************************************************',@Upper,@Inicio);
IF @Inicio=0 OR @Cola=0 OR @Cola<=@Inicio
    THROW 52642,'No se localizaron los limites del INSERT Desglosada B3.',1;

SET @Bloque=N'/* BF3_DESGLOSADA_ETAPAS_SET_V1 */
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES(''cobranza_bf3_desg_set_inicio'',CONCAT(''empresa='',@idEmpresa,''; vigencia='',@idVigencia));
    END TRY BEGIN CATCH END CATCH;

    /* El TOP(1) sin ORDER BY del codigo historico seria ambiguo. No se permite
       escoger otra prima silenciosamente si la misma llave tiene dos montos. */
    IF EXISTS(
        SELECT 1
        FROM dbo.ff_Tarifa AS T WITH(NOLOCK)
        INNER JOIN dbo.ff_TarifaCosto AS TC WITH(NOLOCK) ON TC.TCIdTarifa=T.TAIdTarifa
        WHERE T.TAIdVigencia=@idVigencia AND TC.TCIdEstatus=1
          AND TC.TCIdGrupoParentesco IS NULL
        GROUP BY TC.TCIdPlanOpcion,TC.TCIdParentesco,TC.TCEdad,TC.TCIdSexo
        HAVING MIN(ISNULL(TC.TCPrimaNeta,0))<>MAX(ISNULL(TC.TCPrimaNeta,0))
    )
        THROW 52645,''Tarifa individual ambigua: se cancela para evitar data diferente.'',1;

    IF NOT EXISTS(
        SELECT 1 FROM tempdb.sys.indexes
        WHERE object_id=OBJECT_ID(N''tempdb..#ff_Empleadotemp'')
          AND name=N''IX_BF3_Empleado_Set''
    )
        CREATE NONCLUSTERED INDEX IX_BF3_Empleado_Set
            ON #ff_Empleadotemp(EMidEmpresa,EMidAnt)
            INCLUDE(EMNumeroEmpleado,EMIdPerfil,EMIdParentesco,EMIdSexo);

    SELECT S.SOIdSolicitud,S.SOIdEmpresa,S.SOIdEmpleado,S.SONumEmpleado,
           S.SONumeroSolicitud,S.SOAnexoSolicitud
    INTO #BF3_Solicitudes
    FROM dbo.ff_Solicitud AS S WITH(NOLOCK)
    WHERE S.SOIdVigencia=@idVigencia
      AND S.SOIdEmpresa=@Empresa
      AND S.SOidEstatus=@SOIdEstatus
      AND S.SOEstatusSolicitud=1
      AND S.SOIdSolicitudTipo=1
      AND ISNULL(S.SOFechaAprovacion,CONVERT(date,GETDATE()))<=@FecFin
      AND ISNULL(S.SOFechaAprovacion,CONVERT(date,GETDATE()))>=@FecIni;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_Solicitudes
        ON #BF3_Solicitudes(SOIdEmpresa,SOIdSolicitud);
    CREATE NONCLUSTERED INDEX IX_BF3_Solicitudes_Num
        ON #BF3_Solicitudes(SOIdEmpresa,SONumEmpleado);

    SELECT EC.ECidEmpresa,EC.ECidSolicitud,EC.ECNumeroEmpleado,
           SUM(CASE WHEN EC.ECidCompensacion IS NOT NULL
                    THEN ISNULL(EC.ECCantidad,0) ELSE 0 END) AS MontoTotalCreditos,
           SUM(CASE WHEN EC.ECTipoMovto=1 AND EC.ECIdConcepto=7
                    THEN ISNULL(EC.ECCantidad,0) ELSE 0 END) AS SobranteExcedentes
    INTO #BF3_EdoSolicitud
    FROM dbo.ff_EdoCuentaCobranza AS EC WITH(NOLOCK)
    INNER JOIN #BF3_Solicitudes AS S
        ON S.SOIdEmpresa=EC.ECidEmpresa AND S.SOIdSolicitud=EC.ECidSolicitud
       AND S.SONumEmpleado COLLATE DATABASE_DEFAULT=EC.ECNumeroEmpleado COLLATE DATABASE_DEFAULT
    GROUP BY EC.ECidEmpresa,EC.ECidSolicitud,EC.ECNumeroEmpleado
    OPTION(RECOMPILE);
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_EdoSolicitud
        ON #BF3_EdoSolicitud(ECidEmpresa,ECidSolicitud,ECNumeroEmpleado);

    SELECT GPIdGrupoParentesco,MAX(RTRIM(LTRIM(GPDescripcion))) AS GPDescripcion
    INTO #BF3_GrupoDesc
    FROM dbo.ff_GrupoParentesco WITH(NOLOCK)
    GROUP BY GPIdGrupoParentesco;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_GrupoDesc ON #BF3_GrupoDesc(GPIdGrupoParentesco);

    SELECT GPIdGrupoParentesco,SUM(GPCantidad) AS Cantidad
    INTO #BF3_GrupoCantidad
    FROM dbo.ff_GrupoParentescoParentesco WITH(NOLOCK)
    GROUP BY GPIdGrupoParentesco;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_GrupoCantidad ON #BF3_GrupoCantidad(GPIdGrupoParentesco);

    SELECT VSIdEmpleado,VSIdPlanOpcion,VSIdVigencia,MAX(VSSumaAsegurada) AS SumaAsegurada
    INTO #BF3_ValidaSA
    FROM dbo.ff_ValidaSAVida WITH(NOLOCK)
    WHERE VSIdEstatus=1 AND VSIdVigencia=@idVigencia
    GROUP BY VSIdEmpleado,VSIdPlanOpcion,VSIdVigencia;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_ValidaSA
        ON #BF3_ValidaSA(VSIdEmpleado,VSIdPlanOpcion,VSIdVigencia);

    SELECT T.TAIdVigencia,TC.TCIdPlanOpcion,TC.TCIdParentesco,TC.TCEdad,TC.TCIdSexo,
           MAX(TC.TCPrimaNeta) AS PrimaNeta
    INTO #BF3_TCIndividual
    FROM dbo.ff_Tarifa AS T WITH(NOLOCK)
    INNER JOIN dbo.ff_TarifaCosto AS TC WITH(NOLOCK) ON TC.TCIdTarifa=T.TAIdTarifa
    WHERE T.TAIdVigencia=@idVigencia AND TC.TCIdEstatus=1 AND TC.TCIdGrupoParentesco IS NULL
    GROUP BY T.TAIdVigencia,TC.TCIdPlanOpcion,TC.TCIdParentesco,TC.TCEdad,TC.TCIdSexo;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_TCIndividual
        ON #BF3_TCIndividual(TAIdVigencia,TCIdPlanOpcion,TCIdParentesco,TCEdad,TCIdSexo);

    SELECT T.TAIdVigencia,TC.TCIdPlanOpcion,TC.TCIdGrupoParentesco,
           MAX(TC.TCPrimaNeta) AS PrimaNeta
    INTO #BF3_TCGrupo
    FROM dbo.ff_Tarifa AS T WITH(NOLOCK)
    INNER JOIN dbo.ff_TarifaCosto AS TC WITH(NOLOCK) ON TC.TCIdTarifa=T.TAIdTarifa
    WHERE T.TAIdVigencia=@idVigencia AND T.TAIdEstatus=1
      AND TC.TCIdEstatus=1 AND TC.TCIdSexo IS NULL
    GROUP BY T.TAIdVigencia,TC.TCIdPlanOpcion,TC.TCIdGrupoParentesco;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_TCGrupo
        ON #BF3_TCGrupo(TAIdVigencia,TCIdPlanOpcion,TCIdGrupoParentesco);

    SELECT T.TAIdVigencia,TC.TCIdPlanOpcion,TC.TCIdGrupoParentesco,TC.TCIdSexo,
           MAX(TC.TCPrimaNeta) AS PrimaNeta
    INTO #BF3_TCFallback
    FROM dbo.ff_Tarifa AS T WITH(NOLOCK)
    INNER JOIN dbo.ff_TarifaCosto AS TC WITH(NOLOCK) ON TC.TCIdTarifa=T.TAIdTarifa
    WHERE T.TAIdVigencia=@idVigencia AND T.TAIdEstatus=1 AND TC.TCIdEstatus=1
      AND TC.TCIdGrupoParentesco IS NOT NULL
    GROUP BY T.TAIdVigencia,TC.TCIdPlanOpcion,TC.TCIdGrupoParentesco,TC.TCIdSexo;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_TCFallback
        ON #BF3_TCFallback(TAIdVigencia,TCIdPlanOpcion,TCIdGrupoParentesco,TCIdSexo);

    SELECT T.TAIdVigencia,TP.TPIdPlanOpcion,TP.TPIdPerfil,MAX(TP.TPPrimaNeta) AS PrimaNeta
    INTO #BF3_TCPerfil
    FROM dbo.ff_Tarifa AS T WITH(NOLOCK)
    INNER JOIN dbo.ff_TarifaCostoPerfil AS TP WITH(NOLOCK) ON TP.TPIdTarifa=T.TAIdTarifa
    WHERE T.TAIdVigencia=@idVigencia AND T.TAIdEstatus=1 AND TP.TPIdEstatus=1
    GROUP BY T.TAIdVigencia,TP.TPIdPlanOpcion,TP.TPIdPerfil;
    CREATE UNIQUE CLUSTERED INDEX CX_BF3_TCPerfil
        ON #BF3_TCPerfil(TAIdVigencia,TPIdPlanOpcion,TPIdPerfil);

    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        SELECT ''cobranza_bf3_desg_set_etapas'',
               CONCAT(''solicitudes='',(SELECT COUNT_BIG(*) FROM #BF3_Solicitudes),
                      ''; edo='',(SELECT COUNT_BIG(*) FROM #BF3_EdoSolicitud));
    END TRY BEGIN CATCH END CATCH;

    INSERT INTO #TablaCobDesg
    SELECT POS.POidEmpresa,RTRIM(S.SONumEmpleado),POS.POidEmpleado,
           ISNULL(E.EMApellidoPaterno,''''),ISNULL(E.EMApellidoMaterno,''''),
           ISNULL(E.EMNombre1,''''),ISNULL(E.EMNombre2,''''),E.EMIdSexo,SE.SEDescripcion,
           CONVERT(varchar(10),E.EMFechaNacimiento,103),POS.POEdad,PE.PENombre,
           E.EMIdParentesco,P.PADescripcion,
           CASE WHEN ISNULL(E.EMIdTransferido,0)=0 THEN ''NO'' ELSE ''TRANSFERIDO'' END,
           E.EMSalarioBase,
           CAST(S.SONumeroSolicitud AS varchar(5))+''-''+CAST(S.SOAnexoSolicitud AS varchar(2)),
           S.SOIdSolicitud,PL.PLDescripcion,PO.PODescripcion,
           ISNULL(POS.POIdGrupoParentesco,0),
           CASE WHEN POS.POIdGrupoParentesco IS NULL THEN ''PLAN INDIVIDUAL'' ELSE GD.GPDescripcion END,
           PO.POIdPlanOpcion,PO.POIdPlan,PO.POIdTipoSumaAsegurada,
           V.SumaAsegurada/@cantidadPagos,
           PL.PLOrdenCobranza,
           ROUND(ISNULL(
             CASE WHEN POS.POIdGrupoParentesco IS NULL THEN
                    CASE WHEN POS.POCostoRestante=0 THEN POS.POTarifaNeta ELSE POS.POCostoRestante END
                  WHEN E.EMIdParentesco=1 THEN POS.POTarifaNeta END,
             CASE WHEN ISNULL(GC.Cantidad,0)=1 THEN POS.POCostoRestante ELSE 0 END),2),
           ROUND(ISNULL(
             CASE WHEN PP.PPIdPeriodicidadPago IS NOT NULL
                       AND (POS.POIdGrupoParentesco IS NULL OR E.EMIdParentesco=1)
                    THEN CASE WHEN POS.POCostoRestante>0
                              THEN ROUND(POS.POCostoRestante/@cantidadPagos,2) ELSE 0 END END,
             CASE WHEN ISNULL(GC.Cantidad,0)=1 AND PP.PPIdPeriodicidadPago IS NOT NULL
                    THEN CASE WHEN POS.POCostoRestante=0 THEN 0
                              ELSE ROUND(POS.POCostoRestante/@cantidadPagos,2) END
                  ELSE 0 END),2),
           ROUND(ISNULL(EC.MontoTotalCreditos,0),2),
           ROUND(ISNULL(EC.MontoTotalCreditos,0)/@cantidadPagos,2),
           CONVERT(money,0),0,0,0,CONVERT(money,0),0,0,0,0,0,
           ROUND(ISNULL(EC.SobranteExcedentes,0)/@cantidadPagos,2),
           ROUND(ISNULL(
             CASE
               WHEN POS.POIdGrupoParentesco IS NULL AND PO.POIdTipoCosto<>6
                    AND TI.TCIdPlanOpcion IS NOT NULL
                 THEN CASE WHEN PL.PLSAMI>0 AND PO.POIdTipoSumaAsegurada<>4
                           THEN POS.POTarifaNeta ELSE TI.PrimaNeta END
               WHEN POS.POIdGrupoParentesco IS NOT NULL AND PO.POIdTipoCosto<>6
                    AND POS.POIdEmpresa=@empresa AND E.EMIdParentesco=1 THEN TG.PrimaNeta
               WHEN PO.POIdTipoCosto=6 AND POS.POIdGrupoParentesco IS NULL
                    AND POS.POIdEmpresa=@empresa THEN TP.PrimaNeta
             END,TF.PrimaNeta),2),
           CONVERT(money,0),@idVigencia
    FROM dbo.ff_PlanOpcionSeleccionCobranza2 AS POS WITH(NOLOCK)
    INNER JOIN #BF3_Solicitudes AS S
        ON S.SOIdEmpresa=POS.POIdEmpresa AND S.SOIdSolicitud=POS.POIdSolicitud
       AND S.SONumEmpleado COLLATE DATABASE_DEFAULT=POS.PONumeroEmpleado COLLATE DATABASE_DEFAULT
    INNER JOIN #ff_Empleadotemp AS E
        ON E.EMIdEmpresa=POS.POIdEmpresa AND E.EMIdAnt=POS.POIdEmpleado
    INNER JOIN dbo.ff_Perfil AS PE WITH(NOLOCK)
        ON PE.PEIdEmpresa=E.EMIdEmpresa AND PE.PEIdPerfil=E.EMIdPerfil
    INNER JOIN dbo.ff_Parentesco AS P WITH(NOLOCK) ON P.PAIdParentesco=E.EMIdParentesco
    INNER JOIN dbo.ff_Sexo AS SE WITH(NOLOCK) ON SE.SEIdSexo=E.EMIdSexo
    INNER JOIN dbo.ff_PlanOpcion AS PO WITH(NOLOCK)
        ON PO.POIdPlanOpcion=POS.POIdPlanOpcion AND PO.POIdEstatus=1
    INNER JOIN dbo.ff_Plan AS PL WITH(NOLOCK)
        ON PL.PLIdPlan=PO.POIdPlan AND PL.PLIdEstatus=1 AND PL.PLFondoDeAhorro=0
    INNER JOIN dbo.ff_ConcepAgrupaCob AS CA WITH(NOLOCK)
        ON CA.CAIdEmpresa=POS.POIdEmpresa AND CA.CAIdPlanOpcion=POS.POIdPlanOpcion
    LEFT JOIN #BF3_EdoSolicitud AS EC
        ON EC.ECidEmpresa=POS.POIdEmpresa AND EC.ECidSolicitud=POS.POIdSolicitud
       AND EC.ECNumeroEmpleado COLLATE DATABASE_DEFAULT=POS.PONumeroEmpleado COLLATE DATABASE_DEFAULT
    LEFT JOIN #BF3_GrupoDesc AS GD ON GD.GPIdGrupoParentesco=POS.POIdGrupoParentesco
    LEFT JOIN #BF3_GrupoCantidad AS GC ON GC.GPIdGrupoParentesco=POS.POIdGrupoParentesco
    LEFT JOIN #BF3_ValidaSA AS V
        ON V.VSIdEmpleado=POS.POIdEmpleado AND V.VSIdPlanOpcion=POS.POIdPlanOpcion
       AND V.VSIdVigencia=POS.POIdVigencia
    LEFT JOIN dbo.ff_PeriodicidadPago AS PP WITH(NOLOCK)
        ON PP.PPIdPeriodicidadPago=POS.POIdPeriodicidadPago
    LEFT JOIN #BF3_TCIndividual AS TI
        ON TI.TAIdVigencia=POS.POIdVigencia AND TI.TCIdPlanOpcion=POS.POIdPlanOpcion
       AND TI.TCIdParentesco=POS.POIdParentesco AND TI.TCEdad=POS.POEdad
       AND TI.TCIdSexo=E.EMIdSexo
    LEFT JOIN #BF3_TCGrupo AS TG
        ON TG.TAIdVigencia=POS.POIdVigencia AND TG.TCIdPlanOpcion=POS.POIdPlanOpcion
       AND TG.TCIdGrupoParentesco=POS.POIdGrupoParentesco
    LEFT JOIN #BF3_TCFallback AS TF
        ON TF.TAIdVigencia=POS.POIdVigencia AND TF.TCIdPlanOpcion=POS.POIdPlanOpcion
       AND TF.TCIdGrupoParentesco=POS.POIdGrupoParentesco AND TF.TCIdSexo=E.EMIdSexo
       AND POS.POIdEmpresa=@empresa AND E.EMIdParentesco=1
    LEFT JOIN #BF3_TCPerfil AS TP
        ON TP.TAIdVigencia=POS.POIdVigencia AND TP.TPIdPlanOpcion=POS.POIdPlanOpcion
       AND TP.TPIdPerfil=E.EMIdPerfil
    WHERE POS.POIdEstatus=@SOIdEstatus
      AND POS.POIdEmpresa IN(SELECT EMIdEmpresa FROM #ListEmpresas)
      AND PE.PEIdPerfil IN(SELECT IdTipoNotificacionCorreo FROM #IdPerfilV2)
    ORDER BY S.SONumEmpleado,PL.PLOrdenCobranza,POS.POIdPlanOpcionSeleccion,
             POS.POAnexo,POS.POIdPlanOpcion,POS.POEdad,POS.POIdGrupoParentesco
    OPTION(RECOMPILE);
END

';

SET @Def=STUFF(@Def,@Inicio,@Cola-@Inicio,@Bloque);
SET @Def=REPLACE(@Def,N'EXEC dbo.ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR',
                      N'EXEC dbo.ff_ObtenDivisionCtos_Adaptado_bf3_SET');
SET @Upper=UPPER(@Def);
SET @Proc=CHARINDEX(N'PROCEDURE',@Upper);
IF @Proc=0
    THROW 52643,'No se pudo construir Desglosada SET B3.',1;
SET @Def=N'CREATE OR ALTER '+SUBSTRING(@Def,@Proc,LEN(@Def));
EXEC sys.sp_executesql @Def;

IF OBJECT_DEFINITION(OBJECT_ID(@Destino)) NOT LIKE N'%BF3_DESGLOSADA_ETAPAS_SET_V1%'
    THROW 52644,'Desglosada SET B3 no quedo instalada.',1;

SELECT N'OK' AS Estado,@Destino AS Objeto,N'Solo B3; B2 intacto' AS Alcance;
