/* MONITOR ZURICH 1807 / VIGENCIAS 4320 Y 3993 - SOLO LECTURA */
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @IdEmpresa int=1807,@CacheId bigint,@Inicio datetime2(3),
        @SesionId smallint,@Ahora datetime2(3)=SYSDATETIME();

;WITH UltimoEvento AS
(
    SELECT L.CacheId,L.IdVigencia,L.Estado,L.LogId,L.Fecha,
           ROW_NUMBER() OVER(PARTITION BY L.CacheId ORDER BY L.LogId DESC) RN
    FROM dbo.bf_CobranzaCache_Log AS L WITH(NOLOCK)
    WHERE L.IdEmpresa=@IdEmpresa AND L.IdVigencia IN(4320,3993)
      AND L.CacheId IS NOT NULL AND L.Fecha>=DATEADD(DAY,-1,@Ahora)
)
SELECT TOP(1) @CacheId=CacheId
FROM UltimoEvento
WHERE RN=1 AND Estado='CARGANDO'
ORDER BY LogId DESC;

IF @CacheId IS NULL
    SELECT TOP(1) @CacheId=CacheId
    FROM dbo.bf_CobranzaCache_ConsultaV2 WITH(NOLOCK)
    WHERE IdEmpresa=@IdEmpresa AND IdVigencia IN(4320,3993)
    ORDER BY FechaCargaInicio DESC,CacheId DESC;

IF @CacheId IS NULL
    THROW 52940,'Todavia no existe una carga Zurich para las vigencias 4320/3993.',1;

SELECT TOP(1) @Inicio=Fecha
FROM dbo.bf_CobranzaCache_Log WITH(NOLOCK)
WHERE CacheId=@CacheId AND Etapa='SP_ORIGINAL_INICIO'
ORDER BY LogId DESC;

SELECT TOP(1) @SesionId=SesionId
FROM dbo.bf_CobranzaCache_Log WITH(NOLOCK)
WHERE CacheId=@CacheId AND Fecha>=@Inicio AND SesionId IS NOT NULL
ORDER BY LogId DESC;

SELECT C.CacheId,C.IdEmpresa,C.IdVigencia,C.Estado,C.FechaCargaInicio,
       C.FechaCargaFin,DATEDIFF(SECOND,@Inicio,@Ahora) SegundosActuales,
       CAST(DATEDIFF(SECOND,@Inicio,@Ahora)/60.0 AS decimal(10,2)) MinutosActuales,
       C.FilasConcentrada,C.FilasDesglosada,C.Mensaje,@SesionId SesionSql
FROM dbo.bf_CobranzaCache_ConsultaV2 AS C WITH(NOLOCK)
WHERE C.CacheId=@CacheId;

SELECT CacheId,IdVigencia,Estado,FechaCargaInicio,FechaCargaFin,
       FilasConcentrada,FilasDesglosada,Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH(NOLOCK)
WHERE IdEmpresa=@IdEmpresa AND IdVigencia IN(4320,3993)
ORDER BY IdVigencia DESC,CacheId DESC;

;WITH E AS
(
    SELECT TOP(200) LogId,Fecha,Etapa,Estado,Detalle,SesionId
    FROM dbo.bf_CobranzaCache_Log WITH(NOLOCK)
    WHERE CacheId=@CacheId AND Fecha>=@Inicio
    ORDER BY LogId DESC
), T AS
(
    SELECT E.*,LAG(Fecha) OVER(ORDER BY LogId) FechaAnterior
    FROM E
)
SELECT LogId,Fecha,Etapa,
       CASE
         WHEN Etapa='SP_ORIGINAL_INICIO' THEN 'Inicio del motor B3'
         WHEN Etapa='cobranza_bf3_ruta_sql' THEN 'Entrada a SET_UNICA'
         WHEN Etapa IN('cobranza_obten_pre_sinc','cobranza_obten_pre_sinc_exec') THEN 'Sincronizando fuente'
         WHEN Etapa='cobranza_obten_post_sinc' THEN 'Sincronizacion terminada'
         WHEN Etapa LIKE 'cobranza_bf3_conc%' OR Etapa='cobranza_obten_post_insert' THEN 'Construyendo concentrada'
         WHEN Etapa='cobranza_obten_pre_desglosada' OR Etapa LIKE 'cobranza_bf3_desg%' THEN 'Construyendo desglosada'
         WHEN Etapa LIKE 'cobranza_bf3_division_set%' THEN 'Division masiva SET'
         WHEN Etapa IN('cobranza_obten_post_desglosada','cobranza_obten_fin','SP_ORIGINAL_FIN','CARGA_COMPLETA') THEN 'Finalizando'
         ELSE 'Procesando cobranza'
       END PasoInterpretado,
       DATEDIFF(MILLISECOND,FechaAnterior,Fecha) MilisegundosDesdeAnterior,
       Estado,Detalle,SesionId
FROM T
ORDER BY LogId;

IF HAS_PERMS_BY_NAME(NULL,NULL,'VIEW SERVER STATE')=1
    SELECT R.session_id,R.status,R.command,R.wait_type,R.wait_time,R.cpu_time,
           R.total_elapsed_time,R.logical_reads,R.reads,R.writes,
           R.blocking_session_id
    FROM sys.dm_exec_requests AS R
    WHERE R.session_id=@SesionId;
ELSE
    SELECT N'Para consultar la sesion manualmente: EXEC master.dbo.sp_who2 '
           +CONVERT(varchar(10),@SesionId) AS Aviso;

