/*
   CARGA INICIAL REAL B3 - ZURICH SANTANDER

   Alcance estricto:
     IdEmpresa   = 1807
     IdVigencia  = 4320 y 3993

   No descubre otras vigencias, no ejecuta limpieza general y no devuelve las
   filas del reporte a SSMS. Reconstruye solamente los dos universos indicados.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=1807,
        @ForzarRecarga bit=1,
        @FechaCorte datetime=GETDATE(),
        @InicioTotal datetime2(3)=SYSDATETIME(),
        @FinTotal datetime2(3),
        @InicioVigencia datetime2(3),
        @FinVigencia datetime2(3),
        @IdVigencia int,
        @FecIni varchar(16),
        @FecFin varchar(16),
        @CacheId bigint,
        @Orden tinyint=1;

IF OBJECT_ID(N'dbo.InsertaCobranzaConcentrada_otro_V2_BF3_Cache',N'P') IS NULL
    THROW 52930,'Falta el procedimiento de carga de cache B3.',1;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'))
   NOT LIKE N'%BF3_FLUJO_UNICO_SET_V1%'
    THROW 52931,'No esta instalado el flujo unico SET de B3.',1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMidEmpresa=@IdEmpresa AND EMidEstatus=1
)
    THROW 52932,'La empresa 1807 no existe o no esta activa.',1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Parametro
    WHERE paIdEmpresa=@IdEmpresa
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE'
      AND LTRIM(RTRIM(paValor))='1'
      AND paIdEstatus=1
)
    THROW 52933,'ZURICH SANTANDER no tiene COBRANZA_CACHE=1. Configure la empresa antes de cargar.',1;

DECLARE @Perfiles dbo.ListInt;

INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT PEIdPerfil
FROM dbo.ff_Perfil WITH (NOLOCK)
WHERE PEIdEmpresa=@IdEmpresa
  AND PEIdEstatus=1
  AND PEAdministrador=0;

IF NOT EXISTS (SELECT 1 FROM @Perfiles)
    THROW 52934,'ZURICH SANTANDER no tiene perfiles activos no administradores.',1;

DECLARE @Vigencias TABLE
(
    Orden tinyint NOT NULL PRIMARY KEY,
    IdVigencia int NOT NULL UNIQUE,
    FecIni varchar(16) NULL,
    FecFin varchar(16) NULL
);

/* Son las unicas vigencias autorizadas para este lote. */
INSERT @Vigencias(Orden,IdVigencia)
VALUES(1,4320),(2,3993);

UPDATE T
SET FecIni=CONVERT(varchar(16),
        CASE WHEN V.VIEnrollmentIni IS NOT NULL
                  AND V.VIEnrollmentIni<V.VIVigenciaIni
             THEN V.VIEnrollmentIni ELSE V.VIVigenciaIni END,120),
    FecFin=CONVERT(varchar(16),
        CASE WHEN V.VIVigenciaFin<@FechaCorte THEN V.VIVigenciaFin
             ELSE DATEADD(MINUTE,-1,
                  DATEADD(DAY,1,CONVERT(datetime,CONVERT(date,@FechaCorte)))) END,120)
FROM @Vigencias AS T
INNER JOIN dbo.ff_Empresa AS E WITH (NOLOCK)
        ON E.EMidEmpresa=@IdEmpresa AND E.EMidEstatus=1
INNER JOIN dbo.ff_Vigencia AS V WITH (NOLOCK)
        ON V.VIidConfiguracion=E.EMidConfiguracion
       AND V.VIidVigencia=T.IdVigencia
       AND V.VITipoNegocio=1;

IF EXISTS(SELECT 1 FROM @Vigencias WHERE FecIni IS NULL OR FecFin IS NULL)
BEGIN
    SELECT * FROM @Vigencias ORDER BY Orden;
    THROW 52935,'La vigencia 4320 o 3993 no pertenece a la configuracion de la empresa 1807.',1;
END;

SELECT N'PARAMETROS_CARGA_INICIAL' AS Resultado,@IdEmpresa AS IdEmpresa,
       (SELECT COUNT(*) FROM @Perfiles) AS PerfilesReales,
       @FechaCorte AS FechaCorte,@ForzarRecarga AS ForzarRecarga,
       N'SET_UNICA' AS MotorB3;

SELECT Orden,IdVigencia,FecIni,FecFin
FROM @Vigencias
ORDER BY Orden;

DECLARE @Resultado TABLE
(
    Orden tinyint NOT NULL,
    CacheId bigint NULL,
    IdVigencia int NOT NULL,
    Estado varchar(20) NULL,
    Inicio datetime2(3) NOT NULL,
    Fin datetime2(3) NOT NULL,
    Segundos int NOT NULL,
    FilasConcentrada int NULL,
    FilasDesglosada int NULL,
    Mensaje nvarchar(2000) NULL
);

WHILE @Orden<=2
BEGIN
    SELECT @IdVigencia=IdVigencia,@FecIni=FecIni,@FecFin=FecFin
    FROM @Vigencias
    WHERE Orden=@Orden;

    SET @CacheId=NULL;
    SET @InicioVigencia=SYSDATETIME();

    RAISERROR('Iniciando carga inicial Zurich %d de 2. Empresa=1807; vigencia=%d; rango=%s a %s',
              10,1,@Orden,@IdVigencia,@FecIni,@FecFin) WITH NOWAIT;

    BEGIN TRY
        EXEC dbo.InsertaCobranzaConcentrada_otro_V2_BF3_Cache
             @idEmpresa=@IdEmpresa,
             @idSolTipo=0,
             @FecIni=@FecIni,
             @FecFin=@FecFin,
             @idVencida=1,
             @IdPerfil=@Perfiles,
             @idVIgencia=@IdVigencia,
             @ForzarRecarga=@ForzarRecarga,
             @PrecargarUltimas4=0,
             @EmitirResultado=0,
             @EsUniverso=1;

        SET @FinVigencia=SYSDATETIME();

        SELECT TOP (1) @CacheId=C.CacheId
        FROM dbo.bf_CobranzaCache_ConsultaV2 AS C
        WHERE C.IdEmpresa=@IdEmpresa
          AND C.IdVigencia=@IdVigencia
          AND C.EsUniverso=1
        ORDER BY C.CacheId DESC;

        IF @CacheId IS NULL OR NOT EXISTS
        (
            SELECT 1 FROM dbo.bf_CobranzaCache_ConsultaV2
            WHERE CacheId=@CacheId AND Estado='COMPLETA'
        )
            THROW 52936,'La carga termino sin dejar la cache en estado COMPLETA.',1;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.bf_RepConf_Debug
            WHERE etapa='cobranza_bf3_ruta_sql'
              AND detalle LIKE CONCAT('%ruta=SET_UNICA; empresa=',@IdEmpresa,
                                      '; vigencia=',@IdVigencia,'%')
              AND fecha>=@InicioVigencia
        )
            THROW 52937,'La carga termino sin evidencia de la ruta SET_UNICA.',1;

        INSERT @Resultado
        SELECT @Orden,@CacheId,@IdVigencia,C.Estado,
               @InicioVigencia,@FinVigencia,
               DATEDIFF(SECOND,@InicioVigencia,@FinVigencia),
               C.FilasConcentrada,C.FilasDesglosada,C.Mensaje
        FROM dbo.bf_CobranzaCache_ConsultaV2 AS C
        WHERE C.CacheId=@CacheId;

        RAISERROR('Carga Zurich completa. Vigencia=%d; CacheId=%I64d.',
                  10,1,@IdVigencia,@CacheId) WITH NOWAIT;
    END TRY
    BEGIN CATCH
        SET @FinVigencia=SYSDATETIME();

        IF @CacheId IS NULL
            SELECT TOP (1) @CacheId=CacheId
            FROM dbo.bf_CobranzaCache_ConsultaV2
            WHERE IdEmpresa=@IdEmpresa AND IdVigencia=@IdVigencia
              AND EsUniverso=1
            ORDER BY CacheId DESC;

        SELECT N'CARGA_ZURICH_FALLO' AS Resultado,ERROR_NUMBER() AS NumeroError,
               ERROR_MESSAGE() AS Error,@IdVigencia AS IdVigencia,
               @CacheId AS CacheId,
               DATEDIFF(SECOND,@InicioVigencia,@FinVigencia) AS SegundosHastaError;

        SELECT TOP (100) LogId,Fecha,CacheId,IdEmpresa,IdVigencia,
               Estado,Etapa,Detalle,SesionId
        FROM dbo.bf_CobranzaCache_Log
        WHERE CacheId=@CacheId
        ORDER BY LogId DESC;

        THROW;
    END CATCH;

    SET @Orden+=1;
END;

SET @FinTotal=SYSDATETIME();

SELECT Orden,CacheId,IdVigencia,Estado,Inicio,Fin,Segundos,
       CAST(Segundos/60.0 AS decimal(10,2)) AS Minutos,
       FilasConcentrada,FilasDesglosada,Mensaje
FROM @Resultado
ORDER BY Orden;

SELECT N'CARGA_INICIAL_ZURICH_COMPLETA' AS Resultado,
       @IdEmpresa AS IdEmpresa,2 AS VigenciasProcesadas,
       DATEDIFF(SECOND,@InicioTotal,@FinTotal) AS SegundosTotales,
       CAST(DATEDIFF(SECOND,@InicioTotal,@FinTotal)/60.0 AS decimal(10,2)) AS MinutosTotales;

