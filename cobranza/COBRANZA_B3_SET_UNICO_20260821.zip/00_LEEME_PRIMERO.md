# Optimización de Cobranza B3 — flujo único

El flujo normal de B3 queda único:

`tradicional o caché → ObtenCobranzaConcentrada_otro_V2_BF3 → rama SET`

La configuración por empresa decide solamente si el reporte se atiende desde
caché o se calcula de forma tradicional. Ambos caminos usan las mismas reglas y
el mismo motor optimizado. Las copias `LEGACY` y `OPT` permanecen instaladas como
respaldo técnico, pero no se seleccionan mediante valores de sistema.

## Orden de ejecución en DEV

Prerrequisito: deben existir las copias B3 `..._LEGACY` y `..._OPT` creadas por
el script 12 que ya se ejecutó en esta homologación. En el esquema actual no es
necesario volver a ejecutar los scripts 01 a 16.

No debe existir una carga activa. Ejecutar una sola vez, en este orden:

1. `01_motor-division-set-b3.sql`
2. `02_desglosada-etapas-set-b3.sql`
3. `03_concentrada-etapas-set-b3.sql`
4. `04_integracion-flujo-unico-b3.sql`
5. `05_validacion-final-b3.sql`

`07_MONITOREO_OPCIONAL_b3.sql` es de solo lectura y puede ejecutarse durante la
carga de la empresa 186.

## Carga real de validación (empresa 186)

Después de instalar y validar los cinco objetos anteriores, ejecutar
`06_CARGA_REAL_EMPRESA_186_b3.sql`. Este script reconstruye datos reales: por
defecto procesa las cuatro vigencias más recientes con los perfiles activos de
la empresa 186, fuerza la recarga y mide el tiempo total contra una línea base
de dos horas. No devuelve las miles de filas del reporte a SSMS, para no mezclar
el costo de transferencia con el tiempo del servidor.

Para una prueba real de una sola vigencia, cambiar `@CantidadVigencias` de 4 a
1. Si encuentra una vigencia en estado `CARGANDO`, se detiene sin sobrescribirla.
Durante la ejecución puede abrirse otra ventana y correr el script 07 de
monitoreo.

## Carga inicial Zurich Santander

Ejecutar `08_CONFIGURAR_CACHE_ZURICH_1807.sql` y después
`09_CARGA_INICIAL_ZURICH_1807_VIG_4320_3993.sql`. La carga reconstruye
exclusivamente los universos de la empresa 1807 para las vigencias 4320 y 3993.
No descubre ni limpia otras vigencias. Requiere que la empresa ya tenga
`COBRANZA_CACHE=1`; el script 08 modifica solamente ese parámetro para la empresa
1807 y es idempotente. `10_MONITOREO_ZURICH_1807.sql` permite monitorear
únicamente ese lote desde otra ventana.

## Evidencia local con la exportación real

- Volumen: 3,880 empleados y 23,889 filas desglosadas.
- Máximo: 39 planes por empleado.
- Motor anterior: un ciclo por empleado y otro por plan.
- Motor nuevo: 39 pasos masivos como máximo.
- Resultado comparado: 23,889 de 23,889 filas exactas en las 11 columnas de
  distribución de costos; cero diferencias.
- Tiempo medido del motor completo de división: 2.491 segundos en LocalDB.

Esta medición no predice por sí sola el tiempo total de DEV: la sincronización y
las lecturas de origen dependen del volumen y hardware de esa base. Concentrada
y Desglosada también fueron reorganizadas por etapas para evitar subconsultas
correlacionadas. El script de monitoreo permite medir cada etapa por separado.

## Seguridad de resultados

- B2 no se modifica ni se enruta a objetos SET.
- Importes negativos o llaves históricas duplicadas conservan el motor de
  división B3 anterior automáticamente.
- Si una tarifa individual tiene dos primas diferentes para la misma llave, la
  carga se detiene con un error explícito en vez de elegir un valor distinto.
