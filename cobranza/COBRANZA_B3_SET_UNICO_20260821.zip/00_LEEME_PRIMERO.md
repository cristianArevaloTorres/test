# Optimización de Cobranza B3 — flujo único

El flujo normal de B3 queda único:

`tradicional o caché → ObtenCobranzaConcentrada_otro_V2_BF3 → rama SET`

La configuración por empresa decide solamente si el reporte se atiende desde
caché o se calcula de forma tradicional. Ambos caminos usan las mismas reglas y
el mismo motor optimizado. Las copias `LEGACY` y `OPT` permanecen instaladas como
respaldo técnico, pero no se seleccionan mediante valores de sistema.

## Orden de ejecución en DEV

Prerrequisito: deben existir las copias B3 `..._LEGACY` y `..._OPT` creadas por
el script 12 que ya se ejecutó en esta homologación. En el esquema actual no es
necesario volver a ejecutar los scripts 01 a 16.

No debe existir una carga activa. Ejecutar una sola vez, en este orden:

1. `18_motor-division-set-solo-b3.sql`
2. `20_desglosada-etapas-set-solo-b3.sql`
3. `23_concentrada-etapas-set-solo-b3.sql`
4. `24_integracion-flujo-unico-optimizado-b3.sql`
5. `25_validacion-final-flujo-unico-b3.sql`

`26_monitoreo-flujo-unico-b3.sql` es de solo lectura y puede ejecutarse durante
la carga. Los scripts 17 y 19 pertenecen únicamente al laboratorio LocalDB; no
se despliegan en DEV.

## Evidencia local con la exportación real

- Volumen: 3,880 empleados y 23,889 filas desglosadas.
- Máximo: 39 planes por empleado.
- Motor anterior: un ciclo por empleado y otro por plan.
- Motor nuevo: 39 pasos masivos como máximo.
- Resultado comparado: 23,889 de 23,889 filas exactas en las 11 columnas de
  distribución de costos; cero diferencias.
- Tiempo medido del motor completo de división: 2.491 segundos en LocalDB.

Esta medición no predice por sí sola el tiempo total de DEV: la sincronización y
las lecturas de origen dependen del volumen y hardware de esa base. Concentrada
y Desglosada también fueron reorganizadas por etapas para evitar subconsultas
correlacionadas. El script de monitoreo permite medir cada etapa por separado.

## Seguridad de resultados

- B2 no se modifica ni se enruta a objetos SET.
- Importes negativos o llaves históricas duplicadas conservan el motor de
  división B3 anterior automáticamente.
- Si una tarifa individual tiene dos primas diferentes para la misma llave, la
  carga se detiene con un error explícito en vez de elegir un valor distinto.
