/*
   HABILITAR CACHE DE COBRANZA SOLAMENTE PARA ZURICH SANTANDER (1807)

   Idempotente. No modifica el horario global del worker ni parametros B2.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=1807,@Usuario int=1,@IdParametro int;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMidEmpresa=@IdEmpresa AND EMidEstatus=1
)
    THROW 52945,'La empresa 1807 no existe o no esta activa.',1;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP(1) @IdParametro=paId
    FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=@IdEmpresa
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))='COBRANZA_CACHE'
    ORDER BY paIdEstatus DESC,paId DESC;

    IF @IdParametro IS NULL
    BEGIN
        SELECT @IdParametro=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paIdEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@IdParametro,@IdEmpresa,'COBRANZA_CACHE','1',
         'Habilita cache V2 de cobranza para ZURICH SANTANDER',
         1,@Usuario,GETDATE());
    END
    ELSE
        UPDATE dbo.ff_Parametro
           SET paClase='COBRANZA_CACHE',paValor='1',
               paDescripcion='Habilita cache V2 de cobranza para ZURICH SANTANDER',
               paIdEstatus=1,paUsuarioUMod=@Usuario,paFechaUMod=GETDATE(),
               paUsuarioDel=NULL,paFechaDel=NULL
         WHERE paId=@IdParametro AND paIdEmpresa=@IdEmpresa;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT paId,paIdEmpresa,paClase,paValor,paIdEstatus,paDescripcion
FROM dbo.ff_Parametro
WHERE paIdEmpresa=@IdEmpresa
  AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE';

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Parametro
    WHERE paIdEmpresa=@IdEmpresa
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE'
      AND LTRIM(RTRIM(paValor))='1' AND paIdEstatus=1
)
    THROW 52946,'No quedo habilitado COBRANZA_CACHE=1 para la empresa 1807.',1;

