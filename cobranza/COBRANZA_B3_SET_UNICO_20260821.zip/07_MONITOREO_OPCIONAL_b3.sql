/* Seguimiento de una carga B3. Solo lectura. */
SET NOCOUNT ON;
DECLARE @IdEmpresa int=186,@IdVigencia int=4235,@CacheId bigint;

SELECT TOP(1) @CacheId=CacheId
FROM dbo.bf_CobranzaCache_ConsultaV2
WHERE IdEmpresa=@IdEmpresa AND IdVigencia=@IdVigencia
ORDER BY CacheId DESC;

SELECT CacheId,IdEmpresa,IdVigencia,Estado,FechaCargaInicio,FechaCargaFin,
       DATEDIFF(second,FechaCargaInicio,ISNULL(FechaCargaFin,SYSDATETIME())) Segundos,
       FilasConcentrada,FilasDesglosada,Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WHERE CacheId=@CacheId;

SELECT TOP(100) LogId,Fecha,Etapa,Estado,Detalle,SesionId
FROM dbo.bf_CobranzaCache_Log
WHERE CacheId=@CacheId ORDER BY LogId DESC;

;WITH L AS(
 SELECT TOP(100) id,fecha,etapa,detalle,
        LAG(fecha) OVER(ORDER BY id) AS FechaAnterior
 FROM dbo.bf_RepConf_Debug
 WHERE etapa LIKE 'cobranza%' AND
       (detalle LIKE CONCAT('%empresa=',@IdEmpresa,'%')
        OR etapa LIKE 'cobranza_bf3_%set%'
        OR etapa IN('cobranza_obten_inicio','cobranza_obten_post_sinc',
                    'cobranza_obten_post_insert','cobranza_obten_post_desglosada'))
 ORDER BY id DESC)
SELECT id,fecha,etapa,DATEDIFF(millisecond,FechaAnterior,fecha) MilisegundosDesdeAnterior,detalle
FROM L ORDER BY id DESC;

IF HAS_PERMS_BY_NAME(NULL,NULL,'VIEW SERVER STATE')=1
 SELECT R.session_id,R.status,R.command,R.wait_type,R.wait_time,R.cpu_time,
        R.total_elapsed_time,R.logical_reads,R.writes,R.blocking_session_id
 FROM sys.dm_exec_requests AS R WHERE R.database_id=DB_ID();
