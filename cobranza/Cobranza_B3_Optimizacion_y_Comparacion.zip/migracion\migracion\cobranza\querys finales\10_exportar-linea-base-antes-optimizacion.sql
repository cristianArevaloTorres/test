SET NOCOUNT ON;

/*
   Exporta la linea base terminada ANTES de aplicar la optimizacion 08.
   Es de solo lectura: no modifica ni bloquea la carga.

   En SSMS, guardar cada cuadricula como CSV UTF-8 con estos nombres:
     00_resumen_antes.csv
     01_control_antes.csv
     02_concentrada_antes.csv
     03_desglosada_antes.csv
     04_banwire_antes.csv
     05_log_antes.csv

   Ajustar @InicioCarga si la ejecucion que se desea conservar comenzo antes.
*/
DECLARE @IdEmpresa int=186,
        @InicioCarga datetime2(0)='2026-08-21T00:00:00';

CREATE TABLE #CargaBase
(
    IdVigencia int NOT NULL PRIMARY KEY,
    CacheId bigint NOT NULL UNIQUE
);

;WITH UltimaCompleta AS
(
    SELECT Q.CacheId,Q.IdVigencia,Q.FechaCargaFin,
           ROW_NUMBER() OVER
           (
               PARTITION BY Q.IdVigencia
               ORDER BY Q.FechaCargaFin DESC,Q.CacheId DESC
           ) AS rn
    FROM dbo.bf_CobranzaCache_ConsultaV2 Q WITH (NOLOCK)
    WHERE Q.IdEmpresa=@IdEmpresa
      AND Q.EsUniverso=1
      AND Q.Estado='COMPLETA'
      AND Q.FechaCargaInicio>=@InicioCarga
)
INSERT #CargaBase(IdVigencia,CacheId)
SELECT TOP (4) IdVigencia,CacheId
FROM UltimaCompleta
WHERE rn=1
ORDER BY FechaCargaFin DESC,CacheId DESC;

IF (SELECT COUNT(*) FROM #CargaBase)<>4
BEGIN
    SELECT Q.CacheId,Q.IdVigencia,Q.Estado,Q.FechaCargaInicio,Q.FechaCargaFin,
           Q.FilasConcentrada,Q.FilasDesglosada,Q.Mensaje
    FROM dbo.bf_CobranzaCache_ConsultaV2 Q WITH (NOLOCK)
    WHERE Q.IdEmpresa=@IdEmpresa
    ORDER BY Q.CacheId DESC;

    THROW 51900,
        'No se encontraron cuatro vigencias COMPLETAS desde @InicioCarga. Ajuste la fecha antes de exportar.',1;
END;

/* 00_resumen_antes.csv: identifica los CacheId y conteos exactos exportados. */
SELECT B.IdVigencia,B.CacheId,
       Q.FechaCargaInicio,Q.FechaCargaFin,
       DATEDIFF(SECOND,Q.FechaCargaInicio,Q.FechaCargaFin) AS SegundosCarga,
       Q.FilasConcentrada,Q.FilasDesglosada,
       (SELECT COUNT_BIG(*)
        FROM dbo.bf_CobranzaCache_ConcentradaV2 C WITH (NOLOCK)
        WHERE C.CacheId=B.CacheId) AS ConcentradaReal,
       (SELECT COUNT_BIG(*)
        FROM dbo.bf_CobranzaCache_DesglosadaV2 D WITH (NOLOCK)
        WHERE D.CacheId=B.CacheId) AS DesglosadaReal,
       (SELECT COUNT_BIG(*)
        FROM dbo.bf_CobranzaCache_BanwireV2 W WITH (NOLOCK)
        WHERE W.CacheId=B.CacheId) AS BanwireReal,
       Q.PerfilClave,CONVERT(varchar(130),Q.PerfilHash,1) AS PerfilHash,
       Q.FecIni,Q.FecFin,Q.IdVencida,Q.EsTarjeta,Q.EsUniverso,Q.Mensaje
FROM #CargaBase B
JOIN dbo.bf_CobranzaCache_ConsultaV2 Q WITH (NOLOCK)
  ON Q.CacheId=B.CacheId
ORDER BY B.IdVigencia,B.CacheId;

/* 01_control_antes.csv */
SELECT Q.*
FROM #CargaBase B
JOIN dbo.bf_CobranzaCache_ConsultaV2 Q WITH (NOLOCK)
  ON Q.CacheId=B.CacheId
ORDER BY B.IdVigencia,Q.CacheId;

/* 02_concentrada_antes.csv */
SELECT B.IdVigencia AS VigenciaComparacion,C.*
FROM #CargaBase B
JOIN dbo.bf_CobranzaCache_ConcentradaV2 C WITH (NOLOCK)
  ON C.CacheId=B.CacheId
ORDER BY B.IdVigencia,C.Orden;

/* 03_desglosada_antes.csv */
SELECT B.IdVigencia AS VigenciaComparacion,D.*
FROM #CargaBase B
JOIN dbo.bf_CobranzaCache_DesglosadaV2 D WITH (NOLOCK)
  ON D.CacheId=B.CacheId
ORDER BY B.IdVigencia,D.Orden;

/* 04_banwire_antes.csv */
SELECT B.IdVigencia AS VigenciaComparacion,W.*
FROM #CargaBase B
JOIN dbo.bf_CobranzaCache_BanwireV2 W WITH (NOLOCK)
  ON W.CacheId=B.CacheId
ORDER BY B.IdVigencia,W.Orden;

/* 05_log_antes.csv */
SELECT B.IdVigencia AS VigenciaComparacion,L.*
FROM #CargaBase B
JOIN dbo.bf_CobranzaCache_Log L WITH (NOLOCK)
  ON L.CacheId=B.CacheId
ORDER BY B.IdVigencia,L.LogId;
GO
