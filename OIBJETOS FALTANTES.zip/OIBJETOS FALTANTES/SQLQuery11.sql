USE [FlexiForbesv2]
GO

/****** Objeto: Table [dbo].[ff_Empleado] Fecha de script: 18/08/2026 12:51:50 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ff_Empleado](
	[Id] [int] IDENTITY(10000,1) NOT FOR REPLICATION NOT NULL,
	[EMIdEmpresa] [int] NOT NULL,
	[EMIdTitular] [int] NOT NULL,
	[EMIdPerfil] [int] NOT NULL,
	[EMIdParentesco] [int] NOT NULL,
	[EMIdSexo] [int] NOT NULL,
	[EMIdAcceso] [int] NOT NULL,
	[EMIdContacto] [int] NOT NULL,
	[EMIdEstatus] [int] NOT NULL,
	[EMFechaEstatus] [datetime] NOT NULL,
	[EMIdTransferido] [int] NOT NULL,
	[EMNumeroEmpleado] [varchar](20) MASKED WITH (FUNCTION = 'default()') NOT NULL,
	[EMCertificado] [varchar](20) NOT NULL,
	[EMApellidoPaterno] [varchar](30) MASKED WITH (FUNCTION = 'default()') NULL,
	[EMApellidoMaterno] [varchar](30) MASKED WITH (FUNCTION = 'default()') NULL,
	[EMNombre1] [varchar](70) MASKED WITH (FUNCTION = 'default()') NOT NULL,
	[EMNombre2] [varchar](30) MASKED WITH (FUNCTION = 'default()') NULL,
	[EMFechaNacimiento] [datetime] MASKED WITH (FUNCTION = 'default()') NOT NULL,
	[EMEdad] [int] MASKED WITH (FUNCTION = 'default()') NOT NULL,
	[EMFechaIngresoEmpresa] [datetime] NULL,
	[EMFechaBaja] [datetime] NULL,
	[EMFechaAntiguedadGMM] [datetime] NULL,
	[EMAntiguedadGMM] [decimal](5, 2) NOT NULL,
	[EMPuesto] [varchar](100) NULL,
	[EMArea] [int] NULL,
	[EMOficina] [int] NULL,
	[EMrfc] [varchar](20) MASKED WITH (FUNCTION = 'default()') NULL,
	[EMcurp] [varchar](50) MASKED WITH (FUNCTION = 'default()') NULL,
	[EMnss] [varchar](15) MASKED WITH (FUNCTION = 'default()') NULL,
	[EMTipoEmpleado] [varchar](100) NULL,
	[EMIdTipoAsegurado] [int] NOT NULL,
	[EMIdTipoSalario] [int] NOT NULL,
	[EMIdSalarioConfidencial] [int] NOT NULL,
	[EMSalarioBase] [money] MASKED WITH (FUNCTION = 'default()') NOT NULL,
	[EMSalarioIntegrado] [money] MASKED WITH (FUNCTION = 'default()') NOT NULL,
	[EMSalarioBruto] [money] MASKED WITH (FUNCTION = 'default()') NOT NULL,
	[EMSalarioNeto] [money] MASKED WITH (FUNCTION = 'default()') NOT NULL,
	[EMDeduccionesM] [money] NOT NULL,
	[EMDeduccionesP] [decimal](3, 2) NOT NULL,
	[EMPrestacionesM] [money] NOT NULL,
	[EMPrestacionesP] [decimal](3, 2) NOT NULL,
	[EMFondoAhorroM] [money] NOT NULL,
	[EMFondoAhorroP] [decimal](3, 2) NOT NULL,
	[EMFondoAhorroAcumulado] [money] NOT NULL,
	[EMValesM] [money] NOT NULL,
	[EMValesP] [decimal](3, 2) NOT NULL,
	[EMExcedente] [money] NOT NULL,
	[EMBeneficioMaximoM] [money] NOT NULL,
	[EMBeneficioMaximoP] [money] NOT NULL,
	[EMBeneFicioOtorgadoM] [money] NOT NULL,
	[EMBeneFicioOtorgadoP] [decimal](3, 2) NOT NULL,
	[EMTelefono] [varchar](20) MASKED WITH (FUNCTION = 'default()') NULL,
	[EMCorreoElectronico] [varchar](500) MASKED WITH (FUNCTION = 'default()') NULL,
	[EMArchivoInformacion] [varchar](500) NULL,
	[EMClaveAcceso] [varchar](255) NULL,
	[EMObservaciones] [text] NULL,
	[EMUsuarioAdd] [int] NULL,
	[EMFechaAdd] [datetime] NULL,
	[EMUsuarioUMod] [int] NULL,
	[EMFechaUMod] [datetime] NULL,
	[EMUsuarioDel] [int] NULL,
	[EMFechaDel] [datetime] NULL,
	[EMVIP] [int] NOT NULL,
	[EMIdRol] [int] NOT NULL,
	[EMidCentroCostos] [int] NULL,
	[EMNetForbes] [int] NOT NULL,
	[EMTipoDomicilio] [int] NULL,
	[EMCalleFisico] [varchar](200) NULL,
	[EMColoniaFisico] [varchar](100) NULL,
	[EMMunicipioDelegacionFisico] [varchar](50) NULL,
	[EMEstadoFisico] [int] NULL,
	[EMCodigoPostalFisico] [varchar](5) NULL,
	[EMFumador] [int] NULL,
	[EMConsumoAlcohol] [int] NULL,
	[EMDiasVacacionesporGozar] [int] NULL,
	[EMContraseña] [varchar](200) NULL,
	[EMContinua] [bit] NULL,
	[EMCalleFiscal] [varchar](200) NULL,
	[EMColoniaFiscal] [varchar](100) NULL,
	[EMMunicipioDelegacionFiscal] [varchar](50) NULL,
	[EMEstadoFiscal] [int] NULL,
	[EMCodigoPostalFiscal] [varchar](5) NULL,
	[EMCambioPassword] [bit] NULL,
	[EMFechaAcceso] [datetime] NULL,
	[EMBloqueoXSel] [bit] NULL,
	[EMFecBloqueoXSel] [datetime] NULL,
	[EMReseteoPassword] [bit] NULL,
	[Desarrollo] [varchar](40) NULL,
	[EMFechaSincronizacion] [datetime] NULL,
	[EMFechaAsignacionIdADN] [datetime] NULL,
	[EMFechaAlta] [datetime] NULL,
	[EMIdJefe] [int] NOT NULL,
	[EMFechaAntiguedadPP] [datetime] NULL,
	[EMSaldoCuentaEmpleadoPP] [money] NULL,
	[EMSaldoCuentaEmpresaPP] [money] NULL,
	[EMSaldoCuentaExtraordinarioPP] [money] NULL,
	[EMFechaIngresoIMSSPP] [datetime] NULL,
	[EMSaldoAcumuladoAportacionEmpleadoPP] [money] NULL,
	[EMSaldoAcumuladoAportacionCondicionadaPP] [money] NULL,
	[EMSaldoAcumuladoAportacionBasicaPP] [money] NULL,
	[EMSaldoAcumuladoAportacionAdicionalPP] [money] NULL,
	[EMSalarioPP] [money] NULL,
	[EMIdEstadoCivil] [int] NULL,
	[EMSaldoSubCuenta_08_PP] [money] NULL,
	[EMSaldoSubCuenta_09_PP] [money] NULL,
	[EMSaldoSubCuenta_10_PP] [money] NULL,
	[EMIEmpleado] [bit] NULL,
	[EMBDPPensiones] [int] NULL,
	[EMBonoCambio] [int] NULL,
	[EMBFlexible] [int] NULL,
	[EMMatch] [int] NULL,
	[EMEmpleadoI] [int] NULL,
	[EMIAB] [money] NULL,
	[EMEdadRetiro] [int] NOT NULL,
	[EMSalarioIMSS] [money] NOT NULL,
	[EMSueldoAportacion] [money] NOT NULL,
	[EMSueldoPlan] [money] NOT NULL,
	[EMBeneficioJubilacion] [money] NULL,
	[EMidTipoFondo] [int] NULL,
	[EMFechaModPass] [datetime] NULL,
	[EMRegimen] [int] NULL,
	[EMFechaEmision] [datetime] NULL,
	[EMID_BFS] [int] NULL,
	[EMFecha_solicitud_movimiento] [datetime] NULL,
	[EMFecha_ejecucion_movimiento] [datetime] NULL,
 CONSTRAINT [PK_ff_Empleado] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = ON, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMIdA__5629CD9C]  DEFAULT (1) FOR [EMIdAcceso]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMIdC__571DF1D5]  DEFAULT (0) FOR [EMIdContacto]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMIdE__5812160E]  DEFAULT (1) FOR [EMIdEstatus]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMFec__59063A47]  DEFAULT (getdate()) FOR [EMFechaEstatus]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMIdT__59FA5E80]  DEFAULT (0) FOR [EMIdTransferido]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMEda__5AEE82B9]  DEFAULT (0) FOR [EMEdad]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMAnt__5BE2A6F2]  DEFAULT (0) FOR [EMAntiguedadGMM]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMIdT__5CD6CB2B]  DEFAULT (0) FOR [EMIdTipoAsegurado]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMIdTipoSalario]  DEFAULT (0) FOR [EMIdTipoSalario]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMIdS__5DCAEF64]  DEFAULT (0) FOR [EMIdSalarioConfidencial]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMSal__5EBF139D]  DEFAULT (0) FOR [EMSalarioBase]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMSal__5FB337D6]  DEFAULT (0) FOR [EMSalarioIntegrado]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMSal__60A75C0F]  DEFAULT (0) FOR [EMSalarioBruto]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMSal__619B8048]  DEFAULT (0) FOR [EMSalarioNeto]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMDed__628FA481]  DEFAULT (0) FOR [EMDeduccionesM]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMDed__6383C8BA]  DEFAULT (0) FOR [EMDeduccionesP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMPre__6477ECF3]  DEFAULT (0) FOR [EMPrestacionesM]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMPre__656C112C]  DEFAULT (0) FOR [EMPrestacionesP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMFon__66603565]  DEFAULT (0) FOR [EMFondoAhorroM]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMFon__6754599E]  DEFAULT (0.13) FOR [EMFondoAhorroP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMFon__68487DD7]  DEFAULT (0) FOR [EMFondoAhorroAcumulado]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMVal__693CA210]  DEFAULT (0) FOR [EMValesM]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMVal__6A30C649]  DEFAULT (0.1) FOR [EMValesP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMExc__6B24EA82]  DEFAULT (0) FOR [EMExcedente]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMBen__6C190EBB]  DEFAULT (0) FOR [EMBeneficioMaximoM]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMBen__6D0D32F4]  DEFAULT (0.2) FOR [EMBeneficioMaximoP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMBen__6E01572D]  DEFAULT (0) FOR [EMBeneFicioOtorgadoM]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMBen__6EF57B66]  DEFAULT (0) FOR [EMBeneFicioOtorgadoP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMFec__70DDC3D8]  DEFAULT (getdate()) FOR [EMFechaAdd]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMFec__71D1E811]  DEFAULT (getdate()) FOR [EMFechaUMod]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMVIP__72C60C4A]  DEFAULT (0) FOR [EMVIP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMidCentroCostos]  DEFAULT (0) FOR [EMidCentroCostos]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF__ff_Emplea__EMNet__74AE54BC]  DEFAULT (0) FOR [EMNetForbes]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMEstadoFisico]  DEFAULT (0) FOR [EMEstadoFisico]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMEstadoFiscal]  DEFAULT (0) FOR [EMEstadoFiscal]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMCambioPassword]  DEFAULT (0) FOR [EMCambioPassword]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMReseteoPassword]  DEFAULT (0) FOR [EMReseteoPassword]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMIdJefe_1]  DEFAULT (0) FOR [EMIdJefe]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMSaldoCuentaEmpleadoPP]  DEFAULT (0) FOR [EMSaldoCuentaEmpleadoPP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMSaldoCuentaEmpresaPP]  DEFAULT (0) FOR [EMSaldoCuentaEmpresaPP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMSaldoCuentaExtraordinarioPP]  DEFAULT (0) FOR [EMSaldoCuentaExtraordinarioPP]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMIdEstadoCivil]  DEFAULT (0) FOR [EMIdEstadoCivil]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMIEmpleado]  DEFAULT ((0)) FOR [EMIEmpleado]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMBDPPensiones]  DEFAULT ((0)) FOR [EMBDPPensiones]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMMatch]  DEFAULT ((0)) FOR [EMMatch]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMEmpleadoI]  DEFAULT ((0)) FOR [EMEmpleadoI]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  DEFAULT ((0)) FOR [EMEdadRetiro]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  DEFAULT ((0)) FOR [EMSalarioIMSS]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  DEFAULT ((0)) FOR [EMSueldoAportacion]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  DEFAULT ((0)) FOR [EMSueldoPlan]
GO

ALTER TABLE [dbo].[ff_Empleado] ADD  CONSTRAINT [DF_ff_Empleado_EMBeneficioJubilacion]  DEFAULT ((0)) FOR [EMBeneficioJubilacion]
GO

ALTER TABLE [dbo].[ff_Empleado]  WITH NOCHECK ADD  CONSTRAINT [FK_ff_Empresa_ff_empleado] FOREIGN KEY([EMIdEmpresa])
REFERENCES [dbo].[ff_Empresa] ([EMidEmpresa])
GO

ALTER TABLE [dbo].[ff_Empleado] CHECK CONSTRAINT [FK_ff_Empresa_ff_empleado]
GO

ALTER TABLE [dbo].[ff_Empleado]  WITH NOCHECK ADD  CONSTRAINT [FK_ff_Estatus_ff_empleado] FOREIGN KEY([EMIdEstatus])
REFERENCES [dbo].[ff_Estatus] ([ESid])
GO

ALTER TABLE [dbo].[ff_Empleado] CHECK CONSTRAINT [FK_ff_Estatus_ff_empleado]
GO

ALTER TABLE [dbo].[ff_Empleado]  WITH NOCHECK ADD  CONSTRAINT [FK_ff_Parentesco_ff_empleado] FOREIGN KEY([EMIdParentesco])
REFERENCES [dbo].[ff_Parentesco] ([PAidParentesco])
GO

ALTER TABLE [dbo].[ff_Empleado] CHECK CONSTRAINT [FK_ff_Parentesco_ff_empleado]
GO

ALTER TABLE [dbo].[ff_Empleado]  WITH NOCHECK ADD  CONSTRAINT [FK_ff_Perfil_ff_empleado] FOREIGN KEY([EMIdPerfil])
REFERENCES [dbo].[ff_Perfil] ([PEIdPerfil])
GO

ALTER TABLE [dbo].[ff_Empleado] CHECK CONSTRAINT [FK_ff_Perfil_ff_empleado]
GO

ALTER TABLE [dbo].[ff_Empleado]  WITH NOCHECK ADD  CONSTRAINT [FK_ff_Rol_ff_empleado] FOREIGN KEY([EMIdRol])
REFERENCES [dbo].[ff_Rol] ([ROIdRol])
GO

ALTER TABLE [dbo].[ff_Empleado] CHECK CONSTRAINT [FK_ff_Rol_ff_empleado]
GO

ALTER TABLE [dbo].[ff_Empleado]  WITH NOCHECK ADD  CONSTRAINT [FK_ff_Sexo_ff_empleado] FOREIGN KEY([EMIdSexo])
REFERENCES [dbo].[ff_Sexo] ([SEidSexo])
GO

ALTER TABLE [dbo].[ff_Empleado] CHECK CONSTRAINT [FK_ff_Sexo_ff_empleado]
GO

ALTER TABLE [dbo].[ff_Empleado]  WITH NOCHECK ADD  CONSTRAINT [FK_ff_TipoSalario_ff_empleado] FOREIGN KEY([EMIdTipoSalario])
REFERENCES [dbo].[ff_TipoSalario] ([idTipoSalario])
GO

ALTER TABLE [dbo].[ff_Empleado] CHECK CONSTRAINT [FK_ff_TipoSalario_ff_empleado]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Guarda el id del jefe del empleado el valor lo toma de la misma tabla de empleado' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ff_Empleado', @level2type=N'COLUMN',@level2name=N'EMIdJefe'
GO


