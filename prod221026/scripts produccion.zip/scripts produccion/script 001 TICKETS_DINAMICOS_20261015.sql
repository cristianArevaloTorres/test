USE [FlexiForbesv2]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- CAT: TICKETS DINAMICOS; ELIMINA LOS ID DE PLANTILLA FIJOS DEL FRONT.
-- CAT: USA CONFIGURACION Y PLANTILLA DEL MISMO REGISTRO ACTIVO PARA EVITAR CRUCES.
ALTER PROCEDURE [dbo].[bf_ObtenerConfiguracionNotificacionEmpresa]
    @IdEmpresa int,
    @IdTipoNotificacion int,
    @IdEmpleado int
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdCorporativo AS INT;
    DECLARE @IdPlantilla AS INT;
    DECLARE @IdConfiguracionNotificacionEmpresa AS INT;
    DECLARE @NombreEmpresa AS VARCHAR(200);
    DECLARE @EsAdministrador AS BIT;
    DECLARE @IdEmpresaCorporativo AS INT;
    -- CAT: RESPETA LAS CUATRO COLUMNAS QUE DEVUELVE ff_GetCorreosGrupos.
    DECLARE @TblAdminstradores TABLE
    (
        GCCorreoCopia BIT,
        GCCorreoCopiaOculta BIT,
        GCCorreoVisible BIT,
        ADCorreoElectronico VARCHAR(MAX) NULL
    );

    -- CAT: PRIORIZA LA CONFIGURACION PROPIA DE LA EMPRESA.
    SELECT TOP (1)
        @IdPlantilla = CNEIdPlantilla,
        @IdConfiguracionNotificacionEmpresa = CNEId
    FROM dbo.bf_ConfiguracionNotificacionEmpresa
    WHERE CNEIdEstatus = 1
      AND CNEIdTipoNotificacionCorreo = @IdTipoNotificacion
      AND CNEIdEmpresa = @IdEmpresa
    ORDER BY CNEId DESC;

    IF @IdConfiguracionNotificacionEmpresa IS NOT NULL
    BEGIN
        SET @NombreEmpresa = (SELECT EMNombre FROM dbo.ff_empresa WHERE EMIdEmpresa = @IdEmpresa);

        IF EXISTS (SELECT 1 FROM dbo.ff_empleado WHERE Id = @IdEmpleado)
        BEGIN
            SET @EsAdministrador = 0;

            SELECT
                @IdConfiguracionNotificacionEmpresa AS IdConfiguracionNotificacionEmpresa,
                ISNULL(EMApellidoPaterno, '') + ' ' + ISNULL(EMApellidoMaterno, '') + ' '
                    + ISNULL(EMNombre1, '') + ' ' + ISNULL(EMNombre2, '') AS EMNombreCompletoEmpleado,
                @NombreEmpresa AS NombreEmpresa
            FROM dbo.ff_empleado
            WHERE Id = @IdEmpleado;
        END
        ELSE
        BEGIN
            SET @EsAdministrador = 1;

            SELECT
                @IdConfiguracionNotificacionEmpresa AS IdConfiguracionNotificacionEmpresa,
                ISNULL(ADApellidoPaterno, '') + ' ' + ISNULL(ADApellidoMaterno, '') + ' '
                    + ISNULL(ADNombreS, '') AS EMNombreCompletoEmpleado,
                @NombreEmpresa AS NombreEmpresa
            FROM dbo.ff_administrador
            WHERE ADIdAdministrador = @IdEmpleado;
        END;

        IF EXISTS
        (
            SELECT 1
            FROM dbo.ff_empresa
            WHERE EMIdCorporativo = @IdEmpresa
              AND EMIdEstatus = 1
              AND EMIdEmpresa <> EMIdCorporativo
        )
        BEGIN
            DECLARE CursorEmpresas CURSOR LOCAL FAST_FORWARD FOR
                SELECT EMIdEmpresa
                FROM dbo.ff_empresa
                WHERE EMIdCorporativo = @IdEmpresa
                  AND EMIdEstatus = 1
                  AND EMIdEmpresa <> EMIdCorporativo;

            OPEN CursorEmpresas;
            FETCH NEXT FROM CursorEmpresas INTO @IdEmpresaCorporativo;

            WHILE @@FETCH_STATUS = 0
            BEGIN
                INSERT INTO @TblAdminstradores
                (
                    GCCorreoCopia,
                    GCCorreoCopiaOculta,
                    GCCorreoVisible,
                    ADCorreoElectronico
                )
                EXEC dbo.ff_GetCorreosGrupos @IdPlantilla, @IdEmpresaCorporativo;

                FETCH NEXT FROM CursorEmpresas INTO @IdEmpresaCorporativo;
            END;

            CLOSE CursorEmpresas;
            DEALLOCATE CursorEmpresas;

            SELECT DISTINCT * FROM @TblAdminstradores;
        END
        ELSE
        BEGIN
            EXEC dbo.ff_GetCorreosGrupos @IdPlantilla, @IdEmpresa;
        END;

        EXEC dbo.ff_Catalogo_PlantillaCorreo_Leer @IdPlantilla;

        IF
        (
            SELECT CO.CONotificaEmpleados
            FROM dbo.ff_configuracion CO
            INNER JOIN dbo.ff_empresa EM
                ON CO.COIdConfiguracion = EM.EMIdConfiguracion
            WHERE EM.EMIdEmpresa = @IdEmpresa
        ) > 0
        BEGIN
            EXEC dbo.ff_GetCorreoEmpleado @IdEmpleado, @EsAdministrador;
        END;

        RETURN;
    END;

    -- CAT: SI NO HAY CONFIGURACION PROPIA, HEREDA LA ACTIVA DEL CORPORATIVO.
    SET @IdCorporativo =
    (
        SELECT EMIdCorporativo
        FROM dbo.ff_empresa
        WHERE EMIdEmpresa = @IdEmpresa
    );

    SELECT TOP (1)
        @IdPlantilla = CNEIdPlantilla,
        @IdConfiguracionNotificacionEmpresa = CNEId
    FROM dbo.bf_ConfiguracionNotificacionEmpresa
    WHERE CNEIdEstatus = 1
      AND CNEIdTipoNotificacionCorreo = @IdTipoNotificacion
      AND CNEIdEmpresa = @IdCorporativo
    ORDER BY CNEId DESC;

    IF @IdConfiguracionNotificacionEmpresa IS NULL
    BEGIN
        RETURN;
    END;

    SET @NombreEmpresa = (SELECT EMNombre FROM dbo.ff_empresa WHERE EMIdEmpresa = @IdEmpresa);

    IF EXISTS (SELECT 1 FROM dbo.ff_empleado WHERE Id = @IdEmpleado)
    BEGIN
        SET @EsAdministrador = 0;

        SELECT
            @IdConfiguracionNotificacionEmpresa AS IdConfiguracionNotificacionEmpresa,
            ISNULL(EMApellidoPaterno, '') + ' ' + ISNULL(EMApellidoMaterno, '') + ' '
                + ISNULL(EMNombre1, '') + ' ' + ISNULL(EMNombre2, '') AS EMNombreCompletoEmpleado,
            @NombreEmpresa AS NombreEmpresa
        FROM dbo.ff_empleado
        WHERE Id = @IdEmpleado;
    END
    ELSE
    BEGIN
        SET @EsAdministrador = 1;

        SELECT
            @IdConfiguracionNotificacionEmpresa AS IdConfiguracionNotificacionEmpresa,
            ISNULL(ADApellidoPaterno, '') + ' ' + ISNULL(ADApellidoMaterno, '') + ' '
                + ISNULL(ADNombreS, '') AS EMNombreCompletoEmpleado,
            @NombreEmpresa AS NombreEmpresa
        FROM dbo.ff_administrador
        WHERE ADIdAdministrador = @IdEmpleado;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.ff_empresa
        WHERE EMIdCorporativo = @IdEmpresa
          AND EMIdEstatus = 1
          AND EMIdEmpresa <> EMIdCorporativo
    )
    BEGIN
        DECLARE CursorEmpresasCorporativo CURSOR LOCAL FAST_FORWARD FOR
            SELECT EMIdEmpresa
            FROM dbo.ff_empresa
            WHERE EMIdCorporativo = @IdEmpresa
              AND EMIdEstatus = 1
              AND EMIdEmpresa <> EMIdCorporativo;

        OPEN CursorEmpresasCorporativo;
        FETCH NEXT FROM CursorEmpresasCorporativo INTO @IdEmpresaCorporativo;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO @TblAdminstradores
            (
                GCCorreoCopia,
                GCCorreoCopiaOculta,
                GCCorreoVisible,
                ADCorreoElectronico
            )
            EXEC dbo.ff_GetCorreosGrupos @IdPlantilla, @IdEmpresaCorporativo;

            FETCH NEXT FROM CursorEmpresasCorporativo INTO @IdEmpresaCorporativo;
        END;

        CLOSE CursorEmpresasCorporativo;
        DEALLOCATE CursorEmpresasCorporativo;

        SELECT DISTINCT * FROM @TblAdminstradores;
    END
    ELSE
    BEGIN
        EXEC dbo.ff_GetCorreosGrupos @IdPlantilla, @IdEmpresa;
    END;

    EXEC dbo.ff_Catalogo_PlantillaCorreo_Leer @IdPlantilla;

    IF
    (
        SELECT CO.CONotificaEmpleados
        FROM dbo.ff_configuracion CO
        INNER JOIN dbo.ff_empresa EM
            ON CO.COIdConfiguracion = EM.EMIdConfiguracion
        WHERE EM.EMIdEmpresa = @IdEmpresa
    ) > 0
    BEGIN
        EXEC dbo.ff_GetCorreoEmpleado @IdEmpleado, @EsAdministrador;
    END;
END
GO
