/*
    HU CAP-1037 - Template completo del correo
    Base de datos: Plataforma

    UPDATE directo del HTML utilizado por ENROLAMIENTO_ULTIMO_DIA.
    No copia ni recorta otros templates.

    Diseño incluido:
      - Logo Bankaool.
      - Ilustración de calendario/reloj.
      - Contenido del correo actual.
      - Banner de ayuda.
      - Bloque gris en HTML con "¡Gracias por elegir Bankaool!".
      - Footer negro institucional con redes sociales, descargas y texto legal.
*/
USE [Plataforma];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Template NVARCHAR(MAX) = N'<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="color-scheme" content="light" />
  <title>Tu código de confirmación expiró</title>
</head>
<body bgcolor="#EBEBEB" style="margin:0;padding:0;background-color:#EBEBEB;font-family:Poppins,Arial,sans-serif;color:#141415;">
  <table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#EBEBEB" style="width:100%;background-color:#EBEBEB;border-collapse:collapse;">
    <tr>
      <td align="center" style="padding:32px 12px;">
        <table role="presentation" width="600" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="width:100%;max-width:600px;background-color:#FFFFFF;border-collapse:separate;border-spacing:0;border-radius:24px;overflow:hidden;">
          <tr>
            <td align="center" width="600" style="padding:0;">
              <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Web/bankaool_logo.png"
                   alt="Bankaool"
                   width="600"
                   style="display:block;width:100%;max-width:600px;height:auto;border:0;" />
            </td>
          </tr>
          <tr>
            <td align="center" style="padding:24px 24px;">
              <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/PlantillasCorreo/Deadline.png"
                   alt="Código de confirmación expirado"
                   width="250"
                   style="display:block;width:250px;max-width:100%;height:auto;border:0;" />
            </td>
          </tr>
          <tr>
            <td style="padding:0 64px;">
              <div style="height:2px;background-color:#141415;font-size:0;line-height:2px;">&nbsp;</div>
            </td>
          </tr>
          <tr>
            <td style="padding:32px 64px 24px 64px;font-size:24px;font-weight:700;line-height:36px;color:#141415;">
              Tu código de confirmación expiró &#128084;
            </td>
          </tr>
          <tr>
            <td style="padding:0 64px 32px 64px;font-size:18px;font-weight:400;line-height:28px;color:#141415;">
              Hola, <strong>[Nombre]</strong>
            </td>
          </tr>
          <tr>
            <td style="padding:0 64px 24px 64px;font-size:18px;font-weight:400;line-height:28px;color:#141415;">
              Esto significa que necesitas reactivar el código de confirmación para completar el registro.
              Contacta a tu área interna responsable y solicítale que genere un nuevo código.
            </td>
          </tr>
          <tr>
            <td style="padding:0 64px 24px 64px;font-size:18px;font-weight:400;line-height:28px;color:#141415;">
              De esta manera podrás continuar con tu registro y activar tu cuenta para comenzar a recibir tu nómina.
            </td>
          </tr>
          <tr>
            <td align="center" style="padding:0 32px 24px 32px;">
              <a href="https://api.whatsapp.com/send?phone=526391349059" style="display:inline-block;text-decoration:none;">
                <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Nomina Masiva/CTA_Banner.png"
                     alt="¿Necesitas ayuda? Contacto Bankaool"
                     width="472"
                     style="display:block;width:100%;max-width:472px;height:auto;border:0;" />
              </a>
            </td>
          </tr>
          <tr>
            <td align="center" width="600" bgcolor="#F5F5F5" style="padding:42px 32px;background-color:#F5F5F5;">
              <div style="font-size:25px;font-weight:700;line-height:34px;color:#1E1E23;">
                ¡Gracias por elegir Bankaool!
              </div>
              <div style="padding-top:8px;font-size:17px;font-weight:400;line-height:25px;color:#1E1E23;">
                Tu banco simple, transparente y digital.
              </div>
            </td>
          </tr>
          <tr class="footer" bgcolor="#1E1E23" style="background-color:#1E1E23;">
            <td style="padding:42px 64px;background-color:#1E1E23;color:#FFFFFF;">
              <table role="presentation" width="100%" border="0" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;color:#FFFFFF;">
                <tr>
                  <td valign="middle">
                    <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Web/bankaool_logo_white.png"
                         alt="Bankaool"
                         width="92"
                         style="display:block;width:92px;height:auto;border:0;" />
                  </td>
                  <td align="right" valign="middle" style="text-align:right;white-space:nowrap;color:#FFFFFF;">
                    <a href="https://www.instagram.com/bankaoolmex" style="display:inline-block;margin-left:8px;text-decoration:none;">
                      <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Nomina%20Masiva/Instagram.png" alt="Instagram" style="display:inline-block;border:0;" />
                    </a>
                    <a href="https://x.com/BankaoolMex" style="display:inline-block;margin-left:8px;text-decoration:none;">
                      <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Nomina%20Masiva/X.png" alt="X" style="display:inline-block;border:0;" />
                    </a>
                    <a href="https://www.facebook.com/bankaoolmex" style="display:inline-block;margin-left:8px;text-decoration:none;">
                      <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Nomina%20Masiva/Facebook.png" alt="Facebook" style="display:inline-block;border:0;" />
                    </a>
                    <a href="https://www.youtube.com/@bankaoolmex" style="display:inline-block;margin-left:8px;text-decoration:none;">
                      <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Nomina%20Masiva/Youtube.png" alt="YouTube" style="display:inline-block;border:0;" />
                    </a>
                    <a href="https://mx.linkedin.com/company/bankaoolmex" style="display:inline-block;margin-left:8px;text-decoration:none;">
                      <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Nomina%20Masiva/LinkedIn.png" alt="LinkedIn" style="display:inline-block;border:0;" />
                    </a>
                    <a href="https://www.tiktok.com/@bankaoolmex" style="display:inline-block;margin-left:8px;text-decoration:none;">
                      <img src="https://bankaool-stream-app.bankaool.com/bankaool-stream-app/templates/Nomina%20Masiva/TikTok.png" alt="TikTok" style="display:inline-block;border:0;" />
                    </a>
                  </td>
                </tr>
                <tr>
                  <td colspan="2" style="padding:20px 0 14px;">
                    <div style="height:1px;background-color:#ADADAD;font-size:0;line-height:1px;">&nbsp;</div>
                  </td>
                </tr>
                <tr>
                  <td colspan="2" style="font-size:18px;font-weight:400;line-height:28px;color:#FFFFFF;">
                    Descarga Bankaool para:
                    <a href="https://apps.apple.com/mx/app/bankaool-m%C3%B3vil/id1599762504?see-all=reviews" style="color:#FFFFFF;text-decoration:none;font-weight:700;">iPhone</a>
                    &nbsp;|&nbsp;
                    <a href="https://play.google.com/store/apps/details?id=mx.bankaool.movil.app" style="color:#FFFFFF;text-decoration:none;font-weight:700;">Android</a>
                  </td>
                </tr>
                <tr>
                  <td colspan="2" style="padding:14px 0 20px;">
                    <div style="height:1px;background-color:#ADADAD;font-size:0;line-height:1px;">&nbsp;</div>
                  </td>
                </tr>
                <tr>
                  <td colspan="2" style="font-size:14px;font-weight:400;line-height:18px;color:#ADADAD;text-align:justify;">
                    Para dudas respecto al proceso, <span style="color:#EBEBEB;">puedes marcar al 800 832 44 11 o acude a tu sucursal m&aacute;s cercana.</span>
                    Bankaool S. A. Instituci&oacute;n de Banca M&uacute;ltiple recibe las consultas o reclamaciones, en su Unidad Especializada de Atenci&oacute;n a Usuarios, ubicada en Ave. Del Parque Oriente No. 1035, Col. Centro C.P. 33000, Cd. Delicias, Chih., y por correo electr&oacute;nico
                    <a href="mailto:une@bankaool.com" style="color:#ADADAD;text-decoration:none;">une@bankaool.com</a>
                    o a los tel&eacute;fonos (614) 214-42-12 y (614) 214-42-00 ext. 3012. En el caso de no obtener una respuesta satisfactoria, podr&aacute; acudir a la Comisi&oacute;n Nacional para la Protecci&oacute;n de los Usuarios de Servicios Financieros,
                    <a href="https://www.condusef.gob.mx/" style="color:#ADADAD;text-decoration:none;">www.condusef.gob.mx</a>, al tel&eacute;fono (55) 5340-0999 o al correo asesoria@condusef.gob.mx.
                  </td>
                </tr>
                <tr>
                  <td colspan="2" style="padding-top:56px;font-size:10px;font-weight:400;line-height:16px;color:#FFFFFF;">
                    <a href="https://www.bankaool.com/aviso-de-privacidad" style="color:#FFFFFF;text-decoration:none;">Aviso de privacidad</a>
                    &nbsp;|&nbsp;
                    <a href="https://www.bankaool.com/terminos-condiciones-digitales" style="color:#FFFFFF;text-decoration:none;">T&eacute;rminos y Condiciones Digitales</a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>';

BEGIN TRANSACTION;

/*
    CAT: Actualización completa del template consumido por el worker.
    El saludo conserva [Nombre] para que el código coloque primer nombre
    y primer apellido del nominatario.
*/
UPDATE dbo.tb_TemplatesEmail
SET Descripcion = N'Aviso último día de enrolamiento',
    Estatus = 'Pendiente',
    Proceso = 'Enrolamiento',
    Template = @Template,
    FechaActualizacion = GETDATE()
WHERE CodigoTemplate = 'ENROLAMIENTO_ULTIMO_DIA';

IF @@ROWCOUNT = 0
BEGIN
    ROLLBACK TRANSACTION;
    THROW 50022, 'No existe ENROLAMIENTO_ULTIMO_DIA en dbo.tb_TemplatesEmail.', 1;
END;

COMMIT TRANSACTION;

/*
    Validación esperada:
      TieneFooterNegro = 1
      TieneIlustracion = 1
      TieneBannerAyuda = 1
      TieneBannerGracias = 0
      TieneTextoGracias = 1
      TieneRedesSociales = 1
      TieneTextoLegal = 1
*/
SELECT
    IdTemplate,
    CodigoTemplate,
    FechaActualizacion,
    LEN(Template) AS LongitudTemplate,
    CASE
        WHEN CHARINDEX('bankaool_logo_white.png', Template) = 0
         AND CHARINDEX('<tr class="footer"', Template) = 0
        THEN 0 ELSE 1
    END AS TieneFooterNegro,
    CASE WHEN CHARINDEX('PlantillasCorreo/Deadline.png', Template) > 0 THEN 1 ELSE 0 END AS TieneIlustracion,
    CASE WHEN CHARINDEX('CTA_Banner.png', Template) > 0 THEN 1 ELSE 0 END AS TieneBannerAyuda,
    CASE WHEN CHARINDEX('banner-mail.png', Template) > 0 THEN 1 ELSE 0 END AS TieneBannerGracias,
    CASE WHEN CHARINDEX('¡Gracias por elegir Bankaool!', Template) > 0 THEN 1 ELSE 0 END AS TieneTextoGracias,
    CASE WHEN CHARINDEX('Instagram.png', Template) > 0
           AND CHARINDEX('TikTok.png', Template) > 0 THEN 1 ELSE 0 END AS TieneRedesSociales,
    CASE WHEN CHARINDEX('www.condusef.gob.mx', Template) > 0
           AND CHARINDEX('T&eacute;rminos y Condiciones Digitales', Template) > 0 THEN 1 ELSE 0 END AS TieneTextoLegal
FROM dbo.tb_TemplatesEmail
WHERE CodigoTemplate = 'ENROLAMIENTO_ULTIMO_DIA';
GO

