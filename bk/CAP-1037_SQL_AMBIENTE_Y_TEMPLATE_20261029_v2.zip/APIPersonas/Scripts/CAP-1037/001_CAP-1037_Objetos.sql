/*
    HU CAP-1037 - Aviso de último día de vigencia del enrolamiento
    Integración CAP-1072 - Fecha única de vencimiento
    Base de datos: Plataforma

    CAP-1072: Este script agrega y completa FechaVencimiento, además de crear los
    objetos de control y consulta del aviso. No cambia automáticamente Estatus.
*/
USE [Plataforma];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/*
    CAP-1072: Criterios 1 y 2. FechaVencimiento almacena la referencia única
    para la vigencia de la solicitud. Permanece NULL durante un alta incompleta.
*/
IF COL_LENGTH(N'dbo.tb_NominasMasivas_Control', N'FechaVencimiento') IS NULL
BEGIN
    ALTER TABLE dbo.tb_NominasMasivas_Control
        ADD FechaVencimiento DATETIME2(0) NULL;
END;
GO

/*
    CAP-1072: Migración de solicitudes existentes. FechaIngreso es la única fecha
    histórica disponible para obtener la vigencia inicial. La fecha de alta es
    el día 1; por ello, sumar 30 días y restar un segundo produce las 23:59:59
    del día 30. Las nuevas altas serán registradas directamente por APIPersonas.
*/
UPDATE dbo.tb_NominasMasivas_Control
SET FechaVencimiento = DATEADD(
        SECOND,
        -1,
        DATEADD(DAY, 30, CONVERT(DATETIME2(0), CONVERT(DATE, FechaIngreso))))
WHERE FechaVencimiento IS NULL
  AND FechaIngreso IS NOT NULL;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.tb_NominasMasivas_Control')
      AND name = N'IX_tb_NominasMasivas_Control_FechaVencimiento_Estatus'
)
BEGIN
    CREATE INDEX IX_tb_NominasMasivas_Control_FechaVencimiento_Estatus
        ON dbo.tb_NominasMasivas_Control (FechaVencimiento, Estatus)
        INCLUDE (Identificador);
END;
GO

/*
    CAP-1072: Criterio 2. Se conserva @diasTranscurridos únicamente por
    compatibilidad con consumidores existentes, pero el tiempo restante de los
    recordatorios se obtiene exclusivamente de FechaVencimiento.
*/
CREATE OR ALTER PROCEDURE dbo.nm_enrolamiento_ObtenerXEstatus
    @Estatus VARCHAR(25),
    @diasTranscurridos INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        C.Id,
        C.Identificador,
        C.IdNomina,
        C.Cod_Solicitante,
        C.Cod_SisSaf,
        C.NUM_CUENTA,
        C.Primer_Nombre,
        C.Segundo_Nombre,
        C.Primer_Apellido,
        C.Segundo_Apellido,
        C.Correo,
        C.Telefono,
        C.Estatus,
        C.FechaIngreso,
        C.FechaUltimaModificacion,
        C.FechaVencimiento,
        C.Curp,
        C.Comentario,
        CASE
            WHEN C.FechaVencimiento IS NULL THEN NULL
            WHEN C.FechaVencimiento <= SYSDATETIME() THEN N'0 días, 0 horas'
            ELSE CONCAT(
                DATEDIFF(MINUTE, SYSDATETIME(), C.FechaVencimiento) / 1440,
                N' días, ',
                (DATEDIFF(MINUTE, SYSDATETIME(), C.FechaVencimiento) % 1440) / 60,
                N' horas')
        END AS TiempoRestante
    FROM dbo.tb_NominasMasivas_Control AS C
    WHERE UPPER(LTRIM(RTRIM(C.Estatus))) IN ('PENDIENTE', 'EN PROCESO');
END;
GO

IF OBJECT_ID(N'dbo.tb_NominasMasivas_Notificaciones', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.tb_NominasMasivas_Notificaciones
    (
        IdNotificacion       BIGINT IDENTITY(1,1) NOT NULL,
        Identificador        VARCHAR(25) NOT NULL,
        TipoNotificacion     VARCHAR(50) NOT NULL,
        EstatusEnvio         VARCHAR(15) NOT NULL,
        Intentos             INT NOT NULL
            CONSTRAINT DF_tb_NominasMasivas_Notificaciones_Intentos DEFAULT (1),
        FechaReserva         DATETIME2(0) NOT NULL
            CONSTRAINT DF_tb_NominasMasivas_Notificaciones_FechaReserva DEFAULT (SYSDATETIME()),
        FechaEnvio           DATETIME2(0) NULL,
        UltimoError          NVARCHAR(1000) NULL,
        CONSTRAINT PK_tb_NominasMasivas_Notificaciones
            PRIMARY KEY CLUSTERED (IdNotificacion),
        CONSTRAINT UQ_tb_NominasMasivas_Notificaciones_SolicitudTipo
            UNIQUE (Identificador, TipoNotificacion),
        CONSTRAINT CK_tb_NominasMasivas_Notificaciones_EstatusEnvio
            CHECK (EstatusEnvio IN ('PROCESANDO', 'ENVIADO', 'ERROR'))
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.nm_enrolamiento_ObtenerAvisoUltimoDia
    @FechaProceso DATE,
    @DiasVigencia INT = NULL -- Compatibilidad temporal; CAP-1072 ya no lo utiliza.
AS
BEGIN
    SET NOCOUNT ON;

    /*
        CAT: Criterios de elegibilidad.
        - Sólo solicitudes Pendiente.
        - Sólo solicitudes cuyo último día de vigencia es @FechaProceso.
        - Excluye avisos reservados o enviados para impedir duplicados.

        CAP-1072: Criterio 2. FechaVencimiento es la única referencia para
        seleccionar el último día; no se recalcula desde FechaIngreso.
    */
    SELECT
        C.Id,
        C.Identificador,
        C.IdNomina,
        C.Cod_Solicitante,
        C.Cod_SisSaf,
        C.NUM_CUENTA,
        C.Primer_Nombre,
        C.Segundo_Nombre,
        C.Primer_Apellido,
        C.Segundo_Apellido,
        C.Correo,
        C.Telefono,
        C.Estatus,
        C.FechaIngreso,
        C.FechaUltimaModificacion,
        C.FechaVencimiento,
        C.Curp,
        C.Comentario,
        CAST('Hasta las 23:59 horas de hoy' AS VARCHAR(30)) AS TiempoRestante
    FROM dbo.tb_NominasMasivas_Control AS C
    WHERE UPPER(LTRIM(RTRIM(C.Estatus))) = 'PENDIENTE'
      AND C.FechaVencimiento >= CONVERT(DATETIME2(0), @FechaProceso)
      AND C.FechaVencimiento < DATEADD(DAY, 1, CONVERT(DATETIME2(0), @FechaProceso))
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.tb_NominasMasivas_Notificaciones AS N
          WHERE N.Identificador = C.Identificador
            AND N.TipoNotificacion = 'ENROLAMIENTO_ULTIMO_DIA'
            AND N.EstatusEnvio IN ('PROCESANDO', 'ENVIADO')
      );
END;
GO

CREATE OR ALTER PROCEDURE dbo.nm_enrolamiento_ReservarAvisoUltimoDia
    @Identificador VARCHAR(25),
    @FechaProceso DATE,
    @DiasVigencia INT = NULL, -- Compatibilidad temporal; CAP-1072 ya no lo utiliza.
    @TipoNotificacion VARCHAR(50) = 'ENROLAMIENTO_ULTIMO_DIA'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Reservado BIT = 0;

    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    BEGIN TRANSACTION;

    /*
        CAT: Se vuelve a validar el estatus inmediatamente antes del envío.
        Si dejó de ser Pendiente o ya no corresponde al día 30, no se reserva.

        CAP-1072: Criterio 2. Se vuelve a consultar FechaVencimiento como
        referencia única para que selección y revalidación sean consistentes.
    */
    IF EXISTS
    (
        SELECT 1
        FROM dbo.tb_NominasMasivas_Control WITH (UPDLOCK, HOLDLOCK)
        WHERE Identificador = @Identificador
          AND UPPER(LTRIM(RTRIM(Estatus))) = 'PENDIENTE'
          AND FechaVencimiento >= CONVERT(DATETIME2(0), @FechaProceso)
          AND FechaVencimiento < DATEADD(DAY, 1, CONVERT(DATETIME2(0), @FechaProceso))
    )
    BEGIN
        /* CAT: Un registro ERROR puede reintentarse porque el correo no fue enviado. */
        UPDATE dbo.tb_NominasMasivas_Notificaciones WITH (UPDLOCK, HOLDLOCK)
        SET EstatusEnvio = 'PROCESANDO',
            Intentos = Intentos + 1,
            FechaReserva = SYSDATETIME(),
            FechaEnvio = NULL,
            UltimoError = NULL
        WHERE Identificador = @Identificador
          AND TipoNotificacion = @TipoNotificacion
          AND EstatusEnvio = 'ERROR';

        IF @@ROWCOUNT = 1
        BEGIN
            SET @Reservado = 1;
        END
        ELSE IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.tb_NominasMasivas_Notificaciones WITH (UPDLOCK, HOLDLOCK)
            WHERE Identificador = @Identificador
              AND TipoNotificacion = @TipoNotificacion
        )
        BEGIN
            /*
                CAT: La restricción única más esta reserva serializable garantizan
                un solo aviso aunque el worker se ejecute de forma simultánea o repetida.
            */
            INSERT dbo.tb_NominasMasivas_Notificaciones
                (Identificador, TipoNotificacion, EstatusEnvio, Intentos, FechaReserva)
            VALUES
                (@Identificador, @TipoNotificacion, 'PROCESANDO', 1, SYSDATETIME());

            SET @Reservado = 1;
        END;
    END;

    COMMIT TRANSACTION;

    SELECT @Reservado AS Reservado;
END;
GO

CREATE OR ALTER PROCEDURE dbo.nm_enrolamiento_RegistrarResultadoAvisoUltimoDia
    @Identificador VARCHAR(25),
    @TipoNotificacion VARCHAR(50) = 'ENROLAMIENTO_ULTIMO_DIA',
    @Enviado BIT,
    @Error NVARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    /*
        CAT: Sólo se actualiza la bitácora propia de notificaciones.
        No se altera el estatus ni la vigencia de la solicitud de enrolamiento.
    */
    UPDATE dbo.tb_NominasMasivas_Notificaciones
    SET EstatusEnvio = CASE WHEN @Enviado = 1 THEN 'ENVIADO' ELSE 'ERROR' END,
        FechaEnvio = CASE WHEN @Enviado = 1 THEN SYSDATETIME() ELSE NULL END,
        UltimoError = CASE WHEN @Enviado = 1 THEN NULL ELSE LEFT(@Error, 1000) END
    WHERE Identificador = @Identificador
      AND TipoNotificacion = @TipoNotificacion
      AND EstatusEnvio = 'PROCESANDO';
END;
GO

PRINT 'CAP-1037/CAP-1072: FechaVencimiento y objetos de control instalados correctamente en Plataforma.';
GO
