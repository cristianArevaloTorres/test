namespace MonitorEnrolamientoService
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IConfiguration _configuration;
        private readonly IBRMonitor _brMonitor;

        public Worker(
            ILogger<Worker> logger,
            IConfiguration configuration,
            IBRMonitor brMonitor)
        {
            _logger = logger;
            _configuration = configuration;
            _brMonitor = brMonitor;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            int targetHour = _configuration.GetValue<int>("ConfiguracionEmail:targetHour");
            int targetMinutes = _configuration.GetValue<int>("ConfiguracionEmail:targetMinutes");
            TimeSpan horarioEjecucion = new(targetHour, targetMinutes, 0);
            ValidarHorario(horarioEjecucion, nameof(horarioEjecucion));

            /*
                CAT - MODO DE PRUEBA LOCAL TEMPORAL:
                EjecutarAlIniciar permite probar el mismo flujo productivo sin esperar
                a las 09:00. CorreoDestinoPrueba es obligatorio para impedir que una
                prueba envíe avisos a los destinatarios reales.

                Retirar este bloque y sus dos configuraciones antes de QA/producción.
            */
            if (_configuration.GetValue<bool>("ConfiguracionEmail:EjecutarAlIniciar"))
            {
                string? correoDestinoPrueba =
                    _configuration.GetValue<string>("ConfiguracionEmail:CorreoDestinoPrueba");

                if (string.IsNullOrWhiteSpace(correoDestinoPrueba))
                {
                    throw new InvalidOperationException(
                        "Configura ConfiguracionEmail:CorreoDestinoPrueba antes de iniciar el modo de prueba.");
                }

                _logger.LogWarning(
                    "MODO DE PRUEBA ACTIVO: el proceso se ejecutará inmediatamente y redirigirá los avisos a {correo}.",
                    correoDestinoPrueba);

                bool resultadoInicial = await _brMonitor.ProcesarAvisosUltimoDiaAsync(stoppingToken);
                _logger.LogInformation(
                    "Ejecución inmediata de prueba finalizada. Resultado: {resultado}",
                    resultadoInicial);
            }

            while (!stoppingToken.IsCancellationRequested)
            {
                DateTime ahora = ObtenerHoraLocal();

                // CAT: Criterio "Momento de envío". El proceso se agenda diariamente a las 09:00,
                // sin limitarse a un día de la semana, porque cada fecha puede contener solicitudes en su día 30.
                DateTime proximaEjecucion = ObtenerProximaEjecucion(ahora, horarioEjecucion);
                TimeSpan espera = proximaEjecucion - ahora;

                _logger.LogInformation(
                    "Próxima ejecución de avisos de último día: {fechaHora} | Falta: {espera}",
                    proximaEjecucion,
                    espera);

                try
                {
                    await Task.Delay(espera, stoppingToken);

                    // CAT: La ejecución funcional no depende del nivel de logging configurado.
                    bool resultado = await _brMonitor.ProcesarAvisosUltimoDiaAsync(stoppingToken);
                    _logger.LogInformation(
                        "Proceso de avisos de último día finalizado. Resultado: {resultado}",
                        resultado);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    // Una falla diaria no debe terminar el servicio; el siguiente ciclo vuelve a programarse.
                    _logger.LogError(ex, "Error no controlado al ejecutar los avisos de último día.");
                }
            }
        }

        internal static DateTime ObtenerProximaEjecucion(DateTime ahora, TimeSpan horarioEjecucion)
        {
            DateTime ejecucionHoy = ahora.Date.Add(horarioEjecucion);
            return ahora < ejecucionHoy ? ejecucionHoy : ejecucionHoy.AddDays(1);
        }

        private DateTime ObtenerHoraLocal()
        {
            string zonaHorariaId = _configuration.GetValue<string>("ConfiguracionEmail:ZonaHoraria")
                ?? "Central Standard Time (Mexico)";

            try
            {
                TimeZoneInfo zonaHoraria = TimeZoneInfo.FindSystemTimeZoneById(zonaHorariaId);
                return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, zonaHoraria);
            }
            catch (TimeZoneNotFoundException ex)
            {
                _logger.LogWarning(ex, "No se encontró la zona horaria {zonaHoraria}; se utilizará la hora local del servidor.", zonaHorariaId);
                return DateTime.Now;
            }
            catch (InvalidTimeZoneException ex)
            {
                _logger.LogWarning(ex, "La zona horaria {zonaHoraria} no es válida; se utilizará la hora local del servidor.", zonaHorariaId);
                return DateTime.Now;
            }
        }

        private static void ValidarHorario(TimeSpan horario, string nombre)
        {
            if (horario < TimeSpan.Zero || horario >= TimeSpan.FromDays(1))
            {
                throw new ArgumentOutOfRangeException(nombre, "El horario configurado no es válido.");
            }
        }
    }
}
