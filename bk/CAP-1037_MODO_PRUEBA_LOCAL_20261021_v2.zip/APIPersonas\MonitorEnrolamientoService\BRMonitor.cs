using DataAccess;
using EntityModel.Enums;
using EntityModel.Tables.Plataforma;
using System.Net;
using System.Net.Mail;

namespace MonitorEnrolamientoService
{
    public class BRMonitor : IBRMonitor
    {
        private const string AsuntoPredeterminado = "Aún puedes activar tu cuenta de nómina";

        private readonly IConfiguration _configuration;
        private readonly ICProcesoEnrolamiento _cProcesoEnrolamiento;
        private readonly ILogger<BRMonitor> _logger;

        public BRMonitor(
            IConfiguration configuration,
            ICProcesoEnrolamiento cProcesoEnrolamiento,
            ILogger<BRMonitor> logger)
        {
            _configuration = configuration;
            _cProcesoEnrolamiento = cProcesoEnrolamiento;
            _logger = logger;
        }

        public async Task<bool> ProcesarAvisosUltimoDiaAsync(CancellationToken cancellationToken)
        {
            string pathLog = _configuration.GetValue<string>("ConfiguracionEmail:RutaLogs")
                ?? @"C:\Logs\MonitoreoEnrolamientos";
            LogServicio(pathLog, $"{Fecha()} Inicio del proceso de avisos de último día.");

            try
            {
                string connectionString = _configuration.GetConnectionString("PlataformaPlusContext")
                    ?? throw new InvalidOperationException("No está configurada la conexión PlataformaPlusContext.");
                string codigoTemplate = _configuration.GetValue<string>("ConfiguracionEmail:CodigoTemplateUltimoDia")
                    ?? EmailTemplateCode.ENROLAMIENTO_ULTIMO_DIA.ToString();
                string asunto = _configuration.GetValue<string>("ConfiguracionEmail:AsuntoUltimoDia")
                    ?? AsuntoPredeterminado;
                DateTime fechaProceso = ObtenerFechaLocal();

                // CAT: Criterios "día 30" y "estatus Pendiente". La selección usa únicamente
                // solicitudes que se encuentran en el último día y siguen pendientes.
                // CAP-1072: Criterio 2. El SP usa FechaVencimiento como única referencia;
                // el worker ya no reconstruye la vigencia a partir de FechaIngreso.
                IReadOnlyList<tb_NominasMasivas_Control> solicitudes =
                    await _cProcesoEnrolamiento.ObtenerSolicitudesUltimoDiaAsync(
                        connectionString,
                        fechaProceso,
                        cancellationToken);

                tb_TemplatesEmail? template = await _cProcesoEnrolamiento.ObtenerTemplatePorCodigoAsync(
                    connectionString,
                    codigoTemplate,
                    cancellationToken);

                if (string.IsNullOrWhiteSpace(template?.Template))
                {
                    throw new InvalidOperationException($"No se encontró una plantilla activa con código {codigoTemplate}.");
                }

                LogServicio(
                    pathLog,
                    $"{Fecha()} Se obtuvieron {solicitudes.Count} solicitudes elegibles para el aviso de último día.");

                bool procesoExitoso = true;

                foreach (tb_NominasMasivas_Control solicitud in solicitudes)
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    if (string.IsNullOrWhiteSpace(solicitud.Identificador))
                    {
                        procesoExitoso = false;
                        LogServicio(pathLog, $"{Fecha()} Solicitud omitida porque no tiene Identificador.");
                        continue;
                    }

                    // CAT: Criterios "estatus al momento del envío" y "un solo aviso".
                    // La reserva es atómica y el SP vuelve a validar Pendiente + día 30 antes del SMTP.
                    bool reservada = await _cProcesoEnrolamiento.IntentarReservarAvisoUltimoDiaAsync(
                        connectionString,
                        solicitud.Identificador,
                        fechaProceso,
                        cancellationToken);

                    if (!reservada)
                    {
                        LogServicio(
                            pathLog,
                            $"{Fecha()} Solicitud {solicitud.Identificador} omitida: dejó de ser elegible o ya fue notificada.");
                        continue;
                    }

                    try
                    {
                        // CAT: Criterios de contenido, destinatario y ausencia de adjuntos.
                        // Se envía al correo registrado usando la plantilla almacenada en tb_TemplatesEmail.
                        await EnviarCorreoAsync(
                            solicitud,
                            template.Template,
                            asunto,
                            cancellationToken);

                        await _cProcesoEnrolamiento.RegistrarResultadoAvisoUltimoDiaAsync(
                            connectionString,
                            solicitud.Identificador,
                            enviado: true,
                            error: null,
                            cancellationToken);

                        LogServicio(
                            pathLog,
                            $"{Fecha()} Aviso de último día enviado para la solicitud {solicitud.Identificador}.");
                    }
                    catch (Exception ex) when (ex is not OperationCanceledException)
                    {
                        procesoExitoso = false;
                        string mensaje = ObtenerMensajeExcepcion(ex);

                        await _cProcesoEnrolamiento.RegistrarResultadoAvisoUltimoDiaAsync(
                            connectionString,
                            solicitud.Identificador,
                            enviado: false,
                            error: mensaje,
                            cancellationToken);

                        LogServicio(
                            pathLog,
                            $"{Fecha()} Falló el aviso de la solicitud {solicitud.Identificador}: {mensaje}");
                    }
                }

                // CAT: El aviso no actualiza Estatus, FechaIngreso, FechaUltimaModificacion
                // ni FechaVencimiento;
                // el nominatario conserva la vigencia hasta las 23:59 del día 30.
                return procesoExitoso;
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                string mensaje = ObtenerMensajeExcepcion(ex);
                _logger.LogError(ex, "Error general en el proceso de avisos de último día.");
                LogServicio(pathLog, $"{Fecha()} Excepción general al enviar avisos de último día: {mensaje}");
                return false;
            }
        }

        public async Task EnviarCorreoAsync(
            tb_NominasMasivas_Control datos,
            string cuerpo,
            string asunto,
            CancellationToken cancellationToken)
        {
            string usuarioCorreo = ObtenerConfiguracionObligatoria("ConfiguracionEmail:UsuarioCorreo");
            string claveUsuarioCorreo = ObtenerConfiguracionObligatoria("ConfiguracionEmail:ClaveUsuarioCorreo");
            string servidorCorreo = ObtenerConfiguracionObligatoria("ConfiguracionEmail:ServidorCorreo");
            string correoRemitente = ObtenerConfiguracionObligatoria("ConfiguracionEmail:CorreoRemitente");
            int puertoCorreo = _configuration.GetValue<int>("ConfiguracionEmail:PuertoCorreo");
            bool habilitarSsl = _configuration.GetValue<bool>("ConfiguracionEmail:HabilitarSsl");
            bool ejecutarAlIniciar = _configuration.GetValue<bool>("ConfiguracionEmail:EjecutarAlIniciar");
            string? correoDestinoPrueba = _configuration.GetValue<string>("ConfiguracionEmail:CorreoDestinoPrueba");

            string? correoDestino = datos.Correo?.Trim();

            /*
                CAT - MODO DE PRUEBA LOCAL TEMPORAL:
                Al ejecutar inmediatamente, todos los avisos se redirigen a un correo
                controlado. Si no se configuró, se detiene el envío por seguridad.
            */
            if (ejecutarAlIniciar)
            {
                if (string.IsNullOrWhiteSpace(correoDestinoPrueba))
                {
                    throw new InvalidOperationException(
                        "El modo de prueba requiere ConfiguracionEmail:CorreoDestinoPrueba.");
                }

                correoDestino = correoDestinoPrueba.Trim();
                _logger.LogWarning(
                    "MODO DE PRUEBA ACTIVO: el aviso de {identificador} se redirigirá al correo configurado.",
                    datos.Identificador);
            }

            if (string.IsNullOrWhiteSpace(correoDestino))
            {
                throw new InvalidOperationException($"La solicitud {datos.Identificador} no tiene correo registrado.");
            }

            // CAT: Criterio "Saludo". Se muestra exclusivamente primer nombre y primer apellido.
            string nombre = string.Join(
                " ",
                new[] { datos.Primer_Nombre?.Trim(), datos.Primer_Apellido?.Trim() }
                    .Where(valor => !string.IsNullOrWhiteSpace(valor)));

            string body = cuerpo
                .Replace("[Nombre]", WebUtility.HtmlEncode(nombre), StringComparison.Ordinal)
                .Replace("[identificador]", WebUtility.HtmlEncode(datos.Identificador ?? string.Empty), StringComparison.Ordinal)
                .Replace("[TiempoRestante]", "hasta las 23:59 horas de hoy", StringComparison.Ordinal);

            using SmtpClient client = new(servidorCorreo, puertoCorreo)
            {
                EnableSsl = habilitarSsl,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(usuarioCorreo, claveUsuarioCorreo)
            };

            using MailMessage mailMessage = new()
            {
                From = new MailAddress(correoRemitente),
                IsBodyHtml = true,
                Body = body,
                Subject = asunto,
                Priority = MailPriority.High
            };

            // CAT: Criterio "Destinatario". En producción se utiliza el correo del alta;
            // el overlay local lo sustituye únicamente mientras el modo de prueba está activo.
            mailMessage.To.Add(new MailAddress(correoDestino));

            // CAT: Criterio "Documento o guía adjunta: No aplica". No se agregan Attachments.
            await client.SendMailAsync(mailMessage, cancellationToken);
        }

        private DateTime ObtenerFechaLocal()
        {
            string zonaHorariaId = _configuration.GetValue<string>("ConfiguracionEmail:ZonaHoraria")
                ?? "Central Standard Time (Mexico)";

            try
            {
                TimeZoneInfo zonaHoraria = TimeZoneInfo.FindSystemTimeZoneById(zonaHorariaId);
                return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, zonaHoraria).Date;
            }
            catch (TimeZoneNotFoundException)
            {
                return DateTime.Today;
            }
            catch (InvalidTimeZoneException)
            {
                return DateTime.Today;
            }
        }

        private string ObtenerConfiguracionObligatoria(string llave)
        {
            return _configuration.GetValue<string>(llave)
                ?? throw new InvalidOperationException($"No está configurado el valor {llave}.");
        }

        private bool LogServicio(string pathLog, string mensaje)
        {
            try
            {
                Directory.CreateDirectory(pathLog);
                string logName = $"Log_MonitoreoEnrolamientos_{DateTime.Now:yyyyMMdd}.txt";
                File.AppendAllText(Path.Combine(pathLog, logName), mensaje + Environment.NewLine);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "No fue posible escribir el log de monitoreo en {pathLog}.", pathLog);
                return false;
            }
        }

        private static string Fecha() => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

        private static string ObtenerMensajeExcepcion(Exception ex)
        {
            string mensaje = ex.InnerException is null
                ? ex.Message
                : $"{ex.Message}; {ex.InnerException.Message}";

            return mensaje.Length <= 1000 ? mensaje : mensaje[..1000];
        }
    }
}
