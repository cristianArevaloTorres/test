/*
    HU CAP-1037 / CAP-1072 - Preparación opcional de escenarios en DEV
    Base de datos: Plataforma

    IMPORTANTE:
    - No ejecutar en producción.
    - Sustituir los tres identificadores por registros controlados de prueba.
    - @ConfirmarCambios inicia en 0; por seguridad hará ROLLBACK.
    - Cambiar a 1 solamente cuando se quiera conservar la preparación en DEV.
    - Para que el worker en modo prueba encuentre los escenarios, primero se
      debe ejecutar con @ConfirmarCambios = 1.
*/
USE [Plataforma];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdentificadorDia30 VARCHAR(25) = 'COLOCAR_IDENTIFICADOR_1';
DECLARE @IdentificadorDia29 VARCHAR(25) = 'COLOCAR_IDENTIFICADOR_2';
DECLARE @IdentificadorDia31 VARCHAR(25) = 'COLOCAR_IDENTIFICADOR_3';
DECLARE @FechaPrueba DATE = CONVERT(DATE, GETDATE());
DECLARE @ConfirmarCambios BIT = 0;

IF COL_LENGTH(N'dbo.tb_NominasMasivas_Control', N'FechaVencimiento') IS NULL
BEGIN
    THROW 50009, 'Ejecuta primero 001_CAP-1037_Objetos.sql para crear FechaVencimiento.', 1;
END;

IF @IdentificadorDia30 LIKE 'COLOCAR_%'
   OR @IdentificadorDia29 LIKE 'COLOCAR_%'
   OR @IdentificadorDia31 LIKE 'COLOCAR_%'
BEGIN
    THROW 50010, 'Captura tres identificadores controlados de DEV antes de ejecutar el script.', 1;
END;

IF @IdentificadorDia30 = @IdentificadorDia29
   OR @IdentificadorDia30 = @IdentificadorDia31
   OR @IdentificadorDia29 = @IdentificadorDia31
BEGIN
    THROW 50011, 'Los tres identificadores de prueba deben ser diferentes.', 1;
END;

IF
(
    SELECT COUNT(DISTINCT Identificador)
    FROM dbo.tb_NominasMasivas_Control
    WHERE Identificador IN (@IdentificadorDia30, @IdentificadorDia29, @IdentificadorDia31)
) <> 3
BEGIN
    THROW 50012, 'No se encontraron los tres identificadores en tb_NominasMasivas_Control.', 1;
END;

BEGIN TRANSACTION;

/*
    CAP-1072: Escenario elegible hoy. FechaVencimiento termina hoy
    exactamente a las 23:59:59. FechaIngreso no se modifica para demostrar que
    el worker utiliza exclusivamente la fecha oficial de vencimiento.
*/
UPDATE dbo.tb_NominasMasivas_Control
SET Estatus = 'Pendiente',
    FechaVencimiento = DATEADD(
        SECOND,
        -1,
        DATEADD(DAY, 1, CONVERT(DATETIME2(0), @FechaPrueba)))
WHERE Identificador = @IdentificadorDia30;

/* CAP-1072: Escenario elegible mañana; hoy todavía no debe seleccionarse. */
UPDATE dbo.tb_NominasMasivas_Control
SET Estatus = 'Pendiente',
    FechaVencimiento = DATEADD(
        SECOND,
        -1,
        DATEADD(DAY, 2, CONVERT(DATETIME2(0), @FechaPrueba)))
WHERE Identificador = @IdentificadorDia29;

/*
    CAP-1072: Escenario ya vencido por fecha; permanece Pendiente para comprobar que
    CAP-1037 no lo selecciona y que CAP-1072 no cambia automáticamente el estatus.
*/
UPDATE dbo.tb_NominasMasivas_Control
SET Estatus = 'Pendiente',
    FechaVencimiento = DATEADD(
        SECOND,
        -1,
        CONVERT(DATETIME2(0), @FechaPrueba))
WHERE Identificador = @IdentificadorDia31;

/* Permite repetir exclusivamente estas pruebas controladas. */
DELETE dbo.tb_NominasMasivas_Notificaciones
WHERE TipoNotificacion = 'ENROLAMIENTO_ULTIMO_DIA'
  AND Identificador IN (@IdentificadorDia30, @IdentificadorDia29, @IdentificadorDia31);

SELECT
    Identificador,
    Estatus,
    FechaIngreso,
    FechaVencimiento,
    CONVERT(DATE, FechaVencimiento) AS FechaUltimoDia,
    CONVERT(TIME(0), FechaVencimiento) AS HoraVencimiento,
    CASE
        WHEN UPPER(LTRIM(RTRIM(Estatus))) = 'PENDIENTE'
         AND FechaVencimiento >= CONVERT(DATETIME2(0), @FechaPrueba)
         AND FechaVencimiento < DATEADD(DAY, 1, CONVERT(DATETIME2(0), @FechaPrueba))
        THEN 'ELEGIBLE HOY'
        ELSE 'NO ELEGIBLE HOY'
    END AS ResultadoEsperado
FROM dbo.tb_NominasMasivas_Control
WHERE Identificador IN (@IdentificadorDia30, @IdentificadorDia29, @IdentificadorDia31)
ORDER BY Identificador;

IF @ConfirmarCambios = 1
BEGIN
    COMMIT TRANSACTION;
    PRINT 'Escenarios conservados en DEV.';
    PRINT 'Configura CorreoDestinoPrueba e inicia el worker; se procesarán TODAS las solicitudes elegibles de esta BD DEV.';
END
ELSE
BEGIN
    ROLLBACK TRANSACTION;
    PRINT 'Prueba segura finalizada con ROLLBACK. Cambia @ConfirmarCambios a 1 para conservar los escenarios.';
END;
GO
