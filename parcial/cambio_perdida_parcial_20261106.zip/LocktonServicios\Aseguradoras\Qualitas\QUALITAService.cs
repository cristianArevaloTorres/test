﻿using ExcelLibrary.BinaryFileFormat;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.Qualitas;
using LocktonModel.VModels;
using LocktonModel.xmls.AXA;
using LocktonModel.xmls.Qualitas.Solicitud;
using LocktonServicios.Aseguradoras.GNP;
using LocktonServicios.Aseguradoras.Qualitas;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.Catalogos;
using log4net;
using Newtonsoft.Json;
using Opl.qualitas.pagotdc.request;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using static LocktonServicios.DerivacionOpera.DerivaOperaService;
namespace LocktonServicios.Aseguradoras
{
    internal static class QualitasCoberturaMapper
    {
        internal static string ObtenerClaveCoberturaRespuesta(NCoberturas cobertura)
        {
            // CAT perdida parcial ajuste, mapea la respuesta 28|2 con la cobertura 28|15.
            if (cobertura.NoCobertura == "28" && cobertura.TipoSuma == "2")
                return "28|15";

            return string.Concat(cobertura.NoCobertura, "|", cobertura.TipoSuma);
        }
    }

    public class QUALITAService : IOperacionesAseguradoras
    {
        Utilidades.ConexionHttp conexion = new Utilidades.ConexionHttp();
        private static readonly ILog log = LogManager.GetLogger(typeof(QUALITAService));
        ApplicationDbContext db = new ApplicationDbContext();
        static ConsultaCatParametro consultaCatParametro = new ConsultaCatParametro();

        public string CotizaEmite(string xmlEmision)
        {
            try
            {
                using (CotizacionEmisionQualitas.wsEmisionServiceSoapClient cotizaQualitas = new CotizacionEmisionQualitas.wsEmisionServiceSoapClient())
                {
                    cotizaQualitas.Endpoint.Binding = conexion.Conexion(cotizaQualitas.Endpoint.Address.Uri);
                    return cotizaQualitas.obtenerNuevaEmision(xmlEmision);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("yyyy-MM-dd");
                var movimientos = Serialize(xmlEmision);

                movimientos.Movimiento.DatosGenerales.FechaInicio = date;
                movimientos.Movimiento.DatosGenerales.FechaEmision = date;
                xmlEmision = Serialize(movimientos);
                resultado.XMLSolicitud = xmlEmision;

                using (CotizacionEmisionQualitas.wsEmisionServiceSoapClient cotizaQualitas = new CotizacionEmisionQualitas.wsEmisionServiceSoapClient())
                {
                    cotizaQualitas.Endpoint.Binding = conexion.Conexion(cotizaQualitas.Endpoint.Address.Uri);
                    resultado.XMLRecepcion = cotizaQualitas.obtenerNuevaEmision(xmlEmision);
                    return resultado;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string Serialize(NMovimientos movimientos)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(NMovimientos));
            XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
            XmlDocument XmlQualitas = new XmlDocument();
            string resultado;

            xmlWriterSettings.Indent = true;


            using (Utf8StringWriter stringWriter = new Utf8StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
                {
                    xmlSerializer.Serialize(xmlWriter, movimientos);
                }
                resultado = stringWriter.ToString();
            }

            bool produccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;

            if (!produccion)
                resultado = resultado.Replace("<Movimientos xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">", "<Movimientos>");

            XmlQualitas.LoadXml(resultado);
            if (XmlQualitas.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                XmlQualitas.RemoveChild(XmlQualitas.FirstChild);

            return XmlQualitas.InnerXml;
        }

        private NMovimientos Serialize(string xml)
        {
            using (TextReader sr = new StringReader(xml))
            {
                XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(NMovimientos));
                return (NMovimientos)serializer.Deserialize(sr);

            }

        }

        public EstatusOperacion ResultadoFacturacion(int idPoliza)
        {
            var resultado = new EstatusOperacion();
            resultado.Exitoso = true;

            try
            {
                var poliza = db.Poliza.FirstOrDefault(a => a.Id == idPoliza);
                var movimientos = Serialize(poliza.PolizaDetalle.FirstOrDefault().XMLRecepcion);
                var respuestaFacturacion = movimientos.Movimiento.DatosGenerales.ConsideracionesAdicionalesDG.FirstOrDefault(a => a.NoConsideracion == "160");
                if (respuestaFacturacion != null && !string.IsNullOrEmpty(respuestaFacturacion.ValorRegla))
                {
                    var valores = respuestaFacturacion.ValorRegla.Split('|');
                    if (valores[8] == "1")
                    {
                        resultado.Exitoso = false;
                        resultado.Mensaje = valores[9];
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return resultado;
        }

        public string CotizaEmiteCeroEmision(string xmlEmision)
        {
            try
            {
                XmlDocument resp = new XmlDocument();
                resp.LoadXml(xmlEmision);
                if (resp.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                    resp.RemoveChild(resp.FirstChild);

                NMovimientos response;
                using (TextReader sr = new StringReader(resp.InnerXml))
                {
                    XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(NMovimientos));
                    response = (NMovimientos)serializer.Deserialize(sr);
                }

                response.Movimiento.Primas.Comision = "0";
                response.Movimiento.Primas.Derecho = "0";
                response.Movimiento.Primas.Impuesto = "0";
                response.Movimiento.Primas.PrimaNeta = "0";
                response.Movimiento.Primas.PrimaTotal = "0";
                response.Movimiento.Primas.Recargo = "0";

                response.Movimiento.Recibos = new List<NRecibos>();
                var recibo = new NRecibos();
                recibo.Comision = "0";
                recibo.Derecho = "0";
                recibo.FechaInicio = response.Movimiento.DatosGenerales.FechaInicio;
                recibo.FechaTermino = response.Movimiento.DatosGenerales.FechaTermino;
                recibo.Impuesto = "0";
                recibo.NoRecibo = "1";
                recibo.PrimaNeta = "0";
                recibo.PrimaTotal = "0";
                recibo.Recargo = "0";
                response.Movimiento.Recibos.Add(recibo);

                XmlSerializer xmlSerializer = new XmlSerializer(typeof(NMovimientos));
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                XmlDocument XmlQualitas = new XmlDocument();

                string resultado;

                using (Utf8StringWriter stringWriter = new Utf8StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
                    {
                        xmlSerializer.Serialize(xmlWriter, response);
                    }
                    resultado = stringWriter.ToString();
                }

                XmlQualitas.LoadXml(resultado);
                if (XmlQualitas.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                    XmlQualitas.RemoveChild(XmlQualitas.FirstChild);


                return XmlQualitas.InnerXml;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public class Utf8StringWriter : StringWriter
        {
            public override Encoding Encoding
            {
                get
                {
                    return Encoding.UTF8;
                }
            }
        }

        public Coberturas ObtenerTipoDeducubleCobertura(int idCobertura, string deducible, List<PaqueteDetalle> detalles, List<CatTipoDatoDeducible> deducibles)
        {
            var coberturaDeducible = new Coberturas();
            var detalle = detalles.FirstOrDefault(a => a.IdCobertura == idCobertura);

            decimal _d = 0;

            if (decimal.TryParse(deducible, out _d))
            {
                if (_d > 0 && detalle != null && detalle.IdTipoDatoDeducible > 1)
                {
                    var tipoDato = deducibles.FirstOrDefault(a => a.Id == detalle.IdTipoDatoDeducible);


                    coberturaDeducible.IdTipoDatoDeducible = tipoDato.Id;
                    coberturaDeducible.TipoDato = tipoDato.Nombre;
                }
            }

            return coberturaDeducible;


        }

        public Comparar LecturaXMLRespuesta(CotizacionCompara cotizacionCompara, Comparar comparar, string xdoc, List<LocktonModel.db.Cobertura> coberturas, string Aseguradora, int? IdCOnvenio, int idPaqueteConvenio)
        {
            XmlDocument resp = new XmlDocument();
            resp.LoadXml(xdoc);
            if (resp.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                resp.RemoveChild(resp.FirstChild);
            NMovimientos response;
            string nombre = string.Empty;
            string codigo = string.Empty;

            ApplicationDbContext db = new ApplicationDbContext();
            var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
            var paqueteDetalles = db.PaqueteDetalle.Where(a => a.IdPaqueteConvenio == idPaqueteConvenio).ToList();
            var tipoDatosDeducibles = db.CatTipoDatoDeducible.ToList();
            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == IdCOnvenio).FirstOrDefault();
            try
            {
                using (TextReader sr = new StringReader(resp.InnerXml))
                {
                    XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(NMovimientos));
                    response = (NMovimientos)serializer.Deserialize(sr);
                }
            }
            catch (Exception ex)
            {
                log.Info("LecturaXMLRespuesta: Error al deserializar XML - " + ex.Message);
                throw;
            }

            comparar.Coberturas = new List<LocktonModel.VModels.Coberturas>();
            comparar.Aseguradora = Aseguradora;
            comparar.IdPaqueteConvenio = idPaqueteConvenio;
            comparar.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
            comparar.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
            comparar.Cobertura = cotizacionCompara.Cobertura.ToString();
            comparar.IdAseguradora = convenioCotiza.IdAseguradora;
            comparar.IdConvenio = convenioCotiza.Id;

            if (!string.IsNullOrEmpty(response.Movimiento.CodigoError))
            {
                comparar.ErrorXML = response.Movimiento.CodigoError;

                if (comparar.ErrorXML.Contains("0066"))
                    comparar.ErrorXML = "Vehículo de Alta Gama. - El vehículo seleccionado no está autorizado, favor contactar a su ejecutivo";


                return comparar;
            }

            var PrimaTotal = response.Movimiento.Primas.PrimaTotal;
            //var resQualitas = response.Movimiento.Recibos.ToList();
            Tarificador.TarificadorClient tarificador = new Tarificador.TarificadorClient();
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
            var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == cotizacionCompara.FormadePago).FirstOrDefault();
            var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == cotizacionCompara.MediodePago.ToString());
            var resQualitas = response.Movimiento.Recibos.ToList();
            var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);

            comparar.NumeroDePagos = response.Movimiento.Recibos.Count();
            comparar.FormaPagoEtiqueta = perioricidad.Nombre;
            comparar.MedioPagoEtiqueta = mediopago.Nombre;
            comparar.IdMedioPago = mediopago.Id;
            comparar.IdFormaPago = perioricidad.Id;
            comparar.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
            comparar.AltoRiesgo = false;

            if (paqueteConvenio.CoberturaAdicionalAIG)
            {
                comparar.AplicaCoberturaAdicionalAIG = true;

                comparar.DescargaCoberturaAIG = Utilidades.Utilidades.ContieneTipoDocumentoEmpresa(paqueteConvenio.IdConvenio, 2);
            }

            if (perioricidad.Id != 5 && perioricidad.Id != 6 && perioricidad.Id != 7)
            {
                foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
                {
                    var _id = 0;
                    int idCobe = int.Parse(res.NoCobertura);
                    if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                    {
                        _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Id;
                        nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                        codigo = res.NoCobertura;
                    }
                    else if (coberturas.Exists(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)))
                    {
                        _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Id;
                        nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Descripcion.Trim();
                        codigo = QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res);
                    }

                    var _deducible = ObtenerTipoDeducubleCobertura(_id, res.Deducible, paqueteDetalles, tipoDatosDeducibles);

                    comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, IdTipoDatoDeducible = _deducible.IdTipoDatoDeducible, TipoDato = _deducible.TipoDato, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
                }
                comparar.PrimaTotal = response.Movimiento.Primas.PrimaTotal;
                comparar.Comision = response.Movimiento.Primas.Comision;
                comparar.Derecho = response.Movimiento.Primas.Derecho;
                comparar.Impuesto = response.Movimiento.Primas.Impuesto;
                comparar.PrimaNeta = response.Movimiento.Primas.PrimaNeta;
                comparar.Recargo = response.Movimiento.Primas.Recargo;
                comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
                comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);



                if (resQualitas.Count() >= 1)
                    comparar.PrimerPago = (resQualitas[0] ?? new NRecibos()).PrimaTotal;
                if (resQualitas.Count() >= 2)
                    comparar.SegundoPago = (resQualitas[1] ?? new NRecibos()).PrimaTotal;

                //meses sin intereses
                if (perioricidad.Id == 1 && mediopago.Id == 1)
                {

                    Utilidades.Utilidades.AplicaMSICotizacion(convenioCotiza.IdEmpresa, convenioCotiza.Id, ref comparar);

                }
            }
            else
            {
                //if (!convenioCotiza.DerechosPrimerRecibo)
                //{
                var flotilla = (convenioCotiza.IdCatTipoVigencia == 1) ? true : false;
                var rec = tarificador.GetRecibosOnline(Convert.ToInt32(IdCOnvenio), flotilla, perioricidad.Nombre, Convert.ToDouble(PrimaTotal), Convert.ToDateTime(cotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy"))).ToList();
                //var rec = tarificador.
                var MensageError = "";
                if (rec.Any())
                {
                    foreach (var item in rec)
                    {
                        MensageError = item.MensajeError;
                    }
                    if (MensageError == "" || MensageError == null)
                    {
                        var primerRecibo = rec.Find(a => a.Index == 0);
                        if (string.IsNullOrEmpty(primerRecibo.MensajeError))
                        {
                            foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
                            {
                                int idCobe = int.Parse(res.NoCobertura);
                                var _id = 0;

                                if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                                {
                                    _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Id;
                                    nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                                    codigo = res.NoCobertura;
                                }
                                else if (coberturas.Exists(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)))
                                {
                                    _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Id;
                                    nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Descripcion.Trim();
                                    codigo = QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res);
                                }

                                var _deducible = ObtenerTipoDeducubleCobertura(_id, res.Deducible, paqueteDetalles, tipoDatosDeducibles);

                                comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, IdTipoDatoDeducible = _deducible.IdTipoDatoDeducible, TipoDato = _deducible.TipoDato, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
                            }
                            comparar.PrimaTotal = (Math.Round(primerRecibo.PrimaAnualizada * 100) / 100).ToString();
                            comparar.Comision = primerRecibo.Comision.ToString();
                            comparar.Derecho = primerRecibo.DerechoDePolizaTotal.ToString();
                            comparar.Impuesto = primerRecibo.Impuesto.ToString();
                            comparar.PrimaNeta = (Math.Truncate(primerRecibo.PrimaNeta * 100) / 100).ToString();
                            comparar.Recargo = response.Movimiento.Primas.Recargo;
                            comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
                            comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);
                            comparar.IdAseguradora = convenioCotiza.IdAseguradora;
                            comparar.IdConvenio = convenioCotiza.Id;

                            comparar.PrimerPago = (Math.Truncate(primerRecibo.CobroCorte * 100) / 100).ToString();
                            comparar.SegundoPago = rec.Count == 1 ? "" : (Math.Truncate(rec.Find(a => a.Index == 1).CobroCorte * 100) / 100).ToString();

                        }
                    }
                    else
                    {
                        if (MensageError.Contains("El convenio no tiene asignado ningún calendario de tipo de pago"))
                        {


                            foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
                            {
                                int idCobe = int.Parse(res.NoCobertura);
                                var _id = 0;

                                if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                                {
                                    _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Id;
                                    nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                                    codigo = res.NoCobertura;
                                }
                                else if (coberturas.Exists(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)))
                                {
                                    _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Id;
                                    nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Descripcion.Trim();
                                    codigo = QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res);
                                }

                                var _deducible = ObtenerTipoDeducubleCobertura(_id, res.Deducible, paqueteDetalles, tipoDatosDeducibles);

                                comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, IdTipoDatoDeducible = _deducible.IdTipoDatoDeducible, TipoDato = _deducible.TipoDato, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
                            }
                            comparar.PrimaTotal = response.Movimiento.Primas.PrimaTotal;
                            comparar.Comision = response.Movimiento.Primas.Comision;
                            comparar.Derecho = response.Movimiento.Primas.Derecho;
                            comparar.Impuesto = response.Movimiento.Primas.Impuesto;
                            comparar.PrimaNeta = response.Movimiento.Primas.PrimaNeta;
                            comparar.Recargo = response.Movimiento.Primas.Recargo;
                            comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
                            comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);
                            comparar.IdAseguradora = convenioCotiza.IdAseguradora;
                            comparar.IdConvenio = convenioCotiza.Id;

                            if (resQualitas.Count() >= 1)
                                comparar.PrimerPago = (resQualitas[0] ?? new NRecibos()).PrimaTotal;
                            if (resQualitas.Count() >= 2)
                                comparar.SegundoPago = (resQualitas[1] ?? new NRecibos()).PrimaTotal;
                        }
                        else { comparar.ErrorXML = MensageError; }
                    }
                }
                else
                {
                    comparar.ErrorXML = "No se encontró un calendario configurado";
                }
                //}
                //else
                //{
                //    foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
                //    {
                //        int idCobe = int.Parse(res.NoCobertura);
                //        if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                //        {
                //            nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                //            codigo = res.NoCobertura;
                //        }
                //        else if (coberturas.Exists(x => x.Clave.Trim() == string.Concat(res.NoCobertura, "|", res.TipoSuma)))
                //        {
                //            nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == string.Concat(res.NoCobertura, "|", res.TipoSuma)).Descripcion.Trim();
                //            codigo = string.Concat(res.NoCobertura, "|", res.TipoSuma);
                //        }
                //        comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
                //    }
                //    comparar.PrimaTotal = response.Movimiento.Primas.PrimaTotal;
                //    comparar.Comision = response.Movimiento.Primas.Comision;
                //    comparar.Derecho = response.Movimiento.Primas.Derecho;
                //    comparar.Impuesto = response.Movimiento.Primas.Impuesto;
                //    comparar.PrimaNeta = response.Movimiento.Primas.PrimaNeta;
                //    comparar.Recargo = response.Movimiento.Primas.Recargo;
                //    comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
                //    comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);
                //    comparar.IdAseguradora = convenioCotiza.IdAseguradora;
                //    comparar.IdConvenio = convenioCotiza.Id;

                //    if (resQualitas.Count() >= 1)
                //        comparar.PrimerPago = (resQualitas[0] ?? new NRecibos()).PrimaTotal;
                //    if (resQualitas.Count() >= 2)
                //        comparar.SegundoPago = (resQualitas[1] ?? new NRecibos()).PrimaTotal;

                //}
            }
            comparar.PrimaAnualizada = Utilidades.Utilidades.CalculaPrimaAnualizada(DateTime.Parse(comparar.FechaInicio), DateTime.Parse(comparar.FechaFin), comparar.PrimaNeta, comparar.Derecho, comparar.CesionComision);
            return comparar;
        }

        public Comparar LecturaXMLRespuestaCeroComision(CotizacionCompara cotizacionCompara, Comparar comparar, string xdoc, List<LocktonModel.db.Cobertura> coberturas, string Aseguradora, int? IdCOnvenio, int idPaqueteConvenio)
        {
            XmlDocument resp = new XmlDocument();
            resp.LoadXml(xdoc);
            if (resp.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                resp.RemoveChild(resp.FirstChild);
            NMovimientos response;
            string nombre = string.Empty;
            string codigo = string.Empty;

            ApplicationDbContext db = new ApplicationDbContext();

            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == IdCOnvenio).FirstOrDefault();
            try
            {
                using (TextReader sr = new StringReader(resp.InnerXml))
                {
                    XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(NMovimientos));
                    response = (NMovimientos)serializer.Deserialize(sr);
                }
            }
            catch (Exception ex)
            {
                log.Info("LecturaXMLRespuesta: Error al deserializar XML - " + ex.Message);
                throw;
            }

            comparar.Coberturas = new List<LocktonModel.VModels.Coberturas>();
            comparar.Aseguradora = Aseguradora;
            comparar.Cobertura = cotizacionCompara.Cobertura.ToString();

            //var PrimaTotal = response.Movimiento.Primas.PrimaTotal;
            //var resQualitas = response.Movimiento.Recibos.ToList();
            Tarificador.TarificadorClient tarificador = new Tarificador.TarificadorClient();
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();

            var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == cotizacionCompara.FormadePago).FirstOrDefault();
            //var resQualitas = response.Movimiento.Recibos.ToList();

            foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
            {
                int idCobe = int.Parse(res.NoCobertura);
                if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                {
                    nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                    codigo = res.NoCobertura;
                }
                else if (coberturas.Exists(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)))
                {
                    nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Descripcion.Trim();
                    codigo = QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res);
                }
                comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
            }
            comparar.PrimaTotal = "0";
            comparar.Comision = "0";
            comparar.Derecho = "0";
            comparar.Impuesto = "0";
            comparar.PrimaNeta = "0";
            comparar.Recargo = "0";
            comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
            comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);
            comparar.IdAseguradora = convenioCotiza.IdAseguradora;
            comparar.IdConvenio = convenioCotiza.Id;
            comparar.IdPaqueteConvenio = idPaqueteConvenio;
            comparar.PrimerPago = "0";
            return comparar;
        }

        private string CambioFecha(string fecha)
        {
            string anio = string.Empty;
            string mes = string.Empty;
            string dia = string.Empty;

            if (fecha.Contains("-"))
            {
                string[] separaFecha = fecha.Split('-');
                anio = separaFecha[0];
                mes = separaFecha[1];
                dia = separaFecha[2];
            }

            return string.Concat(dia, "/", mes, "/", anio);
        }

        public LocktonModel.VModels.Comparar LeeXMLCotizacion(string xdoc, List<LocktonModel.db.Cobertura> coberturas, int IdEmpresa, CotizacionDetalle CotDetalle)
        {
            LocktonModel.VModels.Comparar comparar = new LocktonModel.VModels.Comparar();

            XmlDocument resp = new XmlDocument();
            resp.LoadXml(xdoc);
            NMovimientos response;

            ApplicationDbContext db = new ApplicationDbContext();

            using (TextReader sr = new StringReader(resp.InnerXml))
            {
                XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(NMovimientos));
                response = (NMovimientos)serializer.Deserialize(sr);
            }

            comparar.Coberturas = new List<LocktonModel.VModels.Coberturas>();
            string nombre = string.Empty;
            string codigo = string.Empty;
            Tarificador.TarificadorClient tarificador = new Tarificador.TarificadorClient();
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == IdEmpresa).FirstOrDefault();
            var convenio = db.Convenio.Where(x => x.Id == CotDetalle.IdConvenio).FirstOrDefault();
            int Periodicidad = Convert.ToInt32(CotDetalle.Cotizacion.IdPeriodicidadPago);
            var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == Periodicidad).FirstOrDefault();
            var rec = response.Movimiento.Recibos.ToList();

            var paqueteDetalles = db.PaqueteDetalle.Where(a => a.IdPaqueteConvenio == CotDetalle.IdPaqueteConvenio).ToList();
            var tipoDatosDeducibles = db.CatTipoDatoDeducible.ToList();


            if (perioricidad.Nombre.Contains("Mensual") || perioricidad.Nombre.Contains("Contado") || perioricidad.Nombre.Contains("Trimestral") || perioricidad.Nombre.Contains("Semestral"))
            {
                foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
                {
                    int idCobe = int.Parse(res.NoCobertura);
                    var _id = 0;

                    if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                    {
                        _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Id;
                        nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                        codigo = res.NoCobertura;
                    }
                    else if (coberturas.Exists(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)))
                    {
                        _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Id;
                        nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Descripcion.Trim();
                        codigo = QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res);
                    }

                    var _deducible = ObtenerTipoDeducubleCobertura(_id, res.Deducible, paqueteDetalles, tipoDatosDeducibles);

                    comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, IdTipoDatoDeducible = _deducible.IdTipoDatoDeducible, TipoDato = _deducible.TipoDato, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
                }
                comparar.Año = response.Movimiento.DatosVehiculo.Modelo;
                comparar.Derecho = response.Movimiento.DatosVehiculo.DescripcionVehiculo;
                comparar.PrimaTotal = response.Movimiento.Primas.PrimaTotal;
                comparar.Comision = response.Movimiento.Primas.Comision;
                comparar.Derecho = response.Movimiento.Primas.Derecho;
                comparar.Impuesto = response.Movimiento.Primas.Impuesto;
                comparar.PrimaNeta = response.Movimiento.Primas.PrimaNeta;
                comparar.Recargo = response.Movimiento.Primas.Recargo;
                comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
                comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);

                comparar.NumeroDePagos = 1;
                if (rec != null)
                    comparar.NumeroDePagos = rec.Count() == 1 ? 1 : rec.Count() - 1;
                if (rec.Count() >= 1)
                    comparar.PrimerPago = (rec[0] ?? new NRecibos()).PrimaTotal;
                if (rec.Count() >= 2)
                    comparar.SegundoPago = (rec[1] ?? new NRecibos()).PrimaTotal;
            }
            else
            {
                //if (!convenio.DerechosPrimerRecibo)
                //{
                var flotilla = (convenio.IdCatTipoVigencia == 1) ? true : false;
                var rest = tarificador.GetRecibosOnline(CotDetalle.IdConvenio, flotilla, perioricidad.Nombre, Convert.ToDouble(response.Movimiento.Primas.PrimaTotal), Convert.ToDateTime(Convert.ToDateTime(response.Movimiento.DatosGenerales.FechaInicio).ToString("dd/MM/yyyy"))).ToList();
                var error = "";
                if (rest.Any())
                {
                    foreach (var item in rest)
                    {
                        error = item.MensajeError;
                    }
                    if (error == "" || error == null)
                    {
                        foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
                        {
                            int idCobe = int.Parse(res.NoCobertura);
                            var _id = 0;
                            if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                            {
                                _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Id;
                                nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                                codigo = res.NoCobertura;
                            }
                            else if (coberturas.Exists(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)))
                            {
                                _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Id;
                                nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Descripcion.Trim();
                                codigo = QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res);
                            }

                            var _deducible = ObtenerTipoDeducubleCobertura(_id, res.Deducible, paqueteDetalles, tipoDatosDeducibles);

                            comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, IdTipoDatoDeducible = _deducible.IdTipoDatoDeducible, TipoDato = _deducible.TipoDato, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
                        }
                        var primerRecibo = rest.Find(a => a.Index == 0);
                        comparar.NumeroDePagos = rest.Where(x => x.Index > 0).Count();
                        comparar.Año = response.Movimiento.DatosVehiculo.Modelo;
                        comparar.Derecho = response.Movimiento.DatosVehiculo.DescripcionVehiculo;
                        comparar.PrimaTotal = (Math.Truncate(primerRecibo.PrimaAnualizada * 100) / 100).ToString();
                        comparar.Comision = primerRecibo.Comision.ToString();
                        comparar.Derecho = primerRecibo.DerechoDePolizaTotal.ToString();
                        comparar.Impuesto = primerRecibo.Impuesto.ToString();
                        comparar.PrimaNeta = (Math.Truncate(primerRecibo.PrimaNeta * 100) / 100).ToString();
                        comparar.Recargo = response.Movimiento.Primas.Recargo;
                        comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
                        comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);
                        comparar.PrimerPago = (Math.Truncate(primerRecibo.CobroCorte * 100) / 100).ToString();
                        comparar.SegundoPago = rest.Count == 1 ? "" : (Math.Truncate(rest.Find(a => a.Index == 1).CobroCorte * 100) / 100).ToString();


                    }
                    else
                    {
                        if (error.Contains("El convenio no tiene asignado ningún calendario de tipo de pago"))
                        {


                            foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
                            {
                                int idCobe = int.Parse(res.NoCobertura);
                                var _id = 0;
                                if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                                {
                                    _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Id;
                                    nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                                    codigo = res.NoCobertura;
                                }
                                else if (coberturas.Exists(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)))
                                {
                                    _id = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Id;
                                    nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res)).Descripcion.Trim();
                                    codigo = QualitasCoberturaMapper.ObtenerClaveCoberturaRespuesta(res);
                                }

                                var _deducible = ObtenerTipoDeducubleCobertura(_id, res.Deducible, paqueteDetalles, tipoDatosDeducibles);

                                comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, IdTipoDatoDeducible = _deducible.IdTipoDatoDeducible, TipoDato = _deducible.TipoDato, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
                            }
                            comparar.Año = response.Movimiento.DatosVehiculo.Modelo;
                            comparar.Derecho = response.Movimiento.DatosVehiculo.DescripcionVehiculo;
                            comparar.PrimaTotal = response.Movimiento.Primas.PrimaTotal;
                            comparar.Comision = response.Movimiento.Primas.Comision;
                            comparar.Derecho = response.Movimiento.Primas.Derecho;
                            comparar.Impuesto = response.Movimiento.Primas.Impuesto;
                            comparar.PrimaNeta = response.Movimiento.Primas.PrimaNeta;
                            comparar.Recargo = response.Movimiento.Primas.Recargo;
                            comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
                            comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);

                            comparar.NumeroDePagos = 1;
                            if (rec != null)
                                comparar.NumeroDePagos = rec.Count() == 1 ? 1 : rec.Count() - 1;
                            if (rec.Count() >= 1)
                                comparar.PrimerPago = (rec[0] ?? new NRecibos()).PrimaTotal;
                            if (rec.Count() >= 2)
                                comparar.SegundoPago = (rec[1] ?? new NRecibos()).PrimaTotal;
                        }
                        else { comparar.ErrorXML = error; }
                    }
                }
                else
                {

                    comparar.ErrorXML = "No se encontró un calendario configurado";
                }
                //}
                //else
                //{
                //    foreach (NCoberturas res in response.Movimiento.DatosVehiculo.Coberturas)
                //    {
                //        int idCobe = int.Parse(res.NoCobertura);
                //        if (coberturas.Exists(x => x.Clave.Trim() == res.NoCobertura))
                //        {
                //            nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == res.NoCobertura).Descripcion.Trim();
                //            codigo = res.NoCobertura;
                //        }
                //        else if (coberturas.Exists(x => x.Clave.Trim() == string.Concat(res.NoCobertura, "|", res.TipoSuma)))
                //        {
                //            nombre = coberturas.FirstOrDefault(x => x.Clave.Trim() == string.Concat(res.NoCobertura, "|", res.TipoSuma)).Descripcion.Trim();
                //            codigo = string.Concat(res.NoCobertura, "|", res.TipoSuma);
                //        }

                //        comparar.Coberturas.Add(new LocktonModel.VModels.Coberturas() { Deducible = res.Deducible, Codigo = codigo, SumaAsegurada = res.SumaAsegurada, Tipo = res.TipoSuma, Cobertura = res.Prima, Nombre = nombre });
                //    }
                //    comparar.Año = response.Movimiento.DatosVehiculo.Modelo;
                //    comparar.Derecho = response.Movimiento.DatosVehiculo.DescripcionVehiculo;
                //    comparar.PrimaTotal = response.Movimiento.Primas.PrimaTotal;
                //    comparar.Comision = response.Movimiento.Primas.Comision;
                //    comparar.Derecho = response.Movimiento.Primas.Derecho;
                //    comparar.Impuesto = response.Movimiento.Primas.Impuesto;
                //    comparar.PrimaNeta = response.Movimiento.Primas.PrimaNeta;
                //    comparar.Recargo = response.Movimiento.Primas.Recargo;
                //    comparar.FechaInicio = CambioFecha(response.Movimiento.DatosGenerales.FechaInicio);
                //    comparar.FechaFin = CambioFecha(response.Movimiento.DatosGenerales.FechaTermino);

                //    comparar.NumeroDePagos = 1;
                //    if (rec != null)
                //        comparar.NumeroDePagos = rec.Count() == 1 ? 1 : rec.Count() - 1;
                //    if (rec.Count() >= 1)
                //        comparar.PrimerPago = (rec[0] ?? new NRecibos()).PrimaTotal;
                //    if (rec.Count() >= 2)
                //        comparar.SegundoPago = (rec[1] ?? new NRecibos()).PrimaTotal;
                //}
            }
            return comparar;
        }

        #region Metodos para cobranza Qualitas
        //public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        //{
        //    return PagoConTarjeta(datosCobranza);
        //}
        /// <summary>
        /// Metodo para poder instalar una poliza emitida con tarjeta credito y debito
        /// </summary>
        /// <param name="datosCobranza">Objeto con todos los elemtos necesarios para el pago con tarjeta</param>
        /// <returns>Mensaje de si fue correcto o no la instalacion a OPL de tarjeta</returns>
        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            EstatusOperacion estatusOperacion = new EstatusOperacion();
            string key = consultaCatParametro.ObtenerCatParametro("key");
            log.Info("key para cobranza encriptación OPL");
            log.Info(string.Format("Comienza proceso de intalacion cobranza TDC para {0}, Numero_Empleado: {1}, poliza: {2}", datosCobranza.NombreCompleto, datosCobranza.NumeroEmpleado, datosCobranza.NumeroPoliza));
            string xmlResultado = "";
            string xmlResultadoLog = "";
            string resultado = "";
            string number = datosCobranza.NumeroTarjeta;
            List<CatalogoErrorInstalacionDatosBancarios> catalogerrors = new List<CatalogoErrorInstalacionDatosBancarios>();
            CatalogoErrorInstalacionDatosBancarios error = new CatalogoErrorInstalacionDatosBancarios();
            string Mensajecom = "";
            try
            {
                PagoTDCQualitasTest.wsCollectionPortClient clienteTest = null;
                PagoTDCQualitasProd.wsCollectionPortClient clienteProd = null;

                bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                if (esProduccion)
                    clienteProd = new PagoTDCQualitasProd.wsCollectionPortClient();
                else
                    clienteTest = new PagoTDCQualitasTest.wsCollectionPortClient();

                oplCollection collection = new oplCollection();
                oplCollectionCollectionCollectionData collectionData = new oplCollectionCollectionCollectionData();
                oplCollectionCollectionInsuranceData insuredData = new oplCollectionCollectionInsuranceData();
                oplCollectionCollectionCodigoErrorError[] codigoErrorError = { };
                oplCollectionCollection oplCollectionCollection = new oplCollectionCollection();

                oplCollectionCollection.NoNegocio = datosCobranza.NumeroNegocio;
                oplCollectionCollection.NoPoliza = datosCobranza.NumeroPoliza;
                oplCollectionCollection.wpuid = consultaCatParametro.ObtenerCatParametro("wpuid");
                oplCollectionCollection.wptoken = consultaCatParametro.ObtenerCatParametro("wptoken");
                if (datosCobranza != null)
                {
                    collectionData.type = datosCobranza.TipoTarjeta;
                    collectionData.userkey = string.IsNullOrEmpty(datosCobranza.NumeroEmpleado) ? datosCobranza.Rfc : datosCobranza.NumeroEmpleado;
                    collectionData.name = datosCobranza.NombreCompleto;
                    collectionData.crypto = consultaCatParametro.ObtenerCatParametro("crypto");
                    switch (collectionData.crypto)
                    {
                        case "1":
                            log.Info("tarjeta para encriptar:" + datosCobranza.NumeroTarjeta);
                            datosCobranza.NumeroTarjeta = Utilidades.Utilidades.StringToHexString(Utilidades.Utilidades.EncryptRC4(key, datosCobranza.NumeroTarjeta));
                            //datosCobranza.ClaveBanco = Utilidades.Utilidades.EncryptRC4(key, datosCobranza.ClaveBanco);
                            if (!string.IsNullOrEmpty(datosCobranza.MesVencimiento))
                                datosCobranza.MesVencimiento = Utilidades.Utilidades.StringToHexString(Utilidades.Utilidades.EncryptRC4(key, datosCobranza.MesVencimiento));
                            if (!string.IsNullOrEmpty(datosCobranza.AnoVencimiento))
                                datosCobranza.AnoVencimiento = Utilidades.Utilidades.StringToHexString(Utilidades.Utilidades.EncryptRC4(key, datosCobranza.AnoVencimiento));
                            if (!string.IsNullOrEmpty(datosCobranza.CodigoSeguridad))
                                datosCobranza.CodigoSeguridad = Utilidades.Utilidades.StringToHexString(Utilidades.Utilidades.EncryptRC4(key, datosCobranza.CodigoSeguridad));
                            break;
                    }
                    collectionData.number = datosCobranza.NumeroTarjeta;
                    collectionData.bankcode = datosCobranza.ClaveBanco;

                    if (number.Length <= 16)
                    {
                        collectionData.expmonth = datosCobranza.MesVencimiento;
                        collectionData.expyear = datosCobranza.AnoVencimiento;
                        collectionData.cvvcsc = datosCobranza.CodigoSeguridad;
                    }
                    else
                    {
                        collectionData.expmonth = "";
                        collectionData.expyear = "";
                        collectionData.cvvcsc = "";
                    }
                    insuredData.PlazoPago = datosCobranza.Periodicidad; //Datos que obtenemos en la configuracion de forma de pago cobranza del convenio.
                    insuredData.akey = datosCobranza.ClaveAgente;
                    insuredData.email = datosCobranza.CorreoElectronico;

                    oplCollectionCollection.collectionData = collectionData;
                    oplCollectionCollection.insuranceData = insuredData;
                    oplCollectionCollection.CodigoError = codigoErrorError;
                    collection.Items = oplCollectionCollection;

                    xmlResultado = ToXMLString(collection);

                    if (collectionData.crypto == "0")
                    {
                        collectionData.number = "**********";
                        collectionData.bankcode = "***";
                        collectionData.expmonth = collectionData.expmonth;//"**";
                        collectionData.expyear = collectionData.expyear;//"****";
                        collectionData.cvvcsc = "***";
                        xmlResultadoLog = ToXMLString(collection);
                    }
                    else { xmlResultadoLog = xmlResultado; }


                    log.Info(string.Format("Inicia llamado OplTDC Intento {0}/{1}. Xml: {2}", 1, datosCobranza.NumeroReintentos, xmlResultadoLog.Replace("\n", "").Replace("\r", "")));

                    if (esProduccion)
                    {
                        resultado = clienteProd.oplCollection(xmlResultado);
                    }
                    else
                    {
                        resultado = clienteTest.oplCollection(xmlResultado);
                    }

                    log.Info(string.Format("Resultado llamado OplTDC Intento {0}/{1}. Xml: {2}", 1, datosCobranza.NumeroReintentos, resultado.Replace("\n", "").Replace("\r", "")));
                    TextReader reader = new StringReader(resultado);

                    XmlSerializer xs = new XmlSerializer(typeof(oplCollection));
                    oplCollection movimientoResult = (oplCollection)xs.Deserialize(reader);
                    oplCollectionCollection = (oplCollectionCollection)movimientoResult.Items;
                    string sms = string.Empty;

                    if (oplCollectionCollection.CodigoError.Count() > 0)
                    {
                        foreach (var item in oplCollectionCollection.CodigoError)
                        {
                            if (item.Error1 != null && item.Error1.Count() > 0)
                            {
                                foreach (var Err in item.Error1)
                                {
                                    sms = Err.Value;
                                    if (sms == null)
                                        sms = "No se detecta error";
                                    Mensajecom += sms;
                                    CatalogoErrorInstalacionDatosBancarios cataerror = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(y => sms.Contains(y.DescripcionError));
                                    if (cataerror != null)
                                        catalogerrors.Add(cataerror);
                                    log.Info(string.Format("Ocurrio un error al pagar la poliza: {0} Error: {1})", datosCobranza.NumeroPoliza, Err.Value));
                                }
                            }
                            else
                            {
                                sms = item.Value;
                                if (sms == null)
                                    sms = "No se detecta error";
                                Mensajecom += sms;
                                CatalogoErrorInstalacionDatosBancarios cataerror = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(y => sms.Contains(y.DescripcionError));
                                if (cataerror != null)
                                    catalogerrors.Add(cataerror);
                                log.Info(string.Format("Ocurrio un error al pagar la poliza: {0} Error: {1})", datosCobranza.NumeroPoliza, item.Value));
                            }
                        }
                        error = catalogerrors.FirstOrDefault();
                        estatusOperacion.Mensaje = catalogerrors != null ? error.MensajeMostrarUsaurio : "Algo salió mal en la instalación de tus datos bancarios, acércate con tu asesor de servicio";
                        estatusOperacion.Exitoso = false;
                        estatusOperacion.MensajeCatalogo += Mensajecom;

                        if (error.EsReintentable)
                            estatusOperacion.EsReintentable = true;

                    }
                    else
                    {
                        estatusOperacion.Exitoso = true;
                        error = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(x => x.DescripcionError.Equals("Exitoso"));
                        log.Info(string.Format("XML PAGOTDC Pago exitoso, intento({0}/{1})", 1, datosCobranza.NumeroReintentos));



                    }
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado pagoTDC Qualitas: " + ex.Message, ex);
                estatusOperacion.Mensaje = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(x => x.DescripcionError.Contains("exepcion") && x.IdAseguradora == 1).MensajeMostrarUsaurio;
                resultado += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                estatusOperacion.Exitoso = false;
                estatusOperacion.EsReintentable = false;
                estatusOperacion.MensajeCatalogo = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                error = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(y => y.DescripcionError.Contains("exepcion") && y.IdAseguradora == 1);
            }

            RegistraOPL(datosCobranza.NumeroPoliza, xmlResultadoLog, resultado, "Pago Con Tarjeta", 1, estatusOperacion.Exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datosCobranza.NumeroPoliza) == true ? "Online" : "Tradicional", error != null ? error.Id : 0);
            log.Info(string.Format("Termina proceso de intalacion a OPL TDC de la poliza: {0}", datosCobranza.NumeroPoliza));
            return estatusOperacion;
        }

        /// <summary>
        /// Metodo para instalar una poliza emitida en el OPL Nomina
        /// </summary>
        /// <param name="datosCobranza">Objeto con todos los elementos necesatios para instalar una poliza a Nomina OPL</param>
        /// <returns> Mensaje de si fue correcto o no la instalacion de la nomina en OPL</returns>
        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            ConsultaCatParametro consultaCatParametro = new ConsultaCatParametro();
            log.Info(string.Format("Comienza proceso de intalacion cobranza DXN para {0}, Numero_Empleado: {1}, poliza: {2}", datosCobranza.NombreCompleto, datosCobranza.NumeroEmpleado, datosCobranza.NumeroPoliza));
            StringBuilder builder = new StringBuilder();
            string xmlResultado = "";
            string resultado = "";
            try
            {
                PagoTDCQualitasTest.wsCollectionPortClient clienteTest = null;
                PagoTDCQualitasProd.wsCollectionPortClient clienteProd = null;

                bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                if (esProduccion)
                    clienteProd = new PagoTDCQualitasProd.wsCollectionPortClient();
                else
                    clienteTest = new PagoTDCQualitasTest.wsCollectionPortClient();

                oplCollection collection = new oplCollection();
                oplCollectionCollectionCollectionData collectionData = new oplCollectionCollectionCollectionData();
                oplCollectionCollectionInsuranceData insuredData = new oplCollectionCollectionInsuranceData();
                oplCollectionCollectionCodigoErrorError[] codigoErrorError = { };
                oplCollectionCollection oplCollectionCollection = new oplCollectionCollection();

                oplCollectionCollection.NoNegocio = datosCobranza.NumeroNegocio;
                oplCollectionCollection.NoPoliza = datosCobranza.NumeroPoliza;
                oplCollectionCollection.wpuid = consultaCatParametro.ObtenerCatParametro("wpuid");
                oplCollectionCollection.wptoken = consultaCatParametro.ObtenerCatParametro("wptoken");
                if (datosCobranza != null)
                {
                    collectionData.type = "N"; //Nomina "N"
                    collectionData.userkey = string.IsNullOrEmpty(datosCobranza.NumeroEmpleado) ? "" : datosCobranza.NumeroEmpleado;
                    collectionData.name = datosCobranza.NombreCompleto;
                    collectionData.crypto = "0";

                    insuredData.PlazoPago = datosCobranza.Periodicidad; //Datos que obtenemos en la configuracion de forma de pago cobranza del convenio.
                    insuredData.akey = datosCobranza.ClaveAgente;
                    insuredData.email = datosCobranza.CorreoElectronico;

                    oplCollectionCollection.collectionData = collectionData;
                    oplCollectionCollection.insuranceData = insuredData;
                    oplCollectionCollection.CodigoError = codigoErrorError;
                    collection.Items = oplCollectionCollection;

                    xmlResultado = ToXMLString(collection);
                    bool errorCobro = false;


                    log.Info(string.Format("Inicia llamado OplDXN Intento {0}/{1}. Xml: {2}", 1, datosCobranza.NumeroReintentos, xmlResultado.Replace("\n", "").Replace("\r", "")));

                    if (esProduccion)
                    {
                        resultado = clienteProd.oplCollection(xmlResultado);
                    }
                    else
                    {
                        resultado = clienteTest.oplCollection(xmlResultado);
                    }

                    log.Info(string.Format("Resultado llamado OplDXN Intento {0}/{1}. Xml: {2}", 1, datosCobranza.NumeroReintentos, resultado.Replace("\n", "").Replace("\r", "")));
                    TextReader reader = new StringReader(resultado);

                    XmlSerializer xs = new XmlSerializer(typeof(oplCollection));
                    oplCollection movimientoResult = (oplCollection)xs.Deserialize(reader);
                    oplCollectionCollection = (oplCollectionCollection)movimientoResult.Items;

                    if (oplCollectionCollection.CodigoError.Count() > 0)
                    {
                        if (oplCollectionCollection.CodigoError[0].Value.Trim().Length != 0)
                        {
                            builder.AppendLine(" ");
                            builder.AppendLine(string.Format("Error en Instalacion DXN, intento({0}/{1})", 1, datosCobranza.NumeroReintentos));
                            builder.AppendLine(" ");
                            for (int x = 0; x < oplCollectionCollection.CodigoError.Count(); x++)
                            {
                                builder.AppendLine(oplCollectionCollection.CodigoError[x].Value + " ");
                            }
                        }
                        errorCobro = true;
                    }
                    else
                    {
                        log.Info(string.Format("XML Instalacion DXN exitoso, intento({0}/{1})", 1, datosCobranza.NumeroReintentos));
                        builder.Clear();
                        errorCobro = false;
                    }

                    RegistraOPL(datosCobranza.NumeroPoliza, xmlResultado, resultado, "Pago Descuento Nomina", 2, !errorCobro, Utilidades.Utilidades.ValidaPolizaOnline(datosCobranza.NumeroPoliza) == true ? "Online" : "Tradicional");

                    if (errorCobro)
                    {
                        return "Cambiar de estatus de la poliza a por renovar";
                    }

                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado pagoDXN Qualitas:: " + ex.Message, ex);
                RegistraOPL(datosCobranza.NumeroPoliza, xmlResultado, ex.Message, "Pago Descuento Nomina", 2, false, Utilidades.Utilidades.ValidaPolizaOnline(datosCobranza.NumeroPoliza) == true ? "Online" : "Tradicional");
                builder.AppendLine("Verifique sus datos de pago e intente nuevamente");

            }
            log.Info(string.Format("Termina proceso de intalacion a OPlDXN de la poliza: {0}", datosCobranza.NumeroPoliza));

            return builder.ToString();

        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            ConsultaCatParametro consultaCatParametro = new ConsultaCatParametro();
            log.Info(string.Format("Comienza proceso de intalacion cobranza Referenciado para {0}, Numero_Empleado: {1}, poliza: {2}", datosCobranza.NombreCompleto, datosCobranza.NumeroEmpleado, datosCobranza.NumeroPoliza));
            StringBuilder builder = new StringBuilder();
            string xmlResultado = "";
            string resultado = "";

            try
            {
                PagoTDCQualitasTest.wsCollectionPortClient clienteTest = null;
                PagoTDCQualitasProd.wsCollectionPortClient clienteProd = null;

                bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                if (esProduccion)
                    clienteProd = new PagoTDCQualitasProd.wsCollectionPortClient();
                else
                    clienteTest = new PagoTDCQualitasTest.wsCollectionPortClient();

                oplCollection collection = new oplCollection();
                oplCollectionCollectionCollectionData collectionData = new oplCollectionCollectionCollectionData();
                oplCollectionCollectionInsuranceData insuredData = new oplCollectionCollectionInsuranceData();
                oplCollectionCollectionCodigoErrorError[] codigoErrorError = { };
                oplCollectionCollection oplCollectionCollection = new oplCollectionCollection();

                oplCollectionCollection.NoNegocio = datosCobranza.NumeroNegocio;
                oplCollectionCollection.NoPoliza = datosCobranza.NumeroPoliza;
                oplCollectionCollection.wpuid = consultaCatParametro.ObtenerCatParametro("wpuid");
                oplCollectionCollection.wptoken = consultaCatParametro.ObtenerCatParametro("wptoken");
                if (datosCobranza != null)
                {
                    collectionData.type = "R"; //Referenciado "R"
                    collectionData.userkey = string.IsNullOrEmpty(datosCobranza.NumeroEmpleado) ? "" : datosCobranza.NumeroEmpleado;
                    collectionData.name = datosCobranza.NombreCompleto;
                    collectionData.crypto = "0";

                    insuredData.PlazoPago = datosCobranza.Periodicidad; //Datos que obtenemos en la configuracion de forma de pago cobranza del convenio.
                    insuredData.akey = datosCobranza.ClaveAgente;
                    insuredData.email = datosCobranza.CorreoElectronico;

                    oplCollectionCollection.collectionData = collectionData;
                    oplCollectionCollection.insuranceData = insuredData;
                    oplCollectionCollection.CodigoError = codigoErrorError;
                    collection.Items = oplCollectionCollection;

                    xmlResultado = ToXMLString(collection);
                    bool errorCobro = false;

                    log.Info(string.Format("Inicia llamado OplReferenciado Intento {0}/{1}. Xml: {2}", 1, datosCobranza.NumeroReintentos, xmlResultado.Replace("\n", "").Replace("\r", "")));

                    if (esProduccion)
                    {
                        resultado = clienteProd.oplCollection(xmlResultado);
                    }
                    else
                    {
                        resultado = clienteTest.oplCollection(xmlResultado);
                    }

                    log.Info(string.Format("Resultado llamado OplReferenciado Intento {0}/{1}. Xml: {2}", 1, datosCobranza.NumeroReintentos, resultado.Replace("\n", "").Replace("\r", "")));
                    TextReader reader = new StringReader(resultado);

                    XmlSerializer xs = new XmlSerializer(typeof(oplCollection));
                    oplCollection movimientoResult = (oplCollection)xs.Deserialize(reader);
                    oplCollectionCollection = (oplCollectionCollection)movimientoResult.Items;

                    if (oplCollectionCollection.CodigoError.Count() > 0)
                    {
                        if (oplCollectionCollection.CodigoError[0].Value.Trim().Length != 0)
                        {
                            builder.AppendLine(" ");
                            builder.AppendLine(string.Format("Error en Instalacion OplReferenciado, intento({0}/{1})", 1, datosCobranza.NumeroReintentos));
                            builder.AppendLine(" ");
                            for (int x = 0; x < oplCollectionCollection.CodigoError.Count(); x++)
                            {
                                builder.AppendLine(oplCollectionCollection.CodigoError[x].Value + " ");
                            }
                        }
                        errorCobro = true;
                    }
                    else
                    {
                        log.Info(string.Format("XML Instalacion OplReferenciado exitoso, intento({0}/{1})", 1, datosCobranza.NumeroReintentos));
                        builder.Clear();
                        errorCobro = false;
                    }

                    RegistraOPL(datosCobranza.NumeroPoliza, xmlResultado, resultado, "Pago Referenciado", 3, !errorCobro, Utilidades.Utilidades.ValidaPolizaOnline(datosCobranza.NumeroPoliza) == true ? "Online" : "Tradicional");

                    if (errorCobro)
                    {
                        return "Cambiar de estatus de la poliza a por renovar";
                    }

                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado OplReferenciado Qualitas:: " + ex.Message, ex);
                RegistraOPL(datosCobranza.NumeroPoliza, xmlResultado, ex.Message, "Pago Referenciado", 3, false, Utilidades.Utilidades.ValidaPolizaOnline(datosCobranza.NumeroPoliza) == true ? "Online" : "Tradicional");
                builder.AppendLine("Verifique sus datos de pago e intente nuevamente");

            }
            log.Info(string.Format("Termina proceso de intalacion a OplReferenciado de la poliza: {0}", datosCobranza.NumeroPoliza));

            return builder.ToString();

        }

        /// <summary>
        /// Metodo para poder editar una tarjeta instalada en Opl. Ojo: Solamente aplica cuando hay una tarjeta instalada previamente en OPL.
        /// </summary>
        /// <param name="datosCobranza">Objeto con todos los elementos necesarios para la edicion de tarjeta</param>
        /// <returns>Mensaje de si fue o no correcto la edicion de la tarjeta de una poliza en OPL</returns>
        public EstatusOperacion EdicionTarjeta(DatosCobranza datosCobranza)
        {
            string key = consultaCatParametro.ObtenerCatParametro("key");
            log.Info(string.Format("Comienza proceso de Edicion cobranza TDC para {0}, Numero_Empleado: {1}, poliza: {2}", datosCobranza.NombreCompleto, datosCobranza.NumeroEmpleado, datosCobranza.NumeroPoliza));
            string xmlResultado = "";
            string xmlResultadoLog = "";
            string resultado = "";
            string number = datosCobranza.NumeroTarjeta;
            EstatusOperacion estatusOperacion = new EstatusOperacion();
            List<CatalogoErrorInstalacionDatosBancarios> catalogerrors = new List<CatalogoErrorInstalacionDatosBancarios>();
            CatalogoErrorInstalacionDatosBancarios error = new CatalogoErrorInstalacionDatosBancarios();
            string Mensajecom = "";

            try
            {
                PagoTDCQualitasTest.wsCollectionPortClient clienteTest = null;
                PagoTDCQualitasProd.wsCollectionPortClient clienteProd = null;

                bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                if (esProduccion)
                    clienteProd = new PagoTDCQualitasProd.wsCollectionPortClient();
                else
                    clienteTest = new PagoTDCQualitasTest.wsCollectionPortClient();

                Opl.qualitas.Edicion.oplCollection oplCollection = new Opl.qualitas.Edicion.oplCollection();
                Opl.qualitas.Edicion.oplCollectionEditionCollectionData oplCollectionData = new Opl.qualitas.Edicion.oplCollectionEditionCollectionData();
                Opl.qualitas.Edicion.oplCollectionEdition oplCollectionEdition = new Opl.qualitas.Edicion.oplCollectionEdition();
                Opl.qualitas.Edicion.oplCollectionEditionCodigoErrorerror[] codigoErrorErrors = { };

                oplCollectionEdition.NoNegocio = datosCobranza.NumeroNegocio;
                oplCollectionEdition.NoPoliza = datosCobranza.NumeroPoliza;
                oplCollectionEdition.wpuid = consultaCatParametro.ObtenerCatParametro("wpuid");
                oplCollectionEdition.wptoken = consultaCatParametro.ObtenerCatParametro("wptoken");

                if (datosCobranza != null)
                {
                    //oplCollectionData.type = datosCobranza.Periodicidad;
                    oplCollectionData.type = datosCobranza.TipoTarjeta;
                    oplCollectionData.userkey = string.IsNullOrEmpty(datosCobranza.NumeroEmpleado) ? "" : datosCobranza.NumeroEmpleado;
                    oplCollectionData.name = datosCobranza.NombreCompleto;
                    oplCollectionData.crypto = consultaCatParametro.ObtenerCatParametro("crypto");
                    switch (oplCollectionData.crypto)
                    {
                        case "1":
                            datosCobranza.NumeroTarjeta = Utilidades.Utilidades.StringToHexString(Utilidades.Utilidades.EncryptRC4(key, datosCobranza.NumeroTarjeta));
                            //datosCobranza.ClaveBanco = Utilidades.Utilidades.EncryptRC4(key, datosCobranza.ClaveBanco);
                            if (!string.IsNullOrEmpty(datosCobranza.MesVencimiento))
                                datosCobranza.MesVencimiento = Utilidades.Utilidades.StringToHexString(Utilidades.Utilidades.EncryptRC4(key, datosCobranza.MesVencimiento));
                            if (!string.IsNullOrEmpty(datosCobranza.AnoVencimiento))
                                datosCobranza.AnoVencimiento = Utilidades.Utilidades.StringToHexString(Utilidades.Utilidades.EncryptRC4(key, datosCobranza.AnoVencimiento));
                            if (!string.IsNullOrEmpty(datosCobranza.CodigoSeguridad))
                                datosCobranza.CodigoSeguridad = Utilidades.Utilidades.StringToHexString(Utilidades.Utilidades.EncryptRC4(key, datosCobranza.CodigoSeguridad));
                            break;
                    }
                    oplCollectionData.number = datosCobranza.NumeroTarjeta;
                    oplCollectionData.bankcode = datosCobranza.ClaveBanco;

                    if (number.Length <= 16)
                    {
                        oplCollectionData.expmonth = datosCobranza.MesVencimiento;
                        oplCollectionData.expyear = datosCobranza.AnoVencimiento;
                        oplCollectionData.cvvcsc = datosCobranza.CodigoSeguridad;
                    }
                    else
                    {
                        oplCollectionData.expmonth = "";
                        oplCollectionData.expyear = "";
                        oplCollectionData.cvvcsc = "";
                    }

                    oplCollectionEdition.collectionData = oplCollectionData;
                    oplCollectionEdition.CodigoError = codigoErrorErrors;
                    oplCollection.Items = oplCollectionEdition;

                    xmlResultado = ToXMLString(oplCollection);

                    if (oplCollectionData.crypto == "0")
                    {
                        oplCollectionData.number = "**********";
                        oplCollectionData.bankcode = "***";
                        oplCollectionData.expmonth = oplCollectionData.expmonth;//"**";
                        oplCollectionData.expyear = oplCollectionData.expyear;//"****";
                        oplCollectionData.cvvcsc = "***";
                        xmlResultadoLog = ToXMLString(oplCollection);
                    }
                    else { xmlResultadoLog = xmlResultado; }

                    xmlResultado = string.Format("<?xml version=\"1.0\" encoding=\"utf-8\"?>{0}", xmlResultado);
                    log.Info("Inicia llamado servicio EDICION_PAGO_TDC " + xmlResultadoLog.Replace("\n", "").Replace("\r", ""));

                    if (esProduccion)
                        resultado = clienteProd.oplEdition(xmlResultado);
                    else
                        resultado = clienteTest.oplEdition(xmlResultado);

                    //resultado = clienteTest.oplEdition(xmlResultado);
                    log.Info("Resultado  llamado servicio EDICIONPAGOTDC " + xmlResultadoLog.Replace("\n", "").Replace("\r", ""));
                    TextReader reader = new StringReader(resultado);
                    XmlSerializer xs = new XmlSerializer(typeof(Opl.qualitas.Edicion.oplCollection));

                    Opl.qualitas.Edicion.oplCollection movimientoResult = (Opl.qualitas.Edicion.oplCollection)xs.Deserialize(reader);
                    oplCollectionEdition = (Opl.qualitas.Edicion.oplCollectionEdition)movimientoResult.Items;
                    estatusOperacion.Exitoso = true;
                    error = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(x => x.DescripcionError.Equals("Exitoso"));
                    estatusOperacion.Mensaje = "";
                    string sms = string.Empty;
                    if (oplCollectionEdition.CodigoError.Count() > 0)
                    {
                        foreach (var item in oplCollectionEdition.CodigoError)
                        {
                            if (item.Error1 != null && item.Error1.Count() > 0)
                            {
                                foreach (var Err in item.Error1)
                                {
                                    sms = Err.Value.ToString();
                                    if (sms == null)
                                    {
                                        sms = "No se detecta error";
                                    }
                                    Mensajecom += sms;
                                    CatalogoErrorInstalacionDatosBancarios cataerror = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(y => sms.Contains(y.DescripcionError));
                                    if (cataerror != null)
                                        catalogerrors.Add(cataerror);
                                    log.Info(string.Format("Ocurrio un error al actualizar datos bancarios la poliza: {0} Error: {1})", datosCobranza.NumeroPoliza, Err.Value));
                                }
                            }
                            else
                            {
                                sms = item.Value.ToString();
                                if (sms == null)
                                {
                                    sms = "No se detecta error";
                                }
                                Mensajecom += sms;
                                CatalogoErrorInstalacionDatosBancarios cataerror = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(y => sms.Contains(y.DescripcionError));
                                if (cataerror != null)
                                    catalogerrors.Add(cataerror);
                                log.Info(string.Format("Ocurrio un error al actualizar datos bancarios la poliza: {0} Error: {1})", datosCobranza.NumeroPoliza, item.Value));
                            }
                        }
                        error = catalogerrors.FirstOrDefault();
                        estatusOperacion.Mensaje = catalogerrors != null ? error.MensajeMostrarUsaurio : "Algo salió mal en la edición de tus datos bancarios, acércate con tu asesor de servicio";
                        estatusOperacion.MensajeCatalogo = Mensajecom;
                        estatusOperacion.Exitoso = false;
                        if (error.EsReintentable)
                            estatusOperacion.EsReintentable = true;

                        estatusOperacion.Exitoso = false;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado En EdicionTDC Qualitas: " + ex.Message, ex);
                estatusOperacion.Mensaje = estatusOperacion.Mensaje = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(x => x.DescripcionError.Contains("exepcion") && x.IdAseguradora == 1).MensajeMostrarUsaurio; ;
                estatusOperacion.Exitoso = false;
                resultado += ex.Message;
                estatusOperacion.EsReintentable = false;
                estatusOperacion.MensajeCatalogo = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                error = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(y => y.DescripcionError.Contains("exepcion") && y.IdAseguradora == 1);
            }
            RegistraOPL(datosCobranza.NumeroPoliza, xmlResultadoLog, resultado, "Edición Tarjeta", 4, estatusOperacion.Exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datosCobranza.NumeroPoliza) == true ? "Online" : "Tradicional", error != null ? error.Id : 0);
            log.Info(string.Format("Termina proceso de Edicion a OPlTDC de la poliza: {0}", datosCobranza.NumeroPoliza));
            return estatusOperacion;
        }

        public string ToXMLString<T>(T toSerialize)
        {
            MemoryStream memoryStream = new MemoryStream();
            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add(String.Empty, String.Empty);
            XmlSerializer xs = new XmlSerializer(typeof(T));
            XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Default);
            xs.Serialize(xmlTextWriter, toSerialize, ns);
            memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
            string XmlizedString = UTF8ByteArrayToString(memoryStream.ToArray());
            XmlizedString = XmlizedString.Replace("<?xml version=\"1.0\" encoding=\"Windows-1252\"?>", "");
            xmlTextWriter.Close();
            memoryStream.Close();
            return XmlizedString;
        }

        private String UTF8ByteArrayToString(Byte[] characters)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            String constructedString = System.Text.Encoding.Default.GetString(characters);
            return (constructedString);
        }
        #endregion

        /// <summary>
        /// Metodo que sirve para poder reimprimir una poliza emitida para Qualitas
        /// </summary>
        /// <param name="datosCobranza">Objeto con todos los elementos necesarios para la reimpresion.</param>
        /// <returns>Una lista con dos elementos Poliza y Recibo de la poliza.</returns>
        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            List<string> UrlsAseguradora = new List<string>();
            try
            {
                ImpresionQualitas.entradaSoapClient clienteReimpresion = new ImpresionQualitas.entradaSoapClient();
                bool Esproduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                log.Info(string.Format("Comienza reimpresion de la poliza: {0}", NumeroPoliza));
                String polizaRs = "", recibosRs = "", textoss = "";
                string polizaImp = NumeroPoliza;

                string resultado = "";
                string Polizaurl = "";
                string ReciboUrl = "";

                //if (Esproduccion)
                resultado = clienteReimpresion.RecuperaImpresionM15(polizaImp, ref polizaRs, ref recibosRs, ref textoss, Inciso == 0 ? 1 : Inciso, 0, 0, 0, "04", "polizaf1_logoQ_pdf", "recibo_logoQN_pdf", "polizaf2_logoQ_pdf", Endoso == "" ? "000000" : Endoso.ToString(), NumeroNegocio, ClaveAgente, "Usr", "Psw");
                //else
                //	resultado = clienteReimpresion.RecuperaImpresionPrueba(polizaImp, ref polizaRs, ref recibosRs, ref textoss, Inciso == 0 ? 1 : Inciso, 0, 0, 0, "04", "polizaf1_logoQ_pdf", "recibo_logoQN_pdf", "polizaf2_logoQ_pdf", Endoso.Equals(0) ? "000000" : Endoso.ToString(), NumeroNegocio, ClaveAgente, "Usr", "Psw");

                log.Info("Resultado WS:" + resultado);

                if (!string.IsNullOrEmpty(resultado) && resultado.Contains("qualitas"))
                {
                    String[] result = resultado.Split('|');
                    foreach (string urlResult in result)
                    {
                        String[] cadenas = urlResult.Split('/');
                        if (cadenas[cadenas.Length - 1].Contains("p"))
                            Polizaurl = urlResult;
                        if (cadenas[cadenas.Length - 1].Contains("r"))
                            ReciboUrl = urlResult;
                    }
                    UrlsAseguradora.Add(Polizaurl);
                    UrlsAseguradora.Add(ReciboUrl);
                }
                log.Info("Finaliza Reimpresion de póliza");
            }
            catch (Exception ex)
            {
                UrlsAseguradora = new List<string>();
                log.Info(string.Format("Ocurrio un error no controlado en la Reimpresion de póliza. Mensaje: {0}", ex.Message));
            }
            return UrlsAseguradora;
        }
        /// <summary>
        /// Metodo que sirve para poder reimprimir una poliza emitida para Qualitas
        /// </summary>
        /// <param name="datosCobranza">Objeto con todos los elementos necesarios para la reimpresion.</param>
        /// <returns>Una lista con dos elementos Poliza y Recibo de la poliza.</returns>
        public List<string> ReimprimeRC(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            List<string> UrlsAseguradora = new List<string>();
            try
            {
                ImpresionQualitas.entradaSoapClient clienteReimpresion = new ImpresionQualitas.entradaSoapClient();
                bool Esproduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                log.Info(string.Format("Comienza reimpresion de la poliza: {0}", NumeroPoliza));
                String polizaRs = "", recibosRs = "", textoss = "";
                string polizaImp = NumeroPoliza;

                string resultado = "";
                string Polizaurl = "";
                string ReciboUrl = "";

                //if (Esproduccion)
                resultado = clienteReimpresion.RecuperaImpresionM15(polizaImp, ref polizaRs, ref recibosRs, ref textoss, Inciso == 0 ? 1 : Inciso, 0, 0, 0, "04", "polizaf1_logoQ_pdf", "recibo_logoQN_pdf", "polizaf2_logoQ_pdf", Endoso == "" ? "000000" : Endoso.ToString(), NumeroNegocio, ClaveAgente, "Usr", "Psw");
                //else
                //	resultado = clienteReimpresion.RecuperaImpresionPrueba(polizaImp, ref polizaRs, ref recibosRs, ref textoss, Inciso == 0 ? 1 : Inciso, 0, 0, 0, "04", "polizaf1_logoQ_pdf", "recibo_logoQN_pdf", "polizaf2_logoQ_pdf", Endoso.Equals(0) ? "000000" : Endoso.ToString(), NumeroNegocio, ClaveAgente, "Usr", "Psw");

                log.Info("Resultado WS:" + resultado);

                if (!string.IsNullOrEmpty(resultado) && resultado.Contains("qualitas"))
                {
                    String[] result = resultado.Split('|');
                    foreach (string urlResult in result)
                    {
                        String[] cadenas = urlResult.Split('/');
                        if (cadenas[cadenas.Length - 1].Contains("c"))
                            Polizaurl = urlResult;
                        //if (cadenas[cadenas.Length - 1].Contains("r"))
                        //    ReciboUrl = urlResult;
                    }
                    UrlsAseguradora.Add(Polizaurl);
                    //UrlsAseguradora.Add(ReciboUrl);
                }
                log.Info("Finaliza Reimpresion de póliza");
            }
            catch (Exception ex)
            {
                UrlsAseguradora = new List<string>();
                log.Info(string.Format("Ocurrio un error no controlado en la Reimpresion de póliza. Mensaje: {0}", ex.Message));
            }
            return UrlsAseguradora;
        }

        public string calculaDigitoVerificadorAMIS(string AMIS)
        {
            string amisCompleta = AMIS.PadLeft(5);
            int etapa1 = int.Parse(amisCompleta.Substring(0, 1)) + int.Parse(amisCompleta.Substring(2, 1)) + int.Parse(amisCompleta.Substring(4, 1));
            int etapa2 = etapa1 * 3;
            int etapa3 = int.Parse(amisCompleta.Substring(1, 1)) + int.Parse(amisCompleta.Substring(3, 1));
            int etapa4 = etapa2 + etapa3;
            int etapa5 = (etapa4 % 10);
            if (etapa5 > 0)
                return (10 - etapa5).ToString();
            return etapa5.ToString();
        }


        public EstatusOperacion EndosoB(string numeroPoliza, int idConvenio, Modificacion modificacion, int idFormaPago, int idMedioPago, string clave)
        {

            var estatusOperacion = new EstatusOperacion();

            string xmlRequest = "";
            string xmlResponse = "";
            var urlMethod = "";

            try
            {
                //var claveM = idMedioPago.ToString();
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                var catModalidad = db.CatModalidadFormaPago.FirstOrDefault(a => a.Id == idMedioPago);
                var ClaveAgenteModalidadFPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == convenio.Id && x.IdCatPeriodicidadFormaPago == idFormaPago && x.IdCatModalidadFormaPago == catModalidad.Id).FirstOrDefault();
                bool produccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                string DigitoVerificadorAMIS = calculaDigitoVerificadorAMIS(string.Format("{0:00000}", int.Parse(clave)));

                var listConsideracionesAdicionalesDG = new List<NConsideracionesAdicionalesDG>();

                listConsideracionesAdicionalesDG.Add(new NConsideracionesAdicionalesDG() { NoConsideracion = "1", TipoRegla = "1", ValorRegla = DigitoVerificadorAMIS });

                listConsideracionesAdicionalesDG.Add(new NConsideracionesAdicionalesDG() { NoConsideracion = "3", TipoRegla = "1", ValorRegla = "" });

                ///Produccion
                if (produccion)
                    listConsideracionesAdicionalesDG.Add(new NConsideracionesAdicionalesDG() { NoConsideracion = "4", TipoRegla = "1", ValorRegla = "0" });
                else
                    //Pruebas
                    listConsideracionesAdicionalesDG.Add(new NConsideracionesAdicionalesDG() { NoConsideracion = "4", TipoRegla = "1", ValorRegla = "1" });

                var tipoRegla = "";

                switch (modificacion.IdTipoModificacion)
                {
                    case 2: tipoRegla = "5"; break;
                    case 3: tipoRegla = "7"; break;
                    case 4: tipoRegla = "4"; break;
                    case 5: tipoRegla = "9"; break;

                }

                listConsideracionesAdicionalesDG.Add(new NConsideracionesAdicionalesDG() { NoConsideracion = "115", TipoRegla = tipoRegla, ValorRegla = modificacion.DebeDecir });

                XmlDocument XmlQualitas = new XmlDocument();

                NMovimientos movimientos = new NMovimientos()
                {
                    Movimiento = new NMovimiento()
                    {
                        TipoMovimiento = "4",//4 Endosos
                        NoPoliza = $"04{numeroPoliza}000000",
                        NoCotizacion = "",
                        NoEndoso = "",
                        TipoEndoso = "",
                        NoOTra = "",
                        NoNegocio = string.Format("{0:00000}", convenio.NumeroNegocio),
                        DatosAsegurado = new NDatosAsegurado()
                        {
                            NoAsegurado = "",
                            Nombre = "",
                            Direccion = "",
                            Colonia = "",
                            Poblacion = "",
                            Estado = "",
                            CodigoPostal = "",
                            NoEmpleado = "0",
                            Agrupador = "",
                            ConsideracionesAdicionalesDA = new List<NConsideracionesAdicionalesDA>(),
                        },
                        DatosVehiculo = new NDatosVehiculo()
                        {
                            NoInciso = "1",
                            ClaveAmis = clave,
                            Modelo = "",
                            DescripcionVehiculo = "",
                            Uso = "01",
                            Servicio = "01",
                            Paquete = "",
                            Motor = "",
                            Serie = "",

                        },
                        DatosGenerales = new NDatosGenerales()
                        {
                            FechaEmision = DateTime.Now.ToString("yyyy-MM-dd"),
                            FechaInicio = DateTime.Now.ToString("yyyy-MM-dd"),
                            FechaTermino = DateTime.Now.ToString("yyyy-MM-dd"),
                            Moneda = "00",
                            Agente = ClaveAgenteModalidadFPago.ClaveAgenteModalidadFormaPago,
                            FormaPago = "",
                            TarifaValores = "",
                            TarifaCuotas = "",
                            TarifaDerechos = "",
                            Plazo = "",
                            Agencia = "",
                            Contrato = "",
                            PorcentajeDescuento = "",
                            ConsideracionesAdicionalesDG = listConsideracionesAdicionalesDG,
                        },
                        CodigoError = "",
                        Primas = new NPrimas()
                        {
                            Comision = "",
                            Derecho = "",
                            Impuesto = "",
                            PrimaNeta = "",
                            PrimaTotal = "",
                            Recargo = ""
                        }

                    }
                };

                XmlSerializer xmlSerializer = new XmlSerializer(typeof(NMovimientos));
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;

                string resultado;

                using (Utf8StringWriter stringWriter = new Utf8StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
                    {
                        xmlSerializer.Serialize(xmlWriter, movimientos);
                    }
                    resultado = stringWriter.ToString();
                }

                XmlQualitas.LoadXml(resultado);
                if (XmlQualitas.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                    XmlQualitas.RemoveChild(XmlQualitas.FirstChild);

                using (CotizacionEmisionQualitas.wsEmisionServiceSoapClient cotizaQualitas = new CotizacionEmisionQualitas.wsEmisionServiceSoapClient())
                {
                    urlMethod = cotizaQualitas.Endpoint.Address.Uri.AbsoluteUri;
                    xmlRequest = XmlQualitas.InnerXml;

                    cotizaQualitas.Endpoint.Binding = conexion.Conexion(cotizaQualitas.Endpoint.Address.Uri);

                    xmlResponse = cotizaQualitas.obtenerNuevaEmision(XmlQualitas.InnerXml);
                }

                XmlDocument xmlDResponse = new XmlDocument();
                xmlDResponse.LoadXml(xmlResponse);
                string ErrorBQualitas = xmlDResponse.SelectNodes("Movimientos/Movimiento/CodigoError")[0].InnerText;

                if (string.IsNullOrEmpty(ErrorBQualitas) || string.IsNullOrWhiteSpace(ErrorBQualitas))
                {
                    estatusOperacion.Exitoso = true;
                    estatusOperacion.IdEndosoB = xmlDResponse.SelectNodes("Movimientos/Movimiento")[0].Attributes["NoEndoso"].Value;

                    log.Info(string.Format("Corrección de objeto de póliza exitosa)"));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al enviar la correción de objetos de la poliza: {0} Error: {1})", numeroPoliza, xmlResponse));

                    estatusOperacion.Mensaje = "Algo salió mal en él envió de la correción de la póliza, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    //estatusOperacion.MensajeCatalogo = response.mensajeError;
                }


            }
            catch (Exception ex)
            {
                xmlResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            Utilidades.Utilidades.RegistroEndosoBitacora(2, urlMethod, numeroPoliza, estatusOperacion.MensajeCatalogo ?? "", xmlRequest, xmlResponse);

            return estatusOperacion;
        }




        public CotizacionCompara CotizarVehiculo()
        {
            throw new System.NotImplementedException();
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            string movimientosXML = string.Empty;
            string xmlrespQualitas = string.Empty;
            try
            {
                log.Info("Comienza proceso de armado de xml de emision de poliza con numero de serie:" + InfoEmision.Vehiculo.Serie);
                movimientosXML = ArmarXMLEmision(InfoEmision);
                using (CotizacionEmisionQualitas.wsEmisionServiceSoapClient cotizaQualitas = new CotizacionEmisionQualitas.wsEmisionServiceSoapClient())
                {
                    cotizaQualitas.Endpoint.Binding = conexion.Conexion(cotizaQualitas.Endpoint.Address.Uri);
                    log.Info(string.Format("Inicia llamado a servicio de emision qualitas para la serie: {0} a las: {1}", InfoEmision.Vehiculo.Serie.ToUpper(), DateTime.Now));
                    string xmlresQualitas = cotizaQualitas.obtenerNuevaEmision(movimientosXML);
                    log.Info(string.Format("Termina llamado a servicio de emision qualitas para la serie: {0} a las: {1}", InfoEmision.Vehiculo.Serie.ToUpper(), DateTime.Now));
                    XmlDocument xmlResp = new XmlDocument();
                    xmlResp.LoadXml(xmlresQualitas);
                    string ErrorDQualitas = xmlResp.SelectNodes("Movimientos/Movimiento/CodigoError")[0].InnerText;
                    xmlrespQualitas = xmlresQualitas.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");

                    if (string.IsNullOrEmpty(ErrorDQualitas) || string.IsNullOrWhiteSpace(ErrorDQualitas))
                    {
                        log.Info(string.Format("Se logro la emision correcta de la serie: {0} a las: {1} ", InfoEmision.Vehiculo.Serie.ToUpper(), DateTime.Now));
                        GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, movimientosXML.Replace("\n", "").Replace("\r", ""), xmlrespQualitas.Replace("\n", "").Replace("\r", ""), ErrorDQualitas, "Emisión");
                        return new EmisionPoliza(true, movimientosXML, xmlresQualitas);
                    }
                    else
                    {
                        log.Info(string.Format("Ocurrio un error en la emision de la poliza se guarda xml de solicitud de emision --> {0}", movimientosXML.Replace("\n", "").Replace("\r", "")));
                        log.Info(string.Format("Ocurrio un error en la emision de la poliza se guarda xml Emision respuesta --> {0} ", xmlresQualitas.Replace("\n", "").Replace("\r", "")));

                        GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, movimientosXML.Replace("\n", "").Replace("\r", ""), xmlrespQualitas.Replace("\n", "").Replace("\r", ""), ErrorDQualitas, "Emisión");

                        //Mandar a llamar para enviar correo 

                        return new EmisionPoliza(false, null, ErrorDQualitas);
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un error no controlado en el intento de emision para la serie: {0}, Error: {1}", InfoEmision.Vehiculo.Serie, ex.Message));
                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, movimientosXML.Replace("\n", "").Replace("\r", ""), xmlrespQualitas.Replace("\n", "").Replace("\r", ""), ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");
                return new EmisionPoliza(false, null, ex.Message.Replace("\n", " "));
            }
        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            try
            {
                PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
                CotizacionDetalle detalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
                Cotizacion cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == detalle.IdCotizacion);
                double costo = 0;
                CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
                ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Convenio.IdEmpresa).FirstOrDefault();

                DateTime InicioVigencia = cotizacion.FechaFactura;
                DateTime FinVigencia = InfoEmision.Convenio.FinVigencia;

                Poliza poliza = new Poliza();
                PolizaDetalle polizaDet = new PolizaDetalle();

                Endoso endosoAlta = new Endoso();
                endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                endosoAlta.Fecha = DateTime.Now;
                endosoAlta.ValorAnterior = "Alta";
                endosoAlta.ValorActual = "Contratación";

                poliza.FinVigencia = FinVigencia;
                poliza.InicioVigencia = InicioVigencia;

                poliza.PrimaNeta = (decimal)0;
                poliza.PrimaNetaAnualizada = (decimal)0;
                poliza.PrimaTotal = (decimal)0;
                poliza.PrimaTotalAnualizada = (decimal)0;

                poliza.Motor = InfoEmision.NumeroMotor;
                poliza.Serie = InfoEmision.NumeroSerie;
                poliza.Placas = InfoEmision.Placas;
                poliza.FechaEmision = DateTime.Now;
                poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                poliza.UrlPDFPoliza = "";
                poliza.UrlPDFRecibos = "";
                poliza.Estatus = 21;
                poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                poliza.IdConvenio = InfoEmision.Convenio.Id;
                poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                poliza.IdTipoCobertura = Convert.ToInt32(detalle.Paquete);
                poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
                poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                poliza.Acepto_DescuentoPoliza = true;

                polizaDet.Inciso = "1";
                polizaDet.RenovacionAutomatica = true;
                polizaDet.Deducible = 0;
                polizaDet.Comision = 0;
                polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
                polizaDet.MigraOPERA = false;
                polizaDet.UrlPDFPolizaOPERA = "";
                polizaDet.PolizaOPERA = 0;
                polizaDet.OTOpera = 0;
                polizaDet.EndosoOPERA = 0;
                polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                polizaDet.IdCotizacionDetalle = detalle.Id;
                polizaDet.IdCatRamoVehiculo = detalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                polizaDet.IdCatModalidadFormaPago = medioPago.Id;
                polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
                polizaDet.XMLRecepcion = "";
                polizaDet.XMLSolicitud = "";
                polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;

                List<LocktonModel.db.Recibo> recibosGenerados = new List<LocktonModel.db.Recibo>();

                LocktonModel.db.Recibo reciboSave = new LocktonModel.db.Recibo();
                reciboSave.InicioVigencia = InicioVigencia;
                reciboSave.FinVigencia = FinVigencia;
                reciboSave.Numero = 1;
                reciboSave.NoAsegurado = "1";
                reciboSave.PrimaTotal = Convert.ToDecimal(0);
                reciboSave.PrimaNeta = Convert.ToDecimal(0);
                reciboSave.Comision = Convert.ToDecimal(0);
                reciboSave.Impuesto = Convert.ToDecimal(0);

                recibosGenerados.Add(reciboSave);

                endosoAlta.Recibo = recibosGenerados;

                poliza.Endoso.Add(endosoAlta);
                poliza.PolizaDetalle.Add(polizaDet);
                db.Poliza.Add(poliza);
                db.SaveChanges();

                return new EmisionPoliza(true, "", "", poliza);
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un error no controlado en el intento de emision para la serie: {0}, Error: {1}", InfoEmision.Vehiculo.Serie, ex.Message));
                return new EmisionPoliza(false, null, ex.Message);
            }
        }



        private string ArmarXMLEmision(InformacionEmision InfoEmision)
        {
            log.Info(string.Format("Inicia armado del XML para la serie: {0}", InfoEmision.Vehiculo.Serie));
            string cadenaEmisionEXML = "";
            //Revisar si es cotización individual o es flotilla.

            LocktonModel.db.CatRamoVehiculo ramoVehiculo = db.CatRamoVehiculo.First(x => x.Clave == InfoEmision.CotizacionAutoGuardar.TipoVehiculo);
            LocktonModel.db.ConvenioRamoPaquete paqueteRamoConvenio = db.ConvenioRamoPaquete.FirstOrDefault(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatRamoVehiculo == ramoVehiculo.IdCatRamo);
            int tipoPaquete = Convert.ToInt32(db.CotizacionDetalle.Where(x => x.Id == InfoEmision.IdCotizacion).FirstOrDefault().Paquete);
            var _paqueteConvenio = db.PaqueteConvenio.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatTipoPaquete == tipoPaquete & x.IdCatRamoVehiculo == ramoVehiculo.IdCatRamo).FirstOrDefault();
            bool AplicaDepreciacion = _paqueteConvenio.AplicaDepreciacion;
            var aplicaCondicionDV39 = false;
            var detalleUsuarioBeflex = db.DetalleUsuarioBeFlex.FirstOrDefault(a => a.IdUsuario == InfoEmision.DetalleUsuario.IdUsuario);
            var cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
            var cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacionDetalle.IdCotizacion);
            var empresasDeloitte = db.CatDeloitte.Select(a => a.IdEmpresa).ToList();
            LocktonModel.db.PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.FirstOrDefault(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago);
            //Se obtiene el parámetro para apuntar a producción o a pruebas. Cambiar el parámetro cada vez que se envíe a Producción. 
            bool pruebasProd = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;

            //Definir el tipo de usuario (el brody del Vic no puso el tipo de posicion en definicion de usuarios así que hay que arreglar ese desma)
            //Después reemplazar el valor a true con lo mancionado antes
            bool esUsuarioFlotilla = InfoEmision.EsFlotilla;

            //Se toman las coberturas del XML enviad para cotizar.
            XmlCobertura coberturas = new XmlCobertura();
            XmlNodeList nodosCotizacionSeleccionada = InfoEmision.XmlsAseguradoras["CotizacionSolicitud"].SelectNodes("Movimientos/Movimiento/DatosVehiculo/Coberturas");
            coberturas.elementos = new List<XElement>();
            foreach (XmlNode xmlNode in nodosCotizacionSeleccionada)
            {
                XElement elem = new XElement(xmlNode.Name);

                if (xmlNode.Attributes.Count > 0)
                {
                    foreach (XmlAttribute att in xmlNode.Attributes)
                    {
                        elem.SetAttributeValue(att.Name, att.InnerText);
                    }
                }

                foreach (XmlElement hijo in xmlNode.ChildNodes)
                {
                    elem.Add(new XElement(hijo.Name, hijo.InnerText));
                }

                coberturas.elementos.Add(elem);
            }
            XmlNodeList nodosCotizacionGenralesSeleccionada = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales");
            string fechaEmision = Convert.ToDateTime(nodosCotizacionGenralesSeleccionada[0].ChildNodes[0].InnerText).ToString("yyyy-MM-dd");
            string fechaInicio = Convert.ToDateTime(nodosCotizacionGenralesSeleccionada[0].ChildNodes[1].InnerText).ToString("yyyy-MM-dd");


            string fechaTermino = Convert.ToDateTime(nodosCotizacionGenralesSeleccionada[0].ChildNodes[2].InnerText).ToString("yyyy-MM-dd");
            string agente = nodosCotizacionGenralesSeleccionada[0].ChildNodes[4].InnerText;
            string formaPago = nodosCotizacionGenralesSeleccionada[0].ChildNodes[5].InnerText;
            string descuento = nodosCotizacionGenralesSeleccionada[0].ChildNodes[12].InnerText;

            string consideracionone2one = string.Empty;
            foreach (XmlNode node in InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales/ConsideracionesAdicionalesDG"))
            {
                if (node.Attributes.Count > 0)
                {
                    if (node.Attributes["NoConsideracion"].InnerText.Equals("1"))
                    {
                        consideracionone2one = node.ChildNodes[1].InnerText;
                        break;
                    }
                }
            }
            XmlNodeList nodosVehiculoCotizacionSeleccionada = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosVehiculo");
            InfoEmision.Amis = nodosVehiculoCotizacionSeleccionada[0].ChildNodes[0].InnerText;
            InfoEmision.Vehiculo.Modelo = nodosVehiculoCotizacionSeleccionada[0].ChildNodes[1].InnerText;
            InfoEmision.Vehiculo.Descripcion = nodosVehiculoCotizacionSeleccionada[0].ChildNodes[2].InnerText;
            InfoEmision.Vehiculo.Uso = nodosVehiculoCotizacionSeleccionada[0].ChildNodes[3].InnerText;
            InfoEmision.Vehiculo.Servicio = nodosVehiculoCotizacionSeleccionada[0].ChildNodes[4].InnerText;
            InfoEmision.Paquete = nodosVehiculoCotizacionSeleccionada[0].ChildNodes[5].InnerText;

            foreach (XmlNode _node in InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosVehiculo/ConsideracionesAdicionalesDV"))
            {
                if (_node.Attributes.Count > 0)
                {
                    if (_node.Attributes["NoConsideracion"].InnerText.Equals("39"))
                    {
                        aplicaCondicionDV39 = true;
                        break;
                    }
                }
            }


            XmlCobertura ConsideracionCP = new XmlCobertura();
            XmlCobertura ConsinderacionCesionComision = new XmlCobertura();
            XmlCobertura DerechosPrimerRecibo = new XmlCobertura();
            XmlCobertura AplicaDeprec = new XmlCobertura();
            XmlCobertura BeneficiarioPreferente = new XmlCobertura();
            XmlCobertura ConsideracionAG82 = new XmlCobertura();
            XmlCobertura AplicaNumeroEconomico = new XmlCobertura();
            XmlCobertura CondicionDV39 = new XmlCobertura();
            XmlCobertura NumeroSegmento = new XmlCobertura();
            XmlCobertura NEmpleado = new XmlCobertura();
            XmlCobertura Facturacion4 = new XmlCobertura();
            XmlCobertura cosideracion34 = new XmlCobertura();
            XmlCobertura cosideracionLeapYear = new XmlCobertura();


            ConsideracionAG82.elementos = new List<XElement>();
            XElement _conductor = new XElement("ConsideracionesAdicionalesDG",
                                new XAttribute("NoConsideracion", "10"),
                                new XElement("TipoRegla", "82"),
                                new XElement("ValorRegla", InfoEmision.ObtieneNombreCompleto()));
            ConsideracionAG82.elementos.Add(_conductor);

            //Persona Moral 
            if ((InfoEmision.IdTipoDeNegocio == 5 || InfoEmision.IdTipoDeNegocio == 6) && string.IsNullOrEmpty(InfoEmision.PrimerNombre))
            {
                ConsideracionAG82 = new XmlCobertura();
            }

            if (InfoEmision.EsBeneficiarioPreferente)
            {
                BeneficiarioPreferente.elementos = new List<XElement>();
                XElement AplicaBef = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "8"),
                                    new XElement("TipoRegla", "56"),
                                    new XElement("ValorRegla", InfoEmision.IdBeneficiarioPreferente));
                BeneficiarioPreferente.elementos.Add(AplicaBef);
            }

            var tipoRegla34 = "";

            if (AplicaDepreciacion)
            {
                tipoRegla34 = "2";

                if (_paqueteConvenio.TipoRegla34 > 0)
                    tipoRegla34 = _paqueteConvenio.TipoRegla34.ToString();

                AplicaDeprec.elementos = new List<XElement>();
                XElement AplicaDep = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "34"),
                                    new XElement("TipoRegla", tipoRegla34),
                                    new XElement("ValorRegla", ""));
                AplicaDeprec.elementos.Add(AplicaDep);
            }

            if (_paqueteConvenio.Condicion34)
            {
                tipoRegla34 = "1";

                if (_paqueteConvenio.TipoRegla34 > 0)
                    tipoRegla34 = _paqueteConvenio.TipoRegla34.ToString();

                cosideracion34.elementos = new List<XElement>();
                XElement AplicaCons = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "34"),
                                    new XElement("TipoRegla", tipoRegla34),
                                    new XElement("ValorRegla", ""));
                cosideracion34.elementos.Add(AplicaCons);
            }

            if (InfoEmision.AplicaNumeroContrato)
            {
                AplicaNumeroEconomico.elementos = new List<XElement>();
                XElement NumEconomico = new XElement("ConsideracionesAdicionalesDV",
                                    new XAttribute("NoConsideracion", "59"),
                                    new XElement("TipoRegla", ""),
                                    new XElement("ValorRegla", InfoEmision.NumeroEconomico));
                AplicaNumeroEconomico.elementos.Add(NumEconomico);

            }

            if (aplicaCondicionDV39)
            {
                CondicionDV39.elementos = new List<XElement>();
                XElement _39 = new XElement("ConsideracionesAdicionalesDV",
                                    new XAttribute("NoConsideracion", "39"),
                                    new XElement("TipoRegla", "0"),
                                    new XElement("ValorRegla", "N|S"));
                CondicionDV39.elementos.Add(_39);

            }


            if (InfoEmision.AplicaNumeroSegmento)
            {
                NumeroSegmento.elementos = new List<XElement>();
                XElement segmento = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "10"),
                                    new XElement("TipoRegla", "265"),
                                    new XElement("ValorRegla", InfoEmision.NumeroSegmento));
                NumeroSegmento.elementos.Add(segmento);

                NEmpleado.elementos = new List<XElement>();
                XElement NumEmpleado = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "10"),
                                    new XElement("TipoRegla", "266"),
                                    new XElement("ValorRegla", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")));
                NumeroSegmento.elementos.Add(NumEmpleado);

            }

            if (InfoEmision.Convenio.ZonaCirculacion == 2)
            {
                ConsideracionCP.elementos = new List<XElement>();
                XElement CPFijo = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "84"),
                                    new XElement("TipoRegla", ""),
                                    new XElement("ValorRegla", InfoEmision.Convenio.CodigoPostal));

                ConsideracionCP.elementos.Add(CPFijo);
            }
            if (paqueteRamoConvenio.CesionDeComision > 0)
            {
                ConsinderacionCesionComision.elementos = new List<XElement>();
                XElement CesionComision = new XElement("ConsideracionesAdicionalesDG",
                                   new XAttribute("NoConsideracion", "35"),
                                   new XElement("TipoRegla", "2"),
                                   new XElement("ValorRegla", paqueteRamoConvenio.CesionDeComision.ToString("0.##")));
                ConsinderacionCesionComision.elementos.Add(CesionComision);
            }
            if (!InfoEmision.Convenio.DerechosPrimerRecibo)
            {
                DerechosPrimerRecibo.elementos = new List<XElement>();
                XElement Derecho1erRecibo = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "13"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", "S"));

                DerechosPrimerRecibo.elementos.Add(Derecho1erRecibo);
            }

            if (InfoEmision.Convenio.LeapYear)
            {
                cosideracionLeapYear.elementos = new List<XElement>();
                XElement _leapyear = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "7"),
                                    new XElement("TipoRegla", "2"),
                                    new XElement("ValorRegla", "61"));

                cosideracionLeapYear.elementos.Add(_leapyear);

            }
            else if (InfoEmision.Convenio.FLP > 0)
            {

                cosideracionLeapYear.elementos = new List<XElement>();

                XElement _multianual = new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "7"),
                                    new XElement("TipoRegla", ""),
                                    new XElement("ValorRegla", InfoEmision.Convenio.FLP.ToString()));

                cosideracionLeapYear.elementos.Add(_multianual);
            }

            if (InfoEmision.RequiereFactura)
            {

                Facturacion4.elementos = new List<XElement>();
                var _facturacionDB = new Facturacion();
                XElement _facturacion;

                if (esUsuarioFlotilla || InfoEmision.EmisionPersonaMoral)
                {
                    var _regimenEmpresa = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal);
                    _facturacion = new XElement("ConsideracionesAdicionalesDG",
                                        new XAttribute("NoConsideracion", "160"),
                                        new XElement("TipoRegla", ""),
                                        new XElement("ValorRegla", $"{InfoEmision.Empresa.RFC}|{InfoEmision.Empresa.RazonSocial}|||{InfoEmision.Empresa.Direccion.CodigoPostal}|{_regimenEmpresa.Clave}"));

                    _facturacionDB.RFC = InfoEmision.Empresa.RFC;
                    _facturacionDB.Nombre = InfoEmision.Empresa.RazonSocial;
                    _facturacionDB.CodigoPostal = InfoEmision.Empresa.Direccion.CodigoPostal;
                    _facturacionDB.IdRegimenFiscal = InfoEmision.Empresa.IdRegimenFiscal;

                }
                else
                {
                    var _regimen = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.IdRegimenFiscal);
                    _facturacion = new XElement("ConsideracionesAdicionalesDG",
                                        new XAttribute("NoConsideracion", "160"),
                                        new XElement("TipoRegla", ""),
                                        new XElement("ValorRegla", $"{InfoEmision.DatosUsuario.RFC}|{InfoEmision.PrimerNombre} {InfoEmision.SegundoNombre}|{InfoEmision.ApellidoPaterno}|{InfoEmision.ApellidoMaterno}|{InfoEmision.DatosUsuario.Direccion.CodigoPostal}|{_regimen.Clave}"));

                    _facturacionDB.RFC = InfoEmision.DatosUsuario.RFC;
                    _facturacionDB.Nombre = $"{InfoEmision.PrimerNombre} {InfoEmision.SegundoNombre} {InfoEmision.ApellidoPaterno} {InfoEmision.ApellidoMaterno}";
                    _facturacionDB.CodigoPostal = InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                    _facturacionDB.IdRegimenFiscal = InfoEmision.IdRegimenFiscal;

                }

                Facturacion4.elementos.Add(_facturacion);

                Utilidades.Utilidades.GeneraRegistroFacturacion(_facturacionDB);

            }

            decimal recargoPagoFraccionado = 0;

            if (cotizacionDetalle.IdCatPeriodicidadMultianual > 0)
            {
                var periodicidadMultianual = db.PeriodicidadMultianual.FirstOrDefault(a => a.IdCatPeriodicidadMultianual == cotizacionDetalle.IdCatPeriodicidadMultianual && a.IdConvenio == InfoEmision.Convenio.Id && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago);
                recargoPagoFraccionado = periodicidadMultianual.FLP ?? 0;
            }
            else
            {
                recargoPagoFraccionado = perioricidad.RecargoPagoFraccionado;
            }



            XElement Movimientos;
            string NombrePoliza = "";

            //Comienza la fiesta!!!
            try
            {
                #region Individuales - MENOS CAMPOS
                //Asegurado Empleado - Conductor (Persona Fisica) / Sin Contratante
                if (InfoEmision.IdTipoDeNegocio == 3 || (InfoEmision.IdTipoDeNegocio == 5 && !InfoEmision.EmisionPersonaMoral))
                {
                    ConsideracionAG82 = new XmlCobertura();

                    //var tipoIdentificacion = db.CatTipoIdentificacions.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdTipoIdentificacion);
                    var giro = db.CatGiroBase.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdCatGiro);

                    var idOcupacion = InfoEmision.DatosUsuario.IdCatOcupacion;
                    var idProfecion = InfoEmision.DatosUsuario.IdCatProfesion;

                    if (idOcupacion == 0)
                        idOcupacion = 2;

                    if (idProfecion == 0)
                        idProfecion = 16;

                    esUsuarioFlotilla = false;
                    Movimientos =
                    new XElement("Movimientos",
                        new XElement("Movimiento",
                            new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                            new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                            new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                            new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                            new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                            new XAttribute("NoOTra", InfoEmision.NoOTra),
                            new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                            new XElement("DatosAsegurado",
                                new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                                new XElement("Nombre", InfoEmision.ObtieneNombreCompleto()),
                                new XElement("Direccion", InfoEmision.DatosUsuario.Direccion.Calle),
                                new XElement("Colonia", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento),
                                new XElement("Poblacion", InfoEmision.DatosUsuario.Direccion.Municipio),
                                new XElement("Estado", InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                                new XElement("CodigoPostal", InfoEmision.DatosUsuario.Direccion.CodigoPostal),
                                new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                                new XElement("Agrupador", null),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.NumeroExt)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "2"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.NumeroInt)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "3"),
                                    new XElement("ValorRegla", "MEXICO")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "4"),
                                    new XElement("ValorRegla", string.IsNullOrWhiteSpace(InfoEmision.SegundoNombre) ? InfoEmision.PrimerNombre : string.Concat(InfoEmision.PrimerNombre, " ", InfoEmision.SegundoNombre))),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "5"),
                                    new XElement("ValorRegla", InfoEmision.ApellidoPaterno)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "6"),
                                    new XElement("ValorRegla", InfoEmision.ApellidoMaterno)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "7"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "8"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "19"),
                                    new XElement("ValorRegla", "1")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "20"),
                                    new XElement("ValorRegla", InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "21"),
                                    new XElement("ValorRegla", "1")),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "22"),
                                    new XElement("ValorRegla", "001")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "23"),
                                    new XElement("ValorRegla", idOcupacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "24"),
                                    new XElement("ValorRegla", giro == null ? "42" : giro.Clave)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "25"),
                                    new XElement("ValorRegla", idProfecion)),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "26"),
                                    new XElement("ValorRegla", InfoEmision.Email)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "28"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.RFC)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "56"),
                                    new XElement("ValorRegla", (cotizacion.IdCatGenero == 2 ? "M" : "H"))),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "59"),
                                    new XElement("ValorRegla", (InfoEmision.DatosUsuario.RegimenFiscalEmpresarial ? "S" : "N"))),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "62"),
                                    new XElement("ValorRegla", "1")), //INE
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "63"),
                                    new XElement("ValorRegla", "98765")),//numero de identificacion
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "70"),
                                    new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "78"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Valor))
                                    ),
                            new XElement("DatosVehiculo",
                                new XAttribute("NoInciso", InfoEmision.NoInciso),
                                new XElement("ClaveAmis", InfoEmision.Amis),
                                new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                                new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                                new XElement("Uso", InfoEmision.Vehiculo.Uso),
                                new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                                new XElement("Paquete", InfoEmision.Paquete),
                                new XElement("Motor", InfoEmision.Vehiculo.Motor),
                                new XElement("Serie", InfoEmision.Vehiculo.Serie),
                                coberturas.elementos.Select(x => x),
                                AplicaNumeroEconomico.elementos,
                                CondicionDV39.elementos),
                            new XElement("DatosGenerales",
                                new XElement("FechaEmision", fechaEmision),
                                new XElement("FechaInicio", fechaInicio),
                                new XElement("FechaTermino", fechaTermino),
                                new XElement("Moneda", InfoEmision.Moneda),
                                new XElement("Agente", agente),
                                new XElement("FormaPago", formaPago),
                                new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                                new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                                new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                                new XElement("Plazo", null),
                                new XElement("Agencia", null),
                                new XElement("Contrato", null),
                                new XElement("PorcentajeDescuento", descuento),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "1"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", consideracionone2one)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "4"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                                (recargoPagoFraccionado > 0) ? null :
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "31"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", null)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "10"),
                                    new XElement("TipoRegla", "16"),
                                    new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "14"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", "A19397090200")),
                                    ConsideracionAG82.elementos,
                                    AplicaDeprec.elementos,
                                    ConsideracionCP.elementos,
                                    ConsinderacionCesionComision.elementos,
                                    DerechosPrimerRecibo.elementos,
                                    BeneficiarioPreferente.elementos,
                                    NumeroSegmento.elementos,
                                    NEmpleado.elementos,
                                    Facturacion4.elementos,
                                    cosideracion34.elementos,
                                    cosideracionLeapYear.elementos),
                            new XElement("Primas",
                                new XElement("PrimaNeta", null),
                                new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                                new XElement("Recargo", null),
                                new XElement("Impuesto", null),
                                new XElement("PrimaTotal", null),
                                new XElement("Comision", null)),
                            new XElement("CodigoError", null)
                            )
                    );
                }
                #endregion
                //Emision Deloitte
                #region DELOITTE
                else if (empresasDeloitte.Contains(InfoEmision.Convenio.IdEmpresa))
                {
                    esUsuarioFlotilla = true;
                    var sociedad = detalleUsuarioBeflex.Sociedad.Trim() == "S008" ? "S001" : detalleUsuarioBeflex.Sociedad.Trim();
                    var empresaDeloitte = db.EmpresaDeloitte.FirstOrDefault(a => a.Sociedad.Trim() == sociedad);
                    //var tipoIdentificacion = db.CatTipoIdentificacions.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdTipoIdentificacion);
                    var tipoIdentificacionEmpresa = db.CatTipoIdentificacions.FirstOrDefault(a => a.Id == empresaDeloitte.IdCatTipoIdentificacion);
                    //var giro = db.CatGiroBase.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdCatGiro);
                    var catEsado = db.CatEstadosRepublica.FirstOrDefault(a => a.Id == empresaDeloitte.IdCatEstadosRepublica_Nacimiento);
                    //empresaDeloitte.FechaConstitucion = new DateTime(1988, 1, 1);

                    NombrePoliza = empresaDeloitte.RazonSocial;
                    Movimientos =
                    new XElement("Movimientos",
                        new XElement("Movimiento",
                            new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                            new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                            new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                            new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                            new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                            new XAttribute("NoOTra", InfoEmision.NoOTra),
                            new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                            new XElement("DatosAsegurado",
                                new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                                new XElement("Nombre", NombrePoliza),
                                new XElement("Direccion", empresaDeloitte.Direccion.Calle),
                                new XElement("Colonia", empresaDeloitte.Direccion.Colonia),
                                new XElement("Poblacion", empresaDeloitte.Direccion.Municipio),
                                new XElement("Estado", empresaDeloitte.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                                new XElement("CodigoPostal", empresaDeloitte.Direccion.CodigoPostal),
                                new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                                new XElement("Agrupador", null),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", empresaDeloitte.Direccion.NumeroExt)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "2"),
                                    new XElement("ValorRegla", empresaDeloitte.Direccion.NumeroInt)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "4"),
                                    new XElement("ValorRegla", NombrePoliza)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "7"),
                                    new XElement("ValorRegla", empresaDeloitte.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "8"),
                                    new XElement("ValorRegla", empresaDeloitte.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "19"),
                                    new XElement("ValorRegla", "2")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "21"),
                                    new XElement("ValorRegla", "1")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "24"),
                                    new XElement("ValorRegla", empresaDeloitte.CatGiroBase.Clave)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "28"),
                                    new XElement("ValorRegla", empresaDeloitte.RFC)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "29"),
                                    new XElement("ValorRegla", empresaDeloitte.Actividad)),
                                      new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "32"),
                                    new XElement("ValorRegla", Convert.ToDateTime(empresaDeloitte.FechaConstitucion).ToString("dd/MM/yyyy"))),
                                    new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "34"),
                                    new XElement("ValorRegla", empresaDeloitte.NombreApoderado)),
                                      new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "35"),
                                    new XElement("ValorRegla", "001")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "57"),
                                    new XElement("ValorRegla", "N")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "59"),
                                    new XElement("ValorRegla", "N")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "62"),
                                    new XElement("ValorRegla", tipoIdentificacionEmpresa.Clave)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "63"),
                                    new XElement("ValorRegla", empresaDeloitte.NumeroIdentificacion)),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "65"),
                                    new XElement("ValorRegla", empresaDeloitte.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                   new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "66"),
                                    new XElement("ValorRegla", catEsado.Valor)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "70"),
                                    new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "72"),
                                    new XElement("ValorRegla", empresaDeloitte.FolioMercantil)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "11"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CodigoPostal)),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "12"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0'))),
                                   new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "13"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "14"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "16"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.Calle)),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "17"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.NumeroExt)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "36"),
                                    new XElement("ValorRegla", string.IsNullOrWhiteSpace(InfoEmision.SegundoNombre) ? InfoEmision.PrimerNombre : string.Concat(InfoEmision.PrimerNombre, " ", InfoEmision.SegundoNombre))),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "37"),
                                    new XElement("ValorRegla", InfoEmision.ApellidoPaterno)),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "38"),
                                    new XElement("ValorRegla", InfoEmision.ApellidoMaterno)),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "39"),
                                    new XElement("ValorRegla", "1")),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "40"),
                                    new XElement("ValorRegla", InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "41"),
                                    new XElement("ValorRegla", "1")),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "42"),
                                    new XElement("ValorRegla", "001")),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "43"),
                                    new XElement("ValorRegla", "5")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "44"),
                                    new XElement("ValorRegla", "42")),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "45"),
                                    new XElement("ValorRegla", "16")),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "47"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.CURP)),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "48"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.RFC)),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "73"),
                                    new XElement("ValorRegla", (cotizacion.IdCatGenero == 2 ? "M" : "H"))),
                                   new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "74"),
                                    new XElement("ValorRegla", "001")),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "80"),
                                    new XElement("ValorRegla", "N"))
                                    ),
                            new XElement("DatosVehiculo",
                                new XAttribute("NoInciso", InfoEmision.NoInciso),
                                new XElement("ClaveAmis", InfoEmision.Amis),
                                new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                                new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                                new XElement("Uso", InfoEmision.Vehiculo.Uso),
                                new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                                new XElement("Paquete", InfoEmision.Paquete),
                                new XElement("Motor", InfoEmision.Vehiculo.Motor),
                                new XElement("Serie", InfoEmision.Vehiculo.Serie),
                                coberturas.elementos.Select(x => x),
                                AplicaNumeroEconomico.elementos,
                                CondicionDV39.elementos),
                            new XElement("DatosGenerales",
                                new XElement("FechaEmision", fechaEmision),
                                new XElement("FechaInicio", fechaInicio),
                                new XElement("FechaTermino", fechaTermino),
                                new XElement("Moneda", InfoEmision.Moneda),
                                new XElement("Agente", agente),
                                new XElement("FormaPago", formaPago),
                                new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                                new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                                new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                                new XElement("Plazo", null),
                                new XElement("Agencia", null),
                                new XElement("Contrato", null),
                                new XElement("PorcentajeDescuento", descuento),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "1"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", consideracionone2one)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "4"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                                (recargoPagoFraccionado > 0) ? null :
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "31"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", null)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "10"),
                                    new XElement("TipoRegla", "16"),
                                    new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "14"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", "A19397090200")),
                                    ConsideracionAG82.elementos,
                                    AplicaDeprec.elementos,
                                    ConsideracionCP.elementos,
                                    ConsinderacionCesionComision.elementos,
                                    DerechosPrimerRecibo.elementos,
                                    BeneficiarioPreferente.elementos,
                                    NumeroSegmento.elementos,
                                    NEmpleado.elementos,
                                    Facturacion4.elementos,
                                    cosideracion34.elementos,
                                    cosideracionLeapYear.elementos),
                            new XElement("Primas",
                                new XElement("PrimaNeta", null),
                                new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                                new XElement("Recargo", null),
                                new XElement("Impuesto", null),
                                new XElement("PrimaTotal", null),
                                new XElement("Comision", null)),
                            new XElement("CodigoError", null)
                            )
                    );

                }
                #endregion

                #region Persona Moral
                //Asegurado la persona moral 
                else if (InfoEmision.IdTipoDeNegocio == 6 && InfoEmision.EmisionPersonaMoral) //Emision Persona Moral
                {
                    esUsuarioFlotilla = true;
                    InfoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoral.Id);
                    InfoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoralRepresentanteLegal.Id);
                    //var tipoIdentificacion = db.CatTipoIdentificacions.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdTipoIdentificacion);
                    //var giro = db.CatGiroBase.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdCatGiro);

                    NombrePoliza = InfoEmision.PersonaMoral.RazonSocial;
                    //- SIN Contratante 
                    if (string.IsNullOrEmpty(InfoEmision.PrimerNombre))
                    {
                        Movimientos =
                            new XElement("Movimientos",
                           new XElement("Movimiento",
                               new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                               new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                               new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                               new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                               new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                               new XAttribute("NoOTra", InfoEmision.NoOTra),
                               new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                               new XElement("DatosAsegurado",
                                   new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                                   new XElement("Nombre", NombrePoliza),
                                   new XElement("Direccion", InfoEmision.PersonaMoral.Direccion.Calle),
                                   new XElement("Colonia", InfoEmision.PersonaMoral.Direccion.Colonia),
                                   new XElement("Poblacion", InfoEmision.PersonaMoral.Direccion.Municipio),
                                   new XElement("Estado", InfoEmision.PersonaMoral.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                                   new XElement("CodigoPostal", InfoEmision.PersonaMoral.Direccion.CodigoPostal),
                                   new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                                   new XElement("Agrupador", null),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "1"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.NumeroExt)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "2"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.NumeroInt)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "3"),
                                       new XElement("ValorRegla", "MEXICO")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "4"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RazonSocial)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "7"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "8"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "19"),
                                       new XElement("ValorRegla", "2")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "21"),
                                       new XElement("ValorRegla", "1")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "24"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.CatGiroBase.Clave)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "28"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RFC)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "29"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Actividad)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "32"),
                                       new XElement("ValorRegla", Convert.ToDateTime(InfoEmision.PersonaMoral.FechaConstitucion).ToString("dd/MM/yyyy"))),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "34"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.ObtieneNombreCompleto())),
                                   new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "35"),
                                        new XElement("ValorRegla", "001")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "57"),
                                       new XElement("ValorRegla", InfoEmision.EsPersonaPoliticamenteExpuesta ? "S" : "N")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "59"),
                                        new XElement("ValorRegla", "N")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "62"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.CatTipoIdentificacion.Clave)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "63"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.NumeroIdentificacion)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "65"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "66"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.CatEstadosRepublica.Valor)),
                                    new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "70"),
                                       new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "72"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.FolioMercantil))
                                   ),
                               new XElement("DatosVehiculo",
                                   new XAttribute("NoInciso", InfoEmision.NoInciso),
                                   new XElement("ClaveAmis", InfoEmision.Amis),
                                   new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                                   new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                                   new XElement("Uso", InfoEmision.Vehiculo.Uso),
                                   new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                                   new XElement("Paquete", InfoEmision.Paquete),
                                   new XElement("Motor", InfoEmision.Vehiculo.Motor),
                                   new XElement("Serie", InfoEmision.Vehiculo.Serie),
                                   coberturas.elementos.Select(x => x),
                                   AplicaNumeroEconomico.elementos,
                                   CondicionDV39.elementos),
                               new XElement("DatosGenerales",
                                   new XElement("FechaEmision", fechaEmision),
                                   new XElement("FechaInicio", fechaInicio),
                                   new XElement("FechaTermino", fechaTermino),
                                   new XElement("Moneda", InfoEmision.Moneda),
                                   new XElement("Agente", agente),
                                   new XElement("FormaPago", formaPago),
                                   new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                                   new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                                   new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                                   new XElement("Plazo", null),
                                   new XElement("Agencia", null),
                                   new XElement("Contrato", null),
                                   new XElement("PorcentajeDescuento", descuento),
                                   new XElement("ConsideracionesAdicionalesDG",
                                       new XAttribute("NoConsideracion", "1"),
                                       new XElement("TipoRegla", "1"),
                                       new XElement("ValorRegla", consideracionone2one)),
                                   new XElement("ConsideracionesAdicionalesDG",
                                       new XAttribute("NoConsideracion", "4"),
                                       new XElement("TipoRegla", "1"),
                                       new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                                   (recargoPagoFraccionado > 0) ? null :
                                   new XElement("ConsideracionesAdicionalesDG",
                                       new XAttribute("NoConsideracion", "31"),
                                       new XElement("TipoRegla", "1"),
                                       new XElement("ValorRegla", null)),
                                   new XElement("ConsideracionesAdicionalesDG",
                                       new XAttribute("NoConsideracion", "10"),
                                       new XElement("TipoRegla", "16"),
                                       new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                                   new XElement("ConsideracionesAdicionalesDG",
                                       new XAttribute("NoConsideracion", "14"),
                                       new XElement("TipoRegla", "1"),
                                       new XElement("ValorRegla", "A19397090200")),
                                       ConsideracionAG82.elementos,
                                       AplicaDeprec.elementos,
                                       ConsideracionCP.elementos,
                                       ConsinderacionCesionComision.elementos,
                                       DerechosPrimerRecibo.elementos,
                                       BeneficiarioPreferente.elementos,
                                       NumeroSegmento.elementos,
                                       NEmpleado.elementos,
                                       Facturacion4.elementos,
                                       cosideracion34.elementos,
                                       cosideracionLeapYear.elementos),
                               new XElement("Primas",
                                   new XElement("PrimaNeta", null),
                                   new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                                   new XElement("Recargo", null),
                                   new XElement("Impuesto", null),
                                   new XElement("PrimaTotal", null),
                                   new XElement("Comision", null)),
                               new XElement("CodigoError", null)
                               )
                    );
                    }
                    else //Contratante Empleado - Conductor (Persona Fisica)
                    {

                        Movimientos =
                        new XElement("Movimientos",
                            new XElement("Movimiento",
                                new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                                new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                                new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                                new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                                new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                                new XAttribute("NoOTra", InfoEmision.NoOTra),
                                new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                                new XElement("DatosAsegurado",
                                    new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                                    new XElement("Nombre", NombrePoliza),
                                    new XElement("Direccion", InfoEmision.PersonaMoral.Direccion.Calle),
                                    new XElement("Colonia", InfoEmision.PersonaMoral.Direccion.Colonia),
                                    new XElement("Poblacion", InfoEmision.PersonaMoral.Direccion.Municipio),
                                    new XElement("Estado", InfoEmision.PersonaMoral.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                                    new XElement("CodigoPostal", InfoEmision.PersonaMoral.Direccion.CodigoPostal),
                                    new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                                    new XElement("Agrupador", null),
                                     new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "1"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.NumeroExt)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "2"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.NumeroInt)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "3"),
                                       new XElement("ValorRegla", "MEXICO")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "4"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RazonSocial)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "7"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "8"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "19"),
                                       new XElement("ValorRegla", "2")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "21"),
                                       new XElement("ValorRegla", "1")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "24"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.CatGiroBase.Clave)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "28"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RFC)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "29"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.Actividad)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "32"),
                                       new XElement("ValorRegla", Convert.ToDateTime(InfoEmision.PersonaMoral.FechaConstitucion).ToString("dd/MM/yyyy"))),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "34"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.ObtieneNombreCompleto())),
                                   new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "35"),
                                        new XElement("ValorRegla", "001")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "57"),
                                       new XElement("ValorRegla", InfoEmision.EsPersonaPoliticamenteExpuesta ? "S" : "N")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "59"),
                                        new XElement("ValorRegla", "N")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "62"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.CatTipoIdentificacion.TipoIdentificacion)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "63"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.NumeroIdentificacion)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "65"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                   new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "66"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.CatEstadosRepublica.Valor)),
                                    new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "70"),
                                       new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                       new XAttribute("NoConsideracion", "40"),
                                       new XElement("TipoRegla", "72"),
                                       new XElement("ValorRegla", InfoEmision.PersonaMoral.FolioMercantil)), //Empieza Contratante
                                    new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "11"),
                                        new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CodigoPostal)),
                                      new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "12"),
                                        new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0'))),
                                       new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "13"),
                                        new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                    new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "14"),
                                        new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                    new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "16"),
                                        new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.Calle)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "17"),
                                        new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.NumeroExt)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "36"),
                                        new XElement("ValorRegla", string.IsNullOrWhiteSpace(InfoEmision.SegundoNombre) ? InfoEmision.PrimerNombre : string.Concat(InfoEmision.PrimerNombre, " ", InfoEmision.SegundoNombre))),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "37"),
                                        new XElement("ValorRegla", InfoEmision.ApellidoPaterno)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "38"),
                                        new XElement("ValorRegla", InfoEmision.ApellidoMaterno)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "39"),
                                        new XElement("ValorRegla", "1")),
                                      new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "40"),
                                        new XElement("ValorRegla", InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                      new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "41"),
                                        new XElement("ValorRegla", "1")),
                                      new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "42"),
                                        new XElement("ValorRegla", "001")),
                                      new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "43"),
                                        new XElement("ValorRegla", "5")),
                                       new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "44"),
                                        new XElement("ValorRegla", "42")),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "45"),
                                        new XElement("ValorRegla", "16")),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "47"),
                                        new XElement("ValorRegla", InfoEmision.DatosUsuario.CURP)),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "48"),
                                        new XElement("ValorRegla", InfoEmision.DatosUsuario.RFC)),
                                      new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "73"),
                                        new XElement("ValorRegla", (cotizacion.IdCatGenero == 2 ? "M" : "H"))),
                                       new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "74"),
                                        new XElement("ValorRegla", "001")),
                                     new XElement("ConsideracionesAdicionalesDA",
                                        new XAttribute("NoConsideracion", "40"),
                                        new XElement("TipoRegla", "80"),
                                        new XElement("ValorRegla", "N"))
                                       ),
                                new XElement("DatosVehiculo",
                                    new XAttribute("NoInciso", InfoEmision.NoInciso),
                                    new XElement("ClaveAmis", InfoEmision.Amis),
                                    new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                                    new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                                    new XElement("Uso", InfoEmision.Vehiculo.Uso),
                                    new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                                    new XElement("Paquete", InfoEmision.Paquete),
                                    new XElement("Motor", InfoEmision.Vehiculo.Motor),
                                    new XElement("Serie", InfoEmision.Vehiculo.Serie),
                                    coberturas.elementos.Select(x => x),
                                    AplicaNumeroEconomico.elementos,
                                    CondicionDV39.elementos),
                                new XElement("DatosGenerales",
                                    new XElement("FechaEmision", fechaEmision),
                                    new XElement("FechaInicio", fechaInicio),
                                    new XElement("FechaTermino", fechaTermino),
                                    new XElement("Moneda", InfoEmision.Moneda),
                                    new XElement("Agente", agente),
                                    new XElement("FormaPago", formaPago),
                                    new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                                    new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                                    new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                                    new XElement("Plazo", null),
                                    new XElement("Agencia", null),
                                    new XElement("Contrato", null),
                                    new XElement("PorcentajeDescuento", descuento),
                                    new XElement("ConsideracionesAdicionalesDG",
                                        new XAttribute("NoConsideracion", "1"),
                                        new XElement("TipoRegla", "1"),
                                        new XElement("ValorRegla", consideracionone2one)),
                                    new XElement("ConsideracionesAdicionalesDG",
                                        new XAttribute("NoConsideracion", "4"),
                                        new XElement("TipoRegla", "1"),
                                        new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                                    (recargoPagoFraccionado > 0) ? null :
                                    new XElement("ConsideracionesAdicionalesDG",
                                        new XAttribute("NoConsideracion", "31"),
                                        new XElement("TipoRegla", "1"),
                                        new XElement("ValorRegla", null)),
                                    new XElement("ConsideracionesAdicionalesDG",
                                        new XAttribute("NoConsideracion", "10"),
                                        new XElement("TipoRegla", "16"),
                                        new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                                    new XElement("ConsideracionesAdicionalesDG",
                                        new XAttribute("NoConsideracion", "14"),
                                        new XElement("TipoRegla", "1"),
                                        new XElement("ValorRegla", "A19397090200")),
                                        ConsideracionAG82.elementos,
                                        AplicaDeprec.elementos,
                                        ConsideracionCP.elementos,
                                        ConsinderacionCesionComision.elementos,
                                        DerechosPrimerRecibo.elementos,
                                        BeneficiarioPreferente.elementos,
                                        NumeroSegmento.elementos,
                                        NEmpleado.elementos,
                                        Facturacion4.elementos,
                                        cosideracion34.elementos,
                                        cosideracionLeapYear.elementos),
                                new XElement("Primas",
                                    new XElement("PrimaNeta", null),
                                    new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                                    new XElement("Recargo", null),
                                    new XElement("Impuesto", null),
                                    new XElement("PrimaTotal", null),
                                    new XElement("Comision", null)),
                                new XElement("CodigoError", null)
                                )
                        );
                    }

                }

                else if (InfoEmision.IdTipoDeNegocio == 5 && InfoEmision.EmisionPersonaMoral) //Emision Persona Moral - menos campos
                {
                    esUsuarioFlotilla = true;
                    InfoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoral.Id);
                    InfoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoralRepresentanteLegal.Id);
                    //var tipoIdentificacion = db.CatTipoIdentificacions.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdTipoIdentificacion);
                    //var giro = db.CatGiroBase.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdCatGiro);

                    NombrePoliza = InfoEmision.PersonaMoral.RazonSocial;
                    //- SIN Contratante 

                    Movimientos =
                        new XElement("Movimientos",
                       new XElement("Movimiento",
                           new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                           new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                           new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                           new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                           new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                           new XAttribute("NoOTra", InfoEmision.NoOTra),
                           new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                           new XElement("DatosAsegurado",
                               new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                               new XElement("Nombre", NombrePoliza),
                               new XElement("Direccion", InfoEmision.PersonaMoral.Direccion.Calle),
                               new XElement("Colonia", InfoEmision.PersonaMoral.Direccion.Colonia),
                               new XElement("Poblacion", InfoEmision.PersonaMoral.Direccion.Municipio),
                               new XElement("Estado", InfoEmision.PersonaMoral.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                               new XElement("CodigoPostal", InfoEmision.PersonaMoral.Direccion.CodigoPostal),
                               new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                               new XElement("Agrupador", null),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "1"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.NumeroExt)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "2"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.NumeroInt)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "3"),
                                   new XElement("ValorRegla", "MEXICO")),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "4"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.RazonSocial)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "7"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "8"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "19"),
                                   new XElement("ValorRegla", "2")),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "21"),
                                   new XElement("ValorRegla", "1")),
                                new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "24"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.CatGiroBase.Clave)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "28"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.RFC)),
                                 new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "29"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.Actividad)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "32"),
                                   new XElement("ValorRegla", Convert.ToDateTime(InfoEmision.PersonaMoral.FechaConstitucion).ToString("dd/MM/yyyy"))),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "34"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.ObtieneNombreCompleto())),
                               new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "35"),
                                    new XElement("ValorRegla", "001")),
                                new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "57"),
                                   new XElement("ValorRegla", InfoEmision.EsPersonaPoliticamenteExpuesta ? "S" : "N")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "59"),
                                    new XElement("ValorRegla", "N")),
                                new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "62"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.CatTipoIdentificacion.Clave)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "63"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.NumeroIdentificacion)),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "65"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yyyy"))),
                               new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "66"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.RepresentanteLegal.CatEstadosRepublica.Valor)),
                                new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "70"),
                                   new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                                 new XElement("ConsideracionesAdicionalesDA",
                                   new XAttribute("NoConsideracion", "40"),
                                   new XElement("TipoRegla", "72"),
                                   new XElement("ValorRegla", InfoEmision.PersonaMoral.FolioMercantil))
                               ),
                           new XElement("DatosVehiculo",
                               new XAttribute("NoInciso", InfoEmision.NoInciso),
                               new XElement("ClaveAmis", InfoEmision.Amis),
                               new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                               new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                               new XElement("Uso", InfoEmision.Vehiculo.Uso),
                               new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                               new XElement("Paquete", InfoEmision.Paquete),
                               new XElement("Motor", InfoEmision.Vehiculo.Motor),
                               new XElement("Serie", InfoEmision.Vehiculo.Serie),
                               coberturas.elementos.Select(x => x),
                               AplicaNumeroEconomico.elementos,
                               CondicionDV39.elementos),
                           new XElement("DatosGenerales",
                               new XElement("FechaEmision", fechaEmision),
                               new XElement("FechaInicio", fechaInicio),
                               new XElement("FechaTermino", fechaTermino),
                               new XElement("Moneda", InfoEmision.Moneda),
                               new XElement("Agente", agente),
                               new XElement("FormaPago", formaPago),
                               new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                               new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                               new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                               new XElement("Plazo", null),
                               new XElement("Agencia", null),
                               new XElement("Contrato", null),
                               new XElement("PorcentajeDescuento", descuento),
                               new XElement("ConsideracionesAdicionalesDG",
                                   new XAttribute("NoConsideracion", "1"),
                                   new XElement("TipoRegla", "1"),
                                   new XElement("ValorRegla", consideracionone2one)),
                               new XElement("ConsideracionesAdicionalesDG",
                                   new XAttribute("NoConsideracion", "4"),
                                   new XElement("TipoRegla", "1"),
                                   new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                               (recargoPagoFraccionado > 0) ? null :
                               new XElement("ConsideracionesAdicionalesDG",
                                   new XAttribute("NoConsideracion", "31"),
                                   new XElement("TipoRegla", "1"),
                                   new XElement("ValorRegla", null)),
                               new XElement("ConsideracionesAdicionalesDG",
                                   new XAttribute("NoConsideracion", "10"),
                                   new XElement("TipoRegla", "16"),
                                   new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                               new XElement("ConsideracionesAdicionalesDG",
                                   new XAttribute("NoConsideracion", "14"),
                                   new XElement("TipoRegla", "1"),
                                   new XElement("ValorRegla", "A19397090200")),
                                   ConsideracionAG82.elementos,
                                   AplicaDeprec.elementos,
                                   ConsideracionCP.elementos,
                                   ConsinderacionCesionComision.elementos,
                                   DerechosPrimerRecibo.elementos,
                                   BeneficiarioPreferente.elementos,
                                   NumeroSegmento.elementos,
                                   NEmpleado.elementos,
                                   Facturacion4.elementos,
                                   cosideracion34.elementos,
                                   cosideracionLeapYear.elementos),
                           new XElement("Primas",
                               new XElement("PrimaNeta", null),
                               new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                               new XElement("Recargo", null),
                               new XElement("Impuesto", null),
                               new XElement("PrimaTotal", null),
                               new XElement("Comision", null)),
                           new XElement("CodigoError", null)
                           )
                );



                }
                #endregion


                #region Flotilla Datos Fiscales Empresa
                //Asegurado Empresa (Persona Moral) / Sin Contratante
                else if (InfoEmision.Convenio.IdCatTipoContratante == 1)
                {
                    NombrePoliza = InfoEmision.Empresa.RazonSocial;
                    ConsideracionAG82 = new XmlCobertura();

                    Movimientos =
                    new XElement("Movimientos",
                        new XElement("Movimiento",
                            new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                            new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                            new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                            new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                            new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                            new XAttribute("NoOTra", InfoEmision.NoOTra),
                            new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                            new XElement("DatosAsegurado", // Asegurado persona moral empresa - Sin Contratante
                                new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                                new XElement("Nombre", NombrePoliza),
                                new XElement("Direccion", InfoEmision.Empresa.Direccion.Calle),
                                new XElement("Colonia", InfoEmision.Empresa.Direccion.Colonia),
                                new XElement("Poblacion", InfoEmision.Empresa.Direccion.Municipio),
                                new XElement("Estado", InfoEmision.Empresa.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                                new XElement("CodigoPostal", InfoEmision.Empresa.Direccion.CodigoPostal),
                                new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                                new XElement("Agrupador", null), //Asegurado
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.NumeroExt)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "2"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.NumeroInt)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "3"),
                                    new XElement("ValorRegla", "MEXICO")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "4"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.RazonSocial)),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "7"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "8"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "19"),
                                    new XElement("ValorRegla", "2")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "21"),
                                    new XElement("ValorRegla", "1")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "24"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.CatGiroBase.Clave)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "28"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.RFC)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "29"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.Actividad)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "32"),
                                    new XElement("ValorRegla", Convert.ToDateTime(InfoEmision.Empresa.FechaConstitucion).ToString("dd/MM/yyyy"))),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "34"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.ObtieneNombreCompleto())),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "35"),
                                    new XElement("ValorRegla", "001")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "57"),
                                    new XElement("ValorRegla", InfoEmision.EsPersonaPoliticamenteExpuesta ? "S" : "N")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "59"),
                                    new XElement("ValorRegla", "N")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "62"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.CatTipoIdentificacion.Clave)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "63"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.NumeroIdentificacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "65"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "66"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.CatEstadosRepublica.Valor)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "70"),
                                    new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "72"),
                                    new XElement("ValorRegla", InfoEmision.Empresa.FolioMercantil))
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "64"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatEstadosRepublica.Valor)),                                                                                                                            
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "67"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.CatPais.Pais)),                                                                
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "11"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.Codigo)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "12"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdEstadoCotizacion)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "13"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "14"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "16"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.Calle)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "17"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.Direccion.NumeroExt)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "36"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.RazonSocial)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "39"),
                                 //    new XElement("ValorRegla", "2"),
                                 //      new XElement("ValorRegla", InfoEmision.Empresa.RazonSocial)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "41"),
                                 //    new XElement("ValorRegla", "1")),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "44"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.CatGiroBase.Clave)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "49"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.Actividad)),                               
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "48"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.RFC)),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "52"),
                                 //    new XElement("ValorRegla", Convert.ToDateTime(InfoEmision.Empresa.FechaConstitucion).ToString("dd/MM/yyyy"))),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "54"),
                                 //    new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.ObtieneNombreCompleto())),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "15"),
                                 //    new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                                 // new XElement("ConsideracionesAdicionalesDA",
                                 //    new XAttribute("NoConsideracion", "40"),
                                 //    new XElement("TipoRegla", "55"),
                                 //    new XElement("ValorRegla", "001"))
                                 ),
                            new XElement("DatosVehiculo",
                                new XAttribute("NoInciso", InfoEmision.NoInciso),
                                new XElement("ClaveAmis", InfoEmision.Amis),
                                new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                                new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                                new XElement("Uso", InfoEmision.Vehiculo.Uso),
                                new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                                new XElement("Paquete", InfoEmision.Paquete),
                                new XElement("Motor", InfoEmision.Vehiculo.Motor),
                                new XElement("Serie", InfoEmision.Vehiculo.Serie),
                                coberturas.elementos.Select(x => x),
                                AplicaNumeroEconomico.elementos,
                                CondicionDV39.elementos),
                            new XElement("DatosGenerales",
                                new XElement("FechaEmision", fechaEmision),
                                new XElement("FechaInicio", fechaInicio),
                                new XElement("FechaTermino", fechaTermino),
                                new XElement("Moneda", InfoEmision.Moneda),
                                new XElement("Agente", agente),
                                new XElement("FormaPago", formaPago),
                                new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                                new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                                new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                                new XElement("Plazo", null),
                                new XElement("Agencia", null),
                                new XElement("Contrato", null),
                                new XElement("PorcentajeDescuento", descuento),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "1"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", consideracionone2one)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "4"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                                (recargoPagoFraccionado > 0) ? null :
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "31"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", null)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "10"),
                                    new XElement("TipoRegla", "16"),
                                    new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "14"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", "A19397090200")),
                                    ConsideracionAG82.elementos,
                                    AplicaDeprec.elementos,
                                    ConsideracionCP.elementos,
                                    ConsinderacionCesionComision.elementos,
                                    DerechosPrimerRecibo.elementos,
                                    BeneficiarioPreferente.elementos,
                                    NumeroSegmento.elementos,
                                    NEmpleado.elementos,
                                    Facturacion4.elementos,
                                    cosideracion34.elementos,
                                    cosideracionLeapYear.elementos),
                            new XElement("Primas",
                                new XElement("PrimaNeta", null),
                                new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                                new XElement("Recargo", null),
                                new XElement("Impuesto", null),
                                new XElement("PrimaTotal", null),
                                new XElement("Comision", null)),
                            new XElement("CodigoError", null)
                            )
                    );
                }
                #endregion

                #region Flotilla Datos Fiscales Empresa y Empleado
                //Asegurado es persona moral la empresa, contratante empleado (Persona Fisica)
                else if (esUsuarioFlotilla)
                {
                    NombrePoliza = InfoEmision.Empresa.RazonSocial;
                    //DESCUENTO POR NOMINA O DEPOSITO BANCARIO
                    //EL QUE REALIZA EL PAGO ES LA EMPRESA
                    if (cotizacionDetalle.IdMedioPago == 3 || cotizacionDetalle.IdMedioPago == 5 || InfoEmision.IdTipoDeNegocio == 4)
                    {
                        Movimientos =
                  new XElement("Movimientos",
                      new XElement("Movimiento",
                          new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                          new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                          new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                          new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                          new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                          new XAttribute("NoOTra", InfoEmision.NoOTra),
                          new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                          new XElement("DatosAsegurado",
                              new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                              new XElement("Nombre", NombrePoliza),
                              new XElement("Direccion", InfoEmision.Empresa.Direccion.Calle),
                              new XElement("Colonia", InfoEmision.Empresa.Direccion.Colonia),
                              new XElement("Poblacion", InfoEmision.Empresa.Direccion.Municipio),
                              new XElement("Estado", InfoEmision.Empresa.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                              new XElement("CodigoPostal", InfoEmision.Empresa.Direccion.CodigoPostal),
                              new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                              new XElement("Agrupador", null),
                               new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Direccion.NumeroExt)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "2"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Direccion.NumeroInt)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "3"),
                                  new XElement("ValorRegla", "MEXICO")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "4"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RazonSocial)),
                               new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "7"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "8"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "19"),
                                  new XElement("ValorRegla", "2")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "21"),
                                  new XElement("ValorRegla", "1")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "24"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.CatGiroBase.Clave)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "28"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RFC)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "29"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Actividad)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "32"),
                                  new XElement("ValorRegla", Convert.ToDateTime(InfoEmision.Empresa.FechaConstitucion).ToString("dd/MM/yyyy"))),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "34"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.ObtieneNombreCompleto())),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "35"),
                                  new XElement("ValorRegla", "001")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "57"),
                                  new XElement("ValorRegla", InfoEmision.EsPersonaPoliticamenteExpuesta ? "S" : "N")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "59"),
                                  new XElement("ValorRegla", "N")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "62"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.CatTipoIdentificacion.Clave)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "63"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.NumeroIdentificacion)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "65"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yyyy"))),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "66"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.CatEstadosRepublica.Valor)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "70"),
                                  new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "72"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.FolioMercantil))
                                   ),
                          new XElement("DatosVehiculo",
                              new XAttribute("NoInciso", InfoEmision.NoInciso),
                              new XElement("ClaveAmis", InfoEmision.Amis),
                              new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                              new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                              new XElement("Uso", InfoEmision.Vehiculo.Uso),
                              new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                              new XElement("Paquete", InfoEmision.Paquete),
                              new XElement("Motor", InfoEmision.Vehiculo.Motor),
                              new XElement("Serie", InfoEmision.Vehiculo.Serie),
                              coberturas.elementos.Select(x => x),
                              AplicaNumeroEconomico.elementos,
                              CondicionDV39.elementos),
                          new XElement("DatosGenerales",
                              new XElement("FechaEmision", fechaEmision),
                              new XElement("FechaInicio", fechaInicio),
                              new XElement("FechaTermino", fechaTermino),
                              new XElement("Moneda", InfoEmision.Moneda),
                              new XElement("Agente", agente),
                              new XElement("FormaPago", formaPago),
                              new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                              new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                              new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                              new XElement("Plazo", null),
                              new XElement("Agencia", null),
                              new XElement("Contrato", null),
                              new XElement("PorcentajeDescuento", descuento),
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "1"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", consideracionone2one)),
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "4"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                              (recargoPagoFraccionado > 0) ? null :
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "31"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", null)),
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "10"),
                                  new XElement("TipoRegla", "16"),
                                  new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "14"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", "A19397090200")),
                                  ConsideracionAG82.elementos,
                                  AplicaDeprec.elementos,
                                  ConsideracionCP.elementos,
                                  ConsinderacionCesionComision.elementos,
                                  DerechosPrimerRecibo.elementos,
                                  BeneficiarioPreferente.elementos,
                                  NumeroSegmento.elementos,
                                  NEmpleado.elementos,
                                  Facturacion4.elementos,
                                  cosideracion34.elementos,
                                  cosideracionLeapYear.elementos),
                          new XElement("Primas",
                              new XElement("PrimaNeta", null),
                              new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                              new XElement("Recargo", null),
                              new XElement("Impuesto", null),
                              new XElement("PrimaTotal", null),
                              new XElement("Comision", null)),
                          new XElement("CodigoError", null)
                          )
                  );
                    }
                    else
                    {
                        Movimientos =
                  new XElement("Movimientos",
                      new XElement("Movimiento",
                          new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                          new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                          new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                          new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                          new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                          new XAttribute("NoOTra", InfoEmision.NoOTra),
                          new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                          new XElement("DatosAsegurado",
                              new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                              new XElement("Nombre", NombrePoliza),
                              new XElement("Direccion", InfoEmision.Empresa.Direccion.Calle),
                              new XElement("Colonia", InfoEmision.Empresa.Direccion.Colonia),
                              new XElement("Poblacion", InfoEmision.Empresa.Direccion.Municipio),
                              new XElement("Estado", InfoEmision.Empresa.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                              new XElement("CodigoPostal", InfoEmision.Empresa.Direccion.CodigoPostal),
                              new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                              new XElement("Agrupador", null),
                               new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Direccion.NumeroExt)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "2"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Direccion.NumeroInt)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "3"),
                                  new XElement("ValorRegla", "MEXICO")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "4"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RazonSocial)),
                               new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "7"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "8"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "19"),
                                  new XElement("ValorRegla", "2")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "21"),
                                  new XElement("ValorRegla", "1")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "24"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.CatGiroBase.Clave)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "28"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RFC)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "29"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.Actividad)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "32"),
                                  new XElement("ValorRegla", Convert.ToDateTime(InfoEmision.Empresa.FechaConstitucion).ToString("dd/MM/yyyy"))),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "34"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.ObtieneNombreCompleto())),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "35"),
                                  new XElement("ValorRegla", "001")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "57"),
                                  new XElement("ValorRegla", InfoEmision.EsPersonaPoliticamenteExpuesta ? "S" : "N")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "59"),
                                  new XElement("ValorRegla", "N")),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "62"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.CatTipoIdentificacion.TipoIdentificacion)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "63"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.NumeroIdentificacion)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "65"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yyyy"))),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "66"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.RepresentanteLegal.CatEstadosRepublica.Valor)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "70"),
                                  new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                              new XElement("ConsideracionesAdicionalesDA",
                                  new XAttribute("NoConsideracion", "40"),
                                  new XElement("TipoRegla", "72"),
                                  new XElement("ValorRegla", InfoEmision.Empresa.FolioMercantil)),//CONTRATANTE EMPLEADO - CONDUCTOR
                                new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "11"),
                                      new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CodigoPostal)),
                                    new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "12"),
                                      new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0'))),
                                     new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "13"),
                                      new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                  new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "14"),
                                      new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                  new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "16"),
                                      new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.Calle)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "17"),
                                      new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.NumeroExt)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "36"),
                                      new XElement("ValorRegla", string.IsNullOrWhiteSpace(InfoEmision.SegundoNombre) ? InfoEmision.PrimerNombre : string.Concat(InfoEmision.PrimerNombre, " ", InfoEmision.SegundoNombre))),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "37"),
                                      new XElement("ValorRegla", InfoEmision.ApellidoPaterno)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "38"),
                                      new XElement("ValorRegla", InfoEmision.ApellidoMaterno)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "39"),
                                      new XElement("ValorRegla", "1")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "40"),
                                      new XElement("ValorRegla", InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                    new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "41"),
                                      new XElement("ValorRegla", "1")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "42"),
                                      new XElement("ValorRegla", "001")),
                                    new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "43"),
                                      new XElement("ValorRegla", "5")),
                                     new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "44"),
                                      new XElement("ValorRegla", "42")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "45"),
                                      new XElement("ValorRegla", "16")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "47"),
                                      new XElement("ValorRegla", InfoEmision.DatosUsuario.CURP)),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "48"),
                                      new XElement("ValorRegla", InfoEmision.DatosUsuario.RFC)),
                                    new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "73"),
                                      new XElement("ValorRegla", (cotizacion.IdCatGenero == 2 ? "M" : "H"))),
                                     new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "74"),
                                      new XElement("ValorRegla", "001")),
                                   new XElement("ConsideracionesAdicionalesDA",
                                      new XAttribute("NoConsideracion", "40"),
                                      new XElement("TipoRegla", "80"),
                                      new XElement("ValorRegla", "N"))
                                   ),
                          new XElement("DatosVehiculo",
                              new XAttribute("NoInciso", InfoEmision.NoInciso),
                              new XElement("ClaveAmis", InfoEmision.Amis),
                              new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                              new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                              new XElement("Uso", InfoEmision.Vehiculo.Uso),
                              new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                              new XElement("Paquete", InfoEmision.Paquete),
                              new XElement("Motor", InfoEmision.Vehiculo.Motor),
                              new XElement("Serie", InfoEmision.Vehiculo.Serie),
                              coberturas.elementos.Select(x => x),
                              AplicaNumeroEconomico.elementos,
                              CondicionDV39.elementos),
                          new XElement("DatosGenerales",
                              new XElement("FechaEmision", fechaEmision),
                              new XElement("FechaInicio", fechaInicio),
                              new XElement("FechaTermino", fechaTermino),
                              new XElement("Moneda", InfoEmision.Moneda),
                              new XElement("Agente", agente),
                              new XElement("FormaPago", formaPago),
                              new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                              new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                              new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                              new XElement("Plazo", null),
                              new XElement("Agencia", null),
                              new XElement("Contrato", null),
                              new XElement("PorcentajeDescuento", descuento),
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "1"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", consideracionone2one)),
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "4"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                              (recargoPagoFraccionado > 0) ? null :
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "31"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", null)),
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "10"),
                                  new XElement("TipoRegla", "16"),
                                  new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                              new XElement("ConsideracionesAdicionalesDG",
                                  new XAttribute("NoConsideracion", "14"),
                                  new XElement("TipoRegla", "1"),
                                  new XElement("ValorRegla", "A19397090200")),
                                  ConsideracionAG82.elementos,
                                  AplicaDeprec.elementos,
                                  ConsideracionCP.elementos,
                                  ConsinderacionCesionComision.elementos,
                                  DerechosPrimerRecibo.elementos,
                                  BeneficiarioPreferente.elementos,
                                  NumeroSegmento.elementos,
                                  NEmpleado.elementos,
                                  Facturacion4.elementos,
                                  cosideracion34.elementos,
                                  cosideracionLeapYear.elementos),
                          new XElement("Primas",
                              new XElement("PrimaNeta", null),
                              new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                              new XElement("Recargo", null),
                              new XElement("Impuesto", null),
                              new XElement("PrimaTotal", null),
                              new XElement("Comision", null)),
                          new XElement("CodigoError", null)
                          )
                  );

                    }

                }
                #endregion

                #region Individuales - Persona Fisica
                //Asegurado Empleado - Conductor (Persona Fisica) / Sin Contratante
                else
                {
                    ConsideracionAG82 = new XmlCobertura();

                    //var tipoIdentificacion = db.CatTipoIdentificacions.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdTipoIdentificacion);
                    var giro = db.CatGiroBase.FirstOrDefault(a => a.Id == InfoEmision.DatosUsuario.IdCatGiro);

                    var idOcupacion = InfoEmision.DatosUsuario.IdCatOcupacion;
                    var idProfecion = InfoEmision.DatosUsuario.IdCatProfesion;

                    if (idOcupacion == 0)
                        idOcupacion = 2;

                    if (idProfecion == 0)
                        idProfecion = 16;

                    esUsuarioFlotilla = false;
                    Movimientos =
                    new XElement("Movimientos",
                        new XElement("Movimiento",
                            new XAttribute("TipoMovimiento", InfoEmision.TipoMovimiento),
                            new XAttribute("NoPoliza", InfoEmision.NoPoliza),
                            new XAttribute("NoCotizacion", InfoEmision.NoCotizacion),
                            new XAttribute("NoEndoso", InfoEmision.NoEndoso),
                            new XAttribute("TipoEndoso", InfoEmision.TipoEndoso),
                            new XAttribute("NoOTra", InfoEmision.NoOTra),
                            new XAttribute("NoNegocio", InfoEmision.NoNegocio),
                            new XElement("DatosAsegurado",
                                new XAttribute("NoAsegurado", InfoEmision.NoAsegurado),
                                new XElement("Nombre", InfoEmision.ObtieneNombreCompleto()),
                                new XElement("Direccion", InfoEmision.DatosUsuario.Direccion.Calle),
                                new XElement("Colonia", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento),
                                new XElement("Poblacion", InfoEmision.DatosUsuario.Direccion.Municipio),
                                new XElement("Estado", InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0')),
                                new XElement("CodigoPostal", InfoEmision.DatosUsuario.Direccion.CodigoPostal),
                                new XElement("NoEmpleado", (!string.IsNullOrEmpty(InfoEmision.NumeroEmpleado) ? InfoEmision.NumeroEmpleado : !string.IsNullOrEmpty(InfoEmision.NoEmpleado) ? InfoEmision.NoEmpleado : "")),
                                new XElement("Agrupador", null),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.NumeroExt)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "2"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.NumeroInt)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "3"),
                                    new XElement("ValorRegla", "MEXICO")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "4"),
                                    new XElement("ValorRegla", string.IsNullOrWhiteSpace(InfoEmision.SegundoNombre) ? InfoEmision.PrimerNombre : string.Concat(InfoEmision.PrimerNombre, " ", InfoEmision.SegundoNombre))),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "5"),
                                    new XElement("ValorRegla", InfoEmision.ApellidoPaterno)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "6"),
                                    new XElement("ValorRegla", InfoEmision.ApellidoMaterno)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "7"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "8"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "19"),
                                    new XElement("ValorRegla", "1")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "20"),
                                    new XElement("ValorRegla", InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "21"),
                                    new XElement("ValorRegla", "1")),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "22"),
                                    new XElement("ValorRegla", "001")),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "23"),
                                    new XElement("ValorRegla", idOcupacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "24"),
                                    new XElement("ValorRegla", giro == null ? "42" : giro.Clave)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "25"),
                                    new XElement("ValorRegla", idProfecion)),
                                  new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "26"),
                                    new XElement("ValorRegla", InfoEmision.Email)),
                                //new XElement("ConsideracionesAdicionalesDA",
                                //	new XAttribute("NoConsideracion", "40"),
                                //	new XElement("TipoRegla", "27"),
                                //	new XElement("ValorRegla", InfoEmision.DatosUsuario.CURP)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "28"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.RFC)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "56"),
                                    new XElement("ValorRegla", (cotizacion.IdCatGenero == 2 ? "M" : "H"))),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //	new XAttribute("NoConsideracion", "40"),
                                 //	new XElement("TipoRegla", "57"),
                                 //	new XElement("ValorRegla", ("N"))),
                                 //new XElement("ConsideracionesAdicionalesDA",
                                 //	new XAttribute("NoConsideracion", "40"),
                                 //	new XElement("TipoRegla", "58"),
                                 //	new XElement("ValorRegla", (""))),
                                 new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "59"),
                                    new XElement("ValorRegla", (InfoEmision.DatosUsuario.RegimenFiscalEmpresarial ? "S" : "N"))),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "62"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.IdTipoIdentificacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "63"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.NumeroIdentificacion)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "70"),
                                    new XElement("ValorRegla", InfoEmision.TelefonoCel)),
                                new XElement("ConsideracionesAdicionalesDA",
                                    new XAttribute("NoConsideracion", "40"),
                                    new XElement("TipoRegla", "78"),
                                    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Valor))
                                    //new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "11"),
                                    //    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CodigoPostal)),
                                    //  new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "12"),
                                    //    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave.ToString().PadLeft(2, '0'))),
                                    //   new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "13"),
                                    //    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdCiudadCotizacion)),
                                    //new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "14"),
                                    //    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.IdMunicipioCotizacion)),
                                    //new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "16"),
                                    //    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.Calle)),
                                    // new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "17"),
                                    //    new XElement("ValorRegla", InfoEmision.DatosUsuario.Direccion.NumeroExt)),
                                    //   new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "36"),
                                    //    new XElement("ValorRegla", string.IsNullOrWhiteSpace(InfoEmision.SegundoNombre) ? InfoEmision.PrimerNombre : string.Concat(InfoEmision.PrimerNombre, " ", InfoEmision.SegundoNombre))),
                                    // new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "37"),
                                    //    new XElement("ValorRegla", InfoEmision.ApellidoPaterno)),
                                    // new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "38"),
                                    //    new XElement("ValorRegla", InfoEmision.ApellidoMaterno)),
                                    // new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "39"),
                                    //    new XElement("ValorRegla", "1")),
                                    //  new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "40"),
                                    //    new XElement("ValorRegla", InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy"))),
                                    //  new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "41"),
                                    //    new XElement("ValorRegla", "1")),
                                    //  new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "42"),
                                    //    new XElement("ValorRegla", "001")),
                                    //  new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "43"),
                                    //    new XElement("ValorRegla", "5")),
                                    //   new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "44"),
                                    //    new XElement("ValorRegla", "42")),
                                    // new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "45"),
                                    //    new XElement("ValorRegla", "16")),
                                    // new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "48"),
                                    //    new XElement("ValorRegla", InfoEmision.DatosUsuario.RFC)),
                                    //  new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "73"),
                                    //    new XElement("ValorRegla", (cotizacion.IdCatGenero == 2 ? "M" : "H"))),
                                    //   new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "74"),
                                    //    new XElement("ValorRegla", "001")),
                                    // new XElement("ConsideracionesAdicionalesDA",
                                    //    new XAttribute("NoConsideracion", "40"),
                                    //    new XElement("TipoRegla", "80"),
                                    //    new XElement("ValorRegla", "N"))
                                    ),
                            new XElement("DatosVehiculo",
                                new XAttribute("NoInciso", InfoEmision.NoInciso),
                                new XElement("ClaveAmis", InfoEmision.Amis),
                                new XElement("Modelo", InfoEmision.Vehiculo.Modelo),
                                new XElement("DescripcionVehiculo", InfoEmision.Vehiculo.Descripcion),
                                new XElement("Uso", InfoEmision.Vehiculo.Uso),
                                new XElement("Servicio", InfoEmision.Vehiculo.Servicio),
                                new XElement("Paquete", InfoEmision.Paquete),
                                new XElement("Motor", InfoEmision.Vehiculo.Motor),
                                new XElement("Serie", InfoEmision.Vehiculo.Serie),
                                coberturas.elementos.Select(x => x),
                                AplicaNumeroEconomico.elementos,
                                CondicionDV39.elementos),
                            new XElement("DatosGenerales",
                                new XElement("FechaEmision", fechaEmision),
                                new XElement("FechaInicio", fechaInicio),
                                new XElement("FechaTermino", fechaTermino),
                                new XElement("Moneda", InfoEmision.Moneda),
                                new XElement("Agente", agente),
                                new XElement("FormaPago", formaPago),
                                new XElement("TarifaValores", InfoEmision.Convenio.Tarifa),
                                new XElement("TarifaCuotas", InfoEmision.Convenio.Tarifa),
                                new XElement("TarifaDerechos", InfoEmision.Convenio.Tarifa),
                                new XElement("Plazo", null),
                                new XElement("Agencia", null),
                                new XElement("Contrato", null),
                                new XElement("PorcentajeDescuento", descuento),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "1"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", consideracionone2one)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "4"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", pruebasProd ? "0" : "1")),
                                (recargoPagoFraccionado > 0) ? null :
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "31"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", null)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "10"),
                                    new XElement("TipoRegla", "16"),
                                    new XElement("ValorRegla", InfoEmision.Vehiculo.Placas)),
                                new XElement("ConsideracionesAdicionalesDG",
                                    new XAttribute("NoConsideracion", "14"),
                                    new XElement("TipoRegla", "1"),
                                    new XElement("ValorRegla", "A19397090200")),
                                    ConsideracionAG82.elementos,
                                    AplicaDeprec.elementos,
                                    ConsideracionCP.elementos,
                                    ConsinderacionCesionComision.elementos,
                                    DerechosPrimerRecibo.elementos,
                                    BeneficiarioPreferente.elementos,
                                    NumeroSegmento.elementos,
                                    NEmpleado.elementos,
                                    Facturacion4.elementos,
                                    cosideracion34.elementos,
                                    cosideracionLeapYear.elementos),
                            new XElement("Primas",
                                new XElement("PrimaNeta", null),
                                new XElement("Derecho", InfoEmision.Convenio.DerechosPoliza),
                                new XElement("Recargo", null),
                                new XElement("Impuesto", null),
                                new XElement("PrimaTotal", null),
                                new XElement("Comision", null)),
                            new XElement("CodigoError", null)
                            )
                    );
                }
                #endregion

                cadenaEmisionEXML = Movimientos.ToString();
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un error en el armado del XML para la serie: {0}, Error: {1}", InfoEmision.Vehiculo.Serie, ex.Message));
            }

            log.Info(string.Format("Termina armado del XML para la serie: {0}", InfoEmision.Vehiculo.Serie));

            return cadenaEmisionEXML;
        }

        private void RegistraOPL(string numeroPoliza, string xml, string respuesta, string tipo, int idTipo, bool exitoso, string TipoPoliza, int IdCatalogoError = 0)
        {
            try
            {
                using (var _db = new ApplicationDbContext())
                {
                    var oplRegistro = new PolizaRegistroCobranza();
                    oplRegistro.Exitoso = exitoso;
                    oplRegistro.Fecha = DateTime.Now;
                    oplRegistro.FechaResponse = DateTime.Now;
                    oplRegistro.IdTipoOPL = idTipo;
                    oplRegistro.NumeroPoliza = numeroPoliza;
                    oplRegistro.Response = respuesta;
                    oplRegistro.TipoOPL = tipo;
                    oplRegistro.Request = xml;
                    oplRegistro.TipoPoliza = TipoPoliza;
                    oplRegistro.IdCatalogoErrorInstalacionDatosBancarios = IdCatalogoError;
                    oplRegistro.IdAseguradora = 1;
                    _db.PolizaRegistroCobranza.Add(oplRegistro);
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado RegistraOPL Qualitas: " + ex.Message, ex);
            }
        }

        #region RECIBOS OPL - COBRANZA

        public RecibosAseguradoraViewModel ConsultaRecibosOPL(string numeroPoliza, List<sp_POLIZA_Recibos> recibosBD, string userName)
        {
            var result = new RecibosAseguradoraViewModel();

            result.Exitoso = true;

            try
            {
                var url = "";
                var token = Utilidades.Utilidades.ObtienerValorParametro("wptoken");

                bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;

                if (esProduccion)
                    url = Utilidades.Utilidades.ObtienerValorParametro("QUALITAS_OPL_API");
                else
                    url = Utilidades.Utilidades.ObtienerValorParametro("QUALITAS_OPL_API_QA");

                var proxy = new QualitasRecibosProxy(url);
                var request = new QualitasRecibosRequest();

                request.wptoken = token;
                request.m = "listrecs_opl";
                request.poliza = numeroPoliza;

                var response = proxy.RecibosOPL(request);

                var idReferencia = Utilidades.Utilidades.RegistroConsultaReciboAseguradora(1, numeroPoliza, response.JsonData.RequestBody, response.JsonData.ResponseContent, userName);

                result.IdReferencia = idReferencia;

                if (response.success)
                {
                    var recibosQualitas = JsonConvert.DeserializeObject<List<QualitasRecibosResponse>>(response.JsonData.ResponseContent);

                    if (!recibosQualitas.Any())
                        result.Exitoso = false;
                    else
                    {
                        result.EstatusPoliza = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(recibosQualitas.First().status_poliza);
                    }

                    foreach (var recibo in recibosQualitas)
                    {
                        //var serie = $"{recibo.num_pago.ToString("000")}/{recibo.total_pagos.ToString("000")}";
                        var _inDB = recibosBD.FirstOrDefault(a => a.Periodo == recibo.num_pago);
                        if (_inDB != null)
                        {

                            _inDB.MotivoRechazo = ($"{recibo.motivo_rechazo ?? ""} {recibo.motivo_cancelacion ?? ""}").Trim();
                            _inDB.FechaUltimoIntentoCobro = recibo.fecha_cobro;
                            _inDB.FechaPago = recibo.fecha_pago;
                            _inDB.Estatus = recibo.status_recibo.ToUpper();
                        }

                        RegistroReciboAseguradora(idReferencia, recibo);

                    }

                    db.SaveChanges();

                    ActualizacionRecibosLONE(idReferencia, userName);

                    var opera = new DerivacionOperaService();
                    opera.ActualizarRecibosOpera(idReferencia);



                }
                else
                    result.Exitoso = false;

            }

            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado ConsultaRecibosOPL Qualitas: " + ex.Message, ex);

                result.Exitoso = false;
            }

            result.Recibos = recibosBD.OrderBy(a => a.FDesde).ToList();

            return result;

        }


        public void ActualizacionRecibosLONE(int idReferencia, string userName)
        {
            var bitacora = db.ReciboAseguradora_Bitacora.FirstOrDefault(a => a.Id == idReferencia);

            try
            {
                var recibosAseguradora = db.ReciboAseguradora.Where(a => a.IdReferencia == idReferencia).ToList();
                var reciboAseguradoraFisrt = recibosAseguradora.First();
                var poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == bitacora.NumeroPoliza);

                var endosoOpera = 0;

                var numeroPoliza = new SqlParameter("@Poliza", bitacora.NumeroPoliza);
                var recibosLONE = db.sp_POLIZA_Recibos.SqlQuery("sp_POLIZA_Recibos @Poliza", numeroPoliza).ToList();

                Utilidades.Utilidades.RegistroEstatusAseguradora(bitacora.NumeroPoliza, System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(reciboAseguradoraFisrt.EstatusPoliza), idReferencia, userName);

                if (poliza != null)
                {
                    var polizaDetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == poliza.Id);

                    endosoOpera = polizaDetalle.EndosoOPERA;


                }

                if (recibosLONE.Count == reciboAseguradoraFisrt.TotalPagos)
                {

                    foreach (var reciboAseguradora in recibosAseguradora)
                    {
                        var secuencia = $"{reciboAseguradora.Consecutivo.ToString("000")}/{reciboAseguradora.TotalPagos?.ToString("000")}";
                        var recibo = recibosLONE.FirstOrDefault(a => a.Periodo == reciboAseguradora.Consecutivo);

                        if (recibo != null)
                        {

                            var _d = new ReciboAseguradora_Discrepancia();
                            var _registraDiscrepancia = false;

                            decimal _pt = 0;
                            var observaciones = new List<string>();
                            var relacionEstatus = db.ReciboAseguradora_Estatus.FirstOrDefault(a => a.IdAseguradora == 1 && a.EstatusLONE == recibo.EstatusLONE);

                            _d.IdReferencia = idReferencia;
                            _d.IdRecibo = reciboAseguradora.IdRecibo;
                            _d.NumeroPoliza = bitacora.NumeroPoliza;
                            _d.PolizaEndoso = endosoOpera.ToString();
                            _d.Fecha = DateTime.Now;
                            _d.ActualizadoPor = userName;
                            _d.Recibo = reciboAseguradora.IdRecibo.ToString();
                            _d.NoRecibo = reciboAseguradora.Consecutivo.ToString();
                            _d.TotalPagos = reciboAseguradora.TotalPagos;

                            if (reciboAseguradora.EstatusRecibo.ToUpper() == "PAGADO"
                                && relacionEstatus.EstatusAseguradora.ToUpper() != reciboAseguradora.EstatusRecibo.ToUpper()
                                && reciboAseguradora.FechaPago.HasValue)
                            {
                                _registraDiscrepancia = true;
                                _d.EstatusRecibo = $"Estatus de la aseguradora se encuentra pagado, Aseguradora {reciboAseguradora.EstatusRecibo} -  LONE {recibo.EstatusLONE};";
                                observaciones.Add($"Estatus de la aseguradora se encuentra pagado, Aseguradora {reciboAseguradora.EstatusRecibo} -  LONE {recibo.EstatusLONE};");

                                db.Database.ExecuteSqlCommand($"sp_POLIZA_Actualizar_Recibo @IdRecibo={recibo.IdRecibo}, @Fecha = '{reciboAseguradora.FechaPago.Value.ToString("yyyy-MM-dd")}'");
                            }

                            if (decimal.TryParse(recibo.PrimaTotal == null ? "" : recibo.PrimaTotal.ToString(), out _pt))
                            {
                                if (_pt != reciboAseguradora.PrimaTotal)
                                {
                                    _registraDiscrepancia = true;
                                    _d.PrimaTotalRecibos = $"Diferencia en Prima Total Recibo, Aseguradora {reciboAseguradora.PrimaTotal} -  LONE {recibo.PrimaTotal};";
                                    observaciones.Add($"Diferencia en Prima Total Recibo, Aseguradora {reciboAseguradora.PrimaTotal} -  LONE {recibo.PrimaTotal};");
                                }
                            }
                            else
                            {
                                _registraDiscrepancia = true;
                                _d.PrimaTotalRecibos = $"Diferencia en Prima Total Recibo, Aseguradora {reciboAseguradora.PrimaTotal} -  LONE {recibo.PrimaTotal};";
                                observaciones.Add($"Diferencia en Prima Total Recibo, Aseguradora {reciboAseguradora.PrimaTotal} -  LONE {recibo.PrimaTotal};");
                            }

                            observaciones.Add($"Estatus de la asegurada - {reciboAseguradora.EstatusRecibo}, Estatus LONE - {relacionEstatus.EstatusAseguradora}");

                            if (relacionEstatus.EstatusAseguradora.ToUpper() != reciboAseguradora.EstatusRecibo.ToUpper())
                            {
                                var _estatus = db.ReciboAseguradora_Estatus.FirstOrDefault(a => a.IdAseguradora == 1 && a.EstatusAseguradora == reciboAseguradora.EstatusRecibo);

                                if (_estatus != null)
                                {
                                    _registraDiscrepancia = true;
                                    _d.EstatusRecibo = $"Diferencia en Estatus, Aseguradora {reciboAseguradora.EstatusRecibo} -  LONE {relacionEstatus.EstatusAseguradora};";

                                    db.Database.ExecuteSqlCommand($"sp_POLIZA_Actualizar_Recibo @IdRecibo={recibo.IdRecibo}, @Estatus = '{_estatus.EstatusLONE}'");

                                    var _ep = new ReciboAseguradora_CambioEstatusRecibo()
                                    {
                                        IdReferencia = idReferencia,
                                        ActualizadoPor = userName,
                                        EstatusAnterior = relacionEstatus.EstatusAseguradora,
                                        EstatusNuevo = reciboAseguradora.EstatusRecibo,
                                        Fecha = DateTime.Now,
                                        Motivo = "Diferencia Valores",
                                        NumeroPoliza = bitacora.NumeroPoliza,
                                        Origen = "LONE",
                                        IdReciboAseguradora = reciboAseguradora.IdRecibo,
                                        Consecutivo = reciboAseguradora.Consecutivo
                                    };

                                    db.ReciboAseguradora_CambioEstatusRecibo.Add(_ep);
                                    db.SaveChanges();
                                }

                            }

                            reciboAseguradora.Observacion = string.Join(" | ", observaciones);
                            db.SaveChanges();

                            if (_registraDiscrepancia)
                            {
                                db.ReciboAseguradora_Discrepancia.Add(_d);
                                db.SaveChanges();
                            }

                        }
                        else
                        {

                            var discrepancia = new ReciboAseguradora_Discrepancia()
                            {
                                IdReferencia = idReferencia,
                                ActualizadoPor = userName
                   ,
                                PolizaEndoso = endosoOpera.ToString(),
                                NumeroPoliza = bitacora.NumeroPoliza
                   ,
                                Fecha = DateTime.Now,
                                Recibo = $"Recibo no encontrado en LONE {reciboAseguradora.IdRecibo} - {reciboAseguradora.Consecutivo};"
                            };

                            db.ReciboAseguradora_Discrepancia.Add(discrepancia);

                            reciboAseguradora.Observacion = $"Recibo no encontrado en LONE {reciboAseguradora.IdRecibo} - {reciboAseguradora.Consecutivo};";
                            db.SaveChanges();
                        }
                    }

                }
                else
                {
                    var discrepancia = new ReciboAseguradora_Discrepancia()
                    {
                        IdReferencia = idReferencia,
                        ActualizadoPor = userName
                    ,
                        PolizaEndoso = endosoOpera.ToString(),
                        NumeroPoliza = bitacora.NumeroPoliza
                    ,
                        Fecha = DateTime.Now,
                        TotalPagos = reciboAseguradoraFisrt.TotalPagos
                    ,
                        NoRecibo = $"No Recibos Aseguradora {reciboAseguradoraFisrt.TotalPagos}, No Recibos LONE {recibosLONE.Count}, Diferencia en número de recibos"
                    };

                    db.ReciboAseguradora_Discrepancia.Add(discrepancia);

                    bitacora.Observaciones = $"No Recibos Aseguradora {reciboAseguradoraFisrt.TotalPagos}, No Recibos LONE {recibosLONE.Count}, Diferencia en número de recibos";
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                bitacora.Observaciones = "Error ACTUALIZAR RECIBOS QUALITAS - " + ex.ToString();
                db.SaveChanges();
            }
        }

        public void RegistroReciboAseguradora(int idReferencia, QualitasRecibosResponse recibo)
        {
            try
            {
                var item = new ReciboAseguradora();

                item.IdReferencia = idReferencia;

                item.IdRecibo = recibo.idrecibo;
                item.NumeroPoliza = recibo.poliza;
                item.Endoso = recibo.endoso;
                item.ClaveAgente = recibo.ClaveAgente;
                item.TipoCobranza = recibo.tipo_cobranza;
                item.PlazoPago = recibo.plazo_pago;
                item.Consecutivo = recibo.num_pago;
                item.TotalPagos = recibo.total_pagos;
                item.EstatusRecibo = recibo.status_recibo;
                item.MotivoRechazo = recibo.motivo_rechazo;
                item.EstatusPoliza = recibo.status_poliza;
                item.MotivoCancelacion = recibo.motivo_cancelacion;
                item.FechaCobro = recibo.fecha_cobro;
                item.FechaPago = recibo.fecha_pago;
                item.Referencia = recibo.referencia;
                item.PrimaTotal = recibo.monto;
                item.TerminacionTarjeta = recibo.terminacion_tarjeta;
                item.Banco = recibo.banco;
                //item.IdAutorizacion = recibo.ID_autorizacion;
                item.Folio = recibo.folio;

                db.ReciboAseguradora.Add(item);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                log.Info("HDI Ocurrio una excepción al RegistroReciboAseguradora error: " + ex.InnerException.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }

        }


        #endregion


        #region LINK DE PAGO

        public EstatusOperacion LinkCobro(DatosLinkCobro datos, int? idRegistro)
        {
            var estatusOperacion = new EstatusOperacion();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {

                var url = "";
                var token = Utilidades.Utilidades.ObtienerValorParametro("wptoken");

                bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;

                if (esProduccion)
                    url = Utilidades.Utilidades.ObtienerValorParametro("QUALITAS_OPL_API");
                else
                    url = Utilidades.Utilidades.ObtienerValorParametro("QUALITAS_OPL_API_QA");

                var proxy = new QualitasRecibosProxy(url);

                var convenio = db.Convenio.FirstOrDefault(a => a.Id == datos.IdConvenio);

                var request = new QualitasLinkPagoRequest();

                request.wptoken = token;
                request.m = "genlink";
                request.email = datos.Email;
                request.poliza = datos.NumeroPoliza;

                var response = proxy.LinkPagoEmail(request);

                jsonResponse = response.JsonData.ResponseContent;
                jsonRequest = response.JsonData.RequestBody;

                var responseQualitas = JsonConvert.DeserializeObject<QualitasLinkPagoResponse>(jsonResponse);

                urlMethod = response.Url;

                if (response.success)
                {
                    estatusOperacion.Exitoso = true;

                    log.Info(string.Format("QUALITAS Link de Pago exitoso)"));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al enviar el link de pago de la poliza: {0} Error: {1})", datos.NumeroPoliza, responseQualitas.error ?? ""));

                    estatusOperacion.Mensaje = "Algo salió mal en él envió del link de pago, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    estatusOperacion.MensajeCatalogo = responseQualitas.error;
                }

            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado Link de Pago Qualitas: " + ex.Message, ex);

                estatusOperacion.Mensaje = ex.Message;
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                estatusOperacion.Exitoso = false;
                estatusOperacion.EsReintentable = false;
                estatusOperacion.MensajeCatalogo = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            if (idRegistro.HasValue)
            {
                var registro = db.LinkPagoMasivo_Poliza.FirstOrDefault(a => a.Id == idRegistro);

                registro.Error = estatusOperacion.MensajeCatalogo;
                registro.URL = urlMethod;
                registro.Response = jsonResponse;
                registro.Request = jsonRequest;

                db.SaveChanges();
            }

            RegistraOPL(datos.NumeroPoliza, jsonRequest, jsonResponse, "Link de Cobro", 5, estatusOperacion.Exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datos.NumeroPoliza) == true ? "Online" : "Tradicional");

            log.Info(string.Format("Termina proceso de generacion de link de pago de la poliza: {0}", datos.NumeroPoliza));

            return estatusOperacion;
        }


        #endregion


        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
        private class XmlCobertura
        {
            public List<XAttribute> atributos;
            public List<XElement> elementos;
        }

    }
}
