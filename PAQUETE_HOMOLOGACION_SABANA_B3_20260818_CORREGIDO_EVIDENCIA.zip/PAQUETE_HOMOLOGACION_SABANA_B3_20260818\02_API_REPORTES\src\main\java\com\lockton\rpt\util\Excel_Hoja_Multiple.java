package com.lockton.rpt.util;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;

public class Excel_Hoja_Multiple {

 
    public static java.util.function.BiConsumer<String, String> DEBUG_SINK;

    private static void debug(String etapa, String detalle) {
        System.out.println("DIAG " + etapa + " " + detalle);
        java.util.function.BiConsumer<String, String> sink = DEBUG_SINK;
        if (sink != null) {
            try {
                sink.accept(etapa, detalle);
            } catch (Throwable ignore) {
                // Nunca romper la generacion del reporte por un fallo de log
            }
        }
    }

    public static String generar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
                               Map<String, Object> parametros,
                               String outputDir) throws Exception {
        SXSSFWorkbook wb = new SXSSFWorkbook(1000);
        wb.setCompressTempFiles(true);
        String rs = "";
        int rsIdx = 0;
        int sheetsCreated = 0;
        for (ArrayList<LinkedCaseInsensitiveMap<?>> rows : resultsets) {
            rsIdx++;
            if (rows == null || rows.isEmpty()) {
                debug("generar_rs_vacio", "rsIdx=" + rsIdx + " filas=0 — SP no devolvio datos (SP inexistente o error silencioso en ff_Sabana_v2)");
                continue;
            }

            // Config por grupo según indexTable = (rsIdx-1)
            Map<String, Object> grupoConf =
                    obtenerGrupoConfigPrefer(parametros, rows, rsIdx - 1);
            String columnaGrupo;
            boolean agrupar;
            if (grupoConf == null) {
                // Si no hay configuración, NO agrupar por columna (evita usar NombrePestana por defecto)
                columnaGrupo = null;
                agrupar = false;
            } else {
                columnaGrupo = String.valueOf(grupoConf.getOrDefault("columnaGrupo", "NombrePestana"));
                agrupar = parseBool(grupoConf.get("agruparPorColumna"));
            }
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> columnas = grupoConf == null ? null : (List<Map<String, Object>>) grupoConf.get("columnas");
            debug("generar_rs", "rsIdx=" + rsIdx + " grupo=" + (grupoConf == null ? "null" : grupoConf.get("grupo"))
                    + " agruparPorColumna=" + (grupoConf == null ? "null" : grupoConf.get("agruparPorColumna"))
                    + " columnaGrupoCfg=" + (grupoConf == null ? "null" : grupoConf.get("columnaGrupo"))
                    + " columnas=" + (columnas == null ? "null" : columnas.size())
                    + " primeraFilaKeys=" + rows.get(0).keySet());

            Map<String, List<LinkedCaseInsensitiveMap<?>>> porHoja =
                    (agrupar && columnaGrupo != null) ? agruparPorColumna(rows, columnaGrupo) : new LinkedHashMap<>();
            if (agrupar && columnaGrupo != null) {
                StringBuilder resumenGrupos = new StringBuilder();
                for (Map.Entry<String, List<LinkedCaseInsensitiveMap<?>>> e : porHoja.entrySet()) {
                    if (resumenGrupos.length() > 0) resumenGrupos.append(" | ");
                    resumenGrupos.append(e.getKey()).append("=").append(e.getValue().size());
                }
                debug("agrupar_porHoja", "rsIdx=" + rsIdx + " grupo=" + (grupoConf == null ? "null" : grupoConf.get("grupo"))
                        + " columnaGrupo=" + columnaGrupo + " distintos=" + porHoja.size()
                        + " detalle=[" + resumenGrupos + "]");
            }
            if (!agrupar || porHoja.isEmpty()) {
                // Nombre de hoja:
                //  - Si hay configuración de grupo, usar el nombre del grupo (o título).
                //  - Si no, usar nombre genérico RS_n.
                String baseName = "RS_" + rsIdx;
                if (grupoConf != null) {
                    Object g = grupoConf.get("grupo");
                    Object titulo = grupoConf.get("tituloTabla");
                    String candidate = g != null ? String.valueOf(g) :
                                       titulo != null ? String.valueOf(titulo) : baseName;
                    baseName = sanitizarNombreHoja(candidate);
                }
                Sheet sh = wb.createSheet(nombreHojaUnico(wb, baseName));
                escribirTabla(sh, rows, columnas, columnaGrupo, agrupar, grupoConf);
                sheetsCreated++;
            } else {
                for (Map.Entry<String, List<LinkedCaseInsensitiveMap<?>>> e : porHoja.entrySet()) {
                    String sheetName = sanitizarNombreHoja(e.getKey());
                    Sheet sh = wb.createSheet(nombreHojaUnico(wb, sheetName));
                    escribirTabla(sh, (ArrayList)e.getValue(), columnas, columnaGrupo, agrupar, grupoConf);
                    sheetsCreated++;
                }
            }
        }

        // Si ningún RS aportó filas, no generamos archivo
        if (sheetsCreated == 0) {
            try { wb.close(); } catch (Throwable ignore) {}
            try { wb.dispose(); } catch (Throwable ignore) {}
            return "";
        }

        String rutaDir = outputDir;
        // Resolver idEmpresa efectivo: idEmpresa | admIdEmpresa | primer id de empresas/empresasIds
        Object idEmpObj = parametros.get("idEmpresa");
        if (idEmpObj == null) {
            idEmpObj = String.valueOf(
                    String.valueOf(
                            parametros.getOrDefault("admIdEmpresa",
                                    String.valueOf(
                                            parametros.getOrDefault("empresas",
                                                    parametros.get("empresasIds")
                                            )
                                    )
                            )
                    )
            );
        }
        String idEmp = null;
        if (idEmpObj != null) {
            String raw = String.valueOf(idEmpObj).trim();
            raw = raw.replaceAll("[\\{\\}\\[\\]]", "");
            if (raw.contains(",")) raw = raw.split(",")[0].trim();
            String digits = raw.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) idEmp = digits;
        }
        // Subcarpeta por nombre de reporte (catReportesNombre/tituloReporteB1) con fallback por reporteId
        String subFolder = sanitizarNombreCarpeta(
                String.valueOf(
                        parametros.getOrDefault(
                                "catReportesNombre",
                                parametros.getOrDefault("tituloReporteB1", nombreReportePorId(parametros))
                        )
                )
        );
        if (subFolder == null || subFolder.trim().isEmpty()) subFolder = "Reporte";
        // Intentar leer com.lockton.rpt.util.Constantes.DOCUMENTO_EMPRESA vía reflexión (evita dependencias duras)
        try {
            Class<?> c = Class.forName("com.lockton.rpt.util.Constantes");
            Object v = c.getField("DOCUMENTO_EMPRESA").get(null);
            if (idEmp != null && v != null) {
                String base = String.valueOf(v);
                if (base != null && !base.trim().isEmpty()) {
                    rutaDir = base + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            }
        } catch (Throwable ignore) {
            // Ignorar y probar con variable de entorno
        }
        if (rutaDir == null || ".".equals(rutaDir) || outputDir.equals(rutaDir)) {
            try {
                String base = System.getenv("UPLOAD_FOLDER");
                if (base != null && !base.trim().isEmpty() && idEmp != null) {
                    rutaDir = base + File.separator + "DocumentoEmpresa" + File.separator + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            } catch (Throwable ignore) {
                // Si tampoco está la variable de entorno, caeremos en outputDir
            }
        }
        rs = guardarWorkbook(wb, rutaDir, nombreArchivo("Reporte", parametros));
        try { wb.dispose(); } catch (Throwable ignore) {}
        return rs;
    }

    private static Map<String, List<LinkedCaseInsensitiveMap<?>>> agruparPorNombrePestana(ArrayList<LinkedCaseInsensitiveMap<?>> rows) {
        Map<String, List<LinkedCaseInsensitiveMap<?>>> map = new LinkedHashMap<>();
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Object np = row.get("NombrePestana");
            String key = np == null ? null : String.valueOf(np);
            if (key == null || key.isEmpty()) continue;
            map.computeIfAbsent(key, k -> new ArrayList<>()).add(row);
        }
        return map;
    }

    private static Map<String, List<LinkedCaseInsensitiveMap<?>>> agruparPorColumna(ArrayList<LinkedCaseInsensitiveMap<?>> rows, String columna) {
        Map<String, List<LinkedCaseInsensitiveMap<?>>> map = new LinkedHashMap<>();
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Object v = row.get(columna);
            String key = v == null ? null : String.valueOf(v);
            if (key == null || key.isEmpty()) key = "Hoja";
            map.computeIfAbsent(key, k -> new ArrayList<>()).add(row);
        }
        return map;
    }

    private static void escribirTabla(
            Sheet sh,
            ArrayList<LinkedCaseInsensitiveMap<?>> rows,
            List<Map<String, Object>> columnas,
            String columnaGrupo,
            boolean agrupar,
            Map<String, Object> grupoConf) {
        if (rows == null || rows.isEmpty()) return;

        boolean allowAutoSize = !(sh instanceof SXSSFSheet) || rows.size() <= 5000;
        try {
            if (allowAutoSize && sh instanceof SXSSFSheet) {
                ((SXSSFSheet) sh).trackAllColumnsForAutoSizing();
            }
        } catch (Throwable ignore) {}

        LinkedCaseInsensitiveMap<?> first = rows.get(0);
        Map<String, String> normalToActual = new java.util.HashMap<>();
        for (Object key : first.keySet()) {
            String actual = String.valueOf(key);
            normalToActual.put(normalizeColumnKey(actual), actual);
        }

        List<String> headers = new ArrayList<>();
        List<String> campos = new ArrayList<>();
        List<Integer> tipos = new ArrayList<>();
        List<Integer> anchos = new ArrayList<>();
        List<String> formatos = new ArrayList<>();
        List<String> alinears = new ArrayList<>();
        Set<String> camposConfigurados = new LinkedHashSet<>();
        Set<String> camposIncluidos = new LinkedHashSet<>();
        boolean preservarDinamicas = grupoConf != null
                && parseBool(grupoConf.get("preservarColumnasDinamicas"));

        debug("escribirTabla_inicio", "grupo=" + (grupoConf == null ? "null" : grupoConf.get("grupo"))
                + " columnasConfig=" + (columnas == null ? "null" : columnas.size())
                + " preservarDinamicas=" + preservarDinamicas
                + " columnaGrupo=" + columnaGrupo + " agrupar=" + agrupar
                + " filasEnHoja=" + rows.size());

        List<String> matchLog = new ArrayList<>();
        if (columnas != null && !columnas.isEmpty()) {
            for (Map<String, Object> col : columnas) {
                Object campoObj = col.get("campoOrigen");
                if (campoObj == null) {
                    matchLog.add("(sin campoOrigen)=SKIP:campoOrigenNulo");
                    continue;
                }
                String campoCfg = String.valueOf(campoObj);
                String campoNormalizado = normalizeColumnKey(campoCfg);
                camposConfigurados.add(campoNormalizado);

                // visible=0 represents REMOVERCOLUMNAS from the legacy XML.
                if (!esVisible(col.get("visible"))) {
                    matchLog.add(campoCfg + "=SKIP:noVisible");
                    continue;
                }

                String resolved = normalToActual.get(campoNormalizado);
                // Legacy only ordered columns that were present in the SP result.
                if (resolved == null || camposIncluidos.contains(campoNormalizado)) {
                    matchLog.add(campoCfg + "=SKIP:" + (resolved == null ? "noEncontradoEnFila" : "duplicado"));
                    continue;
                }
                if (agrupar && columnaGrupo != null
                        && resolved.equalsIgnoreCase(columnaGrupo)) {
                    matchLog.add(campoCfg + "=SKIP:esColumnaAgrupacion");
                    continue;
                }

                camposIncluidos.add(campoNormalizado);
                campos.add(resolved);
                Object encabezado = col.get("encabezado");
                headers.add(encabezado == null
                        ? resolved : String.valueOf(encabezado));
                tipos.add(safeInteger(col.get("tipoDato")));
                anchos.add(safeInt(col.get("ancho"), 0));
                formatos.add(col.get("formato") == null
                        ? null : String.valueOf(col.get("formato")));
                alinears.add(col.get("alinear") == null
                        ? null : String.valueOf(col.get("alinear")));
                matchLog.add(campoCfg + "=OK->" + resolved);
            }
        }
        debug("escribirTabla_matchColumnas", String.join(" | ", matchLog));


        // SabanaConfig is an order plus a blacklist, not a whitelist.
        if (preservarDinamicas) {
            for (Object keyObj : first.keySet()) {
                String key = String.valueOf(keyObj);
                String normalizada = normalizeColumnKey(key);
                if (camposConfigurados.contains(normalizada)
                        || camposIncluidos.contains(normalizada)
                        || "grupo".equals(normalizada)
                        || "jornada".equals(normalizada)
                        || (agrupar && columnaGrupo != null
                                && key.equalsIgnoreCase(columnaGrupo))) {
                    continue;
                }
                camposIncluidos.add(normalizada);
                campos.add(key);
                headers.add(key);
                tipos.add(null);
                anchos.add(0);
                formatos.add(null);
                alinears.add(null);
            }
        } else if (columnas == null || columnas.isEmpty()) {
            for (Object keyObj : first.keySet()) {
                String key = String.valueOf(keyObj);
                if (agrupar && key.equalsIgnoreCase(columnaGrupo)) continue;
                campos.add(key);
                headers.add(key);
                tipos.add(null);
                anchos.add(0);
                formatos.add(null);
                alinears.add(null);
            }
        }

        // Columnas configuradas pero ninguna existe en el resultset → mostrar columnas crudas
        if (campos.isEmpty() && columnas != null && !columnas.isEmpty()) {
            debug("escribirTabla_fallbackCrudo", "columnas_configuradas=" + columnas.size()
                    + " ninguna_encontrada_en_resultset=true grupo="
                    + (grupoConf == null ? "null" : grupoConf.get("grupo")));
            for (Object keyObj : first.keySet()) {
                String key = String.valueOf(keyObj);
                String norm = normalizeKey(key);
                if ("grupo".equals(norm)) continue;
                if (agrupar && columnaGrupo != null && key.equalsIgnoreCase(columnaGrupo)) continue;
                campos.add(key);
                headers.add(key);
                tipos.add(null);
                anchos.add(0);
                formatos.add(null);
                alinears.add(null);
            }
        }

        // Compatibility with reports that already depend on this exception.
        if (first.containsKey("Jornada")
                && !camposIncluidos.contains(normalizeColumnKey("Jornada"))) {
            int insertAt = Math.min(18, campos.size());
            campos.add(insertAt, "Jornada");
            headers.add(insertAt, "Jornada");
            tipos.add(insertAt, null);
            anchos.add(insertAt, 0);
            formatos.add(insertAt, null);
            alinears.add(insertAt, null);
        }

        debug("escribirTabla_resultado", "totalColumnasEscritas=" + headers.size()
                + " rutaUsada=" + (preservarDinamicas ? "configurado+dinamicas"
                        : (columnas == null || columnas.isEmpty()) ? "CRUDO_SIN_CONFIG" : "solo-configurado")
                + " headers=" + headers);

        CellStyle headerStyle = crearHeaderStyle(
                sh.getWorkbook(),
                grupoConf != null ? grupoConf.get("colorFondo") : null,
                grupoConf != null ? grupoConf.get("colorLetra") : null);
        CellStyle currencyStyle = sh.getWorkbook().createCellStyle();
        currencyStyle.setDataFormat(sh.getWorkbook().createDataFormat()
                .getFormat("\"$\"#,##0.00"));
        CellStyle dateStyle = sh.getWorkbook().createCellStyle();
        dateStyle.setDataFormat(sh.getWorkbook().createDataFormat()
                .getFormat("dd/MM/yyyy"));

        CellStyle[] colStyles = new CellStyle[campos.size()];
        String alineacionGrupo = grupoConf == null
                || grupoConf.get("alineacion") == null
                        ? null : String.valueOf(grupoConf.get("alineacion"));
        for (int i = 0; i < campos.size(); i++) {
            String formatoDesc = formatos.get(i);
            String formato = resolveFormatString(formatoDesc);
            Integer tipo = tipos.get(i);
            if (formato == null) {
                if (tipo != null && tipo == 4) formato = "\"$\"#,##0.00";
                else if (tipo != null && tipo == 3) formato = "dd/MM/yyyy";
            }

            String alinearDesc = alinears.get(i);
            HorizontalAlignment alineacion = resolveAlign(
                    alinearDesc == null || alinearDesc.trim().isEmpty()
                            ? alineacionGrupo : alinearDesc);
            if (formato != null || alineacion != null) {
                CellStyle estilo = sh.getWorkbook().createCellStyle();
                if (formato != null) {
                    estilo.setDataFormat(sh.getWorkbook().createDataFormat()
                            .getFormat(formato));
                }
                if (alineacion != null) estilo.setAlignment(alineacion);
                colStyles[i] = estilo;
            }
        }

        boolean[] autoSize = new boolean[campos.size()];
        for (int i = 0; i < campos.size(); i++) {
            int ancho = anchos.get(i) == null ? 0 : anchos.get(i);
            if (ancho > 0) {
                try {
                    sh.setColumnWidth(i, Math.min(ancho, 255) * 256);
                } catch (Throwable ignore) {}
            } else {
                autoSize[i] = true;
            }
        }

        int rowIndex = 0;
        Row headerRow = sh.createRow(rowIndex++);
        for (int i = 0; i < headers.size(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(clean(headers.get(i)));
            cell.setCellStyle(headerStyle);
        }

        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Row excelRow = sh.createRow(rowIndex++);
            for (int i = 0; i < campos.size(); i++) {
                Object val = row.get(campos.get(i));
                Integer tipo = tipos.get(i);
                String formatoDesc = formatos.get(i);
                CellStyle estiloColumna = colStyles[i];
                Cell cell = excelRow.createCell(i);
                boolean isFecha = tipo != null && tipo == 3;
                boolean isMoneda = tipo != null && tipo == 4;
                boolean fechaPorFormato = formatoDesc != null
                        && formatoDesc.toLowerCase(Locale.ROOT)
                                .startsWith("fecha:");

                if (isFecha || fechaPorFormato) {
                    Date fecha = val instanceof Date
                            ? (Date) val
                            : tryParseDate(val == null ? null : String.valueOf(val));
                    if (fecha == null) {
                        cell.setCellValue("");
                    } else {
                        cell.setCellValue(fecha);
                        cell.setCellStyle(estiloColumna == null
                                ? dateStyle : estiloColumna);
                    }
                } else if (val == null) {
                    cell.setCellValue("");
                    if (estiloColumna != null) cell.setCellStyle(estiloColumna);
                } else if (isMoneda) {
                    Double numero = tryParseDouble(val);
                    if (numero == null) {
                        cell.setCellValue("");
                    } else {
                        cell.setCellValue(numero);
                        cell.setCellStyle(estiloColumna == null
                                ? currencyStyle : estiloColumna);
                    }
                } else if (estiloColumna != null) {
                    String formatoResuelto = resolveFormatString(formatoDesc);
                    boolean solicitaNumero = formatoResuelto != null
                            && !isTextFormat(formatoDesc);
                    Double numero = solicitaNumero ? tryParseDouble(val) : null;
                    if (val instanceof Number && !isTextFormat(formatoDesc)) {
                        cell.setCellValue(((Number) val).doubleValue());
                    } else if (numero != null) {
                        cell.setCellValue(numero);
                    } else {
                        cell.setCellValue(clean(String.valueOf(val)));
                    }
                    cell.setCellStyle(estiloColumna);
                } else if (val instanceof Number) {
                    cell.setCellValue(((Number) val).doubleValue());
                } else if (val instanceof Boolean) {
                    cell.setCellValue((Boolean) val);
                } else if (val instanceof Date) {
                    cell.setCellValue((Date) val);
                } else {
                    cell.setCellValue(clean(String.valueOf(val)));
                }
            }
        }

        if (allowAutoSize) {
            int maxCols = Math.min(headers.size(), 50);
            for (int i = 0; i < maxCols; i++) {
                if (!autoSize[i]) continue;
                try {
                    sh.autoSizeColumn(i);
                } catch (IllegalStateException ignore) {
                    // SXSSF only permits auto-size for tracked columns.
                } catch (Throwable ignore) {}
            }
        }

        // Autofiltro (equivalente al blAddTableName del legacy). Sólo cuando el
        // grupo lo solicita (la Sábana lo activa); cubre desde el encabezado
        // (fila 0) hasta la última fila de datos escrita.
        if (grupoConf != null && parseBool(grupoConf.get("autofiltro"))) {
            try {
                int lastCol = headers.size() - 1;
                int lastRow = rows.size();
                if (lastCol >= 0 && lastRow > 0) {
                    sh.setAutoFilter(new org.apache.poi.ss.util.CellRangeAddress(
                            0, lastRow, 0, lastCol));
                }
            } catch (Throwable ignore) {
                // Un fallo de autofiltro no debe invalidar la hoja ya escrita.
            }
        }
    }

    private static CellStyle crearHeaderStyle(Workbook wb, Object colorFondoObj, Object colorLetraObj) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        String fondo = colorFondoObj == null ? null : String.valueOf(colorFondoObj);
        String letra = colorLetraObj == null ? null : String.valueOf(colorLetraObj);
        Short fondoIdx = colorFromName(fondo);
        Short letraIdx = colorFromName(letra);
        if (fondoIdx != null) {
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                style.setFillForegroundColor(fondoIdx);
                style.setAlignment(HorizontalAlignment.CENTER);
        } else if (isHexColor(fondo) && style instanceof XSSFCellStyle) {
            try {
                java.awt.Color awt = parseHexColor(fondo);
                ((XSSFCellStyle) style).setFillForegroundColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                style.setAlignment(HorizontalAlignment.CENTER);
            } catch (Exception ignore) {}
        }
        if (letraIdx != null) {
            font.setColor(letraIdx);
        } else if (fondoIdx != null && (fondoIdx.equals(IndexedColors.BLUE.getIndex()))) {
            // Contraste por defecto para fondo azul
            font.setColor(IndexedColors.WHITE.getIndex());
        } else if (isHexColor(letra) && font instanceof XSSFFont) {
            try {
                java.awt.Color awt = parseHexColor(letra);
                ((XSSFFont) font).setColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
            } catch (Exception ignore) {}
        } else if (isHexColor(letra) && font instanceof XSSFFont) {
            try {
                java.awt.Color awt = parseHexColor(letra);
                ((XSSFFont) font).setColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
            } catch (Exception ignore) {}
        }
        style.setFont(font);
        return style;
    }

    private static Short colorFromName(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        if (n.equalsIgnoreCase("Blue") || n.equalsIgnoreCase("Azul")) return IndexedColors.BLUE.getIndex();
        if (n.equalsIgnoreCase("LightBlue") || n.equalsIgnoreCase("Light_Blue") || n.equalsIgnoreCase("Celeste")) return IndexedColors.LIGHT_BLUE.getIndex();
        if (n.equalsIgnoreCase("White") || n.equalsIgnoreCase("Blanco")) return IndexedColors.WHITE.getIndex();
        if (n.equalsIgnoreCase("Black") || n.equalsIgnoreCase("Negro")) return IndexedColors.BLACK.getIndex();
        if (n.equalsIgnoreCase("Red") || n.equalsIgnoreCase("Rojo")) return IndexedColors.RED.getIndex();
        if (n.equalsIgnoreCase("Green") || n.equalsIgnoreCase("Verde")) return IndexedColors.GREEN.getIndex();
        if (n.equalsIgnoreCase("Gray") || n.equalsIgnoreCase("Grey") || n.equalsIgnoreCase("Gris")) return IndexedColors.GREY_50_PERCENT.getIndex();
        return null;
    }

    private static boolean isHexColor(String s) {
        if (s == null) return false;
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v.matches("(?i)^[0-9a-f]{6}$");
    }

    private static java.awt.Color parseHexColor(String s) {
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        int r = Integer.parseInt(v.substring(0,2), 16);
        int g = Integer.parseInt(v.substring(2,4), 16);
        int b = Integer.parseInt(v.substring(4,6), 16);
        return new java.awt.Color(r,g,b);
    }

    private static String guardarWorkbook(Workbook wb, String outputDir, String fileName) throws Exception {
        File dir = new File(outputDir);
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(out)) {
            System.out.println("Escribiendo archivo...");
            wb.write(fos);
        }
        wb.close();
        String outPut = out.getAbsolutePath();
        System.out.println("Archivo generado: " + outPut);
        return outPut;
    }

    private static String nombreArchivo(String prefijo, Map<String, Object> parametros) {
        return NombreArchivoUtil.generarNombre(
                parametros,
                prefijo,
                "yyyyMMddHHmmss",
                true,   // incluir sufijo idEmpresa/fileSuffix como antes
                true,   // Sábana: solo timestamp
                true,   // Costos: nombre especial
                true    // separador "_" antes de timestamp
        );
    }

    private static String sanitizarNombreHoja(String name) {
        String n = name.replaceAll("[\\\\/*?:\\[\\]]", " ").trim();
        return n.isEmpty() ? "Hoja" : n;
    }

    private static String limit(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }

    private static String nombreHojaUnico(Workbook wb, String solicitado) {
        String base = limit(sanitizarNombreHoja(solicitado), 31);
        if (wb.getSheet(base) == null) return base;
        int consecutivo = 2;
        while (true) {
            String sufijo = " (" + consecutivo++ + ")";
            String candidato = limit(base, 31 - sufijo.length()) + sufijo;
            if (wb.getSheet(candidato) == null) return candidato;
        }
    }

    private static String normalizeKey(String key) {
        if (key == null) return "";
        return key.replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.ROOT);
    }

    /**
     * SQL identifiers are case-insensitive here, but punctuation is semantic.
     * In particular, legacy treats Costo1 and Costo_1 as different columns.
     */
    private static String normalizeColumnKey(String key) {
        return key == null ? "" : key.trim().toLowerCase(Locale.ROOT);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> obtenerGrupoConfigPrefer(
            Map<String, Object> parametros,
            ArrayList<LinkedCaseInsensitiveMap<?>> rows,
            int index) {
        try {
            Object rawConfig = parametros.get("reporteConfig");
            if (!(rawConfig instanceof List)) return null;
            List<Map<String, Object>> configs =
                    (List<Map<String, Object>>) rawConfig;

            Object nombre = parametros.get("grupoNombre");
            if (nombre != null) {
                Map<String, Object> encontrada =
                        buscarGrupoConfig(configs, String.valueOf(nombre));
                if (encontrada != null) return encontrada;
            }

            if (rows != null && !rows.isEmpty()) {
                LinkedCaseInsensitiveMap<?> first = rows.get(0);
                Object grupoDato = first.get("grupo");
                if (grupoDato == null) grupoDato = first.get("TipoSabana");
                if (grupoDato != null) {
                    Map<String, Object> encontrada = buscarGrupoConfig(
                            configs, String.valueOf(grupoDato));
                    if (encontrada != null) return encontrada;
                }

                String inferido = inferirGrupo(first);
                if (inferido != null) {
                    Map<String, Object> encontrada =
                            buscarGrupoConfig(configs, inferido);
                    if (encontrada != null) return encontrada;
                }
            }

            for (Map<String, Object> config : configs) {
                if (parseInt(config.get("indexTable")) == index) return config;
            }
        } catch (Throwable t) {
            System.out.println("obtenerGrupoConfigPrefer error index=" + index + ": " + t);
        }
        return null;
    }

    private static Map<String, Object> buscarGrupoConfig(
            List<Map<String, Object>> configs, String buscado) {
        String objetivo = normalizeKey(quitarAcentos(buscado));
        for (Map<String, Object> config : configs) {
            Object grupo = config.get("grupo");
            if (grupo == null) continue;
            String candidato = normalizeKey(
                    quitarAcentos(String.valueOf(grupo)));
            if (candidato.equals(objetivo)
                    || candidato.contains(objetivo)
                    || objetivo.contains(candidato)) {
                return config;
            }
        }
        return null;
    }

    private static String inferirGrupo(LinkedCaseInsensitiveMap<?> first) {
        if (first == null) return null;
        if (first.containsKey("Nombre titular")
                || first.containsKey("Raza")
                || first.containsKey("Caracteristicas Mascota")) {
            return "Mascotas";
        }
        if (first.containsKey("GPDescripcion")
                || first.containsKey("PrimeNeta")
                || first.containsKey("GMM_ANT")) {
            return "GMM";
        }
        if (first.containsKey("PONombre")
                || first.containsKey("poidplanopcion")
                || first.containsKey("local_number")
                || first.containsKey("PrimaNeta")) {
            return "Opcionales";
        }
        for (Object keyObj : first.keySet()) {
            String key = normalizeKey(String.valueOf(keyObj));
            if (key.startsWith("vida") || key.startsWith("ss")
                    || key.startsWith("costo")) {
                return "Vida";
            }
        }
        return null;
    }

    private static boolean parseBool(Object v) {
        if (v == null) return false;
        String s = String.valueOf(v).trim();
        return s.equalsIgnoreCase("1") || s.equalsIgnoreCase("true") || s.equalsIgnoreCase("si") || s.equalsIgnoreCase("sí");
    }

    private static int parseInt(Object v) {
        try { return Integer.parseInt(String.valueOf(v)); } catch (Exception e) { return 0; }
    }

    private static boolean esVisible(Object v) {
        if (v == null) return true;
        if (v instanceof Boolean) return (Boolean) v;
        if (v instanceof Number) return ((Number) v).intValue() != 0;
        String s = String.valueOf(v).trim();
        return !(s.equals("0") || s.equalsIgnoreCase("false")
                || s.equalsIgnoreCase("no"));
    }

    private static int safeInt(Object v, int fallback) {
        try {
            return v == null ? fallback : Integer.parseInt(String.valueOf(v));
        } catch (Exception e) {
            return fallback;
        }
    }

    private static Integer safeInteger(Object v) {
        if (v == null) return null;
        try {
            return Integer.parseInt(String.valueOf(v));
        } catch (Exception e) {
            return null;
        }
    }

    private static String resolveFormatString(String desc) {
        if (desc == null) return null;
        String d = desc.trim();
        if (d.isEmpty()) return null;
        String l = d.toLowerCase(java.util.Locale.ROOT);
        if (l.equals("texto") || l.equals("text") || l.equals("@")) return "@";
        if (l.equals("entero") || l.equals("integer")) return "0";
        if (l.equals("numero") || l.equals("number") || l.equals("decimal")) return "#,##0.00";
        if (l.equals("moneda") || l.equals("currency")) return "\"$\"#,##0.00";
        if (l.equals("porcentaje") || l.equals("percent")) return "0.00%";
        if (l.startsWith("fecha:")) return d.substring(6).trim().isEmpty() ? "dd/MM/yyyy" : d.substring(6).trim();
        if (l.startsWith("custom:")) return d.substring(7).trim().isEmpty() ? null : d.substring(7).trim();
        return null;
    }

    private static HorizontalAlignment resolveAlign(String desc) {
        if (desc == null) return null;
        String l = desc.trim().toLowerCase(java.util.Locale.ROOT);
        if (l.isEmpty()) return null;
        if (l.equals("izquierda") || l.equals("left")) return HorizontalAlignment.LEFT;
        if (l.equals("centro") || l.equals("center")) return HorizontalAlignment.CENTER;
        if (l.equals("derecha") || l.equals("right")) return HorizontalAlignment.RIGHT;
        return null;
    }

    private static boolean isTextFormat(String desc) {
        if (desc == null) return false;
        String l = desc.trim().toLowerCase(java.util.Locale.ROOT);
        return l.equals("texto") || l.equals("text") || l.equals("@");
    }

    private static Double tryParseDouble(Object v) {
        if (v == null) return null;
        if (v instanceof Number) return ((Number) v).doubleValue();
        String s = String.valueOf(v).trim().replace(",", "");
        try { return Double.parseDouble(s); } catch (Exception ignore) { return null; }
    }

    private static Date tryParseDate(String raw) {
        if (raw == null) return null;
        String value = raw.trim();
        if (value.isEmpty()) return null;
        String[] patterns = {
            "dd/MM/yyyy", "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss", "MM/dd/yyyy"
        };
        for (String pattern : patterns) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(pattern);
                sdf.setLenient(false);
                return sdf.parse(value);
            } catch (Exception ignore) {}
        }
        return null;
    }

    private static String quitarAcentos(String s) {
        if (s == null) return null;
        String decomposed = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

    private static String sanitizarNombreCarpeta(String s) {
        if (s == null) return null;
        String sinAcentos = quitarAcentos(s);
        // Reemplazar caracteres inválidos en rutas Windows y normalizar espacios
        String cleaned = sinAcentos.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        // Evitar nombres reservados
        String upper = cleaned.equalsIgnoreCase("CON") || cleaned.equalsIgnoreCase("PRN") ||
                       cleaned.equalsIgnoreCase("AUX") || cleaned.equalsIgnoreCase("NUL") ? "Reporte" : cleaned;
        return upper.isEmpty() ? "Reporte" : upper;
    }

    private static String nombreReportePorId(Map<String, Object> parametros) {
        if (parametros == null) return "Reporte";
        Integer rid = null;
        try { Object o = parametros.get("reporteId"); if (o != null) rid = Integer.parseInt(String.valueOf(o)); } catch (Exception ignore) {}
        if (rid == null) return "Reporte";
        switch (rid) {
            case 2: return "Poblacion";
            case 3: return "Sabana";
            default: return "Reporte";
        }
    }

    // Limpia caracteres no permitidos por XML 1.0 que pueden corromper el XLSX
    private static String clean(String s) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == 0x9 || ch == 0xA || ch == 0xD ||
                (ch >= 0x20 && ch <= 0xD7FF) ||
                (ch >= 0xE000 && ch <= 0xFFFD)) {
                sb.append(ch);
            }
        }
        String out = sb.toString();
        return out.length() > 32766 ? out.substring(0, 32766) : out; // límite Excel
    }
}
