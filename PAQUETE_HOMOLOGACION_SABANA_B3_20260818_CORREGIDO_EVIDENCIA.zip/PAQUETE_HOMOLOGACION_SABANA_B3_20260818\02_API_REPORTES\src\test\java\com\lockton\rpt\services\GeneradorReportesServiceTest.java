package com.lockton.rpt.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.util.LinkedCaseInsensitiveMap;

public class GeneradorReportesServiceTest {

    @Test
    @SuppressWarnings("unchecked")
    public void conservaResultsetsNumeradosAunqueExistanHuecos() throws Exception {
        Map<String, Object> resultado = new LinkedHashMap<>();
        resultado.put("#result-set-3", Arrays.asList(row("grupo", "OPC")));
        resultado.put("#result-set-1", Arrays.asList(row("grupo", "GMM")));
        resultado.put("#update-count-1", 0);

        Method extraer = GeneradorReportesService.class.getDeclaredMethod(
                "extraerResultsets", Map.class);
        extraer.setAccessible(true);

        List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets =
                (List<ArrayList<LinkedCaseInsensitiveMap<?>>>) extraer.invoke(
                        new GeneradorReportesService(), resultado);

        assertEquals(2, resultsets.size());
        assertEquals("GMM", resultsets.get(0).get(0).get("grupo"));
        assertEquals("OPC", resultsets.get(1).get(0).get("grupo"));
    }

    @Test
    public void sabanaUsaGrupoCanonicoSinColisionarPorIndexTable()
            throws Exception {
        Method clave = GeneradorReportesService.class.getDeclaredMethod(
                "claveTablaConfiguracion", int.class, Map.class);
        clave.setAccessible(true);
        GeneradorReportesService service = new GeneradorReportesService();

        Object opc = clave.invoke(service, 3, config("OPC", 2));
        Object opcionales = clave.invoke(
                service, 3, config("Opcionales", 7));
        Object gmm = clave.invoke(service, 3, config("GMM", 0));
        Object mascotas = clave.invoke(
                service, 3, config("Mascotas", 0));

        assertEquals(opc, opcionales);
        assertNotEquals(gmm, mascotas);
    }

    @Test
    public void sabanaOrdenaLegacyAntesDeExtensionesMigradas()
            throws Exception {
        Method orden = GeneradorReportesService.class.getDeclaredMethod(
                "ordenGrupoSabana", Map.class);
        orden.setAccessible(true);
        GeneradorReportesService service = new GeneradorReportesService();

        int gmm = (Integer) orden.invoke(service, config("GMM", 99));
        int vida = (Integer) orden.invoke(service, config("Vida", 0));
        int opc = (Integer) orden.invoke(service, config("OPC", 0));
        int mascotas = (Integer) orden.invoke(
                service, config("Mascotas", 0));

        assertTrue(gmm < vida);
        assertTrue(vida < opc);
        assertTrue(opc < mascotas);
    }

    @Test
    public void sabanaPrefiereOpcSobreAliasOpcionalesGlobal()
            throws Exception {
        Method prioridad = GeneradorReportesService.class.getDeclaredMethod(
                "prioridadAliasGrupoSabana", Map.class);
        prioridad.setAccessible(true);
        GeneradorReportesService service = new GeneradorReportesService();

        int opc = (Integer) prioridad.invoke(service, config("OPC", 2));
        int opcionales = (Integer) prioridad.invoke(
                service, config("Opcionales", 2));

        assertTrue(opc < opcionales);
    }

    @Test
    public void sabanaSoloPreservaColumnasDinamicasDeGmmYVida()
            throws Exception {
        Method preservar = GeneradorReportesService.class.getDeclaredMethod(
                "preservarColumnasDinamicasSabana", String.class);
        preservar.setAccessible(true);
        GeneradorReportesService service = new GeneradorReportesService();

        assertEquals(true, preservar.invoke(service, "GMM"));
        assertEquals(true, preservar.invoke(service, " Vida "));
        assertEquals(false, preservar.invoke(service, "OPC"));
        assertEquals(false, preservar.invoke(service, "Opcionales"));
        assertEquals(false, preservar.invoke(service, "Mascotas"));
    }

    private static Map<String, Object> config(String grupo, int indexTable) {
        Map<String, Object> config = new LinkedHashMap<>();
        config.put("grupo", grupo);
        config.put("indexTable", indexTable);
        return config;
    }

    private static LinkedCaseInsensitiveMap<Object> row(
            String key, Object value) {
        LinkedCaseInsensitiveMap<Object> row =
                new LinkedCaseInsensitiveMap<>();
        row.put(key, value);
        return row;
    }
}
