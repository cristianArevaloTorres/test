USE [FlexiForbesv2];
GO

SET NOCOUNT ON;

IF DB_NAME() <> N'FlexiForbesv2'
    THROW 50100, 'La base seleccionada no es FlexiForbesv2.', 1;

DECLARE @ObjetosRequeridos TABLE (
    Nombre sysname NOT NULL,
    Tipo char(2) NOT NULL
);

INSERT INTO @ObjetosRequeridos (Nombre, Tipo)
VALUES
    (N'dbo.ff_Empresa', N'U'),
    (N'dbo.ff_Empleado', N'U'),
    (N'dbo.ff_Vigencia', N'U'),
    (N'dbo.ff_ConfiguracionSabana', N'U'),
    (N'dbo.bf_CatReportesSP', N'U'),
    (N'dbo.bf_RepConf_Columna', N'U'),
    (N'dbo.ff_SabanaMascotas_BF3', N'P');

IF EXISTS (
    SELECT 1
    FROM @ObjetosRequeridos
    WHERE OBJECT_ID(Nombre, Tipo) IS NULL
)
BEGIN
    SELECT Nombre AS ObjetoFaltante, Tipo
    FROM @ObjetosRequeridos
    WHERE OBJECT_ID(Nombre, Tipo) IS NULL
    ORDER BY Nombre;

    THROW 50101, 'Faltan objetos requeridos. Revise el resultado anterior.', 1;
END;

IF COL_LENGTH(N'dbo.ff_Empleado', N'EMMunicipioDelegacionFiscal') IS NULL
    THROW 50102, 'Falta dbo.ff_Empleado.EMMunicipioDelegacionFiscal.', 1;

PRINT 'Prerrequisitos correctos. Puede ejecutar el script 01.';
GO
