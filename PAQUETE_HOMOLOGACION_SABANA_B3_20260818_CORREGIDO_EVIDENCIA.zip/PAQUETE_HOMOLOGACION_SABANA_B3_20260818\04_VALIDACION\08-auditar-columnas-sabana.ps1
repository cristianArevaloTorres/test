[CmdletBinding()]
param(
    [string]$LegacyConfigRoot = 'C:\REPOS\REPORTES\BeflexProduccion-QA (1)\BeflexProduccion-QA\FlexiForbesV2\comun\ConfiguracionReportes',
    [string]$Server = '(localdb)\MSSQLLocalDB',
    [string]$Database = 'FlexiForbesv2',
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'auditoria-sabana'),
    [int[]]$OnlyVigenciaId = @(),
    [switch]$SkipProcedureValidation
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Normalize-Group([object]$Value) {
    $group = if ($null -eq $Value) { '' } else { [string]$Value }
    $group = $group.Trim().ToLowerInvariant()
    if ($group -in @('opc', 'opcional', 'opcionales')) { return 'opcionales' }
    return $group
}

function Normalize-Field([object]$Value) {
    if ($null -eq $Value) { return '' }
    return ([string]$Value).Trim().ToLowerInvariant()
}

function Normalize-Text([object]$Value) {
    if ($null -eq $Value -or $Value -is [System.DBNull]) { return '' }
    return ([string]$Value).Replace("`r", '').Replace("`n", '').Trim()
}

function Convert-ToBool([object]$Value) {
    if ($null -eq $Value -or $Value -is [System.DBNull]) { return $false }
    if ($Value -is [bool]) { return $Value }
    if ($Value -is [ValueType]) { return [int]$Value -ne 0 }
    return (Normalize-Text $Value) -match '^(1|true|si|sí)$'
}

function Invoke-DataTable(
    [System.Data.SqlClient.SqlConnection]$Connection,
    [string]$Query
) {
    $command = $Connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = 180
    $adapter = [System.Data.SqlClient.SqlDataAdapter]::new($command)
    $table = [System.Data.DataTable]::new()
    [void]$adapter.Fill($table)
    $command.Dispose()
    $adapter.Dispose()
    return (, $table)
}

function Get-ProcedureSchema(
    [System.Data.SqlClient.SqlConnection]$Connection,
    [string]$Procedure,
    [System.Collections.IDictionary]$Parameters
) {
    $command = $Connection.CreateCommand()
    $command.CommandType = [System.Data.CommandType]::StoredProcedure
    $command.CommandText = $Procedure
    $command.CommandTimeout = 180
    foreach ($entry in $Parameters.GetEnumerator()) {
        $parameter = $command.Parameters.AddWithValue($entry.Key, $entry.Value)
        if ($entry.Value -is [string]) {
            $parameter.SqlDbType = [System.Data.SqlDbType]::VarChar
        }
    }

    $adapter = [System.Data.SqlClient.SqlDataAdapter]::new($command)
    $dataSet = [System.Data.DataSet]::new()
    try {
        [void]$adapter.Fill($dataSet)
        $resultSets = [System.Collections.Generic.List[object]]::new()
        foreach ($table in $dataSet.Tables) {
            $columns = [System.Collections.Generic.List[string]]::new()
            foreach ($column in $table.Columns) {
                $columns.Add([string]$column.ColumnName)
            }
            $resultSets.Add([pscustomobject]@{
                TableName = [string]$table.TableName
                Columns   = $columns.ToArray()
            })
        }
        return [pscustomobject]@{
            Success    = $true
            Error       = ''
            ResultSets  = $resultSets.ToArray()
        }
    }
    catch {
        return [pscustomobject]@{
            Success    = $false
            Error       = $_.Exception.Message
            ResultSets  = @()
        }
    }
    finally {
        $dataSet.Dispose()
        $adapter.Dispose()
        $command.Dispose()
    }
}

function Add-Finding(
    [System.Collections.Generic.List[object]]$List,
    [int]$CompanyId,
    [string]$Company,
    [string]$Group,
    [string]$Type,
    [string]$Field,
    [string]$Expected,
    [string]$Actual
) {
    $List.Add([pscustomobject]@{
        IdEmpresa = $CompanyId
        Empresa   = $Company
        Grupo     = $Group
        Tipo      = $Type
        Campo     = $Field
        Esperado  = $Expected
        Actual    = $Actual
    })
}

if (-not (Test-Path -LiteralPath $LegacyConfigRoot -PathType Container)) {
    throw "No existe la ruta de configuraciones legacy: $LegacyConfigRoot"
}

$resolvedLegacyRoot = (Resolve-Path -LiteralPath $LegacyConfigRoot).Path
$connectionString = "Server=$Server;Initial Catalog=$Database;Integrated Security=True;TrustServerCertificate=True;Application Name=AuditoriaSabana"
$connection = [System.Data.SqlClient.SqlConnection]::new($connectionString)
$connection.Open()

try {
    $dbTables = Invoke-DataTable $connection @'
SELECT idEmpresa, catReportesId, grupo, columnaGrupo, agruparPorColumna,
       indexTable, tituloTabla, activo
FROM dbo.bf_RepConf_Tabla WITH (NOLOCK)
WHERE catReportesId = 3;
'@
    $dbColumns = Invoke-DataTable $connection @'
SELECT idEmpresa, catReportesId, grupo, orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna WITH (NOLOCK)
WHERE catReportesId = 3;
'@

    $companyNames = Invoke-DataTable $connection @'
SELECT EMidEmpresa, EMNombre
FROM dbo.ff_Empresa WITH (NOLOCK);
'@

    $nameById = @{}
    foreach ($row in $companyNames.Rows) {
        $nameById[[int]$row.EMidEmpresa] = Normalize-Text $row.EMNombre
    }

    $xmlFiles = [System.Collections.Generic.List[object]]::new()
    foreach ($directory in Get-ChildItem -LiteralPath $resolvedLegacyRoot -Directory) {
        if ($directory.Name -ne 'Default' -and $directory.Name -notmatch '^\d+$') { continue }
        $path = Join-Path $directory.FullName 'SabanaConfig.xml'
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        $id = if ($directory.Name -eq 'Default') { 0 } else { [int]$directory.Name }
        $xmlFiles.Add([pscustomobject]@{ IdEmpresa = $id; Path = $path })
    }

    $xmlFindings = [System.Collections.Generic.List[object]]::new()
    $xmlSummary = [System.Collections.Generic.List[object]]::new()

    foreach ($item in ($xmlFiles | Sort-Object IdEmpresa)) {
        $companyId = [int]$item.IdEmpresa
        $company = if ($companyId -eq 0) { 'DEFAULT' } elseif ($nameById.ContainsKey($companyId)) { $nameById[$companyId] } else { '(sin registro en ff_Empresa)' }
        $before = $xmlFindings.Count
        try {
            $document = [System.Xml.XmlDocument]::new()
            $document.PreserveWhitespace = $false
            $document.Load([string]$item.Path)
            $legacyTables = @($document.SelectNodes('/REPORTESABANA/Tabla'))

            foreach ($legacyTable in $legacyTables) {
                $legacyGroupRaw = Normalize-Text $legacyTable.GetAttribute('Grupo')
                $legacyGroup = Normalize-Group $legacyGroupRaw
                $tableRows = @($dbTables.Rows | Where-Object {
                    [int]$_.idEmpresa -eq $companyId -and
                    (Normalize-Group $_.grupo) -eq $legacyGroup
                })

                if ($companyId -eq 0 -and $legacyGroup -eq 'opcionales') {
                    $preferred = @($tableRows | Where-Object { (Normalize-Text $_.grupo).ToUpperInvariant() -eq 'OPC' })
                    if ($preferred.Count -gt 0) { $tableRows = $preferred }
                }

                if ($tableRows.Count -eq 0) {
                    Add-Finding $xmlFindings $companyId $company $legacyGroupRaw 'TABLA_FALTANTE' '' 'configuración de grupo' 'sin fila en bf_RepConf_Tabla'
                    continue
                }

                $tableRow = $tableRows | Sort-Object indexTable | Select-Object -First 1
                $dbGroupRaw = Normalize-Text $tableRow.grupo
                $columnRows = @($dbColumns.Rows | Where-Object {
                    [int]$_.idEmpresa -eq $companyId -and
                    (Normalize-Text $_.grupo).Equals($dbGroupRaw, [System.StringComparison]::OrdinalIgnoreCase)
                } | Sort-Object { [int]$_.orden })

                $legacyGroupColumn = Normalize-Text $legacyTable.GetAttribute('ColumnaGrupo')
                $dbGroupColumn = Normalize-Text $tableRow.columnaGrupo
                if (-not $legacyGroupColumn.Equals($dbGroupColumn, [System.StringComparison]::OrdinalIgnoreCase)) {
                    Add-Finding $xmlFindings $companyId $company $legacyGroupRaw 'COLUMNA_GRUPO' $legacyGroupColumn $legacyGroupColumn $dbGroupColumn
                }

                $removeNode = $legacyTable.SelectSingleNode('./REMOVERCOLUMNAS')
                $removed = @()
                $removedSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
                if ($null -ne $removeNode) {
                    $removed = @((Normalize-Text $removeNode.InnerText).Split('|') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
                    foreach ($removedField in $removed) { [void]$removedSet.Add($removedField) }
                }

                $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
                $lastOrder = -1
                $nodes = @($legacyTable.SelectNodes('./COLUMNAS/*'))
                foreach ($node in $nodes) {
                    $field = Normalize-Text $node.Name
                    if (-not $seen.Add($field)) { continue }
                    # Legacy ejecuta REMOVERCOLUMNAS antes de ordenar/renombrar;
                    # una exclusión gana aunque el campo también esté en COLUMNAS.
                    if ($removedSet.Contains($field)) { continue }
                    $header = Normalize-Text $node.InnerText
                    $matches = @($columnRows | Where-Object {
                        (Normalize-Field $_.campoOrigen) -eq (Normalize-Field $field) -and
                        (Convert-ToBool $_.visible)
                    })
                    if ($matches.Count -eq 0) {
                        Add-Finding $xmlFindings $companyId $company $legacyGroupRaw 'COLUMNA_VISIBLE_FALTANTE' $field $header 'sin columna visible'
                        continue
                    }
                    $match = $matches | Sort-Object { [int]$_.orden } | Select-Object -First 1
                    $actualHeader = Normalize-Text $match.encabezado
                    if (-not $header.Equals($actualHeader, [System.StringComparison]::Ordinal)) {
                        Add-Finding $xmlFindings $companyId $company $legacyGroupRaw 'ENCABEZADO_DIFERENTE' $field $header $actualHeader
                    }
                    $actualOrder = [int]$match.orden
                    if ($actualOrder -lt $lastOrder) {
                        Add-Finding $xmlFindings $companyId $company $legacyGroupRaw 'ORDEN_DIFERENTE' $field "después de orden $lastOrder" "orden $actualOrder"
                    }
                    $lastOrder = [Math]::Max($lastOrder, $actualOrder)
                }

                if ($null -ne $removeNode) {
                    foreach ($field in ($removed | Select-Object -Unique)) {
                        $hidden = @($columnRows | Where-Object {
                            (Normalize-Field $_.campoOrigen) -eq (Normalize-Field $field) -and
                            -not (Convert-ToBool $_.visible)
                        })
                        if ($hidden.Count -eq 0) {
                            Add-Finding $xmlFindings $companyId $company $legacyGroupRaw 'EXCLUSION_FALTANTE' $field 'visible=0' 'no configurada'
                        }
                    }
                }
            }
        }
        catch {
            Add-Finding $xmlFindings $companyId $company '' 'XML_INVALIDO' '' 'XML legible' $_.Exception.Message
        }

        $xmlSummary.Add([pscustomobject]@{
            IdEmpresa = $companyId
            Empresa   = $company
            Archivo   = [string]$item.Path
            Hallazgos = $xmlFindings.Count - $before
            Estado    = if ($xmlFindings.Count -eq $before) { 'OK' } else { 'REVISAR' }
        })
    }

    $schemaFindings = [System.Collections.Generic.List[object]]::new()
    $schemaSummary = [System.Collections.Generic.List[object]]::new()
    $coveredCompanies = [System.Data.DataTable]::new()
    $opcLegacyProcedureUsed = 'NO_VALIDADO'

    if (-not $SkipProcedureValidation) {
        $representatives = Invoke-DataTable $connection @'
;WITH CompanyCandidate AS (
    SELECT E.EMidEmpresa, E.EMNombre, E.EMidConfiguracion,
           ROW_NUMBER() OVER (
               PARTITION BY E.EMidConfiguracion
               ORDER BY CASE WHEN E.EMidPadre = 0 THEN 0 ELSE 1 END, E.EMidEmpresa
           ) AS rn
    FROM dbo.ff_Empresa E WITH (NOLOCK)
    WHERE E.EMidEstatus = 1
      AND EXISTS (
          SELECT 1
          FROM dbo.ff_ConfiguracionSabana CS WITH (NOLOCK)
          WHERE CS.CSidConfiguracion = E.EMidConfiguracion
            AND CS.CSidEstatus = 1
      )
), Representative AS (
    SELECT EMidEmpresa,EMNombre,EMidConfiguracion
    FROM CompanyCandidate WHERE rn=1
)
SELECT R.EMidEmpresa, R.EMNombre, R.EMidConfiguracion,
       V.VIidVigencia, V.VIVigenciaIni, V.VIVigenciaFin
FROM Representative R
INNER JOIN dbo.ff_Vigencia V WITH (NOLOCK)
    ON V.VIidConfiguracion=R.EMidConfiguracion
   AND V.VIidEstatus<>4
ORDER BY R.EMidConfiguracion,V.VIVigenciaIni,V.VIidVigencia;
'@

        $coveredCompanies = Invoke-DataTable $connection @'
SELECT E.EMidEmpresa, E.EMNombre, E.EMidConfiguracion,
       COUNT(DISTINCT V.VIidVigencia) VigenciasValidadas
FROM dbo.ff_Empresa E WITH (NOLOCK)
INNER JOIN dbo.ff_Vigencia V WITH (NOLOCK)
    ON V.VIidConfiguracion = E.EMidConfiguracion
   AND V.VIidEstatus <> 4
WHERE E.EMidEstatus = 1
  AND EXISTS (
      SELECT 1
      FROM dbo.ff_ConfiguracionSabana CS WITH (NOLOCK)
      WHERE CS.CSidConfiguracion = E.EMidConfiguracion
        AND CS.CSidEstatus = 1
  )
GROUP BY E.EMidEmpresa,E.EMNombre,E.EMidConfiguracion
ORDER BY E.EMIdConfiguracion, E.EMidEmpresa;
'@

        $opcLegacyCheck = Invoke-DataTable $connection @'
SELECT CASE WHEN OBJECT_ID(N'dbo.ff_SabanaOPC', N'P') IS NULL
            THEN 0 ELSE 1 END Existe;
'@
        $hasOriginalOpc = [int]$opcLegacyCheck.Rows[0].Existe -eq 1
        $opcLegacyProcedureUsed = if ($hasOriginalOpc) {
            'dbo.ff_SabanaOPC'
        } else {
            'dbo.ff_SabanaOPC_BF3'
        }

        $groups = @(
            [pscustomobject]@{ Group = 'GMM'; Legacy = 'dbo.ff_SabanaGMM'; Migrated = 'dbo.ff_SabanaGMM_v2'; LegacyOldParameters = $true },
            [pscustomobject]@{ Group = 'Vida'; Legacy = 'dbo.ff_SabanaVIDA'; Migrated = 'dbo.ff_SabanaVIDA_v2'; LegacyOldParameters = $true },
            [pscustomobject]@{ Group = 'Opcionales'; Legacy = $opcLegacyProcedureUsed; Migrated = 'dbo.ff_SabanaOPC_v2'; LegacyOldParameters = $hasOriginalOpc }
        )

        $representativeRows = @($representatives.Rows)
        if ($OnlyVigenciaId.Count -gt 0) {
            $representativeRows = @($representativeRows | Where-Object {
                $OnlyVigenciaId -contains [int]$_.VIidVigencia
            })
        }

        foreach ($representative in $representativeRows) {
            $companyId = [int]$representative.EMidEmpresa
            $company = Normalize-Text $representative.EMNombre
            $configurationId = [int]$representative.EMidConfiguracion
            $vigenciaId = [int]$representative.VIidVigencia
            $start = if ($representative.VIVigenciaIni -is [DateTime]) { ([DateTime]$representative.VIVigenciaIni).ToString('yyyyMMdd') } else { '20000101' }
            $end = if ($representative.VIVigenciaFin -is [DateTime]) { ([DateTime]$representative.VIVigenciaFin).ToString('yyyyMMdd') } else { (Get-Date).ToString('yyyyMMdd') }
            $before = $schemaFindings.Count

            foreach ($definition in $groups) {
                $legacyParameters = if ($definition.LegacyOldParameters) {
                    [ordered]@{
                        '@idEmpresa'    = $companyId
                        '@Confidencial' = 0
                        '@FechaCorte'   = $end
                        '@idEstatus'    = 1
                        '@idVigencia'   = $vigenciaId
                    }
                }
                else {
                    [ordered]@{
                        '@idEmpresa'    = $companyId
                        '@FechaIni'     = $start
                        '@FechaFin'     = $end
                        '@idEstatus'    = 1
                        '@idVigencia'   = $vigenciaId
                        '@Confidencial' = 0
                    }
                }
                $migratedParameters = [ordered]@{
                    '@idEmpresa'    = $companyId
                    '@FechaIni'     = $start
                    '@FechaFin'     = $end
                    '@idEstatus'    = 1
                    '@idVigencia'   = $vigenciaId
                    '@Confidencial' = 0
                }

                $legacySchema = Get-ProcedureSchema $connection $definition.Legacy $legacyParameters
                $migratedSchema = Get-ProcedureSchema $connection $definition.Migrated $migratedParameters

                if (-not $legacySchema.Success) {
                    Add-Finding $schemaFindings $companyId $company $definition.Group 'ERROR_LEGACY' '' 'ejecución correcta' $legacySchema.Error
                    continue
                }
                if (-not $migratedSchema.Success) {
                    Add-Finding $schemaFindings $companyId $company $definition.Group 'ERROR_MIGRADO' '' 'ejecución correcta' $migratedSchema.Error
                    continue
                }

                $legacyColumns = if ($legacySchema.ResultSets.Count -gt 0) { @($legacySchema.ResultSets[0].Columns) } else { @() }
                $migratedColumns = if ($migratedSchema.ResultSets.Count -gt 0) { @($migratedSchema.ResultSets[0].Columns) } else { @() }
                if ($legacyColumns.Count -gt 0 -and $migratedColumns.Count -eq 0) {
                    Add-Finding $schemaFindings $companyId $company $definition.Group 'RESULTSET_FALTANTE' '' ($legacyColumns -join ',') 'sin resultset'
                    continue
                }

                $available = [System.Collections.Generic.List[string]]::new()
                foreach ($column in $migratedColumns) {
                    if ((Normalize-Field $column) -ne 'grupo') { $available.Add([string]$column) }
                }
                foreach ($legacyColumn in $legacyColumns) {
                    if ((Normalize-Field $legacyColumn) -eq 'grupo') { continue }
                    $matchedIndex = -1
                    for ($index = 0; $index -lt $available.Count; $index++) {
                        if ((Normalize-Field $available[$index]) -eq (Normalize-Field $legacyColumn)) {
                            $matchedIndex = $index
                            break
                        }
                    }
                    if ($matchedIndex -ge 0) {
                        $available.RemoveAt($matchedIndex)
                    }
                    else {
                        Add-Finding $schemaFindings $companyId $company $definition.Group 'COLUMNA_SP_FALTANTE' $legacyColumn $legacyColumn ($migratedColumns -join ',')
                    }
                }
            }

            $schemaSummary.Add([pscustomobject]@{
                IdEmpresa       = $companyId
                Empresa         = $company
                IdConfiguracion = $configurationId
                IdVigencia      = $vigenciaId
                Hallazgos       = $schemaFindings.Count - $before
                Estado          = if ($schemaFindings.Count -eq $before) { 'OK' } else { 'REVISAR' }
            })
        }
    }

    if (-not (Test-Path -LiteralPath $OutputDirectory -PathType Container)) {
        [void](New-Item -ItemType Directory -Path $OutputDirectory)
    }
    $resolvedOutput = (Resolve-Path -LiteralPath $OutputDirectory).Path
    $xmlSummary | Export-Csv -LiteralPath (Join-Path $resolvedOutput '01-resumen-xml.csv') -NoTypeInformation -Encoding UTF8
    $xmlFindings | Export-Csv -LiteralPath (Join-Path $resolvedOutput '02-hallazgos-xml.csv') -NoTypeInformation -Encoding UTF8
    if (-not $SkipProcedureValidation) {
        $schemaSummary | Export-Csv -LiteralPath (Join-Path $resolvedOutput '03-resumen-procedimientos.csv') -NoTypeInformation -Encoding UTF8
        $schemaFindings | Export-Csv -LiteralPath (Join-Path $resolvedOutput '04-hallazgos-procedimientos.csv') -NoTypeInformation -Encoding UTF8
        $coveredCompanies | Export-Csv -LiteralPath (Join-Path $resolvedOutput '05-empresas-cubiertas.csv') -NoTypeInformation -Encoding UTF8
    }

    $result = [pscustomobject]@{
        XmlAuditFiles             = $xmlSummary.Count
        XmlAuditOk                = @($xmlSummary | Where-Object Estado -eq 'OK').Count
        XmlFindings               = $xmlFindings.Count
        ProcedureConfigurations   = $schemaSummary.Count
        ProcedureConfigurationsOk = @($schemaSummary | Where-Object Estado -eq 'OK').Count
        ProcedureFindings         = $schemaFindings.Count
        CoveredCompanies          = if ($SkipProcedureValidation) { 0 } else { $coveredCompanies.Rows.Count }
        OpcLegacyProcedureUsed    = $opcLegacyProcedureUsed
        OutputDirectory           = $resolvedOutput
    }
    $result | Format-List

    if ($xmlFindings.Count -gt 0 -or $schemaFindings.Count -gt 0) {
        exit 2
    }
}
finally {
    $connection.Close()
    $connection.Dispose()
}
