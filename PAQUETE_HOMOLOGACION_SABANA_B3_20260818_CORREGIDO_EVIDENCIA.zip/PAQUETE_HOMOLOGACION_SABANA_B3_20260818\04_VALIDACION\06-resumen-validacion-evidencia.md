# Validacion profunda de evidencia Sabana B2/B3

Fecha: 18/08/2026

Se compararon los libros B2/B3 de Corteva, SSGT, ATT y BH por hojas,
encabezados, filas y llaves estables. Antes de la correccion se confirmaron:

- Corteva Vida: 219 registros legacy duplicados en B3 (438 filas).
- Una hoja adicional de Mascotas en Corteva, SSGT y ATT.
- Entre 61 y 64 columnas ajenas anexadas a cada hoja opcional.
- `PrimaNeta` vacia en lugar de cero para planes sin tarifa de ATT.
- 28 encabezados de Corteva con nombre distinto y dos alias de hoja distintos.

Se corrigieron los dos flujos redundantes de Vida, la preservacion de columnas
dinamicas en Opcionales, la llamada adicional de Mascotas, la normalizacion de
`PrimaNeta` y los encabezados/alias demostrados por la evidencia.

Validacion posterior:

- Cuatro procedimientos recompilados correctamente en SQL Server.
- `ff_Sabana_v2` ejecutado sin error para empresas 116, 166, 856 y 1038.
- API: 11 pruebas, 0 fallas, 0 errores.

La base local no contiene filas operativas de empleados, solicitudes o planes.
La validacion final requiere regenerar B2/B3 en QA/VPN con los mismos parametros.
Revisar especialmente las diferencias residuales de SSGT: -3 filas en
`GMM ASOCIADOS`, -8 netas en `GMM EMPLEADOS` y -6 netas en `VIDA SALLES`.
