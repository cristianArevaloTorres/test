package com.lockton.rpt.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.springframework.util.LinkedCaseInsensitiveMap;

public class ExcelHojaMultipleHomologacionTest {

    @Test
    public void conservaDinamicasOcultaTecnicasYNoPierdeCeros() throws Exception {
        ArrayList<LinkedCaseInsensitiveMap<?>> primerResultset = rows(
                row("grupo", "GMM",
                        "NombrePestana", "MISMA HOJA",
                        "IDEmp", 7,
                        "EMNumeroEmpleado", "000007",
                        "Plan dinamico", "SI",
                        "Folio", "F-7"));
        ArrayList<LinkedCaseInsensitiveMap<?>> segundoResultset = rows(
                row("grupo", "GMM",
                        "NombrePestana", "MISMA HOJA",
                        "IDEmp", 8,
                        "EMNumeroEmpleado", "000008",
                        "Plan dinamico", "NO",
                        "Folio", "F-8"));

        Map<String, Object> grupo = new LinkedHashMap<>();
        grupo.put("grupo", "GMM");
        grupo.put("indexTable", 0);
        grupo.put("columnaGrupo", "NombrePestana");
        grupo.put("agruparPorColumna", true);
        grupo.put("alineacion", "Izquierda");
        grupo.put("preservarColumnasDinamicas", true);
        grupo.put("columnas", Arrays.asList(
                columna("EMNumeroEmpleado", "No. Empleado", true, 6),
                columna("NombrePestana", "NombrePestana", false, 6),
                columna("IDEmp", "IDEmp", false, 6)));

        Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("reporteId", 3);
        parametros.put("reporteConfig", Collections.singletonList(grupo));
        File output = Files.createTempDirectory(
                "sabana-excel-test-").toFile();

        String ruta = Excel_Hoja_Multiple.generar(
                Arrays.asList(primerResultset, segundoResultset),
                parametros, output.getAbsolutePath());

        assertNotNull(ruta);
        try (FileInputStream input = new FileInputStream(ruta);
                XSSFWorkbook workbook = new XSSFWorkbook(input)) {
            assertEquals(2, workbook.getNumberOfSheets());
            assertEquals("MISMA HOJA", workbook.getSheetName(0));
            assertEquals("MISMA HOJA (2)", workbook.getSheetName(1));

            Row header = workbook.getSheetAt(0).getRow(0);
            assertEquals("No. Empleado", header.getCell(0).getStringCellValue());
            assertEquals("Plan dinamico", header.getCell(1).getStringCellValue());
            assertEquals("Folio", header.getCell(2).getStringCellValue());
            assertEquals(3, header.getLastCellNum());

            Row data = workbook.getSheetAt(0).getRow(1);
            assertEquals(CellType.STRING, data.getCell(0).getCellType());
            assertEquals("000007", data.getCell(0).getStringCellValue());
            assertEquals("SI", data.getCell(1).getStringCellValue());
            assertEquals("F-7", data.getCell(2).getStringCellValue());
        }
    }

    @Test
    public void noConfundeCostoSinGuionConCostoDinamico() throws Exception {
        ArrayList<LinkedCaseInsensitiveMap<?>> resultset = rows(
                row("grupo", "Vida",
                        "NombrePestana", "VIDA",
                        "Costo", "100",
                        "Costo_1", "200"));

        Map<String, Object> grupo = new LinkedHashMap<>();
        grupo.put("grupo", "Vida");
        grupo.put("indexTable", 0);
        grupo.put("columnaGrupo", "NombrePestana");
        grupo.put("agruparPorColumna", true);
        grupo.put("preservarColumnasDinamicas", true);
        grupo.put("columnas", Arrays.asList(
                columna("Costo", "Costo", true, 6),
                columna("Costo1", "Costo", true, 6)));

        Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("reporteId", 3);
        parametros.put("reporteConfig", Collections.singletonList(grupo));
        File output = Files.createTempDirectory(
                "sabana-costo-test-").toFile();

        String ruta = Excel_Hoja_Multiple.generar(
                Collections.singletonList(resultset), parametros,
                output.getAbsolutePath());

        try (FileInputStream input = new FileInputStream(ruta);
                XSSFWorkbook workbook = new XSSFWorkbook(input)) {
            Row header = workbook.getSheet("VIDA").getRow(0);
            assertEquals("Costo", header.getCell(0).getStringCellValue());
            assertEquals("Costo_1", header.getCell(1).getStringCellValue());
            assertEquals(2, header.getLastCellNum());
        }
    }

    @Test
    public void opcionalesSoloEscribeColumnasConfiguradas() throws Exception {
        ArrayList<LinkedCaseInsensitiveMap<?>> resultset = rows(
                row("grupo", "OPC",
                        "NombrePestana", "DENTAL",
                        "EMNumeroEmpleado", "000123",
                        "PONombre", "Dental familiar",
                        "Cobertura_ajena", "SI",
                        "Costo_ajeno", "999"));

        Map<String, Object> grupo = new LinkedHashMap<>();
        grupo.put("grupo", "OPC");
        grupo.put("indexTable", 0);
        grupo.put("columnaGrupo", "NombrePestana");
        grupo.put("agruparPorColumna", true);
        grupo.put("preservarColumnasDinamicas", false);
        grupo.put("columnas", Arrays.asList(
                columna("EMNumeroEmpleado", "No. Empleado", true, 6),
                columna("PONombre", "PONombre", true, 6)));

        Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("reporteId", 3);
        parametros.put("reporteConfig", Collections.singletonList(grupo));
        File output = Files.createTempDirectory(
                "sabana-opc-test-").toFile();

        String ruta = Excel_Hoja_Multiple.generar(
                Collections.singletonList(resultset), parametros,
                output.getAbsolutePath());

        try (FileInputStream input = new FileInputStream(ruta);
                XSSFWorkbook workbook = new XSSFWorkbook(input)) {
            Row header = workbook.getSheet("DENTAL").getRow(0);
            assertEquals("No. Empleado",
                    header.getCell(0).getStringCellValue());
            assertEquals("PONombre",
                    header.getCell(1).getStringCellValue());
            assertEquals(2, header.getLastCellNum());
        }
    }

    private static Map<String, Object> columna(
            String campo, String encabezado, boolean visible, int tipo) {
        Map<String, Object> columna = new LinkedHashMap<>();
        columna.put("campoOrigen", campo);
        columna.put("encabezado", encabezado);
        columna.put("visible", visible);
        columna.put("tipoDato", tipo);
        return columna;
    }

    private static LinkedCaseInsensitiveMap<Object> row(Object... values) {
        LinkedCaseInsensitiveMap<Object> row =
                new LinkedCaseInsensitiveMap<>();
        for (int i = 0; i < values.length; i += 2) {
            row.put(String.valueOf(values[i]), values[i + 1]);
        }
        return row;
    }

    @SafeVarargs
    private static ArrayList<LinkedCaseInsensitiveMap<?>> rows(
            LinkedCaseInsensitiveMap<Object>... rows) {
        return new ArrayList<LinkedCaseInsensitiveMap<?>>(
                Arrays.<LinkedCaseInsensitiveMap<?>>asList(rows));
    }
}
