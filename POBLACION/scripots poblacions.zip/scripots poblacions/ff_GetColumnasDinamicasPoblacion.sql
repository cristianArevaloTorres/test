1. 
2. 
3. 
4. 
5. 
Si todos coinciden, revisaremos después ff_CObtenPlantilla
