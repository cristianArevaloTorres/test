**Asunto:** Ajuste aislado al SOAP para convivencia BF2/BF3 de Deloitte

Hola equipo,

Se preparó un ajuste en la clase `CargaMasivaProcess` para permitir que las dos configuraciones de carga masiva de Deloitte convivan dentro del SOAP.

La lógica nueva se evalúa exclusivamente cuando la autenticación identifica a la empresa interna 186 (Deloitte) y la operación es la 2. Para cualquier otra empresa, el servicio continúa directamente con el comportamiento anterior y no consulta las plantillas de Deloitte.

Para Deloitte, antes de construir los parámetros y ejecutar el procedimiento de negocio, el servicio intenta seleccionar la configuración correspondiente según la cantidad de posiciones recibidas:

- 32 posiciones: plantilla 507 y `ff_XCMTitularesAltaCMDeloitte`.
- 23 posiciones: plantilla 12062 y `ff_XCMTitularesAltaCMM_BF3`.

La evaluación nueva está encapsulada. Si ocurre una excepción, falta una configuración, hay una duplicidad o no es posible identificar de forma única el formato recibido, el error no se propaga al endpoint: se conserva la configuración obtenida originalmente por el servicio y la petición continúa por el flujo anterior.

Con esto se protege la operación compartida del SOAP. Una falla en la selección nueva no detiene el servicio y no modifica el procesamiento de las demás empresas. Tampoco se agregaron logs o mensajes `Debug`.

No se modifican el WSDL, los métodos públicos, los parámetros, los tipos de respuesta, `Web.config`, Java ni objetos de base de datos. El único archivo fuente modificado es `Administracion\CargaMasivaProcess.cs`.

Para realizar el cambio de forma segura se debe obtener del servidor la DLL que actualmente atiende el servicio:

`<ruta física del sitio IIS>\bin\ServiciosLocktonTI.dll`

Esa DLL debe respaldarse y decompilarse para confirmar que la clase publicada corresponde con la fuente usada para el ajuste. Después de integrar y compilar el cambio en Release con las referencias originales, el archivo que se envía a Infraestructura para su despliegue es la nueva:

`ServiciosLocktonTI.dll`

El reemplazo se realiza en la carpeta `bin` del mismo sitio, conservando la DLL anterior para rollback. No deben sustituirse `Web.config`, DLL de terceros ni otros servicios como parte de esta entrega.

Las pruebas técnicas comprobaron que:

1. El formato de 32 posiciones selecciona BF2.
2. El formato de 23 posiciones selecciona BF3.
3. Un conteo no reconocido conserva el flujo anterior.
4. Una excepción simulada en la selección no llega al SOAP y conserva el flujo anterior.
5. Una empresa distinta de Deloitte no entra al selector ni consulta sus plantillas.

Saludos.
