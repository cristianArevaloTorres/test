# DLL que se debe decompilar y DLL que se debe enviar

## DLL que se debe obtener y decompilar

Del servidor IIS que actualmente atiende la URL real del SOAP:

`<ruta física del sitio IIS>\bin\ServiciosLocktonTI.dll`

No debe utilizarse una DLL de una descarga histórica, de otro ambiente ni `Data.dll`.

La ruta física correcta se obtiene en IIS Manager, seleccionando la aplicación del SOAP y abriendo **Basic Settings / Configuración básica**. Dentro de esa ruta deben aparecer los `.svc` que consume el cliente y la carpeta `bin`.

Antes de decompilar, se debe respaldar y calcular el SHA-256 de:

- `ServiciosLocktonTI.dll`.
- `ServiciosLocktonTI.pdb`, si está publicado.
- `Web.config`, únicamente como respaldo; no se modifica para este cambio.

En la decompilación se debe comprobar la existencia de:

- `ServiciosLocktonTI.Administracion.CargaMasivaProcess`.
- `CargaRapida(...)`.
- `CargaRapida_(...)`.
- `GetOperationProperties()`.
- `FieldNameCons(...)`.
- Las clases `ServiciosLocktonTI.Servicios.BF_wbsABC_Empleados` y `ServiciosLocktonTI.Servicios.EmpleadoService`.

También debe confirmarse que la versión publicada continúa obteniendo configuración mediante `ff_CCMOperacionPropiedades`, campos mediante `ff_CPlantillaCampos` y ejecutando el SP indicado en `CEStoredProc`.

## Archivo que debe compilarse

El archivo incluido en este ZIP:

`CargaMasivaProcess.cs`

Debe incorporarse a la fuente que haya sido confirmada contra la DLL publicada. No se debe copiar el `.cs` directamente al servidor esperando que IIS lo compile.

## DLL que se debe enviar para despliegue

Después de integrar, compilar en Release para .NET Framework 4.6.1 y homologar el cambio, se envía:

`ServiciosLocktonTI.dll`

La DLL debe proceder del directorio de salida del proyecto verificado, normalmente:

`bin\ServiciosLocktonTI.dll`

Si el procedimiento interno usa símbolos, puede enviarse también el `ServiciosLocktonTI.pdb` generado en la misma compilación. El PDB no debe mezclarse con uno anterior.

No se deben enviar como parte de este cambio:

- `Web.config`.
- DLL de terceros.
- `Data.dll`.
- Objetos o scripts de modificación de BD.
- La DLL decompilada original como si fuera el binario nuevo.

## Despliegue y rollback

1. Respaldar la DLL publicada actual.
2. Verificar el SHA-256 del artefacto nuevo homologado.
3. Sustituir `bin\ServiciosLocktonTI.dll` durante la ventana acordada.
4. Reciclar únicamente el application pool del SOAP.
5. Probar Deloitte con 23 y 32 posiciones y al menos una empresa distinta.
6. Si se requiere rollback, restaurar la DLL respaldada y reciclar nuevamente el application pool.
