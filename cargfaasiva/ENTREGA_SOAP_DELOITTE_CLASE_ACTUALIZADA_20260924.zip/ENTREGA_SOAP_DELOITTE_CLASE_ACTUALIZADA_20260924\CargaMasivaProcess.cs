using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;

//using XmlWebServices.RepCobranza;
//using XmlWebServices.Utils;

namespace ServiciosLocktonTI.Administracion
{
 
    public class CargaMasivaProcess
    {
        private const string DocumentFolder = "DocumentoEmpresa";
        private const int DeloitteCompanyId = 186;
        private const int TitularRegistrationOperationId = 2;
        private const int DeloitteBf2TemplateId = 507;
        private const int DeloitteBf3TemplateId = 12062;
        private const string DeloitteBf2StoredProcedure = "ff_XCMTitularesAltaCMDeloitte";
        private const string DeloitteBf3StoredProcedure = "ff_XCMTitularesAltaCMM_BF3";
        private readonly CommonBusiness commonBiz;
        private bool _logEnabled;
        private int _idEmpresa;
        private int _idOperacion;
        private int _idDocumento;
        private int _idUsuario;
        private string _nombreEmpresa;
        private string _logFilename;
        private string _logPath;
        private string _appRootPath;
        private CargaMasivaExecutionResult _result;
        private CargaMasivaExecutionMode _mode;
        private CargaMasivaDocumento _documento;
        private CargaMasivaParser _parser;
        private DataTable _operationConfigurations;
        private DataRow _operationProperties;
        private Plantilla _plantilla;
        private SortedList _options;
        private StreamWriter _log;

        public CargaMasivaProcess(string appRootPath, bool useLog)
        {
            this.commonBiz = new CommonBusiness();
            switch (appRootPath)
            {
                case "":
                case null:
                    throw new ArgumentException("La ruta a la raíz de la aplicación no es válida.", nameof(appRootPath));
                default:
                    this._appRootPath = appRootPath;
                    this._logEnabled = useLog;
                    break;
            }
        }

        public CargaMasivaProcess(string appRootPath, bool useLog, string Validator)
        {
            this.commonBiz = new CommonBusiness();
            switch (appRootPath)
            {
                case "":
                case null:
                    throw new ArgumentException("La ruta a la raíz de la aplicación no es válida.", nameof(appRootPath));
                default:
                    this._appRootPath = appRootPath;
                    this._logEnabled = useLog;
                    break;
            }
        }

        public string LogFileName
        {
            get
            {
                return this._logFilename;
            }
        }

        public string LogFilePath
        {
            get
            {
                return this._logPath;
            }
        }

        private bool Initialize()
        {
            bool flag = true;
            this.RecordToLog(string.Format("[{0}]: Archivo de registro inicializado correctamente.", (object)DateTime.Now.ToLongTimeString()));
            try
            {
                this.GetOperationProperties();
                this.RecordToLog(string.Format("[{0}]: Se han cargado las propiedades de la operación.", (object)DateTime.Now.ToLongTimeString()));
                this._documento = new CargaMasivaDocumento(this._idDocumento, this._appRootPath);
                this._documento.Open();
                this.RecordToLog(string.Format("[{0}]: Documento de datos para Carga Masiva inicializado correctamente.", (object)DateTime.Now.ToLongTimeString()));
                this._plantilla = new Plantilla(int.Parse(this._operationProperties["CEIdPlantilla"].ToString()), this._options);
                this.RecordToLog(string.Format("[{0}]: Plantilla para Carga Masiva inicializada correctamente.", (object)DateTime.Now.ToLongTimeString()));
                this._parser = new CargaMasivaParser(this._plantilla, this._documento);
                if (!this._parser.Initialize())
                {
                    this.RecordToLog(string.Format("[{0}]: La inicialización del analizador de Carga Masiva ha fallado: {1}", (object)DateTime.Now.ToLongTimeString(), (object)this._parser.GetLastError()));
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.RecordToLog(string.Format("[{0}]: Error durante la inicializacion: {1} ({2}\n{3})", (object)DateTime.Now.ToLongTimeString(), (object)ex.Message, (object)ex.GetType().ToString(), (object)ex.StackTrace));
                flag = false;
            }
            return flag;
        }

        private new void Finalize()
        {
            if (this._log == null)
                return;
            this._log.Flush();
            this._log.Close();
            this._log = (StreamWriter)null;
            string logPath = this._logPath;
            string logFilename = this._logFilename;
            this._logPath = this._documento != null ? this._documento.FilePath : this._logPath;
            this._logFilename = this._documento != null ? string.Format("{0}_{1}.txt", (object)this._documento.FileName, (object)DateTime.Now.ToString("yyyyMMdd_HHmm")) : this._logFilename;
            File.Move(this._appRootPath + logPath + logFilename, this._appRootPath + this._logPath + this._logFilename);
        }

        private void GetOperationProperties()
        {
            DataSet operationProperties = this.commonBiz.ExecuteStoredProcedure(new SqlParameter[2]
            {
        new SqlParameter("@IdOperacion", (object) this._idOperacion),
        new SqlParameter("@IdEmpresa", (object) this._idEmpresa)
            }, "ff_CCMOperacionPropiedades", string.Empty);

            this._operationConfigurations = operationProperties.Tables[0];
            this._operationProperties = this._operationConfigurations.Rows[0];
        }

        private void TryApplyDeloitteRoute(string register)
        {
            if (this._idEmpresa != DeloitteCompanyId ||
                this._idOperacion != TitularRegistrationOperationId)
                return;

            try
            {
                if (register == null)
                    return;

                string[] documentFieldValues = register.Split('|');
                int bf2FieldCount = this.FieldNameCons(DeloitteBf2TemplateId).Length;
                int bf3FieldCount = this.FieldNameCons(DeloitteBf3TemplateId).Length;
                DataRow selectedConfiguration = null;

                if (documentFieldValues.Length == bf2FieldCount &&
                    documentFieldValues.Length != bf3FieldCount)
                {
                    selectedConfiguration = this.FindDeloitteConfiguration(
                        DeloitteBf2TemplateId,
                        DeloitteBf2StoredProcedure);
                }
                else if (documentFieldValues.Length == bf3FieldCount &&
                         documentFieldValues.Length != bf2FieldCount)
                {
                    selectedConfiguration = this.FindDeloitteConfiguration(
                        DeloitteBf3TemplateId,
                        DeloitteBf3StoredProcedure);
                }

                if (selectedConfiguration != null)
                    this._operationProperties = selectedConfiguration;
            }
            catch
            {
                // Con esto aseguramos que sólo aplique para Deloitte y que, si falla el flujo nuevo, se conserve el flujo anterior.
            }
        }

        private DataRow FindDeloitteConfiguration(int templateId, string storedProcedure)
        {
            if (this._operationConfigurations == null)
                return null;

            DataRow selectedConfiguration = null;
            foreach (DataRow configuration in this._operationConfigurations.Rows)
            {
                int configuredTemplateId;
                if (!int.TryParse(
                    configuration["CEIdPlantilla"].ToString(),
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out configuredTemplateId) ||
                    configuredTemplateId != templateId ||
                    !StoredProcedureNamesEqual(
                        configuration["CEStoredProc"].ToString(),
                        storedProcedure))
                    continue;

                if (selectedConfiguration != null)
                    return null;

                selectedConfiguration = configuration;
            }

            return selectedConfiguration;
        }

        private static bool StoredProcedureNamesEqual(string configuredName, string expectedName)
        {
            string normalizedConfiguredName = NormalizeStoredProcedureName(configuredName);
            string normalizedExpectedName = NormalizeStoredProcedureName(expectedName);
            return string.Equals(
                normalizedConfiguredName,
                normalizedExpectedName,
                StringComparison.OrdinalIgnoreCase);
        }

        private static string NormalizeStoredProcedureName(string storedProcedureName)
        {
            string normalizedName = (storedProcedureName ?? string.Empty)
                .Replace("[", string.Empty)
                .Replace("]", string.Empty)
                .Trim();
            if (normalizedName.StartsWith("dbo.", StringComparison.OrdinalIgnoreCase))
                normalizedName = normalizedName.Substring(4);
            return normalizedName;
        }

        private void RecordToLog(string message)
        {
            if (!this._logEnabled)
                return;
            if (this._log == null)
            {
                this._logFilename = string.Format("cm_{0}.tmp", (object)DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                this._logPath = string.Format("{0}\\temp\\", (object)"DocumentoEmpresa");
                if (!Directory.Exists(this._appRootPath + this._logPath))
                    Directory.CreateDirectory(this._appRootPath + this._logPath);
            //    this._log = new StreamWriter(this._appRootPath + this._logPath + this._logFilename, false, Encoding.UTF8);
                this._log.WriteLine("###  REGISTRO DE OPERACION DE CARGA MASIVA  ###\n\n");
                this._log.WriteLine("[{0}]: Ha comenzado el registro de sucesos.", (object)DateTime.Now.ToLongTimeString());
            }
            this._log.WriteLine(message);
            this._log.Flush();
        }

        public void Dispose()
        {
            this.Finalize();
            if (this._parser != null)
                this._parser.Finalize();
            if (this._plantilla != null)
                this._plantilla.Dispose();
            if (this._documento != null)
                this._documento.Dispose();
            this._parser = (CargaMasivaParser)null;
            this._plantilla = (Plantilla)null;
            this._documento = (CargaMasivaDocumento)null;
            this._operationConfigurations = (DataTable)null;
            this._operationProperties = (DataRow)null;
            this._log = (StreamWriter)null;
        }

        private void threadCargaMasiva()
        {
            if (!this.Initialize())
            {
                this.RecordToLog(string.Format("[{0}]: Terminando el proceso de Carga Masiva...", (object)DateTime.Now.ToLongTimeString()));
                this.Finalize();
                this._result = CargaMasivaExecutionResult.InitError;
            }
            while (this._parser.NextRegister())
            {
                ArrayList spParam = (ArrayList)null;
                this.RecordToLog(string.Format("\n[{0}]: Procesando el registro {1} del documento de datos.", (object)DateTime.Now.ToLongTimeString(), (object)this._documento.RegisterCount));
                if (this._parser.TryParse() == CargaMasivaParsingResult.Success)
                {
                    bool flag;
                    if (this._parser.Parse(out spParam) == CargaMasivaParsingResult.Success)
                    {
                        try
                        {
                            DataSet dataSet = this.commonBiz.ExecuteStoredProcedure((SqlParameter[])spParam.ToArray(typeof(SqlParameter)), this._operationProperties["CEStoredProc"].ToString(), string.Empty);
                            if (bool.Parse(this._operationProperties["Return_Msg"].ToString()) && dataSet != null)
                                this.RecordToLog(string.Format("[{0}]: Mensaje devuelto por el StoredProc: {1}", (object)DateTime.Now.ToLongTimeString(), (object)dataSet.Tables[0].Rows[0]["Return_Msg"].ToString()));
                            flag = !bool.Parse(this._operationProperties["Return_Code"].ToString()) || dataSet == null || int.Parse(dataSet.Tables[0].Rows[0]["Return_Code"].ToString()) == 0;
                        }
                        catch (Exception ex)
                        {
                            this.RecordToLog(string.Format("[{0}]: Ha ocurrido un error al enviar los datos al StoredProc: {1}", (object)DateTime.Now.ToLongTimeString(), (object)ex.Message));
                            flag = false;
                        }
                    }
                    else
                    {
                        this.RecordToLog(string.Format("[{0}]: La conversión de datos ha fallado para el registro:\n{1}", (object)DateTime.Now.ToLongTimeString(), (object)this._parser.GetLastError()));
                        flag = false;
                    }
                    if (flag)
                    {
                        this.RecordToLog(string.Format("[{0}]: El envio y procesamiento del registro actual ha sido satisfactorio. Continuando con el siguiente registro del documento de datos...", (object)DateTime.Now.ToLongTimeString()));
                    }
                    else
                    {
                        this.RecordToLog(string.Format("[{0}]: El envio y procesamiento del registro de datos actual ha fallado.", (object)DateTime.Now.ToLongTimeString()));
                        if (this._mode == CargaMasivaExecutionMode.ExecuteAll)
                        {
                            this.RecordToLog(string.Format("[{0}]: Continuando con el siguiente registro del documento de datos...", (object)DateTime.Now.ToLongTimeString()));
                        }
                        else
                        {
                            this.RecordToLog(string.Format("[{0}]: Terminando el proceso de Carga Masiva...", (object)DateTime.Now.ToLongTimeString()));
                            this.Finalize();
                            this._result = CargaMasivaExecutionResult.DBError;
                            break;
                        }
                    }
                }
                else
                {
                    this.RecordToLog(string.Format("[{0}]: La prueba de conversión ha fallado para el registro:\n{1}", (object)DateTime.Now.ToLongTimeString(), (object)this._parser.GetLastError()));
                    if (this._mode == CargaMasivaExecutionMode.ExecuteAll)
                    {
                        this.RecordToLog(string.Format("[{0}]: Continuando con el siguiente registro del documento de datos...", (object)DateTime.Now.ToLongTimeString()));
                    }
                    else
                    {
                        this.RecordToLog(string.Format("[{0}]: Terminando el proceso de Carga Masiva...", (object)DateTime.Now.ToLongTimeString()));
                        this.Finalize();
                        this._result = CargaMasivaExecutionResult.ParsingError;
                        break;
                    }
                }
            }
            this.RecordToLog(string.Format("[{0}]: Se han procesado todos los registros del documento de datos. Terminando el proceso de Carga Masiva...", (object)DateTime.Now.ToLongTimeString()));
            this.Finalize();
            new Reporte(this._idEmpresa, 1, 1, (string)null, (string)null, 0, this._idUsuario, 28)
            {
                strValidador = ConfigurationSettings.AppSettings["localValidator"].ToString(),
                nombreEmpresa = this._nombreEmpresa,
                nombreArchivo = this._logFilename,
                pathAttach = (this._appRootPath + this._logPath + this._logFilename),
                tipoArchivo = "Archivo adjunto."
            }.EnviaCorreo();
            this._result = CargaMasivaExecutionResult.Success;
        }
        public Mensaje CargaRapida_(string _admin, string _register, string _user, string _pws)
        {
            Mensaje aMensaje = new Mensaje();
            bool flag = true;
            this._result = CargaMasivaExecutionResult.UnknownError;
            try
            {
                try
                {
                    this._idEmpresa = this.Get_IdEmpresa(_admin, _user, _pws.ToUpper());
                }
                catch (Exception ex)
                {
                    this._result = CargaMasivaExecutionResult.AuthenticationError;
                    aMensaje.Detalle = "Error de autenticación";
                }
                this._idOperacion = 2;
                try
                {
                    this.GetOperationProperties();
                    this.TryApplyDeloitteRoute(_register);
                }
                catch
                {
                    this._result = CargaMasivaExecutionResult.InitError;
                    aMensaje.Detalle = "Error al cargar la configuración de la empresa";
                }
                try
                {
                    this._plantilla = new Plantilla(int.Parse(this._operationProperties["CEIdPlantilla"].ToString()), this._options, "");
                }
                catch
                {
                    this._result = CargaMasivaExecutionResult.DBError;
                    aMensaje.Detalle = "Error al cargar la configuración de la empresa";
                }
                ArrayList spParam = (ArrayList)null;
                CargaMasivaParsingResult masivaParsingResult;
                try
                {
                    CargaMasivaParser cargaMasivaParser = new CargaMasivaParser(this._plantilla);
                    string[] documentFieldValues = _register.Split('|');
                    string[] documentFieldNames = this.FieldNameCons(int.Parse(this._operationProperties["CEIdPlantilla"].ToString()));
                    masivaParsingResult = cargaMasivaParser.FastParse(documentFieldNames, documentFieldValues, out spParam, out aMensaje);
                }
                catch (Exception ex)
                {
                    masivaParsingResult = CargaMasivaParsingResult.UnknownError;
                    aMensaje.Detalle = ex.Message;
                }
                if (masivaParsingResult.Equals((object)CargaMasivaParsingResult.Success))
                {
                    try
                    {
                        DataSet dataSet = this.commonBiz.ExecuteStoredProcedure((SqlParameter[])spParam.ToArray(typeof(SqlParameter)), this._operationProperties["CEStoredProc"].ToString(), string.Empty);
                        if (bool.Parse(this._operationProperties["Return_Msg"].ToString()) && dataSet != null)
                            this._result = CargaMasivaExecutionResult.Success;
                        flag = !bool.Parse(this._operationProperties["Return_Code"].ToString()) || dataSet == null || int.Parse(dataSet.Tables[1].Rows[0]["Return_Code"].ToString()) == 0;
                    }
                    catch (Exception ex)
                    {
                        this.RegistrarEntradaRapida(ex.Message, 3);
                        flag = false;
                        aMensaje.Detalle = ex.Message;
                    }
                }
                else
                    this._result = CargaMasivaExecutionResult.ParsingError;
            }
            catch (Exception ex)
            {
               // new ClErrores().MeEnviaError(ex);
               // aMensaje.Detalle = ex.Message;
            }
            aMensaje.Id = (int)this._result;
            aMensaje.Descripcion = this._result.ToString();
            return aMensaje;
        }
        public int CargaRapida(string _admin, string _register, string _user, string _pws)
        {
            bool flag = true;
            this._result = CargaMasivaExecutionResult.UnknownError;
            try
            {
                try
                {
                    this._idEmpresa = this.Get_IdEmpresa(_admin, _user, _pws.ToUpper());
                }
                catch (Exception ex)
                {
                    this._result = CargaMasivaExecutionResult.AuthenticationError;
                }
                this._idOperacion = 2;
                try
                {
                    this.GetOperationProperties();
                    this.TryApplyDeloitteRoute(_register);
                }
                catch
                {
                    this._result = CargaMasivaExecutionResult.InitError;
                }
                this._plantilla = new Plantilla(int.Parse(this._operationProperties["CEIdPlantilla"].ToString()), this._options, "");
                ArrayList spParam = (ArrayList)null;
                CargaMasivaParsingResult masivaParsingResult;
                try
                {
                    CargaMasivaParser cargaMasivaParser = new CargaMasivaParser(this._plantilla);
                    string[] documentFieldValues = _register.Split('|');
                    string[] documentFieldNames = this.FieldNameCons(int.Parse(this._operationProperties["CEIdPlantilla"].ToString()));
                    masivaParsingResult = cargaMasivaParser.FastParse(documentFieldNames, documentFieldValues, out spParam);
                }
                catch
                {
                    masivaParsingResult = CargaMasivaParsingResult.UnknownError;
                }
                if (masivaParsingResult.Equals((object)CargaMasivaParsingResult.Success))
                {
                    try
                    {
                        DataSet dataSet = this.commonBiz.ExecuteStoredProcedure((SqlParameter[])spParam.ToArray(typeof(SqlParameter)), this._operationProperties["CEStoredProc"].ToString(), string.Empty);
                        if (bool.Parse(this._operationProperties["Return_Msg"].ToString()) && dataSet != null)
                            this._result = CargaMasivaExecutionResult.Success;
                        flag = !bool.Parse(this._operationProperties["Return_Code"].ToString()) || dataSet == null || int.Parse(dataSet.Tables[0].Rows[0]["Return_Code"].ToString()) == 0;
                    }
                    catch (Exception ex)
                    {
                        this.RegistrarEntradaRapida(ex.Message, 3);
                        flag = false;
                    }
                }
                else
                    this._result = CargaMasivaExecutionResult.ParsingError;
                if (!flag)
                    this._result = CargaMasivaExecutionResult.DBError;
                return (int)this._result;
            }
            catch (Exception ex)
            {
               //new ClErrores().MeEnviaError(ex);
                return (int)this._result;
            }
        }

        public CargaMasivaExecutionResult ExecuteCargaMasiva(
          int IdEmpresa,
          int IdOperacion,
          int IdDocumento,
          CargaMasivaExecutionMode mode,
          SortedList options,
          int IdUsuario,
          string nombreEmpresa)
        {
            this._idEmpresa = IdEmpresa;
            this._idOperacion = IdOperacion;
            this._idDocumento = IdDocumento;
            this._options = options;
            this._idUsuario = IdUsuario;
            this._nombreEmpresa = nombreEmpresa;
            this._mode = mode;
            Thread thread = new Thread(new ThreadStart(this.threadCargaMasiva));
            CultureInfo cultureInfo = new CultureInfo("es-mx");
            try
            {
                thread.CurrentCulture = cultureInfo;
                thread.IsBackground = true;
                thread.Name = "CargaMasiva_BeFlex";
                thread.Priority = ThreadPriority.Normal;
                thread.Start();
                return this._result;
            }
            catch
            {
                return CargaMasivaExecutionResult.ThreadError;
            }
        }

        private int Get_IdEmpresa(string _admin, string _user, string _pws)
        {
            clEncriptacion clEncriptacion = new clEncriptacion();
            return Convert.ToInt32(this.commonBiz.ExecuteStoredProcedure(new SqlParameter[3]
            {
        new SqlParameter("@IdEmpresa", (object) _admin),
        new SqlParameter("@User", (object) _user),
        new SqlParameter("@Pws", (object) clEncriptacion.Encriptar(_pws))
            }, "ff_CCMEmpresaAdmin", string.Empty).Tables[0].Rows[0][0]);
        }

        private string[] FieldNameCons(int _IdPlantilla)
        {
            DataTable table = this.commonBiz.ExecuteStoredProcedure(new SqlParameter[1]
            {
        new SqlParameter("@IdPlantilla", (object) _IdPlantilla)
            }, "ff_CPlantillaCampos", string.Empty).Tables[0];
            string str = "";
            foreach (DataRow row in (InternalDataCollectionBase)table.Rows)
                str = str + row["CANombreCampo"].ToString() + "|";
            return str.Remove(str.Length - 1, 1).Split('|');
        }

        public void RegistrarEntradaRapida(string _cadena, int _resultado)
        {
            this.commonBiz.ExecuteStoredProcedure(new SqlParameter[2]
            {
        new SqlParameter("@cadena", (object) _cadena),
        new SqlParameter("@res", (object) _resultado)
            }, "bf_CargaMasivaRegistro", string.Empty);
        }
    }

}
