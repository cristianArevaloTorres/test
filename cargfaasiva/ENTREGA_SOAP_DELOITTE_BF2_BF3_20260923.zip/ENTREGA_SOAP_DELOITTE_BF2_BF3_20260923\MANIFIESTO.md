# Manifiesto

- Archivo modificado: `FUENTE_MODIFICADA/Administracion/CargaMasivaProcess.cs`
- SHA-256: `7493D327B28D86E0BA72434D3F4F6E7B294DE73814BC4436463D7F6FD4238B55`
- Contratos WCF modificados: ninguno.
- Cambios de base de datos incluidos: ninguno; los dos scripts SQL son de sólo lectura.
- DLL incluida: no, por las razones documentadas en `VALIDACION_TECNICA.md`.
- DLL que debe decompilarse: `<ruta física IIS>/bin/ServiciosLocktonTI.dll`.
- Alcance especial: únicamente empresa interna 186 (Deloitte), operación 2.
