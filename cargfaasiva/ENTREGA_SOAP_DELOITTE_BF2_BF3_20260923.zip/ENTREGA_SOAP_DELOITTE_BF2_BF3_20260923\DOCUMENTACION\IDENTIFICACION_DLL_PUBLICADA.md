# Qué DLL se debe decompilar y cuál se despliega

## DLL correcta

La DLL que debe obtenerse del servidor donde está publicado el SOAP es:

`<ruta física del sitio IIS>\bin\ServiciosLocktonTI.dll`

La misma DLL recompilada es la que posteriormente se desplegaría en:

`<ruta física del sitio IIS>\bin\ServiciosLocktonTI.dll`

No se debe decompilar `Data.dll`, una DLL de otro repositorio ni el binario de una descarga antigua.

## Evidencia del nombre

El proyecto declara:

- `AssemblyName`: `ServiciosLocktonTI`.
- Framework objetivo: `.NET Framework 4.6.1`.
- Salida Release/Debug: carpeta `bin`.

Además, los archivos publicados `.svc` resuelven estos tipos dentro del ensamblado:

- `ServiciosLocktonTI.Servicios.BF_wbsABC_Empleados`.
- `ServiciosLocktonTI.Servicios.EmpleadoService`.

Ambos llegan finalmente a `ServiciosLocktonTI.Administracion.CargaMasivaProcess`, que es la única clase modificada.

## Cómo localizarla sin suposiciones

1. En IIS Manager, localizar la aplicación que atiende la URL real del SOAP.
2. Abrir **Basic Settings / Configuración básica** y anotar su **Physical path / Ruta física**.
3. Dentro de esa ruta comprobar que existen los `.svc` usados por el cliente.
4. Localizar `bin\ServiciosLocktonTI.dll`.
5. Copiar la DLL y, si existe, `ServiciosLocktonTI.pdb` a una carpeta de respaldo fuera del sitio.
6. Calcular el SHA-256 antes de decompilarla. Puede utilizarse `HERRAMIENTAS/OBTENER_HUELLA_DLL_PUBLICADA.ps1`.

## Clases que deben compararse en la decompilación

Abrir la DLL publicada con ILSpy, dotPeek o una herramienta equivalente y comprobar:

1. `ServiciosLocktonTI.Administracion.CargaMasivaProcess`.
2. `ServiciosLocktonTI.Servicios.BF_wbsABC_Empleados`.
3. `ServiciosLocktonTI.Servicios.EmpleadoService`.
4. `ServiciosLocktonTI.Servicios.IBF_wbsABC_Empleados`.
5. `ServiciosLocktonTI.Servicios.IEmpleadoService`.

En `CargaMasivaProcess` deben existir, como mínimo, los métodos actuales:

- `CargaRapida(...)`.
- `CargaRapida_(...)`.
- `GetOperationProperties()`.
- `FieldNameCons(...)`.

La comparación debe confirmar que la DLL publicada utiliza `ff_CCMOperacionPropiedades`, `ff_CPlantillaCampos` y la ejecución dinámica de `CEStoredProc`. Si difiere, se debe portar la lógica del selector a esa base real, no sustituirla ciegamente por el archivo incluido.

## Qué se reemplaza al publicar

Una vez compilada y homologada la fuente verificada:

- Se sustituye únicamente `bin\ServiciosLocktonTI.dll` y su PDB correspondiente si el procedimiento de publicación lo incluye.
- No se sustituyen DLL de terceros ni `Web.config` como parte de este cambio.
- Se recicla solamente el application pool de la aplicación.
- Se conserva el respaldo para rollback inmediato.

El ZIP no incluye una DLL precompilada porque todavía debe comprobarse que la fuente corresponde exactamente a la publicación y deben recuperarse sus referencias originales.
