param
(
    [Parameter(Mandatory = $true)]
    [string] $RutaFisicaSitio
)

$sitio = (Resolve-Path -LiteralPath $RutaFisicaSitio).Path
$dll = Join-Path $sitio 'bin\ServiciosLocktonTI.dll'

if (-not (Test-Path -LiteralPath $dll -PathType Leaf))
{
    throw "No se encontró la DLL esperada: $dll"
}

$archivo = Get-Item -LiteralPath $dll
$version = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($dll)
$hash = Get-FileHash -LiteralPath $dll -Algorithm SHA256

[pscustomobject]@{
    Ruta = $archivo.FullName
    Bytes = $archivo.Length
    UltimaModificacion = $archivo.LastWriteTime
    AssemblyFileVersion = $version.FileVersion
    ProductVersion = $version.ProductVersion
    SHA256 = $hash.Hash
}
