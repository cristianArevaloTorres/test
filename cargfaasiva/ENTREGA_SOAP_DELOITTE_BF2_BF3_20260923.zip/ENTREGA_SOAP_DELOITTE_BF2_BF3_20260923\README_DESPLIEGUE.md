# Selector BF2/BF3 para la carga masiva SOAP de Deloitte

## Resultado

El cambio conserva los contratos públicos del SOAP y decide la ruta **antes** de crear parámetros o ejecutar un procedimiento almacenado:

- Empresa interna `186` (Deloitte), operación `2`, cadena de `32` posiciones: plantilla `507` y `ff_XCMTitularesAltaCMDeloitte`.
- Empresa interna `186` (Deloitte), operación `2`, cadena de `23` posiciones: plantilla `12062` y `ff_XCMTitularesAltaCMM_BF3`.
- Otra cantidad de posiciones: se rechaza como `ParsingError`; no se ejecuta ningún SP.
- Cualquier otra empresa: conserva íntegramente la selección y el procesamiento actuales.

La cantidad no está duplicada como un número mágico en el flujo: el servicio consulta los campos activos de cada plantilla mediante `ff_CPlantillaCampos` y compara contra esos conteos. Los identificadores de las dos rutas autorizadas sí quedan explícitos para impedir que una configuración ajena sea ejecutada por accidente.

## Contrato y respuesta al cliente

No se modificaron:

- `IBF_wbsABC_Empleados.GuardaDatos(...)`, que sigue devolviendo `int`.
- `IEmpleadoService.CargaMasiva(...)`, que sigue devolviendo `Mensaje` con `Id`, `Descripcion` y `Detalle`.
- Los nombres de operaciones, parámetros SOAP, WSDL, bindings o `Web.config`.

Para una cadena válida, la respuesta se sigue construyendo con el resultado del parser y del SP elegido, exactamente en el flujo existente. Para un número de posiciones no reconocido:

- `GuardaDatos` devuelve el código existente `2` (`ParsingError`).
- `CargaMasiva` devuelve `Id = 2`, `Descripcion = "ParsingError"` y un detalle que indica los conteos admitidos.

No existe un segundo intento después de ejecutar un SP. Esto evita duplicados o altas parciales.

## Archivos

- `FUENTE_MODIFICADA/Administracion/CargaMasivaProcess.cs`: archivo que debe sustituirse en la fuente que corresponda a la publicación real.
- `SQL/01_PREVALIDACION_BD_SOLO_LECTURA.sql`: valida empresa, configuraciones, plantillas y parámetros; no modifica datos.
- `SQL/02_POSTVALIDACION_BD_SOLO_LECTURA.sql`: muestra la matriz efectiva después del despliegue; no modifica datos.
- `PRUEBAS/MATRIZ_PRUEBAS.md`: casos mínimos de homologación.
- `EVIDENCIA/RESULTADOS_QA_20260922.md`: hechos usados para diseñar el cambio.
- `DOCUMENTACION/DIAGRAMA_FLUJO.svg` y `.png`: diagrama visual de la selección y del alcance exclusivo para Deloitte.
- `DOCUMENTACION/IDENTIFICACION_DLL_PUBLICADA.md`: cuál DLL respaldar, decompilar y desplegar.
- `DOCUMENTACION/CORREO_PROPUESTA.md`: correo sugerido para explicar alcance, riesgo y despliegue.
- `HERRAMIENTAS/OBTENER_HUELLA_DLL_PUBLICADA.ps1`: obtiene versión y SHA-256 de la DLL sin modificarla.

## Despliegue recomendado

1. Identificar la DLL actualmente publicada y respaldar el directorio del sitio, su `Web.config`, DLL y PDB.
2. Decompilar o recuperar la fuente de **esa misma DLL publicada** y comparar `CargaMasivaProcess`, los contratos WCF y sus dependencias con la fuente incluida aquí.
3. Ejecutar `SQL/01_PREVALIDACION_BD_SOLO_LECTURA.sql` en la base del ambiente. Debe terminar con `APTO`.
4. Incorporar únicamente el cambio de `CargaMasivaProcess.cs` a la fuente verificada.
5. Compilar en Release para .NET Framework 4.6.1 con las referencias originales del sitio. No cambiar la versión de framework como parte de esta entrega.
6. Publicar primero en homologación y reciclar solamente el application pool correspondiente.
7. Ejecutar la matriz de pruebas, revisar las altas generadas y correr `SQL/02_POSTVALIDACION_BD_SOLO_LECTURA.sql`.
8. Pasar a producción usando el mismo artefacto compilado y su hash.

## Rollback

No hay objetos ni datos de BD que revertir. Para regresar:

1. Detener o reciclar el application pool del SOAP.
2. Restaurar la DLL/PDB respaldadas de la publicación anterior.
3. Reciclar el application pool.
4. Probar una petición conocida de Deloitte y una de otra empresa.

## Condiciones importantes

- Se cuentan posiciones con la misma regla usada por el parser: separador `|` y conservación de valores vacíos, incluso el último.
- Una cadena con separador final adicional tiene una posición extra y será rechazada.
- El selector exige exactamente una configuración activa para cada pareja plantilla/SP de Deloitte. Si falta una o está duplicada, no ejecuta ninguna ruta.
- Este paquete no contiene una DLL compilada: el proyecto recuperado tiene dependencias incompletas y no sería seguro sustituir la publicación con un binario construido fuera de su base real.
