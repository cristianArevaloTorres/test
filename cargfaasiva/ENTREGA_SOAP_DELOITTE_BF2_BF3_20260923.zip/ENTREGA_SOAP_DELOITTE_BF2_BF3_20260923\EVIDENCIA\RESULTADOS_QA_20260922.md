# Evidencia usada

Fuente: resultados del diagnóstico ejecutado en `LOCKMX-DBQA / FlexiForbesv2` el 22 de septiembre de 2026.

- Empresa interna Deloitte: `186`.
- Clave externa recibida por SOAP: `S001`.
- Operación de alta de titulares: `2`.
- Configuración activa `190`: plantilla `507`, SP `ff_XCMTitularesAltaCMDeloitte`, atributos `3`.
- Configuración activa `17845`: plantilla `12062`, SP `ff_XCMTitularesAltaCMM_BF3`, atributos `3`.
- Plantilla `507`: `32` campos activos (37 configuraciones totales).
- Plantilla `12062`: `23` campos activos (29 configuraciones totales).
- Los dos SP existen en el ambiente consultado.
- Deloitte aparece en la bitácora SOAP con la clave `S001` y actividad histórica/reciente.

La BD devuelve actualmente dos filas activas para empresa 186/operación 2 y el procedimiento `ff_CCMOperacionPropiedades` no contiene un criterio de orden o selección entre ellas. El cambio elimina esa indeterminación exclusivamente para Deloitte usando el número de posiciones antes de ejecutar negocio.
