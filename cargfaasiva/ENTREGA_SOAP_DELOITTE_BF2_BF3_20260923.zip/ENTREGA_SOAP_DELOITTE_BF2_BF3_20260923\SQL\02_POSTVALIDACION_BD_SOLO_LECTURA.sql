/*
  POSTVALIDACION DEL SELECTOR SOAP BF2/BF3 PARA DELOITTE

  SOLO LECTURA. Confirma la matriz que usara el codigo publicado.
*/

SET NOCOUNT ON;
SET LOCK_TIMEOUT 15000;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @IdEmpresa INT = 186;
DECLARE @IdOperacion INT = 2;

SELECT
    '00_CONTEXTO' AS bloque,
    CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) AS servidor,
    DB_NAME() AS baseDatos,
    GETDATE() AS fechaConsulta;

SELECT
    '01_MATRIZ_RUTEO_EFECTIVA' AS bloque,
    CE.CEIdEmpresa,
    E.EMNombre AS empresa,
    E.EMIdEmpresaFlexiForbes AS claveExterna,
    CE.CEIdOperacion,
    CE.CEIdPlantilla,
    COUNT(CP.CPIdConfiguracionPlantilla) AS posicionesActivas,
    LTRIM(RTRIM(CE.CEStoredProc)) AS storedProcedure,
    CE.CEStoredProcAtributos
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
INNER JOIN dbo.ff_Empresa E
    ON E.EMIdEmpresa = CE.CEIdEmpresa
INNER JOIN dbo.ff_ConfiguracionPlantilla CP
    ON CP.PLIdPlantilla = CE.CEIdPlantilla
   AND CP.CPIdEstatus = 1
INNER JOIN dbo.ff_Campo C
    ON C.CAIdCampo = CP.CAIdCampo
   AND C.CAIdEstatus = 1
WHERE CE.CEIdEmpresa = @IdEmpresa
  AND CE.CEIdOperacion = @IdOperacion
  AND CE.CEIdEstatus = 1
  AND
  (
      (CE.CEIdPlantilla = 507
       AND LTRIM(RTRIM(CE.CEStoredProc)) IN
           ('ff_XCMTitularesAltaCMDeloitte', 'dbo.ff_XCMTitularesAltaCMDeloitte'))
      OR
      (CE.CEIdPlantilla = 12062
       AND LTRIM(RTRIM(CE.CEStoredProc)) IN
           ('ff_XCMTitularesAltaCMM_BF3', 'dbo.ff_XCMTitularesAltaCMM_BF3'))
  )
GROUP BY
    CE.CEIdEmpresa,
    E.EMNombre,
    E.EMIdEmpresaFlexiForbes,
    CE.CEIdOperacion,
    CE.CEIdPlantilla,
    LTRIM(RTRIM(CE.CEStoredProc)),
    CE.CEStoredProcAtributos
ORDER BY posicionesActivas DESC;

SELECT
    '02_OTRAS_EMPRESAS_SIN_CAMBIO' AS bloque,
    COUNT(DISTINCT CE.CEIdEmpresa) AS empresasActivasOperacion2NoDeloitte,
    COUNT(*) AS configuracionesActivasOperacion2NoDeloitte
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
WHERE CE.CEIdOperacion = @IdOperacion
  AND CE.CEIdEstatus = 1
  AND CE.CEIdEmpresa <> @IdEmpresa;
