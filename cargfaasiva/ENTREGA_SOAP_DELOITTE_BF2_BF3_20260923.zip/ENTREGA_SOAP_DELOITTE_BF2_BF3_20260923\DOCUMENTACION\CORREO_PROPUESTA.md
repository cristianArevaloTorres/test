# Correo sugerido

**Asunto:** Propuesta de ajuste controlado al SOAP de carga masiva Deloitte – convivencia BF2/BF3

Hola equipo,

Como parte de la homologación de las cargas masivas de Deloitte, identificamos que la empresa cuenta actualmente con dos configuraciones activas para la operación de alta de titulares:

- Plantilla 507, correspondiente al formato BF2 de 32 posiciones, procesada por `ff_XCMTitularesAltaCMDeloitte`.
- Plantilla 12062, correspondiente al formato BF3 de 23 posiciones, procesada por `ff_XCMTitularesAltaCMM_BF3`.

El procedimiento que obtiene la configuración devuelve ambas filas y actualmente no contiene un criterio para determinar cuál debe utilizarse. Por ello existe el riesgo de que una petición sea interpretada con una plantilla distinta a la estructura recibida.

La propuesta consiste en incorporar una validación interna y acotada en el servicio SOAP. Después de autenticar la petición y antes de construir parámetros o ejecutar cualquier procedimiento, el servicio contará las posiciones de la cadena y seleccionará la configuración completa correspondiente:

- 32 posiciones: plantilla 507 / flujo BF2.
- 23 posiciones: plantilla 12062 / flujo BF3.
- Cualquier otro conteo: la petición se rechazará como error de parsing sin ejecutar un SP de negocio.

La condición especial aplica únicamente a Deloitte, empresa interna 186, para la operación 2. Las demás empresas continúan utilizando exactamente la configuración que actualmente devuelve la base de datos.

El cambio no modifica el contrato, WSDL, métodos, parámetros ni tipos de respuesta del SOAP. Tampoco requiere cambios del lado del cliente, Java, `Web.config` u objetos nuevos de base de datos. La modificación se concentra en la clase `CargaMasivaProcess`, pero para publicarla será necesario recompilar y sustituir de forma controlada `bin\ServiciosLocktonTI.dll`.

Como medida de seguridad, no se realizará un esquema de “intentar un SP y, si falla, ejecutar el otro”, ya que esto podría provocar altas parciales o duplicadas. La ruta se determina completamente antes de ejecutar negocio.

Previo al despliegue se propone:

1. Obtener y respaldar la DLL actualmente publicada.
2. Decompilar `bin\ServiciosLocktonTI.dll` y comprobar que corresponde con la fuente utilizada para el ajuste.
3. Ejecutar la prevalidación de sólo lectura en la BD del ambiente.
4. Compilar con las referencias originales y publicar primero en homologación.
5. Probar cadenas válidas de 23 y 32 posiciones, cantidades inválidas y una empresa distinta de Deloitte.
6. Validar tanto la respuesta SOAP como los datos almacenados.

El rollback consiste únicamente en restaurar la DLL respaldada y reciclar el application pool; no hay cambios de BD que revertir.

Quedo atento a su confirmación para continuar con la compilación sobre la DLL/fuente publicada y la ejecución de las pruebas de homologación.

Saludos.
