# Matriz mínima de homologación

Usar datos sintéticos y únicos; no reutilizar números de empleado reales. Verificar tanto la respuesta SOAP como el estado final en BD.

| Caso | Empresa | Posiciones | Resultado esperado |
|---|---:|---:|---|
| BF2 válida | S001 / interna 186 | 32 | Selecciona plantilla 507, ejecuta `ff_XCMTitularesAltaCMDeloitte` y conserva la respuesta histórica del endpoint usado. |
| BF3 válida | S001 / interna 186 | 23 | Selecciona plantilla 12062, ejecuta `ff_XCMTitularesAltaCMM_BF3` y conserva la respuesta histórica del endpoint usado. |
| Cantidad inválida | S001 / interna 186 | 24 o 31 | `ParsingError`; no debe existir alta ni ejecución de SP destino. |
| Separador final extra | S001 / interna 186 | 24 o 33 | `ParsingError`; se conserva la posición vacía final y no se ejecuta SP. |
| BF2 con dato inválido | S001 / interna 186 | 32 | Selecciona 507, el parser rechaza el valor y no ejecuta SP. |
| BF3 con dato inválido | S001 / interna 186 | 23 | Selecciona 12062, el parser rechaza el valor y no ejecuta SP. |
| Empresa distinta | Otra empresa activa | Según su plantilla | Comportamiento idéntico al anterior; no participa el selector Deloitte. |
| Configuración incompleta | S001 / interna 186 | 23 o 32 | Se rechaza antes del SP indicando configuración incompleta/duplicada. |

Ejecutar cada formato válido en ambos contratos si ambos están publicados:

1. `BF_wbsABC_Empleados.GuardaDatos`, respuesta `int`.
2. `EmpleadoService.CargaMasiva`, respuesta `Mensaje`.

Validaciones obligatorias:

- Una sola alta por petición.
- Ningún registro generado por los casos rechazados.
- Campos colocados en las columnas correctas, no sólo respuesta `Success`.
- No hay regresión en al menos una empresa no Deloitte.
- El WSDL antes y después conserva las mismas operaciones y tipos.
