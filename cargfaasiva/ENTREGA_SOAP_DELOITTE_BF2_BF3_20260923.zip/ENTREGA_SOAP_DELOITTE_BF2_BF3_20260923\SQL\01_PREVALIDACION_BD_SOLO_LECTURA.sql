/*
  PREVALIDACION DEL SELECTOR SOAP BF2/BF3 PARA DELOITTE

  SOLO LECTURA. No inserta, actualiza ni elimina datos.
  Compatible con versiones de SQL Server sin STRING_AGG.
*/

SET NOCOUNT ON;
SET LOCK_TIMEOUT 15000;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @IdEmpresa INT = 186;
DECLARE @ClaveExterna VARCHAR(20) = 'S001';
DECLARE @IdOperacion INT = 2;

DECLARE @Rutas TABLE
(
    IdPlantilla INT NOT NULL,
    StoredProcedure VARCHAR(128) NOT NULL
);

INSERT INTO @Rutas (IdPlantilla, StoredProcedure)
VALUES (507, 'ff_XCMTitularesAltaCMDeloitte');

INSERT INTO @Rutas (IdPlantilla, StoredProcedure)
VALUES (12062, 'ff_XCMTitularesAltaCMM_BF3');

DECLARE @Problemas TABLE
(
    Problema NVARCHAR(1000) NOT NULL
);

SELECT
    '00_CONTEXTO' AS bloque,
    CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) AS servidor,
    DB_NAME() AS baseDatos,
    GETDATE() AS fechaConsulta;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Empresa E
    WHERE E.EMIdEmpresa = @IdEmpresa
      AND CONVERT(VARCHAR(20), E.EMIdEmpresaFlexiForbes) = @ClaveExterna
      AND E.EMIdEstatus = 1
)
BEGIN
    INSERT INTO @Problemas (Problema)
    VALUES (N'La empresa interna 186 activa no corresponde a la clave externa S001.');
END;

INSERT INTO @Problemas (Problema)
SELECT
    N'La ruta Plantilla=' + CONVERT(NVARCHAR(20), R.IdPlantilla) +
    N'; SP=' + R.StoredProcedure +
    N' debe tener exactamente una configuracion activa para empresa 186 y operacion 2.'
FROM @Rutas R
WHERE
(
    SELECT COUNT(*)
    FROM dbo.ff_CargaMasivaOperacionEmpresa CE
    WHERE CE.CEIdEmpresa = @IdEmpresa
      AND CE.CEIdOperacion = @IdOperacion
      AND CE.CEIdPlantilla = R.IdPlantilla
      AND REPLACE(REPLACE(LTRIM(RTRIM(CE.CEStoredProc)), '[', ''), ']', '')
          IN (R.StoredProcedure, 'dbo.' + R.StoredProcedure)
      AND CE.CEIdEstatus = 1
) <> 1;

INSERT INTO @Problemas (Problema)
SELECT
    N'La plantilla ' + CONVERT(NVARCHAR(20), R.IdPlantilla) +
    N' no tiene campos activos.'
FROM @Rutas R
WHERE
(
    SELECT COUNT(*)
    FROM dbo.ff_ConfiguracionPlantilla CP
    INNER JOIN dbo.ff_Campo C
        ON C.CAIdCampo = CP.CAIdCampo
    WHERE CP.PLIdPlantilla = R.IdPlantilla
      AND CP.CPIdEstatus = 1
      AND C.CAIdEstatus = 1
) = 0;

IF
(
    SELECT COUNT(*)
    FROM dbo.ff_ConfiguracionPlantilla CP
    INNER JOIN dbo.ff_Campo C
        ON C.CAIdCampo = CP.CAIdCampo
    WHERE CP.PLIdPlantilla = 507
      AND CP.CPIdEstatus = 1
      AND C.CAIdEstatus = 1
) =
(
    SELECT COUNT(*)
    FROM dbo.ff_ConfiguracionPlantilla CP
    INNER JOIN dbo.ff_Campo C
        ON C.CAIdCampo = CP.CAIdCampo
    WHERE CP.PLIdPlantilla = 12062
      AND CP.CPIdEstatus = 1
      AND C.CAIdEstatus = 1
)
BEGIN
    INSERT INTO @Problemas (Problema)
    VALUES (N'Las plantillas 507 y 12062 tienen el mismo numero de campos; la seleccion por posiciones seria ambigua.');
END;

INSERT INTO @Problemas (Problema)
SELECT
    N'No existe el procedimiento dbo.' + R.StoredProcedure + N'.'
FROM @Rutas R
WHERE OBJECT_ID(N'dbo.' + R.StoredProcedure, 'P') IS NULL;

INSERT INTO @Problemas (Problema)
SELECT
    N'El campo ' + LTRIM(RTRIM(C.CANombreCampo)) +
    N' de la plantilla ' + CONVERT(NVARCHAR(20), R.IdPlantilla) +
    N' no tiene parametro equivalente en dbo.' + R.StoredProcedure + N'.'
FROM @Rutas R
INNER JOIN dbo.ff_ConfiguracionPlantilla CP
    ON CP.PLIdPlantilla = R.IdPlantilla
   AND CP.CPIdEstatus = 1
INNER JOIN dbo.ff_Campo C
    ON C.CAIdCampo = CP.CAIdCampo
   AND C.CAIdEstatus = 1
LEFT JOIN sys.parameters P
    ON P.object_id = OBJECT_ID(N'dbo.' + R.StoredProcedure, 'P')
   AND P.name = N'@' + LTRIM(RTRIM(C.CANombreCampo))
WHERE P.parameter_id IS NULL;

SELECT
    '01_RUTAS_CONFIGURADAS' AS bloque,
    CE.CEIdOperacionEmpresa,
    CE.CEIdEmpresa,
    CE.CEIdOperacion,
    CE.CEIdPlantilla,
    LTRIM(RTRIM(CE.CEStoredProc)) AS storedProcedure,
    CE.CEStoredProcAtributos,
    CE.CEIdEstatus
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
WHERE CE.CEIdEmpresa = @IdEmpresa
  AND CE.CEIdOperacion = @IdOperacion
ORDER BY CE.CEIdEstatus DESC, CE.CEIdPlantilla, CE.CEIdOperacionEmpresa;

SELECT
    '02_CONTEOS_EFECTIVOS' AS bloque,
    R.IdPlantilla,
    R.StoredProcedure,
    COUNT(CP.CPIdConfiguracionPlantilla) AS posicionesActivas
FROM @Rutas R
LEFT JOIN dbo.ff_ConfiguracionPlantilla CP
    ON CP.PLIdPlantilla = R.IdPlantilla
   AND CP.CPIdEstatus = 1
LEFT JOIN dbo.ff_Campo C
    ON C.CAIdCampo = CP.CAIdCampo
   AND C.CAIdEstatus = 1
WHERE C.CAIdCampo IS NOT NULL
GROUP BY R.IdPlantilla, R.StoredProcedure
ORDER BY posicionesActivas DESC;

IF EXISTS (SELECT 1 FROM @Problemas)
BEGIN
    SELECT 'NO_APTO' AS dictamen, Problema
    FROM @Problemas
    ORDER BY Problema;

    RAISERROR
    (
        'Prevalidacion no aprobada. No publicar el cambio hasta corregir los problemas reportados.',
        16,
        1
    );
    RETURN;
END;

SELECT
    'APTO' AS dictamen,
    N'Las dos rutas de Deloitte son unicas, distinguibles y compatibles con sus SP.' AS detalle;
