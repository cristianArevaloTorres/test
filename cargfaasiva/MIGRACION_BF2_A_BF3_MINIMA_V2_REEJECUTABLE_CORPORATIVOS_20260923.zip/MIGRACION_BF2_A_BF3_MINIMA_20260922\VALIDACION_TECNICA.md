# Validacion tecnica realizada

Fecha inicial: 22 de septiembre de 2026.
Actualizacion de reejecucion/corporativos: 23 de septiembre de 2026.

Base utilizada para validar sintaxis y metadatos:

- servidor: `(localdb)\MSSQLLocalDB`;
- base: `FlexiForbesv2`.

Comprobaciones realizadas:

- `00_DIAGNOSTICO_PREVIO_SOLO_LECTURA.sql`: ejecutado sin errores;
- `01_RESET_MVP_ANTERIOR_A_MINIMO.sql`: ejecutado con `@Aplicar=0`, sin cambios;
- `02_CREAR_SP_MIGRACION_MINIMA_BF2_BF3.sql`: compilado correctamente dentro de una transaccion y revertido; el SP no quedo instalado;
- `03_EJECUTAR_MIGRACION_MINIMA.sql`: probado con `@Aplicar=0` dentro de una transaccion revertida;
- `04_VALIDAR_RESULTADO_SOLO_LECTURA.sql`: ejecutado sin errores.
- el reset se ejecuto dos veces consecutivas dentro de la misma sesion SQL sin
  errores de tablas temporales existentes;
- el instalador del SP se ejecuto dos veces consecutivas dentro de una
  transaccion revertida, sin errores de procedimiento existente;
- los 20 IDs de corporativo se resolvieron en 23 empresas hijas activas en la
  copia local; se excluyo el renglon del propio corporativo.

No se ejecuto ninguna migracion ni reset de datos.

## Hallazgo de la copia local

Las 23 empresas existen, pero en esta copia local sus perfiles administradores
apuntan a roles que no estan disponibles/activos en `ff_Rol`. Por diseño, el SP
nuevo se detiene y reporta el problema; no crea un rol sustituto. Esto debe
revisarse en la base real antes de aplicar.

## Garantias del SP nuevo

- No contiene `INSERT`, `UPDATE` ni `DELETE` contra `ff_Rol`.
- No contiene `INSERT`, `UPDATE` ni `DELETE` contra `ff_Perfil`.
- Bloquea y compara cantidad y checksum de roles/perfiles antes y despues.
- Si detecta cualquier cambio en esas tablas, revierte la transaccion.
- Registra y devuelve `RolesCreados=0`, `RolesModificados=0`,
  `PerfilesCreados=0` y `PerfilesModificados=0`.
- Registra exactamente las plantillas creadas durante su ejecucion y revierte
  si aparece una distinta de `Interfabrica_MVP_<corporativo>`.
- En una reejecucion valida el estado funcional completo. Devuelve
  `YA_MIGRADA_SIN_CAMBIOS` solo si acceso, menus, Interfabrica, asignacion y
  marcador MVP siguen completos; si hay deriva entra a repararla.

## Garantias adicionales del reset

- No elimina menus V1/V2 de roles activos; los conserva para evitar romper la
  navegacion BF2/BF3.
- Antes de desactivar un perfil administrador candidato, busca un perfil
  administrador BF2 no creado por la cascada y con rol activo.
- Reasigna `ff_AdministradorEmpresa` al perfil/rol conservado.
- Si no existe alternativa segura, no desactiva el unico administrador.
- Compara el estado administrativo anterior y posterior dentro de la misma
  transaccion; ante una perdida de administracion revierte el reset completo.
