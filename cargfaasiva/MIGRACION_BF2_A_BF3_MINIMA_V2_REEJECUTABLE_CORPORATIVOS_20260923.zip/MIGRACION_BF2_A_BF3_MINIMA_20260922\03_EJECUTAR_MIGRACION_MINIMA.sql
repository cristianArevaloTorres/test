/*
  EJECUCION CONTROLADA DEL NUEVO SP.

  ENTRADA:
    - La lista contiene IDs DE CORPORATIVO, no IDs de empresa hija.
    - El script resuelve todas las empresas hijas activas de cada corporativo.
    - Excluye expresamente el renglon del propio corporativo.

  REEJECUCION:
    - Muestra si cada empresa tiene una migracion exitosa previa.
    - El SP valida el estado real. Si todo sigue completo devuelve
      YA_MIGRADA_SIN_CAMBIOS; si existe deriva, repara solo lo autorizado.

  Inicia en simulacion. Cambiar @Aplicar a 1 solamente despues del diagnostico.
*/
SET NOCOUNT ON;
SET XACT_ABORT OFF;

DECLARE @Aplicar BIT = 0;

DECLARE @Corporativos TABLE
(
    IdCorporativo INT NOT NULL PRIMARY KEY
);

INSERT INTO @Corporativos (IdCorporativo) VALUES
(495),(531),(658),(698),(718),(721),(723),(725),(727),(752),
(756),(758),(760),(762),(790),(797),(799),(806),(812),(814);

DECLARE @Empresas TABLE
(
    IdEmpresa INT NOT NULL PRIMARY KEY,
    IdCorporativo INT NOT NULL
);

INSERT INTO @Empresas (IdEmpresa, IdCorporativo)
SELECT E.EMidEmpresa, C.IdCorporativo
FROM @Corporativos C
INNER JOIN dbo.ff_Empresa E
    ON E.EMidCorporativo = C.IdCorporativo
   AND E.EMidEmpresa <> C.IdCorporativo
   AND E.EMidEstatus = 1;

SELECT
    '00_RESOLUCION_CORPORATIVOS' AS Bloque,
    C.IdCorporativo,
    COUNT(E.IdEmpresa) AS EmpresasHijasActivas,
    CASE WHEN COUNT(E.IdEmpresa) = 0
         THEN 'ERROR_SIN_EMPRESA_HIJA_ACTIVA'
         ELSE 'OK' END AS Validacion
FROM @Corporativos C
LEFT JOIN @Empresas E ON E.IdCorporativo = C.IdCorporativo
GROUP BY C.IdCorporativo
ORDER BY C.IdCorporativo;

IF EXISTS
(
    SELECT 1
    FROM @Corporativos C
    WHERE NOT EXISTS
    (
        SELECT 1 FROM @Empresas E
        WHERE E.IdCorporativo = C.IdCorporativo
    )
)
BEGIN
    IF @Aplicar = 1
        THROW 51000, 'Al menos un corporativo no tiene empresas hijas activas. No se inicio la migracion.', 1;
END;

IF OBJECT_ID('dbo.bf_MigrarEmpresaBF2aBF3_Minimo','P') IS NULL
    THROW 51000, 'Primero ejecute 02_CREAR_SP_MIGRACION_MINIMA_BF2_BF3.sql.', 1;

SELECT
    '01_ESTADO_ANTES_DE_EJECUTAR' AS Bloque,
    E.IdCorporativo,
    E.IdEmpresa,
    F.EMNombre,
    CASE WHEN EXISTS
    (
        SELECT 1
        FROM dbo.bf_BitacoraEmpresa B
        WHERE B.BEIdEmpresa = E.IdEmpresa
          AND B.BEAccion = 'MIGRAR_BF2_BF3_MINIMO'
          AND B.BEExitoso = 1
    ) THEN 'YA_EJECUTADA_PREVIAMENTE'
      ELSE 'PENDIENTE' END AS EstadoEjecucion,
    (SELECT MAX(B.BEFechaCreacion)
       FROM dbo.bf_BitacoraEmpresa B
      WHERE B.BEIdEmpresa = E.IdEmpresa
        AND B.BEAccion = 'MIGRAR_BF2_BF3_MINIMO'
        AND B.BEExitoso = 1) AS UltimaEjecucionExitosa
FROM @Empresas E
INNER JOIN dbo.ff_Empresa F ON F.EMidEmpresa = E.IdEmpresa
ORDER BY E.IdCorporativo, E.IdEmpresa;

IF @Aplicar = 0
BEGIN
    SELECT
        'SIMULACION: no se modificaron datos' AS Resultado,
        (SELECT COUNT(*) FROM @Empresas) AS EmpresasHijasResueltas,
        (SELECT COUNT(*)
         FROM @Empresas E
         WHERE EXISTS
        (
            SELECT 1
            FROM dbo.bf_BitacoraEmpresa B
            WHERE B.BEIdEmpresa = E.IdEmpresa
              AND B.BEAccion = 'MIGRAR_BF2_BF3_MINIMO'
              AND B.BEExitoso = 1
        )) AS YaEjecutadasPreviamente;

    SELECT 'Para aplicar, cambie DECLARE @Aplicar BIT = 0 por 1 y ejecute nuevamente.' AS Instruccion;
    RETURN;
END;

DECLARE @IdEmpresa INT;
DECLARE @IdCorporativo INT;
DECLARE @TeniaEjecucionPrevia BIT;

DECLARE @Ejecucion TABLE
(
    IdCorporativo INT NOT NULL,
    IdEmpresa INT NOT NULL,
    TeniaEjecucionPrevia BIT NOT NULL,
    Estado VARCHAR(40) NOT NULL,
    Mensaje NVARCHAR(4000) NULL
);

DECLARE C CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        E.IdEmpresa,
        E.IdCorporativo,
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.bf_BitacoraEmpresa B
            WHERE B.BEIdEmpresa = E.IdEmpresa
              AND B.BEAccion = 'MIGRAR_BF2_BF3_MINIMO'
              AND B.BEExitoso = 1
        ) THEN CONVERT(BIT, 1) ELSE CONVERT(BIT, 0) END
    FROM @Empresas E
    ORDER BY E.IdCorporativo, E.IdEmpresa;

OPEN C;
FETCH NEXT FROM C INTO @IdEmpresa, @IdCorporativo, @TeniaEjecucionPrevia;
WHILE @@FETCH_STATUS = 0
BEGIN
    BEGIN TRY
        EXEC dbo.bf_MigrarEmpresaBF2aBF3_Minimo @IdEmpresa = @IdEmpresa;

        INSERT INTO @Ejecucion
            (IdCorporativo, IdEmpresa, TeniaEjecucionPrevia, Estado, Mensaje)
        VALUES
            (@IdCorporativo, @IdEmpresa, @TeniaEjecucionPrevia,
             CASE WHEN @TeniaEjecucionPrevia = 1
                  THEN 'VALIDADA_O_REPARADA'
                  ELSE 'EJECUTADA' END,
             NULL);
    END TRY
    BEGIN CATCH
        INSERT INTO @Ejecucion
            (IdCorporativo, IdEmpresa, TeniaEjecucionPrevia, Estado, Mensaje)
        VALUES
            (@IdCorporativo, @IdEmpresa, @TeniaEjecucionPrevia,
             'ERROR', ERROR_MESSAGE());
    END CATCH;

    FETCH NEXT FROM C INTO @IdEmpresa, @IdCorporativo, @TeniaEjecucionPrevia;
END;
CLOSE C;
DEALLOCATE C;

SELECT
    '02_RESULTADO_POR_EMPRESA' AS Bloque,
    IdCorporativo,
    IdEmpresa,
    TeniaEjecucionPrevia,
    Estado,
    Mensaje
FROM @Ejecucion
ORDER BY IdCorporativo, IdEmpresa;

SELECT
    '03_RESUMEN' AS Bloque,
    COUNT(*) AS EmpresasSolicitadas,
    SUM(CASE WHEN TeniaEjecucionPrevia = 1 THEN 1 ELSE 0 END) AS YaEjecutadasPreviamente,
    SUM(CASE WHEN Estado <> 'ERROR' THEN 1 ELSE 0 END) AS ProcesadasSinError,
    SUM(CASE WHEN Estado = 'ERROR' THEN 1 ELSE 0 END) AS EmpresasConError
FROM @Ejecucion;
