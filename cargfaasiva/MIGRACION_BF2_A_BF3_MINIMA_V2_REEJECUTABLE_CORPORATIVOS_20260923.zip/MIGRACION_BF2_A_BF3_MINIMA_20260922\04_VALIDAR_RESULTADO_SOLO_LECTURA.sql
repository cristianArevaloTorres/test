/* VALIDACION POSTERIOR. SOLO LECTURA. */
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* La lista recibida contiene IDs de corporativo. */
DECLARE @Corporativos TABLE (IdCorporativo INT PRIMARY KEY);
INSERT INTO @Corporativos (IdCorporativo) VALUES
(495),(531),(658),(698),(718),(721),(723),(725),(727),(752),
(756),(758),(760),(762),(790),(797),(799),(806),(812),(814);

DECLARE @Empresas TABLE
(
    IdEmpresa INT PRIMARY KEY,
    IdCorporativo INT NOT NULL
);

INSERT INTO @Empresas (IdEmpresa, IdCorporativo)
SELECT E.EMidEmpresa,C.IdCorporativo
FROM @Corporativos C
INNER JOIN dbo.ff_Empresa E
    ON E.EMidCorporativo=C.IdCorporativo
   AND E.EMidEmpresa<>C.IdCorporativo
   AND E.EMidEstatus=1;

SELECT
    '00_RESOLUCION_CORPORATIVOS' AS Bloque,
    C.IdCorporativo,
    COUNT(E.IdEmpresa) AS EmpresasHijasActivas,
    CASE WHEN COUNT(E.IdEmpresa)=0
         THEN 'ERROR_SIN_EMPRESA_HIJA_ACTIVA'
         ELSE 'OK' END AS Validacion
FROM @Corporativos C
LEFT JOIN @Empresas E ON E.IdCorporativo=C.IdCorporativo
GROUP BY C.IdCorporativo
ORDER BY C.IdCorporativo;

SELECT
    '01_VALIDACION_FINAL' AS Bloque,
    L.IdEmpresa,
    E.EMNombre,
    E.EMidCorporativo,
    P.PEIdPerfil AS PerfilAdminExistente,
    P.PEIdRolDefault AS RolAdminExistente,
    (SELECT COUNT(*) FROM dbo.ff_accesoBeflex A WHERE A.idempresa=L.IdEmpresa AND A.acceso=1) AS AccesoEmpresaBF3,
    (SELECT COUNT(*) FROM dbo.ff_accesoBeflex A WHERE A.idempresa=E.EMidCorporativo AND A.acceso=1) AS AccesoCorporativoBF3,
    (SELECT COUNT(*) FROM dbo.ff_MenuRol2 M WHERE M.MRidRol=P.PEIdRolDefault AND M.MRidEstatus=1) AS MenusBF3Activos,
    I.PLIdPlantilla AS IdInterfabrica,
    I.PLDescripcion AS Interfabrica,
    (SELECT COUNT(*) FROM dbo.ff_PlantillaPerfil PP
      WHERE PP.PPPlantilla=I.PLIdPlantilla AND PP.PPIdEmpresa=L.IdEmpresa
        AND PP.PPIdPerfil=P.PEIdPerfil AND PP.PPIdEstatus=1) AS InterfabricaAsignada,
    (SELECT COUNT(*) FROM dbo.bf_EmpresaMVP M WHERE M.IdEmpresa=L.IdEmpresa AND ISNULL(M.IdEstatus,1)=1) AS MarcadorMVP,
    CASE
      WHEN E.EMidEmpresa IS NULL OR E.EMidEstatus<>1 THEN 'ERROR_EMPRESA'
      WHEN P.PEIdPerfil IS NULL THEN 'ERROR_PERFIL_ADMIN'
      WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_accesoBeflex A WHERE A.idempresa=L.IdEmpresa AND A.acceso=1) THEN 'ERROR_ACCESO'
      WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_MenuRol2 M WHERE M.MRidRol=P.PEIdRolDefault AND M.MRidEstatus=1) THEN 'ERROR_MENUS'
      WHEN I.PLIdPlantilla IS NULL THEN 'ERROR_INTERFABRICA'
      ELSE 'OK'
    END AS Validacion
FROM @Empresas L
LEFT JOIN dbo.ff_Empresa E ON E.EMidEmpresa=L.IdEmpresa
OUTER APPLY
(
    SELECT TOP (1) P.*
    FROM dbo.ff_Perfil P
    INNER JOIN dbo.ff_Rol R
      ON R.ROIdRol=P.PEIdRolDefault
     AND R.ROIdEmpresa=L.IdEmpresa
     AND R.ROIdEstatus=1
    WHERE P.PEIdEmpresa=L.IdEmpresa
      AND P.PEAdministrador=1
      AND P.PEIdEstatus=1
    ORDER BY P.PEIdPerfil
) P
OUTER APPLY
(
    SELECT TOP (1) PL.PLIdPlantilla,PL.PLDescripcion
    FROM dbo.ff_Plantilla PL
    WHERE PL.PLDescripcion=N'Interfabrica_MVP_'+CONVERT(NVARCHAR(10),E.EMidCorporativo)
    ORDER BY PL.PLIdPlantilla DESC
) I
ORDER BY L.IdEmpresa;

/* Debe regresar cero filas. */
SELECT
    '02_PLANTILLAS_NO_AUTORIZADAS_DEBEN_SER_CERO' AS Bloque,
    L.IdEmpresa,
    PL.PLIdPlantilla,
    PL.PLDescripcion
FROM @Empresas L
INNER JOIN dbo.ff_PlantillaPerfil PP ON PP.PPIdEmpresa=L.IdEmpresa
INNER JOIN dbo.ff_Plantilla PL ON PL.PLIdPlantilla=PP.PPPlantilla
WHERE PL.PLDescripcion IN
(
    N'Alta titulares - MVP_'+CONVERT(NVARCHAR(10),L.IdEmpresa),
    N'Modifica titulares - MVP_'+CONVERT(NVARCHAR(10),L.IdEmpresa),
    N'Consulta titulares - MVP_'+CONVERT(NVARCHAR(10),L.IdEmpresa)
)
ORDER BY L.IdEmpresa;

/* Evidencia emitida por el nuevo SP: debe indicar RolesCreados=0 y PerfilesCreados=0. */
SELECT
    '03_BITACORA_NUEVA' AS Bloque,
    B.BEIdEmpresa,
    B.BEIdUsuario,
    B.BEAccion,
    B.BEExitoso,
    B.BEFechaCreacion,
    B.BEDetalle,
    CASE WHEN B.BEDetalle LIKE 'Sin crear roles/perfiles.%' THEN 'OK' ELSE 'REVISAR' END AS Validacion
FROM dbo.bf_BitacoraEmpresa B
INNER JOIN @Empresas E ON E.IdEmpresa=B.BEIdEmpresa
WHERE B.BEAccion='MIGRAR_BF2_BF3_MINIMO'
ORDER BY B.BEIdEmpresa,B.BEFechaCreacion DESC;
