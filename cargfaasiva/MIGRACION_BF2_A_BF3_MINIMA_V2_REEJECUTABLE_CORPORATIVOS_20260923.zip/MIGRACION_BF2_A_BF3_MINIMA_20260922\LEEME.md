# Migracion minima de empresas BF2 a BF3

Este paquete esta pensado para empresas que **ya existen y funcionan en BF2**.
No crea empresas, roles ni perfiles. El alcance autorizado es:

- habilitar acceso a BF3 en `ff_accesoBeflex`;
- sincronizar menus BF3 de `ff_MenuRol2` sobre el rol del perfil administrador existente;
- crear o reutilizar solamente la plantilla `Interfabrica_MVP_<corporativo>` a partir de la plantilla 689;
- asociar Interfabrica al perfil administrador existente;
- marcar la empresa en `bf_EmpresaMVP` para impedir que el Wizard vuelva a ejecutar la cascada completa.

## Archivos y orden

1. `00_DIAGNOSTICO_PREVIO_SOLO_LECTURA.sql`
2. `01_RESET_MVP_ANTERIOR_A_MINIMO.sql`
3. `02_CREAR_SP_MIGRACION_MINIMA_BF2_BF3.sql`
4. `03_EJECUTAR_MIGRACION_MINIMA.sql`
5. `04_VALIDAR_RESULTADO_SOLO_LECTURA.sql`

Los scripts `00` y `04` son de solo lectura. El `01` inicia con `@Aplicar = 0` y
no cambia datos hasta que se revise su diagnostico y se cambie expresamente a 1.
El `03` tambien inicia con `@Aplicar = 0`.

## Reejecucion segura

- El instalador `02` puede ejecutarse varias veces. En servidores que no
  soportan `CREATE OR ALTER`, crea el contenedor del SP solo cuando hace falta y
  despues utiliza `ALTER PROCEDURE`.
- El reset `01` elimina sus tablas temporales al iniciar y al terminar, por lo
  que puede repetirse en la misma pestana de SSMS sin errores de objeto existente.
- El ejecutor `03` muestra `YA_EJECUTADA_PREVIAMENTE` cuando encuentra una
  bitacora exitosa. El SP no confia unicamente en esa bitacora: valida acceso,
  menus, Interfabrica, asignacion y marcador MVP. Si todo esta completo devuelve
  `YA_MIGRADA_SIN_CAMBIOS`; si existe deriva, repara solo el alcance autorizado.

## Advertencia sobre el reset

La cascada historica `bf_ProcesoMVP` no se limito a insertar. Algunos SP pudieron
actualizar perfiles BF2 existentes y reemplazar imagenes u otra configuracion.
Sin un respaldo anterior no es posible reconstruir esos valores originales.

Por seguridad, el reset:

- elimina las tres plantillas de pantalla MVP identificables por nombre y sus detalles;
- desactiva, sin borrar, roles/perfiles que pueden vincularse inequívocamente con la bitacora de copia, pero solo cuando existe otro perfil administrador activo utilizable;
- conserva acceso BF3, menus e Interfabrica;
- no intenta adivinar ni reconstruir valores BF2 previamente sobrescritos;
- muestra las configuraciones que requieren revision manual.

Adicionalmente, antes de desactivar un perfil administrador creado por la
cascada, el reset localiza un perfil administrador BF2 existente con rol activo
y reasigna ahi al administrador. Si no existe una alternativa segura, no
desactiva el unico administrador. Los menus V1 y V2 detectados se conservan: sin
evidencia suficiente, eliminarlos de un rol activo podria romper la navegacion.
La migracion minima posterior sincroniza los menus BF3 autorizados sobre el rol
administrador conservado. Una validacion transaccional revierte todo el reset si
una empresa que tenia administracion valida quedara sin ella.

Antes de aplicar el reset se requiere un respaldo de la base. No se debe ejecutar
directamente en produccion sin validar primero los bloques de resultados.

## Usuario de auditoria

El nuevo SP no recibe `@IdUsuario`. Internamente obtiene un administrador activo
asociado primero a la empresa y despues a su corporativo. Si no encuentra uno,
detiene el proceso. No utiliza `NULL` ni el ID ficticio 0.

## Lista incluida: IDs de corporativo

La lista recibida contiene estos 20 IDs de corporativo:

`495, 531, 658, 698, 718, 721, 723, 725, 727, 752, 756, 758, 760, 762, 790, 797, 799, 806, 812, 814`.

Todos los scripts resuelven las empresas hijas activas mediante
`ff_Empresa.EMidCorporativo` y excluyen el renglon del propio corporativo. Por
eso un corporativo puede producir mas de una empresa destino; en la copia local
se habian identificado 23 empresas hijas para los 20 corporativos.

Si el nuevo lote es diferente, se debe cambiar unicamente el bloque
`@Corporativos` en los scripts `00`, `01`, `03` y `04`. Antes de aplicar, el
bloque `00_RESOLUCION_CORPORATIVOS` debe mostrar al menos una empresa hija activa
para cada ID. Nunca se debe ampliar la lista sin confirmar que sean IDs de
corporativo.
