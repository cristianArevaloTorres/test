/*
  RESET CONSERVADOR DE MIGRACIONES MVP ANTERIORES

  IMPORTANTE:
    - Inicia en simulacion: @Aplicar = 0.
    - Para aplicar exige @ConfirmoRespaldo = 1.
    - Conserva acceso BF3, menus BF3 autorizados e Interfabrica.
    - Elimina artefactos deterministas no autorizados.
    - Roles/perfiles candidatos se DESACTIVAN, no se borran, y solo cuando no
      tienen usuarios activos y existe otro administrador BF2 utilizable.
    - No puede reconstruir valores BF2 que los SP anteriores hayan sobrescrito.
*/

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Aplicar BIT = 0;
DECLARE @ConfirmoRespaldo BIT = 0;
DECLARE @DesactivarRolesPerfilesSeguros BIT = 1;

DECLARE @Empresas TABLE (IdEmpresa INT PRIMARY KEY);
INSERT INTO @Empresas VALUES
(496),(532),(659),(699),(719),(720),(722),(724),(726),(728),(744),(753),
(757),(759),(761),(763),(791),(798),(800),(807),(813),(815),(2679);

IF @Aplicar = 1 AND @ConfirmoRespaldo <> 1
    THROW 51000, 'Para aplicar el reset debe existir un respaldo y @ConfirmoRespaldo debe cambiarse a 1.', 1;

/* Las fechas/usuarios de bitacora permiten limitar los candidatos a ejecuciones MVP. */
SELECT
    B.BEId,
    B.BEIdEmpresa,
    B.BEIdUsuario,
    B.BEAccion,
    B.BEFechaCreacion
INTO #AuditoriaMvp
FROM dbo.bf_BitacoraEmpresa B
INNER JOIN @Empresas E ON E.IdEmpresa=B.BEIdEmpresa
WHERE B.BEExitoso=1
  AND B.BEAccion IN
  (
      'COPIAR_ROLES','COPIAR_PERFILES','COPIAR_MENUS',
      'COPIAR_PLANTILLAS_MVP','COPIAR_CARGA_MASIVA_MVP',
      'COPIAR_PARAM_MISMOSEXO_MVP'
  );

/* Plantillas de pantalla creadas por sp_CopiarPlantillasMVP. */
SELECT DISTINCT
    E.IdEmpresa,
    P.PLIdPlantilla,
    P.PLDescripcion,
    CASE WHEN EXISTS
    (
        SELECT 1
        FROM dbo.ff_PlantillaPerfil X
        WHERE X.PPPlantilla=P.PLIdPlantilla
          AND X.PPIdEmpresa<>E.IdEmpresa
    ) THEN 0 ELSE 1 END AS SeguroEliminar
INTO #PlantillasNoAutorizadas
FROM @Empresas E
INNER JOIN dbo.ff_Plantilla P
  ON P.PLDescripcion IN
  (
      N'Alta titulares - MVP_'+CONVERT(NVARCHAR(10),E.IdEmpresa),
      N'Modifica titulares - MVP_'+CONVERT(NVARCHAR(10),E.IdEmpresa),
      N'Consulta titulares - MVP_'+CONVERT(NVARCHAR(10),E.IdEmpresa)
  );

/* Roles/perfiles insertados cerca de su bitacora de copia. */
SELECT DISTINCT
    E.IdEmpresa,
    R.ROIdRol,
    RTRIM(R.RODescripcionCorta) AS Rol,
    R.ROAdministrador,
    R.ROFechaAdd,
    R.ROUsuarioAdd,
    CASE
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Empleado X WHERE X.EMIdRol=R.ROIdRol AND X.EMIdEstatus=1)
        THEN 'CON_EMPLEADOS_ACTIVOS'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_AdministradorEmpresa X WHERE X.AEIdRol=R.ROIdRol AND X.AEIdEstatus=1)
        THEN 'CON_ADMINISTRADORES_ACTIVOS'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Perfil X WHERE X.PEIdRolDefault=R.ROIdRol AND X.PEIdEstatus=1)
        THEN 'CON_PERFILES_ACTIVOS'
      ELSE 'SEGURO_DESACTIVAR'
    END AS Validacion
INTO #RolesCandidatos
FROM @Empresas E
INNER JOIN dbo.ff_Rol R ON R.ROIdEmpresa=E.IdEmpresa AND R.ROIdEstatus=1
WHERE EXISTS
(
    SELECT 1
    FROM #AuditoriaMvp B
    WHERE B.BEIdEmpresa=E.IdEmpresa
      AND B.BEAccion='COPIAR_ROLES'
      AND B.BEIdUsuario=R.ROUsuarioAdd
      AND ABS(DATEDIFF(MINUTE,R.ROFechaAdd,B.BEFechaCreacion))<=10
);

SELECT DISTINCT
    E.IdEmpresa,
    P.PEIdPerfil,
    P.PENombre AS Perfil,
    P.PEAdministrador,
    P.PEIdRolDefault,
    P.PEFechaAdd,
    P.PEUsuarioAdd,
    CASE
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Empleado X WHERE X.EMIdPerfil=P.PEIdPerfil AND X.EMIdEstatus=1)
        THEN 'CON_EMPLEADOS_ACTIVOS'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_AdministradorEmpresa X WHERE X.AEIdPerfil=P.PEIdPerfil AND X.AEIdEstatus=1)
        THEN 'CON_ADMINISTRADORES_ACTIVOS'
      WHEN P.PEAdministrador=1 AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.ff_Perfil A
          INNER JOIN dbo.ff_Rol R ON R.ROIdRol=A.PEIdRolDefault
          WHERE A.PEIdEmpresa=E.IdEmpresa
            AND A.PEAdministrador=1
            AND A.PEIdEstatus=1
            AND A.PEIdPerfil<>P.PEIdPerfil
            AND R.ROIdEmpresa=E.IdEmpresa
            AND R.ROIdEstatus=1
            AND NOT EXISTS (SELECT 1 FROM #RolesCandidatos RC WHERE RC.ROIdRol=R.ROIdRol)
      ) THEN 'SIN_ADMIN_BF2_ALTERNATIVO'
      ELSE 'SEGURO_DESACTIVAR'
    END AS Validacion
INTO #PerfilesCandidatos
FROM @Empresas E
INNER JOIN dbo.ff_Perfil P ON P.PEIdEmpresa=E.IdEmpresa AND P.PEIdEstatus=1
WHERE EXISTS
(
    SELECT 1
    FROM #AuditoriaMvp B
    WHERE B.BEIdEmpresa=E.IdEmpresa
      AND B.BEAccion='COPIAR_PERFILES'
      AND B.BEIdUsuario=P.PEUsuarioAdd
      AND ABS(DATEDIFF(MINUTE,P.PEFechaAdd,B.BEFechaCreacion))<=10
);

/* Menus V1 agregados por la cascada anterior: no forman parte del alcance minimo BF3. */
SELECT DISTINCT MR.MRidMenuRol,E.IdEmpresa,MR.MRidRol,MR.MRidMenu
INTO #MenusV1NoAutorizados
FROM @Empresas E
INNER JOIN dbo.ff_Rol R ON R.ROIdEmpresa=E.IdEmpresa
INNER JOIN dbo.ff_MenuRol MR ON MR.MRidRol=R.ROIdRol
WHERE EXISTS
(
    SELECT 1 FROM #AuditoriaMvp B
    WHERE B.BEIdEmpresa=E.IdEmpresa
      AND B.BEAccion IN ('COPIAR_ROLES','COPIAR_MENUS')
      AND B.BEIdUsuario=MR.MRUsuarioAdd
      AND ABS(DATEDIFF(MINUTE,MR.MRFechaAdd,B.BEFechaCreacion))<=10
);

/* De ff_MenuRol2 solo se retiran inserciones antiguas que no existen en el modelo BF3 7365. */
SELECT DISTINCT MR.MRidMenuRol,E.IdEmpresa,MR.MRidRol,MR.MRidMenu
INTO #MenusV2NoAutorizados
FROM @Empresas E
INNER JOIN dbo.ff_Rol R ON R.ROIdEmpresa=E.IdEmpresa
INNER JOIN dbo.ff_MenuRol2 MR ON MR.MRidRol=R.ROIdRol
WHERE EXISTS
(
    SELECT 1 FROM #AuditoriaMvp B
    WHERE B.BEIdEmpresa=E.IdEmpresa
      AND B.BEAccion='COPIAR_MENUS'
      AND B.BEIdUsuario=MR.MRUsuarioAdd
      AND ABS(DATEDIFF(MINUTE,MR.MRFechaAdd,B.BEFechaCreacion))<=10
)
AND NOT EXISTS
(
    SELECT 1 FROM dbo.ff_MenuRol2 M
    WHERE M.MRidRol=7365
      AND M.MRidMenu=MR.MRidMenu
      AND M.MRidEstatus=1
);

/* Operaciones de carga masiva insertadas por la cascada anterior. */
SELECT DISTINCT C.CEIdOperacionEmpresa,E.IdEmpresa,C.CEIdOperacion,C.CEIdPlantilla,C.CEStoredProc
INTO #CargaMasivaNoAutorizada
FROM @Empresas E
INNER JOIN dbo.ff_CargaMasivaOperacionEmpresa C ON C.CEIdEmpresa=E.IdEmpresa
WHERE C.CEIdOperacion IN (1,2,3,13,14)
AND EXISTS
(
    SELECT 1 FROM #AuditoriaMvp B
    WHERE B.BEIdEmpresa=E.IdEmpresa
      AND B.BEAccion='COPIAR_CARGA_MASIVA_MVP'
      AND B.BEIdUsuario=C.CEUsuarioAdd
      AND ABS(DATEDIFF(MINUTE,C.CEFechaAdd,B.BEFechaCreacion))<=10
);

/* Parametro 128 insertado por la cascada anterior a nivel corporativo. */
SELECT DISTINCT P.paIdEmpresa,P.paId,P.paUsuarioAdd,P.paFechaAdd
INTO #ParametrosNoAutorizados
FROM @Empresas E
INNER JOIN dbo.ff_Empresa F ON F.EMidEmpresa=E.IdEmpresa
INNER JOIN dbo.ff_Parametro P ON P.paIdEmpresa=F.EMidCorporativo AND P.paId=128
WHERE EXISTS
(
    SELECT 1 FROM #AuditoriaMvp B
    WHERE B.BEIdEmpresa=E.IdEmpresa
      AND B.BEAccion='COPIAR_PARAM_MISMOSEXO_MVP'
      AND B.BEIdUsuario=P.paUsuarioAdd
      AND ABS(DATEDIFF(MINUTE,P.paFechaAdd,B.BEFechaCreacion))<=10
);

/* Diagnostico siempre visible antes de aplicar. */
SELECT '01_PLANTILLAS_NO_AUTORIZADAS' AS Bloque,* FROM #PlantillasNoAutorizadas ORDER BY IdEmpresa,PLIdPlantilla;
SELECT '02_ROLES_CANDIDATOS' AS Bloque,* FROM #RolesCandidatos ORDER BY IdEmpresa,ROIdRol;
SELECT '03_PERFILES_CANDIDATOS' AS Bloque,* FROM #PerfilesCandidatos ORDER BY IdEmpresa,PEIdPerfil;
SELECT '04_MENUS_V1_NO_AUTORIZADOS' AS Bloque,* FROM #MenusV1NoAutorizados ORDER BY IdEmpresa,MRidMenuRol;
SELECT '05_MENUS_V2_NO_AUTORIZADOS' AS Bloque,* FROM #MenusV2NoAutorizados ORDER BY IdEmpresa,MRidMenuRol;
SELECT '06_CARGA_MASIVA_NO_AUTORIZADA' AS Bloque,* FROM #CargaMasivaNoAutorizada ORDER BY IdEmpresa,CEIdOperacion;
SELECT '07_PARAMETROS_NO_AUTORIZADOS' AS Bloque,* FROM #ParametrosNoAutorizados ORDER BY paIdEmpresa,paId;

SELECT
    '08_CAMBIOS_NO_RECONSTRUIBLES_SIN_BACKUP' AS Bloque,
    B.BEIdEmpresa,
    B.BEAccion,
    B.BEDetalle,
    B.BEFechaCreacion
FROM dbo.bf_BitacoraEmpresa B
INNER JOIN @Empresas E ON E.IdEmpresa=B.BEIdEmpresa
WHERE B.BEExitoso=1
  AND B.BEAccion IN
  (
      'COPIAR_PERFILES','COPIAR_IMAGENES','COPIAR_COLORES','COPIAR_DOCUMENTOS',
      'COPIAR_PLANES','COPIAR_PARAMETROS','COPIAR_BEFLEX_INICIO2','COPIAR_CONFIGURACION'
  )
ORDER BY B.BEIdEmpresa,B.BEFechaCreacion;

IF @Aplicar=0
BEGIN
    SELECT 'SIMULACION: no se modificaron datos. Revise todos los bloques anteriores.' AS Resultado;
    RETURN;
END;

DECLARE @Resultado TABLE (Concepto VARCHAR(80),Cantidad INT);

BEGIN TRY
    BEGIN TRANSACTION;

    DELETE C
    FROM dbo.bf_ConfiguracionEdicionEmpresaEmpleado C
    INNER JOIN #PlantillasNoAutorizadas P ON P.PLIdPlantilla=C.CEIdPlantilla
    WHERE P.SeguroEliminar=1;
    INSERT @Resultado VALUES ('Configuracion edicion eliminada',@@ROWCOUNT);

    DELETE PP
    FROM dbo.ff_PlantillaPerfil PP
    INNER JOIN #PlantillasNoAutorizadas P ON P.PLIdPlantilla=PP.PPPlantilla
    WHERE P.SeguroEliminar=1;
    INSERT @Resultado VALUES ('Asignaciones de plantilla eliminadas',@@ROWCOUNT);

    DELETE CP
    FROM dbo.ff_ConfiguracionPlantilla CP
    INNER JOIN #PlantillasNoAutorizadas P ON P.PLIdPlantilla=CP.PLIdPlantilla
    WHERE P.SeguroEliminar=1;
    INSERT @Resultado VALUES ('Campos de plantillas eliminados',@@ROWCOUNT);

    DELETE PL
    FROM dbo.ff_Plantilla PL
    INNER JOIN #PlantillasNoAutorizadas P ON P.PLIdPlantilla=PL.PLIdPlantilla
    WHERE P.SeguroEliminar=1;
    INSERT @Resultado VALUES ('Plantillas no autorizadas eliminadas',@@ROWCOUNT);

    DELETE MR
    FROM dbo.ff_MenuRol MR
    INNER JOIN #MenusV1NoAutorizados X ON X.MRidMenuRol=MR.MRidMenuRol;
    INSERT @Resultado VALUES ('Menus V1 no autorizados eliminados',@@ROWCOUNT);

    DELETE MR
    FROM dbo.ff_MenuRol2 MR
    INNER JOIN #MenusV2NoAutorizados X ON X.MRidMenuRol=MR.MRidMenuRol;
    INSERT @Resultado VALUES ('Menus V2 ajenos al modelo eliminados',@@ROWCOUNT);

    DELETE C
    FROM dbo.ff_CargaMasivaOperacionEmpresa C
    INNER JOIN #CargaMasivaNoAutorizada X ON X.CEIdOperacionEmpresa=C.CEIdOperacionEmpresa;
    INSERT @Resultado VALUES ('Operaciones carga masiva eliminadas',@@ROWCOUNT);

    DELETE P
    FROM dbo.ff_Parametro P
    INNER JOIN #ParametrosNoAutorizados X
      ON X.paIdEmpresa=P.paIdEmpresa AND X.paId=P.paId
     AND X.paUsuarioAdd=P.paUsuarioAdd AND X.paFechaAdd=P.paFechaAdd;
    INSERT @Resultado VALUES ('Parametros no autorizados eliminados',@@ROWCOUNT);

    IF @DesactivarRolesPerfilesSeguros=1
    BEGIN
        /*
          Si la cascada reapunto al administrador hacia un perfil MVP insertado,
          regresarlo a otro perfil administrador BF2 existente. No se mueve ningun
          empleado y no se crea perfil/rol.
        */
        UPDATE AE
           SET AE.AEIdPerfil=A.PEIdPerfil,
               AE.AEIdRol=A.PEIdRolDefault,
               AE.AEUsuarioUMod=AE.AEUsuarioAdd,
               AE.AEFechaUMod=GETDATE()
        FROM dbo.ff_AdministradorEmpresa AE
        INNER JOIN #PerfilesCandidatos X ON X.PEIdPerfil=AE.AEIdPerfil
        CROSS APPLY
        (
            SELECT TOP (1) P.PEIdPerfil,P.PEIdRolDefault
            FROM dbo.ff_Perfil P
            INNER JOIN dbo.ff_Rol R
              ON R.ROIdRol=P.PEIdRolDefault
             AND R.ROIdEmpresa=X.IdEmpresa
             AND R.ROIdEstatus=1
            WHERE P.PEIdEmpresa=X.IdEmpresa
              AND P.PEAdministrador=1
              AND P.PEIdEstatus=1
              AND P.PEIdPerfil<>X.PEIdPerfil
              AND NOT EXISTS
                  (SELECT 1 FROM #PerfilesCandidatos PC WHERE PC.PEIdPerfil=P.PEIdPerfil)
            ORDER BY P.PEIdPerfil
        ) A
        WHERE AE.AEIdEstatus=1
          AND X.PEAdministrador=1
          AND NOT EXISTS
              (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdPerfil=X.PEIdPerfil AND E.EMIdEstatus=1);
        INSERT @Resultado VALUES ('Administradores regresados a perfil BF2',@@ROWCOUNT);

        UPDATE P
           SET P.PEIdEstatus=2,
               P.PEUsuarioDel=P.PEUsuarioAdd,
               P.PEFechaDel=GETDATE(),
               P.PEUsuarioUMod=P.PEUsuarioAdd,
               P.PEFechaUMod=GETDATE()
        FROM dbo.ff_Perfil P
        INNER JOIN #PerfilesCandidatos X ON X.PEIdPerfil=P.PEIdPerfil
        WHERE NOT EXISTS
                  (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdPerfil=P.PEIdPerfil AND E.EMIdEstatus=1)
          AND NOT EXISTS
                  (SELECT 1 FROM dbo.ff_AdministradorEmpresa A WHERE A.AEIdPerfil=P.PEIdPerfil AND A.AEIdEstatus=1)
          AND
          (
              P.PEAdministrador<>1
              OR EXISTS
              (
                  SELECT 1
                  FROM dbo.ff_Perfil A
                  INNER JOIN dbo.ff_Rol R ON R.ROIdRol=A.PEIdRolDefault
                  WHERE A.PEIdEmpresa=X.IdEmpresa
                    AND A.PEAdministrador=1
                    AND A.PEIdEstatus=1
                    AND A.PEIdPerfil<>P.PEIdPerfil
                    AND R.ROIdEmpresa=X.IdEmpresa
                    AND R.ROIdEstatus=1
                    AND NOT EXISTS
                        (SELECT 1 FROM #PerfilesCandidatos PC WHERE PC.PEIdPerfil=A.PEIdPerfil)
              )
          );
        INSERT @Resultado VALUES ('Perfiles MVP seguros desactivados',@@ROWCOUNT);

        /* Recalcular referencias activas despues de desactivar perfiles seguros. */
        UPDATE R
           SET R.ROIdEstatus=2,
               R.ROUsuarioDel=R.ROUsuarioAdd,
               R.ROFechaDel=GETDATE(),
               R.ROUsuarioUMod=R.ROUsuarioAdd,
               R.ROFechaUMod=GETDATE()
        FROM dbo.ff_Rol R
        INNER JOIN #RolesCandidatos X ON X.ROIdRol=R.ROIdRol
        WHERE NOT EXISTS (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdRol=R.ROIdRol AND E.EMIdEstatus=1)
          AND NOT EXISTS (SELECT 1 FROM dbo.ff_AdministradorEmpresa A WHERE A.AEIdRol=R.ROIdRol AND A.AEIdEstatus=1)
          AND NOT EXISTS (SELECT 1 FROM dbo.ff_Perfil P WHERE P.PEIdRolDefault=R.ROIdRol AND P.PEIdEstatus=1);
        INSERT @Resultado VALUES ('Roles MVP seguros desactivados',@@ROWCOUNT);
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT '09_RESULTADO_APLICACION' AS Bloque,* FROM @Resultado;

/* Lo que permanezca aqui necesita revision manual; el script no lo fuerza. */
SELECT '10_PLANTILLAS_OMITIDAS_POR_USO_COMPARTIDO' AS Bloque,*
FROM #PlantillasNoAutorizadas WHERE SeguroEliminar=0;

SELECT '11_ROLES_NO_DESACTIVADOS' AS Bloque,R.*
FROM #RolesCandidatos R
INNER JOIN dbo.ff_Rol A ON A.ROIdRol=R.ROIdRol AND A.ROIdEstatus=1;

SELECT '12_PERFILES_NO_DESACTIVADOS' AS Bloque,P.*
FROM #PerfilesCandidatos P
INNER JOIN dbo.ff_Perfil A ON A.PEIdPerfil=P.PEIdPerfil AND A.PEIdEstatus=1;
