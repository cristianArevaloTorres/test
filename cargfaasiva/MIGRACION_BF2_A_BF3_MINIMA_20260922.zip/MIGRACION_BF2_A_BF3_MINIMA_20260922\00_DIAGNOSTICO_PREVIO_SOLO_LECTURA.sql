/* DIAGNOSTICO PREVIO. SOLO LECTURA. */
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @Empresas TABLE (IdEmpresa INT PRIMARY KEY);
INSERT INTO @Empresas VALUES
(496),(532),(659),(699),(719),(720),(722),(724),(726),(728),(744),(753),
(757),(759),(761),(763),(791),(798),(800),(807),(813),(815),(2679);

SELECT
    '01_EMPRESAS' AS Bloque,
    L.IdEmpresa,
    E.EMNombre,
    E.EMidCorporativo,
    E.EMidEstatus,
    CASE WHEN E.EMidEmpresa IS NULL THEN 'NO_EXISTE'
         WHEN E.EMidEstatus <> 1 THEN 'INACTIVA'
         ELSE 'OK' END AS Validacion
FROM @Empresas L
LEFT JOIN dbo.ff_Empresa E ON E.EMidEmpresa = L.IdEmpresa
ORDER BY L.IdEmpresa;

SELECT
    '02_ADMIN_EXISTENTE' AS Bloque,
    E.IdEmpresa,
    P.PEIdPerfil,
    P.PENombre,
    P.PEAdministrador,
    P.PEIdRolDefault,
    R.RODescripcionCorta,
    CASE WHEN P.PEIdPerfil IS NULL THEN 'FALTA_PERFIL_ADMIN'
         WHEN R.ROIdRol IS NULL THEN 'FALTA_ROL_ADMIN_ACTIVO'
         ELSE 'OK' END AS Validacion
FROM @Empresas E
OUTER APPLY
(
    SELECT TOP (1) P.*
    FROM dbo.ff_Perfil P
    WHERE P.PEIdEmpresa = E.IdEmpresa
      AND P.PEAdministrador = 1
      AND P.PEIdEstatus = 1
    ORDER BY P.PEIdPerfil
) P
LEFT JOIN dbo.ff_Rol R
  ON R.ROIdRol = P.PEIdRolDefault
 AND R.ROIdEmpresa = E.IdEmpresa
 AND R.ROIdEstatus = 1
ORDER BY E.IdEmpresa;

SELECT
    '03_USUARIO_AUDITORIA' AS Bloque,
    L.IdEmpresa,
    E.EMidCorporativo,
    U.ADIdAdministrador,
    U.ADClaveAcceso,
    CASE WHEN U.ADIdAdministrador IS NULL THEN 'FALTA_ADMIN_ACTIVO' ELSE 'OK' END AS Validacion
FROM @Empresas L
LEFT JOIN dbo.ff_Empresa E ON E.EMidEmpresa = L.IdEmpresa
OUTER APPLY
(
    SELECT TOP (1) A.ADIdAdministrador, A.ADClaveAcceso
    FROM dbo.ff_AdministradorEmpresa AE
    INNER JOIN dbo.ff_administrador A
      ON A.ADIdAdministrador = AE.ADIdAdministrador
     AND A.ADIdEstatus = 1
    WHERE AE.AEIdEmpresa IN (L.IdEmpresa, E.EMidCorporativo)
      AND AE.AEIdEstatus = 1
    ORDER BY CASE WHEN AE.AEIdEmpresa = L.IdEmpresa THEN 0 ELSE 1 END,
             AE.ADIdAdministrador
) U
ORDER BY L.IdEmpresa;

SELECT
    '04_ESTADO_ACTUAL' AS Bloque,
    L.IdEmpresa,
    (SELECT COUNT(*) FROM dbo.ff_Rol R WHERE R.ROIdEmpresa=L.IdEmpresa AND R.ROIdEstatus=1) AS RolesActivos,
    (SELECT COUNT(*) FROM dbo.ff_Perfil P WHERE P.PEIdEmpresa=L.IdEmpresa AND P.PEIdEstatus=1) AS PerfilesActivos,
    (SELECT COUNT(*) FROM dbo.ff_accesoBeflex A WHERE A.idempresa=L.IdEmpresa AND A.acceso=1) AS AccesoBF3,
    (SELECT COUNT(*)
       FROM dbo.ff_MenuRol2 MR
       INNER JOIN dbo.ff_Perfil P ON P.PEIdRolDefault=MR.MRidRol
      WHERE P.PEIdEmpresa=L.IdEmpresa AND P.PEAdministrador=1 AND P.PEIdEstatus=1
        AND MR.MRidEstatus=1) AS MenusBF3Admin,
    (SELECT COUNT(*) FROM dbo.ff_PlantillaPerfil PP
       INNER JOIN dbo.ff_Plantilla PL ON PL.PLIdPlantilla=PP.PPPlantilla
      WHERE PP.PPIdEmpresa=L.IdEmpresa AND PP.PPIdEstatus=1
        AND PL.PLDescripcion=N'Interfabrica_MVP_'+CONVERT(NVARCHAR(10),E.EMidCorporativo)) AS InterfabricaAsignada
FROM @Empresas L
LEFT JOIN dbo.ff_Empresa E ON E.EMidEmpresa=L.IdEmpresa
ORDER BY L.IdEmpresa;

SELECT
    '05_PLANTILLAS_MVP_NO_AUTORIZADAS' AS Bloque,
    L.IdEmpresa,
    PL.PLIdPlantilla,
    PL.PLDescripcion,
    PL.PLFechaAdd,
    PL.PLUsuarioAdd
FROM @Empresas L
INNER JOIN dbo.ff_PlantillaPerfil PP ON PP.PPIdEmpresa=L.IdEmpresa
INNER JOIN dbo.ff_Plantilla PL ON PL.PLIdPlantilla=PP.PPPlantilla
WHERE PL.PLDescripcion IN
(
    N'Alta titulares - MVP_'+CONVERT(NVARCHAR(10),L.IdEmpresa),
    N'Modifica titulares - MVP_'+CONVERT(NVARCHAR(10),L.IdEmpresa),
    N'Consulta titulares - MVP_'+CONVERT(NVARCHAR(10),L.IdEmpresa)
)
ORDER BY L.IdEmpresa,PL.PLIdPlantilla;

SELECT
    '06_BITACORA_MVP_PREVIA' AS Bloque,
    B.BEIdEmpresa,
    B.BEIdUsuario,
    B.BEAccion,
    B.BECantidadElementos,
    B.BEExitoso,
    B.BEFechaCreacion,
    B.BEDetalle
FROM dbo.bf_BitacoraEmpresa B
INNER JOIN @Empresas E ON E.IdEmpresa=B.BEIdEmpresa
WHERE B.BEAccion IN
(
    'CREAR_EMPRESA_MVP','BF_PROCESOMVP_V3','COPIAR_ROLES','COPIAR_PERFILES',
    'COPIAR_PLANTILLAS_MVP','COPIAR_INTERFABRICA_MVP','COPIAR_CARGA_MASIVA_MVP',
    'COPIAR_PARAM_MISMOSEXO_MVP','MIGRAR_BF2_BF3_MINIMO'
)
ORDER BY B.BEIdEmpresa,B.BEFechaCreacion;

SELECT
    '07_OBJETOS_REQUERIDOS' AS Bloque,
    V.Nombre,
    CASE WHEN OBJECT_ID(V.Nombre,V.Tipo) IS NULL THEN 'FALTA' ELSE 'OK' END AS Validacion
FROM (VALUES
    ('dbo.ff_Empresa','U'),('dbo.ff_Rol','U'),('dbo.ff_Perfil','U'),
    ('dbo.ff_MenuRol2','U'),('dbo.ff_Plantilla','U'),
    ('dbo.ff_ConfiguracionPlantilla','U'),('dbo.ff_PlantillaPerfil','U'),
    ('dbo.bf_ConfiguracionEdicionEmpresaEmpleado','U'),
    ('dbo.ff_accesoBeflex','U'),('dbo.bf_EmpresaMVP','U'),
    ('dbo.bf_BitacoraEmpresa','U')) V(Nombre,Tipo)
ORDER BY V.Nombre;

