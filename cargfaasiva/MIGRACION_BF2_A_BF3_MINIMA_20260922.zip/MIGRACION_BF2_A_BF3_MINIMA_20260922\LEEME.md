# Migracion minima de empresas BF2 a BF3

Este paquete esta pensado para empresas que **ya existen y funcionan en BF2**.
No crea empresas, roles ni perfiles. El alcance autorizado es:

- habilitar acceso a BF3 en `ff_accesoBeflex`;
- sincronizar menus BF3 de `ff_MenuRol2` sobre el rol del perfil administrador existente;
- crear o reutilizar solamente la plantilla `Interfabrica_MVP_<corporativo>` a partir de la plantilla 689;
- asociar Interfabrica al perfil administrador existente;
- marcar la empresa en `bf_EmpresaMVP` para impedir que el Wizard vuelva a ejecutar la cascada completa.

## Archivos y orden

1. `00_DIAGNOSTICO_PREVIO_SOLO_LECTURA.sql`
2. `01_RESET_MVP_ANTERIOR_A_MINIMO.sql`
3. `02_CREAR_SP_MIGRACION_MINIMA_BF2_BF3.sql`
4. `03_EJECUTAR_MIGRACION_MINIMA.sql`
5. `04_VALIDAR_RESULTADO_SOLO_LECTURA.sql`

Los scripts `00` y `04` son de solo lectura. El `01` inicia con `@Aplicar = 0` y
no cambia datos hasta que se revise su diagnostico y se cambie expresamente a 1.
El `03` tambien inicia con `@Aplicar = 0`.

## Advertencia sobre el reset

La cascada historica `bf_ProcesoMVP` no se limito a insertar. Algunos SP pudieron
actualizar perfiles BF2 existentes y reemplazar imagenes u otra configuracion.
Sin un respaldo anterior no es posible reconstruir esos valores originales.

Por seguridad, el reset:

- elimina las tres plantillas de pantalla MVP identificables por nombre y sus detalles;
- desactiva, sin borrar, roles/perfiles que pueden vincularse inequívocamente con la bitacora de copia, pero solo cuando existe otro perfil administrador activo utilizable;
- conserva acceso BF3, menus e Interfabrica;
- no intenta adivinar ni reconstruir valores BF2 previamente sobrescritos;
- muestra las configuraciones que requieren revision manual.

Antes de aplicar el reset se requiere un respaldo de la base. No se debe ejecutar
directamente en produccion sin validar primero los bloques de resultados.

## Usuario de auditoria

El nuevo SP no recibe `@IdUsuario`. Internamente obtiene un administrador activo
asociado primero a la empresa y despues a su corporativo. Si no encuentra uno,
detiene el proceso. No utiliza `NULL` ni el ID ficticio 0.

## Lista incluida

Los scripts contienen la lista del paquete anterior (23 empresas):

`496, 532, 659, 699, 719, 720, 722, 724, 726, 728, 744, 753, 757, 759, 761, 763, 791, 798, 800, 807, 813, 815, 2679`.

Si el nuevo lote es diferente, se debe cambiar unicamente el bloque `@Empresas`
antes de ejecutar. Nunca se debe ampliar la lista sin confirmar los IDs.

