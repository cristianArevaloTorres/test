/*
  EJECUCION CONTROLADA DEL NUEVO SP.
  Inicia en simulacion. Cambiar @Aplicar a 1 solamente despues del diagnostico.
*/
SET NOCOUNT ON;
SET XACT_ABORT OFF;

DECLARE @Aplicar BIT = 0;

DECLARE @Empresas TABLE (IdEmpresa INT PRIMARY KEY);
INSERT INTO @Empresas VALUES
(496),(532),(659),(699),(719),(720),(722),(724),(726),(728),(744),(753),
(757),(759),(761),(763),(791),(798),(800),(807),(813),(815),(2679);

IF OBJECT_ID('dbo.bf_MigrarEmpresaBF2aBF3_Minimo','P') IS NULL
    THROW 51000, 'Primero ejecute 02_CREAR_SP_MIGRACION_MINIMA_BF2_BF3.sql.', 1;

IF @Aplicar = 0
BEGIN
    SELECT
        'SIMULACION: no se modificaron datos' AS Resultado,
        E.IdEmpresa,
        F.EMNombre,
        F.EMidCorporativo
    FROM @Empresas E
    LEFT JOIN dbo.ff_Empresa F ON F.EMidEmpresa=E.IdEmpresa
    ORDER BY E.IdEmpresa;

    SELECT 'Para aplicar, cambie DECLARE @Aplicar BIT = 0 por 1 y ejecute nuevamente.' AS Instruccion;
    RETURN;
END;

DECLARE @IdEmpresa INT;
DECLARE @Errores TABLE
(
    IdEmpresa INT NOT NULL,
    Mensaje NVARCHAR(4000) NOT NULL
);

DECLARE C CURSOR LOCAL FAST_FORWARD FOR
    SELECT IdEmpresa FROM @Empresas ORDER BY IdEmpresa;

OPEN C;
FETCH NEXT FROM C INTO @IdEmpresa;
WHILE @@FETCH_STATUS = 0
BEGIN
    BEGIN TRY
        EXEC dbo.bf_MigrarEmpresaBF2aBF3_Minimo @IdEmpresa=@IdEmpresa;
    END TRY
    BEGIN CATCH
        INSERT INTO @Errores (IdEmpresa,Mensaje)
        VALUES (@IdEmpresa,ERROR_MESSAGE());
    END CATCH;

    FETCH NEXT FROM C INTO @IdEmpresa;
END;
CLOSE C;
DEALLOCATE C;

SELECT 'ERRORES' AS Bloque,IdEmpresa,Mensaje
FROM @Errores
ORDER BY IdEmpresa;

SELECT
    'RESUMEN' AS Bloque,
    COUNT(*) AS EmpresasSolicitadas,
    (SELECT COUNT(DISTINCT BEIdEmpresa)
       FROM dbo.bf_BitacoraEmpresa B
       INNER JOIN @Empresas E ON E.IdEmpresa=B.BEIdEmpresa
      WHERE B.BEAccion='MIGRAR_BF2_BF3_MINIMO' AND B.BEExitoso=1) AS EmpresasConMigracionExitosa,
    (SELECT COUNT(*) FROM @Errores) AS EmpresasConError;

