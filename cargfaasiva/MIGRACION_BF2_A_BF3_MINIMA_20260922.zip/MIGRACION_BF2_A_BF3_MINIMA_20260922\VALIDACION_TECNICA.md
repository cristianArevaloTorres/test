# Validacion tecnica realizada

Fecha: 22 de septiembre de 2026.

Base utilizada para validar sintaxis y metadatos:

- servidor: `(localdb)\MSSQLLocalDB`;
- base: `FlexiForbesv2`.

Comprobaciones realizadas:

- `00_DIAGNOSTICO_PREVIO_SOLO_LECTURA.sql`: ejecutado sin errores;
- `01_RESET_MVP_ANTERIOR_A_MINIMO.sql`: ejecutado con `@Aplicar=0`, sin cambios;
- `02_CREAR_SP_MIGRACION_MINIMA_BF2_BF3.sql`: compilado correctamente dentro de una transaccion y revertido; el SP no quedo instalado;
- `03_EJECUTAR_MIGRACION_MINIMA.sql`: probado con `@Aplicar=0` dentro de una transaccion revertida;
- `04_VALIDAR_RESULTADO_SOLO_LECTURA.sql`: ejecutado sin errores.

No se ejecuto ninguna migracion ni reset de datos.

## Hallazgo de la copia local

Las 23 empresas existen, pero en esta copia local sus perfiles administradores
apuntan a roles que no estan disponibles/activos en `ff_Rol`. Por diseño, el SP
nuevo se detiene y reporta el problema; no crea un rol sustituto. Esto debe
revisarse en la base real antes de aplicar.

## Garantias del SP nuevo

- No contiene `INSERT`, `UPDATE` ni `DELETE` contra `ff_Rol`.
- No contiene `INSERT`, `UPDATE` ni `DELETE` contra `ff_Perfil`.
- Bloquea y compara cantidad y checksum de roles/perfiles antes y despues.
- Si detecta cualquier cambio en esas tablas, revierte la transaccion.
- Registra y devuelve `RolesCreados=0`, `RolesModificados=0`,
  `PerfilesCreados=0` y `PerfilesModificados=0`.
- Registra exactamente las plantillas creadas durante su ejecucion y revierte
  si aparece una distinta de `Interfabrica_MVP_<corporativo>`.

