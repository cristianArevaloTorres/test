﻿using ServiciosLocktonTI.Administracion;
using ServiciosLocktonTI.Modelo.BitacoraErrores;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace ServiciosLocktonTI.Servicios
{
    /// <summary>
    /// Descripción breve de WSDocumentos
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WSDocumentos : System.Web.Services.WebService
    {
        DateTime Hoy = DateTime.Today;
        DayOfWeek day = DateTime.Now.DayOfWeek;
        Bitacora bitacora = new Bitacora();

        [WebMethod]
        public Resultado CargaDocumento(int aIdOrigen, string aContraseña, int aIdEmpresa, Documento aDocumento)
        {
            string pathLog = string.Format(@"{0}Log\{1}\WSDocumentos{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, aIdEmpresa, DateTime.Now.ToString("ddMMyyyy"));

            string a = Negocio.Decrypt("PXNgegd+yGSIwsGE962V8SEvjjHrGZH5O60ysLViYEE=");
            try
            {
                DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, aIdEmpresa, Negocio.Encrypt(aContraseña), pathLog);

                if (dtDatosprovedor.Columns.Count == 0 || dtDatosprovedor.Rows.Count == 0)
                {
                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", $"No se encontro informacion con el IdOrigen {"'" + aIdOrigen + "'"}. IdOrigen incorrecto o no configurado.", pathLog);
                    return new Resultado()
                    {
                        Estatus = Documento.EEstatus.NoDisponible,
                        Descripcion = $"No se encontro informacion con el IdOrigen {"'" + aIdOrigen + "'"}. IdOrigen incorrecto o no configurado."
                    };
                }
                else
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                {
                                    if (dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                    {
                                        Negocio oReporte = new Negocio();
                                        var result = oReporte.CargaDocumento(aIdOrigen, aIdEmpresa, aDocumento, pathLog);
                                        bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", result.Descripcion, pathLog);
                                        return result;
                                    }
                                    else
                                    {
                                        bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", "Contraseña inválida", pathLog);
                                        return new Resultado()
                                        {
                                            Estatus = Documento.EEstatus.CredencialesNoValidas,
                                            Descripcion = "Contraseña inválida"// cambio  de leyanda 
                                        };
                                    }
                                }
                                else
                                {
                                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", "No se encuentra en semana laboral", pathLog);
                                    return new Resultado()
                                    {
                                        Estatus = Documento.EEstatus.FueraDeHorario,
                                        Descripcion = "No se encuentra en semana laboral"
                                    };
                                }
                            }
                            else
                            {
                                if (dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                {
                                    Negocio oReporte = new Negocio();
                                    var result = oReporte.CargaDocumento(aIdOrigen, aIdEmpresa, aDocumento, pathLog);
                                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", result.Descripcion, pathLog);
                                    return result;
                                }
                                else
                                {
                                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", "Contraseña inválida", pathLog);
                                    return new Resultado()
                                    {
                                        Estatus = Documento.EEstatus.CredencialesNoValidas,
                                        Descripcion = "Contraseña inválida"// cambio  de leyanda 
                                    };
                                }
                            }
                        }
                        else
                        {
                            bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", "Fuera de horario", pathLog);
                            return new Resultado()
                            {
                                Estatus = Documento.EEstatus.FueraDeHorario,
                                Descripcion = "Fuera de horario"// cambio  de leyanda 
                            };
                        }
                    }
                    else
                    {
                        bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", "No se encuentra dentro del rando de fechas establecidas", pathLog);
                        return new Resultado()
                        {
                            Estatus = Documento.EEstatus.FueraDeHorario,
                            Descripcion = "No se encuentra dentro del rando de fechas establecidas"// cambio  de leyanda 
                        };
                    }
                }
            }
            catch (Exception e)
            {
                bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "CargaDocumento", $"Ocurrio un error durante el proceso. Error: {e.Message}", pathLog);
                return new Resultado()
                {
                    Estatus = Documento.EEstatus.NoDisponible,
                    Descripcion = $"Ocurrio un error durante el proceso. Error: {e.Message}"
                };
            }

        }

        [WebMethod]
        public List<Documento> ConsultaDocumento(int aIdOrigen, string aContraseña, int aIdEmpresa, string NumeroEmpleado)
        {
            string pathLogDocumentos = string.Format(@"{0}Log\{1}\WSDocumentos{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, aIdEmpresa, DateTime.Now.ToString("ddMMyyyy"));
            Documento respuesta = new Documento();
            List<Documento> resplist = new List<Documento>();

            try
            {
                DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, aIdEmpresa, Negocio.Encrypt(aContraseña), pathLogDocumentos);

                if (dtDatosprovedor.Columns.Count == 0 || dtDatosprovedor.Rows.Count == 0)
                {

                    respuesta.Estatus = Documento.EEstatus.NoDisponible;
                    respuesta.Descripcion = $"No se encontro informacion con el IdOrigen {"'" + aIdOrigen + "'"}. IdOrigen incorrecto o no configurado.";
                    resplist.Add(respuesta);
                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "ConsultaDocumento", respuesta.Descripcion, pathLogDocumentos);
                    return resplist;
                }
                else
                {

                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                {
                                    if (dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                    {
                                        Negocio oReporte = new Negocio();
                                        return oReporte.ConsultadeDocumento(aIdOrigen, aIdEmpresa, NumeroEmpleado, pathLogDocumentos);
                                    }
                                    else
                                    {

                                        respuesta.Estatus = Documento.EEstatus.CredencialesNoValidas;
                                        respuesta.Descripcion = "Contraseña inválida";
                                        resplist.Add(respuesta);
                                        bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "ConsultaDocumento", respuesta.Descripcion, pathLogDocumentos);
                                        return resplist;

                                    }
                                }
                                else
                                {

                                    respuesta.Estatus = Documento.EEstatus.FueraDeHorario;
                                    respuesta.Descripcion = "No se encuentra en semana laboral";
                                    resplist.Add(respuesta);
                                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "ConsultaDocumento", respuesta.Descripcion, pathLogDocumentos);
                                    return resplist;
                                }

                            }
                            else
                            {
                                if (dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                {
                                    Negocio oReporte = new Negocio();
                                    return oReporte.ConsultadeDocumento(aIdOrigen, aIdEmpresa, NumeroEmpleado, pathLogDocumentos);
                                }
                                else
                                {

                                    respuesta.Estatus = Documento.EEstatus.CredencialesNoValidas;
                                    respuesta.Descripcion = "Contraseña inválida";
                                    resplist.Add(respuesta);
                                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "ConsultaDocumento", respuesta.Descripcion, pathLogDocumentos);
                                    return resplist;

                                }

                            }
                        }
                        else
                        {

                            respuesta.Estatus = Documento.EEstatus.FueraDeHorario;
                            respuesta.Descripcion = "Fuera de horario";
                            resplist.Add(respuesta);
                            bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "ConsultaDocumento", respuesta.Descripcion, pathLogDocumentos);
                            return resplist;
                        }
                    }
                    else
                    {

                        respuesta.Estatus = Documento.EEstatus.FueraDeHorario;
                        respuesta.Descripcion = "No se encuentra dentro del rando de fechas establecidas";
                        resplist.Add(respuesta);
                        bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "ConsultaDocumento", respuesta.Descripcion, pathLogDocumentos);
                        return resplist;
                    }
                }
            }
            catch (Exception e)
            {
                respuesta.Estatus = Documento.EEstatus.NoDisponible;
                respuesta.Descripcion = $"Ocurrio un error durante el proceso. Error: {e.Message}";
                resplist.Add(respuesta);
                bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "ConsultaDocumento", respuesta.Descripcion, pathLogDocumentos);
                return resplist;
            }
        }

        [WebMethod]
        public Resultado EliminaDocumento(int aIdOrigen, string aContraseña, int aIdEmpresa, Int64 IdDocumento)
        {
            string pathLogDocumentos = string.Format(@"{0}Log\{1}\WSDocumentos{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, aIdEmpresa, DateTime.Now.ToString("ddMMyyyy"));

            try
            {
                DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, aIdEmpresa, Negocio.Encrypt(aContraseña), pathLogDocumentos);

                if (dtDatosprovedor.Columns.Count == 0 || dtDatosprovedor.Rows.Count == 0)
                {
                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", $"No se encontro informacion con el IdOrigen {"'" + aIdOrigen + "'"}. IdOrigen incorrecto o no configurado.", pathLogDocumentos);
                    return new Resultado()
                    {
                        Estatus = Documento.EEstatus.NoDisponible,
                        Descripcion = $"No se encontro informacion con el IdOrigen {"'" + aIdOrigen + "'"}. IdOrigen incorrecto o no configurado."
                    };
                }
                else
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                {
                                    if (dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                    {
                                        Negocio oReporte = new Negocio();
                                        var result = oReporte.EliminaDocumento(aIdOrigen, aIdEmpresa, IdDocumento, pathLogDocumentos);
                                        bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", result.Descripcion, pathLogDocumentos);
                                        return result;
                                    }
                                    else
                                    {
                                        bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", "Contraseña inválida", pathLogDocumentos);
                                        return new Resultado()
                                        {
                                            Estatus = Documento.EEstatus.CredencialesNoValidas,
                                            Descripcion = "Contraseña inválida"// cambio  de leyanda 
                                        };
                                    }
                                }
                                else
                                {
                                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", "No se encuentra en semana laboral", pathLogDocumentos);
                                    return new Resultado()
                                    {
                                        Estatus = Documento.EEstatus.FueraDeHorario,
                                        Descripcion = "No se encuentra en semana laboral"
                                    };
                                }
                            }
                            else
                            {
                                if (dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                {
                                    Negocio oReporte = new Negocio();
                                    var result = oReporte.EliminaDocumento(aIdOrigen, aIdEmpresa, IdDocumento, pathLogDocumentos);
                                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", result.Descripcion, pathLogDocumentos);
                                    return result;
                                }
                                else
                                {
                                    bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", "Contraseña inválida", pathLogDocumentos);
                                    return new Resultado()
                                    {
                                        Estatus = Documento.EEstatus.CredencialesNoValidas,
                                        Descripcion = "Contraseña inválida"// cambio  de leyanda 
                                    };
                                }
                            }
                        }
                        else
                        {
                            bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", "Fuera de horario", pathLogDocumentos);
                            return new Resultado()
                            {
                                Estatus = Documento.EEstatus.FueraDeHorario,
                                Descripcion = "Fuera de horario"// cambio  de leyanda 
                            };
                        }
                    }
                    else
                    {
                        bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", "No se encuentra dentro del rando de fechas establecidas", pathLogDocumentos);
                        return new Resultado()
                        {
                            Estatus = Documento.EEstatus.FueraDeHorario,
                            Descripcion = "No se encuentra dentro del rando de fechas establecidas"
                        };
                    }
                }
            }
            catch (Exception e)
            {
                bitacora.GuardarBitacora(aIdOrigen, aIdEmpresa, "EliminaDocumento", $"Ocurrio un error durante el proceso. Error: {e.Message}", pathLogDocumentos);
                return new Resultado()
                {
                    Estatus = Documento.EEstatus.NoDisponible,
                    Descripcion = $"Ocurrio un error durante el proceso. Error: {e.Message}"
                };
            }

        }




    }
}
