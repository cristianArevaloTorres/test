$ErrorActionPreference = 'Stop'

$RepoFront = 'C:\repo\reportes\FRONT'
$TargetBranch = 'issue-reportesabanaQA'
$TargetFile = 'src/app/beflex/adm-reportes/sabana-beneficios/sabana-beneficios.component.html'
$StashName = 'temporal-tooltip-confidencial-sabana'

Set-Location -LiteralPath $RepoFront
git rev-parse --is-inside-work-tree | Out-Null
if ($LASTEXITCODE -ne 0) { throw "No es un repositorio Git: $RepoFront" }
if (-not (Test-Path -LiteralPath $TargetFile -PathType Leaf)) { throw "No existe $TargetFile" }

# Permite iniciar incluso si el repositorio quedo posicionado en QA. Guarda
# solamente el HTML de esta entrega; no incluye .vs, package-lock.json ni global.ts.
$HasTargetChange = -not [string]::IsNullOrWhiteSpace((git status --porcelain -- $TargetFile | Out-String))
if (-not $HasTargetChange) { throw "No hay cambio pendiente en $TargetFile. Primero copie el archivo del ZIP al repositorio." }

git stash push -m $StashName -- $TargetFile
if ($LASTEXITCODE -ne 0) { throw 'No fue posible guardar temporalmente el HTML.' }

git fetch origin
if ($LASTEXITCODE -ne 0) { throw 'Fallo git fetch.' }

git show-ref --verify --quiet "refs/heads/$TargetBranch"
if ($LASTEXITCODE -eq 0) {
    git switch $TargetBranch
} else {
    git switch -c $TargetBranch --track "origin/$TargetBranch"
}
if ($LASTEXITCODE -ne 0) { throw "No fue posible cambiar a $TargetBranch." }

git pull --ff-only origin $TargetBranch
if ($LASTEXITCODE -ne 0) { throw "No fue posible actualizar $TargetBranch sin mezclar historiales." }

git stash pop 'stash@{0}'
if ($LASTEXITCODE -ne 0) { throw 'Revise el conflicto al restaurar el HTML; no se creo commit ni se hizo push.' }

git add -- $TargetFile
$Staged = @(git diff --cached --name-only)
if ($Staged.Count -ne 1 -or $Staged[0] -ne $TargetFile) {
    throw 'El staging contiene archivos distintos de la entrega. Revise git diff --cached --name-only.'
}

git diff --cached --check
if ($LASTEXITCODE -ne 0) { throw 'El cambio contiene errores de espacios o formato.' }

git commit -m 'Aclara comportamiento confidencial en sabana B3'
if ($LASTEXITCODE -ne 0) { throw 'No fue posible crear el commit.' }

git push -u origin $TargetBranch
if ($LASTEXITCODE -ne 0) { throw "No fue posible enviar origin/$TargetBranch." }

Write-Host "Cambio enviado correctamente a origin/$TargetBranch." -ForegroundColor Green
git status --short
