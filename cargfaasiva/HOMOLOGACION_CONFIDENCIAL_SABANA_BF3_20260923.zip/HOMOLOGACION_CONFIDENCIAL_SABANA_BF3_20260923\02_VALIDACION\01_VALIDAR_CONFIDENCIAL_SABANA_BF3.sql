USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*
    VALIDACION DE SOLO LECTURA

    Regla esperada para reportes de ALTAS:
      @Confidencial = 0: excluye empleados confidenciales.
      @Confidencial = 1: incluye confidenciales y no confidenciales.

    Este archivo no crea, altera ni elimina objetos o datos.
*/

DECLARE @Resultado table
(
    Orden   int            NOT NULL,
    Estado  varchar(10)    NOT NULL,
    Clave   nvarchar(100)  NOT NULL,
    Valor   nvarchar(4000) NULL,
    Detalle nvarchar(4000) NULL
);

DECLARE @Wrapper nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_Sabana_BF3')),
        @GMM     nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaGMM_BF3')),
        @Vida    nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaVIDA_BF3')),
        @Opc     nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaOPC_BF3')),
        @Mascota nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaMascotas_BF3'));

DECLARE @WrapperN nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(@Wrapper,N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N'')),
        @GmmN     nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(@GMM,N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N'')),
        @VidaN    nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(@Vida,N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N'')),
        @OpcN     nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(@Opc,N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N''));

INSERT @Resultado
SELECT 10,
       CASE WHEN @Wrapper IS NOT NULL AND @GMM IS NOT NULL AND @Vida IS NOT NULL AND @Opc IS NOT NULL AND @Mascota IS NOT NULL THEN 'OK' ELSE 'ALERTA' END,
       N'ObjetosBF3',
       CONCAT(N'Wrapper=',IIF(@Wrapper IS NULL,0,1),N'; GMM=',IIF(@GMM IS NULL,0,1),N'; Vida=',IIF(@Vida IS NULL,0,1),N'; Opcionales=',IIF(@Opc IS NULL,0,1),N'; Mascotas=',IIF(@Mascota IS NULL,0,1)),
       N'Deben existir los cinco procedimientos vigentes.';

INSERT @Resultado
SELECT 20,
       CASE WHEN @WrapperN LIKE N'%@CONFIDENCIAL%'
                  AND @WrapperN LIKE N'%FF_SABANAGMM_BF3%@CONFIDENCIAL%'
                  AND @WrapperN LIKE N'%FF_SABANAVIDA_BF3%@CONFIDENCIAL%'
                  AND @WrapperN LIKE N'%FF_SABANAOPC_BF3%@CONFIDENCIAL%'
            THEN 'OK' ELSE 'ALERTA' END,
       N'PropagacionWrapper',
       N'@Confidencial hacia GMM, Vida y Opcionales',
       N'El wrapper debe transmitir el mismo valor recibido desde la pantalla.';

INSERT @Resultado
SELECT 30,
       CASE WHEN @GmmN LIKE N'%AND(1=%@CONFIDENCIAL%OREM.EMIDSALARIOCONFIDENCIAL=0)%' THEN 'OK' ELSE 'ALERTA' END,
       N'ReglaGMMAltas',
       N'0=no confidenciales; 1=todos',
       N'No se validan columnas por texto: la regla solamente pertenece al WHERE.';

INSERT @Resultado
SELECT 40,
       CASE WHEN @VidaN LIKE N'%(@CONFIDENCIAL=1OREM.EMIDSALARIOCONFIDENCIAL=0)%' THEN 'OK' ELSE 'ALERTA' END,
       N'ReglaVidaAltas',
       N'0=no confidenciales; 1=todos',
       N'No se validan columnas por texto: la regla solamente pertenece al WHERE.';

INSERT @Resultado
SELECT 50,
       CASE WHEN @OpcN LIKE N'%(@CONFIDENCIAL=1OREM.EMIDSALARIOCONFIDENCIAL=0)%' THEN 'OK' ELSE 'ALERTA' END,
       N'ReglaOpcionalesAltas',
       N'0=no confidenciales; 1=todos',
       N'No se validan columnas por texto: la regla solamente pertenece al WHERE.';

INSERT @Resultado
SELECT 60,
       CASE WHEN COUNT(*)=1 AND MAX(UPPER(LTRIM(RTRIM(P.catReportesParamsNombre))))=N'@CONFIDENCIAL' THEN 'OK' ELSE 'ALERTA' END,
       N'ParametroCatalogo',
       CONCAT(N'Coincidencias=',COUNT(*),N'; orden=',MAX(P.catReportesParamsOrden),N'; activo=',MAX(P.ESId)),
       N'Debe existir una sola vez para la ruta activa del reporte 3.'
FROM dbo.bf_CatReportesSP AS SP
INNER JOIN dbo.bf_CatReportesParams AS P ON P.catReportesSPId=SP.catReportesSPId
WHERE SP.catReportesId=3
  AND ISNULL(SP.ESId,1)=1
  AND UPPER(LTRIM(RTRIM(P.catReportesParamsNombre)))=N'@CONFIDENCIAL';

INSERT @Resultado
SELECT 100+ISNULL(CS.CSIdTipoSabana,0),
       'INFO',
       CONCAT(N'ConfiguracionTipo',ISNULL(CONVERT(varchar(20),CS.CSIdTipoSabana),'NULL')),
       CONCAT(N'Filas=',COUNT(*),N'; pestanas=',COUNT(DISTINCT ISNULL(CS.CSAlias,N''))),
       N'Inventario informativo. Esta entrega no modifica ff_ConfiguracionSabana.'
FROM dbo.ff_ConfiguracionSabana AS CS
WHERE CS.CSIdEstatus=1
GROUP BY CS.CSIdTipoSabana;

SELECT Estado,Clave,Valor,Detalle
FROM @Resultado
ORDER BY Orden;
GO
