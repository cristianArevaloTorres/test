USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* Validacion de solo lectura posterior al despliegue. */

SELECT
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM dbo.bf_CatalogoEstatusReporteGen
            WHERE CatERptId = 7
              AND UPPER(LTRIM(RTRIM(CatERptNombre))) = N'EN ESPERA'
        ) THEN 'OK'
        ELSE 'ERROR'
    END AS ValidacionCatalogo,
    N'7 = En espera' AS ResultadoEsperado;

SELECT
    C.CRptId,
    C.CRptFechaSolicitud,
    C.CRptFechaGeneracion,
    C.CRptIdUsuarioSolicitud,
    C.CRptIdEmpresa,
    C.CRptIdEstatus,
    E.CatERptNombre AS Estatus,
    C.CRptObservaciones,
    C.CRptRuta
FROM dbo.bf_ControlReporteGen AS C
LEFT JOIN dbo.bf_CatalogoEstatusReporteGen AS E
       ON E.CatERptId = C.CRptIdEstatus
WHERE C.CRptIdReporte = 11
ORDER BY C.CRptId DESC;

SELECT
    COALESCE(SUM(CASE WHEN CRptIdEstatus = 1 THEN 1 ELSE 0 END), 0) AS EnProceso,
    COALESCE(SUM(CASE WHEN CRptIdEstatus = 7 THEN 1 ELSE 0 END), 0) AS EnEspera,
    CASE
        WHEN COALESCE(SUM(CASE WHEN CRptIdEstatus = 1 THEN 1 ELSE 0 END), 0) <= 1
        THEN 'OK'
        ELSE 'ERROR: hay mas de una Cobranza en proceso'
    END AS ValidacionConcurrencia
FROM dbo.bf_ControlReporteGen
WHERE CRptIdReporte = 11;
GO
