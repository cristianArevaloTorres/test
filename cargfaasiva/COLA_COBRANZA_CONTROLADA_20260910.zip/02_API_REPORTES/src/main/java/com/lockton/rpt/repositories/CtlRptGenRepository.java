package com.lockton.rpt.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.lockton.rpt.models.entities.ControlReporteGen;

@Repository
public interface CtlRptGenRepository extends JpaRepository<ControlReporteGen, Long> {
//    boolean existsByCRptIdUsuarioSolicitudAndCRptIdReporteAndCRptIdEmpresaAndCRptParamsAndCRptIdEstatus(
//        Integer cRptIdUsuarioSolicitud,
//        Integer cRptIdReporte,
//        Integer cRptIdEmpresa,
//        String cRptParams,
//        Integer cRptIdEstatus
//    );

    @Query(
            "SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END " +
                    "FROM ControlReporteGen c " +
                    "WHERE c.cRptIdUsuarioSolicitud = :cRptIdUsuarioSolicitud " +
                    "AND c.cRptIdReporte = :cRptIdReporte " +
                    "AND c.cRptIdEmpresa = :cRptIdEmpresa " +
                    "AND c.cRptParams = :cRptParams " +
                    "AND c.cRptIdEstatus = :cRptIdEstatus"
    )
    boolean existsControlReporteGen(
            @Param("cRptIdUsuarioSolicitud") Integer cRptIdUsuarioSolicitud,
            @Param("cRptIdReporte") Integer cRptIdReporte,
            @Param("cRptIdEmpresa") Integer cRptIdEmpresa,
            @Param("cRptParams") String cRptParams,
            @Param("cRptIdEstatus") Integer cRptIdEstatus
    );

    @Query(
            "SELECT c FROM ControlReporteGen c " +
                    "WHERE c.cRptIdUsuarioSolicitud = :idUsuario " +
                    "AND c.cRptIdReporte = :idReporte " +
                    "AND c.cRptIdEmpresa = :idEmpresa " +
                    "AND c.cRptParams = :params " +
                    "AND c.cRptIdEstatus IN (:estatus) " +
                    "ORDER BY c.cRptId ASC"
    )
    List<ControlReporteGen> findSolicitudesActivas(
            @Param("idUsuario") Integer idUsuario,
            @Param("idReporte") Integer idReporte,
            @Param("idEmpresa") Integer idEmpresa,
            @Param("params") String params,
            @Param("estatus") List<Integer> estatus
    );
}
