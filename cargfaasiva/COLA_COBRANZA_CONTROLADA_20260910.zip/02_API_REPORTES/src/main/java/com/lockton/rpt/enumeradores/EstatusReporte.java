package com.lockton.rpt.enumeradores;

public enum EstatusReporte {
    
    EN_PROCESO(1),
    DISPONIBLE(2),
    ERROR(3),
    PROGRAMADO(4),
    DEPURADO(5),
    SIN_DATOS(6),
    EN_ESPERA(7);

    private int numVal;

    EstatusReporte(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }
}
