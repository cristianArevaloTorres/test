package com.lockton.rpt.services.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Serializa la generacion de Cobranza tambien entre dos despliegues que usen
 * la misma base. El executor limita cada JVM; sp_getapplock cubre el caso de
 * varias instancias del WAR.
 */
@Component
public class CobranzaExecutionGate {

    private static final String LOCK_RESOURCE =
            "BEFLEX_API_REPORTES_COBRANZA_GENERACION";

    private final JdbcTemplate jdbcTemplate;
    private final int lockTimeoutMs;

    public CobranzaExecutionGate(
            JdbcTemplate jdbcTemplate,
            @Value("${cobranza.queue.lock-timeout-ms:30000}")
            int lockTimeoutMs) {
        this.jdbcTemplate = jdbcTemplate;
        this.lockTimeoutMs = lockTimeoutMs;
    }

    public void ejecutarCuandoDisponible(Runnable trabajo) {
        boolean ejecutado = false;
        while (!ejecutado) {
            if (Thread.currentThread().isInterrupted()) {
                throw new IllegalStateException(
                        "La espera de Cobranza fue interrumpida.");
            }
            Boolean resultado = jdbcTemplate.execute(
                    (ConnectionCallback<Boolean>) connection ->
                            intentarEjecutar(connection, trabajo));
            ejecutado = Boolean.TRUE.equals(resultado);
        }
    }

    private boolean intentarEjecutar(Connection connection, Runnable trabajo)
            throws java.sql.SQLException {
        int resultado = adquirir(connection);
        if (resultado == -1) {
            // Otra instancia sigue procesando. El registro permanece EN_ESPERA
            // y se vuelve a intentar sin consumir una consulta de Cobranza.
            return false;
        }
        if (resultado < 0) {
            throw new IllegalStateException(
                    "No fue posible adquirir el bloqueo de Cobranza. Codigo: "
                    + resultado);
        }

        try {
            trabajo.run();
            return true;
        } finally {
            liberar(connection);
        }
    }

    private int adquirir(Connection connection) throws java.sql.SQLException {
        try (CallableStatement call = connection.prepareCall(
                "{? = call sys.sp_getapplock(?, ?, ?, ?)}")) {
            call.registerOutParameter(1, Types.INTEGER);
            call.setString(2, LOCK_RESOURCE);
            call.setString(3, "Exclusive");
            call.setString(4, "Session");
            call.setInt(5, lockTimeoutMs);
            call.execute();
            return call.getInt(1);
        }
    }

    private void liberar(Connection connection) {
        try (CallableStatement call = connection.prepareCall(
                "{? = call sys.sp_releaseapplock(?, ?)}")) {
            call.registerOutParameter(1, Types.INTEGER);
            call.setString(2, LOCK_RESOURCE);
            call.setString(3, "Session");
            call.execute();
        } catch (Exception ignored) {
            // El cierre de la conexion tambien libera un bloqueo de sesion.
        }
    }
}
