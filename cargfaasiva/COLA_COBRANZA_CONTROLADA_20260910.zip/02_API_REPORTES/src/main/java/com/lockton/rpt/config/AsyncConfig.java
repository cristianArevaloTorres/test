package com.lockton.rpt.config;


import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
public class AsyncConfig {
    
    @Autowired
    private Environment env;

    @Bean(name = "taskExecutor")
    public Executor taskExecutor(){
        ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
        exec.setCorePoolSize(Integer.parseInt(env.getProperty("spring.task.poolsize")));
        exec.setMaxPoolSize(Integer.parseInt(env.getProperty("spring.task.maxpoolsize")));
        exec.setQueueCapacity(Integer.parseInt(env.getProperty("spring.task.queuecapacity")));

        exec.setThreadNamePrefix("Reporte-");
        exec.initialize();
        return exec;
    }

    /**
     * Ejecutor exclusivo y acotado para Cobranza. Un reporte puede permanecer
     * varias horas en SQL; por eso no debe compartir el ForkJoinPool comun ni
     * ejecutarse en paralelo con otra Cobranza dentro de esta instancia.
     */
    @Bean(name = "cobranzaExecutor")
    public Executor cobranzaExecutor() {
        ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
        exec.setCorePoolSize(1);
        exec.setMaxPoolSize(1);
        exec.setQueueCapacity(Integer.parseInt(env.getProperty(
                "cobranza.queue.capacity", "5")));
        exec.setThreadNamePrefix("Cobranza-");
        exec.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        exec.setWaitForTasksToCompleteOnShutdown(false);
        exec.setAwaitTerminationSeconds(30);
        exec.initialize();
        return exec;
    }
}
