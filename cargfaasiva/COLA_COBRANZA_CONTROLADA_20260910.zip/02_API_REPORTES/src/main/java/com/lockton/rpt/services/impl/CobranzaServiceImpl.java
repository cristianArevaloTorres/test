package com.lockton.rpt.services.impl;

import com.lockton.rpt.dao.JDBCCobranza;
import com.lockton.rpt.enumeradores.CatTipoNotificacionReporte;
import com.lockton.rpt.enumeradores.EstatusReporte;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.models.entities.ConfiguracionReporteGen;
import com.lockton.rpt.models.entities.ControlReporteGen;
import com.lockton.rpt.repositories.CfgRptGenRepository;
import com.lockton.rpt.repositories.CtlRptGenRepository;
import com.lockton.rpt.services.CobranzaService;
import com.lockton.rpt.util.Correo;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CobranzaServiceImpl implements CobranzaService {

    private static final Log LOGGER = LogFactory.getLog(CobranzaServiceImpl.class);

    // catReportesSPId para ff_Cobranza_v2
    private static final int REPORTE_ID_COBRANZA = 11;
    private static final String NOMBRE_REPORTE_COBRANZA = "Cobranza";

    @Autowired
    private JDBCCobranza jdbcCobranza;

    @Autowired
    private CtlRptGenRepository ctlRptGenRepository;

    @Autowired
    private CfgRptGenRepository cfgRptGenRepository;

    @Autowired
    private Correo correoServ;

    @Autowired
    @Qualifier("cobranzaExecutor")
    private Executor cobranzaExecutor;

    @Autowired
    private CobranzaExecutionGate cobranzaExecutionGate;

    @Value("${cobranza.ruta.base}")
    private String rutaBase;

    private void debug(String etapa, String detalle) {
        LOGGER.info("COBRANZA-DEBUG " + etapa + " " + detalle);
    }

    @Override
    public List<Object> consultaCobranza(
            int idEmpresa, int idSolTipo, String FecIni, String FecFin,
            int idVencida, List<Integer> IdsPerfil, String empresa, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email,
            int idVigencia, int bandera, int idUsuario, String token) {

        // La pantalla usa este mismo endpoint para recuperar el historial de
        // archivos. Esa lectura no es una solicitud de generacion y no debe
        // crear un renglon de seguimiento (antes producia Usuario=0 y /empty).
        boolean consultaLista = esConsultaListaArchivos(
                idSolTipo, FecIni, FecFin, idVencida, IdsPerfil,
                empresa, nomCorp, nomAdm, nomEmp, email);
        Long rptId = consultaLista ? 0L
                : registrarSeguimiento(idUsuario, idEmpresa,
                        EstatusReporte.EN_PROCESO, "");
        try {
            List<Object> result = jdbcCobranza.consultaCobranza(
                    idEmpresa, idSolTipo, FecIni, FecFin, idVencida, IdsPerfil,
                    empresa, idCorporativo, nomCorp, nomAdm, nomEmp, email,
                    idVigencia, bandera, rutaBase);

            String ruta = extraerRuta(result, idEmpresa);
            actualizarSeguimientoPorResultado(rptId, result, ruta);
            if (!consultaLista) {
                notificarResultado(idUsuario, idEmpresa, nomAdm, nomEmp,
                        email, result, ruta,
                        esRespuestaError(result) ? mensajeRespuesta(result) : "",
                        token);
            }
            return result;
        } catch (Exception e) {
            LOGGER.error("CobranzaServiceImpl.consultaCobranza: " + e.getMessage(), e);
            actualizarSeguimiento(rptId, EstatusReporte.ERROR, e.getMessage(), "");
            if (!consultaLista) {
                notificarResultado(idUsuario, idEmpresa, nomAdm, nomEmp,
                        email, null, "", e.getMessage(), token);
            }
            throw e;
        }
    }

    @Override
    public synchronized ResponseGralDTO solicitarAsync(
            int idEmpresa, int idSolTipo, String FecIni, String FecFin,
            int idVencida, List<Integer> IdsPerfil, String empresa, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email,
            int idVigencia, int bandera, int idUsuario, String token) {

        ResponseGralDTO response = new ResponseGralDTO();
        String claveSolicitud = claveSolicitud(
                idSolTipo, FecIni, FecFin, idVencida, IdsPerfil,
                idCorporativo, idVigencia, bandera);
        Long solicitudActiva = buscarSolicitudActiva(
                idUsuario, idEmpresa, claveSolicitud);
        if (solicitudActiva != null) {
            response.status = true;
            response.messages = "La misma solicitud de Cobranza ya esta "
                    + "en espera o en proceso con Id:" + solicitudActiva;
            return response;
        }

        Long rptId = registrarSeguimiento(idUsuario, idEmpresa,
                EstatusReporte.EN_ESPERA, claveSolicitud);
        if (rptId == 0L) {
            debug("cobranza_solicitar_error", "No se pudo registrar la solicitud idEmpresa=" + idEmpresa);
            response.status = false;
            response.messages = "No se pudo registrar la solicitud.";
            return response;
        }

        debug("cobranza_solicitar_inicio",
            "rptId=" + rptId + " idEmpresa=" + idEmpresa + " idVigencia=" + idVigencia
            + " FecIni=" + FecIni + " FecFin=" + FecFin + " bandera=" + bandera
            + " perfiles=" + IdsPerfil);

        Runnable generacion = () -> {
            List<Object> result = null;
            String ruta = "";
            String errorNotificacion = "";
            try {
                marcarEnProceso(rptId);
                debug("cobranza_sp_inicio", "rptId=" + rptId + " thread=" + Thread.currentThread().getName());
                result = jdbcCobranza.consultaCobranza(
                        idEmpresa, idSolTipo, FecIni, FecFin, idVencida, IdsPerfil,
                        empresa, idCorporativo, nomCorp, nomAdm, nomEmp, email,
                        idVigencia, bandera, rutaBase);
                ruta = extraerRuta(result, idEmpresa);
                boolean esError = esRespuestaError(result);
                if (esError) {
                    String msg = mensajeRespuesta(result);
                    errorNotificacion = msg;
                    EstatusReporte estatus = esRespuestaSinDatos(result)
                            ? EstatusReporte.SIN_DATOS : EstatusReporte.ERROR;
                    debug(estatus == EstatusReporte.SIN_DATOS
                            ? "cobranza_sp_sin_datos" : "cobranza_sp_error",
                            "rptId=" + rptId + " msg=" + msg);
                    actualizarSeguimiento(rptId, estatus, msg, "");
                } else if (ruta.isEmpty()) {
                    String msg = "El reporte termino sin devolver la ruta del archivo.";
                    errorNotificacion = msg;
                    debug("cobranza_sp_error", "rptId=" + rptId + " msg=" + msg);
                    actualizarSeguimiento(rptId, EstatusReporte.ERROR, msg, "");
                } else {
                    debug("cobranza_sp_ok", "rptId=" + rptId + " ruta=" + ruta);
                    actualizarSeguimiento(rptId, EstatusReporte.DISPONIBLE, "", ruta);
                }
            } catch (Exception e) {
                LOGGER.error("CobranzaServiceImpl.solicitarAsync: " + e.getMessage(), e);
                errorNotificacion = e.getMessage();
                debug("cobranza_sp_error", "rptId=" + rptId + " error=" + e.getMessage());
                actualizarSeguimiento(rptId, EstatusReporte.ERROR, e.getMessage(), "");
            } finally {
                notificarResultado(idUsuario, idEmpresa, nomAdm, nomEmp,
                        email, result, ruta, errorNotificacion, token);
            }
        };

        try {
            cobranzaExecutor.execute(() -> {
                try {
                    cobranzaExecutionGate.ejecutarCuandoDisponible(generacion);
                } catch (Exception e) {
                    LOGGER.error("No se pudo iniciar la solicitud de Cobranza Id="
                            + rptId + ": " + e.getMessage(), e);
                    actualizarSeguimiento(rptId, EstatusReporte.ERROR,
                            e.getMessage(), "");
                    notificarResultado(idUsuario, idEmpresa, nomAdm, nomEmp,
                            email, null, "", e.getMessage(), token);
                }
            });
        } catch (RejectedExecutionException e) {
            String mensaje = "La cola de Cobranza alcanzo su capacidad. "
                    + "Intente nuevamente cuando finalice una solicitud.";
            actualizarSeguimiento(rptId, EstatusReporte.ERROR, mensaje, "");
            debug("cobranza_cola_llena", "rptId=" + rptId);
            response.status = false;
            response.messages = mensaje;
            return response;
        }

        response.status = true;
        response.messages = "Solicitud de Cobranza registrada EN_ESPERA con Id:"
                + rptId;
        return response;
    }

    @Override public int    getVigenciaActiva(int idEmpresa)       { return jdbcCobranza.getVigenciaActiva(idEmpresa); }
    @Override public String getFechaInicioVigencia(int vigencia)    { return jdbcCobranza.getFechaInicioVigencia(vigencia); }
    @Override public String getFechaFinalVigencia(int vigencia)     { return jdbcCobranza.getFechaFinalVigencia(vigencia); }
    @Override public String getFechaInicioEnrollment(int vigencia)  { return jdbcCobranza.getFechaInicioEnrollment(vigencia); }
    @Override public int    getConfiguracionEnvio(int idCorporativo){ return jdbcCobranza.getPeriocidad(idCorporativo); }
    @Override public List<Object> getPeriodicidadDePagos(int v)     { return jdbcCobranza.getPeriodicidadDePagos(v); }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private Long registrarSeguimiento(
            int idUsuario, int idEmpresa, EstatusReporte estatus,
            String params) {
        try {
            ControlReporteGen ent = new ControlReporteGen();
            ent.setCRptIdUsuarioSolicitud(idUsuario);
            ent.setCRptIdReporte(REPORTE_ID_COBRANZA);
            ent.setCRptFechaSolicitud(new Date());
            ent.setCRptIdEmpresa(idEmpresa);
            ent.setCRptRuta("");
            ent.setCRptIdEstatus(estatus.getNumVal());
            ent.setCRptObservaciones(estatus == EstatusReporte.EN_ESPERA
                    ? "Solicitud en espera; Cobranza procesa un reporte a la vez."
                    : "");
            ent.setCRptUsuarioAdd(idUsuario);
            ent.setCRptFechaAdd(new Date());
            ent.setCRptParams(params == null ? "" : params);
            ctlRptGenRepository.save(ent);
            return ent.getCRptId();
        } catch (Exception e) {
            LOGGER.warn("No se pudo registrar seguimiento: " + e.getMessage());
            return 0L;
        }
    }

    private Long buscarSolicitudActiva(
            int idUsuario, int idEmpresa, String params) {
        try {
            List<ControlReporteGen> activas =
                    ctlRptGenRepository.findSolicitudesActivas(
                            idUsuario, REPORTE_ID_COBRANZA, idEmpresa, params,
                            Arrays.asList(
                                    EstatusReporte.EN_ESPERA.getNumVal(),
                                    EstatusReporte.EN_PROCESO.getNumVal()));
            return activas == null || activas.isEmpty()
                    ? null : activas.get(0).getCRptId();
        } catch (Exception e) {
            LOGGER.warn("No se pudo validar duplicidad de Cobranza: "
                    + e.getMessage());
            return null;
        }
    }

    private void marcarEnProceso(Long id) {
        if (id == null || id == 0) return;
        try {
            ctlRptGenRepository.findById(id).ifPresent(ent -> {
                ent.setCRptIdEstatus(EstatusReporte.EN_PROCESO.getNumVal());
                ent.setCRptObservaciones("Cobranza en proceso.");
                ent.setCRptFechaMod(new Date());
                ctlRptGenRepository.save(ent);
            });
        } catch (Exception e) {
            throw new IllegalStateException(
                    "No fue posible cambiar Cobranza a EN_PROCESO.", e);
        }
    }

    static String claveSolicitud(
            int idSolTipo, String fecIni, String fecFin, int idVencida,
            List<Integer> idsPerfil, int idCorporativo,
            int idVigencia, int bandera) {
        List<Integer> perfiles = idsPerfil == null
                ? new ArrayList<>() : new ArrayList<>(idsPerfil);
        Collections.sort(perfiles);
        String datos = idSolTipo + "|" + String.valueOf(fecIni)
                + "|" + String.valueOf(fecFin) + "|" + idVencida
                + "|" + perfiles + "|" + idCorporativo
                + "|" + idVigencia + "|" + bandera;
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(datos.getBytes(StandardCharsets.UTF_8));
            StringBuilder hash = new StringBuilder("COBRANZA:");
            for (byte value : digest) {
                hash.append(String.format("%02x", value & 0xff));
            }
            return hash.toString();
        } catch (Exception e) {
            throw new IllegalStateException(
                    "No fue posible identificar la solicitud de Cobranza.", e);
        }
    }

    private void actualizarSeguimiento(Long id, EstatusReporte estatus, String obs, String ruta) {
        if (id == null || id == 0) return;
        try {
            ctlRptGenRepository.findById(id).ifPresent(ent -> {
                ent.setCRptFechaGeneracion(new Date());
                ent.setCRptIdEstatus(estatus.getNumVal());
                ent.setCRptObservaciones(obs != null && obs.length() > 500 ? obs.substring(0, 500) : obs);
                if (ruta != null && !ruta.isEmpty()) ent.setCRptRuta(ruta);
                ctlRptGenRepository.save(ent);
            });
        } catch (Exception e) {
            LOGGER.warn("No se pudo actualizar seguimiento: " + e.getMessage());
        }
    }

    private void actualizarSeguimientoPorResultado(
            Long rptId, List<Object> result, String ruta) {
        if (esRespuestaError(result)) {
            actualizarSeguimiento(rptId,
                    esRespuestaSinDatos(result)
                            ? EstatusReporte.SIN_DATOS : EstatusReporte.ERROR,
                    mensajeRespuesta(result), "");
        } else if (ruta == null || ruta.isEmpty()) {
            actualizarSeguimiento(rptId, EstatusReporte.ERROR,
                    "El reporte termino sin devolver la ruta del archivo.", "");
        } else {
            actualizarSeguimiento(rptId, EstatusReporte.DISPONIBLE, "", ruta);
        }
    }

    static boolean esRespuestaError(List<Object> result) {
        return result != null && !result.isEmpty()
                && result.get(0) instanceof Map
                && Boolean.TRUE.equals(
                        ((Map<?, ?>) result.get(0)).get("error"));
    }

    static boolean esRespuestaSinDatos(List<Object> result) {
        if (!esRespuestaError(result)) return false;
        Map<?, ?> error = (Map<?, ?>) result.get(0);
        if (Boolean.TRUE.equals(error.get("sinDatos"))) return true;
        String mensaje = String.valueOf(error.get("mssError"));
        return mensaje.toLowerCase(java.util.Locale.ROOT)
                .contains("no se encontraron coincidencias");
    }

    static boolean esConsultaListaArchivos(
            int idSolTipo, String fecIni, String fecFin, int idVencida,
            List<Integer> idsPerfil, String empresa, String nomCorp,
            String nomAdm, String nomEmp, String email) {
        return idSolTipo == -1
                && "null".equalsIgnoreCase(String.valueOf(fecIni))
                && "null".equalsIgnoreCase(String.valueOf(fecFin))
                && idVencida == -1
                && (idsPerfil == null || idsPerfil.isEmpty())
                && "null".equalsIgnoreCase(String.valueOf(empresa))
                && "null".equalsIgnoreCase(String.valueOf(nomCorp))
                && "null".equalsIgnoreCase(String.valueOf(nomAdm))
                && "null".equalsIgnoreCase(String.valueOf(nomEmp))
                && "null".equalsIgnoreCase(String.valueOf(email));
    }

    static boolean esNombreArchivoGenerado(Object value) {
        if (!(value instanceof String)) return false;
        String nombre = ((String) value).trim();
        return !nombre.isEmpty()
                && !"empty".equalsIgnoreCase(nombre)
                && !"null".equalsIgnoreCase(nombre)
                && !"undefined".equalsIgnoreCase(nombre);
    }

    static String nombreArchivoRespuesta(List<Object> result) {
        if (result == null || result.isEmpty()) return "Cobranza";
        Object first = result.get(0);
        if (esNombreArchivoGenerado(first)) return String.valueOf(first).trim();
        if (first instanceof List) {
            List<?> inner = (List<?>) first;
            if (!inner.isEmpty() && esNombreArchivoGenerado(inner.get(0))) {
                return String.valueOf(inner.get(0)).trim();
            }
        }
        return "Cobranza";
    }

    void notificarResultado(
            int idUsuario, int idEmpresa, String nomAdm, String nomEmp,
            String email, List<Object> result, String ruta,
            String error, String token) {
        if (email == null || email.trim().isEmpty()
                || "null".equalsIgnoreCase(email.trim())) {
            LOGGER.warn("No se envio notificacion de Cobranza: correo vacio.");
            return;
        }
        try {
            String asunto = valorConfiguracion(
                    "asunto_correo", "Notificacion de reporte - {0}");
            String plantilla = valorConfiguracion(
                    "cuerpo_correo", "Reporte {2} para {3}. Resultado: {0} generado. {5}");
            boolean generado = !esRespuestaError(result)
                    && ruta != null && !ruta.trim().isEmpty()
                    && (error == null || error.trim().isEmpty());
            String mensaje = error == null ? "" : error;
            correoServ.EnviarCorreo(
                    idUsuario, idEmpresa, nomAdm, nomEmp, email,
                    generado, NOMBRE_REPORTE_COBRANZA, plantilla,
                    asunto, mensaje, token,
                    CatTipoNotificacionReporte.resolverIdTipoNotificacion(
                            REPORTE_ID_COBRANZA));
            debug("cobranza_notificacion_solicitada",
                    "idEmpresa=" + idEmpresa + " generado=" + generado);
        } catch (Exception e) {
            // El correo no debe cambiar a ERROR un archivo ya generado.
            LOGGER.error("No se pudo solicitar la notificacion de Cobranza: "
                    + e.getMessage(), e);
        }
    }

    private String valorConfiguracion(String clave, String valorPredeterminado) {
        List<ConfiguracionReporteGen> configuraciones =
                cfgRptGenRepository.findByCfgRptClave(clave);
        if (configuraciones == null || configuraciones.isEmpty()
                || configuraciones.get(0) == null
                || configuraciones.get(0).getCfgRptValor() == null
                || configuraciones.get(0).getCfgRptValor().trim().isEmpty()) {
            return valorPredeterminado;
        }
        return configuraciones.get(0).getCfgRptValor();
    }

    private static String mensajeRespuesta(List<Object> result) {
        if (!esRespuestaError(result)) return "Error desconocido";
        Object mensaje = ((Map<?, ?>) result.get(0)).get("mssError");
        return mensaje == null ? "Error desconocido" : String.valueOf(mensaje);
    }

    /** Extracts the full file path from the List<Object> returned by consultaCobranza. */
    @SuppressWarnings("unchecked")
    private String extraerRuta(List<Object> result, int idEmpresa) {
        try {
            if (result == null || result.isEmpty()) return "";
            Object first = result.get(0);
            if (esNombreArchivoGenerado(first)) {
                return rutaBase + idEmpresa + "/Cobranza/"
                        + ((String) first).trim();
            }
            // result may be a List<String> wrapped in an outer list
            if (first instanceof List) {
                List<?> inner = (List<?>) first;
                if (!inner.isEmpty()
                        && esNombreArchivoGenerado(inner.get(0))) {
                    return rutaBase + idEmpresa + "/Cobranza/"
                            + ((String) inner.get(0)).trim();
                }
            }
            // result may be a Map with error key – not a file
            if (first instanceof Map) {
                Map<?, ?> m = (Map<?, ?>) first;
                if (Boolean.TRUE.equals(m.get("error"))) return "";
            }
        } catch (Exception ignore) {}
        return "";
    }
}
