package com.lockton.rpt.util;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Mantiene el Log.txt operativo junto a los reportes, como en BF2.
 * Un fallo de bitacora nunca debe impedir la generacion del Excel.
 */
public final class ReporteProcesoLog {

    public static final String NOMBRE_ARCHIVO = "Log.txt";

    private static final Log LOGGER =
            LogFactory.getLog(ReporteProcesoLog.class);
    private static final DateTimeFormatter FECHA =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    private static final ConcurrentMap<Path, Object> BLOQUEOS =
            new ConcurrentHashMap<>();

    private ReporteProcesoLog() {
    }

    public static void escribir(File directorio, String contenido) {
        if (directorio == null || contenido == null) {
            return;
        }

        String destino = directorio.getAbsolutePath();
        try {
            Path rutaDirectorio = directorio.toPath().toAbsolutePath().normalize();
            Path archivo = rutaDirectorio.resolve(NOMBRE_ARCHIVO);
            destino = archivo.toString();
            Object bloqueo = BLOQUEOS.computeIfAbsent(
                    archivo, key -> new Object());

            synchronized (bloqueo) {
                Files.createDirectories(rutaDirectorio);
                String linea = contenido + " (" + FECHA.format(LocalDateTime.now())
                        + ")" + System.lineSeparator();
                Files.write(archivo, linea.getBytes(StandardCharsets.UTF_8),
                        StandardOpenOption.CREATE,
                        StandardOpenOption.WRITE,
                        StandardOpenOption.APPEND);
            }
        } catch (IOException | RuntimeException ex) {
            LOGGER.warn("No fue posible actualizar " + destino + ": "
                    + ex.getMessage());
        }
    }
}
