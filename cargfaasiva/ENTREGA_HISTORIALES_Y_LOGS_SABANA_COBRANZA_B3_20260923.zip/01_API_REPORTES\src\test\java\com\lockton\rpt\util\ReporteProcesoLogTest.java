package com.lockton.rpt.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ReporteProcesoLogTest {

    @TempDir
    Path temporal;

    @Test
    void creaYAnexaElLogSinReemplazarEntradasPrevias() throws Exception {
        Path directorio = temporal.resolve("2185").resolve("Sabana");

        ReporteProcesoLog.escribir(directorio.toFile(), "Inicia Sabana");
        ReporteProcesoLog.escribir(directorio.toFile(), "Finaliza Sabana");

        Path log = directorio.resolve(ReporteProcesoLog.NOMBRE_ARCHIVO);
        List<String> lineas = Files.readAllLines(log, StandardCharsets.UTF_8);

        assertEquals(2, lineas.size());
        assertTrue(lineas.get(0).startsWith("Inicia Sabana ("));
        assertTrue(lineas.get(1).startsWith("Finaliza Sabana ("));
    }

    @Test
    void mantieneUnLogIndependientePorFuncionalidad() throws Exception {
        Path sabana = temporal.resolve("2185").resolve("Sabana");
        Path cobranza = temporal.resolve("2185").resolve("Cobranza");

        ReporteProcesoLog.escribir(sabana.toFile(), "Evento Sabana");
        ReporteProcesoLog.escribir(cobranza.toFile(), "Evento Cobranza");

        String logSabana = Files.readString(
                sabana.resolve("Log.txt"), StandardCharsets.UTF_8);
        String logCobranza = Files.readString(
                cobranza.resolve("Log.txt"), StandardCharsets.UTF_8);

        assertTrue(logSabana.contains("Evento Sabana"));
        assertTrue(logCobranza.contains("Evento Cobranza"));
        assertTrue(!logSabana.contains("Evento Cobranza"));
        assertTrue(!logCobranza.contains("Evento Sabana"));
    }
}
