package com.lockton.rpt.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.crypt.EncryptionMode;
import org.apache.poi.poifs.crypt.Encryptor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.SheetUtil;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

import com.lockton.rpt.util.Excel_Columna_Multiple;
import com.lockton.rpt.util.ReportePathUtil;
import com.lockton.rpt.util.ReporteProcesoLog;

@Repository
public class JDBCCobranza {

    private static final Log LOGGER = LogFactory.getLog(JDBCCobranza.class);

    // Columnas que identifican una fila Ăşnicamente en cada tabla de cache
    private static final Map<String, String[]> CACHE_KEY_COLS;
    static {
        Map<String, String[]> m = new HashMap<>();
        m.put("bf_CobranzaCache_Concentrada",     new String[]{"NumEMpleado"});
        m.put("bf_CobranzaCache_Desglosada",       new String[]{"NUMEMPLEADO", "CVEP", "CVEPO", "CVEParentesco"});
        m.put("bf_CobranzaCache_TotCoberturas",    new String[]{"CVEP", "CVEPO"});
        m.put("bf_CobranzaCache_TotCoberturasP",   new String[]{"CVEP", "CVEPO", "CVEParentesco"});
        m.put("bf_CobranzaCache_PlanesParentesco", new String[]{"cvep", "cvepo"});
        CACHE_KEY_COLS = java.util.Collections.unmodifiableMap(m);
    }

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private void debug(String etapa, String detalle) {
        LOGGER.info("COBRANZA-DEBUG " + etapa + " " + detalle);
    }

    // ─── Main cobranza generation ─────────────────────────────────────────────

    public List<Object> consultaCobranza(
            int idEmpresa, int idSolTipo, String FecIni, String FecFin, int idVencida,
            List<Integer> IdsPerfil, String empresa, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email,
            int idVigencia, int bandera, String rutaBase) {

        String pathLog;
        try {
            pathLog = ReportePathUtil.directorioCobranza(
                    rutaBase, idEmpresa).getAbsolutePath();
        } catch (RuntimeException e) {
            return buildError(e.getMessage());
        }
        Date today = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String fechaIniProceso = formatoFecha.format(today);
        File directorioLog = new File(pathLog);

        try {
            // Lista de archivos existentes cuando se llama sin params reales
            if (idSolTipo == -1 && "null".equals(FecIni) && "null".equals(FecFin)
                    && idVencida == -1 && IdsPerfil.isEmpty() && "null".equals(empresa)
                    && "null".equals(nomCorp) && "null".equals(nomAdm)
                    && "null".equals(nomEmp) && "null".equals(email)) {
                return getListArchivosVigenciaActivaRenovada(idEmpresa, idVigencia);
            }

            ReporteProcesoLog.escribir(directorioLog,
                    "Inicia cobranza");

            if ("null".equals(FecIni)) {
                FecIni = getFechaInicioVigencia(idVigencia);
                ReporteProcesoLog.escribir(directorioLog,
                        "La fecha inicial se obtiene de la vigencia activa: "
                                + FecIni);
            }
            if ("null".equals(FecFin)) {
                FecFin = getFechaFinalVigencia(idVigencia);
                ReporteProcesoLog.escribir(directorioLog,
                        "La fecha final se obtiene de la vigencia activa: "
                                + FecFin);
            }

            ReporteProcesoLog.escribir(directorioLog,
                    "Se invoca el proceso de Cobranza con los parametros "
                            + "(idEmpresa=" + idEmpresa
                            + ", idVigencia=" + idVigencia
                            + ", fechaIni=" + FecIni
                            + ", fechaFin=" + FecFin + ")");

            debug("cobranza_jdbc_sp_inicio",
                "idEmpresa=" + idEmpresa + " idVigencia=" + idVigencia
                + " FecIni=" + FecIni + " FecFin=" + FecFin
                + " bandera=" + bandera + " perfiles=" + IdsPerfil);

            boolean usarCache = isCobranzaCacheEnabled(idEmpresa);
            debug("cobranza_ruta_datos", "idEmpresa=" + idEmpresa
                    + " ruta=" + (usarCache ? "CACHE_V2" : "LEGACY"));

            Map<String, Object> spResult = ejecutarCobranzaConFallback(
                    usarCache, idEmpresa, idSolTipo, FecIni, FecFin,
                    idVencida, IdsPerfil, idVigencia);
            int spResultValues = spResult.size();

            ArrayList<ArrayList<LinkedCaseInsensitiveMap>> listaSP =
                    extraerResultsets(spResult);
            // SimpleJdbcCall conserva los resultsets completos en su Map. La
            // extraccion ya tiene las filas necesarias, por lo que se libera el
            // contenedor original antes de construir el Excel.
            spResult.clear();
            ArrayList<ArrayList<LinkedCaseInsensitiveMap>> lista =
                    normalizarContratoCobranza(listaSP);
            listaSP.clear();

            debug("cobranza_jdbc_sp_resultado",
                "tablas=" + lista.size()
                + " filas=" + lista.stream().mapToInt(List::size).sum()
                + " spResultKeys=" + spResult.keySet().toString());
            ReporteProcesoLog.escribir(directorioLog,
                    "Termina la consulta de datos con " + lista.size()
                            + " tablas y "
                            + lista.stream().mapToInt(List::size).sum()
                            + " filas");

            // Los datos reales pueden contener incluso un solo empleado, por
            // lo que no se debe exigir mas de una fila por resultset.
            boolean hayDatos = lista.stream().anyMatch(
                    t -> !t.isEmpty()
                    && t.stream().anyMatch(row -> !esFilaTotal(row)));
            if (!hayDatos) {
                debug("cobranza_jdbc_sin_datos", "spResultValues=" + spResultValues + " tablas=" + lista.size());
                ReporteProcesoLog.escribir(directorioLog,
                        "Finaliza Cobranza sin datos para los filtros seleccionados");
                return buildSinDatos("No se encontraron coincidencias para los rangos o filtros seleccionados.");
            }

            debug("cobranza_jdbc_excel_inicio", "tablas_con_datos=" + lista.size() + " rutaBase=" + rutaBase);
            ReporteProcesoLog.escribir(directorioLog,
                    "Inicia la generacion del Excel de Cobranza");
            List<Object> excelResult = generarExcel(lista, empresa, idEmpresa, rutaBase, FecIni, FecFin,
                    idCorporativo, nomCorp, nomAdm, nomEmp, email, fechaIniProceso, idVigencia, bandera);
            boolean excelError = !excelResult.isEmpty() && excelResult.get(0) instanceof Map
                    && Boolean.TRUE.equals(((Map<?, ?>) excelResult.get(0)).get("error"));
            if (excelError) {
                Object msg = ((Map<?, ?>) excelResult.get(0)).get("mssError");
                debug("cobranza_jdbc_excel_error", String.valueOf(msg));
                ReporteProcesoLog.escribir(directorioLog,
                        "Error al generar Cobranza: " + String.valueOf(msg));
            } else {
                debug("cobranza_jdbc_excel_ok", "archivos=" + excelResult.size());
                ReporteProcesoLog.escribir(directorioLog,
                        "Finaliza la cobranza");
            }
            return excelResult;

        } catch (Exception e) {
            LOGGER.error("Error en consultaCobranza: " + e.getMessage(), e);
            debug("cobranza_jdbc_excepcion", e.getClass().getSimpleName() + ": " + e.getMessage());
            ReporteProcesoLog.escribir(directorioLog,
                    "Error al generar Cobranza: " + e.getClass().getSimpleName()
                            + ": " + e.getMessage());
            return buildError(e.getMessage());
        }
    }

    /**
     * SimpleJdbcCall normalmente devuelve ArrayList, pero ese tipo concreto no
     * forma parte de su contrato. Se acepta cualquier List y cualquier Map para
     * que una diferencia de version del driver/Spring no convierta resultsets
     * validos en una respuesta falsa de "Sin datos".
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    static ArrayList<ArrayList<LinkedCaseInsensitiveMap>> extraerResultsets(
            Map<String, Object> resultado) {
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                new ArrayList<>();
        if (resultado == null) return resultsets;

        for (Object value : resultado.values()) {
            if (!(value instanceof List)) continue;
            List<?> rows = (List<?>) value;
            if (rows.isEmpty()) continue;

            ArrayList<LinkedCaseInsensitiveMap> convertido = new ArrayList<>();
            boolean valido = true;
            for (Object rowObject : rows) {
                if (!(rowObject instanceof Map)) {
                    valido = false;
                    break;
                }
                if (rowObject instanceof LinkedCaseInsensitiveMap) {
                    convertido.add((LinkedCaseInsensitiveMap) rowObject);
                } else {
                    LinkedCaseInsensitiveMap row =
                            new LinkedCaseInsensitiveMap();
                    row.putAll((Map) rowObject);
                    convertido.add(row);
                }
            }
            if (valido && !convertido.isEmpty()) resultsets.add(convertido);
        }
        return resultsets;
    }

    // ─── Excel generation ─────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    public List<Object> generarExcel(
            ArrayList<ArrayList<LinkedCaseInsensitiveMap>> lista, String empresa, int idEmpresa,
            String rutaBase, String FecIni, String FecFin, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email,
            String fechaIniProc, int idVigencia, int bandera) {
        // Cache y consulta directa deben producir el mismo libro. El cache
        // agrega metadatos de enrutamiento que no pertenecen al contrato de
        // negocio; se eliminan antes de usar el renderizador homologado.
        lista = normalizarContratoCobranza(lista);

        SXSSFWorkbook libro = null;
        try {
            Date today = new Date();
            // Incluir milisegundos evita reutilizar/sobrescribir el archivo de
            // otra solicitud hecha dentro del mismo minuto.
            String strFecha = new SimpleDateFormat("yyyyMMddHHmmssSSS")
                    .format(today);
            String nomArch = "Cobranza" + strFecha + ".xlsx";

            libro = new SXSSFWorkbook(100);
            libro.setCompressTempFiles(true);
            getHojaInfo(libro, idEmpresa, empresa, FecIni, FecFin, idVigencia);
            Map<String, Map<String, String>> colConfig  = loadCobranzaColumnConfig(idEmpresa);
            Map<String, Map<String, Object>> tablaConfig = loadCobranzaTablaConfig(idEmpresa);

            // ── Styles ──────────────────────────────────────────────────────
            CellStyle styleCabezera  = libro.createCellStyle();
            CellStyle styleContenido = libro.createCellStyle();
            CellStyle styleDinero    = libro.createCellStyle();
            CellStyle styleFecha     = libro.createCellStyle();
            CellStyle styleEntero    = libro.createCellStyle();
            CellStyle styleTexto     = libro.createCellStyle();

            Font fontCab = libro.createFont();
            fontCab.setFontName("Calibri");
            fontCab.setBold(true);
            fontCab.setColor(IndexedColors.WHITE.getIndex());
            fontCab.setFontHeightInPoints((short) 11);
            styleCabezera.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            styleCabezera.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.index);
            styleCabezera.setFont(fontCab);
            styleCabezera.setVerticalAlignment(VerticalAlignment.CENTER);
            styleCabezera.setAlignment(HorizontalAlignment.CENTER);

            Font fontCont = libro.createFont();
            fontCont.setFontName("Calibri");
            fontCont.setColor(IndexedColors.BLACK.getIndex());
            fontCont.setFontHeightInPoints((short) 11);
            styleContenido.setFont(fontCont);
            styleContenido.setVerticalAlignment(VerticalAlignment.CENTER);
            styleContenido.setAlignment(HorizontalAlignment.LEFT);

            Font fontDin = libro.createFont();
            fontDin.setFontName("Calibri");
            fontDin.setColor(IndexedColors.BLACK.getIndex());
            fontDin.setFontHeightInPoints((short) 11);
            styleDinero.setFont(fontDin);
            styleDinero.setVerticalAlignment(VerticalAlignment.CENTER);
            styleDinero.setAlignment(HorizontalAlignment.LEFT);
            styleDinero.setDataFormat((short) 8);

            CellStyle estiloMoneda = libro.createCellStyle();
            DataFormat formato = libro.createDataFormat();
            estiloMoneda.setDataFormat(formato.getFormat("\"$\"#,##0.00"));

            CreationHelper createHelper = libro.getCreationHelper();
            styleFecha.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy"));
            styleFecha.setAlignment(HorizontalAlignment.RIGHT);
            styleEntero.setDataFormat(createHelper.createDataFormat().getFormat("0"));
            styleEntero.setAlignment(HorizontalAlignment.RIGHT);
            styleTexto.setDataFormat(createHelper.createDataFormat().getFormat("@"));

            // ── Banwire conditional sheets (bandera==1) ──────────────────────
            if (bandera == 1) {
                List<Object> datosTransaccion  = new ArrayList<>();
                List<Object> datosLiquidacion  = new ArrayList<>();
                List<Object> datosDispersion   = new ArrayList<>();

                for (ArrayList<LinkedCaseInsensitiveMap> fila : lista) {
                    for (LinkedCaseInsensitiveMap mapa : fila) {
                        if (tieneValor(mapa, "ProveedorTransaccion")) {
                            datosTransaccion.add(mapearTransacciones(mapa));
                        }
                        if (tieneValor(mapa, "ProveedorLiquidacion")) {
                            datosLiquidacion.add(mapearLiquidaciones(mapa));
                        }
                        if (tieneValor(mapa, "ProveedorDispersion")) {
                            datosDispersion.add(mapearDispersiones(mapa));
                        }
                    }
                }
                hojas_transacciones(libro, estiloMoneda, styleCabezera, filtrarPorClave("ProveedorTransaccion", datosTransaccion));
                hojas_liquidaciones(libro, estiloMoneda, styleCabezera, filtrarPorClave("ProveedorLiquidacion", datosLiquidacion));
                hojas_dispersion(libro, estiloMoneda, styleCabezera, filtrarPorClave("ProveedorDispersion", datosDispersion));
                datosTransaccion.clear();
                datosLiquidacion.clear();
                datosDispersion.clear();
            }

            // ── Main 4 sheets ────────────────────────────────────────────────
            // Hojas activas según bf_RepConf_Tabla (activo=0 excluye la hoja del Excel)
            Sheet hojaConcentrada        = sheetActiva(tablaConfig, "Concentrada")         ? libro.createSheet(sheetNombre(tablaConfig, "Concentrada"))         : null;
            Sheet hojaDesglosada         = sheetActiva(tablaConfig, "Desglosada")          ? libro.createSheet(sheetNombre(tablaConfig, "Desglosada"))          : null;
            Sheet hojaTotalPorCoberturas = sheetActiva(tablaConfig, "Total por coberturas") ? libro.createSheet(sheetNombre(tablaConfig, "Total por coberturas")) : null;
            Sheet hojaPlanesParentesco   = sheetActiva(tablaConfig, "Planes_Parentesco")   ? libro.createSheet(sheetNombre(tablaConfig, "Planes_Parentesco"))   : null;

            int ic = 0, id = 0, it = 0, ip = 0, iex = 1;
            int sizePartition = 100;

            for (ArrayList<LinkedCaseInsensitiveMap> arrayList : lista) {
                Set<String> setKeys = arrayList.get(0).keySet();
                ArrayList<String> keys = new ArrayList<>(setKeys);
                String key = keys.isEmpty() ? null : keys.get(0);

                if (key == null) {
                    Sheet hojaExtra = libro.createSheet("Hoja " + (iex++));
                    setHoja(arrayList, hojaExtra, 0, styleCabezera, styleContenido,
                            styleDinero, styleFecha, styleEntero, styleTexto, "", true, bandera, colConfig);
                } else {
                    switch (key) {
                        case "empresa": case "NumEMpleado":
                            if (hojaConcentrada != null) {
                                if (arrayList.size() > sizePartition) {
                                    boolean salto = true;
                                    for (List<LinkedCaseInsensitiveMap> part : partition(arrayList, sizePartition)) {
                                        ic = setHoja(part, hojaConcentrada, ic, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Concentrada", salto, bandera, colConfig);
                                        salto = false;
                                    }
                                } else {
                                    ic = setHoja(arrayList, hojaConcentrada, ic, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Concentrada", true, bandera, colConfig);
                                }
                            }
                            break;
                        case "EMPRESA": case "NUMEMPLEADO":
                            if (hojaDesglosada != null) {
                                if (arrayList.size() > sizePartition) {
                                    boolean salto = true;
                                    for (List<LinkedCaseInsensitiveMap> part : partition(arrayList, sizePartition)) {
                                        id = setHoja(part, hojaDesglosada, id, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Desglosada", salto, bandera, colConfig);
                                        salto = false;
                                    }
                                } else {
                                    id = setHoja(arrayList, hojaDesglosada, id, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Desglosada", true, bandera, colConfig);
                                }
                            }
                            break;
                        case "CVEP": case "CVEPO":
                            if (hojaTotalPorCoberturas != null) {
                                if (arrayList.size() > sizePartition) {
                                    boolean salto = true;
                                    for (List<LinkedCaseInsensitiveMap> part : partition(arrayList, sizePartition)) {
                                        it = setHoja(part, hojaTotalPorCoberturas, it, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Total por coberturas", salto, bandera, colConfig);
                                        salto = false;
                                    }
                                } else {
                                    it = setHoja(arrayList, hojaTotalPorCoberturas, it, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Total por coberturas", true, bandera, colConfig);
                                }
                            }
                            break;
                        case "cvep": case "cvepo":
                            if (hojaPlanesParentesco != null) {
                                if (arrayList.size() > sizePartition) {
                                    boolean salto = true;
                                    for (List<LinkedCaseInsensitiveMap> part : partition(arrayList, sizePartition)) {
                                        ip = setHoja(part, hojaPlanesParentesco, ip, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Planes_Parentesco", salto, bandera, colConfig);
                                        salto = false;
                                    }
                                } else {
                                    ip = setHoja(arrayList, hojaPlanesParentesco, ip, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Planes_Parentesco", true, bandera, colConfig);
                                }
                            }
                            break;
                    default:
                        break;
                }
                }
                // SXSSF ya escribio estas filas en archivos temporales; no es
                // necesario conservar los mapas mientras se procesa otra hoja.
                arrayList.clear();
            }

            // ── Save file ────────────────────────────────────────────────────
            File dir = ReportePathUtil.directorioCobranza(
                    rutaBase, idEmpresa);
            File file = ReportePathUtil.archivoCobranza(
                    rutaBase, idEmpresa, nomArch);
            if (!dir.exists() && !dir.mkdirs()) {
                throw new IOException(
                        "No se pudo crear el directorio de Cobranza: "
                        + dir.getAbsolutePath());
            }
            String cPassword = getPasswordCobranza(idEmpresa).trim();
            guardarWorkbookSeguro(libro, file, cPassword);

            insertArchivoCobranza(idEmpresa, FecIni, FecFin, idVigencia, nomArch, today);
            return archivoGenerado(nomArch);

        } catch (Exception e) {
            LOGGER.error("Error al guardar Excel de cobranza: " + e.getMessage(), e);
            return buildError(e.getMessage());
        } finally {
            if (libro != null) {
                try { libro.close(); } catch (Exception ignored) {}
                try { libro.dispose(); } catch (Exception ignored) {}
            }
        }
    }

    /**
     * Una fila activa de empresa tiene prioridad sobre la global. Si no existe
     * ninguna configuracion activa o su valor no es 1, se usa el flujo legacy.
     */
    boolean isCobranzaCacheEnabled(int idEmpresa) {
        try {
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                    "SELECT TOP (1) LTRIM(RTRIM(paValor)) AS paValor "
                  + "FROM dbo.ff_Parametro "
                  + "WHERE UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE' "
                  + "  AND paIdEmpresa IN (?,0) "
                  + "  AND paidEstatus=1 "
                  + "ORDER BY CASE WHEN paIdEmpresa=? THEN 0 ELSE 1 END, paId DESC",
                    idEmpresa, idEmpresa);
            if (rows.isEmpty()) return false;
            Object value = rows.get(0).get("paValor");
            return value != null && "1".equals(String.valueOf(value).trim());
        } catch (Exception e) {
            LOGGER.warn("No se pudo leer COBRANZA_CACHE para empresa "
                    + idEmpresa + "; se usara el flujo legacy: " + e.getMessage());
            return false;
        }
    }

    /**
     * El cache es una optimizacion, no una fuente exclusiva. Los parametros de
     * fecha y perfil participan en los calculos del SP, por lo que no es seguro
     * filtrar al final una carga universal. Si la combinacion exacta falla o no
     * devuelve datos reales, se repite la consulta por el procedimiento legacy.
     */
    Map<String, Object> ejecutarCobranzaConFallback(
            boolean usarCache, int idEmpresa, int idSolTipo,
            String fecIni, String fecFin, int idVencida,
            List<Integer> idsPerfil, int idVigencia) {
        if (!usarCache) {
            return ejecutarCobranzaLegacy(idEmpresa, idSolTipo, fecIni, fecFin,
                    idVencida, idsPerfil, idVigencia);
        }

        try {
            Map<String, Object> cache = ejecutarCobranzaCache(
                    idEmpresa, idSolTipo, fecIni, fecFin,
                    idVencida, idsPerfil, idVigencia);
            if (contieneDatosReales(cache)) return cache;

            LOGGER.warn("Cobranza cache sin datos; se usara legacy para empresa "
                    + idEmpresa + " vigencia " + idVigencia);
            debug("cobranza_cache_fallback",
                    "motivo=SIN_DATOS idEmpresa=" + idEmpresa
                    + " idVigencia=" + idVigencia);
        } catch (Exception e) {
            LOGGER.warn("Cobranza cache fallo; se usara legacy para empresa "
                    + idEmpresa + " vigencia " + idVigencia + ": "
                    + e.getMessage());
            debug("cobranza_cache_fallback",
                    "motivo=ERROR idEmpresa=" + idEmpresa
                    + " idVigencia=" + idVigencia + " error=" + e.getMessage());
        }

        return ejecutarCobranzaLegacy(idEmpresa, idSolTipo, fecIni, fecFin,
                idVencida, idsPerfil, idVigencia);
    }

    static boolean contieneDatosReales(Map<String, Object> result) {
        if (result == null || result.isEmpty()) return false;
        for (Object value : result.values()) {
            if (!(value instanceof List) || ((List<?>) value).isEmpty()) continue;
            List<?> rows = (List<?>) value;
            Object first = rows.get(0);
            if (!(first instanceof Map)) continue;
            Object grupo = ((Map<?, ?>) first).get("grupo");
            if (grupo != null && "informacion".equals(
                    normalizeConfigKey(String.valueOf(grupo)))) continue;
            for (Object row : rows) {
                if (row instanceof Map && !esFilaTotal((Map<?, ?>) row)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean esFilaTotal(Map<?, ?> row) {
        Object numero = row.get("NumEMpleado");
        if (numero == null) numero = row.get("NUMEMPLEADO");
        if (numero == null) return false;
        return normalizeConfigKey(String.valueOf(numero)).startsWith("total");
    }

    Map<String, Object> ejecutarCobranzaCache(
            int idEmpresa, int idSolTipo, String fecIni, String fecFin,
            int idVencida, List<Integer> idsPerfil, int idVigencia) {
        SimpleJdbcCall spCall = new SimpleJdbcCall(jdbcTemplate)
                .withoutProcedureColumnMetaDataAccess()
                .withProcedureName("ReporteCobranzaConcentrada_BF3_Cache")
                .declareParameters(
                    new SqlParameter("idEmpresa",  java.sql.Types.INTEGER),
                    new SqlParameter("idSolTipo",  java.sql.Types.INTEGER),
                    new SqlParameter("FecIni",     java.sql.Types.VARCHAR),
                    new SqlParameter("FecFin",     java.sql.Types.VARCHAR),
                    new SqlParameter("idVencida",  java.sql.Types.INTEGER),
                    new SqlParameter("IdPerfil",   microsoft.sql.Types.STRUCTURED, "dbo.ListInt"),
                    new SqlParameter("idVIgencia", java.sql.Types.INTEGER)
                );
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("idEmpresa",  idEmpresa);
        params.addValue("idSolTipo",  idSolTipo);
        params.addValue("FecIni",     fecIni);
        params.addValue("FecFin",     fecFin);
        params.addValue("idVencida",  idVencida);
        params.addValue("IdPerfil",   buildPerfilTVP(idsPerfil));
        params.addValue("idVIgencia", idVigencia);
        return spCall.execute(params);
    }

    Map<String, Object> ejecutarCobranzaLegacy(
            int idEmpresa, int idSolTipo, String fecIni, String fecFin,
            int idVencida, List<Integer> idsPerfil, int idVigencia) {
        SimpleJdbcCall spCall = new SimpleJdbcCall(jdbcTemplate)
                .withoutProcedureColumnMetaDataAccess()
                .withProcedureName("ObtenCobranzaConcentrada_otro_V2_BF3")
                .declareParameters(
                    new SqlParameter("idEmpresa",  java.sql.Types.INTEGER),
                    new SqlParameter("idSolTipo",  java.sql.Types.INTEGER),
                    new SqlParameter("FecIni",     java.sql.Types.VARCHAR),
                    new SqlParameter("FecFin",     java.sql.Types.VARCHAR),
                    new SqlParameter("idVencida",  java.sql.Types.INTEGER),
                    new SqlParameter("IdPerfil",   microsoft.sql.Types.STRUCTURED, "dbo.ListInt"),
                    new SqlParameter("idVIgencia", java.sql.Types.INTEGER)
                );
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("idEmpresa",  idEmpresa);
        params.addValue("idSolTipo",  idSolTipo);
        params.addValue("FecIni",     fecIni);
        params.addValue("FecFin",     fecFin);
        params.addValue("idVencida",  idVencida);
        params.addValue("IdPerfil",   buildPerfilTVP(idsPerfil));
        params.addValue("idVIgencia", idVigencia);
        return spCall.execute(params);
    }

    /**
     * Convierte la salida del cache al mismo contrato que entrega la consulta
     * directa. La hoja Informacion se genera en Java para ambos caminos y las
     * columnas NombrePestana/grupo solo son metadatos del motor configurable.
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    static ArrayList<ArrayList<LinkedCaseInsensitiveMap>> normalizarContratoCobranza(
            ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets) {
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> normalizados = new ArrayList<>();
        if (resultsets == null) return normalizados;

        for (ArrayList<LinkedCaseInsensitiveMap> resultset : resultsets) {
            if (resultset == null || resultset.isEmpty()
                    || esResultsetInformacion(resultset)) continue;

            boolean requiereLimpieza = false;
            for (LinkedCaseInsensitiveMap row : resultset) {
                if (row == null || row.isEmpty()) {
                    requiereLimpieza = true;
                    break;
                }
                for (Object keyObject : row.keySet()) {
                    String key = String.valueOf(keyObject);
                    if ("NombrePestana".equalsIgnoreCase(key)
                            || "grupo".equalsIgnoreCase(key)) {
                        requiereLimpieza = true;
                        break;
                    }
                }
                if (requiereLimpieza) break;
            }
            if (!requiereLimpieza) {
                ordenarFilasContrato(resultset);
                normalizados.add(resultset);
                continue;
            }

            ArrayList<LinkedCaseInsensitiveMap> filas = new ArrayList<>();
            for (LinkedCaseInsensitiveMap row : resultset) {
                if (row == null) continue;
                row.entrySet().removeIf(entryObject -> {
                    Map.Entry entry = (Map.Entry) entryObject;
                    String key = String.valueOf(entry.getKey());
                    return "NombrePestana".equalsIgnoreCase(key)
                            || "grupo".equalsIgnoreCase(key);
                });
                if (!row.isEmpty()) filas.add(row);
            }
            if (!filas.isEmpty()) {
                ordenarFilasContrato(filas);
                normalizados.add(filas);
            }
        }
        return normalizados;
    }

    private static final String[] COBRANZA_SORT_KEYS = {
        "empresa", "NumEMpleado", "CveEmpl", "CVEP", "CVEPO",
        "ImpPer", "CVEParentesco", "POidSolicitud", "idemp",
        "PlanOpcion", "PlanD", "Concepto", "cvep", "cvepo"
    };

    @SuppressWarnings("rawtypes")
    private static void ordenarFilasContrato(
            ArrayList<LinkedCaseInsensitiveMap> filas) {
        if (ordenarResumenTipoPlanComoB2(filas)) return;

        filas.sort((izquierda, derecha) -> {
            boolean totalIzquierda = esFilaTotal(izquierda);
            boolean totalDerecha = esFilaTotal(derecha);
            if (totalIzquierda != totalDerecha) {
                return totalIzquierda ? 1 : -1;
            }
            for (String key : COBRANZA_SORT_KEYS) {
                int comparacion = compararValoresOrden(
                        izquierda.get(key), derecha.get(key));
                if (comparacion != 0) return comparacion;
            }
            java.util.Iterator itIzquierda = izquierda.values().iterator();
            java.util.Iterator itDerecha = derecha.values().iterator();
            while (itIzquierda.hasNext() && itDerecha.hasNext()) {
                int comparacion = compararValoresOrden(
                        itIzquierda.next(), itDerecha.next());
                if (comparacion != 0) return comparacion;
            }
            return Integer.compare(izquierda.size(), derecha.size());
        });
    }

    /**
     * El segundo resumen de "Total por coberturas" debe conservar el orden
     * historico de B2. Se limita al resultset de cuatro totales para no alterar
     * el orden natural de ningun otro bloque de Cobranza.
     */
    @SuppressWarnings("rawtypes")
    static boolean ordenarResumenTipoPlanComoB2(
            ArrayList<LinkedCaseInsensitiveMap> filas) {
        if (filas == null || filas.size() != 4) return false;

        boolean tieneGmm = false;
        boolean tieneOpcionales = false;
        boolean tieneVida = false;
        boolean tieneTotal = false;
        for (LinkedCaseInsensitiveMap fila : filas) {
            int orden = ordenResumenTipoPlan(fila.get("PlanD"));
            if (orden == Integer.MAX_VALUE) return false;
            tieneGmm |= orden == 0;
            tieneOpcionales |= orden == 1;
            tieneVida |= orden == 2;
            tieneTotal |= orden == 3;
        }
        if (!(tieneGmm && tieneOpcionales && tieneVida && tieneTotal)) {
            return false;
        }

        filas.sort((izquierda, derecha) -> Integer.compare(
                ordenResumenTipoPlan(izquierda.get("PlanD")),
                ordenResumenTipoPlan(derecha.get("PlanD"))));
        return true;
    }

    private static int ordenResumenTipoPlan(Object valor) {
        String plan = valor == null ? "" : String.valueOf(valor).trim();
        if ("Total GMM".equalsIgnoreCase(plan)) return 0;
        if ("Total Opcionales".equalsIgnoreCase(plan)) return 1;
        if ("Total Vida".equalsIgnoreCase(plan)) return 2;
        if ("TOTALES:".equalsIgnoreCase(plan)) return 3;
        return Integer.MAX_VALUE;
    }

    private static int compararValoresOrden(Object izquierda, Object derecha) {
        if (izquierda == derecha) return 0;
        if (izquierda == null) return -1;
        if (derecha == null) return 1;
        if (izquierda instanceof Number && derecha instanceof Number) {
            try {
                return new BigDecimal(String.valueOf(izquierda)).compareTo(
                        new BigDecimal(String.valueOf(derecha)));
            } catch (NumberFormatException ignored) {}
        }
        if (izquierda instanceof Date && derecha instanceof Date) {
            return ((Date) izquierda).compareTo((Date) derecha);
        }
        String textoIzquierda = String.valueOf(izquierda).trim();
        String textoDerecha = String.valueOf(derecha).trim();
        int comparacion = textoIzquierda.compareToIgnoreCase(textoDerecha);
        return comparacion != 0 ? comparacion
                : textoIzquierda.compareTo(textoDerecha);
    }

    /**
     * Genera el contrato V2 usando el mismo renderizador configurable del
     * motor de reportes. NombrePestana decide la hoja y grupo decide la
     * configuracion de tabla/columnas.
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private List<Object> generarExcelConfigurable(
            ArrayList<ArrayList<LinkedCaseInsensitiveMap>> lista,
            int idEmpresa,
            String rutaBase,
            String FecIni,
            String FecFin,
            int idVigencia) {
        SXSSFWorkbook libro = new SXSSFWorkbook(1000);
        libro.setCompressTempFiles(true);
        try {
            List<Map<String, Object>> reporteConfig =
                    loadCobranzaReporteConfig(idEmpresa);
            Map<String, Object> parametros = new LinkedHashMap<>();
            parametros.put("reporteId", 11);
            parametros.put("idEmpresa", idEmpresa);
            parametros.put("catReportesNombre", "Cobranza");
            parametros.put("preservarColumnasDinamicas", true);
            parametros.put("reporteConfig", reporteConfig);

            List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets =
                    new ArrayList<>();
            for (ArrayList<LinkedCaseInsensitiveMap> resultset : lista) {
                resultsets.add((ArrayList) resultset);
            }

            int hojas = Excel_Columna_Multiple.agregarHojas(
                    libro, resultsets, parametros);
            if (hojas == 0) {
                libro.close();
                libro.dispose();
                return buildError(
                        "La configuracion no contiene hojas activas con datos.");
            }

            Date today = new Date();
            String nomArch = "Cobranza"
                    + new SimpleDateFormat("yyyyMMddHHmmssSSS").format(today)
                    + ".xlsx";
            File dir = ReportePathUtil.directorioCobranza(
                    rutaBase, idEmpresa);
            File file = ReportePathUtil.archivoCobranza(
                    rutaBase, idEmpresa, nomArch);
            if (!dir.exists() && !dir.mkdirs()) {
                throw new IOException(
                        "No se pudo crear el directorio de Cobranza: "
                        + dir.getAbsolutePath());
            }

            String password = getPasswordCobranza(idEmpresa).trim();
            guardarWorkbookSeguro(libro, file, password);
            libro.close();
            libro.dispose();

            insertArchivoCobranza(
                    idEmpresa, FecIni, FecFin, idVigencia, nomArch, today);
            debug("cobranza_excel_configurable_ok",
                    "idEmpresa=" + idEmpresa + " hojas=" + hojas
                    + " gruposConfig=" + reporteConfig.size()
                    + " archivo=" + file.getAbsolutePath());
            return archivoGenerado(nomArch);
        } catch (Exception e) {
            try { libro.close(); } catch (Exception ignore) {}
            try { libro.dispose(); } catch (Exception ignore) {}
            LOGGER.error("Error al generar Excel configurable de cobranza: "
                    + e.getMessage(), e);
            debug("cobranza_excel_configurable_error",
                    e.getClass().getSimpleName() + ": " + e.getMessage());
            return buildError(e.getMessage());
        }
    }

    private boolean usaContratoConfigurable(
            ArrayList<ArrayList<LinkedCaseInsensitiveMap>> lista) {
        if (lista == null || lista.isEmpty()) return false;
        for (ArrayList<LinkedCaseInsensitiveMap> resultset : lista) {
            if (resultset == null || resultset.isEmpty()) continue;
            Map<?, ?> first = resultset.get(0);
            if (first.containsKey("NombrePestana")
                    && first.containsKey("grupo")) return true;
        }
        return false;
    }

    private static boolean esResultsetInformacion(
            ArrayList<LinkedCaseInsensitiveMap> resultset) {
        if (resultset == null || resultset.isEmpty()) return false;
        Object grupo = resultset.get(0).get("grupo");
        return grupo != null
                && "informacion".equals(normalizeConfigKey(
                        String.valueOf(grupo)));
    }

    /**
     * Resuelve la configuracion efectiva empresa -> global. Se incluyen las
     * filas inactivas para que una desactivacion especifica de empresa no sea
     * sustituida accidentalmente por la configuracion global activa.
     */
    private List<Map<String, Object>> loadCobranzaReporteConfig(
            int idEmpresa) {
        try {
            List<Map<String, Object>> tablas = jdbcTemplate.queryForList(
                    "SELECT idEmpresa,catReportesId,grupo,columnaGrupo,"
                    + "agruparPorColumna,indexTable,tituloTabla,"
                    + "espacioIzquierda,espacioDerecha,alineacion,"
                    + "colorFondo,colorLetra,activo "
                    + "FROM dbo.bf_RepConf_Tabla WITH (NOLOCK) "
                    + "WHERE catReportesId=11 AND idEmpresa IN (?,0) "
                    + "ORDER BY CASE WHEN idEmpresa=? THEN 0 ELSE 1 END,"
                    + "indexTable",
                    idEmpresa, idEmpresa);

            LinkedHashMap<String, Map<String, Object>> efectivas =
                    new LinkedHashMap<>();
            for (Map<String, Object> tabla : tablas) {
                String grupo = String.valueOf(tabla.get("grupo")).trim();
                efectivas.putIfAbsent(normalizeConfigKey(grupo), tabla);
            }

            List<Map<String, Object>> columnas = jdbcTemplate.queryForList(
                    "SELECT idEmpresa,catReportesId,grupo,orden,campoOrigen,"
                    + "encabezado,visible,ancho,formato,alinear,tipoDato "
                    + "FROM dbo.bf_RepConf_Columna WITH (NOLOCK) "
                    + "WHERE catReportesId=11 AND idEmpresa IN (?,0) "
                    + "ORDER BY grupo,CASE WHEN idEmpresa=? THEN 0 ELSE 1 END,"
                    + "orden",
                    idEmpresa, idEmpresa);

            Map<String, List<Map<String, Object>>> columnasEmpresa =
                    new LinkedHashMap<>();
            Map<String, List<Map<String, Object>>> columnasGlobales =
                    new LinkedHashMap<>();
            for (Map<String, Object> columna : columnas) {
                String key = normalizeConfigKey(
                        String.valueOf(columna.get("grupo")));
                int empresaConfig = toInt(columna.get("idEmpresa"));
                Map<String, List<Map<String, Object>>> destino =
                        empresaConfig == idEmpresa
                                ? columnasEmpresa : columnasGlobales;
                destino.computeIfAbsent(key, k -> new ArrayList<>())
                        .add(columna);
            }

            List<Map<String, Object>> result = new ArrayList<>();
            for (Map.Entry<String, Map<String, Object>> entry
                    : efectivas.entrySet()) {
                Map<String, Object> tabla =
                        new LinkedHashMap<>(entry.getValue());
                List<Map<String, Object>> cols =
                        columnasEmpresa.get(entry.getKey());
                if (cols == null || cols.isEmpty()) {
                    cols = columnasGlobales.get(entry.getKey());
                }
                tabla.put("columnas", cols == null
                        ? new ArrayList<>() : cols);
                // El instalador define columnas ancla; las demas vienen
                // dinamicamente del SP y se anexan despues de las configuradas.
                tabla.put("preservarColumnasDinamicas", true);
                result.add(tabla);
            }
            debug("cobranza_config_resuelta",
                    "idEmpresa=" + idEmpresa + " grupos=" + result.size());
            return result;
        } catch (Exception e) {
            LOGGER.warn("loadCobranzaReporteConfig: " + e.getMessage());
            debug("cobranza_config_error",
                    "idEmpresa=" + idEmpresa + " error=" + e.getMessage());
            return new ArrayList<>();
        }
    }

    private static String normalizeConfigKey(String value) {
        return value == null ? ""
                : value.replaceAll("[^A-Za-z0-9]", "")
                        .toLowerCase(java.util.Locale.ROOT);
    }

    static int toInt(Object value) {
        if (value instanceof Boolean) return ((Boolean) value) ? 1 : 0;
        if (value instanceof Number) return ((Number) value).intValue();
        try { return Integer.parseInt(String.valueOf(value)); }
        catch (Exception e) { return 0; }
    }

    // ─── Banwire sheets ───────────────────────────────────────────────────────

    private void hojas_transacciones(Workbook libro, CellStyle estiloMoneda, CellStyle styleCabezera,
            Map<String, List<Map<String, Object>>> filtradas) {
        for (String clave : filtradas.keySet()) {
            Sheet hoja = libro.createSheet("Transacciones " + clave);
            hojas_banwire(styleCabezera, hoja, "Transacciones");
            List<Map<String, Object>> valor = filtradas.get(clave);
            int num = 1;
            for (Map<String, Object> map : valor) {
                Row row = hoja.createRow(num++);
                row.createCell(0).setCellValue(str(map.get("idtrans")));
                row.createCell(1).setCellValue(str(map.get("fechadepago")));
                setMoneda(row, 2, map.get("montoprocesado"), estiloMoneda);
                setMoneda(row, 3, 0.0, estiloMoneda);
                double monto = toDouble(map.get("montoprocesado"));
                setMoneda(row, 4, monto * 0.16, estiloMoneda);
                setMoneda(row, 5, 2.50, estiloMoneda);
                setMoneda(row, 6, 0.40, estiloMoneda);
                setMoneda(row, 7, 0.0, estiloMoneda);
                setMoneda(row, 8, 0.0, estiloMoneda);
                setMoneda(row, 9, 2.90, estiloMoneda);
                setMoneda(row, 10, 2.90, estiloMoneda);
                setMoneda(row, 11, 3.364, estiloMoneda);
                setMoneda(row, 12, monto, estiloMoneda);
                row.createCell(13).setCellValue("V/MC");
                row.createCell(14).setCellValue(str(map.get("codigoaut")));
                row.createCell(15).setCellValue(str(map.get("referencia")));
                row.createCell(16).setCellValue(str(map.get("extrefcliente")));
                row.createCell(17).setCellValue(str(map.get("card")));
                row.createCell(18).setCellValue(str(map.get("telefono")));
                row.createCell(19).setCellValue(str(map.get("mail")));
                row.createCell(20).setCellValue(str(map.get("comercio")));
                row.createCell(21).setCellValue("");
            }
        }
    }

    private void hojas_liquidaciones(Workbook libro, CellStyle estiloMoneda, CellStyle styleCabezera,
            Map<String, List<Map<String, Object>>> filtradas) {
        for (String clave : filtradas.keySet()) {
            Sheet hoja = libro.createSheet("Liquidaciones " + clave);
            hojas_banwire(styleCabezera, hoja, "Liquidaciones");
            List<Map<String, Object>> valor = filtradas.get(clave);
            int num = 1;
            for (Map<String, Object> map : valor) {
                Row row = hoja.createRow(num++);
                row.createCell(0).setCellValue(str(map.get("idTransaccion")));
                setMoneda(row, 1, map.get("MontoTransaccion"), estiloMoneda);
                setMoneda(row, 2, map.get("MontoTransaccion"), estiloMoneda);
                row.createCell(3).setCellValue("Correcto");
                row.createCell(4).setCellValue(str(map.get("Clave")));
                row.createCell(5).setCellValue(str(map.get("NombreBeneficiario")));
                setMoneda(row, 6, map.get("MontoTransaccion"), estiloMoneda);
                row.createCell(7).setCellValue(str(map.get("ConceptoPago")));
                row.createCell(8).setCellValue("");
            }
        }
    }

    private void hojas_dispersion(Workbook libro, CellStyle estiloMoneda, CellStyle styleCabezera,
            Map<String, List<Map<String, Object>>> filtradas) {
        for (String clave : filtradas.keySet()) {
            Sheet hoja = libro.createSheet("Dispersiones " + clave);
            hojas_banwire(styleCabezera, hoja, "Dispersiones");
            List<Map<String, Object>> valor = filtradas.get(clave);
            int num = 1;
            for (Map<String, Object> map : valor) {
                Row row = hoja.createRow(num++);
                row.createCell(0).setCellValue(str(map.get("ConceptoDispersion")));
                setMoneda(row, 1, map.get("monto"), estiloMoneda);
                row.createCell(2).setCellValue(str(map.get("cuenta")));
            }
        }
    }

    private static void hojas_banwire(CellStyle styleCabezera, Sheet hoja, String tipo) {
        Row row = hoja.createRow(0);
        String[] cab = getCabecera(tipo, 0, 1);
        for (int i = 0; i < cab.length; i++) {
            Cell c = row.createCell(i);
            c.setCellStyle(styleCabezera);
            c.setCellValue(cab[i]);
            autoSizeColumn(hoja, i, 1);
        }
    }

    // ─── loadCobranzaTablaConfig ─────────────────────────────────────────────
    // Lee bf_RepConf_Tabla (catReportesId=11); devuelve Map<grupo, {activo, tituloTabla}>
    private Map<String, Map<String, Object>> loadCobranzaTablaConfig(int idEmpresa) {
        try {
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT grupo, activo, tituloTabla " +
                "FROM dbo.bf_RepConf_Tabla WITH (NOLOCK) " +
                "WHERE catReportesId = 11 AND idEmpresa IN (?,0) " +
                "ORDER BY CASE WHEN idEmpresa = ? THEN 0 ELSE 1 END, indexTable",
                idEmpresa, idEmpresa);
            Map<String, Map<String, Object>> cfg = new LinkedHashMap<>();
            for (Map<String, Object> row : rows) {
                cfg.putIfAbsent(String.valueOf(row.get("grupo")), row); // empresa-specific primero
            }
            return cfg;
        } catch (Exception e) {
            LOGGER.warn("loadCobranzaTablaConfig: " + e.getMessage());
            return new LinkedHashMap<>();
        }
    }

    private boolean sheetActiva(Map<String, Map<String, Object>> cfg, String grupo) {
        if (!cfg.containsKey(grupo)) return true;
        Object v = cfg.get(grupo).get("activo");
        return v == null || toInt(v) != 0;
    }

    private String sheetNombre(Map<String, Map<String, Object>> cfg, String grupo) {
        if (!cfg.containsKey(grupo)) return grupo;
        Object t = cfg.get(grupo).get("tituloTabla");
        return (t != null && !t.toString().isEmpty()) ? t.toString() : grupo;
    }

    // ─── loadCobranzaColumnConfig ────────────────────────────────────────────
    // Lee bf_RepConf_Columna (catReportesId=11); devuelve Map<grupo, Map<campoOrigen_lc, encabezado>>
    private Map<String, Map<String, String>> loadCobranzaColumnConfig(int idEmpresa) {
        try {
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT grupo, campoOrigen, encabezado " +
                "FROM dbo.bf_RepConf_Columna WITH (NOLOCK) " +
                "WHERE catReportesId = 11 AND idEmpresa IN (?,0) AND visible = 1 " +
                "ORDER BY CASE WHEN idEmpresa = ? THEN 0 ELSE 1 END, grupo, orden",
                idEmpresa, idEmpresa);
            Map<String, Map<String, String>> cfg = new LinkedHashMap<>();
            Set<String> seen = new java.util.HashSet<>();
            for (Map<String, Object> row : rows) {
                String grupo = String.valueOf(row.get("grupo"));
                String campo = String.valueOf(row.get("campoOrigen")).toLowerCase();
                String encab = String.valueOf(row.get("encabezado"));
                String key   = grupo + "|" + campo;
                if (seen.add(key)) { // empresa-specific tiene prioridad sobre idEmpresa=0
                    cfg.computeIfAbsent(grupo, k -> new LinkedHashMap<>()).put(campo, encab);
                }
            }
            return cfg.isEmpty() ? null : cfg;
        } catch (Exception e) {
            LOGGER.warn("loadCobranzaColumnConfig: " + e.getMessage());
            return null;
        }
    }

    // ─── setHoja ──────────────────────────────────────────────────────────────

    private int setHoja(List<LinkedCaseInsensitiveMap> arrayList, Sheet hoja, int index,
            CellStyle sc, CellStyle sd, CellStyle sdi,
            CellStyle styleFecha, CellStyle styleEntero, CellStyle texto,
            String tipo, boolean saltoL, int bandera,
            Map<String, Map<String, String>> colCfg) {

        Set<String> setKeys = arrayList.get(0).keySet();
        ArrayList<String> keys = new ArrayList<>(setKeys);

        // Campos configurados (en orden) cuando hay config; fallback a SP order
        List<String> configCampos = null; // lowercase keys in 'orden' order
        String[] cabecera;
        if (colCfg != null && !tipo.isEmpty()) {
            String lookupGrupo = tipo;
            if ("Total por coberturas".equals(tipo)
                    && keys.stream().anyMatch(k -> k.equalsIgnoreCase("CVEParentesco"))) {
                lookupGrupo = "Total por coberturas Parentesco";
            }
            Map<String, String> fieldMap = colCfg.get(lookupGrupo);
            if (configuracionColumnasCompleta(fieldMap, keys)) {
                // fieldMap es LinkedHashMap ordenado por 'orden' en bf_RepConf_Columna
                configCampos = new ArrayList<>(fieldMap.keySet());
                cabecera     = configCampos.stream().map(fieldMap::get).toArray(String[]::new);
            } else {
                cabecera = getCabecera(tipo, keys.size(), bandera);
            }
        } else {
            cabecera = getCabecera(tipo, keys.size(), bandera);
        }

        // El patrón B2 contiene dos bloques de 10 columnas en la misma hoja.
        // Ambos comparten tamaño, pero el tercer encabezado depende del campo
        // entregado por el resultset: PlanD = "Nombre del plan" y Concepto =
        // "Concepto". No es posible distinguirlos únicamente por keys.size().
        cabecera = ajustarCabeceraTotal(
                tipo, cabecera, keys, configCampos != null);
        if (configCampos == null
                && "Total por coberturas".equals(tipo)
                && cabecera.length == 10
                && esBloqueConceptos(arrayList)) {
            cabecera = cabecera.clone();
            cabecera[2] = "Concepto";
        }

        int[] fmts = new int[cabecera.length];
        index = (saltoL && index != 0) ? index + 5 : index;

        Row rowC;
        if (saltoL) {
            rowC = hoja.createRow(index++);
        } else {
            rowC = hoja.createRow(index);
        }

        if (cabecera.length == 0) {
            for (int i = 0; i < keys.size(); i++) {
                if (saltoL) {
                    Cell c = rowC.createCell(i);
                    c.setCellStyle(sc);
                    c.setCellValue(keys.get(i));
                }
            }
        } else if (configCampos != null) {
            // Config-driven: headers y formatos por nombre de campo (ignora posición del SP)
            for (int i = 0; i < configCampos.size(); i++) {
                if (saltoL) {
                    Cell c = rowC.createCell(i);
                    c.setCellStyle(sc);
                    c.setCellValue(cabecera[i]);
                }
                String campo = configCampos.get(i);
                Object val = valorReferenciaPorCampo(arrayList, campo);
                fmts[i] = resolverFormatoCobranza(campo, cabecera[i], val);
            }
        } else {
            for (int i = 0; i < cabecera.length; i++) {
                if (saltoL) {
                    Cell c = rowC.createCell(i);
                    c.setCellStyle(sc);
                    c.setCellValue(cabecera[i]);
                }
                Object val = valorReferenciaPorIndice(arrayList, i);
                String campo = i < keys.size() ? keys.get(i) : "";
                fmts[i] = resolverFormatoCobranza(campo, cabecera[i], val);
            }
        }

        String[][] tbDatos = new String[arrayList.size()][cabecera.length];
        if (cabecera.length > 0) {
            if (configCampos != null) {
                // Busca cada valor por nombre de campo (case-insensitive)
                for (int r = 0; r < arrayList.size(); r++) {
                    for (int c = 0; c < configCampos.size(); c++) {
                        Object v = arrayList.get(r).get(configCampos.get(c));
                        tbDatos[r][c] = v != null ? v.toString() : "";
                    }
                }
            } else {
                for (int r = 0; r < arrayList.size(); r++) {
                    ArrayList<Object> celdas = new ArrayList<>(arrayList.get(r).values());
                    for (int c = 0; c < Math.min(celdas.size(), cabecera.length); c++) {
                        tbDatos[r][c] = celdas.get(c) != null ? celdas.get(c).toString() : "";
                    }
                }
            }
        }

        for (String[] fila : tbDatos) {
            Row row = hoja.createRow(index++);
            for (int c = 0; c < fila.length; c++) {
                Cell cell = row.createCell(c);
                switch (fmts[c]) {
                    case 0:
                        int slash = fila[c].indexOf("/");
                        if (slash == 2) {
                            try {
                                cell.setCellValue(new SimpleDateFormat("dd/MM/yyyy").parse(fila[c]));
                                cell.setCellStyle(styleFecha);
                            } catch (ParseException e) {
                                cell.setCellValue(new Date(fila[c]));
                                cell.setCellStyle(styleFecha);
                            }
                        } else if (isNumeric(fila[c])) {
                            cell.setCellType(CellType.STRING);
                            cell.setCellValue(fila[c]);
                            cell.setCellStyle(texto);
                        } else {
                            cell.setCellValue(fila[c]);
                            cell.setCellStyle(sd);
                        }
                        break;
                    case 1:
                        try {
                            cell.setCellValue(Integer.parseInt(fila[c]));
                            cell.setCellStyle(styleEntero);
                        } catch (NumberFormatException ex) {
                            cell.setCellValue(fila[c]);
                            cell.setCellStyle(sd);
                        }
                        break;
                    case 2:
                        try {
                            cell.setCellValue(new BigDecimal(fila[c]).doubleValue());
                            cell.setCellStyle(sdi);
                        } catch (Exception ex) {
                            cell.setCellValue(fila[c]);
                            cell.setCellStyle(sd);
                        }
                        break;
                }
            }
        }
        ajustarAnchosLineales(hoja, cabecera, tbDatos, 1);
        return index;
    }

    /**
     * El Excel se escribe en particiones. Para decidir el tipo de una columna
     * se toma el primer valor real de la particion, no necesariamente el de la
     * primera fila, que puede venir nulo o vacio.
     */
    @SuppressWarnings("rawtypes")
    static Object valorReferenciaPorIndice(
            List<LinkedCaseInsensitiveMap> filas, int indice) {
        for (LinkedCaseInsensitiveMap fila : filas) {
            ArrayList valores = new ArrayList(fila.values());
            if (indice >= valores.size()) continue;
            Object valor = valores.get(indice);
            if (esValorReferencia(valor)) return valor;
        }
        return null;
    }

    @SuppressWarnings("rawtypes")
    static Object valorReferenciaPorCampo(
            List<LinkedCaseInsensitiveMap> filas, String campo) {
        for (LinkedCaseInsensitiveMap fila : filas) {
            Object valor = fila.get(campo);
            if (esValorReferencia(valor)) return valor;
        }
        return null;
    }

    private static boolean esValorReferencia(Object valor) {
        return valor != null
                && (!(valor instanceof String)
                || !((String) valor).trim().isEmpty());
    }

    /**
     * Conserva como texto las claves de negocio que pueden contener ceros a
     * la izquierda y evita aplicar formato moneda a identificadores. El tipo
     * deja de depender de una fila TOTAL con valores nulos.
     */
    static int resolverFormatoCobranza(
            String campo, String encabezado, Object valor) {
        String clave = normalizeConfigKey(campo);
        String titulo = normalizeConfigKey(encabezado);

        if ("empresa".equals(clave)
                || "numempleado".equals(clave)
                || "numeroempleado".equals(clave)
                || "nmeroempleado".equals(titulo)) {
            return 0;
        }

        if ("cveempl".equals(clave)
                || "idemp".equals(clave)
                || "id".equals(clave)
                || "edad".equals(clave)
                || "numoficina".equals(clave)
                || "numerooficina".equals(clave)
                || "id".equals(titulo)
                || "edad".equals(titulo)
                || "nmerooficina".equals(titulo)) {
            return 1;
        }

        if (valor instanceof Byte || valor instanceof Short
                || valor instanceof Integer || valor instanceof Long
                || valor instanceof java.math.BigInteger) {
            return 1;
        }
        if (valor instanceof Number) return 2;
        return 0;
    }

    /**
     * Una configuracion parcial se usa como ancla del motor dinamico y no como
     * lista de columnas visibles del reporte legacy. Solo se aplica al libro
     * homologado cuando cubre el resultset completo.
     */
    static boolean configuracionColumnasCompleta(
            Map<String, String> fieldMap, List<String> keys) {
        if (fieldMap == null || keys == null || fieldMap.size() != keys.size()) {
            return false;
        }
        for (String key : keys) {
            if (!fieldMap.containsKey(key.toLowerCase())) return false;
        }
        return true;
    }

    static String[] ajustarCabeceraTotal(
            String tipo, String[] cabecera, List<String> keys,
            boolean usaConfiguracionCompleta) {
        if (!usaConfiguracionCompleta
                && "Total por coberturas".equals(tipo)
                && cabecera.length == 10
                && keys.stream().anyMatch(k -> "Concepto".equalsIgnoreCase(k))) {
            String[] ajustada = cabecera.clone();
            ajustada[2] = "Concepto";
            return ajustada;
        }
        return cabecera;
    }

    @SuppressWarnings("rawtypes")
    static boolean esBloqueConceptos(List<? extends Map> filas) {
        if (filas == null || filas.isEmpty()) return false;
        for (Map fila : filas) {
            if (fila == null) continue;
            int cvep = toInt(fila.get("CVEP"));
            int orden = toInt(fila.get("ImpPer"));
            if ((cvep == 10002 || cvep == 10003)
                    && orden >= 1 && orden <= 4) {
                return true;
            }
        }
        return false;
    }

    // ─── Hoja Info (portada) ──────────────────────────────────────────────────

    private void getHojaInfo(Workbook libro, int idEmpresa, String empresa, String FecIni, String FecFin, int idVigencia) {
        // La portada conserva su posicion historica, pero sus valores deben
        // corresponder a los filtros con los que se genero el reporte. No
        // copiar fechas, meses ni vigencias de un archivo de referencia.
        Sheet hoja = libro.createSheet("Informacion");

        CellStyle s1 = estilo(libro, 16, true,  IndexedColors.GREY_50_PERCENT, IndexedColors.WHITE, HorizontalAlignment.LEFT, VerticalAlignment.BOTTOM);
        CellStyle s2 = estilo(libro, 11, true,  IndexedColors.GREY_50_PERCENT, IndexedColors.WHITE, HorizontalAlignment.LEFT, VerticalAlignment.CENTER);
        CellStyle s3 = estilo(libro, 11, false, null, IndexedColors.BLACK, HorizontalAlignment.RIGHT, VerticalAlignment.CENTER);
        CellStyle s4 = estilo(libro, 11, false, null, IndexedColors.BLACK, HorizontalAlignment.LEFT,  VerticalAlignment.CENTER);

        Periodicidad periodicidad = getPeriodicidadPagos(idVigencia);

        Row row = hoja.createRow(0);
        Cell cell = row.createCell(0);
        cell.setCellValue("Empresa: " + getRazonSocial(idEmpresa, empresa, idVigencia));
        cell.setCellStyle(s1);
        hoja.addMergedRegion(new CellRangeAddress(0, 5, 0, 8));

        row = hoja.createRow(6);
        cell = row.createCell(0); cell.setCellValue("INFORMACI\u00D3N AL:"); cell.setCellStyle(s2);
        hoja.addMergedRegion(new CellRangeAddress(6, 6, 0, 3));
        cell = row.createCell(4);
        cell.setCellValue(rangoFechasPortada(FecIni, FecFin));
        cell.setCellStyle(s3);
        hoja.addMergedRegion(new CellRangeAddress(6, 6, 4, 8));

        row = hoja.createRow(7);
        cell = row.createCell(0); cell.setCellValue("PERIODICIDAD DE PAGO"); cell.setCellStyle(s2);
        hoja.addMergedRegion(new CellRangeAddress(7, 7, 0, 3));
        cell = row.createCell(4); cell.setCellValue(periodicidad.periodicidad); cell.setCellStyle(s4);
        hoja.addMergedRegion(new CellRangeAddress(7, 7, 4, 8));

        row = hoja.createRow(8);
        cell = row.createCell(0); cell.setCellValue("CANTIDAD DE PAGOS"); cell.setCellStyle(s2);
        hoja.addMergedRegion(new CellRangeAddress(8, 8, 0, 3));
        cell = row.createCell(4); cell.setCellValue(periodicidad.catidadPagos); cell.setCellStyle(s4);
        hoja.addMergedRegion(new CellRangeAddress(8, 8, 4, 8));
    }

    static String fechaCompacta(String fecha) {
        if (fecha == null) return "";
        String digitos = fecha.replaceAll("[^0-9]", "");
        return digitos.length() >= 8 ? digitos.substring(0, 8) : fecha;
    }

    static String fechaPortada(String fecha) {
        String compacta = fechaCompacta(fecha);
        if (!compacta.matches("\\d{8}")) return compacta;
        return compacta.substring(6, 8) + "/"
                + compacta.substring(4, 6) + "/"
                + compacta.substring(0, 4);
    }

    static String rangoFechasPortada(String fechaInicio, String fechaFin) {
        return fechaPortada(fechaInicio) + " al " + fechaPortada(fechaFin);
    }

    // ─── SP helpers ───────────────────────────────────────────────────────────

    public int getVigenciaActiva(int idEmpresa) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_get2VigenciasPorCorporativo");
        Map<String, Object> result = call.execute(new MapSqlParameterSource("IdEmpresa", idEmpresa));
        try {
            List<Object> list = new ArrayList<>(result.values());
            ArrayList<LinkedCaseInsensitiveMap> rows = (ArrayList<LinkedCaseInsensitiveMap>) list.get(0);
            return Integer.parseInt(rows.get(0).values().toArray()[0].toString());
        } catch (Exception e) { return -1; }
    }

    public String getFechaInicioVigencia(int vigencia) {
        return getFechaVigencia(vigencia, "VIVigenciaIni");
    }

    public String getFechaFinalVigencia(int vigencia) {
        return getFechaVigencia(vigencia, "VIVigenciaFin");
    }

    public String getFechaInicioEnrollment(int vigencia) {
        return getFechaVigencia(vigencia, "VIEnrollmentIni");
    }

    private String getFechaVigencia(int vigencia, String campo) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetVigenciaXId");
        Map<String, Object> result = call.execute(new MapSqlParameterSource("IdVigencia", vigencia));
        try {
            List<Object> list = new ArrayList<>(result.values());
            ArrayList<LinkedCaseInsensitiveMap> rows = (ArrayList<LinkedCaseInsensitiveMap>) list.get(0);
            Timestamp ts = (Timestamp) rows.get(0).get(campo);
            return new SimpleDateFormat("yyyy-MM-dd").format(new Date(ts.getTime()));
        } catch (Exception e) { return ""; }
    }

    public int getPeriocidad(int idCorporativo) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_ObtenerConfiguracionEnvio");
        Map<String, Object> result = call.execute(new MapSqlParameterSource("IdCorporativo", idCorporativo));
        try {
            List<Object> list = new ArrayList<>(result.values());
            ArrayList<LinkedCaseInsensitiveMap> rows = (ArrayList<LinkedCaseInsensitiveMap>) list.get(0);
            Object[] v = rows.get(0).values().toArray();
            return Integer.parseInt(v[v.length - 2].toString());
        } catch (Exception e) { return -1; }
    }

    public List<Object> getPeriodicidadDePagos(int idVigencia) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName("getPeriodicidadPagos");
        Map<String, Object> result = call.execute(new MapSqlParameterSource("IdVigencia", idVigencia));
        return new ArrayList<>(result.values());
    }

    public List<Object> getListArchivosVigenciaActivaRenovada(int idEmpresa, int idVigencia) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName("getFilesVigenciaActivaRenovadaXEmpresa");
        Map<String, Object> inMap = new HashMap<>();
        inMap.put("idEmpresa",  idEmpresa);
        inMap.put("idVigencia", idVigencia);
        Map<String, Object> result = call.execute(new MapSqlParameterSource(inMap));
        try {
            List<Object> listSP = new ArrayList<>(result.values());
            ArrayList<LinkedCaseInsensitiveMap> rows = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            ArrayList<String> names = new ArrayList<>();
            for (LinkedCaseInsensitiveMap r : rows) names.add((String) r.values().toArray()[0]);
            return new ArrayList<>(names);
        } catch (Exception e) {
            return buildError(e.getMessage());
        }
    }

    private String getRazonSocial(int idEmpresa, String empresa, int idVigencia) {
        try {
            SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName("getFilesVigenciaActivaRenovadaXEmpresa");
            Map<String, Object> inMap = new HashMap<>();
            inMap.put("idEmpresa",  idEmpresa);
            inMap.put("idVigencia", idVigencia);
            Map<String, Object> result = call.execute(new MapSqlParameterSource(inMap));
            List<Object> listSP = new ArrayList<>(result.values());
            ArrayList<LinkedCaseInsensitiveMap> rows = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            return (String) rows.get(0).values().toArray()[2];
        } catch (Exception e) { return empresa; }
    }

    private Periodicidad getPeriodicidadPagos(int idVigencia) {
        Periodicidad p = new Periodicidad();
        try {
            SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName("getPeriodicidadPagos");
            Map<String, Object> result = call.execute(new MapSqlParameterSource("IdVigencia", idVigencia));
            List<Object> listSP = new ArrayList<>(result.values());
            ArrayList<LinkedCaseInsensitiveMap> rows = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            p.periodicidad  = rows.get(0).get("PPNombre").toString();
            p.catidadPagos  = Integer.parseInt(rows.get(0).get("PPCantidadPagos").toString());
        } catch (Exception ignored) {}
        return p;
    }

    /**
     * Escribe primero un XLSX valido y despues, si corresponde, lo cifra.
     * El destino solo se reemplaza cuando todo el proceso termino; asi un
     * fallo de cifrado no deja un archivo parcial de pocos KB.
     */
    static void guardarWorkbookSeguro(
            Workbook workbook, File destino, String password)
            throws IOException {
        java.nio.file.Path destinoPath = destino.toPath().toAbsolutePath();
        java.nio.file.Path directorio = destinoPath.getParent();
        if (directorio == null) {
            throw new IOException("El archivo destino no tiene directorio.");
        }
        java.nio.file.Files.createDirectories(directorio);

        java.nio.file.Path xlsxTemporal = java.nio.file.Files.createTempFile(
                directorio, ".cobranza-sin-cifrar-", ".xlsx");
        java.nio.file.Path cifradoTemporal = null;
        try {
            try (OutputStream out = java.nio.file.Files.newOutputStream(
                    xlsxTemporal)) {
                workbook.write(out);
            }

            // Comprueba que el libro base sea un paquete XLSX completo.
            try (org.apache.poi.openxml4j.opc.OPCPackage ignored =
                    org.apache.poi.openxml4j.opc.OPCPackage.open(
                            xlsxTemporal.toFile(),
                            org.apache.poi.openxml4j.opc.PackageAccess.READ)) {
                // La apertura valida la estructura ZIP/OOXML.
            } catch (Exception e) {
                throw new IOException("El XLSX generado no es valido.", e);
            }

            java.nio.file.Path listo = xlsxTemporal;
            if (password != null && !password.trim().isEmpty()) {
                cifradoTemporal = java.nio.file.Files.createTempFile(
                        directorio, ".cobranza-cifrada-", ".xlsx");
                try (POIFSFileSystem fs = new POIFSFileSystem()) {
                    EncryptionInfo info = new EncryptionInfo(
                            EncryptionMode.standard);
                    Encryptor enc = info.getEncryptor();
                    enc.confirmPassword(password.trim());

                    // Es indispensable cerrar este stream antes de serializar
                    // POIFS; en caso contrario queda un archivo truncado.
                    try (InputStream source =
                                java.nio.file.Files.newInputStream(xlsxTemporal);
                         org.apache.poi.openxml4j.opc.OPCPackage opc =
                                org.apache.poi.openxml4j.opc.OPCPackage.open(
                                        source);
                         OutputStream encrypted = enc.getDataStream(fs)) {
                        opc.save(encrypted);
                    } catch (Exception e) {
                        throw new IOException(
                                "Error al cifrar el archivo Excel", e);
                    }

                    try (OutputStream out = java.nio.file.Files.newOutputStream(
                            cifradoTemporal)) {
                        fs.writeFilesystem(out);
                    }
                }
                listo = cifradoTemporal;
            }

            try {
                java.nio.file.Files.move(listo, destinoPath,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException e) {
                java.nio.file.Files.move(listo, destinoPath,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            java.nio.file.Files.deleteIfExists(xlsxTemporal);
            if (cifradoTemporal != null) {
                java.nio.file.Files.deleteIfExists(cifradoTemporal);
            }
        }
    }

    String getPasswordCobranza(int idEmpresa) {
        try {
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                    "SELECT TOP (1) paValor "
                  + "FROM dbo.ff_Parametro "
                  + "WHERE paIdEmpresa = ? "
                  + "  AND paidEstatus = 1 "
                  + "  AND UPPER(LTRIM(RTRIM(paClase))) = ? "
                  + "ORDER BY paId DESC",
                    idEmpresa, "COBRANZA_EXCEL_PASSWORD");
            if (rows == null || rows.isEmpty()) return "";
            return valorParametro(rows.get(0));
        } catch (Exception e) { return ""; }
    }

    /**
     * Obtiene paValor por nombre de columna. No debe depender del orden de las
     * columnas que regresa ff_GetParametro (la primera normalmente es paId).
     */
    static String valorParametro(Map<String, ?> row) {
        if (row == null || row.isEmpty()) return "";
        for (Map.Entry<String, ?> entry : row.entrySet()) {
            if (entry.getKey() != null
                    && entry.getKey().equalsIgnoreCase("paValor")) {
                Object value = entry.getValue();
                return value == null ? "" : String.valueOf(value).trim();
            }
        }
        return "";
    }

    private void insertArchivoCobranza(int idEmpresa, String FecIni, String FecFin, int vigencia, String nombreArch, Date today) {
        try {
            SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_IInsertaCobranzaEncabezado");
            Map<String, Object> inMap = new HashMap<>();
            inMap.put("COIdEmpresa",   idEmpresa);
            inMap.put("COIdVigencia",  vigencia);
            inMap.put("COFechaIni",    FecIni);
            inMap.put("COFechaFin",    FecFin);
            inMap.put("CONombreRep",   nombreArch);
            inMap.put("COFecHoraGen",  new SimpleDateFormat("yyy-MM-dd HH:mm:ss:SSS").format(today));
            inMap.put("Usuario",       null);
            call.execute(new MapSqlParameterSource(inMap));
        } catch (Exception e) {
            LOGGER.warn("insertArchivoCobranza: " + e.getMessage());
        }
    }

    // ─── Mappers ──────────────────────────────────────────────────────────────

    private Map<String, Object> mapearTransacciones(LinkedCaseInsensitiveMap col) {
        Map<String, Object> m = new HashMap<>();
        m.put("idtrans",          col.get("idtrans"));
        m.put("fechadepago",      col.get("fechadepago"));
        m.put("montoprocesado",   col.get("montoprocesado"));
        m.put("codigoaut",        col.get("codigoaut"));
        m.put("referencia",       col.get("referencia"));
        m.put("extrefcliente",    col.get("extrefcliente"));
        m.put("card",             col.get("card"));
        m.put("telefono",         col.get("telefono"));
        m.put("mail",             col.get("mail"));
        m.put("comercio",         col.get("comercio"));
        m.put("ProveedorTransaccion", col.get("ProveedorTransaccion"));
        return m;
    }

    private Map<String, Object> mapearLiquidaciones(LinkedCaseInsensitiveMap col) {
        Map<String, Object> m = new HashMap<>();
        m.put("idTransaccion",    col.get("idTransaccion"));
        m.put("MontoTransaccion", col.get("MontoTransaccion"));
        m.put("Clave",            col.get("Clave"));
        m.put("NombreBeneficiario", col.get("NombreBeneficiario"));
        m.put("ConceptoPago",     col.get("ConceptoPago"));
        m.put("ProveedorLiquidacion", col.get("ProveedorLiquidacion"));
        return m;
    }

    private Map<String, Object> mapearDispersiones(LinkedCaseInsensitiveMap col) {
        Map<String, Object> m = new HashMap<>();
        m.put("ConceptoDispersion", col.get("ConceptoDispersion"));
        m.put("monto",              col.get("monto"));
        m.put("cuenta",             col.get("cuenta"));
        m.put("ProveedorDispersion", col.get("ProveedorDispersion"));
        return m;
    }

    private static boolean tieneValor(Map<?, ?> fila, String clave) {
        Object valor = fila == null ? null : fila.get(clave);
        return valor != null && !String.valueOf(valor).trim().isEmpty();
    }

    private Map<String, List<Map<String, Object>>> filtrarPorClave(String clave, List<Object> lista) {
        Map<String, List<Map<String, Object>>> result = new HashMap<>();
        for (Object obj : lista) {
            if (!(obj instanceof Map)) continue;
            Map<String, Object> mapa = (Map<String, Object>) obj;
            String proveedor = mapa.containsKey(clave) && mapa.get(clave) != null
                    ? mapa.get(clave).toString() : null;
            if (proveedor != null && !proveedor.isEmpty())
                result.computeIfAbsent(proveedor, k -> new ArrayList<>()).add(mapa);
        }
        return result;
    }

    // ─── getCabecera ──────────────────────────────────────────────────────────

    private static String[] getCabecera(String nomHoja, int size, int bandera) {
        if (bandera == 1) {
            switch (nomHoja) {
                case "Concentrada":
                    if (size == 69) return new String[]{"Empresa","Número Empleado","Id","Paterno","Materno","Primer nombre","Segundo nombre","Sexo","Fecha nacimiento","Edad","Sueldo confidencial","Sueldo mensual","Sueldo mensual anterior","Diferencia Sueldo mensual","Transferido","Número solicitud","Perfil","Fecha autorización","Grupo Parentesco","Monto GMM periodo descuento","Monto vida periodo descuento","Monto otros periodo descuento","Créditos GMM periodo descuento","Créditos vida periodo descuento","Monto total créditos periodo descuento","Monto total créditos periodo descuento Anterior","Diferencia Créditos","Monto total selecciones periodo descuento","Monto total selecciones anteriores periodo descuento","Diferencia selecciones periodo descuento","Sobrante créditos periodo descuento","Monto pagado con créditos periodo descuento","Descuento empleado periodo descuento","Descuento empleado periodo descuento Anterior","Diferencia descuento empleado","Q1","Q2","Diferencia","Excedentes periodo descuento","Excedentes anteriores periodo descuento","Diferencia Excedentes","Monto fondo ahorro periodo descuento","Monto fondo ahorro periodo descuento Anterior","Diferencia Monto fondo ahorro","Sobrante de excedentes periodo descuento","Aplicación de excedentes periodo descuento","Descuento empleado de fondo ahorro","Descuento empleado final periodo descuento","Costo empleado nómina seguros periodo descuento","Sobrante de excedentes final periodo descuento","Cobertura regalos periodo descuento","Número Oficina","Nombre Oficina","Plan Fondo de Ahorro","Observaciones","Costo Empresa","Costo Empleado","Costo Planes Tarjeta","Cobro Tarjeta","Diferencia Tarjeta","Transacción","Fecha de cobro","Código de autorización","Referencia","Extensión de referencia del cliente","Card","Teléfono","Mail","Comercio"};
                    break;
                case "Desglosada":
                    if (size == 58) return new String[]{"Empresa","Número empleado","Id","Paterno","Materno","Primer nombre","Segundo nombre","Sexo","Fecha nacimiento","Edad","Perfil","CveParentesco","Parentesco","Transferido","Sueldo mensual","Número solicitud","Plan","Cobertura","Grupo parentesco","CVEPO","CVEP","Tipo S.A.","Valor S.A.","Orden cobranza","Importe de costos hasta fin de vigencia","Prima neta hasta fin de vigencia","Importe de costos por periodo","Prima neta por periodo","Monto de créditos al fin de vigencia","Monto de créditos por periodo","Costo empresa por periodo","Costo empresa cashflow por periodo","Costo empresa 1er. exceso por periodo","Costo empresa Stoploss por periodo","Costo empleado por periodo","Costo empleado cashflow por periodo","Costo empleado 1er. exceso por periodo","Costo empleado stoploss por periodo","Costo empleado excedentes por periodo","Costo empleado real por periodo","Sobrante excedentes por periodo","Costo Empresa","Costo Empleado","Tipo","Monto Pago","Derecho Pol","Recargo","IVA","Total","Monto Pago Tarjeta","Derecho Pol Tarjeta","Recargo Tarjeta","IVA Tarjeta","Total Tarjeta","Diferencia","Transacción","Liquidación Concepto","Proveedor"};
                    break;
                case "Total por coberturas":
                    if (size == 10) return new String[]{"Clave de plan","Clave de cobertura","Nombre del plan","Importe por periodo","Prima neta por periodo","Costo empresa por periodo","Costo empleado por periodo","Costo empleado excedentes","Costo empleado real","Sobrante de excedentes"};
                    if (size == 5)  return new String[]{"Clave de plan","Clave de cobertura","Nombre Cobertura","Clave Parentesco","Cantidad"};
                    break;
                case "Planes_Parentesco":
                    if (size == 12) return new String[]{"Clave Plan","Clave Plan Opcion","Plan","Plan Opcion","TITULAR","HIJO(A)","CONYUGE","PADRE_MADRE","HERMANO(A)","SUEGRO(A)","OTRO","CONCUBINO(A)"};
                    break;
                case "Transacciones":
                    return new String[]{"ID Trans","Fecha de Pago","Monto procesado","Comisión BanWire","IVA Comisión Fija","IVA","Comisión Fija Sin IVA","Comisión MSI","IVS MSI","Total Comisión","Tasa","C/IVA","Liquidación","Terminal","codigo_aut","referencia","ext_ref_cliente","Card","teléfono","mail","Comercio","Meses Financiados"};
                case "Liquidaciones":
                    return new String[]{"ID TRANSACCION","Monto transaccion","#","Estatus","Clave","NOMBRE_BENEFICIARIO","MONTO","CONCEPTO_PAGO","EMAIL_BENEFICIARIO"};
                case "Dispersiones":
                    return new String[]{"NOMBRE_BENEFICIARIO","MONTO","CUENTA_BENEFICIARIO"};
            }
        } else {
            switch (nomHoja) {
                case "Concentrada":
                    if (size == 57) return new String[]{"Empresa","Número Empleado","Id","Paterno","Materno","Primer nombre","Segundo nombre","Sexo","Fecha nacimiento","Edad","Sueldo confidencial","Sueldo mensual","Sueldo mensual anterior","Diferencia Sueldo mensual","Transferido","Número solicitud","Perfil","Fecha autorización","Grupo Parentesco","Monto GMM mensual","Monto vida mensual","Monto otros mensual","Créditos GMM mensual","Créditos vida mensual","Monto total créditos mensual","Monto total créditos mensual Anterior","Diferencia Créditos","Monto total selecciones mensual","Monto total selecciones anteriores mensual","Diferencia Selecciones Mensual","Sobrante créditos mensual","Monto pagado con créditos mensual","Descuento empleado mensual","Descuento empleado mensual Anterior","Diferencia descuento empleado","Q1","Q2","Diferencia","Excedentes mensuales","Excedentes anteriores mensuales","Diferencia Excedentes","Monto fondo ahorro mensual","Monto fondo ahorro mensual Anterior","Diferencia Monto fondo ahorro","Sobrante de excedentes mensuales","Aplicación de excedentes mensuales","Descuento empleado de fondo ahorro","Descuento empleado final mensual","Costo empleado nómina seguros mensual","Sobrante de excedentes final mensual","Cobertura regalos mensual","Número Oficina","Nombre Oficina","Plan Fondo de Ahorro","Observaciones","Costo Empresa","Costo Empleado"};
                    break;
                case "Desglosada":
                    if (size == 43) return new String[]{"Empresa","Número empleado","Id","Paterno","Materno","Primer nombre","Segundo nombre","Sexo","Fecha nacimiento","Edad","Perfil","CveParentesco","Parentesco","Transferido","Sueldo mensual","Número solicitud","Plan","Cobertura","Grupo parentesco","CVEPO","CVEP","Tipo S.A.","Valor S.A.","Orden cobranza","Importe de costos hasta fin de vigencia","Prima neta hasta fin de vigencia","Importe de costos por periodo","Prima neta por periodo","Monto de créditos al fin de vigencia","Monto de créditos por periodo","Costo empresa por periodo","Costo empresa cashflow por periodo","Costo empresa 1er. exceso por periodo","Costo empresa Stoploss por periodo","Costo empleado por periodo","Costo empleado cashflow por periodo","Costo empleado 1er. exceso por periodo","Costo empleado stoploss por periodo","Costo empleado excedentes por periodo","Costo empleado real por periodo","Sobrante excedentes por periodo","Costo Empresa","Costo Empleado"};
                    break;
                case "Total por coberturas":
                    if (size == 10) return new String[]{"Clave de plan","Clave de cobertura","Nombre del plan","Importe por periodo","Prima neta por periodo","Costo empresa por periodo","Costo empleado por periodo","Costo empleado excedentes","Costo empleado real","Sobrante de excedentes"};
                    if (size == 5)  return new String[]{"Clave de plan","Clave de cobertura","Nombre Cobertura","Clave Parentesco","Cantidad"};
                    break;
                case "Planes_Parentesco":
                    if (size == 12) return new String[]{"Clave Plan","Clave Plan Opcion","Plan","Plan Opcion","TITULAR","HIJO(A)","CONYUGE","PADRE_MADRE","HERMANO(A)","SUEGRO(A)","OTRO","CONCUBINO(A)"};
                    break;
            }
        }
        return new String[]{};
    }

    // ─── Utilities ────────────────────────────────────────────────────────────

    private static <T> List<List<T>> partition(List<T> list, int size) {
        List<List<T>> result = new ArrayList<>();
        for (int i = 0; i < list.size(); i += size)
            result.add(list.subList(i, Math.min(i + size, list.size())));
        return result;
    }

    private static boolean isNumeric(String s) {
        try { Integer.parseInt(s); return true; } catch (NumberFormatException e) { return false; }
    }

    private static void autoSizeColumn(Sheet hoja, int col, int plus) {
        try {
            double w = SheetUtil.getColumnWidth(hoja, col, false);
            if (w != -1) {
                w = Math.min((w + plus) * 256, 255 * 256);
                hoja.setColumnWidth(col, (int) w);
            }
        } catch (Exception ignored) {}
    }

    /**
     * Conserva el mayor ancho observado sin volver a recorrer las filas que
     * SXSSF ya escribio. SheetUtil sobre la hoja completa en cada particion
     * hacia que el costo creciera de forma casi cuadratica.
     */
    private static void ajustarAnchosLineales(
            Sheet hoja, String[] cabecera, String[][] datos, int plus) {
        int columnas = cabecera == null ? 0 : cabecera.length;
        if (columnas == 0 && datos != null && datos.length > 0) {
            columnas = datos[0].length;
        }
        for (int col = 0; col < columnas; col++) {
            int caracteres = cabecera != null && cabecera[col] != null
                    ? cabecera[col].length() : 0;
            if (datos != null) {
                for (String[] fila : datos) {
                    if (fila != null && col < fila.length && fila[col] != null) {
                        caracteres = Math.max(caracteres, fila[col].length());
                    }
                }
            }
            int ancho = Math.min((caracteres + plus) * 256, 255 * 256);
            if (ancho > hoja.getColumnWidth(col)) {
                hoja.setColumnWidth(col, ancho);
            }
        }
    }

    private static void setMoneda(Row row, int col, Object val, CellStyle style) {
        Cell cell = row.createCell(col);
        cell.setCellValue(toDouble(val));
        cell.setCellStyle(style);
    }

    private static double toDouble(Object val) {
        if (val == null) return 0.0;
        try { return Double.parseDouble(val.toString()); } catch (Exception e) { return 0.0; }
    }

    private static String str(Object val) {
        return val == null ? "" : val.toString();
    }

    private static List<Object> buildError(String msg) {
        return buildError(msg, false);
    }

    private static List<Object> archivoGenerado(String nombreArchivo) {
        List<Object> result = new ArrayList<>();
        result.add(nombreArchivo);
        return result;
    }

    private static List<Object> buildSinDatos(String msg) {
        return buildError(msg, true);
    }

    private static List<Object> buildError(String msg, boolean sinDatos) {
        List<Object> err = new ArrayList<>();
        Map<String, Object> json = new HashMap<>();
        json.put("error",    true);
        json.put("sinDatos", sinDatos);
        json.put("mssError", msg != null ? msg : "Error desconocido");
        err.add(json);
        return err;
    }

    private CellStyle estilo(Workbook libro, int size, boolean bold,
            IndexedColors bg, IndexedColors fg, HorizontalAlignment ha, VerticalAlignment va) {
        CellStyle cs = libro.createCellStyle();
        Font f = libro.createFont();
        f.setFontName("Calibri");
        f.setFontHeightInPoints((short) size);
        f.setBold(bold);
        f.setColor(fg.getIndex());
        if (bg != null) {
            cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            cs.setFillForegroundColor(bg.index);
        }
        cs.setFont(f);
        cs.setAlignment(ha);
        cs.setVerticalAlignment(va);
        return cs;
    }

    // ─── Cache helpers ────────────────────────────────────────────────────────

    private SQLServerDataTable buildPerfilTVP(List<Integer> perfiles) {
        try {
            SQLServerDataTable tvp = new SQLServerDataTable();
            tvp.setTvpName("dbo.ListInt");
            tvp.addColumnMetadata("IdTipoNotificacionCorreo", java.sql.Types.INTEGER);
            for (Integer id : perfiles) {
                tvp.addRow(id);
            }
            return tvp;
        } catch (com.microsoft.sqlserver.jdbc.SQLServerException e) {
            throw new RuntimeException("Error creando TVP IdPerfil: " + e.getMessage(), e);
        }
    }

    private boolean checkCobranzaCache(int idEmpresa, int idVigencia, int idVencida) {
        try {
            Integer ctrl = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM dbo.bf_CobranzaCache_Ctrl " +
                "WHERE ccIdEmpresa=? AND ccIdVigencia=? AND ccIdVencida=? " +
                "  AND ccEstado='VIGENTE' AND CAST(ccFecCalculo AS DATE)=CAST(GETDATE() AS DATE)",
                Integer.class, idEmpresa, idVigencia, idVencida);
            if (ctrl == null || ctrl == 0) return false;
            Integer datos = jdbcTemplate.queryForObject(
                "SELECT TOP 1 1 FROM dbo.bf_CobranzaCache_Concentrada " +
                "WHERE ccdIdEmpresa=? AND ccdIdVigencia=? AND ccdIdVencida=?",
                Integer.class, idEmpresa, idVigencia, idVencida);
            return datos != null;
        } catch (Exception e) {
            LOGGER.warn("checkCobranzaCache error: " + e.getMessage());
            return false;
        }
    }

    public int precalcularCobranzaEmpresa(
            int idEmpresa, int idVigencia, String fecIni, String fecFin,
            int idVencida, String empresa, String rutaBase) {
        debug("cache_mes_inicio", "idEmpresa=" + idEmpresa + " vigencia=" + idVigencia
            + " fecIni=" + fecIni + " fecFin=" + fecFin + " idVencida=" + idVencida);

        List<Integer> perfiles = new ArrayList<>();
        try {
            jdbcTemplate.queryForList(
                "SELECT DISTINCT PEIdPerfil FROM dbo.ff_Perfil "
                + "WHERE PEIdEmpresa=? AND PEIdEstatus=1 AND PEAdministrador=0 "
                + "ORDER BY PEIdPerfil",
                idEmpresa).forEach(r -> perfiles.add(((Number) r.get("PEIdPerfil")).intValue()));
        } catch (Exception ex) {
            debug("cache_perfiles_error", "idEmpresa=" + idEmpresa + " ex=" + ex.getMessage());
            return -1;
        }

        if (perfiles.isEmpty()) {
            debug("cache_perfiles_error", "idEmpresa=" + idEmpresa
                + " sin perfiles activos no administradores");
            return -1;
        }

        debug("cache_mes_sp_params", "EXEC PrecargaUniversoCobranzaVigencia_BF3_Cache"
            + " @idEmpresa=" + idEmpresa + ", @idVigencia=" + idVigencia
            + ", @Desde='" + fecIni + "', @Hasta='" + fecFin + "'"
            + ", @idSolTipo=1, @idVencida=" + idVencida + ", perfiles=" + perfiles);

        try {
            SimpleJdbcCall spCall = new SimpleJdbcCall(jdbcTemplate)
                    .withoutProcedureColumnMetaDataAccess()
                    .withProcedureName("PrecargaUniversoCobranzaVigencia_BF3_Cache")
                    .declareParameters(
                        new SqlParameter("idEmpresa",     java.sql.Types.INTEGER),
                        new SqlParameter("idVigencia",    java.sql.Types.INTEGER),
                        new SqlParameter("IdPerfil",      microsoft.sql.Types.STRUCTURED, "dbo.ListInt"),
                        new SqlParameter("Desde",         java.sql.Types.DATE),
                        new SqlParameter("Hasta",         java.sql.Types.DATE),
                        new SqlParameter("idSolTipo",     java.sql.Types.INTEGER),
                        new SqlParameter("idVencida",     java.sql.Types.INTEGER),
                        new SqlParameter("ForzarRecarga", java.sql.Types.BIT),
                        new SqlParameter("EmitirResultado", java.sql.Types.BIT)
                    );
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue("idEmpresa",     idEmpresa);
            params.addValue("idVigencia",    idVigencia);
            params.addValue("IdPerfil",      buildPerfilTVP(perfiles));
            params.addValue("Desde",         java.sql.Date.valueOf(fecIni.substring(0, 10)));
            params.addValue("Hasta",         java.sql.Date.valueOf(fecFin.substring(0, 10)));
            // La pantalla de Cobranza envia idSolTipo=1. Usar otra clave hace
            // que la precarga sea inutil para la solicitud interactiva.
            params.addValue("idSolTipo",     1);
            params.addValue("idVencida",     idVencida);
            params.addValue("ForzarRecarga", 0);
            params.addValue("EmitirResultado", 0);

            try {
                spCall.execute(params);
                debug("cache_mes_sp_ok", "idEmpresa=" + idEmpresa + " vigencia=" + idVigencia);
            } catch (Exception spEx) {
                debug("cache_mes_sp_error", "idEmpresa=" + idEmpresa + " vigencia=" + idVigencia
                    + " ex=" + spEx.getClass().getSimpleName() + ": " + spEx.getMessage());
                return -1;
            }
            return 1;
        } catch (Exception e) {
            LOGGER.error("precalcularCobranzaEmpresa error idEmpresa=" + idEmpresa + ": " + e.getMessage(), e);
            debug("cache_insert_error", "idEmpresa=" + idEmpresa + " vigencia=" + idVigencia
                + " ex=" + e.getClass().getSimpleName() + ": " + e.getMessage());
            return -1;
        }
    }

    private List<Object> generarExcelDesdeCache(
            String empresaNombre, int idEmpresa, String rutaBase,
            String FecIni, String FecFin, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email,
            int idVigencia, int idVencida, int bandera) {
        try {
            // Reconstruir los result-sets desde las 5 tablas de cache
            ArrayList<ArrayList<LinkedCaseInsensitiveMap>> lista = new ArrayList<>();
            for (String t : new String[]{
                    "bf_CobranzaCache_Concentrada", "bf_CobranzaCache_Desglosada",
                    "bf_CobranzaCache_TotCoberturas", "bf_CobranzaCache_TotCoberturasP",
                    "bf_CobranzaCache_PlanesParentesco"}) {
                ArrayList<LinkedCaseInsensitiveMap> rs = leerTablaCache(t, idEmpresa, idVigencia, idVencida);
                if (!rs.isEmpty()) lista.add(rs);
            }
            if (lista.isEmpty()) return buildError("Sin datos en cache para empresa " + idEmpresa);
            String fechaIni = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
            return generarExcel(lista, empresaNombre, idEmpresa, rutaBase,
                    FecIni, FecFin, idCorporativo, nomCorp, nomAdm, nomEmp, email,
                    fechaIni, idVigencia, bandera);
        } catch (Exception e) {
            LOGGER.error("generarExcelDesdeCache error: " + e.getMessage(), e);
            return buildError(e.getMessage());
        }
    }

    // ─── Helpers de cache ────────────────────────────────────────────────────

    // MERGE incremental: inserta nuevas, actualiza modificadas, elimina desaparecidas
    @SuppressWarnings("unchecked")
    private int insertarResultSet(int idEmpresa, int idVigencia, int idVencida,
                                   ArrayList<LinkedCaseInsensitiveMap> spRows) {
        if (spRows.isEmpty()) return 0;
        String primerCampo = String.valueOf(spRows.get(0).keySet().iterator().next());
        boolean tieneParentesco = spRows.get(0).containsKey("CVEParentesco");

        String tabla;
        if ("empresa".equals(primerCampo) || "NumEMpleado".equals(primerCampo)) {
            tabla = "bf_CobranzaCache_Concentrada";
        } else if ("EMPRESA".equals(primerCampo) || "NUMEMPLEADO".equals(primerCampo)) {
            tabla = "bf_CobranzaCache_Desglosada";
        } else if (("CVEP".equals(primerCampo) || "CVEPO".equals(primerCampo)) && tieneParentesco) {
            tabla = "bf_CobranzaCache_TotCoberturasP";
        } else if ("CVEP".equals(primerCampo) || "CVEPO".equals(primerCampo)) {
            tabla = "bf_CobranzaCache_TotCoberturas";
        } else if ("cvep".equals(primerCampo) || "cvepo".equals(primerCampo)) {
            tabla = "bf_CobranzaCache_PlanesParentesco";
        } else {
            return 0; // Banwire u otro result-set no cacheado
        }

        String[]     keyCols = CACHE_KEY_COLS.get(tabla);
        List<String> allCols = new ArrayList<>(spRows.get(0).keySet());

        // Cargar filas actuales del cache para comparar: clave natural -> {ccdId, firma de valores}
        Map<String, Object[]> existingByKey = new HashMap<>();
        try {
            for (Map<String, Object> row : jdbcTemplate.queryForList(
                    "SELECT * FROM dbo." + tabla +
                    " WHERE ccdIdEmpresa=? AND ccdIdVigencia=? AND ccdIdVencida=?",
                    idEmpresa, idVigencia, idVencida)) {
                LinkedCaseInsensitiveMap lcm = new LinkedCaseInsensitiveMap();
                lcm.putAll(row);
                existingByKey.put(cacheKey(lcm, keyCols),
                    new Object[]{row.get("ccdId"), cacheSig(lcm, allCols)});
            }
        } catch (Exception ignored) {}

        // Construir SQL dinámico
        StringBuilder colList   = new StringBuilder();
        StringBuilder phIns     = new StringBuilder();
        StringBuilder setClause = new StringBuilder();
        for (int i = 0; i < allCols.size(); i++) {
            if (i > 0) { colList.append(','); phIns.append(','); setClause.append(','); }
            colList.append('[').append(allCols.get(i)).append(']');
            phIns.append('?');
            setClause.append('[').append(allCols.get(i)).append("]=?");
        }
        String sqlIns = "INSERT INTO dbo." + tabla +
            " (ccdIdEmpresa,ccdIdVigencia,ccdIdVencida," + colList + ") VALUES (?,?,?," + phIns + ")";
        String sqlUpd = "UPDATE dbo." + tabla + " SET " + setClause + " WHERE ccdId=?";

        // Clasificar cada fila del SP: nueva / modificada / sin cambio
        List<Object[]> toInsert = new ArrayList<>();
        List<Object[]> toUpdate = new ArrayList<>();
        Set<String>    seen    = new HashSet<>();

        for (LinkedCaseInsensitiveMap spRow : spRows) {
            String key = cacheKey(spRow, keyCols);
            String sig = cacheSig(spRow, allCols);
            seen.add(key);
            Object[] existing = existingByKey.get(key);

            if (existing == null) {
                Object[] p = new Object[3 + allCols.size()];
                p[0] = idEmpresa; p[1] = idVigencia; p[2] = idVencida;
                for (int i = 0; i < allCols.size(); i++) {
                    Object v = spRow.get(allCols.get(i));
                    p[3 + i] = v != null ? String.valueOf(v) : null;
                }
                toInsert.add(p);
            } else if (!sig.equals(existing[1])) {
                // SET values + ccdId al final para WHERE ccdId=?
                Object[] p = new Object[allCols.size() + 1];
                for (int i = 0; i < allCols.size(); i++) {
                    Object v = spRow.get(allCols.get(i));
                    p[i] = v != null ? String.valueOf(v) : null;
                }
                p[allCols.size()] = existing[0];
                toUpdate.add(p);
            }
            // sin cambio → skip
        }

        // Filas que ya no devuelve el SP → eliminar
        List<Object> toDelete = new ArrayList<>();
        for (Map.Entry<String, Object[]> e : existingByKey.entrySet()) {
            if (!seen.contains(e.getKey())) toDelete.add(e.getValue()[0]);
        }

        try {
            if (!toInsert.isEmpty()) jdbcTemplate.batchUpdate(sqlIns, toInsert);
            if (!toUpdate.isEmpty()) jdbcTemplate.batchUpdate(sqlUpd, toUpdate);
            if (!toDelete.isEmpty()) {
                for (int i = 0; i < toDelete.size(); i += 500) {
                    List<Object> chunk = toDelete.subList(i, Math.min(i + 500, toDelete.size()));
                    StringBuilder delPh = new StringBuilder();
                    for (int j = 0; j < chunk.size(); j++) { if (j > 0) delPh.append(','); delPh.append('?'); }
                    jdbcTemplate.update("DELETE FROM dbo." + tabla + " WHERE ccdId IN (" + delPh + ")",
                        chunk.toArray());
                }
            }
            String label = tabla.replace("bf_CobranzaCache_", "");
            debug("cache_merge_" + label,
                "ins=" + toInsert.size() + " upd=" + toUpdate.size() + " del=" + toDelete.size()
                + " skip=" + (spRows.size() - toInsert.size() - toUpdate.size()));
            return toInsert.size() + toUpdate.size() + toDelete.size();
        } catch (Exception e) {
            debug("cache_insert_tabla_error", tabla + ": " + e.getMessage());
            return -1;
        }
    }

    private java.sql.Timestamp queryLastCacheDate(int idEmpresa, int idVigencia, int idVencida) {
        try {
            List<Map<String,Object>> rows = jdbcTemplate.queryForList(
                "SELECT TOP 1 ccFecCalculo FROM dbo.bf_CobranzaCache_Ctrl" +
                " WHERE ccIdEmpresa=? AND ccIdVigencia=? AND ccIdVencida=? AND ccEstado='VIGENTE'" +
                " ORDER BY ccFecCalculo DESC",
                idEmpresa, idVigencia, idVencida);
            if (rows.isEmpty() || rows.get(0).get("ccFecCalculo") == null) return null;
            Object v = rows.get(0).get("ccFecCalculo");
            if (v instanceof java.sql.Timestamp) return (java.sql.Timestamp) v;
            return java.sql.Timestamp.valueOf(v.toString());
        } catch (Exception e) {
            return null;
        }
    }

    private static String detectarTablaCache(List<LinkedCaseInsensitiveMap> rows) {
        if (rows == null || rows.isEmpty()) return null;
        String p = String.valueOf(rows.get(0).keySet().iterator().next());
        boolean tieneParentesco = rows.get(0).containsKey("CVEParentesco");
        if ("empresa".equals(p) || "NumEMpleado".equals(p))             return "bf_CobranzaCache_Concentrada";
        if ("EMPRESA".equals(p) || "NUMEMPLEADO".equals(p))             return "bf_CobranzaCache_Desglosada";
        if (("CVEP".equals(p) || "CVEPO".equals(p)) && tieneParentesco) return "bf_CobranzaCache_TotCoberturasP";
        if ("CVEP".equals(p) || "CVEPO".equals(p))                      return "bf_CobranzaCache_TotCoberturas";
        if ("cvep".equals(p) || "cvepo".equals(p))                      return "bf_CobranzaCache_PlanesParentesco";
        return null;
    }

    private static ArrayList<LinkedCaseInsensitiveMap> filtrarFilasTotales(
            ArrayList<LinkedCaseInsensitiveMap> rows) {
        if (rows == null || rows.isEmpty()) return rows;
        String firstKey = String.valueOf(rows.get(0).keySet().iterator().next());
        ArrayList<LinkedCaseInsensitiveMap> result = new ArrayList<>();
        for (LinkedCaseInsensitiveMap row : rows) {
            Object val = row.get(firstKey);
            String s = val != null ? val.toString() : "";
            if (s.startsWith("TOTALES") || s.startsWith("T O T A L") || "10000".equals(s)) continue;
            result.add(row);
        }
        return result;
    }

    private void recalcularTotalesDesdeCache(int idEmpresa, int idVigencia, int idVencida) {
        try {
            Object[] w = {idEmpresa, idVigencia, idVencida};
            String wc  = " WHERE ccdIdEmpresa=? AND ccdIdVigencia=? AND ccdIdVencida=?";
            String src = " FROM dbo.bf_CobranzaCache_Desglosada" + wc
                       + " AND ISNULL(NUMEMPLEADO,'') NOT LIKE 'T O T A L%'";

            jdbcTemplate.update("DELETE FROM dbo.bf_CobranzaCache_TotCoberturas" + wc, w);
            jdbcTemplate.update(
                "INSERT INTO dbo.bf_CobranzaCache_TotCoberturas" +
                " (ccdIdEmpresa,ccdIdVigencia,ccdIdVencida,CVEP,CVEPO,PlanD,ImpPer,ImpPN,ImpEmpresa,ImpEmpleado,ImpEmpExced,ImpEmpReal,ImpExced)" +
                " SELECT ?,?,?,CVEP,'0',PlanD," +
                " CAST(ROUND(SUM(TRY_CAST(ImportexPeriodo       AS DECIMAL(18,4))),2) AS NVARCHAR)," +
                " CAST(ROUND(SUM(TRY_CAST(PrimaNetaxPer         AS DECIMAL(18,4))),2) AS NVARCHAR)," +
                " CAST(ROUND(SUM(TRY_CAST(CostoEmpresa          AS DECIMAL(18,4))),2) AS NVARCHAR)," +
                " CAST(ROUND(SUM(TRY_CAST(CostoEmpleado         AS DECIMAL(18,4))),2) AS NVARCHAR)," +
                " CAST(ROUND(SUM(TRY_CAST(CostoEmpleadoExcedente AS DECIMAL(18,4))),2) AS NVARCHAR)," +
                " CAST(ROUND(SUM(TRY_CAST(CostoEmpleadoReal      AS DECIMAL(18,4))),2) AS NVARCHAR)," +
                " CAST(ROUND(SUM(TRY_CAST(SobranteExcedentes     AS DECIMAL(18,4))),2) AS NVARCHAR)" +
                src + " GROUP BY CVEP, PlanD",
                idEmpresa, idVigencia, idVencida, idEmpresa, idVigencia, idVencida);

            jdbcTemplate.update("DELETE FROM dbo.bf_CobranzaCache_TotCoberturasP" + wc, w);
            jdbcTemplate.update(
                "INSERT INTO dbo.bf_CobranzaCache_TotCoberturasP" +
                " (ccdIdEmpresa,ccdIdVigencia,ccdIdVencida,CVEP,CVEPO,PlanD,CVEParentesco,total)" +
                " SELECT ?,?,?,CVEP,CVEPO,PlanOpcion,CVEParentesco,CAST(COUNT(*) AS NVARCHAR)" +
                src + " GROUP BY CVEP,CVEPO,PlanOpcion,CVEParentesco",
                idEmpresa, idVigencia, idVencida, idEmpresa, idVigencia, idVencida);

            jdbcTemplate.update("DELETE FROM dbo.bf_CobranzaCache_PlanesParentesco" + wc, w);
            jdbcTemplate.update(
                "INSERT INTO dbo.bf_CobranzaCache_PlanesParentesco" +
                " (ccdIdEmpresa,ccdIdVigencia,ccdIdVencida,cvep,cvepo,planD,planopcion," +
                "  Parentesco_1,Parentesco_2,Parentesco_3,Parentesco_4,Parentesco_5,Parentesco_11,Parentesco_17,Parentesco_18)" +
                " SELECT ?,?,?,CVEP,CVEPO,PlanD,PlanOpcion," +
                " CAST(SUM(CASE WHEN CVEParentesco='1'  THEN 1 ELSE 0 END) AS NVARCHAR)," +
                " CAST(SUM(CASE WHEN CVEParentesco='2'  THEN 1 ELSE 0 END) AS NVARCHAR)," +
                " CAST(SUM(CASE WHEN CVEParentesco='3'  THEN 1 ELSE 0 END) AS NVARCHAR)," +
                " CAST(SUM(CASE WHEN CVEParentesco='4'  THEN 1 ELSE 0 END) AS NVARCHAR)," +
                " CAST(SUM(CASE WHEN CVEParentesco='5'  THEN 1 ELSE 0 END) AS NVARCHAR)," +
                " CAST(SUM(CASE WHEN CVEParentesco='11' THEN 1 ELSE 0 END) AS NVARCHAR)," +
                " CAST(SUM(CASE WHEN CVEParentesco='17' THEN 1 ELSE 0 END) AS NVARCHAR)," +
                " CAST(SUM(CASE WHEN CVEParentesco='18' THEN 1 ELSE 0 END) AS NVARCHAR)" +
                src + " GROUP BY CVEP,CVEPO,PlanD,PlanOpcion",
                idEmpresa, idVigencia, idVencida, idEmpresa, idVigencia, idVencida);

            debug("cache_recalc_totales", "idEmpresa=" + idEmpresa + " vigencia=" + idVigencia);
        } catch (Exception e) {
            debug("cache_recalc_error", "idEmpresa=" + idEmpresa + ": " + e.getMessage());
        }
    }

    private static String cacheKey(Map<?, ?> row, String[] keyCols) {
        StringBuilder sb = new StringBuilder();
        for (String k : keyCols) { Object v = row.get(k); sb.append(v != null ? v : "").append('\u0000'); }
        return sb.toString();
    }

    private static String cacheSig(Map<?, ?> row, List<String> cols) {
        StringBuilder sb = new StringBuilder();
        for (String c : cols) { Object v = row.get(c); sb.append(v != null ? v : "").append('\u0001'); }
        return sb.toString();
    }

    // Lee filas de una tabla de cache; excluye columnas meta ccd* para reconstruir el result-set
    @SuppressWarnings("unchecked")
    private ArrayList<LinkedCaseInsensitiveMap> leerTablaCache(
            String tabla, int idEmpresa, int idVigencia, int idVencida) {
        try {
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT * FROM dbo." + tabla +
                " WHERE ccdIdEmpresa=? AND ccdIdVigencia=? AND ccdIdVencida=? ORDER BY ccdId",
                idEmpresa, idVigencia, idVencida);
            ArrayList<LinkedCaseInsensitiveMap> result = new ArrayList<>();
            for (Map<String, Object> row : rows) {
                LinkedCaseInsensitiveMap lcm = new LinkedCaseInsensitiveMap();
                for (Map.Entry<String, Object> e : row.entrySet()) {
                    if (!e.getKey().startsWith("ccd"))
                        lcm.put(e.getKey(), e.getValue() != null ? String.valueOf(e.getValue()) : "");
                }
                result.add(lcm);
            }
            return result;
        } catch (Exception e) {
            LOGGER.warn("leerTablaCache " + tabla + ": " + e.getMessage());
            return new ArrayList<>();
        }
    }

    // ─── Inner types ──────────────────────────────────────────────────────────

    private static class Periodicidad {
        String periodicidad   = "";
        int    catidadPagos   = 0;
    }
}
