**Asunto:** Ajuste aislado y con fallback para convivencia BF2/BF3 de Deloitte

Hola equipo,

Se preparó un ajuste acotado al procesamiento de carga masiva de Deloitte para permitir la convivencia de sus formatos BF2 y BF3.

La funcionalidad nueva sólo se evalúa cuando la autenticación identifica a la empresa interna 186 (Deloitte) y la operación es la 2. Para todas las demás empresas, el servicio continúa directamente por el flujo existente, sin consultar las plantillas de Deloitte ni alterar su configuración.

Para Deloitte, el servicio intenta seleccionar la ruta antes de construir los parámetros y antes de ejecutar cualquier procedimiento de negocio:

- 32 posiciones: plantilla 507 / `ff_XCMTitularesAltaCMDeloitte`.
- 23 posiciones: plantilla 12062 / `ff_XCMTitularesAltaCMM_BF3`.

La selección fue encapsulada como una mejora opcional. Si ocurre una excepción al consultar o evaluar las plantillas, falta una configuración, existe una duplicidad o el conteo no permite determinar una ruta única, la excepción no se propaga al endpoint. En ese caso se conserva la configuración que ya había obtenido el código anterior y la petición continúa por el flujo histórico.

Con esto se protege la disponibilidad del SOAP: una falla en la lógica nueva no detiene el servicio ni afecta a las demás empresas. El parser y las validaciones existentes permanecen activos en el flujo anterior.

La funcionalidad agregada no escribe nuevos mensajes de Debug ni agrega bitácoras. Los mensajes Debug que todavía aparecen en la clase pertenecen al código histórico y no fueron modificados, para evitar ampliar el alcance del cambio.

No se modifican el WSDL, los métodos públicos, los parámetros, los tipos de respuesta, `Web.config`, Java ni objetos de base de datos. El único archivo fuente modificado es `Administracion/CargaMasivaProcess.cs`. Para publicarlo debe recompilarse y desplegarse de manera controlada `bin\ServiciosLocktonTI.dll`, después de compararla contra la DLL que actualmente atiende el SOAP.

Las pruebas técnicas realizadas comprobaron:

1. 32 posiciones seleccionan la configuración BF2.
2. 23 posiciones seleccionan la configuración BF3.
3. Un conteo no reconocido conserva el flujo anterior.
4. Una excepción simulada en el selector no sale hacia el SOAP y conserva el flujo anterior.
5. Una empresa diferente de Deloitte no entra al selector ni consulta sus plantillas.

Es importante señalar que el fallback prioriza conservar la funcionalidad histórica. Si se activa, la petición tendrá exactamente las mismas posibilidades y validaciones que tenía antes del ajuste; por eso se recomienda mantener correctas y activas las dos configuraciones de Deloitte y homologar ambos formatos antes de producción.

Saludos.
