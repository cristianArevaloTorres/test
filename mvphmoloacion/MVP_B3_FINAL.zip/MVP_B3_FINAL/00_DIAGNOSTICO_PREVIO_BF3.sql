/*
  DIAGNOSTICO PREVIO - HOMOLOGACION MVP B3
  Sólo lectura. No crea, modifica ni elimina datos.

  Comprueba la cascada real de B3, los modelos 2494/2493 y la lista recibida.
*/
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;

DECLARE @IdEmpresaModelo INT = 2494;
DECLARE @IdCorporativoModelo INT = 2493;

DECLARE @Corporativos TABLE (
    IdCorporativo INT PRIMARY KEY,
    Grupo VARCHAR(30),
    RazonSocialEsperada VARCHAR(200)
);

INSERT INTO @Corporativos VALUES
(495,'HAPAG','Hapag Lloyd'),
(531,'GN102','GN102 S.A. DE C.V.'),
(658,'GCABLE','SERVICIOS LATINOAMERICANOS GC SA DE CV'),
(698,'TORRENT','LABORATORIOS TORRENT SA DE CV'),
(718,'UNICCO','UNION DE CREDITO PARA LA CONTADURIA PUBLICA, S.A. DE C.V.C'),
(721,'CCPM','COLEGIO DE CONTADORES PUBLICOS DE MEXICO, A.C.C'),
(723,'SCHNEIDER','SCHNEIDER NATIONAL DE MEXICO SA DE CVC'),
(725,'IMCP','INSTITUTO MEXICANO DE CONTADORES PUBLICOS A.C.C'),
(727,'BIOMETC','BIOMET MEXICO SA DE CVC'),
(752,'GEPC','GEP DE MEXICO S DE RL DE CVC'),
(756,'LOEFFLERC','LOEFFLER, S.A. DE C.V.C'),
(758,'AMCHAM','AMERICAN CHAMBER OF COMMERCE OF MEXICO ACC'),
(760,'IMEFC','INSTITUTO MEXICANO DE EJECUTIVOS DE FINANZAS ACC'),
(762,'PRV','PRIETO RUIZ DE VELASCO Y CIA SCC'),
(790,'MELTSANC','MELTSAN SOLUTIONS S.A DE C.V.C'),
(797,'CLYPC','CREACION LANZAMIENTO Y PROMOCION SA DE CVC'),
(799,'VITOLC','RECURSOS ADMINISTRATIVOS Y DE PERSONAL RIO BRAVO, S. DE DE C.V.'),
(806,'SGWIC','SGWI GRUPO MEXICO SA DE CVC'),
(812,'DE LA VEGA','DE LA VEGA & MARTINEZ ROJAS SC'),
(814,'CONSTRUMACC','CONSTRUMAC, S.A.P.I. DE CVC');

SELECT '00_AMBIENTE' Bloque, @@SERVERNAME Servidor, DB_NAME() BaseDatos,
       ORIGINAL_LOGIN() LoginSql, GETDATE() FechaRevision,
       @IdEmpresaModelo EmpresaModelo, @IdCorporativoModelo CorporativoModelo;

DECLARE @Objetos TABLE (Objeto SYSNAME, Tipo CHAR(2));
INSERT INTO @Objetos VALUES
('dbo.bf_BitacoraEmpresa','U'),('dbo.bf_EmpresaMVP','U'),
('dbo.bf_ProcesoMVP','P'),('dbo.sp_CopiarRolesEmpresa','P'),
('dbo.sp_CopiarPerfilesEmpresa','P'),('dbo.sp_CopiarMenusEmpresa','P'),
('dbo.sp_CopiarImagenesEmpresa','P'),('dbo.sp_CopiarColoresEmpresa','P'),
('dbo.sp_CopiarDocumentosEmpresa','P'),('dbo.sp_CopiarPlanesEmpresa','P'),
('dbo.sp_CopiarParametrosEmpresa','P'),('dbo.sp_CopiarAccesoBeflex','P'),
('dbo.sp_CopiarBeflexInicio2','P'),('dbo.sp_CopiarConfiguracionEmpresa','P'),
('dbo.sp_CopiarPlantillasMVP','P'),('dbo.sp_CopiarReporteInterfabricaMVP','P'),
('dbo.sp_CopiarMenusV2_MVP','P'),('dbo.sp_CopiarCargaMasiva_MVP','P'),
('dbo.sp_CopiarParametroMismoSexo_MVP','P');

SELECT '01_OBJETOS_B3' Bloque, Objeto,
       CASE WHEN OBJECT_ID(Objeto, Tipo) IS NULL THEN 'FALTA' ELSE 'OK' END Resultado
FROM @Objetos ORDER BY Objeto;

SELECT '02_FIRMA_BF_PROCESOMVP' Bloque, p.parameter_id, p.name Parametro,
       TYPE_NAME(p.user_type_id) Tipo, p.is_output,
       CASE
           WHEN p.parameter_id = 1 AND p.name = '@idEmpresa' THEN 'OK'
           WHEN p.parameter_id = 2 AND p.name = '@Usuario' THEN 'OK'
           WHEN p.parameter_id = 3 AND p.name = '@ModeloOrigen' THEN 'OK'
           WHEN p.parameter_id = 4 AND p.name = '@ModeloCorp' THEN 'OK'
           ELSE 'REVISAR FIRMA'
       END Resultado
FROM sys.parameters p
WHERE p.object_id = OBJECT_ID('dbo.bf_ProcesoMVP')
ORDER BY p.parameter_id;

SELECT '03_MODELOS' Bloque, e.EMidEmpresa, e.EMidCorporativo, e.EMRazonSocial, e.EMidEstatus,
       CASE
           WHEN e.EMidEmpresa IS NULL THEN 'FALTA'
           WHEN e.EMidEstatus <> 1 THEN 'INACTIVO'
           WHEN e.EMidEmpresa = @IdEmpresaModelo AND e.EMidCorporativo <> @IdCorporativoModelo THEN 'RELACION MODELO INCORRECTA'
           ELSE 'OK'
       END Resultado
FROM (VALUES (@IdCorporativoModelo),(@IdEmpresaModelo)) m(Id)
LEFT JOIN dbo.ff_Empresa e ON e.EMidEmpresa = m.Id;

SELECT '04_CONTENIDO_MODELO' Bloque, @IdEmpresaModelo IdEmpresaModelo,
       (SELECT COUNT(*) FROM dbo.ff_Rol WHERE ROIdEmpresa=@IdEmpresaModelo AND ROIdEstatus=1) Roles,
       (SELECT COUNT(*) FROM dbo.ff_Perfil WHERE PEIdEmpresa=@IdEmpresaModelo AND PEIdEstatus=1) Perfiles,
       (SELECT COUNT(*) FROM dbo.ff_EmpresaImagen WHERE EIIdEmpresa=@IdEmpresaModelo) Imagenes,
       (SELECT COUNT(*) FROM dbo.ff_Parametro WHERE paIdEmpresa=@IdEmpresaModelo AND paidEstatus=1) Parametros,
       (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1 AND CEIdOperacion IN (1,2,3,13,14)) OperacionesCarga,
       CASE WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro WHERE paIdEmpresa IN (@IdEmpresaModelo,@IdCorporativoModelo) AND paId=226 AND paidEstatus=1 AND NULLIF(LTRIM(RTRIM(paValor)),'') IS NOT NULL)
            THEN 'OK' ELSE 'FALTA AVISO 226' END AvisoPrivacidad;

SELECT '05_PRERREQUISITOS_CARGA' Bloque, x.Elemento,
       CASE WHEN x.Tipo='P' AND OBJECT_ID('dbo.'+x.Elemento,'P') IS NOT NULL THEN 'OK'
            WHEN x.Tipo='PL' AND EXISTS (SELECT 1 FROM dbo.ff_Plantilla WHERE PLIdPlantilla=x.Id AND PLIdEstatus=1) THEN 'OK'
            ELSE 'FALTA' END Resultado
FROM (VALUES
('ff_XCMDependientesAltaCMM','P',NULL),
('ff_XCMTitularesAltaCMM_BF3','P',NULL),
('ff_XCMAseguradosBaja_Base','P',NULL),
('Plantilla 12061','PL',12061),('Plantilla 12062','PL',12062),('Plantilla 154','PL',154)
) x(Elemento,Tipo,Id);

SELECT '06_CORPORATIVOS_RECIBIDOS' Bloque, c.IdCorporativo, c.Grupo,
       c.RazonSocialEsperada, corp.EMRazonSocial RazonSocialBD, corp.EMidEstatus,
       SUM(CASE WHEN hija.EMidEmpresa<>c.IdCorporativo AND hija.EMidEstatus=1 THEN 1 ELSE 0 END) HijasActivas,
       CASE
           WHEN corp.EMidEmpresa IS NULL THEN 'FALTA CORPORATIVO'
           WHEN corp.EMidEstatus<>1 THEN 'CORPORATIVO INACTIVO'
           WHEN SUM(CASE WHEN hija.EMidEmpresa<>c.IdCorporativo AND hija.EMidEstatus=1 THEN 1 ELSE 0 END)=0 THEN 'SIN EMPRESA HIJA ACTIVA'
           WHEN UPPER(LTRIM(RTRIM(ISNULL(corp.EMRazonSocial,''))))<>UPPER(LTRIM(RTRIM(c.RazonSocialEsperada))) THEN 'REVISAR NOMBRE'
           ELSE 'OK'
       END Resultado
FROM @Corporativos c
LEFT JOIN dbo.ff_Empresa corp ON corp.EMidEmpresa=c.IdCorporativo
LEFT JOIN dbo.ff_Empresa hija ON hija.EMidCorporativo=c.IdCorporativo
GROUP BY c.IdCorporativo,c.Grupo,c.RazonSocialEsperada,corp.EMidEmpresa,corp.EMRazonSocial,corp.EMidEstatus
ORDER BY c.IdCorporativo;

SELECT '07_EMPRESAS_HIJA_OBJETIVO' Bloque, c.IdCorporativo, c.Grupo,
       e.EMidEmpresa IdEmpresaObjetivo, e.EMRazonSocial, e.EMNombre, e.EMidEstatus,
       CASE WHEN e.EMidEmpresa=496 AND c.IdCorporativo=495 THEN 'PILOTO PROPUESTO' ELSE 'MASIVO DESHABILITADO' END Etapa
FROM @Corporativos c
JOIN dbo.ff_Empresa e ON e.EMidCorporativo=c.IdCorporativo
WHERE e.EMidEmpresa<>c.IdCorporativo AND e.EMidEstatus=1
ORDER BY c.IdCorporativo,e.EMidEmpresa;

SELECT '08_RESUMEN' Bloque,
       (SELECT COUNT(*) FROM @Corporativos) CorporativosRecibidos,
       (SELECT COUNT(*) FROM @Corporativos c JOIN dbo.ff_Empresa e ON e.EMidCorporativo=c.IdCorporativo WHERE e.EMidEmpresa<>c.IdCorporativo AND e.EMidEstatus=1) EmpresasHijaActivas,
       (SELECT COUNT(*) FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL) ObjetosFaltantes,
       CASE WHEN EXISTS (SELECT 1 FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL) THEN 'NO EJECUTAR'
            WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdEmpresaModelo AND EMidCorporativo=@IdCorporativoModelo AND EMidEstatus=1) THEN 'NO EJECUTAR'
            WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_Rol WHERE ROIdEmpresa=@IdEmpresaModelo AND ROIdEstatus=1) THEN 'NO EJECUTAR: MODELO SIN ROLES'
            WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_Perfil WHERE PEIdEmpresa=@IdEmpresaModelo AND PEIdEstatus=1) THEN 'NO EJECUTAR: MODELO SIN PERFILES'
            WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_EmpresaImagen WHERE EIIdEmpresa=@IdEmpresaModelo) THEN 'NO EJECUTAR: MODELO SIN IMAGENES'
            WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_Parametro WHERE paIdEmpresa=@IdEmpresaModelo AND paidEstatus=1) THEN 'NO EJECUTAR: MODELO SIN PARAMETROS'
            WHEN (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1 AND CEIdOperacion IN (1,2,3,13,14))<>5 THEN 'NO EJECUTAR: MODELO SIN 5 OPERACIONES DE CARGA'
            WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_Parametro WHERE paIdEmpresa IN (@IdEmpresaModelo,@IdCorporativoModelo) AND paId=226 AND paidEstatus=1 AND NULLIF(LTRIM(RTRIM(paValor)),'') IS NOT NULL) THEN 'NO EJECUTAR: SIN AVISO 226'
            ELSE 'CONTINUAR CON PILOTO' END Dictamen;
GO
