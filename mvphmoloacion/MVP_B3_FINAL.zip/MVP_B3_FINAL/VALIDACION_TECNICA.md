# Validación técnica del paquete

Fecha: 11/09/2026.

- Lista importada: 20 corporativos.
- Resolución en la copia local: 23 empresas hijas activas.
- Piloto identificado localmente: corporativo `495`, empresa `496`.
- Objetos exigidos por la cascada: 19.
- Scripts SQL analizados sintácticamente: 5 de 5 correctos.
- Diagnósticos ejecutados en modo sólo lectura: 3 de 3 correctos.
- Ejecutables probados con `PARSEONLY`: 2 de 2 correctos.
- Ejecuciones de homologación realizadas durante la validación: 0.

## Observación bloqueante local

La empresa modelo local `2494` existe bajo el corporativo `2493`, pero no contiene todos los insumos requeridos. Por diseño, el nuevo diagnóstico la clasifica como incompleta y los scripts de aplicación se detienen. En el ambiente objetivo debe ejecutarse `00_DIAGNOSTICO_PREVIO_BF3.sql`; sólo un dictamen `CONTINUAR CON PILOTO` permite seguir.

## Evidencia funcional usada

- La definición de `ff_AddEmpresa` ejecuta `bf_ProcesoMVP` cuando `@EM_MVP=1` y después inserta la marca `bf_EmpresaMVP`.
- La definición local de `bf_ProcesoMVP` acepta `@idEmpresa`, `@Usuario`, `@ModeloOrigen` y `@ModeloCorp` y orquesta la cascada completa.
- El diagnóstico recibido enumera la misma familia de objetos y señala `2494/2493` como modelos.
- `99_VALIDACION_EMPRESAS_MVP.sql` confirma como resultado esperado las cinco operaciones de carga masiva y las tres plantillas de pantalla MVP.
