/*
  PILOTO MVP B3 - HAPAG

  La ejecución está desactivada. Primero capture @IdUsuario y revise el modo simulación.
  Este script llama la misma cascada bf_ProcesoMVP usada por ff_AddEmpresa con @EM_MVP=1.
*/
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
/* Igual que la llamada de ff_AddEmpresa: sin XACT_ABORT ni transacción exterior. */
SET XACT_ABORT OFF;

DECLARE @Aplicar BIT = 0;             -- CAMBIAR A 1 sólo con respaldo y aprobación.
DECLARE @IdUsuario INT = NULL;        -- OBLIGATORIO: administrador responsable.
DECLARE @IdCorporativoPiloto INT = 495;
DECLARE @IdEmpresaPiloto INT = 496;
DECLARE @IdEmpresaModelo INT = 2494;
DECLARE @IdCorporativoModelo INT = 2493;

SELECT 'PILOTO' Bloque, @Aplicar Aplicar, @IdUsuario IdUsuario,
       corp.EMidEmpresa IdCorporativo, corp.EMRazonSocial Corporativo,
       emp.EMidEmpresa IdEmpresa, emp.EMRazonSocial Empresa,
       @IdEmpresaModelo EmpresaModelo, @IdCorporativoModelo CorporativoModelo
FROM dbo.ff_Empresa corp
LEFT JOIN dbo.ff_Empresa emp ON emp.EMidEmpresa=@IdEmpresaPiloto
WHERE corp.EMidEmpresa=@IdCorporativoPiloto;

IF DB_NAME() <> 'FlexiForbesv2'
    THROW 51000, 'Base incorrecta. Debe ejecutarse en FlexiForbesv2.', 1;

DECLARE @Objetos TABLE (Objeto SYSNAME,Tipo CHAR(2));
INSERT @Objetos VALUES
('dbo.bf_BitacoraEmpresa','U'),('dbo.bf_EmpresaMVP','U'),
('dbo.bf_ProcesoMVP','P'),('dbo.sp_CopiarRolesEmpresa','P'),('dbo.sp_CopiarPerfilesEmpresa','P'),
('dbo.sp_CopiarMenusEmpresa','P'),('dbo.sp_CopiarImagenesEmpresa','P'),('dbo.sp_CopiarColoresEmpresa','P'),
('dbo.sp_CopiarDocumentosEmpresa','P'),('dbo.sp_CopiarPlanesEmpresa','P'),('dbo.sp_CopiarParametrosEmpresa','P'),
('dbo.sp_CopiarAccesoBeflex','P'),('dbo.sp_CopiarBeflexInicio2','P'),('dbo.sp_CopiarConfiguracionEmpresa','P'),
('dbo.sp_CopiarPlantillasMVP','P'),('dbo.sp_CopiarReporteInterfabricaMVP','P'),('dbo.sp_CopiarMenusV2_MVP','P'),
('dbo.sp_CopiarCargaMasiva_MVP','P'),('dbo.sp_CopiarParametroMismoSexo_MVP','P');
IF EXISTS (SELECT 1 FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL)
    THROW 51000, 'Faltan objetos de la cascada completa MVP B3. Ejecute primero el diagnóstico 00.', 1;

IF (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP')) <> 4
   OR NOT EXISTS (SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP') AND name='@ModeloOrigen')
   OR NOT EXISTS (SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP') AND name='@ModeloCorp')
    THROW 51000, 'La firma de bf_ProcesoMVP no corresponde a la cascada B3 validada.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdEmpresaModelo AND EMidCorporativo=@IdCorporativoModelo AND EMidEstatus=1)
    THROW 51000, 'La empresa modelo 2494 no existe, está inactiva o no pertenece al corporativo modelo 2493.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdCorporativoModelo AND EMidEstatus=1)
    THROW 51000, 'El corporativo modelo 2493 no existe o está inactivo.', 1;

/* La empresa 2494/2493 es obligatoria según la indicación recibida.
   Los conteos vacíos se reportan en el diagnóstico 00, pero no bloquean esta llamada. */

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Rol WHERE ROIdRol=7365 AND ROIdEstatus=1)
    THROW 51000, 'Falta el rol modelo V2 7365 requerido por sp_CopiarMenusV2_MVP.', 1;

IF EXISTS (
    SELECT 1 FROM (VALUES (13),(15),(17),(154),(689),(12061),(12062)) p(IdPlantilla)
    WHERE NOT EXISTS (SELECT 1 FROM dbo.ff_Plantilla x WHERE x.PLIdPlantilla=p.IdPlantilla AND x.PLIdEstatus=1)
)
    THROW 51000, 'Falta una plantilla fija requerida: 13, 15, 17, 154, 689, 12061 o 12062.', 1;

IF (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
    WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1 AND CEIdOperacion IN (1,2,3,13,14))<>5
    THROW 51000, 'La empresa modelo 2494 no tiene las cinco operaciones de carga 1,2,3,13,14.', 1;

/* Fuente comprobada para reparar el aviso de privacidad. La cascada anterior
   permitia continuar aunque el INSERT...SELECT de paId=226 no encontrara origen. */
IF OBJECT_ID('tempdb..#FuenteAviso226') IS NOT NULL DROP TABLE #FuenteAviso226;
SELECT TOP (1)
       p.paId,p.paClase,p.paValor,p.paDescripcion,p.paidEstatus,p.paUsuarioPerfil
INTO #FuenteAviso226
FROM dbo.ff_Parametro p
WHERE p.paId=226
  AND p.paIdEmpresa IN (@IdCorporativoModelo,@IdEmpresaModelo)
  AND p.paidEstatus=1
  AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
ORDER BY CASE WHEN p.paIdEmpresa=@IdCorporativoModelo THEN 0 ELSE 1 END;

IF NOT EXISTS (SELECT 1 FROM #FuenteAviso226)
    THROW 51000, 'No existe una fuente valida para paId=226 en el corporativo o empresa modelo.', 1;

/* Contrato final de carga masiva. Se usa tambien para corregir operaciones
   preexistentes; sp_CopiarCargaMasiva_MVP solo inserta las que no existen. */
DECLARE @CargaEsperada TABLE (
    IdOperacion INT PRIMARY KEY,
    IdPlantilla INT NOT NULL,
    StoredProc VARCHAR(250) NOT NULL,
    StoredProcAtributos INT NOT NULL
);

IF (SELECT COUNT(DISTINCT CEIdOperacion)
    FROM dbo.ff_CargaMasivaOperacionEmpresa
    WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1
      AND CEIdOperacion IN (1,2,3,13,14))<>5
   OR EXISTS (
       SELECT CEIdOperacion
       FROM dbo.ff_CargaMasivaOperacionEmpresa
       WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1
         AND CEIdOperacion IN (1,2,3,13,14)
       GROUP BY CEIdOperacion HAVING COUNT(*)<>1
   )
    THROW 51000, 'La configuracion modelo de carga masiva no es unica para las operaciones 1,2,3,13,14.', 1;

INSERT INTO @CargaEsperada (IdOperacion,IdPlantilla,StoredProc,StoredProcAtributos)
SELECT src.CEIdOperacion,
       CASE src.CEIdOperacion WHEN 1 THEN 12061 WHEN 2 THEN 12062 WHEN 3 THEN 154 ELSE src.CEIdPlantilla END,
       CASE src.CEIdOperacion
            WHEN 1 THEN 'ff_XCMDependientesAltaCMM'
            WHEN 2 THEN 'ff_XCMTitularesAltaCMM_BF3'
            WHEN 3 THEN 'ff_XCMAseguradosBaja_Base'
            ELSE src.CEStoredProc END,
       src.CEStoredProcAtributos
FROM dbo.ff_CargaMasivaOperacionEmpresa src
WHERE src.CEIdEmpresa=@IdEmpresaModelo AND src.CEIdEstatus=1
  AND src.CEIdOperacion IN (1,2,3,13,14);

IF NOT EXISTS (
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMidEmpresa=@IdEmpresaPiloto AND EMidCorporativo=@IdCorporativoPiloto
      AND EMidEmpresa<>EMidCorporativo AND EMidEstatus=1
)
    THROW 51000, 'La empresa piloto 496 no es una empresa hija activa del corporativo 495.', 1;

IF (SELECT COUNT(*) FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresaPiloto) > 1
    THROW 51000, 'La empresa piloto tiene marcas MVP duplicadas; corregir antes de continuar.', 1;

IF @Aplicar=0
BEGIN
    PRINT 'SIMULACION: no se modificó información. Capture @IdUsuario y cambie @Aplicar a 1 para ejecutar el piloto.';
    RETURN;
END;

IF @IdUsuario IS NULL OR @IdUsuario<=0
    THROW 51000, 'Debe capturar @IdUsuario antes de aplicar.', 1;

BEGIN TRY
    EXEC dbo.bf_ProcesoMVP
        @idEmpresa=@IdEmpresaPiloto,
        @Usuario=@IdUsuario,
        @ModeloOrigen=@IdEmpresaModelo,
        @ModeloCorp=@IdCorporativoModelo;

    /* La cascada historica confirma ejecucion, pero algunos SP son solamente
       INSERT-if-not-exists. Esta transaccion repara y comprueba el estado real. */
    BEGIN TRANSACTION;

    DECLARE @AdminPerfilNuevo INT,@AdminRolNuevo INT;
    DECLARE @AdminRefsCorregidas INT=0,@CargaDesactivadas INT=0,
            @CargaActualizadas INT=0,@CargaInsertadas INT=0,@AvisosCorregidos INT=0;

    SELECT TOP (1)
           @AdminPerfilNuevo=p.PEIdPerfil,
           @AdminRolNuevo=p.PEIdRolDefault
    FROM dbo.ff_Perfil p
    INNER JOIN dbo.ff_Rol r
      ON r.ROIdRol=p.PEIdRolDefault
     AND r.ROIdEmpresa=p.PEIdEmpresa
     AND r.ROIdEstatus=1
    WHERE p.PEIdEmpresa=@IdEmpresaPiloto
      AND p.PEAdministrador=1
      AND p.PEIdEstatus=1
    ORDER BY CASE WHEN p.PENombre='Administrador' THEN 0 ELSE 1 END,p.PEIdPerfil;

    IF @AdminPerfilNuevo IS NULL OR @AdminRolNuevo IS NULL
        THROW 51000, 'No existe un perfil Administrador con rol vigente en la empresa piloto.', 1;

    UPDATE ae
       SET ae.AEIdPerfil=@AdminPerfilNuevo,
           ae.AEIdRol=@AdminRolNuevo,
           ae.AEUsuarioUMod=@IdUsuario,
           ae.AEFechaUMod=GETDATE()
    FROM dbo.ff_AdministradorEmpresa ae
    WHERE ae.AEIdEmpresa=@IdEmpresaPiloto
      AND ae.AEIdEstatus=1
      AND (ISNULL(ae.AEIdPerfil,-1)<>@AdminPerfilNuevo
           OR ISNULL(ae.AEIdRol,-1)<>@AdminRolNuevo);
    SET @AdminRefsCorregidas=@@ROWCOUNT;

    IF NOT EXISTS (
        SELECT 1 FROM dbo.ff_AdministradorEmpresa
        WHERE AEIdEmpresa=@IdEmpresaPiloto AND AEIdEstatus=1
    )
        THROW 51000, 'La empresa piloto no tiene administradores activos asociados; no es seguro inventar la asociacion.', 1;

    IF EXISTS (
        SELECT 1
        FROM dbo.ff_AdministradorEmpresa ae
        LEFT JOIN dbo.ff_Perfil p
          ON p.PEIdPerfil=ae.AEIdPerfil AND p.PEIdEmpresa=ae.AEIdEmpresa AND p.PEIdEstatus=1
        LEFT JOIN dbo.ff_Rol r
          ON r.ROIdRol=ae.AEIdRol AND r.ROIdEmpresa=ae.AEIdEmpresa AND r.ROIdEstatus=1
        WHERE ae.AEIdEmpresa=@IdEmpresaPiloto AND ae.AEIdEstatus=1
          AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL)
    )
        THROW 51000, 'Persisten referencias invalidas de perfil/rol en ff_AdministradorEmpresa.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.ff_MenuRol2 WHERE MRidRol=@AdminRolNuevo AND MRidEstatus=1)
        THROW 51000, 'El rol Administrador vigente no tiene menus V2 activos.', 1;

    /* Desactivar duplicados activos, conservar uno y convertirlo al contrato B3. */
    ;WITH Duplicadas AS (
        SELECT ce.CEIdOperacionEmpresa,
               ROW_NUMBER() OVER (
                   PARTITION BY ce.CEIdOperacion
                   ORDER BY ce.CEIdOperacionEmpresa
               ) AS rn
        FROM dbo.ff_CargaMasivaOperacionEmpresa ce
        INNER JOIN @CargaEsperada e ON e.IdOperacion=ce.CEIdOperacion
        WHERE ce.CEIdEmpresa=@IdEmpresaPiloto AND ce.CEIdEstatus=1
    )
    UPDATE ce
       SET ce.CEIdEstatus=0,ce.CEUsuarioUMod=@IdUsuario,ce.CEFechaUMod=GETDATE()
    FROM dbo.ff_CargaMasivaOperacionEmpresa ce
    INNER JOIN Duplicadas d ON d.CEIdOperacionEmpresa=ce.CEIdOperacionEmpresa
    WHERE d.rn>1;
    SET @CargaDesactivadas=@@ROWCOUNT;

    UPDATE ce
       SET ce.CEIdPlantilla=e.IdPlantilla,
           ce.CEStoredProc=e.StoredProc,
           ce.CEStoredProcAtributos=e.StoredProcAtributos,
           ce.CEUsuarioUMod=@IdUsuario,
           ce.CEFechaUMod=GETDATE()
    FROM dbo.ff_CargaMasivaOperacionEmpresa ce
    INNER JOIN @CargaEsperada e ON e.IdOperacion=ce.CEIdOperacion
    WHERE ce.CEIdEmpresa=@IdEmpresaPiloto AND ce.CEIdEstatus=1
      AND (ce.CEIdPlantilla<>e.IdPlantilla
           OR LTRIM(RTRIM(ce.CEStoredProc))<>e.StoredProc
           OR ISNULL(ce.CEStoredProcAtributos,0)<>e.StoredProcAtributos);
    SET @CargaActualizadas=@@ROWCOUNT;

    INSERT INTO dbo.ff_CargaMasivaOperacionEmpresa (
        CEIdOperacion,CEIdEmpresa,CEIdPlantilla,CEStoredProc,CEStoredProcAtributos,
        CEIdEstatus,CEUsuarioAdd,CEFechaAdd,CEUsuarioUMod,CEFechaUMod
    )
    SELECT e.IdOperacion,@IdEmpresaPiloto,e.IdPlantilla,e.StoredProc,e.StoredProcAtributos,
           1,@IdUsuario,GETDATE(),@IdUsuario,GETDATE()
    FROM @CargaEsperada e
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.ff_CargaMasivaOperacionEmpresa ce
        WHERE ce.CEIdEmpresa=@IdEmpresaPiloto
          AND ce.CEIdOperacion=e.IdOperacion
          AND ce.CEIdEstatus=1
    );
    SET @CargaInsertadas=@@ROWCOUNT;

    IF (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
        WHERE CEIdEmpresa=@IdEmpresaPiloto AND CEIdEstatus=1
          AND CEIdOperacion IN (1,2,3,13,14))<>5
       OR EXISTS (
           SELECT 1
           FROM @CargaEsperada e
           LEFT JOIN dbo.ff_CargaMasivaOperacionEmpresa ce
             ON ce.CEIdEmpresa=@IdEmpresaPiloto
            AND ce.CEIdOperacion=e.IdOperacion
            AND ce.CEIdEstatus=1
           WHERE ce.CEIdOperacionEmpresa IS NULL
              OR ce.CEIdPlantilla<>e.IdPlantilla
              OR LTRIM(RTRIM(ce.CEStoredProc))<>e.StoredProc
              OR ISNULL(ce.CEStoredProcAtributos,0)<>e.StoredProcAtributos
       )
        THROW 51000, 'No fue posible dejar una configuracion unica y correcta de carga masiva.', 1;

    /* Reparar paId=226 solamente cuando falta, esta inactivo o no tiene valor. */
    UPDATE d
       SET d.paClase=s.paClase,d.paValor=s.paValor,d.paDescripcion=s.paDescripcion,
           d.paidEstatus=1,d.paUsuarioUmod=@IdUsuario,d.paFechaUmod=GETDATE()
    FROM dbo.ff_Parametro d
    CROSS JOIN #FuenteAviso226 s
    WHERE d.paId=226
      AND d.paIdEmpresa IN (@IdCorporativoPiloto,@IdEmpresaPiloto)
      AND (ISNULL(d.paidEstatus,0)<>1 OR NULLIF(LTRIM(RTRIM(d.paValor)),'') IS NULL);
    SET @AvisosCorregidos=@@ROWCOUNT;

    INSERT INTO dbo.ff_Parametro (
        paId,paIdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
        paUsuarioAdd,paFechaAdd,paUsuarioUmod,paFechaUmod,paUsuarioPerfil
    )
    SELECT s.paId,d.IdEmpresa,s.paClase,s.paValor,s.paDescripcion,1,
           @IdUsuario,GETDATE(),@IdUsuario,GETDATE(),s.paUsuarioPerfil
    FROM #FuenteAviso226 s
    CROSS JOIN (VALUES (@IdCorporativoPiloto),(@IdEmpresaPiloto)) d(IdEmpresa)
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.ff_Parametro p
        WHERE p.paId=226 AND p.paIdEmpresa=d.IdEmpresa
    );
    SET @AvisosCorregidos=@AvisosCorregidos+@@ROWCOUNT;

    IF EXISTS (
        SELECT 1
        FROM (VALUES (@IdCorporativoPiloto),(@IdEmpresaPiloto)) d(IdEmpresa)
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.ff_Parametro p
            WHERE p.paIdEmpresa=d.IdEmpresa AND p.paId=226 AND p.paidEstatus=1
              AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
        )
    )
        THROW 51000, 'No fue posible dejar activo el aviso de privacidad 226.', 1;

    IF EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresaPiloto)
    BEGIN
        UPDATE dbo.bf_EmpresaMVP
           SET IdEstatus=1, IdUsuarioMod=@IdUsuario, FechaMod=GETDATE(),
               IdUsuarioDel=NULL, FechaDel=NULL
         WHERE IdEmpresa=@IdEmpresaPiloto AND ISNULL(IdEstatus,0)<>1;
    END
    ELSE
    BEGIN
        INSERT dbo.bf_EmpresaMVP
            (IdEmpresa,IdEstatus,IdUsuarioAdd,FechaAdd,IdUsuarioMod,FechaMod,IdUsuarioDel,FechaDel)
        VALUES (@IdEmpresaPiloto,1,@IdUsuario,GETDATE(),NULL,NULL,NULL,NULL);
    END;

    IF NOT EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresaPiloto AND IdEstatus=1)
        THROW 51000, 'No fue posible dejar activa la marca MVP del piloto.', 1;

    INSERT INTO dbo.bf_BitacoraEmpresa (
        BEIdEmpresa,BEIdUsuario,BEAccion,BEDetalle,BEElementoAfectado,
        BECantidadElementos,BEExitoso,BEFechaCreacion
    )
    VALUES (
        @IdEmpresaPiloto,@IdUsuario,'AUTORREPARAR_MVP_B3',
        'Referencias admin=' + CAST(@AdminRefsCorregidas AS VARCHAR(12))
        + '; carga desactivada=' + CAST(@CargaDesactivadas AS VARCHAR(12))
        + '; carga actualizada=' + CAST(@CargaActualizadas AS VARCHAR(12))
        + '; carga insertada=' + CAST(@CargaInsertadas AS VARCHAR(12))
        + '; avisos 226=' + CAST(@AvisosCorregidos AS VARCHAR(12)),
        'configuracion funcional',
        @AdminRefsCorregidas+@CargaDesactivadas+@CargaActualizadas+@CargaInsertadas+@AvisosCorregidos,
        1,GETDATE()
    );

    COMMIT TRANSACTION;

    PRINT 'PILOTO COMPLETADO. Ejecute 02_VALIDAR_PILOTO_CORP_495.sql y realice la prueba funcional en BF3.';
END TRY
BEGIN CATCH
    /* Sólo limpia una transacción interna que algún SP hubiera dejado abierta. */
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
IF OBJECT_ID('tempdb..#FuenteAviso226') IS NOT NULL DROP TABLE #FuenteAviso226;
GO
