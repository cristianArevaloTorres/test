/*
  HOMOLOGACION MASIVA MVP B3 - 20 CORPORATIVOS RECIBIDOS

  DESACTIVADO POR DEFECTO. No habilitar hasta aprobar el piloto 495/496.
  Cada empresa hija se procesa en una transacción independiente.
*/
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
/* Igual que ff_AddEmpresa: cada sp_Copiar* controla su propia transacción. */
SET XACT_ABORT OFF;

DECLARE @AplicarMasivo BIT=0;              -- Último seguro: cambiar a 1 al liberar.
DECLARE @Confirmacion VARCHAR(50)='';       -- Escribir: HOMOLOGAR_20_CORPORATIVOS_B3
DECLARE @IdUsuario INT=NULL;                -- OBLIGATORIO.
DECLARE @IdEmpresaModelo INT=2494;
DECLARE @IdCorporativoModelo INT=2493;

DECLARE @Corporativos TABLE (
    IdCorporativo INT PRIMARY KEY,
    Grupo VARCHAR(30),
    Procesar BIT NOT NULL
);

/* Todos permanecen comentados lógicamente con Procesar=0. */
INSERT INTO @Corporativos VALUES
(495,'HAPAG',0),(531,'GN102',0),(658,'GCABLE',0),(698,'TORRENT',0),
(718,'UNICCO',0),(721,'CCPM',0),(723,'SCHNEIDER',0),(725,'IMCP',0),
(727,'BIOMETC',0),(752,'GEPC',0),(756,'LOEFFLERC',0),(758,'AMCHAM',0),
(760,'IMEFC',0),(762,'PRV',0),(790,'MELTSANC',0),(797,'CLYPC',0),
(799,'VITOLC',0),(806,'SGWIC',0),(812,'DE LA VEGA',0),(814,'CONSTRUMACC',0);

/* DESCOMENTAR esta línea sólo después de aprobar el piloto. */
-- UPDATE @Corporativos SET Procesar=1;

CREATE TABLE #Objetivos (
    IdEmpresa INT PRIMARY KEY,
    IdCorporativo INT NOT NULL,
    Grupo VARCHAR(30) NOT NULL,
    Empresa VARCHAR(200) NULL
);

INSERT INTO #Objetivos (IdEmpresa,IdCorporativo,Grupo,Empresa)
SELECT e.EMidEmpresa,c.IdCorporativo,c.Grupo,e.EMRazonSocial
FROM @Corporativos c
JOIN dbo.ff_Empresa e ON e.EMidCorporativo=c.IdCorporativo
WHERE c.Procesar=1 AND e.EMidEmpresa<>c.IdCorporativo AND e.EMidEstatus=1;

SELECT 'OBJETIVOS_MASIVOS' Bloque,* FROM #Objetivos ORDER BY IdCorporativo,IdEmpresa;
SELECT 'RESUMEN' Bloque,
       (SELECT COUNT(*) FROM @Corporativos WHERE Procesar=1) CorporativosHabilitados,
       (SELECT COUNT(*) FROM #Objetivos) EmpresasHijaAProcesar,
       @AplicarMasivo AplicarMasivo,@Confirmacion Confirmacion,@IdUsuario IdUsuario;

IF @AplicarMasivo=0
BEGIN
    PRINT 'SIMULACION: no se modificó información. Los destinos continúan con Procesar=0.';
    DROP TABLE #Objetivos;
    RETURN;
END;

IF @Confirmacion<>'HOMOLOGAR_20_CORPORATIVOS_B3'
    THROW 51000, 'La frase de confirmación no coincide.', 1;
IF @IdUsuario IS NULL OR @IdUsuario<=0
    THROW 51000, 'Debe capturar @IdUsuario.', 1;
IF NOT EXISTS (SELECT 1 FROM @Corporativos WHERE Procesar=1)
    THROW 51000, 'No hay corporativos habilitados. Revise el UPDATE comentado.', 1;
IF NOT EXISTS (SELECT 1 FROM #Objetivos)
    THROW 51000, 'Los corporativos habilitados no tienen empresas hijas activas.', 1;
IF EXISTS (
    SELECT 1 FROM @Corporativos c
    WHERE c.Procesar=1 AND NOT EXISTS (
        SELECT 1 FROM dbo.ff_Empresa e
        WHERE e.EMidCorporativo=c.IdCorporativo AND e.EMidEmpresa<>c.IdCorporativo AND e.EMidEstatus=1
    )
)
    THROW 51000, 'Al menos un corporativo habilitado no tiene empresa hija activa.', 1;
DECLARE @Objetos TABLE (Objeto SYSNAME,Tipo CHAR(2));
INSERT @Objetos VALUES
('dbo.bf_BitacoraEmpresa','U'),('dbo.bf_EmpresaMVP','U'),
('dbo.bf_ProcesoMVP','P'),('dbo.sp_CopiarRolesEmpresa','P'),('dbo.sp_CopiarPerfilesEmpresa','P'),
('dbo.sp_CopiarMenusEmpresa','P'),('dbo.sp_CopiarImagenesEmpresa','P'),('dbo.sp_CopiarColoresEmpresa','P'),
('dbo.sp_CopiarDocumentosEmpresa','P'),('dbo.sp_CopiarPlanesEmpresa','P'),('dbo.sp_CopiarParametrosEmpresa','P'),
('dbo.sp_CopiarAccesoBeflex','P'),('dbo.sp_CopiarBeflexInicio2','P'),('dbo.sp_CopiarConfiguracionEmpresa','P'),
('dbo.sp_CopiarPlantillasMVP','P'),('dbo.sp_CopiarReporteInterfabricaMVP','P'),('dbo.sp_CopiarMenusV2_MVP','P'),
('dbo.sp_CopiarCargaMasiva_MVP','P'),('dbo.sp_CopiarParametroMismoSexo_MVP','P');
IF EXISTS (SELECT 1 FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL)
    THROW 51000, 'Faltan objetos de la cascada completa MVP B3.', 1;
IF (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP'))<>4
   OR NOT EXISTS (SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP') AND name='@ModeloOrigen')
   OR NOT EXISTS (SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP') AND name='@ModeloCorp')
    THROW 51000, 'La firma de bf_ProcesoMVP no corresponde a la cascada B3 validada.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdEmpresaModelo AND EMidCorporativo=@IdCorporativoModelo AND EMidEstatus=1)
    THROW 51000, 'El modelo 2494/2493 no es válido.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.ff_Rol WHERE ROIdRol=7365 AND ROIdEstatus=1)
    THROW 51000, 'Falta el rol modelo V2 7365 requerido por sp_CopiarMenusV2_MVP.', 1;
IF EXISTS (
    SELECT 1 FROM (VALUES (13),(15),(17),(154),(689),(12061),(12062)) p(IdPlantilla)
    WHERE NOT EXISTS (SELECT 1 FROM dbo.ff_Plantilla x WHERE x.PLIdPlantilla=p.IdPlantilla AND x.PLIdEstatus=1)
)
    THROW 51000, 'Falta una plantilla fija requerida: 13, 15, 17, 154, 689, 12061 o 12062.', 1;
IF (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
    WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1 AND CEIdOperacion IN (1,2,3,13,14))<>5
    THROW 51000, 'La empresa modelo 2494 no tiene las cinco operaciones de carga 1,2,3,13,14.', 1;
IF EXISTS (SELECT IdEmpresa FROM dbo.bf_EmpresaMVP GROUP BY IdEmpresa HAVING COUNT(*)>1 AND IdEmpresa IN (SELECT IdEmpresa FROM #Objetivos))
    THROW 51000, 'Hay marcas MVP duplicadas en los destinos; corregir antes de continuar.', 1;

/* Fuentes y contrato para la autorreparacion posterior a bf_ProcesoMVP. */
IF OBJECT_ID('tempdb..#FuenteAviso226') IS NOT NULL DROP TABLE #FuenteAviso226;
SELECT TOP (1)
       p.paId,p.paClase,p.paValor,p.paDescripcion,p.paidEstatus,p.paUsuarioPerfil
INTO #FuenteAviso226
FROM dbo.ff_Parametro p
WHERE p.paId=226
  AND p.paIdEmpresa IN (@IdCorporativoModelo,@IdEmpresaModelo)
  AND p.paidEstatus=1
  AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
ORDER BY CASE WHEN p.paIdEmpresa=@IdCorporativoModelo THEN 0 ELSE 1 END;

IF NOT EXISTS (SELECT 1 FROM #FuenteAviso226)
    THROW 51000, 'No existe una fuente valida para paId=226 en el corporativo o empresa modelo.', 1;

DECLARE @CargaEsperada TABLE (
    IdOperacion INT PRIMARY KEY,
    IdPlantilla INT NOT NULL,
    StoredProc VARCHAR(250) NOT NULL,
    StoredProcAtributos INT NOT NULL
);

IF (SELECT COUNT(DISTINCT CEIdOperacion)
    FROM dbo.ff_CargaMasivaOperacionEmpresa
    WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1
      AND CEIdOperacion IN (1,2,3,13,14))<>5
   OR EXISTS (
       SELECT CEIdOperacion
       FROM dbo.ff_CargaMasivaOperacionEmpresa
       WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1
         AND CEIdOperacion IN (1,2,3,13,14)
       GROUP BY CEIdOperacion HAVING COUNT(*)<>1
   )
    THROW 51000, 'La configuracion modelo de carga masiva no es unica para las operaciones 1,2,3,13,14.', 1;

INSERT INTO @CargaEsperada (IdOperacion,IdPlantilla,StoredProc,StoredProcAtributos)
SELECT src.CEIdOperacion,
       CASE src.CEIdOperacion WHEN 1 THEN 12061 WHEN 2 THEN 12062 WHEN 3 THEN 154 ELSE src.CEIdPlantilla END,
       CASE src.CEIdOperacion
            WHEN 1 THEN 'ff_XCMDependientesAltaCMM'
            WHEN 2 THEN 'ff_XCMTitularesAltaCMM_BF3'
            WHEN 3 THEN 'ff_XCMAseguradosBaja_Base'
            ELSE src.CEStoredProc END,
       src.CEStoredProcAtributos
FROM dbo.ff_CargaMasivaOperacionEmpresa src
WHERE src.CEIdEmpresa=@IdEmpresaModelo AND src.CEIdEstatus=1
  AND src.CEIdOperacion IN (1,2,3,13,14);

DECLARE @Resultados TABLE (
    IdEmpresa INT, IdCorporativo INT, Grupo VARCHAR(30),
    Resultado VARCHAR(10), Mensaje VARCHAR(2000)
);
DECLARE @IdEmpresa INT,@IdCorporativo INT,@Grupo VARCHAR(30);

DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
SELECT IdEmpresa,IdCorporativo,Grupo FROM #Objetivos ORDER BY IdCorporativo,IdEmpresa;
OPEN cur;
FETCH NEXT FROM cur INTO @IdEmpresa,@IdCorporativo,@Grupo;
WHILE @@FETCH_STATUS=0
BEGIN
    BEGIN TRY
        EXEC dbo.bf_ProcesoMVP
            @idEmpresa=@IdEmpresa,
            @Usuario=@IdUsuario,
            @ModeloOrigen=@IdEmpresaModelo,
            @ModeloCorp=@IdCorporativoModelo;

        BEGIN TRANSACTION;

        DECLARE @AdminPerfilNuevo INT=NULL,@AdminRolNuevo INT=NULL;
        DECLARE @AdminRefsCorregidas INT=0,@CargaDesactivadas INT=0,
                @CargaActualizadas INT=0,@CargaInsertadas INT=0,@AvisosCorregidos INT=0;

        SELECT TOP (1)
               @AdminPerfilNuevo=p.PEIdPerfil,
               @AdminRolNuevo=p.PEIdRolDefault
        FROM dbo.ff_Perfil p
        INNER JOIN dbo.ff_Rol r
          ON r.ROIdRol=p.PEIdRolDefault
         AND r.ROIdEmpresa=p.PEIdEmpresa
         AND r.ROIdEstatus=1
        WHERE p.PEIdEmpresa=@IdEmpresa
          AND p.PEAdministrador=1
          AND p.PEIdEstatus=1
        ORDER BY CASE WHEN p.PENombre='Administrador' THEN 0 ELSE 1 END,p.PEIdPerfil;

        IF @AdminPerfilNuevo IS NULL OR @AdminRolNuevo IS NULL
            THROW 51000, 'No existe un perfil Administrador con rol vigente en la empresa destino.', 1;

        UPDATE ae
           SET ae.AEIdPerfil=@AdminPerfilNuevo,
               ae.AEIdRol=@AdminRolNuevo,
               ae.AEUsuarioUMod=@IdUsuario,
               ae.AEFechaUMod=GETDATE()
        FROM dbo.ff_AdministradorEmpresa ae
        WHERE ae.AEIdEmpresa=@IdEmpresa
          AND ae.AEIdEstatus=1
          AND (ISNULL(ae.AEIdPerfil,-1)<>@AdminPerfilNuevo
                   OR ISNULL(ae.AEIdRol,-1)<>@AdminRolNuevo);
        SET @AdminRefsCorregidas=@@ROWCOUNT;

        IF NOT EXISTS (
            SELECT 1 FROM dbo.ff_AdministradorEmpresa
            WHERE AEIdEmpresa=@IdEmpresa AND AEIdEstatus=1
        )
            THROW 51000, 'La empresa destino no tiene administradores activos asociados; no es seguro inventar la asociacion.', 1;

        IF EXISTS (
            SELECT 1
            FROM dbo.ff_AdministradorEmpresa ae
            LEFT JOIN dbo.ff_Perfil p
              ON p.PEIdPerfil=ae.AEIdPerfil AND p.PEIdEmpresa=ae.AEIdEmpresa AND p.PEIdEstatus=1
            LEFT JOIN dbo.ff_Rol r
              ON r.ROIdRol=ae.AEIdRol AND r.ROIdEmpresa=ae.AEIdEmpresa AND r.ROIdEstatus=1
            WHERE ae.AEIdEmpresa=@IdEmpresa AND ae.AEIdEstatus=1
              AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL)
        )
            THROW 51000, 'Persisten referencias invalidas de perfil/rol en ff_AdministradorEmpresa.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.ff_MenuRol2 WHERE MRidRol=@AdminRolNuevo AND MRidEstatus=1)
            THROW 51000, 'El rol Administrador vigente no tiene menus V2 activos.', 1;

        ;WITH Duplicadas AS (
            SELECT ce.CEIdOperacionEmpresa,
                   ROW_NUMBER() OVER (
                       PARTITION BY ce.CEIdOperacion
                       ORDER BY ce.CEIdOperacionEmpresa
                   ) AS rn
            FROM dbo.ff_CargaMasivaOperacionEmpresa ce
            INNER JOIN @CargaEsperada e ON e.IdOperacion=ce.CEIdOperacion
            WHERE ce.CEIdEmpresa=@IdEmpresa AND ce.CEIdEstatus=1
        )
        UPDATE ce
           SET ce.CEIdEstatus=0,ce.CEUsuarioUMod=@IdUsuario,ce.CEFechaUMod=GETDATE()
        FROM dbo.ff_CargaMasivaOperacionEmpresa ce
        INNER JOIN Duplicadas d ON d.CEIdOperacionEmpresa=ce.CEIdOperacionEmpresa
        WHERE d.rn>1;
        SET @CargaDesactivadas=@@ROWCOUNT;

        UPDATE ce
           SET ce.CEIdPlantilla=e.IdPlantilla,
               ce.CEStoredProc=e.StoredProc,
               ce.CEStoredProcAtributos=e.StoredProcAtributos,
               ce.CEUsuarioUMod=@IdUsuario,
               ce.CEFechaUMod=GETDATE()
        FROM dbo.ff_CargaMasivaOperacionEmpresa ce
        INNER JOIN @CargaEsperada e ON e.IdOperacion=ce.CEIdOperacion
        WHERE ce.CEIdEmpresa=@IdEmpresa AND ce.CEIdEstatus=1
          AND (ce.CEIdPlantilla<>e.IdPlantilla
               OR LTRIM(RTRIM(ce.CEStoredProc))<>e.StoredProc
               OR ISNULL(ce.CEStoredProcAtributos,0)<>e.StoredProcAtributos);
        SET @CargaActualizadas=@@ROWCOUNT;

        INSERT INTO dbo.ff_CargaMasivaOperacionEmpresa (
            CEIdOperacion,CEIdEmpresa,CEIdPlantilla,CEStoredProc,CEStoredProcAtributos,
            CEIdEstatus,CEUsuarioAdd,CEFechaAdd,CEUsuarioUMod,CEFechaUMod
        )
        SELECT e.IdOperacion,@IdEmpresa,e.IdPlantilla,e.StoredProc,e.StoredProcAtributos,
               1,@IdUsuario,GETDATE(),@IdUsuario,GETDATE()
        FROM @CargaEsperada e
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.ff_CargaMasivaOperacionEmpresa ce
            WHERE ce.CEIdEmpresa=@IdEmpresa
              AND ce.CEIdOperacion=e.IdOperacion
              AND ce.CEIdEstatus=1
        );
        SET @CargaInsertadas=@@ROWCOUNT;

        IF (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
            WHERE CEIdEmpresa=@IdEmpresa AND CEIdEstatus=1
              AND CEIdOperacion IN (1,2,3,13,14))<>5
           OR EXISTS (
               SELECT 1
               FROM @CargaEsperada e
               LEFT JOIN dbo.ff_CargaMasivaOperacionEmpresa ce
                 ON ce.CEIdEmpresa=@IdEmpresa
                AND ce.CEIdOperacion=e.IdOperacion
                AND ce.CEIdEstatus=1
               WHERE ce.CEIdOperacionEmpresa IS NULL
                  OR ce.CEIdPlantilla<>e.IdPlantilla
                  OR LTRIM(RTRIM(ce.CEStoredProc))<>e.StoredProc
                  OR ISNULL(ce.CEStoredProcAtributos,0)<>e.StoredProcAtributos
           )
            THROW 51000, 'No fue posible dejar una configuracion unica y correcta de carga masiva.', 1;

        UPDATE d
           SET d.paClase=s.paClase,d.paValor=s.paValor,d.paDescripcion=s.paDescripcion,
               d.paidEstatus=1,d.paUsuarioUmod=@IdUsuario,d.paFechaUmod=GETDATE()
        FROM dbo.ff_Parametro d
        CROSS JOIN #FuenteAviso226 s
        WHERE d.paId=226
          AND d.paIdEmpresa IN (@IdCorporativo,@IdEmpresa)
          AND (ISNULL(d.paidEstatus,0)<>1 OR NULLIF(LTRIM(RTRIM(d.paValor)),'') IS NULL);
        SET @AvisosCorregidos=@@ROWCOUNT;

        INSERT INTO dbo.ff_Parametro (
            paId,paIdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
            paUsuarioAdd,paFechaAdd,paUsuarioUmod,paFechaUmod,paUsuarioPerfil
        )
        SELECT s.paId,d.IdEmpresa,s.paClase,s.paValor,s.paDescripcion,1,
               @IdUsuario,GETDATE(),@IdUsuario,GETDATE(),s.paUsuarioPerfil
        FROM #FuenteAviso226 s
        CROSS JOIN (VALUES (@IdCorporativo),(@IdEmpresa)) d(IdEmpresa)
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.ff_Parametro p
            WHERE p.paId=226 AND p.paIdEmpresa=d.IdEmpresa
        );
        SET @AvisosCorregidos=@AvisosCorregidos+@@ROWCOUNT;

        IF EXISTS (
            SELECT 1
            FROM (VALUES (@IdCorporativo),(@IdEmpresa)) d(IdEmpresa)
            WHERE NOT EXISTS (
                SELECT 1 FROM dbo.ff_Parametro p
                WHERE p.paIdEmpresa=d.IdEmpresa AND p.paId=226 AND p.paidEstatus=1
                  AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
            )
        )
            THROW 51000, 'No fue posible dejar activo el aviso de privacidad 226.', 1;

        IF EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresa)
            UPDATE dbo.bf_EmpresaMVP
               SET IdEstatus=1,IdUsuarioMod=@IdUsuario,FechaMod=GETDATE(),IdUsuarioDel=NULL,FechaDel=NULL
             WHERE IdEmpresa=@IdEmpresa AND ISNULL(IdEstatus,0)<>1;
        ELSE
            INSERT dbo.bf_EmpresaMVP
                (IdEmpresa,IdEstatus,IdUsuarioAdd,FechaAdd,IdUsuarioMod,FechaMod,IdUsuarioDel,FechaDel)
            VALUES (@IdEmpresa,1,@IdUsuario,GETDATE(),NULL,NULL,NULL,NULL);

        IF NOT EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresa AND IdEstatus=1)
            THROW 51000, 'No fue posible dejar activa la marca MVP de la empresa.', 1;

        INSERT INTO dbo.bf_BitacoraEmpresa (
            BEIdEmpresa,BEIdUsuario,BEAccion,BEDetalle,BEElementoAfectado,
            BECantidadElementos,BEExitoso,BEFechaCreacion
        )
        VALUES (
            @IdEmpresa,@IdUsuario,'AUTORREPARAR_MVP_B3',
            'Referencias admin=' + CAST(@AdminRefsCorregidas AS VARCHAR(12))
            + '; carga desactivada=' + CAST(@CargaDesactivadas AS VARCHAR(12))
            + '; carga actualizada=' + CAST(@CargaActualizadas AS VARCHAR(12))
            + '; carga insertada=' + CAST(@CargaInsertadas AS VARCHAR(12))
            + '; avisos 226=' + CAST(@AvisosCorregidos AS VARCHAR(12)),
            'configuracion funcional',
            @AdminRefsCorregidas+@CargaDesactivadas+@CargaActualizadas+@CargaInsertadas+@AvisosCorregidos,
            1,GETDATE()
        );

        COMMIT TRANSACTION;

        INSERT @Resultados VALUES (
            @IdEmpresa,@IdCorporativo,@Grupo,'OK',
            'Cascada, autorreparacion comprobada y marca MVP completadas.'
        );
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        INSERT @Resultados VALUES (@IdEmpresa,@IdCorporativo,@Grupo,'ERROR',LEFT(ERROR_MESSAGE(),2000));
    END CATCH;

    FETCH NEXT FROM cur INTO @IdEmpresa,@IdCorporativo,@Grupo;
END;
CLOSE cur;
DEALLOCATE cur;

SELECT * FROM @Resultados ORDER BY IdCorporativo,IdEmpresa;
SELECT Resultado,COUNT(*) Cantidad FROM @Resultados GROUP BY Resultado;

IF EXISTS (SELECT 1 FROM @Resultados WHERE Resultado='ERROR')
    THROW 51000, 'Una o más empresas fallaron. Las demás conservaron su transacción independiente; revise el resultado.', 1;

DROP TABLE #Objetivos;
IF OBJECT_ID('tempdb..#FuenteAviso226') IS NOT NULL DROP TABLE #FuenteAviso226;
GO
