/*
  DIAGNOSTICO ESPECIFICO DEL ERROR 3930 EN sp_CopiarMenusV2_MVP.
  Sólo lectura. Ejecutar en una sesión nueva antes de reintentar el piloto.
*/
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;

DECLARE @IdEmpresa INT=496;
DECLARE @RolModeloV2 INT=7365;
DECLARE @RolDestino INT;

SELECT TOP 1 @RolDestino=ROIdRol
FROM dbo.ff_Rol
WHERE ROIdEmpresa=@IdEmpresa
  AND RODescripcionCorta LIKE '%admi%'
  AND ROIdEstatus=1
ORDER BY ROIdRol;

SELECT '01_SESION_NUEVA' Bloque,@@TRANCOUNT TranCount,XACT_STATE() XactState,
       CASE WHEN @@TRANCOUNT=0 AND XACT_STATE()=0 THEN 'OK'
            ELSE 'CERRAR ESTA SESION, ABRIR OTRA Y VOLVER A EJECUTAR' END Resultado;

SELECT '02_ROL_MODELO_V2' Bloque,r.ROIdRol,r.ROIdEmpresa,r.RODescripcionCorta,r.ROIdEstatus,
       (SELECT COUNT(*) FROM dbo.ff_MenuRol2 mr WHERE mr.MRidRol=@RolModeloV2 AND mr.MRidEstatus=1) MenusActivos,
       CASE WHEN r.ROIdRol IS NULL THEN 'FALTA ROL MODELO 7365'
            WHEN r.ROIdEstatus<>1 THEN 'ROL MODELO INACTIVO'
            WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_MenuRol2 mr WHERE mr.MRidRol=@RolModeloV2 AND mr.MRidEstatus=1) THEN 'ROL MODELO SIN MENUS'
            ELSE 'OK' END Resultado
FROM (SELECT 1 n) x
LEFT JOIN dbo.ff_Rol r ON r.ROIdRol=@RolModeloV2;

SELECT '03_ROL_ADMIN_DESTINO' Bloque,@IdEmpresa IdEmpresa,@RolDestino IdRolDestino,
       r.RODescripcionCorta,r.ROIdEstatus,
       CASE WHEN @RolDestino IS NULL THEN 'NO SE ENCONTRO ROL ADMIN DESTINO' ELSE 'OK' END Resultado
FROM (SELECT 1 n) x
LEFT JOIN dbo.ff_Rol r ON r.ROIdRol=@RolDestino;

SELECT '04_DUPLICADOS_ORIGEN' Bloque,MRidMenu,COUNT(*) Cantidad
FROM dbo.ff_MenuRol2
WHERE MRidRol=@RolModeloV2 AND MRidEstatus=1
GROUP BY MRidMenu
HAVING COUNT(*)>1;

SELECT '05_COMPARACION_MENUS' Bloque,
       (SELECT COUNT(*) FROM dbo.ff_MenuRol2 WHERE MRidRol=@RolModeloV2 AND MRidEstatus=1) MenusModelo,
       (SELECT COUNT(*) FROM dbo.ff_MenuRol2 WHERE MRidRol=@RolDestino AND MRidEstatus=1) MenusDestino,
       (SELECT COUNT(*) FROM dbo.ff_MenuRol2 src
        WHERE src.MRidRol=@RolModeloV2 AND src.MRidEstatus=1
          AND NOT EXISTS (SELECT 1 FROM dbo.ff_MenuRol2 dst WHERE dst.MRidRol=@RolDestino AND dst.MRidMenu=src.MRidMenu)) FaltantesPorInsertar;

SELECT '06_TRIGGERS_MENUROL2' Bloque,tr.name TriggerNombre,tr.is_disabled,tr.is_instead_of_trigger,
       OBJECT_DEFINITION(tr.object_id) Definicion
FROM sys.triggers tr
WHERE tr.parent_id=OBJECT_ID('dbo.ff_MenuRol2');

SELECT TOP 50 '07_BITACORA_RECIENTE' Bloque,BEId,BEAccion,BEExitoso,BEElementoAfectado,
       BECantidadElementos,BEMensajeError,BEDetalle,BEFechaCreacion
FROM dbo.bf_BitacoraEmpresa
WHERE BEIdEmpresa=@IdEmpresa
ORDER BY BEFechaCreacion DESC,BEId DESC;

SELECT '08_INTERPRETACION' Bloque,
       'El 3930 observado fue provocado por la transacción exterior del script 01. Use la versión corregida con XACT_ABORT OFF y sin BEGIN TRANSACTION exterior. Si vuelve a fallar, el mensaje nuevo debe mostrar la causa original.' Resultado;
GO
