/* VALIDACION POSTERIOR DEL PILOTO 495/496. Sólo lectura. */
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;

DECLARE @IdCorporativo INT=495;
DECLARE @IdEmpresa INT=496;

SELECT '01_IDENTIDAD' Bloque, e.EMidEmpresa, e.EMidCorporativo, e.EMRazonSocial, e.EMNombre, e.EMidEstatus,
       CASE WHEN e.EMidEmpresa=@IdEmpresa AND e.EMidCorporativo=@IdCorporativo AND e.EMidEmpresa<>e.EMidCorporativo AND e.EMidEstatus=1
            THEN 'OK' ELSE 'REVISAR' END Resultado
FROM dbo.ff_Empresa e WHERE e.EMidEmpresa=@IdEmpresa;

SELECT '02_RESUMEN_B3' Bloque, @IdEmpresa IdEmpresa,
       (SELECT COUNT(*) FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresa AND IdEstatus=1) MarcaMVP,
       (SELECT COUNT(*) FROM dbo.ff_Rol WHERE ROIdEmpresa=@IdEmpresa AND ROIdEstatus=1) Roles,
       (SELECT COUNT(*) FROM dbo.ff_Perfil WHERE PEIdEmpresa=@IdEmpresa AND PEIdEstatus=1) Perfiles,
       (SELECT COUNT(*) FROM dbo.ff_MenuRol2 mr JOIN dbo.ff_Rol r ON r.ROIdRol=mr.MRidRol WHERE r.ROIdEmpresa=@IdEmpresa AND r.ROIdEstatus=1 AND mr.MRidEstatus=1) MenusV2,
       (SELECT COUNT(*) FROM dbo.ff_EmpresaImagen WHERE EIIdEmpresa=@IdEmpresa) Imagenes,
       (SELECT COUNT(*) FROM dbo.ff_Parametro WHERE paIdEmpresa=@IdEmpresa AND paidEstatus=1) Parametros,
       (SELECT COUNT(*) FROM dbo.ff_DocumentoPlanB3 WHERE DPIdEmpresa=@IdEmpresa AND DPEstatus=1) DocumentosPlanB3,
       (SELECT COUNT(*) FROM dbo.ff_accesoBeflex WHERE idempresa=@IdEmpresa AND acceso=1) AccesoBeflex,
       (SELECT COUNT(*) FROM dbo.bf_BeflexInicio2 WHERE BI_IdCorporativo=@IdEmpresa AND BI_IdEstatus=1) InicioB3,
       (SELECT COUNT(*) FROM dbo.bf_EstiloEmpresa WHERE EEIdEmpresa=@IdEmpresa AND EEIdEstatus=1) EstilosB3,
       (SELECT COUNT(*) FROM dbo.ff_Plantilla WHERE PLDescripcion LIKE '%- MVP[_]'+CAST(@IdEmpresa AS VARCHAR(12))+'%' AND PLIdEstatus=1) PlantillasMVP,
       (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa WHERE CEIdEmpresa=@IdEmpresa AND CEIdEstatus=1 AND CEIdOperacion IN (1,2,3,13,14)) OperacionesCarga;

SELECT '03_CARGA_MASIVA' Bloque, CEIdOperacion, CEIdPlantilla, CEStoredProc, CEStoredProcAtributos, CEIdEstatus,
       CASE
           WHEN CEIdOperacion=1 AND CEIdPlantilla=12061 AND CEStoredProc='ff_XCMDependientesAltaCMM' THEN 'OK'
           WHEN CEIdOperacion=2 AND CEIdPlantilla=12062 AND CEStoredProc='ff_XCMTitularesAltaCMM_BF3' THEN 'OK'
           WHEN CEIdOperacion=3 AND CEIdPlantilla=154 AND CEStoredProc='ff_XCMAseguradosBaja_Base' THEN 'OK'
           WHEN CEIdOperacion IN (13,14) THEN 'REVISAR CONTRA MODELO 2494'
           ELSE 'REVISAR'
       END Resultado
FROM dbo.ff_CargaMasivaOperacionEmpresa
WHERE CEIdEmpresa=@IdEmpresa AND CEIdOperacion IN (1,2,3,13,14)
ORDER BY CEIdOperacion;

SELECT '04_PARAMETROS_CRITICOS' Bloque, e.IdEmpresa, p.paId, p.paValor, p.paidEstatus,
       CASE WHEN p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL THEN 'OK'
            WHEN p.paId=232 THEN 'REVISAR: SSO NO DEBE ACTIVARSE SIN CONFIGURACION REAL'
            ELSE 'REVISAR' END Resultado
FROM (VALUES (@IdCorporativo),(@IdEmpresa)) e(IdEmpresa)
LEFT JOIN dbo.ff_Parametro p ON p.paIdEmpresa=e.IdEmpresa AND p.paId IN (226,232)
ORDER BY e.IdEmpresa,p.paId;

SELECT '05_ADMINISTRADOR' Bloque, ae.ADIdAdministrador, ae.AEIdEmpresa, ae.AEIdPerfil, p.PENombre,
       ae.AEIdRol, r.RODescripcionCorta,
       CASE WHEN p.PEIdPerfil IS NOT NULL AND r.ROIdRol IS NOT NULL THEN 'OK' ELSE 'REFERENCIA INVALIDA' END Resultado
FROM dbo.ff_AdministradorEmpresa ae
LEFT JOIN dbo.ff_Perfil p ON p.PEIdPerfil=ae.AEIdPerfil AND p.PEIdEmpresa=ae.AEIdEmpresa AND p.PEIdEstatus=1
LEFT JOIN dbo.ff_Rol r ON r.ROIdRol=ae.AEIdRol AND r.ROIdEmpresa=ae.AEIdEmpresa AND r.ROIdEstatus=1
WHERE ae.AEIdEmpresa=@IdEmpresa AND ae.AEIdEstatus=1;

SELECT '06_BITACORA' Bloque, BEId, BEAccion, BEExitoso, BEElementoAfectado,
       BECantidadElementos, BEMensajeError, BEDetalle, BEFechaCreacion
FROM dbo.bf_BitacoraEmpresa
WHERE BEIdEmpresa IN (@IdCorporativo,@IdEmpresa)
ORDER BY BEFechaCreacion DESC,BEId DESC;

SELECT '07_DICTAMEN_AUTOMATICO' Bloque,
       CASE
           WHEN NOT EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresa AND IdEstatus=1) THEN 'REVISAR MARCA MVP'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_accesoBeflex WHERE idempresa=@IdEmpresa AND acceso=1) THEN 'REVISAR ACCESO BF3'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_Perfil WHERE PEIdEmpresa=@IdEmpresa AND PEIdEstatus=1) THEN 'REVISAR PERFILES'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_Rol WHERE ROIdEmpresa=@IdEmpresa AND ROIdEstatus=1) THEN 'REVISAR ROLES'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_AdministradorEmpresa WHERE AEIdEmpresa=@IdEmpresa AND AEIdEstatus=1) THEN 'REVISAR ADMINISTRADORES ASOCIADOS'
           WHEN EXISTS (
               SELECT 1
               FROM dbo.ff_AdministradorEmpresa ae
               LEFT JOIN dbo.ff_Perfil p
                 ON p.PEIdPerfil=ae.AEIdPerfil AND p.PEIdEmpresa=ae.AEIdEmpresa AND p.PEIdEstatus=1
               LEFT JOIN dbo.ff_Rol r
                 ON r.ROIdRol=ae.AEIdRol AND r.ROIdEmpresa=ae.AEIdEmpresa AND r.ROIdEstatus=1
               WHERE ae.AEIdEmpresa=@IdEmpresa AND ae.AEIdEstatus=1
                 AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL)
           ) THEN 'REVISAR REFERENCIAS ADMINISTRADOR'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_Parametro WHERE paIdEmpresa=@IdEmpresa AND paId=226 AND paidEstatus=1 AND NULLIF(LTRIM(RTRIM(paValor)),'') IS NOT NULL) THEN 'REVISAR AVISO 226'
           WHEN (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa WHERE CEIdEmpresa=@IdEmpresa AND CEIdEstatus=1 AND CEIdOperacion IN (1,2,3,13,14))<>5 THEN 'REVISAR CARGA MASIVA'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_CargaMasivaOperacionEmpresa WHERE CEIdEmpresa=@IdEmpresa AND CEIdOperacion=1 AND CEIdEstatus=1 AND CEIdPlantilla=12061 AND LTRIM(RTRIM(CEStoredProc))='ff_XCMDependientesAltaCMM') THEN 'REVISAR CARGA MASIVA OP 1'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_CargaMasivaOperacionEmpresa WHERE CEIdEmpresa=@IdEmpresa AND CEIdOperacion=2 AND CEIdEstatus=1 AND CEIdPlantilla=12062 AND LTRIM(RTRIM(CEStoredProc))='ff_XCMTitularesAltaCMM_BF3') THEN 'REVISAR CARGA MASIVA OP 2'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.ff_CargaMasivaOperacionEmpresa WHERE CEIdEmpresa=@IdEmpresa AND CEIdOperacion=3 AND CEIdEstatus=1 AND CEIdPlantilla=154 AND LTRIM(RTRIM(CEStoredProc))='ff_XCMAseguradosBaja_Base') THEN 'REVISAR CARGA MASIVA OP 3'
           WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro WHERE paIdEmpresa IN (@IdCorporativo,@IdEmpresa) AND paId=232 AND paidEstatus=1) THEN 'REVISAR SSO 232'
           WHEN NOT EXISTS (SELECT 1 FROM dbo.bf_BitacoraEmpresa WHERE BEIdEmpresa=@IdEmpresa AND BEAccion='BF_PROCESOMVP_V3' AND BEExitoso=1) THEN 'REVISAR BITACORA DE LA CASCADA'
           ELSE 'OK PARA PRUEBA FUNCIONAL BF3'
       END Resultado;
GO
