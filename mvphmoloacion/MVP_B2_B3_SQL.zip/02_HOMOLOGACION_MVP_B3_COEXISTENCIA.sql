/*
    HOMOLOGACION MVP B2 -> B3: FASE DE COEXISTENCIA

    - No crea empresas nuevas.
    - Conserva IDs y configuracion B2.
    - Agrega solamente componentes B3 faltantes.
    - No llama procedimientos que borran imagenes, colores, parametros,
      documentos, perfiles o asignaciones de plantillas.
    - @Aplicar = 0 por defecto: solamente muestra el plan.

    REQUISITO: ejecutar primero 01_INVENTARIO_Y_PREVALIDACION_MVP_B2_B3.sql.
*/

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Aplicar                       BIT = 0;  -- Cambiar a 1 solamente en QA/copia controlada
DECLARE @CantidadEsperada              INT = 286;
DECLARE @PermitirCantidadDistinta      BIT = 0;
DECLARE @IdUsuarioEjecucion            INT = 0;  -- OBLIGATORIO cuando @Aplicar = 1
DECLARE @IdEmpresaModeloB3             INT = 2494;
DECLARE @IdCorporativoModeloB3         INT = 2493;
DECLARE @IdRolModeloMenuB3             INT = 7365;
DECLARE @IdEmpresaParametroMismoSexo   INT = 645;
DECLARE @IdParametroMismoSexo          INT = 128;
DECLARE @IdParametroAvisoPrivacidad    INT = 226;
DECLARE @IdParametroSSO                INT = 232;
DECLARE @IdEjecucion UNIQUEIDENTIFIER = NEWID();
DECLARE @FechaInicio DATETIME = GETDATE();

IF OBJECT_ID('dbo.ff_Empresa', 'U') IS NULL
    THROW 51000, 'No existe dbo.ff_Empresa.', 1;

IF OBJECT_ID('dbo.bf_EmpresaMVP', 'U') IS NULL
    THROW 51000, 'No existe dbo.bf_EmpresaMVP.', 1;

DROP TABLE IF EXISTS #Empresas;

SELECT DISTINCT
       m.IdEmpresa,
       e.EMNombre,
       e.EMidCorporativo
INTO #Empresas
FROM dbo.bf_EmpresaMVP m
JOIN dbo.ff_Empresa e ON e.EMidEmpresa = m.IdEmpresa
WHERE m.IdEstatus = 1
  AND e.EMidEstatus = 1;

DECLARE @Total INT = (SELECT COUNT(*) FROM #Empresas);

IF @PermitirCantidadDistinta = 0 AND @Total <> @CantidadEsperada
    THROW 51000, 'La cantidad de empresas MVP activas no coincide con la esperada. No se continuara.', 1;

/* Dependencias de la fase segura */
IF OBJECT_ID('dbo.sp_CopiarAccesoBeflex', 'P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarBeflexInicio2', 'P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarPlanesEmpresa', 'P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarMenusV2_MVP', 'P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarCargaMasiva_MVP', 'P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarParametroMismoSexo_MVP', 'P') IS NULL
    THROW 51000, 'Faltan procedimientos requeridos para la fase de coexistencia.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa
               WHERE EMidEmpresa = @IdEmpresaModeloB3 AND EMidEstatus = 1)
    THROW 51000, 'La empresa modelo B3 configurada no existe o esta inactiva.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa
               WHERE EMidEmpresa = @IdCorporativoModeloB3 AND EMidEstatus = 1)
    THROW 51000, 'El corporativo modelo B3 configurado no existe o esta inactivo.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Rol
               WHERE ROIdRol = @IdRolModeloMenuB3 AND ROIdEstatus = 1)
    THROW 51000, 'El rol modelo de menus B3 no existe o esta inactivo.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Parametro
               WHERE paIdEmpresa = @IdEmpresaParametroMismoSexo
                 AND paId = @IdParametroMismoSexo
                 AND paidEstatus = 1)
    THROW 51000, 'No existe el parametro modelo de mismo sexo.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Parametro
               WHERE paIdEmpresa = @IdCorporativoModeloB3
                 AND paId = @IdParametroAvisoPrivacidad
                 AND paidEstatus = 1)
    THROW 51000, 'El corporativo modelo no contiene el aviso de privacidad requerido.', 1;

/* Plan de cambios. No modifica datos. */
SELECT
    e.IdEmpresa,
    e.EMNombre,
    e.EMidCorporativo,
    AgregarAccesoBeflex = CASE WHEN EXISTS
        (SELECT 1 FROM dbo.ff_accesoBeflex a WHERE a.idempresa=e.IdEmpresa AND a.acceso=1)
        THEN 0 ELSE 1 END,
    AgregarInicioB3 =
        (SELECT COUNT(*) FROM dbo.bf_BeflexInicio2 src
         JOIN dbo.ff_Empresa mo ON mo.EMidEmpresa=@IdEmpresaModeloB3
         WHERE src.BI_IdCorporativo=mo.EMidCorporativo
           AND src.BI_Valor=@IdEmpresaModeloB3
           AND NOT EXISTS
           (SELECT 1 FROM dbo.bf_BeflexInicio2 dst
            WHERE dst.BI_IdCorporativo=e.EMidCorporativo
              AND dst.BI_Valor=e.IdEmpresa
              AND dst.BI_Titulo=src.BI_Titulo
              AND ISNULL(dst.BI_Seccion,'')=ISNULL(src.BI_Seccion,''))),
    AgregarEstilosB3 =
        (SELECT COUNT(*) FROM dbo.bf_EstiloEmpresa src
         WHERE src.EEIdEmpresa=@IdEmpresaModeloB3 AND src.EEIdEstatus=1
           AND NOT EXISTS
           (SELECT 1 FROM dbo.bf_EstiloEmpresa dst
            WHERE dst.EEIdEmpresa=e.IdEmpresa
              AND dst.EEidCatalogoEstilo=src.EEidCatalogoEstilo
              AND dst.EEIdEstatus=1)),
    MenusB3Actuales =
        (SELECT COUNT(*) FROM dbo.ff_MenuRol2 mr
         JOIN dbo.ff_Rol r ON r.ROIdRol=mr.MRidRol
         WHERE r.ROIdEmpresa=e.IdEmpresa AND r.ROIdEstatus=1 AND mr.MRidEstatus=1),
    OperacionesCargaMasivaActuales =
        (SELECT COUNT(DISTINCT CEIdOperacion)
         FROM dbo.ff_CargaMasivaOperacionEmpresa c
         WHERE c.CEIdEmpresa=e.IdEmpresa AND c.CEIdEstatus=1
           AND c.CEIdOperacion IN (1,2,3,13,14)),
    RepararAdministradores =
        (SELECT COUNT(*)
         FROM dbo.ff_AdministradorEmpresa a
         LEFT JOIN dbo.ff_Perfil p ON p.PEIdPerfil=a.AEIdPerfil
                                  AND p.PEIdEmpresa=a.AEIdEmpresa
                                  AND p.PEIdEstatus=1
         LEFT JOIN dbo.ff_Rol r ON r.ROIdRol=a.AEIdRol
                               AND r.ROIdEmpresa=a.AEIdEmpresa
                               AND r.ROIdEstatus=1
         WHERE a.AEIdEmpresa=e.IdEmpresa AND a.AEIdEstatus=1
           AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL))
FROM #Empresas e
ORDER BY e.IdEmpresa;

SELECT @IdEjecucion AS IdEjecucionPlaneada,
       @Aplicar AS Aplicar,
       @Total AS EmpresasIncluidas,
       'La fase no reemplaza imagenes, colores, documentos, parametros existentes, perfiles ni plantillas.' AS Alcance;

IF @Aplicar = 0
BEGIN
    PRINT 'SIMULACION: no se modificaron datos. Revise el plan y las referencias modelo.';
    RETURN;
END;

IF @IdUsuarioEjecucion <= 0
    THROW 51000, 'Debe indicar @IdUsuarioEjecucion para aplicar cambios.', 1;

/* Tablas de control para evidencia y reversa */
IF OBJECT_ID('dbo.bf_MigracionMVPB3_Ejecucion', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_MigracionMVPB3_Ejecucion
    (
        IdEjecucion UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
        FechaInicio DATETIME NOT NULL,
        FechaFin DATETIME NULL,
        IdUsuario INT NOT NULL,
        IdEmpresaModelo INT NOT NULL,
        IdCorporativoModelo INT NOT NULL,
        IdRolModeloMenuB3 INT NOT NULL,
        TotalEmpresas INT NOT NULL,
        Estado VARCHAR(30) NOT NULL
    );
END;

IF OBJECT_ID('dbo.bf_MigracionMVPB3_Detalle', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_MigracionMVPB3_Detalle
    (
        IdDetalle INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        IdEjecucion UNIQUEIDENTIFIER NOT NULL,
        IdEmpresa INT NOT NULL,
        Exitoso BIT NOT NULL,
        AccesosAgregados INT NOT NULL DEFAULT 0,
        InicioAgregado INT NOT NULL DEFAULT 0,
        EstilosAgregados INT NOT NULL DEFAULT 0,
        MenusAgregados INT NOT NULL DEFAULT 0,
        OperacionesAgregadas INT NOT NULL DEFAULT 0,
        ParametrosAgregados INT NOT NULL DEFAULT 0,
        DocumentosPlanAgregados INT NOT NULL DEFAULT 0,
        AdministradoresReparados INT NOT NULL DEFAULT 0,
        MensajeError VARCHAR(2000) NULL,
        Fecha DATETIME NOT NULL DEFAULT GETDATE()
    );
END;

IF OBJECT_ID('dbo.bf_MigracionMVPB3_Existencia', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_MigracionMVPB3_Existencia
    (
        IdExistencia BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        IdEjecucion UNIQUEIDENTIFIER NOT NULL,
        IdEmpresa INT NOT NULL,
        Componente VARCHAR(50) NOT NULL,
        Clave VARCHAR(250) NOT NULL
    );
    CREATE INDEX IX_bf_MigracionMVPB3_Existencia
        ON dbo.bf_MigracionMVPB3_Existencia(IdEjecucion, IdEmpresa, Componente);
END;

IF OBJECT_ID('dbo.bf_MigracionMVPB3_BackupAdministrador', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_MigracionMVPB3_BackupAdministrador
    (
        IdEjecucion UNIQUEIDENTIFIER NOT NULL,
        AEIdr INT NOT NULL,
        IdEmpresa INT NOT NULL,
        AEIdRolAnterior INT NULL,
        AEIdPerfilAnterior INT NULL,
        AEUsuarioUModAnterior INT NULL,
        AEFechaUModAnterior DATETIME NULL,
        PRIMARY KEY (IdEjecucion, AEIdr)
    );
END;

INSERT INTO dbo.bf_MigracionMVPB3_Ejecucion
(
    IdEjecucion, FechaInicio, IdUsuario, IdEmpresaModelo,
    IdCorporativoModelo, IdRolModeloMenuB3, TotalEmpresas, Estado
)
VALUES
(
    @IdEjecucion, @FechaInicio, @IdUsuarioEjecucion, @IdEmpresaModeloB3,
    @IdCorporativoModeloB3, @IdRolModeloMenuB3, @Total, 'EN_PROCESO'
);

DECLARE @IdEmpresa INT;
DECLARE @IdCorporativo INT;
DECLARE @Cantidad INT;
DECLARE @cAcceso INT, @cInicio INT, @cEstilos INT, @cMenus INT;
DECLARE @cCarga INT, @cParametros INT, @cPlanes INT, @cAdmins INT;
DECLARE @PerfilAdmin INT, @RolAdmin INT;
DECLARE @Error VARCHAR(2000);

DECLARE empresas CURSOR LOCAL FAST_FORWARD FOR
SELECT IdEmpresa, EMidCorporativo FROM #Empresas ORDER BY IdEmpresa;

OPEN empresas;
FETCH NEXT FROM empresas INTO @IdEmpresa, @IdCorporativo;

WHILE @@FETCH_STATUS = 0
BEGIN
    SELECT @cAcceso=0, @cInicio=0, @cEstilos=0, @cMenus=0,
           @cCarga=0, @cParametros=0, @cPlanes=0, @cAdmins=0,
           @PerfilAdmin=NULL, @RolAdmin=NULL, @Error=NULL;

    BEGIN TRY
        BEGIN TRANSACTION;

        /* Evidencia de registros existentes antes de agregar B3 */
        INSERT INTO dbo.bf_MigracionMVPB3_Existencia(IdEjecucion,IdEmpresa,Componente,Clave)
        SELECT @IdEjecucion,@IdEmpresa,'ACCESO',CONVERT(VARCHAR(250),acceso)
        FROM dbo.ff_accesoBeflex WHERE idempresa=@IdEmpresa;

        INSERT INTO dbo.bf_MigracionMVPB3_Existencia(IdEjecucion,IdEmpresa,Componente,Clave)
        SELECT @IdEjecucion,@IdEmpresa,'INICIO',CONVERT(VARCHAR(250),BI_IdBeflexInicio)
        FROM dbo.bf_BeflexInicio2
        WHERE BI_IdCorporativo=@IdCorporativo AND BI_Valor=@IdEmpresa;

        INSERT INTO dbo.bf_MigracionMVPB3_Existencia(IdEjecucion,IdEmpresa,Componente,Clave)
        SELECT @IdEjecucion,@IdEmpresa,'ESTILO',CONVERT(VARCHAR(250),EEIdEstiloEmpresa)
        FROM dbo.bf_EstiloEmpresa WHERE EEIdEmpresa=@IdEmpresa;

        INSERT INTO dbo.bf_MigracionMVPB3_Existencia(IdEjecucion,IdEmpresa,Componente,Clave)
        SELECT @IdEjecucion,@IdEmpresa,'MENU',CONVERT(VARCHAR(250),mr.MRidMenuRol)
        FROM dbo.ff_MenuRol2 mr JOIN dbo.ff_Rol r ON r.ROIdRol=mr.MRidRol
        WHERE r.ROIdEmpresa=@IdEmpresa;

        INSERT INTO dbo.bf_MigracionMVPB3_Existencia(IdEjecucion,IdEmpresa,Componente,Clave)
        SELECT @IdEjecucion,@IdEmpresa,'CARGA',CONVERT(VARCHAR(250),CEIdOperacionEmpresa)
        FROM dbo.ff_CargaMasivaOperacionEmpresa WHERE CEIdEmpresa=@IdEmpresa;

        INSERT INTO dbo.bf_MigracionMVPB3_Existencia(IdEjecucion,IdEmpresa,Componente,Clave)
        SELECT @IdEjecucion,@IdEmpresa,'DOCUMENTOPLAN',CONVERT(VARCHAR(250),DPidDoc)
        FROM dbo.ff_DocumentoPlanB3 WHERE DPIdEmpresa=@IdEmpresa;

        INSERT INTO dbo.bf_MigracionMVPB3_Existencia(IdEjecucion,IdEmpresa,Componente,Clave)
        SELECT @IdEjecucion,@IdEmpresa,'PARAMETRO',
               CONVERT(VARCHAR(20),paIdEmpresa)+'|'+CONVERT(VARCHAR(20),paId)
        FROM dbo.ff_Parametro
        WHERE paIdEmpresa IN (@IdEmpresa,@IdCorporativo)
          AND paId IN (@IdParametroMismoSexo,@IdParametroAvisoPrivacidad);

        EXEC dbo.sp_CopiarAccesoBeflex
             @IdEmpresaOrigen=@IdEmpresaModeloB3,
             @IdEmpresaDestino=@IdEmpresa,
             @IdUsuario=@IdUsuarioEjecucion,
             @CantidadCopiada=@Cantidad OUTPUT;
        SET @cAcceso=ISNULL(@Cantidad,0);

        EXEC dbo.sp_CopiarBeflexInicio2
             @IdEmpresaOrigen=@IdEmpresaModeloB3,
             @IdEmpresaDestino=@IdEmpresa,
             @IdUsuario=@IdUsuarioEjecucion,
             @CantidadCopiada=@Cantidad OUTPUT;
        SET @cInicio=ISNULL(@Cantidad,0);

        /* Estilos B3: sólo catálogos ausentes; se conservan valores del destino. */
        INSERT INTO dbo.bf_EstiloEmpresa
        (
            EEIdEmpresa, EEidCatalogoEstilo, EEValor, EEIdEstatus,
            EEIdUsuarioCreo, EEFechaCreacion,
            EEIdUsuarioModifico, EEFechaModificacion
        )
        SELECT @IdEmpresa, src.EEidCatalogoEstilo, src.EEValor, src.EEIdEstatus,
               @IdUsuarioEjecucion, GETDATE(), @IdUsuarioEjecucion, GETDATE()
        FROM dbo.bf_EstiloEmpresa src
        WHERE src.EEIdEmpresa=@IdEmpresaModeloB3
          AND src.EEIdEstatus=1
          AND NOT EXISTS
          (
              SELECT 1 FROM dbo.bf_EstiloEmpresa dst
              WHERE dst.EEIdEmpresa=@IdEmpresa
                AND dst.EEidCatalogoEstilo=src.EEidCatalogoEstilo
                AND dst.EEIdEstatus=1
          );
        SET @cEstilos=@@ROWCOUNT;

        EXEC dbo.sp_CopiarMenusV2_MVP
             @IdEmpresaOrigen=@IdEmpresaModeloB3,
             @IdEmpresaDestino=@IdEmpresa,
             @IdUsuario=@IdUsuarioEjecucion,
             @CantidadCopiada=@Cantidad OUTPUT,
             @RolModeloV2=@IdRolModeloMenuB3;
        SET @cMenus=ISNULL(@Cantidad,0);

        EXEC dbo.sp_CopiarCargaMasiva_MVP
             @IdEmpresaOrigen=@IdEmpresaModeloB3,
             @IdEmpresaDestino=@IdEmpresa,
             @IdUsuario=@IdUsuarioEjecucion,
             @CantidadCopiada=@Cantidad OUTPUT,
             @EmpresaModelo=@IdEmpresaModeloB3;
        SET @cCarga=ISNULL(@Cantidad,0);

        EXEC dbo.sp_CopiarParametroMismoSexo_MVP
             @IdEmpresaOrigen=@IdEmpresaModeloB3,
             @IdEmpresaDestino=@IdEmpresa,
             @IdUsuario=@IdUsuarioEjecucion,
             @CantidadCopiada=@Cantidad OUTPUT,
             @ParamId=@IdParametroMismoSexo,
             @EmpresaModelo=@IdEmpresaParametroMismoSexo;
        SET @cParametros=ISNULL(@Cantidad,0);

        /* Aviso de privacidad: corporativo y empresa, sólo si no existe. */
        IF NOT EXISTS (SELECT 1 FROM dbo.ff_Parametro
                       WHERE paIdEmpresa=@IdCorporativo
                         AND paId=@IdParametroAvisoPrivacidad)
        BEGIN
            INSERT INTO dbo.ff_Parametro
            (
                paId,paIdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
                paUsuarioAdd,paFechaAdd,paUsuarioUmod,paFechaUmod,paUsuarioPerfil
            )
            SELECT paId,@IdCorporativo,paClase,paValor,paDescripcion,paidEstatus,
                   @IdUsuarioEjecucion,GETDATE(),@IdUsuarioEjecucion,GETDATE(),paUsuarioPerfil
            FROM dbo.ff_Parametro
            WHERE paIdEmpresa=@IdCorporativoModeloB3
              AND paId=@IdParametroAvisoPrivacidad
              AND paidEstatus=1;
            SET @cParametros=@cParametros+@@ROWCOUNT;
        END;

        IF NOT EXISTS (SELECT 1 FROM dbo.ff_Parametro
                       WHERE paIdEmpresa=@IdEmpresa
                         AND paId=@IdParametroAvisoPrivacidad)
        BEGIN
            INSERT INTO dbo.ff_Parametro
            (
                paId,paIdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
                paUsuarioAdd,paFechaAdd,paUsuarioUmod,paFechaUmod,paUsuarioPerfil
            )
            SELECT paId,@IdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
                   @IdUsuarioEjecucion,GETDATE(),@IdUsuarioEjecucion,GETDATE(),paUsuarioPerfil
            FROM dbo.ff_Parametro
            WHERE paIdEmpresa=@IdCorporativo
              AND paId=@IdParametroAvisoPrivacidad
              AND paidEstatus=1;
            SET @cParametros=@cParametros+@@ROWCOUNT;
        END;

        /* No agregar paId 232: activa SSO y puede redirigir al tenant equivocado. */

        EXEC dbo.sp_CopiarPlanesEmpresa
             @IdEmpresaOrigen=@IdEmpresaModeloB3,
             @IdEmpresaDestino=@IdEmpresa,
             @IdUsuario=@IdUsuarioEjecucion,
             @CantidadCopiada=@Cantidad OUTPUT;
        SET @cPlanes=ISNULL(@Cantidad,0);

        /* Reparar exclusivamente referencias administrativas inválidas. */
        SELECT TOP 1 @PerfilAdmin=p.PEIdPerfil, @RolAdmin=p.PEIdRolDefault
        FROM dbo.ff_Perfil p
        JOIN dbo.ff_Rol r ON r.ROIdRol=p.PEIdRolDefault
                           AND r.ROIdEmpresa=p.PEIdEmpresa
                           AND r.ROIdEstatus=1
        WHERE p.PEIdEmpresa=@IdEmpresa
          AND p.PEAdministrador=1
          AND p.PEIdEstatus=1
        ORDER BY p.PEIdPerfil;

        IF EXISTS
        (
            SELECT 1
            FROM dbo.ff_AdministradorEmpresa a
            LEFT JOIN dbo.ff_Perfil p ON p.PEIdPerfil=a.AEIdPerfil
                                     AND p.PEIdEmpresa=a.AEIdEmpresa
                                     AND p.PEIdEstatus=1
            LEFT JOIN dbo.ff_Rol r ON r.ROIdRol=a.AEIdRol
                                  AND r.ROIdEmpresa=a.AEIdEmpresa
                                  AND r.ROIdEstatus=1
            WHERE a.AEIdEmpresa=@IdEmpresa AND a.AEIdEstatus=1
              AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL)
        )
        BEGIN
            IF @PerfilAdmin IS NULL OR @RolAdmin IS NULL
                THROW 51000, 'Hay administradores invalidos y no existe perfil administrador valido.', 1;

            INSERT INTO dbo.bf_MigracionMVPB3_BackupAdministrador
            (
                IdEjecucion,AEIdr,IdEmpresa,AEIdRolAnterior,AEIdPerfilAnterior,
                AEUsuarioUModAnterior,AEFechaUModAnterior
            )
            SELECT @IdEjecucion,a.AEIdr,@IdEmpresa,a.AEIdRol,a.AEIdPerfil,
                   a.AEUsuarioUMod,a.AEFechaUMod
            FROM dbo.ff_AdministradorEmpresa a
            LEFT JOIN dbo.ff_Perfil p ON p.PEIdPerfil=a.AEIdPerfil
                                     AND p.PEIdEmpresa=a.AEIdEmpresa
                                     AND p.PEIdEstatus=1
            LEFT JOIN dbo.ff_Rol r ON r.ROIdRol=a.AEIdRol
                                  AND r.ROIdEmpresa=a.AEIdEmpresa
                                  AND r.ROIdEstatus=1
            WHERE a.AEIdEmpresa=@IdEmpresa AND a.AEIdEstatus=1
              AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL);

            UPDATE a
               SET a.AEIdPerfil=@PerfilAdmin,
                   a.AEIdRol=@RolAdmin,
                   a.AEUsuarioUMod=@IdUsuarioEjecucion,
                   a.AEFechaUMod=GETDATE()
            FROM dbo.ff_AdministradorEmpresa a
            JOIN dbo.bf_MigracionMVPB3_BackupAdministrador b
              ON b.IdEjecucion=@IdEjecucion AND b.AEIdr=a.AEIdr;
            SET @cAdmins=@@ROWCOUNT;
        END;

        INSERT INTO dbo.bf_BitacoraEmpresa
        (
            BEIdEmpresa,BEIdUsuario,BEAccion,BEDetalle,BEElementoAfectado,
            BECantidadElementos,BEExitoso,BEFechaCreacion
        )
        VALUES
        (
            @IdEmpresa,@IdUsuarioEjecucion,'HOMOLOGAR_MVP_B3_COEXISTENCIA',
            'Ejecucion '+CONVERT(VARCHAR(36),@IdEjecucion),
            'componentes_b3',
            @cAcceso+@cInicio+@cEstilos+@cMenus+@cCarga+@cParametros+@cPlanes+@cAdmins,
            1,GETDATE()
        );

        INSERT INTO dbo.bf_MigracionMVPB3_Detalle
        (
            IdEjecucion,IdEmpresa,Exitoso,AccesosAgregados,InicioAgregado,
            EstilosAgregados,MenusAgregados,OperacionesAgregadas,
            ParametrosAgregados,DocumentosPlanAgregados,AdministradoresReparados
        )
        VALUES
        (
            @IdEjecucion,@IdEmpresa,1,@cAcceso,@cInicio,@cEstilos,@cMenus,
            @cCarga,@cParametros,@cPlanes,@cAdmins
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        SET @Error=LEFT(ERROR_MESSAGE(),2000);

        INSERT INTO dbo.bf_MigracionMVPB3_Detalle
            (IdEjecucion,IdEmpresa,Exitoso,MensajeError)
        VALUES (@IdEjecucion,@IdEmpresa,0,@Error);
    END CATCH;

    FETCH NEXT FROM empresas INTO @IdEmpresa, @IdCorporativo;
END;

CLOSE empresas;
DEALLOCATE empresas;

UPDATE dbo.bf_MigracionMVPB3_Ejecucion
   SET FechaFin=GETDATE(),
       Estado=CASE WHEN EXISTS
                    (SELECT 1 FROM dbo.bf_MigracionMVPB3_Detalle
                     WHERE IdEjecucion=@IdEjecucion AND Exitoso=0)
                   THEN 'TERMINADA_CON_ERRORES' ELSE 'TERMINADA' END
WHERE IdEjecucion=@IdEjecucion;

SELECT * FROM dbo.bf_MigracionMVPB3_Ejecucion WHERE IdEjecucion=@IdEjecucion;
SELECT * FROM dbo.bf_MigracionMVPB3_Detalle WHERE IdEjecucion=@IdEjecucion ORDER BY IdEmpresa;

PRINT 'Conserve el IdEjecucion. Es requerido para validacion y reversa.';

