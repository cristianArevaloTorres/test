/*
===============================================================================
 ANALISIS TECNICO: EMPRESAS MVP B2 Y EMPRESAS MVP B3
===============================================================================

 OBJETIVO
 -------
 Documentar, antes de ejecutar la homologacion, que hace B2, que requiere B3,
 cuales objetos son compartidos y de donde se obtuvo cada conclusion.

 ESTE ARCHIVO NO MODIFICA DATOS.
 Contiene comentarios y consultas de solo lectura sobre metadatos.

 CONCLUSION PRINCIPAL
 --------------------
 Las 286 empresas NO deben borrarse ni volver a crearse. B2 y B3 comparten la
 misma entidad ff_Empresa y varias tablas operativas. La solucion segura es
 conservar el mismo EMidEmpresa y completar solamente la configuracion B3 que
 falte, con validacion previa, bitacora y posibilidad de reversa.

 FUENTES REVISADAS
 -----------------
 1. Codigo legacy B2:
    FlexiForbesV2/ADMFF/ff_AddEmpresa.aspx.cs
    - linea 259: ejecuta el procedimiento ff_AddEmpresa.
    - linea 365: ejecuta ff_CopyDocument.

    FlexiForbesV2/ADMFF/bf_ReplicarEmpresa.aspx.cs
    - linea 249: ejecuta bf_ReplicarEmpresa.

 2. Codigo Java B3:
    WSBeFlex/REST/WSEmpresaMVP.java
    - linea 36: publica la ruta beflex/empresa-mvp.
    - linea 143: publica POST /crear.

    WSBeFlex/DAO/JDBCEmpresaMVP.java
    - linea 72:  sp_CrearEmpresaMVP.
    - linea 92:  sp_CopiarMenusEmpresa.
    - linea 110: sp_CopiarRolesEmpresa.
    - linea 128: sp_CopiarImagenesEmpresa.
    - linea 146: sp_CopiarColoresEmpresa.
    - linea 164: sp_CopiarDocumentosEmpresa.
    - linea 182: sp_CopiarPerfilesEmpresa.
    - linea 200: sp_CopiarPlanesEmpresa.
    - linea 218: sp_CopiarParametrosEmpresa.
    - lineas 255, 278 y 289: usa bf_BitacoraEmpresa.

    WSBeFlex/DAO/JDBCFfMenusRol.java
    - lineas 56 y 62: consulta ff_MenuRol2 para la navegacion B3.

    WSBeFlex/DAO/CargaMasivaB2DAO.java
    - linea 26: consulta ff_CargaMasivaOperacionEmpresa desde B3.

    WSBeFlex/DAO/JDBCPlan.java
    - linea 260: ejecuta FF_BuscaDocumentosPlanesB3.

    WSBeFlex/DAO/JDBCFfEmpleado.java
    - linea 867: consulta ff_PlantillaPerfil.

 3. Base de referencia analizada:
    servidor: (localdb)\MSSQLLocalDB
    base:     FlexiForbesv2

    La base local tiene el esquema, pero no contiene las 286 empresas. Los
    resultados definitivos deben obtenerse en una copia reciente de la base
    funcional y despues repetirse en QA.

===============================================================================
 QUE HACE B2
===============================================================================

 La pantalla legacy crea la empresa mediante ff_AddEmpresa, conserva su
 corporativo/padre, genera o copia el CSS cla<IdEmpresa>.css, copia documentos
 fisicos mediante ff_CopyDocument y continua con un wizard de configuracion.

 La version B2 revisada NO envia el parametro @EM_MVP. La definicion local de
 ff_AddEmpresa si contiene ese parametro opcional y, cuando vale 1, llama a
 bf_ProcesoMVP e inserta bf_EmpresaMVP. Esto es una extension SQL posterior o
 un puente hacia MVP; no esta demostrado como llamada de la pantalla B2
 revisada.

 Objetos demostrados directamente por codigo B2:
 - ff_AddEmpresa
 - ff_CopyDocument
 - bf_ReplicarEmpresa

===============================================================================
 QUE HACE O REQUIERE B3
===============================================================================

 El backend Java B3 publica una API de empresa MVP y llama procedimientos para
 crear/copiar configuracion. Ademas, otros DAOs B3 demuestran el consumo de:

 - ff_MenuRol2: navegacion B3.
 - ff_CargaMasivaOperacionEmpresa: operaciones habilitadas de carga masiva.
 - ff_DocumentoPlanB3 mediante FF_BuscaDocumentosPlanesB3.
 - ff_PlantillaPerfil: plantilla aplicable al empleado/perfil.
 - bf_BitacoraEmpresa: seguimiento del proceso MVP.

 Los procedimientos bf_ProcesoMVP y sp_CrearEmpresaMVP de la BD local llaman
 una familia sp_Copiar*. Esa dependencia SQL demuestra el armado del paquete
 MVP B3, aunque algunos de esos procedimientos operan sobre tablas compartidas.

 IMPORTANTE:
 - sp_CrearEmpresaMVP es para CREAR una empresa nueva. No debe ejecutarse para
   homologar las 286 empresas que ya existen.
 - bf_ProcesoMVP trabaja sobre una empresa existente, pero no debe ejecutarse
   masivamente sin control porque su cascada contiene reemplazos y borrados.

===============================================================================
 CLASIFICACION DE TABLAS
===============================================================================

 COMPARTIDAS B2/B3
 -----------------
 ff_Empresa
   Identidad principal. B2 la crea y B3 utiliza el mismo EMidEmpresa.

 ff_Rol, ff_Perfil, ff_AdministradorEmpresa
   Seguridad y administracion. B3 tambien las consume; no deben reemplazarse
   en bloque porque pueden contener configuracion activa de B2.

 ff_Parametro
   Configuracion compartida. B3 la lee desde JDBCParametro. Solo deben
   insertarse parametros B3 faltantes; no copiar todo el modelo encima.

 ff_Documentos
   B2 copia documentos con ff_CopyDocument y B3 conserva/consulta documentos.

 ff_Plantilla, ff_PlantillaPerfil
   Son compartidas. Las asignaciones pueden entrar en conflicto durante el
   corte; primero se respaldan y despues se decide cual queda activa.

 PRINCIPALMENTE B2 O DE COMPATIBILIDAD
 -------------------------------------
 ff_MenuRol
   La usan los procesos legacy y se conserva por compatibilidad.

 DEMOSTRADAS COMO B3
 -------------------
 ff_MenuRol2
   Evidencia: JDBCFfMenusRol.java, lineas 56 y 62.

 ff_DocumentoPlanB3
   Evidencia: sp_CopiarPlanesEmpresa la alimenta y JDBCPlan.java, linea 260,
   ejecuta FF_BuscaDocumentosPlanesB3.

 bf_BeflexInicio2
   La alimenta sp_CopiarBeflexInicio2 dentro de los orquestadores MVP.

 bf_EstiloEmpresa
   La alimenta sp_CopiarConfiguracionEmpresa como configuracion visual B3.

 bf_BitacoraEmpresa
   Evidencia: JDBCEmpresaMVP.java, lineas 255, 278 y 289.

 COMPARTIDA, PERO REQUERIDA POR EL FLUJO B3
 ------------------------------------------
 ff_CargaMasivaOperacionEmpresa
   Evidencia: CargaMasivaB2DAO.java, linea 26. El nombre del DAO refleja la
   reutilizacion de carga B2, pero la consulta ocurre dentro del backend B3.

 MARCADOR MVP EN BASE DE DATOS
 -----------------------------
 bf_EmpresaMVP
   Define el universo de empresas MVP para estos scripts. La definicion local
   de ff_AddEmpresa inserta la marca cuando @EM_MVP=1. No se encontro una
   consulta directa a esta tabla en JDBCEmpresaMVP.java.

 TABLAS TECNICAS DE ESTA MIGRACION
 ---------------------------------
 bf_MigracionMVPB3_*
   No son tablas funcionales de B2 ni de B3. Sirven exclusivamente para dejar
   evidencia, registrar resultados y permitir una reversa controlada.

===============================================================================
 CLASIFICACION DE PROCEDIMIENTOS
===============================================================================

 B2 DEMOSTRADO POR CODIGO
 ------------------------
 ff_AddEmpresa         -> ff_AddEmpresa.aspx.cs, linea 259.
 ff_CopyDocument       -> ff_AddEmpresa.aspx.cs, linea 365.
 bf_ReplicarEmpresa    -> bf_ReplicarEmpresa.aspx.cs, linea 249.

 B3 DEMOSTRADO POR CODIGO JAVA
 -----------------------------
 sp_CrearEmpresaMVP
 sp_CopiarMenusEmpresa
 sp_CopiarRolesEmpresa
 sp_CopiarImagenesEmpresa
 sp_CopiarColoresEmpresa
 sp_CopiarDocumentosEmpresa
 sp_CopiarPerfilesEmpresa
 sp_CopiarPlanesEmpresa
 sp_CopiarParametrosEmpresa

 B3 DEMOSTRADO POR DEPENDENCIAS SQL DEL PAQUETE MVP
 -------------------------------------------------
 sp_CopiarAccesoBeflex
 sp_CopiarBeflexInicio2
 sp_CopiarConfiguracionEmpresa
 sp_CopiarPlantillasMVP
 sp_CopiarReporteInterfabricaMVP
 sp_CopiarMenusV2_MVP
 sp_CopiarCargaMasiva_MVP
 sp_CopiarParametroMismoSexo_MVP

 PUENTE SQL B2 -> MVP
 -------------------
 bf_ProcesoMVP
   Lo llama ff_AddEmpresa local cuando @EM_MVP=1. Opera sobre una empresa ya
   existente, pero su uso no aparece en la pantalla B2 revisada.

===============================================================================
 PROCEDIMIENTOS QUE NO SE EJECUTAN EN BLOQUE DURANTE LA COEXISTENCIA
===============================================================================

 sp_CopiarImagenesEmpresa
   Elimina las imagenes del destino antes de copiar.

 sp_CopiarColoresEmpresa
   Elimina parametros de color, estilo o CSS del destino.

 sp_CopiarParametrosEmpresa
   Elimina parametros coincidentes antes de copiar los del modelo.

 sp_CopiarDocumentosEmpresa
   Elimina documentos del destino cuando coincide el nombre.

 sp_CopiarPerfilesEmpresa
   Actualiza perfiles existentes con valores del modelo.

 sp_CopiarPlantillasMVP
   Elimina determinadas asignaciones heredadas de titulares.

 sp_CopiarReporteInterfabricaMVP
   Elimina otras asignaciones de Interfabrica.

 Por estas razones no se usa directamente bf_ProcesoMVP para las 286 empresas.
 La solucion 02_HOMOLOGACION_MVP_B3_COEXISTENCIA.sql agrega solo faltantes y
 conserva los valores existentes.

===============================================================================
 RESULTADO ESPERADO
===============================================================================

 1. Permanecen las mismas 286 empresas y los mismos EMidEmpresa.
 2. No se borra informacion ni historial B2.
 3. Se agregan unicamente componentes B3 ausentes.
 4. Las personalizaciones existentes tienen prioridad sobre el modelo.
 5. Las plantillas conflictivas se atienden en una fase de corte separada.
 6. Una segunda ejecucion no duplica configuracion.
 7. Cada cambio queda asociado a un IdEjecucion para validacion/reversa.

===============================================================================
 CONSULTA 1: MATRIZ DOCUMENTAL DE OBJETOS
 Esta salida resume la clasificacion anterior; no inspecciona datos funcionales.
===============================================================================
*/

SET NOCOUNT ON;

SELECT Objeto, TipoObjeto, Clasificacion, Evidencia
FROM
(
    VALUES
    ('ff_AddEmpresa','PROCEDIMIENTO','B2','ff_AddEmpresa.aspx.cs:259'),
    ('ff_CopyDocument','PROCEDIMIENTO','B2','ff_AddEmpresa.aspx.cs:365'),
    ('bf_ReplicarEmpresa','PROCEDIMIENTO','B2','bf_ReplicarEmpresa.aspx.cs:249'),
    ('bf_ProcesoMVP','PROCEDIMIENTO','PUENTE SQL B2-MVP','ff_AddEmpresa local cuando @EM_MVP=1'),
    ('sp_CrearEmpresaMVP','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:72'),
    ('sp_CopiarMenusEmpresa','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:92'),
    ('sp_CopiarRolesEmpresa','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:110'),
    ('sp_CopiarImagenesEmpresa','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:128'),
    ('sp_CopiarColoresEmpresa','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:146'),
    ('sp_CopiarDocumentosEmpresa','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:164'),
    ('sp_CopiarPerfilesEmpresa','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:182'),
    ('sp_CopiarPlanesEmpresa','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:200'),
    ('sp_CopiarParametrosEmpresa','PROCEDIMIENTO','B3','JDBCEmpresaMVP.java:218'),
    ('ff_Empresa','TABLA','COMPARTIDA B2/B3','Identidad creada por B2 y conservada por B3'),
    ('ff_Rol','TABLA','COMPARTIDA B2/B3','Seguridad usada por ambos flujos'),
    ('ff_Perfil','TABLA','COMPARTIDA B2/B3','Perfiles usados por ambos flujos'),
    ('ff_AdministradorEmpresa','TABLA','COMPARTIDA B2/B3','Relacion administrador-empresa-rol-perfil'),
    ('ff_Parametro','TABLA','COMPARTIDA B2/B3','JDBCParametro.java y configuracion legacy'),
    ('ff_MenuRol','TABLA','B2/COMPATIBILIDAD','Menus legacy'),
    ('ff_MenuRol2','TABLA','B3','JDBCFfMenusRol.java:56,62'),
    ('ff_CargaMasivaOperacionEmpresa','TABLA','COMPARTIDA/REQUERIDA B3','CargaMasivaB2DAO.java:26'),
    ('ff_DocumentoPlanB3','TABLA','B3','sp_CopiarPlanesEmpresa y JDBCPlan.java:260'),
    ('ff_PlantillaPerfil','TABLA','COMPARTIDA','JDBCFfEmpleado.java:867; asignacion tambien usada por legacy'),
    ('bf_BitacoraEmpresa','TABLA','B3/MVP','JDBCEmpresaMVP.java:255,278,289'),
    ('bf_BeflexInicio2','TABLA','B3','sp_CopiarBeflexInicio2'),
    ('bf_EstiloEmpresa','TABLA','B3','sp_CopiarConfiguracionEmpresa'),
    ('bf_EmpresaMVP','TABLA','MARCADOR MVP','ff_AddEmpresa local cuando @EM_MVP=1')
) d(Objeto, TipoObjeto, Clasificacion, Evidencia)
ORDER BY TipoObjeto, Objeto;

/*
===============================================================================
 CONSULTA 2: EXISTENCIA REAL DE LOS OBJETOS EN EL AMBIENTE ACTUAL
===============================================================================
*/

SELECT
    Nombre = v.Objeto,
    v.TipoEsperado,
    Existe = CASE
        WHEN v.TipoEsperado='PROCEDIMIENTO'
         AND OBJECT_ID('dbo.'+v.Objeto,'P') IS NOT NULL THEN 'SI'
        WHEN v.TipoEsperado='TABLA'
         AND OBJECT_ID('dbo.'+v.Objeto,'U') IS NOT NULL THEN 'SI'
        ELSE 'NO'
    END,
    FechaCreacion = o.create_date,
    FechaModificacion = o.modify_date
FROM
(
    VALUES
    ('ff_AddEmpresa','PROCEDIMIENTO'),
    ('bf_ProcesoMVP','PROCEDIMIENTO'),
    ('sp_CrearEmpresaMVP','PROCEDIMIENTO'),
    ('sp_CopiarMenusV2_MVP','PROCEDIMIENTO'),
    ('sp_CopiarCargaMasiva_MVP','PROCEDIMIENTO'),
    ('sp_CopiarPlantillasMVP','PROCEDIMIENTO'),
    ('ff_Empresa','TABLA'),
    ('bf_EmpresaMVP','TABLA'),
    ('ff_MenuRol2','TABLA'),
    ('ff_CargaMasivaOperacionEmpresa','TABLA'),
    ('ff_DocumentoPlanB3','TABLA'),
    ('bf_BitacoraEmpresa','TABLA')
) v(Objeto,TipoEsperado)
LEFT JOIN sys.objects o
  ON o.object_id=OBJECT_ID('dbo.'+v.Objeto)
ORDER BY v.TipoEsperado,v.Objeto;

/*
===============================================================================
 CONSULTA 3: DEPENDENCIAS SQL REALES DE LOS ORQUESTADORES MVP

 Permite comprobar en cada ambiente que procedimientos/tablas llaman
 bf_ProcesoMVP y sp_CrearEmpresaMVP. Si la definicion de produccion difiere de
 la local, esta consulta lo mostrara y se debe detener la homologacion hasta
 comparar ambas versiones.
===============================================================================
*/

SELECT
    Orquestador = OBJECT_SCHEMA_NAME(d.referencing_id)+'.'+OBJECT_NAME(d.referencing_id),
    ObjetoReferenciado = COALESCE(d.referenced_schema_name+'.','')+
                         COALESCE(d.referenced_entity_name,''),
    TipoObjeto = o.type_desc
FROM sys.sql_expression_dependencies d
LEFT JOIN sys.objects o ON o.object_id=d.referenced_id
WHERE d.referencing_id IN
(
    OBJECT_ID('dbo.bf_ProcesoMVP'),
    OBJECT_ID('dbo.sp_CrearEmpresaMVP')
)
ORDER BY Orquestador,ObjetoReferenciado;

PRINT 'Analisis terminado. Este archivo no modifico datos.';
