/*
    INVENTARIO Y PREVALIDACION - MVP B2 vs B3
    Solo lectura. No modifica datos.

    Ajustar los identificadores modelo para el ambiente que se analiza.
    No asumir que los IDs de desarrollo son iguales en QA o Produccion.
*/

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @CantidadEsperada             INT = 286;
DECLARE @IdEmpresaModeloB3            INT = 2494;
DECLARE @IdCorporativoModeloB3        INT = 2493;
DECLARE @IdRolModeloMenuB3            INT = 7365;
DECLARE @IdPlantillaInterfabrica      INT = 689;
DECLARE @IdEmpresaParametroMismoSexo  INT = 645;
DECLARE @IdParametroMismoSexo         INT = 128;
DECLARE @IdParametroAvisoPrivacidad   INT = 226;
DECLARE @IdParametroSSO               INT = 232;

IF DB_NAME() IS NULL
    THROW 51000, 'No fue posible determinar la base de datos actual.', 1;

IF OBJECT_ID('dbo.ff_Empresa', 'U') IS NULL
    THROW 51000, 'No existe dbo.ff_Empresa.', 1;

IF OBJECT_ID('dbo.bf_EmpresaMVP', 'U') IS NULL
    THROW 51000, 'No existe dbo.bf_EmpresaMVP; no se puede identificar el universo MVP.', 1;

DROP TABLE IF EXISTS #EmpresasMVP;

SELECT DISTINCT
       m.IdEmpresa,
       e.EMNombre,
       e.EMidCorporativo,
       e.EMidEstatus,
       m.IdEstatus AS IdEstatusMVP
INTO #EmpresasMVP
FROM dbo.bf_EmpresaMVP m
LEFT JOIN dbo.ff_Empresa e
       ON e.EMidEmpresa = m.IdEmpresa
WHERE m.IdEstatus = 1;

/* 1. Universo */
SELECT
    DB_NAME() AS BaseDatos,
    COUNT(*) AS EmpresasMVPEncontradas,
    SUM(CASE WHEN EMidEstatus = 1 THEN 1 ELSE 0 END) AS EmpresasActivas,
    SUM(CASE WHEN EMidEstatus IS NULL THEN 1 ELSE 0 END) AS MarcasSinEmpresa,
    @CantidadEsperada AS CantidadEsperada,
    CASE WHEN COUNT(*) = @CantidadEsperada THEN 'OK' ELSE 'REVISAR' END AS ResultadoCantidad
FROM #EmpresasMVP;

SELECT IdEmpresa, COUNT(*) AS MarcasActivas
FROM dbo.bf_EmpresaMVP
WHERE IdEstatus = 1
GROUP BY IdEmpresa
HAVING COUNT(*) > 1;

/* 2. Objetos requeridos */
DECLARE @Objetos TABLE
(
    Objeto SYSNAME NOT NULL,
    Tipo   VARCHAR(2) NOT NULL,
    Uso    VARCHAR(200) NOT NULL
);

INSERT INTO @Objetos (Objeto, Tipo, Uso)
VALUES
('bf_BitacoraEmpresa',             'U', 'Trazabilidad'),
('bf_BeflexInicio2',                'U', 'Inicio B3'),
('bf_EstiloEmpresa',                'U', 'Estilos B3'),
('ff_MenuRol2',                     'U', 'Menus B3'),
('ff_CargaMasivaOperacionEmpresa',  'U', 'Carga masiva B3'),
('ff_DocumentoPlanB3',              'U', 'Documentos de plan B3'),
('ff_Plantilla',                    'U', 'Plantillas'),
('ff_PlantillaPerfil',              'U', 'Asignacion de plantillas'),
('sp_CopiarAccesoBeflex',           'P', 'Acceso B3'),
('sp_CopiarBeflexInicio2',          'P', 'Inicio B3'),
('sp_CopiarConfiguracionEmpresa',   'P', 'Configuracion adicional'),
('sp_CopiarPlanesEmpresa',          'P', 'DocumentoPlanB3'),
('sp_CopiarMenusV2_MVP',            'P', 'Menus B3'),
('sp_CopiarCargaMasiva_MVP',        'P', 'Carga masiva B3'),
('sp_CopiarParametroMismoSexo_MVP', 'P', 'Parametro corporativo'),
('sp_CopiarPlantillasMVP',          'P', 'Plantillas MVP'),
('sp_CopiarReporteInterfabricaMVP', 'P', 'Interfabrica');

SELECT
    Objeto,
    Uso,
    CASE WHEN OBJECT_ID('dbo.' + Objeto, Tipo) IS NOT NULL THEN 'OK' ELSE 'FALTA' END AS Resultado
FROM @Objetos
ORDER BY Resultado DESC, Objeto;

/* 3. Referencias modelo: deben resolverse nuevamente en cada ambiente */
SELECT 'Empresa modelo B3' AS Referencia, @IdEmpresaModeloB3 AS IdConfigurado,
       COUNT(*) AS Coincidencias,
       CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'REVISAR' END AS Resultado
FROM dbo.ff_Empresa WHERE EMidEmpresa = @IdEmpresaModeloB3 AND EMidEstatus = 1
UNION ALL
SELECT 'Corporativo modelo B3', @IdCorporativoModeloB3, COUNT(*),
       CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'REVISAR' END
FROM dbo.ff_Empresa WHERE EMidEmpresa = @IdCorporativoModeloB3 AND EMidEstatus = 1
UNION ALL
SELECT 'Rol modelo menus B3', @IdRolModeloMenuB3, COUNT(*),
       CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'REVISAR' END
FROM dbo.ff_Rol WHERE ROIdRol = @IdRolModeloMenuB3 AND ROIdEstatus = 1
UNION ALL
SELECT 'Plantilla Interfabrica', @IdPlantillaInterfabrica, COUNT(*),
       CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'REVISAR' END
FROM dbo.ff_Plantilla WHERE PLIdPlantilla = @IdPlantillaInterfabrica AND PLIdEstatus = 1
UNION ALL
SELECT 'Parametro mismo sexo empresa modelo', @IdEmpresaParametroMismoSexo, COUNT(*),
       CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'REVISAR' END
FROM dbo.ff_Parametro
WHERE paIdEmpresa = @IdEmpresaParametroMismoSexo AND paId = @IdParametroMismoSexo;

/* 4. Matriz de cumplimiento por empresa */
DROP TABLE IF EXISTS #Cumplimiento;

SELECT
    e.IdEmpresa,
    e.EMNombre,
    e.EMidCorporativo,
    e.EMidEstatus,
    RolesActivos = (SELECT COUNT(*) FROM dbo.ff_Rol r
                    WHERE r.ROIdEmpresa = e.IdEmpresa AND r.ROIdEstatus = 1),
    PerfilesActivos = (SELECT COUNT(*) FROM dbo.ff_Perfil p
                       WHERE p.PEIdEmpresa = e.IdEmpresa AND p.PEIdEstatus = 1),
    AdministradoresValidos =
    (
        SELECT COUNT(*)
        FROM dbo.ff_AdministradorEmpresa a
        JOIN dbo.ff_Perfil p ON p.PEIdPerfil = a.AEIdPerfil
                            AND p.PEIdEmpresa = a.AEIdEmpresa
                            AND p.PEIdEstatus = 1
        JOIN dbo.ff_Rol r ON r.ROIdRol = a.AEIdRol
                         AND r.ROIdEmpresa = a.AEIdEmpresa
                         AND r.ROIdEstatus = 1
        WHERE a.AEIdEmpresa = e.IdEmpresa AND a.AEIdEstatus = 1
    ),
    AdministradoresInvalidos =
    (
        SELECT COUNT(*)
        FROM dbo.ff_AdministradorEmpresa a
        LEFT JOIN dbo.ff_Perfil p ON p.PEIdPerfil = a.AEIdPerfil
                                 AND p.PEIdEmpresa = a.AEIdEmpresa
                                 AND p.PEIdEstatus = 1
        LEFT JOIN dbo.ff_Rol r ON r.ROIdRol = a.AEIdRol
                              AND r.ROIdEmpresa = a.AEIdEmpresa
                              AND r.ROIdEstatus = 1
        WHERE a.AEIdEmpresa = e.IdEmpresa
          AND a.AEIdEstatus = 1
          AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL)
    ),
    MenusB3Activos =
    (
        SELECT COUNT(*)
        FROM dbo.ff_MenuRol2 mr
        JOIN dbo.ff_Rol r ON r.ROIdRol = mr.MRidRol
        WHERE r.ROIdEmpresa = e.IdEmpresa
          AND r.ROIdEstatus = 1
          AND mr.MRidEstatus = 1
    ),
    AccesoBeflex = (SELECT COUNT(*) FROM dbo.ff_accesoBeflex a
                    WHERE a.idempresa = e.IdEmpresa AND a.acceso = 1),
    ConfiguracionInicioB3 =
    (
        SELECT COUNT(*) FROM dbo.bf_BeflexInicio2 b
        WHERE b.BI_IdCorporativo = e.EMidCorporativo
          AND b.BI_Valor = e.IdEmpresa
          AND b.BI_IdEstatus = 1
    ),
    EstilosB3 = (SELECT COUNT(*) FROM dbo.bf_EstiloEmpresa s
                 WHERE s.EEIdEmpresa = e.IdEmpresa AND s.EEIdEstatus = 1),
    ImagenesEmpresa = (SELECT COUNT(*) FROM dbo.ff_EmpresaImagen i
                       WHERE i.EIIdEmpresa = e.IdEmpresa),
    DocumentosActivos = (SELECT COUNT(*) FROM dbo.ff_Documentos d
                         WHERE d.DOIdEmpresa = e.IdEmpresa AND d.DOUsuarioDel IS NULL),
    DocumentosPlanB3 = (SELECT COUNT(*) FROM dbo.ff_DocumentoPlanB3 d
                        WHERE d.DPIdEmpresa = e.IdEmpresa AND d.DPEstatus = 1),
    PlantillasMVP =
    (
        SELECT COUNT(*) FROM dbo.ff_Plantilla p
        WHERE p.PLIdEstatus = 1
          AND p.PLDescripcion COLLATE Latin1_General_CI_AI
              LIKE '%MVP[_]' + CONVERT(VARCHAR(12), e.IdEmpresa) + '%'
    ),
    OperacionesCargaMasivaB3 =
    (
        SELECT COUNT(DISTINCT c.CEIdOperacion)
        FROM dbo.ff_CargaMasivaOperacionEmpresa c
        WHERE c.CEIdEmpresa = e.IdEmpresa
          AND c.CEIdEstatus = 1
          AND c.CEIdOperacion IN (1, 2, 3, 13, 14)
    ),
    ParametroMismoSexoCorporativo =
    (
        SELECT COUNT(*) FROM dbo.ff_Parametro p
        WHERE p.paIdEmpresa = e.EMidCorporativo
          AND p.paId = @IdParametroMismoSexo
          AND p.paidEstatus = 1
    ),
    AvisoPrivacidadEmpresaOCorporativo =
    (
        SELECT COUNT(*) FROM dbo.ff_Parametro p
        WHERE p.paIdEmpresa IN (e.IdEmpresa, e.EMidCorporativo)
          AND p.paId = @IdParametroAvisoPrivacidad
          AND p.paidEstatus = 1
    ),
    AdvertenciaSSO =
    (
        SELECT COUNT(*) FROM dbo.ff_Parametro p
        WHERE p.paIdEmpresa IN (e.IdEmpresa, e.EMidCorporativo)
          AND p.paId = @IdParametroSSO
          AND p.paidEstatus = 1
          AND NULLIF(LTRIM(RTRIM(CONVERT(VARCHAR(1500), p.paValor))), '') IS NOT NULL
    )
INTO #Cumplimiento
FROM #EmpresasMVP e;

SELECT *,
       CASE
           WHEN EMidEstatus <> 1 THEN 'EMPRESA_INACTIVA'
           WHEN RolesActivos = 0 OR PerfilesActivos = 0 THEN 'FALTA_SEGURIDAD_BASE'
           WHEN AdministradoresInvalidos > 0 THEN 'REFERENCIA_ADMIN_INVALIDA'
           WHEN MenusB3Activos = 0
             OR AccesoBeflex = 0
             OR ConfiguracionInicioB3 = 0
             OR EstilosB3 = 0
             OR OperacionesCargaMasivaB3 < 5 THEN 'INCOMPLETA_B3'
           ELSE 'CANDIDATA_OK'
       END AS Diagnostico
FROM #Cumplimiento
ORDER BY Diagnostico, IdEmpresa;

/* 5. Resumen de brechas */
SELECT
    COUNT(*) AS Total,
    SUM(CASE WHEN EMidEstatus <> 1 THEN 1 ELSE 0 END) AS EmpresasInactivas,
    SUM(CASE WHEN RolesActivos = 0 THEN 1 ELSE 0 END) AS SinRoles,
    SUM(CASE WHEN PerfilesActivos = 0 THEN 1 ELSE 0 END) AS SinPerfiles,
    SUM(CASE WHEN AdministradoresInvalidos > 0 THEN 1 ELSE 0 END) AS ConAdminInvalido,
    SUM(CASE WHEN MenusB3Activos = 0 THEN 1 ELSE 0 END) AS SinMenusB3,
    SUM(CASE WHEN AccesoBeflex = 0 THEN 1 ELSE 0 END) AS SinAccesoBeflex,
    SUM(CASE WHEN ConfiguracionInicioB3 = 0 THEN 1 ELSE 0 END) AS SinInicioB3,
    SUM(CASE WHEN EstilosB3 = 0 THEN 1 ELSE 0 END) AS SinEstilosB3,
    SUM(CASE WHEN DocumentosPlanB3 = 0 THEN 1 ELSE 0 END) AS SinDocumentoPlanB3,
    SUM(CASE WHEN PlantillasMVP = 0 THEN 1 ELSE 0 END) AS SinPlantillasMVP,
    SUM(CASE WHEN OperacionesCargaMasivaB3 < 5 THEN 1 ELSE 0 END) AS CargaMasivaIncompleta,
    SUM(CASE WHEN ParametroMismoSexoCorporativo = 0 THEN 1 ELSE 0 END) AS SinParametroMismoSexo,
    SUM(CASE WHEN AvisoPrivacidadEmpresaOCorporativo = 0 THEN 1 ELSE 0 END) AS SinAvisoPrivacidad,
    SUM(CASE WHEN AdvertenciaSSO > 0 THEN 1 ELSE 0 END) AS ConSSOActivo
FROM #Cumplimiento;

/* 6. Duplicados y referencias logicas */
SELECT r.ROIdEmpresa AS IdEmpresa, RTRIM(r.RODescripcionCorta) AS Rol, COUNT(*) AS Cantidad
FROM dbo.ff_Rol r
JOIN #EmpresasMVP e ON e.IdEmpresa = r.ROIdEmpresa
WHERE r.ROIdEstatus = 1
GROUP BY r.ROIdEmpresa, RTRIM(r.RODescripcionCorta)
HAVING COUNT(*) > 1;

SELECT p.PEIdEmpresa AS IdEmpresa, p.PENombre AS Perfil, COUNT(*) AS Cantidad
FROM dbo.ff_Perfil p
JOIN #EmpresasMVP e ON e.IdEmpresa = p.PEIdEmpresa
WHERE p.PEIdEstatus = 1
GROUP BY p.PEIdEmpresa, p.PENombre
HAVING COUNT(*) > 1;

SELECT r.ROIdEmpresa AS IdEmpresa, mr.MRidRol, mr.MRidMenu, COUNT(*) AS Cantidad
FROM dbo.ff_MenuRol2 mr
JOIN dbo.ff_Rol r ON r.ROIdRol = mr.MRidRol
JOIN #EmpresasMVP e ON e.IdEmpresa = r.ROIdEmpresa
WHERE mr.MRidEstatus = 1
GROUP BY r.ROIdEmpresa, mr.MRidRol, mr.MRidMenu
HAVING COUNT(*) > 1;

SELECT a.AEIdr, a.AEIdEmpresa, a.ADIdAdministrador, a.AEIdPerfil, a.AEIdRol
FROM dbo.ff_AdministradorEmpresa a
JOIN #EmpresasMVP e ON e.IdEmpresa = a.AEIdEmpresa
LEFT JOIN dbo.ff_Perfil p ON p.PEIdPerfil = a.AEIdPerfil
                              AND p.PEIdEmpresa = a.AEIdEmpresa
                              AND p.PEIdEstatus = 1
LEFT JOIN dbo.ff_Rol r ON r.ROIdRol = a.AEIdRol
                         AND r.ROIdEmpresa = a.AEIdEmpresa
                         AND r.ROIdEstatus = 1
WHERE a.AEIdEstatus = 1
  AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL);

PRINT 'Prevalidacion terminada. Este script no modifico datos.';

