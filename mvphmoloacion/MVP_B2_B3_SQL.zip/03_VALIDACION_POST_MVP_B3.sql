/*
    VALIDACION POSTERIOR - HOMOLOGACION MVP B2 -> B3
    Solo lectura. No modifica datos.

    Si se conoce el IdEjecucion de 02_HOMOLOGACION..., colocarlo abajo.
    Si queda NULL, se valida el estado actual de todas las MVP activas.
*/

SET NOCOUNT ON;

DECLARE @IdEjecucion UNIQUEIDENTIFIER = NULL;
DECLARE @CantidadEsperada INT = 286;
DECLARE @IdEmpresaModeloB3 INT = 2494;
DECLARE @IdRolModeloMenuB3 INT = 7365;
DECLARE @IdParametroMismoSexo INT = 128;
DECLARE @IdParametroAvisoPrivacidad INT = 226;
DECLARE @IdParametroSSO INT = 232;

IF OBJECT_ID('dbo.bf_EmpresaMVP','U') IS NULL
    THROW 51000, 'No existe dbo.bf_EmpresaMVP.', 1;

DROP TABLE IF EXISTS #Empresas;

SELECT DISTINCT m.IdEmpresa,e.EMNombre,e.EMidCorporativo,e.EMidEstatus
INTO #Empresas
FROM dbo.bf_EmpresaMVP m
JOIN dbo.ff_Empresa e ON e.EMidEmpresa=m.IdEmpresa
WHERE m.IdEstatus=1;

/* 1. Universo e historial de ejecución */
SELECT COUNT(*) AS EmpresasMarcadasMVP,
       SUM(CASE WHEN EMidEstatus=1 THEN 1 ELSE 0 END) AS EmpresasActivas,
       @CantidadEsperada AS Esperadas,
       CASE WHEN COUNT(*)=@CantidadEsperada THEN 'PASS' ELSE 'FAIL' END AS Resultado
FROM #Empresas;

IF @IdEjecucion IS NOT NULL
BEGIN
    IF OBJECT_ID('dbo.bf_MigracionMVPB3_Ejecucion','U') IS NULL
        THROW 51000, 'No existen tablas de control de la homologacion.', 1;

    SELECT * FROM dbo.bf_MigracionMVPB3_Ejecucion
    WHERE IdEjecucion=@IdEjecucion;

    SELECT * FROM dbo.bf_MigracionMVPB3_Detalle
    WHERE IdEjecucion=@IdEjecucion
    ORDER BY Exitoso,IdEmpresa;
END;

/* 2. Resultado funcional por empresa */
DROP TABLE IF EXISTS #Resultado;

SELECT
    e.IdEmpresa,
    e.EMNombre,
    e.EMidCorporativo,
    EmpresaActiva = CASE WHEN e.EMidEstatus=1 THEN 1 ELSE 0 END,
    MarcaMVPUnica = CASE WHEN
        (SELECT COUNT(*) FROM dbo.bf_EmpresaMVP m
         WHERE m.IdEmpresa=e.IdEmpresa AND m.IdEstatus=1)=1 THEN 1 ELSE 0 END,
    AdminValido = CASE WHEN EXISTS
    (
        SELECT 1 FROM dbo.ff_AdministradorEmpresa a
        JOIN dbo.ff_Perfil p ON p.PEIdPerfil=a.AEIdPerfil
                            AND p.PEIdEmpresa=a.AEIdEmpresa
                            AND p.PEIdEstatus=1
        JOIN dbo.ff_Rol r ON r.ROIdRol=a.AEIdRol
                         AND r.ROIdEmpresa=a.AEIdEmpresa
                         AND r.ROIdEstatus=1
        WHERE a.AEIdEmpresa=e.IdEmpresa AND a.AEIdEstatus=1
    ) THEN 1 ELSE 0 END,
    SinAdminInvalido = CASE WHEN NOT EXISTS
    (
        SELECT 1 FROM dbo.ff_AdministradorEmpresa a
        LEFT JOIN dbo.ff_Perfil p ON p.PEIdPerfil=a.AEIdPerfil
                                 AND p.PEIdEmpresa=a.AEIdEmpresa
                                 AND p.PEIdEstatus=1
        LEFT JOIN dbo.ff_Rol r ON r.ROIdRol=a.AEIdRol
                              AND r.ROIdEmpresa=a.AEIdEmpresa
                              AND r.ROIdEstatus=1
        WHERE a.AEIdEmpresa=e.IdEmpresa AND a.AEIdEstatus=1
          AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL)
    ) THEN 1 ELSE 0 END,
    AccesoBeflex = CASE WHEN EXISTS
        (SELECT 1 FROM dbo.ff_accesoBeflex a
         WHERE a.idempresa=e.IdEmpresa AND a.acceso=1) THEN 1 ELSE 0 END,
    InicioB3 = CASE WHEN EXISTS
        (SELECT 1 FROM dbo.bf_BeflexInicio2 b
         WHERE b.BI_IdCorporativo=e.EMidCorporativo
           AND b.BI_Valor=e.IdEmpresa AND b.BI_IdEstatus=1) THEN 1 ELSE 0 END,
    EstilosB3Completos = CASE WHEN NOT EXISTS
    (
        SELECT 1 FROM dbo.bf_EstiloEmpresa src
        WHERE src.EEIdEmpresa=@IdEmpresaModeloB3 AND src.EEIdEstatus=1
          AND NOT EXISTS
          (SELECT 1 FROM dbo.bf_EstiloEmpresa dst
           WHERE dst.EEIdEmpresa=e.IdEmpresa
             AND dst.EEidCatalogoEstilo=src.EEidCatalogoEstilo
             AND dst.EEIdEstatus=1)
    ) THEN 1 ELSE 0 END,
    MenusB3Completos = CASE WHEN EXISTS
    (
        SELECT 1 FROM dbo.ff_Rol rd
        WHERE rd.ROIdEmpresa=e.IdEmpresa
          AND rd.RODescripcionCorta LIKE '%admi%'
          AND rd.ROIdEstatus=1
          AND NOT EXISTS
          (
              SELECT 1 FROM dbo.ff_MenuRol2 src
              WHERE src.MRidRol=@IdRolModeloMenuB3 AND src.MRidEstatus=1
                AND NOT EXISTS
                (SELECT 1 FROM dbo.ff_MenuRol2 dst
                 WHERE dst.MRidRol=rd.ROIdRol
                   AND dst.MRidMenu=src.MRidMenu
                   AND dst.MRidEstatus=1)
          )
    ) THEN 1 ELSE 0 END,
    CargaMasivaB3 = CASE WHEN
        (SELECT COUNT(DISTINCT c.CEIdOperacion)
         FROM dbo.ff_CargaMasivaOperacionEmpresa c
         WHERE c.CEIdEmpresa=e.IdEmpresa AND c.CEIdEstatus=1
           AND c.CEIdOperacion IN (1,2,3,13,14))=5 THEN 1 ELSE 0 END,
    ParametroMismoSexo = CASE WHEN EXISTS
        (SELECT 1 FROM dbo.ff_Parametro p
         WHERE p.paIdEmpresa=e.EMidCorporativo
           AND p.paId=@IdParametroMismoSexo AND p.paidEstatus=1) THEN 1 ELSE 0 END,
    AvisoPrivacidad = CASE WHEN EXISTS
        (SELECT 1 FROM dbo.ff_Parametro p
         WHERE p.paIdEmpresa=e.IdEmpresa
           AND p.paId=@IdParametroAvisoPrivacidad AND p.paidEstatus=1)
       AND EXISTS
        (SELECT 1 FROM dbo.ff_Parametro p
         WHERE p.paIdEmpresa=e.EMidCorporativo
           AND p.paId=@IdParametroAvisoPrivacidad AND p.paidEstatus=1)
        THEN 1 ELSE 0 END,
    SSOConfigurado = CASE WHEN EXISTS
        (SELECT 1 FROM dbo.ff_Parametro p
         WHERE p.paIdEmpresa IN (e.IdEmpresa,e.EMidCorporativo)
           AND p.paId=@IdParametroSSO AND p.paidEstatus=1
           AND NULLIF(LTRIM(RTRIM(CONVERT(VARCHAR(1500),p.paValor))),'') IS NOT NULL)
        THEN 1 ELSE 0 END,
    DocumentosPlanB3 =
        (SELECT COUNT(*) FROM dbo.ff_DocumentoPlanB3 d
         WHERE d.DPIdEmpresa=e.IdEmpresa AND d.DPEstatus=1),
    PlantillasMVP =
        (SELECT COUNT(*) FROM dbo.ff_Plantilla p
         WHERE p.PLIdEstatus=1
           AND p.PLDescripcion COLLATE Latin1_General_CI_AI
               LIKE '%MVP[_]'+CONVERT(VARCHAR(12),e.IdEmpresa)+'%')
INTO #Resultado
FROM #Empresas e;

SELECT *,
       CASE WHEN EmpresaActiva=1
                  AND MarcaMVPUnica=1
                  AND AdminValido=1
                  AND SinAdminInvalido=1
                  AND AccesoBeflex=1
                  AND InicioB3=1
                  AND EstilosB3Completos=1
                  AND MenusB3Completos=1
                  AND CargaMasivaB3=1
                  AND ParametroMismoSexo=1
                  AND AvisoPrivacidad=1
            THEN 'PASS_FASE_COEXISTENCIA'
            ELSE 'FAIL'
       END AS Resultado
FROM #Resultado
ORDER BY Resultado,IdEmpresa;

SELECT
    COUNT(*) AS Total,
    SUM(CASE WHEN EmpresaActiva=0 THEN 1 ELSE 0 END) AS EmpresaInactiva,
    SUM(CASE WHEN MarcaMVPUnica=0 THEN 1 ELSE 0 END) AS MarcaMVPIncorrecta,
    SUM(CASE WHEN AdminValido=0 OR SinAdminInvalido=0 THEN 1 ELSE 0 END) AS ProblemaAdministrador,
    SUM(CASE WHEN AccesoBeflex=0 THEN 1 ELSE 0 END) AS SinAcceso,
    SUM(CASE WHEN InicioB3=0 THEN 1 ELSE 0 END) AS SinInicio,
    SUM(CASE WHEN EstilosB3Completos=0 THEN 1 ELSE 0 END) AS EstilosIncompletos,
    SUM(CASE WHEN MenusB3Completos=0 THEN 1 ELSE 0 END) AS MenusIncompletos,
    SUM(CASE WHEN CargaMasivaB3=0 THEN 1 ELSE 0 END) AS CargaMasivaIncompleta,
    SUM(CASE WHEN ParametroMismoSexo=0 THEN 1 ELSE 0 END) AS ParametroIncompleto,
    SUM(CASE WHEN AvisoPrivacidad=0 THEN 1 ELSE 0 END) AS AvisoIncompleto,
    SUM(CASE WHEN SSOConfigurado=1 THEN 1 ELSE 0 END) AS RevisarSSO,
    SUM(CASE WHEN PlantillasMVP=0 THEN 1 ELSE 0 END) AS PendientesFasePlantillas
FROM #Resultado;

/* 3. Configuración exacta de carga masiva */
SELECT e.IdEmpresa,c.CEIdOperacion,c.CEIdPlantilla,c.CEStoredProc,c.CEIdEstatus,
       CASE
         WHEN c.CEIdOperacion=1 AND c.CEIdPlantilla=12061
              AND c.CEStoredProc='ff_XCMDependientesAltaCMM' THEN 'PASS'
         WHEN c.CEIdOperacion=2 AND c.CEIdPlantilla=12062
              AND c.CEStoredProc='ff_XCMTitularesAltaCMM_BF3' THEN 'PASS'
         WHEN c.CEIdOperacion=3 AND c.CEIdPlantilla=154
              AND c.CEStoredProc='ff_XCMAseguradosBaja_Base' THEN 'PASS'
         WHEN c.CEIdOperacion IN (13,14) THEN 'VALIDAR_CON_MODELO'
         ELSE 'FAIL'
       END AS ResultadoMapeo
FROM #Empresas e
LEFT JOIN dbo.ff_CargaMasivaOperacionEmpresa c
       ON c.CEIdEmpresa=e.IdEmpresa
      AND c.CEIdOperacion IN (1,2,3,13,14)
      AND c.CEIdEstatus=1
ORDER BY e.IdEmpresa,c.CEIdOperacion;

/* 4. Comprobar que los registros que ya existían no fueron eliminados */
IF @IdEjecucion IS NOT NULL
   AND OBJECT_ID('dbo.bf_MigracionMVPB3_Existencia','U') IS NOT NULL
BEGIN
    SELECT x.IdEmpresa,x.Componente,x.Clave,'REGISTRO_PREVIO_FALTANTE' AS Problema
    FROM dbo.bf_MigracionMVPB3_Existencia x
    WHERE x.IdEjecucion=@IdEjecucion
      AND
      (
          (x.Componente='ACCESO' AND NOT EXISTS
              (SELECT 1 FROM dbo.ff_accesoBeflex a
               WHERE a.idempresa=x.IdEmpresa AND CONVERT(VARCHAR(250),a.acceso)=x.Clave))
       OR (x.Componente='INICIO' AND NOT EXISTS
              (SELECT 1 FROM dbo.bf_BeflexInicio2 b
               WHERE CONVERT(VARCHAR(250),b.BI_IdBeflexInicio)=x.Clave))
       OR (x.Componente='ESTILO' AND NOT EXISTS
              (SELECT 1 FROM dbo.bf_EstiloEmpresa s
               WHERE CONVERT(VARCHAR(250),s.EEIdEstiloEmpresa)=x.Clave))
       OR (x.Componente='MENU' AND NOT EXISTS
              (SELECT 1 FROM dbo.ff_MenuRol2 m
               WHERE CONVERT(VARCHAR(250),m.MRidMenuRol)=x.Clave))
       OR (x.Componente='CARGA' AND NOT EXISTS
              (SELECT 1 FROM dbo.ff_CargaMasivaOperacionEmpresa c
               WHERE CONVERT(VARCHAR(250),c.CEIdOperacionEmpresa)=x.Clave))
       OR (x.Componente='DOCUMENTOPLAN' AND NOT EXISTS
              (SELECT 1 FROM dbo.ff_DocumentoPlanB3 d
               WHERE CONVERT(VARCHAR(250),d.DPidDoc)=x.Clave))
       OR (x.Componente='PARAMETRO' AND NOT EXISTS
              (SELECT 1 FROM dbo.ff_Parametro p
               WHERE CONVERT(VARCHAR(20),p.paIdEmpresa)+'|'+CONVERT(VARCHAR(20),p.paId)=x.Clave))
      );
END;

/* 5. Duplicados no permitidos por clave funcional */
SELECT r.ROIdEmpresa AS IdEmpresa,m.MRidRol,m.MRidMenu,COUNT(*) AS Cantidad
FROM dbo.ff_MenuRol2 m
JOIN dbo.ff_Rol r ON r.ROIdRol=m.MRidRol
JOIN #Empresas e ON e.IdEmpresa=r.ROIdEmpresa
WHERE m.MRidEstatus=1
GROUP BY r.ROIdEmpresa,m.MRidRol,m.MRidMenu
HAVING COUNT(*)>1;

SELECT c.CEIdEmpresa AS IdEmpresa,c.CEIdOperacion,COUNT(*) AS Cantidad
FROM dbo.ff_CargaMasivaOperacionEmpresa c
JOIN #Empresas e ON e.IdEmpresa=c.CEIdEmpresa
WHERE c.CEIdEstatus=1
GROUP BY c.CEIdEmpresa,c.CEIdOperacion
HAVING COUNT(*)>1;

PRINT 'Validacion terminada. Este script no modifico datos.';

