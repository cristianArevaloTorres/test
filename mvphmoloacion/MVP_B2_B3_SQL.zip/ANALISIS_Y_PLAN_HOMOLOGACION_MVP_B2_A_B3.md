# Homologación de 286 empresas MVP B2 al flujo MVP B3

## Objetivo

Homologar mediante scripts SQL las 286 empresas MVP existentes, conservando sus identificadores, corporativos, usuarios, información operativa, personalizaciones e historial, para que cumplan los requisitos de configuración utilizados por B3.

La homologación no crea 286 empresas nuevas. Trabaja sobre las mismas empresas y agrega o corrige únicamente los componentes necesarios para B3.

## Fuentes analizadas

- Alta legacy B2: `FlexiForbesV2/ADMFF/ff_AddEmpresa.aspx.cs`.
- API MVP B3: `WSBeFlex/REST/WSEmpresaMVP.java`.
- Servicio B3: `WSBeFlex/Services/LogicaEmpresaMVP.java`.
- DAO B3: `WSBeFlex/DAO/JDBCEmpresaMVP.java`.
- Esquema de referencia: `(localdb)\MSSQLLocalDB`, base `FlexiForbesv2`.
- Procedimientos revisados: `ff_AddEmpresa`, `bf_ProcesoMVP`, `sp_CrearEmpresaMVP` y la familia `sp_Copiar*Empresa`/`sp_Copiar*_MVP`.

La base local no contiene las 286 empresas funcionales. Por ello, este paquete define el diagnóstico, la homologación y las pruebas, pero el inventario real debe ejecutarse primero sobre una copia actualizada de la base funcional.

## Qué hace B2

La pantalla legacy de alta:

1. Ejecuta `ff_AddEmpresa` con la información general de la empresa.
2. Conserva la relación con corporativo y padre.
3. Copia o genera un archivo CSS `cla<IdEmpresa>.css`.
4. Copia documentos físicos heredados del corporativo mediante `ff_CopyDocument`.
5. Continúa con el wizard para completar la configuración.

La versión de código B2 revisada no envía el parámetro opcional `@EM_MVP`; el procedimiento local sí lo contiene. Cuando `@EM_MVP = 1`, el procedimiento ejecuta `bf_ProcesoMVP` y registra la empresa en `bf_EmpresaMVP`. Esto indica que la habilitación MVP fue incorporada en una versión posterior del procedimiento o de la pantalla.

## Qué requiere el flujo B3

El flujo SQL B3 de referencia agrega o replica:

- marca de empresa MVP;
- acceso a BeFlex;
- roles, perfiles y referencias del administrador;
- menús para `ff_MenuRol2`;
- configuración de inicio en `bf_BeflexInicio2`;
- estilos de `bf_EstiloEmpresa`;
- documentos B3 asociados a planes;
- plantillas MVP y sus asignaciones;
- reporte Interfábrica;
- operaciones de carga masiva;
- parámetros corporativos requeridos;
- bitácora del proceso.

## Diferencias relevantes

| Área | B2 | B3 | Decisión para las 286 |
|---|---|---|---|
| Identidad | Empresa ya creada y relacionada | También necesita `ff_Empresa` | Conservar el mismo `EMidEmpresa`. |
| Marca MVP | Puede provenir de una ejecución histórica | Usa `bf_EmpresaMVP` | Insertar sólo si falta; no duplicar. |
| CSS e imágenes | Puede usar archivos y configuración legacy | Usa configuración almacenada en BD | Conservar B2 y completar únicamente claves B3 ausentes. |
| Roles y perfiles | Pueden estar personalizados y en uso | B3 necesita rol/perfil administrador coherente | No reemplazar; reparar sólo referencias inválidas. |
| Menús | B2 usa principalmente `ff_MenuRol` | B3 consume `ff_MenuRol2` | Agregar menús B3 al rol administrador sin borrar menús B2. |
| Documentos | Incluye registros y archivos físicos | B3 agrega plantillas y documentos de plan | Conservar documentos B2; insertar sólo faltantes B3. |
| Parámetros | Contienen personalizaciones activas | B3 necesita parámetros adicionales | Insertar parámetros obligatorios faltantes; nunca reemplazar en bloque. |
| Plantillas | Pueden estar heredadas o personalizadas | B3 crea plantillas `MVP_<empresa>` | Preparar plantillas B3; resolver asignaciones conflictivas durante el corte. |
| Carga masiva | Puede no tener operaciones B3 | B3 requiere operaciones específicas | Insertar operaciones faltantes de manera idempotente. |
| Interfábrica | Puede no existir o usar otra plantilla | B3 usa una plantilla específica | Habilitar sólo cuando el objeto modelo exista y el negocio lo requiera. |

## Trazabilidad: de dónde se obtuvo cada objeto

La clasificación siguiente distingue entre uso demostrado por código, uso demostrado por dependencias SQL y objetos compartidos. “B3 propuesto” significa que existe backend Java, pero no se encontró una pantalla Angular que lo consuma.

### Procedimientos almacenados

| Procedimiento | Clasificación | Referencia comprobada |
|---|---|---|
| `ff_AddEmpresa` | B2 | `FlexiForbesV2/ADMFF/ff_AddEmpresa.aspx.cs`, línea 259: la pantalla legacy lo ejecuta directamente. |
| `ff_CopyDocument` | B2 | `ff_AddEmpresa.aspx.cs`, línea 365: copia los documentos del corporativo después del alta. |
| `bf_ReplicarEmpresa` | B2 | `FlexiForbesV2/ADMFF/bf_ReplicarEmpresa.aspx.cs`, línea 249. |
| `bf_ProcesoMVP` | Puente SQL sobre una empresa B2 existente | En la definición local de `ff_AddEmpresa`, se ejecuta cuando `@EM_MVP = 1`. No existe llamada directa en el código B2 revisado. |
| `sp_CrearEmpresaMVP` | B3 propuesto | `JDBCEmpresaMVP.java`, línea 72, invocado por el endpoint de `WSEmpresaMVP.java`. |
| `sp_CopiarMenusEmpresa` | B3 propuesto/compatibilidad B2 | `JDBCEmpresaMVP.java`, línea 92. Copia tanto `ff_MenuRol` como `ff_MenuRol2`. |
| `sp_CopiarRolesEmpresa` | B3 propuesto sobre tabla compartida | `JDBCEmpresaMVP.java`, línea 110. |
| `sp_CopiarImagenesEmpresa` | B3 propuesto sobre datos compartidos | `JDBCEmpresaMVP.java`, línea 128. |
| `sp_CopiarColoresEmpresa` | B3 propuesto sobre parámetros compartidos | `JDBCEmpresaMVP.java`, línea 146. |
| `sp_CopiarDocumentosEmpresa` | B3 propuesto sobre documentos compartidos | `JDBCEmpresaMVP.java`, línea 164. |
| `sp_CopiarPerfilesEmpresa` | B3 propuesto sobre tabla compartida | `JDBCEmpresaMVP.java`, línea 182. |
| `sp_CopiarPlanesEmpresa` | B3 propuesto | `JDBCEmpresaMVP.java`, línea 200; en la BD local únicamente inserta en `ff_DocumentoPlanB3`. |
| `sp_CopiarParametrosEmpresa` | B3 propuesto sobre parámetros compartidos | `JDBCEmpresaMVP.java`, línea 218. |
| `sp_CopiarAccesoBeflex` | B3 SQL | No lo llama directamente Java; lo llaman `bf_ProcesoMVP` y `sp_CrearEmpresaMVP` según `sys.sql_expression_dependencies`. |
| `sp_CopiarBeflexInicio2` | B3 SQL | Dependencia de `bf_ProcesoMVP` y `sp_CrearEmpresaMVP`. |
| `sp_CopiarConfiguracionEmpresa` | B3 SQL sobre tablas compartidas | Dependencia de `bf_ProcesoMVP` y `sp_CrearEmpresaMVP`. |
| `sp_CopiarPlantillasMVP` | B3 SQL | Dependencia de `bf_ProcesoMVP` y `sp_CrearEmpresaMVP`; genera descripciones `MVP_<IdEmpresa>`. |
| `sp_CopiarReporteInterfabricaMVP` | B3 SQL | Dependencia de `bf_ProcesoMVP` y `sp_CrearEmpresaMVP`. |
| `sp_CopiarMenusV2_MVP` | B3 SQL | Dependencia de los dos orquestadores; copia hacia `ff_MenuRol2`. |
| `sp_CopiarCargaMasiva_MVP` | B3 SQL | Dependencia de los dos orquestadores; configura operaciones B3. |
| `sp_CopiarParametroMismoSexo_MVP` | B3 SQL | Dependencia de los dos orquestadores; agrega el parámetro al corporativo. |

### Tablas

| Tabla | Clasificación | Referencia comprobada y uso |
|---|---|---|
| `ff_Empresa` | Compartida B2/B3 | B2 la crea mediante `ff_AddEmpresa`; todos los procesos B3 conservan el mismo ID. |
| `ff_Rol` | Compartida B2/B3 | B2 la utiliza para seguridad; los procedimientos B3 replican roles por empresa. |
| `ff_Perfil` | Compartida B2/B3 | Define perfiles de negocio y el rol predeterminado. Java B3 la consume en múltiples DAOs. |
| `ff_AdministradorEmpresa` | Compartida B2/B3 | Relaciona administradores, empresa, rol y perfil; Java B3 la consulta en `JDBCFfEmpresa`, `JDBCFfEmpleado` y flujos administrativos. |
| `ff_MenuRol` | Principalmente B2/compatibilidad | `bf_ReplicarEmpresa` y los procedimientos de menús legacy la utilizan; B3 conserva su población para compatibilidad. |
| `ff_MenuRol2` | B3 | `JDBCFfMenusRol.java`, líneas 56 y 62, consulta esta tabla para construir navegación B3. |
| `ff_Documentos` | Compartida B2/B3 | B2 copia registros y archivos mediante `ff_CopyDocument`; B3 también consulta documentos existentes. |
| `ff_Parametro` | Compartida B2/B3 | Contiene configuración de ambos sistemas. Java B3 la consulta en `JDBCParametro.java`; por eso no se reemplaza masivamente. |
| `ff_Plantilla` | Compartida | B2 mantiene plantillas legacy y B3 agrega clones específicos MVP. |
| `ff_PlantillaPerfil` | Compartida y conflictiva en el corte | Java B3 la consulta en `JDBCFfEmpleado.java`, línea 867; B2 también utiliza las asignaciones de plantilla. |
| `bf_EmpresaMVP` | Marcador MVP en BD | `ff_AddEmpresa` local inserta cuando se activa `@EM_MVP`; la API Java no la consulta directamente. Se usa como universo de las 286. |
| `bf_BitacoraEmpresa` | B3/MVP | `JDBCEmpresaMVP.java`, líneas 255, 278 y 289, inserta y consulta la bitácora. |
| `bf_BeflexInicio2` | B3 | El procedimiento `sp_CopiarBeflexInicio2` la alimenta; Java B3 obtiene el inicio mediante `JDBCBfObtieneBeflexInicio` y procedimientos `bf_ObtieneBeflexInicio*`. |
| `bf_EstiloEmpresa` | Configuración B3 | Es poblada por `sp_CopiarConfiguracionEmpresa`. No se encontró acceso directo en `JDBCEmpresaMVP`; forma parte de la configuración SQL B3. |
| `ff_CargaMasivaOperacionEmpresa` | Compartida, requerida por B3 | `CargaMasivaB2DAO.java`, línea 26, la consulta desde el backend B3 para habilitar operaciones; el nombre de la clase refleja reutilización del flujo B2. |
| `ff_DocumentoPlanB3` | B3 | `sp_CopiarPlanesEmpresa` sólo copia esta tabla; Java B3 obtiene documentos mediante `JDBCPlan.java` y `FF_BuscaDocumentosPlanesB3`. |
| `bf_MigracionMVPB3_*` | Nuevas tablas técnicas del paquete | No pertenecen al producto B2/B3. Se crean únicamente al aplicar la homologación para evidencia y reversa. |

### Ausencia comprobada en Angular

No se localizaron referencias a `empresa-mvp`, `EmpresaMVP` o “empresa MVP” en `BeFlex3/src/app`. Por eso el endpoint Java se clasifica como backend B3 propuesto, no como una opción de pantalla actualmente disponible.

## Por qué no se debe ejecutar `bf_ProcesoMVP` masivamente

Aunque varios procedimientos se describen como idempotentes, algunos sustituyen información del destino:

- `sp_CopiarImagenesEmpresa` elimina todas las imágenes del destino.
- `sp_CopiarColoresEmpresa` elimina parámetros clasificados como color, estilo o CSS.
- `sp_CopiarParametrosEmpresa` elimina parámetros coincidentes antes de copiarlos.
- `sp_CopiarDocumentosEmpresa` elimina documentos cuyos nombres coinciden con el modelo.
- `sp_CopiarPerfilesEmpresa` actualiza los perfiles existentes con valores del modelo.
- `sp_CopiarPlantillasMVP` elimina asignaciones heredadas de titulares.
- `sp_CopiarReporteInterfabricaMVP` elimina otras asignaciones de Interfábrica.

Ejecutar esa cascada sobre empresas activas podría modificar el comportamiento de B2 y eliminar personalizaciones. La solución propuesta no llama esos procedimientos destructivos durante la fase de coexistencia.

## Problemas que deben considerarse en el flujo B3 actual

1. `JDBCEmpresaMVP` no coincide con la firma de `sp_CrearEmpresaMVP`: usa nombres diferentes y no envía la empresa modelo.
2. Los métodos Java de copia no envían `IdUsuario`, aunque los procedimientos lo requieren.
3. `sp_CrearEmpresaMVP` copia elementos por defecto y el servicio Java intenta volver a copiarlos.
4. `@CopiarEstilos` está declarado, pero no se utiliza en el procedimiento local.
5. `sp_CopiarPlanesEmpresa` sólo copia `ff_DocumentoPlanB3`; no replica toda la estructura de planes.
6. Existen dependencias con IDs fijos: empresa 2494, corporativo 2493, rol 7365, plantilla 689 y empresa 645. Deben validarse o sustituirse por IDs resueltos en cada ambiente.
7. En la base local faltan el rol 7365 y la plantilla 689; por eso el flujo completo local no puede ejecutarse de extremo a extremo.

## Solución recomendada: homologación en dos fases

### Fase 1: coexistencia segura

Se conserva toda la información B2 y se agregan componentes B3 que no sustituyen configuración:

- marca MVP faltante;
- acceso BeFlex;
- inicio B3;
- menús B3 faltantes;
- estilos de catálogo ausentes;
- documentos B3 de plan ausentes;
- operaciones de carga masiva ausentes;
- parámetros B3 obligatorios ausentes;
- configuración adicional insertada mediante `NOT EXISTS`;
- reparación exclusiva de administradores con rol/perfil inválido.

La fase se ejecuta por empresa y registra resultados. El script inicia en modo simulación.

### Fase 2: corte de elementos incompatibles

Las plantillas pueden producir opciones duplicadas si permanecen activas simultáneamente las asignaciones B2 y B3. Para esas tablas se requiere un corte controlado:

1. respaldar las asignaciones actuales;
2. crear o validar las plantillas MVP B3;
3. desactivar de forma reversible las asignaciones B2 que compitan con B3;
4. validar funcionalmente;
5. conservar el respaldo hasta finalizar la estabilización.

No se recomienda borrar físicamente las asignaciones.

## Qué información permanece activa en B2

Debe conservarse la información histórica y operativa. B2 y B3 comparten tablas, por lo que borrar y recrear empresas rompería o pondría en riesgo empleados, solicitudes, vigencias, administradores, documentos y relaciones históricas.

Durante la transición B2 puede mantenerse como consulta o contingencia. Una vez aceptada cada empresa en B3, conviene impedir que B2 y B3 ejecuten simultáneamente la misma operación de escritura. Eso es un control de corte operativo; no implica borrar información B2.

## Resultado correcto esperado

El resultado se considera correcto cuando:

- existen exactamente las mismas 286 empresas y conservan sus IDs;
- existe una sola marca MVP activa por empresa;
- todas las empresas activas tienen configuración mínima B3;
- los administradores apuntan a roles y perfiles activos de su propia empresa;
- no aparecen registros huérfanos ni duplicados por clave funcional;
- no disminuyen registros B2 fuera de la lista autorizada de corte;
- los valores personalizados existentes no son reemplazados;
- B2 supera las pruebas de regresión acordadas;
- B3 permite iniciar sesión, navegar y ejecutar los flujos habilitados;
- la segunda ejecución del script informa cero cambios;
- cada cambio puede relacionarse con un identificador de ejecución y revertirse.

## Orden de ejecución

1. Ejecutar `00_ANALISIS_REFERENCIAS_B2_B3.sql` para comprobar la clasificación y las dependencias del ambiente.
2. Ejecutar `01_INVENTARIO_Y_PREVALIDACION_MVP_B2_B3.sql` en una copia de la base funcional.
3. Corregir dependencias o IDs modelo reportados.
4. Ejecutar `02_HOMOLOGACION_MVP_B3_COEXISTENCIA.sql` con `@Aplicar = 0`.
5. Revisar el plan por empresa.
6. Probar con 5 a 10 empresas en QA usando `@Aplicar = 1`.
7. Ejecutar `03_VALIDACION_POST_MVP_B3.sql`.
8. Realizar pruebas B2 y B3.
9. Ejecutar por lotes controlados.
10. Usar `04_REVERSA_HOMOLOGACION_MVP_B3.sql` sólo para una ejecución que deba revertirse.

## Referencias concretas

- `ff_AddEmpresa.aspx.cs`, método `nuevaEmpresa`: alta y generación de recursos legacy.
- `WSEmpresaMVP.java`, ruta `beflex/empresa-mvp`: API propuesta para B3.
- `LogicaEmpresaMVP.java`, método `crearEmpresaMVP`: orquestación actual.
- `JDBCEmpresaMVP.java`, método `crearEmpresa`: contrato JDBC actualmente desalineado.
- `ff_AddEmpresa`: parámetro local `@EM_MVP` y llamada a `bf_ProcesoMVP`.
- `bf_ProcesoMVP`: cascada MVP sobre una empresa ya existente.
- `sp_CrearEmpresaMVP`: creación completa de una empresa nueva; no debe usarse para migrar las 286.
