# Homologación MVP de B3 — lista recibida el 11/09/2026

Este paquete aplica a empresas existentes la misma cascada SQL utilizada cuando el alta de BF3 recibe la bandera `@EM_MVP = 1`.

## Conclusión técnica

- `ff_AddEmpresa` ejecuta `bf_ProcesoMVP @EMidEmpresa, @EMUsuarioAdd` cuando la empresa se crea como MVP y después registra la empresa en `bf_EmpresaMVP`.
- `bf_ProcesoMVP` trabaja sobre una empresa ya existente. Por eso es el procedimiento adecuado para homologar los destinos de la lista.
- `sp_CrearEmpresaMVP` no se ejecuta: su propósito es crear una empresa nueva y duplicaría el registro.
- El flujo legacy B2 revisado no enviaba `@EM_MVP`; la cascada entregada y el diagnóstico recibido corresponden a la incorporación MVP/B3.
- El paquete anterior copiaba sólo ocho componentes. Este paquete cambia el alcance y llama la cascada completa confirmada por el diagnóstico recibido.

## Modelo y universo

- Empresa modelo B3: `2494`.
- Corporativo modelo B3: `2493`.
- Lista recibida: 20 identificadores de corporativo.
- Piloto: corporativo `495` (HAPAG), empresa hija `496`.

La hoja contiene `idCorp`, no el identificador de cada empresa hija. Los scripts resuelven las empresas activas mediante `ff_Empresa.EMidCorporativo`. En la copia local se encontraron 23 empresas hijas activas para los 20 corporativos; UNICCO, SCHNEIDER y SGWIC tienen dos hijas. La cantidad real debe confirmarse en el ambiente donde se ejecutará.

Los identificadores de modelo `2494/2493` se tomaron del archivo recibido `VALIDA_01_diagnostico_insercion_PROD (1).sql`. Ese mismo diagnóstico advierte que pueden no existir o estar incompletos en PROD. Por eso el script `00` y los ejecutables detienen el proceso si el modelo no tiene la configuración mínima. Si la empresa base autorizada en PROD utiliza otros identificadores, deben cambiarse las dos variables de modelo en todos los scripts antes de ejecutar.

## Qué agrega o actualiza la cascada completa

Además de menús, roles, imágenes, colores, documentos, perfiles, planes y parámetros, incorpora acceso BeFlex, inicio B3, configuración de empresa, plantillas MVP, reporte Interfábrica, menús V2, operaciones de carga masiva y el parámetro de mismo sexo. También corrige la referencia del perfil administrador y garantiza el aviso de privacidad `226` cuando la versión desplegada del procedimiento contiene esas reglas.

Algunos procedimientos reemplazan datos del destino, como imágenes, colores, documentos, parámetros y plantillas. Por ello los ejecutables vienen desactivados y deben usarse con respaldo de la base.

La cascada no debe envolverse en otra transacción ni ejecutarse con `XACT_ABORT ON`. Cada `sp_Copiar*` controla su propia transacción y varios escriben bitácora después de su `COMMIT`. Una transacción exterior puede quedar en `XACT_STATE=-1` y producir el error `3930`, ocultando el mensaje original. Los ejecutables corregidos usan `XACT_ABORT OFF` y reproducen la llamada de `ff_AddEmpresa`.

## Orden de ejecución

1. Ejecutar `00_DIAGNOSTICO_PREVIO_BF3.sql` y conservar sus resultados.
2. Revisar que los modelos, los 19 objetos y la empresa piloto aparezcan como `OK`.
3. En `01_EJECUTAR_PILOTO_CORP_495.sql`, capturar `@IdUsuario`.
4. Ejecutarlo primero con `@Aplicar = 0`.
5. Con respaldo confirmado, cambiar únicamente `@Aplicar = 1` y volverlo a ejecutar.
6. Ejecutar `02_VALIDAR_PILOTO_CORP_495.sql` y realizar pruebas funcionales en BF3.
7. Sólo después de aprobar el piloto, preparar `03_EJECUTAR_MASIVO_20_CORPORATIVOS.sql`.
8. Para habilitar el masivo, descomentar el `UPDATE` indicado, capturar el usuario, establecer la confirmación exacta y finalmente cambiar `@AplicarMasivo = 1`.
9. Ejecutar `04_VALIDAR_20_CORPORATIVOS.sql`.

## Salvaguardas

- Los modelos se envían explícitamente; no se depende de defaults ocultos.
- El piloto sólo acepta la empresa `496` dentro del corporativo `495`.
- Cada procedimiento de la cascada conserva su propia transacción, igual que en el flujo B3. Si una etapa posterior falla, las etapas anteriores pueden haber quedado aplicadas; después de corregir la causa se puede volver a ejecutar porque los procedimientos están diseñados como idempotentes.
- La marca `bf_EmpresaMVP` se inserta sólo si falta o se reactiva si estaba inactiva.
- El masivo requiere cuatro acciones expresas: habilitar destinos, capturar usuario, escribir la frase de confirmación y activar `@AplicarMasivo`.
- Ningún script crea o elimina empresas, empleados, solicitudes o vigencias.

## Resultado de la verificación local

Los cinco SQL se validaron sintácticamente. Los scripts `00`, `02` y `04` se ejecutaron como sólo lectura; los scripts `01` y `03` se analizaron con `PARSEONLY`.

La copia local confirma la relación piloto `495 -> 496`, pero el modelo local `2494/2493` está incompleto. Los conteos de configuración se presentan como advertencias, ya que la empresa base fue indicada como obligatoria. Sí se mantienen bloqueos para dependencias inevitables de la cascada, como el rol modelo V2 `7365`, las plantillas fijas y las cinco operaciones de carga. Esto no determina el estado de PROD: ahí debe conservarse la salida del script `00` antes de habilitar el piloto.

## Referencias incluidas

La carpeta `REFERENCIAS_NO_EJECUTAR` conserva la hoja y los dos SQL entregados. Son evidencia de origen y no forman parte del orden de ejecución del paquete.
