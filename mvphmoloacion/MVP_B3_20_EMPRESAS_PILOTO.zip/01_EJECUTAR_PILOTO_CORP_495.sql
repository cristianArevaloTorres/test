/*
  PILOTO MVP B3 - HAPAG

  La ejecución está desactivada. Primero capture @IdUsuario y revise el modo simulación.
  Este script llama la misma cascada bf_ProcesoMVP usada por ff_AddEmpresa con @EM_MVP=1.
*/
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
/* Igual que la llamada de ff_AddEmpresa: sin XACT_ABORT ni transacción exterior. */
SET XACT_ABORT OFF;

DECLARE @Aplicar BIT = 0;             -- CAMBIAR A 1 sólo con respaldo y aprobación.
DECLARE @IdUsuario INT = NULL;        -- OBLIGATORIO: administrador responsable.
DECLARE @IdCorporativoPiloto INT = 495;
DECLARE @IdEmpresaPiloto INT = 496;
DECLARE @IdEmpresaModelo INT = 2494;
DECLARE @IdCorporativoModelo INT = 2493;

SELECT 'PILOTO' Bloque, @Aplicar Aplicar, @IdUsuario IdUsuario,
       corp.EMidEmpresa IdCorporativo, corp.EMRazonSocial Corporativo,
       emp.EMidEmpresa IdEmpresa, emp.EMRazonSocial Empresa,
       @IdEmpresaModelo EmpresaModelo, @IdCorporativoModelo CorporativoModelo
FROM dbo.ff_Empresa corp
LEFT JOIN dbo.ff_Empresa emp ON emp.EMidEmpresa=@IdEmpresaPiloto
WHERE corp.EMidEmpresa=@IdCorporativoPiloto;

IF DB_NAME() <> 'FlexiForbesv2'
    THROW 51000, 'Base incorrecta. Debe ejecutarse en FlexiForbesv2.', 1;

DECLARE @Objetos TABLE (Objeto SYSNAME,Tipo CHAR(2));
INSERT @Objetos VALUES
('dbo.bf_BitacoraEmpresa','U'),('dbo.bf_EmpresaMVP','U'),
('dbo.bf_ProcesoMVP','P'),('dbo.sp_CopiarRolesEmpresa','P'),('dbo.sp_CopiarPerfilesEmpresa','P'),
('dbo.sp_CopiarMenusEmpresa','P'),('dbo.sp_CopiarImagenesEmpresa','P'),('dbo.sp_CopiarColoresEmpresa','P'),
('dbo.sp_CopiarDocumentosEmpresa','P'),('dbo.sp_CopiarPlanesEmpresa','P'),('dbo.sp_CopiarParametrosEmpresa','P'),
('dbo.sp_CopiarAccesoBeflex','P'),('dbo.sp_CopiarBeflexInicio2','P'),('dbo.sp_CopiarConfiguracionEmpresa','P'),
('dbo.sp_CopiarPlantillasMVP','P'),('dbo.sp_CopiarReporteInterfabricaMVP','P'),('dbo.sp_CopiarMenusV2_MVP','P'),
('dbo.sp_CopiarCargaMasiva_MVP','P'),('dbo.sp_CopiarParametroMismoSexo_MVP','P');
IF EXISTS (SELECT 1 FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL)
    THROW 51000, 'Faltan objetos de la cascada completa MVP B3. Ejecute primero el diagnóstico 00.', 1;

IF (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP')) <> 4
   OR NOT EXISTS (SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP') AND name='@ModeloOrigen')
   OR NOT EXISTS (SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP') AND name='@ModeloCorp')
    THROW 51000, 'La firma de bf_ProcesoMVP no corresponde a la cascada B3 validada.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdEmpresaModelo AND EMidCorporativo=@IdCorporativoModelo AND EMidEstatus=1)
    THROW 51000, 'La empresa modelo 2494 no existe, está inactiva o no pertenece al corporativo modelo 2493.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdCorporativoModelo AND EMidEstatus=1)
    THROW 51000, 'El corporativo modelo 2493 no existe o está inactivo.', 1;

/* La empresa 2494/2493 es obligatoria según la indicación recibida.
   Los conteos vacíos se reportan en el diagnóstico 00, pero no bloquean esta llamada. */

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Rol WHERE ROIdRol=7365 AND ROIdEstatus=1)
    THROW 51000, 'Falta el rol modelo V2 7365 requerido por sp_CopiarMenusV2_MVP.', 1;

IF EXISTS (
    SELECT 1 FROM (VALUES (13),(15),(17),(154),(689),(12061),(12062)) p(IdPlantilla)
    WHERE NOT EXISTS (SELECT 1 FROM dbo.ff_Plantilla x WHERE x.PLIdPlantilla=p.IdPlantilla AND x.PLIdEstatus=1)
)
    THROW 51000, 'Falta una plantilla fija requerida: 13, 15, 17, 154, 689, 12061 o 12062.', 1;

IF (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
    WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1 AND CEIdOperacion IN (1,2,3,13,14))<>5
    THROW 51000, 'La empresa modelo 2494 no tiene las cinco operaciones de carga 1,2,3,13,14.', 1;

IF NOT EXISTS (
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMidEmpresa=@IdEmpresaPiloto AND EMidCorporativo=@IdCorporativoPiloto
      AND EMidEmpresa<>EMidCorporativo AND EMidEstatus=1
)
    THROW 51000, 'La empresa piloto 496 no es una empresa hija activa del corporativo 495.', 1;

IF (SELECT COUNT(*) FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresaPiloto) > 1
    THROW 51000, 'La empresa piloto tiene marcas MVP duplicadas; corregir antes de continuar.', 1;

IF @Aplicar=0
BEGIN
    PRINT 'SIMULACION: no se modificó información. Capture @IdUsuario y cambie @Aplicar a 1 para ejecutar el piloto.';
    RETURN;
END;

IF @IdUsuario IS NULL OR @IdUsuario<=0
    THROW 51000, 'Debe capturar @IdUsuario antes de aplicar.', 1;

BEGIN TRY
    EXEC dbo.bf_ProcesoMVP
        @idEmpresa=@IdEmpresaPiloto,
        @Usuario=@IdUsuario,
        @ModeloOrigen=@IdEmpresaModelo,
        @ModeloCorp=@IdCorporativoModelo;

    IF EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresaPiloto)
    BEGIN
        UPDATE dbo.bf_EmpresaMVP
           SET IdEstatus=1, IdUsuarioMod=@IdUsuario, FechaMod=GETDATE(),
               IdUsuarioDel=NULL, FechaDel=NULL
         WHERE IdEmpresa=@IdEmpresaPiloto AND ISNULL(IdEstatus,0)<>1;
    END
    ELSE
    BEGIN
        INSERT dbo.bf_EmpresaMVP
            (IdEmpresa,IdEstatus,IdUsuarioAdd,FechaAdd,IdUsuarioMod,FechaMod,IdUsuarioDel,FechaDel)
        VALUES (@IdEmpresaPiloto,1,@IdUsuario,GETDATE(),NULL,NULL,NULL,NULL);
    END;

    IF NOT EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresaPiloto AND IdEstatus=1)
        THROW 51000, 'No fue posible dejar activa la marca MVP del piloto.', 1;

    PRINT 'PILOTO COMPLETADO. Ejecute 02_VALIDAR_PILOTO_CORP_495.sql y realice la prueba funcional en BF3.';
END TRY
BEGIN CATCH
    /* Sólo limpia una transacción interna que algún SP hubiera dejado abierta. */
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
