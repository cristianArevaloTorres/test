/*
  HOMOLOGACION MASIVA MVP B3 - 20 CORPORATIVOS RECIBIDOS

  DESACTIVADO POR DEFECTO. No habilitar hasta aprobar el piloto 495/496.
  Cada empresa hija se procesa en una transacción independiente.
*/
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
/* Igual que ff_AddEmpresa: cada sp_Copiar* controla su propia transacción. */
SET XACT_ABORT OFF;

DECLARE @AplicarMasivo BIT=0;              -- Último seguro: cambiar a 1 al liberar.
DECLARE @Confirmacion VARCHAR(50)='';       -- Escribir: HOMOLOGAR_20_CORPORATIVOS_B3
DECLARE @IdUsuario INT=NULL;                -- OBLIGATORIO.
DECLARE @IdEmpresaModelo INT=2494;
DECLARE @IdCorporativoModelo INT=2493;

DECLARE @Corporativos TABLE (
    IdCorporativo INT PRIMARY KEY,
    Grupo VARCHAR(30),
    Procesar BIT NOT NULL
);

/* Todos permanecen comentados lógicamente con Procesar=0. */
INSERT INTO @Corporativos VALUES
(495,'HAPAG',0),(531,'GN102',0),(658,'GCABLE',0),(698,'TORRENT',0),
(718,'UNICCO',0),(721,'CCPM',0),(723,'SCHNEIDER',0),(725,'IMCP',0),
(727,'BIOMETC',0),(752,'GEPC',0),(756,'LOEFFLERC',0),(758,'AMCHAM',0),
(760,'IMEFC',0),(762,'PRV',0),(790,'MELTSANC',0),(797,'CLYPC',0),
(799,'VITOLC',0),(806,'SGWIC',0),(812,'DE LA VEGA',0),(814,'CONSTRUMACC',0);

/* DESCOMENTAR esta línea sólo después de aprobar el piloto. */
-- UPDATE @Corporativos SET Procesar=1;

CREATE TABLE #Objetivos (
    IdEmpresa INT PRIMARY KEY,
    IdCorporativo INT NOT NULL,
    Grupo VARCHAR(30) NOT NULL,
    Empresa VARCHAR(200) NULL
);

INSERT INTO #Objetivos (IdEmpresa,IdCorporativo,Grupo,Empresa)
SELECT e.EMidEmpresa,c.IdCorporativo,c.Grupo,e.EMRazonSocial
FROM @Corporativos c
JOIN dbo.ff_Empresa e ON e.EMidCorporativo=c.IdCorporativo
WHERE c.Procesar=1 AND e.EMidEmpresa<>c.IdCorporativo AND e.EMidEstatus=1;

SELECT 'OBJETIVOS_MASIVOS' Bloque,* FROM #Objetivos ORDER BY IdCorporativo,IdEmpresa;
SELECT 'RESUMEN' Bloque,
       (SELECT COUNT(*) FROM @Corporativos WHERE Procesar=1) CorporativosHabilitados,
       (SELECT COUNT(*) FROM #Objetivos) EmpresasHijaAProcesar,
       @AplicarMasivo AplicarMasivo,@Confirmacion Confirmacion,@IdUsuario IdUsuario;

IF @AplicarMasivo=0
BEGIN
    PRINT 'SIMULACION: no se modificó información. Los destinos continúan con Procesar=0.';
    DROP TABLE #Objetivos;
    RETURN;
END;

IF @Confirmacion<>'HOMOLOGAR_20_CORPORATIVOS_B3'
    THROW 51000, 'La frase de confirmación no coincide.', 1;
IF @IdUsuario IS NULL OR @IdUsuario<=0
    THROW 51000, 'Debe capturar @IdUsuario.', 1;
IF NOT EXISTS (SELECT 1 FROM @Corporativos WHERE Procesar=1)
    THROW 51000, 'No hay corporativos habilitados. Revise el UPDATE comentado.', 1;
IF NOT EXISTS (SELECT 1 FROM #Objetivos)
    THROW 51000, 'Los corporativos habilitados no tienen empresas hijas activas.', 1;
IF EXISTS (
    SELECT 1 FROM @Corporativos c
    WHERE c.Procesar=1 AND NOT EXISTS (
        SELECT 1 FROM dbo.ff_Empresa e
        WHERE e.EMidCorporativo=c.IdCorporativo AND e.EMidEmpresa<>c.IdCorporativo AND e.EMidEstatus=1
    )
)
    THROW 51000, 'Al menos un corporativo habilitado no tiene empresa hija activa.', 1;
DECLARE @Objetos TABLE (Objeto SYSNAME,Tipo CHAR(2));
INSERT @Objetos VALUES
('dbo.bf_BitacoraEmpresa','U'),('dbo.bf_EmpresaMVP','U'),
('dbo.bf_ProcesoMVP','P'),('dbo.sp_CopiarRolesEmpresa','P'),('dbo.sp_CopiarPerfilesEmpresa','P'),
('dbo.sp_CopiarMenusEmpresa','P'),('dbo.sp_CopiarImagenesEmpresa','P'),('dbo.sp_CopiarColoresEmpresa','P'),
('dbo.sp_CopiarDocumentosEmpresa','P'),('dbo.sp_CopiarPlanesEmpresa','P'),('dbo.sp_CopiarParametrosEmpresa','P'),
('dbo.sp_CopiarAccesoBeflex','P'),('dbo.sp_CopiarBeflexInicio2','P'),('dbo.sp_CopiarConfiguracionEmpresa','P'),
('dbo.sp_CopiarPlantillasMVP','P'),('dbo.sp_CopiarReporteInterfabricaMVP','P'),('dbo.sp_CopiarMenusV2_MVP','P'),
('dbo.sp_CopiarCargaMasiva_MVP','P'),('dbo.sp_CopiarParametroMismoSexo_MVP','P');
IF EXISTS (SELECT 1 FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL)
    THROW 51000, 'Faltan objetos de la cascada completa MVP B3.', 1;
IF (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP'))<>4
   OR NOT EXISTS (SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP') AND name='@ModeloOrigen')
   OR NOT EXISTS (SELECT 1 FROM sys.parameters WHERE object_id=OBJECT_ID('dbo.bf_ProcesoMVP') AND name='@ModeloCorp')
    THROW 51000, 'La firma de bf_ProcesoMVP no corresponde a la cascada B3 validada.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdEmpresaModelo AND EMidCorporativo=@IdCorporativoModelo AND EMidEstatus=1)
    THROW 51000, 'El modelo 2494/2493 no es válido.', 1;
IF NOT EXISTS (SELECT 1 FROM dbo.ff_Rol WHERE ROIdRol=7365 AND ROIdEstatus=1)
    THROW 51000, 'Falta el rol modelo V2 7365 requerido por sp_CopiarMenusV2_MVP.', 1;
IF EXISTS (
    SELECT 1 FROM (VALUES (13),(15),(17),(154),(689),(12061),(12062)) p(IdPlantilla)
    WHERE NOT EXISTS (SELECT 1 FROM dbo.ff_Plantilla x WHERE x.PLIdPlantilla=p.IdPlantilla AND x.PLIdEstatus=1)
)
    THROW 51000, 'Falta una plantilla fija requerida: 13, 15, 17, 154, 689, 12061 o 12062.', 1;
IF (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
    WHERE CEIdEmpresa=@IdEmpresaModelo AND CEIdEstatus=1 AND CEIdOperacion IN (1,2,3,13,14))<>5
    THROW 51000, 'La empresa modelo 2494 no tiene las cinco operaciones de carga 1,2,3,13,14.', 1;
IF EXISTS (SELECT IdEmpresa FROM dbo.bf_EmpresaMVP GROUP BY IdEmpresa HAVING COUNT(*)>1 AND IdEmpresa IN (SELECT IdEmpresa FROM #Objetivos))
    THROW 51000, 'Hay marcas MVP duplicadas en los destinos; corregir antes de continuar.', 1;

DECLARE @Resultados TABLE (
    IdEmpresa INT, IdCorporativo INT, Grupo VARCHAR(30),
    Resultado VARCHAR(10), Mensaje VARCHAR(2000)
);
DECLARE @IdEmpresa INT,@IdCorporativo INT,@Grupo VARCHAR(30);

DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
SELECT IdEmpresa,IdCorporativo,Grupo FROM #Objetivos ORDER BY IdCorporativo,IdEmpresa;
OPEN cur;
FETCH NEXT FROM cur INTO @IdEmpresa,@IdCorporativo,@Grupo;
WHILE @@FETCH_STATUS=0
BEGIN
    BEGIN TRY
        EXEC dbo.bf_ProcesoMVP
            @idEmpresa=@IdEmpresa,
            @Usuario=@IdUsuario,
            @ModeloOrigen=@IdEmpresaModelo,
            @ModeloCorp=@IdCorporativoModelo;

        IF EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP WHERE IdEmpresa=@IdEmpresa)
            UPDATE dbo.bf_EmpresaMVP
               SET IdEstatus=1,IdUsuarioMod=@IdUsuario,FechaMod=GETDATE(),IdUsuarioDel=NULL,FechaDel=NULL
             WHERE IdEmpresa=@IdEmpresa AND ISNULL(IdEstatus,0)<>1;
        ELSE
            INSERT dbo.bf_EmpresaMVP
                (IdEmpresa,IdEstatus,IdUsuarioAdd,FechaAdd,IdUsuarioMod,FechaMod,IdUsuarioDel,FechaDel)
            VALUES (@IdEmpresa,1,@IdUsuario,GETDATE(),NULL,NULL,NULL,NULL);

        INSERT @Resultados VALUES (@IdEmpresa,@IdCorporativo,@Grupo,'OK','Cascada B3 y marca MVP completadas.');
    END TRY
    BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        INSERT @Resultados VALUES (@IdEmpresa,@IdCorporativo,@Grupo,'ERROR',LEFT(ERROR_MESSAGE(),2000));
    END CATCH;

    FETCH NEXT FROM cur INTO @IdEmpresa,@IdCorporativo,@Grupo;
END;
CLOSE cur;
DEALLOCATE cur;

SELECT * FROM @Resultados ORDER BY IdCorporativo,IdEmpresa;
SELECT Resultado,COUNT(*) Cantidad FROM @Resultados GROUP BY Resultado;

IF EXISTS (SELECT 1 FROM @Resultados WHERE Resultado='ERROR')
    THROW 51000, 'Una o más empresas fallaron. Las demás conservaron su transacción independiente; revise el resultado.', 1;

DROP TABLE #Objetivos;
GO
