/* PREVALIDACION DE SOLO CONFIGURACION MVP B3. NO MODIFICA DATOS. */

SET NOCOUNT ON;

DECLARE @IdEmpresaModeloB3 INT = NULL; -- OBLIGATORIO: empresa modelo aprobada
DECLARE @CantidadEsperada INT = 286;
DECLARE @IdCorporativoModeloB3 INT;

IF @IdEmpresaModeloB3 IS NULL
    THROW 51000, 'Indique @IdEmpresaModeloB3.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMidEmpresa=@IdEmpresaModeloB3 AND EMidEstatus=1
)
    THROW 51000, 'La empresa modelo B3 no existe o esta inactiva.', 1;

SELECT @IdCorporativoModeloB3=EMidCorporativo
FROM dbo.ff_Empresa
WHERE EMidEmpresa=@IdEmpresaModeloB3;

DECLARE @Objetos TABLE
(
    Objeto SYSNAME NOT NULL,
    Tipo CHAR(2) NOT NULL,
    Componente VARCHAR(30) NOT NULL
);

INSERT INTO @Objetos VALUES
('sp_CopiarMenusEmpresa','P','MENUS'),
('sp_CopiarRolesEmpresa','P','ROLES'),
('sp_CopiarImagenesEmpresa','P','IMAGENES'),
('sp_CopiarColoresEmpresa','P','COLORES'),
('sp_CopiarDocumentosEmpresa','P','DOCUMENTOS'),
('sp_CopiarPerfilesEmpresa','P','PERFILES'),
('sp_CopiarPlanesEmpresa','P','PLANES'),
('sp_CopiarParametrosEmpresa','P','PARAMETROS'),
('bf_EmpresaMVP','U','UNIVERSO'),
('bf_BitacoraEmpresa','U','BITACORA'),
('ff_MenuRol','U','MENUS'),
('ff_MenuRol2','U','MENUS'),
('ff_Rol','U','ROLES'),
('ff_EmpresaImagen','U','IMAGENES'),
('ff_ImagenEmpresaMenu','U','IMAGENES'),
('ff_Parametro','U','COLORES/PARAMETROS'),
('ff_Documentos','U','DOCUMENTOS'),
('ff_Perfil','U','PERFILES'),
('ff_DocumentoPlanB3','U','PLANES');

SELECT Objeto,Componente,
       Resultado=CASE WHEN OBJECT_ID('dbo.'+Objeto,Tipo) IS NULL THEN 'FALTA' ELSE 'OK' END
FROM @Objetos
ORDER BY Resultado DESC,Componente,Objeto;

/* Confirma la firma que necesitan los EXEC del script 02. */
SELECT
    p.name AS Procedimiento,
    Firma=CASE WHEN
      EXISTS (SELECT 1 FROM sys.parameters x WHERE x.object_id=p.object_id AND x.name='@IdEmpresaOrigen' AND x.is_output=0)
      AND EXISTS (SELECT 1 FROM sys.parameters x WHERE x.object_id=p.object_id AND x.name='@IdEmpresaDestino' AND x.is_output=0)
      AND EXISTS (SELECT 1 FROM sys.parameters x WHERE x.object_id=p.object_id AND x.name='@IdUsuario' AND x.is_output=0)
      AND EXISTS (SELECT 1 FROM sys.parameters x WHERE x.object_id=p.object_id AND x.name='@CantidadCopiada' AND x.is_output=1)
      THEN 'OK' ELSE 'NO_COINCIDE' END
FROM sys.procedures p
WHERE p.name IN
('sp_CopiarMenusEmpresa','sp_CopiarRolesEmpresa','sp_CopiarImagenesEmpresa',
 'sp_CopiarColoresEmpresa','sp_CopiarDocumentosEmpresa','sp_CopiarPerfilesEmpresa',
 'sp_CopiarPlanesEmpresa','sp_CopiarParametrosEmpresa')
ORDER BY p.name;

IF EXISTS
(
    SELECT 1 FROM @Objetos
    WHERE OBJECT_ID('dbo.'+Objeto,Tipo) IS NULL
)
    THROW 51000, 'Faltan objetos del flujo MVP B3 comprobado.', 1;

IF EXISTS
(
    SELECT 1
    FROM sys.procedures p
    WHERE p.name IN
    ('sp_CopiarMenusEmpresa','sp_CopiarRolesEmpresa','sp_CopiarImagenesEmpresa',
     'sp_CopiarColoresEmpresa','sp_CopiarDocumentosEmpresa','sp_CopiarPerfilesEmpresa',
     'sp_CopiarPlanesEmpresa','sp_CopiarParametrosEmpresa')
      AND
      (
        NOT EXISTS (SELECT 1 FROM sys.parameters x WHERE x.object_id=p.object_id AND x.name='@IdEmpresaOrigen' AND x.is_output=0)
        OR NOT EXISTS (SELECT 1 FROM sys.parameters x WHERE x.object_id=p.object_id AND x.name='@IdEmpresaDestino' AND x.is_output=0)
        OR NOT EXISTS (SELECT 1 FROM sys.parameters x WHERE x.object_id=p.object_id AND x.name='@IdUsuario' AND x.is_output=0)
        OR NOT EXISTS (SELECT 1 FROM sys.parameters x WHERE x.object_id=p.object_id AND x.name='@CantidadCopiada' AND x.is_output=1)
      )
)
    THROW 51000, 'La firma de uno o mas procedimientos B3 no coincide.', 1;

DROP TABLE IF EXISTS #EmpresasMVP;

SELECT DISTINCT m.IdEmpresa,e.EMNombre,e.EMidCorporativo
INTO #EmpresasMVP
FROM dbo.bf_EmpresaMVP m
JOIN dbo.ff_Empresa e ON e.EMidEmpresa=m.IdEmpresa
WHERE m.IdEstatus=1
  AND e.EMidEstatus=1
  AND m.IdEmpresa<>@IdEmpresaModeloB3;

SELECT
    EmpresasMVPActivas=COUNT(*),
    CantidadEsperada=@CantidadEsperada,
    Resultado=CASE WHEN COUNT(*)=@CantidadEsperada THEN 'OK' ELSE 'REVISAR' END
FROM #EmpresasMVP;

/* Cantidades que contiene la empresa modelo. */
SELECT
    IdEmpresaModelo=@IdEmpresaModeloB3,
    Roles=(SELECT COUNT(*) FROM dbo.ff_Rol WHERE ROIdEmpresa=@IdEmpresaModeloB3 AND ROIdEstatus=1),
    Perfiles=(SELECT COUNT(*) FROM dbo.ff_Perfil WHERE PEIdEmpresa=@IdEmpresaModeloB3 AND PEIdEstatus=1),
    MenusV1=(SELECT COUNT(*) FROM dbo.ff_MenuRol mr JOIN dbo.ff_Rol r ON r.ROIdRol=mr.MRidRol WHERE r.ROIdEmpresa=@IdEmpresaModeloB3 AND mr.MRidEstatus=1),
    MenusV2=(SELECT COUNT(*) FROM dbo.ff_MenuRol2 mr JOIN dbo.ff_Rol r ON r.ROIdRol=mr.MRidRol WHERE r.ROIdEmpresa=@IdEmpresaModeloB3 AND mr.MRidEstatus=1),
    ImagenesEmpresa=(SELECT COUNT(*) FROM dbo.ff_EmpresaImagen WHERE EIIdEmpresa=@IdEmpresaModeloB3),
    ImagenesMenu=(SELECT COUNT(*) FROM dbo.ff_ImagenEmpresaMenu WHERE IEMIdEmpresa=@IdEmpresaModeloB3 AND IEMEstatus=1),
    ColoresEstilos=(SELECT COUNT(*) FROM dbo.ff_Parametro WHERE paIdEmpresa=@IdEmpresaModeloB3 AND paidEstatus=1 AND (paClase LIKE '%COLOR%' OR paClase LIKE '%ESTILO%' OR paClase LIKE '%CSS%')),
    Documentos=(SELECT COUNT(*) FROM dbo.ff_Documentos WHERE DOIdEmpresa=@IdEmpresaModeloB3 AND DOUsuarioDel IS NULL),
    DocumentosPlanB3=(SELECT COUNT(*) FROM dbo.ff_DocumentoPlanB3 WHERE DPIdEmpresa=@IdEmpresaModeloB3 AND DPEstatus=1),
    Parametros=(SELECT COUNT(*) FROM dbo.ff_Parametro WHERE paIdEmpresa=@IdEmpresaModeloB3 AND paidEstatus=1),
    Aviso226ModeloEmpresa=(SELECT COUNT(*) FROM dbo.ff_Parametro WHERE paIdEmpresa=@IdEmpresaModeloB3 AND paId=226 AND paidEstatus=1 AND NULLIF(LTRIM(RTRIM(paValor)),'') IS NOT NULL),
    Aviso226ModeloCorporativo=(SELECT COUNT(*) FROM dbo.ff_Parametro WHERE paIdEmpresa=@IdCorporativoModeloB3 AND paId=226 AND paidEstatus=1 AND NULLIF(LTRIM(RTRIM(paValor)),'') IS NOT NULL);

/*
 Diferencias por empresa; son estimaciones previas, no cambios.

 - RolesFaltantes/PerfilesFaltantes: configuracion B3 que se agregaria.
 - PerfilesQueSeActualizarian: perfiles B2 existentes que cambiarian atributos.
 - Imagenes/Colores/Documentos/Parametros: informacion existente potencialmente
   reemplazada por el modelo B3. Estos valores deben revisarse antes de aplicar.
*/
SELECT
    e.IdEmpresa,
    e.EMNombre,
    CorporativoValido=CASE WHEN EXISTS
      (SELECT 1 FROM dbo.ff_Empresa c WHERE c.EMidEmpresa=e.EMidCorporativo AND c.EMidEstatus=1)
      THEN 'OK' ELSE 'REVISAR' END,
    RolesFaltantes=(SELECT COUNT(*) FROM dbo.ff_Rol o WHERE o.ROIdEmpresa=@IdEmpresaModeloB3 AND o.ROIdEstatus=1 AND NOT EXISTS
      (SELECT 1 FROM dbo.ff_Rol d WHERE d.ROIdEmpresa=e.IdEmpresa AND d.ROIdEstatus=1 AND d.RODescripcionCorta=o.RODescripcionCorta AND d.RODescripcionLarga=o.RODescripcionLarga)),
    PerfilesFaltantes=(SELECT COUNT(*) FROM dbo.ff_Perfil o WHERE o.PEIdEmpresa=@IdEmpresaModeloB3 AND o.PEIdEstatus=1 AND NOT EXISTS
      (SELECT 1 FROM dbo.ff_Perfil d WHERE d.PEIdEmpresa=e.IdEmpresa AND d.PENombre=o.PENombre)),
    PerfilesQueSeActualizarian=(SELECT COUNT(*) FROM dbo.ff_Perfil o JOIN dbo.ff_Perfil d ON d.PEIdEmpresa=e.IdEmpresa AND d.PENombre=o.PENombre WHERE o.PEIdEmpresa=@IdEmpresaModeloB3 AND o.PEIdEstatus=1),
    ImagenesQueSeReemplazarian=(SELECT COUNT(*) FROM dbo.ff_EmpresaImagen WHERE EIIdEmpresa=e.IdEmpresa)+(SELECT COUNT(*) FROM dbo.ff_ImagenEmpresaMenu WHERE IEMIdEmpresa=e.IdEmpresa),
    ColoresQueSeReemplazarian=(SELECT COUNT(*) FROM dbo.ff_Parametro WHERE paIdEmpresa=e.IdEmpresa AND (paClase LIKE '%COLOR%' OR paClase LIKE '%ESTILO%' OR paClase LIKE '%CSS%')),
    DocumentosCoincidentes=(SELECT COUNT(*) FROM dbo.ff_Documentos d WHERE d.DOIdEmpresa=e.IdEmpresa AND d.DOUsuarioDel IS NULL AND EXISTS
      (SELECT 1 FROM dbo.ff_Documentos o WHERE o.DOIdEmpresa=@IdEmpresaModeloB3 AND o.DOUsuarioDel IS NULL AND o.DONombreDocumento=d.DONombreDocumento)),
    ParametrosQueSeReemplazarian=(SELECT COUNT(*) FROM dbo.ff_Parametro d WHERE d.paIdEmpresa=e.IdEmpresa AND d.paId<>226 AND EXISTS
      (SELECT 1 FROM dbo.ff_Parametro o WHERE o.paIdEmpresa=@IdEmpresaModeloB3 AND o.paidEstatus=1 AND o.paId=d.paId)),
    Aviso226EmpresaB2=CASE WHEN EXISTS
      (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=e.IdEmpresa AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL)
      THEN 'REUTILIZAR_EMPRESA_B2' ELSE 'NO_VALIDO_O_NO_EXISTE' END,
    Aviso226CorporativoB2=CASE WHEN EXISTS
      (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=e.EMidCorporativo AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL)
      THEN 'REUTILIZAR_CORPORATIVO_B2' ELSE 'NO_VALIDO_O_NO_EXISTE' END,
    AccionCorporativo226=CASE
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=e.EMidCorporativo AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'CONSERVAR_CORPORATIVO_B2'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=@IdCorporativoModeloB3 AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'COMPLETAR_DESDE_CORP_MODELO_B3'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=@IdEmpresaModeloB3 AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'COMPLETAR_DESDE_EMP_MODELO_B3'
      ELSE 'SIN_FUENTE_MODELO_REVISAR' END,
    FuenteAviso226=CASE
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=e.IdEmpresa AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'EMPRESA_B2'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=e.EMidCorporativo AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'CORPORATIVO_B2'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=@IdCorporativoModeloB3 AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'CORPORATIVO_MODELO_B3'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=@IdEmpresaModeloB3 AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'EMPRESA_MODELO_B3'
      ELSE 'SIN_FUENTE_REVISAR' END
FROM #EmpresasMVP e
ORDER BY e.IdEmpresa;

/* Confirma que los complementos fuera de alcance no se consideran. */
SELECT Exclusiones='Carga masiva, acceso/inicio BeFlex, plantillas MVP, Interfabrica, menus especiales, parametros 128/232 y reparacion de administradores.',
       Incluido='Aviso de privacidad 226: conserva B2 valido y completa solamente faltantes.';

PRINT 'Prevalidacion terminada. No se modificaron datos.';
