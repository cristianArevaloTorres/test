/*
 HOMOLOGACION DE EMPRESAS EXISTENTES USANDO SOLO CONFIGURACION MVP B3.

 Por seguridad:
 - @Aplicar=0 solamente muestra el plan.
 - @ProcesarTodas=0 exige indicar una empresa piloto.
 - los reemplazos requieren @PermitirReemplazos=1.
 - no contiene carga masiva ni complementos v3, salvo el requisito puntual 226.
*/

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Aplicar BIT = 0;
DECLARE @IdEmpresaModeloB3 INT = NULL;  -- OBLIGATORIO
DECLARE @IdUsuarioEjecucion INT = 0;    -- OBLIGATORIO al aplicar

/* Seleccion: primero una empresa piloto; despues se puede habilitar el total. */
DECLARE @ProcesarTodas BIT = 0;
DECLARE @IdEmpresaDestino INT = NULL;
DECLARE @CantidadEsperada INT = 286;
DECLARE @PermitirCantidadDistinta BIT = 0;

/* Componentes exactos de LogicaEmpresaMVP.replicarElementos. */
DECLARE @CopiarMenus BIT = 1;
DECLARE @CopiarRoles BIT = 1;
DECLARE @CopiarImagenes BIT = 1;
DECLARE @CopiarColores BIT = 1;
DECLARE @CopiarDocumentos BIT = 1;
DECLARE @CopiarPerfiles BIT = 1;
DECLARE @CopiarPlanes BIT = 1;
DECLARE @CopiarParametros BIT = 1;

/* Imagenes, colores, documentos, perfiles y parametros modifican existentes. */
DECLARE @PermitirReemplazos BIT = 0;
DECLARE @IdEjecucion UNIQUEIDENTIFIER = NEWID();
DECLARE @IdCorporativoModeloB3 INT;

IF @IdEmpresaModeloB3 IS NULL
    THROW 51000, 'Indique @IdEmpresaModeloB3.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdEmpresaModeloB3 AND EMidEstatus=1)
    THROW 51000, 'La empresa modelo B3 no existe o esta inactiva.', 1;

SELECT @IdCorporativoModeloB3=EMidCorporativo
FROM dbo.ff_Empresa
WHERE EMidEmpresa=@IdEmpresaModeloB3;

IF @ProcesarTodas=0 AND @IdEmpresaDestino IS NULL
    THROW 51000, 'Indique @IdEmpresaDestino para piloto o habilite @ProcesarTodas=1.', 1;

IF @IdEmpresaDestino=@IdEmpresaModeloB3
    THROW 51000, 'La empresa modelo no puede ser empresa destino.', 1;

IF OBJECT_ID('dbo.bf_EmpresaMVP','U') IS NULL
    THROW 51000, 'No existe dbo.bf_EmpresaMVP.', 1;

IF OBJECT_ID('dbo.bf_BitacoraEmpresa','U') IS NULL
    THROW 51000, 'No existe dbo.bf_BitacoraEmpresa.', 1;

IF OBJECT_ID('dbo.sp_CopiarMenusEmpresa','P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarRolesEmpresa','P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarImagenesEmpresa','P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarColoresEmpresa','P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarDocumentosEmpresa','P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarPerfilesEmpresa','P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarPlanesEmpresa','P') IS NULL
 OR OBJECT_ID('dbo.sp_CopiarParametrosEmpresa','P') IS NULL
    THROW 51000, 'Faltan procedimientos usados directamente por EmpresaMVP en B3.', 1;

/* La firma SQL debe coincidir con la utilizada por este paquete. */
DECLARE @FirmaEsperada TABLE
(
    Procedimiento SYSNAME NOT NULL,
    Parametro SYSNAME NOT NULL,
    EsSalida BIT NOT NULL
);

INSERT INTO @FirmaEsperada
SELECT p.Procedimiento,v.Parametro,v.EsSalida
FROM (VALUES
 ('sp_CopiarMenusEmpresa'),('sp_CopiarRolesEmpresa'),
 ('sp_CopiarImagenesEmpresa'),('sp_CopiarColoresEmpresa'),
 ('sp_CopiarDocumentosEmpresa'),('sp_CopiarPerfilesEmpresa'),
 ('sp_CopiarPlanesEmpresa'),('sp_CopiarParametrosEmpresa')
) p(Procedimiento)
CROSS JOIN (VALUES
 ('@IdEmpresaOrigen',CONVERT(BIT,0)),
 ('@IdEmpresaDestino',CONVERT(BIT,0)),
 ('@IdUsuario',CONVERT(BIT,0)),
 ('@CantidadCopiada',CONVERT(BIT,1))
) v(Parametro,EsSalida);

IF EXISTS
(
    SELECT 1 FROM @FirmaEsperada f
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM sys.procedures p
        JOIN sys.parameters prm ON prm.object_id=p.object_id
        WHERE p.name=f.Procedimiento
          AND prm.name=f.Parametro
          AND prm.is_output=f.EsSalida
    )
)
    THROW 51000, 'La firma de uno o mas procedimientos B3 no coincide con el paquete.', 1;

DROP TABLE IF EXISTS #Empresas;

SELECT DISTINCT m.IdEmpresa,e.EMNombre,e.EMidCorporativo
INTO #Empresas
FROM dbo.bf_EmpresaMVP m
JOIN dbo.ff_Empresa e ON e.EMidEmpresa=m.IdEmpresa
WHERE m.IdEstatus=1
  AND e.EMidEstatus=1
  AND m.IdEmpresa<>@IdEmpresaModeloB3
  AND (@ProcesarTodas=1 OR m.IdEmpresa=@IdEmpresaDestino);

DECLARE @Total INT=(SELECT COUNT(*) FROM #Empresas);

IF @Total=0
    THROW 51000, 'No se encontraron empresas destino MVP activas con la seleccion indicada.', 1;

IF EXISTS
(
    SELECT 1
    FROM #Empresas e
    LEFT JOIN dbo.ff_Empresa c
      ON c.EMidEmpresa=e.EMidCorporativo AND c.EMidEstatus=1
    WHERE e.EMidCorporativo IS NULL OR c.EMidEmpresa IS NULL
)
    THROW 51000, 'Hay empresas destino sin corporativo activo valido.', 1;

IF @ProcesarTodas=1 AND @PermitirCantidadDistinta=0 AND @Total<>@CantidadEsperada
    THROW 51000, 'El total MVP no coincide con @CantidadEsperada.', 1;

/* Plan sin cambios. */
SELECT
    IdEjecucion=@IdEjecucion,
    e.IdEmpresa,e.EMNombre,
    Modelo=@IdEmpresaModeloB3,
    CopiarRoles=@CopiarRoles,
    CopiarPerfiles=@CopiarPerfiles,
    CopiarMenus=@CopiarMenus,
    CopiarImagenes=@CopiarImagenes,
    CopiarColores=@CopiarColores,
    CopiarDocumentos=@CopiarDocumentos,
    CopiarPlanes=@CopiarPlanes,
    CopiarParametros=@CopiarParametros,
    ImagenesActuales=(SELECT COUNT(*) FROM dbo.ff_EmpresaImagen WHERE EIIdEmpresa=e.IdEmpresa),
    ColoresActuales=(SELECT COUNT(*) FROM dbo.ff_Parametro WHERE paIdEmpresa=e.IdEmpresa AND (paClase LIKE '%COLOR%' OR paClase LIKE '%ESTILO%' OR paClase LIKE '%CSS%')),
    DocumentosCoincidentes=(SELECT COUNT(*) FROM dbo.ff_Documentos d WHERE d.DOIdEmpresa=e.IdEmpresa AND d.DOUsuarioDel IS NULL AND EXISTS
      (SELECT 1 FROM dbo.ff_Documentos o WHERE o.DOIdEmpresa=@IdEmpresaModeloB3 AND o.DOUsuarioDel IS NULL AND o.DONombreDocumento=d.DONombreDocumento)),
    PerfilesQueSeActualizaran=(SELECT COUNT(*) FROM dbo.ff_Perfil d WHERE d.PEIdEmpresa=e.IdEmpresa AND EXISTS
      (SELECT 1 FROM dbo.ff_Perfil o WHERE o.PEIdEmpresa=@IdEmpresaModeloB3 AND o.PEIdEstatus=1 AND o.PENombre=d.PENombre)),
    ParametrosQueSeReemplazaran=(SELECT COUNT(*) FROM dbo.ff_Parametro d WHERE d.paIdEmpresa=e.IdEmpresa AND EXISTS
      (SELECT 1 FROM dbo.ff_Parametro o WHERE o.paIdEmpresa=@IdEmpresaModeloB3 AND o.paidEstatus=1 AND o.paId=d.paId)),
    FuenteAviso226=CASE
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=e.IdEmpresa AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'CONSERVAR_EMPRESA_B2'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=e.EMidCorporativo AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'REUTILIZAR_CORPORATIVO_B2'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=@IdCorporativoModeloB3 AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'CORPORATIVO_MODELO_B3'
      WHEN EXISTS (SELECT 1 FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=@IdEmpresaModeloB3 AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) THEN 'EMPRESA_MODELO_B3'
      ELSE 'SIN_FUENTE_REVISAR' END
FROM #Empresas e
ORDER BY e.IdEmpresa;

SELECT
    IdEjecucion=@IdEjecucion,
    Aplicar=@Aplicar,
    ProcesarTodas=@ProcesarTodas,
    EmpresasSeleccionadas=@Total,
    Alcance='Ocho componentes del flujo Java MVP B3 mas aviso de privacidad 226 reutilizando B2',
    Excluido='Carga masiva, parametros 128/232 y demas complementos v3';

IF @Aplicar=0
BEGIN
    PRINT 'SIMULACION: no se modificaron datos.';
    RETURN;
END;

IF @IdUsuarioEjecucion<=0
    THROW 51000, 'Indique @IdUsuarioEjecucion.', 1;

/*
 Evita una ejecucion masiva parcial: antes de modificar la primera empresa se
 confirma que cada destino tenga una fuente valida para el aviso 226, ya sea
 en B2 (empresa/corporativo) o en el modelo B3 (empresa/corporativo).
*/
IF EXISTS
(
    SELECT 1
    FROM #Empresas e
    WHERE
      /* La empresa hija necesita una fuente propia, corporativa o modelo. */
      NOT EXISTS
      (
          SELECT 1 FROM dbo.ff_Parametro p
          WHERE p.paId=226 AND p.paidEstatus=1
            AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
            AND p.paIdEmpresa IN
                (e.IdEmpresa,e.EMidCorporativo,@IdEmpresaModeloB3,@IdCorporativoModeloB3)
      )
      OR
      /* Si el corporativo B2 no tiene aviso, solo el modelo B3 puede completarlo. */
      (
        NOT EXISTS
        (
            SELECT 1 FROM dbo.ff_Parametro p
            WHERE p.paIdEmpresa=e.EMidCorporativo AND p.paId=226
              AND p.paidEstatus=1
              AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
        )
        AND NOT EXISTS
        (
            SELECT 1 FROM dbo.ff_Parametro p
            WHERE p.paId=226 AND p.paidEstatus=1
              AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
              AND p.paIdEmpresa IN (@IdEmpresaModeloB3,@IdCorporativoModeloB3)
        )
      )
)
    THROW 51000, 'Hay empresas sin una fuente valida para el aviso 226. Revise la prevalidacion antes de aplicar.', 1;

IF @PermitirReemplazos=0
   AND (@CopiarImagenes=1 OR @CopiarColores=1 OR @CopiarDocumentos=1 OR @CopiarPerfiles=1 OR @CopiarParametros=1)
    THROW 51000, 'Los componentes seleccionados modifican existentes. Confirme respaldo y cambie @PermitirReemplazos=1.', 1;

DECLARE @Resultados TABLE
(
    IdEmpresa INT NOT NULL,
    Exitoso BIT NOT NULL,
    Roles INT NOT NULL DEFAULT 0,
    Perfiles INT NOT NULL DEFAULT 0,
    Menus INT NOT NULL DEFAULT 0,
    Imagenes INT NOT NULL DEFAULT 0,
    Colores INT NOT NULL DEFAULT 0,
    Documentos INT NOT NULL DEFAULT 0,
    Planes INT NOT NULL DEFAULT 0,
    Parametros INT NOT NULL DEFAULT 0,
    AvisoPrivacidad226 INT NOT NULL DEFAULT 0,
    Error VARCHAR(2000) NULL
);

/*
 Respaldo en memoria del aviso 226 original. Permite que la copia general de
 parametros nunca sobrescriba un aviso B2 que ya era activo y no vacio.
*/
DECLARE @AvisoOriginal TABLE
(
    IdEmpresa INT NOT NULL PRIMARY KEY,
    paClase CHAR(30) NULL,
    paValor CHAR(1500) NOT NULL,
    paDescripcion VARCHAR(MAX) NOT NULL,
    paidEstatus INT NOT NULL,
    paUsuarioAdd INT NOT NULL,
    paFechaAdd DATETIME NOT NULL,
    paUsuarioUmod INT NULL,
    paFechaUmod DATETIME NULL,
    paFechaDel DATETIME NULL,
    paUsuarioDel INT NULL,
    paUsuarioPerfil INT NULL
);

INSERT INTO @AvisoOriginal
SELECT p.paIdEmpresa,p.paClase,p.paValor,CONVERT(VARCHAR(MAX),p.paDescripcion),
       p.paidEstatus,p.paUsuarioAdd,p.paFechaAdd,p.paUsuarioUmod,p.paFechaUmod,
       p.paFechaDel,p.paUsuarioDel,p.paUsuarioPerfil
FROM dbo.ff_Parametro p
JOIN #Empresas e ON e.IdEmpresa=p.paIdEmpresa
WHERE p.paId=226;

DECLARE @Empresa INT,@CorporativoDestino INT,@Cantidad INT,@FuenteAviso INT;
DECLARE @cRoles INT,@cPerfiles INT,@cMenus INT,@cImagenes INT,@cColores INT,@cDocumentos INT,@cPlanes INT,@cParametros INT,@cAviso INT;

DECLARE empresas CURSOR LOCAL FAST_FORWARD FOR
SELECT IdEmpresa,EMidCorporativo FROM #Empresas ORDER BY IdEmpresa;

OPEN empresas;
FETCH NEXT FROM empresas INTO @Empresa,@CorporativoDestino;

WHILE @@FETCH_STATUS=0
BEGIN
    SELECT @cRoles=0,@cPerfiles=0,@cMenus=0,@cImagenes=0,@cColores=0,@cDocumentos=0,@cPlanes=0,@cParametros=0,@cAviso=0,@FuenteAviso=NULL;

    BEGIN TRY
        BEGIN TRANSACTION;

        /*
          ROLES
          Agrega roles B3 que no tengan equivalente por descripcion.
          No elimina ni actualiza roles existentes. Se ejecuta primero porque
          perfiles y menus necesitan mapear el rol del modelo al rol destino.
        */
        IF @CopiarRoles=1
        BEGIN
            EXEC dbo.sp_CopiarRolesEmpresa @IdEmpresaOrigen=@IdEmpresaModeloB3,@IdEmpresaDestino=@Empresa,@IdUsuario=@IdUsuarioEjecucion,@CantidadCopiada=@Cantidad OUTPUT;
            SET @cRoles=ISNULL(@Cantidad,0);
        END;

        /*
          PERFILES
          Agrega perfiles B3 que no existan por PENombre. Si ya existen,
          actualiza sus atributos con el modelo, pero conserva PEIdPerfil para
          no romper referencias de administradores y negocio.
        */
        IF @CopiarPerfiles=1
        BEGIN
            EXEC dbo.sp_CopiarPerfilesEmpresa @IdEmpresaOrigen=@IdEmpresaModeloB3,@IdEmpresaDestino=@Empresa,@IdUsuario=@IdUsuarioEjecucion,@CantidadCopiada=@Cantidad OUTPUT;
            SET @cPerfiles=ISNULL(@Cantidad,0);
        END;

        /*
          MENUS
          Agrega asignaciones faltantes en ff_MenuRol y ff_MenuRol2 para los
          roles equivalentes. No elimina menus adicionales del destino.
        */
        IF @CopiarMenus=1
        BEGIN
            EXEC dbo.sp_CopiarMenusEmpresa @IdEmpresaOrigen=@IdEmpresaModeloB3,@IdEmpresaDestino=@Empresa,@IdUsuario=@IdUsuarioEjecucion,@CantidadCopiada=@Cantidad OUTPUT;
            SET @cMenus=ISNULL(@Cantidad,0);
        END;

        /*
          IMAGENES
          Replica la imagen del modelo B3. El SP elimina las imagenes actuales
          del destino, vuelve a insertar las del modelo y actualiza EMImagenIzq.
        */
        IF @CopiarImagenes=1
        BEGIN
            EXEC dbo.sp_CopiarImagenesEmpresa @IdEmpresaOrigen=@IdEmpresaModeloB3,@IdEmpresaDestino=@Empresa,@IdUsuario=@IdUsuarioEjecucion,@CantidadCopiada=@Cantidad OUTPUT;
            SET @cImagenes=ISNULL(@Cantidad,0);
        END;

        /*
          COLORES/ESTILOS
          El SP elimina los parametros COLOR/ESTILO/CSS actuales y copia los
          activos del modelo. Este paso reemplaza personalizacion visual B2.
        */
        IF @CopiarColores=1
        BEGIN
            EXEC dbo.sp_CopiarColoresEmpresa @IdEmpresaOrigen=@IdEmpresaModeloB3,@IdEmpresaDestino=@Empresa,@IdUsuario=@IdUsuarioEjecucion,@CantidadCopiada=@Cantidad OUTPUT;
            SET @cColores=ISNULL(@Cantidad,0);
        END;

        /*
          DOCUMENTOS
          Copia registros de ff_Documentos del modelo. Reemplaza solamente los
          documentos destino cuyo nombre coincide y conserva los demas.
        */
        IF @CopiarDocumentos=1
        BEGIN
            EXEC dbo.sp_CopiarDocumentosEmpresa @IdEmpresaOrigen=@IdEmpresaModeloB3,@IdEmpresaDestino=@Empresa,@IdUsuario=@IdUsuarioEjecucion,@CantidadCopiada=@Cantidad OUTPUT;
            SET @cDocumentos=ISNULL(@Cantidad,0);
        END;

        /*
          PLANES
          Agrega ff_DocumentoPlanB3 faltante por DPIdPlan. No reemplaza los
          existentes y no replica la estructura completa de ff_Plan.
        */
        IF @CopiarPlanes=1
        BEGIN
            EXEC dbo.sp_CopiarPlanesEmpresa @IdEmpresaOrigen=@IdEmpresaModeloB3,@IdEmpresaDestino=@Empresa,@IdUsuario=@IdUsuarioEjecucion,@CantidadCopiada=@Cantidad OUTPUT;
            SET @cPlanes=ISNULL(@Cantidad,0);
        END;

        /*
          PARAMETROS
          Reemplaza en el destino los paId activos presentes en el modelo B3.
          Conserva cualquier parametro cuyo paId no exista en el modelo.
        */
        IF @CopiarParametros=1
        BEGIN
            EXEC dbo.sp_CopiarParametrosEmpresa @IdEmpresaOrigen=@IdEmpresaModeloB3,@IdEmpresaDestino=@Empresa,@IdUsuario=@IdUsuarioEjecucion,@CantidadCopiada=@Cantidad OUTPUT;
            SET @cParametros=ISNULL(@Cantidad,0);
        END;

        /*
          AVISO DE PRIVACIDAD 226

          B2 puede tener un PDF estatico, mientras que el login B3 consulta
          ff_Parametro(226). Primero se conserva el valor valido de la empresa
          B2. Si falta, se reutiliza el corporativo B2. El modelo B3 se usa solo
          cuando B2 no aporta un valor. Nunca se sobrescribe un 226 B2 valido.
        */

        /* Completar el corporativo unicamente cuando no tiene un 226 valido. */
        IF NOT EXISTS
        (
            SELECT 1 FROM dbo.ff_Parametro
            WHERE paIdEmpresa=@CorporativoDestino AND paId=226 AND paidEstatus=1
              AND NULLIF(LTRIM(RTRIM(paValor)),'') IS NOT NULL
        )
        BEGIN
            DELETE FROM dbo.ff_Parametro
            WHERE paIdEmpresa=@CorporativoDestino AND paId=226;

            SELECT @FuenteAviso=NULL;

            SELECT TOP 1 @FuenteAviso=p.paIdEmpresa
            FROM dbo.ff_Parametro p
            WHERE p.paId=226 AND p.paidEstatus=1
              AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
              AND p.paIdEmpresa IN (@IdCorporativoModeloB3,@IdEmpresaModeloB3)
            ORDER BY CASE WHEN p.paIdEmpresa=@IdCorporativoModeloB3 THEN 1 ELSE 2 END;

            IF @FuenteAviso IS NULL
                THROW 51000, 'No existe una fuente modelo valida para el aviso corporativo 226.', 1;

            INSERT INTO dbo.ff_Parametro
            (paId,paIdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
             paUsuarioAdd,paFechaAdd,paUsuarioUmod,paFechaUmod,paUsuarioPerfil)
            SELECT paId,@CorporativoDestino,paClase,paValor,paDescripcion,paidEstatus,
                   @IdUsuarioEjecucion,GETDATE(),@IdUsuarioEjecucion,GETDATE(),paUsuarioPerfil
            FROM dbo.ff_Parametro
            WHERE paIdEmpresa=@FuenteAviso AND paId=226;
            SET @cAviso=@cAviso+@@ROWCOUNT;
        END;

        /* Restaurar aviso B2 valido o completar la empresa desde su corporativo. */
        IF EXISTS
        (
            SELECT 1 FROM @AvisoOriginal
            WHERE IdEmpresa=@Empresa AND paidEstatus=1
              AND NULLIF(LTRIM(RTRIM(paValor)),'') IS NOT NULL
        )
        BEGIN
            DELETE FROM dbo.ff_Parametro WHERE paIdEmpresa=@Empresa AND paId=226;

            INSERT INTO dbo.ff_Parametro
            (paId,paIdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
             paUsuarioAdd,paFechaAdd,paUsuarioUmod,paFechaUmod,
             paFechaDel,paUsuarioDel,paUsuarioPerfil)
            SELECT 226,IdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
                   paUsuarioAdd,paFechaAdd,paUsuarioUmod,paFechaUmod,
                   paFechaDel,paUsuarioDel,paUsuarioPerfil
            FROM @AvisoOriginal
            WHERE IdEmpresa=@Empresa;
        END
        ELSE
        BEGIN
            SELECT @FuenteAviso=NULL;

            SELECT TOP 1 @FuenteAviso=p.paIdEmpresa
            FROM dbo.ff_Parametro p
            WHERE p.paId=226 AND p.paidEstatus=1
              AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
              AND p.paIdEmpresa IN (@CorporativoDestino,@IdCorporativoModeloB3,@IdEmpresaModeloB3)
            ORDER BY CASE
                WHEN p.paIdEmpresa=@CorporativoDestino THEN 1
                WHEN p.paIdEmpresa=@IdCorporativoModeloB3 THEN 2
                ELSE 3 END;

            IF @FuenteAviso IS NULL
                THROW 51000, 'No existe aviso 226 valido para completar la empresa.', 1;

            DELETE FROM dbo.ff_Parametro WHERE paIdEmpresa=@Empresa AND paId=226;

            INSERT INTO dbo.ff_Parametro
            (paId,paIdEmpresa,paClase,paValor,paDescripcion,paidEstatus,
             paUsuarioAdd,paFechaAdd,paUsuarioUmod,paFechaUmod,paUsuarioPerfil)
            SELECT paId,@Empresa,paClase,paValor,paDescripcion,paidEstatus,
                   @IdUsuarioEjecucion,GETDATE(),@IdUsuarioEjecucion,GETDATE(),paUsuarioPerfil
            FROM dbo.ff_Parametro
            WHERE paIdEmpresa=@FuenteAviso AND paId=226;
            SET @cAviso=@cAviso+@@ROWCOUNT;
        END;

        INSERT INTO dbo.bf_BitacoraEmpresa
        (BEIdEmpresa,BEIdUsuario,BEAccion,BEDetalle,BEElementoAfectado,BECantidadElementos,BEExitoso,BEFechaCreacion)
        VALUES
        (@Empresa,@IdUsuarioEjecucion,'HOMOLOGAR_SOLO_CONFIG_MVP_B3',
         'Ejecucion '+CONVERT(VARCHAR(36),@IdEjecucion)+'; modelo '+CONVERT(VARCHAR(20),@IdEmpresaModeloB3),
         '8 componentes EmpresaMVP + aviso 226',@cRoles+@cPerfiles+@cMenus+@cImagenes+@cColores+@cDocumentos+@cPlanes+@cParametros+@cAviso,1,GETDATE());

        COMMIT TRANSACTION;

        INSERT INTO @Resultados VALUES
        (@Empresa,1,@cRoles,@cPerfiles,@cMenus,@cImagenes,@cColores,@cDocumentos,@cPlanes,@cParametros,@cAviso,NULL);
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;

        INSERT INTO @Resultados(IdEmpresa,Exitoso,Error)
        VALUES(@Empresa,0,LEFT(ERROR_MESSAGE(),2000));

        BEGIN TRY
            INSERT INTO dbo.bf_BitacoraEmpresa
            (BEIdEmpresa,BEIdUsuario,BEAccion,BEDetalle,BEElementoAfectado,BECantidadElementos,BEExitoso,BEMensajeError,BEFechaCreacion)
            VALUES
            (@Empresa,@IdUsuarioEjecucion,'HOMOLOGAR_SOLO_CONFIG_MVP_B3',
             'Ejecucion '+CONVERT(VARCHAR(36),@IdEjecucion)+'; modelo '+CONVERT(VARCHAR(20),@IdEmpresaModeloB3),
             '8 componentes EmpresaMVP + aviso 226',0,0,LEFT(ERROR_MESSAGE(),2000),GETDATE());
        END TRY BEGIN CATCH END CATCH;
    END CATCH;

    FETCH NEXT FROM empresas INTO @Empresa,@CorporativoDestino;
END;

CLOSE empresas;
DEALLOCATE empresas;

SELECT IdEjecucion=@IdEjecucion,IdEmpresa,Exitoso,Roles,Perfiles,Menus,Imagenes,Colores,Documentos,Planes,Parametros,AvisoPrivacidad226,Error
FROM @Resultados ORDER BY IdEmpresa;

PRINT 'Homologacion terminada. Ejecute 03_VALIDACION_SOLO_CONFIG_MVP_B3.sql.';
