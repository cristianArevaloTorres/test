# Resultado de verificación final

Fecha: 1 de septiembre de 2026.

## Alcance comprobado

El script ejecutable contiene únicamente las ocho llamadas directas del flujo Java `EmpresaMVP`:

- roles;
- perfiles;
- menús;
- imágenes;
- colores/estilos;
- documentos;
- documentos de planes B3;
- parámetros.

Adicionalmente valida y completa el aviso de privacidad `paId = 226`, porque el login B3 consulta ese parámetro. No se ejecuta carga masiva ni otro complemento v3.

## Correcciones de la revisión final

- El aviso B2 activo y no vacío de la empresa se conserva aunque la copia general de parámetros contenga otro `226`.
- Si la empresa no tiene aviso, se reutiliza el aviso válido de su corporativo B2.
- Si el corporativo no tiene aviso, se completa exclusivamente desde el modelo B3 aprobado.
- No se promueve un aviso particular de una empresa hija al corporativo, para evitar afectar a otras empresas del mismo corporativo.
- El parámetro `226` se excluyó de la comparación general contra el modelo y se valida por separado.
- Se agregó validación de corporativos activos y de las firmas SQL requeridas.
- Antes de aplicar se comprueba que todas las empresas seleccionadas tengan una fuente válida para el aviso.

## Pruebas realizadas en LocalDB

- Los cuatro SQL pasaron análisis sintáctico y compilación: resultado `0`.
- Los ocho procedimientos existen y sus cuatro parámetros requeridos coinciden.
- La prevalidación y el análisis se ejecutaron sin modificar información.
- Búsqueda de llamadas fuera de alcance en el ejecutable: ninguna.
- Prueba de conservación: la empresa hija mantuvo `AVISO B2 ORIGINAL` y el corporativo faltante recibió `AVISO B3 MODELO`.
- Prueba de reutilización: una hija sin aviso recibió `AVISO CORPORATIVO B2` sin sobrescribir al corporativo.
- Prueba integrada: se ejecutaron los ocho procedimientos, privacidad y validación sobre una empresa de prueba dentro de una transacción externa.
- Resultado de la validación integrada: una empresa correcta, cero por revisar.
- La transacción externa permaneció activa hasta el `ROLLBACK`.
- Verificación posterior: cero marcadores y cero avisos de prueba residuales.

## Limitación del ambiente local

La tabla local `bf_EmpresaMVP` no contiene las 286 empresas y la empresa local 2494 no contiene una configuración modelo completa ni el aviso `226`. Ese ID no debe asumirse en QA o producción.

En la base funcional se debe indicar la empresa modelo B3 aprobada y ejecutar primero `01_PREVALIDACION_SOLO_CONFIG_MVP_B3.sql`. No debe aplicarse la homologación si aparece una firma diferente, un corporativo inválido o `SIN_FUENTE_REVISAR`/`SIN_FUENTE_MODELO_REVISAR`.
