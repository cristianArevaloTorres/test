/* VALIDACION GLOBAL DESPUES DEL MASIVO. Sólo lectura. */
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;

DECLARE @Corporativos TABLE (IdCorporativo INT PRIMARY KEY,Grupo VARCHAR(30));
INSERT INTO @Corporativos VALUES
(495,'HAPAG'),(531,'GN102'),(658,'GCABLE'),(698,'TORRENT'),(718,'UNICCO'),
(721,'CCPM'),(723,'SCHNEIDER'),(725,'IMCP'),(727,'BIOMETC'),(752,'GEPC'),
(756,'LOEFFLERC'),(758,'AMCHAM'),(760,'IMEFC'),(762,'PRV'),(790,'MELTSANC'),
(797,'CLYPC'),(799,'VITOLC'),(806,'SGWIC'),(812,'DE LA VEGA'),(814,'CONSTRUMACC');

CREATE TABLE #Objetivos (IdEmpresa INT PRIMARY KEY,IdCorporativo INT,Grupo VARCHAR(30),Empresa VARCHAR(200));
INSERT #Objetivos
SELECT e.EMidEmpresa,c.IdCorporativo,c.Grupo,e.EMRazonSocial
FROM @Corporativos c
JOIN dbo.ff_Empresa e ON e.EMidCorporativo=c.IdCorporativo
WHERE e.EMidEmpresa<>c.IdCorporativo AND e.EMidEstatus=1;

SELECT '01_VALIDACION_GLOBAL' Bloque,o.IdCorporativo,o.Grupo,o.IdEmpresa,o.Empresa,
       x.MarcaMVP,x.Roles,x.Perfiles,x.AdministradoresActivos,x.ReferenciasAdminInvalidas,
       x.MenusV2,x.IconosMenuV2,x.RutasIconosEmpresa,x.EstilosB3,x.ParametrosVisuales,
       x.AccesoBeflex,x.Aviso226,
       x.Sso232,x.OperacionesCarga,x.OperacionesBaseCorrectas,x.PlantillasMVP,x.BitacoraExitosa,
       CASE
           WHEN x.MarcaMVP<>1 THEN 'REVISAR MARCA MVP'
           WHEN x.Roles=0 THEN 'REVISAR ROLES'
           WHEN x.Perfiles=0 THEN 'REVISAR PERFILES'
           WHEN x.AdministradoresActivos=0 THEN 'REVISAR ADMINISTRADORES ASOCIADOS'
           WHEN x.ReferenciasAdminInvalidas>0 THEN 'REVISAR REFERENCIAS ADMINISTRADOR'
           WHEN x.MenusV2=0 THEN 'REVISAR MENUS V2'
           WHEN x.EstilosB3=0 AND x.ParametrosVisuales=0 THEN 'REVISAR ESTILOS/COLORES BF3'
           WHEN x.IconosMenuV2=0 AND x.RutasIconosEmpresa=0 THEN 'REVISAR ICONOS BF3'
           WHEN x.AccesoBeflex=0 THEN 'REVISAR ACCESO BF3'
           WHEN x.Aviso226=0 THEN 'REVISAR AVISO 226'
           WHEN x.Sso232>0 THEN 'REVISAR SSO 232'
           WHEN x.OperacionesCarga<>5 THEN 'REVISAR CARGA MASIVA'
           WHEN x.OperacionesBaseCorrectas<>3 THEN 'REVISAR MAPEO CARGA MASIVA'
           WHEN x.PlantillasMVP<3 THEN 'REVISAR PLANTILLAS MVP'
           WHEN x.BitacoraExitosa=0 THEN 'REVISAR BITACORA'
           ELSE 'OK PARA PRUEBA FUNCIONAL'
       END Resultado
FROM #Objetivos o
CROSS APPLY (
    SELECT
      (SELECT COUNT(*) FROM dbo.bf_EmpresaMVP m WHERE m.IdEmpresa=o.IdEmpresa AND m.IdEstatus=1) MarcaMVP,
      (SELECT COUNT(*) FROM dbo.ff_Rol r WHERE r.ROIdEmpresa=o.IdEmpresa AND r.ROIdEstatus=1) Roles,
      (SELECT COUNT(*) FROM dbo.ff_Perfil p WHERE p.PEIdEmpresa=o.IdEmpresa AND p.PEIdEstatus=1) Perfiles,
      (SELECT COUNT(*) FROM dbo.ff_AdministradorEmpresa ae WHERE ae.AEIdEmpresa=o.IdEmpresa AND ae.AEIdEstatus=1) AdministradoresActivos,
      (SELECT COUNT(*)
       FROM dbo.ff_AdministradorEmpresa ae
       LEFT JOIN dbo.ff_Perfil p
         ON p.PEIdPerfil=ae.AEIdPerfil AND p.PEIdEmpresa=ae.AEIdEmpresa AND p.PEIdEstatus=1
       LEFT JOIN dbo.ff_Rol r
         ON r.ROIdRol=ae.AEIdRol AND r.ROIdEmpresa=ae.AEIdEmpresa AND r.ROIdEstatus=1
       WHERE ae.AEIdEmpresa=o.IdEmpresa AND ae.AEIdEstatus=1
         AND (p.PEIdPerfil IS NULL OR r.ROIdRol IS NULL)) ReferenciasAdminInvalidas,
      (SELECT COUNT(*) FROM dbo.ff_MenuRol2 mr JOIN dbo.ff_Rol r ON r.ROIdRol=mr.MRidRol WHERE r.ROIdEmpresa=o.IdEmpresa AND r.ROIdEstatus=1 AND mr.MRidEstatus=1) MenusV2,
      (SELECT COUNT(DISTINCT mr.MRidMenu)
       FROM dbo.ff_Perfil p
       JOIN dbo.ff_Rol r ON r.ROIdRol=p.PEIdRolDefault AND r.ROIdEmpresa=p.PEIdEmpresa AND r.ROIdEstatus=1
       JOIN dbo.ff_MenuRol2 mr ON mr.MRidRol=r.ROIdRol AND mr.MRidEstatus=1
       WHERE p.PEIdEmpresa=o.IdEmpresa AND p.PEAdministrador=1 AND p.PEIdEstatus=1
         AND NULLIF(LTRIM(RTRIM(mr.MRImagenMenu)),'') IS NOT NULL) IconosMenuV2,
      (SELECT COUNT(*) FROM dbo.ff_ImagenEmpresaMenu m
       WHERE m.IEMIdEmpresa=o.IdEmpresa AND m.IEMEstatus=1
         AND (NULLIF(LTRIM(RTRIM(m.IEMImagenHijo)),'') IS NOT NULL
              OR NULLIF(LTRIM(RTRIM(m.IEMImagenDer)),'') IS NOT NULL
              OR NULLIF(LTRIM(RTRIM(m.IEMImagenIzq)),'') IS NOT NULL)) RutasIconosEmpresa,
      (SELECT COUNT(*) FROM dbo.bf_EstiloEmpresa s
       WHERE s.EEIdEmpresa=o.IdEmpresa AND s.EEIdEstatus=1
         AND NULLIF(LTRIM(RTRIM(s.EEValor)),'') IS NOT NULL) EstilosB3,
      (SELECT COUNT(*) FROM dbo.ff_Parametro p
       WHERE p.paIdEmpresa=o.IdEmpresa AND p.paidEstatus=1
         AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
         AND (UPPER(ISNULL(p.paClase,'')) LIKE '%COLOR%'
              OR UPPER(ISNULL(p.paClase,'')) LIKE '%ESTILO%'
              OR UPPER(ISNULL(p.paClase,'')) LIKE '%CSS%')) ParametrosVisuales,
      (SELECT COUNT(*) FROM dbo.ff_accesoBeflex a WHERE a.idempresa=o.IdEmpresa AND a.acceso=1) AccesoBeflex,
      (SELECT COUNT(*) FROM dbo.ff_Parametro p WHERE p.paIdEmpresa=o.IdEmpresa AND p.paId=226 AND p.paidEstatus=1 AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL) Aviso226,
      (SELECT COUNT(*) FROM dbo.ff_Parametro p WHERE p.paIdEmpresa IN (o.IdEmpresa,o.IdCorporativo) AND p.paId=232 AND p.paidEstatus=1) Sso232,
      (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa c WHERE c.CEIdEmpresa=o.IdEmpresa AND c.CEIdEstatus=1 AND c.CEIdOperacion IN (1,2,3,13,14)) OperacionesCarga,
      (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa c
       WHERE c.CEIdEmpresa=o.IdEmpresa AND c.CEIdEstatus=1
         AND (
              (c.CEIdOperacion=1 AND c.CEIdPlantilla=12061 AND LTRIM(RTRIM(c.CEStoredProc))='ff_XCMDependientesAltaCMM')
           OR (c.CEIdOperacion=2 AND c.CEIdPlantilla=12062 AND LTRIM(RTRIM(c.CEStoredProc))='ff_XCMTitularesAltaCMM_BF3')
           OR (c.CEIdOperacion=3 AND c.CEIdPlantilla=154 AND LTRIM(RTRIM(c.CEStoredProc))='ff_XCMAseguradosBaja_Base')
         )) OperacionesBaseCorrectas,
      (SELECT COUNT(*) FROM dbo.ff_Plantilla p WHERE p.PLDescripcion LIKE '%- MVP[_]'+CAST(o.IdEmpresa AS VARCHAR(12))+'%' AND p.PLIdEstatus=1) PlantillasMVP,
      (SELECT COUNT(*) FROM dbo.bf_BitacoraEmpresa b WHERE b.BEIdEmpresa=o.IdEmpresa AND b.BEAccion='BF_PROCESOMVP_V3' AND b.BEExitoso=1) BitacoraExitosa
) x
ORDER BY o.IdCorporativo,o.IdEmpresa;

SELECT '02_RESUMEN' Bloque,
       (SELECT COUNT(*) FROM @Corporativos) CorporativosRecibidos,
       (SELECT COUNT(*) FROM #Objetivos) EmpresasHijaActivas,
       (SELECT COUNT(*) FROM #Objetivos o WHERE EXISTS (SELECT 1 FROM dbo.bf_EmpresaMVP m WHERE m.IdEmpresa=o.IdEmpresa AND m.IdEstatus=1)) EmpresasMarcadasMVP,
       (SELECT COUNT(*) FROM #Objetivos o WHERE EXISTS (SELECT 1 FROM dbo.bf_BitacoraEmpresa b WHERE b.BEIdEmpresa=o.IdEmpresa AND b.BEAccion='BF_PROCESOMVP_V3' AND b.BEExitoso=1)) EmpresasConCascadaExitosa;

SELECT '03_ERRORES_BITACORA' Bloque,o.IdCorporativo,o.Grupo,o.IdEmpresa,
       b.BEAccion,b.BEMensajeError,b.BEDetalle,b.BEFechaCreacion
FROM #Objetivos o
JOIN dbo.bf_BitacoraEmpresa b ON b.BEIdEmpresa=o.IdEmpresa AND b.BEExitoso=0
WHERE b.BEFechaCreacion=(
    SELECT MAX(b2.BEFechaCreacion) FROM dbo.bf_BitacoraEmpresa b2
    WHERE b2.BEIdEmpresa=b.BEIdEmpresa AND b2.BEExitoso=0
)
ORDER BY o.IdCorporativo,o.IdEmpresa;

SELECT '04_DETALLE_CARGA_INCORRECTA' Bloque,o.IdCorporativo,o.Grupo,o.IdEmpresa,
       c.CEIdOperacion,c.CEIdPlantilla,c.CEStoredProc,c.CEIdEstatus
FROM #Objetivos o
LEFT JOIN dbo.ff_CargaMasivaOperacionEmpresa c
  ON c.CEIdEmpresa=o.IdEmpresa AND c.CEIdOperacion IN (1,2,3,13,14)
WHERE
   (c.CEIdOperacion=1 AND (c.CEIdPlantilla<>12061 OR c.CEStoredProc<>'ff_XCMDependientesAltaCMM' OR c.CEIdEstatus<>1))
OR (c.CEIdOperacion=2 AND (c.CEIdPlantilla<>12062 OR c.CEStoredProc<>'ff_XCMTitularesAltaCMM_BF3' OR c.CEIdEstatus<>1))
OR (c.CEIdOperacion=3 AND (c.CEIdPlantilla<>154 OR c.CEStoredProc<>'ff_XCMAseguradosBaja_Base' OR c.CEIdEstatus<>1))
OR c.CEIdOperacion IS NULL
ORDER BY o.IdCorporativo,o.IdEmpresa,c.CEIdOperacion;

DROP TABLE #Objetivos;
GO
