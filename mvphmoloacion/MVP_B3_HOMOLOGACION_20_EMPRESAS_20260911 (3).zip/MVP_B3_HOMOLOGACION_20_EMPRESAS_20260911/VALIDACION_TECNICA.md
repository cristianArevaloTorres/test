# Validación técnica del paquete

Fecha: 11/09/2026.

- Lista importada: 20 corporativos.
- Resolución en la copia local: 23 empresas hijas activas.
- Piloto identificado localmente: corporativo `495`, empresa `496`.
- Objetos exigidos por la cascada: 19.
- Scripts SQL analizados sintácticamente: 5 de 5 correctos.
- Diagnósticos ejecutados en modo sólo lectura: 3 de 3 correctos.
- Ejecutables probados con `PARSEONLY`: 2 de 2 correctos.
- Ejecuciones de homologación realizadas durante la validación: 0.

## Validación visual actualizada (18/09/2026)

- El selector `06` se ejecutó contra `(localdb)\MSSQLLocalDB / FlexiForbesv2` y terminó con código `0`.
- La empresa `186` no tiene un perfil administrador activo utilizable, pero sí aporta `47` iconos distintos mediante roles activos; ahora es una fuente válida de iconos porque el proceso ya no depende del rol administrador de la fuente.
- La ruta de prueba `Stilos/Menus/496/../186/369_64_logout.png` respondió HTTP `200` y el valor almacenado más largo queda en `56` bytes, por debajo de los `100` bytes de `ff_MenuRol2.MRImagenMenu`.
- El CSS de la fuente `Stilos/General/186/Cla186.css` respondió HTTP `200`; el CSS del destino `Stilos/General/496/Cla496.css` respondió HTTP `404`.
- La copia SQL puede reutilizar iconos con rutas relativas. El CSS sigue requiriendo que exista `Cla{idEmpresaDestino}.css` en el servidor estático, porque BF3 construye esa URL directamente con la empresa de la sesión.
- La copia local no contiene filas activas en `bf_EstiloEmpresa`; por seguridad, el selector no propone una fuente de estilos en ese ambiente y muestra `NO HAY FUENTE DE ESTILOS`.
- No se ejecutó ninguna homologación ni se modificaron datos durante estas comprobaciones.

## Observación local

La empresa modelo local `2494` existe bajo el corporativo `2493`, pero no contiene todos los insumos requeridos. Como el modelo fue indicado como obligatorio, esos conteos son informativos. La ejecución sí se detiene cuando falta una dependencia técnica utilizada directamente por la cascada. En el ambiente objetivo debe ejecutarse `00_DIAGNOSTICO_PREVIO_BF3.sql`; sólo un dictamen `CONTINUAR CON PILOTO` permite seguir.

## Corrección del error 3930

La primera versión envolvía `bf_ProcesoMVP` en una transacción exterior con `XACT_ABORT ON`. Los procedimientos internos realizan `BEGIN/COMMIT` y después intentan escribir su bitácora. Un error ignorado en esa bitácora podía dejar la transacción exterior no confirmable y el siguiente procedimiento reportaba `3930`. La versión corregida elimina esa envoltura, establece `XACT_ABORT OFF` y conserva únicamente las transacciones internas del flujo B3.

## Evidencia funcional usada

- La definición de `ff_AddEmpresa` ejecuta `bf_ProcesoMVP` cuando `@EM_MVP=1` y después inserta la marca `bf_EmpresaMVP`.
- La definición local de `bf_ProcesoMVP` acepta `@idEmpresa`, `@Usuario`, `@ModeloOrigen` y `@ModeloCorp` y orquesta la cascada completa.
- El diagnóstico recibido enumera la misma familia de objetos y señala `2494/2493` como modelos.
- `99_VALIDACION_EMPRESAS_MVP.sql` confirma como resultado esperado las cinco operaciones de carga masiva y las tres plantillas de pantalla MVP.
