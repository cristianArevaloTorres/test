/*
  SELECCION TECNICA DE MODELO VISUAL - SOLO LECTURA

  Objetivo:
    - Buscar cualquier empresa activa, sea MVP o no.
    - Comprobar que tenga estilos y rutas de iconos reutilizables.
    - Preferir acceso BF3, marca MVP y administrador, sin volverlos obligatorios.
    - Proponer @IdEmpresaModeloVisual sin considerar logos corporativos como puntos.

  Importante:
    - El primer lugar es un CANDIDATO TECNICO, no una autorizacion de marca.
    - Un perfil administrador NO es obligatorio para donar iconos. Cuando no
      existe, se inspeccionan todos los roles activos y se deduplica por MRidMenu.
    - Antes de copiar, revisar las URL devueltas al final y confirmar que sean
      recursos genericos/autorizados y que respondan desde el servidor web.
    - SQL valida referencias, no la existencia fisica de CSS/PNG.
    - No cambia ningun dato.
*/
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @IdEmpresaModeloFuncional INT=2494;
DECLARE @IdEmpresaModeloVisual INT=NULL;
DECLARE @IdEmpresaModeloIconos INT=NULL;
DECLARE @IdEmpresaPreferidaEstilos INT=NULL; -- Opcional. NULL elige el mejor candidato de estilos.
DECLARE @IdEmpresaPreferidaIconos INT=NULL;  -- Opcional, por ejemplo 186. NULL elige el mejor candidato de iconos.
DECLARE @UrlBaseRecursos VARCHAR(300)='https://belocktonha.com/';

DECLARE @Objetos TABLE (Objeto SYSNAME,Tipo CHAR(2));
INSERT INTO @Objetos VALUES
('dbo.ff_Empresa','U'),('dbo.bf_EmpresaMVP','U'),('dbo.ff_accesoBeflex','U'),
('dbo.ff_Perfil','U'),('dbo.ff_Rol','U'),('dbo.ff_MenuRol2','U'),
('dbo.bf_EstiloEmpresa','U'),('dbo.ff_Parametro','U'),
('dbo.ff_ImagenEmpresaMenu','U'),('dbo.ff_EmpresaImagen','U'),
('dbo.bf_BeflexInicio2','U');

IF EXISTS (SELECT 1 FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL)
BEGIN
    SELECT '00_OBJETOS_FALTANTES' Bloque,Objeto,Tipo
    FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL;
    THROW 51000, 'Faltan tablas necesarias para evaluar el modelo visual.', 1;
END;

/* Se evalua cada empresa activa. bf_EmpresaMVP es informativa, no un filtro. */
SELECT
    e.EMidEmpresa IdEmpresa,
    e.EMidCorporativo IdCorporativo,
    e.EMNombre Empresa,
    e.EMRazonSocial RazonSocial,
    CASE WHEN e.EMidEmpresa<>e.EMidCorporativo THEN 1 ELSE 0 END EsEmpresaHija,
    CASE WHEN EXISTS (
        SELECT 1 FROM dbo.bf_EmpresaMVP m
        WHERE m.IdEmpresa=e.EMidEmpresa AND m.IdEstatus=1
    ) THEN 1 ELSE 0 END EsMVP,
    CASE WHEN EXISTS (
        SELECT 1 FROM dbo.ff_accesoBeflex a
        WHERE a.idempresa=e.EMidEmpresa AND a.acceso=1
    ) THEN 1 ELSE 0 END AccesoBF3,
    ISNULL(admin.RolesAdministradorValidos,0) RolesAdministradorValidos,
    ISNULL(admin.MenusAdministrador,0) MenusAdministrador,
    ISNULL(admin.IconosMenuAdministrador,0) IconosMenuAdministrador,
    ISNULL(admin.BannersAdministrador,0) BannersAdministrador,
    ISNULL(menus.RolesConMenus,0) RolesConMenus,
    ISNULL(menus.MenusRolesActivos,0) MenusRolesActivos,
    ISNULL(menus.IconosRolesActivos,0) IconosRolesActivos,
    ISNULL(menus.BannersRolesActivos,0) BannersRolesActivos,
    ISNULL(est.EstilosB3,0) EstilosB3,
    ISNULL(estdup.EstilosDuplicados,0) EstilosDuplicados,
    ISNULL(par.ParametrosVisuales,0) ParametrosVisuales,
    ISNULL(iem.RutasIconosEmpresa,0) RutasIconosEmpresa,
    ISNULL(iem.RutasLogoEmpresa,0) RutasLogoEmpresa,
    ISNULL(iem.ConfiguracionesImagenMenu,0) ConfiguracionesImagenMenu,
    ISNULL(img.ImagenesEmpresaConContenido,0) ImagenesEmpresaConContenido,
    CASE WHEN DATALENGTH(e.EMImagenIzq)>0 THEN 1 ELSE 0 END ImagenIzquierdaConContenido,
    ISNULL(ini.ElementosInicioB3,0) ElementosInicioB3,
    ISNULL(ini.ImagenesInicioB3,0) ImagenesInicioB3
INTO #BaseVisual
FROM dbo.ff_Empresa e
OUTER APPLY (
    SELECT
        COUNT(DISTINCT r.ROIdRol) RolesAdministradorValidos,
        COUNT(DISTINCT mr.MRidMenu) MenusAdministrador,
        COUNT(DISTINCT CASE
            WHEN NULLIF(LTRIM(RTRIM(mr.MRImagenMenu)),'') IS NOT NULL THEN mr.MRidMenu END
        ) IconosMenuAdministrador,
        COUNT(DISTINCT CASE
            WHEN NULLIF(LTRIM(RTRIM(mr.MRRutaBanner)),'') IS NOT NULL THEN mr.MRidMenu END
        ) BannersAdministrador
    FROM dbo.ff_Perfil p
    INNER JOIN dbo.ff_Rol r
      ON r.ROIdRol=p.PEIdRolDefault
     AND r.ROIdEmpresa=p.PEIdEmpresa
     AND r.ROIdEstatus=1
    LEFT JOIN dbo.ff_MenuRol2 mr
      ON mr.MRidRol=r.ROIdRol
     AND mr.MRidEstatus=1
    WHERE p.PEIdEmpresa=e.EMidEmpresa
      AND p.PEAdministrador=1
      AND p.PEIdEstatus=1
) admin
OUTER APPLY (
    SELECT
        COUNT(DISTINCT r.ROIdRol) RolesConMenus,
        COUNT(DISTINCT mr.MRidMenu) MenusRolesActivos,
        COUNT(DISTINCT CASE
            WHEN NULLIF(LTRIM(RTRIM(mr.MRImagenMenu)),'') IS NOT NULL THEN mr.MRidMenu END
        ) IconosRolesActivos,
        COUNT(DISTINCT CASE
            WHEN NULLIF(LTRIM(RTRIM(mr.MRRutaBanner)),'') IS NOT NULL THEN mr.MRidMenu END
        ) BannersRolesActivos
    FROM dbo.ff_Rol r
    INNER JOIN dbo.ff_MenuRol2 mr
      ON mr.MRidRol=r.ROIdRol AND mr.MRidEstatus=1
    WHERE r.ROIdEmpresa=e.EMidEmpresa
      AND r.ROIdEstatus=1
) menus
OUTER APPLY (
    SELECT COUNT(DISTINCT s.EEidCatalogoEstilo) EstilosB3
    FROM dbo.bf_EstiloEmpresa s
    WHERE s.EEIdEmpresa=e.EMidEmpresa
      AND s.EEIdEstatus=1
      AND NULLIF(LTRIM(RTRIM(s.EEValor)),'') IS NOT NULL
) est
OUTER APPLY (
    SELECT COUNT(*) EstilosDuplicados
    FROM (
        SELECT s.EEidCatalogoEstilo
        FROM dbo.bf_EstiloEmpresa s
        WHERE s.EEIdEmpresa=e.EMidEmpresa AND s.EEIdEstatus=1
        GROUP BY s.EEidCatalogoEstilo HAVING COUNT(*)>1
    ) d
) estdup
OUTER APPLY (
    SELECT COUNT(*) ParametrosVisuales
    FROM dbo.ff_Parametro p
    WHERE p.paIdEmpresa=e.EMidEmpresa
      AND p.paidEstatus=1
      AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
      AND (
           UPPER(ISNULL(p.paClase,'')) LIKE '%COLOR%'
        OR UPPER(ISNULL(p.paClase,'')) LIKE '%ESTILO%'
        OR UPPER(ISNULL(p.paClase,'')) LIKE '%CSS%'
      )
) par
OUTER APPLY (
    SELECT
        COUNT(*) ConfiguracionesImagenMenu,
        SUM(
            CASE WHEN NULLIF(LTRIM(RTRIM(m.IEMImagenHijo)),'') IS NOT NULL THEN 1 ELSE 0 END
          + CASE WHEN NULLIF(LTRIM(RTRIM(m.IEMImagenDer)),'') IS NOT NULL THEN 1 ELSE 0 END
          + CASE WHEN NULLIF(LTRIM(RTRIM(m.IEMImagenIzq)),'') IS NOT NULL THEN 1 ELSE 0 END
        ) RutasIconosEmpresa,
        SUM(CASE WHEN NULLIF(LTRIM(RTRIM(m.IEMImagenLogo)),'') IS NOT NULL THEN 1 ELSE 0 END) RutasLogoEmpresa
    FROM dbo.ff_ImagenEmpresaMenu m
    WHERE m.IEMIdEmpresa=e.EMidEmpresa AND m.IEMEstatus=1
) iem
OUTER APPLY (
    SELECT COUNT(*) ImagenesEmpresaConContenido
    FROM dbo.ff_EmpresaImagen i
    WHERE i.EIIdEmpresa=e.EMidEmpresa
      AND (DATALENGTH(i.EIImagen1)>0 OR DATALENGTH(i.EIImagen2)>0)
) img
OUTER APPLY (
    SELECT
        COUNT(*) ElementosInicioB3,
        SUM(CASE WHEN NULLIF(LTRIM(RTRIM(b.BI_RutaImagen)),'') IS NOT NULL THEN 1 ELSE 0 END) ImagenesInicioB3
    FROM dbo.bf_BeflexInicio2 b
    WHERE b.BI_IdCorporativo=e.EMidCorporativo
      AND b.BI_Valor=e.EMidEmpresa
      AND b.BI_IdEstatus=1
) ini
WHERE e.EMIdEstatus=1;

SELECT b.*,
       CAST(
           CASE WHEN b.EsMVP=1 THEN 3 ELSE 0 END
         + CASE WHEN b.AccesoBF3=1 THEN 3 ELSE 0 END
         + CASE WHEN b.RolesAdministradorValidos>0 THEN 4 ELSE 0 END
         + CASE WHEN b.MenusAdministrador>0 THEN 5 ELSE 0 END
         + CASE WHEN b.IconosMenuAdministrador>0 THEN 5 ELSE 0 END
         + CASE WHEN b.IconosRolesActivos>0 THEN 25 ELSE 0 END
         + CASE WHEN b.RutasIconosEmpresa>0 THEN 15 ELSE 0 END
         + CASE WHEN b.EstilosB3>0 THEN 25 ELSE 0 END
         + CASE WHEN b.ParametrosVisuales>0 THEN 10 ELSE 0 END
         + CASE WHEN b.ImagenesInicioB3>0 THEN 5 ELSE 0 END
       AS INT) PuntuacionVisual,
       CASE
           WHEN b.IdEmpresa=@IdEmpresaModeloFuncional
                AND b.EstilosB3=0 AND b.ParametrosVisuales=0
               THEN 'NO APTO: MODELO FUNCIONAL SIN ESTILOS'
           WHEN b.EstilosDuplicados>0 THEN 'NO APTO: ESTILOS ACTIVOS DUPLICADOS'
           WHEN b.ConfiguracionesImagenMenu>1 THEN 'NO APTO: IMAGENES DE MENU DUPLICADAS'
           WHEN b.EstilosB3=0 AND b.ParametrosVisuales=0 THEN 'NO APTO: SIN ESTILOS/COLORES'
           WHEN b.IconosRolesActivos=0 AND b.RutasIconosEmpresa=0 THEN 'NO APTO: SIN ICONOS EN ROLES ACTIVOS'
           ELSE 'CANDIDATO TECNICO: REVISAR URL, ARCHIVOS Y MARCA'
       END Dictamen
       ,CASE
           WHEN b.EstilosDuplicados>0 THEN 'NO APTO: ESTILOS ACTIVOS DUPLICADOS'
           WHEN b.EstilosB3=0 AND b.ParametrosVisuales=0 THEN 'NO APTO: SIN ESTILOS/COLORES'
           ELSE 'CANDIDATO DE ESTILOS: VALIDAR CSS'
       END DictamenEstilos
       ,CASE
           WHEN b.ConfiguracionesImagenMenu>1 THEN 'NO APTO: IMAGENES DE MENU DUPLICADAS'
           WHEN b.IconosRolesActivos=0 AND b.RutasIconosEmpresa=0 THEN 'NO APTO: SIN ICONOS EN ROLES ACTIVOS'
           ELSE 'CANDIDATO DE ICONOS: VALIDAR PNG'
       END DictamenIconos
INTO #EvaluacionVisual
FROM #BaseVisual b;

/* Resultado 01: todas las empresas activas, ordenadas por evidencia visual. */
SELECT '01_RANKING_MODELOS_VISUALES' Bloque,*
FROM #EvaluacionVisual
ORDER BY
    CASE WHEN Dictamen LIKE 'CANDIDATO TECNICO%' THEN 0 ELSE 1 END,
    PuntuacionVisual DESC,EstilosB3 DESC,IconosRolesActivos DESC,IdEmpresa;

/* Las fuentes de estilos e iconos son independientes. Esto permite usar, por
   ejemplo, los 47 iconos de la empresa 186 aunque esa empresa no tenga estilos. */
IF @IdEmpresaPreferidaEstilos IS NOT NULL
BEGIN
    SELECT @IdEmpresaModeloVisual=IdEmpresa
    FROM #EvaluacionVisual
    WHERE IdEmpresa=@IdEmpresaPreferidaEstilos
      AND DictamenEstilos LIKE 'CANDIDATO DE ESTILOS%';
END
ELSE
BEGIN
    SELECT TOP (1) @IdEmpresaModeloVisual=IdEmpresa
    FROM #EvaluacionVisual
    WHERE DictamenEstilos LIKE 'CANDIDATO DE ESTILOS%'
      AND IdEmpresa<>@IdEmpresaModeloFuncional
    ORDER BY EsMVP DESC,AccesoBF3 DESC,EsEmpresaHija DESC,PuntuacionVisual DESC,
             EstilosB3 DESC,ParametrosVisuales DESC,IdEmpresa;
END;

IF @IdEmpresaPreferidaIconos IS NOT NULL
BEGIN
    SELECT @IdEmpresaModeloIconos=IdEmpresa
    FROM #EvaluacionVisual
    WHERE IdEmpresa=@IdEmpresaPreferidaIconos
      AND DictamenIconos LIKE 'CANDIDATO DE ICONOS%';
END
ELSE
BEGIN
    SELECT TOP (1) @IdEmpresaModeloIconos=IdEmpresa
    FROM #EvaluacionVisual
    WHERE DictamenIconos LIKE 'CANDIDATO DE ICONOS%'
    ORDER BY CASE WHEN IdEmpresa=@IdEmpresaModeloVisual THEN 0 ELSE 1 END,
             EsMVP DESC,AccesoBF3 DESC,RolesAdministradorValidos DESC,
             IconosRolesActivos DESC,RutasIconosEmpresa DESC,IdEmpresa;
END;

SELECT '02_MODELO_VISUAL_PROPUESTO' Bloque,
       @IdEmpresaModeloVisual IdEmpresaModeloVisual,
       @IdEmpresaPreferidaEstilos IdEmpresaPreferidaEstilos,
       est.IdCorporativo,est.Empresa,est.RazonSocial,est.EsMVP,est.AccesoBF3,
       est.EstilosB3,est.ParametrosVisuales,est.DictamenEstilos,
       CASE
           WHEN @IdEmpresaPreferidaEstilos IS NOT NULL AND @IdEmpresaModeloVisual IS NULL
             THEN 'LA FUENTE DE ESTILOS PREFERIDA NO CUMPLE. Revisar bloque 01.'
           WHEN @IdEmpresaModeloVisual IS NULL
             THEN 'NO HAY FUENTE DE ESTILOS. No ejecutar homologacion visual.'
           ELSE 'VALIDAR por HTTP que el CSS exista y sea reutilizable.'
       END SiguientePasoEstilos,
       CASE WHEN @IdEmpresaModeloVisual IS NULL THEN NULL ELSE
         @UrlBaseRecursos+'Stilos/General/'+CONVERT(VARCHAR(12),@IdEmpresaModeloVisual)
         +'/Cla'+CONVERT(VARCHAR(12),@IdEmpresaModeloVisual)+'.css' END UrlCssEsperada,
       @IdEmpresaModeloIconos IdEmpresaModeloIconos,
       @IdEmpresaPreferidaIconos IdEmpresaPreferidaIconos,
       ico.IdCorporativo IdCorporativoIconos,ico.Empresa EmpresaIconos,
       ico.EsMVP EsMVPIconos,ico.AccesoBF3 AccesoBF3Iconos,
       ico.RolesAdministradorValidos,ico.IconosRolesActivos,ico.RutasIconosEmpresa,
       ico.DictamenIconos,
       CASE
           WHEN @IdEmpresaPreferidaIconos IS NOT NULL AND @IdEmpresaModeloIconos IS NULL
             THEN 'LA FUENTE DE ICONOS PREFERIDA NO CUMPLE. Revisar bloque 01.'
      WHEN @IdEmpresaModeloIconos IS NULL
      THEN 'NO HAY FUENTE DE ICONOS. No ejecutar homologacion visual.'
      ELSE 'VALIDAR por HTTP los PNG. La ejecucion guardara ../{fuente}/archivo para reutilizarlos sin duplicar carpetas.'
    END SiguientePasoIconos
FROM (SELECT 1 n) x
LEFT JOIN #EvaluacionVisual est ON est.IdEmpresa=@IdEmpresaModeloVisual
LEFT JOIN #EvaluacionVisual ico ON ico.IdEmpresa=@IdEmpresaModeloIconos;

/* Resultado 03: detalle de estilos del candidato propuesto. */
SELECT '03_ESTILOS_PROPUESTOS' Bloque,s.EEidCatalogoEstilo,c.CENombre,c.CEDescripcion,
       s.EEValor,s.EEIdEstatus
FROM dbo.bf_EstiloEmpresa s
LEFT JOIN dbo.bf_CatalogoEstilos c ON c.CEIdCatalogoEstilos=s.EEidCatalogoEstilo
WHERE s.EEIdEmpresa=@IdEmpresaModeloVisual AND s.EEIdEstatus=1
ORDER BY s.EEidCatalogoEstilo;

/* Resultado 04: una ruta canonica por menu, aun sin perfil administrador. */
;WITH IconosCandidatos AS (
    SELECT r.ROIdRol,r.RODescripcionCorta,mr.MRidMenu,mr.MRImagenMenu,mr.MRRutaBanner,
           CASE WHEN EXISTS (
               SELECT 1 FROM dbo.ff_Perfil p
               WHERE p.PEIdEmpresa=r.ROIdEmpresa
                 AND p.PEIdRolDefault=r.ROIdRol
                 AND p.PEAdministrador=1
                 AND p.PEIdEstatus=1
           ) THEN 1 ELSE 0 END EsRolAdministrador,
           ROW_NUMBER() OVER (
               PARTITION BY mr.MRidMenu
               ORDER BY
                 CASE WHEN EXISTS (
                     SELECT 1 FROM dbo.ff_Perfil p
                     WHERE p.PEIdEmpresa=r.ROIdEmpresa
                       AND p.PEIdRolDefault=r.ROIdRol
                       AND p.PEAdministrador=1
                       AND p.PEIdEstatus=1
                 ) THEN 0 ELSE 1 END,
                 CASE WHEN NULLIF(LTRIM(RTRIM(mr.MRImagenMenu)),'') IS NOT NULL THEN 0 ELSE 1 END,
                 CASE WHEN NULLIF(LTRIM(RTRIM(mr.MRRutaBanner)),'') IS NOT NULL THEN 0 ELSE 1 END,
                 r.ROIdRol
           ) OrdenVisual
    FROM dbo.ff_Rol r
    INNER JOIN dbo.ff_MenuRol2 mr
      ON mr.MRidRol=r.ROIdRol AND mr.MRidEstatus=1
    WHERE r.ROIdEmpresa=@IdEmpresaModeloIconos
      AND r.ROIdEstatus=1
      AND (NULLIF(LTRIM(RTRIM(mr.MRImagenMenu)),'') IS NOT NULL
           OR NULLIF(LTRIM(RTRIM(mr.MRRutaBanner)),'') IS NOT NULL)
)
SELECT '04_ICONOS_MENU_PROPUESTOS' Bloque,ROIdRol,RODescripcionCorta,
       EsRolAdministrador,MRidMenu,MRImagenMenu,MRRutaBanner,
       CASE WHEN NULLIF(LTRIM(RTRIM(MRImagenMenu)),'') IS NULL THEN NULL ELSE
         @UrlBaseRecursos+'Stilos/Menus/'+CONVERT(VARCHAR(12),@IdEmpresaModeloIconos)
         +'/'+LTRIM(RTRIM(MRImagenMenu)) END UrlIconoEsperada,
       CASE WHEN NULLIF(LTRIM(RTRIM(MRRutaBanner)),'') IS NULL THEN NULL ELSE
         @UrlBaseRecursos+'Stilos/banner/'+CONVERT(VARCHAR(12),@IdEmpresaModeloIconos)
         +'/'+LTRIM(RTRIM(MRRutaBanner)) END UrlBannerEsperada
FROM IconosCandidatos
WHERE OrdenVisual=1
ORDER BY MRidMenu;

/* Resultado 05: rutas de imagen generales; IEMImagenLogo requiere aprobacion expresa. */
SELECT '05_RUTAS_IMAGEN_PROPUESTAS' Bloque,IEMImagenHijo,IEMImagenDer,IEMImagenIzq,
       IEMImagenLogo,IEMEstatus
FROM dbo.ff_ImagenEmpresaMenu
WHERE IEMIdEmpresa=@IdEmpresaModeloIconos AND IEMEstatus=1;

/* Resultado 06: parametros visuales que se copiarian. */
SELECT '06_PARAMETROS_VISUALES_PROPUESTOS' Bloque,paId,paClase,
       LEFT(LTRIM(RTRIM(paValor)),250) Valor,paDescripcion
FROM dbo.ff_Parametro
WHERE paIdEmpresa=@IdEmpresaModeloVisual AND paidEstatus=1
  AND (
       UPPER(ISNULL(paClase,'')) LIKE '%COLOR%'
    OR UPPER(ISNULL(paClase,'')) LIKE '%ESTILO%'
    OR UPPER(ISNULL(paClase,'')) LIKE '%CSS%'
  )
ORDER BY paId;

DROP TABLE #EvaluacionVisual;
DROP TABLE #BaseVisual;
GO
