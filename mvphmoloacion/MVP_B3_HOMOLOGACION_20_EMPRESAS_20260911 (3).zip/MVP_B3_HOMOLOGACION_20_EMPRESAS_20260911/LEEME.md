# Homologación MVP de B3 — lista recibida el 11/09/2026

Este paquete aplica a empresas existentes la misma cascada SQL utilizada cuando el alta de BF3 recibe la bandera `@EM_MVP = 1`.

## Conclusión técnica

- `ff_AddEmpresa` ejecuta `bf_ProcesoMVP @EMidEmpresa, @EMUsuarioAdd` cuando la empresa se crea como MVP y después registra la empresa en `bf_EmpresaMVP`.
- `bf_ProcesoMVP` trabaja sobre una empresa ya existente. Por eso es el procedimiento adecuado para homologar los destinos de la lista.
- `sp_CrearEmpresaMVP` no se ejecuta: su propósito es crear una empresa nueva y duplicaría el registro.
- El flujo legacy B2 revisado no enviaba `@EM_MVP`; la cascada entregada y el diagnóstico recibido corresponden a la incorporación MVP/B3.
- El paquete anterior copiaba sólo ocho componentes. Este paquete cambia el alcance y llama la cascada completa confirmada por el diagnóstico recibido.

## Modelo y universo

- Empresa modelo B3: `2494`.
- Corporativo modelo B3: `2493`.
- Fuente de estilos: se obtiene con `06_SELECCIONAR_MODELO_VISUAL_MVP.sql` y se captura en `@IdEmpresaModeloVisual`.
- Fuente de iconos: se captura en `@IdEmpresaModeloIconos`; puede ser distinta de la fuente de estilos, no necesita ser MVP ni tener perfil administrador. Con `NULL` reutiliza `@IdEmpresaModeloVisual`.
- Lista recibida: 20 identificadores de corporativo.
- Piloto: corporativo `495` (HAPAG), empresa hija `496`.

La hoja contiene `idCorp`, no el identificador de cada empresa hija. Los scripts resuelven las empresas activas mediante `ff_Empresa.EMidCorporativo`. En la copia local se encontraron 23 empresas hijas activas para los 20 corporativos; UNICCO, SCHNEIDER y SGWIC tienen dos hijas. La cantidad real debe confirmarse en el ambiente donde se ejecutará.

Los identificadores de modelo `2494/2493` se tomaron del archivo recibido `VALIDA_01_diagnostico_insercion_PROD (1).sql`. Ese mismo diagnóstico advierte que pueden no existir o estar incompletos en PROD. Por eso el script `00` y los ejecutables detienen el proceso si el modelo no tiene la configuración mínima. Si la empresa base autorizada en PROD utiliza otros identificadores, deben cambiarse las dos variables de modelo en todos los scripts antes de ejecutar.

## Qué agrega o actualiza la cascada completa

Además de menús, roles, imágenes, colores, documentos, perfiles, planes y parámetros, incorpora acceso BeFlex, inicio B3, configuración de empresa, plantillas MVP, reporte Interfábrica, menús V2, operaciones de carga masiva y el parámetro de mismo sexo.

Los ejecutables `01` y `03` agregan una autorreparación posterior a `bf_ProcesoMVP`. Esto cubre los casos donde los procedimientos históricos sólo insertan cuando no existe un registro y, por lo tanto, dejan intacta una configuración previa incorrecta. Antes de declarar éxito, ambos scripts:

- corrigen en `ff_AdministradorEmpresa` tanto el perfil como el rol administrador, y comprueban que exista al menos una asociación activa y que ambas referencias existan y estén activas en la empresa destino;
- comprueban que el rol administrador tenga menús V2 activos;
- dejan una sola configuración activa para cada operación `1, 2, 3, 13 y 14`;
- actualizan o insertan las operaciones con el contrato B3 esperado; para `1`, `2` y `3` exigen las plantillas/SP `12061/ff_XCMDependientesAltaCMM`, `12062/ff_XCMTitularesAltaCMM_BF3` y `154/ff_XCMAseguradosBaja_Base`;
- reparan el aviso de privacidad `226` del corporativo y de la empresa hija usando únicamente el texto activo del modelo `2493/2494`;
- aplican estilos y parámetros `COLOR/ESTILO/CSS` desde `@IdEmpresaModeloVisual`, e iconos desde `@IdEmpresaModeloIconos`, relacionándolos por `MRidMenu`; si la fuente de iconos no tiene administrador, toman y deduplican las rutas de todos sus roles activos;
- cuando los iconos vienen de otra empresa, guardan rutas relativas `../{idFuente}/archivo.png`; así BF3 consume los PNG publicados de la fuente y no exige duplicar físicamente la carpeta para cada destino;
- validan antes de modificar datos que las rutas relativas de iconos y banners quepan en las columnas de 100 bytes;
- preservan por defecto las imágenes binarias, el logotipo y el indicador visual propios del destino; `@CopiarBrandingModeloVisual` permanece en `0` salvo autorización expresa;
- registran la acción `AUTORREPARAR_MVP_B3` en `bf_BitacoraEmpresa` y sólo después insertan o reactivan la marca `bf_EmpresaMVP`.

Si no hay una fuente válida para el aviso `226`, un perfil administrador con rol vigente, menús V2, un contrato de carga inequívoco o un modelo visual con estilos e iconos reales, la ejecución se detiene y reporta la causa. No inventa datos de configuración.

Algunos procedimientos reemplazan datos del destino, como imágenes, colores, documentos, parámetros y plantillas. Por ello los ejecutables vienen desactivados y deben usarse con respaldo de la base.

La cascada no debe envolverse en otra transacción ni ejecutarse con `XACT_ABORT ON`. Cada `sp_Copiar*` controla su propia transacción y varios escriben bitácora después de su `COMMIT`. Una transacción exterior puede quedar en `XACT_STATE=-1` y producir el error `3930`, ocultando el mensaje original. Los ejecutables corregidos usan `XACT_ABORT OFF` y reproducen la llamada de `ff_AddEmpresa`.

## Orden de ejecución

1. Ejecutar `00_DIAGNOSTICO_PREVIO_BF3.sql` y conservar sus resultados.
2. Ejecutar `06_SELECCIONAR_MODELO_VISUAL_MVP.sql`. El resultado revisa todas las empresas activas, sean MVP o no, y propone por separado una fuente de estilos y otra de iconos. `@IdEmpresaPreferidaEstilos` y `@IdEmpresaPreferidaIconos` permiten evaluar fuentes concretas; con `NULL` se elige automáticamente la opción mejor puntuada. Las URL, los archivos físicos y el branding deben aprobarse antes de copiarse.
3. Revisar que los modelos, los 19 objetos y la empresa piloto aparezcan como `OK`.
4. En `01_EJECUTAR_PILOTO_CORP_495.sql`, capturar `@IdUsuario`, `@IdEmpresaModeloVisual` y `@IdEmpresaModeloIconos` con los candidatos aprobados; mantener `@CopiarBrandingModeloVisual = 0`.
5. Ejecutarlo primero con `@Aplicar = 0`.
6. Con respaldo confirmado, cambiar únicamente `@Aplicar = 1` y volverlo a ejecutar.
7. Ejecutar `02_VALIDAR_PILOTO_CORP_495.sql` y realizar pruebas funcionales en BF3.
8. Sólo después de aprobar el piloto, preparar `03_EJECUTAR_MASIVO_20_CORPORATIVOS.sql`.
9. En el masivo, capturar los mismos `@IdEmpresaModeloVisual` y `@IdEmpresaModeloIconos` aprobados por el piloto, mantener el branding en `0`, descomentar el `UPDATE` indicado, capturar el usuario, establecer la confirmación exacta y finalmente cambiar `@AplicarMasivo = 1`.
10. Ejecutar `04_VALIDAR_20_CORPORATIVOS.sql`.

## Salvaguardas

- Los modelos se envían explícitamente; no se depende de defaults ocultos.
- El modelo funcional y el visual son independientes. El visual nunca aporta roles, perfiles, planes, plantillas ni operaciones de carga.
- Antes de la cascada se congelan la fuente visual y un respaldo visual de cada destino. Si la superposición visual falla, se intenta restaurar automáticamente la apariencia previa.
- La marca MVP, el acceso BF3 y el perfil administrador de la fuente visual son únicamente señales preferentes. Se rechazan fuentes sin estilos/colores, sin rutas de iconos en roles activos o con configuraciones visuales activas duplicadas.
- La base sólo contiene configuración y nombres de archivo. Antes de usar una fuente se debe comprobar por HTTP que existan `Stilos/General/{id}/Cla{id}.css`, `Stilos/Menus/{id}/*.png` y, cuando aplique, `Stilos/banner/{id}/*`. Los iconos y banners pueden compartirse mediante las rutas relativas que generan los scripts; el CSS continúa necesitando publicación, copia o alias bajo el ID destino porque BF3 construye esa URL directamente.
- El piloto sólo acepta la empresa `496` dentro del corporativo `495`.
- Cada procedimiento de la cascada conserva su propia transacción, igual que en el flujo B3. Si una etapa posterior falla, las etapas anteriores pueden haber quedado aplicadas; después de corregir la causa se puede volver a ejecutar porque los procedimientos están diseñados como idempotentes.
- La marca `bf_EmpresaMVP` se inserta sólo si falta o se reactiva si estaba inactiva.
- La marca MVP se realiza después de que la autorreparación y sus comprobaciones concluyen correctamente.
- En el masivo, la autorreparación se confirma por empresa. Si falla, revierte sus correcciones de esa empresa, la reporta como `ERROR` y continúa con los demás destinos; al final el script lanza un error si hubo al menos un fallo.
- El masivo requiere cuatro acciones expresas: habilitar destinos, capturar usuario, escribir la frase de confirmación y activar `@AplicarMasivo`.
- Ningún script crea o elimina empresas, empleados, solicitudes o vigencias.

## Resultado de la verificación local

Los cinco scripts involucrados (`01`, `02`, `03`, `04` y `06`) se validaron con `PARSEONLY` y se compilaron con `NOEXEC` contra `FlexiForbesv2`. No presentaron errores de sintaxis ni de resolución de columnas/objetos en esa copia. El selector `06` también se ejecutó en modo sólo lectura; la copia local no contiene un candidato visual completo y devolvió correctamente `NO HAY CANDIDATO`.

La copia local confirma la relación piloto `495 -> 496`, pero el modelo local `2494/2493` está incompleto: no existe el rol modelo V2 `7365`. La prueba controlada del piloto se detuvo exactamente en esa precondición, antes de modificar datos. Por ello se comprobó compilación y comportamiento de bloqueo, pero la ejecución funcional de la autorreparación debe validarse en el ambiente que sí contiene el modelo completo. Esto no determina el estado de PROD: ahí debe conservarse la salida del script `00` antes de habilitar el piloto.

## Referencias incluidas

La carpeta `REFERENCIAS_NO_EJECUTAR` conserva la hoja y los dos SQL entregados. Son evidencia de origen y no forman parte del orden de ejecución del paquete.
