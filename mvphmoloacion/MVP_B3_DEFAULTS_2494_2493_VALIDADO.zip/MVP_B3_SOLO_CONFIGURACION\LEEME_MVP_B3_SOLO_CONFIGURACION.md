# Homologación MVP B2 → B3: sólo configuración MVP comprobada

Este paquete corrige el alcance anterior. Replica únicamente los ocho componentes expuestos por `LogicaEmpresaMVP.replicarElementos` y `JDBCEmpresaMVP`: menús, roles, imágenes, colores, documentos, perfiles, planes y parámetros.

Se excluyen carga masiva, los parámetros especiales 128 y 232, plantillas MVP, Interfábrica, acceso BeFlex, configuración de inicio, menús complementarios y cualquier reparación adicional de administradores.

Los scripts ya incluyen los defaults de B3 observados en `bf_ProcesoMVP`: empresa modelo `2494` (**DRÄGER MEDICAL MEXICO, S.A. DE C.V.**) y corporativo modelo `2493` (**DRAGER**). No es necesario capturarlos manualmente. Las empresas existentes mantienen su `EMidEmpresa`; `sp_CrearEmpresaMVP` no se ejecuta.

## Aclaración después de revisar Wizard-QA

`Wizard-QA` sí corresponde a la administración de B3, aunque esté desarrollado en .NET. Hay referencias directas a `Empresa acceso b3`, a la clase `Empresab3`, a recursos `block3` y al consumo de estilos por BeFlex3.

En el alta del Wizard el usuario no captura una empresa modelo. Selecciona una configuración y la bandera **Es Empresa MVP**. Cuando la bandera vale `1`, `ff_AddEmpresa` llama a `bf_ProcesoMVP` con la nueva empresa y el usuario. La importación de Entity Framework también expone solamente esos dos argumentos.

Esto es posible porque el procedimiento de base de datos tiene modelos predeterminados internos. En la LocalDB revisada aparecen `ModeloOrigen = 2494` y `ModeloCorp = 2493`. Además, `GenericMVP` funciona como plantilla predeterminada de archivos CSS, logos, menús y login.

La opción **Configuración default** del Wizard corresponde a `IdConfiguracion`; no equivale a una empresa modelo MVP.

El paquete utiliza esos defaults automáticamente, pero antes valida que ambos registros existan, estén activos, que la empresa `2494` pertenezca al corporativo `2493` y que tenga roles, perfiles, menús V2 y parámetros activos. Si alguna comprobación falla, se detiene sin aplicar cambios. Si otro ambiente usa IDs distintos, deben ajustarse las dos declaraciones al inicio de los scripts.

## Enfoque de comparación

La prevalidación no presupone que todas las empresas tengan las mismas carencias. Para cada empresa muestra qué configuración del modelo B3 falta y qué registros actuales serían reemplazados.

- Roles, menús y documentos de plan: agregan faltantes sin eliminar existentes.
- Perfiles: agregan faltantes y actualizan atributos cuando coincide `PENombre`, conservando `PEIdPerfil`.
- Imágenes: reemplazan las imágenes actuales por las del modelo.
- Colores/estilos: reemplazan parámetros `COLOR`, `ESTILO` y `CSS`.
- Documentos: reemplazan solamente nombres coincidentes.
- Parámetros: reemplazan los `paId` presentes en el modelo y conservan los demás.

No cambian el identificador de empresa, empleados, solicitudes, historial ni configuración de carga masiva.

### Aviso de privacidad

El parámetro `226` sí se valida porque el login B3 utiliza `paValor` como leyenda del aviso. Se aplica esta prioridad:

1. Conservar el `226` activo y no vacío de la empresa B2.
2. Si falta, reutilizar el `226` de su corporativo B2.
3. Si también falta en el corporativo, tomarlo del corporativo o empresa modelo B3.

Un valor B2 válido nunca se sobrescribe. Únicamente se sustituye un registro vacío/inactivo o se inserta uno inexistente.

## Orden

1. `00_ALCANCE_MVP_B3_COMPROBADO.sql`
2. `01_PREVALIDACION_SOLO_CONFIG_MVP_B3.sql`
3. `02_HOMOLOGACION_SOLO_CONFIG_MVP_B3.sql` con `@Aplicar = 0`.
4. Probar una empresa indicando `@IdEmpresaDestino`.
5. Revisar el resultado con `03_VALIDACION_SOLO_CONFIG_MVP_B3.sql`.
6. Sólo después habilitar `@ProcesarTodas = 1` en QA.

## Seguridad

Imágenes, colores, documentos, perfiles y parámetros pueden reemplazar valores existentes. El script exige `@PermitirReemplazos = 1` antes de aplicarlos. Debe existir un respaldo verificable de la base antes de ejecutar la homologación.

La validación es de sólo lectura y no contiene ninguna revisión de carga masiva.

## Lista de aprobación antes de aplicar

En la salida de `01_PREVALIDACION_SOLO_CONFIG_MVP_B3.sql` debe confirmarse:

- Los ocho procedimientos aparecen con objeto y firma `OK`.
- `ResultadoModeloDefault` aparece como `OK`; si muestra `INCOMPLETO_NO_APLICAR`, no debe ejecutarse el script 02.
- La empresa modelo B3 contiene la configuración que realmente se desea replicar.
- `CorporativoValido` aparece como `OK` para todos los destinos.
- Ninguna empresa muestra `FuenteAviso226 = SIN_FUENTE_REVISAR`.
- Se revisaron los conteos de imágenes, colores, documentos, perfiles y parámetros que serían reemplazados.
- Existe un respaldo recuperable de la base.

Después debe ejecutarse una empresa piloto con `@ProcesarTodas = 0`. El procesamiento de las 286 sólo se habilita después de validar el piloto con el script 03.
