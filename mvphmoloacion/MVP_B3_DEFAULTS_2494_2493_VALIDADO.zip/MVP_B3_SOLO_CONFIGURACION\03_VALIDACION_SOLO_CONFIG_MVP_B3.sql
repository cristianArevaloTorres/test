/* VALIDACION POSTERIOR. SOLO LECTURA. NO REVISA CARGA MASIVA. */

SET NOCOUNT ON;

/* Mismos defaults de bf_ProcesoMVP B3 usados por el script 02. */
DECLARE @IdEmpresaModeloB3 INT = 2494;       -- DRAGER MEDICAL MEXICO
DECLARE @IdCorporativoModeloB3 INT = 2493;  -- DRAGER
DECLARE @ProcesarTodas BIT = 0;
DECLARE @IdEmpresaDestino INT = NULL;  -- EMPRESA PILOTO; NULL solo si @ProcesarTodas=1
DECLARE @CantidadEsperada INT = 286;

IF @ProcesarTodas=0 AND @IdEmpresaDestino IS NULL
    THROW 51000, 'Indique @IdEmpresaDestino o habilite @ProcesarTodas=1.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMidEmpresa=@IdEmpresaModeloB3 AND EMidEstatus=1)
    THROW 51000, 'La empresa modelo B3 no existe o esta inactiva.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMidEmpresa=@IdCorporativoModeloB3 AND EMidEstatus=1
)
    THROW 51000, 'El corporativo modelo B3 default no existe o esta inactivo.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMidEmpresa=@IdEmpresaModeloB3
      AND EMidCorporativo=@IdCorporativoModeloB3
)
    THROW 51000, 'La empresa modelo B3 no pertenece al corporativo modelo default.', 1;

DROP TABLE IF EXISTS #Empresas;

SELECT DISTINCT m.IdEmpresa,e.EMNombre,e.EMidCorporativo
INTO #Empresas
FROM dbo.bf_EmpresaMVP m
JOIN dbo.ff_Empresa e ON e.EMidEmpresa=m.IdEmpresa
WHERE m.IdEstatus=1
  AND e.EMidEstatus=1
  AND m.IdEmpresa<>@IdEmpresaModeloB3
  AND (@ProcesarTodas=1 OR m.IdEmpresa=@IdEmpresaDestino);

IF NOT EXISTS (SELECT 1 FROM #Empresas)
    THROW 51000, 'No se encontraron empresas destino.', 1;

SELECT
    EmpresasValidadas=COUNT(*),
    CantidadEsperada=CASE WHEN @ProcesarTodas=1 THEN @CantidadEsperada ELSE 1 END,
    ResultadoCantidad=CASE
      WHEN @ProcesarTodas=0 AND COUNT(*)=1 THEN 'OK'
      WHEN @ProcesarTodas=1 AND COUNT(*)=@CantidadEsperada THEN 'OK'
      ELSE 'REVISAR' END
FROM #Empresas;

DROP TABLE IF EXISTS #Resultado;

SELECT
    e.IdEmpresa,
    e.EMNombre,

    RolesFaltantes=
    (
      SELECT COUNT(*) FROM dbo.ff_Rol o
      WHERE o.ROIdEmpresa=@IdEmpresaModeloB3 AND o.ROIdEstatus=1
        AND NOT EXISTS
        (
          SELECT 1 FROM dbo.ff_Rol d
          WHERE d.ROIdEmpresa=e.IdEmpresa AND d.ROIdEstatus=1
            AND d.RODescripcionCorta=o.RODescripcionCorta
            AND d.RODescripcionLarga=o.RODescripcionLarga
            AND ISNULL(d.RODefault,0)=ISNULL(o.RODefault,0)
            AND ISNULL(d.ROAdministrador,0)=ISNULL(o.ROAdministrador,0)
        )
    ),

    PerfilesFaltantesODiferentes=
    (
      SELECT COUNT(*) FROM dbo.ff_Perfil o
      WHERE o.PEIdEmpresa=@IdEmpresaModeloB3 AND o.PEIdEstatus=1
        AND NOT EXISTS
        (
          SELECT 1 FROM dbo.ff_Perfil d
          WHERE d.PEIdEmpresa=e.IdEmpresa
            AND d.PENombre=o.PENombre
            AND ISNULL(d.PEDescripcion,'')=ISNULL(o.PEDescripcion,'')
            AND ISNULL(d.PEidPeriodicidadNomina,0)=ISNULL(o.PEidPeriodicidadNomina,0)
            AND ISNULL(d.PEMuestraSueldo,0)=ISNULL(o.PEMuestraSueldo,0)
            AND ISNULL(d.PEAdministrador,0)=ISNULL(o.PEAdministrador,0)
            AND ISNULL(d.PECarpetaDefault,0)=ISNULL(o.PECarpetaDefault,0)
            AND d.PEIdEstatus=o.PEIdEstatus
        )
    ),

    MenusV1Faltantes=
    (
      SELECT COUNT(*)
      FROM dbo.ff_MenuRol mo
      JOIN dbo.ff_Rol ro ON ro.ROIdRol=mo.MRidRol
      WHERE ro.ROIdEmpresa=@IdEmpresaModeloB3 AND ro.ROIdEstatus=1 AND mo.MRidEstatus=1
        AND NOT EXISTS
        (
          SELECT 1
          FROM dbo.ff_Rol rd
          JOIN dbo.ff_MenuRol md ON md.MRidRol=rd.ROIdRol
          WHERE rd.ROIdEmpresa=e.IdEmpresa AND rd.ROIdEstatus=1
            AND rd.RODescripcionCorta=ro.RODescripcionCorta
            AND rd.RODescripcionLarga=ro.RODescripcionLarga
            AND md.MRidMenu=mo.MRidMenu AND md.MRidEstatus=1
        )
    ),

    MenusV2Faltantes=
    (
      SELECT COUNT(*)
      FROM dbo.ff_MenuRol2 mo
      JOIN dbo.ff_Rol ro ON ro.ROIdRol=mo.MRidRol
      WHERE ro.ROIdEmpresa=@IdEmpresaModeloB3 AND ro.ROIdEstatus=1 AND mo.MRidEstatus=1
        AND NOT EXISTS
        (
          SELECT 1
          FROM dbo.ff_Rol rd
          JOIN dbo.ff_MenuRol2 md ON md.MRidRol=rd.ROIdRol
          WHERE rd.ROIdEmpresa=e.IdEmpresa AND rd.ROIdEstatus=1
            AND rd.RODescripcionCorta=ro.RODescripcionCorta
            AND rd.RODescripcionLarga=ro.RODescripcionLarga
            AND md.MRidMenu=mo.MRidMenu AND md.MRidEstatus=1
        )
    ),

    DiferenciaConteoImagenEmpresa=ABS(
      (SELECT COUNT(*) FROM dbo.ff_EmpresaImagen WHERE EIIdEmpresa=@IdEmpresaModeloB3)-
      (SELECT COUNT(*) FROM dbo.ff_EmpresaImagen WHERE EIIdEmpresa=e.IdEmpresa)),

    DiferenciaConteoImagenMenu=ABS(
      (SELECT COUNT(*) FROM dbo.ff_ImagenEmpresaMenu WHERE IEMIdEmpresa=@IdEmpresaModeloB3 AND IEMEstatus=1)-
      (SELECT COUNT(*) FROM dbo.ff_ImagenEmpresaMenu WHERE IEMIdEmpresa=e.IdEmpresa AND IEMEstatus=1)),

    ColoresFaltantesODiferentes=
    (
      SELECT COUNT(*) FROM dbo.ff_Parametro o
      WHERE o.paIdEmpresa=@IdEmpresaModeloB3 AND o.paidEstatus=1
        AND o.paId<>226
        AND (o.paClase LIKE '%COLOR%' OR o.paClase LIKE '%ESTILO%' OR o.paClase LIKE '%CSS%')
        AND NOT EXISTS
        (
          SELECT 1 FROM dbo.ff_Parametro d
          WHERE d.paIdEmpresa=e.IdEmpresa AND d.paId=o.paId
            AND ISNULL(d.paClase,'')=ISNULL(o.paClase,'')
            AND ISNULL(d.paValor,'')=ISNULL(o.paValor,'')
            AND d.paidEstatus=o.paidEstatus
        )
    ),

    DocumentosFaltantes=
    (
      SELECT COUNT(*) FROM dbo.ff_Documentos o
      WHERE o.DOIdEmpresa=@IdEmpresaModeloB3 AND o.DOUsuarioDel IS NULL
        AND NOT EXISTS
        (
          SELECT 1 FROM dbo.ff_Documentos d
          WHERE d.DOIdEmpresa=e.IdEmpresa AND d.DOUsuarioDel IS NULL
            AND d.DONombreDocumento=o.DONombreDocumento
        )
    ),

    DocumentosPlanFaltantes=
    (
      SELECT COUNT(*) FROM dbo.ff_DocumentoPlanB3 o
      WHERE o.DPIdEmpresa=@IdEmpresaModeloB3 AND o.DPEstatus=1
        AND NOT EXISTS
        (
          SELECT 1 FROM dbo.ff_DocumentoPlanB3 d
          WHERE d.DPIdEmpresa=e.IdEmpresa AND d.DPIdPlan=o.DPIdPlan AND d.DPEstatus=1
        )
    ),

    ParametrosFaltantesODiferentes=
    (
      SELECT COUNT(*) FROM dbo.ff_Parametro o
      WHERE o.paIdEmpresa=@IdEmpresaModeloB3 AND o.paidEstatus=1
        AND o.paId<>226
        AND NOT EXISTS
        (
          SELECT 1 FROM dbo.ff_Parametro d
          WHERE d.paIdEmpresa=e.IdEmpresa AND d.paId=o.paId
            AND ISNULL(d.paClase,'')=ISNULL(o.paClase,'')
            AND ISNULL(d.paValor,'')=ISNULL(o.paValor,'')
            AND d.paidEstatus=o.paidEstatus
        )
    ),

    AvisoEmpresa226Valido=CASE WHEN EXISTS
    (
      SELECT 1 FROM dbo.ff_Parametro p
      WHERE p.paIdEmpresa=e.IdEmpresa AND p.paId=226 AND p.paidEstatus=1
        AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
    ) THEN 1 ELSE 0 END,

    AvisoCorporativo226Valido=CASE WHEN EXISTS
    (
      SELECT 1 FROM dbo.ff_Parametro p
      WHERE p.paIdEmpresa=e.EMidCorporativo AND p.paId=226 AND p.paidEstatus=1
        AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
    ) THEN 1 ELSE 0 END
INTO #Resultado
FROM #Empresas e;

SELECT *,
       Resultado=CASE WHEN
         RolesFaltantes=0 AND PerfilesFaltantesODiferentes=0
         AND MenusV1Faltantes=0 AND MenusV2Faltantes=0
         AND DiferenciaConteoImagenEmpresa=0 AND DiferenciaConteoImagenMenu=0
         AND ColoresFaltantesODiferentes=0 AND DocumentosFaltantes=0
         AND DocumentosPlanFaltantes=0 AND ParametrosFaltantesODiferentes=0
         AND AvisoEmpresa226Valido=1 AND AvisoCorporativo226Valido=1
       THEN 'OK' ELSE 'REVISAR' END
FROM #Resultado
ORDER BY IdEmpresa;

SELECT
    Total=COUNT(*),
    Correctas=SUM(CASE WHEN
      RolesFaltantes=0 AND PerfilesFaltantesODiferentes=0
      AND MenusV1Faltantes=0 AND MenusV2Faltantes=0
      AND DiferenciaConteoImagenEmpresa=0 AND DiferenciaConteoImagenMenu=0
      AND ColoresFaltantesODiferentes=0 AND DocumentosFaltantes=0
      AND DocumentosPlanFaltantes=0 AND ParametrosFaltantesODiferentes=0
      AND AvisoEmpresa226Valido=1 AND AvisoCorporativo226Valido=1
      THEN 1 ELSE 0 END),
    PorRevisar=SUM(CASE WHEN
      RolesFaltantes<>0 OR PerfilesFaltantesODiferentes<>0
      OR MenusV1Faltantes<>0 OR MenusV2Faltantes<>0
      OR DiferenciaConteoImagenEmpresa<>0 OR DiferenciaConteoImagenMenu<>0
      OR ColoresFaltantesODiferentes<>0 OR DocumentosFaltantes<>0
      OR DocumentosPlanFaltantes<>0 OR ParametrosFaltantesODiferentes<>0
      OR AvisoEmpresa226Valido<>1 OR AvisoCorporativo226Valido<>1
      THEN 1 ELSE 0 END)
FROM #Resultado;

/* Evidencia de que el script no valida ni altera carga masiva. */
SELECT AlcanceValidado='Menus, roles, imagenes, colores, documentos, perfiles, planes y parametros',
       RequisitoAdicional='Aviso de privacidad 226 valido en empresa y corporativo, reutilizando B2 cuando existe',
       FueraDeAlcance='Carga masiva, parametros 128/232 y demas complementos v3';

PRINT 'Validacion terminada. No se modificaron datos.';
