# Resultado de verificación final

Fecha: 1 de septiembre de 2026.

## Alcance comprobado

El script ejecutable contiene únicamente las ocho llamadas directas del flujo Java `EmpresaMVP`:

- roles;
- perfiles;
- menús;
- imágenes;
- colores/estilos;
- documentos;
- documentos de planes B3;
- parámetros.

Adicionalmente valida y completa el aviso de privacidad `paId = 226`, porque el login B3 consulta ese parámetro. No se ejecuta carga masiva ni otro complemento v3.

## Correcciones de la revisión final

- El aviso B2 activo y no vacío de la empresa se conserva aunque la copia general de parámetros contenga otro `226`.
- Si la empresa no tiene aviso, se reutiliza el aviso válido de su corporativo B2.
- Si el corporativo no tiene aviso, se completa exclusivamente desde el modelo B3 aprobado.
- No se promueve un aviso particular de una empresa hija al corporativo, para evitar afectar a otras empresas del mismo corporativo.
- El parámetro `226` se excluyó de la comparación general contra el modelo y se valida por separado.
- Se agregó validación de corporativos activos y de las firmas SQL requeridas.
- Antes de aplicar se comprueba que todas las empresas seleccionadas tengan una fuente válida para el aviso.

## Verificación adicional en Wizard-QA

- Se confirmó que Wizard-QA administra B3; no es evidencia del flujo B2 aunque su implementación sea .NET.
- La pantalla de alta no solicita empresa modelo: envía `IdConfiguracion` y la bandera `EmpresaMVP`.
- `ff_AddEmpresa`, cuando recibe `EM_MVP=1`, llama a `bf_ProcesoMVP` con empresa y usuario.
- La conversión de una empresa existente también llama `bf_ProcesoMVP(idEmpresa, Admin)` sin modelo visible.
- La LocalDB contiene defaults internos para empresa y corporativo modelo; no se consideran portables a QA/producción.
- `GenericMVP` es otra configuración predeterminada, pero sólo para archivos visuales; no sustituye la copia de datos de configuración en BD.
- Se incorporaron directamente los defaults B3: empresa modelo `2494` y corporativo modelo `2493`; ya no requieren captura manual.
- Se agregó una detención preventiva si los defaults no existen, están inactivos, no están relacionados o carecen de roles, perfiles, menús V2 o parámetros activos.

## Pruebas realizadas en LocalDB

- Los cuatro SQL pasaron análisis sintáctico y compilación: resultado `0`.
- Los IDs default existen y su relación es correcta: empresa `2494` → corporativo `2493`.
- La prevalidación detectó correctamente que el modelo de la LocalDB está incompleto: `INCOMPLETO_NO_APLICAR`.
- El script 02 terminó con error preventivo antes de seleccionar o modificar destinos cuando detectó el modelo incompleto.
- Los ocho procedimientos existen y sus cuatro parámetros requeridos coinciden.
- La prevalidación y el análisis se ejecutaron sin modificar información.
- Búsqueda de llamadas fuera de alcance en el ejecutable: ninguna.
- Prueba de conservación: la empresa hija mantuvo `AVISO B2 ORIGINAL` y el corporativo faltante recibió `AVISO B3 MODELO`.
- Prueba de reutilización: una hija sin aviso recibió `AVISO CORPORATIVO B2` sin sobrescribir al corporativo.
- Prueba integrada: se ejecutaron los ocho procedimientos, privacidad y validación sobre una empresa de prueba dentro de una transacción externa.
- Resultado de la validación integrada: una empresa correcta, cero por revisar.
- La transacción externa permaneció activa hasta el `ROLLBACK`.
- Verificación posterior: cero marcadores y cero avisos de prueba residuales.

## Limitación del ambiente local

La tabla local `bf_EmpresaMVP` no contiene las 286 empresas. Aunque `2494` y `2493` existen y coinciden con los defaults declarados en `bf_ProcesoMVP`, la empresa local `2494` no contiene una configuración modelo completa ni el aviso `226`. La nueva validación la clasifica como `INCOMPLETO_NO_APLICAR` y el script ejecutable se detiene.

En la base funcional debe ejecutarse primero `01_PREVALIDACION_SOLO_CONFIG_MVP_B3.sql`. No debe aplicarse la homologación si el modelo default aparece incompleto, si existe una firma diferente, un corporativo inválido o `SIN_FUENTE_REVISAR`/`SIN_FUENTE_MODELO_REVISAR`.
