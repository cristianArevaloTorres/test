/*
===============================================================================
 ALCANCE CORREGIDO: HOMOLOGACION EXCLUSIVA DE CONFIGURACION MVP B3
===============================================================================

 Este archivo es informativo y de solo lectura. No modifica datos.

 CONFIRMACION ADICIONAL: WIZARD-QA ES ADMINISTRACION B3
 -----------------------------------------------------
 Aunque Wizard-QA esta implementado en .NET, el repositorio administra B3:

  - CategoriaPlanAsistenteController.cs, linea 322, identifica expresamente
    el bloque como "Empresa acceso b3" y utiliza la clase Empresab3.
  - Empresa.cs, lineas 351 a 382, registra la empresa mediante ff_AddEmpresa
    y envia EmpresaMVP como bandera; no envia un IdEmpresaModelo.
  - Empresa.cs, lineas 162 a 203, convierte una empresa existente llamando
    bf_ProcesoMVP(idEmpresa, Admin), tambien sin empresa modelo en la llamada.
  - BeflexEF.edmx, lineas 19346 a 19349, importa bf_ProcesoMVP con solamente
    idEmpresa y Usuario.
  - Web.config, lineas 107 a 113, apunta los estilos GenericMVP a recursos
    block3; EstilosMVP.cs indica que esos recursos son consumidos por BeFlex3.

 EMPRESA MODELO Y CONFIGURACION DEFAULT
 --------------------------------------
 La pantalla del Wizard B3 NO obliga al usuario a capturar una empresa modelo:
 solo solicita la configuracion y la bandera "Es Empresa MVP". La seleccion
 denominada "Configuracion default" es IdConfiguracion; no es el ID de una
 empresa modelo.

 En la base local revisada, ff_AddEmpresa llama bf_ProcesoMVP con dos argumentos
 cuando EM_MVP=1. bf_ProcesoMVP admite adicionalmente valores predeterminados
 internos para ModeloOrigen y ModeloCorp. Por eso el Wizard puede omitirlos.
 Tambien existe GenericMVP como plantilla default de archivos CSS, logos y menu.

 A solicitud del despliegue, este paquete deja indicados los mismos defaults
 observados en bf_ProcesoMVP de B3:

   Empresa modelo B3:     2494 - DRAGER MEDICAL MEXICO, S.A. DE C.V.
   Corporativo modelo B3: 2493 - DRAGER

 Ya no es obligatorio capturar esos IDs. Antes de usar cualquiera de ellos,
 los scripts validan existencia, estatus, relacion empresa-corporativo y que
 el modelo contenga configuracion MVP minima. Si el ambiente utiliza IDs
 distintos o el default esta incompleto, la ejecucion se detiene sin cambios.

 FUENTE AUTORITATIVA
 ------------------
 Se toma como alcance el metodo replicarElementos de:

   WSBeFlex/Services/LogicaEmpresaMVP.java, lineas 110 a 212

 y los procedimientos invocados directamente por:

   WSBeFlex/DAO/JDBCEmpresaMVP.java, lineas 92 a 218.

 El flujo Java MVP B3 permite replicar exclusivamente estos ocho componentes:

  1. Menus       -> sp_CopiarMenusEmpresa
  2. Roles       -> sp_CopiarRolesEmpresa
  3. Imagenes    -> sp_CopiarImagenesEmpresa
  4. Colores     -> sp_CopiarColoresEmpresa
  5. Documentos  -> sp_CopiarDocumentosEmpresa
  6. Perfiles    -> sp_CopiarPerfilesEmpresa
  7. Planes      -> sp_CopiarPlanesEmpresa
  8. Parametros  -> sp_CopiarParametrosEmpresa

 OBJETOS EXPRESAMENTE EXCLUIDOS
 ------------------------------
 No forman parte de replicarElementos de LogicaEmpresaMVP y NO se ejecutan:

  - sp_CopiarCargaMasiva_MVP y ff_CargaMasivaOperacionEmpresa.
  - sp_CopiarParametroMismoSexo_MVP.
  - sp_CopiarMenusV2_MVP como complemento especial.
  - sp_CopiarPlantillasMVP.
  - sp_CopiarReporteInterfabricaMVP.
  - sp_CopiarAccesoBeflex.
  - sp_CopiarBeflexInicio2.
  - sp_CopiarConfiguracionEmpresa.
  - parametros especiales 128 y 232.
  - reparaciones adicionales de ff_AdministradorEmpresa.

 MOTIVO DE LA CORRECCION
 -----------------------
 El sp_CrearEmpresaMVP disponible en la base local fue ampliado posteriormente
 con una cascada denominada v3. Esa version incorpora carga masiva y otros
 complementos que no aparecen en el metodo Java replicarElementos. Para evitar
 mezclar desarrollos, este paquete usa solamente los ocho procedimientos que
 Java B3 llama directamente.

 sp_CrearEmpresaMVP tampoco se ejecuta: las empresas destino ya existen y deben
 conservar su EMidEmpresa. Solo se replica la configuracion desde una empresa
 modelo B3 aprobada hacia esas empresas existentes.

 EFECTOS IMPORTANTES DE LOS PROCEDIMIENTOS B3
 --------------------------------------------
 - Roles, menus y documentos de plan agregan faltantes.
 - Perfiles inserta faltantes y actualiza perfiles del mismo nombre.
 - Imagenes reemplaza las imagenes del destino.
 - Colores reemplaza parametros COLOR/ESTILO/CSS del destino.
 - Documentos reemplaza documentos cuyo nombre coincide con el modelo.
 - Parametros reemplaza los paId existentes que tambien existen en el modelo.

 Por eso 02_HOMOLOGACION_SOLO_CONFIG_MVP_B3.sql inicia en simulacion y exige
 habilitar expresamente @PermitirReemplazos antes de aplicar esos componentes.

===============================================================================
 ENFOQUE: QUE NO TIENE DE B3, QUE SE AGREGA Y QUE CAMBIA
===============================================================================

 No se presupone que todas las empresas carezcan de lo mismo. El script 01
 compara cada empresa contra el modelo B3 e informa las diferencias reales.
 El script 02 actua solamente sobre los componentes habilitados.

 ROLES
 - Que puede faltar: roles activos del modelo B3 identificados por descripcion.
 - Que se agrega: los roles que no existen y sus asociaciones MenuRol faltantes.
 - Que cambia: no actualiza ni elimina roles existentes.
 - Por que: perfiles y menus B3 requieren roles equivalentes en el destino.

 PERFILES
 - Que puede faltar: perfiles B3 identificados por PENombre.
 - Que se agrega: perfiles del modelo cuyo nombre no existe en el destino.
 - Que cambia: si el nombre ya existe, actualiza descripcion, periodicidad,
   visibilidad de sueldo, indicador administrador, rol predeterminado, carpeta
   y estatus. Conserva PEIdPerfil para no romper relaciones existentes.
 - Por que: B3 aplica reglas y permisos mediante perfil y rol predeterminado.

 MENUS
 - Que puede faltar: asignaciones de menu del modelo para roles equivalentes.
 - Que se agrega: faltantes en ff_MenuRol (V1) y ff_MenuRol2 (V2/B3).
 - Que cambia: no borra menus existentes. El paquete copia primero los roles
   para que el procedimiento pueda resolver correctamente el mapeo.
 - Por que: B3 construye su navegacion consultando ff_MenuRol2.

 IMAGENES
 - Que puede faltar: imagen corporativa y recursos visuales del modelo B3.
 - Que se agrega: registros del modelo en ff_EmpresaImagen y
   ff_ImagenEmpresaMenu; tambien se copia EMImagenIzq.
 - Que cambia: reemplaza todas las imagenes registradas para el destino.
 - Por que: el procedimiento B3 fue diseñado como replica exacta, no como alta
   incremental. Requiere respaldo y autorizacion de reemplazo.

 COLORES
 - Que puede faltar: parametros activos del modelo clasificados como COLOR,
   ESTILO o CSS.
 - Que se agrega: dichos parametros desde la empresa modelo.
 - Que cambia: elimina primero los COLOR/ESTILO/CSS actuales del destino.
 - Por que: B3 trata colores y estilos como una configuracion unica del modelo.

 DOCUMENTOS
 - Que puede faltar: documentos activos del modelo identificados por nombre.
 - Que se agrega: registros de ff_Documentos provenientes del modelo B3.
 - Que cambia: reemplaza documentos del destino cuyo nombre coincide; conserva
   documentos con nombres distintos. El SP copia registros de BD, no demuestra
   por si solo la copia de archivos fisicos.
 - Por que: evita dos definiciones activas con el mismo nombre funcional.

 PLANES
 - Que puede faltar: configuracion documental B3 por plan.
 - Que se agrega: faltantes en ff_DocumentoPlanB3 por DPIdPlan.
 - Que cambia: no reemplaza registros existentes y NO copia toda ff_Plan.
 - Por que: aunque Java lo denomina "planes", el procedimiento revisado solo
   replica documentos/formato de plan utilizados por B3.

 PARAMETROS
 - Que puede faltar: parametros activos de la empresa modelo B3.
 - Que se agrega: los parametros activos del modelo con el mismo paId.
 - Que cambia: reemplaza en el destino los paId que existen en el modelo;
   conserva parametros del destino que no forman parte del modelo. El paId 226
   es una excepcion protegida: se restaura si B2 ya tenia un valor valido.
 - Por que: garantiza que los parametros seleccionados coincidan con el modelo
   MVP B3, pero puede sustituir personalizaciones B2.

 AVISO DE PRIVACIDAD (paId=226)
 - Que puede faltar: B2 puede mostrar un PDF o pagina estatica sin tener la
   leyenda parametrizada que consulta el login B3.
 - Que se reutiliza: primero el 226 activo y no vacio de la empresa B2; si no
   existe, el de su corporativo B2.
 - Que se agrega: solo cuando falta, se completa el corporativo y la empresa
   usando el modelo B3 como ultimo recurso.
 - Que cambia: un 226 B2 activo y con valor nunca se sobrescribe. Un registro
   vacio o inactivo se reemplaza para que B3 pueda consumirlo.
 - Por que: login.component.ts, linea 380, consulta getParametro(empresa,226)
   y usa paValor como LeyendaAviso. bf_ProcesoMVP v3 tambien garantiza 226 en
   el corporativo y en la empresa hija.
 - Clasificacion: requisito operativo de B3 que puede reutilizar informacion
   B2; no habilita ni justifica copiar los demas complementos v3.

 QUE PERMANECE INTACTO
 ---------------------
 - La empresa y su EMidEmpresa.
 - Empleados, dependientes, solicitudes, movimientos e historial.
 - La marca existente en bf_EmpresaMVP.
 - Menus y roles adicionales que no coinciden con el modelo.
 - Documentos con nombres distintos a los del modelo.
 - Parametros cuyos paId no existen en el modelo.
 - Toda configuracion de carga masiva y los complementos v3 excluidos.
 - El aviso 226 B2 cuando ya se encuentra activo y con valor.
===============================================================================
*/

SET NOCOUNT ON;

SELECT Componente, Procedimiento, EvidenciaJava, Efecto
FROM (VALUES
 ('MENUS','sp_CopiarMenusEmpresa','LogicaEmpresaMVP.java:110-121; JDBCEmpresaMVP.java:92','Agrega faltantes en ff_MenuRol y ff_MenuRol2'),
 ('ROLES','sp_CopiarRolesEmpresa','LogicaEmpresaMVP.java:123-134; JDBCEmpresaMVP.java:110','Agrega roles faltantes y MenuRol'),
 ('IMAGENES','sp_CopiarImagenesEmpresa','LogicaEmpresaMVP.java:136-147; JDBCEmpresaMVP.java:128','Reemplaza imagenes del destino'),
 ('COLORES','sp_CopiarColoresEmpresa','LogicaEmpresaMVP.java:149-160; JDBCEmpresaMVP.java:146','Reemplaza parametros COLOR/ESTILO/CSS'),
 ('DOCUMENTOS','sp_CopiarDocumentosEmpresa','LogicaEmpresaMVP.java:162-173; JDBCEmpresaMVP.java:164','Reemplaza documentos con el mismo nombre'),
 ('PERFILES','sp_CopiarPerfilesEmpresa','LogicaEmpresaMVP.java:175-186; JDBCEmpresaMVP.java:182','Inserta o actualiza por PENombre'),
 ('PLANES','sp_CopiarPlanesEmpresa','LogicaEmpresaMVP.java:188-199; JDBCEmpresaMVP.java:200','Agrega ff_DocumentoPlanB3 faltante'),
 ('PARAMETROS','sp_CopiarParametrosEmpresa','LogicaEmpresaMVP.java:201-212; JDBCEmpresaMVP.java:218','Reemplaza paId presentes en el modelo')
) x(Componente,Procedimiento,EvidenciaJava,Efecto)
ORDER BY Componente;

/* Resumen ejecutivo del efecto esperado por componente. */
SELECT Componente,QueDetectaLaPrevalidacion,QueAgrega,QuePuedeCambiar
FROM (VALUES
 ('ROLES','Roles activos del modelo sin equivalente','Roles y MenuRol faltantes','Nada de los roles existentes'),
 ('PERFILES','Perfiles del modelo ausentes o coincidentes','Perfiles faltantes','Atributos de perfiles del mismo nombre; conserva PEIdPerfil'),
 ('MENUS','Asignaciones V1/V2 ausentes','MenuRol y MenuRol2 faltantes','No elimina asignaciones existentes'),
 ('IMAGENES','Conteos/recursos distintos al modelo','Imagenes del modelo','Reemplaza imagenes del destino y EMImagenIzq'),
 ('COLORES','Parametros COLOR/ESTILO/CSS distintos','Configuracion visual del modelo','Reemplaza COLOR/ESTILO/CSS del destino'),
 ('DOCUMENTOS','Documentos del modelo ausentes o coincidentes','Registros de documentos del modelo','Reemplaza documentos del mismo nombre'),
 ('PLANES','DocumentoPlanB3 ausente por plan','ff_DocumentoPlanB3 faltante','No reemplaza ni copia toda la estructura de planes'),
 ('PARAMETROS','Parametros activos del modelo ausentes o distintos','Parametros activos del modelo','Reemplaza paId coincidentes salvo 226; conserva los demas'),
 ('AVISO PRIVACIDAD 226','Ausencia en empresa/corporativo o valor vacio','Reutiliza B2; modelo B3 solo como respaldo','Conserva el 226 B2 valido; reemplaza solo vacio/inactivo')
) x(Componente,QueDetectaLaPrevalidacion,QueAgrega,QuePuedeCambiar)
ORDER BY Componente;

SELECT
    Procedimiento=p.name,
    Parametro=pr.name,
    Tipo=TYPE_NAME(pr.user_type_id),
    EsSalida=pr.is_output
FROM sys.procedures p
JOIN sys.parameters pr ON pr.object_id=p.object_id
WHERE p.name IN
(
 'sp_CopiarMenusEmpresa','sp_CopiarRolesEmpresa','sp_CopiarImagenesEmpresa',
 'sp_CopiarColoresEmpresa','sp_CopiarDocumentosEmpresa',
 'sp_CopiarPerfilesEmpresa','sp_CopiarPlanesEmpresa','sp_CopiarParametrosEmpresa'
)
ORDER BY p.name,pr.parameter_id;

PRINT 'Analisis de alcance terminado. No se modificaron datos.';
