# Ajustes realizados

1. Se reemplazó la réplica parcial de ocho componentes por la llamada controlada a `bf_ProcesoMVP`, que es la cascada señalada en los archivos recibidos y la utilizada por `ff_AddEmpresa` cuando `@EM_MVP=1`.
2. Se mantuvo fuera `sp_CrearEmpresaMVP`, porque las empresas destino ya existen.
3. Se sustituyó el universo genérico de `bf_EmpresaMVP` por la lista explícita de 20 corporativos del archivo `Mustra_empresas_MVP_020209.xlsx`.
4. Se agregó resolución de empresas hijas. En el esquema local, los 20 corporativos corresponden a 23 empresas activas; el ambiente destino deberá confirmar su propio resultado.
5. Se fijaron explícitamente la empresa modelo `2494` y el corporativo modelo `2493` en cada llamada para evitar depender de parámetros predeterminados distintos entre ambientes.
6. Se creó un piloto exclusivo para HAPAG: corporativo `495`, empresa hija `496`.
7. Se eliminó la transacción exterior después de detectar el error SQL `3930`. La cascada debe ejecutarse como lo hace `ff_AddEmpresa`, dejando que cada `sp_Copiar*` administre su propia transacción y usando `XACT_ABORT OFF`.
8. Se agregó alta o reactivación idempotente de la marca `bf_EmpresaMVP`, reproduciendo el paso que normalmente realiza `ff_AddEmpresa` después de la cascada.
9. El masivo quedó bloqueado por defecto. La lista está en `Procesar=0`, la línea de habilitación está comentada, la ejecución está en cero y existe una frase de confirmación obligatoria.
10. Se añadieron validaciones de objetos, firma del procedimiento, modelos, relación corporativo/empresa, operaciones de carga masiva, plantillas, acceso B3, aviso de privacidad, SSO, administrador y bitácora.
11. La configuración vacía del modelo obligatorio se reporta como advertencia. Sólo se bloquean dependencias que provocarían un fallo seguro: rol V2 `7365`, plantillas fijas, objetos y operaciones de carga.
12. Se añadió una autorreparación posterior a `bf_ProcesoMVP` tanto en el piloto como en el masivo. Corrige referencias de perfil/rol administrador aunque el perfil ya fuera el correcto, normaliza las operaciones `1, 2, 3, 13 y 14`, repara el aviso `226` desde el modelo y valida el resultado antes de marcar la empresa como MVP.
13. Se corrigió el punto ciego detectado en HAPAG `495 -> 496`: el perfil administrador `1648` era válido, pero los registros conservaban el rol inexistente/inactivo `1168`. La condición de reparación ahora compara perfil y rol por separado.
14. Se corrigió el punto ciego de `sp_CopiarCargaMasiva_MVP`: como sólo agrega operaciones faltantes, una operación existente con plantilla o SP legacy no se reemplazaba. Los ejecutables ahora actualizan el registro activo, insertan el faltante y desactivan duplicados activos de forma auditable.
15. Los validadores `02` y `04` ahora detectan referencias inválidas de administrador y verifican el mapeo exacto de las operaciones base, no sólo su cantidad.
16. Se separó el modelo funcional `2494` de un nuevo `@IdEmpresaModeloVisual`, seleccionado previamente por el script de sólo lectura `06`.
17. La capa visual copia únicamente estilos, parámetros visuales e iconos por `MRidMenu`; no toma roles, perfiles, planes, plantillas ni operaciones del segundo modelo.
18. El branding del destino se respalda y conserva por defecto. Si falla la aplicación visual, el piloto y el masivo intentan restaurar estilos, parámetros e imágenes anteriores.
19. Los validadores ahora consideran estilos/colores e iconos como condiciones obligatorias para emitir `OK PARA PRUEBA FUNCIONAL`.

## Nota sobre B2 y B3

El código legacy B2 revisado no activaba `@EM_MVP`. La evidencia entregada ubica la homologación en la cascada `bf_ProcesoMVP`, incorporada al alta MVP y compuesta por objetos de B3. Las tablas de empresa son compartidas, pero el resultado buscado es la configuración completa consumida por BF3.
