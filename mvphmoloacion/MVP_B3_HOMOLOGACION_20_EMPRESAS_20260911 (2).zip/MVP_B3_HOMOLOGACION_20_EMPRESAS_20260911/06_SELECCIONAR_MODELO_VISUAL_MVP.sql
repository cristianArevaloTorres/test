/*
  SELECCION TECNICA DE MODELO VISUAL MVP - SOLO LECTURA

  Objetivo:
    - Buscar empresas activas y marcadas como MVP.
    - Comprobar que tengan acceso BF3, rol administrador, menus, iconos y estilos.
    - Proponer @IdEmpresaModeloVisual sin considerar logos corporativos como puntos.

  Importante:
    - El primer lugar es un CANDIDATO TECNICO, no una autorizacion de marca.
    - Antes de copiar, revisar las rutas devueltas al final y confirmar que sean
      recursos genericos/autorizados y que existan fisicamente en el servidor web.
    - No cambia ningun dato.
*/
USE [FlexiForbesv2];
GO
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @IdEmpresaModeloFuncional INT=2494;
DECLARE @IdEmpresaModeloVisual INT=NULL;

DECLARE @Objetos TABLE (Objeto SYSNAME,Tipo CHAR(2));
INSERT INTO @Objetos VALUES
('dbo.ff_Empresa','U'),('dbo.bf_EmpresaMVP','U'),('dbo.ff_accesoBeflex','U'),
('dbo.ff_Perfil','U'),('dbo.ff_Rol','U'),('dbo.ff_MenuRol2','U'),
('dbo.bf_EstiloEmpresa','U'),('dbo.ff_Parametro','U'),
('dbo.ff_ImagenEmpresaMenu','U'),('dbo.ff_EmpresaImagen','U'),
('dbo.bf_BeflexInicio2','U');

IF EXISTS (SELECT 1 FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL)
BEGIN
    SELECT '00_OBJETOS_FALTANTES' Bloque,Objeto,Tipo
    FROM @Objetos WHERE OBJECT_ID(Objeto,Tipo) IS NULL;
    THROW 51000, 'Faltan tablas necesarias para evaluar el modelo visual MVP.', 1;
END;

/* Se evalua cada empresa una sola vez aunque bf_EmpresaMVP tuviera duplicados. */
SELECT
    e.EMidEmpresa IdEmpresa,
    e.EMidCorporativo IdCorporativo,
    e.EMNombre Empresa,
    e.EMRazonSocial RazonSocial,
    CASE WHEN e.EMidEmpresa<>e.EMidCorporativo THEN 1 ELSE 0 END EsEmpresaHija,
    CASE WHEN EXISTS (
        SELECT 1 FROM dbo.ff_accesoBeflex a
        WHERE a.idempresa=e.EMidEmpresa AND a.acceso=1
    ) THEN 1 ELSE 0 END AccesoBF3,
    ISNULL(admin.RolesAdministradorValidos,0) RolesAdministradorValidos,
    ISNULL(admin.MenusAdministrador,0) MenusAdministrador,
    ISNULL(admin.IconosMenuAdministrador,0) IconosMenuAdministrador,
    ISNULL(admin.BannersAdministrador,0) BannersAdministrador,
    ISNULL(est.EstilosB3,0) EstilosB3,
    ISNULL(estdup.EstilosDuplicados,0) EstilosDuplicados,
    ISNULL(par.ParametrosVisuales,0) ParametrosVisuales,
    ISNULL(iem.RutasIconosEmpresa,0) RutasIconosEmpresa,
    ISNULL(iem.RutasLogoEmpresa,0) RutasLogoEmpresa,
    ISNULL(iem.ConfiguracionesImagenMenu,0) ConfiguracionesImagenMenu,
    ISNULL(img.ImagenesEmpresaConContenido,0) ImagenesEmpresaConContenido,
    CASE WHEN DATALENGTH(e.EMImagenIzq)>0 THEN 1 ELSE 0 END ImagenIzquierdaConContenido,
    ISNULL(ini.ElementosInicioB3,0) ElementosInicioB3,
    ISNULL(ini.ImagenesInicioB3,0) ImagenesInicioB3
INTO #BaseVisual
FROM dbo.ff_Empresa e
OUTER APPLY (
    SELECT
        COUNT(DISTINCT r.ROIdRol) RolesAdministradorValidos,
        COUNT(DISTINCT mr.MRidMenu) MenusAdministrador,
        COUNT(DISTINCT CASE
            WHEN NULLIF(LTRIM(RTRIM(mr.MRImagenMenu)),'') IS NOT NULL THEN mr.MRidMenu END
        ) IconosMenuAdministrador,
        COUNT(DISTINCT CASE
            WHEN NULLIF(LTRIM(RTRIM(mr.MRRutaBanner)),'') IS NOT NULL THEN mr.MRidMenu END
        ) BannersAdministrador
    FROM dbo.ff_Perfil p
    INNER JOIN dbo.ff_Rol r
      ON r.ROIdRol=p.PEIdRolDefault
     AND r.ROIdEmpresa=p.PEIdEmpresa
     AND r.ROIdEstatus=1
    LEFT JOIN dbo.ff_MenuRol2 mr
      ON mr.MRidRol=r.ROIdRol
     AND mr.MRidEstatus=1
    WHERE p.PEIdEmpresa=e.EMidEmpresa
      AND p.PEAdministrador=1
      AND p.PEIdEstatus=1
) admin
OUTER APPLY (
    SELECT COUNT(DISTINCT s.EEidCatalogoEstilo) EstilosB3
    FROM dbo.bf_EstiloEmpresa s
    WHERE s.EEIdEmpresa=e.EMidEmpresa
      AND s.EEIdEstatus=1
      AND NULLIF(LTRIM(RTRIM(s.EEValor)),'') IS NOT NULL
) est
OUTER APPLY (
    SELECT COUNT(*) EstilosDuplicados
    FROM (
        SELECT s.EEidCatalogoEstilo
        FROM dbo.bf_EstiloEmpresa s
        WHERE s.EEIdEmpresa=e.EMidEmpresa AND s.EEIdEstatus=1
        GROUP BY s.EEidCatalogoEstilo HAVING COUNT(*)>1
    ) d
) estdup
OUTER APPLY (
    SELECT COUNT(*) ParametrosVisuales
    FROM dbo.ff_Parametro p
    WHERE p.paIdEmpresa=e.EMidEmpresa
      AND p.paidEstatus=1
      AND NULLIF(LTRIM(RTRIM(p.paValor)),'') IS NOT NULL
      AND (
           UPPER(ISNULL(p.paClase,'')) LIKE '%COLOR%'
        OR UPPER(ISNULL(p.paClase,'')) LIKE '%ESTILO%'
        OR UPPER(ISNULL(p.paClase,'')) LIKE '%CSS%'
      )
) par
OUTER APPLY (
    SELECT
        COUNT(*) ConfiguracionesImagenMenu,
        SUM(
            CASE WHEN NULLIF(LTRIM(RTRIM(m.IEMImagenHijo)),'') IS NOT NULL THEN 1 ELSE 0 END
          + CASE WHEN NULLIF(LTRIM(RTRIM(m.IEMImagenDer)),'') IS NOT NULL THEN 1 ELSE 0 END
          + CASE WHEN NULLIF(LTRIM(RTRIM(m.IEMImagenIzq)),'') IS NOT NULL THEN 1 ELSE 0 END
        ) RutasIconosEmpresa,
        SUM(CASE WHEN NULLIF(LTRIM(RTRIM(m.IEMImagenLogo)),'') IS NOT NULL THEN 1 ELSE 0 END) RutasLogoEmpresa
    FROM dbo.ff_ImagenEmpresaMenu m
    WHERE m.IEMIdEmpresa=e.EMidEmpresa AND m.IEMEstatus=1
) iem
OUTER APPLY (
    SELECT COUNT(*) ImagenesEmpresaConContenido
    FROM dbo.ff_EmpresaImagen i
    WHERE i.EIIdEmpresa=e.EMidEmpresa
      AND (DATALENGTH(i.EIImagen1)>0 OR DATALENGTH(i.EIImagen2)>0)
) img
OUTER APPLY (
    SELECT
        COUNT(*) ElementosInicioB3,
        SUM(CASE WHEN NULLIF(LTRIM(RTRIM(b.BI_RutaImagen)),'') IS NOT NULL THEN 1 ELSE 0 END) ImagenesInicioB3
    FROM dbo.bf_BeflexInicio2 b
    WHERE b.BI_IdCorporativo=e.EMidCorporativo
      AND b.BI_Valor=e.EMidEmpresa
      AND b.BI_IdEstatus=1
) ini
WHERE e.EMIdEstatus=1
  AND EXISTS (
      SELECT 1 FROM dbo.bf_EmpresaMVP m
      WHERE m.IdEmpresa=e.EMidEmpresa AND m.IdEstatus=1
  );

SELECT b.*,
       CAST(
           CASE WHEN b.AccesoBF3=1 THEN 10 ELSE 0 END
         + CASE WHEN b.RolesAdministradorValidos>0 THEN 10 ELSE 0 END
         + CASE WHEN b.MenusAdministrador>0 THEN 10 ELSE 0 END
         + CASE WHEN b.IconosMenuAdministrador>0 THEN 25 ELSE 0 END
         + CASE WHEN b.RutasIconosEmpresa>0 THEN 15 ELSE 0 END
         + CASE WHEN b.EstilosB3>0 THEN 20 ELSE 0 END
         + CASE WHEN b.ParametrosVisuales>0 THEN 5 ELSE 0 END
         + CASE WHEN b.ImagenesInicioB3>0 THEN 5 ELSE 0 END
       AS INT) PuntuacionVisual,
       CASE
           WHEN b.IdEmpresa=@IdEmpresaModeloFuncional
                AND b.EstilosB3=0 AND b.ParametrosVisuales=0
               THEN 'NO APTO: MODELO FUNCIONAL SIN ESTILOS'
           WHEN b.AccesoBF3=0 THEN 'NO APTO: SIN ACCESO BF3'
           WHEN b.RolesAdministradorValidos=0 THEN 'NO APTO: SIN ROL ADMINISTRADOR VALIDO'
           WHEN b.MenusAdministrador=0 THEN 'NO APTO: SIN MENUS ADMINISTRADOR'
           WHEN b.EstilosDuplicados>0 THEN 'NO APTO: ESTILOS ACTIVOS DUPLICADOS'
           WHEN b.ConfiguracionesImagenMenu>1 THEN 'NO APTO: IMAGENES DE MENU DUPLICADAS'
           WHEN b.EstilosB3=0 AND b.ParametrosVisuales=0 THEN 'NO APTO: SIN ESTILOS/COLORES'
           WHEN b.IconosMenuAdministrador=0 AND b.RutasIconosEmpresa=0 THEN 'NO APTO: SIN ICONOS DE MENU'
           ELSE 'CANDIDATO TECNICO: REVISAR RUTAS Y MARCA'
       END Dictamen
INTO #EvaluacionVisual
FROM #BaseVisual b;

/* Resultado 01: todos los MVP, aptos y no aptos, ordenados por evidencia visual. */
SELECT '01_RANKING_MODELOS_VISUALES' Bloque,*
FROM #EvaluacionVisual
ORDER BY
    CASE WHEN Dictamen LIKE 'CANDIDATO TECNICO%' THEN 0 ELSE 1 END,
    PuntuacionVisual DESC,EstilosB3 DESC,IconosMenuAdministrador DESC,IdEmpresa;

/* La recomendacion automatica excluye el modelo funcional y prioriza empresas hija. */
SELECT TOP (1) @IdEmpresaModeloVisual=IdEmpresa
FROM #EvaluacionVisual
WHERE Dictamen LIKE 'CANDIDATO TECNICO%'
  AND IdEmpresa<>@IdEmpresaModeloFuncional
ORDER BY EsEmpresaHija DESC,PuntuacionVisual DESC,EstilosB3 DESC,
         IconosMenuAdministrador DESC,IdEmpresa;

SELECT '02_MODELO_VISUAL_PROPUESTO' Bloque,
       @IdEmpresaModeloVisual IdEmpresaModeloVisual,
       e.IdCorporativo,e.Empresa,e.RazonSocial,e.PuntuacionVisual,e.Dictamen,
       CASE
           WHEN @IdEmpresaModeloVisual IS NULL
             THEN 'NO HAY CANDIDATO. No ejecutar homologacion visual.'
           ELSE 'VALIDAR que las rutas existan y que no contengan branding ajeno.'
       END SiguientePaso
FROM (SELECT 1 n) x
LEFT JOIN #EvaluacionVisual e ON e.IdEmpresa=@IdEmpresaModeloVisual;

/* Resultado 03: detalle de estilos del candidato propuesto. */
SELECT '03_ESTILOS_PROPUESTOS' Bloque,s.EEidCatalogoEstilo,c.CENombre,c.CEDescripcion,
       s.EEValor,s.EEIdEstatus
FROM dbo.bf_EstiloEmpresa s
LEFT JOIN dbo.bf_CatalogoEstilos c ON c.CEIdCatalogoEstilos=s.EEidCatalogoEstilo
WHERE s.EEIdEmpresa=@IdEmpresaModeloVisual AND s.EEIdEstatus=1
ORDER BY s.EEidCatalogoEstilo;

/* Resultado 04: iconos de menu; son reutilizables solo si la ruta es generica. */
SELECT DISTINCT '04_ICONOS_MENU_PROPUESTOS' Bloque,r.ROIdRol,r.RODescripcionCorta,
       mr.MRidMenu,mr.MRImagenMenu,mr.MRRutaBanner
FROM dbo.ff_Perfil p
INNER JOIN dbo.ff_Rol r
  ON r.ROIdRol=p.PEIdRolDefault AND r.ROIdEmpresa=p.PEIdEmpresa AND r.ROIdEstatus=1
INNER JOIN dbo.ff_MenuRol2 mr ON mr.MRidRol=r.ROIdRol AND mr.MRidEstatus=1
WHERE p.PEIdEmpresa=@IdEmpresaModeloVisual
  AND p.PEAdministrador=1 AND p.PEIdEstatus=1
ORDER BY mr.MRidMenu;

/* Resultado 05: rutas de imagen generales; IEMImagenLogo requiere aprobacion expresa. */
SELECT '05_RUTAS_IMAGEN_PROPUESTAS' Bloque,IEMImagenHijo,IEMImagenDer,IEMImagenIzq,
       IEMImagenLogo,IEMEstatus
FROM dbo.ff_ImagenEmpresaMenu
WHERE IEMIdEmpresa=@IdEmpresaModeloVisual AND IEMEstatus=1;

/* Resultado 06: parametros visuales que se copiarian. */
SELECT '06_PARAMETROS_VISUALES_PROPUESTOS' Bloque,paId,paClase,
       LEFT(LTRIM(RTRIM(paValor)),250) Valor,paDescripcion
FROM dbo.ff_Parametro
WHERE paIdEmpresa=@IdEmpresaModeloVisual AND paidEstatus=1
  AND (
       UPPER(ISNULL(paClase,'')) LIKE '%COLOR%'
    OR UPPER(ISNULL(paClase,'')) LIKE '%ESTILO%'
    OR UPPER(ISNULL(paClase,'')) LIKE '%CSS%'
  )
ORDER BY paId;

DROP TABLE #EvaluacionVisual;
DROP TABLE #BaseVisual;
GO
