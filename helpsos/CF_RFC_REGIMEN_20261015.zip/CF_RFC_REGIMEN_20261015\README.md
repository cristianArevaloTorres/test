# Constancia fiscal: RFC sin homoclave y regimen vigente en reportes

Fecha: 2026-10-15

Esta entrega es incremental y se aplica sobre la version final de Constancia Fiscal sin agregar archivos Java al proyecto.

## Cambios incluidos

### 1. Validacion del propietario

- Para persona fisica, un RFC de 13 caracteres se compara con sus primeros 10 caracteres.
- Para persona moral, un RFC de 12 caracteres se compara con sus primeros 9 caracteres.
- Se eliminan espacios, guiones y diferencias entre mayusculas/minusculas antes de comparar.
- La CURP se sigue extrayendo y guardando, pero no se utiliza para decidir si la constancia pertenece al empleado.
- Si el RFC base no coincide, la constancia se rechaza y se muestra el mensaje correspondiente.

Archivo Java que se debe sustituir:

- `JAVA/src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/JDBCProcesaFormatos.java`

### 2. Regimen fiscal en el Reporte de Poblacion

- El reporte toma primero el regimen vigente guardado en `ff_Empleado.EMRegimen`.
- El identificador se convierte a su descripcion mediante el catalogo `EMRegimen` de la empresa.
- Si el empleado no tiene regimen vigente o el catalogo no contiene el identificador, se conserva como respaldo el regimen de su ultima constancia en `bf_ConstanciaEmpleado`.
- La fecha de emision sigue correspondiendo a la ultima constancia cargada.

Procedimientos actualizados:

- `dbo.ff_GetDatosReporteAseguradoB3`
- `dbo.ff_GetDatosReporteAseguradoConSalarioB3`
- `dbo.ff_GetDatosReporteAseguradoB3v2`
- `dbo.ff_GetDatosReporteAseguradoConSalarioB3v2`

Scripts:

- `BD/01_actualiza_regimen_reporte.sql`: aplica el cambio de forma transaccional.
- `BD/02_valida_regimen_reporte.sql`: valida las cuatro definiciones y muestra hasta 50 casos donde el valor manual difiere del de la constancia.
- `BD/99_reversa_regimen_reporte.sql`: revierte solamente esta modificacion de los reportes.

## Componentes sin cambios

- No se modifica el frontend.
- No se agregan clases Java.
- No cambia la estructura de tablas ni la firma de procedimientos.

## Orden de aplicacion

1. Copiar el contenido de `JAVA/src` sobre `src` del backend.
2. Compilar o validar el backend.
3. Ejecutar `BD/01_actualiza_regimen_reporte.sql` en `FlexiForbesv2`.
4. Ejecutar `BD/02_valida_regimen_reporte.sql`.
5. Generar un Reporte de Poblacion y confirmar que la columna `EMRegimen` muestre la seleccion manual vigente.

## Verificaciones realizadas

- El script de aplicacion modifico correctamente los cuatro SP dentro de una transaccion de prueba.
- El script de validacion reconocio las cuatro reglas nuevas.
- Los dos SP usados por el flujo actual, con y sin salario, se ejecutaron correctamente sobre la base local y devolvieron 11,084 filas cada uno.
- En ambos SP activos se comprobo con el empleado `70037328` que `EMRegimen` devuelve la descripcion del regimen vigente de `ff_Empleado`, sin depender de una constancia almacenada.
- El script de reversa restauro las cuatro expresiones anteriores durante la prueba.
- Todas las pruebas de BD se revirtieron; la base local quedo sin cambios permanentes.
- El archivo Java del paquete coincide por SHA-256 con el codigo actualizado del backend BAC.
- La ruta interna mas larga del paquete tiene 109 caracteres.

Los comandos sugeridos estan en `COMANDOS_GIT.md`.

