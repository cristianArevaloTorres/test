SET NOCOUNT ON;

IF DB_NAME() <> N'FlexiForbesv2'
    THROW 51000, 'El script debe ejecutarse en la base FlexiForbesv2.', 1;

DECLARE @Procedimientos TABLE (Nombre sysname NOT NULL PRIMARY KEY);

INSERT INTO @Procedimientos (Nombre)
VALUES
    (N'ff_GetDatosReporteAseguradoB3'),
    (N'ff_GetDatosReporteAseguradoConSalarioB3'),
    (N'ff_GetDatosReporteAseguradoB3v2'),
    (N'ff_GetDatosReporteAseguradoConSalarioB3v2');

IF EXISTS
(
    SELECT 1
    FROM @Procedimientos P
    LEFT JOIN sys.procedures SP
        ON SP.name = P.Nombre
       AND SCHEMA_NAME(SP.schema_id) = N'dbo'
    LEFT JOIN sys.sql_modules SM
        ON SM.object_id = SP.object_id
    WHERE SP.object_id IS NULL
       OR SM.definition NOT LIKE N'%TEDRegimen.TEIdDetalle = ADO.EMRegimen%'
       OR SM.definition NOT LIKE N'%CE.IdEmpleado = ADO.Id%'
)
    THROW 51010, 'Uno o mas procedimientos no contienen la regla del regimen vigente.', 1;

SELECT
    P.Nombre AS Procedimiento,
    N'OK: prioriza ff_Empleado.EMRegimen y conserva la constancia como respaldo' AS Resultado
FROM @Procedimientos P
ORDER BY P.Nombre;

-- Casos utiles para comprobar el cambio funcional en el Reporte de Poblacion.
SELECT TOP (50)
    E.Id AS IdEmpleado,
    E.EMNumeroEmpleado,
    E.EMIdEmpresa,
    E.EMRegimen AS IdRegimenVigente,
    R.RegimenVigente,
    C.RegimenConstancia,
    C.FechaEmision
FROM dbo.ff_Empleado E
OUTER APPLY
(
    SELECT TOP (1)
        TED.TEDescripcion AS RegimenVigente
    FROM dbo.ff_TablaEncabezado TE
    INNER JOIN dbo.ff_TablaEncabezadoDetalle TED
        ON TED.TEEnClave = TE.ENClave
    WHERE TE.ENIdEmpresa = E.EMIdEmpresa
      AND TE.ENNombreCampo = N'EMRegimen'
      AND TED.TEIdDetalle = E.EMRegimen
) R
OUTER APPLY
(
    SELECT TOP (1)
        CE.Regimen AS RegimenConstancia,
        CE.FechaEmision
    FROM dbo.bf_ConstanciaEmpleado CE
    WHERE CE.IdEmpleado = E.Id
    ORDER BY CE.Id DESC
) C
WHERE E.EMRegimen IS NOT NULL
  AND ISNULL(R.RegimenVigente, N'') <> ISNULL(C.RegimenConstancia, N'')
ORDER BY E.Id DESC;

