SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;

IF DB_NAME() <> N'FlexiForbesv2'
    THROW 51000, 'El script debe ejecutarse en la base FlexiForbesv2.', 1;

DECLARE @Procedimientos TABLE
(
    Nombre sysname NOT NULL PRIMARY KEY,
    EsDinamico bit NOT NULL
);

INSERT INTO @Procedimientos (Nombre, EsDinamico)
VALUES
    (N'ff_GetDatosReporteAseguradoB3', 0),
    (N'ff_GetDatosReporteAseguradoConSalarioB3', 0),
    (N'ff_GetDatosReporteAseguradoB3v2', 1),
    (N'ff_GetDatosReporteAseguradoConSalarioB3v2', 1);

DECLARE @ExpresionAnterior nvarchar(max) =
    N'(SELECT TOP 1 Regimen FROM bf_ConstanciaEmpleado WHERE IdEmpleado = ADO.Id ORDER BY Id DESC)';

DECLARE @ExpresionNueva nvarchar(max) = N'COALESCE(
        (SELECT TOP 1 TEDRegimen.TEDescripcion
         FROM dbo.ff_TablaEncabezado TERegimen
         INNER JOIN dbo.ff_TablaEncabezadoDetalle TEDRegimen
            ON TERegimen.ENClave = TEDRegimen.TEEnClave
         WHERE TERegimen.ENIdEmpresa = ADO.EMIdEmpresa
           AND TERegimen.ENNombreCampo = ''EMRegimen''
           AND TEDRegimen.TEIdDetalle = ADO.EMRegimen),
        (SELECT TOP 1 CE.Regimen
         FROM dbo.bf_ConstanciaEmpleado CE
         WHERE CE.IdEmpleado = ADO.Id
         ORDER BY CE.Id DESC)
    )';

-- Esta variante conserva las comillas escapadas dentro del SQL dinamico de los SP v2.
DECLARE @ExpresionNuevaDinamica nvarchar(max) = N'COALESCE(
        (SELECT TOP 1 TEDRegimen.TEDescripcion
         FROM dbo.ff_TablaEncabezado TERegimen
         INNER JOIN dbo.ff_TablaEncabezadoDetalle TEDRegimen
            ON TERegimen.ENClave = TEDRegimen.TEEnClave
         WHERE TERegimen.ENIdEmpresa = ADO.EMIdEmpresa
           AND TERegimen.ENNombreCampo = ''''EMRegimen''''
           AND TEDRegimen.TEIdDetalle = ADO.EMRegimen),
        (SELECT TOP 1 CE.Regimen
         FROM dbo.bf_ConstanciaEmpleado CE
         WHERE CE.IdEmpleado = ADO.Id
         ORDER BY CE.Id DESC)
    )';

DECLARE
    @Nombre sysname,
    @EsDinamico bit,
    @NombreCompleto nvarchar(517),
    @Definicion nvarchar(max),
    @Reemplazo nvarchar(max),
    @Coincidencias int,
    @PosicionProcedure int,
    @Mensaje nvarchar(2048);

DECLARE Procedimientos CURSOR LOCAL FAST_FORWARD FOR
    SELECT Nombre, EsDinamico
    FROM @Procedimientos
    ORDER BY Nombre;

BEGIN TRY
    BEGIN TRANSACTION;

    OPEN Procedimientos;
    FETCH NEXT FROM Procedimientos INTO @Nombre, @EsDinamico;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @NombreCompleto = N'dbo.' + QUOTENAME(@Nombre);

        IF OBJECT_ID(@NombreCompleto, N'P') IS NULL
        BEGIN
            SET @Mensaje = N'No existe el procedimiento ' + @NombreCompleto + N'. No se aplicaron cambios.';
            THROW 51001, @Mensaje, 1;
        END;

        SET @Definicion = OBJECT_DEFINITION(OBJECT_ID(@NombreCompleto, N'P'));
        SET @Coincidencias =
            (LEN(@Definicion) - LEN(REPLACE(@Definicion, @ExpresionAnterior, N''))) /
            LEN(@ExpresionAnterior);

        IF @Coincidencias <> 1
        BEGIN
            SET @Mensaje = N'La definicion de ' + @NombreCompleto
                + N' no contiene exactamente una expresion esperada. No se aplicaron cambios.';
            THROW 51002, @Mensaje, 1;
        END;

        SET @Reemplazo = CASE WHEN @EsDinamico = 1
            THEN @ExpresionNuevaDinamica
            ELSE @ExpresionNueva
        END;

        SET @Definicion = REPLACE(@Definicion, @ExpresionAnterior, @Reemplazo);
        SET @PosicionProcedure = CHARINDEX(N'PROCEDURE', UPPER(@Definicion));

        IF @PosicionProcedure = 0
        BEGIN
            SET @Mensaje = N'No se pudo preparar ALTER PROCEDURE para ' + @NombreCompleto + N'.';
            THROW 51003, @Mensaje, 1;
        END;

        SET @Definicion = STUFF(@Definicion, 1, @PosicionProcedure - 1, N'ALTER ');
        EXEC sys.sp_executesql @Definicion;

        PRINT N'Actualizado: ' + @NombreCompleto;
        FETCH NEXT FROM Procedimientos INTO @Nombre, @EsDinamico;
    END;

    CLOSE Procedimientos;
    DEALLOCATE Procedimientos;
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF CURSOR_STATUS('local', 'Procedimientos') >= 0
        CLOSE Procedimientos;
    IF CURSOR_STATUS('local', 'Procedimientos') > -3
        DEALLOCATE Procedimientos;
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;

PRINT N'Los cuatro procedimientos ahora priorizan ff_Empleado.EMRegimen.';

