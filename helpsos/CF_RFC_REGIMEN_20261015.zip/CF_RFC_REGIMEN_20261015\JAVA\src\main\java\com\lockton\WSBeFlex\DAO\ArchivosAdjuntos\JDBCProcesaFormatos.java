package com.lockton.WSBeFlex.DAO.ArchivosAdjuntos;

import com.lockton.WSBeFlex.DAO.ArchivosAdjuntos.ProcesaFormatosDAO.DatosConstanciaFiscal;
import java.sql.Types;
import java.text.Normalizer;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCProcesaFormatos implements ProcesaFormatosDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void validarPropietario(int idEmpleado, DatosConstanciaFiscal datos) {
        List<Map<String, Object>> empleados = jdbcTemplate.queryForList(
                "SELECT EMrfc FROM ff_Empleado WHERE Id = ?", idEmpleado);

        if (empleados.isEmpty()) {
            throw new IllegalArgumentException("No se encontro el empleado indicado");
        }

        String rfcEmpleado = obtenerRfcSinHomoclave(empleados.get(0).get("EMrfc"));
        String rfcConstancia = obtenerRfcSinHomoclave(datos.getRfc());

        if (rfcEmpleado.isEmpty()) {
            throw new IllegalArgumentException(
                    "El empleado no tiene RFC registrado y no fue posible validar la constancia");
        }
        if (!rfcEmpleado.equals(rfcConstancia)) {
            throw new IllegalArgumentException(
                    "La constancia no pertenece al empleado porque el RFC no coincide. No se cargaron los datos");
        }
    }

    @Override
    public String guardarDatos(int idEmpleado, int idAdministrador, DatosConstanciaFiscal datos) {
        SimpleJdbcCall llamada = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_AltaConstanciaEmpleado")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("IdEmpleado", Types.INTEGER),
                        new SqlParameter("IdAdministrador", Types.INTEGER),
                        new SqlParameter("LugarFechaEmision", Types.VARCHAR),
                        new SqlParameter("FechaEmision", Types.VARCHAR),
                        new SqlParameter("RFC", Types.VARCHAR),
                        new SqlParameter("CURP", Types.VARCHAR),
                        new SqlParameter("CodigoPostal", Types.VARCHAR),
                        new SqlParameter("TipoVialidad", Types.VARCHAR),
                        new SqlParameter("NombreVialidad", Types.VARCHAR),
                        new SqlParameter("NoExterior", Types.VARCHAR),
                        new SqlParameter("NoInterior", Types.VARCHAR),
                        new SqlParameter("NombreColonia", Types.VARCHAR),
                        new SqlParameter("NombreLocalidad", Types.VARCHAR),
                        new SqlParameter("NombreEntidadFederativa", Types.VARCHAR),
                        new SqlParameter("CorreoElectronico", Types.VARCHAR),
                        new SqlParameter("Telefono", Types.VARCHAR),
                        new SqlParameter("Regimen", Types.VARCHAR),
                        new SqlOutParameter("NombreArchivo", Types.VARCHAR));

        Map<String, Object> parametros = new HashMap<String, Object>();
        parametros.put("IdEmpleado", idEmpleado);
        parametros.put("IdAdministrador", idAdministrador);
        parametros.put("LugarFechaEmision", datos.getLugarFechaEmision());
        parametros.put("FechaEmision", datos.getFechaEmision());
        parametros.put("RFC", datos.getRfc());
        parametros.put("CURP", datos.getCurp());
        parametros.put("CodigoPostal", datos.getCodigoPostal());
        parametros.put("TipoVialidad", datos.getTipoVialidad());
        parametros.put("NombreVialidad", datos.getNombreVialidad());
        parametros.put("NoExterior", datos.getNoExterior());
        parametros.put("NoInterior", datos.getNoInterior());
        parametros.put("NombreColonia", datos.getNombreColonia());
        parametros.put("NombreLocalidad", datos.getNombreLocalidad());
        parametros.put("NombreEntidadFederativa", datos.getNombreEntidadFederativa());
        parametros.put("CorreoElectronico", datos.getCorreoElectronico());
        parametros.put("Telefono", datos.getTelefono());
        parametros.put("Regimen", datos.getRegimen());

        Map<String, Object> resultado = llamada.execute(new MapSqlParameterSource(parametros));
        Object nombreArchivo = resultado.get("NombreArchivo");
        if (nombreArchivo == null || nombreArchivo.toString().trim().isEmpty()) {
            throw new IllegalStateException("No fue posible generar la ruta de la constancia");
        }
        return nombreArchivo.toString().trim();
    }

    private String normalizarIdentificador(Object valor) {
        if (valor == null || "NULL".equalsIgnoreCase(valor.toString().trim())) {
            return "";
        }
        return Normalizer.normalize(valor.toString(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .replaceAll("[^A-Za-z0-9&]", "")
                .toUpperCase(Locale.ROOT);
    }

    private String obtenerRfcSinHomoclave(Object valor) {
        String rfc = normalizarIdentificador(valor);
        if (rfc.length() == 12 || rfc.length() == 13) {
            return rfc.substring(0, rfc.length() - 3);
        }
        return rfc;
    }
}
