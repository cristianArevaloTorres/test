# Comandos de aplicacion y Git

## Backend Java

Copiar primero el contenido de `JAVA/src` sobre `src` del backend.

```powershell
$RepoBack = 'C:\repo\helpsoso\back'
Set-Location -LiteralPath $RepoBack

if (-not (Test-Path -LiteralPath '.git')) {
    throw "Esta carpeta no es un clon Git: $RepoBack"
}

$Archivo = 'src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/JDBCProcesaFormatos.java'

git status --short
git add -- $Archivo
git diff --cached --check
git diff --cached -- $Archivo
git commit -m "Valida propietario por RFC sin homoclave"

$Branch = (git branch --show-current).Trim()
if ([string]::IsNullOrWhiteSpace($Branch)) {
    throw 'No se pudo determinar la rama actual.'
}
git push -u origin $Branch
```

El `push` utiliza `$Branch`; no debe escribirse `git push -u origin $`.

## Base de datos

Desde la carpeta raiz extraida del ZIP:

```powershell
$Servidor = '(localdb)\MSSQLLocalDB'
$BaseDatos = 'FlexiForbesv2'

sqlcmd -S $Servidor -d $BaseDatos -E -b -f 65001 -i '.\BD\01_actualiza_regimen_reporte.sql'
if ($LASTEXITCODE -ne 0) { throw 'No se pudo aplicar el cambio de regimen.' }

sqlcmd -S $Servidor -d $BaseDatos -E -b -f 65001 -i '.\BD\02_valida_regimen_reporte.sql'
if ($LASTEXITCODE -ne 0) { throw 'La validacion de los procedimientos no fue correcta.' }
```

Para otro ambiente, cambiar solamente `$Servidor` y `$BaseDatos` despues de confirmar el destino.

Reversa, solo si fuera necesaria:

```powershell
sqlcmd -S $Servidor -d $BaseDatos -E -b -f 65001 -i '.\BD\99_reversa_regimen_reporte.sql'
if ($LASTEXITCODE -ne 0) { throw 'No se pudo revertir el cambio de regimen.' }
```

No hay archivos de frontend que copiar o registrar en Git.

