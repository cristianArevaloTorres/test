package com.lockton.rpt.models.dto.crea17;

public class PlantillaCatalogoGuardarRequestDTO {
    private Integer idPlantilla;
    private String tipo;
    private Integer idCorporativo;
    private String nombre;
    private String descripcion;
    private Integer idIdioma;
    private Integer idTipoArchivo;
    private Integer idTamanoDocumento;
    private String orientacion;
    private Integer idUsuario;

    public Integer getIdPlantilla() {
        return idPlantilla;
    }

    public void setIdPlantilla(Integer idPlantilla) {
        this.idPlantilla = idPlantilla;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getIdCorporativo() {
        return idCorporativo;
    }

    public void setIdCorporativo(Integer idCorporativo) {
        this.idCorporativo = idCorporativo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getIdIdioma() {
        return idIdioma;
    }

    public void setIdIdioma(Integer idIdioma) {
        this.idIdioma = idIdioma;
    }


    public Integer getIdTipoArchivo() {
        return idTipoArchivo;
    }

    public void setIdTipoArchivo(Integer idTipoArchivo) {
        this.idTipoArchivo = idTipoArchivo;
    }

    public Integer getIdTamanoDocumento() {
        return idTamanoDocumento;
    }

    public void setIdTamanoDocumento(Integer idTamanoDocumento) {
        this.idTamanoDocumento = idTamanoDocumento;
    }

    public String getOrientacion() {
        return orientacion;
    }

    public void setOrientacion(String orientacion) {
        this.orientacion = orientacion;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }
}
