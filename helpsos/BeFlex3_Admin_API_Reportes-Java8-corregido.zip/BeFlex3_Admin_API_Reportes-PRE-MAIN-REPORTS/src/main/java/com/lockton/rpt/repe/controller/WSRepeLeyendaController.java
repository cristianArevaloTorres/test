package com.lockton.rpt.repe.controller;

import com.lockton.rpt.repe.dto.RepeApiResponse;
import com.lockton.rpt.repe.dto.RepeEstatusRequest;
import com.lockton.rpt.repe.dto.RepeLeyendaRequest;
import com.lockton.rpt.repe.service.RepeLeyendaService;
import com.lockton.rpt.util.SafeApiError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/beflex/reporte-estadisticas/repe/leyendas")
public class WSRepeLeyendaController {
    private static final Logger LOGGER = LoggerFactory.getLogger(WSRepeLeyendaController.class);
    private final RepeLeyendaService service;

    public WSRepeLeyendaController(RepeLeyendaService service) {
        this.service = service;
    }

    private <T> ResponseEntity<RepeApiResponse<T>> ok(String code, T data) {
        return ResponseEntity.ok(RepeApiResponse.ok(code, "Operación completada.", data));
    }

    private <T> ResponseEntity<RepeApiResponse<T>> error(String code, Exception ex) {
        LOGGER.error("REPE leyendas [{}]", code, ex);
        HttpStatus status = SafeApiError.isInfrastructureFailure(ex)
                ? HttpStatus.SERVICE_UNAVAILABLE
                : HttpStatus.BAD_REQUEST;
        return ResponseEntity.status(status)
                .body(RepeApiResponse.<T>fail(
                        code,
                        SafeApiError.publicMessage(ex, "No fue posible completar la operación. Intenta nuevamente."),
                        null));
    }

    @GetMapping
    public ResponseEntity<?> listar(
            @RequestParam(required = false) Integer idConsulta,
            @RequestParam(required = false) String idioma,
            @RequestParam(defaultValue = "false") boolean incluirBajas,
            @RequestParam(defaultValue = "true") boolean incluirGlobales) {
        try { return ok("REPE-LE-LIST", service.listar(idConsulta, idioma, incluirBajas, incluirGlobales)); }
        catch (Exception ex) { return error("REPE-LE-ERR", ex); }
    }

    @GetMapping("/resolver")
    public ResponseEntity<?> resolver(
            @RequestParam(required = false) Integer idConsulta,
            @RequestParam String clave,
            @RequestParam(required = false) String idioma,
            @RequestParam(required = false) String claveCondicion) {
        try { return ok("REPE-LE-RESOLVE", service.resolver(idConsulta, clave, idioma, claveCondicion)); }
        catch (Exception ex) { return error("REPE-LE-ERR", ex); }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtener(@PathVariable int id, @RequestParam(required = false) String idioma) {
        try { return ok("REPE-LE-GET", service.obtener(id, idioma)); }
        catch (Exception ex) { return error("REPE-LE-ERR", ex); }
    }

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody RepeLeyendaRequest request) {
        try { return ok("REPE-LE-SAVE", service.guardar(null, request)); }
        catch (Exception ex) { return error("REPE-LE-ERR", ex); }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editar(@PathVariable int id, @RequestBody RepeLeyendaRequest request) {
        try { return ok("REPE-LE-SAVE", service.guardar(Integer.valueOf(id), request)); }
        catch (Exception ex) { return error("REPE-LE-ERR", ex); }
    }

    @PutMapping("/{id}/estatus")
    public ResponseEntity<?> estatus(@PathVariable int id, @RequestBody RepeEstatusRequest request) {
        try { return ok("REPE-LE-STATUS", service.estatus(id, request)); }
        catch (Exception ex) { return error("REPE-LE-STATUS-ERR", ex); }
    }
}
