package com.lockton.rpt.services.impl;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lockton.rpt.mappers.CatStsRptGenMapper;
import com.lockton.rpt.mappers.CtlRptGenMapper;
import com.lockton.rpt.models.dto.CatalogoEstatusReporteGenDTO;
import com.lockton.rpt.models.dto.ControlReporteGenDTO;
import com.lockton.rpt.models.entities.CatalogoEstatusReporteGen;
import com.lockton.rpt.models.entities.ControlReporteGen;
import com.lockton.rpt.models.entities.VwControlReporte;
import com.lockton.rpt.repositories.CatStsRptGenRepository;
import com.lockton.rpt.repositories.CtlRptGenRepository;
import com.lockton.rpt.repositories.FiltroRepository;
import com.lockton.rpt.services.ReporteSeguimientoService;
import com.lockton.rpt.models.dto.ItemReporteDTO;
import com.lockton.rpt.models.entities.CatalogoReporteGen;
import com.lockton.rpt.mappers.RptItemMapper;
import com.lockton.rpt.repositories.CatRptGenRepository;

@Service
public class ReporteSeguimientoServiceImpl implements ReporteSeguimientoService{

    @Autowired
    private CtlRptGenRepository repository;
    @Autowired
    private CatStsRptGenRepository repositoryEstatus;
    @Autowired
    private CatRptGenRepository repositoryCatRpt;
    @Autowired
    private FiltroRepository filtroRepository;

    @Override
    public List<ControlReporteGenDTO> getAll() {
        List<ControlReporteGenDTO> dtos = null;
        List<ControlReporteGen> cats = repository.findAll();
        if(!cats.isEmpty())
            dtos = CtlRptGenMapper.MapperDTO(cats);
        return dtos;
    }

    @Override
    public List<VwControlReporte> buscar(Integer idEmpresa, Integer idEmpleado, Integer idRpt, Integer estatus, LocalDate fechaInicio, LocalDate fechaFinal) {
        List<VwControlReporte> ls = null;
        try {
            Date sqlFInicio = fechaInicio != null ? java.sql.Date.valueOf(fechaInicio) : java.sql.Date.valueOf("2000-01-01");
            Date sqlFFin = fechaFinal != null ? java.sql.Date.valueOf(fechaFinal) : new java.sql.Date(new java.util.Date().getTime());
            ls = filtroRepository.buscar(idEmpresa, idEmpleado, idRpt, estatus, sqlFInicio, sqlFFin);
        }
        catch(Exception ex){
            ls = null;
        }
        return ls;
    }

    @Override
    public List<CatalogoEstatusReporteGenDTO> getEstatus() {
        List<CatalogoEstatusReporteGenDTO> dtos = null;
        List<CatalogoEstatusReporteGen> cats = repositoryEstatus.findAll();
        if(!cats.isEmpty())
            dtos = CatStsRptGenMapper.MapperDTO(cats);
        return dtos;
    }

    @Override
    public List<ItemReporteDTO> getReportes() {
        List<ItemReporteDTO> dtos = null;
        List<CatalogoReporteGen> cats = repositoryCatRpt.findAll();
        if(!cats.isEmpty())
            dtos = RptItemMapper.MapperDTO(cats);
        return dtos;
    }
}
