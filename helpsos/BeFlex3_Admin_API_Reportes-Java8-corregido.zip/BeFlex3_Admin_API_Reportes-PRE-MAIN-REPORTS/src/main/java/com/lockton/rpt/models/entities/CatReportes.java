package com.lockton.rpt.models.entities;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "bf_CatReportes")
public class CatReportes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "catReportesId")
    private Integer catReportesId;

    @Column(name = "catReportesNombre", length = 100, nullable = false, unique = true)
    private String catReportesNombre;

    @Column(name = "catReportesDesc", length = 150)
    private String catReportesDesc;
    
    @Column(name = "catReportesTAId")
    private Integer catReportesTAId;
    
    @Column(name = "catReportesFormato", length = 150)
    private String catReportesFormato;

    @Column(name = "Esid")
    private Integer esid;

    @Column(name = "catReportesUsuarioAdd")
    private Integer catReportesUsuarioAdd;

    @Column(name = "catReportesFechaAdd")
    private LocalDateTime catReportesFechaAdd;

    @Column(name = "catReportesUsuarioMod")
    private Integer catReportesUsuarioMod;

    @Column(name = "catReportesFechaMod")
    private LocalDateTime catReportesFechaMod;
    
    @Column(name = "catTipoReporteId")
    private Integer catTipoReporteId;
    
    @Column(name = "catReportesNum")
    private Integer catReportesNum;
}