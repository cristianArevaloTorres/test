package com.lockton.rpt.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lockton.rpt.models.dto.CatReportesCabecerosDTO;
import com.lockton.rpt.models.dto.CatReportesDTO;
import com.lockton.rpt.models.dto.CatReportesSPDTO;
import com.lockton.rpt.models.dto.CatReportesTipoArchivoDTO;
import com.lockton.rpt.models.dto.CatReportesTipoDatosDTO;
import com.lockton.rpt.models.dto.ResponseCreateReportDTO;
import com.lockton.rpt.models.entities.CatReportes;
import com.lockton.rpt.models.request.CreateReporteRequest;
import com.lockton.rpt.services.CatReportesCabecerosService;
import com.lockton.rpt.services.CatReportesParamsService;
import com.lockton.rpt.services.CatReportesSPService;
import com.lockton.rpt.services.CatReportesService;
import com.lockton.rpt.services.CatReportesTipoArchivoService;
import com.lockton.rpt.services.CatReportesTipoDatosService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/beflex/reportes/DBconfiguracion")
@Api(tags = "Controlador para pantalla de configuración de reportes")
public class ReportesDBConfigController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportesDBConfigController.class);

    @Autowired
    CatReportesSPService catReportesSPService;
    @Autowired
    CatReportesParamsService catReportesParamsService;
    @Autowired
    CatReportesCabecerosService catReportesCabecerosService;
    @Autowired
    CatReportesService catReportesService;
    @Autowired
    CatReportesTipoArchivoService catReportesTipoArchivoService; 
    @Autowired
    CatReportesTipoDatosService catReportesTipoDatosService;

    @GetMapping(value = "/existsReportName")
    @ApiOperation(value = "Validar Nombre del reporte.",
                  notes = "Operacion encargada de validar si un reporte no se duplica.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<Map<String, Object>> existsReportName(
        @ApiParam(value = "Valores de la aplicacion a filtrar", required = false) 
        @RequestParam String nameReport) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> existsReportName... " +  nameReport);
        
        Map<String, Object> response = new HashMap<>();
        
        List<CatReportes> catLst = this.catReportesService.findBycatReportesNombre(nameReport);

        if(catLst.toArray().length > 0){
            response.put("messages", "El valor " + nameReport + " no está disponible");
            response.put("success", false);
        }
        else{
            response.put("messages", "El valor " + nameReport + " esta disponible");
            response.put("success", true);
        }
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/getAllFileTypes")
    @ApiOperation(value = "Obtener Tipos de Archivos.",
                  notes = "Operacion encargada de regresar los tipos de reportes.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<List<CatReportesTipoArchivoDTO>> getAllFileTypes() 
    {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> getAllFileTypes... ");        
        List<CatReportesTipoArchivoDTO> catLst = this.catReportesTipoArchivoService.getAllFileTypes();
        return ResponseEntity.ok(catLst);
    }

    @GetMapping(value = "/getAllParamsTypes")
    @ApiOperation(value = "Obtener los Tipos de Datos.",
                  notes = "Operacion encargada de recuperar los tipos de datos.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<Map<String, Object>> getAllParamsTypes() {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> getAllParamsTypes... ");
        Map<String, Object> response = new HashMap<>();
        List<CatReportesTipoDatosDTO> catLst = this.catReportesTipoDatosService.getAll();
        if(catLst.toArray().length > 0){
            response.put("messages", "Información disponible");
            response.put("success", true);
            response.put("data", catLst);
        }
        else{
            response.put("messages", "No se cuneta con información  disponible");
            response.put("success", false);
            response.put("data", catLst);
        }
        return ResponseEntity.ok(response);
    }

    @PostMapping(value = "/agregarReporte")
    @ApiOperation(value = "Creación de reporte.", notes = "Operacion encargada de establecer guardar la configuración de Sp's asociadas a un reporte.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<CatReportesDTO> agregarReporte(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) @RequestBody CatReportesDTO catReportesDTO) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> agregarReporte... " +  catReportesDTO);
        return ResponseEntity.ok().body(catReportesService.create(catReportesDTO));
    }

    @GetMapping(value = "/obtenerSP")
    @ApiOperation(value = "Obtención de Stored Procedures.", notes = "Operacion encargada de obtener todos los SP's.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<List<CatReportesSPDTO>> obtenerSPs() {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> obtenerSPs... ");        
        return null; // ResponseEntity.ok().body(catReportesSPService.findAll());
    }

    @GetMapping(value = "/obtenerCabeceros")
    @ApiOperation(value = "Obtención de cabeceros.", notes = "Operacion encargada de obtener todos los cabeceros.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<List<CatReportesCabecerosDTO>> obtenerCabeceros() {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> obtenerCabeceros... ");        
        return null;
        //return ResponseEntity.ok().body(catReportesCabecerosService.findAll());
    }

    @DeleteMapping(value = "/cancelReport")
    @ApiOperation(value = "Baja Logica de un Reporte.",
                  notes = "Operacion encargada de dar baja logica de un reporte.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<Map<String, Object>> cancelReport(
        @ApiParam(value = "Valores de la aplicacion a filtrar", required = false) 
        @RequestBody int idReport) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> cancelReport... ");
        
        Map<String, Object> response = new HashMap<>();
        
        boolean request = this.catReportesService.deleteLogic(idReport);

        if(request){
            response.put("messages", "El Reporte fue cancelado Exitosamente");
            response.put("success", false);
        }
        else{
            response.put("messages", "El Reporte No fue cancelado.");
            response.put("success", true);
        }
        return ResponseEntity.ok(response);
    }

    @PostMapping("/createReportes")
    @ApiOperation(value = "Crear Nuevo Reporte.",
                  notes = "Con sus configuraciones.")
    public ResponseEntity<ResponseCreateReportDTO> crearReporte(@RequestBody CreateReporteRequest request){
        ResponseCreateReportDTO response = new ResponseCreateReportDTO();
        response = this.catReportesService.createNewReport(request);            
        return ResponseEntity.ok(response);
    }
}