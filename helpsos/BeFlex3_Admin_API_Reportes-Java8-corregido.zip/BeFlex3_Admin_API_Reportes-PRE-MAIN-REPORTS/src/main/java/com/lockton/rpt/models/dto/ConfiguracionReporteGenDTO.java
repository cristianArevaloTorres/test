package com.lockton.rpt.models.dto;

import java.util.Date;
import lombok.Data;

@Data
public class ConfiguracionReporteGenDTO {
    private Long CfgRptId;
    private String CfgRptClave;
    private String CfgRptValor;
    private String CfgRptDescripcion;
    private Integer CfgRptUsuarioAdd;
    private Date CfgRptFechaAdd;
}