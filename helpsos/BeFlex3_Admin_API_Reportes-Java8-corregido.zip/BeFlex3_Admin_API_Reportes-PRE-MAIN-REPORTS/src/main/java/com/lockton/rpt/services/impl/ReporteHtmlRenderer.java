package com.lockton.rpt.services.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Component;

/**
 * Vista previa HTML con las mismas reglas de flujo/ancho que generar_reporte_documento.py (PDF).
 */
@Component
public class ReporteHtmlRenderer {

    private static final int EXCEL_MAX_ROWS = 48;
    private static final double DEFAULT_GRAPH_WIDTH_PCT = 50.0;
    private static final double DEFAULT_TABLE_WIDTH_PCT = 100.0;
    private static final int LEGACY_REF_WIDTH_PX = 1200;
    private static final int LEGACY_REF_HEIGHT_PX = 450;
    private static final int EXCEL_PAGE_WIDTH_PX = 960;
    private static final int EXCEL_ROW_PX = 18;
    private static final int TITLE_ROWS = 1;

    public String render(Map<String, Object> payload) {
        StringBuilder html = new StringBuilder(8192);
        html.append("<div class=\"crea017-reporte-preview\">");
        boolean incluirPortadasSeccion = boolOrDefault(payload.get("incluirPortadasSeccion"), false);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> secciones = (List<Map<String, Object>>) payload.get("secciones");
        if (secciones != null) {
            for (Map<String, Object> sec : secciones) {
                renderSeccion(html, sec, incluirPortadasSeccion);
            }
        }
        html.append("</div>");
        return html.toString();
    }

    private void renderSeccion(StringBuilder html, Map<String, Object> sec, boolean incluirPortada) {
        html.append("<section class=\"crea017-reporte-seccion\">");
        if (incluirPortada) {
            html.append("<div class=\"crea017-seccion-portada\">");
            html.append("<h2 class=\"crea017-seccion-titulo\">").append(esc(sec.get("titulo"))).append("</h2>");
            if (sec.get("descripcion") != null && !String.valueOf(sec.get("descripcion")).trim().isEmpty()) {
                html.append("<p class=\"crea017-seccion-descripcion\">").append(esc(sec.get("descripcion")))
                        .append("</p>");
            }
            if (sec.get("notas") != null && !String.valueOf(sec.get("notas")).trim().isEmpty()) {
                html.append("<p class=\"crea017-seccion-notas\"><em>").append(esc(sec.get("notas"))).append("</em></p>");
            }
            html.append("</div>");
        }
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> indicadores = (List<Map<String, Object>>) sec.get("indicadores");
        List<List<Map<String, Object>>> pages = packIndicadores(indicadores != null ? indicadores : Collections.emptyList());
        for (int p = 0; p < pages.size(); p++) {
            if (p > 0) {
                html.append("<div class=\"crea017-reporte-page-sep\" aria-hidden=\"true\"></div>");
            }
            html.append("<div class=\"crea017-reporte-page\">");
            for (List<FlowPlacement> row : groupFlowRows(pages.get(p))) {
                html.append("<div class=\"crea017-reporte-row\">");
                for (FlowPlacement placement : row) {
                    html.append("<div class=\"crea017-reporte-slot\" style=\"flex:0 0 ")
                            .append(formatPct(placement.wPct))
                            .append("%;max-width:")
                            .append(formatPct(placement.wPct))
                            .append("%;\">");
                    renderIndicador(html, placement.ind);
                    html.append("</div>");
                }
                html.append("</div>");
            }
            html.append("</div>");
        }
        html.append("</section>");
    }

    private void renderIndicador(StringBuilder html, Map<String, Object> ind) {
        html.append("<article class=\"crea017-indicador\" data-id=\"").append(esc(ind.get("id"))).append("\">");
        if (boolOrDefault(ind.get("mostrarTitulo"), true)) {
            html.append("<h3 class=\"crea017-indicador-titulo\">").append(esc(ind.get("nombre"))).append("</h3>");
        }
        if (ind.get("error") != null) {
            html.append("<p class=\"crea017-indicador-error\">").append(esc(ind.get("error"))).append("</p>");
        } else {
            if (ind.get("errorGrafica") != null) {
                html.append("<p class=\"crea017-indicador-grafica-error\">Gráfica: ")
                        .append(esc(ind.get("errorGrafica"))).append("</p>");
            }
            Object graficaB64 = ind.get("graficaBase64");
            if (graficaB64 != null && !isTabla(ind)) {
                html.append("<figure class=\"crea017-indicador-grafica\">")
                        .append("<img src=\"data:image/png;base64,").append(String.valueOf(graficaB64).trim())
                        .append("\" alt=\"").append(esc(ind.get("nombre"))).append("\" />")
                        .append("</figure>");
            } else {
                renderTabla(html, ind);
            }
        }
        html.append("</article>");
    }

    @SuppressWarnings("unchecked")
    private void renderTabla(StringBuilder html, Map<String, Object> ind) {
        Map<String, Object> tabla = (Map<String, Object>) ind.get("tabla");
        if (tabla == null) {
            return;
        }
        List<String> columnas = (List<String>) tabla.get("columnas");
        List<List<Object>> filas = (List<List<Object>>) tabla.get("filas");
        if (columnas == null || columnas.isEmpty()) {
            return;
        }
        html.append("<div class=\"crea017-indicador-tabla-wrap\"><table class=\"crea017-indicador-tabla\">");
        html.append("<thead><tr>");
        for (String col : columnas) {
            html.append("<th>").append(esc(col)).append("</th>");
        }
        html.append("</tr></thead><tbody>");
        if (filas != null) {
            for (List<Object> row : filas) {
                html.append("<tr>");
                for (int i = 0; i < columnas.size(); i++) {
                    Object val = row != null && i < row.size() ? row.get(i) : "";
                    html.append("<td>").append(esc(val)).append("</td>");
                }
                html.append("</tr>");
            }
        }
        html.append("</tbody></table></div>");
    }

    private List<List<Map<String, Object>>> packIndicadores(List<Map<String, Object>> indicadores) {
        List<List<Map<String, Object>>> pages = new ArrayList<>();
        List<Map<String, Object>> current = new ArrayList<>();
        for (Map<String, Object> ind : indicadores) {
            List<Map<String, Object>> trial = new ArrayList<>(current);
            trial.add(ind);
            List<FlowPlacement> layout = flowLayout(trial);
            int totalRows = 0;
            if (!layout.isEmpty()) {
                FlowPlacement last = layout.get(layout.size() - 1);
                totalRows = last.yRows + last.hRows;
            }
            if (!current.isEmpty() && totalRows > EXCEL_MAX_ROWS) {
                pages.add(current);
                current = new ArrayList<>();
                current.add(ind);
            } else {
                current = trial;
            }
        }
        if (!current.isEmpty()) {
            pages.add(current);
        }
        if (pages.isEmpty()) {
            pages.add(Collections.emptyList());
        }
        return pages;
    }

    private List<List<FlowPlacement>> groupFlowRows(List<Map<String, Object>> page) {
        Map<Integer, List<FlowPlacement>> byRow = new TreeMap<>();
        for (FlowPlacement placement : flowLayout(page)) {
            List<FlowPlacement> row = byRow.get(placement.yRows);
            if (row == null) {
                row = new ArrayList<>();
                byRow.put(placement.yRows, row);
            }
            row.add(placement);
        }
        return new ArrayList<>(byRow.values());
    }

    private List<FlowPlacement> flowLayout(List<Map<String, Object>> page) {
        List<FlowPlacement> placements = new ArrayList<>();
        int yRows = 0;
        double xPct = 0.0;
        int rowHeight = 0;
        for (Map<String, Object> ind : page) {
            double widthPct = widthPct(ind);
            int heightRows = indicatorHeightRows(ind, widthPct);
            if (xPct + widthPct > 100.0 && xPct > 0) {
                yRows += rowHeight + 1;
                xPct = 0.0;
                rowHeight = 0;
            }
            placements.add(new FlowPlacement(ind, xPct, yRows, widthPct, heightRows));
            rowHeight = Math.max(rowHeight, heightRows);
            xPct += widthPct;
            if (xPct >= 100.0) {
                yRows += rowHeight + 1;
                xPct = 0.0;
                rowHeight = 0;
            }
        }
        return placements;
    }

    private int indicatorHeightRows(Map<String, Object> ind, double contentWidthPct) {
        if (isTabla(ind)) {
            @SuppressWarnings("unchecked")
            Map<String, Object> tabla = (Map<String, Object>) ind.get("tabla");
            int filas = 0;
            if (tabla != null) {
                @SuppressWarnings("unchecked")
                List<List<Object>> rows = (List<List<Object>>) tabla.get("filas");
                filas = rows != null ? rows.size() : 0;
            }
            int title = boolOrDefault(ind.get("mostrarTitulo"), true) ? TITLE_ROWS : 0;
            return title + 1 + filas;
        }
        int title = boolOrDefault(ind.get("mostrarTitulo"), true) ? TITLE_ROWS : 0;
        int bodyRows = Math.max(10, (int) (imageHeightPx(ind, contentWidthPct) / EXCEL_ROW_PX));
        return title + bodyRows;
    }

    private int imageHeightPx(Map<String, Object> ind, double contentWidthPct) {
        double widthPct = contentWidthPct > 0 ? contentWidthPct : widthPct(ind);
        int widthPx = Math.max(1, (int) (EXCEL_PAGE_WIDTH_PX * widthPct / 100.0));
        return Math.max(1, (int) (widthPx * aspectRatio(ind)));
    }

    private double aspectRatio(Map<String, Object> ind) {
        int[] size = imagePixelSize(ind);
        if (size[0] > 0 && size[1] > 0) {
            return (double) size[1] / (double) size[0];
        }
        return (double) LEGACY_REF_HEIGHT_PX / (double) LEGACY_REF_WIDTH_PX;
    }

    private int[] imagePixelSize(Map<String, Object> ind) {
        Object b64Obj = ind.get("graficaBase64");
        if (b64Obj == null) {
            return new int[] { LEGACY_REF_WIDTH_PX, LEGACY_REF_HEIGHT_PX };
        }
        try {
            byte[] img = java.util.Base64.getDecoder().decode(String.valueOf(b64Obj).trim());
            if (img.length >= 24 && img[0] == (byte) 0x89 && img[1] == 'P' && img[2] == 'N' && img[3] == 'G') {
                int w = ((img[16] & 0xff) << 24) | ((img[17] & 0xff) << 16) | ((img[18] & 0xff) << 8) | (img[19] & 0xff);
                int h = ((img[20] & 0xff) << 24) | ((img[21] & 0xff) << 16) | ((img[22] & 0xff) << 8) | (img[23] & 0xff);
                if (w > 0 && h > 0) {
                    return new int[] { w, h };
                }
            }
        } catch (IllegalArgumentException ignored) {
            // usar legacy
        }
        return new int[] { LEGACY_REF_WIDTH_PX, LEGACY_REF_HEIGHT_PX };
    }

    private boolean isTabla(Map<String, Object> ind) {
        return "TABLA".equalsIgnoreCase(String.valueOf(ind.get("tipo")));
    }

    private double widthPct(Map<String, Object> ind) {
        if (isTabla(ind)) {
            return toPct(ind.get("ancho"), DEFAULT_TABLE_WIDTH_PCT, LEGACY_REF_WIDTH_PX);
        }
        return toPct(ind.get("ancho"), DEFAULT_GRAPH_WIDTH_PCT, LEGACY_REF_WIDTH_PX);
    }

    private double toPct(Object raw, double defaultValue, int legacyRefPx) {
        if (raw == null) {
            return defaultValue;
        }
        try {
            double value = Double.parseDouble(String.valueOf(raw).trim());
            if (value <= 0) {
                return defaultValue;
            }
            if (value <= 100) {
                return Math.min(100.0, value);
            }
            if (legacyRefPx > 0) {
                return Math.min(100.0, (value / legacyRefPx) * 100.0);
            }
        } catch (NumberFormatException ignored) {
            return defaultValue;
        }
        return defaultValue;
    }

    private String formatPct(double pct) {
        return String.format(java.util.Locale.US, "%.4f", pct).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private boolean boolOrDefault(Object value, boolean defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }

    private String esc(Object value) {
        if (value == null) {
            return "";
        }
        return String.valueOf(value)
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    private static final class FlowPlacement {
        private final Map<String, Object> ind;
        private final double xPct;
        private final int yRows;
        private final double wPct;
        private final int hRows;

        private FlowPlacement(Map<String, Object> ind, double xPct, int yRows, double wPct, int hRows) {
            this.ind = ind;
            this.xPct = xPct;
            this.yRows = yRows;
            this.wPct = wPct;
            this.hRows = hRows;
        }
    }
}
