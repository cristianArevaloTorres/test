package com.lockton.rpt.repositories;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.lockton.rpt.util.TextUtil;

/**
 * Catálogo SP reporte estadísticas en bf_CatReportesSP / Params / RepConf_Columna.
 */
public final class BfCatReportesCatalogSupport {

    public static final int CAT_REPORTES_NUM = 10;
    public static final int SALIDA_ID_FACTOR = 10000;
    private static final String META_PREFIX = "[CREA017]";
    private static final Pattern META_PATTERN = Pattern.compile("(\\w+)=([^|]*)");

    private BfCatReportesCatalogSupport() {
    }

    public static String buildSpDesc(String clave, String nombre, String descripcion) {
        String desc = descripcion != null ? descripcion.trim() : "";
        return META_PREFIX + "clave=" + trim(clave) + "|nombre=" + trim(nombre) + "|" + desc;
    }

    public static Map<String, String> parseSpMeta(String spDesc) {
        Map<String, String> meta = new LinkedHashMap<>();
        if (spDesc == null || !spDesc.startsWith(META_PREFIX)) {
            return meta;
        }
        String body = spDesc.substring(META_PREFIX.length());
        Matcher m = META_PATTERN.matcher(body);
        while (m.find()) {
            meta.put(m.group(1), m.group(2));
        }
        return meta;
    }

    public static String metaClave(String spDesc, String spNombre) {
        Map<String, String> meta = parseSpMeta(spDesc);
        if (!TextUtil.isBlank(meta.getOrDefault("clave", ""))) {
            return meta.get("clave");
        }
        return spNombre != null ? spNombre : "";
    }

    public static String metaNombre(String spDesc, String spNombre) {
        Map<String, String> meta = parseSpMeta(spDesc);
        if (!TextUtil.isBlank(meta.getOrDefault("nombre", ""))) {
            return meta.get("nombre");
        }
        return spNombre != null ? spNombre : "";
    }

    public static String plainDescripcion(String spDesc) {
        if (spDesc == null) {
            return "";
        }
        if (!spDesc.startsWith(META_PREFIX)) {
            return spDesc;
        }
        int lastPipe = spDesc.indexOf('|', META_PREFIX.length());
        while (lastPipe >= 0) {
            int next = spDesc.indexOf('|', lastPipe + 1);
            if (next < 0) {
                return spDesc.substring(lastPipe + 1);
            }
            String segment = spDesc.substring(lastPipe + 1, next);
            if (!segment.contains("=")) {
                return spDesc.substring(lastPipe + 1);
            }
            lastPipe = next;
        }
        return "";
    }

    public static int syntheticSalidaId(int catReportesSpId, int orden) {
        return catReportesSpId * SALIDA_ID_FACTOR + orden;
    }

    public static int salidaSpId(int syntheticId) {
        return syntheticId / SALIDA_ID_FACTOR;
    }

    public static int salidaOrden(int syntheticId) {
        return syntheticId % SALIDA_ID_FACTOR;
    }

    public static String mapTipoDatoToNombre(Object tipoDatoId) {
        if (tipoDatoId == null) {
            return "NVARCHAR";
        }
        switch (((Number) tipoDatoId).intValue()) {
            case 1:
                return "INT";
            case 2:
                return "VARCHAR";
            case 3:
                return "DATETIME";
            case 4:
                return "BIT";
            case 5:
                return "BIGINT";
            case 6:
                return "NVARCHAR";
            case 7:
                return "TVP";
            default:
                return "NVARCHAR";
        }
    }

    public static int mapTipoDatoToId(String tipoDato) {
        if (tipoDato == null || TextUtil.isBlank(tipoDato)) {
            return 6;
        }
        switch (tipoDato.trim().toUpperCase()) {
            case "INT":
                return 1;
            case "VARCHAR":
                return 2;
            case "DATETIME":
            case "DATE":
            case "SMALLDATETIME":
                return 3;
            case "BIT":
                return 4;
            case "BIGINT":
                return 5;
            case "NVARCHAR":
                return 6;
            case "TVP":
                return 7;
            case "DECIMAL":
            case "NUMERIC":
            case "FLOAT":
                return 2;
            default:
                return 6;
        }
    }

    public static String defaultLongitud(int tipoDatoId) {
        switch (tipoDatoId) {
            case 1:
            case 4:
            case 5:
                return "10";
            case 3:
                return "30";
            default:
                return "255";
        }
    }

    public static Map<String, Object> mapSpRow(Map<String, Object> row) {
        Map<String, Object> out = new LinkedHashMap<>();
        Object id = row.get("catReportesSPId");
        String spNombre = stringVal(row.get("catReportesSPNombre"));
        String spDesc = stringVal(row.get("catReportesSPDesc"));
        out.put("CESPidConfiguracionEstadisticasStoredProcedure", id);
        out.put("CESPClave", metaClave(spDesc, spNombre));
        out.put("CESPNombre", metaNombre(spDesc, spNombre));
        out.put("CESPNombreRealStoredProcedure", spNombre);
        out.put("CESPDescripcion", plainDescripcion(spDesc));
        out.put("CESPIdEstatus", row.get("ESid"));
        out.put("IdStoredProcedure", id);
        out.put("Clave", out.get("CESPClave"));
        out.put("Nombre", out.get("CESPNombre"));
        out.put("NombreReal", spNombre);
        out.put("Descripcion", out.get("CESPDescripcion"));
        return out;
    }

    public static Map<String, Object> mapParamRow(Map<String, Object> row) {
        Map<String, Object> out = new LinkedHashMap<>();
        Object tipoId = row.get("catReportesTipoDatoId");
        String paramNombre = stringVal(row.get("catReportesParamsNombre"));
        String paramDesc = stringVal(row.get("catReportesParamsDesc"));
        String nombreParam = paramNombre.startsWith("@") ? paramNombre.substring(1) : paramNombre;
        out.put("CESPPidConfiguracionEstadisticasStoredProcedureParametro", row.get("catReportesParamsId"));
        out.put("CESPPIdConfiguracionEstadisticasStoredProcedure", row.get("catReportesSPId"));
        out.put("CESPPNombreParametro", nombreParam);
        out.put("CESPPNombreVisual", TextUtil.isBlank(paramDesc) ? nombreParam : paramDesc);
        out.put("CESPPParametroSql", paramNombre.startsWith("@") ? paramNombre : "@" + paramNombre);
        out.put("CESPPTipoDato", mapTipoDatoToNombre(tipoId));
        out.put("CESPPOrden", row.get("catReportesParamsOrden"));
        out.put("CESPPObligatorio", 0);
        out.put("CESPPFiltroBase", 0);
        out.put("CESPPVisible", 1);
        out.put("CESPPIdEstatus", row.get("ESid"));
        return out;
    }

    public static Map<String, Object> mapSalidaRow(Map<String, Object> row) {
        Map<String, Object> out = new LinkedHashMap<>();
        int spId = ((Number) row.get("catReportesSPId")).intValue();
        int orden = ((Number) row.get("orden")).intValue();
        Object tipoDato = row.get("tipoDato");
        String tipoNombre = tipoDato instanceof Number ? mapTipoDatoToNombre(tipoDato) : "NVARCHAR";
        out.put("CESPSidConfiguracionEstadisticasStoredProcedureSalida", syntheticSalidaId(spId, orden));
        out.put("CESPSIdConfiguracionEstadisticasStoredProcedure", spId);
        out.put("CESPSIndiceResultSet", 0);
        out.put("CESPSNombreColumna", row.get("campoOrigen"));
        out.put("CESPSNombreVisual", row.get("encabezado"));
        out.put("CESPSTipoDato", tipoNombre);
        out.put("CESPSOrden", orden);
        out.put("CESPSIdEstatus", 1);
        return out;
    }

    private static String trim(String value) {
        return value == null ? "" : value.trim();
    }

    private static String stringVal(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
