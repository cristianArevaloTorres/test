package com.lockton.rpt.util;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;

public class Excel_Filtros {

    public static String generar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
                               Map<String, Object> parametros,
                               String outputDir) throws Exception {
        SXSSFWorkbook wb = new SXSSFWorkbook(1000);
        wb.setCompressTempFiles(true);

        // Esperamos 1 RS por archivo (Generadorreportes puede invocar por RS)
        ArrayList<LinkedCaseInsensitiveMap<?>> rows = (resultsets == null || resultsets.isEmpty()) ? null : resultsets.get(0);
        if (rows == null) rows = new ArrayList<>();

        // Preferir títulos dinámicos si vienen en parámetros:
        // - tituloReporteB1: texto para B1 ("Tipo de reporte")
        // - nombreHoja / sheetName: nombre de hoja Excel
        String reporteNombre = String.valueOf(
                firstNonNull(parametros.get("tituloReporteB1"), parametros.get("catReportesNombre"), "Reporte")
        );
        String hojaPreferida = String.valueOf(
                firstNonNull(parametros.get("nombreHoja"), parametros.get("sheetName"), reporteNombre)
        );
        String hojaNombre = limit(sanitizarNombreHoja(hojaPreferida), 31);
        Sheet sh = wb.createSheet(hojaNombre);

        // Estilos base
        CellStyle titleStyle = crearTitleStyle(sh.getWorkbook());
        // Estilo para fechas DD/MM/YYYY (sin negritas)
        org.apache.poi.ss.usermodel.CellStyle dateStyle = sh.getWorkbook().createCellStyle();
        short dateFmt = sh.getWorkbook().createDataFormat().getFormat("dd/MM/yyyy");
        dateStyle.setDataFormat(dateFmt);
        // Estilo para moneda MXN $#,##0.00
        org.apache.poi.ss.usermodel.CellStyle currencyStyle = sh.getWorkbook().createCellStyle();
        short cfmt = sh.getWorkbook().createDataFormat().getFormat("\"$\"#,##0.00");
        currencyStyle.setDataFormat(cfmt);

        // Habilitar tracking para auto-size con SXSSF ANTES de escribir datos
        try {
            if (sh instanceof SXSSFSheet) {
                ((SXSSFSheet) sh).trackAllColumnsForAutoSizing();
            }
        } catch (Throwable ignore) {}

        // Encabezado fijo
        int r = 0;
        Row r1 = sh.createRow(r++);
        crearCelda(r1, 0, "Tipo de reporte", titleStyle);
        crearCelda(r1, 1, reporteNombre, titleStyle);

        Row r2 = sh.createRow(r++);
        crearCelda(r2, 0, "Corporativo", titleStyle);
        Object corpNombre = parametros.get("corporativoNombre");
        if (corpNombre == null) {
            // Fallback: si no viene el nombre, mostrar el id recibido
            corpNombre = firstNonNull(parametros.get("admIdEmpresa"), parametros.get("idEmpresa"), parametros.get("empresas"));
        }
        crearCelda(r2, 1, corpNombre == null ? "" : String.valueOf(corpNombre), titleStyle);

        Row r3 = sh.createRow(r++);
        crearCelda(r3, 0, "Fecha Generación Reporte", titleStyle);
        String ahora = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ROOT).format(new Date());
        crearCelda(r3, 1, ahora, titleStyle);

        // Fila 4 vacía
        r++;

        // Fila 5: encabezados + filtros
        List<String> headers = new ArrayList<>();
        List<String> campos = new ArrayList<>();
        // Intentar respetar configuración de columnas (bf_RepConf_Columna) enviada en parametros.reporteConfig
        @SuppressWarnings("unchecked")
        Map<String, Object> grupoConf = obtenerGrupoConfigPrefer(parametros, safeInt(parametros.get("grupoIndex"), 0));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> columnas = grupoConf == null ? null : (List<Map<String, Object>>) grupoConf.get("columnas");

        // Tipos alineados con 'campos' (si vienen en configuración). 3 = DATETIME
        List<Integer> tipos = new ArrayList<>();
        // Metadatos opcionales por columna
        List<Integer> anchos = new ArrayList<>();
        List<String> formatos = new ArrayList<>();
        List<String> alinears = new ArrayList<>();

        // Estilo de encabezados según bf_RepConf_Tabla (colorFondo/colorLetra)
        CellStyle headerStyle = crearHeaderStyle(
                sh.getWorkbook(),
                grupoConf != null ? grupoConf.get("colorFondo") : null,
                grupoConf != null ? grupoConf.get("colorLetra") : null
        );

        // Mapa de normalización: clave normalizada -> clave real del RS
        java.util.Map<String, String> normalToActual = new java.util.HashMap<>();
        if (rows != null && !rows.isEmpty()) {
            LinkedCaseInsensitiveMap<?> first = rows.get(0);
            for (Object k : first.keySet()) {
                String actual = String.valueOf(k);
                normalToActual.put(normalizeKey(actual), actual);
            }
        }

        if (columnas != null && !columnas.isEmpty()) {
            for (Map<String, Object> col : columnas) {
                String campoCfg = String.valueOf(col.get("campoOrigen"));
                String enc = String.valueOf(col.get("encabezado"));
                // Resolver el campo real del RS por normalización (para tolerar espacios/acentos)
                String resolved = campoCfg;
                String try1 = normalToActual.get(normalizeKey(campoCfg));
                if (try1 != null) resolved = try1;
                // Solo agregar si existe en el RS (evita columnas vacías como EMSalarioBase cuando no aplica)
                if (rows.isEmpty() || normalToActual.containsKey(normalizeKey(resolved))) {
                    campos.add(resolved);
                    headers.add(enc);
                    // tipoDato (entero) opcional
                    Integer tipo = null;
                    try { Object td = col.get("tipoDato"); if (td != null) tipo = Integer.parseInt(String.valueOf(td)); } catch (Exception ignore) {}
                    tipos.add(tipo);
                    // ancho / formato / alinear (opcionales)
                    anchos.add(safeInt(col.get("ancho"), 0));
                    formatos.add(col.get("formato") == null ? null : String.valueOf(col.get("formato")));
                    alinears.add(col.get("alinear") == null ? null : String.valueOf(col.get("alinear")));
                }
            }
        } else if (!rows.isEmpty()) {
            // Fallback: si no hay configuración, inferir del RS
            LinkedCaseInsensitiveMap<?> first = rows.get(0);
            for (Object k : first.keySet()) {
                String key = String.valueOf(k);
                campos.add(key);
                headers.add(key);
                tipos.add(null);
                anchos.add(0);
                formatos.add(null);
                alinears.add(null);
            }
        } else {
            // Sin filas: no podemos inferir encabezados; dejamos vacío
        }
        // Inserción de columnas adicionales en posición 19 (1-based) si existen en RS y no están en config
        // Caso: Jornada
        String jornadaKey = normalToActual.get(normalizeKey("Jornada"));
        if (jornadaKey != null && campos.stream().map(Excel_Filtros::normalizeKey).noneMatch(k -> k.equalsIgnoreCase(normalizeKey(jornadaKey)))) {
            int insertAt = Math.min(18, campos.size()); // index 18 = posición 19
            campos.add(insertAt, jornadaKey);
            headers.add(insertAt, "Jornada");
            tipos.add(insertAt, null);
            anchos.add(insertAt, 0);
            formatos.add(insertAt, null);
            alinears.add(insertAt, null);
        }

        Row rh = sh.createRow(4);
        int c = 0;
        for (String h : headers) {
            Cell cell = rh.createCell(c++);
            cell.setCellValue(clean(h));
            cell.setCellStyle(headerStyle);
        }
        if (!headers.isEmpty()) {
            sh.setAutoFilter(new CellRangeAddress(4, 4, 0, headers.size() - 1));
        }

        // Datos desde fila 6
        // Asegurar que el puntero de fila avance a la siguiente después de encabezados
        r = Math.max(r, 5);
        // Preparar estilos por columna (formato + alineación)
        CellStyle[] colStyles = new CellStyle[campos.size()];
        for (int i = 0; i < campos.size(); i++) {
            String fmtDesc = (i < formatos.size() ? formatos.get(i) : null);
            String fmt = resolveFormatString(fmtDesc);
            HorizontalAlignment align = resolveAlign((i < alinears.size() ? alinears.get(i) : null));
            // Si no hay 'formato', usar tipoDato para setear estilos por defecto
            if (fmt == null) {
                Integer t = (i < tipos.size() ? tipos.get(i) : null);
                if (t != null && t == 4) fmt = "\"$\"#,##0.00";
                else if (t != null && t == 3) fmt = "dd/MM/yyyy";
            }
            if (fmt != null || align != null) {
                CellStyle st = sh.getWorkbook().createCellStyle();
                if (fmt != null) {
                    short df = sh.getWorkbook().createDataFormat().getFormat(fmt);
                    st.setDataFormat(df);
                }
                if (align != null) st.setAlignment(align);
                colStyles[i] = st;
            } else {
                colStyles[i] = null;
            }
        }
        // Configurar anchos fijos donde aplique; si no, dejarlos para autosize
        boolean[] autoSize = new boolean[campos.size()];
        for (int i = 0; i < anchos.size(); i++) {
            int w = anchos.get(i) == null ? 0 : anchos.get(i);
            if (w > 0) {
                int width256 = Math.min(w, 255) * 256;
                try { sh.setColumnWidth(i, width256); } catch (Throwable ignore) {}
                autoSize[i] = false;
            } else {
                autoSize[i] = true;
            }
        }
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Row rr = sh.createRow(r++);
            c = 0;
            for (int i = 0; i < campos.size(); i++) {
                String campo = campos.get(i);
                Integer tipo = (i < tipos.size() ? tipos.get(i) : null);
                Object val = row.get(campo);
                Cell cell = rr.createCell(c++);
                boolean isFecha = (tipo != null && tipo == 3);
                boolean isMoneda = (tipo != null && tipo == 4);
                String fmtDesc = (i < formatos.size() ? formatos.get(i) : null);
                boolean fechaPorFormato = fmtDesc != null && fmtDesc.toLowerCase(java.util.Locale.ROOT).startsWith("fecha:");
                if (isFecha) {
                    // Formatear fecha DD/MM/YYYY
                    Date fecha = null;
                    if (val instanceof Date) {
                        fecha = (Date) val;
                    } else if (val != null) {
                        // Intentar parsear cadenas comunes
                        String s = String.valueOf(val).trim();
                        fecha = tryParseDate(s);
                    }
                    if (fecha != null) {
                        cell.setCellValue(fecha);
                        if (colStyles[i] != null) cell.setCellStyle(colStyles[i]); else cell.setCellStyle(dateStyle);
                    } else {
                        cell.setCellValue("");
                    }
                } else if (fechaPorFormato) {
                    Date fecha = null;
                    if (val instanceof Date) {
                        fecha = (Date) val;
                    } else if (val != null) {
                        String s = String.valueOf(val).trim();
                        fecha = tryParseDate(s);
                    }
                    if (fecha != null) {
                        cell.setCellValue(fecha);
                        if (colStyles[i] != null) cell.setCellStyle(colStyles[i]); else cell.setCellStyle(dateStyle);
                    } else {
                        cell.setCellValue("");
                    }
                } else if (isMoneda) {
                    // Formato moneda con dos decimales
                    Double num = tryParseDouble(val);
                    if (num != null) {
                        cell.setCellValue(num);
                        if (colStyles[i] != null) cell.setCellStyle(colStyles[i]); else cell.setCellStyle(currencyStyle);
                    } else {
                        cell.setCellValue("");
                    }
                } else if (colStyles[i] != null) {
                    // Si hay formato específico para la columna
                    Double num = tryParseDouble(val);
                    if (num != null && !isTextFormat(formatos.get(i))) {
                        cell.setCellValue(num);
                        cell.setCellStyle(colStyles[i]);
                    } else {
                        cell.setCellValue(val == null ? "" : clean(String.valueOf(val)));
                        cell.setCellStyle(colStyles[i]);
                    }
                } else {
                    // Texto para null y todos los demás tipos
                    cell.setCellValue(val == null ? "" : clean(String.valueOf(val)));
                }
            }
        }

        // Auto-size columnas (cota 50) solo donde no haya ancho fijo
        int maxCols = Math.min(headers.size(), 50);
        try {
            if (sh instanceof SXSSFSheet) ((SXSSFSheet) sh).trackAllColumnsForAutoSizing();
        } catch (Throwable ignore) {}
        for (int i = 0; i < maxCols; i++) {
            if (i < autoSize.length && !autoSize[i]) continue;
            try { sh.autoSizeColumn(i); } catch (Throwable ignore) {}
        }

        // Resolución de ruta igual que Excel_Hoja_Multiple
        String rutaDir = outputDir;
        // Resolver idEmpresa efectivo: idEmpresa | admIdEmpresa | primer id de empresas/empresasIds
        Object idEmpObj = parametros.get("idEmpresa");
        if (idEmpObj == null) {
            idEmpObj = firstNonNull(parametros.get("admIdEmpresa"), parametros.get("empresas"), parametros.get("empresasIds"));
        }
        String idEmp = null;
        if (idEmpObj != null) {
            String raw = String.valueOf(idEmpObj).trim();
            raw = raw.replaceAll("[\\{\\}\\[\\]]", "");
            if (raw.contains(",")) raw = raw.split(",")[0].trim();
            String digits = raw.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) idEmp = digits;
        }
        // Determinar subcarpeta del reporte: por nombre de catálogos o por reporteId
        String subFolder = sanitizarNombreCarpeta(
                String.valueOf(firstNonNull(
                        parametros.get("catReportesNombre"),
                        parametros.get("tituloReporteB1"),
                        nombreReportePorId(parametros)
                ))
        );
        if (subFolder == null || subFolder.trim().isEmpty()) subFolder = "Reporte";
        // 1) Priorizar constante (reflexión) como en Excel_Hoja_Multiple
        try {
            Class<?> cst = Class.forName("com.lockton.rpt.util.Constantes");
            Object v = cst.getField("DOCUMENTO_EMPRESA").get(null);
            if (idEmp != null && v != null) {
                String base = String.valueOf(v);
                if (base != null && !base.trim().isEmpty()) {
                    rutaDir = base + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            }
        } catch (Throwable ignore) {}
        // 2) Fallback: variable de entorno UPLOAD_FOLDER
        if (rutaDir == null || ".".equals(rutaDir) || outputDir.equals(rutaDir)) {
            try {
                String base = System.getenv("UPLOAD_FOLDER");
                if (base != null && !base.trim().isEmpty() && idEmp != null) {
                    rutaDir = base + File.separator + "DocumentoEmpresa" + File.separator + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            } catch (Throwable ignore) {}
        }

        String fileName = NombreArchivoUtil.generarNombre(
                parametros,
                reporteNombre,
                "yyyyMMddHHmm",
                false, // sin sufijo idEmpresa/fileSuffix
                false, // sin caso especial Sábana
                false, // sin caso especial Costos
                false  // sin separador "_" (comportamiento previo base+timestamp)
        );
        try {
            System.out.println("Generando Excel_Filtros en: " + rutaDir + " archivo: " + fileName);
            String rutaGenerada = guardarWorkbook(wb, rutaDir, fileName);
            System.out.println("Archivo generado: " + rutaGenerada);
            return rutaGenerada;
        } catch (Exception ex) {
            System.out.println("Error al guardar Excel_Filtros: " + (ex.getMessage() == null ? ex.getClass().getName() : ex.getMessage()));
            ex.printStackTrace(System.out);
            throw ex;
        } finally {
            try { wb.dispose(); } catch (Throwable ignore) {}
        }
    }

    private static void crearCelda(Row r, int col, String val, CellStyle st) {
        Cell c = r.createCell(col);
        c.setCellValue(val == null ? "" : val);
        if (st != null) c.setCellStyle(st);
    }

    private static Object firstNonNull(Object... vals) {
        if (vals == null) return null;
        for (Object v : vals) if (v != null) return v;
        return null;
    }

    private static CellStyle crearTitleStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        style.setFont(font);
        return style;
    }

    private static CellStyle crearHeaderStyle(Workbook wb, Object colorFondoObj, Object colorLetraObj) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        String fondo = colorFondoObj == null ? null : String.valueOf(colorFondoObj);
        String letra = colorLetraObj == null ? null : String.valueOf(colorLetraObj);
        Short fondoIdx = colorFromName(fondo);
        Short letraIdx = colorFromName(letra);
        if (fondoIdx != null) {
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            style.setFillForegroundColor(fondoIdx);
            style.setAlignment(HorizontalAlignment.CENTER);
        } else if (isHexColor(fondo) && style instanceof XSSFCellStyle) {
            try {
                java.awt.Color awt = parseHexColor(fondo);
                ((XSSFCellStyle) style).setFillForegroundColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                style.setAlignment(HorizontalAlignment.CENTER);
            } catch (Exception ignore) {}
        }
        // Color de letra: preferir XSSFColor para asegurar aplicación en SXSSF
        try {
            if (font instanceof XSSFFont) {
                java.awt.Color awt = null;
                if (isHexColor(letra)) {
                    awt = parseHexColor(letra);
                } else if (letraIdx != null) {
                    awt = awtFromIndexed(letraIdx);
                }
                if (awt != null) {
                    ((XSSFFont) font).setColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
                } else if (letraIdx != null) {
                    // Fallback a indexado
                    font.setColor(letraIdx);
                }
            } else {
                if (letraIdx != null) font.setColor(letraIdx);
            }
        } catch (Exception ignore) {}
        style.setFont(font);
        return style;
    }

    private static Short colorFromName(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        if (n.equalsIgnoreCase("Blue") || n.equalsIgnoreCase("Azul")) return IndexedColors.BLUE.getIndex();
        if (n.equalsIgnoreCase("LightBlue") || n.equalsIgnoreCase("Light_Blue") || n.equalsIgnoreCase("Celeste")) return IndexedColors.LIGHT_BLUE.getIndex();
        if (n.equalsIgnoreCase("White") || n.equalsIgnoreCase("Blanco")) return IndexedColors.WHITE.getIndex();
        if (n.equalsIgnoreCase("Black") || n.equalsIgnoreCase("Negro")) return IndexedColors.BLACK.getIndex();
        if (n.equalsIgnoreCase("Red") || n.equalsIgnoreCase("Rojo")) return IndexedColors.RED.getIndex();
        if (n.equalsIgnoreCase("Green") || n.equalsIgnoreCase("Verde")) return IndexedColors.GREEN.getIndex();
        if (n.equalsIgnoreCase("Gray") || n.equalsIgnoreCase("Grey") || n.equalsIgnoreCase("Gris")) return IndexedColors.GREY_50_PERCENT.getIndex();
        return null;
    }

    private static boolean isHexColor(String s) {
        if (s == null) return false;
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v.matches("(?i)^[0-9a-f]{6}$");
    }

    private static java.awt.Color parseHexColor(String s) {
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        int r = Integer.parseInt(v.substring(0,2), 16);
        int g = Integer.parseInt(v.substring(2,4), 16);
        int b = Integer.parseInt(v.substring(4,6), 16);
        return new java.awt.Color(r,g,b);
    }

    private static java.awt.Color awtFromIndexed(Short idx) {
        if (idx == null) return null;
        if (idx.equals(IndexedColors.WHITE.getIndex())) return java.awt.Color.WHITE;
        if (idx.equals(IndexedColors.BLACK.getIndex())) return java.awt.Color.BLACK;
        if (idx.equals(IndexedColors.RED.getIndex())) return java.awt.Color.RED;
        if (idx.equals(IndexedColors.GREEN.getIndex())) return java.awt.Color.GREEN;
        if (idx.equals(IndexedColors.BLUE.getIndex())) return java.awt.Color.BLUE;
        if (idx.equals(IndexedColors.LIGHT_BLUE.getIndex())) return new java.awt.Color(173, 216, 230);
        if (idx.equals(IndexedColors.GREY_50_PERCENT.getIndex())) return new java.awt.Color(128, 128, 128);
        return null;
    }

    private static String guardarWorkbook(Workbook wb, String outputDir, String fileName) throws Exception {
        File dir = new File(outputDir);
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(out)) {
            wb.write(fos);
        }
        wb.close();
        return out.getAbsolutePath();
    }

    private static String sanitizarNombreHoja(String name) {
        String n = name.replaceAll("[\\\\/*?:\\[\\]]", " ").trim();
        return n.isEmpty() ? "Hoja" : n;
    }

    private static String limit(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }

    // Limpia caracteres no permitidos por XML 1.0 que pueden corromper el XLSX
    private static String clean(String s) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == 0x9 || ch == 0xA || ch == 0xD ||
                (ch >= 0x20 && ch <= 0xD7FF) ||
                (ch >= 0xE000 && ch <= 0xFFFD)) {
                sb.append(ch);
            }
        }
        String out = sb.toString();
        return out.length() > 32766 ? out.substring(0, 32766) : out; // límite Excel
    }

    private static String quitarAcentos(String s) {
        if (s == null) return null;
        String decomposed = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }
    private static String sanitizarNombreCarpeta(String s) {
        if (s == null) return null;
        String sinAcentos = quitarAcentos(s);
        // Reemplazar caracteres inválidos en rutas Windows y normalizar espacios
        String cleaned = sinAcentos.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        // Evitar nombres reservados
        String upper = cleaned.equalsIgnoreCase("CON") || cleaned.equalsIgnoreCase("PRN") ||
                       cleaned.equalsIgnoreCase("AUX") || cleaned.equalsIgnoreCase("NUL") ? "Reporte" : cleaned;
        return upper.isEmpty() ? "Reporte" : upper;
    }
    private static String nombreReportePorId(Map<String, Object> parametros) {
        if (parametros == null) return "Reporte";
        Integer rid = null;
        try { Object o = parametros.get("reporteId"); if (o != null) rid = Integer.parseInt(String.valueOf(o)); } catch (Exception ignore) {}
        if (rid == null) return "Reporte";
        switch (rid) {
            case 2: return "Poblacion";
            case 3: return "Sabana";
            default: return "Reporte";
        }
    }
    @SuppressWarnings("unchecked")
    private static Map<String, Object> obtenerGrupoConfigPrefer(Map<String, Object> parametros, int index) {
        try {
            Object o = parametros.get("reporteConfig");
            if (o instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) o;
                Object nombre = parametros.get("grupoNombre");
                if (nombre != null) {
                    for (Map<String, Object> m : list) {
                        if (String.valueOf(m.get("grupo")).equalsIgnoreCase(String.valueOf(nombre))) {
                            return m;
                        }
                    }
                }
                // ordenar por indexTable asc
                List<Map<String, Object>> ordered = new ArrayList<>(list);
                ordered.sort((a,b) -> Integer.compare(safeInt(a.get("indexTable"), 0), safeInt(b.get("indexTable"), 0)));
                if (index >= 0 && index < ordered.size()) return ordered.get(index);
            }
        } catch (Throwable ignore) {}
        return null;
    }

    private static int safeInt(Object v, int def) {
        try { return Integer.parseInt(String.valueOf(v)); } catch (Exception e) { return def; }
    }

    // Normaliza una clave eliminando acentos, espacios y signos; en minúsculas
    private static String normalizeKey(String s) {
        if (s == null) return "";
        String lower = s.toLowerCase(java.util.Locale.ROOT);
        String decomposed = java.text.Normalizer.normalize(lower, java.text.Normalizer.Form.NFD);
        String noAccents = decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return noAccents.replaceAll("[^a-z0-9]", "");
    }

    private static Date tryParseDate(String s) {
        if (s == null || s.isEmpty()) return null;
        String[] fmts = new String[] {
                "yyyy-MM-dd'T'HH:mm:ss",
                "yyyy-MM-dd HH:mm:ss",
                "yyyy-MM-dd",
                "dd/MM/yyyy",
                "MM/dd/yyyy"
        };
        for (String f : fmts) {
            try {
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(f, java.util.Locale.ROOT);
                sdf.setLenient(false);
                return sdf.parse(s);
            } catch (Exception ignore) {}
        }
        try {
            double excelSerial = Double.parseDouble(s);
            // Si viene como número serial Excel (poco probable en RS), ignorar
        } catch (Exception ignore) {}
        return null;
    }
    private static Double tryParseDouble(Object v) {
        if (v == null) return null;
        if (v instanceof Number) return ((Number)v).doubleValue();
        String s = String.valueOf(v).trim().replace(",", "");
        try { return Double.parseDouble(s); } catch (Exception ignore) { return null; }
    }
    private static String resolveFormatString(String desc) {
        if (desc == null) return null;
        String d = desc.trim();
        if (d.isEmpty()) return null;
        String l = d.toLowerCase(java.util.Locale.ROOT);
        if (l.equals("texto") || l.equals("text") || l.equals("@")) return "@";
        if (l.equals("entero") || l.equals("integer")) return "0";
        if (l.equals("numero") || l.equals("number") || l.equals("decimal")) return "#,##0.00";
        if (l.equals("moneda") || l.equals("currency")) return "\"$\"#,##0.00";
        if (l.equals("porcentaje") || l.equals("percent")) return "0.00%";
        if (l.startsWith("fecha:")) return d.substring(6).trim().isEmpty() ? "dd/MM/yyyy" : d.substring(6).trim();
        if (l.startsWith("custom:")) return d.substring(7).trim().isEmpty() ? null : d.substring(7).trim();
        return null;
    }
    private static HorizontalAlignment resolveAlign(String desc) {
        if (desc == null) return null;
        String l = desc.trim().toLowerCase(java.util.Locale.ROOT);
        if (l.isEmpty()) return null;
        if (l.equals("izquierda") || l.equals("left")) return HorizontalAlignment.LEFT;
        if (l.equals("centro") || l.equals("center")) return HorizontalAlignment.CENTER;
        if (l.equals("derecha") || l.equals("right")) return HorizontalAlignment.RIGHT;
        return null;
    }
    private static boolean isTextFormat(String desc) {
        if (desc == null) return false;
        String l = desc.trim().toLowerCase(java.util.Locale.ROOT);
        return l.equals("texto") || l.equals("text") || l.equals("@");
    }
}