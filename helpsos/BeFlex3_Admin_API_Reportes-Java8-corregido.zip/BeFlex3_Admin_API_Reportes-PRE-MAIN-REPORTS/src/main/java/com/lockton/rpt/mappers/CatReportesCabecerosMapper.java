package com.lockton.rpt.mappers;

import java.util.List;
import java.util.stream.Collectors;
import com.lockton.rpt.models.dto.CatReportesCabecerosDTO;
import com.lockton.rpt.models.entities.CatReportesCabeceros;

public class CatReportesCabecerosMapper {

public static CatReportesCabecerosDTO MapperDTO(CatReportesCabeceros ent) {
        CatReportesCabecerosDTO dto = new CatReportesCabecerosDTO();
        dto.setId(ent.getCatReportesId());
        dto.setCatReportesId(ent.getCatReportesId());
        dto.setNombre(ent.getCatReportesCabecerosNombre());
        dto.setDescripcion(ent.getCatReportesCabecerosDesc());
        dto.setEsid(ent.getEsid());
        return dto;
    }

    public static List<CatReportesCabecerosDTO> MapperDTO(List<CatReportesCabeceros> ent) {
        return ent
            .stream()
            .map(CatReportesCabecerosMapper::MapperDTO)
            .collect(Collectors.toList());
    }

    public static CatReportesCabeceros MapperEntity(CatReportesCabecerosDTO dto) {
        CatReportesCabeceros ent = new CatReportesCabeceros();
        ent.setCatReportesCabecerosId(dto.getId());
        ent.setCatReportesId(dto.getCatReportesId());
        ent.setCatReportesCabecerosNombre(dto.getNombre());
        ent.setCatReportesCabecerosDesc(dto.getDescripcion());
        ent.setEsid(dto.getEsid());
        return ent;
    }
    
    public static List<CatReportesCabeceros> MapperEntity(List<CatReportesCabecerosDTO> dto) {
        return dto
            .stream()
            .map(CatReportesCabecerosMapper::MapperEntity)
            .collect(Collectors.toList());
    }
}