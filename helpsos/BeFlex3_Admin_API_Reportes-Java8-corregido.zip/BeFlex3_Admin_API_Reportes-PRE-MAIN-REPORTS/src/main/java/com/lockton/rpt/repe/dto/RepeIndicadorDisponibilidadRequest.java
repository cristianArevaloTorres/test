package com.lockton.rpt.repe.dto;

import com.fasterxml.jackson.databind.JsonNode;

public class RepeIndicadorDisponibilidadRequest {
    private String modoDisponibilidad;
    private JsonNode corporativosDisponibilidad;
    private Integer idUsuario;

    public String getModoDisponibilidad() { return modoDisponibilidad; }
    public void setModoDisponibilidad(String value) { modoDisponibilidad = value; }

    public JsonNode getCorporativosDisponibilidad() { return corporativosDisponibilidad; }
    public void setCorporativosDisponibilidad(JsonNode value) { corporativosDisponibilidad = value; }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer value) { idUsuario = value; }
}
