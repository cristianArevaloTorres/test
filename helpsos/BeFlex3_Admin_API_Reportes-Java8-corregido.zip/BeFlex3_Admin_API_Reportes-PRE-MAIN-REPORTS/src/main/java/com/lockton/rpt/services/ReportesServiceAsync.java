package com.lockton.rpt.services;

import com.lockton.rpt.enumeradores.EstatusReporte;
import com.lockton.rpt.models.dto.ResponseAsyncRptDTO;
import com.lockton.rpt.models.entities.ControlReporteGen;
import com.lockton.rpt.repositories.CtlRptGenRepository;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class ReportesServiceAsync {
    
    private static final Log LOGGER = LogFactory.getLog(ReportesServiceAsync.class);

    @Autowired
    GeneradorReportesService generadorReportesService;
    @Autowired
    CtlRptGenRepository ctlRptGenRepository;

    @Async("taskExecutor")
    public CompletableFuture<ResponseAsyncRptDTO> GenerarReporte(int idUsuario, int idEmpresa, int reporteId, long idRpt, Map<String,Object> params) {
        LOGGER.info("WorkerReportes-" + Thread.currentThread().getName());
        ResponseAsyncRptDTO rsReporte = new ResponseAsyncRptDTO();
        try {
            rsReporte = generadorReportesService.ejecutarOrquestadorBD(reporteId, params);
            LOGGER.info("Generacion de reporte concluida. Worker-" + Thread.currentThread().getName() + "-Response: " + rsReporte.getMensaje());
            return CompletableFuture.completedFuture(rsReporte);
        }
        catch(Exception ex) {
            rsReporte.setEstatus(EstatusReporte.ERROR);
            rsReporte.setMensaje(ex.getMessage());
            return CompletableFuture.completedFuture(rsReporte);
        }
        finally {
            if(rsReporte.getEstatus() == EstatusReporte.DISPONIBLE)
                ActualizarReporte(rsReporte.getRuta(), Long.valueOf(idRpt), rsReporte.getEstatus(), "");
            else
                ActualizarReporte("", Long.valueOf(idRpt), rsReporte.getEstatus(), rsReporte.getMensaje());
        }
    }

    public boolean ActualizarReporte(String ruta, Long idReporte, EstatusReporte estatus, String observaciones) {
        boolean rs = false;
        try {
            Optional<ControlReporteGen> ent = ctlRptGenRepository.findById(idReporte);
            if(ent.isPresent()){
                ControlReporteGen ctlRpt = ent.get();
                
                ctlRpt.setCRptFechaGeneracion(new Date());
                ctlRpt.setCRptRuta(ruta);
                ctlRpt.setCRptIdEstatus(estatus.getNumVal());
                ctlRpt.setCRptObservaciones(observaciones);
                ctlRptGenRepository.save(ctlRpt);
                rs = true;
            }
        }
        catch(Exception ex){
            LOGGER.error("Error al actualizar estatus: " + ex.getCause().getMessage());
        }
        return rs;
    }
}