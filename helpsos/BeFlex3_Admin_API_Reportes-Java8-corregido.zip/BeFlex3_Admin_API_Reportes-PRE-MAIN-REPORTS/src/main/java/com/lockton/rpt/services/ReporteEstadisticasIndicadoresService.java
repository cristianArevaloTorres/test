package com.lockton.rpt.services;

import java.util.List;
import java.util.Map;

public interface ReporteEstadisticasIndicadoresService {

    List<Map<String, Object>> listarSecciones();

    Map<String, Object> getParametros(int idCorporativo);

    List<Map<String, Object>> s1RazonSocial(int idCorporativo);

    List<Map<String, Object>> s1Genero(int idCorporativo);

    Map<String, Object> s1GeneroGrafica(int idCorporativo);

    List<Map<String, Object>> s1Generacion(int idCorporativo);

    List<Map<String, Object>> s1Perfil(int idCorporativo);

    Map<String, Object> s2ParticipacionGeneral(int idCorporativo);

    List<Map<String, Object>> s2ParticipacionEmpresa(int idCorporativo);

    List<Map<String, Object>> s2SolicitudesDia(int idCorporativo);

    List<Map<String, Object>> s2ParticipacionPerfil(int idCorporativo);

    List<Map<String, Object>> s3OpcionalesResumen(int idCorporativo);

    List<Map<String, Object>> s3OpcionalesTabla(int idCorporativo);

    List<Map<String, Object>> s3OpcionalesGeneracion(int idCorporativo);

    List<Map<String, Object>> s3ComposicionFamiliar(int idCorporativo);

    List<Map<String, Object>> s3Movilidad(int idCorporativo);
}
