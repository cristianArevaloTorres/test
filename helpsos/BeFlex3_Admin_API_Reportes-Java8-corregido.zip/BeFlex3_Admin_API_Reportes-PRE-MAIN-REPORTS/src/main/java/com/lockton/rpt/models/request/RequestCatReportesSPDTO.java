package com.lockton.rpt.models.request;

import java.util.List;

public class RequestCatReportesSPDTO {
    
    private int catReportesId;
    private String catReportesSPNombre;
    private String catReportesSPDesc;
    private int catReportesSPOrden;
    private String catReportesSPFechaAdd;
    private int catReportesSPUsuarioAdd;
    private int esid;
    private List<RequestCatReportesParamDTO> parameters;

    // Getters y Setters
    public int getCatReportesId() {
        return catReportesId;
    }

    public void setCatReportesId(int catReportesId) {
        this.catReportesId = catReportesId;
    }

    public String getCatReportesSPNombre() {
        return catReportesSPNombre;
    }

    public void setCatReportesSPNombre(String catReportesSPNombre) {
        this.catReportesSPNombre = catReportesSPNombre;
    }

    public String getCatReportesSPDesc() {
        return catReportesSPDesc;
    }

    public void setCatReportesSPDesc(String catReportesSPDesc) {
        this.catReportesSPDesc = catReportesSPDesc;
    }

    public int getCatReportesSPOrden() {
        return catReportesSPOrden;
    }

    public void setCatReportesSPOrden(int catReportesSPOrden) {
        this.catReportesSPOrden = catReportesSPOrden;
    }

    public String getCatReportesSPFechaAdd() {
        return catReportesSPFechaAdd;
    }

    public void setCatReportesSPFechaAdd(String catReportesSPFechaAdd) {
        this.catReportesSPFechaAdd = catReportesSPFechaAdd;
    }

    public int getCatReportesSPUsuarioAdd() {
        return catReportesSPUsuarioAdd;
    }

    public void setCatReportesSPUsuarioAdd(int catReportesSPUsuarioAdd) {
        this.catReportesSPUsuarioAdd = catReportesSPUsuarioAdd;
    }

    public int getEsid() {
        return esid;
    }

    public void setEsid(int esid) {
        this.esid = esid;
    }

    public List<RequestCatReportesParamDTO> getParameters() {
        return parameters;
    }

    public void setParameters(List<RequestCatReportesParamDTO> parameters) {
        this.parameters = parameters;
    }

}
