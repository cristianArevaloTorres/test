package com.lockton.rpt.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lockton.rpt.mappers.CatReportesMapper;
import com.lockton.rpt.mappers.CatReportesParamsMapper;
import com.lockton.rpt.mappers.CatReportesSPMapper;
import com.lockton.rpt.models.dto.CatReportesDTO;
import com.lockton.rpt.models.dto.ResponseCreateReportDTO;
import com.lockton.rpt.models.entities.CatReportes;
import com.lockton.rpt.models.entities.CatReportesParams;
import com.lockton.rpt.models.entities.CatReportesSP;
import com.lockton.rpt.models.request.CreateReporteRequest;
import com.lockton.rpt.models.request.RequestCatReportesParamDTO;
import com.lockton.rpt.models.request.RequestCatReportesSPDTO;
import com.lockton.rpt.repositories.CatReportesParamsRepository;
import com.lockton.rpt.repositories.CatReportesRepository;
import com.lockton.rpt.repositories.CatReportesSPRepository;

@Service
public class CatReportesService {
    @Autowired
    private CatReportesRepository repository;

    @Autowired
    private CatReportesSPRepository spRepository;

    @Autowired
    private CatReportesParamsRepository paramsRepository;

    public List<CatReportesDTO> getAll() {
        List<CatReportesDTO> dtos = null;
        List<CatReportes> cats = repository.findAll();
        if(!cats.isEmpty())
            dtos = CatReportesMapper.MapperDTO(cats);
        return dtos;
    }

    public CatReportesDTO create(CatReportesDTO catReportesDTO) {
        CatReportes catReportes = CatReportesMapper.MapperEntity(catReportesDTO);
        CatReportes cat = repository.save(catReportes);
        return CatReportesMapper.MapperDTO(cat);
    }

    public ResponseCreateReportDTO createNewReport(CreateReporteRequest request) {
        ResponseCreateReportDTO response = new ResponseCreateReportDTO();
        try{
            List<CatReportes> ls = repository.findAll();
            int num = ls.size() +1;
            request.getRequestCatReportes().setCatReportesNum(num);
            CatReportes catReportes = CatReportesMapper.mapToReporte(request.getRequestCatReportes());
            CatReportes cat = repository.save(catReportes);
            if(cat != null){
                Integer catReportesId = num;
                
                for (RequestCatReportesSPDTO spDTO : request.getRequestCatReportesSP()){
                    CatReportesSP sp = CatReportesSPMapper.mapToSP(spDTO, catReportesId);
                    CatReportesSP spAdd = spRepository.save(sp);
                    Integer catReportesSPId = spAdd.getCatReportesSPId();

                    if (spDTO.getParameters() != null){
                        for (RequestCatReportesParamDTO pDTO : spDTO.getParameters()){
                            CatReportesParams param = CatReportesParamsMapper.mapToParametro(pDTO, catReportesSPId);
                            paramsRepository.save(param);
                        }
                    }
                }
                response.isCreated = true;
                response.messages = "Proceso Exitoso";
            }
        }catch(Exception ex){
            response.isCreated = false;
            response.messages = "Se presento el siguiente error: " + ex.getMessage();
        }
        return response;
    }

    public boolean delete(CatReportesDTO catReportesDTO) {
        boolean rs = false;
        CatReportes catReportes = CatReportesMapper.MapperEntity(catReportesDTO);
        repository.delete(catReportes);
        rs = true;
        return rs;
    }

    public CatReportesDTO update(CatReportesDTO catReportesDTO) {
        CatReportes catReportes = CatReportesMapper.MapperEntity(catReportesDTO);
        CatReportes cat = repository.save(catReportes);
        return CatReportesMapper.MapperDTO(cat);
    }

    public List<CatReportes> findBycatReportesNombre(String nombreReporte){
        return repository.findBycatReportesNombre(nombreReporte);
    }

    public CatReportesDTO deleteLogic(CatReportesDTO catReportesDTO){
        CatReportes catReportes = CatReportesMapper.MapperEntity(catReportesDTO);
        CatReportes cat = repository.save(catReportes);
        return CatReportesMapper.MapperDTO(cat);
    }

    public Boolean deleteLogic(int catReportesId){
        Optional<CatReportes> catReportes = repository.findById(catReportesId);
        if(catReportes.isPresent()){
            CatReportes data = catReportes.get();
            data.setEsid(0);
            return true;
        }else {
            return false;
        }   
    }
}