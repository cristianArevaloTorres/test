package com.lockton.rpt.models.dto;

import lombok.Data;

@Data
public class CatReportesTipoArchivoDTO {
    private Integer catReportesTAId;
    private String catReportesTATipo;
    private String catReportesTADescripcion;
}
