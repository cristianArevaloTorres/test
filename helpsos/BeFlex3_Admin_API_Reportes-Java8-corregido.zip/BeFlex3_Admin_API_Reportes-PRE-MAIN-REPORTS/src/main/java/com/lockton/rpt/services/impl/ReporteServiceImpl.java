package com.lockton.rpt.services.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.rpt.enumeradores.EstatusReporte;
import com.lockton.rpt.mappers.CatRptGenMapper;
import com.lockton.rpt.models.dto.CatalogoReporteGenDTO;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.models.entities.CatalogoReporteGen;
import com.lockton.rpt.models.entities.ControlReporteGen;
import com.lockton.rpt.enumeradores.CatTipoNotificacionReporte;
import com.lockton.rpt.repositories.CatRptGenRepository;
import com.lockton.rpt.repositories.CfgRptGenRepository;
import com.lockton.rpt.repositories.CtlRptGenRepository;
import com.lockton.rpt.repositories.EmpresaRepository;
import com.lockton.rpt.repositories.ReportesRepository;
import com.lockton.rpt.services.ReporteService;
import com.lockton.rpt.services.ReportesServiceAsync;
import com.lockton.rpt.util.Correo;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ReporteServiceImpl implements ReporteService {
    private static final Log LOGGER = LogFactory.getLog(ReporteServiceImpl.class);

    @Autowired
    CatRptGenRepository catRptGenRepository;
    @Autowired
    CfgRptGenRepository cfgRptGenRepository;
    @Autowired
    ReportesRepository reportesRepository;
    @Autowired
    CtlRptGenRepository ctlRptGenRepository;
    @Autowired
	EmpresaRepository empresaRepository;
    @Autowired
    ReportesServiceAsync reportesServiceAsync;
    @Autowired
    Correo correoServ;

    @Value("${administracion.reportes.ruta}")
	private String pathReportesProperties;

    @Override
    public ResponseGralDTO EjecutarReporte(int reporteId, String requestMapEncode, String token, int controlReporteId){
        Long rptIdBd = Long.valueOf(0);
        final int idUsuario;
        final int idEmpresa;
        final String nomAdm;
        final String nomEmp;
        final String email;
        Object reporteObj = null;
        String responseStr = ""; 
        ResponseGralDTO response = new ResponseGralDTO();
        response.status = false;
        try{
            Map<String, Object> requestMap = DecodeMap(requestMapEncode);
            reporteObj = requestMap.get("idUsuario");
            if (reporteObj == null){
                response.messages = "'idUsuario' no está en la lista de parámetros.";
                return response;
            }
            else
                idUsuario = Integer.parseInt(reporteObj.toString());
            reporteObj = requestMap.get("idEmpresa");
            if (reporteObj == null) {
                response.messages = "'idEmpresa' no está en la lista de parámetros.";
                return response;
            }
            else
                idEmpresa = Integer.parseInt(reporteObj.toString());
            reporteObj = requestMap.get("nomAdm");
            if (reporteObj == null) {
                response.messages = "'nomAdm' no está en la lista de parámetros.";
                return response;
            }
            else
                nomAdm = reporteObj.toString();
            reporteObj = requestMap.get("nomEmp");
            if (reporteObj == null) {
                response.messages = "'nomEmp' no está en la lista de parámetros.";
                return response;
            }
            else
                nomEmp = reporteObj.toString();
            reporteObj = requestMap.get("email");
            if (reporteObj == null) {
                response.messages = "'email' no está en la lista de parámetros.";
                return response;
            }
            else
                email = reporteObj.toString();

            CatalogoReporteGenDTO catRpt = ValidacionConfiguracionReporte(Long.valueOf(reporteId));
            if(catRpt.getCatRptActivo()) {
                if(controlReporteId > 0 || !catRpt.getCatRptProgramado()) {
                    if(controlReporteId > 0){
                        reportesServiceAsync.ActualizarReporte("", Long.valueOf(controlReporteId), EstatusReporte.EN_PROCESO, "Reporte programado en proceso");
                        rptIdBd = Long.valueOf(controlReporteId);
                    }
                    else
                        rptIdBd = RegistrarReporte(idUsuario, reporteId, idEmpresa, requestMapEncode, EstatusReporte.EN_PROCESO);
                    if(rptIdBd > 0) {
                        reportesServiceAsync.GenerarReporte(idUsuario, idEmpresa, reporteId, rptIdBd, requestMap).thenAccept(
                            rsReporte -> { 
                                String asuntoCorreo = cfgRptGenRepository.findByCfgRptClave("asunto_correo").get(0).getCfgRptValor();
                                String plantillaCorreo = cfgRptGenRepository.findByCfgRptClave("cuerpo_correo").get(0).getCfgRptValor();
                                Integer idTipoNotificacion = CatTipoNotificacionReporte.resolverIdTipoNotificacion(reporteId);
                                correoServ.EnviarCorreo(idUsuario, idEmpresa, nomAdm, nomEmp, email, !rsReporte.getRuta().equals(""), catRpt.getCatRptNombre(), plantillaCorreo, asuntoCorreo, rsReporte.getMensaje(), token, idTipoNotificacion);
                            });
                        responseStr = "Solicitud generada con éxito con Id:" + rptIdBd.toString();
                    }
                    else
                        responseStr = "El reporte no ha podido ser registrado.";
                }
                else {
                    rptIdBd = RegistrarReporte(idUsuario, reporteId, idEmpresa, requestMapEncode, EstatusReporte.PROGRAMADO);
                    if(rptIdBd == 0)
                        responseStr = "Ya existe un reporte solicitado con los mismos parámetros";
                    else
                        responseStr = "El reporte ha sido programado";
                }
            }
            else {
                responseStr = "El tipo de reporte no se encuentra activo";
            }
            response.status = true;
            response.messages = responseStr;
        }
        catch(Exception ex) {
            response.status = false;
            response.messages = "ERROR.EjecutarReporte: " + ex.getMessage();
        }
        return response;
    }

    @Override
    public CatalogoReporteGenDTO ValidacionConfiguracionReporte(Long reporteId){
        CatalogoReporteGenDTO dto = null;
        Optional<CatalogoReporteGen> catRpt = catRptGenRepository.findById(reporteId);
        if(catRpt.isPresent())
            dto = CatRptGenMapper.MapperDTO(catRpt.get());        
        return dto;
    }

    @Override
    public String ConsultaStatusReporte(int reporteGenId){
        String rs = "";
        Optional<ControlReporteGen> ent = ctlRptGenRepository.findById(Long.valueOf(reporteGenId));
        if(ent.isPresent())
            rs = EstatusReporte.values()[ent.get().getCRptIdEstatus() - 1].toString();
        return rs;
    }

    @Override
    public Long RegistrarReporte(int idUsuario, int idReporte, int idEmpresa, String paramsSPEncode, EstatusReporte estatusRpt) {
        ControlReporteGen ent = new ControlReporteGen();
        try {
            // String paramStr = paramsSP == null ? "" : objectMapper.writeValueAsString(paramsSP);

            ent.setCRptIdUsuarioSolicitud(idUsuario);
            ent.setCRptIdReporte(idReporte);
            ent.setCRptFechaSolicitud(new Date());
            ent.setCRptIdEmpresa(idEmpresa);
            ent.setCRptRuta("");
            ent.setCRptIdEstatus(estatusRpt.getNumVal());
            ent.setCRptUsuarioAdd(idUsuario);
            ent.setCRptFechaAdd(new Date());
            ent.setCRptParams(paramsSPEncode);
            if(!ExisteReporteProgramado((ent)))
                ctlRptGenRepository.save(ent);
            else
                ent.setCRptId(0L);
        }
        catch(Exception ex){
            LOGGER.error("Error al registrar reporte: " + ex.getMessage());
        }
        return ent.getCRptId();
    }

    @Override
    public boolean ExisteReporteProgramado(ControlReporteGen ent){
        return ctlRptGenRepository.existsByCRptIdUsuarioSolicitudAndCRptIdReporteAndCRptIdEmpresaAndCRptParamsAndCRptIdEstatus(
            ent.getCRptIdUsuarioSolicitud(),
            ent.getCRptIdReporte(),
            ent.getCRptIdEmpresa(),
            ent.getCRptParams(),
            EstatusReporte.PROGRAMADO.getNumVal()
        );
    }

    @Override
    public int crearBitacora(int idPagina, int idEmpleado, String ipUser, String urlUser, int admin, int idEmpresa, String nombrePagina) {
        reportesRepository.crearBitacora(idPagina, idEmpleado, ipUser, urlUser, admin, idEmpresa, nombrePagina);
		
		//if (!listSP.isEmpty())
			return 1;
		//return 0;
    }

    private Map<String, Object> DecodeMap(String paramsMask) {
        byte[] decodedBytes = Base64.getDecoder().decode(paramsMask);
        String decodedJson = new String(decodedBytes, StandardCharsets.UTF_8);
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> requestMap = null;
        try{
            requestMap = mapper.readValue(
                decodedJson, new TypeReference<Map<String, Object>>() {}
            );
        }
        catch(Exception ex){}
        return requestMap;
    }
}