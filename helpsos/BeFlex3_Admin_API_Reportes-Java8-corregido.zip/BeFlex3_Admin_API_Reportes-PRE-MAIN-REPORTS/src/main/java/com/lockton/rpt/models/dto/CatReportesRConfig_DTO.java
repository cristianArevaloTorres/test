package com.lockton.rpt.models.dto;

public class CatReportesRConfig_DTO {
    public Integer catReportesId;
    public Integer catReportesNum;
    public String  catReportesNombre;
    public String  catReportesDesc;
    public Integer catReportesTAId;
    public String  catReportesFormato;
    public Integer esId;
    public Integer catReportesUsuarioAdd;
    public String  catReportesFechaAdd;

    public Integer getCatReportesId() {
        return catReportesId;
    }

    public void setCatReportesId(Integer catReportesId) {
        this.catReportesId = catReportesId;
    }

    public Integer getCatReportesNum() {
        return catReportesNum;
    }

    public void setCatReportesNum(Integer catReportesNum) {
        this.catReportesNum = catReportesNum;
    }

    public String getCatReportesNombre() {
        return catReportesNombre;
    }

    public void setCatReportesNombre(String catReportesNombre) {
        this.catReportesNombre = catReportesNombre;
    }

    public String getCatReportesDesc() {
        return catReportesDesc;
    }

    public void setCatReportesDesc(String catReportesDesc) {
        this.catReportesDesc = catReportesDesc;
    }

    public Integer getCatReportesTAId() {
        return catReportesTAId;
    }

    public void setCatReportesTAId(Integer catReportesTAId) {
        this.catReportesTAId = catReportesTAId;
    }

    public String getCatReportesFormato() {
        return catReportesFormato;
    }

    public void setCatReportesFormato(String catReportesFormato) {
        this.catReportesFormato = catReportesFormato;
    }

    public Integer getEsId() {
        return esId;
    }
    
    public void setEsId(Integer esId) {
        this.esId = esId;
    }

    public Integer getCatReportesUsuarioAdd() {
        return catReportesUsuarioAdd;
    }

    public void setCatReportesUsuarioAdd(Integer catReportesUsuarioAdd) {
        this.catReportesUsuarioAdd = catReportesUsuarioAdd;
    }

    public String getCatReportesFechaAdd() {
        return catReportesFechaAdd;
    }

    public void setCatReportesFechaAdd(String catReportesFechaAdd) {
        this.catReportesFechaAdd = catReportesFechaAdd;
    }
}
