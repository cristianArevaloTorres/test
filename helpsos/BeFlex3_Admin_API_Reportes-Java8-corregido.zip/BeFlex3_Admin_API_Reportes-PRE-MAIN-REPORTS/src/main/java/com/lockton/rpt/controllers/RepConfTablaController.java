package com.lockton.rpt.controllers;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lockton.rpt.models.dto.RepConfTablaHojaRquestDTO;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.models.dto.ResponseHojaColumnaDTO;
import com.lockton.rpt.models.request.RequestHojaColumnaDTO;
import com.lockton.rpt.services.RepConfTablaService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/beflex/reportes/excel")
@Api(tags = "Controlar para CRUD Excel")
public class RepConfTablaController {
    private static final Log LOGGER = LogFactory.getLog(WSReportesController.class);
    
    @Autowired
    RepConfTablaService repConfTablaService;

    @GetMapping(value = "/getSheetsByReportId")
    @ApiOperation(value = "Obtener Hojas del Excel.",
                  notes = "")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<List<ResponseHojaColumnaDTO>> getSheetsByReportId(@RequestParam int catReportesId){
        LOGGER.info("Inicia controller==> RepConfTablaController ==> getSheetsByReportId... "); 
        return ResponseEntity.ok(this.repConfTablaService.getSheetsByReportId(catReportesId));
    }

    @PostMapping(value = "/turnOffOnSheet")
    @ApiOperation(value = "Desactivar/Activar Hojas del Excel.",
                  notes = "")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<ResponseGralDTO> turnOffOnSheet(@RequestBody RepConfTablaHojaRquestDTO request){
        LOGGER.info("Inicia controller==> RepConfTablaController ==> turnOffOnSheet... "); 
        return ResponseEntity.ok(this.repConfTablaService.turnOffOnSheet(request));
    }

    @PostMapping(value = "/saveAll")
    @ApiOperation(value = "Desactivar/Activar Hojas del Excel.",
                  notes = "")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<ResponseGralDTO> turnOffOnSheet(@RequestBody List<RequestHojaColumnaDTO> request){
        LOGGER.info("Inicia controller==> RepConfTablaController ==> saveAll... "); 
        return ResponseEntity.ok(this.repConfTablaService.saveAll(request));
    }

    



}
