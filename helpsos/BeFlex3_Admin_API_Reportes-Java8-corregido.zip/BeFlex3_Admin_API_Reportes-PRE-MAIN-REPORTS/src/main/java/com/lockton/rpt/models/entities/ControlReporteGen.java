package com.lockton.rpt.models.entities;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "bf_ControlReporteGen")
public class ControlReporteGen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "CRptId")
    private Long cRptId;
    @Basic(optional = false)
    @Column(name = "CRptIdUsuarioSolicitud")
    private Integer cRptIdUsuarioSolicitud;
    @Basic(optional = false)
    @Column(name = "CRptIdReporte")
    private Integer cRptIdReporte;
    @Basic(optional = false)
    @Column(name = "CRptFechaSolicitud")
    private Date cRptFechaSolicitud;
    @Column(name = "CRptFechaGeneracion")
    private Date cRptFechaGeneracion;
    @Basic(optional = false)
    @Column(name = "CRptRuta")
    private String cRptRuta;
    @Basic(optional = false)
    @Column(name = "CRptIdEmpresa")
    private Integer cRptIdEmpresa;
    @Basic(optional = false)
    @Column(name = "CRptIdEstatus")
    private Integer cRptIdEstatus;
    @Column(name = "CRptObservaciones")
    private String cRptObservaciones;
    @Basic(optional = false)
    @Column(name = "CRptParams")
    private String cRptParams;
    @Basic(optional = false)
    @Column(name = "CRptUsuarioAdd")
    private Integer cRptUsuarioAdd;
    @Basic(optional = false)
    @Column(name = "CRptFechaAdd")
    private Date cRptFechaAdd;
    @Column(name = "CRptUsuarioMod")
    private Integer cRptUsuarioMod;
    @Column(name = "CRptFechaMod")
    private Date cRptFechaMod;
    @Column(name = "CRptUsuarioDel")
    private Integer cRptUsuarioDel;
    @Column(name = "CRptFechaDel")
    private Date cRptFechaDel;
}
