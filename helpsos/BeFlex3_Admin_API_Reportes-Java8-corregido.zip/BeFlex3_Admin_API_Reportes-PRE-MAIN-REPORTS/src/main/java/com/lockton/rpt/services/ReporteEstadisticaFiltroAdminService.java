package com.lockton.rpt.services;

import java.util.List;
import java.util.Map;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroAdminRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroOrdenRequestDTO;

public interface ReporteEstadisticaFiltroAdminService {
    List<Map<String, Object>> listar(boolean incluirBajas);
    Map<String, Object> obtener(int idFiltro);
    Map<String, Object> auditoria(int idFiltro);
    List<Map<String, Object>> listarCampos(Integer idFiltro, boolean soloDisponibles, String tipoCampo);
    Map<String, Object> sincronizarCampos(int idUsuario);
    Map<String, Object> crear(ReporteEstadisticaFiltroAdminRequestDTO request);
    Map<String, Object> actualizar(int idFiltro, ReporteEstadisticaFiltroAdminRequestDTO request);
    Map<String, Object> reordenar(ReporteEstadisticaFiltroOrdenRequestDTO request);
    Map<String, Object> cambiarEstatus(int idFiltro, CambioEstatusRequestDTO request);
}
