package com.lockton.rpt.models.dto;

import java.util.Date;
import lombok.Data;

@Data
public class ControlReporteGenDTO {
    private Long CRptId;
    private Integer CRptIdUsuarioSolicitud;
    private Integer CRptIdReporte;
    private Date CRptFechaSolicitud;
    private Date CRptFechaGeneracion;
    private String CRptRuta;
    private Integer CRptIdEmpresa;
    private Integer CRptIdEstatus;
    private String CRptObservaciones;
    private Integer CRptUsuarioAdd;
    private Date CRptFechaAdd;
}
