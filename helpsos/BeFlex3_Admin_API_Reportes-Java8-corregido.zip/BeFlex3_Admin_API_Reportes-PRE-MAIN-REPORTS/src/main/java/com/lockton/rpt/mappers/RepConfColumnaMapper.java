package com.lockton.rpt.mappers;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.RepConfColumnaDTO;
import com.lockton.rpt.models.entities.RepConfColumna;

public class RepConfColumnaMapper {
    
    public static List<RepConfColumnaDTO> lstEntityToDTO (List<RepConfColumna> entity){
        if(entity == null || entity.isEmpty()){
            return new ArrayList<>();
        }
        return entity
            .stream()
            .map(RepConfColumnaMapper::EntityToDTO)
            .collect(Collectors.toList());
    }

    public static RepConfColumnaDTO EntityToDTO (RepConfColumna entity){
        RepConfColumnaDTO dto = new RepConfColumnaDTO();
        dto.setIdEmpresa(entity.getId().getIdEmpresa());	
        dto.setCatReportesId(entity.getId().getCatReportesId());	
        dto.setGrupo(entity.getId().getGrupo());	
        dto.setOrden(entity.getId().getOrden());	
        dto.setCampoOrigen(entity.getCampoOrigen()); 
        dto.setEncabezado(entity.getEncabezado());
        dto.setVisible(entity.isVisible());
        dto.setRepConfColumnaUsuarioAdd(entity.getRepConfColumnaUsuarioAdd());
        dto.setRepConfColumnaUsuarioMod(entity.getRepConfColumnaUsuarioMod());
        dto.setRepConfColumnaUsuarioDel(entity.getRepConfColumnaUsuarioDel());
        
        return dto;
    }
}
