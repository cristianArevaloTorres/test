package com.lockton.rpt.models.dto;

public class ResponseCreateReportDTO {
    public String messages;
    public boolean isCreated;
    
    public String getMessages() {
        return messages;
    }
    public void setMessages(String messages) {
        this.messages = messages;
    }
    public boolean isCreated() {
        return isCreated;
    }
    public void setCreated(boolean isCreated) {
        this.isCreated = isCreated;
    }
}
