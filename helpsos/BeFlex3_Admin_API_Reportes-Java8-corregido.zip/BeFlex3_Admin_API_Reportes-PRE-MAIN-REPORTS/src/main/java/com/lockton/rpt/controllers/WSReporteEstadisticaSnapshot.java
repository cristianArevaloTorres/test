package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.crea17.ApiResponseDTO;
import com.lockton.rpt.models.dto.crea17.SnapshotEjecucionRequestDTO;
import com.lockton.rpt.services.ReporteEstadisticaSnapshotService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/beflex/reporte-estadisticas/crea17/snapshots")
public class WSReporteEstadisticaSnapshot {
    private static final Logger LOGGER = LoggerFactory.getLogger(WSReporteEstadisticaSnapshot.class);
    private final ReporteEstadisticaSnapshotService service;

    public WSReporteEstadisticaSnapshot(ReporteEstadisticaSnapshotService service) {
        this.service = service;
    }

    /** Compatibilidad: el GET base sigue siendo el historial de sincronizaciones. */
    @GetMapping
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> listar(
            @RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SNP-LIST", "Historial de sincronizaciones consultado correctamente.",
                    service.listarHistorial(idCorporativo)));
        } catch (Exception ex) {
            return error("RPE-SNP-LIST-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/activo")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> activo(@RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SNP-ACT", "Estado de sincronización consultado correctamente.",
                    service.obtenerActivo(idCorporativo)));
        } catch (Exception ex) {
            return error("RPE-SNP-ACT-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/disponibilidad")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> disponibilidad(
            @RequestParam int idCorporativo,
            @RequestParam(required = false) Integer idVigencia) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SNP-AVAILABLE",
                    "Disponibilidad del histórico consultada correctamente.",
                    service.obtenerDisponibilidad(idCorporativo, idVigencia)));
        } catch (Exception ex) {
            return error("RPE-SNP-AVAILABLE-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{idEjecucion}/progreso")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> progreso(
            @PathVariable long idEjecucion,
            @RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SNP-PROG", "Progreso de sincronización consultado correctamente.",
                    service.obtenerProgreso(idEjecucion, idCorporativo)));
        } catch (IllegalArgumentException ex) {
            return error("RPE-SNP-PROG-404", ex, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return error("RPE-SNP-PROG-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/datos/vigencias")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> vigencias(@RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SNP-VIG", "Vigencias con histórico publicado consultadas correctamente.",
                    service.listarVigencias(idCorporativo)));
        } catch (Exception ex) {
            return error("RPE-SNP-VIG-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/datos/empresas")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> empresas(
            @RequestParam int idCorporativo,
            @RequestParam int idVigencia) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SNP-EMP", "Empresas del histórico consultadas correctamente.",
                    service.listarEmpresas(idCorporativo, idVigencia)));
        } catch (Exception ex) {
            return error("RPE-SNP-EMP-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/datos")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> datos(
            @RequestParam int idCorporativo,
            @RequestParam int idVigencia,
            @RequestParam(required = false) Integer idEmpresa,
            @RequestParam(required = false) String titular,
            @RequestParam(defaultValue = "1") int pagina,
            @RequestParam(defaultValue = "50") int tamanioPagina) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SNP-DATA", "Datos históricos consultados correctamente.",
                    service.consultarDatos(idCorporativo, idVigencia, idEmpresa, titular, pagina, tamanioPagina)));
        } catch (Exception ex) {
            return error("RPE-SNP-DATA-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{idEjecucion}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> detalle(
            @PathVariable long idEjecucion,
            @RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SNP-DET", "Detalle de la sincronización consultado correctamente.",
                    service.obtenerDetalle(idEjecucion, idCorporativo)));
        } catch (IllegalArgumentException ex) {
            return error("RPE-SNP-DET-404", ex, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return error("RPE-SNP-DET-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Registra la ejecución y devuelve 202 inmediatamente.
     * El procesamiento del histórico continúa en taskExecutor y el front recupera
     * el progreso mediante /{idEjecucion}/progreso.
     */
    @PostMapping("/ejecutar")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> ejecutar(
            @RequestBody SnapshotEjecucionRequestDTO request) {
        try {
            if (request == null || request.getIdCorporativo() == null || request.getIdUsuario() == null) {
                throw new IllegalArgumentException("El corporativo y el usuario son requeridos.");
            }
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(ApiResponseDTO.ok(
                    "RPE-SNP-RUN", "La sincronización fue registrada y continúa en segundo plano.",
                    service.iniciar(request.getIdCorporativo(), request.getIdUsuario())));
        } catch (Exception ex) {
            return error("RPE-SNP-RUN-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    private <T> ResponseEntity<ApiResponseDTO<T>> error(String code, Exception ex, HttpStatus status) {
        LOGGER.error("CREA17 snapshot [{}]", code, ex);
        return ResponseEntity.status(status).body(
                ApiResponseDTO.<T>fail(
                        code,
                        "No fue posible completar la operación.",
                        null,
                        null));
    }
}
