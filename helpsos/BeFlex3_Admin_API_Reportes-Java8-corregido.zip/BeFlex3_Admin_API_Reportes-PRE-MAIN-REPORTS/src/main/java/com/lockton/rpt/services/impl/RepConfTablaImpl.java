package com.lockton.rpt.services.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.tomcat.jni.Local;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lockton.rpt.mappers.RepConfColumnaMapper;
import com.lockton.rpt.mappers.RepConfTablaMapper;
import com.lockton.rpt.models.dto.RepConfColumnaDTO;
import com.lockton.rpt.models.dto.RepConfTablaHojaResponseDTO;
import com.lockton.rpt.models.dto.RepConfTablaHojaRquestDTO;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.models.dto.ResponseHojaColumnaDTO;
import com.lockton.rpt.models.entities.RepConfColumna;
import com.lockton.rpt.models.entities.RepConfColumnaPk;
import com.lockton.rpt.models.entities.RepConfTabla;
import com.lockton.rpt.models.entities.RepConfTablaPk;
import com.lockton.rpt.models.request.RequestHojaColumnaDTO;
import com.lockton.rpt.repositories.RepConfColumnaRepository;
import com.lockton.rpt.repositories.RepConfTablaRepository;
import com.lockton.rpt.services.RepConfTablaService;

@Service
public class RepConfTablaImpl implements RepConfTablaService {

    @Autowired
    RepConfTablaRepository repConfTablaRepository;
    @Autowired
    RepConfColumnaRepository repConfColumnaRepository;

    @Override
    public List<ResponseHojaColumnaDTO> getSheetsByReportId(int catReportesId) {
        List<ResponseHojaColumnaDTO> response = new ArrayList<>();
        try{
            List<RepConfTabla> sheets = this.repConfTablaRepository.findAll()
                .stream()
                .filter(x -> x.getId().getCatReportesId() == catReportesId)
                .collect(Collectors.toList());

            for(RepConfTabla sheet: sheets){
                List<RepConfColumna> columns = this.repConfColumnaRepository.findAll()
                .stream()
                .filter(x -> x.getId().getCatReportesId() == catReportesId &&
                        x.getId().getGrupo().equals(sheet.getId().getGrupo()))
                .collect(Collectors.toList());
                ResponseHojaColumnaDTO dto = new ResponseHojaColumnaDTO();
                dto.setHoja(RepConfTablaMapper.entityToSheetDTO(sheet));
                dto.setColumnas(RepConfColumnaMapper.lstEntityToDTO(columns));
                response.add(dto);
            }            
        }catch(Exception ex){
            throw new RuntimeException("Error generado en getSheetsByReportId: " + ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ResponseGralDTO turnOffOnSheet(RepConfTablaHojaRquestDTO request) {
        ResponseGralDTO response = new ResponseGralDTO();
        try{
            RepConfTabla data = this.repConfTablaRepository
                .findAll()
                .stream()
                .filter(x -> x.getId().getIdEmpresa() == request.idEmpresa &&
                             x.getId().getCatReportesId() == request.catReportesId &&
                             x.getId().getGrupo().equals(request.grupo))
                .findFirst()
                .orElse(null);
            if(data != null){
                data.setActivo(request.getActivo());
                data.setRepConfTablaUsuarioDel(request.getRepConfTablaUsuarioDel());
                data.setRepConfTablaFechaDel(LocalDateTime.now());
                this.repConfTablaRepository.save(data);
                response.messages = "Actualización Exitosa";
                response.status = true;
            }else{
                response.messages = "No se encontraton coincidencias";
                response.status = false; 
            }
        }catch(Exception ex){
            response.messages = "turnOffOnSheet:: " + ex.getMessage();
            response.status = false; 
        }
        return response;
    }

    @Override
    public ResponseGralDTO saveAll(List<RequestHojaColumnaDTO> request) {
        ResponseGralDTO response = new ResponseGralDTO();
        try{
            List<RepConfTablaPk> hojaPks = request.stream()
                .map(item -> new RepConfTablaPk(
                    item.hoja.getIdEmpresa(),
                    item.hoja.getCatReportesId(),
                    item.hoja.getGrupo()
                ))
                .collect(Collectors.toList());

            List<RepConfTabla> existentes = this.repConfTablaRepository.findAllById(hojaPks);

            Map<RepConfTablaPk, RepConfTabla> mapExistentes = existentes.stream()
                .collect(Collectors.toMap(RepConfTabla::getId, t -> t));
            
            List<RepConfTabla> hojas = new ArrayList<>();

            for (RequestHojaColumnaDTO item : request) {
                RepConfTablaPk pk = new RepConfTablaPk(
                    item.getHoja().getIdEmpresa(),
                    item.getHoja().getCatReportesId(),
                    item.getHoja().getGrupo()
                );

                RepConfTabla tabla = mapExistentes.getOrDefault(pk, null);

                if(tabla == null){
                    tabla = new RepConfTabla();
                    tabla.setId(pk);
                    tabla.setRepConfTablaUsuarioAdd(item.getHoja().getRepConfTablaUsuarioAdd());
                    tabla.setRepConfTablaFechaAdd(LocalDateTime.now());
                }

                tabla.setIndexTable(item.getHoja().getIndexTable());
                tabla.setColorFondo(item.getHoja().getColorFondo());
                tabla.setColorLetra(item.getHoja().getColorLetra());
                tabla.setActivo(item.getHoja().getActivo());
                tabla.setRepConfTablaUsuarioMod(item.getHoja().getRepConfTablaUsuarioMod());
                tabla.setRepConfTablaFechaMod(LocalDateTime.now());

                hojas.add(tabla);
            }

            List<RepConfColumnaPk> columnaPks = request.stream()
                .flatMap(item -> 
                    item.getColumnas().stream()
                        .map(col -> new RepConfColumnaPk(
                            col.getIdEmpresa(),
                            col.getCatReportesId(),
                            col.getGrupo(),
                            col.getOrden()
                        ))
                )
                .collect(Collectors.toList());

            List<RepConfColumna> columnasExistentes = 
                this.repConfColumnaRepository.findAllById(columnaPks);
            
            Map<RepConfColumnaPk, RepConfColumna> mapColumnas =
                columnasExistentes.stream()
                .collect(Collectors.toMap(RepConfColumna::getId, c -> c));

            List<RepConfColumna> columnasAGuardar = new ArrayList<>();

            for(RequestHojaColumnaDTO item : request){
                for(RepConfColumnaDTO col : item.getColumnas()){
                    RepConfColumnaPk pkCol = new RepConfColumnaPk(
                        col.getIdEmpresa(),
                        col.getCatReportesId(),
                        col.getGrupo(),
                        col.getOrden()
                    );
                    RepConfColumna entidad = mapColumnas.getOrDefault(pkCol, null);
                    if(entidad == null){
                        entidad = new RepConfColumna();
                        entidad.setId(pkCol);
                        entidad.setRepConfColumnaUsuarioAdd(col.getRepConfColumnaUsuarioAdd());
                        entidad.setRepConfColumnaFechaAdd(LocalDateTime.now());
                    }

                    entidad.setCampoOrigen(col.getCampoOrigen());
                    entidad.setEncabezado(col.getEncabezado());
                    entidad.setVisible(col.getVisible());
                    entidad.setRepConfColumnaUsuarioMod(col.getRepConfColumnaUsuarioMod());
                    entidad.setRepConfColumnaFechaMod(LocalDateTime.now());

                    columnasAGuardar.add(entidad);
                }
            }
            
            this.repConfTablaRepository.saveAll(hojas);
            this.repConfColumnaRepository.saveAll(columnasAGuardar);

            response.messages = "Actualización Exitosa";
            response.status = true;
        }catch(Exception ex){
            response.messages = "saveAll:: " + ex.getMessage();
            response.status = false; 
        }
        return response;
    }
}
