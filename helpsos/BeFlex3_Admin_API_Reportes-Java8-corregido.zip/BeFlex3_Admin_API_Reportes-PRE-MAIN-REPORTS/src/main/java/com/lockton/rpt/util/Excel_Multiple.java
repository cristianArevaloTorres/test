package com.lockton.rpt.util;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.text.Normalizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.util.LinkedCaseInsensitiveMap;

/**
 * Versión vertical: encabezados en columna izquierda y valores en la siguiente columna.
 * Cada dataset adicional (después del encabezado) se envía a una hoja nueva,
 * reutilizando la lógica de nombres/columnas de Excel_Hoja_Multiple.
 */
public class Excel_Multiple {

    public static String generar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
                                 Map<String, Object> parametros,
                                 String outputDir) throws Exception {
        if (resultsets == null || resultsets.isEmpty()) {
            return "";
        }
        // Determinar si el primer dataset es solo encabezado (antes de crear el workbook)
        ArrayList<LinkedCaseInsensitiveMap<?>> headerRows = resultsets.get(0);
        boolean tieneTituloFullSize = extraerTituloFullSize(headerRows) != null;
        boolean tieneNoStyle = tieneNoStyleEnHeader(headerRows);
        boolean tieneEncabezado = tieneColumnaReporte(headerRows) || tieneTituloFullSize || tieneNoStyle;
        int startData = tieneEncabezado ? 1 : 0;

        // No generar Excel si el RS de datos no trae información (solo encabezados no basta)
        boolean hayDatos = false;
        for (int i = startData; i < resultsets.size(); i++) {
            ArrayList<LinkedCaseInsensitiveMap<?>> data = resultsets.get(i);
            if (data != null && !data.isEmpty()) {
                hayDatos = true;
                break;
            }
        }
        if (!hayDatos) {
            return "";
        }

        SXSSFWorkbook wb = new SXSSFWorkbook(100);
        wb.setCompressTempFiles(true);
        ArrayList<LinkedCaseInsensitiveMap<?>> headerData = null;
        if (tieneEncabezado) {
            if (headerRows != null && headerRows.size() > 1) {
                headerData = new ArrayList<>(headerRows.subList(1, headerRows.size()));
            }
        } else {
            headerRows = null; // no usar como encabezado
        }

        boolean headersColocados = false;
        boolean filtrado = parametros.get("idSubReporte") != null;
        // Si hay datos en el RS de encabezados, hacer una hoja con ellos y los encabezados verticales
        if (headerData != null && !headerData.isEmpty()) {
            int confIndex = Math.max(0, startData - 1);
            Map<String, Object> grupoConf = obtenerGrupoConfigPrefer(parametros, confIndex);
            String sheetName = nombreHoja(grupoConf, startData);
            Sheet sh = wb.createSheet(limit(sheetName, 31));
            escribirTablaHorizontal(sh, headerData, grupoConf, headerRows, false);
            headersColocados = true;
        }

        // Resto de datasets
        boolean repetirEncabezados = tieneNoStyle;
        for (int i = startData; i < resultsets.size(); i++) {
            ArrayList<LinkedCaseInsensitiveMap<?>> data = resultsets.get(i);
            if (data == null || data.isEmpty()) continue;
            int confIndex = Math.max(0, i - startData);
            Map<String, Object> grupoConf = obtenerGrupoConfigPrefer(parametros, confIndex);
            String sheetName = "";
            if(nombreReportePorId(parametros).contains("Poblacion"))
                sheetName = parametros.get("nombreHoja").toString();
            else
                sheetName = nombreHoja(grupoConf, i);
            Sheet sh = wb.createSheet(limit(sheetName, 31));
            ArrayList<LinkedCaseInsensitiveMap<?>> headersParaEstaHoja =
                    repetirEncabezados ? headerRows : ((!headersColocados && headerRows != null) ? headerRows : null);
            escribirTablaHorizontal(sh, data, grupoConf, headersParaEstaHoja, filtrado);
            if (!repetirEncabezados && headersParaEstaHoja != null) headersColocados = true;
        }
        
        // ========== RESOLVER RUTA IGUAL QUE Excel_Hoja_Multiple ==========
        String rutaDir = outputDir;
        Object idEmpObj = parametros.get("idEmpresa");
        if (idEmpObj == null) {
            idEmpObj = String.valueOf(
                    String.valueOf(
                            parametros.getOrDefault("admIdEmpresa",
                                    String.valueOf(
                                            parametros.getOrDefault("empresas",
                                                    parametros.get("empresasIds")
                                            )
                                    )
                            )
                    )
            );
        }
        String idEmp = null;
        if (idEmpObj != null) {
            String raw = String.valueOf(idEmpObj).trim();
            raw = raw.replaceAll("[\\{\\}\\[\\]]", "");
            if (raw.contains(",")) raw = raw.split(",")[0].trim();
            String digits = raw.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) idEmp = digits;
        }

        String subFolder = sanitizarNombreCarpeta(
                String.valueOf(
                        parametros.getOrDefault(
                                "catReportesNombre",
                                parametros.getOrDefault("tituloReporteB1", nombreReportePorId(parametros))
                        )
                )
        );
        if (subFolder == null || subFolder.trim().isEmpty()) subFolder = "Reporte";

        try {
            Class<?> c = Class.forName("com.lockton.rpt.util.Constantes");
            Object v = c.getField("DOCUMENTO_EMPRESA").get(null);
            if (idEmp != null && v != null) {
                String base = String.valueOf(v);
                if (base != null && !base.trim().isEmpty()) {
                    rutaDir = base + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            }
        } catch (Throwable ignore) {
            // Ignorar y probar con variable de entorno
        }
        if (rutaDir == null || ".".equals(rutaDir) || outputDir.equals(rutaDir)) {
            try {
                String base = System.getenv("UPLOAD_FOLDER");
                if (base != null && !base.trim().isEmpty() && idEmp != null) {
                    rutaDir = base + File.separator + "DocumentoEmpresa" + File.separator + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            } catch (Throwable ignore) {
                // Si tampoco está la variable de entorno, caeremos en outputDir
            }
        }

        // Guardar archivo
        String reporteNombre = nombreReporte(parametros);
        String fileName = NombreArchivoUtil.generarNombre(
                parametros,
                reporteNombre,
                "yyyyMMdd_HHmmss",
                false, // sin sufijo idEmpresa/fileSuffix
                false, // sin caso especial Sábana
                false, // sin caso especial Costos
                false   // separador "_" antes del timestamp
        );
        File dir = new File(rutaDir);
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(out)) {
            wb.write(fos);
        } finally {
            try { wb.dispose(); } catch (Exception ignore) {}
        }
        return out.getAbsolutePath();
    }

    private static void crearHojaEncabezadosVertical(Workbook wb,
                                                     ArrayList<LinkedCaseInsensitiveMap<?>> headerRows,
                                                     Map<String, Object> parametros) {
        Sheet sh = wb.createSheet(limit(nombreHojaEncabezado(parametros), 31));
        if (sh instanceof SXSSFSheet) {
            ((SXSSFSheet) sh).trackAllColumnsForAutoSizing();
        }
        CellStyle headerStyle = crearHeaderStyle(wb, obtenerGrupoConfigPrefer(parametros, 0));
        int rowNum = 0;
        if (headerRows != null && !headerRows.isEmpty()) {
            LinkedCaseInsensitiveMap<?> first = headerRows.get(0);
            for (Object key : first.keySet()) {
                Row r = sh.createRow(rowNum++);
                Cell c1 = r.createCell(0);
                c1.setCellValue(clean(String.valueOf(key)));
                c1.setCellStyle(headerStyle);
                Object val = first.get(key);
                Cell c2 = r.createCell(1);
                c2.setCellValue(val == null ? "" : clean(String.valueOf(val)));
            }
        } else {
            Row r = sh.createRow(rowNum);
            r.createCell(0).setCellValue("Sin encabezados");
        }
        try {
            sh.autoSizeColumn(0);
            sh.autoSizeColumn(1);
        } catch (Exception ignore) {}
    }

    public static Sheet escribirTablaHorizontal(Sheet sh,
                                                ArrayList<LinkedCaseInsensitiveMap<?>> rows,
                                                Map<String, Object> grupoConf,
                                                ArrayList<LinkedCaseInsensitiveMap<?>> headerRows,
                                                boolean filtrar) {
        if (rows == null || rows.isEmpty()) return sh;

        boolean allowAutoSize = true;
        if (allowAutoSize && sh instanceof SXSSFSheet) {
            try { ((SXSSFSheet) sh).trackAllColumnsForAutoSizing(); } catch (Exception ignore) {}
        }

        int rowNum = 0;
        TitleTokens tituloTokens = extraerTituloTokens(headerRows);
        boolean tituloFullFlag = tituloTokens != null && tituloTokens.fullSize;
        boolean tituloNoStyle = tituloTokens != null && tituloTokens.noStyle;
        String tituloFull = tituloTokens == null ? null : tituloTokens.text;
        CellStyle headerStyle = crearHeaderStyle(sh.getWorkbook(), grupoConf);
        CellStyle headerNoStyle = sinFondoConColorLetra(headerStyle, sh.getWorkbook());
        CellStyle headerStyleLeft = clonarConAlineacion(headerStyle, sh.getWorkbook(), HorizontalAlignment.LEFT);
        CellStyle headerNoStyleLeft = clonarConAlineacion(headerNoStyle, sh.getWorkbook(), HorizontalAlignment.LEFT);
        // Encabezados verticales (col 0 = título, col 1 = valor) solo si NO hay título full-size
        if (tituloFull == null && headerRows != null && !headerRows.isEmpty()) {
            LinkedCaseInsensitiveMap<?> firstHeader = headerRows.get(0);
            for (Object key : firstHeader.keySet()) {
                Row r = sh.createRow(rowNum++);
                Cell c1 = r.createCell(0);
                Object valObj = firstHeader.get(key);
                boolean noStyle = tieneNoStyle(key) || tieneNoStyle(valObj);
                String keyText = limpiarTokensTitulo(String.valueOf(key));
                c1.setCellValue(clean(keyText));
                c1.setCellStyle(noStyle ? headerNoStyleLeft : headerStyleLeft);
                Object val = firstHeader.get(key);
                Cell c2 = r.createCell(1);
                String valText = val == null ? "" : limpiarTokensTitulo(String.valueOf(val));
                c2.setCellValue(clean(valText));
                c2.setCellStyle(noStyle ? headerNoStyleLeft : headerStyleLeft);
            }
        }

        LinkedCaseInsensitiveMap<?> first = rows.get(0);
        Map<String, String> normalToActual = new LinkedHashMap<>();
        for (Object k : first.keySet()) {
            String actual = String.valueOf(k);
            normalToActual.put(normalizeKey(actual), actual);
        }

        List<ColMeta> cols = new ArrayList<>();
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> columnas = grupoConf == null ? null : (List<Map<String, Object>>) grupoConf.get("columnas");
        if (columnas != null && !columnas.isEmpty()) {
            for (Map<String, Object> col : columnas) {
                String campoCfg = String.valueOf(col.get("campoOrigen"));
                String enc = String.valueOf(col.get("encabezado"));
                String resolved = normalToActual.getOrDefault(normalizeKey(campoCfg), campoCfg);
                ColMeta meta = new ColMeta();
                meta.campo = resolved;
                meta.encabezado = enc;
                Object formatoCfg = col.get("formato");
                if (formatoCfg != null) {
                    String f = String.valueOf(formatoCfg);
                    if (f.toLowerCase(Locale.ROOT).contains("__autofilter__")) {
                        meta.autoFilterFlag = true;
                        f = f.replaceAll("(?i)__autofilter__", "").trim();
                    }
                    meta.formato = f.isEmpty() ? null : f;
                }
                meta.ancho = parseAncho(col.get("ancho"));
                Object al = col.get("alineacion");
                if (al == null) al = col.get("alinear"); // compat con bf_RepConf_Columna
                meta.alineacion = al == null ? null : String.valueOf(al);
                cols.add(meta);
            }
        } else {
            for (Object k : first.keySet()) {
                ColMeta meta = new ColMeta();
                if(filtrar) {
                    meta.autoFilterFlag = true;
                    filtrar = false;
                }
                meta.campo = String.valueOf(k);
                meta.encabezado = String.valueOf(k);
                cols.add(meta);
            }
            cols.forEach(meta -> {
                if (meta.campo != null &&
                    meta.campo.toLowerCase().contains("fecha")) {
                    meta.formato = "fecha";
                }
            });
        }

        Map<String, CellStyle> styleCache = new LinkedHashMap<>();
        CellStyle titleStyle = headerStyle;
        if (tituloFull != null && !tituloFull.isEmpty()) {
            CellStyle baseTitleStyle = tituloNoStyle ? sinFondoConColorLetra(headerStyle, sh.getWorkbook()) : headerStyle;
            titleStyle = tituloFullFlag ? clonarConTamanoFuente(baseTitleStyle, sh.getWorkbook(), (short) 14) : baseTitleStyle;
        }

        // Título de ancho completo si algún valor de encabezado incluye __fullSize__
        if (tituloFull != null && !tituloFull.isEmpty() && !cols.isEmpty()) {
            Row tr = sh.createRow(rowNum++);
            Cell tc = tr.createCell(0);
            tc.setCellValue(clean(tituloFull));
            tc.setCellStyle(titleStyle);
            try {
                sh.addMergedRegion(new CellRangeAddress(tr.getRowNum(), tr.getRowNum(), 0, Math.max(cols.size() - 1, 0)));
            } catch (Exception ignore) {}
        }

        int headerRowIdx = rowNum;
        Row hr = sh.createRow(rowNum++);
        for (int i = 0; i < cols.size(); i++) {
            Cell cell = hr.createCell(i);
            cell.setCellValue(clean(cols.get(i).encabezado));
            cell.setCellStyle(headerStyle);
        }

        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Row rr = sh.createRow(rowNum++);
            for (int i = 0; i < cols.size(); i++) {
                ColMeta meta = cols.get(i);
                Object val = row.get(meta.campo);
                Cell cell = rr.createCell(i);
                setCellValueWithFormat(cell, val, meta, sh.getWorkbook(), styleCache);
            }
        }

        int maxCols = Math.min(cols.size(), 50);
        for (int i = 0; i < cols.size(); i++) {
            ColMeta meta = cols.get(i);
            if (meta.ancho != null && meta.ancho > 0) {
                int width = Math.min(meta.ancho, 255 * 256);
                try { sh.setColumnWidth(i, width); } catch (Exception ignore) {}
            } else if (allowAutoSize && i < maxCols) {
                try { sh.autoSizeColumn(i); } catch (Exception ignore) {}
            }
        }
        // Filtros automáticos en la fila de encabezados si hay datos y está habilitado
        if (autoFiltroHabilitado(cols) && rowNum - 1 >= headerRowIdx && !cols.isEmpty()) {
            try {
                sh.setAutoFilter(new CellRangeAddress(headerRowIdx, rowNum - 1, 0, cols.size() - 1));
            } catch (Exception ignore) {}
        }
        int extraWidth = 4 * 256; // 4 caracteres extra en caso de aplicar filtrado.

        for (int c = 0; c < cols.size(); c++) {
            int currentWidth = sh.getColumnWidth(c);
            if(currentWidth / 256 >= 255)
                currentWidth = 256* 70;
            sh.setColumnWidth(c, currentWidth + extraWidth);
        }
        return sh;
    }

    private static String nombreHoja(Map<String, Object> grupoConf, int indexDataSet) {
        if (grupoConf != null) {
            Object g = grupoConf.get("grupo");
            Object titulo = grupoConf.get("tituloTabla");
            if (g != null) return sanitizarNombreHoja(String.valueOf(g));
            if (titulo != null) return sanitizarNombreHoja(String.valueOf(titulo));
        }
        return "RS_" + indexDataSet;
    }

    private static String nombreHojaEncabezado(Map<String, Object> parametros) {
        String base = "Encabezados";
        if (parametros != null) {
            Object nom = parametros.get("tituloReporteB1");
            if (nom == null) nom = parametros.get("catReportesNombre");
            if (nom != null) base = String.valueOf(nom);
        }
        return sanitizarNombreHoja(base);
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> obtenerGrupoConfigPrefer(Map<String, Object> parametros, int index) {
        try {
            Object o = parametros == null ? null : parametros.get("reporteConfig");
            if (o instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) o;
                // Ordenar por indexTable
                List<Map<String, Object>> ordered = new ArrayList<>(list);
                ordered.sort((a, b) -> Integer.compare(parseInt(a.get("indexTable")), parseInt(b.get("indexTable"))));
                if (index >= 0 && index < ordered.size()) return ordered.get(index);
            }
        } catch (Exception ignore) {}
        return null;
    }

    private static int parseInt(Object v) {
        try { return Integer.parseInt(String.valueOf(v)); } catch (Exception e) { return 0; }
    }

    private static CellStyle clonarConTamanoFuente(CellStyle base, Workbook wb, short fontSize) {
        CellStyle cs = wb.createCellStyle();
        cs.cloneStyleFrom(base);
        Font baseFont = wb.getFontAt(base.getFontIndex());
        Font newFont = wb.createFont();
        newFont.setBold(baseFont.getBold());
        newFont.setItalic(baseFont.getItalic());
        newFont.setUnderline(baseFont.getUnderline());
        newFont.setStrikeout(baseFont.getStrikeout());
        if (baseFont instanceof XSSFFont && newFont instanceof XSSFFont) {
            XSSFColor xc = ((XSSFFont) baseFont).getXSSFColor();
            if (xc != null) {
                ((XSSFFont) newFont).setColor(xc);
            } else {
                newFont.setColor(baseFont.getColor());
            }
        } else {
            newFont.setColor(baseFont.getColor());
        }
        newFont.setFontName(baseFont.getFontName());
        newFont.setTypeOffset(baseFont.getTypeOffset());
        newFont.setCharSet(baseFont.getCharSet());
        newFont.setFontHeightInPoints(fontSize);
        cs.setFont(newFont);
        return cs;
    }

    private static CellStyle clonarConAlineacion(CellStyle base, Workbook wb, HorizontalAlignment align) {
        CellStyle cs = wb.createCellStyle();
        cs.cloneStyleFrom(base);
        cs.setAlignment(align);
        return cs;
    }

    private static CellStyle sinFondoConColorLetra(CellStyle base, Workbook wb) {
        CellStyle cs = wb.createCellStyle();
        cs.cloneStyleFrom(base);
        cs.setFillPattern(FillPatternType.NO_FILL);
        cs.setFillForegroundColor((short) 0);
        cs.setFillBackgroundColor((short) 0);

        Font baseFont = wb.getFontAt(base.getFontIndex());
        Font newFont = wb.createFont();
        copiarFuente(baseFont, newFont);

        // Tomar color del fondo del header y aplicarlo a la letra
        boolean colorAplicado = false;
        if (base instanceof XSSFCellStyle && newFont instanceof XSSFFont) {
            XSSFColor fg = ((XSSFCellStyle) base).getFillForegroundColorColor();
            if (fg != null) {
                ((XSSFFont) newFont).setColor(fg);
                colorAplicado = true;
            }
        }
        if (!colorAplicado) {
            short fgIdx = base.getFillForegroundColor();
            if (fgIdx != 0) newFont.setColor(fgIdx);
        }
        cs.setFont(newFont);
        return cs;
    }

    private static void copiarFuente(Font src, Font dst) {
        dst.setBold(src.getBold());
        dst.setItalic(src.getItalic());
        dst.setUnderline(src.getUnderline());
        dst.setStrikeout(src.getStrikeout());
        dst.setColor(src.getColor());
        dst.setFontName(src.getFontName());
        dst.setTypeOffset(src.getTypeOffset());
        dst.setCharSet(src.getCharSet());
        dst.setFontHeight(src.getFontHeight());
        dst.setFontHeightInPoints(src.getFontHeightInPoints());
    }

    private static CellStyle crearHeaderStyle(Workbook wb, Map<String, Object> grupoConf) {
        String colorFondo = null;
        String colorLetra = null;
        if (grupoConf != null) {
            Object cf = grupoConf.get("colorFondo");
            Object cl = grupoConf.get("colorLetra");
            colorFondo = cf == null ? null : String.valueOf(cf);
            colorLetra = cl == null ? null : String.valueOf(cl);
        }
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        // Fondo
        Short fondoIdx = colorFromName(colorFondo);
        if (fondoIdx != null) {
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            style.setFillForegroundColor(fondoIdx);
        } else if (isHexColor(colorFondo) && style instanceof XSSFCellStyle) {
            try {
                Color awt = parseHexColor(colorFondo);
                ((XSSFCellStyle) style).setFillForegroundColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            } catch (Exception ignore) {}
        } else {
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        }
        // Letra
        Short letraIdx = colorFromName(colorLetra);
        if (letraIdx != null) {
            font.setColor(letraIdx);
        } else if (isHexColor(colorLetra) && font instanceof XSSFFont) {
            try {
                Color awt = parseHexColor(colorLetra);
                ((XSSFFont) font).setColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
            } catch (Exception ignore) {}
        } else if (fondoIdx != null && fondoIdx.equals(IndexedColors.BLUE.getIndex())) {
            font.setColor(IndexedColors.WHITE.getIndex());
        }
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private static String nombreReporte(Map<String, Object> parametros) {
        if (parametros == null) return "Reporte";
        if (parametros.get("idSubReporte") != null){
            Object t = parametros.get("tituloReporte");
            if (t != null) return String.valueOf(t).replaceAll(" ", "");
        }
        Object t = parametros.get("tituloReporteB1");
        if (t != null) return String.valueOf(t);
        Object c = parametros.get("catReportesNombre");
        if (c != null) return String.valueOf(c);
        Object rid = parametros.get("reporteId");
        return rid == null ? "Reporte" : "Reporte_" + String.valueOf(rid);
    }

    private static String sanitizarNombreHoja(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) return "Hoja";
        String limpio = nombre.replaceAll("[\\\\/*?:\\[\\]]", " ").trim();
        return limpio.isEmpty() ? "Hoja" : limpio;
    }

    private static String limit(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }

    private static boolean tieneColumnaReporte(ArrayList<LinkedCaseInsensitiveMap<?>> headerRows) {
        if (headerRows == null || headerRows.isEmpty()) return false;
        LinkedCaseInsensitiveMap<?> first = headerRows.get(0);
        if (first == null || first.isEmpty()) return false;
        for (Object k : first.keySet()) {
            if (k != null) {
                String name = String.valueOf(k).toLowerCase(Locale.ROOT);
                if (name.contains("reporte")) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean tieneNoStyleEnHeader(ArrayList<LinkedCaseInsensitiveMap<?>> headerRows) {
        if (headerRows == null || headerRows.isEmpty()) return false;
        LinkedCaseInsensitiveMap<?> first = headerRows.get(0);
        if (first == null || first.isEmpty()) return false;
        for (Object v : first.values()) {
            if (v != null && String.valueOf(v).toLowerCase(Locale.ROOT).contains("__nostyle__")) {
                return true;
            }
        }
        return false;
    }

    private static String normalizeKey(String key) {
        if (key == null) return "";
        return key.replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.ROOT);
    }

    private static Short colorFromName(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        if (n.equalsIgnoreCase("Blue") || n.equalsIgnoreCase("Azul")) return IndexedColors.BLUE.getIndex();
        if (n.equalsIgnoreCase("LightBlue") || n.equalsIgnoreCase("Light_Blue") || n.equalsIgnoreCase("Celeste")) return IndexedColors.LIGHT_BLUE.getIndex();
        if (n.equalsIgnoreCase("White") || n.equalsIgnoreCase("Blanco")) return IndexedColors.WHITE.getIndex();
        if (n.equalsIgnoreCase("Black") || n.equalsIgnoreCase("Negro")) return IndexedColors.BLACK.getIndex();
        if (n.equalsIgnoreCase("Red") || n.equalsIgnoreCase("Rojo")) return IndexedColors.RED.getIndex();
        if (n.equalsIgnoreCase("Green") || n.equalsIgnoreCase("Verde")) return IndexedColors.GREEN.getIndex();
        if (n.equalsIgnoreCase("Gray") || n.equalsIgnoreCase("Grey") || n.equalsIgnoreCase("Gris")) return IndexedColors.GREY_50_PERCENT.getIndex();
        if (n.equalsIgnoreCase("Yellow") || n.equalsIgnoreCase("Amarillo")) return IndexedColors.YELLOW.getIndex();
        return null;
    }

    private static boolean isHexColor(String s) {
        if (s == null) return false;
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v.matches("(?i)^[0-9a-f]{6}$");
    }

    private static Color parseHexColor(String s) {
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        int r = Integer.parseInt(v.substring(0, 2), 16);
        int g = Integer.parseInt(v.substring(2, 4), 16);
        int b = Integer.parseInt(v.substring(4, 6), 16);
        return new Color(r, g, b);
    }

    private static void setCellValueWithFormat(Cell cell,
                                               Object val,
                                               ColMeta meta,
                                               Workbook wb,
                                               Map<String, CellStyle> cache) {
        String fmt = meta.formato == null ? null : meta.formato.trim();
        String pattern = resolveFormatPattern(fmt);
        CellStyle style = null;
        if (pattern != null || (meta.alineacion != null && !meta.alineacion.trim().isEmpty())) {
            style = styleForFormat(wb, cache, pattern, meta.alineacion);
        }

        if (val == null) {
            cell.setCellValue("");
        } else if (isDateFormat(fmt)) {
            Date d = null;
            if (val instanceof Date) {
                d = (Date) val;
            } else {
                d = parseDateFlexible(String.valueOf(val));
            }
            if (d != null) {
                cell.setCellValue(d);
            } else {
                cell.setCellValue(clean(String.valueOf(val)));
            }
        } else if (isPercentageFormat(fmt)) {
            Double d = parsePercentage(val);
            if (d != null) {
                cell.setCellValue(d);
            } else {
                cell.setCellValue(clean(String.valueOf(val)));
            }
        } else if (isNumericFormat(fmt)) {
            Double d = parseDoubleSafe(val);
            if (d != null) {
                cell.setCellValue(d);
            } else {
                cell.setCellValue(clean(String.valueOf(val)));
            }
        } else {
            if (val instanceof Number) {
                cell.setCellValue(((Number) val).doubleValue());
            } else if (val instanceof Boolean) {
                cell.setCellValue((Boolean) val);
            } else {
                cell.setCellValue(clean(String.valueOf(val)));
            }
        }

        if (style != null) {
            cell.setCellStyle(style);
        }
    }

    private static CellStyle styleForFormat(Workbook wb,
                                            Map<String, CellStyle> cache,
                                            String formato,
                                            String alineacion) {
        String key = (formato == null ? "" : formato) + "|" + (alineacion == null ? "" : alineacion.toLowerCase(Locale.ROOT));
        if (cache.containsKey(key)) return cache.get(key);
        CellStyle st = wb.createCellStyle();
        if (formato != null) {
            DataFormat df = wb.createDataFormat();
            st.setDataFormat(df.getFormat(formato));
        }
        if (alineacion != null) {
            String a = alineacion.trim().toLowerCase(Locale.ROOT);
            if ("left".equals(a) || "izquierda".equals(a)) st.setAlignment(HorizontalAlignment.LEFT);
            else if ("right".equals(a) || "derecha".equals(a)) st.setAlignment(HorizontalAlignment.RIGHT);
            else if ("center".equals(a) || "centro".equals(a) || "centrado".equals(a)) st.setAlignment(HorizontalAlignment.CENTER);
        }
        cache.put(key, st);
        return st;
    }

    private static String resolveFormatPattern(String formato) {
        if (formato == null || formato.trim().isEmpty()) return null;
        String f = formato.trim();
        String alias = f;
        String custom = null;
        int idx = f.indexOf(':');
        if (idx >= 0) {
            alias = f.substring(0, idx).trim();
            String rest = f.substring(idx + 1).trim();
            if (!rest.isEmpty()) custom = rest;
        }
        String al = alias.toLowerCase(Locale.ROOT);
        if (custom != null) return custom;
        switch (al) {
            case "fecha":
            case "date":
                return "dd/MM/yyyy";
            case "fechahora":
            case "datetime":
                return "dd/MM/yyyy HH:mm:ss";
            case "porcentaje":
            case "percent":
            case "%":
                return "0.00%";
            case "moneda":
            case "currency":
            case "money":
                return "$ #,##0.00";
            case "miles":
            case "thousands":
                return "#,##0";
            case "miles2":
            case "thousands2":
                return "#,##0.00";
            case "decimal2":
            case "double":
            case "float":
            case "real":
            case "numero":
            case "number":
                return "#,##0.00";
            case "decimal3":
                return "#,##0.000";
            case "decimal4":
                return "#,##0.0000";
            case "entero":
            case "int":
            case "integer":
            case "long":
                return "#,##0";
            case "texto":
            case "text":
                return null;
            default:
                // si ya parece un patrón de POI, devolverlo tal cual
                if (al.contains("0") || al.contains("#") || al.contains("y") || al.contains("m") || al.contains("d")) {
                    return f;
                }
                return null;
        }
    }

    private static boolean isDateFormat(String formato) {
        if (formato == null) return false;
        String f = formato.toLowerCase(Locale.ROOT);
        String alias = f;
        int idx = f.indexOf(':');
        if (idx >= 0) alias = f.substring(0, idx).trim();
        return alias.contains("fecha") || alias.contains("date") || f.contains("y");
    }

    private static boolean isPercentageFormat(String formato) {
        if (formato == null) return false;
        String f = formato.toLowerCase(Locale.ROOT);
        String alias = f;
        int idx = f.indexOf(':');
        if (idx >= 0) alias = f.substring(0, idx).trim();
        return alias.contains("%") || alias.contains("porcentaje") || alias.contains("percent");
    }

    private static boolean isNumericFormat(String formato) {
        if (formato == null) return false;
        String f = formato.toLowerCase(Locale.ROOT);
        String alias = f;
        int idx = f.indexOf(':');
        if (idx >= 0) alias = f.substring(0, idx).trim();
        if (alias.contains("entero") || alias.equals("int") || alias.equals("integer") || alias.equals("long")) return true;
        if (alias.contains("decimal") || alias.equals("double") || alias.equals("float") || alias.equals("real")) return true;
        if (alias.contains("numero") || alias.contains("number")) return true;
        if (alias.contains("moneda") || alias.contains("currency") || alias.contains("money")) return true;
        return f.contains("0") || f.contains("#");
    }

    private static Date parseDateFlexible(String s) {
        if (s == null || s.trim().isEmpty()) return null;
        List<String> patterns = Arrays.asList(
                "yyyy-MM-dd HH:mm:ss",
                "yyyy/MM/dd HH:mm:ss",
                "dd-MM-yyyy HH:mm:ss",
                "dd/MM/yyyy HH:mm:ss",
                "yyyy-MM-dd",
                "yyyy/MM/dd",
                "dd-MM-yyyy",
                "dd/MM/yyyy",
                "MM/dd/yyyy"
        );
        for (String p : patterns) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(p, Locale.ROOT);
                sdf.setLenient(false);
                return sdf.parse(s.trim());
            } catch (Exception ignore) {}
        }
        return null;
    }

    private static Double parseDoubleSafe(Object val) {
        if (val == null) return null;
        if (val instanceof Number) return ((Number) val).doubleValue();
        try {
            String s = String.valueOf(val).trim();
            if (s.isEmpty()) return null;
            s = s.replaceAll("[\\s\\$%]", "");
            s = s.replace(",", "");
            return Double.parseDouble(s);
        } catch (Exception e) {
            return null;
        }
    }

    private static Double parsePercentage(Object val) {
        if (val == null) return null;
        if (val instanceof Number) {
            double d = ((Number) val).doubleValue();
            // Si viene en rango 0-100, normalizar a 0-1
            if (Math.abs(d) >= 1d) d = d / 100d;
            return d;
        }
        String s = String.valueOf(val).trim();
        if (s.isEmpty()) return null;
        boolean hadPercent = s.contains("%");
        s = s.replace("%", "").replaceAll("\\s", "");
        s = s.replace(",", "");
        try {
            double d = Double.parseDouble(s);
            if (hadPercent) d = d / 100d;
            else if (Math.abs(d) >= 1d) d = d / 100d; // normalizar cuando viene 100 -> 1.0
            return d;
        } catch (Exception e) {
            return null;
        }
    }

    private static TitleTokens extraerTituloTokens(ArrayList<LinkedCaseInsensitiveMap<?>> headerRows) {
        if (headerRows == null || headerRows.isEmpty()) return null;
        LinkedCaseInsensitiveMap<?> first = headerRows.get(0);
        if (first == null || first.isEmpty()) return null;
        for (Object k : first.keySet()) {
            Object v = first.get(k);
            String keyStr = k == null ? "" : String.valueOf(k);
            String valStr = v == null ? "" : String.valueOf(v);
            boolean esReporte = keyStr.toLowerCase(Locale.ROOT).contains("reporte");
            String lowerVal = valStr.toLowerCase(Locale.ROOT);
            boolean tieneFull = lowerVal.contains("__fullsize__");
            boolean tieneNoStyle = lowerVal.contains("__nostyle__");
            if (esReporte && (tieneFull || tieneNoStyle)) {
                String cleanedVal = limpiarTokensTitulo(valStr);
                String cleanedKey = limpiarTokensTitulo(keyStr);
                String texto = cleanedVal.isEmpty() ? cleanedKey : cleanedVal;
                TitleTokens t = new TitleTokens();
                t.text = texto;
                t.fullSize = tieneFull;
                t.noStyle = tieneNoStyle;
                return t;
            }
        }
        return null;
    }

    // Compatibilidad con llamadas previas
    private static String extraerTituloFullSize(ArrayList<LinkedCaseInsensitiveMap<?>> headerRows) {
        TitleTokens t = extraerTituloTokens(headerRows);
        return (t != null && t.fullSize) ? t.text : null;
    }

    private static Integer parseAncho(Object v) {
        if (v == null) return null;
        try {
            int n = Integer.parseInt(String.valueOf(v).trim());
            return n > 0 ? n : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean tieneNoStyle(Object o) {
        if (o == null) return false;
        return String.valueOf(o).toLowerCase(Locale.ROOT).contains("__nostyle__");
    }

    private static String limpiarTokensTitulo(String s) {
        if (s == null) return "";
        return s.replaceAll("(?i)__fullsize__", " ")
                .replaceAll("(?i)__nostyle__", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private static boolean autoFiltroHabilitado(List<ColMeta> cols) {
        for (ColMeta c : cols) {
            if (c != null && c.autoFilterFlag) return true;
        }
        return false;
    }

    private static class ColMeta {
        String campo;
        String encabezado;
        String formato;
        Integer ancho;
        String alineacion;
        boolean autoFilterFlag;
    }

    private static class TitleTokens {
        String text;
        boolean fullSize;
        boolean noStyle;
    }

    // Limpia caracteres no permitidos por XML 1.0
    private static String clean(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == 0x9 || ch == 0xA || ch == 0xD ||
                (ch >= 0x20 && ch <= 0xD7FF) ||
                (ch >= 0xE000 && ch <= 0xFFFD)) {
                sb.append(ch);
            }
        }
        String out = sb.toString();
        return out.length() > 32766 ? out.substring(0, 32766) : out;
    }
    private static String sanitizarNombreCarpeta(String s) {
        if (s == null) return null;
        String sinAcentos = quitarAcentos(s);
        String cleaned = sinAcentos.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        String upper = cleaned.equalsIgnoreCase("CON") || cleaned.equalsIgnoreCase("PRN") ||
                       cleaned.equalsIgnoreCase("AUX") || cleaned.equalsIgnoreCase("NUL") ? "Reporte" : cleaned;
        return upper.isEmpty() ? "Reporte" : upper;
    }

    private static String nombreReportePorId(Map<String, Object> parametros) {
        if (parametros == null) return "Reporte";
        Integer rid = null;
        try { Object o = parametros.get("reporteId"); if (o != null) rid = Integer.parseInt(String.valueOf(o)); } catch (Exception ignore) {}
        if (rid == null) return "Reporte";
        switch (rid) {
            case 1: return "DocPersonaliados";
            case 2: return "Poblacion";
            case 5: return "BitacoraNavegacion";
            case 8: return "CambiosCalificados";
            default: return "Reporte";
        }
    }

    private static String quitarAcentos(String s) {
        if (s == null) return null;
        String decomposed = Normalizer.normalize(s, Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

}

