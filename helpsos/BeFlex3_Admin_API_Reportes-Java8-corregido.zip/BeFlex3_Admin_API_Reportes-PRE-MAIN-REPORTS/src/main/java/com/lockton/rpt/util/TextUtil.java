package com.lockton.rpt.util;

public final class TextUtil {

    private TextUtil() {
    }

    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static boolean isBlank(Object value) {
        return value == null || String.valueOf(value).trim().isEmpty();
    }

    public static boolean isNotBlank(String value) {
        return !isBlank(value);
    }
}
