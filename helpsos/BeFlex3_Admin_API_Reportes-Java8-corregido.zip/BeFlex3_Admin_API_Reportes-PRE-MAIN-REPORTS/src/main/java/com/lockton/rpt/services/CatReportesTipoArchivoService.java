package com.lockton.rpt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lockton.rpt.mappers.CatReportesTipoArchivoMapper;
import com.lockton.rpt.models.dto.CatReportesTipoArchivoDTO;
import com.lockton.rpt.models.entities.CatReportesTipoArchivo;
import com.lockton.rpt.repositories.CatReportesTipoArchivoRepository;

@Service
public class CatReportesTipoArchivoService {
    @Autowired
    CatReportesTipoArchivoRepository repository;

    public List<CatReportesTipoArchivoDTO> getAllFileTypes(){
        List<CatReportesTipoArchivo> entidades = repository.findAll();
        return CatReportesTipoArchivoMapper.MapperDTO(entidades);
    }
}
