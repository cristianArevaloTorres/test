package com.lockton.rpt.repositories;

import java.util.List;
import java.util.Map;

public interface ConfigIndicadoresDAO {

    List<Map<String, Object>> getSecciones(Integer idCorporativo);

    List<Map<String, Object>> getIndicadores(Integer idCorporativo, int idSeccion);

    List<Integer> getIndicadorIdsCorporativosPlantilla(int idIndicador);

    Map<String, Object> getIndicadorDetalle(Integer idCorporativo, int idIndicador);

    List<Map<String, Object>> getIndicadorParametros(Integer idCorporativo, int idIndicador);

    List<Map<String, Object>> getIndicadorMapeo(Integer idCorporativo, int idIndicador);

    List<List<Map<String, Object>>> ejecutarStoredProcedure(
            String nombreProcedimiento,
            List<Map<String, Object>> parametrosOrdenados);

    int saveCorporativoParametrosValores(int idCorporativo, int idIndicador,
            Map<String, String> valores, int idUsuario, String nombreUsuario);

    List<Map<String, Object>> getParametrosReporte(int idCorporativo,
            List<Map<String, Object>> indicadoresVisibles);

    List<Map<String, Object>> getParametroBindingsCorporativo(int idCorporativo,
            List<Map<String, Object>> indicadoresVisibles);

    Map<String, Object> getSeccionDetalle(int idSeccion, Integer idCorporativo);

    int addSeccionCatalog(String clave, String nombre, String descripcion,
            Integer idCorporativo, int idUsuario, String nombreUsuario);

    int updateSeccionCatalog(int idSeccion, String clave, String nombre, String descripcion,
            int idUsuario, String nombreUsuario);

    int saveSeccionConfig(int idSeccion, Integer idCorporativo, int orden, boolean mostrarEnReporte,
            String textoAdicional, String textosJson, int idUsuario, String nombreUsuario);

    int deleteSeccion(int idSeccion, int idUsuario, String nombreUsuario);

    int deleteSeccionConfig(int idSeccion, int idCorporativo, int idUsuario, String nombreUsuario);

    int addIndicadorCatalog(int idSeccion, Integer idStoredProcedure, String clave, String nombre,
            String descripcion, Integer idCorporativo, int idUsuario, String nombreUsuario);

    int updateIndicadorCatalog(int idIndicador, int idSeccion, Integer idStoredProcedure,
            String clave, String nombre, String descripcion, int idUsuario, String nombreUsuario);

    int saveIndicadorConfig(int idIndicador, Integer idCorporativo, String tipoClave, int orden,
            Integer ancho, Integer alto, boolean mostrarTitulo, boolean mostrarLeyenda,
            boolean mostrarEnReporte, String configJson, int idUsuario, String nombreUsuario);

    int deleteIndicador(int idIndicador, int idUsuario, String nombreUsuario);

    int deleteIndicadorConfig(int idIndicador, int idCorporativo, int idUsuario, String nombreUsuario);

    int activarCorporativo(int idCorporativo, Integer idSeccion, Integer idIndicador,
            int idUsuario, String nombreUsuario);

    int resetPlantillaCorporativo(int idCorporativo, int idUsuario, String nombreUsuario);

    boolean existePlantillaCorporativo(int idCorporativo);

    boolean hasSeccionConfigCorporativo(int idSeccion, int idCorporativo);

    boolean hasIndicadorConfigCorporativo(int idIndicador, int idCorporativo);

    List<Map<String, Object>> getStoredProcedures();

    Map<String, Object> getStoredProcedureDetalle(int idStoredProcedure);

    int addStoredProcedure(String clave, String nombre, String nombreReal, String descripcion,
            int idUsuario, String nombreUsuario);

    int updateStoredProcedure(int idSp, String clave, String nombre, String nombreReal, String descripcion,
            int idUsuario, String nombreUsuario);

    int deleteStoredProcedure(int idSp, int idUsuario, String nombreUsuario);

    List<Map<String, Object>> getStoredProcedureParametros(int idStoredProcedure);

    List<Map<String, Object>> getStoredProcedureSalidas(int idStoredProcedure);

    int addStoredProcedureParametro(int idStoredProcedure, String nombreParametro, String nombreVisual,
            String parametroSql, String tipoDato, int orden, boolean obligatorio, boolean filtroBase,
            boolean visible, int idUsuario, String nombreUsuario);

    int updateStoredProcedureParametro(int idParametro, String nombreVisual, String parametroSql,
            String tipoDato, int orden, boolean obligatorio, boolean filtroBase, boolean visible,
            int idUsuario, String nombreUsuario);

    int deleteStoredProcedureParametro(int idParametro, int idUsuario, String nombreUsuario);

    int addStoredProcedureSalida(int idStoredProcedure, int indiceResultSet, String nombreColumna,
            String nombreVisual, String tipoDato, int orden, int idUsuario, String nombreUsuario);

    int updateStoredProcedureSalida(int idSalida, String nombreVisual, String tipoDato, int orden,
            int idUsuario, String nombreUsuario);

    int deleteStoredProcedureSalida(int idSalida, int idUsuario, String nombreUsuario);
}
