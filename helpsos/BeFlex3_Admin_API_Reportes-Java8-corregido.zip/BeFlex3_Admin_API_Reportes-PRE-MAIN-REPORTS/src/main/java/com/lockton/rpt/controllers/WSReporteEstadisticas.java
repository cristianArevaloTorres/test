package com.lockton.rpt.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lockton.rpt.services.impl.CatCorporativosService;
import com.lockton.rpt.services.ReporteEstadisticasIndicadoresService;
import com.lockton.rpt.util.SafeApiError;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("beflex/reporte-estadisticas")
public class WSReporteEstadisticas {

    private final ReporteEstadisticasIndicadoresService service;
    private final CatCorporativosService catCorporativosService;

    public WSReporteEstadisticas(ReporteEstadisticasIndicadoresService service,
            CatCorporativosService catCorporativosService) {
        this.service = service;
        this.catCorporativosService = catCorporativosService;
    }

    /**
     * Catálogo temporal de corporativos (ff_Empresa). Sustituir por endpoint definitivo en BeFlex3.
     */
    @GetMapping("/catcorporativos")
    public ResponseEntity<Map<String, Object>> catCorporativos() {
        return ok(catCorporativosService.listarCorporativos());
    }

    @GetMapping("/secciones")
    public ResponseEntity<Map<String, Object>> secciones() {
        return ok(service.listarSecciones());
    }

    @GetMapping("/parametros")
    public ResponseEntity<Map<String, Object>> parametros(@RequestParam(defaultValue = "364") int idCorporativo) {
        return okSingle(service.getParametros(idCorporativo));
    }

    @GetMapping("/s1/razon-social")
    public ResponseEntity<Map<String, Object>> s1RazonSocial(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s1RazonSocial(idCorporativo));
    }

    @GetMapping("/s1/genero")
    public ResponseEntity<Map<String, Object>> s1Genero(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s1Genero(idCorporativo));
    }

    @GetMapping("/s1/genero/grafica")
    public ResponseEntity<Map<String, Object>> s1GeneroGrafica(@RequestParam(defaultValue = "364") int idCorporativo) {
        try {
            return okSingle(service.s1GeneroGrafica(idCorporativo));
        } catch (IllegalStateException ex) {
            return error(ex.getMessage());
        }
    }

    @GetMapping("/s1/generacion")
    public ResponseEntity<Map<String, Object>> s1Generacion(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s1Generacion(idCorporativo));
    }

    @GetMapping("/s1/perfil")
    public ResponseEntity<Map<String, Object>> s1Perfil(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s1Perfil(idCorporativo));
    }

    @GetMapping("/s2/participacion-general")
    public ResponseEntity<Map<String, Object>> s2ParticipacionGeneral(@RequestParam(defaultValue = "364") int idCorporativo) {
        return okSingle(service.s2ParticipacionGeneral(idCorporativo));
    }

    @GetMapping("/s2/participacion-empresa")
    public ResponseEntity<Map<String, Object>> s2ParticipacionEmpresa(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s2ParticipacionEmpresa(idCorporativo));
    }

    @GetMapping("/s2/solicitudes-dia")
    public ResponseEntity<Map<String, Object>> s2SolicitudesDia(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s2SolicitudesDia(idCorporativo));
    }

    @GetMapping("/s2/participacion-perfil")
    public ResponseEntity<Map<String, Object>> s2ParticipacionPerfil(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s2ParticipacionPerfil(idCorporativo));
    }

    @GetMapping("/s3/opcionales-resumen")
    public ResponseEntity<Map<String, Object>> s3OpcionalesResumen(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s3OpcionalesResumen(idCorporativo));
    }

    @GetMapping("/s3/opcionales-tabla")
    public ResponseEntity<Map<String, Object>> s3OpcionalesTabla(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s3OpcionalesTabla(idCorporativo));
    }

    @GetMapping("/s3/opcionales-generacion")
    public ResponseEntity<Map<String, Object>> s3OpcionalesGeneracion(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s3OpcionalesGeneracion(idCorporativo));
    }

    @GetMapping("/s3/composicion-familiar")
    public ResponseEntity<Map<String, Object>> s3ComposicionFamiliar(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s3ComposicionFamiliar(idCorporativo));
    }

    @GetMapping("/s3/movilidad")
    public ResponseEntity<Map<String, Object>> s3Movilidad(@RequestParam(defaultValue = "364") int idCorporativo) {
        return ok(service.s3Movilidad(idCorporativo));
    }

    private ResponseEntity<Map<String, Object>> ok(List<Map<String, Object>> data) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", data);
        return new ResponseEntity<>(body, HttpStatus.OK);
    }

    private ResponseEntity<Map<String, Object>> okSingle(Map<String, Object> data) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", data);
        return new ResponseEntity<>(body, HttpStatus.OK);
    }

    private ResponseEntity<Map<String, Object>> error(String message) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("error", SafeApiError.sanitizeMessage(
                message,
                "No fue posible completar la operación. Intenta nuevamente."));
        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
