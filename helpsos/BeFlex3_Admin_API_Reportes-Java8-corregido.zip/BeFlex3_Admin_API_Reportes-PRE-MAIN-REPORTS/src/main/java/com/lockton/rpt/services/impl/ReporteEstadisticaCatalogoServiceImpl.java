package com.lockton.rpt.services.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpFiltroRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpSalidaRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpValidacionRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpValidacionLoteRequestDTO;
import com.lockton.rpt.repositories.ReporteEstadisticaCatalogoDAO;
import com.lockton.rpt.services.ReporteEstadisticaCatalogoService;
import com.lockton.rpt.services.ReporteEstadisticaSnapshotService;

import org.springframework.stereotype.Service;

@Service
public class ReporteEstadisticaCatalogoServiceImpl implements ReporteEstadisticaCatalogoService {
    private final ReporteEstadisticaCatalogoDAO repository;
    private final ReporteEstadisticaSnapshotService snapshotService;

    public ReporteEstadisticaCatalogoServiceImpl(
            ReporteEstadisticaCatalogoDAO repository,
            ReporteEstadisticaSnapshotService snapshotService) {
        this.repository = repository;
        this.snapshotService = snapshotService;
    }

    @Override
    public Map<String, Object> obtenerContextoValidacion(int idCorporativo) {
        positive(idCorporativo, "El corporativo es requerido.");
        return repository.obtenerContextoValidacion(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> listarFiltros() {
        return repository.listarFiltros();
    }

    @Override
    public List<Map<String, Object>> listarStoredProcedures(boolean incluirBajas) {
        return repository.listarStoredProcedures(incluirBajas);
    }

    @Override
    public Map<String, Object> obtenerStoredProcedure(int idStoredProcedure) {
        positive(idStoredProcedure, "El id del stored procedure es requerido.");
        Map<String, Object> result = repository.obtenerStoredProcedure(idStoredProcedure);
        Object item = result.get("storedProcedure");
        if (!(item instanceof Map) || ((Map<?, ?>) item).isEmpty()) {
            throw new IllegalArgumentException("El stored procedure solicitado no existe.");
        }
        return result;
    }

    @Override
    public Map<String, Object> validarStoredProcedure(ReporteEstadisticaSpValidacionRequestDTO request) {
        required(request, "La solicitud de validación es requerida.");
        text(request.getNombreTecnico(), "El nombre técnico es requerido.");
        if (Boolean.TRUE.equals(request.getEjecutarMuestra())) {
            positive(value(request.getIdCorporativo()), "El corporativo es requerido para ejecutar la muestra.");
            positive(value(request.getIdVigencia()), "La vigencia es requerida para ejecutar la muestra.");
            snapshotService.asegurarDisponible(
                    request.getIdCorporativo(),
                    request.getIdVigencia());
        }
        return repository.validarStoredProcedure(request);
    }

    @Override
    public List<Map<String, Object>> validarStoredProceduresLote(ReporteEstadisticaSpValidacionLoteRequestDTO request) {
        required(request, "La solicitud de validación por lote es requerida.");
        positive(value(request.getIdCorporativo()), "El corporativo es requerido.");
        positive(value(request.getIdVigencia()), "La vigencia es requerida.");
        positive(value(request.getIdUsuario()), "El usuario es requerido.");
        positive(value(request.getIdCorporativo()), "El corporativo es requerido para validar la consulta.");
        positive(value(request.getIdVigencia()), "La vigencia es requerida para validar la consulta.");
        snapshotService.asegurarDisponible(
                request.getIdCorporativo(),
                request.getIdVigencia());
        if (request.getIdsStoredProcedure() == null || request.getIdsStoredProcedure().isEmpty()) {
            throw new IllegalArgumentException("Selecciona al menos una fuente de datos para comprobar.");
        }

        List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();
        for (Integer id : request.getIdsStoredProcedure()) {
            if (id == null || id.intValue() <= 0) continue;
            Map<String, Object> item = new LinkedHashMap<String, Object>();
            item.put("IdStoredProcedure", id);
            try {
                Map<String, Object> detail = obtenerStoredProcedure(id.intValue());
                @SuppressWarnings("unchecked")
                Map<String, Object> storedProcedure = (Map<String, Object>) detail.get("storedProcedure");
                String technicalName = storedProcedure == null ? null : String.valueOf(storedProcedure.get("NombreTecnico"));

                ReporteEstadisticaSpValidacionRequestDTO validation = new ReporteEstadisticaSpValidacionRequestDTO();
                validation.setNombreTecnico(technicalName);
                validation.setIdCorporativo(request.getIdCorporativo());
                validation.setIdVigencia(request.getIdVigencia());
                validation.setEjecutarMuestra(Boolean.TRUE);
                validation.setIdUsuario(request.getIdUsuario());

                item.put("Resultado", validarStoredProcedure(validation));
                item.put("Error", null);
            } catch (Exception ex) {
                item.put("Resultado", null);
                item.put("Error", "No fue posible validar esta consulta.");
                item.put("DetalleTecnico", ex.getMessage());
            }
            results.add(item);
        }
        return results;
    }

    @Override
    public Map<String, Object> obtenerUltimoSnapshot(
            int idCorporativo, int idStoredProcedure, int pagina, int tamanoPagina) {
        positive(idCorporativo, "El corporativo es requerido.");
        positive(idStoredProcedure, "El id del stored procedure es requerido.");
        int normalizedPage = Math.max(1, pagina);
        int normalizedPageSize = Math.max(1, Math.min(500, tamanoPagina));
        return repository.obtenerUltimoSnapshot(
                idCorporativo, idStoredProcedure, normalizedPage, normalizedPageSize);
    }

    @Override
    public Map<String, Object> crearStoredProcedure(ReporteEstadisticaSpRequestDTO request) {
        validateSpRequest(request);
        Map<String, Object> validation = validateForSave(request);
        Map<String, Object> result = repository.crearStoredProcedure(request);
        int id = requiredPositiveId(
                result == null ? null : result.get("IdStoredProcedure"),
                "La consulta fue registrada, pero la base de datos no devolvió un identificador válido.");
        syncValidation(id, validation, request.getIdUsuario().intValue(), true);
        return result;
    }

    @Override
    public Map<String, Object> actualizarStoredProcedure(int idStoredProcedure, ReporteEstadisticaSpRequestDTO request) {
        positive(idStoredProcedure, "El id del stored procedure es requerido.");
        validateSpRequest(request);
        Map<String, Object> validation = validateForSave(request);
        Map<String, Object> result = repository.actualizarStoredProcedure(idStoredProcedure, request);
        syncValidation(idStoredProcedure, validation, request.getIdUsuario().intValue(), false);
        return result;
    }

    @Override
    public Map<String, Object> cambiarEstatusStoredProcedure(int idStoredProcedure, CambioEstatusRequestDTO request) {
        positive(idStoredProcedure, "El id del stored procedure es requerido.");
        validateStatus(request);
        return repository.cambiarEstatusStoredProcedure(idStoredProcedure, request);
    }

    @Override
    public Map<String, Object> revalidarStoredProcedure(int idStoredProcedure, int idUsuario, int idCorporativo, int idVigencia) {
        positive(idStoredProcedure, "El id del stored procedure es requerido.");
        positive(idUsuario, "El usuario es requerido.");
        positive(idCorporativo, "El corporativo es requerido.");
        positive(idVigencia, "La vigencia es requerida.");
        Map<String, Object> detail = obtenerStoredProcedure(idStoredProcedure);
        @SuppressWarnings("unchecked") Map<String,Object> sp=(Map<String,Object>)detail.get("storedProcedure");
        ReporteEstadisticaSpValidacionRequestDTO v=new ReporteEstadisticaSpValidacionRequestDTO();
        v.setNombreTecnico(String.valueOf(sp.get("NombreTecnico"))); v.setIdCorporativo(Integer.valueOf(idCorporativo));
        v.setIdVigencia(Integer.valueOf(idVigencia)); v.setEjecutarMuestra(Boolean.TRUE); v.setIdUsuario(Integer.valueOf(idUsuario));
        Map<String,Object> validation=validarStoredProcedure(v);
        syncValidation(idStoredProcedure,validation,idUsuario,false);
        Map<String,Object> out=new LinkedHashMap<String,Object>(); out.put("Code","RPE-QRY-REVAL"); out.put("Status",Boolean.TRUE);
        out.put("Message","Consulta revalidada y salidas sincronizadas correctamente."); out.put("IdStoredProcedure",Integer.valueOf(idStoredProcedure)); return out;
    }

    @SuppressWarnings("unchecked")
    private Map<String,Object> validateForSave(ReporteEstadisticaSpRequestDTO request) {
        ReporteEstadisticaSpValidacionRequestDTO v=new ReporteEstadisticaSpValidacionRequestDTO();
        v.setNombreTecnico(request.getNombreTecnico()); v.setIdCorporativo(request.getIdCorporativo()); v.setIdVigencia(request.getIdVigencia());
        v.setEjecutarMuestra(Boolean.TRUE); v.setIdUsuario(request.getIdUsuario());
        Map<String,Object> validation=validarStoredProcedure(v); Map<String,Object> resumen=(Map<String,Object>)validation.get("resumen");
        if (resumen==null || !Boolean.TRUE.equals(resumen.get("EsValido"))) throw new IllegalArgumentException(resumen==null?"La consulta no pudo validarse.":String.valueOf(resumen.get("Mensaje")));
        return validation;
    }

    @SuppressWarnings("unchecked")
    private void syncValidation(int id, Map<String,Object> validation, int idUsuario, boolean esAlta) {
        Map<String,Object> resumen=(Map<String,Object>)validation.get("resumen");
        List<Map<String,Object>> salidas=(List<Map<String,Object>>)validation.get("salidas");
        repository.sincronizarSalidas(id,salidas,resumen==null?null:String.valueOf(resumen.get("HashDefinicion")),idUsuario,esAlta);
    }

    private int requiredPositiveId(Object value, String message) {
        final int id;
        if (value instanceof Number) {
            id = ((Number) value).intValue();
        } else {
            try {
                id = Integer.parseInt(String.valueOf(value));
            } catch (Exception ex) {
                throw new IllegalStateException(message, ex);
            }
        }
        if (id <= 0) {
            throw new IllegalStateException(message);
        }
        return id;
    }

    @Override
    public Map<String, Object> crearSalida(int idStoredProcedure, ReporteEstadisticaSpSalidaRequestDTO request) {
        positive(idStoredProcedure, "El id del stored procedure es requerido.");
        validateSalida(request);
        return repository.crearSalida(idStoredProcedure, request);
    }

    @Override
    public Map<String, Object> actualizarSalida(int idSalida, ReporteEstadisticaSpSalidaRequestDTO request) {
        positive(idSalida, "El id de la salida es requerido.");
        validateSalida(request);
        return repository.actualizarSalida(idSalida, request);
    }

    @Override
    public Map<String, Object> cambiarEstatusSalida(int idSalida, CambioEstatusRequestDTO request) {
        positive(idSalida, "El id de la salida es requerido.");
        validateStatus(request);
        return repository.cambiarEstatusSalida(idSalida, request);
    }

    @Override
    public Map<String, Object> crearFiltro(int idStoredProcedure, ReporteEstadisticaSpFiltroRequestDTO request) {
        positive(idStoredProcedure, "El id del stored procedure es requerido.");
        validateFiltro(request);
        return repository.crearFiltro(idStoredProcedure, request);
    }

    @Override
    public Map<String, Object> actualizarFiltro(int idRelacion, ReporteEstadisticaSpFiltroRequestDTO request) {
        positive(idRelacion, "El id de la relación del filtro es requerido.");
        validateFiltro(request);
        return repository.actualizarFiltro(idRelacion, request);
    }

    @Override
    public Map<String, Object> cambiarEstatusFiltro(int idRelacion, CambioEstatusRequestDTO request) {
        positive(idRelacion, "El id de la relación del filtro es requerido.");
        validateStatus(request);
        return repository.cambiarEstatusFiltro(idRelacion, request);
    }

    private void validateSpRequest(ReporteEstadisticaSpRequestDTO request) {
        required(request, "La información del stored procedure es requerida.");
        text(request.getClave(), "La clave es requerida.");
        text(request.getNombre(), "El nombre es requerido.");
        text(request.getNombreTecnico(), "El nombre técnico es requerido.");
        positive(value(request.getIdUsuario()), "El usuario es requerido.");
    }

    private void validateSalida(ReporteEstadisticaSpSalidaRequestDTO request) {
        required(request, "La información de la salida es requerida.");
        text(request.getNombreColumna(), "El nombre de la columna es requerido.");
        text(request.getNombreVisual(), "El nombre visual es requerido.");
        text(request.getTipoDato(), "El tipo de dato es requerido.");
        positive(value(request.getOrden()), "El orden es requerido.");
        positive(value(request.getIdUsuario()), "El usuario es requerido.");
    }

    private void validateFiltro(ReporteEstadisticaSpFiltroRequestDTO request) {
        required(request, "La información del filtro es requerida.");
        positive(value(request.getIdFiltro()), "El filtro del catálogo es requerido.");
        text(request.getColumnaValor(), "La columna valor es requerida.");
        text(request.getColumnaTexto(), "La columna texto es requerida.");
        positive(value(request.getOrdenSugerido()), "El orden sugerido es requerido.");
        positive(value(request.getIdUsuario()), "El usuario es requerido.");
    }

    private void validateStatus(CambioEstatusRequestDTO request) {
        required(request, "La solicitud de cambio de estatus es requerida.");
        int status = value(request.getIdEstatus());
        if (status != 1 && status != 2) {
            throw new IllegalArgumentException("El estatus permitido es 1 activo o 2 baja lógica.");
        }
        positive(value(request.getIdUsuario()), "El usuario es requerido.");
    }

    private void required(Object value, String message) {
        if (value == null) throw new IllegalArgumentException(message);
    }

    private void text(String value, String message) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(message);
    }

    private void positive(int value, String message) {
        if (value <= 0) throw new IllegalArgumentException(message);
    }

    private int value(Integer value) {
        return value == null ? 0 : value.intValue();
    }
}
