package com.lockton.rpt.repositories;

import java.util.List;
import java.util.Map;

public interface SnapshotReporteDAO {

    Map<String, Object> resolverContexto(int idCorporativo);

    List<Map<String, Object>> listarProcedimientosSnapshot();

    int upsertPeriodo(int idCorporativo, int idVigencia, Integer idVigenciaAnterior,
            java.time.LocalDateTime fechaCorte, java.time.LocalDateTime fechaInicioVigencia,
            int idUsuario, String nombreUsuario, String estado, String detalleError);

    void limpiarTablaSnapshot(String tabla, int idCorporativo, int idVigencia,
            java.time.LocalDateTime fechaCorte);

    void insertarFilasSnapshot(String tabla, int idCorporativo, int idVigencia,
            Integer idVigenciaAnterior, java.time.LocalDateTime fechaCorte,
            List<Map<String, Object>> filas, int indiceResultSet);

    boolean existeSnapshot(int idCorporativo, int idVigencia, java.time.LocalDateTime fechaCorte);

    List<Map<String, Object>> consultarSnapshot(String tabla, int idCorporativo, int idVigencia,
            java.time.LocalDateTime fechaCorte, Map<String, String> filtrosPermitidos);

    List<Map<String, Object>> getParametrosCatalogoSp(int idStoredProcedure);

    List<Map<String, Object>> getParametrosRealesProcedimiento(String nombreProcedimiento);

    List<Map<String, Object>> listarPeriodosSnapshot(Integer idCorporativo);
}
