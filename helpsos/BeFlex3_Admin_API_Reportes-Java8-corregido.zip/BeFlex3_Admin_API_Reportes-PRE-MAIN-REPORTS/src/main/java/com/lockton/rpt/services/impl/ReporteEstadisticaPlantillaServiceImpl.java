package com.lockton.rpt.services.impl;

import com.lockton.rpt.repositories.ReporteEstadisticaPlantillaDAO;
import com.lockton.rpt.services.ReporteEstadisticaPlantillaService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class ReporteEstadisticaPlantillaServiceImpl implements ReporteEstadisticaPlantillaService {
    private final ReporteEstadisticaPlantillaDAO dao;

    public ReporteEstadisticaPlantillaServiceImpl(ReporteEstadisticaPlantillaDAO dao) {
        this.dao = dao;
    }

    @Override
    public Map<String, Object> obtenerGlobal() {
        return dao.obtenerPlantilla("GLOBAL", null);
    }

    @Override
    public Map<String, Object> obtenerCorporativa(int idCorporativo) {
        validateCorporativo(idCorporativo);
        return dao.obtenerPlantilla("CORPORATIVO", Integer.valueOf(idCorporativo));
    }


    @Override
    public Map<String, Object> obtenerCorporativaCompleta(
            int idCorporativo,
            int maxFilasPorFuente) {
        validateCorporativo(idCorporativo);
        int normalizedMax = maxFilasPorFuente <= 0
                ? 25000
                : Math.min(maxFilasPorFuente, 25000);
        return dao.obtenerPlantillaCompletaBeflex(idCorporativo, normalizedMax);
    }

    @Override
    public Map<String, Object> obtenerCatalogos() {
        return dao.obtenerCatalogos();
    }

    @Override
    public Map<String, Object> guardarGlobal(Map<String, Object> plantilla, int idUsuario) {
        validatePayload(plantilla, idUsuario);
        return dao.guardarPlantilla("GLOBAL", null, plantilla, idUsuario);
    }

    @Override
    public Map<String, Object> guardarCorporativa(
            int idCorporativo,
            Map<String, Object> plantilla,
            int idUsuario) {
        validateCorporativo(idCorporativo);
        validatePayload(plantilla, idUsuario);
        return dao.guardarPlantilla(
                "CORPORATIVO",
                Integer.valueOf(idCorporativo),
                plantilla,
                idUsuario);
    }

    @Override
    public Map<String, Object> replicarCorporativa(int idCorporativo, int idUsuario) {
        validateCorporativo(idCorporativo);
        validateUsuario(idUsuario);
        return dao.replicarPlantillaCorporativo(idCorporativo, idUsuario);
    }

    @Override
    public Map<String, Object> crearCorporativaVacia(int idCorporativo, int idUsuario) {
        validateCorporativo(idCorporativo);
        validateUsuario(idUsuario);
        return dao.crearPlantillaCorporativaVacia(idCorporativo, idUsuario);
    }

    @Override
    public Map<String, Object> obtenerPreview(
            int idCorporativo,
            int idStoredProcedure,
            int maxFilas) {
        validateCorporativo(idCorporativo);
        if (idStoredProcedure <= 0) {
            throw new IllegalArgumentException("El Stored Procedure es requerido.");
        }
        int normalizedMax = maxFilas <= 0 ? 100 : Math.min(maxFilas, 500);
        return dao.obtenerPreview(idCorporativo, idStoredProcedure, normalizedMax);
    }

    @Override
    public Map<String, Object> obtenerDatosBeflex(
            int idCorporativo,
            int idStoredProcedure,
            int maxFilas) {
        validateCorporativo(idCorporativo);
        if (idStoredProcedure <= 0) {
            throw new IllegalArgumentException("El Stored Procedure es requerido.");
        }
        int normalizedMax = maxFilas <= 0 ? 10000 : Math.min(maxFilas, 25000);
        return dao.obtenerDatosBeflex(idCorporativo, idStoredProcedure, normalizedMax);
    }

    private void validatePayload(Map<String, Object> plantilla, int idUsuario) {
        validateUsuario(idUsuario);
        if (plantilla == null || plantilla.isEmpty()) {
            throw new IllegalArgumentException("La configuración de la plantilla es requerida.");
        }
    }

    private void validateCorporativo(int idCorporativo) {
        if (idCorporativo <= 0) {
            throw new IllegalArgumentException("El corporativo es requerido.");
        }
    }

    private void validateUsuario(int idUsuario) {
        if (idUsuario <= 0) {
            throw new IllegalArgumentException("El usuario es requerido.");
        }
    }
}
