package com.lockton.rpt.models.dto.crea17;

import java.util.List;

public class ReporteEstadisticaFiltroOrdenRequestDTO {
    private Integer idUsuario;
    private List<ReporteEstadisticaFiltroOrdenItemDTO> elementos;

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public List<ReporteEstadisticaFiltroOrdenItemDTO> getElementos() { return elementos; }
    public void setElementos(List<ReporteEstadisticaFiltroOrdenItemDTO> elementos) { this.elementos = elementos; }
}
