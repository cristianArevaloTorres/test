package com.lockton.rpt.repositories;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.lockton.rpt.models.entities.VwControlReporte;

@Repository
public interface FiltroRepository extends JpaRepository<VwControlReporte, Long> {
    @Query(value = "EXEC FF_ConsultaReportesGenFiltro ?, ?, ?, ?, ?, ? ", nativeQuery = true)
    List<VwControlReporte> buscar(
        @Param("IdEmpresa") int idEmpresa,
        @Param("IdEmpleado") int idEmpleado,
        @Param("IdReporte") int idReporte,
        @Param("EstatusReporte") int estatusReporte,
        @Param("FechaIni") Date FechaIni,
        @Param("FechaFin") Date FechaFin
    );
}
