package com.lockton.rpt.models.dto.crea17;

import java.util.Map;

public class PlantillaPortadaGuardarRequestDTO {
    private Map<String, Object> portada;
    private Integer idUsuario;

    public Map<String, Object> getPortada() { return portada; }
    public void setPortada(Map<String, Object> portada) { this.portada = portada; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
