package com.lockton.rpt.repositories.jdbc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.rpt.repositories.ReporteEstadisticaPlantillaCatalogoDAO;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class JDBCReporteEstadisticaPlantillaCatalogoDAO
        implements ReporteEstadisticaPlantillaCatalogoDAO {

    private final DataSource dataSource;
    private final ObjectMapper objectMapper;

    public JDBCReporteEstadisticaPlantillaCatalogoDAO(
            @Qualifier("dataSourceRPT") DataSource dataSource,
            ObjectMapper objectMapper) {
        this.dataSource = dataSource;
        this.objectMapper = objectMapper;
    }

    @Override
    public List<Map<String, Object>> listar(
            String tipo,
            Integer idCorporativo,
            boolean incluirBajas) {
        return getResultSet(execute("dbo.ff_CReporteEstadisticaPlantillasCatalogo",
                idCorporativo, incluirBajas, tipo), 0);
    }

    @Override
    public Map<String, Object> catalogos() {
        List<List<Map<String, Object>>> resultSets =
                execute("dbo.ff_CReporteEstadisticaPlantillaCatalogoCatalogos");
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("idiomas", getResultSet(resultSets, 0));
        result.put("tiposArchivo", getResultSet(resultSets, 1));
        result.put("tamanos", getResultSet(resultSets, 2));
        result.put("global", getResultSet(resultSets, 3));
        return result;
    }

    @Override
    public Map<String, Object> validarNombre(
            String tipo,
            Integer idCorporativo,
            String nombre,
            Integer idPlantilla) {
        return one("dbo.ff_CValidarReporteEstadisticaPlantillaNombre",
                tipo, idCorporativo, nombre, idPlantilla);
    }

    @Override
    public Map<String, Object> guardar(
            Integer idPlantilla,
            String tipo,
            Integer idCorporativo,
            String nombre,
            String descripcion,
            int idIdioma,
            Integer idTipoArchivo,
            Integer idTamanoDocumento,
            String orientacion,
            int idUsuario) {
        return one("dbo.ff_GReporteEstadisticaPlantillaCatalogo",
                idPlantilla, idCorporativo, nombre, descripcion, idIdioma, idUsuario, tipo,
                idTipoArchivo, idTamanoDocumento, orientacion);
    }

    @Override
    public Map<String, Object> cambiarEstatus(int idPlantilla, int idEstatus, int idUsuario) {
        return one("dbo.ff_UEstatusReporteEstadisticaPlantillaCatalogo",
                idPlantilla, idEstatus, idUsuario);
    }

    @Override
    public Map<String, Object> duplicarMismoNivel(
            int idPlantillaOrigen,
            String tipoDestino,
            Integer idCorporativo,
            String nombre,
            Integer idIdioma,
            int idUsuario) {
        return one("dbo.ff_DuplicarReporteEstadisticaPlantilla",
                idPlantillaOrigen,
                idCorporativo,
                nombre,
                idIdioma,
                idUsuario,
                null,
                tipoDestino);
    }

    @Override
    public Map<String, Object> replicarGlobal(
            int idPlantillaGlobal,
            int idCorporativo,
            String nombre,
            Integer idIdioma,
            int idUsuario) {
        return one("dbo.ff_DuplicarReporteEstadisticaPlantilla",
                idPlantillaGlobal,
                idCorporativo,
                nombre,
                idIdioma,
                idUsuario,
                null,
                "CORPORATIVO");
    }

    @Override
    public Map<String, Object> obtenerDiseno(int idPlantilla) {
        return mapDesign(execute("dbo.ff_CReporteEstadisticaPlantillaPorId", idPlantilla));
    }

    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> guardarDiseno(
            int idPlantilla,
            Map<String, Object> payload,
            int idUsuario) {
        if (payload == null) {
            throw new IllegalArgumentException("La configuración de la plantilla es requerida.");
        }

        Object rawTemplate = payload.get("plantilla");
        if (!(rawTemplate instanceof Map)) {
            throw new IllegalArgumentException("El nodo plantilla es requerido.");
        }

        Map<String, Object> template = (Map<String, Object>) rawTemplate;
        template.put("idPlantilla", idPlantilla);
        String tipo = String.valueOf(template.get("tipo")).trim().toUpperCase();
        if (!"GLOBAL".equals(tipo) && !"CORPORATIVO".equals(tipo)) {
            throw new IllegalArgumentException("El tipo de plantilla no es válido.");
        }

        Integer idCorporativo = toInteger(template.get("idCorporativo"));

        Connection connection = null;
        try {
            String json = objectMapper.writeValueAsString(payload);
            connection = dataSource.getConnection();
            connection.setAutoCommit(false);

            Map<String, Object> result = one(connection,
                    "dbo.ff_GuardarReporteEstadisticaPlantilla",
                    tipo,
                    idCorporativo,
                    json,
                    idUsuario);

            one(connection,
                    "dbo.ff_GuardarReporteEstadisticaPlantillaTextos",
                    tipo,
                    idCorporativo,
                    json,
                    idUsuario);

            connection.commit();
            result.put("diseno", mapDesign(execute(connection, "dbo.ff_CReporteEstadisticaPlantillaPorId", idPlantilla)));
            return result;
        } catch (Exception exception) {
            rollbackQuietly(connection);
            throw new IllegalStateException(
                    "No fue posible guardar la configuración de la plantilla.", exception);
        } finally {
            closeQuietly(connection);
        }
    }

    @Override
    public Map<String, Object> guardarDocumento(
            int idPlantilla,
            Map<String, Object> documento,
            int idUsuario) {
        return oneJson("dbo.ff_GReporteEstadisticaPlantillaDocumento",
                idPlantilla, documento, idUsuario);
    }

    @Override
    public Map<String, Object> guardarPortada(
            int idPlantilla,
            Map<String, Object> portada,
            int idUsuario) {
        return oneJson("dbo.ff_GReporteEstadisticaPlantillaPortada",
                idPlantilla, portada, idUsuario);
    }

    @Override
    public Map<String, Object> guardarSeccion(
            int idPlantilla,
            Integer idSeccion,
            Map<String, Object> seccion,
            int idUsuario) {
        return oneJson("dbo.ff_GReporteEstadisticaPlantillaSeccion",
                idPlantilla, idSeccion, seccion, idUsuario);
    }

    @Override
    public Map<String, Object> guardarLienzo(
            int idPlantilla,
            int idSeccion,
            Map<String, Object> lienzo,
            int idUsuario) {
        return oneJson("dbo.ff_GReporteEstadisticaPlantillaLienzo",
                idPlantilla, idSeccion, lienzo, idUsuario);
    }

    private Map<String, Object> oneJson(
            String storedProcedure,
            Object... parameters) {
        Object[] serialized = new Object[parameters.length];
        for (int index = 0; index < parameters.length; index++) {
            Object parameter = parameters[index];
            if (parameter instanceof Map || parameter instanceof List) {
                try {
                    serialized[index] = objectMapper.writeValueAsString(parameter);
                } catch (Exception exception) {
                    throw new IllegalArgumentException(
                            "No fue posible serializar la configuración solicitada.", exception);
                }
            } else {
                serialized[index] = parameter;
            }
        }
        return one(storedProcedure, serialized);
    }

    private Map<String, Object> mapDesign(List<List<Map<String, Object>>> resultSets) {
        String[] keys = {
                "plantilla",
                "secciones",
                "paginas",
                "visualizaciones",
                "mapeos",
                "filtros",
                "colores",
                "seccionCorporativos",
                "visualizacionCorporativos",
                "textos",
                "indicadoresAsignados",
                "indicadorVistas",
                "indicadorMapeos",
                "indicadorColores",
                "indicadorFiltros",
                "indicadorTextos",
                "indicadorVariables",
                "indicadorVariableTokens"
        };
        Map<String, Object> result = new LinkedHashMap<>();
        for (int index = 0; index < keys.length; index++) {
            List<Map<String, Object>> rows = getResultSet(resultSets, index);
            result.put(keys[index], index == 0
                    ? (rows.isEmpty() ? null : rows.get(0))
                    : rows);
        }
        // Alias temporal para consumidores anteriores. El contrato oficial del diseñador
        // utiliza visualizacionCorporativos.
        result.put("visualCorporativos", result.get("visualizacionCorporativos"));
        result.put("existe", !getResultSet(resultSets, 0).isEmpty());
        return result;
    }

    @Override
    public Map<String, Object> asignables(int idPlantilla, Integer idSeccion) {
        List<List<Map<String, Object>>> resultSets =
                execute("dbo.ff_CReporteEstadisticaIndicadoresAsignables",
                        idPlantilla, idSeccion);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("indicadores", getResultSet(resultSets, 0));
        result.put("vistas", getResultSet(resultSets, 1));
        result.put("mapeos", getResultSet(resultSets, 2));
        result.put("colores", getResultSet(resultSets, 3));
        result.put("textos", getResultSet(resultSets, 4));
        return result;
    }

    @Override
    public Map<String, Object> asignar(
            int idSeccion,
            List<Integer> idsIndicador,
            int idUsuario) {
        try {
            return one("dbo.ff_GReporteEstadisticaPlantillaSeccionIndicadores",
                    idSeccion,
                    objectMapper.writeValueAsString(idsIndicador),
                    idUsuario);
        } catch (Exception exception) {
            throw new IllegalArgumentException(
                    "No fue posible serializar los indicadores seleccionados.", exception);
        }
    }

    @Override
    public Map<String, Object> ordenarIndicadores(
            int idSeccion,
            List<Integer> idsSeccionIndicador,
            int idUsuario) {
        try {
            return one("dbo.ff_UReporteEstadisticaPlantillaSeccionIndicadoresOrden",
                    idSeccion,
                    objectMapper.writeValueAsString(idsSeccionIndicador),
                    idUsuario);
        } catch (Exception exception) {
            throw new IllegalArgumentException(
                    "No fue posible serializar el orden de los indicadores.", exception);
        }
    }

    @Override
    public Map<String, Object> cambiarEstatusAsignacion(
            int idSeccionIndicador,
            int idEstatus,
            int idUsuario) {
        return one("dbo.ff_UEstatusReporteEstadisticaPlantillaSeccionIndicador",
                idSeccionIndicador, idEstatus, idUsuario);
    }

    private Map<String, Object> one(String storedProcedure, Object... parameters) {
        return lastRow(execute(storedProcedure, parameters));
    }

    private Map<String, Object> one(
            Connection connection,
            String storedProcedure,
            Object... parameters) throws SQLException {
        return lastRow(execute(connection, storedProcedure, parameters));
    }

    private Map<String, Object> lastRow(List<List<Map<String, Object>>> resultSets) {
        for (int index = resultSets.size() - 1; index >= 0; index--) {
            if (!resultSets.get(index).isEmpty()) {
                return resultSets.get(index).get(0);
            }
        }
        return new LinkedHashMap<>();
    }

    private List<Map<String, Object>> getResultSet(
            List<List<Map<String, Object>>> resultSets,
            int index) {
        return index < resultSets.size()
                ? resultSets.get(index)
                : new ArrayList<>();
    }

    private List<List<Map<String, Object>>> execute(
            String storedProcedure,
            Object... parameters) {
        try (Connection connection = dataSource.getConnection()) {
            return execute(connection, storedProcedure, parameters);
        } catch (SQLException exception) {
            throw new IllegalStateException(exception.getMessage(), exception);
        }
    }

    private List<List<Map<String, Object>>> execute(
            Connection connection,
            String storedProcedure,
            Object... parameters) throws SQLException {
        String call = buildCall(storedProcedure, parameters.length);
        List<List<Map<String, Object>>> resultSets = new ArrayList<>();

        try (CallableStatement statement = connection.prepareCall(call)) {
            bind(statement, parameters);
            boolean hasResult = statement.execute();

            while (true) {
                if (hasResult) {
                    try (ResultSet resultSet = statement.getResultSet()) {
                        resultSets.add(readRows(resultSet));
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
        }
        return resultSets;
    }

    private String buildCall(String storedProcedure, int parameterCount) {
        StringBuilder call = new StringBuilder("{call ").append(storedProcedure);
        if (parameterCount > 0) {
            call.append('(');
            for (int index = 0; index < parameterCount; index++) {
                if (index > 0) {
                    call.append(',');
                }
                call.append('?');
            }
            call.append(')');
        }
        return call.append('}').toString();
    }

    private void bind(CallableStatement statement, Object[] parameters)
            throws SQLException {
        for (int index = 0; index < parameters.length; index++) {
            Object value = parameters[index];
            int parameterIndex = index + 1;
            if (value == null) {
                statement.setNull(parameterIndex, Types.NULL);
            } else if (value instanceof Integer) {
                statement.setInt(parameterIndex, (Integer) value);
            } else if (value instanceof Boolean) {
                statement.setBoolean(parameterIndex, (Boolean) value);
            } else {
                statement.setString(parameterIndex, String.valueOf(value));
            }
        }
    }

    private List<Map<String, Object>> readRows(ResultSet resultSet)
            throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        ResultSetMetaData metadata = resultSet.getMetaData();
        while (resultSet.next()) {
            Map<String, Object> row = new LinkedHashMap<>();
            for (int column = 1; column <= metadata.getColumnCount(); column++) {
                row.put(metadata.getColumnLabel(column), resultSet.getObject(column));
            }
            rows.add(row);
        }
        return rows;
    }

    private Integer toInteger(Object value) {
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            return null;
        }
        return Integer.valueOf(String.valueOf(value));
    }

    private void rollbackQuietly(Connection connection) {
        if (connection == null) {
            return;
        }
        try {
            connection.rollback();
        } catch (SQLException ignored) {
            // Se preserva la excepción original.
        }
    }

    private void closeQuietly(Connection connection) {
        if (connection == null) {
            return;
        }
        try {
            connection.close();
        } catch (SQLException ignored) {
            // El contenedor administrará cualquier recurso restante.
        }
    }
}
