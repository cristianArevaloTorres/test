package com.lockton.rpt.mappers;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;
import com.lockton.rpt.models.dto.CatReportesParamsDTO;
import com.lockton.rpt.models.dto.CatReportesParamsRequest_DTO;
import com.lockton.rpt.models.entities.CatReportesParams;
import com.lockton.rpt.models.request.RequestCatReportesParamDTO;

public class CatReportesParamsMapper {

public static CatReportesParamsDTO MapperDTO(CatReportesParams ent) {
        CatReportesParamsDTO dto = new CatReportesParamsDTO();
        dto.setId(ent.getCatReportesParamsId());
        dto.setCatReportesSPId(ent.getCatReportesSPId());
        dto.setTipoDatoId(ent.getCatReportesTipoDatoId());
        dto.setNombre(ent.getCatReportesParamsNombre());
        dto.setDescripcion(ent.getCatReportesParamsDesc());
        dto.setOrden(ent.getCatReportesParamsOrden());
        dto.setEsid(ent.getEsid());
        return dto;
    }

    public static List<CatReportesParamsDTO> MapperDTO(List<CatReportesParams> ent) {
        return ent
            .stream()
            .map(CatReportesParamsMapper::MapperDTO)
            .collect(Collectors.toList());
    }

    public static CatReportesParams MapperEntity(CatReportesParamsDTO dto) {
        CatReportesParams ent = new CatReportesParams();
        ent.setCatReportesParamsId(dto.getId());
        ent.setCatReportesSPId(dto.getCatReportesSPId());
        ent.setCatReportesTipoDatoId(dto.getTipoDatoId());
        ent.setCatReportesParamsNombre(dto.getNombre());
        ent.setCatReportesParamsDesc(dto.getDescripcion());
        ent.setCatReportesParamsOrden(dto.getOrden());
        ent.setEsid(dto.getEsid());
        return ent;
    }
    
    public static List<CatReportesParams> MapperEntity(List<CatReportesParamsDTO> dto) {
        return dto
            .stream()
            .map(CatReportesParamsMapper::MapperEntity)
            .collect(Collectors.toList());
    }

    public static CatReportesParams mapToParametro(RequestCatReportesParamDTO dto, Integer spId) {
        CatReportesParams entity = new CatReportesParams();
        entity.setCatReportesSPId(spId);
        entity.setCatReportesTipoDatoId(dto.getCatReportesTipoDatoId());
        entity.setCatReportesParamsLongitud(String.valueOf(dto.getCatReportesParamsLongitud()));
        entity.setCatReportesParamsOrden(dto.getCatReportesParamsOrden());
        entity.setCatReportesParamsNombre(dto.getCatReportesParamsNombre());
        entity.setCatReportesParamsDesc(dto.getCatReportesParamsDesc());
        entity.setEsid(dto.getESid());
        entity.setCatReportesParamsUsuarioAdd(dto.getCatReportesParamsUsuarioAdd());
        entity.setCatReportesParamsFechaAdd(toLocalDateTime(dto.getCatReportesParamsFechaAdd()));
        return entity;
    }

    public static CatReportesParams mapToParametroDTOToEntity(CatReportesParamsRequest_DTO dto, Integer spId) {
        CatReportesParams entity = new CatReportesParams();
        entity.setCatReportesSPId(spId);
        entity.setCatReportesTipoDatoId(dto.getCatReportesTipoDatoId());
        entity.setCatReportesParamsLongitud(String.valueOf(dto.getCatReportesParamsLongitud()));
        entity.setCatReportesParamsOrden(dto.getCatReportesParamsOrden());
        entity.setCatReportesParamsNombre(dto.getCatReportesParamsNombre());
        entity.setCatReportesParamsDesc(dto.getCatReportesParamsDesc());
        entity.setEsid(dto.getESid());
        entity.setCatReportesParamsUsuarioAdd(dto.getCatReportesParamsUsuarioAdd());
        entity.setCatReportesParamsFechaAdd(dto.getCatReportesParamsFechaAdd());
        return entity;
    }

    public static LocalDateTime toLocalDateTime(String fecha) {
        if (fecha == null || fecha.trim().isEmpty()) {
            return null;
        }
        return OffsetDateTime.parse(fecha).toLocalDateTime();
    }
}
