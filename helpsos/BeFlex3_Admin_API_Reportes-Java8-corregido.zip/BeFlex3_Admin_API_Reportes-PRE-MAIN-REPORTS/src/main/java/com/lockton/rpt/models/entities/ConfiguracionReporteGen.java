package com.lockton.rpt.models.entities;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "bf_ConfiguracionReporteGen")
public class ConfiguracionReporteGen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "CfgRptId")
    private Long cfgRptId;
    @Basic(optional = false)
    @Column(name = "CfgRptClave")
    private String cfgRptClave;
    @Basic(optional = false)
    @Column(name = "CfgRptValor")
    private String cfgRptValor;
    @Basic(optional = false)
    @Column(name = "CfgRptDescripcion")
    private String cfgRptDescripcion;
    @Basic(optional = false)
    @Column(name = "CfgRptUsuarioAdd")
    private Integer cfgRptUsuarioAdd;
    @Basic(optional = false)
    @Column(name = "CfgRptFechaAdd")
    private Date cfgRptFechaAdd;
    @Basic(optional = false)
    @Column(name = "CfgRptUsuarioMod")
    private Integer cfgRptUsuarioMod;
    @Basic(optional = false)
    @Column(name = "CfgRptFechaMod")
    private Date cfgRptFechaMod;
    @Basic(optional = false)
    @Column(name = "CfgRptUsuarioDel")
    private Integer cfgRptUsuarioDel;
    @Basic(optional = false)
    @Column(name = "CfgRptFechaDel")
    private Date cfgRptFechaDel;
}