package com.lockton.rpt;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;


/**
* <p>La clase WsBeFlexApplication extiende de SpringBootServletInitializer que nos permite
* implementar de una manera tradicional la aplicación empaquetada como WAR.</p>
* 
* @author  DTI
* @since 1.0
*/
@EnableScheduling
@ServletComponentScan
@Configuration
@EnableAutoConfiguration
@SpringBootApplication(scanBasePackages = {
    "com.lockton.rpt.config",
    "com.lockton.rpt.controllers",
    "com.lockton.rpt.dao",
    "com.lockton.rpt.jobs",
    "com.lockton.rpt.models.entities",
    "com.lockton.rpt.repositories",
    "com.lockton.rpt.services",
    "com.lockton.rpt.services.impl",
    "com.lockton.rpt.util",
    "com.lockton.rpt.repe"
})

public class RptApplication extends SpringBootServletInitializer {
	private static final Logger LOGGER = LoggerFactory.getLogger(RptApplication.class);

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(RptApplication.class);
    }

	public static void main(String[] args) {
		LOGGER.info("Inicializando API de reportes en segundo plano...");
		SpringApplication.run(RptApplication.class, args);
	}
}
