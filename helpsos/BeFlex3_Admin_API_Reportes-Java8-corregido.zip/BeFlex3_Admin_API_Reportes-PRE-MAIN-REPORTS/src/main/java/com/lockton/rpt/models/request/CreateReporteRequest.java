package com.lockton.rpt.models.request;

import java.util.List;

public class CreateReporteRequest {
    private RequestCatReportesDTO requestCatReportes;
    private List<RequestCatReportesSPDTO> requestCatReportesSP;

    public RequestCatReportesDTO getRequestCatReportes() {
        return requestCatReportes;
    }

    public void setRequestCatReportes(RequestCatReportesDTO requestCatReportes) {
        this.requestCatReportes = requestCatReportes;
    }

    public List<RequestCatReportesSPDTO> getRequestCatReportesSP() {
        return requestCatReportesSP;
    }

    public void setRequestCatReportesSP(List<RequestCatReportesSPDTO> requestCatReportesSP) {
        this.requestCatReportesSP = requestCatReportesSP;
    }
}
