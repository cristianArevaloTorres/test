package com.lockton.rpt.mappers;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.CatReportesParamsResp_DTO;
import com.lockton.rpt.models.dto.CatReportesRSPS_DTO;
import com.lockton.rpt.models.dto.CatReportesRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesSPRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesTipoDatosResp_DTO;
import com.lockton.rpt.models.entities.CatReportes;
import com.lockton.rpt.models.entities.CatReportesParams;
import com.lockton.rpt.models.entities.CatReportesSP;
import com.lockton.rpt.models.entities.CatReportesTipoDatos;

public class ReportesEdicionMapper {
    public static CatReportes mapCatReportReqToCatReport(CatReportesRequest_DTO dto){
        CatReportes entity = new CatReportes();
        entity.setCatReportesId(dto.getCatReportesId());
        entity.setCatReportesNum(dto.getCatReportesNum());
        entity.setCatReportesNombre(dto.getCatReportesNombre());
        entity.setCatReportesDesc(dto.getCatReportesDesc());
        entity.setCatReportesTAId(dto.getCatReportesTAId());
        entity.setCatReportesFormato(dto.getCatReportesFormato());
        entity.setEsid(dto.getEsId());
        entity.setCatTipoReporteId(1);
        entity.setCatReportesUsuarioAdd(dto.getCatReportesUsuarioAdd());
        entity.setCatReportesFechaAdd(dto.getCatReportesFechaAdd());
        entity.setCatReportesUsuarioMod(dto.getCatReportesUsuarioMod());	
        entity.setCatReportesFechaMod(toLocalDateTime(dto.getCatReportesFechaMod()));
        return entity;
    }

    private static LocalDateTime toLocalDateTime(String fecha) {
        if (fecha == null || fecha.trim().isEmpty()) {
            return null;
        }
        return OffsetDateTime.parse(fecha).toLocalDateTime();
    }

    public static CatReportesRSPS_DTO MapperDTOSP (CatReportesSP data){
        CatReportesRSPS_DTO dto = new CatReportesRSPS_DTO();
        dto.setCatReportesSPId(data.getCatReportesSPId());
        dto.setCatReportesId(data.getCatReportesId());
        dto.setCatReportesSPNombre(data.getCatReportesSPNombre());
        dto.setCatReportesSPOrden(data.getCatReportesSPOrden());
        dto.setCatReportesSPDesc(data.getCatReportesSPDesc());
        dto.setESid(data.getEsid());
        dto.setCatReportesSPUsuarioAdd(data.getCatReportesSPUsuarioAdd());
        dto.setCatReportesSPFechaAdd(data.getCatReportesSPFechaAdd());
        dto.setCatReportesSPUsuarioMod(data.getCatReportesSPUsuarioMod());
        dto.setCatReportesSPFechaMod(data.getCatReportesSPFechaMod());
        dto.setCatReportesSPUsuarioDel(data.getCatReportesSPUsuarioDel());
        dto.setCatReportesSPFechaDel(data.getCatReportesSPFechaDel());
        return dto;
    }

    public static CatReportesParamsResp_DTO MapperParamDTO (CatReportesParams data){
        CatReportesParamsResp_DTO dto = new CatReportesParamsResp_DTO();
        dto.setCatReportesParamsId(data.getCatReportesParamsId());
        dto.setCatReportesSPId(data.getCatReportesSPId());
        dto.setCatReportesTipoDatoId(data.getCatReportesTipoDatoId());
        dto.setCatReportesParamsLongitud(data.getCatReportesParamsLongitud());
        dto.setCatReportesParamsOrden(data.getCatReportesParamsOrden());
        dto.setCatReportesParamsNombre(data.getCatReportesParamsNombre());
        dto.setESid(data.getEsid());
        dto.setCatReportesParamsUsuarioMod(data.getCatReportesParamsUsuarioMod());
        dto.setCatReportesParamsFechaMod(data.getCatReportesParamsFechaMod());
        dto.setCatReportesParamsUsuarioDel(data.getCatReportesParamsUsuarioDel());
        dto.setCatReportesParamsFechaDel(data.getCatReportesParamsFechaDel());
        return dto;
    }

    public static CatReportesTipoDatosResp_DTO MapperTipoDatoDTO(CatReportesTipoDatos data){
        CatReportesTipoDatosResp_DTO dto = new CatReportesTipoDatosResp_DTO();
        dto.setCatReportesTipoDatoId(data.getCatReportesTipoDatoId());
        dto.setCatReportesTipoDatoNombre(data.getCatReportesTipoDatoNombre());
        return dto;
    };

    public static List<CatReportesRSPS_DTO> mapCatReportesSPToCatReportesRSPS_DTO(List<CatReportesSP> data){
        if(data == null || data.isEmpty()){
            return new ArrayList<>();
        }
        return data
            .stream()
            .map(ReportesEdicionMapper::MapperDTOSP)
            .collect(Collectors.toList());
    }

    public static CatReportesSP MapperCatRepSPToCatRepSPReqDTO(CatReportesSPRequest_DTO dto){
        CatReportesSP sp = new CatReportesSP();
        sp.setCatReportesSPId(dto.getCatReportesSPId());	
        sp.setCatReportesId(dto.getCatReportesId());	
        sp.setCatReportesSPNombre(dto.getCatReportesSPNombre());	
        sp.setCatReportesSPOrden(dto.getCatReportesSPOrden());	
        sp.setCatReportesSPDesc(dto.getCatReportesSPDesc());	
        sp.setEsid(dto.getESid());	
        sp.setCatReportesSPUsuarioAdd(dto.getCatReportesSPUsuarioAdd());	
        sp.setCatReportesSPFechaAdd(dto.getCatReportesSPFechaAdd());	
        sp.setCatReportesSPUsuarioMod(dto.getCatReportesSPUsuarioMod());	
        sp.setCatReportesSPFechaMod(dto.getCatReportesSPFechaMod());	
        sp.setCatReportesSPUsuarioDel(dto.getCatReportesSPUsuarioDel());	
        sp.setCatReportesSPFechaDel(dto.getCatReportesSPFechaDel());
        return sp;
    }

    public static List<CatReportesParamsResp_DTO> MapperCatRepParamToParamDTO(List<CatReportesParams> data){
        if(data == null || data.isEmpty()){
            return new ArrayList<>();
        }
        return data
            .stream()
            .map(ReportesEdicionMapper::MapperParamDTO)
            .collect(Collectors.toList());
    }

    public static List<CatReportesTipoDatosResp_DTO> MapperCatRepTipoDatoToTipoDatoDTO(List<CatReportesTipoDatos> data){
        if(data == null || data.isEmpty()){
            return new ArrayList<>();
        }
        return data
            .stream()
            .map(ReportesEdicionMapper::MapperTipoDatoDTO)
            .collect(Collectors.toList());
    }

    




}
