package com.lockton.rpt.models.entities;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Entity
@Data
@Table(name = "VW_ReportesGenFiltro", schema = "dbo")
public class VwControlReporte {
    @Id
    @Column(name = "Id")
    private Long id;
    @Column(name = "IdReporte")
    private Integer idReporte;
    @Column(name = "NombreReporte")
    private String nombreReporte;
    @Column(name = "FechaSolicitud")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaSolicitud;
    @Column(name = "UsuarioSolicitud")
    private Integer usuarioSolicitud;
    @Column(name = "IdEstatus")
    private Integer idEstatus;
    @Column(name = "Estatus")
    private String estatus;
    @Column(name = "IdEmpresa")
    private Integer idEmpresa;
    @Column(name = "FechaGeneracion")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaGeneracion;
    @Column(name = "Ruta")
    private String ruta;
    @Column(name = "Observaciones")
    private String observaciones;
}