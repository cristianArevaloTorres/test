package com.lockton.rpt.services.impl.graficas;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import com.lockton.rpt.util.TextUtil;

final class ChartSupport {

    static final String[] DEFAULT_COLORS = {
            "#2563eb", "#16a34a", "#dc2626", "#ca8a04",
            "#9333ea", "#0891b2", "#ea580c", "#4b5563"
    };

    private ChartSupport() {
    }

    static String col(Map<String, Object> cfg, String... keys) {
        Object mapeoObj = cfg.get("mapeo");
        if (!(mapeoObj instanceof Map)) {
            return null;
        }
        @SuppressWarnings("unchecked")
        Map<String, Object> mapeo = (Map<String, Object>) mapeoObj;
        for (String key : keys) {
            Object val = mapeo.get(key);
            if (val != null && !TextUtil.isBlank(String.valueOf(val))) {
                return String.valueOf(val);
            }
        }
        return null;
    }

    static double num(Object value) {
        if (value == null) {
            return 0.0;
        }
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        String s = String.valueOf(value).trim().replace(",", ".");
        if (s.isEmpty()) {
            return 0.0;
        }
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException ex) {
            return 0.0;
        }
    }

    static int intVal(Object value, int defaultValue) {
        if (value == null || TextUtil.isBlank(String.valueOf(value))) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return defaultValue;
        }
    }

    static boolean boolVal(Object value, boolean defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }

    @SuppressWarnings("unchecked")
    static List<Map<String, Object>> rows(Map<String, Object> cfg) {
        Object filasObj = cfg.get("filas");
        if (!(filasObj instanceof List)) {
            return new ArrayList<>();
        }
        List<Map<String, Object>> out = new ArrayList<>();
        for (Object item : (List<Object>) filasObj) {
            if (item instanceof Map) {
                out.add((Map<String, Object>) item);
            }
        }
        return out;
    }

    static int width(Map<String, Object> cfg, int defaultValue) {
        return Math.max(intVal(cfg.get("width"), defaultValue), 200);
    }

    static int height(Map<String, Object> cfg, int defaultValue) {
        return Math.max(intVal(cfg.get("height"), defaultValue), 150);
    }

    static List<Color> palette(Map<String, Object> cfg, int n) {
        List<Color> colors = parseColors(cfg.get("colores"));
        if (colors.isEmpty()) {
            colors = new ArrayList<>();
            for (String hex : DEFAULT_COLORS) {
                colors.add(parseColor(hex));
            }
        }
        List<Color> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            out.add(colors.get(i % colors.size()));
        }
        return out;
    }

    static List<Color> spectralColors(int n) {
        Color[] stops = {
                new Color(0xd7, 0x30, 0x27),
                new Color(0xfc, 0x8d, 0x59),
                new Color(0xfe, 0xe0, 0x8b),
                new Color(0xe6, 0xf5, 0x98),
                new Color(0x66, 0xc2, 0xa5),
                new Color(0x5e, 0x4f, 0xa2)
        };
        if (n <= 0) {
            return new ArrayList<>();
        }
        if (n == 1) {
            List<Color> single = new ArrayList<>();
            single.add(stops[2]);
            return single;
        }
        List<Color> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            float t = 0.15f + (0.70f * i / (n - 1));
            float scaled = t * (stops.length - 1);
            int idx = Math.min((int) scaled, stops.length - 2);
            float frac = scaled - idx;
            out.add(interpolate(stops[idx], stops[idx + 1], frac));
        }
        return out;
    }

    static List<Color> pieColors(Map<String, Object> cfg, int n) {
        List<Color> custom = parseColors(cfg.get("colores"));
        if (!custom.isEmpty()) {
            List<Color> out = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                out.add(custom.get(i % custom.size()));
            }
            return out;
        }
        return spectralColors(n);
    }

    @SuppressWarnings("unchecked")
    static List<Color> parseColors(Object raw) {
        List<Color> out = new ArrayList<>();
        if (raw instanceof List) {
            for (Object item : (List<Object>) raw) {
                if (item != null && !TextUtil.isBlank(String.valueOf(item))) {
                    out.add(parseColor(String.valueOf(item).trim()));
                }
            }
        }
        return out;
    }

    static Color parseColor(String value) {
        String s = value.trim();
        if (s.startsWith("#")) {
            s = s.substring(1);
        }
        try {
            if (s.length() == 6) {
                int rgb = Integer.parseInt(s, 16);
                return new Color((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
            }
            if (s.length() == 8) {
                int argb = (int) Long.parseLong(s, 16);
                return new Color((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF, (argb >> 24) & 0xFF);
            }
        } catch (NumberFormatException ignored) {
            // fallback below
        }
        return Color.GRAY;
    }

    static Color interpolate(Color a, Color b, float t) {
        int r = Math.round(a.getRed() + (b.getRed() - a.getRed()) * t);
        int g = Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * t);
        int bl = Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * t);
        return new Color(r, g, bl);
    }

    static byte[] pngFromImage(BufferedImage image) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        ImageIO.write(image, "png", buffer);
        return buffer.toByteArray();
    }

    static BufferedImage blankImage(int width, int height) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, height);
        g.dispose();
        return image;
    }

    static void drawCenteredText(Graphics2D g, String text, int width, int height, Font font, Color color) {
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setFont(font);
        g.setColor(color);
        int textWidth = g.getFontMetrics().stringWidth(text);
        int textHeight = g.getFontMetrics().getAscent();
        g.drawString(text, (width - textWidth) / 2, (height + textHeight) / 2);
    }

    static Map<String, Object> chartResult(Object chartId, byte[] png, Map<String, Object> cfg) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("id", chartId);
        result.put("mimeType", "image/png");
        result.put("base64", Base64.getEncoder().encodeToString(png));
        result.put("width", cfg.get("width"));
        result.put("height", cfg.get("height"));
        return result;
    }

    static String formatCount(int n) {
        return String.format("%,d", n).replace(',', '.');
    }

    static String formatValue(double value) {
        if (Math.rint(value) == value) {
            return String.format("%,.0f", value).replace(',', '.');
        }
        return String.format("%,.2f", value).replace(',', '.');
    }
}
