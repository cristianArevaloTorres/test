package com.lockton.rpt.services;

import com.lockton.rpt.models.entities.FfCObtenPlantilla;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;

@Profile("dev")
@Service
public class TestService {

    @Autowired
	JdbcTemplate jdbcTemplate;

    public List<LinkedCaseInsensitiveMap> reporteDeAsegurados(String empresas, String fechaIni,
            String fechaFin, String estatus, String parentescos,
            String perfiles, String sueldo, Integer admIdEmpresa,
            Integer admIdPerfil) {
        List<Object> data = invokeReportes(empresas, fechaIni, fechaFin, estatus, parentescos, perfiles, sueldo);
        LinkedCaseInsensitiveMap<String> columnas = obtenerColumnas(admIdEmpresa, admIdPerfil, sueldo);
        List<LinkedCaseInsensitiveMap> filas = new ArrayList();
        data.forEach((fila) -> {
            LinkedCaseInsensitiveMap<Object> f = new LinkedCaseInsensitiveMap<Object>();
            columnas.forEach((k, v) -> {
                if (((LinkedCaseInsensitiveMap<String>) fila).containsKey(k)) {
                    Object obj;
                    if (((LinkedCaseInsensitiveMap<String>) fila).get(k) instanceof String) {
                        obj = ((LinkedCaseInsensitiveMap<String>) fila).get(k).trim();
                    } else {
                        obj = ((LinkedCaseInsensitiveMap<String>) fila).get(k);
                    }
                    f.put(v, obj);
                }
            });
            filas.add(f);
        });
        return filas;
    }

    private LinkedCaseInsensitiveMap<String> obtenerColumnas(Integer admIdEmpresa, Integer admIdPerfil, String sueldo) {
        List<FfCObtenPlantilla> columnasDinamicas = new ArrayList();
        List<FfCObtenPlantilla> columnasDinamicasA = invokePlantilla(admIdEmpresa, admIdPerfil, "ff_Admi_AltaTitulares.aspx");
        columnasDinamicas.addAll(columnasDinamicasA);
        List<FfCObtenPlantilla> columnasDinamicasM = invokePlantilla(admIdEmpresa, admIdPerfil, "ff_Admi_ActualizaTitulares.aspx");
        columnasDinamicasM.forEach((columna) -> {
            if (!columnasDinamicas.contains(columna)) {
                columnasDinamicas.add(columna);
            }
        });
        List<FfCObtenPlantilla> columnasDinamicasBaja = invokePlantilla(admIdEmpresa, admIdPerfil, "ff_Admi_BajaTitulares.aspx");
        columnasDinamicasBaja.forEach((columna) -> {
            if (!columnasDinamicas.contains(columna)) {
                columnasDinamicas.add(columna);
            }
        });
        List<FfCObtenPlantilla> columnasDinamicasDependientesAlta = invokePlantilla(admIdEmpresa, admIdPerfil, "ff_Admi_Altadependientes.aspx");
        columnasDinamicasDependientesAlta.forEach((columna) -> {
            if (!columnasDinamicas.contains(columna)) {
                columnasDinamicas.add(columna);
            }
        });
        List<FfCObtenPlantilla> columnasDinamicasConsulta = invokePlantilla(admIdEmpresa, admIdPerfil, "ff_Admi_Consulta.aspx");
        columnasDinamicasConsulta.forEach((columna) -> {
            if (!columnasDinamicas.contains(columna)) {
                columnasDinamicas.add(columna);
            }
        });
        columnasDinamicas.sort(Comparator.comparing(FfCObtenPlantilla::getCpOrden));
        LinkedCaseInsensitiveMap<String> headers = new LinkedCaseInsensitiveMap<String>();
        LinkedCaseInsensitiveMap<String> sortedHeaders = new LinkedCaseInsensitiveMap<String>();
        LinkedCaseInsensitiveMap<String> lastHeaders = new LinkedCaseInsensitiveMap<String>();

        List<String> fijos = Arrays.asList(
                "Id", "EMIdParentesco",
                "EMIdEstatus", "EMIdEmpresa", "EMUsuarioAdd", "EMFechaAdd",
                "EMUsuarioUMod", "EMFechaUMod", "UsuarioDel", "EMFechaDel",
                "EMNombreEmpresa");
        columnasDinamicas.forEach((columna) -> {
            if ((((columna.getCpEtiqueta().trim().toUpperCase().contains("SUELDO")
                    || columna.getCpEtiqueta().trim().toUpperCase().contains("SALARIO"))
                    && Boolean.TRUE.toString().equals(sueldo))
                    || (!columna.getCpEtiqueta().trim().toUpperCase().contains("SUELDO")
                    && !columna.getCpEtiqueta().trim().toUpperCase().contains("SALARIO")))) //&& !fijos.contains(columna.getCaNombreCampo().trim()))
            {
                headers.put(columna.getCaNombreCampo().trim(), columna.getCpEtiqueta().trim());
            }
        });
        headers.put("EMIdEstatus", "Estatus"); //Esta columna debe formar parte de todas las tablas. //
        headers.put("UsuarioAdd", "Usuario Agregó"); //Esta columna debe formar parte de todas las tablas.
        headers.put("EMFechaAdd", "Fecha Registro Sistema"); //Esta columna debe formar parte de todas las tablas.
        headers.put("UsuarioMod", "Usuario Modificó"); //Esta columna debe formar parte de todas las tablas.
        headers.put("EMFechaUMod", "Fecha Modificación"); //Esta columna debe formar parte de todas las tablas.
        headers.put("UsuarioDel", "Usuario Eliminó"); //Esta columna debe formar parte de todas las tablas.
        headers.put("EMFechaDel", "Fecha Baja Sistema"); //Esta columna debe formar parte de todas las tablas.
        sortedHeaders.put("ID del registro/asegurado", "ID del registro/asegurado");
        sortedHeaders.put("ID de la empresa", "ID de la empresa");
        sortedHeaders.put("Nombre de empresa", "Nombre de empresa");

        invokeEmpleado().forEach((emp_col) -> {
            switch (emp_col) {
                case "EMUsuarioAdd":
                    if (headers.containsKey("UsuarioAdd")) {
                        sortedHeaders.put("UsuarioAdd", headers.get("UsuarioAdd"));
                        sortedHeaders.put("EMFechaAdd", headers.get("EMFechaAdd"));
                    }
                    break;
                case "EMUsuarioUMod":
                    if (headers.containsKey("UsuarioMod")) {
                        sortedHeaders.put("UsuarioMod", headers.get("UsuarioMod"));
                        sortedHeaders.put("EMFechaUMod", headers.get("EMFechaUMod"));
                    }
                    break;
                case "EMUsuarioDel":
                    if (headers.containsKey("UsuarioDel")) {
                        sortedHeaders.put("UsuarioDel", headers.get("UsuarioDel"));
                        sortedHeaders.put("EMFechaDel", headers.get("EMFechaDel"));
                    }
                    break;
                case "EMIdEmpresa":
                    if (headers.containsKey("EMIdEmpresa")) {
                    }
                    break;
                default:
                    if (headers.containsKey(emp_col)) {
                        sortedHeaders.put(emp_col, headers.get(emp_col));
                    }
                    break;
            }

        });
        return sortedHeaders;
    }

    List<Object> invokeReportes(String empresas, String fechaIni, String fechaFin, String estatus, String parentescos, String perfiles, String sueldo) {
        String spName;
        if ( Boolean.TRUE.toString().equals(sueldo) ) {
            spName = "ff_GetDatosReporteAseguradoConSalarioB3";
        } else {
            spName = "ff_GetDatosReporteAseguradoB3";
        }
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spName);
        Map<String, Object> inParamMap = new HashMap<>();

        inParamMap.put("idEmpresa", empresas);
        inParamMap.put("FechaInicial", fechaIni);
        inParamMap.put("FechaFinal", fechaFin);
        inParamMap.put("IdEstatus", estatus);
        inParamMap.put("IdParentesco", parentescos);
        inParamMap.put("IdPerfil", perfiles);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);

        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
        
        return listSP.isEmpty() ? listSP : new ArrayList<Object>((Collection<? extends Object>) listSP.get(0));
    }

    public List<FfCObtenPlantilla> invokePlantilla(int IdEmpresa, int IdPerfil, String Pantalla) {
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_CObtenPlantilla").returningResultSet("rs", new
				BeanPropertyRowMapper<FfCObtenPlantilla>(FfCObtenPlantilla.class));

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdEmpresa", IdEmpresa);
		inParamMap.put("IdPerfil", IdPerfil);
		inParamMap.put("Pantalla", Pantalla);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);

		return (List<FfCObtenPlantilla>) simpleJdbcCallResult.get("rs");
	}

    public List<String> invokeEmpleado() {
        String sql = "SELECT COLUMN_NAME " +
        "FROM INFORMATION_SCHEMA.COLUMNS " +
        "WHERE TABLE_NAME = 'ff_Empleado' AND TABLE_SCHEMA='dbo'";
        return jdbcTemplate.queryForList(sql, String.class);
    }
}
