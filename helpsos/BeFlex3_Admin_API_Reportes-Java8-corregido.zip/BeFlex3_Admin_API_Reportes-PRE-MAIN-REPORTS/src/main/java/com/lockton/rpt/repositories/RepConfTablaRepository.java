package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lockton.rpt.models.entities.RepConfTabla;
import com.lockton.rpt.models.entities.RepConfTablaPk;

public interface RepConfTablaRepository extends JpaRepository<RepConfTabla, RepConfTablaPk>{
    
}
