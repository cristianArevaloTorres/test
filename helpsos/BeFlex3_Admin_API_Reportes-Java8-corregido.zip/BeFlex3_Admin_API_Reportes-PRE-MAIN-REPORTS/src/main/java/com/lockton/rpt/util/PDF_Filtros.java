package com.lockton.rpt.util;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.text.Normalizer;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.springframework.util.LinkedCaseInsensitiveMap;

/**
 * Genera un PDF similar al front (jsPDF + autoTable):
 * - Landscape, tamaño carta, unidades en mm.
 * - Encabezados con color de fondo.
 * - Texto general color RGB.
 * - Si no es reporte a nivel empresa: dos tablas (ejecución y detalle).
 * - Si es reporte a nivel empresa: una sola tabla.
 *
 * Convención de RS:
 *   resultsets[0] => datosEjecucion (tabla superior)
 *   resultsets[1] => datos (tabla inferior)
 * Si solo llega un RS, se usará como cuerpo principal.
 */
public class PDF_Filtros {

    private static final DateTimeFormatter FECHA_HORA_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm", Locale.ROOT);

    public static String generar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
                                 Map<String, Object> parametros,
                                 String outputDir) throws Exception {

        ArrayList<LinkedCaseInsensitiveMap<?>> rsEjecucion = null;
        ArrayList<LinkedCaseInsensitiveMap<?>> rsDatos = null;

        if (resultsets != null) {
            if (resultsets.size() > 0) rsEjecucion = resultsets.get(0);
            if (resultsets.size() > 1) rsDatos = resultsets.get(1);
        }
        if (rsEjecucion == null) rsEjecucion = new ArrayList<>();
        if (rsDatos == null) rsDatos = new ArrayList<>();

        boolean reporteNivelEmpresa = toBoolean(parametros.get("reporteNivelEmpresa"));

        // Colores configurables (mismos nombres que Excel_Encabezados)
        String[] colores = obtenerColores(parametros);
        Color headerBg = parseColor(colores[0], new Color(0x5B, 0x67, 0x70));   // default #5B6770
        Color headerText = parseColor(colores[1], Color.WHITE);                 // texto encabezado
        Color bodyText =  new Color(96, 96, 96);
        Color generalText = new Color(6, 67, 122); // mismo que front por defecto

        // Preparar documentos
        PDDocument doc = new PDDocument();
        // Carta horizontal
        PDPage page = new PDPage(new PDRectangle(PDRectangle.LETTER.getHeight(), PDRectangle.LETTER.getWidth()));
        doc.addPage(page);

        float mm = 72f / 25.4f;
        float marginX = 20f * mm;
        float usableWidth = page.getMediaBox().getWidth() - 2 * marginX;

        PageCtx ctx = new PageCtx();
        ctx.page = page;
        ctx.cs = new PDPageContentStream(doc, page);
        ctx.cs.setNonStrokingColor(generalText.getRed(), generalText.getGreen(), generalText.getBlue());
        ctx.y = page.getMediaBox().getHeight() - 20f * mm;

        if (!reporteNivelEmpresa) {
            if (!rsEjecucion.isEmpty()) {
                ctx = drawTable(doc, ctx, marginX, usableWidth, rsEjecucion, headerBg, headerText, bodyText, mm);
                ctx.y -= 5f * mm; // espacio
            }
            ctx = drawTable(doc, ctx, marginX, usableWidth, rsDatos, headerBg, headerText, bodyText, mm);
        } else {
            ctx = drawTable(doc, ctx, marginX, usableWidth, rsDatos, headerBg, headerText, bodyText, mm);
        }
        if (ctx.cs != null) {
            ctx.cs.close();
        }

        
        // ========== RESOLVER RUTA IGUAL QUE Excel_Hoja_Multiple ==========
        String rutaDir = outputDir;
        Object idEmpObj = parametros.get("idEmpresa");
        if (idEmpObj == null) {
            idEmpObj = String.valueOf(
                    String.valueOf(
                            parametros.getOrDefault("admIdEmpresa",
                                    String.valueOf(
                                            parametros.getOrDefault("empresas",
                                                    parametros.get("empresasIds")
                                            )
                                    )
                            )
                    )
            );
        }
        String idEmp = null;
        if (idEmpObj != null) {
            String raw = String.valueOf(idEmpObj).trim();
            raw = raw.replaceAll("[\\{\\}\\[\\]]", "");
            if (raw.contains(",")) raw = raw.split(",")[0].trim();
            String digits = raw.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) idEmp = digits;
        }

        String subFolder = sanitizarNombreCarpeta(
                String.valueOf(
                        parametros.getOrDefault(
                                "catReportesNombre",
                                parametros.getOrDefault("tituloReporteB1", nombreReportePorId(parametros))
                        )
                )
        );
        if (subFolder == null || subFolder.trim().isEmpty()) subFolder = "Reporte";

        try {
            Class<?> c = Class.forName("com.lockton.rpt.util.Constantes");
            Object v = c.getField("DOCUMENTO_EMPRESA").get(null);
            if (idEmp != null && v != null) {
                String base = String.valueOf(v);
                if (base != null && !base.trim().isEmpty()) {
                    rutaDir = base + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            }
        } catch (Throwable ignore) {
            // Ignorar y probar con variable de entorno
        }
        if (rutaDir == null || ".".equals(rutaDir) || outputDir.equals(rutaDir)) {
            try {
                String base = System.getenv("UPLOAD_FOLDER");
                if (base != null && !base.trim().isEmpty() && idEmp != null) {
                    rutaDir = base + File.separator + "DocumentoEmpresa" + File.separator + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            } catch (Throwable ignore) {
                // Si tampoco está la variable de entorno, caeremos en outputDir
            }
        }
        // Guardar
        File dir = new File(rutaDir);
        if (!dir.exists()) dir.mkdirs();
        String fileName = nombreArchivoDesdeTitulo(parametros);
        File out = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(out)) {
            doc.save(fos);
        } finally {
            doc.close();
        }
        return out.getAbsolutePath();
    }

    private static PageCtx drawTable(PDDocument doc,
                                     PageCtx ctx,
                                     float startX,
                                     float width,
                                     ArrayList<LinkedCaseInsensitiveMap<?>> rows,
                                     Color headerBg,
                                     Color headerText,
                                     Color bodyText,
                                     float mm) throws IOException {
        if (rows == null || rows.isEmpty()) return ctx;
        PDPage page = ctx.page;
        PDPageContentStream cs = ctx.cs;
        float y = ctx.y;
        float bottomMargin = 20f * mm;

        LinkedCaseInsensitiveMap<?> first = rows.get(0);
        List<String> headers = new ArrayList<>();
        for (Object k : first.keySet()) headers.add(String.valueOf(k));

        int cols = headers.size();
        if (cols == 0) {
            ctx.y = y;
            return ctx;
        }
        PDType1Font bodyFont = PDType1Font.HELVETICA;
        PDType1Font headerFont = PDType1Font.HELVETICA_BOLD;
        float fontSize = 8f;
        float headerFontSize = 8f;
        float padding = 2f; // padding mínimo
        float colWidth = width / cols;
        float lineHeight = fontSize + padding; // altura por línea en puntos
        float headerLineHeight = headerFontSize + padding;
        Color gridColor = new Color(230, 230, 230);
        Color rowShade = new Color(245, 245, 245);

        // Preparar líneas de encabezado y altura
        List<List<String>> headerLines = new ArrayList<>();
        float headerHeight = headerLineHeight + padding;
        for (int i = 0; i < cols; i++) {
            List<String> lines = wrapText(headers.get(i), headerFont, headerFontSize, colWidth - 2 * padding);
            headerLines.add(lines);
            headerHeight = Math.max(headerHeight, lines.size() * headerLineHeight + 2 * padding);
        }

        // Si no cabe el header en la página actual, crear nueva
        if (y - headerHeight < bottomMargin) {
            cs.close();
            page = new PDPage(page.getMediaBox());
            doc.addPage(page);
            cs = new PDPageContentStream(doc, page);
            y = page.getMediaBox().getHeight() - bottomMargin;
        }

        // Dibujar header
        cs.setNonStrokingColor(headerBg.getRed(), headerBg.getGreen(), headerBg.getBlue()); // fondo header
        cs.addRect(startX, y - headerHeight, width, headerHeight);
        cs.fill();
        cs.setNonStrokingColor(headerText.getRed(), headerText.getGreen(), headerText.getBlue()); // texto header
        for (int i = 0; i < cols; i++) {
            float x = startX + i * colWidth + padding;
            drawWrappedCenteredText(cs, headerFont, headerFontSize, headerLines.get(i), x, colWidth - 2 * padding, y, headerHeight, headerLineHeight, padding);
        }
        // Grid sobre header
        cs.setStrokingColor(gridColor.getRed(), gridColor.getGreen(), gridColor.getBlue());
        cs.setLineWidth(0.3f);
        for (int i = 0; i < cols; i++) {
            float x = startX + i * colWidth;
            cs.addRect(x, y - headerHeight, colWidth, headerHeight);
        }
        cs.stroke();
        y -= headerHeight;

        // Cuerpo
        cs.setNonStrokingColor(bodyText.getRed(), bodyText.getGreen(), bodyText.getBlue()); // texto cuerpo

        int rowIndex = 0;
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            List<List<String>> cellLines = new ArrayList<>();
            float rowHeight = lineHeight + padding;
            for (int i = 0; i < cols; i++) {
                String header = headers.get(i);
                Object v = row.get(header);
                String txt = formatCellValue(header, v);
                List<String> lines = wrapText(txt, bodyFont, fontSize, colWidth - 2 * padding);
                cellLines.add(lines);
                rowHeight = Math.max(rowHeight, lines.size() * lineHeight + 2 * padding);
            }

            // Salto de página
            if (y - rowHeight < bottomMargin) {
                cs.close();
                page = new PDPage(page.getMediaBox());
                doc.addPage(page);
                cs = new PDPageContentStream(doc, page);
                y = page.getMediaBox().getHeight() - bottomMargin;

                // Redibujar header en nueva página
                cs.setNonStrokingColor(headerBg.getRed(), headerBg.getGreen(), headerBg.getBlue());
                cs.addRect(startX, y - headerHeight, width, headerHeight);
                cs.fill();
                cs.setNonStrokingColor(headerText.getRed(), headerText.getGreen(), headerText.getBlue());
                for (int i = 0; i < cols; i++) {
                    float x = startX + i * colWidth + padding;
                    drawWrappedCenteredText(cs, headerFont, headerFontSize, headerLines.get(i), x, colWidth - 2 * padding, y, headerHeight, headerLineHeight, padding);
                }
                y -= headerHeight;
                cs.setNonStrokingColor(bodyText.getRed(), bodyText.getGreen(), bodyText.getBlue());
            }

            // Sombreado alternado
            if (rowIndex % 2 == 0) {
                cs.setNonStrokingColor(rowShade.getRed(), rowShade.getGreen(), rowShade.getBlue());
                cs.addRect(startX, y - rowHeight, width, rowHeight);
                cs.fill();
                cs.setNonStrokingColor(bodyText.getRed(), bodyText.getGreen(), bodyText.getBlue());
            }

            for (int i = 0; i < cols; i++) {
                float x = startX + i * colWidth + padding;
                drawWrappedCenteredText(cs, bodyFont, fontSize, cellLines.get(i), x, colWidth - 2 * padding, y, rowHeight, lineHeight, padding);
            }

            // Grid de la fila
            cs.setStrokingColor(gridColor.getRed(), gridColor.getGreen(), gridColor.getBlue());
            cs.setLineWidth(0.3f);
            for (int i = 0; i < cols; i++) {
                float x = startX + i * colWidth;
                cs.addRect(x, y - rowHeight, colWidth, rowHeight);
            }
            cs.stroke();

            y -= rowHeight;
            rowIndex++;
        }

        ctx.page = page;
        ctx.cs = cs;
        ctx.y = y;
        return ctx;
    }

    private static void drawWrappedCenteredText(PDPageContentStream cs, PDType1Font font, float fontSize, List<String> lines, float x, float width, float rowTopY, float rowHeight, float lineHeight, float padding) throws IOException {
        if (lines == null) lines = java.util.Collections.emptyList();
        float totalHeight = lines.size() * lineHeight;
        float startY = rowTopY - padding - fontSize; // primera línea desde el top con padding
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            float textWidth = font.getStringWidth(line) / 1000f * fontSize;
            float drawX = x + Math.max(0, (width - textWidth) / 2f);
            float drawY = startY - i * lineHeight;
            cs.beginText();
            cs.setFont(font, fontSize);
            cs.newLineAtOffset(drawX, drawY);
            cs.showText(line);
            cs.endText();
        }
    }

    private static List<String> wrapText(String text, PDType1Font font, float fontSize, float maxWidth) throws IOException {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        String[] words = text.split("\\s+");
        StringBuilder line = new StringBuilder();
        for (String w : words) {
            if (line.length() == 0) {
                line.append(w);
            } else {
                String trial = line + " " + w;
                float width = font.getStringWidth(trial) / 1000f * fontSize;
                if (width <= maxWidth) {
                    line.append(" ").append(w);
                } else {
                    out.add(line.toString());
                    line.setLength(0);
                    line.append(w);
                }
            }
        }
        if (line.length() > 0) out.add(line.toString());

        // si alguna palabra sola excede el ancho, cortar duro
        for (int i = 0; i < out.size(); i++) {
            String ln = out.get(i);
            float w = font.getStringWidth(ln) / 1000f * fontSize;
            if (w > maxWidth) {
                out.remove(i);
                out.addAll(i, hardBreak(ln, font, fontSize, maxWidth));
            }
        }
        if (out.isEmpty()) out.add("");
        return out;
    }

    private static List<String> hardBreak(String text, PDType1Font font, float fontSize, float maxWidth) throws IOException {
        List<String> res = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            sb.append(text.charAt(i));
            float w = font.getStringWidth(sb.toString()) / 1000f * fontSize;
            if (w > maxWidth && sb.length() > 1) {
                sb.setLength(sb.length() - 1);
                res.add(sb.toString());
                sb.setLength(0);
                sb.append(text.charAt(i));
            }
        }
        if (sb.length() > 0) res.add(sb.toString());
        return res;
    }

    private static boolean toBoolean(Object o) {
        if (o == null) return false;
        if (o instanceof Boolean) return (Boolean) o;
        String s = String.valueOf(o).trim().toLowerCase(Locale.ROOT);
        return s.equals("true") || s.equals("1") || s.equals("si") || s.equals("sí");
    }

    private static String truncate(String s) {
        if (s == null) return "";
        return s.length() > 100 ? s.substring(0, 100) : s;
    }

    private static String formatCellValue(String header, Object value) {
        String val;
        if (header != null && header.toLowerCase(Locale.ROOT).contains("fecha")) {
            val = formatFecha(value);
        } else {
            val = value == null ? "" : String.valueOf(value);
        }
        return truncate(val);
    }

    private static String formatFecha(Object v) {
        if (v == null) return "";
        if (v instanceof LocalDateTime) {
            return ((LocalDateTime) v).format(FECHA_HORA_FMT);
        }
        if (v instanceof LocalDate) {
            return ((LocalDate) v).atStartOfDay().format(FECHA_HORA_FMT);
        }
        if (v instanceof java.util.Date) {
            return LocalDateTime.ofInstant(((java.util.Date) v).toInstant(), ZoneId.systemDefault())
                    .format(FECHA_HORA_FMT);
        }
        String s = String.valueOf(v).trim();
        if (s.isEmpty()) return "";
        try { LocalDateTime ldt = parseDateTimeFlex(s); if (ldt != null) return ldt.format(FECHA_HORA_FMT); } catch (Exception ignore) {}
        try { return OffsetDateTime.parse(s).toLocalDateTime().format(FECHA_HORA_FMT); } catch (Exception ignore) {}
        try { return LocalDate.parse(s).atStartOfDay().format(FECHA_HORA_FMT); } catch (Exception ignore) {}
        if (s.matches("^\\d{10,}$")) {
            try {
                long epoch = Long.parseLong(s);
                if (s.length() == 10) epoch *= 1000L;
                return LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(epoch), ZoneId.systemDefault())
                        .format(FECHA_HORA_FMT);
            } catch (Exception ignore) {}
        }
        return s;
    }

    private static LocalDateTime parseDateTimeFlex(String s) {
        String[] patterns = {
                "dd/MM/yyyy HH:mm:ss",
                "dd/MM/yyyy HH:mm",
                "yyyy-MM-dd HH:mm:ss",
                "yyyy-MM-dd HH:mm",
                "yyyy-MM-dd'T'HH:mm:ss",
                "yyyy-MM-dd'T'HH:mm:ss.SSS"
        };
        for (String p : patterns) {
            try {
                return LocalDateTime.parse(s, DateTimeFormatter.ofPattern(p, Locale.ROOT));
            } catch (Exception ignore) {}
        }
        try {
            return LocalDateTime.parse(s); // fallback ISO
        } catch (Exception ignore) {}
        return null;
    }

    private static String nombreArchivoDesdeTitulo(Map<String, Object> params) {
        String base = "Reporte";
        try {
            Object t = params.get("tituloReporteB1");
            if (t == null) t = params.get("catReportesNombre");
            if (t != null) base = String.valueOf(t);
        } catch (Exception ignore) {}
        base = base.replaceAll("[\\\\/*?:<>|\"]", "_").replaceAll("\\s+", "_");
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss", Locale.ROOT));
        return base + "_" + ts + ".pdf";
    }

    private static String[] obtenerColores(Map<String, Object> parametros) {
        String fondo = null;
        String letra = null;
        if (parametros != null && parametros.containsKey("reporteConfig")) {
            try {
                Object configObj = parametros.get("reporteConfig");
                if (configObj instanceof List) {
                    List<?> configList = (List<?>) configObj;
                    if (!configList.isEmpty() && configList.get(0) instanceof Map) {
                        Map<?, ?> configMap = (Map<?, ?>) configList.get(0);
                        if (configMap.containsKey("colorFondo")) {
                            fondo = String.valueOf(configMap.get("colorFondo"));
                        }
                        if (configMap.containsKey("colorLetra")) {
                            letra = String.valueOf(configMap.get("colorLetra"));
                        }
                    }
                }
            } catch (Exception ignore) {}
        }
        return new String[] { fondo, letra };
    }

    private static Color parseColor(String val, Color def) {
        if (val == null || val.trim().isEmpty()) return def;
        String v = val.trim();
        Color byName = colorFromName(v);
        if (byName != null) return byName;
        if (isHexColor(v)) return parseHexColor(v);
        return def;
    }

    private static boolean isHexColor(String s) {
        if (s == null) return false;
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v.matches("(?i)^[0-9a-f]{6}$");
    }

    private static Color parseHexColor(String s) {
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        int r = Integer.parseInt(v.substring(0, 2), 16);
        int g = Integer.parseInt(v.substring(2, 4), 16);
        int b = Integer.parseInt(v.substring(4, 6), 16);
        return new Color(r, g, b);
    }

    private static Color colorFromName(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        if (n.equalsIgnoreCase("Blue") || n.equalsIgnoreCase("Azul")) return new Color(0, 0, 255);
        if (n.equalsIgnoreCase("LightBlue") || n.equalsIgnoreCase("Light_Blue") || n.equalsIgnoreCase("Celeste")) return new Color(173, 216, 230);
        if (n.equalsIgnoreCase("White") || n.equalsIgnoreCase("Blanco")) return Color.WHITE;
        if (n.equalsIgnoreCase("Black") || n.equalsIgnoreCase("Negro")) return Color.BLACK;
        if (n.equalsIgnoreCase("Red") || n.equalsIgnoreCase("Rojo")) return Color.RED;
        if (n.equalsIgnoreCase("Green") || n.equalsIgnoreCase("Verde")) return Color.GREEN;
        if (n.equalsIgnoreCase("Gray") || n.equalsIgnoreCase("Grey") || n.equalsIgnoreCase("Gris")) return new Color(128, 128, 128);
        if (n.equalsIgnoreCase("Yellow") || n.equalsIgnoreCase("Amarillo")) return Color.YELLOW;
        return null;
    }

    private static class PageCtx {
        PDPage page;
        PDPageContentStream cs;
        float y;
    }

    private static String sanitizarNombreCarpeta(String s) {
        if (s == null) return null;
        String sinAcentos = quitarAcentos(s);
        String cleaned = sinAcentos.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        String upper = cleaned.equalsIgnoreCase("CON") || cleaned.equalsIgnoreCase("PRN") ||
                       cleaned.equalsIgnoreCase("AUX") || cleaned.equalsIgnoreCase("NUL") ? "Reporte" : cleaned;
        return upper.isEmpty() ? "Reporte" : upper;
    }

    private static String nombreReportePorId(Map<String, Object> parametros) {
        if (parametros == null) return "Reporte";
        Integer rid = null;
        try { Object o = parametros.get("reporteId"); if (o != null) rid = Integer.parseInt(String.valueOf(o)); } catch (Exception ignore) {}
        if (rid == null) return "Reporte";
        switch (rid) {
            case 1: return "DocPersonaliados";
            case 2: return "Poblacion";
            case 5: return "BitacoraNavegacion";
            case 8: return "CambiosCalificados";
            default: return "Reporte";
        }
    }

    private static String quitarAcentos(String s) {
        if (s == null) return null;
        String decomposed = Normalizer.normalize(s, Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }
}

