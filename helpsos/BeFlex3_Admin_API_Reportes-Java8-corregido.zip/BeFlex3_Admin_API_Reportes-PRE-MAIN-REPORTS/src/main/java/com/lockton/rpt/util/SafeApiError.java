package com.lockton.rpt.util;

import java.util.Locale;

/**
 * Centraliza la sanitización de mensajes que pueden terminar en una respuesta HTTP.
 * El detalle técnico debe permanecer exclusivamente en los logs del servidor.
 */
public final class SafeApiError {

    private static final String DEFAULT_MESSAGE =
            "No fue posible completar la operación. Intenta nuevamente.";
    private static final String SERVICE_UNAVAILABLE_MESSAGE =
            "No fue posible conectar con el servicio de reportes. Intenta nuevamente.";

    private SafeApiError() {
    }

    public static String sanitizeMessage(String candidate, String fallback) {
        String safeFallback = isBlank(fallback) ? DEFAULT_MESSAGE : fallback.trim();
        if (isBlank(candidate)) {
            return safeFallback;
        }

        String value = candidate.trim();
        if (looksTechnical(value)) {
            return safeFallback;
        }
        return value;
    }

    public static String publicMessage(Throwable error, String fallback) {
        if (isInfrastructureFailure(error)) {
            return SERVICE_UNAVAILABLE_MESSAGE;
        }
        return sanitizeMessage(error == null ? null : error.getMessage(), fallback);
    }

    public static boolean isInfrastructureFailure(Throwable error) {
        Throwable current = error;
        int depth = 0;
        while (current != null && depth++ < 12) {
            String className = current.getClass().getName().toLowerCase(Locale.ROOT);
            String message = current.getMessage();
            String lower = message == null ? "" : message.toLowerCase(Locale.ROOT);

            if (className.contains("sqlexception")
                    || className.contains("sqlserverexception")
                    || className.contains("cannotgetjdbcconnection")
                    || className.contains("sockettimeoutexception")
                    || className.contains("connectexception")
                    || lower.contains("tcp/ip connection")
                    || lower.contains("connection refused")
                    || lower.contains("could not get jdbc connection")
                    || lower.contains("could not open jdbc connection")
                    || lower.contains("unable to acquire jdbc connection")
                    || lower.contains("communications link failure")
                    || lower.contains("login failed for user")
                    || lower.contains("port 1433")) {
                return true;
            }
            current = current.getCause();
        }
        return false;
    }

    private static boolean looksTechnical(String message) {
        String lower = message.toLowerCase(Locale.ROOT);
        return lower.contains("tcp/ip connection")
                || lower.contains("sqlserverexception")
                || lower.contains("sqlexception")
                || lower.contains("jdbc:")
                || lower.contains("com.microsoft.sqlserver")
                || lower.contains("nested exception")
                || lower.contains("java.lang.")
                || lower.contains("org.springframework")
                || lower.contains("connection refused")
                || lower.contains("communications link failure")
                || lower.contains("login failed for user")
                || lower.contains("port 1433")
                || lower.contains(" at com.")
                || lower.contains(" at org.")
                || message.indexOf('\n') >= 0
                || message.indexOf('\r') >= 0
                || message.length() > 500;
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
