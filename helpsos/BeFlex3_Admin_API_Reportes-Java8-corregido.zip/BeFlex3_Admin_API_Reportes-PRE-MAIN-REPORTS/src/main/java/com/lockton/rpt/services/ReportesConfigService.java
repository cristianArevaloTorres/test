package com.lockton.rpt.services;

import java.util.List;

import com.lockton.rpt.models.dto.CatalogoReporteGenDTO;

public interface ReportesConfigService {
    List<CatalogoReporteGenDTO> getAll();
    List<CatalogoReporteGenDTO> actualizar(List<CatalogoReporteGenDTO> dtos);
}
