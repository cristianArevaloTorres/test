package com.lockton.rpt.services;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaAsignarIndicadoresRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaCatalogoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaDocumentoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaDuplicarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaLienzoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaOrdenIndicadoresRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaPortadaGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaSeccionGuardarRequestDTO;

import java.util.List;
import java.util.Map;

public interface ReporteEstadisticaPlantillaCatalogoService {
    List<Map<String, Object>> listarGlobal(boolean incluirBajas);

    List<Map<String, Object>> listarCorporativo(
            int idCorporativo,
            boolean incluirBajas);

    Map<String, Object> catalogos();

    Map<String, Object> validarNombre(
            String tipo,
            Integer idCorporativo,
            String nombre,
            Integer idPlantilla);

    Map<String, Object> guardar(PlantillaCatalogoGuardarRequestDTO request);

    Map<String, Object> estatus(int idPlantilla, CambioEstatusRequestDTO request);

    Map<String, Object> duplicarMismoNivel(
            int idPlantillaOrigen,
            PlantillaDuplicarRequestDTO request);

    Map<String, Object> replicarGlobal(
            int idPlantillaGlobal,
            PlantillaDuplicarRequestDTO request);

    Map<String, Object> diseno(int idPlantilla);

    Map<String, Object> guardarDiseno(
            int idPlantilla,
            PlantillaGuardarRequestDTO request);

    Map<String, Object> guardarDocumento(
            int idPlantilla,
            PlantillaDocumentoGuardarRequestDTO request);

    Map<String, Object> guardarPortada(
            int idPlantilla,
            PlantillaPortadaGuardarRequestDTO request);

    Map<String, Object> guardarSeccion(
            int idPlantilla,
            Integer idSeccion,
            PlantillaSeccionGuardarRequestDTO request);

    Map<String, Object> guardarLienzo(
            int idPlantilla,
            int idSeccion,
            PlantillaLienzoGuardarRequestDTO request);

    Map<String, Object> asignables(int idPlantilla, Integer idSeccion);

    Map<String, Object> asignar(
            int idSeccion,
            PlantillaAsignarIndicadoresRequestDTO request);

    Map<String, Object> ordenarIndicadores(
            int idSeccion,
            PlantillaOrdenIndicadoresRequestDTO request);

    Map<String, Object> estatusAsignacion(
            int idSeccionIndicador,
            CambioEstatusRequestDTO request);
}
