package com.lockton.rpt.models.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CatReportesCabecerosDTO {
    private Integer id;
    private Integer catReportesId;
    private String nombre;
    private String descripcion;
    private Integer orden;
    private Integer esid;
    private Integer UsuarioAdd;
    private LocalDateTime fechaReg;
    private Integer userMod;
    private LocalDateTime fechaMod;
}