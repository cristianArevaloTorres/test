package com.lockton.rpt.services.impl;

import com.lockton.rpt.repositories.ReporteEstadisticaSnapshotDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class ReporteEstadisticaSnapshotAsyncService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReporteEstadisticaSnapshotAsyncService.class);
    private final ReporteEstadisticaSnapshotDAO dao;

    public ReporteEstadisticaSnapshotAsyncService(ReporteEstadisticaSnapshotDAO dao) {
        this.dao = dao;
    }

    @Async("taskExecutor")
    public void procesar(long idEjecucion) {
        try {
            dao.procesar(idEjecucion);
        } catch (Exception ex) {
            // Contingencia: si SQL Server cancela por timeout, la conexión se pierde o el
            // procedimiento falla antes de alcanzar su CATCH, cerramos la ejecución desde
            // una llamada independiente. Nunca se toca la versión publicada anterior.
            try {
                dao.marcarError(idEjecucion, ex.getMessage());
            } catch (Exception markEx) {
                LOGGER.error("REPE histórico: no fue posible cerrar la ejecución {} después del error: {}",
                        idEjecucion, markEx.getMessage(), markEx);
            }
            LOGGER.error("REPE histórico: error en ejecución {}: {}", idEjecucion, ex.getMessage(), ex);
        }
    }
}
