package com.lockton.rpt.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lockton.rpt.services.impl.ConfigPlantillaService;
import com.lockton.rpt.services.impl.SnapshotReporteService;

import com.lockton.rpt.util.TextUtil;
import com.lockton.rpt.util.SafeApiError;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("beflex/reporte-estadisticas/config/plantilla")
public class WSConfigPlantilla {

    private final ConfigPlantillaService service;
    private final SnapshotReporteService snapshotService;

    public WSConfigPlantilla(ConfigPlantillaService service, SnapshotReporteService snapshotService) {
        this.service = service;
        this.snapshotService = snapshotService;
    }

    @GetMapping("/catalogos")
    public ResponseEntity<Map<String, Object>> catalogos() {
        return okSingle(service.getCatalogos());
    }

    @GetMapping("/catalogos/stored-procedures/{idSp}/parametros")
    public ResponseEntity<Map<String, Object>> spParametros(@PathVariable int idSp) {
        return ok(service.getStoredProcedureParametros(idSp));
    }

    @GetMapping("/catalogos/stored-procedures/{idSp}")
    public ResponseEntity<Map<String, Object>> storedProcedure(@PathVariable int idSp) {
        try {
            return okSingle(service.obtenerStoredProcedure(idSp));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/catalogos/stored-procedures")
    public ResponseEntity<Map<String, Object>> crearStoredProcedure(@RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.crearStoredProcedure(body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/catalogos/stored-procedures/{idSp}")
    public ResponseEntity<Map<String, Object>> actualizarStoredProcedure(
            @PathVariable int idSp, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.actualizarStoredProcedure(idSp, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/catalogos/stored-procedures/{idSp}")
    public ResponseEntity<Map<String, Object>> eliminarStoredProcedure(@PathVariable int idSp) {
        try {
            return okSingle(service.eliminarStoredProcedure(idSp, 1, "CREA017 UI"));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/catalogos/stored-procedures/{idSp}/salidas")
    public ResponseEntity<Map<String, Object>> crearSpSalida(
            @PathVariable int idSp, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.crearStoredProcedureSalida(idSp, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/catalogos/stored-procedures/salidas/{idSalida}")
    public ResponseEntity<Map<String, Object>> actualizarSpSalida(
            @PathVariable int idSalida, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.actualizarStoredProcedureSalida(idSalida, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/catalogos/stored-procedures/salidas/{idSalida}")
    public ResponseEntity<Map<String, Object>> eliminarSpSalida(
            @PathVariable int idSalida, @RequestParam int idSp) {
        try {
            return okSingle(service.eliminarStoredProcedureSalida(idSalida, idSp, 1, "CREA017 UI"));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/catalogos/stored-procedures/{idSp}/salidas")
    public ResponseEntity<Map<String, Object>> spSalidas(@PathVariable int idSp) {
        return ok(service.getStoredProcedureSalidas(idSp));
    }

    @PostMapping("/catalogos/stored-procedures/{idSp}/parametros")
    public ResponseEntity<Map<String, Object>> crearSpParametro(
            @PathVariable int idSp, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.crearStoredProcedureParametro(idSp, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/catalogos/stored-procedures/parametros/{idParametro}")
    public ResponseEntity<Map<String, Object>> actualizarSpParametro(
            @PathVariable int idParametro, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.actualizarStoredProcedureParametro(idParametro, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/catalogos/stored-procedures/parametros/{idParametro}")
    public ResponseEntity<Map<String, Object>> eliminarSpParametro(
            @PathVariable int idParametro, @RequestParam int idSp) {
        try {
            return okSingle(service.eliminarStoredProcedureParametro(idParametro, idSp, 1, "CREA017 UI"));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/secciones")
    public ResponseEntity<Map<String, Object>> secciones(
            @RequestParam(required = false) Integer idCorporativo) {
        return ok(service.listarSecciones(idCorporativo));
    }

    @GetMapping("/secciones/{idSeccion}")
    public ResponseEntity<Map<String, Object>> seccion(
            @PathVariable int idSeccion,
            @RequestParam(required = false) Integer idCorporativo) {
        try {
            return okSingle(service.obtenerSeccion(idSeccion, idCorporativo));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/secciones")
    public ResponseEntity<Map<String, Object>> crearSeccion(@RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.crearSeccion(body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/secciones/{idSeccion}")
    public ResponseEntity<Map<String, Object>> actualizarSeccion(
            @PathVariable int idSeccion, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.actualizarSeccion(idSeccion, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/secciones/{idSeccion}")
    public ResponseEntity<Map<String, Object>> eliminarSeccion(
            @PathVariable int idSeccion,
            @RequestParam(required = false) Integer idCorporativo,
            @RequestParam(defaultValue = "1") int idUsuario,
            @RequestParam(defaultValue = "CREA017 UI") String nombreUsuario) {
        try {
            return okSingle(service.eliminarSeccion(idSeccion, idCorporativo, idUsuario, nombreUsuario));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/secciones/{idSeccion}/textos")
    public ResponseEntity<Map<String, Object>> crearTexto(
            @PathVariable int idSeccion, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.crearTextoSeccion(idSeccion, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/secciones/{idSeccion}/indicadores")
    public ResponseEntity<Map<String, Object>> indicadores(
            @PathVariable int idSeccion,
            @RequestParam(required = false) Integer idCorporativo) {
        return ok(service.listarIndicadores(idSeccion, idCorporativo));
    }

    @GetMapping("/indicadores/{idIndicador}")
    public ResponseEntity<Map<String, Object>> indicador(
            @PathVariable int idIndicador,
            @RequestParam(required = false) Integer idCorporativo) {
        try {
            return okSingle(service.obtenerIndicador(idIndicador, idCorporativo));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/secciones/{idSeccion}/indicadores")
    public ResponseEntity<Map<String, Object>> crearIndicador(
            @PathVariable int idSeccion, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.crearIndicador(idSeccion, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/indicadores/{idIndicador}")
    public ResponseEntity<Map<String, Object>> actualizarIndicador(
            @PathVariable int idIndicador, @RequestBody Map<String, Object> body) {
        try {
            return okSingle(service.actualizarIndicador(idIndicador, body, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/indicadores/{idIndicador}")
    public ResponseEntity<Map<String, Object>> eliminarIndicador(
            @PathVariable int idIndicador,
            @RequestParam(required = false) Integer idCorporativo) {
        try {
            return okSingle(service.eliminarIndicador(idIndicador, idCorporativo, 1, "CREA017 UI"));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/corporativo/existe")
    public ResponseEntity<Map<String, Object>> existePlantillaCorporativo(
            @RequestParam int idCorporativo) {
        try {
            return okSingle(service.existePlantillaCorporativo(idCorporativo));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/corporativo/eliminar")
    public ResponseEntity<Map<String, Object>> eliminarPlantillaCorporativo(@RequestBody Map<String, Object> body) {
        try {
            List<Integer> ids = parseIdCorporativosBody(body);
            if (ids.isEmpty()) {
                return error("Se requiere idCorporativo para eliminar la plantilla corporativa.",
                        HttpStatus.BAD_REQUEST);
            }
            return okSingle(service.eliminarPlantillaCorporativo(ids, userId(body), userName(body)));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/corporativo/reset")
    public ResponseEntity<Map<String, Object>> resetPlantillaCorporativo(@RequestBody Map<String, Object> body) {
        try {
            List<Integer> ids = parseIdCorporativosBody(body);
            if (ids.isEmpty()) {
                return error("Se requiere idCorporativo para restablecer la plantilla corporativa.",
                        HttpStatus.BAD_REQUEST);
            }
            return okSingle(service.resetPlantillaCorporativo(ids, userId(body), userName(body)));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/snapshot/ejecutar")
    public ResponseEntity<Map<String, Object>> ejecutarSnapshot(@RequestBody Map<String, Object> body) {
        try {
            List<Integer> ids = parseIdCorporativosBody(body);
            if (ids.isEmpty()) {
                return error("Seleccione al menos un IdCorporativo.", HttpStatus.BAD_REQUEST);
            }
            if (ids.size() == 1) {
                return okSingle(snapshotService.ejecutarSnapshot(
                        ids.get(0), userId(body), userName(body)));
            }
            return okSingle(snapshotService.ejecutarSnapshotVarios(
                    ids, userId(body), userName(body)));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/snapshot/periodos")
    public ResponseEntity<Map<String, Object>> snapshotPeriodos(
            @RequestParam(required = false) Integer idCorporativo) {
        try {
            return ok(snapshotService.listarPeriodosSnapshot(idCorporativo));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/snapshot/periodo")
    public ResponseEntity<Map<String, Object>> snapshotPeriodo(
            @RequestParam int idCorporativo,
            @RequestParam(required = false) String fechaCorte,
            @RequestParam(required = false) Integer idVigencia) {
        try {
            Map<String, String> parametros = new HashMap<>();
            if (fechaCorte != null && !TextUtil.isBlank(fechaCorte)) {
                parametros.put("FechaCorte", fechaCorte);
            }
            if (idVigencia != null) {
                parametros.put("IdVigencia", String.valueOf(idVigencia));
            }
            return okSingle(snapshotService.resolverPeriodoPreview(idCorporativo, parametros));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    private int intFromBody(Map<String, Object> body, String key, int defaultValue) {
        Object v = body.get(key);
        if (v instanceof Number) {
            return ((Number) v).intValue();
        }
        if (v != null) {
            try {
                return Integer.parseInt(String.valueOf(v).trim());
            } catch (NumberFormatException ignored) {
                return defaultValue;
            }
        }
        return defaultValue;
    }

    @SuppressWarnings("unchecked")
    private List<Integer> parseIdCorporativosBody(Map<String, Object> body) {
        Set<Integer> ids = new LinkedHashSet<>();
        Object rawList = body.get("idCorporativos");
        if (rawList instanceof List) {
            for (Object item : (List<Object>) rawList) {
                addIdCorporativo(ids, item);
            }
        }
        int single = intFromBody(body, "idCorporativo", 0);
        if (single > 0) {
            ids.add(single);
        }
        return new ArrayList<>(ids);
    }

    private void addIdCorporativo(Set<Integer> ids, Object value) {
        if (value == null) {
            return;
        }
        if (value instanceof Number) {
            int parsed = ((Number) value).intValue();
            if (parsed > 0) {
                ids.add(parsed);
            }
            return;
        }
        String text = String.valueOf(value).trim();
        if (text.isEmpty()) {
            return;
        }
        for (String part : text.split("[,;\\s]+")) {
            if (TextUtil.isBlank(part)) {
                continue;
            }
            try {
                int parsed = Integer.parseInt(part.trim());
                if (parsed > 0) {
                    ids.add(parsed);
                }
            } catch (NumberFormatException ignored) {
                // omitir token inválido
            }
        }
    }

    private int userId(Map<String, Object> body) {
        Object v = body.get("idUsuario");
        if (v instanceof Number) {
            return ((Number) v).intValue();
        }
        return 1;
    }

    private String userName(Map<String, Object> body) {
        Object v = body.get("nombreUsuario");
        return v != null ? String.valueOf(v) : "CREA017 UI";
    }

    private ResponseEntity<Map<String, Object>> ok(List<Map<String, Object>> data) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", data);
        return new ResponseEntity<>(body, HttpStatus.OK);
    }

    private ResponseEntity<Map<String, Object>> okSingle(Map<String, Object> data) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", data);
        return new ResponseEntity<>(body, HttpStatus.OK);
    }

    private ResponseEntity<Map<String, Object>> error(String message, HttpStatus status) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("error", SafeApiError.sanitizeMessage(
                message,
                "No fue posible completar la operación. Intenta nuevamente."));
        return new ResponseEntity<>(body, status);
    }
}
