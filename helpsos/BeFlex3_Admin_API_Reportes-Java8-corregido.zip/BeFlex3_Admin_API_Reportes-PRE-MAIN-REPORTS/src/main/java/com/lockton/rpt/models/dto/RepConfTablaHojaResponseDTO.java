package com.lockton.rpt.models.dto;

public class RepConfTablaHojaResponseDTO {
    public Integer idEmpresa;
    public Integer catReportesId;
    public String grupo;
    public Integer indexTable;
    public String colorFondo;
    public String colorLetra;
    public boolean activo;
    public Integer repConfTablaUsuarioAdd;
    public Integer repConfTablaUsuarioMod;
    public Integer repConfTablaUsuarioDel;

    public Integer getIdEmpresa() {
        return idEmpresa;
    }
    public void setIdEmpresa(Integer idEmpresa) {
        this.idEmpresa = idEmpresa;
    }
    public Integer getCatReportesId() {
        return catReportesId;
    }
    public void setCatReportesId(Integer catReportesId) {
        this.catReportesId = catReportesId;
    }
    public String getGrupo() {
        return grupo;
    }
    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }
    public Integer getIndexTable() {
        return indexTable;
    }
    public void setIndexTable(Integer indexTable) {
        this.indexTable = indexTable;
    }
    public String getColorFondo() {
        return colorFondo;
    }
    public void setColorFondo(String colorFondo) {
        this.colorFondo = colorFondo;
    }
    public String getColorLetra() {
        return colorLetra;
    }
    public void setColorLetra(String colorLetra) {
        this.colorLetra = colorLetra;
    }
    public boolean getActivo() {
        return activo;
    }
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    public Integer getRepConfTablaUsuarioAdd() {
        return repConfTablaUsuarioAdd;
    }
    public void setRepConfTablaUsuarioAdd(Integer repConfTablaUsuarioAdd) {
        this.repConfTablaUsuarioAdd = repConfTablaUsuarioAdd;
    }
    public Integer getRepConfTablaUsuarioMod() {
        return repConfTablaUsuarioMod;
    }
    public void setRepConfTablaUsuarioMod(Integer repConfTablaUsuarioMod) {
        this.repConfTablaUsuarioMod = repConfTablaUsuarioMod;
    }
    public Integer getRepConfTablaUsuarioDel() {
        return repConfTablaUsuarioDel;
    }
    public void setRepConfTablaUsuarioDel(Integer repConfTablaUsuarioDel) {
        this.repConfTablaUsuarioDel = repConfTablaUsuarioDel;
    }
}
