package com.lockton.rpt.models.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CatReportesParamsDTO {
    private Integer id;
    private Integer catReportesSPId;
    private Integer tipoDatoId;
    private Integer orden;
    private String nombre;
    private String descripcion;
    private Integer esid;
    private Integer UsuarioAdd;
    private LocalDateTime fechaReg;
    private Integer userMod;
    private LocalDateTime fechaMod;
}