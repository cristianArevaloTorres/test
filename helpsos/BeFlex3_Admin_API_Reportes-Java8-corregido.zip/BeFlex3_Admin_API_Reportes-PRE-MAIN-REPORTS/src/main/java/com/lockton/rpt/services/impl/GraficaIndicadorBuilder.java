package com.lockton.rpt.services.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.lockton.rpt.util.TextUtil;

import org.springframework.stereotype.Component;

@Component
public class GraficaIndicadorBuilder {

    private final ObjectMapper objectMapper = new ObjectMapper();

    public boolean esGrafica(String tipoClave) {
        return IndicadorTipoCatalog.esGrafica(tipoClave);
    }

    /** Al menos una columna de salida vinculada en plantilla (FF_ConfiguracionEstadisticasIndicadorMapeo). */
    public boolean tieneColumnasVinculadas(List<Map<String, Object>> mapeoDb) {
        return mapeoDb != null && !mapeoDb.isEmpty();
    }

    /**
     * Configuración mínima para renderizar: tablas solo requieren columnas vinculadas;
     * gráficos requieren mapeoAtributos en ConfiguracionJson.grafica (o roles legacy en BD).
     */
    public boolean tieneMapeoMinimo(String tipoClave, List<Map<String, Object>> mapeoDb,
            Object configuracionJson) {
        if (!tieneColumnasVinculadas(mapeoDb)) {
            return false;
        }
        if (!IndicadorTipoCatalog.esGrafica(tipoClave)) {
            return true;
        }
        return tieneGraficaConfigMinima(tipoClave, configuracionJson, mapeoDb);
    }

    public boolean tieneGraficaConfigMinima(String tipoClave, Object configuracionJson,
            List<Map<String, Object>> mapeoDb) {
        Map<String, String> attrs = parseMapeoAtributos(parseGraficaConfig(configuracionJson));
        if (!attrs.isEmpty()) {
            return IndicadorTipoCatalog.validarAtributosGrafica(tipoClave, attrs);
        }
        return tieneRolesLegacyEnMapeo(tipoClave, mapeoDb);
    }

    public Map<String, Object> construirChartConfig(
            Map<String, Object> detalle,
            List<Map<String, Object>> filas,
            List<Map<String, Object>> mapeo) {
        String tipo = String.valueOf(detalle.getOrDefault("TipoIndicadorClave", "BARRAS"));
        Map<String, Object> graficaCfg = parseGraficaConfig(detalle.get("ConfiguracionJson"));

        Map<String, Object> chart = new LinkedHashMap<>();
        chart.put("id", String.valueOf(detalle.get("IdIndicador")));
        chart.put("tipo", tipo);
        chart.put("titulo", detalle.get("Nombre"));
        chart.put("width", resolvePixelDimension(detalle.get("Ancho"), graficaCfg.get("width"), 1200));
        chart.put("height", resolvePixelDimension(detalle.get("Alto"), graficaCfg.get("height"), 450));
        chart.put("dpi", intOrDefault(graficaCfg.get("dpi"), 120));
        chart.put("mostrarTitulo", boolOrDefault(detalle.get("MostrarTitulo"), true));
        chart.put("mostrarLeyenda", boolOrDefault(detalle.get("MostrarLeyenda"), true));
        chart.put("colores", parseColores(graficaCfg.get("colores")));
        chart.put("mapeo", construirMapeoChart(graficaCfg, mapeo));
        chart.put("filas", filas != null ? filas : new ArrayList<>());
        return chart;
    }

    /** Columnas del SP asignadas a cada rol de gráfica (labels, values, …). */
    public Map<String, String> resolverAtributosColumna(Object configuracionJson,
            List<Map<String, Object>> mapeoDb) {
        Map<String, String> attrs = parseMapeoAtributos(parseGraficaConfig(configuracionJson));
        if (!attrs.isEmpty()) {
            return attrs;
        }
        return rolesLegacyDesdeMapeo(mapeoDb);
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> parseGraficaConfig(Object configuracionJson) {
        if (configuracionJson == null || TextUtil.isBlank(String.valueOf(configuracionJson))) {
            return new LinkedHashMap<>();
        }
        try {
            Map<String, Object> root = objectMapper.readValue(String.valueOf(configuracionJson),
                    new TypeReference<Map<String, Object>>() {
                    });
            Object grafica = root.get("grafica");
            if (grafica instanceof Map) {
                return new LinkedHashMap<>((Map<String, Object>) grafica);
            }
        } catch (Exception ignored) {
            // configuracionJson inválido — usar defaults
        }
        return new LinkedHashMap<>();
    }

    @SuppressWarnings("unchecked")
    private Map<String, String> parseMapeoAtributos(Map<String, Object> graficaCfg) {
        Map<String, String> out = new LinkedHashMap<>();
        if (graficaCfg == null || graficaCfg.isEmpty()) {
            return out;
        }
        Object raw = graficaCfg.get("mapeoAtributos");
        if (!(raw instanceof Map)) {
            return out;
        }
        for (Map.Entry<String, Object> entry : ((Map<String, Object>) raw).entrySet()) {
            String col = entry.getValue() != null ? String.valueOf(entry.getValue()).trim() : "";
            if (!TextUtil.isBlank(col)) {
                out.put(entry.getKey().trim().toLowerCase(), col);
            }
        }
        return out;
    }

    private Map<String, Object> construirMapeoChart(Map<String, Object> graficaCfg,
            List<Map<String, Object>> mapeoDb) {
        Map<String, String> attrs = parseMapeoAtributos(graficaCfg);
        if (!attrs.isEmpty()) {
            Map<String, Object> mapeo = new LinkedHashMap<>();
            putIfPresent(mapeo, "labels", attrs.get("labels"));
            putIfPresent(mapeo, "values", attrs.get("values"));
            putIfPresent(mapeo, "series", attrs.get("series"));
            putIfPresent(mapeo, "colors", attrs.get("colors"));
            putIfPresent(mapeo, "percentage", attrs.get("percentage"));
            putIfPresent(mapeo, "hombres", attrs.get("hombres"));
            putIfPresent(mapeo, "mujeres", attrs.get("mujeres"));
            return mapeo;
        }
        return construirMapeoLegacy(mapeoDb);
    }

    private Map<String, Object> construirMapeoLegacy(List<Map<String, Object>> mapeoDb) {
        Map<String, Object> mapeo = new LinkedHashMap<>();
        if (mapeoDb == null) {
            return mapeo;
        }
        for (Map<String, Object> row : mapeoDb) {
            String campo = String.valueOf(row.getOrDefault("CEIMCampoVisual", "")).trim().toUpperCase();
            String columna = columnName(row);
            if (TextUtil.isBlank(columna) || TextUtil.isBlank(campo)) {
                continue;
            }
            switch (campo) {
                case "LABEL":
                    mapeo.put("labels", columna);
                    break;
                case "VALUE":
                    mapeo.put("values", columna);
                    break;
                case "SERIES":
                    mapeo.put("series", columna);
                    break;
                case "COLOR":
                    mapeo.put("colors", columna);
                    break;
                case "PERCENTAGE":
                    mapeo.put("percentage", columna);
                    break;
                case "HOMBRES":
                    mapeo.put("hombres", columna);
                    break;
                case "MUJERES":
                    mapeo.put("mujeres", columna);
                    break;
                default:
                    break;
            }
        }
        return mapeo;
    }

    private Map<String, String> rolesLegacyDesdeMapeo(List<Map<String, Object>> mapeoDb) {
        Map<String, String> out = new LinkedHashMap<>();
        if (mapeoDb == null) {
            return out;
        }
        for (Map<String, Object> row : mapeoDb) {
            String campo = String.valueOf(row.getOrDefault("CEIMCampoVisual", "")).trim().toUpperCase();
            String columna = columnName(row);
            if (TextUtil.isBlank(columna) || TextUtil.isBlank(campo)) {
                continue;
            }
            switch (campo) {
                case "LABEL":
                    out.put("labels", columna);
                    break;
                case "VALUE":
                    out.put("values", columna);
                    break;
                case "SERIES":
                    out.put("series", columna);
                    break;
                case "COLOR":
                    out.put("colors", columna);
                    break;
                case "PERCENTAGE":
                    out.put("percentage", columna);
                    break;
                case "HOMBRES":
                    out.put("hombres", columna);
                    break;
                case "MUJERES":
                    out.put("mujeres", columna);
                    break;
                default:
                    break;
            }
        }
        return out;
    }

    private boolean tieneRolesLegacyEnMapeo(String tipoClave, List<Map<String, Object>> mapeoDb) {
        Set<String> roles = new HashSet<>();
        if (mapeoDb != null) {
            for (Map<String, Object> row : mapeoDb) {
                String campo = String.valueOf(row.getOrDefault("CEIMCampoVisual", "")).trim().toUpperCase();
                if (!TextUtil.isBlank(campo)) {
                    roles.add(campo);
                }
            }
        }
        if (roles.isEmpty()) {
            return false;
        }
        String tipo = tipoClave != null ? tipoClave.trim().toUpperCase() : "";
        if ("KPI".equals(tipo)) {
            return roles.contains("VALUE");
        }
        if ("PASTEL".equals(tipo) || "PIE".equals(tipo)) {
            return roles.contains("VALUE")
                    && (roles.contains("LABEL") || roles.contains("PERCENTAGE"));
        }
        if ("GENERO".equals(tipo)) {
            return roles.contains("VALUE")
                    && (roles.contains("LABEL") || roles.contains("PERCENTAGE"));
        }
        return roles.contains("VALUE") && roles.contains("LABEL");
    }

    private void putIfPresent(Map<String, Object> target, String key, String value) {
        if (value != null && !TextUtil.isBlank(value)) {
            target.put(key, value);
        }
    }

    private String columnName(Map<String, Object> row) {
        Object col = row.get("CESPSNombreColumna");
        if (col == null || TextUtil.isBlank(String.valueOf(col))) {
            col = row.get("CEIMNombreColumnaSP");
        }
        return col != null ? String.valueOf(col) : "";
    }

    @SuppressWarnings("unchecked")
    private List<String> parseColores(Object raw) {
        if (raw instanceof List) {
            List<String> out = new ArrayList<>();
            for (Object item : (List<Object>) raw) {
                if (item != null && !TextUtil.isBlank(String.valueOf(item))) {
                    out.add(String.valueOf(item).trim());
                }
            }
            return out;
        }
        if (raw instanceof String && !TextUtil.isBlank((String) raw)) {
            List<String> out = new ArrayList<>();
            for (String part : ((String) raw).split("[,;\\s]+")) {
                if (!TextUtil.isBlank(part)) {
                    out.add(part.trim());
                }
            }
            return out;
        }
        return new ArrayList<>();
    }

    private int resolvePixelDimension(Object plantillaVal, Object cfgVal, int defaultPx) {
        int plantilla = intOrDefault(plantillaVal, 0);
        if (plantilla > 100) {
            return plantilla;
        }
        int cfg = intOrDefault(cfgVal, 0);
        if (cfg > 0) {
            return cfg;
        }
        return defaultPx;
    }

    private int intOrDefault(Object value, int defaultValue) {
        if (value == null || TextUtil.isBlank(String.valueOf(value))) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return defaultValue;
        }
    }

    private boolean boolOrDefault(Object value, boolean defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }
}
