package com.lockton.rpt.controllers;

import java.util.List;
import java.util.Map;

import com.lockton.rpt.models.dto.crea17.ApiResponseDTO;
import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroAdminRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroOrdenRequestDTO;
import com.lockton.rpt.services.ReporteEstadisticaFiltroAdminService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/beflex/reporte-estadisticas/crea17/filtros")
public class WSReporteEstadisticaFiltros {
    private final ReporteEstadisticaFiltroAdminService service;

    public WSReporteEstadisticaFiltros(ReporteEstadisticaFiltroAdminService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> listar(
            @RequestParam(defaultValue = "true") boolean incluirBajas) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-FIL-GET", "Filtros consultados correctamente.", service.listar(incluirBajas)));
        } catch (Exception ex) {
            return error("RPE-FIL-GET-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{idFiltro}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtener(@PathVariable int idFiltro) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-FIL-DET", "Filtro consultado correctamente.", service.obtener(idFiltro)));
        } catch (IllegalArgumentException ex) {
            return error("RPE-FIL-DET-404", ex, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return error("RPE-FIL-DET-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{idFiltro}/auditoria")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> auditoria(@PathVariable int idFiltro) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-FIL-AUD", "Auditoría consultada correctamente.", service.auditoria(idFiltro)));
        } catch (IllegalArgumentException ex) {
            return error("RPE-FIL-AUD-404", ex, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return error("RPE-FIL-AUD-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/campos")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> campos(
            @RequestParam(required = false) Integer idFiltro,
            @RequestParam(defaultValue = "false") boolean soloDisponibles,
            @RequestParam(required = false) String tipoCampo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-FIL-CAM", "Campos del histórico consultados correctamente.",
                    service.listarCampos(idFiltro, soloDisponibles, tipoCampo)));
        } catch (Exception ex) {
            return error("RPE-FIL-CAM-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    /* Se conserva para que Snapshot/orquestador pueda actualizar las cabeceras
       del histórico. Ya no se expone como acción manual en el catálogo. */
    @PostMapping("/campos/sincronizar")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> sincronizarCampos(
            @RequestParam int idUsuario) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-FIL-CAM-SYNC", "Campos del histórico actualizados correctamente.",
                    service.sincronizarCampos(idUsuario)));
        } catch (Exception ex) {
            return error("RPE-FIL-CAM-SYNC-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> crear(
            @RequestBody ReporteEstadisticaFiltroAdminRequestDTO request) {
        try {
            Map<String, Object> data = service.crear(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(successFromOperation(data));
        } catch (Exception ex) {
            return error("RPE-FIL-INS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/orden")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> reordenar(
            @RequestBody ReporteEstadisticaFiltroOrdenRequestDTO request) {
        try {
            return ResponseEntity.ok(successFromOperation(service.reordenar(request)));
        } catch (Exception ex) {
            return error("RPE-FIL-ORD-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/{idFiltro}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> actualizar(
            @PathVariable int idFiltro,
            @RequestBody ReporteEstadisticaFiltroAdminRequestDTO request) {
        try {
            return ResponseEntity.ok(successFromOperation(service.actualizar(idFiltro, request)));
        } catch (Exception ex) {
            return error("RPE-FIL-UPD-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    /* PUT evita el 403 que producía PATCH con la política CORS actual. */
    @PutMapping("/{idFiltro}/estatus")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatus(
            @PathVariable int idFiltro,
            @RequestBody CambioEstatusRequestDTO request) {
        try {
            return ResponseEntity.ok(successFromOperation(service.cambiarEstatus(idFiltro, request)));
        } catch (Exception ex) {
            return error("RPE-FIL-STS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    private ApiResponseDTO<Map<String, Object>> successFromOperation(Map<String, Object> data) {
        String code = stringValue(data, "Code", "RPE-FIL-OK");
        String message = stringValue(data, "Message", "Operación realizada correctamente.");
        String detail = nullableString(data.get("Detail"));
        ApiResponseDTO<Map<String, Object>> response = ApiResponseDTO.ok(code, message, data);
        response.setDetail(detail);
        return response;
    }

    private <T> ResponseEntity<ApiResponseDTO<T>> error(String code, Exception ex, HttpStatus status) {
        return ResponseEntity.status(status).body(
                ApiResponseDTO.<T>fail(
                        code,
                        "No fue posible completar la operación.",
                        rootMessage(ex),
                        ex.getClass().getSimpleName()));
    }

    private String stringValue(Map<String, Object> map, String key, String fallback) {
        Object value = map == null ? null : map.get(key);
        return value == null || String.valueOf(value).trim().isEmpty() ? fallback : String.valueOf(value);
    }

    private String nullableString(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    private String rootMessage(Throwable error) {
        Throwable cursor = error;
        String message = error.getMessage();
        while (cursor.getCause() != null && cursor.getCause() != cursor) {
            cursor = cursor.getCause();
            if (cursor.getMessage() != null && !cursor.getMessage().trim().isEmpty()) {
                message = cursor.getMessage();
            }
        }
        return message == null ? "Error no identificado." : message;
    }
}
