package com.lockton.rpt.models.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CatReportesRequest_DTO {
    public int catReportesId;
    public int catReportesNum;
    public String catReportesNombre;
    public String catReportesDesc;
    public int catReportesTAId;
    public String catReportesFormato;
    public int esId;
    public int catTipoReporteId;
    public int catReportesUsuarioAdd;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    public LocalDateTime catReportesFechaAdd;
    public int catReportesUsuarioMod;
    public String catReportesFechaMod;
    
    public int getCatReportesId() {
        return catReportesId;
    }
    public void setCatReportesId(int catReportesId) {
        this.catReportesId = catReportesId;
    }
    public int getCatReportesNum() {
        return catReportesNum;
    }
    public void setCatReportesNum(int catReportesNum) {
        this.catReportesNum = catReportesNum;
    }
    public String getCatReportesNombre() {
        return catReportesNombre;
    }
    public void setCatReportesNombre(String catReportesNombre) {
        this.catReportesNombre = catReportesNombre;
    }
    public String getCatReportesDesc() {
        return catReportesDesc;
    }
    public void setCatReportesDesc(String catReportesDesc) {
        this.catReportesDesc = catReportesDesc;
    }
    public int getCatReportesTAId() {
        return catReportesTAId;
    }
    public void setCatReportesTAId(int catReportesTAId) {
        this.catReportesTAId = catReportesTAId;
    }
    public String getCatReportesFormato() {
        return catReportesFormato;
    }
    public void setCatReportesFormato(String catReportesFormato) {
        this.catReportesFormato = catReportesFormato;
    }
    public int getEsId() {
        return esId;
    }
    public void setEsId(int esId) {
        this.esId = esId;
    }
    public int getCatReportesUsuarioMod() {
        return catReportesUsuarioMod;
    }
    public void setCatReportesUsuarioMod(int catReportesUsuarioMod) {
        this.catReportesUsuarioMod = catReportesUsuarioMod;
    }
    public String getCatReportesFechaMod() {
        return catReportesFechaMod;
    }
    public void setCatReportesFechaMod(String catReportesFechaMod) {
        this.catReportesFechaMod = catReportesFechaMod;
    }
    public int getCatReportesUsuarioAdd() {
        return catReportesUsuarioAdd;
    }
    public void setCatReportesUsuarioAdd(int catReportesUsuarioAdd) {
        this.catReportesUsuarioAdd = catReportesUsuarioAdd;
    }
    public LocalDateTime getCatReportesFechaAdd() {
        return catReportesFechaAdd;
    }
    public void setCatReportesFechaAdd(LocalDateTime catReportesFechaAdd) {
        this.catReportesFechaAdd = catReportesFechaAdd;
    }
}
