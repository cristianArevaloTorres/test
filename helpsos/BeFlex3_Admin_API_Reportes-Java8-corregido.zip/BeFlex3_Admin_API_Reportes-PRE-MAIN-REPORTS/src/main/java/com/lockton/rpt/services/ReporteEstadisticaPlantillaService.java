package com.lockton.rpt.services;

import java.util.Map;

public interface ReporteEstadisticaPlantillaService {
    Map<String, Object> obtenerGlobal();
    Map<String, Object> obtenerCorporativa(int idCorporativo);
    Map<String, Object> obtenerCorporativaCompleta(int idCorporativo, int maxFilasPorFuente);
    Map<String, Object> obtenerCatalogos();
    Map<String, Object> guardarGlobal(Map<String, Object> plantilla, int idUsuario);
    Map<String, Object> guardarCorporativa(int idCorporativo, Map<String, Object> plantilla, int idUsuario);
    Map<String, Object> replicarCorporativa(int idCorporativo, int idUsuario);
    Map<String, Object> crearCorporativaVacia(int idCorporativo, int idUsuario);
    Map<String, Object> obtenerPreview(int idCorporativo, int idStoredProcedure, int maxFilas);
    Map<String, Object> obtenerDatosBeflex(int idCorporativo, int idStoredProcedure, int maxFilas);
}
