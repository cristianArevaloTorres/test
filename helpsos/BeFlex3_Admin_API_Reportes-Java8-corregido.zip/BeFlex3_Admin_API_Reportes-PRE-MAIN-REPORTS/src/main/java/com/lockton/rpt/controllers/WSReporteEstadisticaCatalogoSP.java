package com.lockton.rpt.controllers;

import java.util.List;
import java.util.Map;

import com.lockton.rpt.models.dto.crea17.ApiResponseDTO;
import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpFiltroRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpSalidaRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpValidacionRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpValidacionLoteRequestDTO;
import com.lockton.rpt.services.ReporteEstadisticaCatalogoService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/beflex/reporte-estadisticas/crea17/catalogo-consultas", "/beflex/reporte-estadisticas/crea17/catalogo-sp"})
public class WSReporteEstadisticaCatalogoSP {
    private final ReporteEstadisticaCatalogoService service;

    public WSReporteEstadisticaCatalogoSP(ReporteEstadisticaCatalogoService service) {
        this.service = service;
    }

    @GetMapping("/contexto-validacion")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerContextoValidacion(
            @RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-CTX-GET", "Contexto de validación consultado correctamente.",
                    service.obtenerContextoValidacion(idCorporativo)));
        } catch (Exception ex) {
            return error("RPE-CTX-GET-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/filtros")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> listarFiltros() {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-CAT-001", "Catálogo de filtros consultado correctamente.", service.listarFiltros()));
        } catch (Exception ex) {
            return error("RPE-CAT-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/stored-procedures")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> listarStoredProcedures(
            @RequestParam(defaultValue = "true") boolean incluirBajas) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SP-GET", "Stored procedures consultados correctamente.",
                    service.listarStoredProcedures(incluirBajas)));
        } catch (Exception ex) {
            return error("RPE-SP-GET-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/stored-procedures/{idStoredProcedure}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerStoredProcedure(
            @PathVariable int idStoredProcedure) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SP-DET", "Detalle consultado correctamente.",
                    service.obtenerStoredProcedure(idStoredProcedure)));
        } catch (IllegalArgumentException ex) {
            return error("RPE-SP-DET-404", ex, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return error("RPE-SP-DET-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/stored-procedures/validar")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> validarStoredProcedure(
            @RequestBody ReporteEstadisticaSpValidacionRequestDTO request) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SP-VAL", "Validación técnica ejecutada correctamente.",
                    service.validarStoredProcedure(request)));
        } catch (Exception ex) {
            return error("RPE-SP-VAL-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/stored-procedures/validar-lote")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> validarStoredProceduresLote(
            @RequestBody ReporteEstadisticaSpValidacionLoteRequestDTO request) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SP-VAL-BATCH", "Comprobación automática ejecutada correctamente.",
                    service.validarStoredProceduresLote(request)));
        } catch (Exception ex) {
            return error("RPE-SP-VAL-BATCH-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/stored-procedures/{idStoredProcedure}/ultimo-snapshot")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerUltimoSnapshot(
            @PathVariable int idStoredProcedure,
            @RequestParam int idCorporativo,
            @RequestParam(defaultValue = "1") int pagina,
            @RequestParam(defaultValue = "100") int tamanoPagina,
            @RequestParam(required = false) Integer maxFilas) {
        try {
            int pageSize = maxFilas == null ? tamanoPagina : maxFilas.intValue();
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-SP-SNAPSHOT", "Último snapshot publicado consultado correctamente.",
                    service.obtenerUltimoSnapshot(idCorporativo, idStoredProcedure, pagina, pageSize)));
        } catch (Exception ex) {
            return error("RPE-SP-SNAPSHOT-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/stored-procedures")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> crearStoredProcedure(
            @RequestBody ReporteEstadisticaSpRequestDTO request) {
        try {
            Map<String, Object> data = service.crearStoredProcedure(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(successFromOperation(data));
        } catch (Exception ex) {
            return error("RPE-SP-INS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/stored-procedures/{idStoredProcedure}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> actualizarStoredProcedure(
            @PathVariable int idStoredProcedure,
            @RequestBody ReporteEstadisticaSpRequestDTO request) {
        try {
            return ResponseEntity.ok(successFromOperation(
                    service.actualizarStoredProcedure(idStoredProcedure, request)));
        } catch (Exception ex) {
            return error("RPE-SP-UPD-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/stored-procedures/{idStoredProcedure}/estatus")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatusStoredProcedure(
            @PathVariable int idStoredProcedure,
            @RequestBody CambioEstatusRequestDTO request) {
        try {
            return ResponseEntity.ok(successFromOperation(
                    service.cambiarEstatusStoredProcedure(idStoredProcedure, request)));
        } catch (Exception ex) {
            return error("RPE-SP-STS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/stored-procedures/{idStoredProcedure}/revalidar")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> revalidarStoredProcedure(
            @PathVariable int idStoredProcedure,
            @RequestParam int idUsuario,
            @RequestParam int idCorporativo,
            @RequestParam int idVigencia) {
        try {
            return ResponseEntity.ok(successFromOperation(
                    service.revalidarStoredProcedure(idStoredProcedure, idUsuario, idCorporativo, idVigencia)));
        } catch (Exception ex) {
            return error("RPE-SP-REVAL-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/stored-procedures/{idStoredProcedure}/salidas")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> crearSalida(
            @PathVariable int idStoredProcedure,
            @RequestBody ReporteEstadisticaSpSalidaRequestDTO request) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(successFromOperation(
                    service.crearSalida(idStoredProcedure, request)));
        } catch (Exception ex) {
            return error("RPE-SAL-INS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/stored-procedures/{idStoredProcedure}/salidas/{idSalida}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> actualizarSalida(
            @PathVariable int idStoredProcedure,
            @PathVariable int idSalida,
            @RequestBody ReporteEstadisticaSpSalidaRequestDTO request) {
        try {
            // idStoredProcedure forma parte de la ruta para conservar el contexto REST; la BD valida la relación real.
            return ResponseEntity.ok(successFromOperation(service.actualizarSalida(idSalida, request)));
        } catch (Exception ex) {
            return error("RPE-SAL-UPD-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/stored-procedures/{idStoredProcedure}/salidas/{idSalida}/estatus")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatusSalida(
            @PathVariable int idStoredProcedure,
            @PathVariable int idSalida,
            @RequestBody CambioEstatusRequestDTO request) {
        try {
            return ResponseEntity.ok(successFromOperation(service.cambiarEstatusSalida(idSalida, request)));
        } catch (Exception ex) {
            return error("RPE-SAL-STS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/stored-procedures/{idStoredProcedure}/filtros")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> crearFiltro(
            @PathVariable int idStoredProcedure,
            @RequestBody ReporteEstadisticaSpFiltroRequestDTO request) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(successFromOperation(
                    service.crearFiltro(idStoredProcedure, request)));
        } catch (Exception ex) {
            return error("RPE-FIL-INS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/stored-procedures/{idStoredProcedure}/filtros/{idRelacion}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> actualizarFiltro(
            @PathVariable int idStoredProcedure,
            @PathVariable int idRelacion,
            @RequestBody ReporteEstadisticaSpFiltroRequestDTO request) {
        try {
            return ResponseEntity.ok(successFromOperation(service.actualizarFiltro(idRelacion, request)));
        } catch (Exception ex) {
            return error("RPE-FIL-UPD-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/stored-procedures/{idStoredProcedure}/filtros/{idRelacion}/estatus")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatusFiltro(
            @PathVariable int idStoredProcedure,
            @PathVariable int idRelacion,
            @RequestBody CambioEstatusRequestDTO request) {
        try {
            return ResponseEntity.ok(successFromOperation(service.cambiarEstatusFiltro(idRelacion, request)));
        } catch (Exception ex) {
            return error("RPE-FIL-STS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    private ApiResponseDTO<Map<String, Object>> successFromOperation(Map<String, Object> data) {
        String code = stringValue(data, "Code", "RPE-OK");
        String message = stringValue(data, "Message", "Operación realizada correctamente.");
        String detail = nullableString(data.get("Detail"));
        ApiResponseDTO<Map<String, Object>> response = ApiResponseDTO.ok(code, message, data);
        response.setDetail(detail);
        return response;
    }

    private <T> ResponseEntity<ApiResponseDTO<T>> error(String code, Exception ex, HttpStatus status) {
        String detail = rootMessage(ex);
        return ResponseEntity.status(status).body(
                ApiResponseDTO.<T>fail(code, "No fue posible completar la operación.", detail,
                        ex.getClass().getSimpleName()));
    }

    private String stringValue(Map<String, Object> map, String key, String fallback) {
        Object value = map == null ? null : map.get(key);
        return value == null || String.valueOf(value).trim().isEmpty() ? fallback : String.valueOf(value);
    }

    private String nullableString(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    private String rootMessage(Throwable error) {
        Throwable cursor = error;
        String message = error.getMessage();
        while (cursor.getCause() != null && cursor.getCause() != cursor) {
            cursor = cursor.getCause();
            if (cursor.getMessage() != null && !cursor.getMessage().trim().isEmpty()) {
                message = cursor.getMessage();
            }
        }
        return message == null ? "Error no identificado." : message;
    }
}
