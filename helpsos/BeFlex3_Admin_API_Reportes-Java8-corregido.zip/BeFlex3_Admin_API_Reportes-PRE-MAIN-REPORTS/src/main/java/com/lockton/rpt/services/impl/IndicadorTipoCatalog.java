package com.lockton.rpt.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.lockton.rpt.util.TextUtil;

/**
 * Catálogo de tipos de indicador/gráfica.
 * Para agregar un tipo nuevo: añadir una entrada en {@link #TIPOS} con roles de mapeo e hint.
 */
public final class IndicadorTipoCatalog {

    public static final String ROLE_LABELS = "labels";
    public static final String ROLE_VALUES = "values";
    public static final String ROLE_SERIES = "series";
    public static final String ROLE_COLORS = "colors";
    public static final String ROLE_PERCENTAGE = "percentage";
    public static final String ROLE_HOMBRES = "hombres";
    public static final String ROLE_MUJERES = "mujeres";

    private static final List<Map<String, Object>> TIPOS = Arrays.asList(
            tipo("TABLA", "Tabla", true,
                    Collections.emptyList(), Collections.emptyList(), null),
            tipo("BARRAS", "Gráfico de barras", true,
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES, ROLE_SERIES, ROLE_COLORS),
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES),
                    "Columnas labels y values obligatorias. Series y colors opcionales."),
            tipo("BARRAS_REDONDEADAS", "Barras redondeadas", true,
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES, ROLE_PERCENTAGE, ROLE_SERIES, ROLE_COLORS),
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES),
                    "Muestra total y porcentaje en la misma etiqueta de cada barra; percentage no crea otra serie."),
            tipo("LINEA", "Gráfico de líneas", true,
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES, ROLE_SERIES, ROLE_COLORS),
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES),
                    "Igual que barras; el render usa líneas suaves."),
            tipo("PASTEL", "Gráfico de pastel", true,
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES, ROLE_PERCENTAGE, ROLE_COLORS),
                    Arrays.asList(ROLE_VALUES),
                    "Requiere values y labels o percentage."),
            tipo("KPI", "Indicador KPI", true,
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES),
                    Arrays.asList(ROLE_VALUES),
                    "Requiere la columna values (labels opcional para subtítulo)."),
            tipo("PUNTOS", "Gráfico de puntos", true,
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES, ROLE_SERIES, ROLE_COLORS),
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES),
                    "Columnas labels y values obligatorias."),
            tipo("GENERO", "Gráfico de género", true,
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES, ROLE_PERCENTAGE),
                    Arrays.asList(ROLE_VALUES),
                    "Siluetas M/F. En labels la columna de género; en values el conteo o en percentage el % (0–100)."),
            tipo("DISTRIBUCION_DONA", "Distribución dona", true,
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES, ROLE_PERCENTAGE, ROLE_HOMBRES, ROLE_MUJERES, ROLE_COLORS),
                    Arrays.asList(ROLE_LABELS, ROLE_VALUES),
                    "Una tarjeta por fila: labels, values, percentage, hombres/mujeres (barra H/M), colors opcional."),
            tipo("IMAGEN", "Imagen", false,
                    Collections.emptyList(), Collections.emptyList(), null),
            tipo("MATRIZ_MOVILIDAD", "Matriz movilidad", true,
                    Collections.emptyList(), Collections.emptyList(), null));

    private static final Set<String> CLAVES = Collections.unmodifiableSet(new HashSet<String>(Arrays.asList(
            "TABLA", "BARRAS", "BARRAS_REDONDEADAS", "LINEA", "LINE", "PASTEL", "PIE", "KPI", "PUNTOS", "SCATTER", "GENERO",
            "DISTRIBUCION_DONA", "DIST_DONA", "DONA", "DONUT", "IMAGEN", "MATRIZ_MOVILIDAD")));

    private IndicadorTipoCatalog() {
    }

    public static List<Map<String, Object>> listForApi() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> t : TIPOS) {
            Map<String, Object> row = new LinkedHashMap<>(t);
            row.put("CETIidConfiguracionEstadisticasTipoIndicador", row.get("ordinal"));
            out.add(row);
        }
        return out;
    }

    public static Map<String, Object> getDefinition(String clave) {
        String normalized = normalize(clave);
        for (Map<String, Object> t : TIPOS) {
            if (normalized.equals(String.valueOf(t.get("Clave")))) {
                return new LinkedHashMap<>(t);
            }
        }
        return new LinkedHashMap<>();
    }

    @SuppressWarnings("unchecked")
    public static List<String> rolesConfiguracion(String clave) {
        Map<String, Object> def = getDefinition(clave);
        Object raw = def.get("rolesConfiguracion");
        if (!(raw instanceof List)) {
            return Collections.emptyList();
        }
        List<String> out = new ArrayList<>();
        for (Object item : (List<?>) raw) {
            if (item != null) {
                out.add(String.valueOf(item));
            }
        }
        return out;
    }

    public static String hintConfiguracion(String clave) {
        Map<String, Object> def = getDefinition(clave);
        return String.valueOf(def.getOrDefault("hintConfiguracion", ""));
    }

    public static String normalize(String clave) {
        if (TextUtil.isBlank(clave)) {
            return "TABLA";
        }
        String c = clave.trim().toUpperCase(Locale.ROOT);
        if ("PIE".equals(c)) {
            return "PASTEL";
        }
        if ("LINE".equals(c)) {
            return "LINEA";
        }
        if ("SCATTER".equals(c)) {
            return "PUNTOS";
        }
        if ("DIST_DONA".equals(c)) {
            return "DISTRIBUCION_DONA";
        }
        if ("DONA".equals(c) || "DONUT".equals(c)) {
            return "PASTEL";
        }
        return CLAVES.contains(c) ? c : "TABLA";
    }

    public static boolean esGrafica(String clave) {
        String t = normalize(clave);
        return !"TABLA".equals(t) && !"IMAGEN".equals(t) && !"MATRIZ_MOVILIDAD".equals(t);
    }

    public static boolean validarAtributosGrafica(String tipoClave, Map<String, String> attrs) {
        String tipo = normalize(tipoClave);
        Map<String, String> a = attrs != null ? attrs : Collections.emptyMap();
        boolean hasValues = hasAttr(a, ROLE_VALUES);
        boolean hasLabels = hasAttr(a, ROLE_LABELS);
        boolean hasPct = hasAttr(a, ROLE_PERCENTAGE);
        if ("KPI".equals(tipo)) {
            return hasValues;
        }
        if ("PASTEL".equals(tipo)) {
            return hasValues && (hasLabels || hasPct);
        }
        if ("GENERO".equals(tipo)) {
            return hasValues && (hasLabels || hasPct);
        }
        if ("DISTRIBUCION_DONA".equals(tipo)) {
            return hasValues && hasLabels;
        }
        if (!esGrafica(tipo)) {
            return true;
        }
        List<String> required = rolesRequeridos(tipo);
        if (required.isEmpty()) {
            return hasValues && hasLabels;
        }
        for (String role : required) {
            if (ROLE_VALUES.equals(role) && hasValues) {
                continue;
            }
            if (ROLE_LABELS.equals(role) && hasLabels) {
                continue;
            }
            if (!hasAttr(a, role)) {
                return false;
            }
        }
        if ("PASTEL".equals(tipo) || "GENERO".equals(tipo)) {
            return hasValues && (hasLabels || hasPct);
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    private static List<String> rolesRequeridos(String clave) {
        Map<String, Object> def = getDefinition(clave);
        Object raw = def.get("rolesRequeridos");
        if (!(raw instanceof List)) {
            return Collections.emptyList();
        }
        List<String> out = new ArrayList<>();
        for (Object item : (List<?>) raw) {
            if (item != null) {
                out.add(String.valueOf(item));
            }
        }
        return out;
    }

    private static boolean hasAttr(Map<String, String> attrs, String key) {
        String val = attrs.get(key);
        return val != null && !TextUtil.isBlank(val);
    }

    private static Map<String, Object> tipo(String clave, String nombre, boolean requiereSp,
            List<String> rolesConfiguracion, List<String> rolesRequeridos, String hint) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("ordinal", ordinalFor(clave));
        m.put("CETIClave", clave);
        m.put("CETINombre", nombre);
        m.put("CETIDescripcion", nombre);
        m.put("CETIRequiereSP", requiereSp ? 1 : 0);
        m.put("CETIPermiteMapeo", 1);
        m.put("Clave", clave);
        m.put("Nombre", nombre);
        m.put("esGrafica", esGraficaClave(clave));
        m.put("rolesConfiguracion", rolesConfiguracion != null ? rolesConfiguracion : Collections.emptyList());
        m.put("rolesRequeridos", rolesRequeridos != null ? rolesRequeridos : Collections.emptyList());
        List<String> opcionales = new ArrayList<>();
        if (rolesConfiguracion != null && rolesRequeridos != null) {
            for (String role : rolesConfiguracion) {
                if (!rolesRequeridos.contains(role)) {
                    opcionales.add(role);
                }
            }
        }
        m.put("rolesOpcionales", opcionales);
        m.put("hintConfiguracion", hint != null ? hint : "");
        return m;
    }

    private static boolean esGraficaClave(String clave) {
        return !"TABLA".equals(clave) && !"IMAGEN".equals(clave) && !"MATRIZ_MOVILIDAD".equals(clave);
    }

    private static int ordinalFor(String clave) {
        switch (clave) {
            case "TABLA": return 1;
            case "BARRAS": return 2;
            case "BARRAS_REDONDEADAS": return 26;
            case "LINEA": return 3;
            case "PUNTOS": return 4;
            case "PASTEL": return 5;
            case "KPI": return 6;
            case "GENERO": return 9;
            case "DISTRIBUCION_DONA": return 10;
            case "IMAGEN": return 7;
            case "MATRIZ_MOVILIDAD": return 8;
            default: return 99;
        }
    }
}
