package com.lockton.rpt.models.dto;

public class ResponseGralDTO {
    public String messages;
    public Boolean status;
    
    public String getMessages() {
        return messages;
    }
    public void setMessages(String messages) {
        this.messages = messages;
    }
    public Boolean getStatus() {
        return status;
    }
    public void setStatus(Boolean status) {
        this.status = status;
    }
}
