package com.lockton.rpt.repositories;

import java.util.List;
import java.util.Map;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpFiltroRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpSalidaRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpValidacionRequestDTO;

public interface ReporteEstadisticaCatalogoDAO {
    Map<String, Object> obtenerContextoValidacion(int idCorporativo);
    List<Map<String, Object>> listarFiltros();
    List<Map<String, Object>> listarStoredProcedures(boolean incluirBajas);
    Map<String, Object> obtenerStoredProcedure(int idStoredProcedure);
    Map<String, Object> validarStoredProcedure(ReporteEstadisticaSpValidacionRequestDTO request);
    Map<String, Object> obtenerUltimoSnapshot(int idCorporativo, int idStoredProcedure, int pagina, int tamanoPagina);
    Map<String, Object> crearStoredProcedure(ReporteEstadisticaSpRequestDTO request);
    Map<String, Object> actualizarStoredProcedure(int idStoredProcedure, ReporteEstadisticaSpRequestDTO request);
    Map<String, Object> cambiarEstatusStoredProcedure(int idStoredProcedure, CambioEstatusRequestDTO request);
    Map<String, Object> revalidarStoredProcedure(int idStoredProcedure, int idUsuario);
    Map<String, Object> sincronizarSalidas(int idStoredProcedure, List<Map<String, Object>> salidas, String hashDefinicion, int idUsuario, boolean esAlta);
    Map<String, Object> crearSalida(int idStoredProcedure, ReporteEstadisticaSpSalidaRequestDTO request);
    Map<String, Object> actualizarSalida(int idSalida, ReporteEstadisticaSpSalidaRequestDTO request);
    Map<String, Object> cambiarEstatusSalida(int idSalida, CambioEstatusRequestDTO request);
    Map<String, Object> crearFiltro(int idStoredProcedure, ReporteEstadisticaSpFiltroRequestDTO request);
    Map<String, Object> actualizarFiltro(int idRelacion, ReporteEstadisticaSpFiltroRequestDTO request);
    Map<String, Object> cambiarEstatusFiltro(int idRelacion, CambioEstatusRequestDTO request);
}
