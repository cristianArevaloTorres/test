package com.lockton.rpt.services.impl;

import com.lockton.rpt.util.TextUtil;

/**
 * Nombres de tablas históricas bf_Indicador* por SP de reporte estadísticas.
 */
public final class SnapshotTableNaming {

    private SnapshotTableNaming() {
    }

    /** dbo.sp_ReporteEstad_GetParametros → bf_IndicadorReporteEstad_GetParametros */
    public static String tableForProcedure(String nombreProcedimiento) {
        if (nombreProcedimiento == null || TextUtil.isBlank(nombreProcedimiento)) {
            throw new IllegalArgumentException("Nombre de procedimiento vacío.");
        }
        String proc = nombreProcedimiento.trim().replace("dbo.", "");
        if (proc.regionMatches(true, 0, "sp_", 0, 3)) {
            proc = proc.substring(3);
        }
        return "bf_Indicador" + proc;
    }

    public static boolean isKnownSnapshotProcedure(String nombreProcedimiento) {
        try {
            tableForProcedure(nombreProcedimiento);
            return nombreProcedimiento.contains("ReporteEstad_");
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }
}
