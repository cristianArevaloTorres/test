package com.lockton.rpt.repositories.jdbc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.rpt.repositories.ReporteEstadisticaBeflexPlantillaDAO;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;


import java.util.Map;

@Repository
public class JDBCReporteEstadisticaBeflexPlantillaDAO
        implements ReporteEstadisticaBeflexPlantillaDAO {

    private static final int DEFAULT_TIMEOUT_SECONDS = 120;
    private static final int RESOLVER_TIMEOUT_SECONDS = 900;

    private final DataSource dataSource;
    private final ObjectMapper objectMapper;

    public JDBCReporteEstadisticaBeflexPlantillaDAO(
            DataSource dataSource,
            ObjectMapper objectMapper) {
        this.dataSource = dataSource;
        this.objectMapper = objectMapper;
    }

    @Override
    public List<Map<String, Object>> listarPlantillas(
            int idCorporativo,
            Integer idIdioma,
            boolean soloPdf) {
        return resultSet(callReadOnly(
                "dbo.bf_BeFlexCREA17_PlantillasCorporativas_Listar",
                DEFAULT_TIMEOUT_SECONDS,
                Integer.valueOf(idCorporativo),
                idIdioma == null ? sqlNull(Types.INTEGER) : idIdioma,
                Boolean.valueOf(soloPdf)), 0);
    }

    @Override
    public Map<String, Object> obtenerContexto(int idCorporativo) {


        Map<String, Object> row = firstRow(callReadOnly(
                "dbo.bf_BeFlexCREA17_ContextoPlantilla",
                DEFAULT_TIMEOUT_SECONDS,
                Integer.valueOf(idCorporativo)), 0);
        if (row == null) {
            throw new IllegalStateException(
                    "No fue posible resolver el contexto actual del corporativo.");
        }
        return row;
    }

    @Override
    public List<Map<String, Object>> listarFiltros(int idCorporativo) {
        return resultSet(callReadOnly(
                "dbo.bf_REPEQ_CatalogoFiltrosModulo",
                DEFAULT_TIMEOUT_SECONDS,
                Boolean.FALSE,
                Integer.valueOf(idCorporativo)), 0);
    }

    @Override
    public Map<String, Object> obtenerConfiguracion(
            int idCorporativo,
            int idPlantilla) {
        List<List<Map<String, Object>>> resultSets = callReadOnly(
                "dbo.bf_REPEQ_PlantillaRuntime_Resolver",
                DEFAULT_TIMEOUT_SECONDS,
                Integer.valueOf(idCorporativo),
                Integer.valueOf(idPlantilla));

        Map<String, Object> design = mapDesign(resultSets);
        Object exists = design.get("existe");
        if (!Boolean.TRUE.equals(exists)) {
            throw new IllegalStateException(
                    "No se encontró la configuración de la plantilla.");
        }

        Map<String, Object> plantilla = mapValue(design.get("Plantilla"));
        String tipo = stringValue(value(plantilla, "Tipo"));
        Integer corporativoPlantilla = integerValue(
                value(plantilla, "IdCorporativo"));

        if (!"CORPORATIVO".equalsIgnoreCase(tipo)
                || corporativoPlantilla == null
                || corporativoPlantilla.intValue() != idCorporativo) {
            throw new IllegalStateException(
                    "La plantilla no está disponible para el corporativo actual.");
        }
        return design;
    }

    @Override
    public List<Map<String, Object>> obtenerOpcionesFiltro(
            int idCorporativo,
            int idVigencia,
            String clave,
            Map<String, Object> filtros) {
        String json = json(filtros);
        return resultSet(callReadOnly(
                "dbo.bf_REPEQ_ResolverFiltroOpciones",
                RESOLVER_TIMEOUT_SECONDS,
                Integer.valueOf(idCorporativo),
                Integer.valueOf(idVigencia),
                clave,
                json), 0);
    }

    @Override
    public Map<String, Object> consultarPlantilla(
            String uidSolicitud,
            int idCorporativo,
            int idVigencia,
            int idPlantilla,
            int idUsuario,
            Map<String, Object> filtros) {
        String filtrosJson = json(filtros);
        Long idEjecucion = null;
        String uidEjecucion = null;

        try (Connection connection = dataSource.getConnection()) {
            connection.setReadOnly(false);

            Map<String, Object> start = firstRow(execute(
                    connection,
                    "dbo.bf_BeFlexCREA17_ConsultaEjecucion_Iniciar",
                    DEFAULT_TIMEOUT_SECONDS,
                    uidSolicitud,
                    Integer.valueOf(idUsuario),
                    Integer.valueOf(idCorporativo),
                    Integer.valueOf(idVigencia),
                    Integer.valueOf(idPlantilla),
                    filtrosJson), 0);

            if (start == null) {
                throw new IllegalStateException(
                        "No fue posible registrar la solicitud de consulta.");
            }

            idEjecucion = longValue(value(start, "IdEjecucion"));
            Object uid = value(start, "UidEjecucion");
            uidEjecucion = uid == null ? null : String.valueOf(uid);
            Object esNuevaRaw = value(start, "EsNueva");
            boolean esNueva = esNuevaRaw == null || Boolean.parseBoolean(String.valueOf(esNuevaRaw)) || "1".equals(String.valueOf(esNuevaRaw));
            if (!esNueva) {
                Map<String, Object> existing = new LinkedHashMap<String, Object>();
                existing.put("idSolicitud", idEjecucion);
                existing.put("uidSolicitud", uidEjecucion);
                existing.put("estadoSolicitud", value(start, "Estado"));
                existing.put("reutilizada", Boolean.TRUE);
                return existing;
            }

            if (idEjecucion == null) {
                throw new IllegalStateException(
                        "La solicitud de consulta no devolvió un identificador.");
            }

            List<List<Map<String, Object>>> resultSets = execute(
                    connection,
                    "dbo.bf_REPEQ_ResolverPlantilla",
                    RESOLVER_TIMEOUT_SECONDS,
                    Integer.valueOf(idCorporativo),
                    Integer.valueOf(idVigencia),
                    Integer.valueOf(idPlantilla),
                    filtrosJson);

            List<Map<String, Object>> metadata = resultSet(resultSets, 0);
            List<Map<String, Object>> indicadores =
                    new ArrayList<Map<String, Object>>();
            Map<String, Object> porIndicador =
                    new LinkedHashMap<String, Object>();
            Map<String, Object> porStoredProcedure =
                    new LinkedHashMap<String, Object>();

            for (int index = 0; index < metadata.size(); index++) {
                Map<String, Object> meta = metadata.get(index);
                List<Map<String, Object>> filas =
                        resultSet(resultSets, index + 1);

                Map<String, Object> item =
                        new LinkedHashMap<String, Object>();
                item.putAll(meta);
                item.put("filas", filas);
                item.put("totalFilas", Integer.valueOf(filas.size()));
                indicadores.add(item);

                Object idIndicador = value(meta, "IdIndicador");
                if (idIndicador != null) {
                    porIndicador.put(String.valueOf(idIndicador), filas);
                }
                Object idStoredProcedure = value(meta, "IdStoredProcedure");
                if (idStoredProcedure != null && !porStoredProcedure.containsKey(String.valueOf(idStoredProcedure))) {
                    porStoredProcedure.put(String.valueOf(idStoredProcedure), filas);
                }
            }

            Map<String, Object> finished = firstRow(execute(
                    connection,
                    "dbo.bf_BeFlexCREA17_ConsultaEjecucion_Finalizar",
                    DEFAULT_TIMEOUT_SECONDS,
                    idEjecucion,
                    "CORRECTO",
                    Integer.valueOf(indicadores.size()),
                    metadata.isEmpty() ? sqlNull(Types.BIGINT) : value(metadata.get(0), "IdEjecucionSnapshot"),
                    sqlNull(Types.NVARCHAR)), 0);

            Map<String, Object> contexto =
                    new LinkedHashMap<String, Object>();
            contexto.put("idCorporativo", Integer.valueOf(idCorporativo));
            contexto.put("idVigencia", Integer.valueOf(idVigencia));
            contexto.put("idPlantilla", Integer.valueOf(idPlantilla));
            if (!metadata.isEmpty()) {
                Object snapshot = value(
                        metadata.get(0),
                        "IdEjecucionSnapshot");
                contexto.put("idEjecucionSnapshot", snapshot);
            }

            Map<String, Object> response =
                    new LinkedHashMap<String, Object>();
            response.put("idSolicitud", idEjecucion);
            response.put("uidSolicitud", uidEjecucion);
            response.put("contexto", contexto);
            response.put("filtros", filtros == null
                    ? new LinkedHashMap<String, Object>()
                    : filtros);
            response.put("indicadores", indicadores);
            response.put("porIndicador", porIndicador);
            response.put("porStoredProcedure", porStoredProcedure);
            response.put("estadoSolicitud", "CORRECTO");
            response.put("ejecucion", finished);
            return response;
        } catch (Exception ex) {
            if (idEjecucion != null) {
                finalizarError(idEjecucion.longValue(), ex);
            }
            if (ex instanceof IllegalStateException) {
                throw (IllegalStateException) ex;
            }
            throw new IllegalStateException(
                    "No fue posible resolver la plantilla filtrada.",
                    ex);
        }
    }

    @Override
    public Map<String, Object> obtenerEjecucion(String uidSolicitud) {
        Map<String, Object> row = firstRow(callReadOnly(
                "dbo.bf_BeFlexCREA17_ConsultaEjecucion_Obtener",
                DEFAULT_TIMEOUT_SECONDS,
                uidSolicitud), 0);
        if (row == null) {
            throw new IllegalStateException("No se encontró la solicitud indicada.");
        }
        return row;
    }

    /**
     * Compatibilidad del endpoint antiguo. Ya no es utilizado por el nuevo
     * runtime, pero se mantiene funcional mientras termina la migración.
     */
    @Override
    public Map<String, Object> obtenerDatosFuente(
            int idCorporativo,
            int idPlantilla,
            int idStoredProcedure,
            int maxFilas) {
        Map<String, Object> contexto = obtenerContexto(idCorporativo);
        Integer idVigencia = integerValue(value(contexto, "IdVigencia"));
        if (idVigencia == null || idVigencia.intValue() <= 0) {
            throw new IllegalStateException(
                    "No fue posible resolver la vigencia actual.");
        }

        String nombreTecnico = consultaAsignada(
                idPlantilla,
                idStoredProcedure);
        if (nombreTecnico == null || nombreTecnico.trim().isEmpty()) {
            throw new IllegalStateException(
                    "La consulta no está asignada a la plantilla solicitada.");
        }

        List<Map<String, Object>> rows = resultSet(callReadOnly(
                "dbo.bf_REPEQ_ResolverPreviewConsulta",
                RESOLVER_TIMEOUT_SECONDS,
                Integer.valueOf(idCorporativo),
                idVigencia,
                nombreTecnico), 0);

        boolean limite = maxFilas > 0 && rows.size() > maxFilas;
        if (limite) {
            rows = new ArrayList<Map<String, Object>>(
                    rows.subList(0, maxFilas));
        }

        Map<String, Object> meta = new LinkedHashMap<String, Object>();
        meta.put("idPlantilla", Integer.valueOf(idPlantilla));
        meta.put("idStoredProcedure", Integer.valueOf(idStoredProcedure));
        meta.put("filasDevueltas", Integer.valueOf(rows.size()));
        meta.put("maxFilasSolicitadas", Integer.valueOf(maxFilas));
        meta.put("limiteAlcanzado", Boolean.valueOf(limite));
        meta.put("rendererContract", "CREA17-RENDERER-2026.09");

        Map<String, Object> response =
                new LinkedHashMap<String, Object>();
        response.put("contexto", contexto);
        response.put("filas", rows);
        response.put("meta", meta);
        return response;
    }

    private String consultaAsignada(
            int idPlantilla,
            int idStoredProcedure) {
        String sql =
                "SELECT TOP(1) SP.RESPNombreTecnico "
                + "FROM dbo.ff_ReporteEstadisticaStoredProcedure SP WITH (NOLOCK) "
                + "INNER JOIN dbo.ff_ReporteEstadisticaIndicador I WITH (NOLOCK) "
                + " ON I.RINDIdStoredProcedure=SP.RESPIdStoredProcedure "
                + " AND I.RINDIdEstatus=1 "
                + "INNER JOIN dbo.ff_ReporteEstadisticaPlantillaSeccionIndicador SI WITH (NOLOCK) "
                + " ON SI.RPSIIdIndicador=I.RINDIdIndicador "
                + " AND SI.RPSIIdEstatus=1 "
                + "INNER JOIN dbo.ff_ReporteEstadisticaPlantillaSeccion S WITH (NOLOCK) "
                + " ON S.RPSIdSeccion=SI.RPSIIdSeccion "
                + " AND S.RPSIdEstatus=1 AND S.RPSHabilitada=1 "
                + "WHERE SP.RESPIdStoredProcedure=? "
                + " AND SP.RESPIdEstatus=1 AND SP.RESPTipoUso='CONSULTA' "
                + " AND S.RPSIdPlantilla=?;";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            connection.setReadOnly(true);
            statement.setInt(1, idStoredProcedure);
            statement.setInt(2, idPlantilla);
            statement.setQueryTimeout(DEFAULT_TIMEOUT_SECONDS);
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
    }

    private void finalizarError(long idEjecucion, Exception cause) {
        String detail = cause == null || cause.getMessage() == null
                ? "Error no especificado."
                : cause.getMessage();
        try (Connection connection = dataSource.getConnection()) {
            connection.setReadOnly(false);
            execute(
                    connection,
                    "dbo.bf_BeFlexCREA17_ConsultaEjecucion_Finalizar",
                    DEFAULT_TIMEOUT_SECONDS,
                    Long.valueOf(idEjecucion),
                    "ERROR",
                    sqlNull(Types.INTEGER),
                    sqlNull(Types.BIGINT),
                    detail);
        } catch (Exception ignored) {
            // La falla de auditoría no debe ocultar el error original.
        }
    }

    private List<List<Map<String, Object>>> callReadOnly(
            String procedure,
            int timeoutSeconds,
            Object... parameters) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setReadOnly(true);
            return execute(
                    connection,
                    procedure,
                    timeoutSeconds,
                    parameters);
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
    }

    private List<List<Map<String, Object>>> execute(
            Connection connection,
            String procedure,
            int timeoutSeconds,
            Object... parameters) throws SQLException {
        String call = buildCall(procedure, parameters.length);
        List<List<Map<String, Object>>> resultSets =
                new ArrayList<List<Map<String, Object>>>();

        try (CallableStatement statement =
                     connection.prepareCall(call)) {
            statement.setQueryTimeout(timeoutSeconds);
            bind(statement, parameters);
            boolean hasResult = statement.execute();

            while (true) {
                if (hasResult) {
                    try (ResultSet resultSet = statement.getResultSet()) {
                        resultSets.add(readRows(resultSet));
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
        }
        return resultSets;
    }

    private String buildCall(String procedure, int parameterCount) {
        StringBuilder call = new StringBuilder("{call ")
                .append(procedure);
        if (parameterCount > 0) {
            call.append('(');
            for (int index = 0; index < parameterCount; index++) {
                if (index > 0) {
                    call.append(',');
                }
                call.append('?');
            }
            call.append(')');
        }
        return call.append('}').toString();
    }

    private void bind(
            CallableStatement statement,
            Object[] parameters) throws SQLException {
        for (int index = 0; index < parameters.length; index++) {
            Object parameter = parameters[index];
            int parameterIndex = index + 1;

            if (parameter instanceof SqlNull) {
                statement.setNull(parameterIndex, ((SqlNull) parameter).jdbcType);
            } else if (parameter == null) {
                statement.setNull(parameterIndex, Types.NVARCHAR);
            } else if (parameter instanceof Integer) {
                statement.setInt(
                        parameterIndex,
                        ((Integer) parameter).intValue());
            } else if (parameter instanceof Boolean) {
                statement.setBoolean(
                        parameterIndex,
                        ((Boolean) parameter).booleanValue());
            } else if (parameter instanceof Long) {
                statement.setLong(
                        parameterIndex,
                        ((Long) parameter).longValue());
            } else {
                statement.setString(
                        parameterIndex,
                        String.valueOf(parameter));
            }
        }
    }

    private Object sqlNull(int jdbcType) {
        return new SqlNull(jdbcType);
    }

    private static final class SqlNull {
        private final int jdbcType;

        private SqlNull(int jdbcType) {
            this.jdbcType = jdbcType;
        }
    }

    private List<Map<String, Object>> readRows(
            ResultSet resultSet) throws SQLException {
        List<Map<String, Object>> rows =
                new ArrayList<Map<String, Object>>();
        ResultSetMetaData metadata = resultSet.getMetaData();

        while (resultSet.next()) {
            Map<String, Object> row =
                    new LinkedHashMap<String, Object>();
            for (int column = 1;
                 column <= metadata.getColumnCount();
                 column++) {
                int jdbcType = metadata.getColumnType(column);
                Object columnValue;
                if (jdbcType == Types.CHAR
                        || jdbcType == Types.VARCHAR
                        || jdbcType == Types.LONGVARCHAR
                        || jdbcType == Types.NCHAR
                        || jdbcType == Types.NVARCHAR
                        || jdbcType == Types.LONGNVARCHAR
                        || jdbcType == Types.CLOB
                        || jdbcType == Types.NCLOB) {
                    columnValue = resultSet.getString(column);
                } else {
                    columnValue = resultSet.getObject(column);
                }
                row.put(
                        metadata.getColumnLabel(column),
                        columnValue);
            }
            rows.add(row);
        }
        return rows;
    }

    private Map<String, Object> mapDesign(
            List<List<Map<String, Object>>> resultSets) {
        String[] keys = {
                "Plantilla",
                "Secciones",
                "Paginas",
                "Visualizaciones",
                "MapeosVisualizacion",
                "FiltrosVisualizacion",
                "ColoresVisualizacion",
                "SeccionCorporativos",
                "VisualizacionCorporativos",
                "TextosLienzo",
                "IndicadoresSeccion",
                "VistasIndicador",
                "MapeosVistaIndicador",
                "ColoresVistaIndicador",
                "FiltrosIndicador",
                "TextosIndicador",
                "VariablesIndicador",
                "VariableTokens",
                "TraduccionesValores",
                "Advertencias"
        };

        Map<String, Object> result = new LinkedHashMap<String, Object>();
        for (int index = 0; index < keys.length; index++) {
            List<Map<String, Object>> rows = resultSet(resultSets, index);
            result.put(keys[index], index == 0
                    ? (rows.isEmpty() ? null : rows.get(0))
                    : rows);
        }
        result.put("VisualCorporativos", result.get("VisualizacionCorporativos"));
        result.put("existe", Boolean.valueOf(!resultSet(resultSets, 0).isEmpty()));
        completarVisualizacionesInteractivo(result);
        return result;
    }


    @SuppressWarnings("unchecked")
    private void completarVisualizacionesInteractivo(Map<String, Object> design) {
        Object visualRaw = design.get("Visualizaciones");
        Object indicatorRaw = design.get("IndicadoresSeccion");
        Object viewRaw = design.get("VistasIndicador");
        if (!(visualRaw instanceof List)
                || !(indicatorRaw instanceof List)
                || !(viewRaw instanceof List)) {
            return;
        }

        List<Map<String, Object>> visuales =
                (List<Map<String, Object>>) visualRaw;
        List<Map<String, Object>> indicadores =
                (List<Map<String, Object>>) indicatorRaw;
        List<Map<String, Object>> vistas =
                (List<Map<String, Object>>) viewRaw;

        Map<Integer, Boolean> conVisual = new LinkedHashMap<Integer, Boolean>();
        for (Map<String, Object> visual : visuales) {
            Integer idIndicador = integerValue(value(visual, "IdIndicador"));
            if (idIndicador != null && idIndicador.intValue() > 0) {
                conVisual.put(idIndicador, Boolean.TRUE);
            }
        }

        for (Map<String, Object> indicador : indicadores) {
            Integer idIndicador = integerValue(value(indicador, "IdIndicador"));
            if (idIndicador == null || idIndicador.intValue() <= 0
                    || conVisual.containsKey(idIndicador)) {
                continue;
            }

            Map<String, Object> vista = vistaPreferida(vistas, idIndicador.intValue());
            if (vista == null) {
                continue;
            }

            Integer idVista = integerValue(value(vista, "IdVista"));
            Integer idTipo = integerValue(value(vista, "IdTipoVisualizacion"));
            if (idVista == null || idVista.intValue() <= 0 || idTipo == null) {
                continue;
            }

            Map<String, Object> visual = new LinkedHashMap<String, Object>();
            visual.put("IdVisualizacion", Integer.valueOf(-1000000 - idVista.intValue()));
            visual.put("IdPagina", null);
            visual.put("IdTipoVisualizacion", idTipo);
            visual.put("TipoVisualizacion", value(vista, "Tipo"));
            visual.put("TipoVisualizacionNombre", value(vista, "Nombre"));
            visual.put("IdStoredProcedure", value(indicador, "IdStoredProcedure"));
            visual.put("IdIndicador", idIndicador);
            visual.put("IdIndicadorVista", idVista);
            visual.put("Capa", Integer.valueOf(1));
            visual.put("OrdenZ", value(indicador, "Orden"));
            visual.put("Nombre", value(vista, "Nombre"));
            Object titulo = value(indicador, "Titulo");
            visual.put("Titulo", titulo == null ? value(indicador, "Nombre") : titulo);
            visual.put("Subtitulo", value(indicador, "Subtitulo"));
            visual.put("Descripcion", value(vista, "Descripcion"));
            visual.put("TextoPie", value(indicador, "PieGrafica"));
            visual.put("Orden", value(indicador, "Orden"));
            visual.put("Columna", Integer.valueOf(1));
            visual.put("Fila", Integer.valueOf(1));
            visual.put("Ancho", Integer.valueOf(48));
            visual.put("Alto", Integer.valueOf(24));
            visual.put("Habilitada", Boolean.TRUE);
            visual.put("MuestraTitulo", Boolean.FALSE);
            visual.put("MuestraLeyenda", Boolean.TRUE);
            visual.put("DisponibilidadModo", "TODOS");
            visual.put("ConfiguracionJson", value(vista, "ConfiguracionJson"));
            visual.put("RequiereRevision", Boolean.FALSE);
            visual.put("DisponibleCorporativo", Boolean.TRUE);
            visual.put("SinteticaBeflex", Boolean.TRUE);
            visuales.add(visual);
            conVisual.put(idIndicador, Boolean.TRUE);
        }
    }

    private Map<String, Object> vistaPreferida(
            List<Map<String, Object>> vistas,
            int idIndicador) {
        Map<String, Object> primeraBeflex = null;
        Map<String, Object> predeterminadaReporte = null;
        Map<String, Object> primeraReporte = null;

        for (Map<String, Object> vista : vistas) {
            Integer current = integerValue(value(vista, "IdIndicador"));
            if (current == null || current.intValue() != idIndicador) {
                continue;
            }
            boolean disponibleBeflex = booleanValue(value(vista, "DisponibleBeflex"), false);
            boolean disponibleReporte = booleanValue(value(vista, "DisponibleReporte"), true);
            boolean predeterminada = booleanValue(value(vista, "EsPredeterminada"), false);

            if (disponibleBeflex && predeterminada) {
                return vista;
            }
            if (disponibleBeflex && primeraBeflex == null) {
                primeraBeflex = vista;
            }
            if (disponibleReporte && predeterminada && predeterminadaReporte == null) {
                predeterminadaReporte = vista;
            }
            if (disponibleReporte && primeraReporte == null) {
                primeraReporte = vista;
            }
        }
        if (primeraBeflex != null) return primeraBeflex;
        if (predeterminadaReporte != null) return predeterminadaReporte;
        return primeraReporte;
    }

    private boolean booleanValue(Object value, boolean fallback) {
        if (value == null) return fallback;
        if (value instanceof Boolean) return ((Boolean) value).booleanValue();
        if (value instanceof Number) return ((Number) value).intValue() != 0;
        String normalized = String.valueOf(value).trim();
        return "1".equals(normalized) || "true".equalsIgnoreCase(normalized)
                || "si".equalsIgnoreCase(normalized) || "sí".equalsIgnoreCase(normalized);
    }

    private String json(Map<String, Object> value) {
        try {
            Map<String, Object> safe = value == null
                    ? new LinkedHashMap<String, Object>()
                    : value;
            return objectMapper.writeValueAsString(safe);
        } catch (Exception ex) {
            throw new IllegalArgumentException(
                    "No fue posible preparar los filtros seleccionados.",
                    ex);
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> mapValue(Object value) {
        return value instanceof Map
                ? (Map<String, Object>) value
                : new LinkedHashMap<String, Object>();
    }

    private List<Map<String, Object>> resultSet(
            List<List<Map<String, Object>>> resultSets,
            int index) {
        if (resultSets == null
                || index < 0
                || index >= resultSets.size()) {
            return new ArrayList<Map<String, Object>>();
        }
        return resultSets.get(index);
    }

    private Map<String, Object> firstRow(
            List<List<Map<String, Object>>> resultSets,
            int index) {
        List<Map<String, Object>> rows = resultSet(resultSets, index);
        return rows.isEmpty() ? null : rows.get(0);
    }

    private Object value(Map<String, Object> row, String key) {
        if (row == null) {
            return null;
        }
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (entry.getKey() != null
                    && entry.getKey().equalsIgnoreCase(key)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private String stringValue(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private Integer integerValue(Object value) {
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            return null;
        }
        if (value instanceof Number) {
            return Integer.valueOf(((Number) value).intValue());
        }
        try {
            return Integer.valueOf(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private Long longValue(Object value) {
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            return null;
        }
        if (value instanceof Number) {
            return Long.valueOf(((Number) value).longValue());
        }
        try {
            return Long.valueOf(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private String databaseMessage(SQLException ex) {
        SQLException cursor = ex;
        String lastMessage = ex.getMessage();
        while (cursor != null) {
            if (cursor.getMessage() != null
                    && !cursor.getMessage().trim().isEmpty()) {
                lastMessage = cursor.getMessage();
            }
            cursor = cursor.getNextException();
        }
        return lastMessage == null
                ? "Error al consultar el runtime CREA17 de beFlex."
                : lastMessage;
    }
}
