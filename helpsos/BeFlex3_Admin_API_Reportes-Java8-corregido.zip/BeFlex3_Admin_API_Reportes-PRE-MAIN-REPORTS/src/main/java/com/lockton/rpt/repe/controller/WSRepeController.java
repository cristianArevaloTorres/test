package com.lockton.rpt.repe.controller;

import com.lockton.rpt.repe.dto.RepeApiResponse;
import com.lockton.rpt.repe.dto.RepeConsultaRequest;
import com.lockton.rpt.repe.dto.RepeConsultaValidacionRequest;
import com.lockton.rpt.repe.dto.RepeEstatusRequest;
import com.lockton.rpt.repe.dto.RepeFiltroOrdenRequest;
import com.lockton.rpt.repe.dto.RepeFiltroRequest;
import com.lockton.rpt.repe.dto.RepeIndicadorRequest;
import com.lockton.rpt.repe.dto.RepeIndicadorDisponibilidadRequest;
import com.lockton.rpt.repe.dto.RepePlantillaRequest;
import com.lockton.rpt.repe.dto.RepePlantillaDuplicarRequest;
import com.lockton.rpt.repe.dto.RepeReplicarRequest;
import com.lockton.rpt.repe.dto.RepeTipoVisualizacionRequest;
import com.lockton.rpt.repe.service.RepeService;
import com.lockton.rpt.util.SafeApiError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/beflex/reporte-estadisticas/repe")
public class WSRepeController {
    private static final Logger LOGGER = LoggerFactory.getLogger(WSRepeController.class);
    private final RepeService service;

    public WSRepeController(RepeService service) {
        this.service = service;
    }

    private <T> ResponseEntity<RepeApiResponse<T>> ok(String code, T data) {
        return ResponseEntity.ok(RepeApiResponse.ok(code, "Operación completada.", data));
    }

    private <T> ResponseEntity<RepeApiResponse<T>> error(String code, Exception ex) {
        LOGGER.error("REPE [{}]", code, ex);
        HttpStatus status = SafeApiError.isInfrastructureFailure(ex)
                ? HttpStatus.SERVICE_UNAVAILABLE
                : HttpStatus.BAD_REQUEST;
        String message = SafeApiError.publicMessage(
                ex,
                "No fue posible completar la operación. Intenta nuevamente.");
        return ResponseEntity.status(status)
                .body(RepeApiResponse.<T>fail(code, message, null));
    }

    @GetMapping("/tipos-visualizacion")
    public ResponseEntity<?> tipos(@RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-TV-LIST", service.tipos(incluirBajas)); }
        catch (Exception ex) { return error("REPE-TV-ERR", ex); }
    }

    @GetMapping("/tipos-visualizacion/{id}")
    public ResponseEntity<?> tipo(@PathVariable int id) {
        try { return ok("REPE-TV-GET", service.tipo(id)); }
        catch (Exception ex) { return error("REPE-TV-ERR", ex); }
    }

    @PostMapping("/tipos-visualizacion")
    public ResponseEntity<?> tipoCrear(@RequestBody RepeTipoVisualizacionRequest request) {
        try { return ok("REPE-TV-SAVE", service.saveTipo(null, request)); }
        catch (Exception ex) { return error("REPE-TV-ERR", ex); }
    }

    @PutMapping("/tipos-visualizacion/{id}")
    public ResponseEntity<?> tipoEditar(@PathVariable int id, @RequestBody RepeTipoVisualizacionRequest request) {
        try { return ok("REPE-TV-SAVE", service.saveTipo(id, request)); }
        catch (Exception ex) { return error("REPE-TV-ERR", ex); }
    }

    @GetMapping("/filtros")
    public ResponseEntity<?> filtros(@RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-FI-LIST", service.filtros(incluirBajas)); }
        catch (Exception ex) { return error("REPE-FI-ERR", ex); }
    }

    @GetMapping("/filtros/campos-disponibles")
    public ResponseEntity<?> filtroCamposDisponibles(
            @RequestParam(required = false) Integer idFiltroActual) {
        try { return ok("REPE-FI-FIELDS", service.filtroCamposDisponibles(idFiltroActual)); }
        catch (Exception ex) { return error("REPE-FI-FIELDS-ERR", ex); }
    }

    @GetMapping("/filtros/{id}")
    public ResponseEntity<?> filtro(@PathVariable int id) {
        try { return ok("REPE-FI-GET", service.filtro(id)); }
        catch (Exception ex) { return error("REPE-FI-ERR", ex); }
    }

    @PostMapping("/filtros")
    public ResponseEntity<?> filtroCrear(@RequestBody RepeFiltroRequest request) {
        try { return ok("REPE-FI-SAVE", service.saveFiltro(null, request)); }
        catch (Exception ex) { return error("REPE-FI-ERR", ex); }
    }

    @PutMapping("/filtros/{id}")
    public ResponseEntity<?> filtroEditar(@PathVariable int id, @RequestBody RepeFiltroRequest request) {
        try { return ok("REPE-FI-SAVE", service.saveFiltro(id, request)); }
        catch (Exception ex) { return error("REPE-FI-ERR", ex); }
    }

    @PutMapping("/filtros/orden")
    public ResponseEntity<?> filtrosOrden(@RequestBody RepeFiltroOrdenRequest request) {
        try { return ok("REPE-FI-ORDER", service.reorderFiltros(request)); }
        catch (Exception ex) { return error("REPE-FI-ORDER-ERR", ex); }
    }

    @GetMapping("/consultas")
    public ResponseEntity<?> consultas(@RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-CO-LIST", service.consultas(incluirBajas)); }
        catch (Exception ex) { return error("REPE-CO-ERR", ex); }
    }

    @PostMapping("/consultas/validar")
    public ResponseEntity<?> validarConsultaPreRegistro(@RequestBody RepeConsultaValidacionRequest request) {
        try {
            return ok("REPE-CO-PREVALIDATE", service.validarConsultaPreRegistro(request));
        } catch (Exception ex) {
            LOGGER.error("REPE [REPE-CO-PREVALIDATE-ERR]", ex);
            HttpStatus status = SafeApiError.isInfrastructureFailure(ex)
                    ? HttpStatus.SERVICE_UNAVAILABLE
                    : HttpStatus.BAD_REQUEST;
            String message = SafeApiError.isInfrastructureFailure(ex)
                    ? SafeApiError.publicMessage(ex, "No fue posible validar el procedimiento. Intenta nuevamente.")
                    : "No fue posible validar el procedimiento. Intenta nuevamente.";
            return ResponseEntity.status(status)
                    .body(RepeApiResponse.fail(
                            "REPE-CO-PREVALIDATE-ERR",
                            message,
                            null));
        }
    }

    @GetMapping("/consultas/{id}")
    public ResponseEntity<?> consulta(@PathVariable int id) {
        try { return ok("REPE-CO-GET", service.consulta(id)); }
        catch (Exception ex) { return error("REPE-CO-ERR", ex); }
    }

    @PostMapping("/consultas")
    public ResponseEntity<?> consultaCrear(@RequestBody RepeConsultaRequest request) {
        try { return ok("REPE-CO-SAVE", service.saveConsulta(null, request)); }
        catch (Exception ex) { return error("REPE-CO-ERR", ex); }
    }

    @PutMapping("/consultas/{id}")
    public ResponseEntity<?> consultaEditar(@PathVariable int id, @RequestBody RepeConsultaRequest request) {
        try { return ok("REPE-CO-SAVE", service.saveConsulta(id, request)); }
        catch (Exception ex) { return error("REPE-CO-ERR", ex); }
    }

    @PostMapping("/consultas/{id}/validar")
    public ResponseEntity<?> validarConsulta(@PathVariable int id) {
        try { return ok("REPE-CO-VALIDATE", service.validarConsulta(id)); }
        catch (Exception ex) { return error("REPE-CO-ERR", ex); }
    }

    @GetMapping("/indicadores")
    public ResponseEntity<?> indicadores(
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) Integer idCorporativo,
            @RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-IN-LIST", service.indicadores(tipo, idCorporativo, incluirBajas)); }
        catch (Exception ex) { return error("REPE-IN-ERR", ex); }
    }

    @GetMapping("/indicadores/{id}")
    public ResponseEntity<?> indicador(@PathVariable int id) {
        try { return ok("REPE-IN-GET", service.indicador(id)); }
        catch (Exception ex) { return error("REPE-IN-ERR", ex); }
    }

    @PostMapping("/indicadores")
    public ResponseEntity<?> indicadorCrear(@RequestBody RepeIndicadorRequest request) {
        try { return ok("REPE-IN-SAVE", service.saveIndicador(null, request)); }
        catch (Exception ex) { return error("REPE-IN-ERR", ex); }
    }

    @PutMapping("/indicadores/{id}")
    public ResponseEntity<?> indicadorEditar(@PathVariable int id, @RequestBody RepeIndicadorRequest request) {
        try { return ok("REPE-IN-SAVE", service.saveIndicador(id, request)); }
        catch (Exception ex) { return error("REPE-IN-ERR", ex); }
    }

    @PutMapping("/indicadores/{id}/disponibilidad")
    public ResponseEntity<?> indicadorDisponibilidad(
            @PathVariable int id,
            @RequestBody RepeIndicadorDisponibilidadRequest request) {
        try { return ok("REPE-IN-AVAILABILITY", service.saveIndicadorDisponibilidad(id, request)); }
        catch (Exception ex) { return error("REPE-IN-AVAILABILITY-ERR", ex); }
    }

    @PostMapping("/indicadores/{id}/replicar")
    public ResponseEntity<?> replicarIndicador(@PathVariable int id, @RequestBody RepeReplicarRequest request) {
        try { return ok("REPE-IN-REPLICATE", service.replicarIndicador(id, request)); }
        catch (Exception ex) { return error("REPE-IN-REPLICATE-ERR", ex); }
    }

    @GetMapping("/plantillas")
    public ResponseEntity<?> plantillas(
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) Integer idCorporativo,
            @RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-PL-LIST", service.plantillas(tipo, idCorporativo, incluirBajas)); }
        catch (Exception ex) { return error("REPE-PL-ERR", ex); }
    }

    @GetMapping("/plantillas/{id}")
    public ResponseEntity<?> plantilla(@PathVariable int id) {
        try { return ok("REPE-PL-GET", service.plantilla(id)); }
        catch (Exception ex) { return error("REPE-PL-ERR", ex); }
    }

    @PostMapping("/plantillas")
    public ResponseEntity<?> plantillaCrear(@RequestBody RepePlantillaRequest request) {
        try { return ok("REPE-PL-SAVE", service.savePlantilla(null, request)); }
        catch (Exception ex) { return error("REPE-PL-ERR", ex); }
    }

    @PutMapping("/plantillas/{id}")
    public ResponseEntity<?> plantillaEditar(@PathVariable int id, @RequestBody RepePlantillaRequest request) {
        try { return ok("REPE-PL-SAVE", service.savePlantilla(id, request)); }
        catch (Exception ex) { return error("REPE-PL-ERR", ex); }
    }

    @PostMapping("/plantillas/{id}/replicar")
    public ResponseEntity<?> replicarPlantilla(@PathVariable int id, @RequestBody RepeReplicarRequest request) {
        try { return ok("REPE-PL-REPLICATE", service.replicarPlantilla(id, request)); }
        catch (Exception ex) { return error("REPE-PL-REPLICATE-ERR", ex); }
    }

    @PostMapping("/plantillas/{id}/duplicar")
    public ResponseEntity<?> duplicarPlantilla(@PathVariable int id, @RequestBody RepePlantillaDuplicarRequest request) {
        try { return ok("REPE-PL-DUPLICATE", service.duplicarPlantilla(id, request)); }
        catch (Exception ex) { return error("REPE-PL-DUPLICATE-ERR", ex); }
    }

    @PutMapping("/plantillas/{id}/estatus")
    public ResponseEntity<?> plantillaEstatus(@PathVariable int id, @RequestBody RepeEstatusRequest request) {
        try { return ok("REPE-PL-STATUS", service.plantillaEstatus(id, request)); }
        catch (Exception ex) { return error("REPE-PL-STATUS-ERR", ex); }
    }

    @GetMapping("/catalogos/variables-globales")
    public ResponseEntity<?> variablesGlobales(@RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-CAT-GLOBAL-VARS", service.variablesGlobales(incluirBajas)); }
        catch (Exception ex) { return error("REPE-CAT-GLOBAL-VARS-ERR", ex); }
    }

    @GetMapping("/catalogos/idiomas")
    public ResponseEntity<?> idiomas(@RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-CAT-LANG", service.idiomas(incluirBajas)); }
        catch (Exception ex) { return error("REPE-CAT-LANG-ERR", ex); }
    }

    @GetMapping("/catalogos/tipos-archivo")
    public ResponseEntity<?> tiposArchivo(@RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-CAT-FILE", service.tiposArchivo(incluirBajas)); }
        catch (Exception ex) { return error("REPE-CAT-FILE-ERR", ex); }
    }

    @GetMapping("/catalogos/tamanos-documento")
    public ResponseEntity<?> tamanosDocumento(@RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-CAT-SIZE", service.tamanosDocumento(incluirBajas)); }
        catch (Exception ex) { return error("REPE-CAT-SIZE-ERR", ex); }
    }

    @GetMapping("/catalogos/orientaciones-archivo")
    public ResponseEntity<?> orientacionesArchivo(@RequestParam(defaultValue = "false") boolean incluirBajas) {
        try { return ok("REPE-CAT-ORIENTATION", service.orientacionesArchivo(incluirBajas)); }
        catch (Exception ex) { return error("REPE-CAT-ORIENTATION-ERR", ex); }
    }

    @PutMapping("/{entidad}/{id}/estatus")
    public ResponseEntity<?> status(
            @PathVariable String entidad,
            @PathVariable int id,
            @RequestBody RepeEstatusRequest request) {
        try { return ok("REPE-STATUS", service.status(normalizarEntidad(entidad), id, request)); }
        catch (Exception ex) { return error("REPE-STATUS-ERR", ex); }
    }

    private String normalizarEntidad(String value) {
        String normalized = value == null ? "" : value.toLowerCase();
        if ("tipos-visualizacion".equals(normalized) || "tipo-visualizacion".equals(normalized)) return "TIPO_VISUALIZACION";
        if ("filtros".equals(normalized) || "filtro".equals(normalized)) return "FILTRO";
        if ("consultas".equals(normalized) || "consulta".equals(normalized)) return "CONSULTA";
        if ("indicadores".equals(normalized) || "indicador".equals(normalized)) return "INDICADOR";
        if ("plantillas".equals(normalized) || "plantilla".equals(normalized)) return "PLANTILLA";
        throw new IllegalArgumentException("Entidad REPE no soportada.");
    }
}
