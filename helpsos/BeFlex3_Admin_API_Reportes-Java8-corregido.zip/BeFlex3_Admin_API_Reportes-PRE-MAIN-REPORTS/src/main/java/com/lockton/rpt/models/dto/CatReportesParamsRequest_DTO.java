package com.lockton.rpt.models.dto;

import java.time.LocalDateTime;

public class CatReportesParamsRequest_DTO {
    public Integer catReportesParamsId;
    public Integer catReportesSPId;
    public Integer catReportesTipoDatoId;
    public String catReportesParamsLongitud;
    public Integer catReportesParamsOrden;
    public String catReportesParamsNombre;
    public String catReportesParamsDesc;
    public Integer ESid;
    public Integer catReportesParamsUsuarioAdd;	
    public LocalDateTime catReportesParamsFechaAdd;
    public Integer catReportesParamsUsuarioMod;
    public LocalDateTime catReportesParamsFechaMod;
    public Integer catReportesParamsUsuarioDel;
    public LocalDateTime catReportesParamsFechaDel;
    
    public Integer getCatReportesParamsId() {
        return catReportesParamsId;
    }
    public void setCatReportesParamsId(Integer catReportesParamsId) {
        this.catReportesParamsId = catReportesParamsId;
    }
    public Integer getCatReportesSPId() {
        return catReportesSPId;
    }
    public void setCatReportesSPId(Integer catReportesSPId) {
        this.catReportesSPId = catReportesSPId;
    }
    public Integer getCatReportesTipoDatoId() {
        return catReportesTipoDatoId;
    }
    public void setCatReportesTipoDatoId(Integer catReportesTipoDatoId) {
        this.catReportesTipoDatoId = catReportesTipoDatoId;
    }
    public String getCatReportesParamsLongitud() {
        return catReportesParamsLongitud;
    }
    public void setCatReportesParamsLongitud(String catReportesParamsLongitud) {
        this.catReportesParamsLongitud = catReportesParamsLongitud;
    }
    public Integer getCatReportesParamsOrden() {
        return catReportesParamsOrden;
    }
    public void setCatReportesParamsOrden(Integer catReportesParamsOrden) {
        this.catReportesParamsOrden = catReportesParamsOrden;
    }
    public String getCatReportesParamsNombre() {
        return catReportesParamsNombre;
    }
    public void setCatReportesParamsNombre(String catReportesParamsNombre) {
        this.catReportesParamsNombre = catReportesParamsNombre;
    }
    public String getCatReportesParamsDesc() {
        return catReportesParamsDesc;
    }
    public void setCatReportesParamsDesc(String catReportesParamsDesc) {
        this.catReportesParamsDesc = catReportesParamsDesc;
    }
    public Integer getESid() {
        return ESid;
    }
    public void setESid(Integer eSid) {
        ESid = eSid;
    }
    public Integer getCatReportesParamsUsuarioAdd() {
        return catReportesParamsUsuarioAdd;
    }
    public void setCatReportesParamsUsuarioAdd(Integer catReportesParamsUsuarioAdd) {
        this.catReportesParamsUsuarioAdd = catReportesParamsUsuarioAdd;
    }
    public LocalDateTime getCatReportesParamsFechaAdd() {
        return catReportesParamsFechaAdd;
    }
    public void setCatReportesParamsFechaAdd(LocalDateTime catReportesParamsFechaAdd) {
        this.catReportesParamsFechaAdd = catReportesParamsFechaAdd;
    }
    public Integer getCatReportesParamsUsuarioMod() {
        return catReportesParamsUsuarioMod;
    }
    public void setCatReportesParamsUsuarioMod(Integer catReportesParamsUsuarioMod) {
        this.catReportesParamsUsuarioMod = catReportesParamsUsuarioMod;
    }
    public LocalDateTime getCatReportesParamsFechaMod() {
        return catReportesParamsFechaMod;
    }
    public void setCatReportesParamsFechaMod(LocalDateTime catReportesParamsFechaMod) {
        this.catReportesParamsFechaMod = catReportesParamsFechaMod;
    }
    public Integer getCatReportesParamsUsuarioDel() {
        return catReportesParamsUsuarioDel;
    }
    public void setCatReportesParamsUsuarioDel(Integer catReportesParamsUsuarioDel) {
        this.catReportesParamsUsuarioDel = catReportesParamsUsuarioDel;
    }
    public LocalDateTime getCatReportesParamsFechaDel() {
        return catReportesParamsFechaDel;
    }
    public void setCatReportesParamsFechaDel(LocalDateTime catReportesParamsFechaDel) {
        this.catReportesParamsFechaDel = catReportesParamsFechaDel;
    }    
  
}
