package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.crea17.ApiResponseDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaAccionRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaGuardarRequestDTO;
import com.lockton.rpt.services.ReporteEstadisticaPlantillaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/beflex/reporte-estadisticas/crea17/plantillas")
public class WSReporteEstadisticaPlantilla {
    private final ReporteEstadisticaPlantillaService service;

    public WSReporteEstadisticaPlantilla(ReporteEstadisticaPlantillaService service) {
        this.service = service;
    }

    @GetMapping("/catalogos")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> catalogos() {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-CAT",
                    "Catálogos del diseñador consultados correctamente.",
                    service.obtenerCatalogos()));
        } catch (Exception ex) {
            return error("RPE-PLT-CAT-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/global")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerGlobal() {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-GLOBAL",
                    "Plantilla global consultada correctamente.",
                    service.obtenerGlobal()));
        } catch (Exception ex) {
            return error("RPE-PLT-GLOBAL-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/global")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardarGlobal(
            @RequestBody PlantillaGuardarRequestDTO request) {
        try {
            validateGuardarRequest(request);
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-GLOBAL-SAVE",
                    "Plantilla global guardada correctamente.",
                    service.guardarGlobal(request.getPlantilla(), request.getIdUsuario().intValue())));
        } catch (Exception ex) {
            return error("RPE-PLT-GLOBAL-SAVE-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/corporativo/{idCorporativo}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerCorporativa(
            @PathVariable int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-CORP",
                    "Plantilla corporativa consultada correctamente.",
                    service.obtenerCorporativa(idCorporativo)));
        } catch (Exception ex) {
            return error("RPE-PLT-CORP-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/corporativo/{idCorporativo}/completa")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerCorporativaCompleta(
            @PathVariable int idCorporativo,
            @RequestParam(defaultValue = "25000") int maxFilasPorFuente) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-CORP-COMPLETE",
                    "Plantilla, snapshot y datos consultados en una sola carga.",
                    service.obtenerCorporativaCompleta(idCorporativo, maxFilasPorFuente)));
        } catch (Exception ex) {
            return error("RPE-PLT-CORP-COMPLETE-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/corporativo/{idCorporativo}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardarCorporativa(
            @PathVariable int idCorporativo,
            @RequestBody PlantillaGuardarRequestDTO request) {
        try {
            validateGuardarRequest(request);
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-CORP-SAVE",
                    "Plantilla corporativa guardada correctamente.",
                    service.guardarCorporativa(
                            idCorporativo,
                            request.getPlantilla(),
                            request.getIdUsuario().intValue())));
        } catch (Exception ex) {
            return error("RPE-PLT-CORP-SAVE-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/corporativo/{idCorporativo}/replicar")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> replicarCorporativa(
            @PathVariable int idCorporativo,
            @RequestBody PlantillaAccionRequestDTO request) {
        try {
            validateAccionRequest(request);
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-CORP-CLONE",
                    "Plantilla global replicada correctamente.",
                    service.replicarCorporativa(idCorporativo, request.getIdUsuario().intValue())));
        } catch (Exception ex) {
            return error("RPE-PLT-CORP-CLONE-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/corporativo/{idCorporativo}/crear-vacia")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> crearCorporativaVacia(
            @PathVariable int idCorporativo,
            @RequestBody PlantillaAccionRequestDTO request) {
        try {
            validateAccionRequest(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponseDTO.ok(
                    "RPE-PLT-CORP-EMPTY",
                    "Plantilla corporativa vacía creada correctamente.",
                    service.crearCorporativaVacia(idCorporativo, request.getIdUsuario().intValue())));
        } catch (Exception ex) {
            return error("RPE-PLT-CORP-EMPTY-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/preview")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> preview(
            @RequestParam int idCorporativo,
            @RequestParam int idStoredProcedure,
            @RequestParam(defaultValue = "100") int maxFilas) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-PREVIEW",
                    "Datos de vista previa consultados correctamente.",
                    service.obtenerPreview(idCorporativo, idStoredProcedure, maxFilas)));
        } catch (Exception ex) {
            return error("RPE-PLT-PREVIEW-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/corporativo/{idCorporativo}/datos")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> datosBeflex(
            @PathVariable int idCorporativo,
            @RequestParam int idStoredProcedure,
            @RequestParam(defaultValue = "10000") int maxFilas) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-PLT-BEFLEX-DATA",
                    "Datos del indicador consultados correctamente.",
                    service.obtenerDatosBeflex(idCorporativo, idStoredProcedure, maxFilas)));
        } catch (Exception ex) {
            return error("RPE-PLT-BEFLEX-DATA-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    private void validateGuardarRequest(PlantillaGuardarRequestDTO request) {
        if (request == null || request.getIdUsuario() == null || request.getPlantilla() == null) {
            throw new IllegalArgumentException("El usuario y la configuración de la plantilla son requeridos.");
        }
    }

    private void validateAccionRequest(PlantillaAccionRequestDTO request) {
        if (request == null || request.getIdUsuario() == null) {
            throw new IllegalArgumentException("El usuario es requerido.");
        }
    }

    private <T> ResponseEntity<ApiResponseDTO<T>> error(
            String code,
            Exception ex,
            HttpStatus status) {
        String message = ex.getMessage() == null
                ? "No fue posible completar la operación."
                : ex.getMessage();
        return ResponseEntity.status(status).body(
                ApiResponseDTO.<T>fail(code, message, message, ex.getClass().getSimpleName()));
    }
}
