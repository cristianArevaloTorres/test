package com.lockton.rpt.repe.dto;

import com.fasterxml.jackson.databind.JsonNode;

public class RepeFiltroOrdenRequest {
    private JsonNode orden;
    private Integer idUsuario;

    public JsonNode getOrden() { return orden; }
    public void setOrden(JsonNode orden) { this.orden = orden; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
