package com.lockton.rpt.repositories;

import java.util.Map;

public interface ReporteEstadisticaPlantillaDAO {
    Map<String, Object> obtenerPlantilla(String tipo, Integer idCorporativo);
    Map<String, Object> obtenerPlantillaCompletaBeflex(int idCorporativo, int maxFilasPorFuente);
    Map<String, Object> obtenerCatalogos();
    Map<String, Object> guardarPlantilla(String tipo, Integer idCorporativo, Map<String, Object> plantilla, int idUsuario);
    Map<String, Object> replicarPlantillaCorporativo(int idCorporativo, int idUsuario);
    Map<String, Object> crearPlantillaCorporativaVacia(int idCorporativo, int idUsuario);
    Map<String, Object> obtenerPreview(int idCorporativo, int idStoredProcedure, int maxFilas);
    Map<String, Object> obtenerDatosBeflex(int idCorporativo, int idStoredProcedure, int maxFilas);
}
