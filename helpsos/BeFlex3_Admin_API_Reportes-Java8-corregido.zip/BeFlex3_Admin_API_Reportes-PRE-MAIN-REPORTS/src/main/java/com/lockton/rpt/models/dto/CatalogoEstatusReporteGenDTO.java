package com.lockton.rpt.models.dto;

import java.util.Date;
import lombok.Data;

@Data
public class CatalogoEstatusReporteGenDTO {
    private Long CatERptId;
    private String CatERptNombre;
    private Integer CatERptUsuarioAdd;
    private Date CatERptFechaAdd;
}
