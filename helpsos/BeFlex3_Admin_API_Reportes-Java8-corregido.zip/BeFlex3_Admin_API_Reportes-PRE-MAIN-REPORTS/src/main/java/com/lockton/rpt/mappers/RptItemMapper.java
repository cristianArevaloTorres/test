package com.lockton.rpt.mappers;

import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.ItemReporteDTO;
import com.lockton.rpt.models.entities.CatalogoReporteGen;

public class RptItemMapper {
    public static ItemReporteDTO MapperDTO(CatalogoReporteGen ent) {
        ItemReporteDTO dto = new ItemReporteDTO();
        dto.setCatRptId(ent.getCatRptId());
        dto.setCatRptNombre(ent.getCatRptNombre());
        return dto;
    }
 
    public static List<ItemReporteDTO> MapperDTO(List<CatalogoReporteGen> ent) {
        return ent
            .stream()
            .map(RptItemMapper::MapperDTO)
            .collect(Collectors.toList());
    }
 
    public static CatalogoReporteGen MapperEntity(ItemReporteDTO dto) {
        CatalogoReporteGen ent = new CatalogoReporteGen();
        ent.setCatRptId(dto.getCatRptId());
        ent.setCatRptNombre(dto.getCatRptNombre());
        return ent;
    }
   
    public static List<CatalogoReporteGen> MapperEntity(List<ItemReporteDTO> dto) {
        return dto
            .stream()
            .map(RptItemMapper::MapperEntity)
            .collect(Collectors.toList());
    }
}