package com.lockton.rpt.models.dto.crea17;

public class ReporteEstadisticaFiltroOrdenItemDTO {
    private Integer idFiltro;
    private Integer orden;

    public Integer getIdFiltro() { return idFiltro; }
    public void setIdFiltro(Integer idFiltro) { this.idFiltro = idFiltro; }

    public Integer getOrden() { return orden; }
    public void setOrden(Integer orden) { this.orden = orden; }
}
