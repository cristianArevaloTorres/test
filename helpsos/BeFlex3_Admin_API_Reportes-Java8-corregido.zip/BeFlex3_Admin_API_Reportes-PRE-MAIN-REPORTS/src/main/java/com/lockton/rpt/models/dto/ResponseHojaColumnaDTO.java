package com.lockton.rpt.models.dto;

import java.util.List;

public class ResponseHojaColumnaDTO {
    public RepConfTablaHojaResponseDTO hoja;    
    public List<RepConfColumnaDTO> columnas;

    public RepConfTablaHojaResponseDTO getHoja() {
        return hoja;
    }
    public void setHoja(RepConfTablaHojaResponseDTO hoja) {
        this.hoja = hoja;
    }
    public List<RepConfColumnaDTO> getColumnas() {
        return columnas;
    }
    public void setColumnas(List<RepConfColumnaDTO> columnas) {
        this.columnas = columnas;
    }
}
