package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.crea17.ApiResponseDTO;
import com.lockton.rpt.util.SafeApiError;
import com.lockton.rpt.services.ReporteEstadisticaBeflexPlantillaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Runtime CREA17 consumido exclusivamente por beFlex.
 *
 * La resolución filtrada de la plantilla se ejecuta en una única sesión SQL
 * para que todas las consultas REPEQ trabajen sobre el mismo universo #REPE_*.
 */
@RestController
@RequestMapping({"/beflex/reporte-estadisticas/crea17/beflex", "/beflex/reporte-estadisticas/repe/beflex"})
public class WSReporteEstadisticaBeflexPlantilla {

    private static final Logger LOGGER = LoggerFactory.getLogger(WSReporteEstadisticaBeflexPlantilla.class);
    private final ReporteEstadisticaBeflexPlantillaService service;

    public WSReporteEstadisticaBeflexPlantilla(
            ReporteEstadisticaBeflexPlantillaService service) {
        this.service = service;
    }

    @GetMapping("/bootstrap")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> bootstrap(
            @RequestParam int idCorporativo,
            @RequestParam(required = false) Integer idIdioma,
            @RequestParam(defaultValue = "true") boolean soloPdf) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-BEFLEX-BOOT",
                    "Configuración del reporte consultada correctamente.",
                    service.obtenerBootstrap(idCorporativo, idIdioma, soloPdf)));
        } catch (Exception ex) {
            return error("RPE-BEFLEX-BOOT-ERR",
                    "No fue posible cargar la configuración del reporte.",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/filtros/{clave}/opciones")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> opcionesFiltro(
            @PathVariable String clave,
            @RequestBody Map<String, Object> payload) {
        try {
            int idCorporativo = intValue(payload, "idCorporativo");
            int idVigencia = intValue(payload, "idVigencia");
            Map<String, Object> filtros = mapValue(payload, "filtros");
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-BEFLEX-FIL-OPT",
                    "Opciones del filtro consultadas correctamente.",
                    service.obtenerOpcionesFiltro(
                            idCorporativo,
                            idVigencia,
                            clave,
                            filtros)));
        } catch (Exception ex) {
            return error("RPE-BEFLEX-FIL-OPT-ERR",
                    "No fue posible consultar las opciones del filtro.",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/consultar")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> consultar(
            @RequestBody Map<String, Object> payload) {
        try {
            String uidSolicitud = stringValue(payload, "uidSolicitud");
            int idCorporativo = intValue(payload, "idCorporativo");
            int idVigencia = intValue(payload, "idVigencia");
            int idPlantilla = intValue(payload, "idPlantilla");
            int idUsuario = intValue(payload, "idUsuario");
            Map<String, Object> filtros = mapValue(payload, "filtros");

            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-BEFLEX-CONSULTA",
                    "Reporte consultado correctamente.",
                    service.consultarPlantilla(
                            uidSolicitud,
                            idCorporativo,
                            idVigencia,
                            idPlantilla,
                            idUsuario,
                            filtros)));
        } catch (Exception ex) {
            return error("RPE-BEFLEX-CONSULTA-ERR",
                    "No fue posible consultar el reporte con los filtros seleccionados.",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/consultas/{uidSolicitud}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerEjecucion(
            @PathVariable String uidSolicitud) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-BEFLEX-CONSULTA-ESTADO",
                    "Estado de la consulta obtenido correctamente.",
                    service.obtenerEjecucion(uidSolicitud)));
        } catch (Exception ex) {
            return error("RPE-BEFLEX-CONSULTA-ESTADO-ERR",
                    "No fue posible consultar el estado de la solicitud.",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/plantillas")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> listarPlantillas(
            @RequestParam int idCorporativo,
            @RequestParam(required = false) Integer idIdioma,
            @RequestParam(defaultValue = "true") boolean soloPdf) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-BEFLEX-PLT-LIST",
                    "Plantillas disponibles consultadas correctamente.",
                    service.listarPlantillas(idCorporativo, idIdioma, soloPdf)));
        } catch (Exception ex) {
            return error("RPE-BEFLEX-PLT-LIST-ERR",
                    "No fue posible consultar las plantillas disponibles.",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/plantillas/{idPlantilla}/configuracion")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerConfiguracion(
            @PathVariable int idPlantilla,
            @RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-BEFLEX-PLT-CONFIG",
                    "Configuración completa de la plantilla consultada correctamente.",
                    service.obtenerConfiguracion(idCorporativo, idPlantilla)));
        } catch (Exception ex) {
            return error("RPE-BEFLEX-PLT-CONFIG-ERR",
                    "No fue posible consultar la configuración de la plantilla.",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Compatibilidad temporal con el consumidor CREA17 anterior.
     * El runtime nuevo de beFlex ya no consulta fuentes por separado.
     */
    @GetMapping("/plantillas/{idPlantilla}/fuentes/{idStoredProcedure}/datos")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerDatosFuente(
            @PathVariable int idPlantilla,
            @PathVariable int idStoredProcedure,
            @RequestParam int idCorporativo,
            @RequestParam(defaultValue = "25000") int maxFilas) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-BEFLEX-PLT-DATA",
                    "Datos de la consulta obtenidos correctamente.",
                    service.obtenerDatosFuente(
                            idCorporativo,
                            idPlantilla,
                            idStoredProcedure,
                            maxFilas)));
        } catch (Exception ex) {
            return error("RPE-BEFLEX-PLT-DATA-ERR",
                    "No fue posible consultar los datos solicitados.",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    private String stringValue(Map<String, Object> payload, String key) {
        Object value = payload == null ? null : payload.get(key);
        String result = value == null ? "" : String.valueOf(value).trim();
        if (result.isEmpty()) {
            throw new IllegalArgumentException("El campo " + key + " es requerido.");
        }
        return result;
    }

    private int intValue(Map<String, Object> payload, String key) {
        Object value = payload == null ? null : payload.get(key);
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            throw new IllegalArgumentException("El campo " + key + " es requerido.");
        }
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("El campo " + key + " no es válido.");
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> mapValue(
            Map<String, Object> payload,
            String key) {
        Object raw = payload == null ? null : payload.get(key);
        if (raw == null) {
            return new LinkedHashMap<String, Object>();
        }
        if (!(raw instanceof Map)) {
            throw new IllegalArgumentException(
                    "La configuración de " + key + " no es válida.");
        }
        return (Map<String, Object>) raw;
    }

    private <T> ResponseEntity<ApiResponseDTO<T>> error(
            String code,
            String safeMessage,
            Exception ex,
            HttpStatus status) {
        LOGGER.error("CREA17 beFlex [{}] - {}", code, safeMessage, ex);

        HttpStatus responseStatus = SafeApiError.isInfrastructureFailure(ex)
                ? HttpStatus.SERVICE_UNAVAILABLE
                : status;
        String publicMessage = SafeApiError.isInfrastructureFailure(ex)
                ? SafeApiError.publicMessage(ex, safeMessage)
                : SafeApiError.sanitizeMessage(safeMessage, "No fue posible completar la operación. Intenta nuevamente.");

        return ResponseEntity.status(responseStatus).body(
                ApiResponseDTO.<T>fail(
                        code,
                        publicMessage,
                        null,
                        null));
    }
}
