package com.lockton.rpt.services.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ReporteDocumentoRenderer {

    private final String pythonCommand;
    private final String scriptPath;
    private final int timeoutSeconds;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public ReporteDocumentoRenderer(
            @Value("${crea017.reporte-documento.python-command:python3}") String pythonCommand,
            @Value("${crea017.reporte-documento.script-path:../tools/generar_reporte_documento.py}") String scriptPath,
            @Value("${crea017.reporte-documento.timeout-seconds:120}") int timeoutSeconds) {
        this.pythonCommand = pythonCommand;
        this.scriptPath = scriptPath;
        this.timeoutSeconds = timeoutSeconds;
    }

    public Map<String, Object> generarDocumento(Map<String, Object> payload)
            throws IOException, InterruptedException {
        Path script = resolveScriptPath();
        if (!Files.isRegularFile(script)) {
            throw new IOException("No se encontró el script de reporte: " + script.toAbsolutePath());
        }

        String inputJson = objectMapper.writeValueAsString(payload);

        List<String> command = new ArrayList<>();
        command.add(pythonCommand);
        command.add(script.toAbsolutePath().toString());

        ProcessBuilder builder = new ProcessBuilder(command);
        builder.redirectErrorStream(true);
        Process process = builder.start();

        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8))) {
            writer.write(inputJson);
        }

        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line);
            }
        }

        boolean finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
        if (!finished) {
            process.destroyForcibly();
            throw new IOException("Timeout generando reporte (" + timeoutSeconds + "s)");
        }

        String raw = output.toString().trim();
        if (raw.isEmpty()) {
            throw new IOException("El script de reporte no devolvió JSON (exit " + process.exitValue() + ")");
        }

        Map<String, Object> parsed = objectMapper.readValue(raw, new TypeReference<Map<String, Object>>() {
        });
        if (process.exitValue() != 0 || Boolean.FALSE.equals(parsed.get("success"))) {
            Object err = parsed.get("error");
            throw new IOException("Error generando reporte: " + (err != null ? err : raw));
        }
        return parsed;
    }

    private Path resolveScriptPath() {
        Path configured = Paths.get(scriptPath);
        if (configured.isAbsolute()) {
            return configured.normalize();
        }
        return Paths.get(System.getProperty("user.dir")).resolve(configured).normalize();
    }
}
