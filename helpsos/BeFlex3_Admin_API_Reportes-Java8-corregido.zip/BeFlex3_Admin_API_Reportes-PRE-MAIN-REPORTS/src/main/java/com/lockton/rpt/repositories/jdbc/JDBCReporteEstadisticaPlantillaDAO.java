package com.lockton.rpt.repositories.jdbc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.rpt.repositories.ReporteEstadisticaPlantillaDAO;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
public class JDBCReporteEstadisticaPlantillaDAO implements ReporteEstadisticaPlantillaDAO {
    private final DataSource dataSource;
    private final ObjectMapper objectMapper;

    public JDBCReporteEstadisticaPlantillaDAO(DataSource dataSource, ObjectMapper objectMapper) {
        this.dataSource = dataSource;
        this.objectMapper = objectMapper;
    }

    @Override
    public Map<String, Object> obtenerPlantilla(String tipo, Integer idCorporativo) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CReporteEstadisticaPlantilla",
                new Object[] { tipo, idCorporativo });
        return plantillaResponse(sets, consultarTextos(tipo, idCorporativo));
    }

    @Override
    public Map<String, Object> obtenerPlantillaCompletaBeflex(
            int idCorporativo,
            int maxFilasPorFuente) {
        try (Connection connection = dataSource.getConnection()) {
            connection.setReadOnly(true);

            List<List<Map<String, Object>>> sets = call(
                    connection,
                    "dbo.ff_CReporteEstadisticaPlantilla",
                    new Object[] { "CORPORATIVO", Integer.valueOf(idCorporativo) });

            Map<String, Object> out = plantillaResponse(
                    sets,
                    consultarTextos(connection, "CORPORATIVO", Integer.valueOf(idCorporativo)));

            if (!Boolean.TRUE.equals(out.get("existe"))) {
                out.put("datasets", new LinkedHashMap<String, Object>());
                out.put("contexto", null);
                out.put("fuentesCarga", new ArrayList<Map<String, Object>>());
                out.put("validacion", validationResult(
                        false,
                        "NO_EXISTE_PLANTILLA",
                        "El corporativo no tiene una plantilla activa.",
                        0,
                        0,
                        new ArrayList<String>()));
                out.put("metaCarga", singleLoadMeta(maxFilasPorFuente, 0));
                return out;
            }

            List<Map<String, Object>> visualizaciones =
                    castRows(out.get("visualizaciones"));
            Set<Integer> sourceIds = new LinkedHashSet<Integer>();

            for (Map<String, Object> visual : visualizaciones) {
                if (!booleanValue(value(visual, "Habilitada"), true)
                        || booleanValue(value(visual, "RequiereRevision"), false)) {
                    continue;
                }

                int idStoredProcedure = intValue(
                        value(visual, "IdStoredProcedure", "RESPIdStoredProcedure"),
                        0);
                if (idStoredProcedure > 0) {
                    sourceIds.add(Integer.valueOf(idStoredProcedure));
                }
            }

            Map<String, Object> datasets = new LinkedHashMap<String, Object>();
            List<Map<String, Object>> fuentesCarga =
                    new ArrayList<Map<String, Object>>();
            List<String> errores = new ArrayList<String>();

            Map<String, Object> contextoGeneral = null;
            Integer idVigenciaEsperada = null;
            Long idEjecucionEsperada = null;
            int fuentesDisponibles = 0;

            for (Integer idStoredProcedure : sourceIds) {
                List<List<Map<String, Object>>> dataSets = call(
                        connection,
                        "dbo.ff_CReporteEstadisticaPlantillaDatosBeflex",
                        new Object[] {
                                Integer.valueOf(idCorporativo),
                                idStoredProcedure,
                                Integer.valueOf(maxFilasPorFuente)
                        });

                Map<String, Object> dataset =
                        dataResponse(dataSets, maxFilasPorFuente, "BEFLEX_CARGA_UNICA");
                Map<String, Object> contexto =
                        castMap(dataset.get("contexto"));
                List<Map<String, Object>> filas =
                        castRows(dataset.get("filas"));

                boolean disponible = contexto != null
                        && booleanValue(value(contexto, "Disponible"), true);
                Integer idVigencia = nullableInteger(
                        value(contexto, "IdVigencia", "RSEIdVigencia"));
                Long idEjecucion = nullableLong(
                        value(contexto, "IdEjecucion", "IdEjecucionSnapshot", "RSEIdEjecucionSnapshot"));

                if (disponible) {
                    fuentesDisponibles += 1;

                    if (contextoGeneral == null) {
                        contextoGeneral = contexto;
                    }

                    if (idVigenciaEsperada == null) {
                        idVigenciaEsperada = idVigencia;
                    } else if (idVigencia != null
                            && !idVigenciaEsperada.equals(idVigencia)) {
                        errores.add("La fuente " + idStoredProcedure
                                + " pertenece a una vigencia diferente.");
                    }

                    if (idEjecucionEsperada == null) {
                        idEjecucionEsperada = idEjecucion;
                    } else if (idEjecucion != null
                            && !idEjecucionEsperada.equals(idEjecucion)) {
                        errores.add("La fuente " + idStoredProcedure
                                + " pertenece a una ejecución snapshot diferente.");
                    }
                } else {
                    errores.add("La fuente " + idStoredProcedure
                            + " no tiene un snapshot publicado disponible.");
                }

                Map<String, Object> meta =
                        castMap(dataset.get("meta"));
                if (meta != null) {
                    meta.put("idStoredProcedure", idStoredProcedure);
                    meta.put("cargaUnica", Boolean.TRUE);
                }

                datasets.put(String.valueOf(idStoredProcedure), dataset);

                Map<String, Object> sourceSummary =
                        new LinkedHashMap<String, Object>();
                sourceSummary.put("idStoredProcedure", idStoredProcedure);
                sourceSummary.put("disponible", Boolean.valueOf(disponible));
                sourceSummary.put("filas", Integer.valueOf(filas.size()));
                sourceSummary.put("idVigencia", idVigencia);
                sourceSummary.put("idEjecucionSnapshot", idEjecucion);
                sourceSummary.put(
                        "limiteAlcanzado",
                        meta == null ? Boolean.FALSE : meta.get("limiteAlcanzado"));
                fuentesCarga.add(sourceSummary);
            }

            boolean valid = errores.isEmpty()
                    && !sourceIds.isEmpty()
                    && fuentesDisponibles == sourceIds.size();

            out.put("datasets", datasets);
            out.put("contexto", contextoGeneral);
            out.put("fuentesCarga", fuentesCarga);
            out.put("validacion", validationResult(
                    valid,
                    valid ? "OK" : "SNAPSHOT_INCOMPLETO",
                    valid
                            ? "La plantilla y todas sus fuentes están disponibles."
                            : "La plantilla no tiene un snapshot completo y consistente.",
                    sourceIds.size(),
                    fuentesDisponibles,
                    errores));
            out.put("metaCarga", singleLoadMeta(
                    maxFilasPorFuente,
                    sourceIds.size()));
            return out;
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
    }

    @Override
    public Map<String, Object> obtenerCatalogos() {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CReporteEstadisticaPlantillaCatalogos",
                new Object[] {});
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("tiposVisualizacion", resultSet(sets, 0));
        out.put("rolesVisualizacion", resultSet(sets, 1));
        out.put("storedProcedures", resultSet(sets, 2));
        out.put("salidas", resultSet(sets, 3));
        out.put("filtros", resultSet(sets, 4));
        out.put("corporativos", resultSet(sets, 5));
        return out;
    }

    @Override
    public Map<String, Object> guardarPlantilla(
            String tipo,
            Integer idCorporativo,
            Map<String, Object> plantilla,
            int idUsuario) {
        String json;
        try {
            json = objectMapper.writeValueAsString(plantilla);
        } catch (JsonProcessingException ex) {
            throw new IllegalArgumentException(
                    "No fue posible serializar la configuración de la plantilla.",
                    ex);
        }

        Map<String, Object> result = operation(
                "dbo.ff_GuardarReporteEstadisticaPlantilla",
                new Object[] { tipo, idCorporativo, json, Integer.valueOf(idUsuario) });
        operation(
                "dbo.ff_GuardarReporteEstadisticaPlantillaTextos",
                new Object[] { tipo, idCorporativo, json, Integer.valueOf(idUsuario) });
        return result;
    }

    @Override
    public Map<String, Object> replicarPlantillaCorporativo(
            int idCorporativo,
            int idUsuario) {
        Map<String, Object> result = operation(
                "dbo.ff_RReporteEstadisticaPlantillaCorporativo",
                new Object[] {
                        Integer.valueOf(idCorporativo),
                        Integer.valueOf(idUsuario),
                        Boolean.FALSE
                });
        operation(
                "dbo.ff_RReporteEstadisticaPlantillaTextosCorporativo",
                new Object[] {
                        Integer.valueOf(idCorporativo),
                        Integer.valueOf(idUsuario)
                });
        return result;
    }

    @Override
    public Map<String, Object> crearPlantillaCorporativaVacia(
            int idCorporativo,
            int idUsuario) {
        return operation(
                "dbo.ff_IReporteEstadisticaPlantillaCorporativoVacia",
                new Object[] {
                        Integer.valueOf(idCorporativo),
                        Integer.valueOf(idUsuario)
                });
    }

    @Override
    public Map<String, Object> obtenerPreview(
            int idCorporativo,
            int idStoredProcedure,
            int maxFilas) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CReporteEstadisticaPlantillaPreview",
                new Object[] {
                        Integer.valueOf(idCorporativo),
                        Integer.valueOf(idStoredProcedure),
                        Integer.valueOf(maxFilas)
                });

        // La consulta debe completar su cálculo sobre el universo histórico.
        // El límite de preview se aplica después, igual que en Indicadores, para
        // no alterar agregaciones internas mediante SET ROWCOUNT/TOP.
        if (maxFilas > 0 && sets.size() > 1 && sets.get(1) != null
                && sets.get(1).size() > maxFilas) {
            sets.set(1, new ArrayList<Map<String, Object>>(
                    sets.get(1).subList(0, maxFilas)));
        }

        return dataResponse(sets, maxFilas, "PREVIEW");
    }

    @Override
    public Map<String, Object> obtenerDatosBeflex(
            int idCorporativo,
            int idStoredProcedure,
            int maxFilas) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CReporteEstadisticaPlantillaDatosBeflex",
                new Object[] {
                        Integer.valueOf(idCorporativo),
                        Integer.valueOf(idStoredProcedure),
                        Integer.valueOf(maxFilas)
                });
        return dataResponse(sets, maxFilas, "BEFLEX");
    }

    private Map<String, Object> plantillaResponse(
            List<List<Map<String, Object>>> sets,
            List<Map<String, Object>> textos) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        Map<String, Object> plantilla = firstRow(sets, 0);
        out.put("existe", Boolean.valueOf(plantilla != null));
        out.put("plantilla", plantilla);
        out.put("secciones", resultSet(sets, 1));
        out.put("paginas", resultSet(sets, 2));
        out.put("bloques", resultSet(sets, 3));
        out.put("visualizaciones", resultSet(sets, 4));
        out.put("mapeos", resultSet(sets, 5));
        out.put("filtros", resultSet(sets, 6));
        out.put("colores", resultSet(sets, 7));
        out.put("seccionCorporativos", resultSet(sets, 8));
        out.put("visualizacionCorporativos", resultSet(sets, 9));
        out.put(
                "textos",
                textos == null
                        ? new ArrayList<Map<String, Object>>()
                        : textos);
        return out;
    }

    private Map<String, Object> dataResponse(
            List<List<Map<String, Object>>> sets,
            int maxFilas,
            String mode) {
        List<Map<String, Object>> rows = resultSet(sets, 1);
        Map<String, Object> meta = new LinkedHashMap<String, Object>();
        meta.put("modo", mode);
        meta.put("filasDevueltas", Integer.valueOf(rows.size()));
        meta.put("maxFilasSolicitadas", Integer.valueOf(maxFilas));
        meta.put(
                "limiteAlcanzado",
                Boolean.valueOf(maxFilas > 0 && rows.size() >= maxFilas));
        meta.put("gridColumns", Integer.valueOf(48));
        meta.put("rendererContract", "CREA17-RENDERER-2026.07");

        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("contexto", firstRow(sets, 0));
        out.put("filas", rows);
        out.put("meta", meta);
        return out;
    }

    private Map<String, Object> validationResult(
            boolean valid,
            String code,
            String message,
            int required,
            int available,
            List<String> errors) {
        Map<String, Object> validation = new LinkedHashMap<String, Object>();
        validation.put("valida", Boolean.valueOf(valid));
        validation.put("codigo", code);
        validation.put("mensaje", message);
        validation.put("fuentesRequeridas", Integer.valueOf(required));
        validation.put("fuentesDisponibles", Integer.valueOf(available));
        validation.put("errores", errors);
        return validation;
    }

    private Map<String, Object> singleLoadMeta(
            int maxFilasPorFuente,
            int totalFuentes) {
        Map<String, Object> meta = new LinkedHashMap<String, Object>();
        meta.put("cargaUnica", Boolean.TRUE);
        meta.put("maxFilasPorFuente", Integer.valueOf(maxFilasPorFuente));
        meta.put("totalFuentes", Integer.valueOf(totalFuentes));
        meta.put("gridColumns", Integer.valueOf(48));
        meta.put("rendererContract", "CREA17-RENDERER-2026.07");
        return meta;
    }

    private List<Map<String, Object>> consultarTextos(
            String tipo,
            Integer idCorporativo) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CReporteEstadisticaPlantillaTextos",
                new Object[] { tipo, idCorporativo });
        return resultSet(sets, 0);
    }

    private List<Map<String, Object>> consultarTextos(
            Connection connection,
            String tipo,
            Integer idCorporativo) {
        List<List<Map<String, Object>>> sets = call(
                connection,
                "dbo.ff_CReporteEstadisticaPlantillaTextos",
                new Object[] { tipo, idCorporativo });
        return resultSet(sets, 0);
    }

    private Map<String, Object> operation(
            String procedure,
            Object[] parameters) {
        List<List<Map<String, Object>>> sets = call(procedure, parameters);
        for (int i = sets.size() - 1; i >= 0; i--) {
            if (!sets.get(i).isEmpty()) {
                return sets.get(i).get(0);
            }
        }
        return new LinkedHashMap<String, Object>();
    }

    private List<List<Map<String, Object>>> call(
            String procedure,
            Object[] parameters) {
        try (Connection connection = dataSource.getConnection()) {
            return call(connection, procedure, parameters);
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
    }

    private List<List<Map<String, Object>>> call(
            Connection connection,
            String procedure,
            Object[] parameters) {
        StringBuilder sql = new StringBuilder("{call ").append(procedure);
        if (parameters.length > 0) {
            sql.append('(');
            for (int i = 0; i < parameters.length; i++) {
                if (i > 0) {
                    sql.append(',');
                }
                sql.append('?');
            }
            sql.append(')');
        }
        sql.append('}');

        List<List<Map<String, Object>>> resultSets =
                new ArrayList<List<Map<String, Object>>>();

        try (CallableStatement statement =
                     connection.prepareCall(sql.toString())) {
            for (int i = 0; i < parameters.length; i++) {
                bind(statement, i + 1, parameters[i]);
            }

            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet rs = statement.getResultSet()) {
                        resultSets.add(readRows(rs));
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
            return resultSets;
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
    }

    private void bind(
            CallableStatement statement,
            int index,
            Object value) throws SQLException {
        if (value == null) {
            statement.setNull(index, Types.NULL);
        } else if (value instanceof Integer) {
            statement.setInt(index, ((Integer) value).intValue());
        } else if (value instanceof Long) {
            statement.setLong(index, ((Long) value).longValue());
        } else if (value instanceof Boolean) {
            statement.setBoolean(index, ((Boolean) value).booleanValue());
        } else {
            statement.setString(index, String.valueOf(value));
        }
    }

    private List<Map<String, Object>> readRows(ResultSet rs)
            throws SQLException {
        List<Map<String, Object>> rows =
                new ArrayList<Map<String, Object>>();
        ResultSetMetaData md = rs.getMetaData();
        int count = md.getColumnCount();

        while (rs.next()) {
            Map<String, Object> row =
                    new LinkedHashMap<String, Object>();
            for (int i = 1; i <= count; i++) {
                row.put(md.getColumnLabel(i), rs.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }

    private List<Map<String, Object>> resultSet(
            List<List<Map<String, Object>>> sets,
            int index) {
        if (sets == null || index < 0 || index >= sets.size()) {
            return new ArrayList<Map<String, Object>>();
        }
        return sets.get(index);
    }

    private Map<String, Object> firstRow(
            List<List<Map<String, Object>>> sets,
            int index) {
        List<Map<String, Object>> rows = resultSet(sets, index);
        return rows.isEmpty() ? null : rows.get(0);
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> castRows(Object value) {
        if (value instanceof List<?>) {
            return (List<Map<String, Object>>) value;
        }
        return new ArrayList<Map<String, Object>>();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> castMap(Object value) {
        if (value instanceof Map<?, ?>) {
            return (Map<String, Object>) value;
        }
        return null;
    }

    private Object value(
            Map<String, Object> row,
            String... keys) {
        if (row == null || keys == null) {
            return null;
        }

        for (String key : keys) {
            if (row.containsKey(key)) {
                return row.get(key);
            }

            for (Map.Entry<String, Object> entry : row.entrySet()) {
                if (entry.getKey() != null
                        && entry.getKey().equalsIgnoreCase(key)) {
                    return entry.getValue();
                }
            }
        }
        return null;
    }

    private boolean booleanValue(
            Object value,
            boolean fallback) {
        if (value == null) {
            return fallback;
        }
        if (value instanceof Boolean) {
            return ((Boolean) value).booleanValue();
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }

        String normalized = String.valueOf(value).trim();
        return "1".equals(normalized)
                || "true".equalsIgnoreCase(normalized)
                || "si".equalsIgnoreCase(normalized)
                || "sí".equalsIgnoreCase(normalized);
    }

    private int intValue(
            Object value,
            int fallback) {
        if (value == null) {
            return fallback;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }

        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    private Integer nullableInteger(Object value) {
        if (value == null) {
            return null;
        }

        int parsed = intValue(value, Integer.MIN_VALUE);
        return parsed == Integer.MIN_VALUE
                ? null
                : Integer.valueOf(parsed);
    }

    private Long nullableLong(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return Long.valueOf(((Number) value).longValue());
        }

        try {
            return Long.valueOf(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private String databaseMessage(SQLException ex) {
        SQLException cursor = ex;
        String last = ex.getMessage();

        while (cursor != null) {
            if (cursor.getMessage() != null
                    && !cursor.getMessage().trim().isEmpty()) {
                last = cursor.getMessage();
            }
            cursor = cursor.getNextException();
        }

        return last == null
                ? "Error al ejecutar la operación de plantillas."
                : last;
    }
}
