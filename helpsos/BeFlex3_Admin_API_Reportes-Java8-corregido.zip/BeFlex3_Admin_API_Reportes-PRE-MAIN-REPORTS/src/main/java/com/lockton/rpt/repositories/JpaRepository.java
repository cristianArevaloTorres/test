package com.lockton.rpt.repositories;

public class JpaRepository<T1, T2> {

}
