package com.lockton.rpt.enumeradores;

public enum IdReporte {
    DOCUMENTOS_PERSONALIZADOS(1),
    POBLACION(2),
    SABANA_BENEFICIOS(3),
    BITACORA_NAVEGACION(4),
    COMPARATIVO_COSTOS_CREDITOS(5),
    ACCESOS_SOLICITUDES(6),
    ACCESOS_BEMOBILE(7),
    CAMBIOS_CALIFICADOS(8),
    ESTATUS_ADMIN(9),
    ACTIVIDAD_BITACORA(10);

    private int numVal;

    IdReporte(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }

    public String getStrVal(int val) {
        return IdReporte.values()[val].toString();
    }
}
