package com.lockton.rpt.mappers;

import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.ControlReporteGenDTO;
import com.lockton.rpt.models.entities.ControlReporteGen;

public class CtlRptGenMapper {
public static ControlReporteGenDTO MapperDTO(ControlReporteGen ent) {
        ControlReporteGenDTO dto = new ControlReporteGenDTO();
        dto.setCRptId(ent.getCRptId());
        dto.setCRptIdUsuarioSolicitud(ent.getCRptIdUsuarioSolicitud());
        dto.setCRptIdReporte(ent.getCRptIdReporte());
        dto.setCRptFechaSolicitud(ent.getCRptFechaSolicitud());
        dto.setCRptFechaGeneracion(ent.getCRptFechaGeneracion());
        dto.setCRptRuta(ent.getCRptRuta());
        dto.setCRptIdEmpresa(ent.getCRptIdEmpresa());
        dto.setCRptIdEstatus(ent.getCRptIdEstatus());
        dto.setCRptObservaciones(ent.getCRptObservaciones());
        dto.setCRptUsuarioAdd(ent.getCRptUsuarioAdd());
        dto.setCRptFechaAdd(ent.getCRptFechaAdd());
        return dto;
    }

    public static List<ControlReporteGenDTO> MapperDTO(List<ControlReporteGen> ent) {
        return ent
            .stream()
            .map(CtlRptGenMapper::MapperDTO)
            .collect(Collectors.toList());
    }

    public static ControlReporteGen MapperEntity(ControlReporteGenDTO dto) {
        ControlReporteGen ent = new ControlReporteGen();
        ent.setCRptId(dto.getCRptId());
        ent.setCRptIdUsuarioSolicitud(dto.getCRptIdUsuarioSolicitud());
        ent.setCRptIdReporte(dto.getCRptIdReporte());
        ent.setCRptFechaSolicitud(dto.getCRptFechaSolicitud());
        ent.setCRptFechaGeneracion(dto.getCRptFechaGeneracion());
        ent.setCRptRuta(dto.getCRptRuta());
        ent.setCRptIdEmpresa(dto.getCRptIdEmpresa());
        ent.setCRptIdEstatus(dto.getCRptIdEstatus());
        ent.setCRptObservaciones(dto.getCRptObservaciones());
        ent.setCRptUsuarioAdd(dto.getCRptUsuarioAdd());
        ent.setCRptFechaAdd(dto.getCRptFechaAdd());
        return ent;
    }

    public static List<ControlReporteGen> MapperEntity(List<ControlReporteGenDTO> dto) {
        return dto
            .stream()
            .map(CtlRptGenMapper::MapperEntity)
            .collect(Collectors.toList());
    }
}
