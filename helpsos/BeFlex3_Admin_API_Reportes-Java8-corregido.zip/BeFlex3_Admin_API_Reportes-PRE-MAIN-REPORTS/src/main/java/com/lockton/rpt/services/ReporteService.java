package com.lockton.rpt.services;

import com.lockton.rpt.enumeradores.EstatusReporte;
import com.lockton.rpt.models.dto.CatalogoReporteGenDTO;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.models.entities.ControlReporteGen;

public interface ReporteService {

    public ResponseGralDTO EjecutarReporte(int reporteId, String requestMapEncode, String token, int controlReporteId);
    public CatalogoReporteGenDTO ValidacionConfiguracionReporte(Long reporteId);
    public String ConsultaStatusReporte(int reporteGenId);
    public Long RegistrarReporte(int idUsuario, int idReporte, int idEmpresa, String paramsSP, EstatusReporte rpt);
    public boolean ExisteReporteProgramado(ControlReporteGen ent);
    public int crearBitacora(int idPagina, int idEmpleado, String ipUser, String urlUser, int admin, int idEmpresa, String nombrePagina);
}
