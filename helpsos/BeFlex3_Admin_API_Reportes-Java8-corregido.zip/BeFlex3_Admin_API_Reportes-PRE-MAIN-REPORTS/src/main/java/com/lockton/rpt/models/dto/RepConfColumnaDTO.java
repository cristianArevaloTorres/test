package com.lockton.rpt.models.dto;

public class RepConfColumnaDTO {
    public Integer idEmpresa;	
    public Integer catReportesId;	
    public String grupo;	
    public Integer orden;	
    public String campoOrigen; 
    public String encabezado;
    public Boolean visible;
    public Integer repConfColumnaUsuarioAdd;
    public Integer repConfColumnaUsuarioMod;
    public Integer repConfColumnaUsuarioDel;
    
    public Integer getIdEmpresa() {
        return idEmpresa;
    }
    public void setIdEmpresa(Integer idEmpresa) {
        this.idEmpresa = idEmpresa;
    }
    public Integer getCatReportesId() {
        return catReportesId;
    }
    public void setCatReportesId(Integer catReportesId) {
        this.catReportesId = catReportesId;
    }
    public String getGrupo() {
        return grupo;
    }
    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }
    public Integer getOrden() {
        return orden;
    }
    public void setOrden(Integer orden) {
        this.orden = orden;
    }
    public String getCampoOrigen() {
        return campoOrigen;
    }
    public void setCampoOrigen(String campoOrigen) {
        this.campoOrigen = campoOrigen;
    }
    public String getEncabezado() {
        return encabezado;
    }
    public void setEncabezado(String encabezado) {
        this.encabezado = encabezado;
    }
    public Boolean getVisible() {
        return visible;
    }
    public void setVisible(Boolean visible) {
        this.visible = visible;
    }
    public Integer getRepConfColumnaUsuarioAdd() {
        return repConfColumnaUsuarioAdd;
    }
    public void setRepConfColumnaUsuarioAdd(Integer repConfColumnaUsuarioAdd) {
        this.repConfColumnaUsuarioAdd = repConfColumnaUsuarioAdd;
    }
    public Integer getRepConfColumnaUsuarioMod() {
        return repConfColumnaUsuarioMod;
    }
    public void setRepConfColumnaUsuarioMod(Integer repConfColumnaUsuarioMod) {
        this.repConfColumnaUsuarioMod = repConfColumnaUsuarioMod;
    }
    public Integer getRepConfColumnaUsuarioDel() {
        return repConfColumnaUsuarioDel;
    }
    public void setRepConfColumnaUsuarioDel(Integer repConfColumnaUsuarioDel) {
        this.repConfColumnaUsuarioDel = repConfColumnaUsuarioDel;
    }
}
