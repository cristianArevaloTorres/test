package com.lockton.rpt.repositories.jdbc;

import com.lockton.rpt.repositories.BfCatReportesCatalogSupport;
import com.lockton.rpt.repositories.ConfigIndicadorJsonSupport;
import com.lockton.rpt.repositories.ConfigIndicadoresDAO;
import com.lockton.rpt.repositories.CatCorporativosDAO;
import com.lockton.rpt.repositories.SnapshotReporteDAO;
import com.lockton.rpt.repositories.ReporteEstadisticasDAO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCReporteEstadisticas implements ReporteEstadisticasDAO {

    private final JdbcTemplate jdbcTemplate;

    public JDBCReporteEstadisticas(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Map<String, Object>> listarSecciones() {
        return callSpNoParams("sp_ReporteEstad_ListarSecciones");
    }

    @Override
    public Map<String, Object> getParametros(int idCorporativo) {
        List<Map<String, Object>> rows = callSpInt("sp_ReporteEstad_GetParametros", idCorporativo);
        return rows.isEmpty() ? new LinkedHashMap<>() : rows.get(0);
    }

    @Override
    public List<Map<String, Object>> s1RazonSocial(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S1_RazonSocial", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s1Genero(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S1_Genero", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s1Generacion(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S1_Generacion", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s1Perfil(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S1_Perfil", idCorporativo);
    }

    @Override
    public Map<String, Object> s2ParticipacionGeneral(int idCorporativo) {
        List<Map<String, Object>> rows = callSpInt("sp_ReporteEstad_S2_ParticipacionGeneral", idCorporativo);
        return rows.isEmpty() ? new LinkedHashMap<>() : rows.get(0);
    }

    @Override
    public List<Map<String, Object>> s2ParticipacionEmpresa(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S2_ParticipacionEmpresa", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s2SolicitudesDia(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S2_SolicitudesDia", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s2ParticipacionPerfil(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S2_ParticipacionPerfil", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3OpcionalesResumen(int idCorporativo) {
        return jdbcTemplate.execute((Connection con) -> {
            CallableStatement cs = con.prepareCall("{call sp_ReporteEstad_S3_OpcionalesResumen(?)}");
            cs.setInt(1, idCorporativo);
            List<Map<String, Object>> all = new ArrayList<>();
            boolean more = cs.execute();
            while (more) {
                ResultSet rs = cs.getResultSet();
                if (rs != null) {
                    while (rs.next()) {
                        all.add(mapRow(rs));
                    }
                }
                more = cs.getMoreResults();
            }
            return all;
        });
    }

    @Override
    public List<Map<String, Object>> s3OpcionalesTabla(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S3_OpcionalesTabla", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3OpcionalesGeneracion(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S3_OpcionalesGeneracion", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3ComposicionFamiliar(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S3_ComposicionFamiliar", idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3Movilidad(int idCorporativo) {
        return callSpInt("sp_ReporteEstad_S3_Movilidad", idCorporativo);
    }

    private List<Map<String, Object>> callSpNoParams(String procedureName) {
        return jdbcTemplate.query(
                connection -> connection.prepareCall("{call " + procedureName + "}"),
                (rs, rowNum) -> mapRow(rs));
    }

    private List<Map<String, Object>> callSpInt(String procedureName, int idCorporativo) {
        return jdbcTemplate.query(
                connection -> {
                    CallableStatement cs = connection.prepareCall("{call " + procedureName + "(?)}");
                    cs.setInt(1, idCorporativo);
                    return cs;
                },
                (rs, rowNum) -> mapRow(rs));
    }

    private Map<String, Object> mapRow(ResultSet rs) throws java.sql.SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        ResultSetMetaData meta = rs.getMetaData();
        for (int i = 1; i <= meta.getColumnCount(); i++) {
            row.put(meta.getColumnLabel(i), rs.getObject(i));
        }
        return row;
    }
}
