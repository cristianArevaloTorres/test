package com.lockton.rpt.models.dto;

import com.lockton.rpt.enumeradores.EstatusReporte;
import lombok.Data;

@Data
public class ResponseAsyncRptDTO {
    EstatusReporte estatus;
    String mensaje;
    String ruta = "";
}
