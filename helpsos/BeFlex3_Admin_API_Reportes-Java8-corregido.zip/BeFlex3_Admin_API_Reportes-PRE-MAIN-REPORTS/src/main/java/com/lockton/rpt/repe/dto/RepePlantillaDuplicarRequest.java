package com.lockton.rpt.repe.dto;

public class RepePlantillaDuplicarRequest {
    private String nombre;
    private Integer idUsuario;

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
