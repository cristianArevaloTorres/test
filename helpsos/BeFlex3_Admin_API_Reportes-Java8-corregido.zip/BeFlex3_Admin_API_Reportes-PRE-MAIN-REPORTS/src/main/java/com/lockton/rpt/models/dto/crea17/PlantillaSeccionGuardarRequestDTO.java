package com.lockton.rpt.models.dto.crea17;

import java.util.Map;

public class PlantillaSeccionGuardarRequestDTO {
    private Map<String, Object> seccion;
    private Integer idUsuario;

    public Map<String, Object> getSeccion() { return seccion; }
    public void setSeccion(Map<String, Object> seccion) { this.seccion = seccion; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
