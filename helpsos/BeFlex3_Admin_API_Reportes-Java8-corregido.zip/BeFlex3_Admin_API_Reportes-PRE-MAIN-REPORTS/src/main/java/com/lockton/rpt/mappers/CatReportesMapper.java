package com.lockton.rpt.mappers;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.CatReportesRConfig_DTO;
import com.lockton.rpt.models.dto.CatReportesDTO;
import com.lockton.rpt.models.entities.CatReportes;
import com.lockton.rpt.models.request.RequestCatReportesDTO;

public class CatReportesMapper {

public static CatReportesDTO MapperDTO(CatReportes ent) {
        CatReportesDTO dto = new CatReportesDTO();
        dto.setCatReportesId(ent.getCatReportesId());
        dto.setCatReportesNombre(ent.getCatReportesNombre());
        dto.setCatReportesDesc(ent.getCatReportesDesc());
        dto.setCatReportesTAId(ent.getCatReportesTAId());
        dto.setCatReportesFormato(ent.getCatReportesFormato());
        dto.setEsid(ent.getEsid());
        dto.setCatReportesUsuarioAdd(ent.getCatReportesUsuarioAdd());
        dto.setCatReportesFechaAdd(ent.getCatReportesFechaAdd());
        dto.setCatReportesUsuarioMod(ent.getCatReportesUsuarioMod());
        dto.setCatReportesFechaMod(ent.getCatReportesFechaMod());
        dto.setCatTipoReporteId(ent.getCatTipoReporteId());
        dto.setCatReportesNum(ent.getCatReportesNum());
        return dto;
    }

    public static List<CatReportesDTO> MapperDTO(List<CatReportes> ent) {
        return ent
            .stream()
            .map(CatReportesMapper::MapperDTO)
            .collect(Collectors.toList());
    }

    public static CatReportes MapperEntity(CatReportesDTO dto) {
        CatReportes ent = new CatReportes();
        ent.setCatReportesId(dto.getCatReportesId());
        ent.setCatReportesNombre(dto.getCatReportesNombre());
        ent.setCatReportesDesc(dto.getCatReportesDesc());
        ent.setCatReportesTAId(dto.getCatReportesTAId());
        ent.setCatReportesFormato(dto.getCatReportesFormato());
        ent.setEsid(dto.getEsid());
        ent.setCatReportesUsuarioAdd(dto.getCatReportesUsuarioAdd());
        ent.setCatReportesFechaAdd(dto.getCatReportesFechaAdd());
        ent.setCatReportesUsuarioMod(dto.getCatReportesUsuarioMod());
        ent.setCatReportesFechaMod(dto.getCatReportesFechaMod());
        ent.setCatTipoReporteId(dto.getCatTipoReporteId());
        return ent;
    }
    
    public static List<CatReportes> MapperEntity(List<CatReportesDTO> dto) {
        return dto
            .stream()
            .map(CatReportesMapper::MapperEntity)
            .collect(Collectors.toList());
    }

    public static CatReportes mapToReporte(RequestCatReportesDTO dto) {
        CatReportes entity = new CatReportes();
        entity.setCatReportesId(dto.getCatReportesId());
        entity.setCatReportesNombre(dto.getCatReportesNombre());
        entity.setCatReportesDesc(dto.getCatReportesDesc());
        entity.setCatReportesTAId(dto.getCatReportesTAId());
        entity.setCatReportesFormato(dto.getCatReportesFormato());
        entity.setEsid(dto.getEsid());
        entity.setCatReportesUsuarioAdd(dto.getCatReportesUsuarioAdd());
        entity.setCatReportesFechaAdd(toLocalDateTime(dto.getCatReportesFechaAdd()));
        entity.setCatReportesUsuarioMod(dto.getCatReportesUsuarioMod());
        entity.setCatReportesFechaMod(toLocalDateTime(dto.getCatReportesFechaMod()));
        entity.setCatTipoReporteId(dto.getCatTipoReporteId());
        entity.setCatReportesNum(dto.getCatReportesNum());
        return entity;
    }

    public static List<CatReportesRConfig_DTO> mapToCatReportConf(List<CatReportes> data){
        return data.stream().map(item -> {
            CatReportesRConfig_DTO dto = new CatReportesRConfig_DTO();
            dto.setCatReportesId(item.getCatReportesId());
            dto.setCatReportesNombre(item.getCatReportesNombre());
            dto.setCatReportesDesc(item.getCatReportesDesc());
            dto.setCatReportesTAId(item.getCatReportesTAId());
            dto.setCatReportesFormato(item.getCatReportesFormato());
            dto.setEsId(item.getEsid());
            dto.setCatReportesNum(item.getCatReportesNum());
            dto.setCatReportesUsuarioAdd(item.getCatReportesUsuarioAdd());
            dto.setCatReportesFechaAdd(item.getCatReportesFechaAdd().toString());
            return dto;
        }).collect(Collectors.toList());
    }


    public static LocalDateTime toLocalDateTime(String fecha) {
        if (fecha == null || fecha.trim().isEmpty()) {
            return null;
        }
        return OffsetDateTime.parse(fecha).toLocalDateTime();
    }

}