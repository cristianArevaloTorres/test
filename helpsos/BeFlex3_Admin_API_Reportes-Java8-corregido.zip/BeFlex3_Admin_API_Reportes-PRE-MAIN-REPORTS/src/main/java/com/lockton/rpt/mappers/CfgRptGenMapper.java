package com.lockton.rpt.mappers;

import com.lockton.rpt.models.dto.ConfiguracionReporteGenDTO;
import com.lockton.rpt.models.entities.ConfiguracionReporteGen;

public class CfgRptGenMapper {
    public static ConfiguracionReporteGenDTO MapperDTO(ConfiguracionReporteGen ent) {
        ConfiguracionReporteGenDTO dto = new ConfiguracionReporteGenDTO();
        dto.setCfgRptId(ent.getCfgRptId());
        dto.setCfgRptClave(ent.getCfgRptClave());
        dto.setCfgRptValor(ent.getCfgRptValor());
        dto.setCfgRptDescripcion(ent.getCfgRptDescripcion());
        dto.setCfgRptUsuarioAdd(ent.getCfgRptUsuarioAdd());
        dto.setCfgRptFechaAdd(ent.getCfgRptFechaAdd());
        return dto;
    }

    public static ConfiguracionReporteGen MapperEntity(ConfiguracionReporteGenDTO dto) {
        ConfiguracionReporteGen ent = new ConfiguracionReporteGen();
        ent.setCfgRptId(dto.getCfgRptId());
        ent.setCfgRptClave(dto.getCfgRptClave());
        ent.setCfgRptValor(dto.getCfgRptValor());
        ent.setCfgRptDescripcion(dto.getCfgRptDescripcion());
        ent.setCfgRptUsuarioAdd(dto.getCfgRptUsuarioAdd());
        ent.setCfgRptFechaAdd(dto.getCfgRptFechaAdd());
        return ent;
    }
}
