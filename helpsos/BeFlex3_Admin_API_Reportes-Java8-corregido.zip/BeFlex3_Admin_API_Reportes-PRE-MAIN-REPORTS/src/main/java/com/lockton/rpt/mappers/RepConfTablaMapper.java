package com.lockton.rpt.mappers;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.RepConfTablaHojaResponseDTO;
import com.lockton.rpt.models.entities.RepConfTabla;

public class RepConfTablaMapper {
    public static List<RepConfTablaHojaResponseDTO> entityToSheetRespDTO(List<RepConfTabla> entity){
        if(entity == null || entity.isEmpty()){
            return new ArrayList<>();
        }
        return entity
            .stream()
            .map(RepConfTablaMapper::entityToSheetDTO)
            .collect(Collectors.toList());
    }

    public static RepConfTablaHojaResponseDTO entityToSheetDTO(RepConfTabla entity){
        RepConfTablaHojaResponseDTO dto = new RepConfTablaHojaResponseDTO();
        dto.setIdEmpresa(entity.getId().getIdEmpresa());
        dto.setCatReportesId(entity.getId().getCatReportesId());
        dto.setGrupo(entity.getId().getGrupo());
        dto.setIndexTable(entity.getIndexTable());
        dto.setColorFondo(entity.getColorFondo());
        dto.setColorLetra(entity.getColorLetra());
        dto.setActivo(entity.isActivo());
        dto.setRepConfTablaUsuarioAdd(entity.getRepConfTablaUsuarioAdd()); 
        dto.setRepConfTablaUsuarioMod(entity.getRepConfTablaUsuarioMod());
        dto.setRepConfTablaUsuarioDel(entity.getRepConfTablaUsuarioDel());        
        return dto;
    }
}
