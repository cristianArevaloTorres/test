package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lockton.rpt.models.entities.CatalogoReporteGen;

@Repository
public interface CatRptGenRepository extends JpaRepository<CatalogoReporteGen, Long> { }
