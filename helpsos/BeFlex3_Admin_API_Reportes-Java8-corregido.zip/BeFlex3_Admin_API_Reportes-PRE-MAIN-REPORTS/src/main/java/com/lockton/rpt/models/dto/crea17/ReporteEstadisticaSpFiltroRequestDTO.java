package com.lockton.rpt.models.dto.crea17;

public class ReporteEstadisticaSpFiltroRequestDTO {
    private Integer idFiltro;
    private String columnaValor;
    private String columnaTexto;
    private Integer ordenSugerido;
    private Integer idUsuario;

    public Integer getIdFiltro() { return idFiltro; }
    public void setIdFiltro(Integer idFiltro) { this.idFiltro = idFiltro; }
    public String getColumnaValor() { return columnaValor; }
    public void setColumnaValor(String columnaValor) { this.columnaValor = columnaValor; }
    public String getColumnaTexto() { return columnaTexto; }
    public void setColumnaTexto(String columnaTexto) { this.columnaTexto = columnaTexto; }
    public Integer getOrdenSugerido() { return ordenSugerido; }
    public void setOrdenSugerido(Integer ordenSugerido) { this.ordenSugerido = ordenSugerido; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
