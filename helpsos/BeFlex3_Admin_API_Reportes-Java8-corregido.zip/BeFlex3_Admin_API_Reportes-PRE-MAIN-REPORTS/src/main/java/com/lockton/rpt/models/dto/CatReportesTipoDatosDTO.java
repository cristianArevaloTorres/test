package com.lockton.rpt.models.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CatReportesTipoDatosDTO {
    private Integer id;
    private String nombre;
    private String descripcion;
    private Integer esid;
    private Integer UsuarioAdd;
    private LocalDateTime fechaReg;
    private Integer userMod;
    private LocalDateTime fechaMod;
}