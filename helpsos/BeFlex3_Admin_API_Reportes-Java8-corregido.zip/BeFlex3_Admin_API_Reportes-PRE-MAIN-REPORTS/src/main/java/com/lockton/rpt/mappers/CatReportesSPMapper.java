package com.lockton.rpt.mappers;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.CatReportesSPCreateRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesSPDTO;
import com.lockton.rpt.models.entities.CatReportesSP;
import com.lockton.rpt.models.request.RequestCatReportesSPDTO;

public interface CatReportesSPMapper {
    
    public static CatReportesSPDTO MapperDTO(CatReportesSP ent) {
        CatReportesSPDTO dto = new CatReportesSPDTO();
        dto.setId(ent.getCatReportesSPId());
        dto.setCatReportesId(ent.getCatReportesSPId());
        dto.setOrden(ent.getCatReportesSPOrden());
        dto.setNombre(ent.getCatReportesSPNombre());
        dto.setDescripcion(ent.getCatReportesSPDesc());
        dto.setEsid(ent.getEsid());
        return dto;
    }

    public static List<CatReportesSPDTO> MapperDTO(List<CatReportesSP> ent) {
        return ent
            .stream()
            .map(CatReportesSPMapper::MapperDTO)
            .collect(Collectors.toList());
    }

    public static CatReportesSP MapperEntity(CatReportesSPDTO dto) {
        CatReportesSP ent = new CatReportesSP();
        ent.setCatReportesSPId(dto.getId());
        ent.setCatReportesId(dto.getCatReportesId());
        ent.setCatReportesSPOrden(dto.getOrden());
        ent.setCatReportesSPNombre(dto.getNombre());
        ent.setCatReportesSPDesc(dto.getDescripcion());
        ent.setEsid(dto.getEsid());
        return ent;
    }
    
    public static List<CatReportesSP> MapperEntity(List<CatReportesSPDTO> dto) {
        return dto
            .stream()
            .map(CatReportesSPMapper::MapperEntity)
            .collect(Collectors.toList());
    }

    public static CatReportesSP mapToSP(RequestCatReportesSPDTO dto, Integer reporteId) {
        CatReportesSP entity = new CatReportesSP();
        entity.setCatReportesId(reporteId);
        entity.setCatReportesSPNombre(dto.getCatReportesSPNombre());
        entity.setCatReportesSPOrden(dto.getCatReportesSPOrden());
        entity.setCatReportesSPDesc(dto.getCatReportesSPDesc());
        entity.setEsid(dto.getEsid());
        entity.setCatReportesSPUsuarioAdd(dto.getCatReportesSPUsuarioAdd());
        entity.setCatReportesSPFechaAdd(toLocalDateTime(dto.getCatReportesSPFechaAdd()));
        return entity;
    }

    public static CatReportesSP mapRequestDTOToCatSP(CatReportesSPCreateRequest_DTO dto, Integer reporteId) {
        CatReportesSP entity = new CatReportesSP();
        entity.setCatReportesId(reporteId);
        entity.setCatReportesSPNombre(dto.getCatReportesSPNombre());
        entity.setCatReportesSPOrden(dto.getCatReportesSPOrden());
        entity.setCatReportesSPDesc(dto.getCatReportesSPDesc());
        entity.setEsid(dto.getESid());
        entity.setCatReportesSPUsuarioAdd(dto.getCatReportesSPUsuarioAdd());
        entity.setCatReportesSPFechaAdd(dto.getCatReportesSPFechaAdd());
        return entity;
    }

    public static LocalDateTime toLocalDateTime(String fecha) {
        if (fecha == null || fecha.trim().isEmpty()) {
            return null;
        }
        return OffsetDateTime.parse(fecha).toLocalDateTime();
    }
}