package com.lockton.rpt.repe.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class RepeRepository {
    private final DataSource dataSource;

    public RepeRepository(@Qualifier("dataSourceRPT") DataSource ds) {
        this.dataSource = ds;
    }

    public List<Map<String, Object>> call(String procedure, Object... params) {
        List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
        String sql = callSql(procedure, params.length);
        try (Connection connection = dataSource.getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {
            for (int i = 0; i < params.length; i++) bind(statement, i + 1, params[i]);
            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet rs = statement.getResultSet()) {
                        rows = read(rs);
                        if (!rows.isEmpty()) return rows;
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
            return rows;
        } catch (SQLException ex) {
            throw new IllegalStateException(message(ex), ex);
        }
    }

    /**
     * Ejecuta un Stored Procedure y conserva tanto el metadata del primer ResultSet
     * tabular como una muestra limitada de sus filas. No contiene SQL de negocio;
     * únicamente reutiliza la misma infraestructura genérica de CallableStatement.
     */
    public Map<String, Object> callWithMetadata(String procedure, int maxRows, Object... params) {
        List<Map<String, Object>> columns = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
        String sql = callSql(procedure, params.length);
        int normalizedMaxRows = Math.max(1, Math.min(100, maxRows));

        try (Connection connection = dataSource.getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {
            for (int i = 0; i < params.length; i++) bind(statement, i + 1, params[i]);

            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet rs = statement.getResultSet()) {
                        ResultSetMetaData metadata = rs.getMetaData();
                        int count = metadata.getColumnCount();

                        for (int i = 1; i <= count; i++) {
                            Map<String, Object> column = new LinkedHashMap<String, Object>();
                            column.put("orden", Integer.valueOf(i));
                            column.put("nombre", metadata.getColumnLabel(i));
                            column.put("tipo", metadata.getColumnTypeName(i));
                            column.put("nullable", Boolean.valueOf(
                                    metadata.isNullable(i) != ResultSetMetaData.columnNoNulls));
                            columns.add(column);
                        }

                        int index = 0;
                        while (rs.next() && index < normalizedMaxRows) {
                            Map<String, Object> row = new LinkedHashMap<String, Object>();
                            for (int i = 1; i <= count; i++) {
                                row.put(metadata.getColumnLabel(i), rs.getObject(i));
                            }
                            rows.add(row);
                            index++;
                        }

                        Map<String, Object> result = new LinkedHashMap<String, Object>();
                        result.put("columnas", columns);
                        result.put("muestra", rows);
                        return result;
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }

            Map<String, Object> result = new LinkedHashMap<String, Object>();
            result.put("columnas", columns);
            result.put("muestra", rows);
            return result;
        } catch (SQLException ex) {
            throw new IllegalStateException(message(ex), ex);
        }
    }

    public Map<String, Object> one(String procedure, Object... params) {
        List<Map<String, Object>> rows = call(procedure, params);
        return rows.isEmpty() ? new LinkedHashMap<String, Object>() : rows.get(0);
    }

    private String callSql(String procedure, int parameterCount) {
        StringBuilder sql = new StringBuilder("{call ").append(procedure);
        if (parameterCount > 0) {
            sql.append('(');
            for (int i = 0; i < parameterCount; i++) {
                if (i > 0) sql.append(',');
                sql.append('?');
            }
            sql.append(')');
        }
        return sql.append('}').toString();
    }

    private void bind(CallableStatement statement, int index, Object value) throws SQLException {
        if (value == null) statement.setNull(index, Types.NULL);
        else if (value instanceof Integer) statement.setInt(index, ((Integer) value).intValue());
        else if (value instanceof Boolean) statement.setBoolean(index, ((Boolean) value).booleanValue());
        else statement.setObject(index, value);
    }

    private List<Map<String, Object>> read(ResultSet rs) throws SQLException {
        List<Map<String, Object>> out = new ArrayList<Map<String, Object>>();
        ResultSetMetaData metadata = rs.getMetaData();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<String, Object>();
            for (int i = 1; i <= metadata.getColumnCount(); i++) {
                row.put(metadata.getColumnLabel(i), rs.getObject(i));
            }
            out.add(row);
        }
        return out;
    }

    private String message(SQLException ex) {
        SQLException current = ex;
        while (current.getNextException() != null) current = current.getNextException();
        return current.getMessage() == null ? ex.getMessage() : current.getMessage();
    }
}
