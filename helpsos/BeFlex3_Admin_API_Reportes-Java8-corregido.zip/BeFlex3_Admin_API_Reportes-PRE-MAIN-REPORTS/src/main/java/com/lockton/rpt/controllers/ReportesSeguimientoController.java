package com.lockton.rpt.controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.time.LocalDate;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.lockton.rpt.models.dto.CatalogoEstatusReporteGenDTO;
import com.lockton.rpt.models.dto.ControlReporteGenDTO;
import com.lockton.rpt.models.dto.ItemReporteDTO;
import com.lockton.rpt.models.entities.VwControlReporte;
import com.lockton.rpt.services.ReporteSeguimientoService;

@RestController
@RequestMapping("/beflex/reportes/seguimiento")
@Api(tags = "Controlador de pantalla de seguimiento de reportes")
public class ReportesSeguimientoController {
    
    private static final Log LOGGER = LogFactory.getLog(WSReportesController.class);

    @Autowired
    ReporteSeguimientoService service;

    @GetMapping("Estatus")
    public ResponseEntity<List<CatalogoEstatusReporteGenDTO>> getEstatus() {
        return ResponseEntity.ok().body(service.getEstatus());
    }

    @GetMapping("Reportes")
    public ResponseEntity<List<ItemReporteDTO>> getReportes() {
        return ResponseEntity.ok().body(service.getReportes());
    }

    @GetMapping()
    @ApiOperation("Lectura de tabla")
    public ResponseEntity<List<ControlReporteGenDTO>> GetAll() {
        return ResponseEntity.ok().body(service.getAll());
    }

    @GetMapping("/buscar")
    @ApiOperation("Filtrado de reportes.")
    public ResponseEntity<List<VwControlReporte>> Buscar(
        @RequestParam(required = false) Integer idEmpresa,
        @RequestParam(required = false) Integer idEmpleado,
        @RequestParam(required = false) Integer idRpt,
        @RequestParam(required = false) Integer estatus,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFinal) {
        return ResponseEntity.ok().body(service.buscar(idEmpresa, idEmpleado, idRpt, estatus, fechaInicio, fechaFinal));
    }


    
}
