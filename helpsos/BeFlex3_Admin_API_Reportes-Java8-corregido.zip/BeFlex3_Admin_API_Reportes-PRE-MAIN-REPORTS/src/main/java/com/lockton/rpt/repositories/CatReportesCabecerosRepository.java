package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.lockton.rpt.models.entities.CatReportesCabeceros;
import java.util.List;

@Repository
public interface CatReportesCabecerosRepository extends JpaRepository<CatReportesCabeceros, Integer> {
    // Buscar todos los cabeceros por catReportesId
    List<CatReportesCabeceros> findByCatReportesId(Integer catReportesId);
}
