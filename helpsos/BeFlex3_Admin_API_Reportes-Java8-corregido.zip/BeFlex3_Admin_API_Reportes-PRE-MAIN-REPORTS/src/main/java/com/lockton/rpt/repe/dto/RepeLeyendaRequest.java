package com.lockton.rpt.repe.dto;

import com.fasterxml.jackson.databind.JsonNode;

public class RepeLeyendaRequest {
    private Integer idConsulta;
    private String clave;
    private String nombre;
    private String descripcion;
    private String tipo;
    private JsonNode textos;
    private String claveCondicion;
    private Integer orden;
    private Integer idUsuario;

    public Integer getIdConsulta() { return idConsulta; }
    public void setIdConsulta(Integer value) { idConsulta = value; }
    public String getClave() { return clave; }
    public void setClave(String value) { clave = value; }
    public String getNombre() { return nombre; }
    public void setNombre(String value) { nombre = value; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String value) { descripcion = value; }
    public String getTipo() { return tipo; }
    public void setTipo(String value) { tipo = value; }
    public JsonNode getTextos() { return textos; }
    public void setTextos(JsonNode value) { textos = value; }
    public String getClaveCondicion() { return claveCondicion; }
    public void setClaveCondicion(String value) { claveCondicion = value; }
    public Integer getOrden() { return orden; }
    public void setOrden(Integer value) { orden = value; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer value) { idUsuario = value; }
}
