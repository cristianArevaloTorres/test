package com.lockton.rpt.mappers;

import java.util.List;
import java.util.stream.Collectors;
import com.lockton.rpt.models.dto.CatReportesTipoDatosDTO;
import com.lockton.rpt.models.entities.CatReportesTipoDatos;

public class CatReportesTipoDatosMapper {

public static CatReportesTipoDatosDTO MapperDTO(CatReportesTipoDatos ent) {
        CatReportesTipoDatosDTO dto = new CatReportesTipoDatosDTO();
        dto.setId(ent.getCatReportesTipoDatoId());
        dto.setNombre(ent.getCatReportesTipoDatoNombre());
        dto.setDescripcion(ent.getCatReportesTipoDatoDesc());
        dto.setEsid(ent.getEsid());
        return dto;
    }

    public static List<CatReportesTipoDatosDTO> MapperDTO(List<CatReportesTipoDatos> ent) {
        return ent
            .stream()
            .map(CatReportesTipoDatosMapper::MapperDTO)
            .collect(Collectors.toList());
    }

    public static CatReportesTipoDatos MapperEntity(CatReportesTipoDatosDTO dto) {
        CatReportesTipoDatos ent = new CatReportesTipoDatos();
        ent.setCatReportesTipoDatoId(dto.getId());
        ent.setCatReportesTipoDatoNombre(dto.getNombre());
        ent.setCatReportesTipoDatoDesc(dto.getDescripcion());
        ent.setEsid(dto.getEsid());
        return ent;
    }
    
    public static List<CatReportesTipoDatos> MapperEntity(List<CatReportesTipoDatosDTO> dto) {
        return dto
            .stream()
            .map(CatReportesTipoDatosMapper::MapperEntity)
            .collect(Collectors.toList());
    }
}

