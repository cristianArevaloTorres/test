package com.lockton.rpt.repositories.jdbc;

import com.lockton.rpt.repositories.BfCatReportesCatalogSupport;
import com.lockton.rpt.repositories.ConfigIndicadorJsonSupport;
import com.lockton.rpt.repositories.ConfigIndicadoresDAO;
import com.lockton.rpt.repositories.CatCorporativosDAO;
import com.lockton.rpt.repositories.SnapshotReporteDAO;
import com.lockton.rpt.repositories.ReporteEstadisticasDAO;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.lockton.rpt.util.TextUtil;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCSnapshotReporteDAO implements SnapshotReporteDAO {

    private static final Set<String> PERIOD_COLUMNS = Collections.unmodifiableSet(new HashSet<String>(Arrays.asList(
            "IdCorporativo", "IdVigencia", "IdVigenciaAnterior", "FechaCorte", "IndiceResultSet")));

    private final JdbcTemplate jdbcTemplate;
    private final ConfigIndicadoresDAO configIndicadoresDAO;

    public JDBCSnapshotReporteDAO(JdbcTemplate jdbcTemplate, ConfigIndicadoresDAO configIndicadoresDAO) {
        this.jdbcTemplate = jdbcTemplate;
        this.configIndicadoresDAO = configIndicadoresDAO;
    }

    @Override
    public Map<String, Object> resolverContexto(int idCorporativo) {
        return jdbcTemplate.query(
                "DECLARE @Fi DATETIME, @Fc DATETIME, @Vig INT, @VigAnt INT; "
                        + "EXEC dbo.sp_ReporteEstad_ResolverContexto ?, @Fi OUT, @Fc OUT, @Vig OUT, @VigAnt OUT; "
                        + "SELECT @Fi AS FechaInicio, @Fc AS FechaCorte, @Vig AS IdVigencia, @VigAnt AS IdVigenciaAnterior;",
                rs -> {
                    if (!rs.next()) {
                        return Collections.<String, Object>emptyMap();
                    }
                    Map<String, Object> out = new LinkedHashMap<>();
                    out.put("FechaInicio", rs.getTimestamp("FechaInicio"));
                    out.put("FechaCorte", rs.getTimestamp("FechaCorte"));
                    out.put("IdVigencia", rs.getObject("IdVigencia"));
                    out.put("IdVigenciaAnterior", rs.getObject("IdVigenciaAnterior"));
                    return out;
                },
                idCorporativo);
    }

    @Override
    public List<Map<String, Object>> listarProcedimientosSnapshot() {
        return jdbcTemplate.query(
                "SELECT catReportesSPId, catReportesSPNombre, catReportesSPDesc "
                        + "FROM dbo.bf_CatReportesSP WHERE catReportesId = ? AND ESid = 1 "
                        + "ORDER BY catReportesSPOrden, catReportesSPNombre",
                (rs, rowNum) -> {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("IdStoredProcedure", rs.getInt("catReportesSPId"));
                    row.put("NombreProcedimiento", rs.getString("catReportesSPNombre"));
                    row.put("Descripcion", rs.getString("catReportesSPDesc"));
                    return row;
                },
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
    }

    @Override
    public int upsertPeriodo(int idCorporativo, int idVigencia, Integer idVigenciaAnterior,
            LocalDateTime fechaCorte, LocalDateTime fechaInicioVigencia,
            int idUsuario, String nombreUsuario, String estado, String detalleError) {
        Timestamp fc = Timestamp.valueOf(fechaCorte);
        Timestamp fi = fechaInicioVigencia != null ? Timestamp.valueOf(fechaInicioVigencia) : null;
        Integer updated = jdbcTemplate.update(
                "UPDATE dbo.bf_IndicadorSnapshotPeriodo SET IdVigenciaAnterior=?, FechaInicioVigencia=?, "
                        + "FechaSnapshot=GETDATE(), IdUsuarioSnapshot=?, NombreUsuarioSnapshot=?, "
                        + "Estado=?, DetalleError=? "
                        + "WHERE IdCorporativo=? AND IdVigencia=? AND FechaCorte=?",
                idVigenciaAnterior, fi, idUsuario, nombreUsuario, estado, detalleError,
                idCorporativo, idVigencia, fc);
        if (updated != null && updated > 0) {
            return updated;
        }
        return jdbcTemplate.update(
                "INSERT INTO dbo.bf_IndicadorSnapshotPeriodo "
                        + "(IdCorporativo, IdVigencia, IdVigenciaAnterior, FechaCorte, FechaInicioVigencia, "
                        + "IdUsuarioSnapshot, NombreUsuarioSnapshot, Estado, DetalleError) "
                        + "VALUES (?,?,?,?,?,?,?,?,?)",
                idCorporativo, idVigencia, idVigenciaAnterior, fc, fi,
                idUsuario, nombreUsuario, estado, detalleError);
    }

    @Override
    public void limpiarTablaSnapshot(String tabla, int idCorporativo, int idVigencia,
            LocalDateTime fechaCorte) {
        validarNombreTabla(tabla);
        jdbcTemplate.update(
                "DELETE FROM dbo." + tabla + " WHERE IdCorporativo=? AND IdVigencia=? AND FechaCorte=?",
                idCorporativo, idVigencia, Timestamp.valueOf(fechaCorte));
    }

    @Override
    public void insertarFilasSnapshot(String tabla, int idCorporativo, int idVigencia,
            Integer idVigenciaAnterior, LocalDateTime fechaCorte,
            List<Map<String, Object>> filas, int indiceResultSet) {
        if (filas == null || filas.isEmpty()) {
            return;
        }
        validarNombreTabla(tabla);
        Timestamp fc = Timestamp.valueOf(fechaCorte);
        for (Map<String, Object> fila : filas) {
            Map<String, Object> payload = new LinkedHashMap<>(fila);
            payload.put("IdCorporativo", idCorporativo);
            payload.put("IdVigencia", idVigencia);
            payload.put("IdVigenciaAnterior", idVigenciaAnterior);
            payload.put("FechaCorte", fc);
            if (tabla.contains("OpcionalesResumen") && indiceResultSet > 0) {
                payload.put("IndiceResultSet", indiceResultSet);
            }
            if (tabla.contains("GetParametros")) {
                Object vigSp = payload.remove("IdVigencia");
                Object vigAntSp = payload.remove("IdVigenciaAnterior");
                payload.put("IdVigenciaSnapshot", vigSp);
                payload.put("IdVigenciaAnteriorSnapshot", vigAntSp);
                payload.put("IdVigencia", idVigencia);
                payload.put("IdVigenciaAnterior", idVigenciaAnterior);
            }
            insertDynamicRow(tabla, payload);
        }
    }

    @Override
    public boolean existeSnapshot(int idCorporativo, int idVigencia, LocalDateTime fechaCorte) {
        Integer n = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM dbo.bf_IndicadorSnapshotPeriodo "
                        + "WHERE IdCorporativo=? AND IdVigencia=? AND FechaCorte=? AND Estado='OK'",
                Integer.class,
                idCorporativo, idVigencia, Timestamp.valueOf(fechaCorte));
        return n != null && n > 0;
    }

    @Override
    public List<Map<String, Object>> consultarSnapshot(String tabla, int idCorporativo, int idVigencia,
            LocalDateTime fechaCorte, Map<String, String> filtrosPermitidos) {
        validarNombreTabla(tabla);
        Set<String> columnas = columnasTabla(tabla);
        StringBuilder sql = new StringBuilder("SELECT ");
        sql.append(columnas.stream()
                .filter(c -> !"SnapRowId".equalsIgnoreCase(c))
                .collect(Collectors.joining(", ")));
        sql.append(" FROM dbo.").append(tabla);
        sql.append(" WHERE IdCorporativo=? AND IdVigencia=? AND FechaCorte=?");
        List<Object> args = new ArrayList<>();
        args.add(idCorporativo);
        args.add(idVigencia);
        args.add(Timestamp.valueOf(fechaCorte));
        if (filtrosPermitidos != null) {
            for (Map.Entry<String, String> e : filtrosPermitidos.entrySet()) {
                String col = resolverColumnaFiltro(columnas, e.getKey());
                if (col == null || PERIOD_COLUMNS.contains(col)) {
                    continue;
                }
                sql.append(" AND ").append(col).append(" = ?");
                args.add(e.getValue());
            }
        }
        return jdbcTemplate.query(sql.toString(), (rs, rowNum) -> mapRow(rs), args.toArray());
    }

    @Override
    public List<Map<String, Object>> getParametrosCatalogoSp(int idStoredProcedure) {
        return jdbcTemplate.query(
                "SELECT catReportesParamsNombre, catReportesParamsDesc, catReportesParamsOrden "
                        + "FROM dbo.bf_CatReportesParams WHERE catReportesSPId=? AND ESid=1 "
                        + "ORDER BY catReportesParamsOrden",
                (rs, rowNum) -> {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("nombreParametro", rs.getString("catReportesParamsNombre"));
                    row.put("nombreVisual", rs.getString("catReportesParamsDesc"));
                    row.put("orden", rs.getInt("catReportesParamsOrden"));
                    return row;
                },
                idStoredProcedure);
    }

    @Override
    public List<Map<String, Object>> getParametrosRealesProcedimiento(String nombreProcedimiento) {
        String proc = normalizeProcedureName(nombreProcedimiento);
        return jdbcTemplate.query(
                "SELECT p.name AS nombre, TYPE_NAME(p.user_type_id) AS tipo, p.parameter_id AS orden "
                        + "FROM sys.parameters p "
                        + "WHERE p.object_id = OBJECT_ID(?) AND p.parameter_id > 0 "
                        + "ORDER BY p.parameter_id",
                (rs, rowNum) -> {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("nombre", rs.getString("nombre"));
                    row.put("tipo", rs.getString("tipo"));
                    row.put("orden", rs.getInt("orden"));
                    return row;
                },
                proc);
    }

    @Override
    public List<Map<String, Object>> listarPeriodosSnapshot(Integer idCorporativo) {
        String sql = "SELECT SnapPeriodoId, IdCorporativo, IdVigencia, IdVigenciaAnterior, "
                + "FechaCorte, FechaInicioVigencia, FechaSnapshot, Estado, DetalleError, "
                + "NombreUsuarioSnapshot "
                + "FROM dbo.bf_IndicadorSnapshotPeriodo ";
        List<Object> args = new ArrayList<>();
        if (idCorporativo != null) {
            sql += "WHERE IdCorporativo=? ";
            args.add(idCorporativo);
        }
        sql += "ORDER BY FechaSnapshot DESC, IdCorporativo, IdVigencia DESC";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("snapPeriodoId", rs.getInt("SnapPeriodoId"));
            row.put("idCorporativo", rs.getInt("IdCorporativo"));
            row.put("idVigencia", rs.getInt("IdVigencia"));
            row.put("idVigenciaAnterior", rs.getObject("IdVigenciaAnterior"));
            row.put("fechaCorte", rs.getTimestamp("FechaCorte"));
            row.put("fechaInicioVigencia", rs.getTimestamp("FechaInicioVigencia"));
            row.put("fechaSnapshot", rs.getTimestamp("FechaSnapshot"));
            row.put("estado", rs.getString("Estado"));
            row.put("detalleError", rs.getString("DetalleError"));
            row.put("nombreUsuarioSnapshot", rs.getString("NombreUsuarioSnapshot"));
            return row;
        }, args.toArray());
    }

    private String normalizeProcedureName(String nombreProcedimiento) {
        if (nombreProcedimiento == null || TextUtil.isBlank(nombreProcedimiento)) {
            throw new IllegalArgumentException("Nombre de procedimiento vacío.");
        }
        String proc = nombreProcedimiento.trim();
        if (!proc.regionMatches(true, 0, "dbo.", 0, 4)) {
            proc = "dbo." + proc.replace("dbo.", "");
        }
        return proc;
    }

    public List<List<Map<String, Object>>> ejecutarProcedimientoSnapshot(String nombreProcedimiento,
            List<Map<String, Object>> parametros) {
        return configIndicadoresDAO.ejecutarStoredProcedure(nombreProcedimiento, parametros);
    }

    private void insertDynamicRow(String tabla, Map<String, Object> payload) {
        Set<String> columnas = columnasTabla(tabla);
        List<String> cols = new ArrayList<>();
        List<Object> vals = new ArrayList<>();
        for (Map.Entry<String, Object> e : payload.entrySet()) {
            String col = resolverColumnaFiltro(columnas, e.getKey());
            if (col == null || "SnapRowId".equalsIgnoreCase(col)) {
                continue;
            }
            cols.add(col);
            vals.add(e.getValue());
        }
        if (cols.isEmpty()) {
            return;
        }
        String placeholders = cols.stream().map(c -> "?").collect(Collectors.joining(", "));
        String sql = "INSERT INTO dbo." + tabla + " (" + String.join(", ", cols) + ") VALUES (" + placeholders + ")";
        jdbcTemplate.update(sql, vals.toArray());
    }

    private Set<String> columnasTabla(String tabla) {
        List<String> cols = jdbcTemplate.query(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
                        + "WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME=? ORDER BY ORDINAL_POSITION",
                (rs, rowNum) -> rs.getString("COLUMN_NAME"),
                tabla);
        return new LinkedHashSet<>(cols);
    }

    private String resolverColumnaFiltro(Set<String> columnas, String paramName) {
        if (paramName == null) {
            return null;
        }
        String normalized = paramName.replace("@", "").trim();
        for (String col : columnas) {
            if (col.equalsIgnoreCase(normalized)) {
                return col;
            }
        }
        return null;
    }

    private void validarNombreTabla(String tabla) {
        if (tabla == null || !tabla.matches("bf_IndicadorReporteEstad_[A-Za-z0-9_]+")) {
            throw new IllegalArgumentException("Tabla snapshot no permitida: " + tabla);
        }
    }

    private Map<String, Object> mapRow(ResultSet rs) throws java.sql.SQLException {
        ResultSetMetaData meta = rs.getMetaData();
        Map<String, Object> row = new LinkedHashMap<>();
        for (int i = 1; i <= meta.getColumnCount(); i++) {
            row.put(meta.getColumnLabel(i), rs.getObject(i));
        }
        return row;
    }
}
