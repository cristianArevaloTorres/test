package com.lockton.rpt.models.entities;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "bf_CatReportesTipoArchivo")
public class CatReportesTipoArchivo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "catReportesTAId")
    private Integer catReportesTAId;
    @Column(name = "catReportesTATipo", length = 50, nullable = false, unique = true)
    private String catReportesTATipo;
    @Column(name = "catReportesTADescripcion", length = 150, nullable = false)
    private String catReportesTADescripcion;
    @Column(name = "ESid", nullable = false)
    private Integer ESid;
    @Column(name = "catReportesTAUsuarioAdd", nullable = true)
    private Integer catReportesTAUsuarioAdd;
    @Column(name = "catReportesTAFechaAdd", nullable = false)
    private LocalDateTime catReportesTAFechaAdd;
    @Column(name = "catReportesTAUsuarioMod", nullable = true)
    private Integer catReportesTAUsuarioMod;
    @Column(name = "catReportesTAFechaMod", nullable = true)
    private LocalDateTime catReportesTAFechaMod;
    @Column(name = "catReportesTAUsuarioDel", nullable = true)
    private Integer catReportesTAUsuarioDel;
    @Column(name = "catReportesTAFechaDel", nullable = true)
    private LocalDateTime catReportesTAFechaDel;
}