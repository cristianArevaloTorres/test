package com.lockton.rpt.services.impl;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorDisponibilidadRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorPasoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorReplicarRequestDTO;
import com.lockton.rpt.repositories.ReporteEstadisticaIndicadorDAO;
import com.lockton.rpt.services.ReporteEstadisticaIndicadorService;
import com.lockton.rpt.services.ReporteEstadisticaSnapshotService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class ReporteEstadisticaIndicadorServiceImpl
        implements ReporteEstadisticaIndicadorService {
    private final ReporteEstadisticaIndicadorDAO dao;
    private final ReporteEstadisticaSnapshotService snapshotService;

    public ReporteEstadisticaIndicadorServiceImpl(
            ReporteEstadisticaIndicadorDAO dao,
            ReporteEstadisticaSnapshotService snapshotService) {
        this.dao = dao;
        this.snapshotService = snapshotService;
    }

    @Override
    public Map<String, Object> obtenerCatalogos() {
        return dao.obtenerCatalogos();
    }

    @Override
    public List<Map<String, Object>> listar(
            String tipo,
            Integer idCorporativo,
            boolean incluirBajas) {
        String normalized = normalizeType(tipo);
        if ("CORPORATIVO".equals(normalized)
                && (idCorporativo == null || idCorporativo.intValue() <= 0)) {
            throw new IllegalArgumentException(
                    "El corporativo es requerido para consultar su catálogo.");
        }
        return dao.listar(normalized, idCorporativo, incluirBajas);
    }

    @Override
    public Map<String, Object> obtener(int idIndicador) {
        requirePositive(idIndicador, "El indicador es requerido.");
        return dao.obtener(idIndicador);
    }

    @Override
    public Map<String, Object> guardarPaso(
            IndicadorPasoGuardarRequestDTO request) {
        if (request == null) {
            throw new IllegalArgumentException("La configuración es requerida.");
        }
        if (request.getPaso() == null
                || request.getPaso().intValue() < 1
                || request.getPaso().intValue() > 5) {
            throw new IllegalArgumentException(
                    "El paso debe encontrarse entre 1 y 5.");
        }
        requirePositive(
                request.getIdUsuario() == null
                        ? 0
                        : request.getIdUsuario().intValue(),
                "El usuario es requerido.");
        request.setTipo(normalizeType(request.getTipo()));

        if ("CORPORATIVO".equals(request.getTipo())) {
            requirePositive(
                    request.getIdCorporativo() == null
                            ? 0
                            : request.getIdCorporativo().intValue(),
                    "El corporativo es requerido.");
        } else {
            request.setIdCorporativo(null);
        }

        Map<String, Object> result = dao.guardarPaso(request);
        if (request.getPaso().intValue() == 1) {
            requiredPositiveId(result,
                    "La base de datos no devolvió un identificador válido para el indicador.");
        }
        return result;
    }

    @Override
    public Map<String, Object> cambiarEstatus(
            int idIndicador,
            CambioEstatusRequestDTO request) {
        requirePositive(idIndicador, "El indicador es requerido.");
        if (request == null
                || request.getIdEstatus() == null
                || request.getIdUsuario() == null) {
            throw new IllegalArgumentException(
                    "El estatus y el usuario son requeridos.");
        }
        if (request.getIdEstatus().intValue() != 1
                && request.getIdEstatus().intValue() != 2) {
            throw new IllegalArgumentException(
                    "El estatus debe ser 1 activo o 2 inactivo.");
        }
        return dao.cambiarEstatus(idIndicador, request);
    }

    @Override
    public Map<String, Object> guardarDisponibilidad(
            int idIndicador,
            IndicadorDisponibilidadRequestDTO request) {
        requirePositive(idIndicador, "El indicador global es requerido.");
        if (request == null
                || request.getIdUsuario() == null
                || request.getModo() == null) {
            throw new IllegalArgumentException(
                    "El modo y el usuario son requeridos.");
        }
        requirePositive(request.getIdUsuario().intValue(),
                "El usuario es requerido.");

        String modo = request.getModo().trim().toUpperCase();
        if (!"TODOS".equals(modo)
                && !"SOLO_INCLUIDOS".equals(modo)
                && !"TODOS_EXCEPTO".equals(modo)) {
            throw new IllegalArgumentException(
                    "El modo debe ser TODOS, SOLO_INCLUIDOS o TODOS_EXCEPTO.");
        }

        request.setModo(modo);
        request.setIdsCorporativo(normalizePositiveIds(
                request.getIdsCorporativo()));
        if (!"TODOS".equals(modo)
                && request.getIdsCorporativo().isEmpty()) {
            throw new IllegalArgumentException(
                    "Selecciona al menos un corporativo para el modo elegido.");
        }
        if ("TODOS".equals(modo)) {
            request.setIdsCorporativo(new ArrayList<Integer>());
        }
        return dao.guardarDisponibilidad(idIndicador, request);
    }

    @Override
    public List<Map<String, Object>> listarGlobalesDisponibles(
            int idCorporativo) {
        requirePositive(idCorporativo, "El corporativo es requerido.");
        return dao.listarGlobalesDisponibles(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> replicar(
            int idCorporativo,
            IndicadorReplicarRequestDTO request) {
        requirePositive(idCorporativo, "El corporativo es requerido.");
        if (request == null || request.getIdUsuario() == null) {
            throw new IllegalArgumentException(
                    "Selecciona al menos un indicador y proporciona el usuario.");
        }
        requirePositive(request.getIdUsuario().intValue(),
                "El usuario es requerido.");
        request.setIdsIndicadorGlobal(normalizePositiveIds(
                request.getIdsIndicadorGlobal()));
        if (request.getIdsIndicadorGlobal().isEmpty()) {
            throw new IllegalArgumentException(
                    "Selecciona al menos un indicador global válido.");
        }
        return dao.replicar(idCorporativo, request);
    }

    @Override
    public Map<String, Object> validarClave(
            String tipo,
            String clave,
            Integer idRegistro,
            Integer idIndicador) {
        String normalizedType = tipo == null ? "" : tipo.trim().toUpperCase();
        if (!"VARIABLE".equals(normalizedType)
                && !"TEXTO".equals(normalizedType)) {
            throw new IllegalArgumentException(
                    "El tipo de clave debe ser VARIABLE o TEXTO.");
        }
        String normalizedKey = clave == null ? "" : clave.trim().toUpperCase();
        if (!normalizedKey.matches("^[A-Z0-9_]+$")) {
            throw new IllegalArgumentException(
                    "La clave solo puede contener letras, números y guiones bajos.");
        }
        return dao.validarClave(normalizedType, normalizedKey, idRegistro, idIndicador);
    }

    @Override
    public Map<String, Object> obtenerMuestraFuente(
            int idCorporativo,
            int idStoredProcedure,
            int maxFilas) {
        requirePositive(idCorporativo, "El corporativo es requerido.");
        requirePositive(idStoredProcedure, "La consulta es requerida.");
        snapshotService.asegurarDisponible(idCorporativo, null);
        int safeMax = maxFilas < 1 || maxFilas > 500 ? 100 : maxFilas;
        return dao.obtenerMuestraFuente(
                idCorporativo,
                idStoredProcedure,
                safeMax);
    }

    @Override
    public List<Map<String, Object>> obtenerValoresDistintos(
            int idCorporativo,
            int idStoredProcedure,
            String columna,
            int maxValores) {
        requirePositive(idCorporativo, "El corporativo es requerido.");
        requirePositive(idStoredProcedure, "La consulta es requerida.");
        snapshotService.asegurarDisponible(idCorporativo, null);
        if (columna == null || columna.trim().isEmpty()) {
            throw new IllegalArgumentException("La columna es requerida.");
        }
        int safeMax = maxValores < 1 || maxValores > 1000
                ? 200
                : maxValores;
        return dao.obtenerValoresDistintos(
                idCorporativo,
                idStoredProcedure,
                columna.trim(),
                safeMax);
    }

    private List<Integer> normalizePositiveIds(List<Integer> values) {
        Set<Integer> unique = new LinkedHashSet<Integer>();
        if (values != null) {
            for (Integer value : values) {
                if (value != null && value.intValue() > 0) {
                    unique.add(value);
                }
            }
        }
        return new ArrayList<Integer>(unique);
    }

    private String normalizeType(String value) {
        String normalized = value == null
                ? ""
                : value.trim().toUpperCase();
        if (!"GLOBAL".equals(normalized)
                && !"CORPORATIVO".equals(normalized)) {
            throw new IllegalArgumentException(
                    "El tipo debe ser GLOBAL o CORPORATIVO.");
        }
        return normalized;
    }


    private int requiredPositiveId(Map<String, Object> result, String message) {
        if (result == null) {
            throw new IllegalStateException(message);
        }
        Object raw = result.get("IdIndicador");
        if (raw == null) raw = result.get("idIndicador");
        int id = 0;
        if (raw instanceof Number) {
            id = ((Number) raw).intValue();
        } else if (raw != null) {
            try { id = Integer.parseInt(String.valueOf(raw)); }
            catch (NumberFormatException ignored) { id = 0; }
        }
        if (id <= 0) {
            throw new IllegalStateException(message);
        }
        return id;
    }

    private void requirePositive(int value, String message) {
        if (value <= 0) {
            throw new IllegalArgumentException(message);
        }
    }
}
