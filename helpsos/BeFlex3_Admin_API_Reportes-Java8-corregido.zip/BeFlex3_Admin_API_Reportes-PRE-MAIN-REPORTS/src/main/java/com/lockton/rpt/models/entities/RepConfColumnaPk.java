package com.lockton.rpt.models.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RepConfColumnaPk implements Serializable{
    
    @Column(name = "idEmpresa")
    public Integer idEmpresa;

    @Column(name = "catReportesId")
    public Integer catReportesId;

    @Column(name = "grupo")
    public String grupo;

    @Column(name = "orden")
    public Integer orden;

    public RepConfColumnaPk(){}
    
    public RepConfColumnaPk(Integer idEmpresa, Integer catReportesId, String grupo, Integer orden){
        this.idEmpresa = idEmpresa;
        this.catReportesId = catReportesId;
        this.grupo = grupo;
        this.orden = orden;
    }

    public Integer getIdEmpresa() {
        return idEmpresa;
    }
    public void setIdEmpresa(Integer idEmpresa) {
        this.idEmpresa = idEmpresa;
    }
    public Integer getCatReportesId() {
        return catReportesId;
    }
    public void setCatReportesId(Integer catReportesId) {
        this.catReportesId = catReportesId;
    }
    public String getGrupo() {
        return grupo;
    }
    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }
    public Integer getOrden() {
        return orden;
    }
    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RepConfColumnaPk that = (RepConfColumnaPk) o;
        return Objects.equals(idEmpresa, that.idEmpresa) &&
               Objects.equals(catReportesId, that.catReportesId) &&
               Objects.equals(grupo, that.grupo) &&
               Objects.equals(orden, that.orden);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEmpresa, catReportesId, grupo, orden);
    }
}