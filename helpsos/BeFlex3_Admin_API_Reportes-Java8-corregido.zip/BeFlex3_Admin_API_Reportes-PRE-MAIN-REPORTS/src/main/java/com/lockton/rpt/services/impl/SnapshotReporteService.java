package com.lockton.rpt.services.impl;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.lockton.rpt.repositories.jdbc.JDBCSnapshotReporteDAO;
import com.lockton.rpt.repositories.SnapshotReporteDAO;

import com.lockton.rpt.util.TextUtil;

import org.springframework.stereotype.Service;

@Service
public class SnapshotReporteService {

    private final SnapshotReporteDAO snapshotDao;
    private final JDBCSnapshotReporteDAO jdbcSnapshotDao;

    public SnapshotReporteService(SnapshotReporteDAO snapshotDao,
            JDBCSnapshotReporteDAO jdbcSnapshotDao) {
        this.snapshotDao = snapshotDao;
        this.jdbcSnapshotDao = jdbcSnapshotDao;
    }

    /**
     * Volcado histórico: periodo desde {@code sp_ReporteEstad_ResolverContexto}.
     * Los SP se ejecutan solo con {@code @IdCorporativo}; demás parámetros del catálogo van en NULL
     * para no aplicar filtros opcionales al momento de capturar datos.
     */
    public Map<String, Object> ejecutarSnapshotVarios(List<Integer> idCorporativos, int idUsuario,
            String nombreUsuario) {
        List<Map<String, Object>> corporativos = new ArrayList<>();
        String estadoGlobal = "OK";
        for (Integer idCorporativo : idCorporativos) {
            if (idCorporativo == null || idCorporativo <= 0) {
                continue;
            }
            Map<String, Object> one = ejecutarSnapshot(idCorporativo, idUsuario, nombreUsuario);
            corporativos.add(one);
            if (!"OK".equals(String.valueOf(one.get("estado")))) {
                estadoGlobal = "PARCIAL";
            }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("estado", estadoGlobal);
        out.put("totalCorporativos", corporativos.size());
        out.put("corporativos", corporativos);
        return out;
    }

    public Map<String, Object> ejecutarSnapshot(int idCorporativo, int idUsuario, String nombreUsuario) {
        Map<String, Object> ctx = snapshotDao.resolverContexto(idCorporativo);
        LocalDateTime fechaCorte = toLocalDateTime(ctx.get("FechaCorte"));
        LocalDateTime fechaInicio = toLocalDateTime(ctx.get("FechaInicio"));
        int idVigencia = intVal(ctx.get("IdVigencia"));
        Integer idVigenciaAnterior = intOrNull(ctx.get("IdVigenciaAnterior"));

        List<Map<String, Object>> procedimientos = snapshotDao.listarProcedimientosSnapshot();
        List<Map<String, Object>> resultados = new ArrayList<>();
        String estadoGlobal = "OK";
        StringBuilder errores = new StringBuilder();

        for (Map<String, Object> spMeta : procedimientos) {
            String proc = String.valueOf(spMeta.get("NombreProcedimiento"));
            String tabla = SnapshotTableNaming.tableForProcedure(proc);
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("procedimiento", proc);
            item.put("tabla", tabla);
            try {
                List<Map<String, Object>> paramsEjecucion = construirParametrosSnapshot(proc, idCorporativo);
                snapshotDao.limpiarTablaSnapshot(tabla, idCorporativo, idVigencia, fechaCorte);
                List<List<Map<String, Object>>> resultSets = jdbcSnapshotDao.ejecutarProcedimientoSnapshot(
                        proc, paramsEjecucion);
                for (int i = 0; i < resultSets.size(); i++) {
                    snapshotDao.insertarFilasSnapshot(tabla, idCorporativo, idVigencia, idVigenciaAnterior,
                            fechaCorte, resultSets.get(i), i + 1);
                }
                item.put("filas", resultSets.stream().mapToInt(List::size).sum());
                item.put("estado", "OK");
            } catch (Exception ex) {
                item.put("estado", "ERROR");
                item.put("error", ex.getMessage());
                estadoGlobal = "PARCIAL";
                errores.append(proc).append(": ").append(ex.getMessage()).append("; ");
            }
            resultados.add(item);
        }

        snapshotDao.upsertPeriodo(idCorporativo, idVigencia, idVigenciaAnterior, fechaCorte, fechaInicio,
                idUsuario, nombreUsuario, estadoGlobal,
                errores.length() > 0 ? errores.toString() : null);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("idCorporativo", idCorporativo);
        out.put("idVigencia", idVigencia);
        out.put("idVigenciaAnterior", idVigenciaAnterior);
        out.put("fechaCorte", fechaCorte.toString());
        out.put("estado", estadoGlobal);
        out.put("procedimientos", resultados);
        return out;
    }

    public List<Map<String, Object>> leerDatosSnapshot(String nombreProcedimiento, int idCorporativo,
            LocalDateTime fechaCorte, int idVigencia, Map<String, String> filtrosCatalogo) {
        String tabla = SnapshotTableNaming.tableForProcedure(nombreProcedimiento);
        return snapshotDao.consultarSnapshot(tabla, idCorporativo, idVigencia, fechaCorte, filtrosCatalogo);
    }

    public List<Map<String, Object>> listarPeriodosSnapshot(Integer idCorporativo) {
        return snapshotDao.listarPeriodosSnapshot(idCorporativo);
    }

    public Map<String, Object> resolverPeriodoPreview(int idCorporativo, Map<String, String> parametrosEntrada) {
        Map<String, Object> ctx = snapshotDao.resolverContexto(idCorporativo);
        LocalDateTime fechaCorte = toLocalDateTime(ctx.get("FechaCorte"));
        int idVigencia = intVal(ctx.get("IdVigencia"));
        if (parametrosEntrada != null) {
            if (parametrosEntrada.containsKey("FechaCorte")) {
                fechaCorte = parseDateTime(parametrosEntrada.get("FechaCorte"), fechaCorte);
            }
            if (parametrosEntrada.containsKey("IdVigencia")) {
                idVigencia = intVal(parametrosEntrada.get("IdVigencia"));
            }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("fechaCorte", fechaCorte);
        out.put("idVigencia", idVigencia);
        out.put("existeSnapshot", snapshotDao.existeSnapshot(idCorporativo, idVigencia, fechaCorte));
        return out;
    }

    public Map<String, String> filtrosPermitidosParaSp(int idStoredProcedure,
            Map<String, String> parametrosEntrada) {
        Map<String, String> out = new LinkedHashMap<>();
        if (parametrosEntrada == null || parametrosEntrada.isEmpty()) {
            return out;
        }
        List<Map<String, Object>> catalogo = snapshotDao.getParametrosCatalogoSp(idStoredProcedure);
        for (Map<String, Object> param : catalogo) {
            String nombre = String.valueOf(param.get("nombreParametro")).replace("@", "");
            for (Map.Entry<String, String> e : parametrosEntrada.entrySet()) {
                if (nombre.equalsIgnoreCase(e.getKey()) && e.getValue() != null && !TextUtil.isBlank(e.getValue())) {
                    out.put(nombre, e.getValue());
                }
            }
        }
        return out;
    }

    private List<Map<String, Object>> construirParametrosSnapshot(String nombreProcedimiento, int idCorporativo) {
        List<Map<String, Object>> reales = snapshotDao.getParametrosRealesProcedimiento(nombreProcedimiento);
        List<Map<String, Object>> ordered = new ArrayList<>();
        for (Map<String, Object> p : reales) {
            String nombre = String.valueOf(p.get("nombre"));
            String key = nombre.replace("@", "");
            String valor = "IdCorporativo".equalsIgnoreCase(key) ? String.valueOf(idCorporativo) : null;
            Map<String, Object> copy = new LinkedHashMap<>();
            copy.put("CESPPNombreParametro", key);
            copy.put("CESPPTipoDato", mapSqlTypeToCatalog(String.valueOf(p.get("tipo"))));
            copy.put("valor", valor);
            ordered.add(copy);
        }
        return ordered;
    }

    private String mapSqlTypeToCatalog(String sqlType) {
        if (sqlType == null || TextUtil.isBlank(sqlType)) {
            return "NVARCHAR";
        }
        switch (sqlType.toUpperCase()) {
            case "INT":
            case "BIGINT":
            case "SMALLINT":
            case "TINYINT":
            case "BIT":
                return "INT";
            case "DATE":
            case "DATETIME":
            case "DATETIME2":
            case "SMALLDATETIME":
                return "DATETIME";
            default:
                return "NVARCHAR";
        }
    }

    private LocalDateTime toLocalDateTime(Object value) {
        if (value == null) {
            return LocalDateTime.now();
        }
        if (value instanceof Timestamp) {
            return ((Timestamp) value).toLocalDateTime();
        }
        if (value instanceof java.util.Date) {
            return new Timestamp(((java.util.Date) value).getTime()).toLocalDateTime();
        }
        return parseDateTime(String.valueOf(value), LocalDateTime.now());
    }

    private LocalDateTime parseDateTime(String raw, LocalDateTime defaultValue) {
        if (raw == null || TextUtil.isBlank(raw)) {
            return defaultValue;
        }
        try {
            if (raw.length() <= 10) {
                return LocalDateTime.parse(raw + "T00:00:00");
            }
            return LocalDateTime.parse(raw.replace(" ", "T").substring(0, Math.min(19, raw.length())));
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    private int intVal(Object value) {
        if (value == null) {
            return 0;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(String.valueOf(value).trim());
    }

    private Integer intOrNull(Object value) {
        if (value == null || TextUtil.isBlank(String.valueOf(value))) {
            return null;
        }
        return intVal(value);
    }
}
