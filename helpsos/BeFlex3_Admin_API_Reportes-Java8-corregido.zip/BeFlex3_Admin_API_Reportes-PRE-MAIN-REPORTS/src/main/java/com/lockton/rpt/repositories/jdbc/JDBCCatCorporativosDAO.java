package com.lockton.rpt.repositories.jdbc;

import com.lockton.rpt.repositories.BfCatReportesCatalogSupport;
import com.lockton.rpt.repositories.ConfigIndicadorJsonSupport;
import com.lockton.rpt.repositories.ConfigIndicadoresDAO;
import com.lockton.rpt.repositories.CatCorporativosDAO;
import com.lockton.rpt.repositories.SnapshotReporteDAO;
import com.lockton.rpt.repositories.ReporteEstadisticasDAO;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.lockton.rpt.util.TextUtil;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCCatCorporativosDAO implements CatCorporativosDAO {

    private final JdbcTemplate jdbcTemplate;

    public JDBCCatCorporativosDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Map<String, Object>> listarCorporativosActivos() {
        String sql = "SELECT em.EMidEmpresa AS idCorporativo, "
                + "em.EMNombre AS nombre, "
                + "em.EMRazonSocial AS razonSocial, "
                + "em.EMEtiqueta AS etiqueta, "
                + "em.EMOrden AS orden, "
                + "em.EMidPadre AS idPadre, "
                + "em.EMidCorporativo AS idCorporativoGrupo, "
                + "CASE WHEN em.EMidPadre = 0 THEN 1 ELSE 0 END AS esRaiz "
                + "FROM dbo.ff_Empresa em "
                + "WHERE em.EMidEstatus = 1 "
                + "ORDER BY em.EMidCorporativo, em.EMidPadre, em.EMOrden, em.EMNombre, em.EMidEmpresa";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("idCorporativo", rs.getInt("idCorporativo"));
            row.put("nombre", rs.getString("nombre"));
            row.put("razonSocial", rs.getString("razonSocial"));
            row.put("etiqueta", rs.getString("etiqueta"));
            row.put("orden", rs.getInt("orden"));
            row.put("idPadre", rs.getInt("idPadre"));
            row.put("idCorporativoGrupo", rs.getInt("idCorporativoGrupo"));
            row.put("esRaiz", rs.getInt("esRaiz") == 1);
            return row;
        }).stream().map(this::normalizar).collect(Collectors.toList());
    }

    private Map<String, Object> normalizar(Map<String, Object> row) {
        Map<String, Object> out = new LinkedHashMap<>(row);
        String nombre = stringVal(row.get("nombre"));
        String razon = stringVal(row.get("razonSocial"));
        out.put("label", !TextUtil.isBlank(razon) ? razon : nombre);
        return out;
    }

    private String stringVal(Object value) {
        return value != null ? String.valueOf(value).trim() : "";
    }
}
