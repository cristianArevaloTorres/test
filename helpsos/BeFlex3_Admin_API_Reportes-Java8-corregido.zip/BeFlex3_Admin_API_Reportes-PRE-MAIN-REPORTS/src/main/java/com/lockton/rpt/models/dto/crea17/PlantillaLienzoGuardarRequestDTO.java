package com.lockton.rpt.models.dto.crea17;

import java.util.Map;

public class PlantillaLienzoGuardarRequestDTO {
    private Map<String, Object> lienzo;
    private Integer idUsuario;

    public Map<String, Object> getLienzo() { return lienzo; }
    public void setLienzo(Map<String, Object> lienzo) { this.lienzo = lienzo; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
