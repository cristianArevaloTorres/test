package com.lockton.rpt.util;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.util.LinkedCaseInsensitiveMap;

public class Excel_Encabezados {
    
    public static String generar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
                               Map<String, Object> parametros,
                               String outputDir) throws Exception {
        
        // Crear workbook
        SXSSFWorkbook wb = new SXSSFWorkbook(100);
        wb.setCompressTempFiles(true);
        
        // Obtener datos del primer resultset
        ArrayList<LinkedCaseInsensitiveMap<?>> headerRows = null;
        ArrayList<LinkedCaseInsensitiveMap<?>> dataRows = null;
        if (resultsets != null) {
            if (resultsets.size() > 0 && resultsets.get(0) != null) {
                headerRows = resultsets.get(0);
                if (!headerRows.isEmpty()) {
                }
            }
            if (resultsets.size() > 1 && resultsets.get(1) != null) {
                headerRows = resultsets.get(0) != null ? resultsets.get(0) : new ArrayList<>();
                dataRows = resultsets.get(1);
                if (!dataRows.isEmpty()) {
                }
            }
        }
        if (dataRows == null) dataRows = new ArrayList<>();
        if (headerRows == null) headerRows = new ArrayList<>();
        if (dataRows.isEmpty() && headerRows.isEmpty()) {
        }
        
        // Obtener nombre del reporte
        String reporteNombre = "Reporte";
        if (parametros != null) {
            if (parametros.containsKey("tituloReporteB1")) {
                reporteNombre = String.valueOf(parametros.get("tituloReporteB1"));
            } else if (parametros.containsKey("catReportesNombre")) {
                reporteNombre = String.valueOf(parametros.get("catReportesNombre"));
            }
        }

        // Crear nombre de hoja (máximo 31 caracteres) similar a Excel_Multiple
        String hojaNombre = limit(nombreHojaEncabezado(parametros), 31);
        
        // Crear hoja
        Sheet sh = wb.createSheet(hojaNombre);
        
        // Habilitar autosize
        if (sh instanceof SXSSFSheet) {
            ((SXSSFSheet) sh).trackAllColumnsForAutoSizing();
        }
        
        // ========== ESTILOS ==========
        // Estilo para título
        CellStyle titleStyle = wb.createCellStyle();
        Font titleFont = wb.createFont();
        titleFont.setBold(true);
        String[] colores = obtenerColores(parametros);
        aplicarColorFondo(titleStyle, colores[0]);
        aplicarColorLetra(titleFont, colores[1]);
        titleStyle.setFont(titleFont);
        
        // Estilo para encabezados de columna
        CellStyle headerStyle = crearHeaderStyle(wb, parametros);
        
        // Estilo para fechas
        CellStyle dateStyle = wb.createCellStyle();
        short dateFormat = wb.createDataFormat().getFormat("dd/MM/yyyy");
        dateStyle.setDataFormat(dateFormat);
        
        // Estilo para fechas con hora
        CellStyle datetimeStyle = wb.createCellStyle();
        short datetimeFormat = wb.createDataFormat().getFormat("dd/MM/yyyy HH:mm:ss");
        datetimeStyle.setDataFormat(datetimeFormat);
        
        // ========== ENCABEZADOS FIJOS EN BLOQUES 2x2 (SIN ESPACIOS) ==========
        int rowNum = 0;

        // Fila 1: Títulos de los encabezados
        Row titulosRow = sh.createRow(rowNum++);
        // Fila 2: Valores de los encabezados  
        Row valoresRow = sh.createRow(rowNum++);

        // Encabezados dinámicos desde el primer dataset (headerRows)
        int colNum = 0; // Empezamos en columna 0 (A)
        if (headerRows != null && !headerRows.isEmpty() && headerRows.get(0) != null) {
            LinkedCaseInsensitiveMap<?> firstHeader = headerRows.get(0);
            for (Object key : firstHeader.keySet()) {
                String titulo = String.valueOf(key);
                Object valObj = firstHeader.get(key);
                String valor = valObj == null ? "" : limpiarTexto(String.valueOf(valObj));
                crearCelda(titulosRow, colNum, titulo, titleStyle);
                crearCelda(valoresRow, colNum, valor, null);
                colNum++;
            }
        }

        // Fila 3: vacía (separación)
        //rowNum++;
        
        // ========== ENCABEZADOS DE COLUMNAS ==========
        if (dataRows != null && !dataRows.isEmpty()) {
            // Obtener nombres de columnas del primer registro
            LinkedCaseInsensitiveMap<?> firstRow = dataRows.get(0);
            List<String> columnNames = new ArrayList<>();
            
            for (Object key : firstRow.keySet()) {
                String colName = String.valueOf(key);
                columnNames.add(colName);
            }
            
            // Crear fila de encabezados
            Row headerRow = sh.createRow(rowNum++);
            
            for (int i = 0; i < columnNames.size(); i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columnNames.get(i));
                cell.setCellStyle(headerStyle);
            }
            
            // Aplicar autofiltro
            //sh.setAutoFilter(new CellRangeAddress(headerRow.getRowNum(), headerRow.getRowNum(), 0, columnNames.size() - 1));
            
            // ========== DATOS ==========
            for (LinkedCaseInsensitiveMap<?> rowData : dataRows) {
                Row dataRow = sh.createRow(rowNum++);
                
                for (int i = 0; i < columnNames.size(); i++) {
                    String colName = columnNames.get(i);
                    Object value = rowData.get(colName);
                    
                    Cell cell = dataRow.createCell(i);
                    
                    if (value == null) {
                        cell.setCellValue("");
                    } else {
                        // Intentar detectar el tipo de dato
                        String stringValue = String.valueOf(value);
                        
                        // Verificar si es fecha
                        if (esFecha(colName, stringValue)) {
                            try {
                                Date fecha = parsearFecha(stringValue);
                                cell.setCellValue(fecha);
                                cell.setCellStyle(dateStyle);
                            } catch (Exception e) {
                                cell.setCellValue(limpiarTexto(stringValue));
                            }
                        } 
                        // Verificar si es número
                        else if (esNumero(stringValue)) {
                            try {
                                double num = Double.parseDouble(stringValue.replace(",", ""));
                                cell.setCellValue(num);
                            } catch (Exception e) {
                                cell.setCellValue(limpiarTexto(stringValue));
                            }
                        } 
                        // Es texto
                        else {
                            cell.setCellValue(limpiarTexto(stringValue));
                        }
                    }
                }
            }
            
            // Ajustar ancho de columnas
            for (int i = 0; i < columnNames.size(); i++) {
                sh.autoSizeColumn(i);
                // Ancho mínimo
                if (sh.getColumnWidth(i) < 3000) {
                    sh.setColumnWidth(i, 3000);
                }
                // Ancho máximo
                if (sh.getColumnWidth(i) > 15000) {
                    sh.setColumnWidth(i, 15000);
                }
            }
        } else {
            // Sin datos
            Row emptyRow = sh.createRow(rowNum++);
            crearCelda(emptyRow, 0, "No hay datos para mostrar", titleStyle);
        }
        
        // ========== RESOLVER RUTA IGUAL QUE Excel_Hoja_Multiple ==========
        String rutaDir = outputDir;
        Object idEmpObj = parametros.get("idEmpresa");
        if (idEmpObj == null) {
            idEmpObj = String.valueOf(
                    String.valueOf(
                            parametros.getOrDefault("admIdEmpresa",
                                    String.valueOf(
                                            parametros.getOrDefault("empresas",
                                                    parametros.get("empresasIds")
                                            )
                                    )
                            )
                    )
            );
        }
        String idEmp = null;
        if (idEmpObj != null) {
            String raw = String.valueOf(idEmpObj).trim();
            raw = raw.replaceAll("[\\{\\}\\[\\]]", "");
            if (raw.contains(",")) raw = raw.split(",")[0].trim();
            String digits = raw.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) idEmp = digits;
        }

        String subFolder = sanitizarNombreCarpeta(
                String.valueOf(
                        parametros.getOrDefault(
                                "catReportesNombre",
                                parametros.getOrDefault("tituloReporteB1", nombreReportePorId(parametros))
                        )
                )
        );
        if (subFolder == null || subFolder.trim().isEmpty()) subFolder = "Reporte";

        try {
            Class<?> c = Class.forName("com.lockton.rpt.util.Constantes");
            Object v = c.getField("DOCUMENTO_EMPRESA").get(null);
            if (idEmp != null && v != null) {
                String base = String.valueOf(v);
                if (base != null && !base.trim().isEmpty()) {
                    rutaDir = base + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            }
        } catch (Throwable ignore) {
            // Ignorar y probar con variable de entorno
        }
        if (rutaDir == null || ".".equals(rutaDir) || outputDir.equals(rutaDir)) {
            try {
                String base = System.getenv("UPLOAD_FOLDER");
                if (base != null && !base.trim().isEmpty() && idEmp != null) {
                    rutaDir = base + File.separator + "DocumentoEmpresa" + File.separator + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            } catch (Throwable ignore) {
                // Si tampoco está la variable de entorno, caeremos en outputDir
            }
        }

        // ========== GUARDAR ARCHIVO ==========
        // Crear nombre de archivo
        String fileName = NombreArchivoUtil.generarNombre(
                parametros,
                reporteNombre,
                "yyyyMMdd_HHmmss",
                false, // sin sufijo idEmpresa/fileSuffix
                false, // sin caso especial Sábana
                false, // sin caso especial Costos
                true   // mantener separador "_" antes de timestamp
        );
        
        // Asegurar directorio
        File dir = new File(rutaDir);
        if (!dir.exists()) {
            boolean created = dir.mkdirs();
        }
        
        // Crear archivo
        File outputFile = new File(dir, fileName);
        
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            wb.write(fos);
        } catch (Exception e) {
            System.err.println("Error al guardar archivo: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            try {
                wb.dispose();
            } catch (Exception e) {
                System.err.println("Error al limpiar workbook: " + e.getMessage());
            }
        }
        
        return outputFile.getAbsolutePath();
    }
    
    private static void crearCelda(Row row, int col, String valor, CellStyle estilo) {
        Cell cell = row.createCell(col);
        cell.setCellValue(valor == null ? "" : valor);
        if (estilo != null) {
            cell.setCellStyle(estilo);
        }
    }

    
    private static CellStyle crearHeaderStyle(Workbook wb, Map<String, Object> parametros) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        
        // Colores por defecto
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        font.setColor(IndexedColors.BLACK.getIndex());
        
        String colorFondo = null;
        String colorLetra = null;
        
        // Intentar obtener colores de los parámetros
        if (parametros != null && parametros.containsKey("reporteConfig")) {
            try {
                Object configObj = parametros.get("reporteConfig");
                if (configObj instanceof List) {
                    List<?> configList = (List<?>) configObj;
                    if (!configList.isEmpty() && configList.get(0) instanceof Map) {
                        Map<?, ?> configMap = (Map<?, ?>) configList.get(0);
                        if (configMap.containsKey("colorFondo")) {
                            colorFondo = String.valueOf(configMap.get("colorFondo"));
                        }
                        if (configMap.containsKey("colorLetra")) {
                            colorLetra = String.valueOf(configMap.get("colorLetra"));
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("Error al parsear colores: " + e.getMessage());
            }
        }

        aplicarColorFondo(style, colorFondo);
        aplicarColorLetra(font, colorLetra);
        
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
        
        
        return style;
    }
    
    private static void aplicarColorFondo(CellStyle style, String colorFondo) {
        if (colorFondo == null || colorFondo.trim().isEmpty()) {
            return;
        }
        Short idx = colorFromName(colorFondo);
        if (idx != null) {
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            style.setFillForegroundColor(idx);
            return;
        }
        if (isHexColor(colorFondo) && style instanceof XSSFCellStyle) {
            try {
                XSSFColor xcolor = new XSSFColor(parseHexColor(colorFondo), new DefaultIndexedColorMap());
                ((XSSFCellStyle) style).setFillForegroundColor(xcolor);
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            } catch (Exception ignored) {
            }
        }
    }

    private static void aplicarColorLetra(Font font, String colorLetra) {
        if (colorLetra == null || colorLetra.trim().isEmpty()) {
            return;
        }
        Short idx = colorFromName(colorLetra);
        try {
            if (font instanceof XSSFFont) {
                Color awt = null;
                if (isHexColor(colorLetra)) {
                    awt = parseHexColor(colorLetra);
                } else if (idx != null) {
                    awt = awtFromIndexed(idx);
                }
                if (awt != null) {
                    ((XSSFFont) font).setColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
                    return;
                }
            }
        } catch (Exception ignored) {
        }
        if (idx != null) {
            font.setColor(idx);
        }
    }

    private static String[] obtenerColores(Map<String, Object> parametros) {
        String fondo = null;
        String letra = null;
        if (parametros != null && parametros.containsKey("reporteConfig")) {
            try {
                Object configObj = parametros.get("reporteConfig");
                if (configObj instanceof List) {
                    List<?> configList = (List<?>) configObj;
                    if (!configList.isEmpty() && configList.get(0) instanceof Map) {
                        Map<?, ?> configMap = (Map<?, ?>) configList.get(0);
                        if (configMap.containsKey("colorFondo")) {
                            fondo = String.valueOf(configMap.get("colorFondo"));
                        }
                        if (configMap.containsKey("colorLetra")) {
                            letra = String.valueOf(configMap.get("colorLetra"));
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("Error al obtener colores: " + e.getMessage());
            }
        }
        return new String[] { fondo, letra };
    }

    private static Short colorFromName(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        if (n.equalsIgnoreCase("Blue") || n.equalsIgnoreCase("Azul")) return IndexedColors.BLUE.getIndex();
        if (n.equalsIgnoreCase("LightBlue") || n.equalsIgnoreCase("Light_Blue") || n.equalsIgnoreCase("Celeste")) return IndexedColors.LIGHT_BLUE.getIndex();
        if (n.equalsIgnoreCase("White") || n.equalsIgnoreCase("Blanco")) return IndexedColors.WHITE.getIndex();
        if (n.equalsIgnoreCase("Black") || n.equalsIgnoreCase("Negro")) return IndexedColors.BLACK.getIndex();
        if (n.equalsIgnoreCase("Red") || n.equalsIgnoreCase("Rojo")) return IndexedColors.RED.getIndex();
        if (n.equalsIgnoreCase("Green") || n.equalsIgnoreCase("Verde")) return IndexedColors.GREEN.getIndex();
        if (n.equalsIgnoreCase("Gray") || n.equalsIgnoreCase("Grey") || n.equalsIgnoreCase("Gris")) return IndexedColors.GREY_50_PERCENT.getIndex();
        if (n.equalsIgnoreCase("Yellow") || n.equalsIgnoreCase("Amarillo")) return IndexedColors.YELLOW.getIndex();
        return null;
    }

    private static boolean isHexColor(String s) {
        if (s == null) return false;
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v.matches("(?i)^[0-9a-f]{6}$");
    }

    private static Color parseHexColor(String s) {
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        int r = Integer.parseInt(v.substring(0, 2), 16);
        int g = Integer.parseInt(v.substring(2, 4), 16);
        int b = Integer.parseInt(v.substring(4, 6), 16);
        return new Color(r, g, b);
    }

    private static Color awtFromIndexed(Short idx) {
        if (idx == null) return null;
        if (idx.equals(IndexedColors.WHITE.getIndex())) return Color.WHITE;
        if (idx.equals(IndexedColors.BLACK.getIndex())) return Color.BLACK;
        if (idx.equals(IndexedColors.RED.getIndex())) return Color.RED;
        if (idx.equals(IndexedColors.GREEN.getIndex())) return Color.GREEN;
        if (idx.equals(IndexedColors.BLUE.getIndex())) return Color.BLUE;
        if (idx.equals(IndexedColors.LIGHT_BLUE.getIndex())) return new Color(173, 216, 230);
        if (idx.equals(IndexedColors.GREY_50_PERCENT.getIndex())) return new Color(128, 128, 128);
        if (idx.equals(IndexedColors.YELLOW.getIndex())) return Color.YELLOW;
        return null;
    }
    
    private static String nombreHojaEncabezado(Map<String, Object> parametros) {
        String base = "Encabezados";
        if (parametros != null) {
            Object nom = parametros.get("tituloReporteB1");
            if (nom == null) nom = parametros.get("catReportesNombre");
            if (nom != null) base = String.valueOf(nom);
        }
        return sanitizarNombreHoja(base);
    }
    
    private static String limit(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }
    
    private static String sanitizarNombreHoja(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Reporte";
        }
        
        // Remover caracteres inválidos para nombre de hoja Excel
        String limpio = nombre.replaceAll("[\\\\/*?:\\[\\]]", " ").trim();
        
        if (limpio.isEmpty()) {
            return "Reporte";
        }
        
        return limpio;
    }
    
    private static boolean esFecha(String colName, String valor) {
        if (valor == null || valor.isEmpty()) {
            return false;
        }
        
        // Si el nombre de columna sugiere que es fecha
        String colLower = colName.toLowerCase();
        if (colLower.contains("fecha") || colLower.contains("date")) {
            return true;
        }
        
        // Patrones de fecha comunes
        String[] patronesFecha = {
            "\\d{2}/\\d{2}/\\d{4}",
            "\\d{4}-\\d{2}-\\d{2}",
            "\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}:\\d{2}",
            "\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}"
        };
        
        for (String patron : patronesFecha) {
            if (valor.matches(patron)) {
                return true;
            }
        }
        
        return false;
    }
    
    private static Date parsearFecha(String valor) {
        if (valor == null || valor.isEmpty()) {
            return null;
        }
        
        String[] formatos = {
            "dd/MM/yyyy HH:mm:ss",
            "dd/MM/yyyy",
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd",
            "MM/dd/yyyy HH:mm:ss",
            "MM/dd/yyyy"
        };
        
        for (String formato : formatos) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(formato, Locale.ROOT);
                sdf.setLenient(false);
                return sdf.parse(valor);
            } catch (Exception e) {
                // Continuar con el siguiente formato
            }
        }
        
        return null;
    }
    
    private static boolean esNumero(String valor) {
        if (valor == null || valor.isEmpty()) {
            return false;
        }
        
        try {
            // Intentar parsear como double
            String limpio = valor.replace(",", "").trim();
            Double.parseDouble(limpio);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    private static String limpiarTexto(String texto) {
        if (texto == null) {
            return "";
        }
        
        // Limitar longitud máxima de celda Excel
        if (texto.length() > 32767) {
            texto = texto.substring(0, 32767);
        }
        
        return texto;
    }

    private static String sanitizarNombreCarpeta(String s) {
        if (s == null) return null;
        String sinAcentos = quitarAcentos(s);
        String cleaned = sinAcentos.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        String upper = cleaned.equalsIgnoreCase("CON") || cleaned.equalsIgnoreCase("PRN") ||
                       cleaned.equalsIgnoreCase("AUX") || cleaned.equalsIgnoreCase("NUL") ? "Reporte" : cleaned;
        return upper.isEmpty() ? "Reporte" : upper;
    }

    private static String nombreReportePorId(Map<String, Object> parametros) {
        if (parametros == null) return "Reporte";
        Integer rid = null;
        try { Object o = parametros.get("reporteId"); if (o != null) rid = Integer.parseInt(String.valueOf(o)); } catch (Exception ignore) {}
        if (rid == null) return "Reporte";
        switch (rid) {
            case 1: return "DocPersonaliados";
            case 2: return "Poblacion";
            case 5: return "BitacoraNavegacion";
            case 8: return "CambiosCalificados";
            default: return "Reporte";
        }
    }

    private static String quitarAcentos(String s) {
        if (s == null) return null;
        String decomposed = Normalizer.normalize(s, Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }
}