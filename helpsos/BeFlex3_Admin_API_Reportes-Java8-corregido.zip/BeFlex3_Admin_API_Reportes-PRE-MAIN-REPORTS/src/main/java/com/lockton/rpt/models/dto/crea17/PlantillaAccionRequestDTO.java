package com.lockton.rpt.models.dto.crea17;

public class PlantillaAccionRequestDTO {
    private Integer idUsuario;

    public PlantillaAccionRequestDTO() {}

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
