package com.lockton.rpt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lockton.rpt.mappers.CatReportesSPMapper;
import com.lockton.rpt.models.dto.CatReportesSPDTO;
import com.lockton.rpt.models.entities.CatReportesSP;
import com.lockton.rpt.repositories.CatReportesSPRepository;

@Service
public class CatReportesSPService {
    @Autowired
    private CatReportesSPRepository repository;

    public List<CatReportesSPDTO> getAll() {
        List<CatReportesSPDTO> dtos = null;
        List<CatReportesSP> cats = repository.findAll();
        if(!cats.isEmpty())
            dtos = CatReportesSPMapper.MapperDTO(cats);
        return dtos;
    }

    public CatReportesSPDTO create(CatReportesSPDTO catReportesDTO) {
        CatReportesSP catReportes = CatReportesSPMapper.MapperEntity(catReportesDTO);
        CatReportesSP cat = repository.save(catReportes);
        return CatReportesSPMapper.MapperDTO(cat);
    }

    public boolean delete(CatReportesSPDTO catReportesDTO) {
        boolean rs = false;
        CatReportesSP catReportes = CatReportesSPMapper.MapperEntity(catReportesDTO);
        repository.delete(catReportes);
        rs = true;
        return rs;
    }

    public CatReportesSPDTO update(CatReportesSPDTO catReportesDTO) {
        CatReportesSP catReportes = CatReportesSPMapper.MapperEntity(catReportesDTO);
        CatReportesSP cat = repository.save(catReportes);
        return CatReportesSPMapper.MapperDTO(cat);
    }
}
