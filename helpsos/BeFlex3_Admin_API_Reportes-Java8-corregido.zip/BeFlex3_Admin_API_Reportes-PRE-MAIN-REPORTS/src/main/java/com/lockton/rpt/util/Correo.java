package com.lockton.rpt.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.lockton.rpt.repositories.CorreosRepository;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
public class Correo {

    private static final Log LOGGER = LogFactory.getLog(Correo.class);

    @Autowired
    CorreosRepository correosRepository;
    @Autowired
    private JavaMailSender javaMailSender;


    public Correo(CorreosRepository correosRepository, JavaMailSender javaMailSender) {
        this.correosRepository = correosRepository;
        this.javaMailSender = javaMailSender;
    }

    public void EnviarCorreo(int idUsuario, int idEmpresa, String nomAdm, String nomEmp, 
            String email, boolean generado, String nomArchivo, String cuerpoCorreo, String asuntoCorreo, String error, String token, Integer idTipoNotificacion) {
        LOGGER.info("Notificación a correo: " + email);
        String to = email;
        String cc = "";
        List<String> correos = correosRepository.GetCorreosAdmin(idEmpresa);
        String plantilla = SustitucionCuerpoCorreo(cuerpoCorreo, nomAdm, nomArchivo, nomEmp, generado, error);
        String asunto = SustitucioAsunto(asuntoCorreo, nomArchivo);
        if (correos != null) {
            for (String correo : correos) {
                cc += correo + ",";
            }
        }
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }};
            SSLContext context = SSLContext.getInstance("SSL");
            context.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(context.getSocketFactory());
            HostnameVerifier host = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            HttpsURLConnection.setDefaultHostnameVerifier(host);
            URL urlPost = new URL(Constantes.SEND_MAIL);
            HttpURLConnection con = (HttpURLConnection) urlPost.openConnection();
            con.setDoOutput(true);
            con.setInstanceFollowRedirects(false);
            con.setRequestMethod("POST");
            String boundary = "---- delimitador" + UUID.randomUUID();
            con.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            con.setUseCaches(false);
            if (token != null && !token.trim().isEmpty()) {
                con.setRequestProperty("Authorization", token);
            }
            try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                writeFormField(wr, boundary, "to", to);
                writeFormField(wr, boundary, "cc", cc);
                writeFormField(wr, boundary, "bcc", "");
                writeFormField(wr, boundary, "sujeto", asunto);
                writeFormField(wr, boundary, "plantilla", plantilla);
                writeFormField(wr, boundary, "nombreAdjunto", nomArchivo);
                writeFormField(wr, boundary, "idTipoNotificacion", idTipoNotificacion != null ? String.valueOf(idTipoNotificacion) : "");
                wr.writeBytes("--" + boundary + "--\r\n");
                wr.flush();
            }
            LOGGER.info("Enviando correo...");
            BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
        } catch (Exception e) {
            LOGGER.error("Error al enviar el correo: " + e.getMessage());
        }
    }

    public String SustitucionCuerpoCorreo(String cuerpoCorreo, String nomAdm, String nomRpt, String nomEmp, boolean generado, String error) {
        String plantilla = cuerpoCorreo;
        plantilla = plantilla.replace("{0}", generado ? "": "no");
        plantilla = plantilla.replace("{1}", nomAdm);
        plantilla = plantilla.replace("{2}", nomRpt);
        plantilla = plantilla.replace("{3}", nomEmp);
        plantilla = plantilla.replace("{4}", generado ? "": "no");
        plantilla = plantilla.replace("{5}", error);


        if(!generado)
            plantilla += "<FONT COLOR=\"black\" SIZE=\"2\" FACE=\"COSMOS\">Mensaje de error: " + error +
                         "</FONT><BR />" + 
                         "<HR NOSHADE WIDTH=\"50%\" COLOR=\"#ADA990\"><BR>";
        return plantilla;
    }

    public String SustitucioAsunto(String asuntoCorreo, String nomRpt) {
        String asunto = asuntoCorreo;
        asunto = asunto.replace("{0}", nomRpt);
        return asunto;
    }

    private void writeFormField(DataOutputStream out, String boundary, String name, String value) throws IOException {
        if (value == null) {
            value = "";
        }
        out.writeBytes("--" + boundary + "\r\n");
        out.writeBytes("Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n");
        out.write(value.getBytes(StandardCharsets.UTF_8));
        out.writeBytes("\r\n");
    }

    public void EnviarCorreo(String to, String cc, String bcc, String plantilla, String sujeto) throws IOException {
        LOGGER.info("Inicia servicio ==> CorreoService ==> EnviarCorreo... to:  " + to);
        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper;

        try {
            to = desencryptarAES_GCM(to);
            sujeto = desencryptarAES_GCM(sujeto);
            plantilla = desencryptarAES_GCM(plantilla);
        } catch (Exception e) {

        }
		
        String correos = "";
        if (cc!= null ) {
            correos = cc;
            correos = correos.trim().replaceAll(",+$", "");
        }

        try {
            helper = new MimeMessageHelper(message, true);
            helper.setFrom("beflex@mx.lockton.com");
            helper.setTo(obtenerCorreos(to));
            helper.setCc(obtenerCorreos(cc));
            helper.setBcc(obtenerCorreos(bcc));
            helper.setSubject(sujeto);
            helper.setText(plantilla, true);
            javaMailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public String encryptarAES_GCM(String text) throws Exception {
		String secretKeyHex = Constantes.KEY_AES256;
		byte[] secretKeyBytes = hexStringToByteArray(secretKeyHex);

		// Generar un IV aleatorio (12 bytes es común para GCM)
		byte[] ivBytes = new byte[12];
		SecureRandom secureRandom = new SecureRandom();
		secureRandom.nextBytes(ivBytes);

		String plainText = text;

		SecretKeySpec secretKeySpec = new SecretKeySpec(secretKeyBytes, "AES");

		int GCM_TAG_LENGTH = 128; // 128 bits es común para GCM

		Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
		GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, ivBytes);
		cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, gcmParameterSpec);

		byte[] cipherTextBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

		// Combinar el IV y el texto cifrado (IV + cipherText)
		byte[] ivAndCipherText = new byte[ivBytes.length + cipherTextBytes.length];
		System.arraycopy(ivBytes, 0, ivAndCipherText, 0, ivBytes.length);
		System.arraycopy(cipherTextBytes, 0, ivAndCipherText, ivBytes.length, cipherTextBytes.length);

		// Codificar el resultado en Base64
		String cipherTextBase64 = java.util.Base64.getEncoder().encodeToString(ivAndCipherText);
		return cipherTextBase64;
	}

	public String desencryptarAES_GCM(String text) throws Exception {
		String secretKeyHex = Constantes.KEY_AES256;
		byte[] secretKeyBytes = hexStringToByteArray(secretKeyHex);
	
		// Decodificar el texto cifrado desde Base64
		byte[] ivAndCipherText = java.util.Base64.getDecoder().decode(text);
	
		// Extraer el IV (los primeros 12 bytes)
		byte[] ivBytes = new byte[12];
		System.arraycopy(ivAndCipherText, 0, ivBytes, 0, ivBytes.length);
	
		// Extraer el texto cifrado (el resto de los bytes)
		byte[] cipherTextBytes = new byte[ivAndCipherText.length - ivBytes.length];
		System.arraycopy(ivAndCipherText, ivBytes.length, cipherTextBytes, 0, cipherTextBytes.length);
	
		SecretKeySpec secretKeySpec = new SecretKeySpec(secretKeyBytes, "AES");
	
		int GCM_TAG_LENGTH = 128; // 128 bits es común para GCM
	
		Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
		GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH, ivBytes);
		cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, gcmParameterSpec);
	
		// Desencriptar el texto
		byte[] plainTextBytes = cipher.doFinal(cipherTextBytes);
	
		// Convertir los bytes desencriptados a String
		String plainText = new String(plainTextBytes, StandardCharsets.UTF_8);
		return plainText;
	}

    public static byte[] hexStringToByteArray(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4) +
                                  Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }

    public static String[] obtenerCorreos(String cadenaCorreos) {
        // Verifica si la cadena es nula o vacía (después de quitar espacios)
        if (cadenaCorreos == null || cadenaCorreos.trim().isEmpty()) {
            return new String[0]; // retorna un arreglo vacío
        }

    // Divide la cadena por comas y limpia los espacios de cada correo
        String[] correos = cadenaCorreos.split(",");
        for (int i = 0; i < correos.length; i++) {
            correos[i] = correos[i].trim();
        }
        return correos;
    }

    public void EnviarCorreoInter(int idUsuario, int idEmpresa, String nomAdm, String nomEmp, 
            String email, boolean generado, String nomArchivo, String cuerpoCorreo, String asuntoCorreo, String error, String token) {
        LOGGER.info("Notificación a correo: " + email);
        String to = email;
        String cc = "";
        List<String> correos = null; // correosRepository.GetCorreosAdmin(idEmpresa); // null;//GetCorreosAdmin(idEmpresa);
        String plantilla = SustitucionCuerpoCorreo(cuerpoCorreo, nomAdm, nomArchivo, nomEmp, generado, error);
        String asunto = SustitucioAsunto(asuntoCorreo, nomArchivo);
        correos = new ArrayList<String>();
        for (String correo : correos) {
            cc += correo + ",";
        }
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }};
            SSLContext context = SSLContext.getInstance("SSL");
            context.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(context.getSocketFactory());
            HostnameVerifier host = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            EnviarCorreo(to, cc, "", plantilla, asunto);

        } catch (Exception e) {
            LOGGER.error("Error al enviar el correo: " + e.getMessage());
        }
    }
}