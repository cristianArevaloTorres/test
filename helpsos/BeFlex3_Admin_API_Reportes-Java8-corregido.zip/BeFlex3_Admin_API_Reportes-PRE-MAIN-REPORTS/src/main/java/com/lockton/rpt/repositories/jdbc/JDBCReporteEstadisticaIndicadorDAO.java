package com.lockton.rpt.repositories.jdbc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorDisponibilidadRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorPasoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorReplicarRequestDTO;
import com.lockton.rpt.repositories.ReporteEstadisticaIndicadorDAO;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class JDBCReporteEstadisticaIndicadorDAO implements ReporteEstadisticaIndicadorDAO {
    private final DataSource dataSource;
    private final ObjectMapper objectMapper;

    public JDBCReporteEstadisticaIndicadorDAO(
            @Qualifier("dataSourceRPT") DataSource dataSource,
            ObjectMapper objectMapper) {
        this.dataSource = dataSource;
        this.objectMapper = objectMapper;
    }

    @Override
    public Map<String, Object> obtenerCatalogos() {
        List<List<Map<String, Object>>> sets =
                call("dbo.ff_CReporteEstadisticaIndicadorCatalogos", params());
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("idiomas", resultSet(sets, 0));
        out.put("tiposVisualizacion", resultSet(sets, 1));
        out.put("rolesVisualizacion", resultSet(sets, 2));
        out.put("fuentes", resultSet(sets, 3));
        out.put("salidas", resultSet(sets, 4));
        out.put("filtrosFuente", resultSet(sets, 5));
        out.put("corporativos", resultSet(sets, 6));
        out.put("operacionesVariable", resultSet(sets, 7));
        out.put("formatosVariable", resultSet(sets, 8));
        out.put("variablesMetadata", resultSet(sets, 9));
        return out;
    }

    @Override
    public List<Map<String, Object>> listar(
            String tipo,
            Integer idCorporativo,
            boolean incluirBajas) {
        LinkedHashMap<String, Object> p = params();
        p.put("@Tipo", tipo);
        p.put("@IdCorporativo", idCorporativo);
        p.put("@IncluirBajas", Boolean.valueOf(incluirBajas));
        return firstResultSet(call("dbo.ff_CReporteEstadisticaIndicadores", p));
    }

    @Override
    public Map<String, Object> obtener(int idIndicador) {
        LinkedHashMap<String, Object> p = params();
        p.put("@IdIndicador", Integer.valueOf(idIndicador));
        List<List<Map<String, Object>>> sets =
                call("dbo.ff_CReporteEstadisticaIndicador", p);

        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("indicador", firstRow(sets, 0));
        out.put("salidas", resultSet(sets, 1));
        out.put("variables", resultSet(sets, 2));
        out.put("tokens", resultSet(sets, 3));
        out.put("textos", resultSet(sets, 4));
        out.put("textosAdicionales", resultSet(sets, 5));
        out.put("vistas", resultSet(sets, 6));
        out.put("mapeos", resultSet(sets, 7));
        out.put("mapeoTextos", resultSet(sets, 8));
        out.put("colores", resultSet(sets, 9));
        out.put("filtros", resultSet(sets, 10));
        out.put("valoresTraduccion", resultSet(sets, 11));
        out.put("disponibilidadCorporativos", resultSet(sets, 12));
        return out;
    }

    @Override
    public Map<String, Object> guardarPaso(IndicadorPasoGuardarRequestDTO request) {
        int paso = request.getPaso() == null ? 0 : request.getPaso().intValue();

        if (paso == 1) {
            Map<String, Object> config = request.getConfiguracion();
            LinkedHashMap<String, Object> p = params();
            p.put("@IdIndicador", request.getIdIndicador());
            p.put("@Tipo", request.getTipo());
            p.put("@IdCorporativo", request.getIdCorporativo());
            p.put("@Nombre", stringValue(config, "nombre"));
            p.put("@Descripcion", stringValue(config, "descripcion"));
            p.put("@IdStoredProcedure", integerValue(config, "idStoredProcedure"));
            p.put("@Orden", integerValue(config, "orden"));
            p.put("@DisponiblePlantillas", booleanValue(config, "disponiblePlantillas", true));
            p.put("@IdUsuario", request.getIdUsuario());
            return operation("dbo.ff_GReporteEstadisticaIndicadorGeneral_Seguro", p);
        }

        if (request.getIdIndicador() == null || request.getIdIndicador().intValue() <= 0) {
            throw new IllegalArgumentException(
                    "Primero debe guardarse el paso de datos generales.");
        }

        if (paso == 2) {
            return saveJsonStep(
                    "dbo.ff_GReporteEstadisticaIndicadorContenido",
                    request);
        }

        if (paso == 3) {
            return saveJsonStep(
                    "dbo.ff_GReporteEstadisticaIndicadorVistas_Seguro",
                    request);
        }

        if (paso == 4) {
            return saveJsonStep(
                    "dbo.ff_GReporteEstadisticaIndicadorFiltros",
                    request);
        }

        if (paso == 5) {
            LinkedHashMap<String, Object> p = params();
            p.put("@IdIndicador", request.getIdIndicador());
            p.put("@IdUsuario", request.getIdUsuario());
            return operation("dbo.ff_FinalizarReporteEstadisticaIndicador", p);
        }

        throw new IllegalArgumentException("El paso debe encontrarse entre 1 y 5.");
    }

    @Override
    public Map<String, Object> cambiarEstatus(
            int idIndicador,
            CambioEstatusRequestDTO request) {
        LinkedHashMap<String, Object> p = params();
        p.put("@IdIndicador", Integer.valueOf(idIndicador));
        p.put("@IdEstatus", request.getIdEstatus());
        p.put("@IdUsuario", request.getIdUsuario());
        return operation("dbo.ff_UEstatusReporteEstadisticaIndicador", p);
    }

    @Override
    public Map<String, Object> guardarDisponibilidad(
            int idIndicador,
            IndicadorDisponibilidadRequestDTO request) {
        LinkedHashMap<String, Object> p = params();
        p.put("@IdIndicador", Integer.valueOf(idIndicador));
        p.put("@Modo", request.getModo());
        p.put("@CorporativosJson", json(request.getIdsCorporativo()));
        p.put("@IdUsuario", request.getIdUsuario());
        return operation("dbo.ff_GReporteEstadisticaIndicadorDisponibilidad", p);
    }

    @Override
    public List<Map<String, Object>> listarGlobalesDisponibles(int idCorporativo) {
        LinkedHashMap<String, Object> p = params();
        p.put("@IdCorporativo", Integer.valueOf(idCorporativo));
        return firstResultSet(call(
                "dbo.ff_CReporteEstadisticaIndicadoresGlobalesDisponibles",
                p));
    }

    @Override
    public List<Map<String, Object>> replicar(
            int idCorporativo,
            IndicadorReplicarRequestDTO request) {
        LinkedHashMap<String, Object> p = params();
        p.put("@IdCorporativo", Integer.valueOf(idCorporativo));
        p.put("@IndicadoresJson", json(request.getIdsIndicadorGlobal()));
        p.put("@IdUsuario", request.getIdUsuario());
        return firstResultSet(call(
                "dbo.ff_RReporteEstadisticaIndicadoresCorporativo_Seguro",
                p));
    }

    @Override
    public Map<String, Object> validarClave(
            String tipo,
            String clave,
            Integer idRegistro,
            Integer idIndicador) {
        LinkedHashMap<String, Object> p = params();
        p.put("@Tipo", tipo);
        p.put("@Clave", clave);
        p.put("@IdRegistro", idRegistro);
        p.put("@IdIndicador", idIndicador);
        return firstRow(call(
                "dbo.ff_CValidarReporteEstadisticaIndicadorClave",
                p), 0);
    }

    @Override
    public Map<String, Object> obtenerMuestraFuente(
            int idCorporativo,
            int idStoredProcedure,
            int maxFilas) {
        LinkedHashMap<String, Object> p = params();
        p.put("@IdCorporativo", Integer.valueOf(idCorporativo));
        p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        p.put("@MaxFilas", Integer.valueOf(maxFilas));

        List<List<Map<String, Object>>> sets =
                call("dbo.ff_CReporteEstadisticaPlantillaPreview", p);

        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("contexto", firstRow(sets, 0));
        List<Map<String, Object>> rows = resultSet(sets, 1);
        if (maxFilas > 0 && rows.size() > maxFilas) {
            rows = new ArrayList<Map<String, Object>>(rows.subList(0, maxFilas));
        }
        out.put("filas", rows);
        return out;
    }

    @Override
    public List<Map<String, Object>> obtenerValoresDistintos(
            int idCorporativo,
            int idStoredProcedure,
            String columna,
            int maxValores) {
        LinkedHashMap<String, Object> p = params();
        p.put("@IdCorporativo", Integer.valueOf(idCorporativo));
        p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        p.put("@Columna", columna);
        p.put("@MaxValores", Integer.valueOf(maxValores));
        return firstResultSet(call(
                "dbo.ff_CReporteEstadisticaIndicadorValoresDistintos",
                p));
    }

    private Map<String, Object> saveJsonStep(
            String procedure,
            IndicadorPasoGuardarRequestDTO request) {
        LinkedHashMap<String, Object> p = params();
        p.put("@IdIndicador", request.getIdIndicador());
        p.put("@Json", json(request.getConfiguracion()));
        p.put("@IdUsuario", request.getIdUsuario());
        return operation(procedure, p);
    }

    private Map<String, Object> operation(
            String procedure,
            LinkedHashMap<String, Object> parameters) {
        List<List<Map<String, Object>>> sets = call(procedure, parameters);
        for (int index = sets.size() - 1; index >= 0; index--) {
            List<Map<String, Object>> rows = sets.get(index);
            if (!rows.isEmpty()) {
                return rows.get(0);
            }
        }
        return new LinkedHashMap<String, Object>();
    }

    private List<List<Map<String, Object>>> call(
            String procedure,
            LinkedHashMap<String, Object> parameters) {
        StringBuilder sql = new StringBuilder("{call ").append(procedure);
        if (!parameters.isEmpty()) {
            sql.append('(');
            for (int index = 0; index < parameters.size(); index++) {
                if (index > 0) {
                    sql.append(',');
                }
                sql.append('?');
            }
            sql.append(')');
        }
        sql.append('}');

        List<List<Map<String, Object>>> resultSets =
                new ArrayList<List<Map<String, Object>>>();

        try (Connection connection = dataSource.getConnection();
             CallableStatement statement =
                     connection.prepareCall(sql.toString())) {
            int parameterIndex = 1;
            for (Object value : parameters.values()) {
                bind(statement, parameterIndex++, value);
            }

            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet resultSet = statement.getResultSet()) {
                        resultSets.add(readRows(resultSet));
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }

        return resultSets;
    }

    private void bind(
            CallableStatement statement,
            int index,
            Object value) throws SQLException {
        if (value == null) {
            statement.setNull(index, Types.NULL);
        } else if (value instanceof Integer) {
            statement.setInt(index, ((Integer) value).intValue());
        } else if (value instanceof Long) {
            statement.setLong(index, ((Long) value).longValue());
        } else if (value instanceof Boolean) {
            statement.setBoolean(index, ((Boolean) value).booleanValue());
        } else {
            statement.setString(index, String.valueOf(value));
        }
    }

    private List<Map<String, Object>> readRows(ResultSet resultSet)
            throws SQLException {
        List<Map<String, Object>> rows =
                new ArrayList<Map<String, Object>>();
        ResultSetMetaData metadata = resultSet.getMetaData();
        int columnCount = metadata.getColumnCount();

        while (resultSet.next()) {
            Map<String, Object> row = new LinkedHashMap<String, Object>();
            for (int column = 1; column <= columnCount; column++) {
                row.put(
                        metadata.getColumnLabel(column),
                        resultSet.getObject(column));
            }
            rows.add(row);
        }

        return rows;
    }

    private List<Map<String, Object>> firstResultSet(
            List<List<Map<String, Object>>> sets) {
        return resultSet(sets, 0);
    }

    private List<Map<String, Object>> resultSet(
            List<List<Map<String, Object>>> sets,
            int index) {
        if (sets == null || index < 0 || index >= sets.size()) {
            return new ArrayList<Map<String, Object>>();
        }
        return sets.get(index);
    }

    private Map<String, Object> firstRow(
            List<List<Map<String, Object>>> sets,
            int index) {
        List<Map<String, Object>> rows = resultSet(sets, index);
        return rows.isEmpty()
                ? new LinkedHashMap<String, Object>()
                : rows.get(0);
    }

    private LinkedHashMap<String, Object> params() {
        return new LinkedHashMap<String, Object>();
    }

    private String json(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException ex) {
            throw new IllegalArgumentException(
                    "No fue posible serializar la configuración del indicador.",
                    ex);
        }
    }

    private String stringValue(Map<String, Object> map, String key) {
        Object value = map == null ? null : map.get(key);
        return value == null ? null : String.valueOf(value);
    }

    private Integer integerValue(Map<String, Object> map, String key) {
        Object value = map == null ? null : map.get(key);
        if (value == null || String.valueOf(value).trim().isEmpty()) {
            return null;
        }
        if (value instanceof Number) {
            return Integer.valueOf(((Number) value).intValue());
        }
        return Integer.valueOf(String.valueOf(value));
    }

    private Boolean booleanValue(
            Map<String, Object> map,
            String key,
            boolean fallback) {
        Object value = map == null ? null : map.get(key);
        if (value == null) {
            return Boolean.valueOf(fallback);
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        String normalized = String.valueOf(value).trim();
        return Boolean.valueOf(
                "true".equalsIgnoreCase(normalized)
                || "1".equals(normalized));
    }

    private String databaseMessage(SQLException ex) {
        SQLException cursor = ex;
        String last = ex.getMessage();
        while (cursor != null) {
            if (cursor.getMessage() != null
                    && !cursor.getMessage().trim().isEmpty()) {
                last = cursor.getMessage();
            }
            cursor = cursor.getNextException();
        }
        if (last != null
                && last.contains("UX_ff_RIVM_Vista_Rol_Salida_Activo")) {
            return "La vista ya contiene un mapeo activo para la misma combinación "
                    + "de rol y salida. Ejecuta el script BD del patch y vuelve a intentar.";
        }
        return last == null
                ? "Error al ejecutar la operación de base de datos."
                : last;
    }
}
