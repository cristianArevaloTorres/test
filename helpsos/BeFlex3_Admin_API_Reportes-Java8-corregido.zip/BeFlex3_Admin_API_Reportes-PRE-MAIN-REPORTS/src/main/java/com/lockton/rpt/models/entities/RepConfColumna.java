package com.lockton.rpt.models.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "bf_RepConf_Columna")
public class RepConfColumna {
    
    @EmbeddedId
    public RepConfColumnaPk id;

    @Column(name = "campoOrigen")
    public String campoOrigen;

    @Column(name = "encabezado")
    public String encabezado;
    
    @Column(name = "visible")
    public boolean visible;

    @Column(name = "repConfColumnaUsuarioAdd")
    public Integer repConfColumnaUsuarioAdd;

    @Column(name = "repConfColumnaUsuarioMod")
    public Integer repConfColumnaUsuarioMod;

    @Column(name = "repConfColumnaUsuarioDel")
    public Integer repConfColumnaUsuarioDel;

    @Column(name = "repConfColumnaFechaAdd")
    public LocalDateTime repConfColumnaFechaAdd;
    
    @Column(name = "repConfColumnaFechaMod")
    public LocalDateTime repConfColumnaFechaMod;
    
    @Column(name = "repConfColumnaFechaDel")
    public LocalDateTime repConfColumnaFechaDel;
}
