package com.lockton.rpt.repositories.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroAdminRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroOrdenItemDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroOrdenRequestDTO;
import com.lockton.rpt.repositories.ReporteEstadisticaFiltroAdminDAO;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCReporteEstadisticaFiltroAdminDAO implements ReporteEstadisticaFiltroAdminDAO {
    private final DataSource dataSource;
    private final JdbcTemplate jdbcTemplate;

    public JDBCReporteEstadisticaFiltroAdminDAO(@Qualifier("dataSourceRPT") DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public List<Map<String, Object>> listar(boolean incluirBajas) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IncluirBajas", Boolean.valueOf(incluirBajas));
        return first(call("dbo.ff_CReporteEstadisticaFiltrosAdmin", p));
    }

    @Override
    public Map<String, Object> obtener(int idFiltro) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdFiltro", Integer.valueOf(idFiltro));
        return firstRow(call("dbo.ff_CReporteEstadisticaFiltroAdmin", p));
    }

    @Override
    public Map<String, Object> auditoria(int idFiltro) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdFiltro", Integer.valueOf(idFiltro));
        return firstRow(call("dbo.ff_CReporteEstadisticaFiltroAuditoria", p));
    }

    @Override
    public List<Map<String, Object>> listarCampos(Integer idFiltro, boolean soloDisponibles, String tipoCampo) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdFiltro", idFiltro);
        p.put("@SoloDisponibles", Boolean.valueOf(soloDisponibles));
        p.put("@TipoCampo", tipoCampo);
        return first(call("dbo.ff_CReporteEstadisticaFiltroCampos", p));
    }

    @Override
    public Map<String, Object> sincronizarCampos(int idUsuario) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdUsuario", Integer.valueOf(idUsuario));
        return firstRow(call("dbo.ff_SReporteEstadisticaFiltroCamposHistorico", p));
    }

    @Override
    public Map<String, Object> crear(ReporteEstadisticaFiltroAdminRequestDTO request) {
        return operation("dbo.ff_IReporteEstadisticaFiltroAdmin", params(request, false, 0));
    }

    @Override
    public Map<String, Object> actualizar(int idFiltro, ReporteEstadisticaFiltroAdminRequestDTO request) {
        return operation("dbo.ff_UReporteEstadisticaFiltroAdmin", params(request, true, idFiltro));
    }

    @Override
    public Map<String, Object> reordenar(ReporteEstadisticaFiltroOrdenRequestDTO request) {
        try {
            SQLServerDataTable tvp = new SQLServerDataTable();
            tvp.addColumnMetadata("IdFiltro", Types.INTEGER);
            tvp.addColumnMetadata("Orden", Types.INTEGER);
            for (ReporteEstadisticaFiltroOrdenItemDTO item : request.getElementos()) {
                tvp.addRow(item.getIdFiltro(), item.getOrden());
            }

            SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                    .withSchemaName("dbo")
                    .withProcedureName("ff_UReporteEstadisticaFiltrosOrden")
                    .withoutProcedureColumnMetaDataAccess()
                    .declareParameters(
                            new SqlParameter("Elementos", microsoft.sql.Types.STRUCTURED,
                                    "dbo.ff_TVPReporteEstadisticaFiltroOrden"),
                            new SqlParameter("IdUsuario", Types.INTEGER));

            Map<String, Object> inMap = new LinkedHashMap<String, Object>();
            inMap.put("Elementos", tvp);
            inMap.put("IdUsuario", request.getIdUsuario());
            SqlParameterSource in = new MapSqlParameterSource(inMap);
            return firstRowFromSimpleCall(call.execute(in));
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
    }

    @Override
    public Map<String, Object> cambiarEstatus(int idFiltro, CambioEstatusRequestDTO request) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdFiltro", Integer.valueOf(idFiltro));
        p.put("@IdEstatus", request.getIdEstatus());
        p.put("@IdUsuario", request.getIdUsuario());
        return operation("dbo.ff_UEstatusReporteEstadisticaFiltroAdmin", p);
    }

    private LinkedHashMap<String, Object> params(
            ReporteEstadisticaFiltroAdminRequestDTO request,
            boolean includeId,
            int idFiltro) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        if (includeId) p.put("@IdFiltro", Integer.valueOf(idFiltro));
        p.put("@Clave", request.getClave());
        p.put("@Nombre", request.getNombre());
        p.put("@Descripcion", request.getDescripcion());
        p.put("@Orden", request.getOrden());
        p.put("@EsFiltroBase", request.getEsFiltroBase() == null ? Boolean.FALSE : request.getEsFiltroBase());
        p.put("@Observaciones", request.getObservaciones());
        p.put("@IdCampoValor", request.getIdCampoValor());
        p.put("@IdCampoTexto", request.getIdCampoTexto());
        p.put("@TipoControl", request.getTipoControl());
        p.put("@MostrarEnModulo", request.getMostrarEnModulo() == null ? Boolean.TRUE : request.getMostrarEnModulo());
        p.put("@IdUsuario", request.getIdUsuario());
        return p;
    }

    private Map<String, Object> operation(String procedure, LinkedHashMap<String, Object> parameters) {
        List<List<Map<String, Object>>> sets = call(procedure, parameters);
        for (int i = sets.size() - 1; i >= 0; i--) {
            if (!sets.get(i).isEmpty()) return sets.get(i).get(0);
        }
        return new LinkedHashMap<String, Object>();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> firstRowFromSimpleCall(Map<String, Object> result) {
        if (result == null) return new LinkedHashMap<String, Object>();
        for (Object value : result.values()) {
            if (!(value instanceof List<?>)) continue;
            List<?> rows = (List<?>) value;
            if (rows.isEmpty() || !(rows.get(0) instanceof Map<?, ?>)) continue;
            Map<?, ?> source = (Map<?, ?>) rows.get(0);
            Map<String, Object> row = new LinkedHashMap<String, Object>();
            for (Map.Entry<?, ?> entry : source.entrySet()) {
                row.put(String.valueOf(entry.getKey()), entry.getValue());
            }
            return row;
        }
        return new LinkedHashMap<String, Object>();
    }

    private List<List<Map<String, Object>>> call(String procedure, LinkedHashMap<String, Object> parameters) {
        StringBuilder sql = new StringBuilder("{call ").append(procedure);
        if (!parameters.isEmpty()) {
            sql.append('(');
            for (int i = 0; i < parameters.size(); i++) {
                if (i > 0) sql.append(',');
                sql.append('?');
            }
            sql.append(')');
        }
        sql.append('}');

        List<List<Map<String, Object>>> resultSets = new ArrayList<List<Map<String, Object>>>();
        try (Connection connection = dataSource.getConnection();
             CallableStatement statement = connection.prepareCall(sql.toString())) {
            int index = 1;
            for (Object value : parameters.values()) bind(statement, index++, value);

            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet rs = statement.getResultSet()) {
                        resultSets.add(readRows(rs));
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
        return resultSets;
    }

    private void bind(CallableStatement statement, int index, Object value) throws SQLException {
        if (value == null) {
            statement.setNull(index, Types.NULL);
        } else if (value instanceof Integer) {
            statement.setInt(index, ((Integer) value).intValue());
        } else if (value instanceof Boolean) {
            statement.setBoolean(index, ((Boolean) value).booleanValue());
        } else {
            statement.setString(index, String.valueOf(value));
        }
    }

    private List<Map<String, Object>> readRows(ResultSet rs) throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
        ResultSetMetaData md = rs.getMetaData();
        int count = md.getColumnCount();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<String, Object>();
            for (int i = 1; i <= count; i++) {
                row.put(md.getColumnLabel(i), rs.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }

    private List<Map<String, Object>> first(List<List<Map<String, Object>>> sets) {
        return sets == null || sets.isEmpty() ? new ArrayList<Map<String, Object>>() : sets.get(0);
    }

    private Map<String, Object> firstRow(List<List<Map<String, Object>>> sets) {
        List<Map<String, Object>> rows = first(sets);
        return rows.isEmpty() ? new LinkedHashMap<String, Object>() : rows.get(0);
    }

    private String databaseMessage(SQLException ex) {
        SQLException cursor = ex;
        String last = ex.getMessage();
        while (cursor != null) {
            if (cursor.getMessage() != null && !cursor.getMessage().trim().isEmpty()) last = cursor.getMessage();
            cursor = cursor.getNextException();
        }
        return last == null ? "Error al ejecutar la operación de base de datos." : last;
    }
}
