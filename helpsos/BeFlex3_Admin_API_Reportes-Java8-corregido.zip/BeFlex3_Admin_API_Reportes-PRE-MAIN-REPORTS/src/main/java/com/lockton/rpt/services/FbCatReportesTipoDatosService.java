package com.lockton.rpt.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.lockton.rpt.models.entities.CatReportesTipoDatos;
import com.lockton.rpt.repositories.CatReportesTipoDatosRepository;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FbCatReportesTipoDatosService {

    private final CatReportesTipoDatosRepository repository;

    public List<CatReportesTipoDatos> getAll() {
        return repository.findAll();
    }

    public Optional<CatReportesTipoDatos> getById(Integer id) {
        return repository.findById(id);
    }

    public CatReportesTipoDatos create(CatReportesTipoDatos entity) {
        return repository.save(entity);
    }

    public CatReportesTipoDatos update(CatReportesTipoDatos entity) {
        return repository.save(entity);
    }

    public void delete(Integer id) {
        repository.deleteById(id);
    }
}