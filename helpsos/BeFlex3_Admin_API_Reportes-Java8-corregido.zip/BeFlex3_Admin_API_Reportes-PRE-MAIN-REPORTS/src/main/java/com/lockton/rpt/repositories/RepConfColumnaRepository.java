package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lockton.rpt.models.entities.RepConfColumna;
import com.lockton.rpt.models.entities.RepConfColumnaPk;

public interface RepConfColumnaRepository extends JpaRepository<RepConfColumna, RepConfColumnaPk>{
    
}
