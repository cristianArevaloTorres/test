package com.lockton.rpt.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.data.jpa.repository.JpaRepository;

public abstract class ConfiguracionGenericService<DTO, ENTITY> {

    protected abstract JpaRepository<ENTITY, Integer> getRepository();
    protected abstract DTO toDTO(ENTITY entity);
    protected abstract ENTITY toEntity(DTO dto);

    public List<DTO> findAll() {
        return getRepository().findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public Optional<DTO> findById(Integer id) {
        return getRepository().findById(id).map(this::toDTO);
    }

    public DTO create(DTO dto) {
        ENTITY entity = toEntity(dto);
        return toDTO(getRepository().save(entity));
    }

    public DTO update(DTO dto) {
        ENTITY entity = toEntity(dto);
        return toDTO(getRepository().save(entity));
    }

    public void delete(Integer id) {
        getRepository().deleteById(id);
    }
}