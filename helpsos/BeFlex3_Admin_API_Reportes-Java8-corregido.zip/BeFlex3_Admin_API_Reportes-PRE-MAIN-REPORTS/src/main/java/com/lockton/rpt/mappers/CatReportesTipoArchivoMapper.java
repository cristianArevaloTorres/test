package com.lockton.rpt.mappers;

import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.CatReportesTipoArchivoDTO;
import com.lockton.rpt.models.entities.CatReportesTipoArchivo;

public class CatReportesTipoArchivoMapper {

    public static CatReportesTipoArchivoDTO MapperDTO(CatReportesTipoArchivo entity) {
        CatReportesTipoArchivoDTO dto = new CatReportesTipoArchivoDTO();
        dto.setCatReportesTAId(entity.getCatReportesTAId());
        dto.setCatReportesTATipo(entity.getCatReportesTATipo());
        dto.setCatReportesTADescripcion(entity.getCatReportesTADescripcion());
        return dto;
    }

    public static List<CatReportesTipoArchivoDTO> MapperDTO(List<CatReportesTipoArchivo> ent){
        return ent
            .stream()
            .map(CatReportesTipoArchivoMapper::MapperDTO)
            .collect(Collectors.toList());
    }
}
