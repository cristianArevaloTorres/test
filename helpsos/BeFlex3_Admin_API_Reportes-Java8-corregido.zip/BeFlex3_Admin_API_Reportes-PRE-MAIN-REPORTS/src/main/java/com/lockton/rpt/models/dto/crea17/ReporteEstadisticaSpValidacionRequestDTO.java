package com.lockton.rpt.models.dto.crea17;

public class ReporteEstadisticaSpValidacionRequestDTO {
    private String nombreTecnico;
    private Integer idCorporativo;
    private Integer idVigencia;
    private String fechaInicioEnrollment;
    private String fechaCorte;
    private Boolean ejecutarMuestra;
    private Integer maxFilasMuestra;
    private Integer idUsuario;

    public String getNombreTecnico() { return nombreTecnico; }
    public void setNombreTecnico(String nombreTecnico) { this.nombreTecnico = nombreTecnico; }
    public Integer getIdCorporativo() { return idCorporativo; }
    public void setIdCorporativo(Integer idCorporativo) { this.idCorporativo = idCorporativo; }
    public Integer getIdVigencia() { return idVigencia; }
    public void setIdVigencia(Integer idVigencia) { this.idVigencia = idVigencia; }
    public String getFechaInicioEnrollment() { return fechaInicioEnrollment; }
    public void setFechaInicioEnrollment(String fechaInicioEnrollment) { this.fechaInicioEnrollment = fechaInicioEnrollment; }
    public String getFechaCorte() { return fechaCorte; }
    public void setFechaCorte(String fechaCorte) { this.fechaCorte = fechaCorte; }
    public Boolean getEjecutarMuestra() { return ejecutarMuestra; }
    public void setEjecutarMuestra(Boolean ejecutarMuestra) { this.ejecutarMuestra = ejecutarMuestra; }
    public Integer getMaxFilasMuestra() { return maxFilasMuestra; }
    public void setMaxFilasMuestra(Integer maxFilasMuestra) { this.maxFilasMuestra = maxFilasMuestra; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
