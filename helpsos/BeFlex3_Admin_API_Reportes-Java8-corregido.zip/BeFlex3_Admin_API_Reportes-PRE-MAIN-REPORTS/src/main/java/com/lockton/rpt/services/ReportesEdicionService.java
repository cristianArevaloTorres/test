package com.lockton.rpt.services;

import java.time.LocalDateTime;
import java.util.List;

import com.lockton.rpt.models.dto.CatReportesParamsResp_DTO;
import com.lockton.rpt.models.dto.CatReportesRConfig_DTO;
import com.lockton.rpt.models.dto.CatReportesRSPS_DTO;
import com.lockton.rpt.models.dto.CatReportesRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesSPCreateRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesSPRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesTipoDatosResp_DTO;
import com.lockton.rpt.models.dto.ResponseGralDTO;

public interface ReportesEdicionService {
    public List<CatReportesRConfig_DTO> getCatReports();
    public List<CatReportesRConfig_DTO> setReportingEnabled(int catReportesNum);
    public ResponseGralDTO updateCatReport(CatReportesRequest_DTO catReportesRequestDTO);
    public List<CatReportesRSPS_DTO> getCatalogoSPsByIdReport(int catReportesId);
    public ResponseGralDTO turnOffCatReportSP(int catReportesSPId, int catReportesSPUsuarioDel, LocalDateTime catReportesSPFechaDel);
    public ResponseGralDTO updateReportSP(CatReportesSPRequest_DTO request);
    public List<CatReportesParamsResp_DTO> getParamsById(int catReportesSPId); 
    public List<CatReportesTipoDatosResp_DTO> getCatReportsTypeData();
    public ResponseGralDTO turnOffCatReportParam(int catReportesParamsId, int catReportesParamsUsuarioDel, LocalDateTime catReportesParamsFechaDel);
    public ResponseGralDTO updateParameter(CatReportesParamsResp_DTO parameter);
    public ResponseGralDTO createNewConfiguration(List<CatReportesSPCreateRequest_DTO> request);

}
