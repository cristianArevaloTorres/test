package com.lockton.rpt.services;

import java.time.LocalDate;
import java.util.List;

import com.lockton.rpt.models.dto.CatalogoEstatusReporteGenDTO;
import com.lockton.rpt.models.dto.ControlReporteGenDTO;
import com.lockton.rpt.models.dto.ItemReporteDTO;
import com.lockton.rpt.models.entities.VwControlReporte;

public interface ReporteSeguimientoService {

    List<ControlReporteGenDTO> getAll();
    List<VwControlReporte> buscar(Integer idEmpresa, Integer idEmpleado, Integer idRpt, Integer estatus, LocalDate fechaInicio, LocalDate fechaFinal);
    List<CatalogoEstatusReporteGenDTO> getEstatus();
    List<ItemReporteDTO> getReportes();
}
