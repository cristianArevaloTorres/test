package com.lockton.rpt.models.dto.crea17;

import java.util.List;

public class ReporteEstadisticaSpValidacionLoteRequestDTO {
    private List<Integer> idsStoredProcedure;
    private Integer idCorporativo;
    private Integer idVigencia;
    private String fechaInicioEnrollment;
    private String fechaCorte;
    private Integer idUsuario;

    public List<Integer> getIdsStoredProcedure() { return idsStoredProcedure; }
    public void setIdsStoredProcedure(List<Integer> idsStoredProcedure) { this.idsStoredProcedure = idsStoredProcedure; }
    public Integer getIdCorporativo() { return idCorporativo; }
    public void setIdCorporativo(Integer idCorporativo) { this.idCorporativo = idCorporativo; }
    public Integer getIdVigencia() { return idVigencia; }
    public void setIdVigencia(Integer idVigencia) { this.idVigencia = idVigencia; }
    public String getFechaInicioEnrollment() { return fechaInicioEnrollment; }
    public void setFechaInicioEnrollment(String fechaInicioEnrollment) { this.fechaInicioEnrollment = fechaInicioEnrollment; }
    public String getFechaCorte() { return fechaCorte; }
    public void setFechaCorte(String fechaCorte) { this.fechaCorte = fechaCorte; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
