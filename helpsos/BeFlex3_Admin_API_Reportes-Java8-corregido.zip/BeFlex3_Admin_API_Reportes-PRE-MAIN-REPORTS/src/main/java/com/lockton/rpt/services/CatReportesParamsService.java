package com.lockton.rpt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lockton.rpt.mappers.CatReportesParamsMapper;
import com.lockton.rpt.models.dto.CatReportesParamsDTO;
import com.lockton.rpt.models.entities.CatReportesParams;
import com.lockton.rpt.repositories.CatReportesParamsRepository;

@Service
public class CatReportesParamsService {

    @Autowired
    private  CatReportesParamsRepository repository;
    
    public List<CatReportesParamsDTO> getAll() {
        List<CatReportesParamsDTO> dtos = null;
        List<CatReportesParams> cats = repository.findAll();
        if(!cats.isEmpty())
            dtos = CatReportesParamsMapper.MapperDTO(cats);
        return dtos;
    }

    public CatReportesParamsDTO create(CatReportesParamsDTO catReportesDTO) {
        CatReportesParams catReportes = CatReportesParamsMapper.MapperEntity(catReportesDTO);
        CatReportesParams cat = repository.save(catReportes);
        return CatReportesParamsMapper.MapperDTO(cat);
    }

    public boolean delete(CatReportesParamsDTO catReportesDTO) {
        boolean rs = false;
        CatReportesParams catReportes = CatReportesParamsMapper.MapperEntity(catReportesDTO);
        repository.delete(catReportes);
        rs = true;
        return rs;
    }

    public CatReportesParamsDTO update(CatReportesParamsDTO catReportesDTO) {
        CatReportesParams catReportes = CatReportesParamsMapper.MapperEntity(catReportesDTO);
        CatReportesParams cat = repository.save(catReportes);
        return CatReportesParamsMapper.MapperDTO(cat);
    }
}
