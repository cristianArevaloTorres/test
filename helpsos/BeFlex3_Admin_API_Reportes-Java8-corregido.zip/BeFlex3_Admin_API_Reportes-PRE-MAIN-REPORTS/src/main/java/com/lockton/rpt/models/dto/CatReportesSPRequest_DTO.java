package com.lockton.rpt.models.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CatReportesSPRequest_DTO {
    public int catReportesSPId;	
    public int catReportesId;	
    public String catReportesSPNombre;	
    public int catReportesSPOrden;	
    public String catReportesSPDesc;	
    public int ESid;	
    public Integer catReportesSPUsuarioAdd;	
    public LocalDateTime catReportesSPFechaAdd;	
    public Integer catReportesSPUsuarioMod;	
    public LocalDateTime catReportesSPFechaMod;	
    public Integer catReportesSPUsuarioDel;	
    public LocalDateTime catReportesSPFechaDel;
    
    public int getCatReportesSPId() {
        return catReportesSPId;
    }
    public void setCatReportesSPId(int catReportesSPId) {
        this.catReportesSPId = catReportesSPId;
    }
    public int getCatReportesId() {
        return catReportesId;
    }
    public void setCatReportesId(int catReportesId) {
        this.catReportesId = catReportesId;
    }
    public String getCatReportesSPNombre() {
        return catReportesSPNombre;
    }
    public void setCatReportesSPNombre(String catReportesSPNombre) {
        this.catReportesSPNombre = catReportesSPNombre;
    }
    public int getCatReportesSPOrden() {
        return catReportesSPOrden;
    }
    public void setCatReportesSPOrden(int catReportesSPOrden) {
        this.catReportesSPOrden = catReportesSPOrden;
    }
    public String getCatReportesSPDesc() {
        return catReportesSPDesc;
    }
    public void setCatReportesSPDesc(String catReportesSPDesc) {
        this.catReportesSPDesc = catReportesSPDesc;
    }
    public int getESid() {
        return ESid;
    }
    public void setESid(int eSid) {
        ESid = eSid;
    }
    public Integer getCatReportesSPUsuarioAdd() {
        return catReportesSPUsuarioAdd;
    }
    public void setCatReportesSPUsuarioAdd(Integer catReportesSPUsuarioAdd) {
        this.catReportesSPUsuarioAdd = catReportesSPUsuarioAdd;
    }
    public LocalDateTime getCatReportesSPFechaAdd() {
        return catReportesSPFechaAdd;
    }
    public void setCatReportesSPFechaAdd(LocalDateTime catReportesSPFechaAdd) {
        this.catReportesSPFechaAdd = catReportesSPFechaAdd;
    }
    public Integer getCatReportesSPUsuarioMod() {
        return catReportesSPUsuarioMod;
    }
    public void setCatReportesSPUsuarioMod(Integer catReportesSPUsuarioMod) {
        this.catReportesSPUsuarioMod = catReportesSPUsuarioMod;
    }
    public LocalDateTime getCatReportesSPFechaMod() {
        return catReportesSPFechaMod;
    }
    public void setCatReportesSPFechaMod(LocalDateTime catReportesSPFechaMod) {
        this.catReportesSPFechaMod = catReportesSPFechaMod;
    }
    public Integer getCatReportesSPUsuarioDel() {
        return catReportesSPUsuarioDel;
    }
    public void setCatReportesSPUsuarioDel(Integer catReportesSPUsuarioDel) {
        this.catReportesSPUsuarioDel = catReportesSPUsuarioDel;
    }
    public LocalDateTime getCatReportesSPFechaDel() {
        return catReportesSPFechaDel;
    }
    public void setCatReportesSPFechaDel(LocalDateTime catReportesSPFechaDel) {
        this.catReportesSPFechaDel = catReportesSPFechaDel;
    }
}
