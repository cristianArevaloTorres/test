package com.lockton.rpt.services;

import java.util.Map;

import com.lockton.rpt.models.entities.UsuarioToken;

public interface JwtService {
    public Object validarToken(String token);

    public UsuarioToken getPayloadFromToken(String token);

    public String generarTokenUsuario(Map<String,Object> params, String tipo);

    public String getEncriptPassword(String pass);
}
