package com.lockton.rpt.repositories;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lockton.rpt.models.entities.EmpresaEntity;

public interface EmpresaRepository extends JpaRepository<EmpresaEntity, Integer> {

	//Obtiene el numero de empresa activas asociadas al corporativo	
	int countByidCorporativoAndIdEstatusEmpresaAndIdPadreNot (Integer idCorporativo, Integer status,  Integer idPadre);
	
	//Obtiene empresas Activas por Id 
	List<EmpresaEntity> findByIdEmpresaPKInAndIdEstatusEmpresaEquals(Collection<Integer> listIdEmpresas, Integer idEstatus);
}