package com.lockton.rpt.services.impl;

import java.io.IOException;

import com.lockton.rpt.services.impl.graficas.GeneroChartEngine;

import org.springframework.stereotype.Component;

@Component
public class GeneroGraficaRenderer {

    private final GeneroChartEngine chartEngine;

    public GeneroGraficaRenderer(GeneroChartEngine chartEngine) {
        this.chartEngine = chartEngine;
    }

    public String generarBase64(int hombres, int mujeres) throws IOException {
        return chartEngine.renderBase64(hombres, mujeres);
    }
}
