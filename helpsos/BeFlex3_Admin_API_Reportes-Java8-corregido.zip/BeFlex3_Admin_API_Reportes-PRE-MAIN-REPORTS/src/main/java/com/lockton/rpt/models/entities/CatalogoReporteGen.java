package com.lockton.rpt.models.entities;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "bf_CatalogoReporteGen")
public class CatalogoReporteGen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "CatRptId")
    private Long CatRptId;
    @Basic(optional = false)
    @Column(name = "CatRptNombre")
    private String CatRptNombre;
    @Basic(optional = false)
    @Column(name = "CatRptProgramado")
    private Boolean CatRptProgramado;
    @Basic(optional = false)
    @Column(name = "CatRptActivo")
    private Boolean CatRptActivo;
    @Basic(optional = true)
    @Column(name = "CatRptHorario")
    private Date CatRptHorario;
    @Basic(optional = false)
    @Column(name = "CatRptUsuarioAdd")
    private Integer CatRptUsuarioAdd;
    @Basic(optional = false)
    @Column(name = "CatRptFechaAdd")
    private Date CatRptFechaAdd;
    @Basic(optional = false)
    @Column(name = "CatRptUsuarioMod")
    private Integer CatRptUsuarioMod;
    @Basic(optional = false)
    @Column(name = "CatRptFechaMod")
    private Date CatRptFechaMod;
    @Basic(optional = false)
    @Column(name = "CatRptUsuarioDel")
    private Integer CatRptUsuarioDel;
    @Basic(optional = false)
    @Column(name = "CatRptFechaDel")
    private Date CatRptFechaDel;
}