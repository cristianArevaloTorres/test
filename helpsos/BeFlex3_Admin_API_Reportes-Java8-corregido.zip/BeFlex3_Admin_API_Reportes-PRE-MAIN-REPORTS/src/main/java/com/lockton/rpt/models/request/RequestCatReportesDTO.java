package com.lockton.rpt.models.request;

public class RequestCatReportesDTO {
    
    private int catReportesId;
    private String catReportesNombre;
    private String catReportesDesc;
    private int catReportesTAId;
    private String catReportesFormato;
    private int esid;
    private int catReportesUsuarioAdd;
    private String catReportesFechaAdd;
    private int catReportesUsuarioMod;
    private String catReportesFechaMod;
    private int catReportesUsuarioDel;
    private String catReportesFechaDel;
    private int catTipoReporteId;
    private int catTipoReporteNum;
    private int catReportesNum;

    // Getters y Setters
    public int getCatReportesId() {
        return catReportesId;
    }

    public void setCatReportesId(int catReportesId) {
        this.catReportesId = catReportesId;
    }

public int getCatReportesNum() {
        return catReportesNum;
    }

    public void setCatReportesNum(int catReportesNum) {
        this.catReportesNum = catReportesNum;
    }

public int getCatTipoReporteNum() {
        return catTipoReporteNum;
    }

    public void setCatTipoReporteNum(int catTipoReporteNum) {
        this.catTipoReporteNum = catTipoReporteNum;
    }

    public String getCatReportesNombre() {
        return catReportesNombre;
    }

    public void setCatReportesNombre(String catReportesNombre) {
        this.catReportesNombre = catReportesNombre;
    }

    public String getCatReportesDesc() {
        return catReportesDesc;
    }

    public void setCatReportesDesc(String catReportesDesc) {
        this.catReportesDesc = catReportesDesc;
    }

    public int getCatReportesTAId() {
        return catReportesTAId;
    }

    public void setCatReportesTAId(int catReportesTAId) {
        this.catReportesTAId = catReportesTAId;
    }

    public String getCatReportesFormato() {
        return catReportesFormato;
    }

    public void setCatReportesFormato(String catReportesFormato) {
        this.catReportesFormato = catReportesFormato;
    }

    public int getEsid() {
        return esid;
    }

    public void setEsid(int esid) {
        this.esid = esid;
    }

    public int getCatReportesUsuarioAdd() {
        return catReportesUsuarioAdd;
    }

    public void setCatReportesUsuarioAdd(int catReportesUsuarioAdd) {
        this.catReportesUsuarioAdd = catReportesUsuarioAdd;
    }

    public String getCatReportesFechaAdd() {
        return catReportesFechaAdd;
    }

    public void setCatReportesFechaAdd(String catReportesFechaAdd) {
        this.catReportesFechaAdd = catReportesFechaAdd;
    }

    public int getCatReportesUsuarioMod() {
        return catReportesUsuarioMod;
    }

    public void setCatReportesUsuarioMod(int catReportesUsuarioMod) {
        this.catReportesUsuarioMod = catReportesUsuarioMod;
    }

    public String getCatReportesFechaMod() {
        return catReportesFechaMod;
    }

    public void setCatReportesFechaDel(String catReportesFechaDel) {
        this.catReportesFechaDel = catReportesFechaDel;
    }

    public int getCatReportesUsuarioDel() {
        return catReportesUsuarioDel;
    }

    public void setCatReportesUsuarioDel(int catReportesUsuarioDel) {
        this.catReportesUsuarioDel = catReportesUsuarioDel;
    }

    public String getCatReportesFechaDel() {
        return catReportesFechaDel;
    }

    public void setCatReportesFechaMod(String catReportesFechaMod) {
        this.catReportesFechaMod = catReportesFechaMod;
    }

    public int getCatTipoReporteId() {
        return catTipoReporteId;
    }

    public void setCatTipoReporteId(int catTipoReporteId) {
        this.catTipoReporteId = catTipoReporteId;
    }
}
