package com.lockton.rpt.repositories;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.rpt.services.impl.IndicadorTipoCatalog;
import com.lockton.rpt.util.TextUtil;

/**
 * Parseo y proyección del JSON de FF_ConfiguracionEstadisticasIndicadorConfig / SeccionConfig.
 */
public final class ConfigIndicadorJsonSupport {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** Fila corporativa que solo persiste valores de parámetros (preview), no plantilla. */
    public static final String SCOPE_PARAMETROS = "parametros";

    private ConfigIndicadorJsonSupport() {
    }

    public static Map<String, Object> parseJson(String raw) {
        if (raw == null || TextUtil.isBlank(raw)) {
            return new LinkedHashMap<>();
        }
        try {
            return MAPPER.readValue(raw, new TypeReference<Map<String, Object>>() {});
        } catch (Exception ex) {
            return new LinkedHashMap<>();
        }
    }

    public static List<Map<String, Object>> parseTextosJson(String raw) {
        if (raw == null || TextUtil.isBlank(raw)) {
            return new ArrayList<>();
        }
        try {
            return MAPPER.readValue(raw, new TypeReference<List<Map<String, Object>>>() {});
        } catch (Exception ex) {
            return new ArrayList<>();
        }
    }

    public static String toJson(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return MAPPER.writeValueAsString(value);
        } catch (Exception ex) {
            throw new IllegalArgumentException("JSON inválido: " + ex.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> mergeIndicadorConfig(Map<String, Object> plantillaRow,
            Map<String, Object> corpRow) {
        Map<String, Object> out = new LinkedHashMap<>();
        if (plantillaRow != null) {
            out.putAll(plantillaRow);
        }
        if (corpRow == null || corpRow.isEmpty()) {
            return out;
        }
        // Solo overrides corporativos: orden, visibilidad en reporte y valores JSON.
        // Tipo, dimensiones y presentación vienen siempre de la fila plantilla (IdCorporativo NULL).
        for (String key : Arrays.asList("CEICfgOrden", "CEICfgMostrarEnReporte")) {
            if (corpRow.get(key) != null) {
                out.put(key, corpRow.get(key));
            }
        }
        Map<String, Object> plantillaJson = parseJson(str(plantillaRow, "CEICfgConfigJson"));
        Map<String, Object> corpJson = parseJson(str(corpRow, "CEICfgConfigJson"));
        Map<String, Object> mergedJson = new LinkedHashMap<>(plantillaJson);
        if (corpJson.containsKey("valores")) {
            mergedJson.put("valores", corpJson.get("valores"));
        }
        if (corpJson.containsKey("activo")) {
            mergedJson.put("activo", corpJson.get("activo"));
        }
        if (corpJson.containsKey("idsCorporativos")) {
            mergedJson.put("idsCorporativos", corpJson.get("idsCorporativos"));
        }
        out.put("CEICfgConfigJson", toJson(mergedJson));
        return out;
    }

    /** Override corporativo completo, salvo filas marcadas solo como parámetros de entrada. */
    public static Map<String, Object> resolveIndicadorConfigForRead(Map<String, Object> plantillaRow,
            Map<String, Object> corpRow, Integer idCorporativo) {
        if (idCorporativo == null || idCorporativo <= 0) {
            return plantillaRow != null ? new LinkedHashMap<>(plantillaRow) : new LinkedHashMap<>();
        }
        if (corpRow != null && !corpRow.isEmpty()) {
            if (isParametrosOnlyRow(corpRow)) {
                return mergeIndicadorConfig(plantillaRow, corpRow);
            }
            return new LinkedHashMap<>(corpRow);
        }
        return plantillaRow != null ? new LinkedHashMap<>(plantillaRow) : new LinkedHashMap<>();
    }

    public static boolean isParametrosOnlyRow(Map<String, Object> cfgRow) {
        if (cfgRow == null || cfgRow.isEmpty()) {
            return false;
        }
        Map<String, Object> json = parseJson(str(cfgRow, "CEICfgConfigJson"));
        return SCOPE_PARAMETROS.equals(String.valueOf(json.getOrDefault("scope", "")));
    }

    public static boolean isPlantillaCorporativoRow(Map<String, Object> cfgRow) {
        return cfgRow != null && !cfgRow.isEmpty() && !isParametrosOnlyRow(cfgRow);
    }

    @SuppressWarnings("unchecked")
    public static List<Map<String, Object>> expandParametrosForApi(Map<String, Object> mergedCfg,
            List<Map<String, Object>> bfParams, int idCorporativo) {
        Map<String, Object> json = parseJson(str(mergedCfg, "CEICfgConfigJson"));
        List<Map<String, Object>> stored = castList(json.get("parametros"));
        Map<Integer, Map<String, Object>> byBfId = new LinkedHashMap<>();
        for (Map<String, Object> p : stored) {
            Object idObj = p.get("idBfParam");
            if (idObj instanceof Number) {
                byBfId.put(((Number) idObj).intValue(), p);
            }
        }
        Map<String, String> valores = valoresMap(json);

        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> bp : bfParams) {
            int bfId = intVal(bp.get("CESPPidConfiguracionEstadisticasStoredProcedureParametro"));
            Map<String, Object> link = byBfId.get(bfId);
            if (link == null) {
                continue;
            }
            Map<String, Object> row = new LinkedHashMap<>(bp);
            row.put("CEIPidConfiguracionEstadisticasIndicadorParametro", link.get("linkId"));
            row.put("CEIPIdConfiguracionEstadisticasStoredProcedureParametro", bfId);
            row.put("CEIPOrigenValor", link.getOrDefault("origen", "MANUAL"));
            row.put("CEIPValorFijo", link.get("valorFijo"));
            row.put("CEIPVisible", link.getOrDefault("visible", true));
            row.put("CEIPOrden", link.getOrDefault("orden", bp.get("CESPPOrden")));
            String paramName = String.valueOf(row.get("CESPPNombreParametro"));
            if (valores.containsKey(paramName)) {
                row.put("Valor", valores.get(paramName));
            }
            out.add(row);
        }
        out.sort(Comparator.comparingInt(r -> intVal(r.get("CEIPOrden"))));
        return out;
    }

    @SuppressWarnings("unchecked")
    public static List<Map<String, Object>> expandMapeoForApi(Map<String, Object> mergedCfg) {
        Map<String, Object> json = parseJson(str(mergedCfg, "CEICfgConfigJson"));
        List<Map<String, Object>> stored = castList(json.get("mapeoSalida"));
        List<Map<String, Object>> out = new ArrayList<>();
        int idx = 0;
        for (Map<String, Object> m : stored) {
            if (Boolean.FALSE.equals(m.get("activo")) || m.get("activo") instanceof Number
                    && ((Number) m.get("activo")).intValue() == 0) {
                continue;
            }
            String col = str(m, "campoOrigen");
            if (TextUtil.isBlank(col)) {
                col = str(m, "columna");
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("CEIMidConfiguracionEstadisticasIndicadorMapeo", m.get("mapeoId") != null
                    ? m.get("mapeoId") : ++idx);
            row.put("CEIMCampoVisual", col);
            row.put("CEIMIdStoredProcedureSalida", m.get("idSalida"));
            row.put("CESPSNombreColumna", col);
            row.put("CEIMEtiqueta", m.getOrDefault("etiqueta", col));
            row.put("CEIMFormato", m.get("formato"));
            row.put("CEIMOrden", m.getOrDefault("orden", idx));
            row.put("CESPSNombreVisual", m.getOrDefault("etiqueta", col));
            out.add(row);
        }
        out.sort(Comparator.comparingInt(r -> intVal(r.get("CEIMOrden"))));
        return out;
    }

    public static Map<String, Object> buildIndicadorApiRow(Map<String, Object> catalog,
            Map<String, Object> mergedCfg, int idCorporativo) {
        Map<String, Object> out = new LinkedHashMap<>(catalog);
        if (mergedCfg == null || mergedCfg.isEmpty()) {
            out.putIfAbsent("TipoIndicadorClave", "TABLA");
            return out;
        }
        out.put("TipoIndicadorClave", IndicadorTipoCatalog.normalize(str(mergedCfg, "CEICfgTipoClave")));
        out.put("Orden", mergedCfg.get("CEICfgOrden"));
        out.put("Ancho", mergedCfg.get("CEICfgAncho"));
        out.put("Alto", mergedCfg.get("CEICfgAlto"));
        out.put("MostrarTitulo", mergedCfg.get("CEICfgMostrarTitulo"));
        out.put("MostrarLeyenda", mergedCfg.get("CEICfgMostrarLeyenda"));
        out.put("MostrarEnReporte", mergedCfg.get("CEICfgMostrarEnReporte"));
        out.put("ConfiguracionJson", str(mergedCfg, "CEICfgConfigJson"));
        out.put("IdTipoIndicador", tipoOrdinal(out.get("TipoIndicadorClave")));
        return out;
    }

    public static int tipoOrdinal(Object clave) {
        for (Map<String, Object> t : IndicadorTipoCatalog.listForApi()) {
            if (String.valueOf(t.get("CETIClave")).equals(String.valueOf(clave))) {
                return ((Number) t.get("ordinal")).intValue();
            }
        }
        return 1;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, String> valoresMap(Map<String, Object> json) {
        Object raw = json.get("valores");
        if (!(raw instanceof Map)) {
            return new LinkedHashMap<>();
        }
        Map<String, String> out = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : ((Map<String, Object>) raw).entrySet()) {
            if (e.getValue() != null) {
                out.put(e.getKey(), String.valueOf(e.getValue()));
            }
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> castList(Object raw) {
        if (!(raw instanceof List)) {
            return new ArrayList<>();
        }
        List<Map<String, Object>> out = new ArrayList<>();
        for (Object item : (List<?>) raw) {
            if (item instanceof Map) {
                out.add((Map<String, Object>) item);
            }
        }
        return out;
    }

    public static String str(Map<String, Object> map, String key) {
        if (map == null || map.get(key) == null) {
            return "";
        }
        return String.valueOf(map.get(key));
    }

    public static int intVal(Object value) {
        if (value == null) {
            return 0;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Integer> parseIdsCorporativos(String configJson) {
        Map<String, Object> json = parseJson(configJson);
        Object raw = json.get("idsCorporativos");
        if (!(raw instanceof List)) {
            return new ArrayList<>();
        }
        List<Integer> out = new ArrayList<>();
        for (Object item : (List<?>) raw) {
            if (item instanceof Number) {
                int id = ((Number) item).intValue();
                if (id > 0) {
                    out.add(id);
                }
            } else if (item != null) {
                try {
                    int id = Integer.parseInt(String.valueOf(item).trim());
                    if (id > 0) {
                        out.add(id);
                    }
                } catch (NumberFormatException ignored) {
                    // omitir valores no numéricos
                }
            }
        }
        return out;
    }

    /** Sin idsCorporativos en plantilla = aplica a todos los corporativos del rol. */
    public static boolean indicadorAplicaARol(List<Integer> idsIndicador, List<Integer> idsRol) {
        if (idsRol == null || idsRol.isEmpty()) {
            return true;
        }
        if (idsIndicador == null || idsIndicador.isEmpty()) {
            return true;
        }
        for (Integer id : idsIndicador) {
            if (id != null && idsRol.contains(id)) {
                return true;
            }
        }
        return false;
    }
}
