package com.lockton.rpt.models.dto.crea17;

import java.util.List;

public class PlantillaOrdenIndicadoresRequestDTO {
    private List<Integer> idsSeccionIndicador;
    private Integer idUsuario;

    public List<Integer> getIdsSeccionIndicador() { return idsSeccionIndicador; }
    public void setIdsSeccionIndicador(List<Integer> value) { idsSeccionIndicador = value; }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer value) { idUsuario = value; }
}
