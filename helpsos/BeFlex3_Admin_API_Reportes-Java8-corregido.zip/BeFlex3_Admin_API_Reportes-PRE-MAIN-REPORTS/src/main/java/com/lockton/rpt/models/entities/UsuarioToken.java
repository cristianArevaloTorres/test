package com.lockton.rpt.models.entities;

public class UsuarioToken {
    public String claveEmpleado;
    public int idEmpresa;
    public int exp;
    public int n;
    // Constructor, getters y setters
}
