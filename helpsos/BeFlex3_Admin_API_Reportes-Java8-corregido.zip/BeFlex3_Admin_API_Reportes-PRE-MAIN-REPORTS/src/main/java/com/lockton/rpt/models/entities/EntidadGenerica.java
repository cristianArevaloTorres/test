package com.lockton.rpt.models.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EntidadGenerica {
    @Id
    private long id;
}
