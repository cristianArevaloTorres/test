package com.lockton.rpt.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lockton.rpt.models.dto.CatReportesDTO;
import com.lockton.rpt.models.dto.CatReportesParamsResp_DTO;
import com.lockton.rpt.models.dto.CatReportesRConfig_DTO;
import com.lockton.rpt.models.dto.CatReportesRSPS_DTO;
import com.lockton.rpt.models.dto.CatReportesRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesSPCreateRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesSPRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesTipoDatosResp_DTO;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.services.ReportesEdicionService;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/beflex/reportes/edicion")
@Api(tags = "Controlador para Re-Configuración de Reportes")
public class ReportesEdicionController {
    
    private static final Log LOGGER = LogFactory.getLog(WSReportesController.class);
    
    @Autowired
    ReportesEdicionService _reportesEdicionServices;

    @GetMapping(value = "/getCatReports")
    @ApiOperation(value = "Obtener Catalogo de Reportes.",
                  notes = "")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<List<CatReportesRConfig_DTO>> getCatReports(){
        LOGGER.info("Inicia controller==> ReportesEdicionController ==> getCatReports... "); 
        return ResponseEntity.ok(this._reportesEdicionServices.getCatReports());
    }

    @PostMapping(value = "/setReportingEnabled")
    @ApiOperation(value = "Habilitar y Deshabilitar Catalogo de Reportes.",
                  notes = "")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<List<CatReportesRConfig_DTO>> setReportingEnabled(
        @RequestBody Map<String, Integer> body
    ){
        LOGGER.info("Inicia controller==> ReportesEdicionController ==> setReportingEnabled... ");
        int catReportesNum = body.get("catReportesNum");
        return ResponseEntity.ok(this._reportesEdicionServices.setReportingEnabled(catReportesNum));
    }

    @PostMapping(value = "/updateCatReport")
    @ApiOperation(value = "Actualizar Reporte Existente.", 
                  notes = "Operacion encargada Actualizar Configuraciones de un Reporte.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<ResponseGralDTO> updateCatReport(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) 
            @RequestBody CatReportesRequest_DTO catReportesRequest_DTO) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> updateCatReport... ");
        return ResponseEntity.ok().body(this._reportesEdicionServices.updateCatReport(catReportesRequest_DTO));
    }

    @GetMapping(value = "/getCatReportsSPs")
    @ApiOperation(value = "Obtener Catalogo de SP's por Id Reportes.",
                  notes = "")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<List<CatReportesRSPS_DTO>> getCatReportsSPs(
        @RequestParam int catReportesId){
        LOGGER.info("Inicia controller==> ReportesEdicionController ==> getCatReportsSPs... ");
        return ResponseEntity.ok(this._reportesEdicionServices.getCatalogoSPsByIdReport(catReportesId));
    }

    @PostMapping(value = "/turnOffCatReportSP")
    @ApiOperation(value = "Actualizar Reporte Existente.", 
                  notes = "Operacion encargada Actualizar Configuraciones de un Reporte.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<ResponseGralDTO> turnOffCatReportSP(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) 
            @RequestBody Map<String, Object> body) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> turnOffCatReportSPById... ");
        int catReportesSPId = (Integer)body.get("catReportesSPId");
        int catReportesSPUsuarioDel = (Integer)body.get("catReportesSPUsuarioDel");
        String catReportesSPFechaDel = (String)body.get("catReportesSPFechaDel").toString();
        LocalDateTime fechaBaja = OffsetDateTime.parse(catReportesSPFechaDel).toLocalDateTime();
        return ResponseEntity.ok().body(this._reportesEdicionServices.turnOffCatReportSP(catReportesSPId, catReportesSPUsuarioDel, fechaBaja));
    }

    @PostMapping(value = "/updateReportSP")
    @ApiOperation(value = "Actualizar Reporte Existente.", 
                  notes = "Operacion encargada Actualizar Configuraciones de un Reporte.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<ResponseGralDTO> updateReportSP(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) 
            @RequestBody CatReportesSPRequest_DTO request) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> turnOffCatReportSPById... ");        
        return ResponseEntity.ok().body(this._reportesEdicionServices.updateReportSP(request));
    }

    @GetMapping(value = "/getCatReportsParams")
    @ApiOperation(value = "Obtener Catalogo de SP's por Id Reportes.",
                  notes = "")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<List<CatReportesParamsResp_DTO>> getCatReportsParams(
        @RequestParam int catReportesSPId){
        LOGGER.info("Inicia controller==> ReportesEdicionController ==> getCatReportsParams... ");
        return ResponseEntity.ok(this._reportesEdicionServices.getParamsById(catReportesSPId));
    }

    @GetMapping(value = "/getCatReportsTypeData")
    @ApiOperation(value = "Obtener Catalogo de SP's por Id Reportes.",
                  notes = "")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<List<CatReportesTipoDatosResp_DTO>> getCatReportsTypeData(){
        LOGGER.info("Inicia controller==> ReportesEdicionController ==> getCatReportsTypeData... ");
        return ResponseEntity.ok(this._reportesEdicionServices.getCatReportsTypeData());
    }

    @PostMapping(value = "/turnOffCatReportParam")
    @ApiOperation(value = "Actualizar Reporte Existente.", 
                  notes = "Operacion encargada Actualizar Configuraciones de un Reporte.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<ResponseGralDTO> turnOffCatReportParam(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) 
            @RequestBody Map<String, Object> body) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> turnOffCatReportParam... ");
        int catReportesParamsId = (Integer)body.get("catReportesParamsId");
        int catReportesParamsUsuarioDel = (Integer)body.get("catReportesParamsUsuarioDel");
        String catReportesParamsFechaDel = (String)body.get("catReportesParamsFechaDel").toString();
        LocalDateTime fechaBaja = OffsetDateTime.parse(catReportesParamsFechaDel).toLocalDateTime();
        return ResponseEntity.ok().body(this._reportesEdicionServices.turnOffCatReportParam(catReportesParamsId, catReportesParamsUsuarioDel, fechaBaja));
    }

    @PostMapping(value = "/updateParameter")
    @ApiOperation(value = "Actualizar Reporte Existente.", 
                  notes = "Operacion encargada Actualizar Configuraciones de un Reporte.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<ResponseGralDTO> updateParameter(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) 
            @RequestBody CatReportesParamsResp_DTO parameter) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> updateParameter... ");
        return ResponseEntity.ok().body(this._reportesEdicionServices.updateParameter(parameter));
    }

    @PostMapping(value = "/createNewConfiguration")
    @ApiOperation(value = "Actualizar Reporte Existente.", 
                  notes = "Operacion encargada Actualizar Configuraciones de un Reporte.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<ResponseGralDTO> createNewConfiguration(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) 
            @RequestBody List<CatReportesSPCreateRequest_DTO> request) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> updateParameter... ");
        return ResponseEntity.ok().body(this._reportesEdicionServices.createNewConfiguration(request));
    }
}
