package com.lockton.rpt.models.entities;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "bf_CatReportesTipoDatos")
public class CatReportesTipoDatos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "catReportesTipoDatoId")
    private Integer catReportesTipoDatoId;

    @Column(name = "catReportesTipoDatoNombre", length = 30, nullable = false)
    private String catReportesTipoDatoNombre;

    @Column(name = "catReportesTipoDatoDesc", length = 150)
    private String catReportesTipoDatoDesc;

    @Column(name = "Esid")
    private Integer esid;

    @Column(name = "catReportesTipoDatoUsuarioAdd")
    private Integer catReportesTipoDatoUsuarioAdd;

    @Column(name = "catReportesTipoDatoFechaAdd")
    private LocalDateTime catReportesTipoDatoFechaAdd;

    @Column(name = "catReportesTipoDatoUsuarioMod")
    private Integer catReportesTipoDatoUsuarioMod;

    @Column(name = "catReportesTipoDatoFechaMod")
    private LocalDateTime catReportesTipoDatoFechaMod;

    @Column(name = "catReportesTipoDatoUsuarioDel")
    private Integer catReportesTipoDatoUsuarioDel;

    @Column(name = "catReportesTipoDatoFechaDel")
    private LocalDateTime catReportesTipoDatoFechaDel;
}