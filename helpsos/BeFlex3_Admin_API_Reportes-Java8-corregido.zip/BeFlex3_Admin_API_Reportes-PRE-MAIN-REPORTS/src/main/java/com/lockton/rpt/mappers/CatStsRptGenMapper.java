package com.lockton.rpt.mappers;

import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.CatalogoEstatusReporteGenDTO;
import com.lockton.rpt.models.entities.CatalogoEstatusReporteGen;

public class CatStsRptGenMapper {
    public static CatalogoEstatusReporteGenDTO MapperDTO(CatalogoEstatusReporteGen ent) {
        CatalogoEstatusReporteGenDTO dto = new CatalogoEstatusReporteGenDTO();
        dto.setCatERptId(ent.getCatERptId());
        dto.setCatERptNombre(ent.getCatERptNombre());
        dto.setCatERptUsuarioAdd(ent.getCatERptUsuarioAdd());
        dto.setCatERptFechaAdd(ent.getCatERptFechaAdd());
        return dto;
    }

    public static List<CatalogoEstatusReporteGenDTO> MapperDTO(List<CatalogoEstatusReporteGen> ent) {
        return ent
            .stream()
            .map(CatStsRptGenMapper::MapperDTO)
            .collect(Collectors.toList());
    }

    public static CatalogoEstatusReporteGen MapperEntity(CatalogoEstatusReporteGenDTO dto) {
        CatalogoEstatusReporteGen ent = new CatalogoEstatusReporteGen();
        ent.setCatERptId(dto.getCatERptId());
        ent.setCatERptNombre(dto.getCatERptNombre());
        ent.setCatERptUsuarioAdd(dto.getCatERptUsuarioAdd());
        ent.setCatERptFechaAdd(dto.getCatERptFechaAdd());
        return ent;
    }

    public static List<CatalogoEstatusReporteGen> MapperEntity(List<CatalogoEstatusReporteGenDTO> dto) {
        return dto
            .stream()
            .map(CatStsRptGenMapper::MapperEntity)
            .collect(Collectors.toList());
    }
}