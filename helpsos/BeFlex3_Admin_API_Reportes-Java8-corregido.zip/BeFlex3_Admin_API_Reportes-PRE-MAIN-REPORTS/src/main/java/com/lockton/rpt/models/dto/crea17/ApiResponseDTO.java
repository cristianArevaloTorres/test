package com.lockton.rpt.models.dto.crea17;

import com.lockton.rpt.util.SafeApiError;

public class ApiResponseDTO<T> {
    private String code;
    private boolean status;
    private String message;
    private String detail;
    private String error;
    private T data;

    public ApiResponseDTO() {}

    public ApiResponseDTO(String code, boolean status, String message, String detail, String error, T data) {
        this.code = code;
        this.status = status;
        this.message = status
                ? message
                : SafeApiError.sanitizeMessage(message, "No fue posible completar la operación. Intenta nuevamente.");
        // En errores, detail/error son exclusivamente de log y nunca viajan al cliente.
        this.detail = status ? detail : null;
        this.error = status ? error : null;
        this.data = status ? data : null;
    }

    public static <T> ApiResponseDTO<T> ok(String code, String message, T data) {
        return new ApiResponseDTO<T>(code, true, message, null, null, data);
    }

    public static <T> ApiResponseDTO<T> fail(String code, String message, String detail, String error) {
        // detail/error se ignoran deliberadamente para evitar exposición de infraestructura.
        return new ApiResponseDTO<T>(code, false, message, null, null, null);
    }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public boolean isStatus() { return status; }
    public void setStatus(boolean status) { this.status = status; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getDetail() { return detail; }
    public void setDetail(String detail) { this.detail = detail; }
    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
    public T getData() { return data; }
    public void setData(T data) { this.data = data; }
}
