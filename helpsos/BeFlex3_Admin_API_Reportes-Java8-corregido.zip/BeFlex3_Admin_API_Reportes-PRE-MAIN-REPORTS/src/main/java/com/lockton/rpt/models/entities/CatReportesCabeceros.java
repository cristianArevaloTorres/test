package com.lockton.rpt.models.entities;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "CatReportesCabeceros")
public class CatReportesCabeceros {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "catReportesCabecerosId")
    private Integer catReportesCabecerosId;

    @Column(name = "catReportesId", nullable = false)
    private Integer catReportesId;

    @Column(name = "catReportesCabecerosNombre", length = 50, nullable = false)
    private String catReportesCabecerosNombre;

    @Column(name = "catReportesCabecerosDesc", length = 150)
    private String catReportesCabecerosDesc;

    @Column(name = "catReportesCabecerosOrden")
    private Integer catReportesCabecerosOrden;

    @Column(name = "Esid")
    private Integer esid;

    @Column(name = "catReportesCabecerosUsuarioAdd")
    private Integer catReportesCabecerosUsuarioAdd;

    @Column(name = "catReportesCabecerosFechaAdd")
    private LocalDateTime catReportesCabecerosFechaAdd;

    @Column(name = "catReportesCabecerosUsuarioMod")
    private Integer catReportesCabecerosUsuarioMod;

    @Column(name = "catReportesCabecerosFechaMod")
    private LocalDateTime catReportesCabecerosFechaMod;
}