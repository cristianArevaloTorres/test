package com.lockton.rpt.services.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.lockton.rpt.util.TextUtil;

import org.springframework.stereotype.Service;

/**
 * Datos del reporte para composición en frontend (plantilla HTML + ECharts).
 * La generación de PDF/Excel ya no usa Python ni imágenes server-side.
 */
@Service
public class ReporteCorporativoService {

    private final ConfigIndicadoresService indicadoresService;

    public ReporteCorporativoService(ConfigIndicadoresService indicadoresService) {
        this.indicadoresService = indicadoresService;
    }

    /**
     * @deprecated Use {@link #obtenerDatosReporte(int, Map, List, Integer)} desde el frontend.
     */
    @Deprecated
    public Map<String, Object> generarReporte(int idCorporativo, String formato,
            Map<String, String> parametros) {
        return generarReporte(idCorporativo, formato, parametros, null, null);
    }

    @Deprecated
    public Map<String, Object> generarReporte(int idCorporativo, String formato,
            Map<String, String> parametros, List<Integer> idCorporativosRol) {
        return generarReporte(idCorporativo, formato, parametros, idCorporativosRol, null);
    }

    @Deprecated
    public Map<String, Object> generarReporte(int idCorporativo, String formato,
            Map<String, String> parametros, List<Integer> idCorporativosRol, Integer idSeccion) {
        String fmt = normalizeFormatoLegacy(formato);
        if ("datos".equals(fmt) || "html".equals(fmt)) {
            return obtenerDatosReporte(idCorporativo, parametros, idCorporativosRol, idSeccion);
        }
        throw new IllegalArgumentException(
                "La exportación a " + fmt + " se realiza en el navegador (PDF/Excel). "
                        + "Use el botón Exportar del preview corporativo.");
    }

    public Map<String, Object> obtenerDatosReporte(int idCorporativo, Map<String, String> parametros,
            List<Integer> idCorporativosRol, Integer idSeccion) {
        if (idCorporativosRol == null || idCorporativosRol.isEmpty()) {
            throw new IllegalArgumentException(
                    "Se requiere idCorporativosRol para filtrar indicadores del reporte.");
        }
        if (idCorporativo <= 0) {
            throw new IllegalArgumentException(
                    "Indique IdCorporativo en los parámetros del reporte para consultar los datos.");
        }

        Integer idSeccionFiltro = (idSeccion != null && idSeccion > 0) ? idSeccion : null;
        Map<String, Object> payload = construirPayloadReporte(idCorporativo, parametros, idCorporativosRol,
                idSeccionFiltro);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> seccionesPayload = (List<Map<String, Object>>) payload.get("secciones");

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("formato", "datos");
        out.put("idCorporativo", idCorporativo);
        out.put("titulo", payload.get("titulo"));
        out.put("seccionesIncluidas", seccionesPayload.size());
        out.put("incluirPortadasSeccion", payload.get("incluirPortadasSeccion"));
        out.put("fechaGeneracion", LocalDate.now().toString());
        out.put("secciones", seccionesPayload);
        return out;
    }

    private Map<String, Object> construirPayloadReporte(int idCorporativo, Map<String, String> parametros,
            List<Integer> idCorporativosRol, Integer idSeccionFiltro) {
        List<Map<String, Object>> seccionesRaw = indicadoresService.listarSecciones(idCorporativosRol);
        List<Map<String, Object>> seccionesPayload = new ArrayList<>();
        String tituloSeccionFiltro = null;
        if (idSeccionFiltro != null) {
            tituloSeccionFiltro = seccionesRaw.stream()
                    .filter(s -> intVal(s.get("CESidConfiguracionEstadisticasSeccion"), 0) == idSeccionFiltro)
                    .map(s -> String.valueOf(s.get("CESNombre")))
                    .findFirst()
                    .orElse(null);
        }

        seccionesRaw.stream()
                .sorted(Comparator.comparingInt(s -> intVal(s.get("Orden"), 999)))
                .forEach(seccion -> {
                    int idSeccionActual = intVal(seccion.get("CESidConfiguracionEstadisticasSeccion"), 0);
                    if (idSeccionActual <= 0) {
                        return;
                    }
                    if (idSeccionFiltro != null && idSeccionActual != idSeccionFiltro) {
                        return;
                    }
                    List<Map<String, Object>> indicadoresPayload = new ArrayList<>();
                    indicadoresService.listarIndicadores(idSeccionActual, idCorporativosRol)
                            .forEach(ind -> {
                                int idInd = intVal(ind.get("CEIidConfiguracionEstadisticasIndicador"), 0);
                                if (idInd <= 0) {
                                    return;
                                }
                                try {
                                    Map<String, Object> preview = indicadoresService.preview(
                                            idCorporativo, idInd, parametros);
                                    indicadoresPayload.add(construirIndicadorDatos(preview, ind));
                                } catch (Exception ex) {
                                    Map<String, Object> errInd = new LinkedHashMap<>();
                                    errInd.put("id", String.valueOf(idInd));
                                    errInd.put("nombre", ind.get("CEINombre"));
                                    errInd.put("tipo", ind.get("TipoIndicadorClave"));
                                    errInd.put("mostrarTitulo", boolOrDefault(metaVal(ind, "MostrarTitulo", "CEIMostrarTitulo"), true));
                                    errInd.put("ancho", metaVal(ind, "Ancho", "CEIAncho", "CEICfgAncho"));
                                    errInd.put("alto", metaVal(ind, "Alto", "CEIAlto", "CEICfgAlto"));
                                    errInd.put("error", ex.getMessage());
                                    errInd.put("elemento", elementoError(ex.getMessage()));
                                    indicadoresPayload.add(errInd);
                                }
                            });

                    if (indicadoresPayload.isEmpty()) {
                        return;
                    }

                    Map<String, Object> secPayload = new LinkedHashMap<>();
                    secPayload.put("idSeccion", idSeccionActual);
                    secPayload.put("titulo", seccion.get("CESNombre"));
                    secPayload.put("descripcion", seccion.get("CESDescripcion"));
                    secPayload.put("notas", seccion.get("CESTextoAdicional"));
                    secPayload.put("indicadores", indicadoresPayload);
                    seccionesPayload.add(secPayload);
                });

        if (seccionesPayload.isEmpty()) {
            if (idSeccionFiltro != null) {
                throw new IllegalArgumentException(
                        "La sección indicada no tiene indicadores visibles para los corporativos del rol.");
            }
            throw new IllegalArgumentException(
                    "No hay secciones con indicadores visibles para los corporativos del rol.");
        }

        String tituloReporte = "Reporte estadístico — Corporativo " + idCorporativo;
        if (idSeccionFiltro != null && tituloSeccionFiltro != null) {
            tituloReporte = "Reporte estadístico — " + tituloSeccionFiltro;
        }

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("titulo", tituloReporte);
        payload.put("idCorporativo", idCorporativo);
        payload.put("secciones", seccionesPayload);
        payload.put("incluirPortadasSeccion", idSeccionFiltro == null);
        return payload;
    }

    private Map<String, Object> construirIndicadorDatos(Map<String, Object> preview,
            Map<String, Object> indMeta) {
        Map<String, Object> block = new LinkedHashMap<>();
        block.put("id", String.valueOf(preview.get("idIndicador")));
        block.put("nombre", preview.get("nombre"));
        block.put("clave", preview.get("clave"));
        block.put("tipo", preview.get("tipoIndicadorClave"));
        block.put("mostrarTitulo", boolOrDefault(metaVal(indMeta, "MostrarTitulo", "CEIMostrarTitulo"), true));
        block.put("mostrarLeyenda", boolOrDefault(metaVal(indMeta, "MostrarLeyenda", "CEIMostrarLeyenda"), true));
        block.put("ancho", metaVal(indMeta, "Ancho", "CEIAncho", "CEICfgAncho"));
        block.put("alto", metaVal(indMeta, "Alto", "CEIAlto", "CEICfgAlto"));
        block.put("elemento", preview.get("elemento"));
        block.put("chartConfig", preview.get("chartConfig"));
        if (preview.get("graficaError") != null) {
            block.put("errorGrafica", preview.get("graficaError"));
        }
        return block;
    }

    private Object metaVal(Map<String, Object> indMeta, String... keys) {
        if (indMeta == null) {
            return null;
        }
        for (String key : keys) {
            Object val = indMeta.get(key);
            if (val != null && !String.valueOf(val).trim().isEmpty()) {
                return val;
            }
        }
        return null;
    }

    private Map<String, Object> elementoError(String mensaje) {
        Map<String, Object> elemento = new LinkedHashMap<>();
        elemento.put("tipo", "TABLA");
        elemento.put("sinMapeo", true);
        elemento.put("mensaje", mensaje);
        elemento.put("filas", Collections.emptyList());
        return elemento;
    }

    private String normalizeFormatoLegacy(String formato) {
        if (formato == null || TextUtil.isBlank(formato)) {
            return "datos";
        }
        String f = formato.trim().toLowerCase();
        if (f.equals("datos") || f.equals("json")) {
            return "datos";
        }
        if (f.equals("html") || f.equals("htm")) {
            return "html";
        }
        if (f.equals("xlsx") || f.equals("xls") || f.equals("excel")) {
            return "excel";
        }
        if (f.equals("pdf")) {
            return "pdf";
        }
        if (f.equals("pptx") || f.equals("ppt") || f.equals("powerpoint")) {
            return "powerpoint";
        }
        if (f.equals("docx") || f.equals("doc") || f.equals("word")) {
            return "word";
        }
        throw new IllegalArgumentException("Formato no soportado: " + formato);
    }

    private int intVal(Object value, int defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return defaultValue;
        }
    }

    private boolean boolOrDefault(Object value, boolean defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }
}
