package com.lockton.rpt.repositories.jdbc;

import com.lockton.rpt.repositories.BfCatReportesCatalogSupport;
import com.lockton.rpt.repositories.ConfigIndicadorJsonSupport;
import com.lockton.rpt.repositories.ConfigIndicadoresDAO;
import com.lockton.rpt.repositories.CatCorporativosDAO;
import com.lockton.rpt.repositories.SnapshotReporteDAO;
import com.lockton.rpt.repositories.ReporteEstadisticasDAO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.lockton.rpt.util.TextUtil;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCConfigIndicadores implements ConfigIndicadoresDAO {

    private final JdbcTemplate jdbcTemplate;

    public JDBCConfigIndicadores(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Map<String, Object>> getSecciones(Integer idCorporativo) {
        List<Map<String, Object>> rows = jdbcTemplate.query(
                connection -> {
                    CallableStatement cs = connection.prepareCall("{call FF_ListConfiguracionEstadisticasSecciones(?)}");
                    setNullableInt(cs, 1, idCorporativo);
                    return cs;
                },
                (rs, rowNum) -> mapRow(rs));
        for (Map<String, Object> row : rows) {
            row.putIfAbsent("CESidConfiguracionEstadisticasSeccion", row.get("CESidConfiguracionEstadisticasSeccion"));
            row.put("CESOrden", row.get("Orden"));
            row.put("CESMostrarEnReporte", row.get("MostrarEnReporte"));
            row.put("CESTextoAdicional", row.get("CESTextoAdicional"));
        }
        return rows;
    }

    @Override
    public List<Map<String, Object>> getIndicadores(Integer idCorporativo, int idSeccion) {
        List<Map<String, Object>> rows = jdbcTemplate.query(
                connection -> {
                    CallableStatement cs = connection.prepareCall(
                            "{call FF_ListConfiguracionEstadisticasIndicadores(?, ?)}");
                    cs.setInt(1, idSeccion);
                    setNullableInt(cs, 2, idCorporativo);
                    return cs;
                },
                (rs, rowNum) -> mapRow(rs));
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            row.put("CEINombre", row.get("CEINombre"));
            row.put("CEIidConfiguracionEstadisticasIndicador",
                    row.get("CEIidConfiguracionEstadisticasIndicador"));
            out.add(enrichIndicadorSpFields(row));
        }
        return out;
    }

    @Override
    public List<Integer> getIndicadorIdsCorporativosPlantilla(int idIndicador) {
        List<Map<String, Object>> rows = jdbcTemplate.query(
                "SELECT CEICfgConfigJson "
                        + "FROM dbo.FF_ConfiguracionEstadisticasIndicadorConfig "
                        + "WHERE CEICfgIdConfiguracionEstadisticasIndicador = ? "
                        + "AND CEICfgIdCorporativo IS NULL AND CEICfgIdEstatus = 1",
                (rs, rowNum) -> mapRow(rs),
                idIndicador);
        if (rows.isEmpty()) {
            return new ArrayList<>();
        }
        Object json = rows.get(0).get("CEICfgConfigJson");
        return ConfigIndicadorJsonSupport.parseIdsCorporativos(
                json != null ? String.valueOf(json) : null);
    }

    @Override
    public Map<String, Object> getIndicadorDetalle(Integer idCorporativo, int idIndicador) {
        Map<String, Object> catalog = getIndicadorCatalogRow(idIndicador);
        if (catalog.isEmpty()) {
            return new LinkedHashMap<>();
        }
        Map<String, Object> plantillaCfg = getIndicadorConfigRow(idIndicador, null);
        Map<String, Object> corporativoCfg = idCorporativo == null
                ? new LinkedHashMap<>()
                : getIndicadorConfigRow(idIndicador, idCorporativo);
        Map<String, Object> merged = ConfigIndicadorJsonSupport.resolveIndicadorConfigForRead(
                plantillaCfg, corporativoCfg, idCorporativo);
        Map<String, Object> out = ConfigIndicadorJsonSupport.buildIndicadorApiRow(
                catalog,
                merged,
                idCorporativo != null ? idCorporativo : 0);
        return enrichIndicadorSpFields(out);
    }

    @Override
    public List<Map<String, Object>> getIndicadorParametros(Integer idCorporativo, int idIndicador) {
        Map<String, Object> mergedCfg = getMergedIndicadorConfig(idIndicador, idCorporativo);
        int idStoredProcedure = getIndicadorStoredProcedureId(idIndicador);
        if (idStoredProcedure <= 0) {
            return new ArrayList<>();
        }
        List<Map<String, Object>> bfParams = getStoredProcedureParametros(idStoredProcedure);
        return ConfigIndicadorJsonSupport.expandParametrosForApi(
                mergedCfg,
                bfParams,
                idCorporativo != null ? idCorporativo : 0);
    }

    @Override
    public List<Map<String, Object>> getIndicadorMapeo(Integer idCorporativo, int idIndicador) {
        Map<String, Object> mergedCfg = getMergedIndicadorConfig(idIndicador, idCorporativo);
        return ConfigIndicadorJsonSupport.expandMapeoForApi(mergedCfg);
    }

    @Override
    public List<List<Map<String, Object>>> ejecutarStoredProcedure(
            String nombreProcedimiento,
            List<Map<String, Object>> parametrosOrdenados) {
        String proc = nombreProcedimiento.replace("dbo.", "");
        int paramCount = parametrosOrdenados.size();
        String placeholders = paramCount == 0 ? "" : String.join(", ", Collections.nCopies(paramCount, "?"));
        String callSql = "{call " + proc + "(" + placeholders + ")}";

        return jdbcTemplate.execute((Connection con) -> {
            CallableStatement cs = con.prepareCall(callSql);
            for (int i = 0; i < paramCount; i++) {
                Map<String, Object> p = parametrosOrdenados.get(i);
                String tipo = String.valueOf(p.getOrDefault("CESPPTipoDato", "NVARCHAR"));
                String valor = p.get("valor") != null ? String.valueOf(p.get("valor")) : null;
                int idx = i + 1;
                if ("INT".equalsIgnoreCase(tipo)) {
                    if (valor == null || TextUtil.isBlank(valor)) {
                        cs.setNull(idx, Types.INTEGER);
                    } else {
                        cs.setInt(idx, Integer.parseInt(valor.trim()));
                    }
                } else {
                    cs.setString(idx, valor);
                }
            }

            List<List<Map<String, Object>>> resultSets = new ArrayList<>();
            if (paramCount == 0) {
                ResultSet rs = cs.executeQuery();
                resultSets.add(readAllRows(rs));
                return resultSets;
            }

            boolean more = cs.execute();
            while (more) {
                ResultSet rs = cs.getResultSet();
                if (rs != null) {
                    resultSets.add(readAllRows(rs));
                }
                more = cs.getMoreResults();
            }
            if (resultSets.isEmpty()) {
                resultSets.add(new ArrayList<>());
            }
            return resultSets;
        });
    }

    @Override
    public int saveCorporativoParametrosValores(int idCorporativo, int idIndicador,
            Map<String, String> valores, int idUsuario, String nombreUsuario) {
        Map<String, Object> plantillaCfg = getIndicadorConfigRow(idIndicador, null);
        Map<String, Object> corporativoCfg = getIndicadorConfigRow(idIndicador, idCorporativo);
        Map<String, Object> jsonBase = corporativoCfg.isEmpty()
                ? new LinkedHashMap<>()
                : ConfigIndicadorJsonSupport.parseJson(
                        ConfigIndicadorJsonSupport.str(corporativoCfg, "CEICfgConfigJson"));
        Map<String, Object> mergedJson = new LinkedHashMap<>(jsonBase);

        Map<String, Object> mergedValores = new LinkedHashMap<>();
        Object existing = mergedJson.get("valores");
        if (existing instanceof Map<?, ?>) {
            for (Map.Entry<?, ?> e : ((Map<?, ?>) existing).entrySet()) {
                if (e.getKey() != null && e.getValue() != null) {
                    mergedValores.put(String.valueOf(e.getKey()), e.getValue());
                }
            }
        }
        if (valores != null) {
            for (Map.Entry<String, String> e : valores.entrySet()) {
                if (e.getKey() != null) {
                    mergedValores.put(e.getKey(), e.getValue());
                }
            }
        }
        mergedJson.put("valores", mergedValores);

        if (corporativoCfg.isEmpty()
                || ConfigIndicadorJsonSupport.isParametrosOnlyRow(corporativoCfg)) {
            mergedJson.put("scope", ConfigIndicadorJsonSupport.SCOPE_PARAMETROS);
            Map<String, Object> presentacion = plantillaCfg.isEmpty() ? corporativoCfg : plantillaCfg;
            return saveIndicadorConfig(
                    idIndicador,
                    idCorporativo,
                    defaultIfBlank(ConfigIndicadorJsonSupport.str(presentacion, "CEICfgTipoClave"), "TABLA"),
                    ConfigIndicadorJsonSupport.intVal(presentacion.get("CEICfgOrden")),
                    nullableInt(presentacion.get("CEICfgAncho")),
                    nullableInt(presentacion.get("CEICfgAlto")),
                    boolVal(presentacion.get("CEICfgMostrarTitulo")),
                    boolVal(presentacion.get("CEICfgMostrarLeyenda")),
                    boolVal(presentacion.get("CEICfgMostrarEnReporte")),
                    ConfigIndicadorJsonSupport.toJson(mergedJson),
                    idUsuario,
                    nombreUsuario);
        }

        mergedJson.remove("scope");
        return saveIndicadorConfig(
                idIndicador,
                idCorporativo,
                defaultIfBlank(ConfigIndicadorJsonSupport.str(corporativoCfg, "CEICfgTipoClave"), "TABLA"),
                ConfigIndicadorJsonSupport.intVal(corporativoCfg.get("CEICfgOrden")),
                nullableInt(corporativoCfg.get("CEICfgAncho")),
                nullableInt(corporativoCfg.get("CEICfgAlto")),
                boolVal(corporativoCfg.get("CEICfgMostrarTitulo")),
                boolVal(corporativoCfg.get("CEICfgMostrarLeyenda")),
                boolVal(corporativoCfg.get("CEICfgMostrarEnReporte")),
                ConfigIndicadorJsonSupport.toJson(mergedJson),
                idUsuario,
                nombreUsuario);
    }

    @Override
    public List<Map<String, Object>> getParametrosReporte(int idCorporativo,
            List<Map<String, Object>> indicadoresVisibles) {
        List<Map<String, Object>> indicadores = indicadoresVisibles != null
                ? indicadoresVisibles
                : new ArrayList<>();
        Map<String, Map<String, Object>> agregados = new LinkedHashMap<>();

        for (Map<String, Object> indicador : indicadores) {
            int idIndicador = ConfigIndicadorJsonSupport.intVal(indicador.get("IdIndicador"));
            int ordenIndicador = ConfigIndicadorJsonSupport.intVal(indicador.get("OrdenIndicador"));
            List<Map<String, Object>> parametros = getIndicadorParametros(idCorporativo, idIndicador);
            for (Map<String, Object> param : parametros) {
                String origen = String.valueOf(param.getOrDefault("CEIPOrigenValor", "")).toUpperCase(Locale.ROOT);
                if (!"MANUAL".equals(origen) && !"SESION".equals(origen)) {
                    continue;
                }
                if (!boolVal(param.get("CEIPVisible"))) {
                    continue;
                }
                String nombreParam = String.valueOf(param.getOrDefault("CESPPNombreParametro", "")).trim();
                if (nombreParam.isEmpty()) {
                    continue;
                }
                Map<String, Object> bucket = agregados.computeIfAbsent(nombreParam, k -> {
                    Map<String, Object> b = new LinkedHashMap<>();
                    b.put("CESPPNombreParametro", nombreParam);
                    b.put("CESPPNombreVisual", param.get("CESPPNombreVisual"));
                    b.put("CESPPTipoDato", param.get("CESPPTipoDato"));
                    b.put("Orden", orderValue(param, ordenIndicador));
                    b.put("Visible", 1);
                    b.put("Valor", param.get("Valor"));
                    return b;
                });

                int ordenActual = ConfigIndicadorJsonSupport.intVal(bucket.get("Orden"));
                int ordenNuevo = orderValue(param, ordenIndicador);
                if (ordenNuevo < ordenActual || ordenActual == 0) {
                    bucket.put("Orden", ordenNuevo);
                }
                if (isBlank(bucket.get("CESPPNombreVisual")) && !isBlank(param.get("CESPPNombreVisual"))) {
                    bucket.put("CESPPNombreVisual", param.get("CESPPNombreVisual"));
                }
                if (isBlank(bucket.get("CESPPTipoDato")) && !isBlank(param.get("CESPPTipoDato"))) {
                    bucket.put("CESPPTipoDato", param.get("CESPPTipoDato"));
                }
                if (isBlank(bucket.get("Valor")) && !isBlank(param.get("Valor"))) {
                    bucket.put("Valor", param.get("Valor"));
                }
            }
        }

        List<Map<String, Object>> out = new ArrayList<>(agregados.values());
        out.sort(Comparator.comparingInt(r -> ConfigIndicadorJsonSupport.intVal(r.get("Orden"))));
        return out;
    }

    @Override
    public List<Map<String, Object>> getParametroBindingsCorporativo(int idCorporativo,
            List<Map<String, Object>> indicadoresVisibles) {
        List<Map<String, Object>> indicadores = indicadoresVisibles != null
                ? indicadoresVisibles
                : new ArrayList<>();
        List<Map<String, Object>> out = new ArrayList<>();

        for (Map<String, Object> indicador : indicadores) {
            int idIndicador = ConfigIndicadorJsonSupport.intVal(indicador.get("IdIndicador"));
            List<Map<String, Object>> parametros = getIndicadorParametros(idCorporativo, idIndicador);
            for (Map<String, Object> param : parametros) {
                String origen = String.valueOf(param.getOrDefault("CEIPOrigenValor", "")).toUpperCase(Locale.ROOT);
                if (!"MANUAL".equals(origen) && !"SESION".equals(origen)) {
                    continue;
                }
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("IdIndicador", idIndicador);
                row.put("IdStoredProcedureParametro", param.get("CEIPIdConfiguracionEstadisticasStoredProcedureParametro"));
                row.put("CESPPNombreParametro", param.get("CESPPNombreParametro"));
                row.put("IdValor", null);
                row.put("OrdenIndicador", indicador.get("OrdenIndicador"));
                row.put("OrdenParametro", param.get("CEIPOrden"));
                out.add(row);
            }
        }
        out.sort(Comparator
                .comparing((Map<String, Object> r) -> String.valueOf(r.getOrDefault("CESPPNombreParametro", "")))
                .thenComparingInt(r -> ConfigIndicadorJsonSupport.intVal(r.get("OrdenIndicador")))
                .thenComparingInt(r -> ConfigIndicadorJsonSupport.intVal(r.get("OrdenParametro"))));
        for (Map<String, Object> row : out) {
            row.remove("OrdenIndicador");
            row.remove("OrdenParametro");
        }
        return out;
    }

    @Override
    public Map<String, Object> getSeccionDetalle(int idSeccion, Integer idCorporativo) {
        List<Map<String, Object>> rows = jdbcTemplate.query(
                "SELECT S.CESidConfiguracionEstadisticasSeccion AS IdSeccion, "
                        + "S.CESClave AS Clave, S.CESNombre AS Nombre, S.CESDescripcion AS Descripcion "
                        + "FROM dbo.FF_ConfiguracionEstadisticasSecciones S "
                        + "WHERE S.CESidConfiguracionEstadisticasSeccion = ? AND S.CESIdEstatus = 1",
                (rs, rowNum) -> mapRow(rs),
                idSeccion);
        if (rows.isEmpty()) {
            return new LinkedHashMap<>();
        }

        Map<String, Object> out = new LinkedHashMap<>(rows.get(0));
        Map<String, Object> plantillaCfg = getSeccionConfigRow(idSeccion, null);
        Map<String, Object> corpCfg = idCorporativo == null
                ? new LinkedHashMap<>()
                : getSeccionConfigRow(idSeccion, idCorporativo);
        Map<String, Object> resolved = resolveSeccionConfig(plantillaCfg, corpCfg, idCorporativo);

        out.put("Orden", resolved.get("CESCfgOrden"));
        out.put("MostrarEnReporte", resolved.get("CESCfgMostrarEnReporte"));
        out.put("TextoAdicional", resolved.get("CESCfgTextoAdicional"));
        out.put("TextosJson", resolved.get("CESCfgTextosJson"));
        out.put("textos", textosForApi(resolved, idSeccion));
        out.put("indicadores", getIndicadores(idCorporativo, idSeccion));
        out.put("CESOrden", resolved.get("CESCfgOrden"));
        out.put("CESMostrarEnReporte", resolved.get("CESCfgMostrarEnReporte"));
        out.put("CESTextoAdicional", resolved.get("CESCfgTextoAdicional"));
        out.put("CESidConfiguracionEstadisticasSeccion", idSeccion);
        out.put("CESClave", out.get("Clave"));
        out.put("CESNombre", out.get("Nombre"));
        out.put("CESDescripcion", out.get("Descripcion"));
        return out;
    }

    @Override
    public int addSeccionCatalog(String clave, String nombre, String descripcion,
            Integer idCorporativo, int idUsuario, String nombreUsuario) {
        return querySingleId(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_AddConfiguracionEstadisticasSeccion(?, ?, ?, ?, ?, ?)}");
            cs.setString(1, clave);
            cs.setString(2, nombre);
            cs.setString(3, descripcion);
            cs.setInt(4, idUsuario);
            cs.setString(5, nombreUsuario);
            setNullableInt(cs, 6, idCorporativo);
            return cs;
        }, "IdConfiguracionEstadisticasSeccion");
    }

    @Override
    public int updateSeccionCatalog(int idSeccion, String clave, String nombre, String descripcion,
            int idUsuario, String nombreUsuario) {
        return queryRowCount(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_UpdateConfiguracionEstadisticasSeccionCatalogo(?, ?, ?, ?, ?, ?)}");
            cs.setInt(1, idSeccion);
            cs.setString(2, clave);
            cs.setString(3, nombre);
            cs.setString(4, descripcion);
            cs.setInt(5, idUsuario);
            cs.setString(6, nombreUsuario);
            return cs;
        });
    }

    @Override
    public int saveSeccionConfig(int idSeccion, Integer idCorporativo, int orden, boolean mostrarEnReporte,
            String textoAdicional, String textosJson, int idUsuario, String nombreUsuario) {
        return queryRowCount(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_SaveConfiguracionEstadisticasSeccionConfig(?, ?, ?, ?, ?, ?, ?, ?)}");
            cs.setInt(1, idSeccion);
            setNullableInt(cs, 2, idCorporativo);
            cs.setInt(3, orden);
            cs.setBoolean(4, mostrarEnReporte);
            cs.setString(5, textoAdicional);
            cs.setString(6, textosJson);
            cs.setInt(7, idUsuario);
            cs.setString(8, nombreUsuario);
            return cs;
        });
    }

    @Override
    public int deleteSeccion(int idSeccion, int idUsuario, String nombreUsuario) {
        return queryRowCount(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_DeleteConfiguracionEstadisticasSeccion(?, ?, ?)}");
            cs.setInt(1, idSeccion);
            cs.setInt(2, idUsuario);
            cs.setString(3, nombreUsuario);
            return cs;
        });
    }

    @Override
    public int deleteSeccionConfig(int idSeccion, int idCorporativo, int idUsuario, String nombreUsuario) {
        return jdbcTemplate.update(
                "UPDATE dbo.FF_ConfiguracionEstadisticasSeccionConfig "
                        + "SET CESCfgIdEstatus = 0, CESCfgUsuarioUMod = ?, CESCfgNombreUsuarioUMod = ?, "
                        + "CESCfgFechaUMod = GETDATE() "
                        + "WHERE CESCfgIdConfiguracionEstadisticasSeccion = ? "
                        + "AND CESCfgIdCorporativo = ? AND CESCfgIdEstatus = 1",
                idUsuario, nombreUsuario, idSeccion, idCorporativo);
    }

    @Override
    public int addIndicadorCatalog(int idSeccion, Integer idStoredProcedure, String clave, String nombre,
            String descripcion, Integer idCorporativo, int idUsuario, String nombreUsuario) {
        return querySingleId(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_AddConfiguracionEstadisticasSeccionIndicador(?, ?, ?, ?, ?, ?, ?, ?)}");
            cs.setInt(1, idSeccion);
            setNullableInt(cs, 2, idStoredProcedure);
            cs.setString(3, clave);
            cs.setString(4, nombre);
            cs.setString(5, descripcion);
            cs.setInt(6, idUsuario);
            cs.setString(7, nombreUsuario);
            setNullableInt(cs, 8, idCorporativo);
            return cs;
        }, "IdConfiguracionEstadisticasIndicador");
    }

    @Override
    public int updateIndicadorCatalog(int idIndicador, int idSeccion, Integer idStoredProcedure,
            String clave, String nombre, String descripcion, int idUsuario, String nombreUsuario) {
        return queryRowCount(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_UpdateConfiguracionEstadisticasSeccionIndicadorCatalogo(?, ?, ?, ?, ?, ?, ?, ?)}");
            cs.setInt(1, idIndicador);
            cs.setInt(2, idSeccion);
            setNullableInt(cs, 3, idStoredProcedure);
            cs.setString(4, clave);
            cs.setString(5, nombre);
            cs.setString(6, descripcion);
            cs.setInt(7, idUsuario);
            cs.setString(8, nombreUsuario);
            return cs;
        });
    }

    @Override
    public int saveIndicadorConfig(int idIndicador, Integer idCorporativo, String tipoClave, int orden,
            Integer ancho, Integer alto, boolean mostrarTitulo, boolean mostrarLeyenda,
            boolean mostrarEnReporte, String configJson, int idUsuario, String nombreUsuario) {
        return queryRowCount(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_SaveConfiguracionEstadisticasIndicadorConfig(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
            cs.setInt(1, idIndicador);
            setNullableInt(cs, 2, idCorporativo);
            cs.setString(3, tipoClave);
            cs.setInt(4, orden);
            setNullableInt(cs, 5, ancho);
            setNullableInt(cs, 6, alto);
            cs.setBoolean(7, mostrarTitulo);
            cs.setBoolean(8, mostrarLeyenda);
            cs.setBoolean(9, mostrarEnReporte);
            if (configJson == null) {
                cs.setNull(10, Types.NVARCHAR);
            } else {
                cs.setString(10, configJson);
            }
            cs.setInt(11, idUsuario);
            cs.setString(12, nombreUsuario);
            return cs;
        });
    }

    @Override
    public int deleteIndicador(int idIndicador, int idUsuario, String nombreUsuario) {
        return queryRowCount(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_DeleteConfiguracionEstadisticasSeccionIndicador(?, ?, ?)}");
            cs.setInt(1, idIndicador);
            cs.setInt(2, idUsuario);
            cs.setString(3, nombreUsuario);
            return cs;
        });
    }

    @Override
    public int deleteIndicadorConfig(int idIndicador, int idCorporativo, int idUsuario, String nombreUsuario) {
        return jdbcTemplate.update(
                "UPDATE dbo.FF_ConfiguracionEstadisticasIndicadorConfig "
                        + "SET CEICfgIdEstatus = 0, CEICfgUsuarioUMod = ?, CEICfgNombreUsuarioUMod = ?, "
                        + "CEICfgFechaUMod = GETDATE() "
                        + "WHERE CEICfgIdConfiguracionEstadisticasIndicador = ? "
                        + "AND CEICfgIdCorporativo = ? AND CEICfgIdEstatus = 1",
                idUsuario, nombreUsuario, idIndicador, idCorporativo);
    }

    @Override
    public int activarCorporativo(int idCorporativo, Integer idSeccion, Integer idIndicador,
            int idUsuario, String nombreUsuario) {
        return queryRowCount(connection -> {
            CallableStatement cs = connection.prepareCall(
                    "{call FF_ActivarConfiguracionEstadisticasCorporativo(?, ?, ?, ?, ?)}");
            cs.setInt(1, idCorporativo);
            setNullableInt(cs, 2, idSeccion);
            setNullableInt(cs, 3, idIndicador);
            cs.setInt(4, idUsuario);
            cs.setString(5, nombreUsuario);
            return cs;
        });
    }

    @Override
    public int resetPlantillaCorporativo(int idCorporativo, int idUsuario, String nombreUsuario) {
        int secciones = jdbcTemplate.update(
                "UPDATE dbo.FF_ConfiguracionEstadisticasSeccionConfig "
                        + "SET CESCfgIdEstatus = 0, CESCfgUsuarioUMod = ?, CESCfgNombreUsuarioUMod = ?, "
                        + "CESCfgFechaUMod = GETDATE() "
                        + "WHERE CESCfgIdCorporativo = ? AND CESCfgIdEstatus = 1",
                idUsuario, nombreUsuario, idCorporativo);
        int indicadores = jdbcTemplate.update(
                "UPDATE dbo.FF_ConfiguracionEstadisticasIndicadorConfig "
                        + "SET CEICfgIdEstatus = 0, CEICfgUsuarioUMod = ?, CEICfgNombreUsuarioUMod = ?, "
                        + "CEICfgFechaUMod = GETDATE() "
                        + "WHERE CEICfgIdCorporativo = ? AND CEICfgIdEstatus = 1",
                idUsuario, nombreUsuario, idCorporativo);
        return secciones + indicadores;
    }

    @Override
    public boolean existePlantillaCorporativo(int idCorporativo) {
        if (idCorporativo <= 0) {
            return false;
        }
        Integer found = jdbcTemplate.queryForObject(
                "SELECT CASE WHEN EXISTS ("
                        + "SELECT 1 FROM dbo.FF_ConfiguracionEstadisticasSeccionConfig "
                        + "WHERE CESCfgIdCorporativo = ? AND CESCfgIdEstatus = 1"
                        + ") OR EXISTS ("
                        + "SELECT 1 FROM dbo.FF_ConfiguracionEstadisticasIndicadorConfig "
                        + "WHERE CEICfgIdCorporativo = ? AND CEICfgIdEstatus = 1 "
                        + "AND (CEICfgConfigJson IS NULL OR CEICfgConfigJson NOT LIKE '%\"scope\":\""
                        + ConfigIndicadorJsonSupport.SCOPE_PARAMETROS + "\"%')"
                        + ") THEN 1 ELSE 0 END",
                Integer.class,
                idCorporativo,
                idCorporativo);
        return found != null && found > 0;
    }

    @Override
    public boolean hasSeccionConfigCorporativo(int idSeccion, int idCorporativo) {
        if (idSeccion <= 0 || idCorporativo <= 0) {
            return false;
        }
        return !getSeccionConfigRow(idSeccion, idCorporativo).isEmpty();
    }

    @Override
    public boolean hasIndicadorConfigCorporativo(int idIndicador, int idCorporativo) {
        if (idIndicador <= 0 || idCorporativo <= 0) {
            return false;
        }
        Map<String, Object> row = getIndicadorConfigRow(idIndicador, idCorporativo);
        return ConfigIndicadorJsonSupport.isPlantillaCorporativoRow(row);
    }

    @Override
    public List<Map<String, Object>> getStoredProcedures() {
        List<Map<String, Object>> rows = jdbcTemplate.query(
                "SELECT catReportesSPId, catReportesSPNombre, catReportesSPDesc, ESid "
                        + "FROM dbo.bf_CatReportesSP "
                        + "WHERE catReportesId = ? AND ESid = 1 "
                        + "ORDER BY catReportesSPOrden, catReportesSPNombre",
                (rs, rowNum) -> mapRow(rs), BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
        List<Map<String, Object>> mapped = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            mapped.add(BfCatReportesCatalogSupport.mapSpRow(row));
        }
        return mapped;
    }

    @Override
    public Map<String, Object> getStoredProcedureDetalle(int idStoredProcedure) {
        int spId = resolveCatalogSpId(idStoredProcedure);
        List<Map<String, Object>> rows = jdbcTemplate.query(
                "SELECT catReportesSPId, catReportesSPNombre, catReportesSPDesc, ESid "
                        + "FROM dbo.bf_CatReportesSP "
                        + "WHERE catReportesSPId = ? AND catReportesId = ? AND ESid = 1",
                (rs, rowNum) -> mapRow(rs), spId, BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
        if (rows.isEmpty()) {
            return new LinkedHashMap<>();
        }
        Map<String, Object> detalle = new LinkedHashMap<>(BfCatReportesCatalogSupport.mapSpRow(rows.get(0)));
        detalle.put("parametrosEntrada", getStoredProcedureParametros(spId));
        detalle.put("salidas", getStoredProcedureSalidas(spId));
        return detalle;
    }

    @Override
    public int addStoredProcedure(String clave, String nombre, String nombreReal, String descripcion,
            int idUsuario, String nombreUsuario) {
        String spDesc = BfCatReportesCatalogSupport.buildSpDesc(clave, nombre, descripcion);
        Integer maxOrden = jdbcTemplate.queryForObject(
                "SELECT ISNULL(MAX(catReportesSPOrden), 0) FROM dbo.bf_CatReportesSP WHERE catReportesId = ?",
                Integer.class, BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
        return jdbcTemplate.queryForObject(
                "INSERT INTO dbo.bf_CatReportesSP "
                        + "(catReportesId, catReportesSPNombre, catReportesSPOrden, catReportesSPDesc, ESid, "
                        + "catReportesSPUsuarioAdd, catReportesSPFechaAdd) "
                        + "VALUES (?, ?, ?, ?, 1, ?, GETDATE()); SELECT SCOPE_IDENTITY()",
                (rs, rowNum) -> rs.getInt(1),
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM, nombreReal, maxOrden + 1, spDesc, idUsuario);
    }

    @Override
    public int updateStoredProcedure(int idSp, String clave, String nombre, String nombreReal, String descripcion,
            int idUsuario, String nombreUsuario) {
        String spDesc = BfCatReportesCatalogSupport.buildSpDesc(clave, nombre, descripcion);
        return jdbcTemplate.update(
                "UPDATE dbo.bf_CatReportesSP SET catReportesSPNombre = ?, catReportesSPDesc = ?, "
                        + "catReportesSPUsuarioMod = ?, catReportesSPFechaMod = GETDATE() "
                        + "WHERE catReportesSPId = ? AND catReportesId = ? AND ESid = 1",
                nombreReal, spDesc, idUsuario, idSp, BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
    }

    @Override
    public int deleteStoredProcedure(int idSp, int idUsuario, String nombreUsuario) {
        return jdbcTemplate.update(
                "UPDATE dbo.bf_CatReportesSP SET ESid = 0, catReportesSPUsuarioDel = ?, "
                        + "catReportesSPFechaDel = GETDATE() "
                        + "WHERE catReportesSPId = ? AND catReportesId = ? AND ESid = 1",
                idUsuario, idSp, BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
    }

    @Override
    public List<Map<String, Object>> getStoredProcedureParametros(int idStoredProcedure) {
        int spId = resolveCatalogSpId(idStoredProcedure);
        List<Map<String, Object>> rows = jdbcTemplate.query(
                "SELECT P.catReportesParamsId, P.catReportesSPId, P.catReportesTipoDatoId, "
                        + "P.catReportesParamsOrden, P.catReportesParamsNombre, P.catReportesParamsDesc, P.ESid "
                        + "FROM dbo.bf_CatReportesParams P "
                        + "INNER JOIN dbo.bf_CatReportesSP SP ON SP.catReportesSPId = P.catReportesSPId "
                        + "WHERE P.catReportesSPId = ? AND SP.catReportesId = ? AND P.ESid = 1 "
                        + "ORDER BY P.catReportesParamsOrden",
                (rs, rowNum) -> mapRow(rs), spId,
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
        List<Map<String, Object>> mapped = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            mapped.add(BfCatReportesCatalogSupport.mapParamRow(row));
        }
        return mapped;
    }

    @Override
    public List<Map<String, Object>> getStoredProcedureSalidas(int idStoredProcedure) {
        int spId = resolveCatalogSpId(idStoredProcedure);
        String grupo = resolveSpGrupo(spId);
        if (TextUtil.isBlank(grupo)) {
            return new ArrayList<>();
        }
        List<Map<String, Object>> rows = jdbcTemplate.query(
                "SELECT C.orden, C.campoOrigen, C.encabezado, C.tipoDato, SP.catReportesSPId "
                        + "FROM dbo.bf_RepConf_Columna C "
                        + "INNER JOIN dbo.bf_CatReportesSP SP ON SP.catReportesSPId = ? "
                        + "WHERE C.idEmpresa = 0 AND C.catReportesId = ? AND C.grupo = ? "
                        + "ORDER BY C.orden",
                (rs, rowNum) -> mapRow(rs), spId,
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM, grupo);
        List<Map<String, Object>> mapped = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            row.put("catReportesSPId", spId);
            mapped.add(BfCatReportesCatalogSupport.mapSalidaRow(row));
        }
        return mapped;
    }

    private int resolveCatalogSpId(int idStoredProcedure) {
        List<Integer> direct = jdbcTemplate.query(
                "SELECT catReportesSPId FROM dbo.bf_CatReportesSP "
                        + "WHERE catReportesSPId = ? AND catReportesId = ? AND ESid = 1",
                (rs, rowNum) -> rs.getInt(1), idStoredProcedure,
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
        return direct.isEmpty() ? idStoredProcedure : direct.get(0);
    }

    @Override
    public int addStoredProcedureParametro(int idStoredProcedure, String nombreParametro, String nombreVisual,
            String parametroSql, String tipoDato, int orden, boolean obligatorio, boolean filtroBase,
            boolean visible, int idUsuario, String nombreUsuario) {
        int tipoId = BfCatReportesCatalogSupport.mapTipoDatoToId(tipoDato);
        String sqlName = parametroSql != null && parametroSql.startsWith("@")
                ? parametroSql : "@" + nombreParametro;
        return jdbcTemplate.queryForObject(
                "INSERT INTO dbo.bf_CatReportesParams "
                        + "(catReportesSPId, catReportesTipoDatoId, catReportesParamsLongitud, catReportesParamsOrden, "
                        + "catReportesParamsNombre, catReportesParamsDesc, ESid, catReportesParamsUsuarioAdd, "
                        + "catReportesParamsFechaAdd) "
                        + "VALUES (?, ?, ?, ?, ?, ?, 1, ?, GETDATE()); SELECT SCOPE_IDENTITY()",
                (rs, rowNum) -> rs.getInt(1),
                idStoredProcedure, tipoId, BfCatReportesCatalogSupport.defaultLongitud(tipoId), orden,
                sqlName, nombreVisual, idUsuario);
    }

    @Override
    public int updateStoredProcedureParametro(int idParametro, String nombreVisual, String parametroSql,
            String tipoDato, int orden, boolean obligatorio, boolean filtroBase, boolean visible,
            int idUsuario, String nombreUsuario) {
        int tipoId = BfCatReportesCatalogSupport.mapTipoDatoToId(tipoDato);
        return jdbcTemplate.update(
                "UPDATE P SET P.catReportesParamsDesc = ?, P.catReportesParamsNombre = ?, "
                        + "P.catReportesTipoDatoId = ?, P.catReportesParamsOrden = ?, "
                        + "P.catReportesParamsLongitud = ?, P.catReportesParamsUsuarioMod = ?, "
                        + "P.catReportesParamsFechaMod = GETDATE() "
                        + "FROM dbo.bf_CatReportesParams P "
                        + "INNER JOIN dbo.bf_CatReportesSP SP ON SP.catReportesSPId = P.catReportesSPId "
                        + "WHERE P.catReportesParamsId = ? AND SP.catReportesId = ? AND P.ESid = 1",
                nombreVisual, parametroSql, tipoId, orden,
                BfCatReportesCatalogSupport.defaultLongitud(tipoId), idUsuario, idParametro,
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
    }

    @Override
    public int deleteStoredProcedureParametro(int idParametro, int idUsuario, String nombreUsuario) {
        return jdbcTemplate.update(
                "UPDATE P SET P.ESid = 0, P.catReportesParamsUsuarioDel = ?, P.catReportesParamsFechaDel = GETDATE() "
                        + "FROM dbo.bf_CatReportesParams P "
                        + "INNER JOIN dbo.bf_CatReportesSP SP ON SP.catReportesSPId = P.catReportesSPId "
                        + "WHERE P.catReportesParamsId = ? AND SP.catReportesId = ? AND P.ESid = 1",
                idUsuario, idParametro, BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
    }

    @Override
    public int addStoredProcedureSalida(int idStoredProcedure, int indiceResultSet, String nombreColumna,
            String nombreVisual, String tipoDato, int orden, int idUsuario, String nombreUsuario) {
        String grupo = resolveSpGrupo(idStoredProcedure);
        if (TextUtil.isBlank(grupo)) {
            throw new IllegalArgumentException("Stored procedure de catálogo no encontrado.");
        }
        jdbcTemplate.update(
                "INSERT INTO dbo.bf_RepConf_Columna "
                        + "(idEmpresa, catReportesId, grupo, orden, campoOrigen, encabezado, visible, "
                        + "tipoDato, repConfColumnaUsuarioAdd, repConfColumnaFechaAdd) "
                        + "VALUES (0, ?, ?, ?, ?, ?, 1, ?, ?, GETDATE())",
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM, grupo, orden, nombreColumna, nombreVisual,
                BfCatReportesCatalogSupport.mapTipoDatoToId(tipoDato), idUsuario);
        return BfCatReportesCatalogSupport.syntheticSalidaId(idStoredProcedure, orden);
    }

    @Override
    public int updateStoredProcedureSalida(int idSalida, String nombreVisual, String tipoDato, int orden,
            int idUsuario, String nombreUsuario) {
        int spId = BfCatReportesCatalogSupport.salidaSpId(idSalida);
        int oldOrden = BfCatReportesCatalogSupport.salidaOrden(idSalida);
        String grupo = resolveSpGrupo(spId);
        return jdbcTemplate.update(
                "UPDATE C SET C.encabezado = ?, C.tipoDato = ?, C.orden = ?, "
                        + "C.repConfColumnaUsuarioMod = ?, C.repConfColumnaFechaMod = GETDATE() "
                        + "FROM dbo.bf_RepConf_Columna C "
                        + "WHERE C.idEmpresa = 0 AND C.catReportesId = ? AND C.grupo = ? AND C.orden = ?",
                nombreVisual, BfCatReportesCatalogSupport.mapTipoDatoToId(tipoDato), orden, idUsuario,
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM, grupo, oldOrden);
    }

    @Override
    public int deleteStoredProcedureSalida(int idSalida, int idUsuario, String nombreUsuario) {
        int spId = BfCatReportesCatalogSupport.salidaSpId(idSalida);
        int orden = BfCatReportesCatalogSupport.salidaOrden(idSalida);
        String grupo = resolveSpGrupo(spId);
        return jdbcTemplate.update(
                "DELETE FROM dbo.bf_RepConf_Columna "
                        + "WHERE idEmpresa = 0 AND catReportesId = ? AND grupo = ? AND orden = ?",
                BfCatReportesCatalogSupport.CAT_REPORTES_NUM, grupo, orden);
    }

    private Map<String, Object> enrichIndicadorSpFields(Map<String, Object> row) {
        if (row == null) {
            return row;
        }
        if (row.get("CESPNombreRealStoredProcedure") == null && row.get("StoredProcedureNombre") != null) {
            row.put("CESPNombreRealStoredProcedure", row.get("StoredProcedureNombre"));
        }
        String spNombre = row.get("CESPNombreRealStoredProcedure") != null
                ? String.valueOf(row.get("CESPNombreRealStoredProcedure")) : "";
        if (TextUtil.isBlank(spNombre)) {
            return row;
        }
        String spDesc = row.get("SpDescMeta") != null ? String.valueOf(row.get("SpDescMeta")) : "";
        row.put("StoredProcedureClave", BfCatReportesCatalogSupport.metaClave(spDesc, spNombre));
        row.put("StoredProcedureNombre", BfCatReportesCatalogSupport.metaNombre(spDesc, spNombre));
        row.remove("SpDescMeta");
        row.remove("SpBfId");
        return row;
    }

    private String resolveSpGrupo(int idStoredProcedure) {
        List<String> rows = jdbcTemplate.query(
                "SELECT catReportesSPDesc, catReportesSPNombre FROM dbo.bf_CatReportesSP "
                        + "WHERE catReportesSPId = ? AND catReportesId = ? AND ESid = 1",
                (rs, rowNum) -> BfCatReportesCatalogSupport.metaClave(
                        rs.getString("catReportesSPDesc"), rs.getString("catReportesSPNombre")),
                idStoredProcedure, BfCatReportesCatalogSupport.CAT_REPORTES_NUM);
        return rows.isEmpty() ? "" : rows.get(0);
    }

    private Map<String, Object> getIndicadorCatalogRow(int idIndicador) {
        List<Map<String, Object>> rows = jdbcTemplate.query(
                "SELECT I.CEIidConfiguracionEstadisticasIndicador AS IdIndicador, "
                        + "I.CEIIdConfiguracionEstadisticasSeccion AS IdSeccion, "
                        + "I.CEIIdConfiguracionEstadisticasStoredProcedure AS IdStoredProcedure, "
                        + "I.CEIClave AS Clave, I.CEINombre AS Nombre, I.CEIDescripcion AS Descripcion, "
                        + "COALESCE(SPbf.catReportesSPNombre, '') AS CESPNombreRealStoredProcedure, "
                        + "COALESCE(SPbf.catReportesSPDesc, '') AS SpDescMeta, "
                        + "SPbf.catReportesSPId AS SpBfId "
                        + "FROM dbo.FF_ConfiguracionEstadisticasSeccionIndicadores I "
                        + "LEFT JOIN dbo.bf_CatReportesSP SPbf "
                        + "ON SPbf.catReportesSPId = I.CEIIdConfiguracionEstadisticasStoredProcedure "
                        + "AND SPbf.catReportesId = " + BfCatReportesCatalogSupport.CAT_REPORTES_NUM + " "
                        + "WHERE I.CEIidConfiguracionEstadisticasIndicador = ? AND I.CEIIdEstatus = 1",
                (rs, rowNum) -> mapRow(rs),
                idIndicador);
        return rows.isEmpty() ? new LinkedHashMap<>() : rows.get(0);
    }

    private int getIndicadorStoredProcedureId(int idIndicador) {
        List<Integer> ids = jdbcTemplate.query(
                "SELECT CEIIdConfiguracionEstadisticasStoredProcedure "
                        + "FROM dbo.FF_ConfiguracionEstadisticasSeccionIndicadores "
                        + "WHERE CEIidConfiguracionEstadisticasIndicador = ? AND CEIIdEstatus = 1",
                (rs, rowNum) -> rs.getInt(1),
                idIndicador);
        return ids.isEmpty() ? 0 : ids.get(0);
    }

    private Map<String, Object> getIndicadorConfigRow(int idIndicador, Integer idCorporativo) {
        String corpFilter = idCorporativo == null ? "IS NULL" : "= ?";
        List<Map<String, Object>> rows = idCorporativo == null
                ? jdbcTemplate.query(
                        "SELECT TOP 1 * FROM dbo.FF_ConfiguracionEstadisticasIndicadorConfig "
                                + "WHERE CEICfgIdConfiguracionEstadisticasIndicador = ? "
                                + "AND CEICfgIdCorporativo IS NULL AND CEICfgIdEstatus = 1",
                        (rs, rowNum) -> mapRow(rs),
                        idIndicador)
                : jdbcTemplate.query(
                        "SELECT TOP 1 * FROM dbo.FF_ConfiguracionEstadisticasIndicadorConfig "
                                + "WHERE CEICfgIdConfiguracionEstadisticasIndicador = ? "
                                + "AND CEICfgIdCorporativo " + corpFilter + " AND CEICfgIdEstatus = 1",
                        (rs, rowNum) -> mapRow(rs),
                        idIndicador,
                        idCorporativo);
        return rows.isEmpty() ? new LinkedHashMap<>() : rows.get(0);
    }

    private Map<String, Object> getMergedIndicadorConfig(int idIndicador, Integer idCorporativo) {
        Map<String, Object> plantillaCfg = getIndicadorConfigRow(idIndicador, null);
        Map<String, Object> corporativoCfg = idCorporativo == null
                ? new LinkedHashMap<>()
                : getIndicadorConfigRow(idIndicador, idCorporativo);
        return ConfigIndicadorJsonSupport.resolveIndicadorConfigForRead(plantillaCfg, corporativoCfg, idCorporativo);
    }

    private Map<String, Object> getSeccionConfigRow(int idSeccion, Integer idCorporativo) {
        String sql = "SELECT TOP 1 * FROM dbo.FF_ConfiguracionEstadisticasSeccionConfig "
                + "WHERE CESCfgIdConfiguracionEstadisticasSeccion = ? "
                + "AND CESCfgIdCorporativo "
                + (idCorporativo == null ? "IS NULL" : "= ?")
                + " AND CESCfgIdEstatus = 1";
        List<Map<String, Object>> rows = idCorporativo == null
                ? jdbcTemplate.query(sql, (rs, rowNum) -> mapRow(rs), idSeccion)
                : jdbcTemplate.query(sql, (rs, rowNum) -> mapRow(rs), idSeccion, idCorporativo);
        return rows.isEmpty() ? new LinkedHashMap<>() : rows.get(0);
    }

    private Map<String, Object> resolveSeccionConfig(Map<String, Object> plantilla,
            Map<String, Object> corporativo, Integer idCorporativo) {
        if (idCorporativo == null || idCorporativo <= 0) {
            return mergeSeccionConfig(plantilla, null);
        }
        if (corporativo != null && !corporativo.isEmpty()) {
            Map<String, Object> out = new LinkedHashMap<>(corporativo);
            out.putIfAbsent("CESCfgOrden", 0);
            out.putIfAbsent("CESCfgMostrarEnReporte", 1);
            out.putIfAbsent("CESCfgTextoAdicional", "");
            out.putIfAbsent("CESCfgTextosJson", "[]");
            return out;
        }
        return mergeSeccionConfig(plantilla, null);
    }

    private Map<String, Object> mergeSeccionConfig(Map<String, Object> plantilla, Map<String, Object> corporativo) {
        Map<String, Object> out = new LinkedHashMap<>();
        if (plantilla != null) {
            out.putAll(plantilla);
        }
        if (corporativo != null) {
            if (corporativo.get("CESCfgOrden") != null) {
                out.put("CESCfgOrden", corporativo.get("CESCfgOrden"));
            }
            if (corporativo.get("CESCfgMostrarEnReporte") != null) {
                out.put("CESCfgMostrarEnReporte", corporativo.get("CESCfgMostrarEnReporte"));
            }
            if (corporativo.get("CESCfgTextoAdicional") != null) {
                out.put("CESCfgTextoAdicional", corporativo.get("CESCfgTextoAdicional"));
            }
            if (corporativo.get("CESCfgTextosJson") != null) {
                out.put("CESCfgTextosJson", corporativo.get("CESCfgTextosJson"));
            }
        }
        out.putIfAbsent("CESCfgOrden", 0);
        out.putIfAbsent("CESCfgMostrarEnReporte", 1);
        out.putIfAbsent("CESCfgTextoAdicional", "");
        out.putIfAbsent("CESCfgTextosJson", "[]");
        return out;
    }

    private List<Map<String, Object>> textosForApi(Map<String, Object> mergedSeccionCfg, int idSeccion) {
        List<Map<String, Object>> textos = ConfigIndicadorJsonSupport.parseTextosJson(
                ConfigIndicadorJsonSupport.str(mergedSeccionCfg, "CESCfgTextosJson"));
        List<Map<String, Object>> out = new ArrayList<>();
        int seq = 1;
        for (Map<String, Object> t : textos) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("CESTXidConfiguracionEstadisticasSeccionTexto", nullableInt(t.get("id")));
            if (row.get("CESTXidConfiguracionEstadisticasSeccionTexto") == null) {
                row.put("CESTXidConfiguracionEstadisticasSeccionTexto", nullableInt(t.get("textoId")));
            }
            if (row.get("CESTXidConfiguracionEstadisticasSeccionTexto") == null) {
                row.put("CESTXidConfiguracionEstadisticasSeccionTexto", seq);
            }
            row.put("CESTXIdConfiguracionEstadisticasSeccion", idSeccion);
            row.put("CESTXIdConfiguracionEstadisticasIndicador", nullableInt(t.get("idIndicador")));
            row.put("CESTXClave", t.getOrDefault("clave", ""));
            row.put("CESTXTipoTexto", t.getOrDefault("tipoTexto", "TEXTO"));
            row.put("CESTXTextoPlantilla", t.getOrDefault("textoPlantilla", t.getOrDefault("texto", "")));
            row.put("CESTXEsDinamico", boolAsInt(t.get("esDinamico")));
            row.put("CESTXIdConfiguracionEstadisticasStoredProcedureSalida",
                    nullableInt(t.get("idStoredProcedureSalida")));
            row.put("CESTXOrden", t.getOrDefault("orden", seq));
            row.put("CESTXMostrarEnReporte", boolAsInt(t.getOrDefault("mostrarEnReporte", true)));
            out.add(row);
            seq++;
        }
        out.sort(Comparator.comparingInt(r -> ConfigIndicadorJsonSupport.intVal(r.get("CESTXOrden"))));
        return out;
    }

    private int orderValue(Map<String, Object> param, int fallback) {
        int o = ConfigIndicadorJsonSupport.intVal(param.get("CEIPOrden"));
        if (o <= 0) {
            o = ConfigIndicadorJsonSupport.intVal(param.get("CESPPOrden"));
        }
        return o > 0 ? o : fallback;
    }

    private boolean boolVal(Object value) {
        if (value == null) {
            return false;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        String s = String.valueOf(value).trim();
        return "1".equals(s) || "true".equalsIgnoreCase(s);
    }

    private Integer nullableInt(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        String s = String.valueOf(value).trim();
        if (s.isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private int boolAsInt(Object value) {
        return boolVal(value) ? 1 : 0;
    }

    private String defaultIfBlank(String value, String fallback) {
        return value == null || TextUtil.isBlank(value) ? fallback : value;
    }

    private boolean isBlank(Object value) {
        return value == null || String.valueOf(value).trim().isEmpty();
    }

    private int querySingleId(org.springframework.jdbc.core.PreparedStatementCreator creator, String idColumn) {
        Integer id = jdbcTemplate.execute((Connection conn) -> {
            try (PreparedStatement ps = creator.createPreparedStatement(conn)) {
                if (ps instanceof CallableStatement) {
                    CallableStatement cs = (CallableStatement) ps;
                    int resolved = 0;
                    boolean hasResult = cs.execute();
                    while (true) {
                        if (hasResult) {
                            try (ResultSet rs = cs.getResultSet()) {
                                resolved = readIdFromResultSet(rs, idColumn, resolved);
                            }
                        } else if (cs.getUpdateCount() == -1) {
                            break;
                        }
                        hasResult = cs.getMoreResults();
                    }
                    return resolved;
                }
                try (ResultSet rs = ps.executeQuery()) {
                    return readIdFromResultSet(rs, idColumn, 0);
                }
            }
        });
        return id != null ? id : 0;
    }

    private int readIdFromResultSet(ResultSet rs, String idColumn, int current) throws SQLException {
        if (rs == null) {
            return current;
        }
        ResultSetMetaData meta = rs.getMetaData();
        int colIndex = -1;
        for (int i = 1; i <= meta.getColumnCount(); i++) {
            if (idColumn.equalsIgnoreCase(meta.getColumnLabel(i))) {
                colIndex = i;
                break;
            }
        }
        if (colIndex < 0) {
            return current;
        }
        while (rs.next()) {
            Object val = rs.getObject(colIndex);
            if (val instanceof Number) {
                current = ((Number) val).intValue();
            }
        }
        return current;
    }

    private int queryRowCount(org.springframework.jdbc.core.PreparedStatementCreator creator) {
        List<Map<String, Object>> rows = jdbcTemplate.query(creator, (rs, rowNum) -> mapRow(rs));
        if (rows.isEmpty()) {
            return 0;
        }
        Object n = rows.get(0).get("RegistrosAfectados");
        return n instanceof Number ? ((Number) n).intValue() : 0;
    }

    private void setNullableInt(CallableStatement cs, int index, Integer value) throws java.sql.SQLException {
        if (value == null) {
            cs.setNull(index, Types.INTEGER);
        } else {
            cs.setInt(index, value);
        }
    }

    private List<Map<String, Object>> readAllRows(ResultSet rs) throws java.sql.SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        while (rs.next()) {
            rows.add(mapRow(rs));
        }
        return rows;
    }

    private Map<String, Object> mapRow(ResultSet rs) throws java.sql.SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        ResultSetMetaData meta = rs.getMetaData();
        for (int i = 1; i <= meta.getColumnCount(); i++) {
            row.put(meta.getColumnLabel(i), rs.getObject(i));
        }
        return row;
    }
}
