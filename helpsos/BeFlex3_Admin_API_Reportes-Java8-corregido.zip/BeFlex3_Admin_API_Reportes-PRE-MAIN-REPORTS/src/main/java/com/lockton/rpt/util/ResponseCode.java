package com.lockton.rpt.util;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;


public class ResponseCode implements Serializable {
	
	private static final long serialVersionUID = -3647558820623846857L;

	@ApiModelProperty(value = "C\u00f3digo de respuesta", required = true)
	private String code;

	@ApiModelProperty(value = "Mensaje de respuesta.", required = true)
	private String message;

	@ApiModelProperty(value = "Mensaje de detallado respuesta.", required = true)
	private String messageDetail;

	
	public ResponseCode() {
	}

	public ResponseCode(String code, String message, String messageDetail) {
		this.code = code;
		this.message = message;
		this.messageDetail = messageDetail;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageDetail() {
		return messageDetail;
	}

	public void setMessageDetail(String messageDetail) {
		this.messageDetail = messageDetail;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseCode [");
		if (code != null) {
			builder.append("code=");
			builder.append(code);
			builder.append(", ");
		}
		if (message != null) {
			builder.append("message=");
			builder.append(message);
			builder.append(", ");
		}
		if (messageDetail != null) {
			builder.append("messageDetail=");
			builder.append(messageDetail);
		}
		builder.append("]");
		return builder.toString();
	}
}
