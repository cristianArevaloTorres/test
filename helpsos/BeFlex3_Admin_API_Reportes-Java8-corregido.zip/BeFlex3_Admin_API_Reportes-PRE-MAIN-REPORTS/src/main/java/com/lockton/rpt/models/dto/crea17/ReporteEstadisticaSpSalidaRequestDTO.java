package com.lockton.rpt.models.dto.crea17;

public class ReporteEstadisticaSpSalidaRequestDTO {
    private Integer indiceResultSet;
    private String nombreColumna;
    private String nombreVisual;
    private String tipoDato;
    private Boolean nullable;
    private Integer orden;
    private Integer idUsuario;

    public Integer getIndiceResultSet() { return indiceResultSet; }
    public void setIndiceResultSet(Integer indiceResultSet) { this.indiceResultSet = indiceResultSet; }
    public String getNombreColumna() { return nombreColumna; }
    public void setNombreColumna(String nombreColumna) { this.nombreColumna = nombreColumna; }
    public String getNombreVisual() { return nombreVisual; }
    public void setNombreVisual(String nombreVisual) { this.nombreVisual = nombreVisual; }
    public String getTipoDato() { return tipoDato; }
    public void setTipoDato(String tipoDato) { this.tipoDato = tipoDato; }
    public Boolean getNullable() { return nullable; }
    public void setNullable(Boolean nullable) { this.nullable = nullable; }
    public Integer getOrden() { return orden; }
    public void setOrden(Integer orden) { this.orden = orden; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
