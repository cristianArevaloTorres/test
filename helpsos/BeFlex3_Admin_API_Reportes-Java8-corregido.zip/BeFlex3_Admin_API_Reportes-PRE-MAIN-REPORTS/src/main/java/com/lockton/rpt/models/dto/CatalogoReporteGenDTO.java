package com.lockton.rpt.models.dto;

import lombok.Data;
import java.util.Date;

@Data
public class CatalogoReporteGenDTO {
    private Long catRptId;
    private String CatRptNombre;
    private Boolean CatRptProgramado;
    private Date CatRptHorario;
    private String CatRptHorarioStr;
    private Boolean CatRptActivo;
}
