package com.lockton.rpt.repe.dto;

import com.lockton.rpt.util.SafeApiError;

public class RepeApiResponse<T> {
    private String code;
    private boolean status;
    private String message;
    private String detail;
    private String error;
    private T data;

    public RepeApiResponse() {
    }

    public RepeApiResponse(String code, boolean status, String message, String detail, String error, T data) {
        this.code = code;
        this.status = status;
        this.message = status
                ? message
                : SafeApiError.sanitizeMessage(message, "No fue posible completar la operación. Intenta nuevamente.");
        // Nunca se publica detalle técnico en respuestas de error.
        this.detail = status ? detail : null;
        this.error = status ? error : null;
        this.data = status ? data : null;
    }

    public static <T> RepeApiResponse<T> ok(String code, String message, T data) {
        return new RepeApiResponse<T>(code, true, message, null, null, data);
    }

    /**
     * Se conserva la firma con Exception para compatibilidad con controladores existentes,
     * pero la excepción jamás forma parte del payload HTTP.
     */
    public static <T> RepeApiResponse<T> fail(String code, String message, Exception ignored) {
        return new RepeApiResponse<T>(code, false, message, null, null, null);
    }

    public String getCode() { return code; }
    public boolean isStatus() { return status; }
    public String getMessage() { return message; }
    public String getDetail() { return detail; }
    public String getError() { return error; }
    public T getData() { return data; }
}
