package com.lockton.rpt.repositories.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpFiltroRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpSalidaRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpValidacionRequestDTO;
import com.lockton.rpt.repositories.ReporteEstadisticaCatalogoDAO;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCReporteEstadisticaCatalogoDAO implements ReporteEstadisticaCatalogoDAO {
    private final DataSource dataSource;
    private final ObjectMapper objectMapper;

    public JDBCReporteEstadisticaCatalogoDAO(@Qualifier("dataSourceRPT") DataSource dataSource, ObjectMapper objectMapper) {
        this.dataSource = dataSource;
        this.objectMapper = objectMapper;
    }

    @Override
    public Map<String, Object> obtenerContextoValidacion(int idCorporativo) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdCorporativo", Integer.valueOf(idCorporativo));
        List<List<Map<String, Object>>> sets = call("dbo.ff_CReporteEstadisticaContextoValidacion", p);
        Map<String, Object> row = firstRow(sets, 0);
        if (row.isEmpty()) {
            throw new IllegalArgumentException("No se encontró una vigencia actual válida para el corporativo.");
        }
        return row;
    }

    @Override
    public List<Map<String, Object>> listarFiltros() {
        return firstResultSet(call("dbo.ff_CReporteEstadisticaFiltros"));
    }

    @Override
    public List<Map<String, Object>> listarStoredProcedures(boolean incluirBajas) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IncluirBajas", Boolean.valueOf(incluirBajas));
        return firstResultSet(call("dbo.ff_CReporteEstadisticaStoredProcedures", p));
    }

    @Override
    public Map<String, Object> obtenerStoredProcedure(int idStoredProcedure) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        List<List<Map<String, Object>>> sets = call("dbo.ff_CReporteEstadisticaStoredProcedure", p);
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("storedProcedure", firstRow(sets, 0));
        out.put("salidas", resultSet(sets, 1));
        out.put("filtros", resultSet(sets, 2));
        return out;
    }

    @Override
    public Map<String, Object> validarStoredProcedure(ReporteEstadisticaSpValidacionRequestDTO request) {
        List<List<Map<String, Object>>> sets = callValidacionStoredProcedure(request);
        Map<String, Object> resumen = firstRow(sets, 0);
        List<Map<String, Object>> parametros = resultSet(sets, 1);
        List<Map<String, Object>> salidas = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> muestra = new ArrayList<Map<String, Object>>();

        boolean estructuraValida = Boolean.TRUE.equals(resumen.get("EsValido"));
        if (estructuraValida && Boolean.TRUE.equals(request.getEjecutarMuestra())) {
            ConsultaResult runtime = ejecutarConsulta(request.getIdCorporativo(), request.getIdVigencia(), request.getNombreTecnico());
            salidas = runtime.columns;
            muestra = runtime.rows;
        }
        boolean salidaValida = !salidas.isEmpty();
        resumen.put("SalidaValida", Boolean.valueOf(salidaValida));
        resumen.put("TotalSalidas", Integer.valueOf(salidas.size()));
        resumen.put("TotalFiltrosPotenciales", Integer.valueOf(0));
        resumen.put("EsValido", Boolean.valueOf(estructuraValida && (!Boolean.TRUE.equals(request.getEjecutarMuestra()) || salidaValida)));
        if (estructuraValida && Boolean.TRUE.equals(request.getEjecutarMuestra()) && !salidaValida) {
            resumen.put("Mensaje", "La consulta cumple el contrato, pero no devolvió un resultset tabular.");
        } else if (Boolean.TRUE.equals(resumen.get("EsValido"))) {
            resumen.put("Mensaje", "Consulta validada correctamente.");
        }

        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("resumen", resumen);
        out.put("parametros", parametros);
        out.put("salidas", salidas);
        out.put("filtrosPotenciales", new ArrayList<Map<String, Object>>());
        out.put("muestra", muestra);
        return out;
    }

    private ConsultaResult ejecutarConsulta(Integer idCorporativo, Integer idVigencia, String nombreTecnico) {
        if (idCorporativo == null || idCorporativo.intValue() <= 0 || idVigencia == null || idVigencia.intValue() <= 0) {
            throw new IllegalArgumentException("Corporativo y vigencia son requeridos para ejecutar la consulta.");
        }
        String sql = "{call dbo.bf_REPEQ_ResolverPreviewConsulta(?,?,?)}";
        try (Connection connection = dataSource.getConnection(); CallableStatement statement = connection.prepareCall(sql)) {
            statement.setInt(1, idCorporativo.intValue());
            statement.setInt(2, idVigencia.intValue());
            statement.setString(3, nombreTecnico);
            boolean has = statement.execute();
            while (true) {
                if (has) {
                    try (ResultSet rs = statement.getResultSet()) {
                        ResultSetMetaData md = rs.getMetaData();
                        int count = md.getColumnCount();
                        List<Map<String, Object>> cols = new ArrayList<Map<String, Object>>();
                        for (int i=1;i<=count;i++) {
                            Map<String, Object> c = new LinkedHashMap<String, Object>();
                            c.put("Orden", Integer.valueOf(i));
                            c.put("NombreColumna", md.getColumnLabel(i));
                            c.put("TipoDato", md.getColumnTypeName(i));
                            c.put("Nullable", Boolean.valueOf(md.isNullable(i) != ResultSetMetaData.columnNoNulls));
                            c.put("Oculta", Boolean.FALSE); c.put("NumeroError", null); c.put("MensajeError", null);
                            cols.add(c);
                        }
                        return new ConsultaResult(cols, readRows(rs));
                    }
                }
                if (!has && statement.getUpdateCount() == -1) break;
                has = statement.getMoreResults();
            }
            return new ConsultaResult(new ArrayList<Map<String, Object>>(), new ArrayList<Map<String, Object>>());
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
    }

    private List<List<Map<String, Object>>> callValidacionStoredProcedure(ReporteEstadisticaSpValidacionRequestDTO request) {
        String sql = "{call dbo.ff_CValidarReporteEstadisticaStoredProcedure(?,?,?,?,?,?,?)}";
        List<List<Map<String, Object>>> resultSets = new ArrayList<List<Map<String, Object>>>();
        try (Connection connection = dataSource.getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {
            statement.setString(1, request.getNombreTecnico());
            if (request.getIdCorporativo() == null) statement.setNull(2, Types.INTEGER);
            else statement.setInt(2, request.getIdCorporativo().intValue());
            if (request.getIdVigencia() == null) statement.setNull(3, Types.INTEGER);
            else statement.setInt(3, request.getIdVigencia().intValue());

            // El contrato legacy conserva estos parámetros DATETIME2. Aunque actualmente
            // el validador estructural no los usa, se tipan explícitamente para evitar que
            // SQL Server interprete un NULL genérico como VARBINARY.
            statement.setNull(4, Types.TIMESTAMP);
            statement.setNull(5, Types.TIMESTAMP);
            statement.setBoolean(6, false);
            statement.setNull(7, Types.INTEGER);

            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet rs = statement.getResultSet()) {
                        resultSets.add(readRows(rs));
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
            return resultSets;
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
    }

    private static final class ConsultaResult {
        final List<Map<String, Object>> columns; final List<Map<String, Object>> rows;
        ConsultaResult(List<Map<String, Object>> columns, List<Map<String, Object>> rows) { this.columns=columns; this.rows=rows; }
    }

    @Override
    public Map<String, Object> obtenerUltimoSnapshot(
            int idCorporativo, int idStoredProcedure, int pagina, int tamanoPagina) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdCorporativo", Integer.valueOf(idCorporativo));
        p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        p.put("@Pagina", Integer.valueOf(pagina));
        p.put("@TamanoPagina", Integer.valueOf(tamanoPagina));

        List<List<Map<String, Object>>> sets =
                call("dbo.ff_CReporteEstadisticaStoredProcedureUltimoSnapshot", p);
        Map<String, Object> context = firstRow(sets, 0);
        List<Map<String, Object>> rows = resultSet(sets, 1);

        Map<String, Object> pagination = new LinkedHashMap<String, Object>();
        pagination.put("pagina", context.get("Pagina"));
        pagination.put("tamanoPagina", context.get("TamanoPagina"));
        pagination.put("totalRegistros", context.get("TotalRegistros"));
        pagination.put("totalPaginas", context.get("TotalPaginas"));

        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("contexto", context);
        out.put("filas", rows);
        out.put("paginacion", pagination);
        return out;
    }

    @Override
    public Map<String, Object> crearStoredProcedure(ReporteEstadisticaSpRequestDTO request) {
        LinkedHashMap<String, Object> p = storedProcedureParams(request, false, 0);
        return operation("dbo.ff_IReporteEstadisticaStoredProcedure", p);
    }

    @Override
    public Map<String, Object> actualizarStoredProcedure(int idStoredProcedure, ReporteEstadisticaSpRequestDTO request) {
        LinkedHashMap<String, Object> p = storedProcedureParams(request, true, idStoredProcedure);
        return operation("dbo.ff_UReporteEstadisticaStoredProcedure", p);
    }

    @Override
    public Map<String, Object> cambiarEstatusStoredProcedure(int idStoredProcedure, CambioEstatusRequestDTO request) {
        LinkedHashMap<String, Object> p = statusParams("@IdStoredProcedure", idStoredProcedure, request);
        return operation("dbo.ff_UEstatusReporteEstadisticaStoredProcedure", p);
    }

    @Override
    public Map<String, Object> revalidarStoredProcedure(int idStoredProcedure, int idUsuario) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        p.put("@IdUsuario", Integer.valueOf(idUsuario));
        return operation("dbo.ff_UValidarReporteEstadisticaStoredProcedure", p);
    }

    @Override
    public Map<String, Object> sincronizarSalidas(int idStoredProcedure, List<Map<String, Object>> salidas, String hashDefinicion, int idUsuario, boolean esAlta) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        try { p.put("@SalidasJson", objectMapper.writeValueAsString(salidas)); }
        catch (JsonProcessingException ex) { throw new IllegalStateException("No fue posible serializar las salidas detectadas.", ex); }
        p.put("@HashDefinicion", hashDefinicion);
        p.put("@IdUsuario", Integer.valueOf(idUsuario));
        p.put("@EsAlta", Boolean.valueOf(esAlta));
        return operation("dbo.ff_SReporteEstadisticaConsultaSalidas", p);
    }

    @Override
    public Map<String, Object> crearSalida(int idStoredProcedure, ReporteEstadisticaSpSalidaRequestDTO request) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        p.put("@IndiceResultSet", valueOr(request.getIndiceResultSet(), 0));
        p.put("@NombreColumna", request.getNombreColumna());
        p.put("@NombreVisual", request.getNombreVisual());
        p.put("@TipoDato", request.getTipoDato());
        p.put("@Nullable", request.getNullable() == null ? Boolean.TRUE : request.getNullable());
        p.put("@Orden", request.getOrden());
        p.put("@IdUsuario", request.getIdUsuario());
        return operation("dbo.ff_IReporteEstadisticaStoredProcedureSalida", p);
    }

    @Override
    public Map<String, Object> actualizarSalida(int idSalida, ReporteEstadisticaSpSalidaRequestDTO request) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put("@IdSalida", Integer.valueOf(idSalida));
        p.put("@NombreColumna", request.getNombreColumna());
        p.put("@NombreVisual", request.getNombreVisual());
        p.put("@TipoDato", request.getTipoDato());
        p.put("@Nullable", request.getNullable() == null ? Boolean.TRUE : request.getNullable());
        p.put("@Orden", request.getOrden());
        p.put("@IdUsuario", request.getIdUsuario());
        return operation("dbo.ff_UReporteEstadisticaStoredProcedureSalida", p);
    }

    @Override
    public Map<String, Object> cambiarEstatusSalida(int idSalida, CambioEstatusRequestDTO request) {
        return operation("dbo.ff_UEstatusReporteEstadisticaStoredProcedureSalida",
                statusParams("@IdSalida", idSalida, request));
    }

    @Override
    public Map<String, Object> crearFiltro(int idStoredProcedure, ReporteEstadisticaSpFiltroRequestDTO request) {
        LinkedHashMap<String, Object> p = filtroParams(request, false, 0, idStoredProcedure);
        return operation("dbo.ff_IReporteEstadisticaStoredProcedureFiltro", p);
    }

    @Override
    public Map<String, Object> actualizarFiltro(int idRelacion, ReporteEstadisticaSpFiltroRequestDTO request) {
        LinkedHashMap<String, Object> p = filtroParams(request, true, idRelacion, 0);
        return operation("dbo.ff_UReporteEstadisticaStoredProcedureFiltro", p);
    }

    @Override
    public Map<String, Object> cambiarEstatusFiltro(int idRelacion, CambioEstatusRequestDTO request) {
        return operation("dbo.ff_UEstatusReporteEstadisticaStoredProcedureFiltro",
                statusParams("@IdStoredProcedureFiltro", idRelacion, request));
    }

    private LinkedHashMap<String, Object> storedProcedureParams(ReporteEstadisticaSpRequestDTO request,
            boolean includeId, int idStoredProcedure) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        if (includeId) p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        p.put("@Clave", request.getClave());
        p.put("@Nombre", request.getNombre());
        p.put("@NombreTecnico", request.getNombreTecnico());
        p.put("@Descripcion", request.getDescripcion());
        p.put("@IdUsuario", request.getIdUsuario());
        p.put("@HashDefinicionValidada", null);
        return p;
    }

    private LinkedHashMap<String, Object> filtroParams(ReporteEstadisticaSpFiltroRequestDTO request,
            boolean includeId, int idRelacion, int idStoredProcedure) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        if (includeId) p.put("@IdStoredProcedureFiltro", Integer.valueOf(idRelacion));
        else p.put("@IdStoredProcedure", Integer.valueOf(idStoredProcedure));
        p.put("@IdFiltro", request.getIdFiltro());
        p.put("@ColumnaValor", request.getColumnaValor());
        p.put("@ColumnaTexto", request.getColumnaTexto());
        p.put("@OrdenSugerido", request.getOrdenSugerido());
        p.put("@IdUsuario", request.getIdUsuario());
        return p;
    }

    private LinkedHashMap<String, Object> statusParams(String idName, int id, CambioEstatusRequestDTO request) {
        LinkedHashMap<String, Object> p = new LinkedHashMap<String, Object>();
        p.put(idName, Integer.valueOf(id));
        p.put("@IdEstatus", request.getIdEstatus());
        p.put("@IdUsuario", request.getIdUsuario());
        return p;
    }

    private Map<String, Object> operation(String procedure, LinkedHashMap<String, Object> parameters) {
        List<List<Map<String, Object>>> sets = call(procedure, parameters);
        for (int i = sets.size() - 1; i >= 0; i--) {
            if (!sets.get(i).isEmpty()) return sets.get(i).get(0);
        }
        return new LinkedHashMap<String, Object>();
    }

    private List<List<Map<String, Object>>> call(String procedure) {
        return call(procedure, new LinkedHashMap<String, Object>());
    }

    private List<List<Map<String, Object>>> call(String procedure, LinkedHashMap<String, Object> parameters) {
        StringBuilder sql = new StringBuilder("{call ").append(procedure);
        if (!parameters.isEmpty()) {
            sql.append('(');
            for (int i = 0; i < parameters.size(); i++) {
                if (i > 0) sql.append(',');
                sql.append('?');
            }
            sql.append(')');
        }
        sql.append('}');

        List<List<Map<String, Object>>> resultSets = new ArrayList<List<Map<String, Object>>>();
        try (Connection connection = dataSource.getConnection();
             CallableStatement statement = connection.prepareCall(sql.toString())) {
            int index = 1;
            for (Object value : parameters.values()) {
                bind(statement, index++, value);
            }

            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet rs = statement.getResultSet()) {
                        resultSets.add(readRows(rs));
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
        } catch (SQLException ex) {
            throw new IllegalStateException(databaseMessage(ex), ex);
        }
        return resultSets;
    }

    private void bind(CallableStatement statement, int index, Object value) throws SQLException {
        if (value == null) {
            statement.setNull(index, Types.NULL);
        } else if (value instanceof Integer) {
            statement.setInt(index, ((Integer) value).intValue());
        } else if (value instanceof Long) {
            statement.setLong(index, ((Long) value).longValue());
        } else if (value instanceof Boolean) {
            statement.setBoolean(index, ((Boolean) value).booleanValue());
        } else if (value instanceof Timestamp) {
            statement.setTimestamp(index, (Timestamp) value);
        } else {
            statement.setString(index, String.valueOf(value));
        }
    }

    private List<Map<String, Object>> readRows(ResultSet rs) throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
        ResultSetMetaData md = rs.getMetaData();
        int count = md.getColumnCount();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<String, Object>();
            for (int i = 1; i <= count; i++) {
                row.put(md.getColumnLabel(i), rs.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }

    private List<Map<String, Object>> firstResultSet(List<List<Map<String, Object>>> sets) {
        return resultSet(sets, 0);
    }

    private List<Map<String, Object>> resultSet(List<List<Map<String, Object>>> sets, int index) {
        if (sets == null || index < 0 || index >= sets.size()) return new ArrayList<Map<String, Object>>();
        return sets.get(index);
    }

    private Map<String, Object> firstRow(List<List<Map<String, Object>>> sets, int index) {
        List<Map<String, Object>> rows = resultSet(sets, index);
        return rows.isEmpty() ? new LinkedHashMap<String, Object>() : rows.get(0);
    }

    private Timestamp timestampStartOfDay(String value) {
        return timestamp(value, false);
    }

    private Timestamp timestampEndOfDay(String value) {
        return timestamp(value, true);
    }

    private Timestamp timestamp(String value, boolean endOfDay) {
        if (value == null || value.trim().isEmpty()) return null;
        String normalized = value.trim().replace('T', ' ');
        if (normalized.length() == 10) {
            normalized += endOfDay ? " 23:59:59" : " 00:00:00";
        }
        if (normalized.length() == 16) normalized += ":00";
        return Timestamp.valueOf(normalized);
    }

    private Integer valueOr(Integer value, int fallback) {
        return value == null ? Integer.valueOf(fallback) : value;
    }

    private String databaseMessage(SQLException ex) {
        SQLException cursor = ex;
        String last = ex.getMessage();
        while (cursor != null) {
            if (cursor.getMessage() != null && !cursor.getMessage().trim().isEmpty()) {
                last = cursor.getMessage();
            }
            cursor = cursor.getNextException();
        }
        return last == null ? "Error al ejecutar la operación de base de datos." : last;
    }
}
