package com.lockton.rpt.mappers;

import java.util.List;
import java.util.stream.Collectors;

import com.lockton.rpt.models.dto.CatalogoReporteGenDTO;
import com.lockton.rpt.models.entities.CatalogoReporteGen;

public class CatRptGenMapper {
    public static CatalogoReporteGenDTO MapperDTO(CatalogoReporteGen ent) {
        CatalogoReporteGenDTO dto = new CatalogoReporteGenDTO();
        dto.setCatRptId(ent.getCatRptId());
        dto.setCatRptNombre(ent.getCatRptNombre());
        dto.setCatRptProgramado(ent.getCatRptProgramado());
        dto.setCatRptActivo(ent.getCatRptActivo());
        dto.setCatRptHorario(ent.getCatRptHorario());
        return dto;
    }

    public static List<CatalogoReporteGenDTO> MapperDTO(List<CatalogoReporteGen> ent) {
        return ent
            .stream()
            .map(CatRptGenMapper::MapperDTO)
            .collect(Collectors.toList());
    }

    public static CatalogoReporteGen MapperEntity(CatalogoReporteGenDTO dto) {
        CatalogoReporteGen ent = new CatalogoReporteGen();
        ent.setCatRptId(dto.getCatRptId());
        ent.setCatRptNombre(dto.getCatRptNombre());
        ent.setCatRptProgramado(dto.getCatRptProgramado());
        ent.setCatRptActivo(dto.getCatRptActivo());
        ent.setCatRptHorario(dto.getCatRptHorario());
        return ent;
    }
    
    public static List<CatalogoReporteGen> MapperEntity(List<CatalogoReporteGenDTO> dto) {
        return dto
            .stream()
            .map(CatRptGenMapper::MapperEntity)
            .collect(Collectors.toList());
    }
}