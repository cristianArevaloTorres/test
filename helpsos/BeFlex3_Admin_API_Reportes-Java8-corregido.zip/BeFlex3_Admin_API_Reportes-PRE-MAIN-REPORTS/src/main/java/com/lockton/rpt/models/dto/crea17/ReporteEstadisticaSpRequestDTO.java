package com.lockton.rpt.models.dto.crea17;

public class ReporteEstadisticaSpRequestDTO {
    private String clave;
    private String nombre;
    private String nombreTecnico;
    private String descripcion;
    private Integer idUsuario;
    private Integer idCorporativo;
    private Integer idVigencia;

    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getNombreTecnico() { return nombreTecnico; }
    public void setNombreTecnico(String nombreTecnico) { this.nombreTecnico = nombreTecnico; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
    public Integer getIdCorporativo() { return idCorporativo; }
    public void setIdCorporativo(Integer idCorporativo) { this.idCorporativo = idCorporativo; }
    public Integer getIdVigencia() { return idVigencia; }
    public void setIdVigencia(Integer idVigencia) { this.idVigencia = idVigencia; }
}
