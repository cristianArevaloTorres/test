package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.repositories.CfgRptGenRepository;
import com.lockton.rpt.services.JwtService;
import com.lockton.rpt.services.ReporteService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/beflex")
@Api(tags = "Controlador de reportes")
public class WSReportesController {

    private static final Log LOGGER = LogFactory.getLog(WSReportesController.class);

    JwtService jwtService;
    ReporteService rptService;
    CfgRptGenRepository cfgRptGenRepository;

    public WSReportesController(JwtService jwtService, ReporteService rptService, CfgRptGenRepository cfgRptGenRepository) {
        this.jwtService = jwtService;
        this.rptService = rptService;
        this.cfgRptGenRepository = cfgRptGenRepository;
    }

    @PostMapping("/solicitarReporte/{reporteId}")
    @ApiOperation(value = "Solicitud de reportes en segundo plano", notes = "Operacion encargada de Generacion de Informacion de todos los reportes en segundo plano.")
    @ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<ResponseGralDTO> GetReporte(
        @RequestHeader("authorization") String token, 
        @PathVariable int reporteId,
        @ApiParam(value = "Mapa de filtros", required = false) @RequestBody String requestMapEncode) {
        LOGGER.info("Inicia controller ==> ReportesController ==> solicitarReporte... ReporteId:  " + reporteId + ", parametros: " +  requestMapEncode);
        ResponseGralDTO response = new ResponseGralDTO();
        Object jwt = null;
        
        jwt = jwtService.validarToken(token);
        if (jwt.toString() == "error" || jwt.toString() == "Unauthorized") {
            response.status = false;
            response.messages = "Token incorrecto";
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
        else
            response = rptService.EjecutarReporte(reporteId, requestMapEncode, token, 0);
        return ResponseEntity.ok().body(response);
    }
    
    @PostMapping("/solicitarReporteProgramado/{reporteId}/{controlReporteId}")
    @ApiOperation(value = "Solicitud de reportes programados en segundo plano", notes = "Operacion encargada de Generacion de Informacion de todos los reportes en segundo plano.")
    @ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
    public ResponseEntity<ResponseGralDTO> GetReporteProgramado(
        @RequestHeader("authorization") String token, 
        @PathVariable int reporteId,
        @PathVariable int controlReporteId,
        @ApiParam(value = "Mapa de filtros", required = false) @RequestBody String requestMapEncode) {
        LOGGER.info("Inicia controller ==> ReportesController ==> solicitarReporteProgramado... ReporteId:  " + reporteId + ", parametros: " +  requestMapEncode);
        ResponseGralDTO response = new ResponseGralDTO();
        if (token.equals(cfgRptGenRepository.findByCfgRptClave("TOKEN_API").get(0).getCfgRptValor())) {
            response.status = false;
            response.messages = "API token incorrecto";
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
        else
            response = rptService.EjecutarReporte(reporteId, requestMapEncode, token, controlReporteId);
        return ResponseEntity.accepted().body(response);
    }

    @PostMapping("/bitacora/pagina/{idPagina}/empleado/{idEmpleado}")
	public ResponseEntity<Void> crearBitacora(@PathVariable int idPagina, @PathVariable int idEmpleado, @RequestParam String ipUser, 
			@RequestParam String urlUser, @RequestParam int admin, @RequestParam int idEmpresa, @RequestParam String nombrePagina) {
		int retornoJdbc = 0;
		try {
			retornoJdbc = rptService.crearBitacora(idPagina, idEmpleado, ipUser, urlUser, admin, idEmpresa, nombrePagina);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
		if (retornoJdbc == 1) {
			return new ResponseEntity<Void>(HttpStatus.OK);
		} else {
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
	}

    @GetMapping("/descargar")
    @ApiOperation("Descarga de archivo generado por los reportes")
    public ResponseEntity<Resource> descargarArchivo(@ApiParam(value = "Ruta absoluta del archivo a descargar", required = true)
                                                     @RequestParam("ruta") String ruta) {
        if (ruta == null || ruta.trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        File file = new File(ruta);
        if (!file.exists() || !file.isFile()) {
            return ResponseEntity.notFound().build();
        }

        try {
            InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
            String contentType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    .contentLength(file.length())
                    .body(resource);
        } catch (IOException e) {
            LOGGER.error("Error al descargar archivo: " + ruta, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}