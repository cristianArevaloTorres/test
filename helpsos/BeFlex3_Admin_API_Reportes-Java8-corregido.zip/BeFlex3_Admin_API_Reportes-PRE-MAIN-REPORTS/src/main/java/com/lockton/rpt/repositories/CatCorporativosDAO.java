package com.lockton.rpt.repositories;

import java.util.List;
import java.util.Map;

public interface CatCorporativosDAO {

    /** Corporativos activos (ff_Empresa, todos los registros con EMidEstatus = 1). */
    List<Map<String, Object>> listarCorporativosActivos();
}
