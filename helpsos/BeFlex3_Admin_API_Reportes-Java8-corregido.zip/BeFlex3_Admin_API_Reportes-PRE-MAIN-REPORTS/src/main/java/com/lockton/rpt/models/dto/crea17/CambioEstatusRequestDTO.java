package com.lockton.rpt.models.dto.crea17;

public class CambioEstatusRequestDTO {
    private Integer idEstatus;
    private Integer idUsuario;

    public Integer getIdEstatus() { return idEstatus; }
    public void setIdEstatus(Integer idEstatus) { this.idEstatus = idEstatus; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
