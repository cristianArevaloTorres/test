package com.lockton.rpt.controllers;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lockton.rpt.models.dto.CatalogoReporteGenDTO;
import com.lockton.rpt.services.ReportesConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/beflex/reportes/configuracion")
@Api(tags = "Controlador para pantalla de configuración de reportes")
public class ReportesConfigController {
    
    private static final Log LOGGER = LogFactory.getLog(WSReportesController.class);

    @Autowired
    ReportesConfigService service;

    @GetMapping()
    @ApiOperation("Lectura de catálogo de reportes")
    public ResponseEntity<List<CatalogoReporteGenDTO>> GetAll() {
        return ResponseEntity.ok().body(service.getAll());
    }

    @PutMapping("/actualizar")
    @ApiOperation("Actualiza los reportes enviados")
    public ResponseEntity<List<CatalogoReporteGenDTO>> Actualizar(@RequestBody List<CatalogoReporteGenDTO> dtos) {
        return ResponseEntity.ok().body(service.actualizar(dtos));
    }
}
