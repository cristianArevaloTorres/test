package com.lockton.rpt.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;

@Service
public class SabanaBeneficiosLegacyService {

    private static final Log LOGGER = LogFactory.getLog(SabanaBeneficiosLegacyService.class);
    private static final int FOLIO_BATCH_SIZE = 500;

    private final JdbcTemplate jdbcTemplate;

    public SabanaBeneficiosLegacyService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void homologar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
            Map<String, Object> parametros) {
        if (resultsets == null || resultsets.isEmpty()) {
            return;
        }

        List<LinkedCaseInsensitiveMap<?>> gmm =
                localizarGrupo(resultsets, "GMM");
        List<LinkedCaseInsensitiveMap<?>> opc =
                localizarGrupo(resultsets, "OPC", "OPCIONALES");
        if (gmm.isEmpty() && opc.isEmpty()) {
            return;
        }

        int idEmpresa = resolverEntero(parametros, "idEmpresa", "admIdEmpresa");
        inicializarFolio(gmm);
        inicializarFolio(opc);

        Set<EmpleadoPlan> empleadosPlanes = new LinkedHashSet<>();
        recolectarEmpleadosPlanes(gmm, empleadosPlanes);
        recolectarEmpleadosPlanes(opc, empleadosPlanes);

        Map<EmpleadoPlan, String> folios = cargarFolios(empleadosPlanes);
        aplicarFoliosBase(gmm, folios);
        aplicarFoliosBase(opc, folios);

        Integer idPlanDentalia = leerParametroEntero(idEmpresa, 141);
        if (idPlanDentalia != null) {
            aplicarDentalia(gmm, idPlanDentalia);
            aplicarDentalia(opc, idPlanDentalia);
        }

        Integer idPlanDentegra = leerParametroEntero(idEmpresa, 142);
        if (idPlanDentegra != null) {
            aplicarDentegra(gmm, idPlanDentegra);
            aplicarDentegra(opc, idPlanDentegra);
        }
    }

    private List<LinkedCaseInsensitiveMap<?>> localizarGrupo(
            List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
            String... gruposBuscados) {
        for (ArrayList<LinkedCaseInsensitiveMap<?>> rows : resultsets) {
            if (rows == null || rows.isEmpty()) {
                continue;
            }
            Object grupo = rows.get(0).get("grupo");
            if (grupo == null) continue;
            String normalizado = normalizarGrupo(grupo);
            for (String grupoBuscado : gruposBuscados) {
                if (normalizado.equals(grupoBuscado)) {
                    return rows;
                }
            }
        }
        return Collections.emptyList();
    }

    private String normalizarGrupo(Object grupo) {
        return String.valueOf(grupo).trim().toUpperCase(Locale.ROOT);
    }

    private void inicializarFolio(List<LinkedCaseInsensitiveMap<?>> rows) {
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            put(row, "Folio", "");
        }
    }

    private void recolectarEmpleadosPlanes(List<LinkedCaseInsensitiveMap<?>> rows,
            Set<EmpleadoPlan> destino) {
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Integer idEmpleado = idEmpleado(row);
            Integer idPlan = entero(row.get("POidPlan"));
            if (idEmpleado != null && idPlan != null) {
                destino.add(new EmpleadoPlan(idEmpleado, idPlan));
            }
        }
    }

    private Map<EmpleadoPlan, String> cargarFolios(Set<EmpleadoPlan> pares) {
        if (pares.isEmpty()) {
            return Collections.emptyMap();
        }
        List<EmpleadoPlan> ordenados = new ArrayList<>(pares);
        Map<EmpleadoPlan, String> resultado = new LinkedHashMap<>();
        try {
            for (int inicio = 0; inicio < ordenados.size(); inicio += FOLIO_BATCH_SIZE) {
                int fin = Math.min(inicio + FOLIO_BATCH_SIZE, ordenados.size());
                cargarFoliosBatch(ordenados.subList(inicio, fin), resultado);
            }
            return resultado;
        } catch (DataAccessException ex) {
            LOGGER.warn("No fue posible consultar Folio en lote; se usara "
                    + "bf_BuscaFoliosPorIdsEmpleado como compatibilidad.", ex);
            return cargarFoliosConStoredProcedure(ordenados);
        }
    }

    private void cargarFoliosBatch(List<EmpleadoPlan> pares,
            Map<EmpleadoPlan, String> destino) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT DISTINCT SF.SFIdEmpleado AS IdEmpleado, ")
                .append("PF.PFIdPlan AS IdPlan, PF.PFFolio ")
                .append("FROM dbo.FF_EMPLEADO E WITH (NOLOCK) ")
                .append("INNER JOIN dbo.bf_SolicitudFolio SF WITH (NOLOCK) ")
                .append("ON E.Id = SF.SFIdEmpleado ")
                .append("INNER JOIN dbo.bf_PlanFolio PF WITH (NOLOCK) ")
                .append("ON PF.PFId = SF.SFIdPlanFolio WHERE ");

        List<Object> args = new ArrayList<>(pares.size() * 2);
        for (int i = 0; i < pares.size(); i++) {
            if (i > 0) {
                sql.append(" OR ");
            }
            sql.append("(SF.SFIdEmpleado = ? AND PF.PFIdPlan = ?)");
            args.add(pares.get(i).idEmpleado);
            args.add(pares.get(i).idPlan);
        }

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                sql.toString(), args.toArray());
        for (Map<String, Object> row : rows) {
            Integer idEmpleado = entero(valor(row, "IdEmpleado"));
            Integer idPlan = entero(valor(row, "IdPlan"));
            Object folio = valor(row, "PFFolio");
            if (idEmpleado != null && idPlan != null && folio != null) {
                destino.put(new EmpleadoPlan(idEmpleado, idPlan),
                        String.valueOf(folio).trim());
            }
        }
    }

    private Map<EmpleadoPlan, String> cargarFoliosConStoredProcedure(
            List<EmpleadoPlan> pares) {
        Map<EmpleadoPlan, String> resultado = new LinkedHashMap<>();
        for (EmpleadoPlan par : pares) {
            try {
                List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                        "EXEC dbo.bf_BuscaFoliosPorIdsEmpleado "
                                + "@IdEmpleado = ?, @IdPlan = ?",
                        par.idEmpleado, par.idPlan);
                for (Map<String, Object> row : rows) {
                    Object folio = valor(row, "PFFolio");
                    if (folio != null) {
                        resultado.put(par, String.valueOf(folio).trim());
                    }
                }
            } catch (DataAccessException ex) {
                LOGGER.warn("No fue posible recuperar Folio para empleado "
                        + par.idEmpleado + " y plan " + par.idPlan + ".", ex);
            }
        }
        return resultado;
    }

    private void aplicarFoliosBase(List<LinkedCaseInsensitiveMap<?>> rows,
            Map<EmpleadoPlan, String> folios) {
        Set<EmpleadoPlan> procesados = new LinkedHashSet<>();
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Integer idEmpleado = idEmpleado(row);
            Integer idPlan = entero(row.get("POidPlan"));
            if (idEmpleado == null || idPlan == null) {
                continue;
            }
            EmpleadoPlan par = new EmpleadoPlan(idEmpleado, idPlan);
            if (!procesados.add(par)) continue;
            String folio = folios.get(par);
            if (folio != null) {
                put(row, "Folio", folio);
            }
        }
    }

    private void aplicarDentalia(List<LinkedCaseInsensitiveMap<?>> rows, int idPlan) {
        Set<EmpleadoPlan> procesados = new LinkedHashSet<>();
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Integer plan = entero(row.get("POidPlan"));
            Integer empleado = idEmpleado(row);
            String numeroEmpleado = texto(row.get("EMNumeroEmpleado"));
            if (plan != null && plan == idPlan && empleado != null
                    && procesados.add(new EmpleadoPlan(empleado, plan))
                    && !numeroEmpleado.isEmpty()) {
                put(row, "Folio", "BIMBO-" + numeroEmpleado);
            }
        }
    }

    private void aplicarDentegra(List<LinkedCaseInsensitiveMap<?>> rows, int idPlan) {
        Map<String, List<LinkedCaseInsensitiveMap<?>>> porNumeroEmpleado =
                new LinkedHashMap<>();
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Integer plan = entero(row.get("POidPlan"));
            String numeroEmpleado = texto(row.get("EMNumeroEmpleado"));
            if (plan != null && plan == idPlan && !numeroEmpleado.isEmpty()) {
                porNumeroEmpleado.computeIfAbsent(numeroEmpleado,
                        k -> new ArrayList<>()).add(row);
            }
        }

        for (Map.Entry<String, List<LinkedCaseInsensitiveMap<?>>> entry
                : porNumeroEmpleado.entrySet()) {
            String numeroEmpleado = entry.getKey();
            List<LinkedCaseInsensitiveMap<?>> dependientes = new ArrayList<>();
            boolean tieneTitular = false;

            for (LinkedCaseInsensitiveMap<?> row : entry.getValue()) {
                Integer parentesco = entero(row.get("EMIdParentesco"));
                if (parentesco != null && parentesco == 1) {
                    put(row, "Folio", numeroEmpleado + "-1");
                    tieneTitular = true;
                } else {
                    dependientes.add(row);
                }
            }

            if (!tieneTitular) continue;

            dependientes.sort(Comparator.comparing(
                    this::idEmpleado,
                    Comparator.nullsLast(Comparator.naturalOrder())));
            int consecutivo = 2;
            for (LinkedCaseInsensitiveMap<?> dependiente : dependientes) {
                put(dependiente, "Folio", numeroEmpleado + "-" + consecutivo++);
            }
        }
    }

    private Integer leerParametroEntero(int idEmpresa, int parametro) {
        if (idEmpresa <= 0) {
            return null;
        }
        try {
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                    "EXEC dbo.ff_GetParametro @Empresa = ?, @Parametro = ?",
                    idEmpresa, parametro);
            if (rows.isEmpty()) {
                return null;
            }
            return entero(valor(rows.get(0), "paValor"));
        } catch (DataAccessException ex) {
            LOGGER.warn("No fue posible consultar el parametro legacy "
                    + parametro + " para la empresa " + idEmpresa + ".", ex);
            return null;
        }
    }

    private int resolverEntero(Map<String, Object> parametros, String... llaves) {
        if (parametros == null) {
            return 0;
        }
        for (String llave : llaves) {
            Integer n = entero(parametros.get(llave));
            if (n != null) {
                return n;
            }
        }
        return 0;
    }

    private Integer idEmpleado(Map<String, ?> row) {
        Integer id = entero(row.get("IDEmp"));
        return id != null ? id : entero(row.get("Id"));
    }

    private Integer entero(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        String raw = String.valueOf(value).trim();
        if (raw.isEmpty()) {
            return null;
        }
        try {
            return new BigDecimal(raw.replace(",", "")).intValue();
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private String texto(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private Object valor(Map<String, Object> row, String llave) {
        if (row.containsKey(llave)) {
            return row.get(llave);
        }
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (entry.getKey() != null
                    && entry.getKey().equalsIgnoreCase(llave)) {
                return entry.getValue();
            }
        }
        return null;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private void put(LinkedCaseInsensitiveMap<?> row, String key, Object value) {
        ((Map) row).put(key, value);
    }

    private static final class EmpleadoPlan {
        private final int idEmpleado;
        private final int idPlan;

        private EmpleadoPlan(int idEmpleado, int idPlan) {
            this.idEmpleado = idEmpleado;
            this.idPlan = idPlan;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof EmpleadoPlan)) {
                return false;
            }
            EmpleadoPlan other = (EmpleadoPlan) obj;
            return idEmpleado == other.idEmpleado && idPlan == other.idPlan;
        }

        @Override
        public int hashCode() {
            return Objects.hash(idEmpleado, idPlan);
        }
    }
}
