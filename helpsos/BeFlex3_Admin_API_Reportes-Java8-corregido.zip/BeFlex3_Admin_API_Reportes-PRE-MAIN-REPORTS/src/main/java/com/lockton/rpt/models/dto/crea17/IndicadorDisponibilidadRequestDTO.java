package com.lockton.rpt.models.dto.crea17;

import java.util.ArrayList;
import java.util.List;

public class IndicadorDisponibilidadRequestDTO {
    private String modo;
    private List<Integer> idsCorporativo = new ArrayList<Integer>();
    private Integer idUsuario;

    public String getModo() { return modo; }
    public void setModo(String modo) { this.modo = modo; }
    public List<Integer> getIdsCorporativo() { return idsCorporativo; }
    public void setIdsCorporativo(List<Integer> idsCorporativo) {
        this.idsCorporativo = idsCorporativo == null
                ? new ArrayList<Integer>()
                : idsCorporativo;
    }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
