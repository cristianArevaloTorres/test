package com.lockton.rpt.models.entities;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "bf_CatReportesParams")
public class CatReportesParams {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "catReportesParamsId")
    private Integer catReportesParamsId;

    @Column(name = "catReportesSPId", nullable = false)
    private Integer catReportesSPId;

    @Column(name = "catReportesTipoDatoId", nullable = false)
    private Integer catReportesTipoDatoId;

    @Column(name = "catReportesParamsLongitud", length = 10, nullable = true)
    private String catReportesParamsLongitud;

    @Column(name = "catReportesParamsOrden")
    private Integer catReportesParamsOrden;

    @Column(name = "catReportesParamsNombre", length = 50, nullable = false)
    private String catReportesParamsNombre;

    @Column(name = "catReportesParamsDesc", length = 150)
    private String catReportesParamsDesc;

    @Column(name = "Esid")
    private Integer esid;

    @Column(name = "catReportesParamsUsuarioAdd")
    private Integer catReportesParamsUsuarioAdd;

    @Column(name = "catReportesParamsFechaAdd")
    private LocalDateTime catReportesParamsFechaAdd;

    @Column(name = "catReportesParamsUsuarioMod")
    private Integer catReportesParamsUsuarioMod;

    @Column(name = "catReportesParamsFechaMod")
    private LocalDateTime catReportesParamsFechaMod;

    @Column(name = "catReportesParamsUsuarioDel")
    private Integer catReportesParamsUsuarioDel;

    @Column(name = "catReportesParamsFechaDel")
    private LocalDateTime catReportesParamsFechaDel;
}