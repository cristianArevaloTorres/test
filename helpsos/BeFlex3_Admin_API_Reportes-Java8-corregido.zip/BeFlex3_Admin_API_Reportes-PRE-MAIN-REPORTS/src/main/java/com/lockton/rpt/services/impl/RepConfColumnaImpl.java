package com.lockton.rpt.services.impl;

import com.lockton.rpt.services.RepConfColumnaService;

public class RepConfColumnaImpl implements RepConfColumnaService {
    
}
