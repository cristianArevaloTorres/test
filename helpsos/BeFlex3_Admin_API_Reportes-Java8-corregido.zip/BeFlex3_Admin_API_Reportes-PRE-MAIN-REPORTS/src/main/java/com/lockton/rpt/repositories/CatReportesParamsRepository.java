package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.lockton.rpt.models.entities.CatReportesParams;
import java.util.List;

@Repository
public interface CatReportesParamsRepository extends JpaRepository<CatReportesParams, Integer> {
    List<CatReportesParams> findByCatReportesSPId(Integer catReportesSPId);
    List<CatReportesParams> findByCatReportesTipoDatoId(Integer catReportesTipoDatoId);
}