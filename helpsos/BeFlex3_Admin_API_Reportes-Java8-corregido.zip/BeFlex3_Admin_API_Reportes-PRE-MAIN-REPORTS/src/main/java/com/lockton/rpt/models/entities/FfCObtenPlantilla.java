package com.lockton.rpt.models.entities;

import java.util.Objects;

public class FfCObtenPlantilla {

	public Integer plIdPlantilla;
	public Integer ppIdEmpresa;
	public Integer ppIdPerfil;
	public Integer caIdCampo;
	public Integer reIdRegla;
	public Integer cpIdTitular;
	public Integer cpHabilitado;
	public Integer cpvisible;
	public String cpEtiqueta;
	public String cpRequerido;
	public Integer cpOrden;
	public Integer cpIdEstatus;
	public String caNombreCampo;
	public String caNombreComponente;
	public String caDescripcionComponente;
	public String caAyudaCampo;
	public String caTipoComponente;
	public String caTipoDato;
	public String caLongitud;
	public String caCaracteresValidos;
	public Integer cpEncriptado;
	public String plDescripcion;
	public String plPagina;
	public Integer caCatalogo;
    public String caDominio;
    public String cpRangoValores;
    public Integer cpConfirmacion;
        
    public FfCObtenPlantilla() {
    }

    public FfCObtenPlantilla(Integer plIdPlantilla, Integer ppIdEmpresa, Integer ppIdPerfil, Integer caIdCampo, Integer reIdRegla, Integer cpIdTitular, Integer cpHabilitado, Integer cpvisible, String cpEtiqueta, String cpRequerido, Integer cpOrden, Integer cpIdEstatus, String caNombreCampo, String caNombreComponente, String caDescripcionComponente, String caAyudaCampo, String caTipoComponente, String caTipoDato, String caLongitud, String caCaracteresValidos, Integer cpEncriptado, String plDescripcion, String plPagina, Integer caCatalogo, String caDominio, String cpRangoValores, Integer cpConfirmacion) {
        this.plIdPlantilla = plIdPlantilla;
        this.ppIdEmpresa = ppIdEmpresa;
        this.ppIdPerfil = ppIdPerfil;
        this.caIdCampo = caIdCampo;
        this.reIdRegla = reIdRegla;
        this.cpIdTitular = cpIdTitular;
        this.cpHabilitado = cpHabilitado;
        this.cpvisible = cpvisible;
        this.cpEtiqueta = cpEtiqueta;
        this.cpRequerido = cpRequerido;
        this.cpOrden = cpOrden;
        this.cpIdEstatus = cpIdEstatus;
        this.caNombreCampo = caNombreCampo;
        this.caNombreComponente = caNombreComponente;
        this.caDescripcionComponente = caDescripcionComponente;
        this.caAyudaCampo = caAyudaCampo;
        this.caTipoComponente = caTipoComponente;
        this.caTipoDato = caTipoDato;
        this.caLongitud = caLongitud;
        this.caCaracteresValidos = caCaracteresValidos;
        this.cpEncriptado = cpEncriptado;
        this.plDescripcion = plDescripcion;
        this.plPagina = plPagina;
        this.caCatalogo = caCatalogo;
        this.caDominio = caDominio;
        this.cpRangoValores = cpRangoValores;
        this.cpConfirmacion = cpConfirmacion;
    }

    public Integer getPlIdPlantilla() {
        return plIdPlantilla;
    }

    public void setPlIdPlantilla(Integer plIdPlantilla) {
        this.plIdPlantilla = plIdPlantilla;
    }

    public Integer getPpIdEmpresa() {
        return ppIdEmpresa;
    }

    public void setPpIdEmpresa(Integer ppIdEmpresa) {
        this.ppIdEmpresa = ppIdEmpresa;
    }

    public Integer getPpIdPerfil() {
        return ppIdPerfil;
    }

    public void setPpIdPerfil(Integer ppIdPerfil) {
        this.ppIdPerfil = ppIdPerfil;
    }

    public Integer getCaIdCampo() {
        return caIdCampo;
    }

    public void setCaIdCampo(Integer caIdCampo) {
        this.caIdCampo = caIdCampo;
    }

    public Integer getReIdRegla() {
        return reIdRegla;
    }

    public void setReIdRegla(Integer reIdRegla) {
        this.reIdRegla = reIdRegla;
    }

    public Integer getCpIdTitular() {
        return cpIdTitular;
    }

    public void setCpIdTitular(Integer cpIdTitular) {
        this.cpIdTitular = cpIdTitular;
    }

    public Integer getCpHabilitado() {
        return cpHabilitado;
    }

    public void setCpHabilitado(Integer cpHabilitado) {
        this.cpHabilitado = cpHabilitado;
    }

    public Integer getCpvisible() {
        return cpvisible;
    }

    public void setCpvisible(Integer cpvisible) {
        this.cpvisible = cpvisible;
    }

    public String getCpEtiqueta() {
        return cpEtiqueta;
    }

    public void setCpEtiqueta(String cpEtiqueta) {
        this.cpEtiqueta = cpEtiqueta;
    }

    public String getCpRequerido() {
        return cpRequerido;
    }

    public void setCpRequerido(String cpRequerido) {
        this.cpRequerido = cpRequerido;
    }

    public Integer getCpOrden() {
        return cpOrden;
    }

    public void setCpOrden(Integer cpOrden) {
        this.cpOrden = cpOrden;
    }

    public Integer getCpIdEstatus() {
        return cpIdEstatus;
    }

    public void setCpIdEstatus(Integer cpIdEstatus) {
        this.cpIdEstatus = cpIdEstatus;
    }

    public String getCaNombreCampo() {
        return caNombreCampo;
    }

    public void setCaNombreCampo(String caNombreCampo) {
        this.caNombreCampo = caNombreCampo;
    }

    public String getCaNombreComponente() {
        return caNombreComponente;
    }

    public void setCaNombreComponente(String caNombreComponente) {
        this.caNombreComponente = caNombreComponente;
    }

    public String getCaDescripcionComponente() {
        return caDescripcionComponente;
    }

    public void setCaDescripcionComponente(String caDescripcionComponente) {
        this.caDescripcionComponente = caDescripcionComponente;
    }

    public String getCaAyudaCampo() {
        return caAyudaCampo;
    }

    public void setCaAyudaCampo(String caAyudaCampo) {
        this.caAyudaCampo = caAyudaCampo;
    }

    public String getCaTipoComponente() {
        return caTipoComponente;
    }

    public void setCaTipoComponente(String caTipoComponente) {
        this.caTipoComponente = caTipoComponente;
    }

    public String getCaTipoDato() {
        return caTipoDato;
    }

    public void setCaTipoDato(String caTipoDato) {
        this.caTipoDato = caTipoDato;
    }

    public String getCaLongitud() {
        return caLongitud;
    }

    public void setCaLongitud(String caLongitud) {
        this.caLongitud = caLongitud;
    }

    public String getCaCaracteresValidos() {
        return caCaracteresValidos;
    }

    public void setCaCaracteresValidos(String caCaracteresValidos) {
        this.caCaracteresValidos = caCaracteresValidos;
    }

    public Integer getCpEncriptado() {
        return cpEncriptado;
    }

    public void setCpEncriptado(Integer cpEncriptado) {
        this.cpEncriptado = cpEncriptado;
    }

    public String getPlDescripcion() {
        return plDescripcion;
    }

    public void setPlDescripcion(String plDescripcion) {
        this.plDescripcion = plDescripcion;
    }

    public String getPlPagina() {
        return plPagina;
    }

    public void setPlPagina(String plPagina) {
        this.plPagina = plPagina;
    }

    public Integer getCaCatalogo() {
        return caCatalogo;
    }

    public void setCaCatalogo(Integer caCatalogo) {
        this.caCatalogo = caCatalogo;
    }

    public String getCaDominio() {
        return caDominio;
    }

    public void setCaDominio(String caDominio) {
        this.caDominio = caDominio;
    }

    public String getCpRangoValores() {
        return cpRangoValores;
    }

    public void setCpRangoValores(String cpRangoValores) {
        this.cpRangoValores = cpRangoValores;
    }
       

    public Integer getCpConfirmacion() {
        return cpConfirmacion;
    }

    public void setCpConfirmacion(Integer cpConfirmacion) {
        this.cpConfirmacion = cpConfirmacion;
    }

	@Override
	public String toString() {
		try {
			return new com.fasterxml.jackson.databind.ObjectMapper().writerWithDefaultPrettyPrinter()
					.writeValueAsString(this);
		} catch (com.fasterxml.jackson.core.JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}
        
        private String nullSafeTrim(String input){
            return input != null ? input.trim() : input;
        }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.plIdPlantilla);
        hash = 89 * hash + Objects.hashCode(this.ppIdEmpresa);
        hash = 89 * hash + Objects.hashCode(this.ppIdPerfil);
        hash = 89 * hash + Objects.hashCode(this.caIdCampo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FfCObtenPlantilla other = (FfCObtenPlantilla) obj;
        if (!Objects.equals(this.plIdPlantilla, other.plIdPlantilla)) {
            return false;
        }
        if (!Objects.equals(this.ppIdEmpresa, other.ppIdEmpresa)) {
            return false;
        }
        if (!Objects.equals(this.ppIdPerfil, other.ppIdPerfil)) {
            return false;
        }
        if (!Objects.equals(this.caIdCampo, other.caIdCampo)) {
            return false;
        }
        return true;
    }
        
        
}