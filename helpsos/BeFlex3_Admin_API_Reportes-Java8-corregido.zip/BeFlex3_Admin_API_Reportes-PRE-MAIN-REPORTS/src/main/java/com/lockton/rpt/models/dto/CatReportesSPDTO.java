package com.lockton.rpt.models.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CatReportesSPDTO {
    private Integer id;
    private Integer catReportesId;
    private String nombre;
    private Integer orden;
    private String descripcion;
    private Integer esid;
    private Integer catReportesSP;
    private Integer UsuarioAdd;
    private LocalDateTime fechaReg;
    private Integer userMod;
    private LocalDateTime fechaMod;
}