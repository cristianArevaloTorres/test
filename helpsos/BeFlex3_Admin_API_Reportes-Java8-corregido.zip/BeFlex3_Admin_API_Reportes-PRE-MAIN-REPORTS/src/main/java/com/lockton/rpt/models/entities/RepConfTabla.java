package com.lockton.rpt.models.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "bf_RepConf_Tabla")
public class RepConfTabla {
    @EmbeddedId
    private RepConfTablaPk id;

    @Column(name = "columnaGrupo", length = 256, nullable = true)
    private String columnaGrupo;

    @Column(name = "agruparPorColumna", nullable = false)
    private boolean agruparPorColumna;
    
    @Column(name = "indexTable", nullable = true)
    private Integer indexTable;

    @Column(name = "tituloTabla", length = 400, nullable = true)
    private String tituloTabla;

    @Column(name = "espacioIzquierda", nullable = true)
    private Integer espacioIzquierda;

    @Column(name = "espacioDerecha", nullable = true)
    private Integer espacioDerecha;

    @Column(name = "alineacion", length = 40, nullable = true)
    private String alineacion;

    @Column(name = "colorFondo", length = 60, nullable = true)
    private String colorFondo;

    @Column(name = "colorLetra", length = 64, nullable = true)
    private String colorLetra;

    @Column(name = "activo", nullable = false)
    private boolean activo;

    @Column(name = "repConfTablaUsuarioAdd", nullable = false)
    private Integer repConfTablaUsuarioAdd;

    @Column(name = "repConfTablaFechaAdd", nullable = false)
    private LocalDateTime repConfTablaFechaAdd;

    @Column(name = "repConfTablaUsuarioMod", nullable = true)
    private Integer repConfTablaUsuarioMod;

    @Column(name = "repConfTablaFechaMod", nullable = true)
    private LocalDateTime repConfTablaFechaMod;

    @Column(name = "repConfTablaUsuarioDel", nullable = true)
    private Integer repConfTablaUsuarioDel;

    @Column(name = "repConfTablaFechaDel", nullable = true)
    private LocalDateTime repConfTablaFechaDel;
}
