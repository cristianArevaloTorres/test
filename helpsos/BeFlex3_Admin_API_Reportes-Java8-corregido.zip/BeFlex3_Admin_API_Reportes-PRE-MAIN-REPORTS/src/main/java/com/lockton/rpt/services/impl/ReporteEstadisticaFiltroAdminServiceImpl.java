package com.lockton.rpt.services.impl;

import java.text.Normalizer;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroAdminRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroOrdenItemDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaFiltroOrdenRequestDTO;
import com.lockton.rpt.repositories.ReporteEstadisticaFiltroAdminDAO;
import com.lockton.rpt.services.ReporteEstadisticaFiltroAdminService;

import org.springframework.stereotype.Service;

@Service
public class ReporteEstadisticaFiltroAdminServiceImpl implements ReporteEstadisticaFiltroAdminService {
    private final ReporteEstadisticaFiltroAdminDAO repository;

    public ReporteEstadisticaFiltroAdminServiceImpl(ReporteEstadisticaFiltroAdminDAO repository) {
        this.repository = repository;
    }

    @Override
    public List<Map<String, Object>> listar(boolean incluirBajas) {
        return repository.listar(incluirBajas);
    }

    @Override
    public Map<String, Object> obtener(int idFiltro) {
        positive(idFiltro, "El filtro es requerido.");
        Map<String, Object> item = repository.obtener(idFiltro);
        if (item == null || item.isEmpty()) {
            throw new IllegalArgumentException("El filtro solicitado no existe.");
        }
        return item;
    }

    @Override
    public Map<String, Object> auditoria(int idFiltro) {
        positive(idFiltro, "El filtro es requerido.");
        Map<String, Object> item = repository.auditoria(idFiltro);
        if (item == null || item.isEmpty()) {
            throw new IllegalArgumentException("El filtro solicitado no existe.");
        }
        return item;
    }

    @Override
    public List<Map<String, Object>> listarCampos(Integer idFiltro, boolean soloDisponibles, String tipoCampo) {
        String normalized = tipoCampo == null ? null : tipoCampo.trim().toUpperCase(Locale.ROOT);
        if (normalized != null && normalized.isEmpty()) normalized = null;
        if (normalized != null && !"ID".equals(normalized) && !"TEXTO".equals(normalized) && !"FECHA".equals(normalized)) {
            throw new IllegalArgumentException("El tipo de campo debe ser ID, TEXTO o FECHA.");
        }
        return repository.listarCampos(idFiltro, soloDisponibles, normalized);
    }

    @Override
    public Map<String, Object> sincronizarCampos(int idUsuario) {
        positive(idUsuario, "El usuario es requerido.");
        return repository.sincronizarCampos(idUsuario);
    }

    @Override
    public Map<String, Object> crear(ReporteEstadisticaFiltroAdminRequestDTO request) {
        if (request == null) throw new IllegalArgumentException("La solicitud es requerida.");
        request.setClave(technicalKey(request.getNombre()));
        request.setOrden(null); // El orden se calcula exclusivamente en BD.
        request.setObservaciones(null);
        request.setMostrarEnModulo(Boolean.TRUE); // Compatibilidad runtime; ya no es dato administrable.
        validate(request);
        Map<String, Object> result = repository.crear(request);
        requiredPositiveId(result, "La base de datos no devolvió un identificador válido para el filtro.");
        return result;
    }

    @Override
    public Map<String, Object> actualizar(int idFiltro, ReporteEstadisticaFiltroAdminRequestDTO request) {
        positive(idFiltro, "El filtro es requerido.");
        if (request == null) throw new IllegalArgumentException("La solicitud es requerida.");

        Map<String, Object> current = obtener(idFiltro);
        request.setClave(stringValue(current.get("Clave"))); // La clave técnica queda congelada después del alta.
        request.setOrden(integerValue(current.get("Orden"))); // Sólo Reordenar puede modificarla.
        request.setObservaciones(nullableString(current.get("Observaciones")));
        request.setMostrarEnModulo(Boolean.TRUE); // Campo legacy interno, no administrable por el usuario.
        validate(request);
        return repository.actualizar(idFiltro, request);
    }

    @Override
    public Map<String, Object> reordenar(ReporteEstadisticaFiltroOrdenRequestDTO request) {
        if (request == null) throw new IllegalArgumentException("La solicitud es requerida.");
        positive(value(request.getIdUsuario()), "El usuario es requerido.");
        if (request.getElementos() == null || request.getElementos().isEmpty()) {
            throw new IllegalArgumentException("El nuevo orden es requerido.");
        }

        Set<Integer> ids = new HashSet<Integer>();
        Set<Integer> orders = new HashSet<Integer>();
        for (ReporteEstadisticaFiltroOrdenItemDTO item : request.getElementos()) {
            if (item == null) throw new IllegalArgumentException("El orden contiene un elemento inválido.");
            int idFiltro = value(item.getIdFiltro());
            int orden = value(item.getOrden());
            positive(idFiltro, "Todos los filtros del orden deben tener un ID válido.");
            positive(orden, "Todos los filtros deben tener un orden mayor a cero.");
            if (!ids.add(Integer.valueOf(idFiltro))) {
                throw new IllegalArgumentException("El nuevo orden contiene filtros duplicados.");
            }
            if (!orders.add(Integer.valueOf(orden))) {
                throw new IllegalArgumentException("El nuevo orden contiene posiciones duplicadas.");
            }
        }
        return repository.reordenar(request);
    }

    @Override
    public Map<String, Object> cambiarEstatus(int idFiltro, CambioEstatusRequestDTO request) {
        positive(idFiltro, "El filtro es requerido.");
        if (request == null) throw new IllegalArgumentException("La solicitud es requerida.");
        if (request.getIdEstatus() == null
                || (request.getIdEstatus().intValue() != 1 && request.getIdEstatus().intValue() != 2)) {
            throw new IllegalArgumentException("El estatus debe ser 1 o 2.");
        }
        positive(value(request.getIdUsuario()), "El usuario es requerido.");
        return repository.cambiarEstatus(idFiltro, request);
    }


    private int requiredPositiveId(Map<String, Object> result, String message) {
        if (result == null) throw new IllegalStateException(message);
        Object raw = result.get("IdFiltro");
        if (raw == null) raw = result.get("idFiltro");
        int id = integerValue(raw);
        if (id <= 0) throw new IllegalStateException(message);
        return id;
    }

    private void validate(ReporteEstadisticaFiltroAdminRequestDTO request) {
        requiredText(request.getClave(), "La clave técnica no pudo generarse a partir del nombre.");
        max(request.getClave(), 50, "La clave excede 50 caracteres.");
        requiredText(request.getNombre(), "El nombre es requerido.");
        max(request.getNombre(), 120, "El nombre excede 120 caracteres.");
        max(request.getDescripcion(), 500, "La descripción excede 500 caracteres.");
        positive(value(request.getIdCampoValor()), "El campo de valor es requerido.");
        positive(value(request.getIdUsuario()), "El usuario es requerido.");

        String type = request.getTipoControl() == null ? "" : request.getTipoControl().trim().toUpperCase(Locale.ROOT);
        request.setTipoControl(type);
        if (!"LISTA".equals(type) && !"RANGO_FECHA".equals(type)) {
            throw new IllegalArgumentException("Tipo de control no permitido.");
        }
        if ("LISTA".equals(type)) {
            positive(value(request.getIdCampoTexto()), "El campo de texto es requerido.");
        } else {
            request.setIdCampoTexto(request.getIdCampoValor());
        }
    }

    private String technicalKey(String name) {
        requiredText(name, "El nombre es requerido.");
        String normalized = Normalizer.normalize(name.trim(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toUpperCase(Locale.ROOT)
                .replaceAll("[^A-Z0-9]+", "_")
                .replaceAll("_+", "_")
                .replaceAll("^_+|_+$", "");
        if (normalized.length() > 50) {
            normalized = normalized.substring(0, 50).replaceAll("_+$", "");
        }
        return normalized;
    }

    private void requiredText(String value, String message) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(message);
    }

    private void max(String value, int max, String message) {
        if (value != null && value.length() > max) throw new IllegalArgumentException(message);
    }

    private void positive(int value, String message) {
        if (value <= 0) throw new IllegalArgumentException(message);
    }

    private int value(Integer value) {
        return value == null ? 0 : value.intValue();
    }

    private int integerValue(Object value) {
        if (value instanceof Number) return ((Number) value).intValue();
        if (value == null) return 0;
        try { return Integer.parseInt(String.valueOf(value)); }
        catch (NumberFormatException ex) { return 0; }
    }

    private String stringValue(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    private String nullableString(Object value) {
        return value == null ? null : String.valueOf(value);
    }
}
