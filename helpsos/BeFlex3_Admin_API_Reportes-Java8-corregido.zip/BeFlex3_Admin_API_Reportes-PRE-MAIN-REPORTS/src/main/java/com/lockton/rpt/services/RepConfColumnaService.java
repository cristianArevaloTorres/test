package com.lockton.rpt.services;

public interface RepConfColumnaService {
    
}
