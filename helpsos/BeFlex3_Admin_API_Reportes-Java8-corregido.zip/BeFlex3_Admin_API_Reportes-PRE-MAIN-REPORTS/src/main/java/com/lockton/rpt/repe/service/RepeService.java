package com.lockton.rpt.repe.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.lockton.rpt.repe.dto.RepeConsultaRequest;
import com.lockton.rpt.repe.dto.RepeConsultaValidacionRequest;
import com.lockton.rpt.repe.dto.RepeEstatusRequest;
import com.lockton.rpt.repe.dto.RepeFiltroOrdenRequest;
import com.lockton.rpt.repe.dto.RepeFiltroRequest;
import com.lockton.rpt.repe.dto.RepeIndicadorRequest;
import com.lockton.rpt.repe.dto.RepeIndicadorDisponibilidadRequest;
import com.lockton.rpt.repe.dto.RepePlantillaRequest;
import com.lockton.rpt.repe.dto.RepePlantillaDuplicarRequest;
import com.lockton.rpt.repe.dto.RepeReplicarRequest;
import com.lockton.rpt.repe.dto.RepeTipoVisualizacionRequest;
import com.lockton.rpt.repe.repository.RepeRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class RepeService {
    private final RepeRepository repo;
    private final ObjectMapper objectMapper;

    public RepeService(RepeRepository repo, ObjectMapper objectMapper) {
        this.repo = repo;
        this.objectMapper = objectMapper;
    }

    private String jsonText(JsonNode node) {
        return node == null ? null : node.toString();
    }

    private void required(Object value, String message) {
        if (value == null || (value instanceof String && ((String) value).trim().isEmpty())) {
            throw new IllegalArgumentException(message);
        }
    }

    private int numberValue(Object value) {
        if (value instanceof Number) return ((Number) value).intValue();
        if (value == null) return 0;
        try { return Integer.parseInt(String.valueOf(value)); }
        catch (NumberFormatException ignored) { return 0; }
    }

    private String stringValue(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private String jsonTextValue(JsonNode node, String field) {
        if (node == null || field == null) return "";
        JsonNode value = node.get(field);
        if (value == null || value.isNull()) return "";
        return value.asText("").trim();
    }

    private boolean rowFlag(Object value) {
        if (value instanceof Boolean) return ((Boolean) value).booleanValue();
        if (value instanceof Number) return ((Number) value).intValue() != 0;
        if (value == null) return false;
        String text = String.valueOf(value).trim();
        return "1".equals(text) || "true".equalsIgnoreCase(text);
    }

    private Map<String, Object> findCampo(List<Map<String, Object>> campos, String nombreCampo) {
        if (nombreCampo == null || nombreCampo.trim().isEmpty()) return null;
        for (Map<String, Object> campo : campos) {
            Object value = campo.get("nombreCampo");
            if (value != null && nombreCampo.trim().equalsIgnoreCase(String.valueOf(value).trim())) {
                return campo;
            }
        }
        return null;
    }

    private Map<String, Object> parseJsonFields(Map<String, Object> row) {
        for (String key : new String[]{"configuracion", "corporativos", "requisitos", "contrato", "corporativosDisponibilidad"}) {
            Object value = row.get(key);
            if (value instanceof String) {
                try {
                    row.put(key, objectMapper.readTree((String) value));
                } catch (Exception ignored) {
                    // Si BD devuelve texto no JSON, se conserva el valor original para diagnóstico.
                }
            }
        }
        return row;
    }

    private List<Map<String, Object>> parseJsonFields(List<Map<String, Object>> rows) {
        for (Map<String, Object> row : rows) parseJsonFields(row);
        return rows;
    }

    public List<Map<String, Object>> tipos(boolean incluirBajas) {
        return parseJsonFields(repo.call("dbo.ff_REPE_TipoVisualizacion_Listar", incluirBajas));
    }

    public Map<String, Object> tipo(int id) {
        return parseJsonFields(repo.one("dbo.ff_REPE_TipoVisualizacion_Obtener", id));
    }

    public Map<String, Object> saveTipo(Integer id, RepeTipoVisualizacionRequest request) {
        required(request, "Body requerido");
        required(request.getClave(), "Clave requerida");
        required(request.getNombre(), "Nombre requerido");
        required(request.getConfiguracion(), "Configuración requerida");
        required(request.getIdUsuario(), "Usuario requerido");
        return parseJsonFields(repo.one(
                "dbo.ff_REPE_TipoVisualizacion_Guardar",
                id, request.getClave(), request.getNombre(), request.getDescripcion(),
                jsonText(request.getConfiguracion()), request.getIdUsuario()));
    }

    public List<Map<String, Object>> filtros(boolean incluirBajas) {
        return parseJsonFields(repo.call("dbo.ff_REPE_Filtro_Listar", incluirBajas));
    }

    public Map<String, Object> filtro(int id) {
        return parseJsonFields(repo.one("dbo.ff_REPE_Filtro_Obtener", id));
    }

    public List<Map<String, Object>> filtroCamposDisponibles(Integer idFiltroActual) {
        return repo.call("dbo.ff_REPE_FiltroCampo_ListarDisponibles", idFiltroActual);
    }

    public Map<String, Object> saveFiltro(Integer id, RepeFiltroRequest request) {
        required(request, "Body requerido");
        required(request.getClave(), "Clave requerida");
        required(request.getNombre(), "Nombre requerido");
        required(request.getOrden(), "Orden requerido");
        required(request.getTipoControl(), "Tipo control requerido");
        required(request.getConfiguracion(), "Configuración requerida");
        required(request.getIdUsuario(), "Usuario requerido");

        if (!request.getConfiguracion().isObject()) {
            throw new IllegalArgumentException("La configuración del filtro debe ser un objeto JSON.");
        }

        String tipoControl = request.getTipoControl().trim().toUpperCase();
        if (!"LISTA".equals(tipoControl) && !"RANGO_FECHA".equals(tipoControl)) {
            throw new IllegalArgumentException("Tipo de control no soportado.");
        }

        ObjectNode configuracion = ((ObjectNode) request.getConfiguracion()).deepCopy();
        if (!configuracion.has("version")) configuracion.put("version", 1);

        boolean esFiltroBase = configuracion.path("esFiltroBase").asBoolean(false);
        String campoValor = jsonTextValue(configuracion, "campoValor");
        String campoTexto = jsonTextValue(configuracion, "campoTexto");

        required(campoValor, "Campo valor requerido");

        List<Map<String, Object>> camposDisponibles = filtroCamposDisponibles(id);
        Map<String, Object> campoValorCatalogo = findCampo(camposDisponibles, campoValor);
        if (campoValorCatalogo == null) {
            throw new IllegalArgumentException("El campo valor no está disponible o ya está asignado a otro filtro activo.");
        }

        if ("LISTA".equals(tipoControl)) {
            required(campoTexto, "Campo texto requerido");
            if (campoValor.equalsIgnoreCase(campoTexto)) {
                throw new IllegalArgumentException("Campo valor y campo texto deben ser distintos para un filtro de lista.");
            }
            if (!rowFlag(campoValorCatalogo.get("esCampoId"))) {
                throw new IllegalArgumentException("El campo valor debe estar catalogado como campo ID.");
            }

            Map<String, Object> campoTextoCatalogo = findCampo(camposDisponibles, campoTexto);
            if (campoTextoCatalogo == null) {
                throw new IllegalArgumentException("El campo texto no está disponible o ya está asignado a otro filtro activo.");
            }
            if (!rowFlag(campoTextoCatalogo.get("esCampoTexto"))) {
                throw new IllegalArgumentException("El campo texto debe estar catalogado como campo de texto.");
            }
        } else {
            if (!rowFlag(campoValorCatalogo.get("esCampoFecha"))) {
                throw new IllegalArgumentException("El campo seleccionado debe estar catalogado como campo fecha.");
            }
            campoTexto = campoValor;
        }

        configuracion.put("esFiltroBase", esFiltroBase);
        configuracion.put("campoValor", campoValor);
        configuracion.put("campoTexto", campoTexto);

        ObjectNode corporativosNormalizados = objectMapper.createObjectNode();
        corporativosNormalizados.put("version", 1);
        ArrayNode idsNormalizados = corporativosNormalizados.putArray("idsCorporativos");

        if (esFiltroBase) {
            corporativosNormalizados.put("modo", "TODOS");
        } else {
            JsonNode corporativos = request.getCorporativos();
            if (corporativos == null || !corporativos.isObject()) {
                throw new IllegalArgumentException("Disponibilidad por corporativo requerida.");
            }

            String modo = jsonTextValue(corporativos, "modo").toUpperCase();
            if (!"INCLUIR".equals(modo) && !"EXCLUIR".equals(modo)) {
                throw new IllegalArgumentException("Un filtro no base sólo admite disponibilidad INCLUIR o EXCLUIR.");
            }

            JsonNode ids = corporativos.get("idsCorporativos");
            if (ids == null || !ids.isArray()) {
                throw new IllegalArgumentException("Debes seleccionar al menos un corporativo.");
            }

            Set<Integer> unicos = new LinkedHashSet<Integer>();
            for (JsonNode value : ids) {
                if (value != null && value.canConvertToInt() && value.asInt() > 0) {
                    unicos.add(Integer.valueOf(value.asInt()));
                }
            }
            if (unicos.isEmpty()) {
                throw new IllegalArgumentException("Debes seleccionar al menos un corporativo.");
            }
            for (Integer idCorporativo : unicos) idsNormalizados.add(idCorporativo.intValue());
            corporativosNormalizados.put("modo", modo);
        }

        return parseJsonFields(repo.one(
                "dbo.ff_REPE_Filtro_Guardar",
                id, request.getClave(), request.getNombre(), request.getDescripcion(), request.getOrden(),
                tipoControl, jsonText(configuracion), jsonText(corporativosNormalizados),
                request.getIdUsuario()));
    }

    public List<Map<String, Object>> reorderFiltros(RepeFiltroOrdenRequest request) {
        required(request, "Body requerido");
        required(request.getOrden(), "Orden requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        return parseJsonFields(repo.call(
                "dbo.ff_REPE_Filtro_Reordenar",
                jsonText(request.getOrden()), request.getIdUsuario()));
    }

    public List<Map<String, Object>> consultas(boolean incluirBajas) {
        return parseJsonFields(repo.call("dbo.ff_REPE_Consulta_Listar", incluirBajas));
    }

    public Map<String, Object> consulta(int id) {
        return parseJsonFields(repo.one("dbo.ff_REPE_Consulta_Obtener", id));
    }

    public Map<String, Object> validarConsultaPreRegistro(RepeConsultaValidacionRequest request) {
        required(request, "Solicitud de validación requerida");
        required(request.getNombreTecnico(), "Nombre técnico requerido");
        required(request.getIdCorporativo(), "Corporativo requerido para validar");
        required(request.getIdVigencia(), "Vigencia requerida para validar");

        if (request.getIdCorporativo().intValue() <= 0 || request.getIdVigencia().intValue() <= 0) {
            throw new IllegalArgumentException("No se encontró un contexto válido para ejecutar la validación.");
        }

        Map<String, Object> validation = repo.one(
                "dbo.ff_REPE_Consulta_ValidarPreRegistro",
                request.getNombreTecnico(), request.getIdConsultaActual());

        Map<String, Object> result = new LinkedHashMap<String, Object>();
        result.putAll(validation);
        result.put("contrato", null);
        result.put("columnas", new ArrayList<Map<String, Object>>());
        result.put("muestra", new ArrayList<Map<String, Object>>());

        if (!rowFlag(validation.get("valido"))) {
            return result;
        }

        try {
            int maxRows = request.getMaxFilas() == null ? 20 : request.getMaxFilas().intValue();
            Map<String, Object> preview = repo.callWithMetadata(
                    "dbo.bf_REPEQ_ResolverPreviewConsulta",
                    maxRows,
                    request.getIdCorporativo(), request.getIdVigencia(), request.getNombreTecnico());

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> columns = preview.get("columnas") instanceof List
                    ? (List<Map<String, Object>>) preview.get("columnas")
                    : new ArrayList<Map<String, Object>>();

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> sample = preview.get("muestra") instanceof List
                    ? (List<Map<String, Object>>) preview.get("muestra")
                    : new ArrayList<Map<String, Object>>();

            if (columns.isEmpty()) {
                result.put("valido", Boolean.FALSE);
                result.put("codigo", "SIN_SALIDA");
                result.put("mensaje", "El procedimiento no devolvió una salida tabular válida.");
                result.put("detalle", "La consulta debe devolver al menos una columna para poder mapear indicadores.");
                return result;
            }

            ObjectNode contract = objectMapper.createObjectNode();
            contract.put("version", 1);
            ArrayNode resultSets = contract.putArray("resultSets");
            ObjectNode set = resultSets.addObject();
            set.put("indice", 0);
            ArrayNode contractColumns = set.putArray("columnas");
            for (Map<String, Object> column : columns) {
                ObjectNode item = contractColumns.addObject();
                item.put("orden", numberValue(column.get("orden")));
                item.put("nombre", stringValue(column.get("nombre")));
                item.put("tipo", stringValue(column.get("tipo")));
                item.put("nullable", rowFlag(column.get("nullable")));
            }

            result.put("valido", Boolean.TRUE);
            result.put("codigo", "OK");
            result.put("mensaje", "Validación correcta. El procedimiento cumple con las reglas requeridas y puede registrarse.");
            result.put("detalle", null);
            result.put("contrato", contract);
            result.put("columnas", columns);
            result.put("muestra", sample);
            return result;
        } catch (Exception ex) {
            result.put("valido", Boolean.FALSE);
            result.put("codigo", "EJECUCION");
            result.put("mensaje", "El procedimiento no pudo ejecutarse correctamente con el contexto de validación.");
            result.put("detalle", "Revisa que la consulta pueda ejecutarse con el corporativo y la vigencia actuales y que devuelva una salida tabular.");
            return result;
        }
    }

    public Map<String, Object> saveConsulta(Integer id, RepeConsultaRequest request) {
        required(request, "Body requerido");
        required(request.getClave(), "Clave requerida");
        required(request.getNombre(), "Nombre requerido");
        required(request.getNombreTecnico(), "Nombre técnico requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        required(request.getIdCorporativoValidacion(), "Corporativo de validación requerido");
        required(request.getIdVigenciaValidacion(), "Vigencia de validación requerida");

        RepeConsultaValidacionRequest validationRequest = new RepeConsultaValidacionRequest();
        validationRequest.setNombreTecnico(request.getNombreTecnico());
        validationRequest.setIdConsultaActual(id);
        validationRequest.setIdCorporativo(request.getIdCorporativoValidacion());
        validationRequest.setIdVigencia(request.getIdVigenciaValidacion());
        validationRequest.setMaxFilas(Integer.valueOf(20));

        Map<String, Object> validation = validarConsultaPreRegistro(validationRequest);
        if (!rowFlag(validation.get("valido")) || !(validation.get("contrato") instanceof JsonNode)) {
            String message = stringValue(validation.get("mensaje"));
            throw new IllegalArgumentException(message.isEmpty()
                    ? "El procedimiento debe validarse correctamente antes de guardar la consulta."
                    : message);
        }

        ObjectNode requirements = objectMapper.createObjectNode();
        requirements.put("version", 1);
        ArrayNode parameters = requirements.putArray("parametros");
        ObjectNode corporate = parameters.addObject();
        corporate.put("nombre", "@IdCorporativo");
        corporate.put("tipo", "INT");
        corporate.put("requerido", true);
        ObjectNode term = parameters.addObject();
        term.put("nombre", "@IdVigencia");
        term.put("tipo", "INT");
        term.put("requerido", true);

        return parseJsonFields(repo.one(
                "dbo.ff_REPE_Consulta_Guardar",
                id, request.getClave(), request.getNombre(), request.getNombreTecnico(), request.getDescripcion(),
                request.getTipoUso() == null ? "INDICADOR" : request.getTipoUso(),
                jsonText(requirements), jsonText((JsonNode) validation.get("contrato")), request.getIdUsuario()));
    }

    public Map<String, Object> validarConsulta(int id) {
        return parseJsonFields(repo.one("dbo.ff_REPE_Consulta_Validar", id));
    }

    public List<Map<String, Object>> indicadores(String tipo, Integer idCorporativo, boolean incluirBajas) {
        return parseJsonFields(repo.call("dbo.ff_REPE_Indicador_Listar", tipo, idCorporativo, incluirBajas));
    }

    public Map<String, Object> indicador(int id) {
        return parseJsonFields(repo.one("dbo.ff_REPE_Indicador_ObtenerV2", id));
    }

    private Set<String> indicadorContratoCampos(JsonNode contrato) {
        Set<String> fields = new LinkedHashSet<String>();
        if (contrato == null || !contrato.isObject()) return fields;
        JsonNode resultSets = contrato.path("resultSets");
        if (!resultSets.isArray()) return fields;
        for (JsonNode resultSet : resultSets) {
            JsonNode columnas = resultSet.path("columnas");
            if (!columnas.isArray()) continue;
            for (JsonNode columna : columnas) {
                String nombre = columna.path("nombre").asText("").trim();
                if (!nombre.isEmpty()) fields.add(nombre.toUpperCase());
            }
        }
        return fields;
    }

    private String indicadorTokenKey(String value) {
        String normalized = value == null ? "" : value.trim().toUpperCase();
        if (normalized.startsWith("{{") && normalized.endsWith("}}") && normalized.length() > 4) {
            normalized = normalized.substring(2, normalized.length() - 2).trim();
        }
        return normalized;
    }

    private void validarIndicador(RepeIndicadorRequest request) {
        Map<String, Object> consulta = this.consulta(request.getIdConsulta().intValue());
        if (consulta.isEmpty()) throw new IllegalArgumentException("La consulta seleccionada no existe.");
        if (numberValue(consulta.get("idEstatus")) != 1) {
            throw new IllegalArgumentException("La consulta seleccionada no está activa.");
        }
        Object contratoValue = consulta.get("contrato");
        if (!(contratoValue instanceof JsonNode)) {
            throw new IllegalArgumentException("La consulta seleccionada no tiene un contrato de salida válido.");
        }
        Set<String> campos = indicadorContratoCampos((JsonNode) contratoValue);
        if (campos.isEmpty()) {
            throw new IllegalArgumentException("La consulta seleccionada no tiene columnas disponibles para mapear.");
        }

        Map<String, Object> tipoVisual = this.tipo(request.getIdTipoVisualizacion().intValue());
        if (tipoVisual.isEmpty()) throw new IllegalArgumentException("El tipo de visualización no existe.");
        if (numberValue(tipoVisual.get("idEstatus")) != 1) {
            throw new IllegalArgumentException("El tipo de visualización seleccionado no está activo.");
        }
        Object tipoConfigValue = tipoVisual.get("configuracion");
        if (!(tipoConfigValue instanceof JsonNode) || !((JsonNode) tipoConfigValue).isObject()) {
            throw new IllegalArgumentException("El tipo de visualización no tiene un contrato técnico válido.");
        }

        JsonNode configuracion = request.getConfiguracion();
        if (configuracion == null || !configuracion.isObject()) {
            throw new IllegalArgumentException("La configuración del indicador debe ser un objeto JSON válido.");
        }
        JsonNode visualizacion = configuracion.path("visualizacion");
        if (!visualizacion.isObject()) {
            throw new IllegalArgumentException("El indicador requiere configuración de visualización.");
        }
        JsonNode mapeos = visualizacion.path("mapeos");
        if (!mapeos.isArray()) {
            throw new IllegalArgumentException("La visualización requiere una colección de mapeos.");
        }

        JsonNode roles = ((JsonNode) tipoConfigValue).path("roles");
        Map<String, JsonNode> rolesByKey = new LinkedHashMap<String, JsonNode>();
        if (roles.isArray()) {
            for (JsonNode role : roles) {
                String clave = role.path("clave").asText("").trim().toUpperCase();
                if (!clave.isEmpty()) rolesByKey.put(clave, role);
            }
        }

        Map<String, Integer> roleCounts = new LinkedHashMap<String, Integer>();
        for (JsonNode mapping : mapeos) {
            String role = mapping.path("rol").asText("").trim().toUpperCase();
            String campo = mapping.path("campo").asText("").trim();
            if (role.isEmpty() || campo.isEmpty()) continue;
            if (!campos.contains(campo.toUpperCase())) {
                throw new IllegalArgumentException("El campo mapeado “" + campo + "” ya no existe en el contrato de la consulta.");
            }
            if (!rolesByKey.isEmpty() && !rolesByKey.containsKey(role)) {
                throw new IllegalArgumentException("El rol “" + role + "” no existe en el tipo de visualización seleccionado.");
            }
            Integer count = roleCounts.get(role);
            roleCounts.put(role, Integer.valueOf(count == null ? 1 : count.intValue() + 1));
        }

        for (Map.Entry<String, JsonNode> entry : rolesByKey.entrySet()) {
            JsonNode role = entry.getValue();
            int count = roleCounts.containsKey(entry.getKey()) ? roleCounts.get(entry.getKey()).intValue() : 0;
            int min = role.path("min").isNumber() ? role.path("min").asInt(0) : 0;
            JsonNode maxNode = role.get("max");
            Integer max = maxNode != null && maxNode.isNumber() ? Integer.valueOf(maxNode.asInt()) : null;
            if (count < min) {
                throw new IllegalArgumentException("El rol “" + role.path("nombre").asText(entry.getKey())
                        + "” requiere al menos " + min + " campo(s).");
            }
            if (max != null && max.intValue() >= 0 && count > max.intValue()) {
                throw new IllegalArgumentException("El rol “" + role.path("nombre").asText(entry.getKey())
                        + "” permite como máximo " + max + " campo(s).");
            }
        }

        Set<String> reserved = new LinkedHashSet<String>();
        for (Map<String, Object> global : variablesGlobales(false)) {
            String clave = indicadorTokenKey(stringValue(global.get("clave")));
            String token = indicadorTokenKey(stringValue(global.get("token")));
            if (!clave.isEmpty()) reserved.add(clave);
            if (!token.isEmpty()) reserved.add(token);
        }

        JsonNode variables = configuracion.path("variables");
        Set<String> seenTokens = new LinkedHashSet<String>();
        Set<String> seenKeys = new LinkedHashSet<String>();
        if (variables.isArray()) {
            for (JsonNode variable : variables) {
                String token = indicadorTokenKey(variable.path("token").asText(""));
                String clave = indicadorTokenKey(variable.path("clave").asText(token));
                String campo = variable.path("campo").asText("").trim();
                if (token.isEmpty()) throw new IllegalArgumentException("Las variables del indicador requieren token.");
                if (campo.isEmpty()) throw new IllegalArgumentException("Las variables del indicador requieren columna de origen.");
                if (!campos.contains(campo.toUpperCase())) {
                    throw new IllegalArgumentException("La variable “" + token + "” usa una columna que no existe en la consulta.");
                }
                if (!seenTokens.add(token)) throw new IllegalArgumentException("El token “" + token + "” está repetido en el indicador.");
                if (!clave.isEmpty() && !seenKeys.add(clave)) throw new IllegalArgumentException("La clave de variable “" + clave + "” está repetida en el indicador.");
                if (reserved.contains(token) || (!clave.isEmpty() && reserved.contains(clave))) {
                    throw new IllegalArgumentException("La variable “" + token + "” colisiona con una variable general activa.");
                }
            }
        }

        JsonNode traducciones = configuracion.path("traduccionesValores");
        if (traducciones.isArray()) {
            for (JsonNode traduccion : traducciones) {
                String campo = traduccion.path("campo").asText("").trim();
                String original = traduccion.path("valorOrigen").asText("").trim();
                JsonNode valores = traduccion.path("valores");
                boolean hasTranslation = false;
                if (valores.isObject()) {
                    java.util.Iterator<JsonNode> iterator = valores.elements();
                    while (iterator.hasNext()) {
                        if (!iterator.next().asText("").trim().isEmpty()) { hasTranslation = true; break; }
                    }
                }
                boolean touched = !campo.isEmpty() || !original.isEmpty() || hasTranslation;
                if (!touched) continue;
                if (campo.isEmpty() || original.isEmpty() || !hasTranslation) {
                    throw new IllegalArgumentException("Las traducciones capturadas requieren columna, valor original y valor traducido.");
                }
                if (!campos.contains(campo.toUpperCase())) {
                    throw new IllegalArgumentException("La traducción usa una columna que no existe en la consulta.");
                }
            }
        }
    }

    public Map<String, Object> saveIndicador(Integer id, RepeIndicadorRequest request) {
        required(request, "Body requerido");
        required(request.getNombre(), "Nombre requerido");
        required(request.getTipo(), "Tipo requerido");
        required(request.getIdConsulta(), "Consulta requerida");
        required(request.getIdTipoVisualizacion(), "Tipo visual requerido");
        required(request.getConfiguracion(), "Configuración requerida");
        required(request.getIdUsuario(), "Usuario requerido");
        validarIndicador(request);

        /*
         * RINIdCorporativo determina la pertenencia del registro:
         *   GLOBAL      -> NULL
         *   CORPORATIVO -> Id corporativo requerido
         *
         * La disponibilidad corporativa NO determina pertenencia. Es una regla adicional
         * de los indicadores GLOBAL para decidir en qué corporativos puede replicarse/consumirse.
         * Por eso debe persistirse y recuperarse; editar un indicador no debe volverla a TODOS.
         */
        String tipoIndicador = request.getTipo().trim().toUpperCase(java.util.Locale.ROOT);
        Integer idCorporativoFinal = "GLOBAL".equals(tipoIndicador) ? null : request.getIdCorporativo();
        if ("CORPORATIVO".equals(tipoIndicador) && idCorporativoFinal == null) {
            throw new IllegalArgumentException("Corporativo requerido para un indicador corporativo.");
        }

        String modoDisponibilidad = "TODOS";
        String corporativosJson = null;
        if ("GLOBAL".equals(tipoIndicador)) {
            modoDisponibilidad = request.getModoDisponibilidad() == null
                    ? "TODOS"
                    : request.getModoDisponibilidad().trim().toUpperCase(java.util.Locale.ROOT);
            if (!java.util.Arrays.asList("TODOS", "INCLUIR", "EXCLUIR").contains(modoDisponibilidad)) {
                throw new IllegalArgumentException("Modo de disponibilidad inválido.");
            }
            if (!"TODOS".equals(modoDisponibilidad)) {
                if (request.getCorporativosDisponibilidad() == null || !request.getCorporativosDisponibilidad().isArray()) {
                    throw new IllegalArgumentException("Selecciona al menos un corporativo para la disponibilidad configurada.");
                }
                if (request.getCorporativosDisponibilidad().size() == 0) {
                    throw new IllegalArgumentException("Selecciona al menos un corporativo para la disponibilidad configurada.");
                }
                corporativosJson = jsonText(request.getCorporativosDisponibilidad());
            }
        }

        return parseJsonFields(repo.one(
                "dbo.ff_REPE_Indicador_GuardarV2",
                id, request.getClave(), request.getNombre(), request.getDescripcion(), tipoIndicador,
                idCorporativoFinal, request.getIdIndicadorOrigen(), request.getIdConsulta(),
                request.getIdTipoVisualizacion(),
                modoDisponibilidad, corporativosJson, jsonText(request.getConfiguracion()),
                request.getIdUsuario()));
    }

    public Map<String, Object> saveIndicadorDisponibilidad(
            int idIndicador,
            RepeIndicadorDisponibilidadRequest request) {
        required(request, "Body requerido");
        required(request.getModoDisponibilidad(), "Modo de disponibilidad requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        if (idIndicador <= 0) throw new IllegalArgumentException("Indicador requerido.");

        String modo = request.getModoDisponibilidad().trim().toUpperCase(java.util.Locale.ROOT);
        if (!java.util.Arrays.asList("TODOS", "INCLUIR", "EXCLUIR").contains(modo)) {
            throw new IllegalArgumentException("Modo de disponibilidad inválido.");
        }

        String corporativosJson = null;
        if (!"TODOS".equals(modo)) {
            JsonNode corporativos = request.getCorporativosDisponibilidad();
            if (corporativos == null || !corporativos.isArray() || corporativos.size() == 0) {
                throw new IllegalArgumentException("Selecciona al menos un corporativo para la disponibilidad configurada.");
            }
            corporativosJson = jsonText(corporativos);
        }

        return parseJsonFields(repo.one(
                "dbo.ff_REPE_Indicador_Disponibilidad_Guardar",
                idIndicador, modo, corporativosJson, request.getIdUsuario()));
    }

    public Map<String, Object> replicarIndicador(int idIndicadorGlobal, RepeReplicarRequest request) {
        required(request, "Body requerido");
        required(request.getIdCorporativo(), "Corporativo requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        return parseJsonFields(repo.one(
                "dbo.ff_REPE_Indicador_Replicar",
                idIndicadorGlobal, request.getIdCorporativo(), request.getIdUsuario()));
    }

    public List<Map<String, Object>> plantillas(String tipo, Integer idCorporativo, boolean incluirBajas) {
        return parseJsonFields(repo.call("dbo.ff_REPE_Plantilla_Listar", tipo, idCorporativo, incluirBajas));
    }

    public Map<String, Object> plantilla(int id) {
        return parseJsonFields(repo.one("dbo.ff_REPE_Plantilla_Obtener", id));
    }

    public Map<String, Object> savePlantilla(Integer id, RepePlantillaRequest request) {
        required(request, "Body requerido");
        required(request.getClave(), "Clave requerida");
        required(request.getNombre(), "Nombre requerido");
        required(request.getTipo(), "Tipo requerido");
        required(request.getConfiguracion(), "Configuración requerida");
        required(request.getIdUsuario(), "Usuario requerido");
        if (request.getConfiguracion().has("lienzo")) {
            throw new IllegalArgumentException("El lienzo no forma parte del contrato REPE.");
        }
        return parseJsonFields(repo.one(
                "dbo.ff_REPE_Plantilla_Guardar",
                id, request.getClave(), request.getNombre(), request.getDescripcion(), request.getTipo(),
                request.getIdCorporativo(), request.getIdPlantillaOrigen(),
                request.getIdioma() == null ? "ES" : request.getIdioma(),
                jsonText(request.getConfiguracion()), request.getIdUsuario()));
    }

    public Map<String, Object> replicarPlantilla(int idPlantillaGlobal, RepeReplicarRequest request) {
        required(request, "Body requerido");
        required(request.getIdCorporativo(), "Corporativo requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        return parseJsonFields(repo.one(
                "dbo.ff_REPE_Plantilla_Replicar",
                idPlantillaGlobal, request.getIdCorporativo(), request.getIdUsuario()));
    }

    public Map<String, Object> duplicarPlantilla(int idPlantilla, RepePlantillaDuplicarRequest request) {
        required(request, "Body requerido");
        required(request.getNombre(), "Nombre requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        return parseJsonFields(repo.one(
                "dbo.ff_REPE_Plantilla_Duplicar",
                idPlantilla, request.getNombre(), request.getIdUsuario()));
    }

    public Map<String, Object> plantillaEstatus(int idPlantilla, RepeEstatusRequest request) {
        required(request, "Body requerido");
        required(request.getIdEstatus(), "Estatus requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        return repo.one(
                "dbo.ff_REPE_Plantilla_Estatus_Guardar",
                idPlantilla, request.getIdEstatus(), request.getIdUsuario());
    }

    public Map<String, Object> status(String entity, int id, RepeEstatusRequest request) {
        required(request, "Body requerido");
        required(request.getIdEstatus(), "Estatus requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        if ("INDICADOR".equalsIgnoreCase(entity)) {
            return repo.one("dbo.ff_REPE_Indicador_Estatus_Guardar", id, request.getIdEstatus(), request.getIdUsuario());
        }
        return repo.one("dbo.ff_REPE_Estatus_Guardar", entity, id, request.getIdEstatus(), request.getIdUsuario());
    }

    public List<Map<String, Object>> variablesGlobales(boolean incluirBajas) {
        return repo.call("dbo.ff_REPE_VariableGlobal_Listar", incluirBajas);
    }

    public List<Map<String, Object>> idiomas(boolean incluirBajas) {
        return repo.call("dbo.ff_REPE_Idioma_Listar", incluirBajas);
    }

    public List<Map<String, Object>> tiposArchivo(boolean incluirBajas) {
        return repo.call("dbo.ff_REPE_TipoArchivo_Listar", incluirBajas);
    }

    public List<Map<String, Object>> tamanosDocumento(boolean incluirBajas) {
        return repo.call("dbo.ff_REPE_TamanoDocumento_Listar", incluirBajas);
    }
    
    public List<Map<String, Object>> orientacionesArchivo(boolean incluirBajas) {
        return repo.call("dbo.ff_REPE_ArchivoOrientacion_Listar", incluirBajas);
    }
}
