package com.lockton.rpt.repe.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.rpt.repe.dto.RepeEstatusRequest;
import com.lockton.rpt.repe.dto.RepeLeyendaRequest;
import com.lockton.rpt.repe.repository.RepeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class RepeLeyendaService {
    private final RepeRepository repo;
    private final ObjectMapper objectMapper;

    public RepeLeyendaService(RepeRepository repo, ObjectMapper objectMapper) {
        this.repo = repo;
        this.objectMapper = objectMapper;
    }

    public List<Map<String, Object>> listar(Integer idConsulta, String idioma, boolean incluirBajas, boolean incluirGlobales) {
        List<Map<String, Object>> rows = repo.call("dbo.ff_REPE_Leyenda_Listar", idConsulta, idioma, incluirBajas, incluirGlobales);
        for (Map<String, Object> row : rows) parse(row);
        return rows;
    }

    public Map<String, Object> obtener(int id, String idioma) {
        return parse(repo.one("dbo.ff_REPE_Leyenda_Obtener", Integer.valueOf(id), idioma));
    }

    public Map<String, Object> resolver(Integer idConsulta, String clave, String idioma, String claveCondicion) {
        required(clave, "Clave requerida");
        return parse(repo.one("dbo.ff_REPE_Leyenda_Resolver", idConsulta, clave, idioma, claveCondicion));
    }

    public Map<String, Object> guardar(Integer id, RepeLeyendaRequest request) {
        required(request, "Body requerido");
        required(request.getClave(), "Clave requerida");
        required(request.getNombre(), "Nombre requerido");
        required(request.getTextos(), "Textos por idioma requeridos");
        required(request.getIdUsuario(), "Usuario requerido");
        if (!request.getTextos().isObject()) {
            throw new IllegalArgumentException("Los textos por idioma deben enviarse como un objeto JSON.");
        }
        return parse(repo.one(
                "dbo.ff_REPE_Leyenda_Guardar",
                id,
                request.getIdConsulta(),
                request.getClave(),
                request.getNombre(),
                request.getDescripcion(),
                request.getTipo() == null ? "LEYENDA" : request.getTipo(),
                request.getTextos().toString(),
                request.getClaveCondicion(),
                request.getOrden() == null ? Integer.valueOf(1) : request.getOrden(),
                request.getIdUsuario()));
    }

    public Map<String, Object> estatus(int id, RepeEstatusRequest request) {
        required(request, "Body requerido");
        required(request.getIdEstatus(), "Estatus requerido");
        required(request.getIdUsuario(), "Usuario requerido");
        return parse(repo.one(
                "dbo.ff_REPE_Leyenda_Estatus_Guardar",
                Integer.valueOf(id), request.getIdEstatus(), request.getIdUsuario()));
    }

    private Map<String, Object> parse(Map<String, Object> row) {
        Object value = row.get("textos");
        if (value instanceof String) {
            try {
                JsonNode json = objectMapper.readTree((String) value);
                row.put("textos", json);
            } catch (Exception ignored) {
            }
        }
        return row;
    }

    private void required(Object value, String message) {
        if (value == null || (value instanceof String && ((String) value).trim().isEmpty())) {
            throw new IllegalArgumentException(message);
        }
    }
}
