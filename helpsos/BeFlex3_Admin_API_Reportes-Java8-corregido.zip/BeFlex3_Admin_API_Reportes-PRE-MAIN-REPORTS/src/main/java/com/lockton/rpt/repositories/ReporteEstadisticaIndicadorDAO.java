package com.lockton.rpt.repositories;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorDisponibilidadRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorPasoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorReplicarRequestDTO;

import java.util.List;
import java.util.Map;

public interface ReporteEstadisticaIndicadorDAO {
    Map<String, Object> obtenerCatalogos();
    List<Map<String, Object>> listar(String tipo, Integer idCorporativo, boolean incluirBajas);
    Map<String, Object> obtener(int idIndicador);
    Map<String, Object> guardarPaso(IndicadorPasoGuardarRequestDTO request);
    Map<String, Object> cambiarEstatus(int idIndicador, CambioEstatusRequestDTO request);
    Map<String, Object> guardarDisponibilidad(
            int idIndicador,
            IndicadorDisponibilidadRequestDTO request);
    List<Map<String, Object>> listarGlobalesDisponibles(int idCorporativo);
    List<Map<String, Object>> replicar(
            int idCorporativo,
            IndicadorReplicarRequestDTO request);
    Map<String, Object> validarClave(
            String tipo,
            String clave,
            Integer idRegistro,
            Integer idIndicador);
    Map<String, Object> obtenerMuestraFuente(
            int idCorporativo,
            int idStoredProcedure,
            int maxFilas);
    List<Map<String, Object>> obtenerValoresDistintos(
            int idCorporativo,
            int idStoredProcedure,
            String columna,
            int maxValores);
}
