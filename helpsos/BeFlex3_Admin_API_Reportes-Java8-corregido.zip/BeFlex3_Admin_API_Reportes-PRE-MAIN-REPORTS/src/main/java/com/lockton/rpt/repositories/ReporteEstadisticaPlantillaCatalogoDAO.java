package com.lockton.rpt.repositories;

import java.util.List;
import java.util.Map;

public interface ReporteEstadisticaPlantillaCatalogoDAO {
    List<Map<String, Object>> listar(
            String tipo,
            Integer idCorporativo,
            boolean incluirBajas);

    Map<String, Object> catalogos();

    Map<String, Object> validarNombre(
            String tipo,
            Integer idCorporativo,
            String nombre,
            Integer idPlantilla);

    Map<String, Object> guardar(
            Integer idPlantilla,
            String tipo,
            Integer idCorporativo,
            String nombre,
            String descripcion,
            int idIdioma,
            Integer idTipoArchivo,
            Integer idTamanoDocumento,
            String orientacion,
            int idUsuario);

    Map<String, Object> cambiarEstatus(
            int idPlantilla,
            int idEstatus,
            int idUsuario);

    Map<String, Object> duplicarMismoNivel(
            int idPlantillaOrigen,
            String tipoDestino,
            Integer idCorporativo,
            String nombre,
            Integer idIdioma,
            int idUsuario);

    Map<String, Object> replicarGlobal(
            int idPlantillaGlobal,
            int idCorporativo,
            String nombre,
            Integer idIdioma,
            int idUsuario);

    Map<String, Object> obtenerDiseno(int idPlantilla);

    Map<String, Object> guardarDiseno(
            int idPlantilla,
            Map<String, Object> plantilla,
            int usuario);

    Map<String, Object> guardarDocumento(
            int idPlantilla,
            Map<String, Object> documento,
            int usuario);

    Map<String, Object> guardarPortada(
            int idPlantilla,
            Map<String, Object> portada,
            int usuario);

    Map<String, Object> guardarSeccion(
            int idPlantilla,
            Integer idSeccion,
            Map<String, Object> seccion,
            int usuario);

    Map<String, Object> guardarLienzo(
            int idPlantilla,
            int idSeccion,
            Map<String, Object> lienzo,
            int usuario);

    Map<String, Object> asignables(int idPlantilla, Integer idSeccion);

    Map<String, Object> asignar(
            int idSeccion,
            List<Integer> ids,
            int usuario);

    Map<String, Object> ordenarIndicadores(
            int idSeccion,
            List<Integer> idsSeccionIndicador,
            int usuario);

    Map<String, Object> cambiarEstatusAsignacion(
            int idSeccionIndicador,
            int idEstatus,
            int usuario);
}
