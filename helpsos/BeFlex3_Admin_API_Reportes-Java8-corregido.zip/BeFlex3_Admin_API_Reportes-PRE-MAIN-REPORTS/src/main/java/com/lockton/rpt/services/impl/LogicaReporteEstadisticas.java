package com.lockton.rpt.services.impl;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.lockton.rpt.repositories.ReporteEstadisticasDAO;
import com.lockton.rpt.services.ReporteEstadisticasIndicadoresService;

import org.springframework.stereotype.Service;

@Service
public class LogicaReporteEstadisticas implements ReporteEstadisticasIndicadoresService {

    private final ReporteEstadisticasDAO dao;
    private final GeneroGraficaRenderer generoGraficaRenderer;

    public LogicaReporteEstadisticas(ReporteEstadisticasDAO dao, GeneroGraficaRenderer generoGraficaRenderer) {
        this.dao = dao;
        this.generoGraficaRenderer = generoGraficaRenderer;
    }

    @Override
    public List<Map<String, Object>> listarSecciones() {
        return dao.listarSecciones();
    }

    @Override
    public Map<String, Object> getParametros(int idCorporativo) {
        return dao.getParametros(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s1RazonSocial(int idCorporativo) {
        return dao.s1RazonSocial(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s1Genero(int idCorporativo) {
        return dao.s1Genero(idCorporativo);
    }

    @Override
    public Map<String, Object> s1GeneroGrafica(int idCorporativo) {
        List<Map<String, Object>> rows = dao.s1Genero(idCorporativo);
        int hombres = 0;
        int mujeres = 0;

        for (Map<String, Object> row : rows) {
            String genero = String.valueOf(row.get("Genero"));
            Object totalRaw = row.containsKey("TotalTitulares") ? row.get("TotalTitulares") : row.get("TotalSexo");
            int total = toInt(totalRaw);
            String normalizado = genero == null ? "" : genero.trim().toUpperCase();
            if (normalizado.contains("MASCUL") || normalizado.contains("HOMBRE") || "H".equals(normalizado)) {
                hombres += total;
            } else if (normalizado.contains("FEMEN") || normalizado.contains("MUJER") || "M".equals(normalizado)) {
                mujeres += total;
            }
        }

        int total = hombres + mujeres;
        double pctHombres = total == 0 ? 0.0 : hombres * 100.0 / total;
        double pctMujeres = total == 0 ? 0.0 : mujeres * 100.0 / total;

        try {
            String imageBase64 = generoGraficaRenderer.generarBase64(hombres, mujeres);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("idCorporativo", idCorporativo);
            data.put("hombres", hombres);
            data.put("mujeres", mujeres);
            data.put("total", total);
            data.put("porcentajeHombres", round1(pctHombres));
            data.put("porcentajeMujeres", round1(pctMujeres));
            data.put("mimeType", "image/png");
            data.put("imageBase64", imageBase64);
            data.put("dataUri", "data:image/png;base64," + imageBase64);
            return data;
        } catch (IOException ex) {
            throw new IllegalStateException("No se pudo generar la gráfica de género: " + ex.getMessage(), ex);
        }
    }

    private int toInt(Object value) {
        if (value == null) {
            return 0;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private double round1(double value) {
        return Math.round(value * 10.0) / 10.0;
    }

    @Override
    public List<Map<String, Object>> s1Generacion(int idCorporativo) {
        return dao.s1Generacion(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s1Perfil(int idCorporativo) {
        return dao.s1Perfil(idCorporativo);
    }

    @Override
    public Map<String, Object> s2ParticipacionGeneral(int idCorporativo) {
        return dao.s2ParticipacionGeneral(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s2ParticipacionEmpresa(int idCorporativo) {
        return dao.s2ParticipacionEmpresa(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s2SolicitudesDia(int idCorporativo) {
        return dao.s2SolicitudesDia(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s2ParticipacionPerfil(int idCorporativo) {
        return dao.s2ParticipacionPerfil(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3OpcionalesResumen(int idCorporativo) {
        return dao.s3OpcionalesResumen(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3OpcionalesTabla(int idCorporativo) {
        return dao.s3OpcionalesTabla(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3OpcionalesGeneracion(int idCorporativo) {
        return dao.s3OpcionalesGeneracion(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3ComposicionFamiliar(int idCorporativo) {
        return dao.s3ComposicionFamiliar(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> s3Movilidad(int idCorporativo) {
        return dao.s3Movilidad(idCorporativo);
    }
}
