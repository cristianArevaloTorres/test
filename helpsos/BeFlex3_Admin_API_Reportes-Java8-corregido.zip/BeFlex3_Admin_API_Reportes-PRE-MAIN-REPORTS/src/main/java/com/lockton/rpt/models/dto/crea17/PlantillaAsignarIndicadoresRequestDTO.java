package com.lockton.rpt.models.dto.crea17;
import java.util.List;
public class PlantillaAsignarIndicadoresRequestDTO {
 private List<Integer> idsIndicador; private Integer idUsuario;
 public List<Integer> getIdsIndicador(){return idsIndicador;} public void setIdsIndicador(List<Integer> v){idsIndicador=v;}
 public Integer getIdUsuario(){return idUsuario;} public void setIdUsuario(Integer v){idUsuario=v;}
}
