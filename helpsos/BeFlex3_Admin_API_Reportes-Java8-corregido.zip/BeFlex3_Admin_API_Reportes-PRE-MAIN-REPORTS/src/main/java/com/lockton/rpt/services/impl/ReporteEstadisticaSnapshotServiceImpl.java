package com.lockton.rpt.services.impl;

import com.lockton.rpt.repositories.ReporteEstadisticaSnapshotDAO;
import com.lockton.rpt.services.ReporteEstadisticaSnapshotService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ReporteEstadisticaSnapshotServiceImpl implements ReporteEstadisticaSnapshotService {
    private final ReporteEstadisticaSnapshotDAO dao;
    private final ReporteEstadisticaSnapshotAsyncService asyncService;

    public ReporteEstadisticaSnapshotServiceImpl(
            ReporteEstadisticaSnapshotDAO dao,
            ReporteEstadisticaSnapshotAsyncService asyncService) {
        this.dao = dao;
        this.asyncService = asyncService;
    }

    @Override
    public List<Map<String, Object>> listarHistorial(int idCorporativo) {
        validateCorporativo(idCorporativo);
        return dao.listarHistorial(idCorporativo);
    }

    @Override
    public Map<String, Object> obtenerDetalle(long idEjecucion, int idCorporativo) {
        validateCorporativo(idCorporativo);
        validateEjecucion(idEjecucion);
        Map<String, Object> result = dao.obtenerDetalle(idEjecucion, idCorporativo);
        if (result.get("ejecucion") == null) {
            throw new IllegalArgumentException("La ejecución solicitada no existe.");
        }
        return result;
    }

    @Override
    public Map<String, Object> obtenerProgreso(long idEjecucion, int idCorporativo) {
        validateCorporativo(idCorporativo);
        validateEjecucion(idEjecucion);
        Map<String, Object> result = dao.obtenerProgreso(idEjecucion, idCorporativo);
        if (result.get("ejecucion") == null) {
            throw new IllegalArgumentException("La ejecución solicitada no existe.");
        }
        return result;
    }

    @Override
    public Map<String, Object> obtenerActivo(int idCorporativo) {
        validateCorporativo(idCorporativo);
        return dao.obtenerActivo(idCorporativo);
    }

    @Override
    public Map<String, Object> obtenerDisponibilidad(int idCorporativo, Integer idVigencia) {
        validateCorporativo(idCorporativo);
        if (idVigencia != null && idVigencia.intValue() <= 0) {
            throw new IllegalArgumentException("La vigencia enviada no es válida.");
        }
        return dao.obtenerDisponibilidad(idCorporativo, idVigencia);
    }

    @Override
    public Map<String, Object> asegurarDisponible(int idCorporativo, Integer idVigencia) {
        Map<String, Object> disponibilidad = obtenerDisponibilidad(idCorporativo, idVigencia);
        if (!booleanValue(value(disponibilidad, "Disponible"))) {
            Object rawMessage = value(disponibilidad, "Mensaje");
            String message = rawMessage == null
                    ? "No existe un histórico publicado para el corporativo y la vigencia actuales."
                    : String.valueOf(rawMessage).trim();
            throw new IllegalStateException(message);
        }
        return disponibilidad;
    }

    @Override
    public Map<String, Object> iniciar(int idCorporativo, int idUsuario) {
        validateCorporativo(idCorporativo);
        if (idUsuario <= 0) throw new IllegalArgumentException("El usuario es requerido.");

        Map<String, Object> start = dao.iniciar(idCorporativo, idUsuario);
        Object rawId = start.get("IdEjecucion");
        if (!(rawId instanceof Number)) {
            throw new IllegalStateException("La base de datos no devolvió el identificador de la ejecución.");
        }

        long idEjecucion = ((Number) rawId).longValue();
        asyncService.procesar(idEjecucion);
        return dao.obtenerProgreso(idEjecucion, idCorporativo);
    }

    @Override
    public List<Map<String, Object>> listarVigencias(int idCorporativo) {
        validateCorporativo(idCorporativo);
        return dao.listarVigencias(idCorporativo);
    }

    @Override
    public List<Map<String, Object>> listarEmpresas(int idCorporativo, int idVigencia) {
        validateCorporativo(idCorporativo);
        validateVigencia(idVigencia);
        return dao.listarEmpresas(idCorporativo, idVigencia);
    }

    @Override
    public Map<String, Object> consultarDatos(int idCorporativo, int idVigencia, Integer idEmpresa,
                                              String titular, int pagina, int tamanioPagina) {
        validateCorporativo(idCorporativo);
        validateVigencia(idVigencia);
        if (idEmpresa != null && idEmpresa.intValue() <= 0) idEmpresa = null;
        if (pagina <= 0) pagina = 1;
        if (tamanioPagina != 25 && tamanioPagina != 50 && tamanioPagina != 100 && tamanioPagina != 200) {
            tamanioPagina = 50;
        }
        return dao.consultarDatos(idCorporativo, idVigencia, idEmpresa, titular, pagina, tamanioPagina);
    }

    private Object value(Map<String, Object> row, String key) {
        if (row == null || key == null) return null;
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(key)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private boolean booleanValue(Object raw) {
        if (raw instanceof Boolean) return ((Boolean) raw).booleanValue();
        if (raw instanceof Number) return ((Number) raw).intValue() != 0;
        if (raw == null) return false;
        String value = String.valueOf(raw).trim();
        return "1".equals(value) || "true".equalsIgnoreCase(value) || "si".equalsIgnoreCase(value);
    }

    private void validateCorporativo(int idCorporativo) {
        if (idCorporativo <= 0) throw new IllegalArgumentException("El corporativo es requerido.");
    }

    private void validateVigencia(int idVigencia) {
        if (idVigencia <= 0) throw new IllegalArgumentException("La vigencia es requerida.");
    }

    private void validateEjecucion(long idEjecucion) {
        if (idEjecucion <= 0) throw new IllegalArgumentException("La ejecución es requerida.");
    }
}
