package com.lockton.rpt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lockton.rpt.mappers.CatReportesTipoDatosMapper;
import com.lockton.rpt.models.dto.CatReportesTipoDatosDTO;
import com.lockton.rpt.models.entities.CatReportesTipoDatos;
import com.lockton.rpt.repositories.CatReportesTipoDatosRepository;

@Service
public class CatReportesTipoDatosService {
    @Autowired
    private CatReportesTipoDatosRepository repository;

    public List<CatReportesTipoDatosDTO> getAll() {
        List<CatReportesTipoDatosDTO> dtos = null;
        List<CatReportesTipoDatos> cats = repository.findAll();
        if(!cats.isEmpty())
            dtos = CatReportesTipoDatosMapper.MapperDTO(cats);
        return dtos;
    }

    public CatReportesTipoDatosDTO create(CatReportesTipoDatosDTO catReportesDTO) {
        CatReportesTipoDatos catReportes = CatReportesTipoDatosMapper.MapperEntity(catReportesDTO);
        CatReportesTipoDatos cat = repository.save(catReportes);
        return CatReportesTipoDatosMapper.MapperDTO(cat);
    }

    public boolean delete(CatReportesTipoDatosDTO catReportesDTO) {
        boolean rs = false;
        CatReportesTipoDatos catReportes = CatReportesTipoDatosMapper.MapperEntity(catReportesDTO);
        repository.delete(catReportes);
        rs = true;
        return rs;
    }

    public CatReportesTipoDatosDTO update(CatReportesTipoDatosDTO catReportesDTO) {
        CatReportesTipoDatos catReportes = CatReportesTipoDatosMapper.MapperEntity(catReportesDTO);
        CatReportesTipoDatos cat = repository.save(catReportes);
        return CatReportesTipoDatosMapper.MapperDTO(cat);
    }
}