package com.lockton.rpt.services.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.lockton.rpt.repositories.ConfigIndicadoresDAO;
import com.lockton.rpt.repositories.ConfigIndicadorJsonSupport;

import com.lockton.rpt.util.TextUtil;

import org.springframework.stereotype.Service;

@Service
public class ConfigIndicadoresService {

    private final ConfigIndicadoresDAO dao;
    private final GraficaIndicadorBuilder graficaBuilder;
    private final SnapshotReporteService snapshotService;

    public ConfigIndicadoresService(
            ConfigIndicadoresDAO dao,
            GraficaIndicadorBuilder graficaBuilder,
            SnapshotReporteService snapshotService) {
        this.dao = dao;
        this.graficaBuilder = graficaBuilder;
        this.snapshotService = snapshotService;
    }

    public List<Map<String, Object>> listarSecciones(List<Integer> idCorporativosRol) {
        List<Integer> rol = normalizarCorporativosRol(idCorporativosRol);
        if (rol.isEmpty()) {
            return new ArrayList<>();
        }
        Integer idCorporativoMerge = rol.get(0);
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> seccion : dao.getSecciones(idCorporativoMerge)) {
            int idSeccion = intOrDefault(seccion.get("CESidConfiguracionEstadisticasSeccion"), 0);
            if (idSeccion <= 0) {
                continue;
            }
            if (listarIndicadores(idSeccion, rol).isEmpty()) {
                continue;
            }
            out.add(seccion);
        }
        out.sort(Comparator.comparingInt(s -> intOrDefault(s.get("Orden"), 999)));
        return out;
    }

    public List<Map<String, Object>> listarIndicadores(int idSeccion, List<Integer> idCorporativosRol) {
        List<Integer> rol = normalizarCorporativosRol(idCorporativosRol);
        if (rol.isEmpty()) {
            return new ArrayList<>();
        }
        List<Map<String, Object>> out = new ArrayList<>();
        Integer idCorporativoMerge = rol.get(0);
        for (Map<String, Object> indicador : dao.getIndicadores(idCorporativoMerge, idSeccion)) {
            if (!mostrarEnReporte(indicador)) {
                continue;
            }
            int idIndicador = intOrDefault(indicador.get("CEIidConfiguracionEstadisticasIndicador"), 0);
            if (idIndicador <= 0) {
                continue;
            }
            List<Integer> idsIndicador = dao.getIndicadorIdsCorporativosPlantilla(idIndicador);
            if (!ConfigIndicadorJsonSupport.indicadorAplicaARol(idsIndicador, rol)) {
                continue;
            }
            Map<String, Object> detalle = dao.getIndicadorDetalle(idCorporativoMerge, idIndicador);
            if (!detalle.isEmpty()) {
                indicador.put("Ancho", detalle.get("Ancho"));
                indicador.put("Alto", detalle.get("Alto"));
                indicador.put("MostrarTitulo", detalle.get("MostrarTitulo"));
                indicador.put("MostrarLeyenda", detalle.get("MostrarLeyenda"));
            }
            out.add(indicador);
        }
        out.sort(Comparator.comparingInt(i -> intOrDefault(i.get("Orden"), 999)));
        return out;
    }

    private List<Integer> normalizarCorporativosRol(List<Integer> idCorporativosRol) {
        List<Integer> rol = new ArrayList<>();
        if (idCorporativosRol == null) {
            return rol;
        }
        for (Integer id : idCorporativosRol) {
            if (id != null && id > 0 && !rol.contains(id)) {
                rol.add(id);
            }
        }
        return rol;
    }

    private boolean mostrarEnReporte(Map<String, Object> row) {
        return boolOrDefault(row.get("MostrarEnReporte"), true);
    }

    public Map<String, Object> obtenerIndicador(int idCorporativo, int idIndicador) {
        Map<String, Object> detalle = dao.getIndicadorDetalle(idCorporativo, idIndicador);
        if (detalle.isEmpty()) {
            throw new IllegalArgumentException("Indicador no encontrado o no activo para el corporativo.");
        }
        detalle.put("parametros", dao.getIndicadorParametros(idCorporativo, idIndicador));
        detalle.put("mapeo", dao.getIndicadorMapeo(idCorporativo, idIndicador));
        return detalle;
    }

    public Map<String, Object> preview(Integer idCorporativo, int idIndicador, Map<String, String> parametrosEntrada) {
        if (idCorporativo == null || idCorporativo <= 0) {
            return previewSinCorporativo(idIndicador);
        }
        Map<String, Object> detalle = obtenerIndicador(idCorporativo, idIndicador);
        String proc = String.valueOf(detalle.get("CESPNombreRealStoredProcedure"));
        String tipoClave = IndicadorTipoCatalog.normalize(String.valueOf(detalle.get("TipoIndicadorClave")));

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> paramsMeta = (List<Map<String, Object>>) detalle.get("parametros");
        List<Map<String, Object>> paramsEjecucion = resolverParametros(idCorporativo, paramsMeta, parametrosEntrada);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> mapeo = (List<Map<String, Object>>) detalle.get("mapeo");
        Object configuracionJson = detalle.get("ConfiguracionJson");
        if (!graficaBuilder.tieneMapeoMinimo(tipoClave, mapeo, configuracionJson)) {
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("idIndicador", idIndicador);
            out.put("clave", detalle.get("Clave"));
            out.put("nombre", detalle.get("Nombre"));
            out.put("tipoIndicadorClave", tipoClave);
            out.put("storedProcedure", proc);
            out.put("parametrosEjecutados", paramsEjecucionResumen(paramsEjecucion));
            String mensaje = mensajeMapeoInsuficiente(tipoClave, mapeo, configuracionJson);
            out.put("elemento", construirElementoSinMapeo(tipoClave, mensaje));
            if (graficaBuilder.esGrafica(tipoClave)) {
                out.put("graficaError", mensaje);
            }
            return out;
        }

        Map<String, Object> periodo = snapshotService.resolverPeriodoPreview(idCorporativo, parametrosEntrada);
        if (!Boolean.TRUE.equals(periodo.get("existeSnapshot"))) {
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("idIndicador", idIndicador);
            out.put("clave", detalle.get("Clave"));
            out.put("nombre", detalle.get("Nombre"));
            out.put("tipoIndicadorClave", tipoClave);
            out.put("storedProcedure", proc);
            out.put("parametrosEjecutados", paramsEjecucionResumen(paramsEjecucion));
            String mensaje = "No hay snapshot para corporativo " + idCorporativo
                    + " y vigencia " + periodo.get("idVigencia")
                    + ". Ejecute snapshot en Admin → Configura snapshot.";
            out.put("elemento", construirElementoSinMapeo(tipoClave, mensaje));
            out.put("snapshotRequerido", true);
            return out;
        }

        java.time.LocalDateTime fechaCorte = (java.time.LocalDateTime) periodo.get("fechaCorte");
        int idVigencia = ((Number) periodo.get("idVigencia")).intValue();
        int idSp = intOrDefault(detalle.get("IdStoredProcedure"), 0);
        Map<String, String> filtrosSnapshot = snapshotService.filtrosPermitidosParaSp(idSp, parametrosEntrada);
        List<Map<String, Object>> filas = snapshotService.leerDatosSnapshot(
                proc, idCorporativo, fechaCorte, idVigencia, filtrosSnapshot);
        filas = stripSnapshotMetadata(filas);

        Map<String, Object> elemento = construirElemento(tipoClave, filas, mapeo, configuracionJson);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("idIndicador", idIndicador);
        out.put("clave", detalle.get("Clave"));
        out.put("nombre", detalle.get("Nombre"));
        out.put("tipoIndicadorClave", tipoClave);
        out.put("storedProcedure", proc);
        out.put("parametrosEjecutados", paramsEjecucionResumen(paramsEjecucion));
        Map<String, Object> snapshotPeriodo = new LinkedHashMap<>();
        snapshotPeriodo.put("idVigencia", idVigencia);
        snapshotPeriodo.put("fechaCorte", fechaCorte.toString());
        out.put("snapshotPeriodo", snapshotPeriodo);
        out.put("elemento", elemento);
        if (graficaBuilder.esGrafica(tipoClave)) {
            try {
                Map<String, Object> chartConfig = graficaBuilder.construirChartConfig(detalle, filas, mapeo);
                out.put("chartConfig", chartConfig);
            } catch (Exception ex) {
                out.put("graficaError", ex.getMessage());
            }
        }
        return out;
    }

    private Map<String, Object> previewSinCorporativo(int idIndicador) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("idIndicador", idIndicador);
        out.put("idCorporativo", null);
        out.put("sinCorporativo", true);
        out.put("parametrosEjecutados", new LinkedHashMap<String, Object>());
        out.put("elemento", construirElementoSinMapeo(
                "TABLA",
                "Indique IdCorporativo en los parámetros del reporte para consultar datos del indicador."));
        return out;
    }

    private List<Map<String, Object>> stripSnapshotMetadata(List<Map<String, Object>> filas) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> fila : filas) {
            Map<String, Object> row = new LinkedHashMap<>(fila);
            row.remove("SnapRowId");
            row.remove("IdCorporativo");
            row.remove("IdVigencia");
            row.remove("IdVigenciaAnterior");
            row.remove("FechaCorte");
            row.remove("IndiceResultSet");
            out.add(row);
        }
        return out;
    }

    public List<Map<String, Object>> listarParametrosReporte(int idCorporativo,
            List<Integer> idCorporativosRol) {
        return dao.getParametrosReporte(idCorporativo, indicadoresVisiblesParaReporte(idCorporativosRol));
    }

    public Map<String, Object> guardarParametrosReporte(int idCorporativo,
            Map<String, String> parametros, int idUsuario, String nombreUsuario,
            List<Integer> idCorporativosRol) {
        List<Map<String, Object>> indicadoresVisibles = indicadoresVisiblesParaReporte(idCorporativosRol);
        List<Map<String, Object>> bindings = dao.getParametroBindingsCorporativo(
                idCorporativo, indicadoresVisibles);
        int guardados = 0;
        Map<Integer, Map<String, String>> porIndicador = new LinkedHashMap<>();
        for (Map.Entry<String, String> entry : parametros.entrySet()) {
            String nombre = entry.getKey();
            String valor = entry.getValue();
            for (Map<String, Object> binding : bindings) {
                if (!nombre.equals(String.valueOf(binding.get("CESPPNombreParametro")))) {
                    continue;
                }
                int idIndicador = ((Number) binding.get("IdIndicador")).intValue();
                porIndicador.computeIfAbsent(idIndicador, k -> new LinkedHashMap<>()).put(nombre, valor);
            }
        }
        for (Map.Entry<Integer, Map<String, String>> e : porIndicador.entrySet()) {
            guardados += dao.saveCorporativoParametrosValores(idCorporativo, e.getKey(),
                    e.getValue(), idUsuario, nombreUsuario);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("idCorporativo", idCorporativo);
        out.put("parametrosGuardados", guardados);
        out.put("parametros", dao.getParametrosReporte(idCorporativo, indicadoresVisibles));
        return out;
    }

    private List<Map<String, Object>> indicadoresVisiblesParaReporte(List<Integer> idCorporativosRol) {
        List<Integer> rol = normalizarCorporativosRol(idCorporativosRol);
        if (rol.isEmpty()) {
            return new ArrayList<>();
        }
        Map<Integer, Map<String, Object>> porId = new LinkedHashMap<>();
        for (Map<String, Object> seccion : listarSecciones(rol)) {
            int idSeccion = intOrDefault(seccion.get("CESidConfiguracionEstadisticasSeccion"), 0);
            if (idSeccion <= 0) {
                continue;
            }
            for (Map<String, Object> indicador : listarIndicadores(idSeccion, rol)) {
                int idIndicador = intOrDefault(indicador.get("CEIidConfiguracionEstadisticasIndicador"), 0);
                if (idIndicador <= 0 || porId.containsKey(idIndicador)) {
                    continue;
                }
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("IdIndicador", idIndicador);
                row.put("OrdenIndicador", intOrDefault(indicador.get("Orden"), 999));
                porId.put(idIndicador, row);
            }
        }
        return new ArrayList<>(porId.values());
    }

    public Map<String, Object> guardarParametros(int idCorporativo, int idIndicador,
            List<Map<String, Object>> parametros, int idUsuario, String nombreUsuario) {
        Map<String, String> valores = new LinkedHashMap<>();
        for (Map<String, Object> p : parametros) {
            String valor = p.get("valor") != null ? String.valueOf(p.get("valor")) : null;
            Object spParamId = p.get("idStoredProcedureParametro");
            if (spParamId == null) {
                continue;
            }
            List<Map<String, Object>> meta = dao.getIndicadorParametros(idCorporativo, idIndicador);
            for (Map<String, Object> m : meta) {
                if (String.valueOf(m.get("CEIPIdConfiguracionEstadisticasStoredProcedureParametro"))
                        .equals(String.valueOf(spParamId))) {
                    valores.put(String.valueOf(m.get("CESPPNombreParametro")), valor);
                }
            }
        }
        int guardados = dao.saveCorporativoParametrosValores(idCorporativo, idIndicador,
                valores, idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("idCorporativo", idCorporativo);
        out.put("idIndicador", idIndicador);
        out.put("parametrosGuardados", guardados > 0 ? valores.size() : 0);
        out.put("parametros", dao.getIndicadorParametros(idCorporativo, idIndicador));
        return out;
    }

    private List<Map<String, Object>> resolverParametros(int idCorporativo,
            List<Map<String, Object>> paramsMeta, Map<String, String> entrada) {
        List<Map<String, Object>> ordered = new ArrayList<>();
        for (Map<String, Object> meta : paramsMeta) {
            if (!parametroVinculado(meta)) {
                continue;
            }
            String origen = String.valueOf(meta.getOrDefault("CEIPOrigenValor", ""));
            if (("MANUAL".equalsIgnoreCase(origen) || "SESION".equalsIgnoreCase(origen))
                    && !boolOrDefault(meta.get("Visible"), true)) {
                continue;
            }
            String nombre = String.valueOf(meta.get("CESPPNombreParametro"));
            String valor = null;
            if ("FIJO".equalsIgnoreCase(origen)) {
                if (meta.get("CEIPValorFijo") != null && !TextUtil.isBlank(String.valueOf(meta.get("CEIPValorFijo")))) {
                    valor = String.valueOf(meta.get("CEIPValorFijo"));
                }
            } else if ("MANUAL".equalsIgnoreCase(origen) || "SESION".equalsIgnoreCase(origen)) {
                if (entrada != null && entrada.containsKey(nombre)) {
                    valor = entrada.get(nombre);
                } else if (meta.get("Valor") != null && !TextUtil.isBlank(String.valueOf(meta.get("Valor")))) {
                    valor = String.valueOf(meta.get("Valor"));
                } else if ("SESION".equalsIgnoreCase(origen) && "IdCorporativo".equals(nombre)
                        && idCorporativo > 0) {
                    valor = String.valueOf(idCorporativo);
                }
            }
            Map<String, Object> p = new LinkedHashMap<>(meta);
            p.put("valor", valor);
            ordered.add(p);
        }
        return ordered;
    }

    private boolean parametroVinculado(Map<String, Object> meta) {
        return meta.get("CEIPidConfiguracionEstadisticasIndicadorParametro") != null
                || meta.get("IdConfiguracionEstadisticasIndicadorParametro") != null;
    }

    private Map<String, Object> construirElementoSinMapeo(String tipoClave, String mensaje) {
        Map<String, Object> elemento = new LinkedHashMap<>();
        elemento.put("tipo", tipoClave);
        elemento.put("filas", new ArrayList<>());
        elemento.put("sinMapeo", true);
        elemento.put("mensaje", mensaje);
        return elemento;
    }

    private String mensajeMapeoInsuficiente(String tipoClave, List<Map<String, Object>> mapeo,
            Object configuracionJson) {
        String tipo = IndicadorTipoCatalog.normalize(tipoClave);
        if (!graficaBuilder.tieneColumnasVinculadas(mapeo)) {
            return "No hay columnas de salida vinculadas al indicador.";
        }
        if ("TABLA".equals(tipo)) {
            return "No hay columnas de salida vinculadas al indicador.";
        }
        if ("KPI".equals(tipo)) {
            return "Configure la columna de valores en Configuración de gráfica.";
        }
        if ("PASTEL".equals(tipo)) {
            return "Configure valores y etiquetas (o porcentaje) en Configuración de gráfica.";
        }
        if ("GENERO".equals(tipo)) {
            return "Configure etiquetas (Masculino/Femenino) y valores o porcentajes en Configuración de gráfica.";
        }
        if ("DISTRIBUCION_DONA".equals(tipo)) {
            return "Configure etiquetas, totales y opcionalmente porcentaje, hombres y mujeres por fila.";
        }
        return "Configure etiquetas y valores en Configuración de gráfica.";
    }

    private Map<String, Object> paramsEjecucionResumen(List<Map<String, Object>> params) {
        Map<String, Object> resumen = new LinkedHashMap<>();
        for (Map<String, Object> p : params) {
            resumen.put(String.valueOf(p.get("CESPPNombreParametro")), p.get("valor"));
        }
        return resumen;
    }

    private Map<String, Object> construirElemento(String tipoClave, List<Map<String, Object>> filas,
            List<Map<String, Object>> mapeo, Object configuracionJson) {
        Map<String, Object> elemento = new LinkedHashMap<>();
        elemento.put("tipo", tipoClave);
        List<Map<String, Object>> filasMapeadas = filtrarFilasPorMapeo(filas, mapeo);
        elemento.put("filas", filasMapeadas);
        elemento.put("mapeo", mapeo);

        if ("TABLA".equalsIgnoreCase(tipoClave)) {
            return elemento;
        }

        Map<String, String> attrs = graficaBuilder.resolverAtributosColumna(configuracionJson, mapeo);

        List<Map<String, Object>> series = new ArrayList<>();
        for (Map<String, Object> fila : filas) {
            Map<String, Object> punto = new LinkedHashMap<>();
            putSerieValor(punto, "label", fila, attrs.get("labels"));
            putSerieValor(punto, "value", fila, attrs.get("values"));
            putSerieValor(punto, "percentage", fila, attrs.get("percentage"));
            putSerieValor(punto, "hombres", fila, attrs.get("hombres"));
            putSerieValor(punto, "mujeres", fila, attrs.get("mujeres"));
            series.add(punto);
        }
        elemento.put("series", series);

        if ("KPI".equalsIgnoreCase(tipoClave) && !filas.isEmpty()) {
            Map<String, Object> kpi = new LinkedHashMap<>();
            putSerieValor(kpi, "value", filas.get(0), attrs.get("values"));
            putSerieValor(kpi, "label", filas.get(0), attrs.get("labels"));
            elemento.put("kpi", kpi);
        }
        return elemento;
    }

    private void putSerieValor(Map<String, Object> target, String key, Map<String, Object> fila,
            String columna) {
        if (columna != null && !TextUtil.isBlank(columna)) {
            target.put(key, fila.get(columna));
        }
    }

    private List<Map<String, Object>> filtrarFilasPorMapeo(List<Map<String, Object>> filas,
            List<Map<String, Object>> mapeo) {
        if (mapeo == null || mapeo.isEmpty()) {
            return new ArrayList<>();
        }
        if (filas == null || filas.isEmpty()) {
            return new ArrayList<>();
        }
        List<Map<String, Object>> orderedMapeo = new ArrayList<>(mapeo);
        orderedMapeo.sort(Comparator.comparingInt(m -> intOrDefault(m.get("CEIMOrden"), 999)));
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> fila : filas) {
            Map<String, Object> row = new LinkedHashMap<>();
            for (Map<String, Object> m : orderedMapeo) {
                String col = String.valueOf(m.getOrDefault("CESPSNombreColumna", ""));
                if (TextUtil.isBlank(col)) {
                    continue;
                }
                Object etiquetaObj = m.get("CEIMEtiqueta");
                String header = etiquetaObj != null && !TextUtil.isBlank(String.valueOf(etiquetaObj))
                        ? String.valueOf(etiquetaObj)
                        : String.valueOf(m.getOrDefault("CESPSNombreVisual", col));
                row.put(header, fila.get(col));
            }
            out.add(row);
        }
        return out;
    }

    private int intOrDefault(Object value, int defaultValue) {
        if (value == null || TextUtil.isBlank(String.valueOf(value))) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException ex) {
            return defaultValue;
        }
    }

    private boolean boolOrDefault(Object value, boolean defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() != 0;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }

    /**
     * Obtiene IdCorporativo únicamente desde los parámetros del reporte (sin default de sesión).
     */
    public Integer resolverIdCorporativoDesdeParametros(Map<String, String> parametrosEntrada) {
        if (parametrosEntrada == null || parametrosEntrada.isEmpty()) {
            return null;
        }
        for (Map.Entry<String, String> entry : parametrosEntrada.entrySet()) {
            String key = entry.getKey() != null ? entry.getKey().replace("@", "") : "";
            if (!"IdCorporativo".equalsIgnoreCase(key)) {
                continue;
            }
            String val = entry.getValue();
            if (val == null || TextUtil.isBlank(val)) {
                return null;
            }
            try {
                int parsed = Integer.parseInt(val.trim());
                return parsed > 0 ? parsed : null;
            } catch (NumberFormatException ignored) {
                return null;
            }
        }
        return null;
    }
}
