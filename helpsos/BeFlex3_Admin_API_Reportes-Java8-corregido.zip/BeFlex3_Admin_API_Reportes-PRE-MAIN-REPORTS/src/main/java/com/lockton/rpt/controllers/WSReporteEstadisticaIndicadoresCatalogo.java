package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.crea17.ApiResponseDTO;
import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorDisponibilidadRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorPasoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.IndicadorReplicarRequestDTO;
import com.lockton.rpt.services.ReporteEstadisticaIndicadorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/beflex/reporte-estadisticas/crea17/indicadores")
public class WSReporteEstadisticaIndicadoresCatalogo {
    private final ReporteEstadisticaIndicadorService service;

    public WSReporteEstadisticaIndicadoresCatalogo(
            ReporteEstadisticaIndicadorService service) {
        this.service = service;
    }

    @GetMapping("/catalogos")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> catalogos() {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-CAT",
                    "Catálogos de indicadores consultados correctamente.",
                    service.obtenerCatalogos()));
        } catch (Exception ex) {
            return error("RPE-IND-CAT-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> listar(
            @RequestParam String tipo,
            @RequestParam(required = false) Integer idCorporativo,
            @RequestParam(defaultValue = "false") boolean incluirBajas) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-LIST",
                    "Indicadores consultados correctamente.",
                    service.listar(tipo, idCorporativo, incluirBajas)));
        } catch (Exception ex) {
            return error("RPE-IND-LIST-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{idIndicador}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtener(
            @PathVariable int idIndicador) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-DETAIL",
                    "Indicador consultado correctamente.",
                    service.obtener(idIndicador)));
        } catch (Exception ex) {
            return error("RPE-IND-DETAIL-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/paso")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardarPaso(
            @RequestBody IndicadorPasoGuardarRequestDTO request) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-STEP",
                    "Paso del indicador guardado correctamente.",
                    service.guardarPaso(request)));
        } catch (Exception ex) {
            return error("RPE-IND-STEP-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    /*
     * PUT es la ruta principal porque algunos proxies/WAF heredados bloquean
     * PATCH antes de que la solicitud llegue a Spring. Se conserva PATCH como
     * alias para no romper clientes existentes de CREA 17.
     */
    @PutMapping("/{idIndicador}/estatus")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatusPut(
            @PathVariable int idIndicador,
            @RequestBody CambioEstatusRequestDTO request) {
        return cambiarEstatusInterno(idIndicador, request);
    }

    @PatchMapping("/{idIndicador}/estatus")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatusPatch(
            @PathVariable int idIndicador,
            @RequestBody CambioEstatusRequestDTO request) {
        return cambiarEstatusInterno(idIndicador, request);
    }

    private ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatusInterno(
            int idIndicador,
            CambioEstatusRequestDTO request) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-STATUS",
                    "Estatus del indicador actualizado correctamente.",
                    service.cambiarEstatus(idIndicador, request)));
        } catch (Exception ex) {
            return error("RPE-IND-STATUS-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/{idIndicador}/disponibilidad")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> disponibilidad(
            @PathVariable int idIndicador,
            @RequestBody IndicadorDisponibilidadRequestDTO request) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-AVAILABILITY",
                    "Disponibilidad corporativa actualizada correctamente.",
                    service.guardarDisponibilidad(idIndicador, request)));
        } catch (Exception ex) {
            return error(
                    "RPE-IND-AVAILABILITY-ERR",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/globales-disponibles")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>>
            globalesDisponibles(@RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-GLOBAL-AVAILABLE",
                    "Indicadores globales disponibles consultados correctamente.",
                    service.listarGlobalesDisponibles(idCorporativo)));
        } catch (Exception ex) {
            return error(
                    "RPE-IND-GLOBAL-AVAILABLE-ERR",
                    ex,
                    HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/corporativo/{idCorporativo}/replicar")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> replicar(
            @PathVariable int idCorporativo,
            @RequestBody IndicadorReplicarRequestDTO request) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-REPLICATE",
                    "Indicadores replicados correctamente.",
                    service.replicar(idCorporativo, request)));
        } catch (Exception ex) {
            return error("RPE-IND-REPLICATE-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/claves/disponibilidad")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> validarClave(
            @RequestParam String tipo,
            @RequestParam String clave,
            @RequestParam(required = false) Integer idRegistro,
            @RequestParam(required = false) Integer idIndicador) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-KEY",
                    "Disponibilidad de la clave consultada correctamente.",
                    service.validarClave(tipo, clave, idRegistro, idIndicador)));
        } catch (Exception ex) {
            return error("RPE-IND-KEY-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/fuentes/{idStoredProcedure}/muestra")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> muestraFuente(
            @PathVariable int idStoredProcedure,
            @RequestParam int idCorporativo,
            @RequestParam(defaultValue = "100") int maxFilas) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-SAMPLE",
                    "Muestra de la consulta consultada correctamente.",
                    service.obtenerMuestraFuente(
                            idCorporativo,
                            idStoredProcedure,
                            maxFilas)));
        } catch (Exception ex) {
            return error("RPE-IND-SAMPLE-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/fuentes/{idStoredProcedure}/valores-distintos")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>>
            valoresDistintos(
                    @PathVariable int idStoredProcedure,
                    @RequestParam int idCorporativo,
                    @RequestParam String columna,
                    @RequestParam(defaultValue = "200") int maxValores) {
        try {
            return ResponseEntity.ok(ApiResponseDTO.ok(
                    "RPE-IND-DISTINCT",
                    "Valores distintos consultados correctamente.",
                    service.obtenerValoresDistintos(
                            idCorporativo,
                            idStoredProcedure,
                            columna,
                            maxValores)));
        } catch (Exception ex) {
            return error("RPE-IND-DISTINCT-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    private <T> ResponseEntity<ApiResponseDTO<T>> error(
            String code,
            Exception ex,
            HttpStatus status) {
        String message = ex.getMessage() == null
                ? "No fue posible completar la operación."
                : ex.getMessage();
        return ResponseEntity.status(status).body(
                ApiResponseDTO.<T>fail(
                        code,
                        message,
                        message,
                        ex.getClass().getSimpleName()));
    }
}
