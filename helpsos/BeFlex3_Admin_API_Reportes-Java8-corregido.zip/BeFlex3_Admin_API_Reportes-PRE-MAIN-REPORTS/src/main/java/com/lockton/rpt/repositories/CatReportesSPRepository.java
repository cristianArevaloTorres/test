package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.lockton.rpt.models.entities.CatReportesSP;
import java.util.List;

@Repository
public interface CatReportesSPRepository  extends JpaRepository<CatReportesSP, Integer> {
    List<CatReportesSP> findByCatReportesId(Integer catReportesId);
}
