package com.lockton.rpt.services.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lockton.rpt.mappers.CatReportesMapper;
import com.lockton.rpt.mappers.CatReportesParamsMapper;
import com.lockton.rpt.mappers.CatReportesSPMapper;
import com.lockton.rpt.mappers.ReportesEdicionMapper;
import com.lockton.rpt.models.dto.CatReportesParamsRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesParamsResp_DTO;
import com.lockton.rpt.models.dto.CatReportesRConfig_DTO;
import com.lockton.rpt.models.dto.CatReportesRSPS_DTO;
import com.lockton.rpt.models.dto.CatReportesRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesSPCreateRequest_DTO;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.models.entities.CatReportes;
import com.lockton.rpt.models.entities.CatReportesParams;
import com.lockton.rpt.models.entities.CatReportesSP;
import com.lockton.rpt.models.entities.CatReportesTipoArchivo;
import com.lockton.rpt.models.entities.CatReportesTipoDatos;
import com.lockton.rpt.models.request.RequestCatReportesParamDTO;
import com.lockton.rpt.models.request.RequestCatReportesSPDTO;
import com.lockton.rpt.repositories.CatReportesParamsRepository;
import com.lockton.rpt.repositories.CatReportesRepository;
import com.lockton.rpt.repositories.CatReportesSPRepository;
import com.lockton.rpt.repositories.CatReportesTipoDatosRepository;
import com.lockton.rpt.models.dto.CatReportesSPRequest_DTO;
import com.lockton.rpt.models.dto.CatReportesTipoDatosResp_DTO;
import com.lockton.rpt.services.ReportesEdicionService;

@Service
public class ReportesEdicionImpl implements ReportesEdicionService {

    @Autowired
    private CatReportesRepository repository;
    
    @Autowired
    private CatReportesSPRepository spRepository;

    @Autowired
    private CatReportesParamsRepository paramsRepository;

    @Autowired
    private CatReportesTipoDatosRepository tipoDatoRepository;

    @Autowired
    private CatReportesRepository catReportesRepository;

    @Override
    public List<CatReportesRConfig_DTO> getCatReports() {
        List<CatReportesRConfig_DTO> response = null;
        List<CatReportes> reports = repository.findAll()
            .stream()
            .collect(Collectors.toList());
        if(!reports.isEmpty())
            response = CatReportesMapper.mapToCatReportConf(reports);
        return response;
    }

    @Override
    public List<CatReportesRConfig_DTO> setReportingEnabled(int catReportesNum) {
        List<CatReportesRConfig_DTO> response = null;
        try{
            CatReportes report = repository.findAll()
                .stream()
                .filter(x -> x.getCatReportesNum() == catReportesNum)
                .findFirst()
                .orElse(null);
            if(report != null){
                report.setEsid(report.getEsid() == 1 ? 0 : 1);
                repository.save(report);
            }
            response = this.getCatReports();
        }catch(Exception ex){
            throw new UnsupportedOperationException(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseGralDTO updateCatReport(CatReportesRequest_DTO catReportesRequestDTO) {
        ResponseGralDTO response = new ResponseGralDTO();
        try{
            CatReportes _reporte = ReportesEdicionMapper.mapCatReportReqToCatReport(catReportesRequestDTO);
            repository.save(_reporte);
            response.messages = "Actualización Exitosa";
            response.status = true;
        }catch(Exception ex){
            response.messages = "updateCatReport:: " + ex.getMessage();
            response.status = false;
        }
        return response;
    }

    @Override
    public List<CatReportesRSPS_DTO> getCatalogoSPsByIdReport(int catReportesId) {
        List<CatReportesRSPS_DTO> response = null;
        try{
            List<CatReportesSP> sps = spRepository.findAll()
                .stream()
                .filter(x -> x.getCatReportesId() == catReportesId)
                .collect(Collectors.toList());
            if(sps != null){
                response = ReportesEdicionMapper.mapCatReportesSPToCatReportesRSPS_DTO(sps);
            }
        }catch(Exception ex){
            throw new RuntimeException("Error obteniendo SPs del reporte: " + ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ResponseGralDTO turnOffCatReportSP(int catReportesSPId, int catReportesSPUsuarioDel, LocalDateTime catReportesSPFechaDel) {
        ResponseGralDTO response = new ResponseGralDTO();
        try{
            CatReportesSP sp = spRepository.findAll()
                .stream()
                .filter(x -> x.getCatReportesSPId() == catReportesSPId)
                .findFirst()
                .orElse(null);
            if(sp != null){
                sp.setEsid(sp.getEsid() == 1 ? 0 : 1);
                sp.setCatReportesSPUsuarioDel(catReportesSPUsuarioDel);
                sp.setCatReportesSPFechaDel(catReportesSPFechaDel);
                spRepository.save(sp);
                response.messages = "Actualización Exitosa";
                response.status = true;
            }
            else{
                response.messages = "Datos no Encontrados";
                response.status = false;
            }
        }catch(Exception ex){
            response.messages = "turnOffCatReportSPById:: " + ex.getMessage();
            response.status = false;           
        }
        return response;
    }

    @Override
    public ResponseGralDTO updateReportSP(CatReportesSPRequest_DTO request) {
        ResponseGralDTO response = new ResponseGralDTO();
        try{
            CatReportesSP spUpd = spRepository.findAll()
                .stream()
                .filter(x -> x.getCatReportesSPId() == request.catReportesSPId)
                .findFirst()
                .orElse(null);
            //CatReportesSP spUpd = ReportesEdicionMapper.MapperCatRepSPToCatRepSPReqDTO(request);
            spUpd.setCatReportesSPNombre(request.catReportesSPNombre);
            spUpd.setCatReportesSPDesc(request.catReportesSPDesc);
            spUpd.setCatReportesSPOrden(request.catReportesSPOrden);
            spUpd.setCatReportesSPUsuarioMod(request.catReportesSPUsuarioMod);
            spUpd.setCatReportesSPFechaMod(request.catReportesSPFechaMod);
            spRepository.save(spUpd);
            
            response.messages = "Actualización Exitosa";
            response.status = true;        
        }catch(Exception ex){
            response.messages = "updateReportSP:: " + ex.getMessage();
            response.status = false;
        }
        return response;
    }

    @Override
    public List<CatReportesParamsResp_DTO> getParamsById(int catReportesSPId) {
        List<CatReportesParamsResp_DTO> response = null;
        try{
            List<CatReportesParams> paramLts = this.paramsRepository.findAll()
                .stream()
                .filter(x -> x.getCatReportesSPId() == catReportesSPId)
                .collect(Collectors.toList());
            if(paramLts != null){
                response = ReportesEdicionMapper.MapperCatRepParamToParamDTO(paramLts);
            }
        }catch(Exception ex){
            throw new RuntimeException("Error obteniendo getParamsById: " + ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public List<CatReportesTipoDatosResp_DTO> getCatReportsTypeData() {
        List<CatReportesTipoDatosResp_DTO> response = null;
        try{
            List<CatReportesTipoDatos> data = this.tipoDatoRepository.findAll();
            if(data != null){
                response = ReportesEdicionMapper.MapperCatRepTipoDatoToTipoDatoDTO(data);
            }
        }catch(Exception ex){
            throw new RuntimeException("Error obteniendo getCatReportsTypeData: " + ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ResponseGralDTO turnOffCatReportParam(int catReportesParamsId,
        int catReportesParamsUsuarioDel, LocalDateTime catReportesParamsFechaDel) {
        ResponseGralDTO response = new ResponseGralDTO();
        try{
            CatReportesParams param = this.paramsRepository.findAll()
                .stream()
                .filter(x -> x.getCatReportesParamsId() == catReportesParamsId)
                .findFirst()
                .orElse(null);
            if(param != null){
                param.setEsid(param.getEsid() == 1 ? 0 : 1);
                param.setCatReportesParamsUsuarioDel(catReportesParamsUsuarioDel);
                param.setCatReportesParamsFechaDel(catReportesParamsFechaDel);
                this.paramsRepository.save(param);
                response.messages = "Actualización Exitosa";
                response.status = true;
            }
            else{
                response.messages = "Datos no Encontrados";
                response.status = false;
            }
        }catch(Exception ex){
            response.messages = "turnOffCatReportParam:: " + ex.getMessage();
            response.status = false;           
        }
        return response;
    }

    @Override
    public ResponseGralDTO updateParameter(CatReportesParamsResp_DTO parameter) {
        ResponseGralDTO response = new ResponseGralDTO();
        try{
            CatReportesParams param = this.paramsRepository.findAll()
                .stream()
                .filter(x -> x.getCatReportesParamsId() == parameter.getCatReportesParamsId())
                .findFirst()
                .orElse(null);
            if(param != null){
                param.setCatReportesTipoDatoId(parameter.getCatReportesTipoDatoId());
                param.setCatReportesParamsLongitud(parameter.getCatReportesParamsLongitud());
                param.setCatReportesParamsUsuarioMod(param.getCatReportesParamsUsuarioMod());
                param.setCatReportesParamsFechaMod(LocalDateTime.now());
                this.paramsRepository.save(param);
                response.messages = "Actualización Exitosa";
                response.status = true;
            }
            else{
                response.messages = "Datos no Encontrados";
                response.status = false;
            }
        }catch(Exception ex){
            response.messages = "updateParameter:: " + ex.getMessage();
            response.status = false;
        }
        return response;
    }

    @Override
    public ResponseGralDTO createNewConfiguration(List<CatReportesSPCreateRequest_DTO> request) {
        ResponseGralDTO response = new ResponseGralDTO();
        try{
           CatReportes reports = this.catReportesRepository.findAll()
            .stream()
            .filter(x -> x.getCatReportesId() == request.get(0).getCatReportesId())
            .findFirst()
            .orElse(null);
            if(reports != null){                
                for (CatReportesSPCreateRequest_DTO spDTO : request){
                    spDTO.setCatReportesSPFechaAdd(LocalDateTime.now());
                    CatReportesSP sp = CatReportesSPMapper.mapRequestDTOToCatSP(spDTO, reports.getCatReportesNum());
                    CatReportesSP spAdd = spRepository.save(sp);
                    Integer catReportesSPId = spAdd.getCatReportesSPId();

                    if (spDTO.getParameters() != null){
                        for (CatReportesParamsRequest_DTO pDTO : spDTO.getParameters()){
                            pDTO.setCatReportesParamsFechaAdd(LocalDateTime.now());
                            CatReportesParams param = CatReportesParamsMapper.mapToParametroDTOToEntity(pDTO, catReportesSPId);
                            paramsRepository.save(param);
                        }
                    }
                }
                response.messages = "Proceso Exitoso";
                response.status = true;
            }else{
                response.messages = "Datos no Encontrados";
                response.status = false;
            }
        }catch(Exception ex){
            response.messages = "createNewConfiguration:: " + ex.getMessage();
            response.status = false;
        }
        return response;
    }

    
}
