package com.lockton.rpt.services.impl;

import com.lockton.rpt.repositories.ReporteEstadisticaBeflexPlantillaDAO;
import com.lockton.rpt.services.ReporteEstadisticaBeflexPlantillaService;
import com.lockton.rpt.services.ReporteEstadisticaSnapshotService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ReporteEstadisticaBeflexPlantillaServiceImpl
        implements ReporteEstadisticaBeflexPlantillaService {

    private static final int DEFAULT_MAX_ROWS = 25000;
    private static final int MAX_ROWS = 25000;
    private static final Pattern FILTER_KEY = Pattern.compile("^[A-Z0-9_]+$");
    private static final Pattern TOKEN_PATTERN = Pattern.compile("\\{\\{\\s*([^{}]+?)\\s*\\}\\}");
    private static final DateTimeFormatter DATE_ES = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final ReporteEstadisticaBeflexPlantillaDAO dao;
    private final ReporteEstadisticaSnapshotService snapshotService;

    public ReporteEstadisticaBeflexPlantillaServiceImpl(
            ReporteEstadisticaBeflexPlantillaDAO dao,
            ReporteEstadisticaSnapshotService snapshotService) {
        this.dao = dao;
        this.snapshotService = snapshotService;
    }

    @Override
    public List<Map<String, Object>> listarPlantillas(
            int idCorporativo,
            Integer idIdioma,
            boolean soloPdf) {
        validateCorporativo(idCorporativo);
        snapshotService.asegurarDisponible(idCorporativo, null);
        if (idIdioma != null && idIdioma.intValue() <= 0) {
            throw new IllegalArgumentException("El idioma enviado no es válido.");
        }
        return soloPlantillasCorporativas(
                dao.listarPlantillas(idCorporativo, idIdioma, soloPdf),
                idCorporativo);
    }

    @Override
    public Map<String, Object> obtenerBootstrap(
            int idCorporativo,
            Integer idIdioma,
            boolean soloPdf) {
        validateCorporativo(idCorporativo);
        snapshotService.asegurarDisponible(idCorporativo, null);

        if (idIdioma != null && idIdioma.intValue() <= 0) {
            throw new IllegalArgumentException("El idioma enviado no es válido.");
        }

        Map<String, Object> contexto = dao.obtenerContexto(idCorporativo);
        List<Map<String, Object>> plantillas = soloPlantillasCorporativas(
                dao.listarPlantillas(idCorporativo, idIdioma, soloPdf),
                idCorporativo);
        List<Map<String, Object>> filtros = normalizarFiltros(dao.listarFiltros(idCorporativo));

        Map<String, Object> seleccionada =
                plantillas.isEmpty() ? null : plantillas.get(0);
        Map<String, Object> configuracion = null;

        if (seleccionada != null) {
            int idPlantilla = positiveInt(
                    value(seleccionada, "IdPlantilla"),
                    "La plantilla seleccionada no es válida.");
            configuracion = resolverConfiguracion(
                    dao.obtenerConfiguracion(idCorporativo, idPlantilla),
                    contexto,
                    null);
        }

        Map<String, Object> result = new LinkedHashMap<String, Object>();
        result.put("contexto", contexto);
        result.put("plantillas", plantillas);
        result.put("plantillaSeleccionada", seleccionada);
        result.put("configuracion", configuracion);
        result.put("filtros", filtros);
        return result;
    }

    @Override
    public Map<String, Object> obtenerConfiguracion(
            int idCorporativo,
            int idPlantilla) {
        validateCorporativo(idCorporativo);
        validatePlantilla(idPlantilla);
        snapshotService.asegurarDisponible(idCorporativo, null);
        Map<String, Object> contexto = dao.obtenerContexto(idCorporativo);
        return resolverConfiguracion(
                dao.obtenerConfiguracion(idCorporativo, idPlantilla),
                contexto,
                null);
    }

    @Override
    public List<Map<String, Object>> obtenerOpcionesFiltro(
            int idCorporativo,
            int idVigencia,
            String clave,
            Map<String, Object> filtros) {
        validateCorporativo(idCorporativo);
        validateVigencia(idVigencia);
        snapshotService.asegurarDisponible(idCorporativo, Integer.valueOf(idVigencia));
        String normalizedKey = clave == null ? "" : clave.trim().toUpperCase(Locale.ROOT);
        if (normalizedKey.isEmpty() || !FILTER_KEY.matcher(normalizedKey).matches()) {
            throw new IllegalArgumentException("El filtro solicitado no es válido.");
        }
        validateDateRanges(filtros);
        return dao.obtenerOpcionesFiltro(
                idCorporativo,
                idVigencia,
                normalizedKey,
                filtros);
    }

    @Override
    public Map<String, Object> consultarPlantilla(
            String uidSolicitud,
            int idCorporativo,
            int idVigencia,
            int idPlantilla,
            int idUsuario,
            Map<String, Object> filtros) {
        validateCorporativo(idCorporativo);
        validateVigencia(idVigencia);
        validatePlantilla(idPlantilla);
        snapshotService.asegurarDisponible(idCorporativo, Integer.valueOf(idVigencia));
        if (idUsuario <= 0) {
            throw new IllegalArgumentException("El usuario es requerido.");
        }
        validateUid(uidSolicitud);
        validateDateRanges(filtros);

        Map<String, Object> result = dao.consultarPlantilla(
                uidSolicitud.trim(),
                idCorporativo,
                idVigencia,
                idPlantilla,
                idUsuario,
                filtros);

        /* Una solicitud reutilizada en proceso todavía no trae datasets. */
        String estado = stringValue(value(result, "estadoSolicitud")).toUpperCase(Locale.ROOT);
        if ("EN_PROCESO".equals(estado)) {
            return result;
        }

        Map<String, Object> contexto = new LinkedHashMap<String, Object>();
        contexto.putAll(dao.obtenerContexto(idCorporativo));
        contexto.put("IdPlantilla", Integer.valueOf(idPlantilla));
        Map<String, Object> contextoOriginal = mapValue(result.get("contexto"));
        Object snapshot = value(contextoOriginal, "idEjecucionSnapshot");
        if (snapshot == null) {
            snapshot = value(contextoOriginal, "IdEjecucionSnapshot");
        }
        if (snapshot != null) {
            contexto.put("IdEjecucionSnapshot", snapshot);
        }

        Map<String, Object> configuracion = resolverConfiguracion(
                dao.obtenerConfiguracion(idCorporativo, idPlantilla),
                contexto,
                result);

        result.put("contexto", contexto);
        result.put("configuracion", configuracion);
        return result;
    }

    @Override
    public Map<String, Object> obtenerEjecucion(String uidSolicitud) {
        validateUid(uidSolicitud);
        return dao.obtenerEjecucion(uidSolicitud.trim());
    }

    @Override
    public Map<String, Object> obtenerDatosFuente(
            int idCorporativo,
            int idPlantilla,
            int idStoredProcedure,
            int maxFilas) {
        validateCorporativo(idCorporativo);
        validatePlantilla(idPlantilla);
        snapshotService.asegurarDisponible(idCorporativo, null);
        if (idStoredProcedure <= 0) {
            throw new IllegalArgumentException("La consulta es requerida.");
        }
        int normalizedMax = maxFilas <= 0
                ? DEFAULT_MAX_ROWS
                : Math.min(maxFilas, MAX_ROWS);
        return dao.obtenerDatosFuente(
                idCorporativo,
                idPlantilla,
                idStoredProcedure,
                normalizedMax);
    }

    private List<Map<String, Object>> soloPlantillasCorporativas(
            List<Map<String, Object>> rows,
            int idCorporativo) {
        List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
        if (rows == null) {
            return result;
        }
        for (Map<String, Object> row : rows) {
            String tipo = stringValue(value(row, "Tipo"));
            Integer corporativo = integerValue(value(row, "IdCorporativoPlantilla"));
            if (corporativo == null) {
                corporativo = integerValue(value(row, "IdCorporativo"));
            }
            if ("CORPORATIVO".equalsIgnoreCase(tipo)
                    && corporativo != null
                    && corporativo.intValue() == idCorporativo) {
                result.add(row);
            }
        }
        return result;
    }

    private List<Map<String, Object>> normalizarFiltros(
            List<Map<String, Object>> rows) {
        List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
        if (rows == null) {
            return result;
        }
        for (Map<String, Object> row : rows) {
            String clave = stringValue(value(row, "REFClave")).toUpperCase(Locale.ROOT);
            if (clave.isEmpty() || !FILTER_KEY.matcher(clave).matches()) {
                continue;
            }
            Map<String, Object> normalized = new LinkedHashMap<String, Object>();
            normalized.put("IdFiltro", value(row, "REFIdFiltro"));
            normalized.put("Clave", clave);
            normalized.put("Nombre", value(row, "REFNombre"));
            normalized.put("Descripcion", value(row, "REFDescripcion"));
            normalized.put("Orden", value(row, "REFOrden"));
            normalized.put("EsFiltroBase", value(row, "REFEsFiltroBase"));
            normalized.put("TipoControl", value(row, "REFTipoControl"));
            result.add(normalized);
        }
        return result;
    }

    private Map<String, Object> resolverConfiguracion(
            Map<String, Object> configuracion,
            Map<String, Object> contexto,
            Map<String, Object> consulta) {
        if (configuracion == null) {
            return null;
        }

        Map<String, String> tokens = new LinkedHashMap<String, String>();
        addContextTokens(tokens, contexto, configuracion);
        if (consulta != null) {
            addIndicatorVariableTokens(tokens, configuracion, consulta, contexto);
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> resolved = (Map<String, Object>) resolveObject(configuracion, tokens);
        resolved.put("TokensResueltos", new LinkedHashMap<String, String>(tokens));
        agregarContratoDocumento(resolved);
        return resolved;
    }

    /**
     * Contrato aditivo para consumidores CREA17. Conserva Plantilla intacta y
     * expone en un bloque estable los datos que determinan el layout del PDF.
     * Las dimensiones provienen del catálogo SQL, no de constantes JavaScript.
     */
    private void agregarContratoDocumento(Map<String, Object> configuracion) {
        Map<String, Object> plantilla = mapValue(configuracion.get("Plantilla"));
        if (plantilla.isEmpty()) {
            return;
        }

        Map<String, Object> documento = new LinkedHashMap<String, Object>();
        copiar(documento, plantilla, "IdTamanoDocumento");
        copiar(documento, plantilla, "TamanoDocumento");
        copiar(documento, plantilla, "TamanoPagina");
        copiar(documento, plantilla, "AnchoMm");
        copiar(documento, plantilla, "AltoMm");
        copiar(documento, plantilla, "Orientacion");
        copiar(documento, plantilla, "MargenSuperior");
        copiar(documento, plantilla, "MargenDerecho");
        copiar(documento, plantilla, "MargenInferior");
        copiar(documento, plantilla, "MargenIzquierdo");
        copiar(documento, plantilla, "IdTipoArchivo");
        copiar(documento, plantilla, "TipoArchivo");
        configuracion.put("Documento", documento);

        Map<String, Object> portada = new LinkedHashMap<String, Object>();
        copiar(portada, plantilla, "TituloPortada");
        copiar(portada, plantilla, "SubtituloPortada");
        copiar(portada, plantilla, "TextoCorporativo");
        copiar(portada, plantilla, "TextoPeriodo");
        copiar(portada, plantilla, "TextoAdicionalPortada");
        copiar(portada, plantilla, "TextoPeriodoPrefijo");
        copiar(portada, plantilla, "TextoPeriodoConector");
        copiar(portada, plantilla, "TextoPeriodoSufijo");
        copiar(portada, plantilla, "LogoRuta");
        copiar(portada, plantilla, "LogoArchivoNombre");
        copiar(portada, plantilla, "ColorBandaPrimaria");
        copiar(portada, plantilla, "ColorBandaSecundaria");
        copiar(portada, plantilla, "EstilosPortadaJson");
        configuracion.put("Portada", portada);

        Map<String, Object> contraportada = new LinkedHashMap<String, Object>();
        copiar(contraportada, plantilla, "MostrarContraportada");
        copiar(contraportada, plantilla, "EstilosContraportadaJson");
        copiar(contraportada, plantilla, "ColorBandaPrimaria");
        copiar(contraportada, plantilla, "ColorBandaSecundaria");
        configuracion.put("Contraportada", contraportada);
    }

    private void copiar(
            Map<String, Object> destino,
            Map<String, Object> origen,
            String clave) {
        Object valor = value(origen, clave);
        if (valor != null) {
            destino.put(clave, valor);
        }
    }

    private void addContextTokens(
            Map<String, String> tokens,
            Map<String, Object> contexto,
            Map<String, Object> configuracion) {
        String corporativo = textValue(firstValue(
                contexto, "Corporativo", "NombreCorporativo", "Empresa"));
        String vigencia = textValue(firstValue(
                contexto, "Vigencia", "NombreVigencia"));
        String vigenciaInicio = formatDate(firstValue(
                contexto, "FechaInicioVigencia", "VigenciaInicio", "VIVigenciaIni"));
        String vigenciaFin = formatDate(firstValue(
                contexto, "FechaFinVigencia", "VigenciaFin", "VIVigenciaFin"));
        String enrollmentInicio = formatDate(firstValue(
                contexto, "FechaInicioEnrollment", "EnrollmentInicio", "VIEnrollmentIni"));
        String enrollmentFin = formatDate(firstValue(
                contexto, "FechaFinEnrollment", "EnrollmentFin", "VIEnrollmentFin"));
        String fechaActual = formatDate(firstValue(
                contexto, "FechaActual", "FechaGeneracion"));

        putToken(tokens, "Corporativo", corporativo);
        putToken(tokens, "Vigencia", vigencia);
        putToken(tokens, "FechaInicioVigencia", vigenciaInicio);
        putToken(tokens, "FechaFinVigencia", vigenciaFin);
        putToken(tokens, "FechaInicioEnrollment", enrollmentInicio);
        putToken(tokens, "FechaFinEnrollment", enrollmentFin);
        putToken(tokens, "FechaActual", fechaActual);
        putToken(tokens, "FechaGeneracion", fechaActual);

        /* Alias canónicos usados por RPLConfiguracionJson del Wizard. */
        putToken(tokens, "VIGENCIA_INICIO", vigenciaInicio);
        putToken(tokens, "VIGENCIA_FIN", vigenciaFin);
        putToken(tokens, "ENROLLMENT_INICIO", enrollmentInicio);
        putToken(tokens, "ENROLLMENT_FIN", enrollmentFin);
        putToken(tokens, "FECHA_ACTUAL", fechaActual);
        putToken(tokens, "FECHA_GENERACION", fechaActual);
        putToken(tokens, "PERIODO", periodo(vigenciaInicio, vigenciaFin));

        Map<String, Object> plantilla = mapValue(configuracion.get("Plantilla"));
        String extension = stringValue(value(plantilla, "TipoArchivo"));
        if (extension.isEmpty()) {
            extension = "PDF";
        }
        putToken(tokens, "Extension", extension.toLowerCase(Locale.ROOT));
    }

    private void addIndicatorVariableTokens(
            Map<String, String> tokens,
            Map<String, Object> configuracion,
            Map<String, Object> consulta,
            Map<String, Object> contexto) {
        List<Map<String, Object>> variables = listValue(configuracion.get("VariablesIndicador"));
        if (variables.isEmpty()) {
            return;
        }
        List<Map<String, Object>> mappings = listValue(configuracion.get("MapeosVistaIndicador"));
        List<Map<String, Object>> variableTokens = listValue(configuracion.get("VariableTokens"));
        Map<String, Object> porIndicador = mapValue(consulta.get("porIndicador"));

        Map<Integer, String> outputColumns = new LinkedHashMap<Integer, String>();
        for (Map<String, Object> mapping : mappings) {
            Integer idSalida = integerValue(value(mapping, "IdSalida"));
            String column = stringValue(value(mapping, "NombreColumna"));
            if (idSalida != null && !column.isEmpty() && !outputColumns.containsKey(idSalida)) {
                outputColumns.put(idSalida, column);
            }
        }

        Map<Integer, Map<String, Object>> byId = new LinkedHashMap<Integer, Map<String, Object>>();
        for (Map<String, Object> variable : variables) {
            Integer id = integerValue(value(variable, "IdVariable"));
            if (id != null) {
                byId.put(id, variable);
            }
        }

        Collections.sort(variables, new Comparator<Map<String, Object>>() {
            @Override
            public int compare(Map<String, Object> left, Map<String, Object> right) {
                return intOrZero(value(left, "Orden")) - intOrZero(value(right, "Orden"));
            }
        });

        /* Primera pasada: SALIDA y METADATA. */
        for (Map<String, Object> variable : variables) {
            String tipo = stringValue(value(variable, "Tipo")).toUpperCase(Locale.ROOT);
            if ("FORMULA".equals(tipo)) {
                continue;
            }
            Object raw = resolveVariableValue(variable, outputColumns, porIndicador, contexto);
            putToken(tokens,
                    stringValue(value(variable, "Clave")),
                    formatVariable(raw, variable));
        }

        /* Segunda pasada: fórmulas. Se permiten referencias entre variables. */
        for (int pass = 0; pass < 8; pass++) {
            boolean changed = false;
            for (Map<String, Object> variable : variables) {
                String tipo = stringValue(value(variable, "Tipo")).toUpperCase(Locale.ROOT);
                if (!"FORMULA".equals(tipo)) {
                    continue;
                }
                String clave = stringValue(value(variable, "Clave"));
                String calculated = resolveFormulaVariable(variable, variableTokens, byId, tokens);
                if (calculated == null || calculated.isEmpty()) {
                    calculated = stringValue(value(variable, "ValorAlternativo"));
                }
                if (!calculated.isEmpty()) {
                    String before = tokenValue(tokens, clave);
                    putToken(tokens, clave, calculated);
                    if (!calculated.equals(before)) {
                        changed = true;
                    }
                }
            }
            if (!changed) {
                break;
            }
        }
    }

    private Object resolveVariableValue(
            Map<String, Object> variable,
            Map<Integer, String> outputColumns,
            Map<String, Object> porIndicador,
            Map<String, Object> contexto) {
        String tipo = stringValue(value(variable, "Tipo")).toUpperCase(Locale.ROOT);
        if ("METADATA".equals(tipo)) {
            String expression = stringValue(value(variable, "Expresion"));
            String key = expression.replace("{{", "").replace("}}", "").trim();
            Object metadata = value(contexto, key);
            if (metadata == null) {
                metadata = value(contexto, stringValue(value(variable, "Clave")));
            }
            return metadata != null ? metadata : value(variable, "ValorAlternativo");
        }

        Integer indicatorId = integerValue(value(variable, "IdIndicador"));
        Integer outputId = integerValue(value(variable, "IdSalida"));
        if (indicatorId == null || outputId == null) {
            return value(variable, "ValorAlternativo");
        }
        String column = stringValue(value(variable, "NombreColumna"));
        if (column.isEmpty()) {
            column = outputColumns.get(outputId);
        }
        if (column == null || column.isEmpty()) {
            return value(variable, "ValorAlternativo");
        }
        List<Map<String, Object>> rows = rowsValue(value(porIndicador, String.valueOf(indicatorId)));
        List<Object> values = new ArrayList<Object>();
        for (Map<String, Object> row : rows) {
            values.add(value(row, column));
        }
        Object aggregated = aggregate(values, stringValue(value(variable, "Operacion")));
        return aggregated != null ? aggregated : value(variable, "ValorAlternativo");
    }

    private String resolveFormulaVariable(
            Map<String, Object> variable,
            List<Map<String, Object>> allTokens,
            Map<Integer, Map<String, Object>> variablesById,
            Map<String, String> resolvedTokens) {
        Integer idVariable = integerValue(value(variable, "IdVariable"));
        List<Map<String, Object>> tokens = new ArrayList<Map<String, Object>>();
        for (Map<String, Object> token : allTokens) {
            Integer owner = integerValue(value(token, "IdVariable"));
            if (idVariable != null && idVariable.equals(owner)) {
                tokens.add(token);
            }
        }
        Collections.sort(tokens, new Comparator<Map<String, Object>>() {
            @Override
            public int compare(Map<String, Object> left, Map<String, Object> right) {
                return intOrZero(value(left, "Orden")) - intOrZero(value(right, "Orden"));
            }
        });

        StringBuilder expression = new StringBuilder();
        if (!tokens.isEmpty()) {
            for (Map<String, Object> token : tokens) {
                String type = stringValue(value(token, "TipoToken")).toUpperCase(Locale.ROOT);
                if ("VARIABLE".equals(type)) {
                    Integer ref = integerValue(value(token, "IdVariableReferencia"));
                    Map<String, Object> refVar = ref == null ? null : variablesById.get(ref);
                    String refKey = refVar == null
                            ? stringValue(value(token, "VariableClaveReferencia"))
                            : stringValue(value(refVar, "Clave"));
                    String refValue = tokenValue(resolvedTokens, refKey);
                    if (refValue.isEmpty()) {
                        return null;
                    }
                    expression.append(normalizeNumericText(refValue));
                } else {
                    expression.append(stringValue(value(token, "Valor")));
                }
            }
        } else {
            String raw = stringValue(value(variable, "Expresion"));
            if (raw.isEmpty()) {
                return null;
            }
            Matcher matcher = TOKEN_PATTERN.matcher(raw);
            StringBuffer buffer = new StringBuffer();
            while (matcher.find()) {
                String replacement = tokenValue(resolvedTokens, matcher.group(1));
                if (replacement.isEmpty()) {
                    return null;
                }
                matcher.appendReplacement(buffer, Matcher.quoteReplacement(normalizeNumericText(replacement)));
            }
            matcher.appendTail(buffer);
            expression.append(buffer.toString());
        }

        try {
            BigDecimal value = new ArithmeticParser(expression.toString()).parse();
            return formatVariable(value, variable);
        } catch (RuntimeException ex) {
            return null;
        }
    }

    private Object aggregate(List<Object> values, String operation) {
        String op = operation == null ? "FIRST" : operation.trim().toUpperCase(Locale.ROOT);
        List<Object> nonNull = new ArrayList<Object>();
        for (Object item : values) {
            if (item != null && !String.valueOf(item).trim().isEmpty()) {
                nonNull.add(item);
            }
        }
        if ("COUNT".equals(op)) {
            return Integer.valueOf(nonNull.size());
        }
        if ("COUNT_DISTINCT".equals(op)) {
            Map<String, Boolean> distinct = new LinkedHashMap<String, Boolean>();
            for (Object item : nonNull) {
                distinct.put(String.valueOf(item), Boolean.TRUE);
            }
            return Integer.valueOf(distinct.size());
        }
        if ("FIRST".equals(op) || nonNull.isEmpty()) {
            return nonNull.isEmpty() ? null : nonNull.get(0);
        }

        List<BigDecimal> numbers = new ArrayList<BigDecimal>();
        for (Object item : nonNull) {
            try {
                numbers.add(new BigDecimal(String.valueOf(item).replace(",", "").trim()));
            } catch (NumberFormatException ignored) {
                // Una variable numérica ignora valores no numéricos.
            }
        }
        if (numbers.isEmpty()) {
            return nonNull.get(0);
        }
        BigDecimal result = numbers.get(0);
        if ("SUM".equals(op) || "AVG".equals(op)) {
            result = BigDecimal.ZERO;
            for (BigDecimal number : numbers) {
                result = result.add(number);
            }
            if ("AVG".equals(op)) {
                result = result.divide(BigDecimal.valueOf(numbers.size()), 8, RoundingMode.HALF_UP);
            }
        } else if ("MIN".equals(op)) {
            for (BigDecimal number : numbers) if (number.compareTo(result) < 0) result = number;
        } else if ("MAX".equals(op)) {
            for (BigDecimal number : numbers) if (number.compareTo(result) > 0) result = number;
        }
        return result;
    }

    private String formatVariable(Object raw, Map<String, Object> variable) {
        if (raw == null || String.valueOf(raw).trim().isEmpty()) {
            return stringValue(value(variable, "ValorAlternativo"));
        }
        String format = stringValue(value(variable, "Formato")).toUpperCase(Locale.ROOT);
        if ("FECHA".equals(format) || "FECHA_HORA".equals(format)) {
            String formatted = formatDate(raw);
            return formatted.isEmpty() ? String.valueOf(raw) : formatted;
        }
        if ("TEXTO".equals(format)) {
            return String.valueOf(raw);
        }
        try {
            BigDecimal number = raw instanceof BigDecimal
                    ? (BigDecimal) raw
                    : new BigDecimal(String.valueOf(raw).replace(",", "").replace("%", "").trim());
            if ("ENTERO".equals(format)) {
                return number.setScale(0, RoundingMode.HALF_UP).toPlainString();
            }
            if ("PORCENTAJE".equals(format)) {
                return number.setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString() + "%";
            }
            if ("MONEDA".equals(format)) {
                NumberFormat currency = NumberFormat.getCurrencyInstance(new Locale("es", "MX"));
                return currency.format(number);
            }
            return number.setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
        } catch (NumberFormatException ignored) {
            return String.valueOf(raw);
        }
    }

    private Object resolveObject(Object source, Map<String, String> tokens) {
        if (source instanceof Map) {
            Map<?, ?> map = (Map<?, ?>) source;
            Map<String, Object> result = new LinkedHashMap<String, Object>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                result.put(String.valueOf(entry.getKey()), resolveObject(entry.getValue(), tokens));
            }
            return result;
        }
        if (source instanceof List) {
            List<?> list = (List<?>) source;
            List<Object> result = new ArrayList<Object>();
            for (Object item : list) {
                result.add(resolveObject(item, tokens));
            }
            return result;
        }
        if (!(source instanceof String)) {
            return source;
        }
        String text = (String) source;
        Matcher matcher = TOKEN_PATTERN.matcher(text);
        StringBuffer buffer = new StringBuffer();
        while (matcher.find()) {
            String replacement = tokenValue(tokens, matcher.group(1));
            /* No exponemos tokens técnicos sin resolver a beFlex. */
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(buffer);
        return buffer.toString();
    }

    private void putToken(Map<String, String> tokens, String key, String value) {
        if (key == null || key.trim().isEmpty()) {
            return;
        }
        tokens.put(key.trim().toUpperCase(Locale.ROOT), value == null ? "" : value);
    }

    private String tokenValue(Map<String, String> tokens, String key) {
        if (key == null) {
            return "";
        }
        String value = tokens.get(key.trim().toUpperCase(Locale.ROOT));
        return value == null ? "" : value;
    }

    private String normalizeNumericText(String value) {
        return value == null ? "" : value.replace("$", "").replace(",", "").replace("%", "").trim();
    }

    private String periodo(String inicio, String fin) {
        String desde = inicio == null ? "" : inicio.trim();
        String hasta = fin == null ? "" : fin.trim();
        if (!desde.isEmpty() && !hasta.isEmpty()) {
            return desde + " - " + hasta;
        }
        return !desde.isEmpty() ? desde : hasta;
    }

    private String formatDate(Object raw) {
        if (raw == null) {
            return "";
        }
        if (raw instanceof java.sql.Date) {
            return ((java.sql.Date) raw).toLocalDate().format(DATE_ES);
        }
        if (raw instanceof java.sql.Timestamp) {
            return ((java.sql.Timestamp) raw).toLocalDateTime().toLocalDate().format(DATE_ES);
        }
        if (raw instanceof LocalDate) {
            return ((LocalDate) raw).format(DATE_ES);
        }
        if (raw instanceof LocalDateTime) {
            return ((LocalDateTime) raw).toLocalDate().format(DATE_ES);
        }
        String value = String.valueOf(raw).trim();
        if (value.isEmpty()) {
            return "";
        }
        try {
            return LocalDate.parse(value.substring(0, Math.min(10, value.length()))).format(DATE_ES);
        } catch (Exception ignored) {
            try {
                return OffsetDateTime.parse(value).toLocalDate().format(DATE_ES);
            } catch (Exception ignoredAgain) {
                return value;
            }
        }
    }

    private String textValue(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private List<Map<String, Object>> listValue(Object raw) {
        List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
        if (!(raw instanceof List)) {
            return result;
        }
        for (Object item : (List<?>) raw) {
            if (item instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> map = (Map<String, Object>) item;
                result.add(map);
            }
        }
        return result;
    }

    private List<Map<String, Object>> rowsValue(Object raw) {
        return listValue(raw);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> mapValue(Object raw) {
        if (raw instanceof Map) {
            return (Map<String, Object>) raw;
        }
        return new LinkedHashMap<String, Object>();
    }

    private Integer integerValue(Object raw) {
        if (raw == null || String.valueOf(raw).trim().isEmpty()) {
            return null;
        }
        if (raw instanceof Number) {
            return Integer.valueOf(((Number) raw).intValue());
        }
        try {
            return Integer.valueOf(String.valueOf(raw).trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private int intOrZero(Object raw) {
        Integer value = integerValue(raw);
        return value == null ? 0 : value.intValue();
    }

    private String stringValue(Object raw) {
        return raw == null ? "" : String.valueOf(raw).trim();
    }

    private void validateUid(String uidSolicitud) {
        if (uidSolicitud == null || uidSolicitud.trim().isEmpty()) {
            throw new IllegalArgumentException("El identificador de la solicitud es requerido.");
        }
        try {
            UUID.fromString(uidSolicitud.trim());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("El identificador de la solicitud no es válido.");
        }
    }

    /**
     * Valida únicamente la forma común de los filtros RANGO_FECHA. No modifica
     * el mapa recibido y no interfiere con filtros de lista u otros contratos.
     * Desde y Hasta son opcionales de manera independiente.
     */
    private void validateDateRanges(Map<String, Object> filtros) {
        if (filtros == null || filtros.isEmpty()) {
            return;
        }
        for (Map.Entry<String, Object> entry : filtros.entrySet()) {
            if (!(entry.getValue() instanceof Map)) {
                continue;
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> range = (Map<String, Object>) entry.getValue();
            Object desdeRaw = value(range, "Desde");
            Object hastaRaw = value(range, "Hasta");
            if (desdeRaw == null && hastaRaw == null) {
                continue;
            }

            LocalDate desde = parseOptionalDate(desdeRaw, entry.getKey(), "Desde");
            LocalDate hasta = parseOptionalDate(hastaRaw, entry.getKey(), "Hasta");
            if (desde != null && hasta != null && desde.isAfter(hasta)) {
                throw new IllegalArgumentException(
                        "El rango de fecha del filtro " + entry.getKey()
                                + " no es válido: Desde no puede ser posterior a Hasta.");
            }
        }
    }

    private LocalDate parseOptionalDate(Object raw, String clave, String lado) {
        if (raw == null) {
            return null;
        }
        String value = String.valueOf(raw).trim();
        if (value.isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(value);
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException(
                    "La fecha " + lado + " del filtro " + clave
                            + " debe tener formato yyyy-MM-dd.");
        }
    }

    private void validateCorporativo(int idCorporativo) {
        if (idCorporativo <= 0) {
            throw new IllegalArgumentException("El corporativo es requerido.");
        }
    }

    private void validateVigencia(int idVigencia) {
        if (idVigencia <= 0) {
            throw new IllegalArgumentException("La vigencia es requerida.");
        }
    }

    private void validatePlantilla(int idPlantilla) {
        if (idPlantilla <= 0) {
            throw new IllegalArgumentException("La plantilla es requerida.");
        }
    }

    private Object value(Map<String, Object> row, String key) {
        if (row == null || key == null) {
            return null;
        }
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (entry.getKey() != null
                    && entry.getKey().equalsIgnoreCase(key)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private Object firstValue(Map<String, Object> row, String... keys) {
        if (keys == null) {
            return null;
        }
        for (String key : keys) {
            Object candidate = value(row, key);
            if (candidate != null) {
                return candidate;
            }
        }
        return null;
    }

    private int positiveInt(Object value, String message) {
        try {
            int parsed = Integer.parseInt(String.valueOf(value));
            if (parsed > 0) {
                return parsed;
            }
        } catch (Exception ignored) {
            // Se lanza el mensaje funcional de abajo.
        }
        throw new IllegalStateException(message);
    }

    /** Parser aritmético mínimo para fórmulas configuradas ( + - * / y paréntesis ). */
    private static final class ArithmeticParser {
        private final String source;
        private int position;

        private ArithmeticParser(String source) {
            this.source = source == null ? "" : source;
        }

        private BigDecimal parse() {
            position = 0;
            BigDecimal value = expression();
            spaces();
            if (position != source.length()) {
                throw new IllegalArgumentException("Expresión inválida.");
            }
            return value;
        }

        private BigDecimal expression() {
            BigDecimal value = term();
            while (true) {
                spaces();
                if (take('+')) value = value.add(term());
                else if (take('-')) value = value.subtract(term());
                else return value;
            }
        }

        private BigDecimal term() {
            BigDecimal value = factor();
            while (true) {
                spaces();
                if (take('*')) value = value.multiply(factor());
                else if (take('/')) value = value.divide(factor(), 8, RoundingMode.HALF_UP);
                else return value;
            }
        }

        private BigDecimal factor() {
            spaces();
            if (take('+')) return factor();
            if (take('-')) return factor().negate();
            if (take('(')) {
                BigDecimal value = expression();
                spaces();
                if (!take(')')) throw new IllegalArgumentException("Paréntesis incompleto.");
                return value;
            }
            int start = position;
            while (position < source.length()) {
                char c = source.charAt(position);
                if ((c >= '0' && c <= '9') || c == '.') position++;
                else break;
            }
            if (start == position) throw new IllegalArgumentException("Número esperado.");
            return new BigDecimal(source.substring(start, position));
        }

        private boolean take(char expected) {
            spaces();
            if (position < source.length() && source.charAt(position) == expected) {
                position++;
                return true;
            }
            return false;
        }

        private void spaces() {
            while (position < source.length() && Character.isWhitespace(source.charAt(position))) position++;
        }
    }
}
