package com.lockton.rpt.repositories;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedCaseInsensitiveMap;

@Repository
public class CorreosRepository {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<String> GetCorreosAdmin(int idEmpresa) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(
                "ff_getCorreosAdminPorEmpresa");
                
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("idEmpresa", idEmpresa);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        List<String> correos = new ArrayList<>();
        try {
            ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            for (LinkedCaseInsensitiveMap correo: listLinks) {
                String value = (String) correo.values().toArray()[0];
                if (!value.trim().isEmpty()) {
                    correos.add(value.trim());
                }
            }
            
            return correos;
        } catch (Exception e) {
            
            return correos;
        }
    }    
}
