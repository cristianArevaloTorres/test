package com.lockton.rpt.services;

import java.util.List;

import com.lockton.rpt.models.dto.RepConfTablaHojaRquestDTO;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.models.dto.ResponseHojaColumnaDTO;
import com.lockton.rpt.models.request.RequestHojaColumnaDTO;

public interface RepConfTablaService {
    List<ResponseHojaColumnaDTO> getSheetsByReportId(int catReportesId);
    ResponseGralDTO turnOffOnSheet(RepConfTablaHojaRquestDTO request);
    ResponseGralDTO saveAll(List<RequestHojaColumnaDTO> request);
}
