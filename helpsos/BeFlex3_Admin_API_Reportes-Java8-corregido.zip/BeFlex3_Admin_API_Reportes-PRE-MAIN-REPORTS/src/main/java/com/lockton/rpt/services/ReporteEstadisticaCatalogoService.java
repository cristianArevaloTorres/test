package com.lockton.rpt.services;

import java.util.List;
import java.util.Map;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpFiltroRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpSalidaRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpValidacionRequestDTO;
import com.lockton.rpt.models.dto.crea17.ReporteEstadisticaSpValidacionLoteRequestDTO;

public interface ReporteEstadisticaCatalogoService {
    Map<String, Object> obtenerContextoValidacion(int idCorporativo);
    List<Map<String, Object>> listarFiltros();
    List<Map<String, Object>> listarStoredProcedures(boolean incluirBajas);
    Map<String, Object> obtenerStoredProcedure(int idStoredProcedure);
    Map<String, Object> validarStoredProcedure(ReporteEstadisticaSpValidacionRequestDTO request);
    List<Map<String, Object>> validarStoredProceduresLote(ReporteEstadisticaSpValidacionLoteRequestDTO request);
    Map<String, Object> obtenerUltimoSnapshot(int idCorporativo, int idStoredProcedure, int pagina, int tamanoPagina);
    Map<String, Object> crearStoredProcedure(ReporteEstadisticaSpRequestDTO request);
    Map<String, Object> actualizarStoredProcedure(int idStoredProcedure, ReporteEstadisticaSpRequestDTO request);
    Map<String, Object> cambiarEstatusStoredProcedure(int idStoredProcedure, CambioEstatusRequestDTO request);
    Map<String, Object> revalidarStoredProcedure(int idStoredProcedure, int idUsuario, int idCorporativo, int idVigencia);
    Map<String, Object> crearSalida(int idStoredProcedure, ReporteEstadisticaSpSalidaRequestDTO request);
    Map<String, Object> actualizarSalida(int idSalida, ReporteEstadisticaSpSalidaRequestDTO request);
    Map<String, Object> cambiarEstatusSalida(int idSalida, CambioEstatusRequestDTO request);
    Map<String, Object> crearFiltro(int idStoredProcedure, ReporteEstadisticaSpFiltroRequestDTO request);
    Map<String, Object> actualizarFiltro(int idRelacion, ReporteEstadisticaSpFiltroRequestDTO request);
    Map<String, Object> cambiarEstatusFiltro(int idRelacion, CambioEstatusRequestDTO request);
}
