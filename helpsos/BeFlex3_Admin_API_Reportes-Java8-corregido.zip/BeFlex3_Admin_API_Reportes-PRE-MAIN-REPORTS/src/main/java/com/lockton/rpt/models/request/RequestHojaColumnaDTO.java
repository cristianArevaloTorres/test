package com.lockton.rpt.models.request;

import java.util.List;

import com.lockton.rpt.models.dto.RepConfColumnaDTO;
import com.lockton.rpt.models.dto.RepConfTablaHojaResponseDTO;

public class RequestHojaColumnaDTO {
    public RepConfTablaHojaResponseDTO hoja;    
    public List<RepConfColumnaDTO> columnas;
    
    public RepConfTablaHojaResponseDTO getHoja() {
        return hoja;
    }
    public void setHoja(RepConfTablaHojaResponseDTO hoja) {
        this.hoja = hoja;
    }
    public List<RepConfColumnaDTO> getColumnas() {
        return columnas;
    }
    public void setColumnas(List<RepConfColumnaDTO> columnas) {
        this.columnas = columnas;
    }
}
