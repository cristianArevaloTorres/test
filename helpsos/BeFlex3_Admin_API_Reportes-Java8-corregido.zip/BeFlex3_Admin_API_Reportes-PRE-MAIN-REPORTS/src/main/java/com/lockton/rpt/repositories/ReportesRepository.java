package com.lockton.rpt.repositories;

import com.lockton.rpt.models.entities.EntidadGenerica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportesRepository extends JpaRepository<EntidadGenerica, Long> {

    @Procedure(procedureName = "dbo.ff_AddBitacora")
    void crearBitacora(
        @Param("IdPagina") int idPagina, @Param("IdEmpleado") int idEmpleado,
        @Param("IpUser") String ipUser, @Param("UrlUser") String urlUser, 
        @Param("Admin") int admin, @Param("IdEmpresa") int idEmpresa,
        @Param("NombrePagina") String nombrePagina);
}
