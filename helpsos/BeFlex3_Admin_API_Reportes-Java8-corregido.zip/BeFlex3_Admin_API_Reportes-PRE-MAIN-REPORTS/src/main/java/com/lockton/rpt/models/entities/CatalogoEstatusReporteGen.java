package com.lockton.rpt.models.entities;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "bf_CatalogoEstatusReporteGen")
public class CatalogoEstatusReporteGen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "CatERptId")
    private Long CatERptId;
    @Basic(optional = false)
    @Column(name = "CatERptNombre")
    private String CatERptNombre;
    @Basic(optional = false)
    @Column(name = "CatERptUsuarioAdd")
    private Integer CatERptUsuarioAdd;
    @Basic(optional = false)
    @Column(name = "CatERptFechaAdd")
    private Date CatERptFechaAdd;
    @Basic(optional = false)
    @Column(name = "CatERptUsuarioMod")
    private Integer CatERptUsuarioMod;
    @Basic(optional = false)
    @Column(name = "CatERptFechaMod")
    private Date CatERptFechaMod;
    @Basic(optional = false)
    @Column(name = "CatERptUsuarioDel")
    private Integer CatERptUsuarioDel;
    @Basic(optional = false)
    @Column(name = "CatERptFechaDel")
    private Date CatERptFechaDel;
}
