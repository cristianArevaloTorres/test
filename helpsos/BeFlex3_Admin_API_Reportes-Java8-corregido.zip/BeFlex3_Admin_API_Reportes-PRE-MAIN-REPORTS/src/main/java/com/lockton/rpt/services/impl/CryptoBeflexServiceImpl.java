package com.lockton.rpt.services.impl;

import com.lockton.rpt.services.CryptoBeflexService;
import com.lockton.rpt.util.PasswordDeriveBytes;
import io.jsonwebtoken.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Date;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.stereotype.Service;

@Service
public class CryptoBeflexServiceImpl implements CryptoBeflexService {

    private static final String passPhrase = "FLEXIFORBES";
    private static final String saltValue = "FLEXIFORBES";
    private static final String initVector = "@1B2c3D4e5F6g7H8";
    private static final int passwordIterations = 2;
    private static final int keySize = 32;

    private static final long EXPIRATION_TIME = 1000 * 60; // 60 segundos
    private static final SignatureAlgorithm ALGORITHM = SignatureAlgorithm.HS256;

    private static final String SECRET_KEY_STRING = "FLEXIFORBES-1B2c3D4e5F6g7H8-2025";
    private static final byte[] SECRET_KEY_BYTES = SECRET_KEY_STRING.getBytes(StandardCharsets.UTF_8);

    @Override
    public String desencriptar(String cipherText) {
        try {
            // Limpiar la cadena por si contiene espacios o caracteres inválidos
            String cleanCipherText = cipherText.replace(" ", "+").replaceAll("\\s", "");
            byte[] encrypted = Base64.getDecoder().decode(cleanCipherText);
    
            byte[] iv = initVector.getBytes(StandardCharsets.US_ASCII);
            byte[] salt = saltValue.getBytes(StandardCharsets.US_ASCII);
    
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(passPhrase, salt, "MD5", passwordIterations);
            byte[] key = pdb.GetBytes(keySize);
    
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivSpec);
    
            byte[] decrypted = cipher.doFinal(encrypted);
            return new String(decrypted, StandardCharsets.UTF_8);
        } catch (Exception e) {
            System.out.println("Fallo el metodo de desencriptar, motivo: " + e.getMessage());
        }
        return null;
    }
    
    @Override
    public String encriptar(String plainText) {
        try {
            byte[] iv = initVector.getBytes(StandardCharsets.US_ASCII);
            byte[] salt = saltValue.getBytes(StandardCharsets.US_ASCII);
            byte[] data = plainText.getBytes(StandardCharsets.UTF_8);

            PasswordDeriveBytes pdb = new PasswordDeriveBytes(passPhrase, salt, "MD5", passwordIterations);
            byte[] key = pdb.GetBytes(keySize);

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivSpec);

            byte[] encrypted = cipher.doFinal(data);
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception e) {
            System.out.println("Fallo el metodo de encriptar, motivo: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String generateToken(String subject) {
        return Jwts.builder()
                .setSubject(subject)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(ALGORITHM, SECRET_KEY_BYTES)
                .compact();
    }

    @Override
    public boolean validateToken(String token) {
        try {
            Jwts.parser()
                    .setSigningKey(SECRET_KEY_BYTES)
                    .parseClaimsJws(token);
            return true;
        } catch (JwtException e) {
            return false;
        }
    }
}
