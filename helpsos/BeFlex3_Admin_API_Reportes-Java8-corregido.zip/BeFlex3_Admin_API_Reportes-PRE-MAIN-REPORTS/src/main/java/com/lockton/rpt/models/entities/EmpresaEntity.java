package com.lockton.rpt.models.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ff_Empresa")
public class EmpresaEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "EMidEmpresa")
	private Integer idEmpresaPK;
	
	@Column(name = "EMClaveAcceso")
	private String claveAcceso;
	
	@Column(name = "EMPrefijo")
	private String prefijo;
	
	@Column(name = "EMNombre")
	private String nombreEmpresa;
	
	@Column(name = "EMRazonSocial")
	private String razonSocial;
	
	@Column(name = "EMidEstatus")
	private Integer idEstatusEmpresa;
	
	@Column(name = "EMidConfiguracion")
	private Integer idConfigEmpresa;
	
	@Column(name = "EMidCorporativo")
	private Integer idCorporativo;
	
	@Column(name = "EMidPadre")
	private Integer idPadre;
		
		
	public Integer getIdEmpresaPK() {
		return idEmpresaPK;
	}
	public void setIdEmpresaPK(Integer idEmpresaPK) {
		this.idEmpresaPK = idEmpresaPK;
	}
	public String getClaveAcceso() {
		return claveAcceso;
	}
	public void setClaveAcceso(String claveAcceso) {
		this.claveAcceso = claveAcceso;
	}
	public String getPrefijo() {
		return prefijo;
	}
	public void setPrefijo(String prefijo) {
		this.prefijo = prefijo;
	}
	public String getNombreEmpresa() {
		return nombreEmpresa;
	}
	public void setNombreEmpresa(String nombreEmpresa) {
		this.nombreEmpresa = nombreEmpresa;
	}	
	public Integer getIdEstatusEmpresa() {
		return idEstatusEmpresa;
	}
	public void setIdEstatusEmpresa(Integer idEstatusEmpresa) {
		this.idEstatusEmpresa = idEstatusEmpresa;
	}
	public Integer getIdConfigEmpresa() {
		return idConfigEmpresa;
	}
	public void setIdConfigEmpresa(Integer idConfigEmpresa) {
		this.idConfigEmpresa = idConfigEmpresa;
	}
	public Integer getIdCorporativo() {
		return idCorporativo;
	}
	public void setIdCorporativo(Integer idCorporativo) {
		this.idCorporativo = idCorporativo;
	}
	public String getRazonSocial() {
		return razonSocial;
	}
	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	public Integer getIdPadre() {
		return idPadre;
	}
	public void setIdPadre(Integer idPadre) {
		this.idPadre = idPadre;
	}
}