package com.lockton.rpt.models.dto.crea17;

import java.util.LinkedHashMap;
import java.util.Map;

public class IndicadorPasoGuardarRequestDTO {
    private Integer idIndicador;
    private String tipo;
    private Integer idCorporativo;
    private Integer paso;
    private Integer idUsuario;
    private Map<String, Object> configuracion = new LinkedHashMap<String, Object>();

    public Integer getIdIndicador() { return idIndicador; }
    public void setIdIndicador(Integer idIndicador) { this.idIndicador = idIndicador; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public Integer getIdCorporativo() { return idCorporativo; }
    public void setIdCorporativo(Integer idCorporativo) { this.idCorporativo = idCorporativo; }
    public Integer getPaso() { return paso; }
    public void setPaso(Integer paso) { this.paso = paso; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
    public Map<String, Object> getConfiguracion() { return configuracion; }
    public void setConfiguracion(Map<String, Object> configuracion) {
        this.configuracion = configuracion == null
                ? new LinkedHashMap<String, Object>()
                : configuracion;
    }
}
