package com.lockton.rpt.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lockton.rpt.mappers.CatReportesCabecerosMapper;
import com.lockton.rpt.models.dto.CatReportesCabecerosDTO;
import com.lockton.rpt.models.entities.CatReportesCabeceros;
import com.lockton.rpt.repositories.CatReportesCabecerosRepository;

@Service
public class CatReportesCabecerosService {

@Autowired
    private CatReportesCabecerosRepository repository;

    public List<CatReportesCabecerosDTO> getAll() {
        List<CatReportesCabecerosDTO> dtos = null;
        List<CatReportesCabeceros> cats = repository.findAll();
        if(!cats.isEmpty())
            dtos = CatReportesCabecerosMapper.MapperDTO(cats);
        return dtos;
    }

    public CatReportesCabecerosDTO create(CatReportesCabecerosDTO catReportesDTO) {
        CatReportesCabeceros catReportes = CatReportesCabecerosMapper.MapperEntity(catReportesDTO);
        CatReportesCabeceros cat = repository.save(catReportes);
        return CatReportesCabecerosMapper.MapperDTO(cat);
    }

    public boolean delete(CatReportesCabecerosDTO catReportesDTO) {
        boolean rs = false;
        CatReportesCabeceros catReportes = CatReportesCabecerosMapper.MapperEntity(catReportesDTO);
        repository.delete(catReportes);
        rs = true;
        return rs;
    }

    public CatReportesCabecerosDTO update(CatReportesCabecerosDTO catReportesDTO) {
        CatReportesCabeceros catReportes = CatReportesCabecerosMapper.MapperEntity(catReportesDTO);
        CatReportesCabeceros cat = repository.save(catReportes);
        return CatReportesCabecerosMapper.MapperDTO(cat);
    }
}
