package com.lockton.rpt.repe.dto;

public class RepeConsultaValidacionRequest {
    private String nombreTecnico;
    private Integer idConsultaActual;
    private Integer idCorporativo;
    private Integer idVigencia;
    private Integer maxFilas;

    public String getNombreTecnico() { return nombreTecnico; }
    public void setNombreTecnico(String nombreTecnico) { this.nombreTecnico = nombreTecnico; }

    public Integer getIdConsultaActual() { return idConsultaActual; }
    public void setIdConsultaActual(Integer idConsultaActual) { this.idConsultaActual = idConsultaActual; }

    public Integer getIdCorporativo() { return idCorporativo; }
    public void setIdCorporativo(Integer idCorporativo) { this.idCorporativo = idCorporativo; }

    public Integer getIdVigencia() { return idVigencia; }
    public void setIdVigencia(Integer idVigencia) { this.idVigencia = idVigencia; }

    public Integer getMaxFilas() { return maxFilas; }
    public void setMaxFilas(Integer maxFilas) { this.maxFilas = maxFilas; }
}
