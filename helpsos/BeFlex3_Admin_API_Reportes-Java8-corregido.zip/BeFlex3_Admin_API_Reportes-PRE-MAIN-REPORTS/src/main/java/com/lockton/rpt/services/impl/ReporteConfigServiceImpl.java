package com.lockton.rpt.services.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lockton.rpt.mappers.CatRptGenMapper;
import com.lockton.rpt.models.dto.CatalogoReporteGenDTO;
import com.lockton.rpt.models.entities.CatalogoReporteGen;
import com.lockton.rpt.repositories.CatRptGenRepository;
import com.lockton.rpt.services.ReportesConfigService;

@Service
public class ReporteConfigServiceImpl implements ReportesConfigService {

    @Autowired
    private CatRptGenRepository repository;

    @Override
    public List<CatalogoReporteGenDTO> getAll(){
        List<CatalogoReporteGenDTO> dtos = null;
        List<CatalogoReporteGen> cats = repository.findAll();
        if(!cats.isEmpty())
            dtos = CatRptGenMapper.MapperDTO(cats);
        return dtos;
    }

    @Transactional
    @Override
    public List<CatalogoReporteGenDTO> actualizar(List<CatalogoReporteGenDTO> dtos) {
        List<CatalogoReporteGenDTO> lsUpdate = new ArrayList<>();

        for (CatalogoReporteGenDTO dto : dtos){
            CatalogoReporteGen ent = repository.findById(dto.getCatRptId())
            .orElseThrow(() -> new RuntimeException("El reporte con id" + dto.getCatRptId() + " no existe"));

            Date horario = FormatearFechaCadena(dto.getCatRptHorarioStr());
            dto.setCatRptHorario(horario);
            ent.setCatRptActivo(dto.getCatRptActivo());
            ent.setCatRptProgramado(dto.getCatRptProgramado());
            ent.setCatRptHorario(horario);
            repository.save(ent);
            lsUpdate.add(dto);
        }
        return lsUpdate;
    }

    private Date FormatearFechaCadena(String fechaStr) {
        if(fechaStr != null) {
            String[] horaMinuto = fechaStr.split(":");
            Calendar calendar = Calendar.getInstance();
            calendar.set( Calendar.HOUR_OF_DAY, Integer.parseInt(horaMinuto[0]) );
            calendar.set( Calendar.MINUTE, Integer.parseInt(horaMinuto[1]) );
            return calendar.getTime();
        }
        else
            return null;
    }
}
