package com.lockton.rpt.repe.dto;

import com.fasterxml.jackson.databind.JsonNode;

public class RepeConsultaRequest {
    private String clave;
    private String nombre;
    private String nombreTecnico;
    private String descripcion;
    private String tipoUso;
    private JsonNode requisitos;
    private JsonNode contrato;
    private Integer idUsuario;
    private Integer idCorporativoValidacion;
    private Integer idVigenciaValidacion;

    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getNombreTecnico() { return nombreTecnico; }
    public void setNombreTecnico(String nombreTecnico) { this.nombreTecnico = nombreTecnico; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getTipoUso() { return tipoUso; }
    public void setTipoUso(String tipoUso) { this.tipoUso = tipoUso; }

    public JsonNode getRequisitos() { return requisitos; }
    public void setRequisitos(JsonNode requisitos) { this.requisitos = requisitos; }

    public JsonNode getContrato() { return contrato; }
    public void setContrato(JsonNode contrato) { this.contrato = contrato; }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public Integer getIdCorporativoValidacion() { return idCorporativoValidacion; }
    public void setIdCorporativoValidacion(Integer idCorporativoValidacion) { this.idCorporativoValidacion = idCorporativoValidacion; }

    public Integer getIdVigenciaValidacion() { return idVigenciaValidacion; }
    public void setIdVigenciaValidacion(Integer idVigenciaValidacion) { this.idVigenciaValidacion = idVigenciaValidacion; }
}
