package com.lockton.rpt.models.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RepConfTablaPk implements Serializable{
    @Column(name = "idEmpresa")
    private Integer idEmpresa;

    @Column(name = "catReportesId", nullable = false)
    private Integer catReportesId;

    @Column(name = "grupo", length = 100, nullable = false)
    private String grupo;

    public RepConfTablaPk(){}

    public RepConfTablaPk(Integer idEmpresa, Integer catReportesId, String grupo){
        this.idEmpresa = idEmpresa;
        this.catReportesId = catReportesId;
        this.grupo = grupo;
    }

    public Integer getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Integer idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Integer getCatReportesId() {
        return catReportesId;
    }

    public void setCatReportesId(Integer catReportesId) {
        this.catReportesId = catReportesId;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RepConfTablaPk that = (RepConfTablaPk) o;
        return Objects.equals(idEmpresa, that.idEmpresa) &&
               Objects.equals(catReportesId, that.catReportesId) &&
               Objects.equals(grupo, that.grupo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idEmpresa, catReportesId, grupo);
    }
}
