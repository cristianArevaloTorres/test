package com.lockton.rpt.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lockton.rpt.models.dto.CatReportesCabecerosDTO;
import com.lockton.rpt.models.dto.CatReportesParamsDTO;
import com.lockton.rpt.models.dto.CatReportesSPDTO;
import com.lockton.rpt.services.CatReportesCabecerosService;
import com.lockton.rpt.services.CatReportesParamsService;
import com.lockton.rpt.services.CatReportesSPService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/beflex/reportes/SPconfiguracion")
@Api(tags = "Controlador para pantalla de configuración de reportes")
public class ReportesSPConfigController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportesSPConfigController.class);

    @Autowired
    CatReportesSPService catReportesSPService;
    @Autowired
    CatReportesParamsService catReportesParamsService;
    @Autowired
    CatReportesCabecerosService catReportesCabecerosService;

    @PostMapping(value = "/agregarSP")
    @ApiOperation(value = "Creación de Stored Procedure.", notes = "Operacion encargada de establecer el nombre de un SP.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<CatReportesSPDTO> agregarSP(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) @RequestBody CatReportesSPDTO catReportesSPDTO) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> agregarSP... " +  catReportesSPDTO);        
        return ResponseEntity.ok().body(catReportesSPService.create(catReportesSPDTO));
    }
    @DeleteMapping(value = "/eliminarSP")
    @ApiOperation(value = "Creación de Stored Procedure.", notes = "Operacion encargada de establecer el nombre de un SP.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<String> eliminarSP(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) @RequestBody int id) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> eliminarSP... " +  id);        
        // catReportesSPService.delete(id);
        return ResponseEntity.ok().body("Eliminado");
    }

    @GetMapping(value = "/obtenerParametros")
    @ApiOperation(value = "Obtención de parametros.", notes = "Operacion encargada de obtener todos los parametros.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<List<CatReportesParamsDTO>> obtenerParametros() {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> obtenerParametros... ");
        return ResponseEntity.ok().body(catReportesParamsService.getAll());
    }

    @PostMapping(value = "/agregarParametros")
    @ApiOperation(value = "Creación de parametro.", notes = "Operacion encargada de establecer el nombre de un parametro.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<CatReportesParamsDTO> agregarParametro(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) @RequestBody CatReportesParamsDTO catReportesParamsDTO) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> agregarParametro... " +  catReportesParamsDTO);
        return ResponseEntity.ok().body(catReportesParamsService.create(catReportesParamsDTO));
    }

    
    @PostMapping(value = "/agregarCabeceros")
    @ApiOperation(value = "Creación de cabecero.", notes = "Operacion encargada de establecer el nombre de un cabecero.")
	@ApiResponses(value = { @ApiResponse(code = 500, message = "En caso de que se presente un error inesperado."),
    @ApiResponse(code = 400, message = "No se recibieron los par\u00e1metros correctos.") })
	public ResponseEntity<CatReportesCabecerosDTO> agregarCabecero(
			@ApiParam(value = "Valores de la aplicacion a filtrar", required = false) @RequestBody CatReportesCabecerosDTO catReportesCabecerosDTO) {
		LOGGER.info("Inicia controller==> ReportesDBConfigController ==> agregarCabecero... " +  catReportesCabecerosDTO);
        return ResponseEntity.ok().body(catReportesCabecerosService.create(catReportesCabecerosDTO));
    }
}