package com.lockton.rpt.repe.controller;

import com.lockton.rpt.repe.dto.RepeApiResponse;
import com.lockton.rpt.repe.dto.RepeSnapshotEjecucionRequest;
import com.lockton.rpt.services.ReporteEstadisticaSnapshotService;
import com.lockton.rpt.util.SafeApiError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/beflex/reporte-estadisticas/repe/snapshots")
public class WSRepeSnapshotController {
    private static final Logger LOGGER = LoggerFactory.getLogger(WSRepeSnapshotController.class);

    private final ReporteEstadisticaSnapshotService snapshotService;
    public WSRepeSnapshotController(ReporteEstadisticaSnapshotService snapshotService) {
        this.snapshotService = snapshotService;
    }

    @GetMapping
    public ResponseEntity<RepeApiResponse<List<Map<String, Object>>>> listar(@RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(RepeApiResponse.ok(
                    "REPE-SNP-LIST", "Historial de sincronizaciones consultado correctamente.",
                    snapshotService.listarHistorial(idCorporativo)));
        } catch (Exception ex) {
            return error("REPE-SNP-LIST-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/activo")
    public ResponseEntity<RepeApiResponse<Map<String, Object>>> activo(@RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(RepeApiResponse.ok(
                    "REPE-SNP-ACT", "Estado de sincronización consultado correctamente.",
                    snapshotService.obtenerActivo(idCorporativo)));
        } catch (Exception ex) {
            return error("REPE-SNP-ACT-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/disponibilidad")
    public ResponseEntity<RepeApiResponse<Map<String, Object>>> disponibilidad(
            @RequestParam int idCorporativo,
            @RequestParam(required = false) Integer idVigencia) {
        try {
            return ResponseEntity.ok(RepeApiResponse.ok(
                    "REPE-SNP-AVAILABLE", "Disponibilidad del histórico consultada correctamente.",
                    snapshotService.obtenerDisponibilidad(idCorporativo, idVigencia)));
        } catch (Exception ex) {
            return error("REPE-SNP-AVAILABLE-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{idEjecucion}/progreso")
    public ResponseEntity<RepeApiResponse<Map<String, Object>>> progreso(
            @PathVariable long idEjecucion,
            @RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(RepeApiResponse.ok(
                    "REPE-SNP-PROG", "Progreso de sincronización consultado correctamente.",
                    snapshotService.obtenerProgreso(idEjecucion, idCorporativo)));
        } catch (IllegalArgumentException ex) {
            return error("REPE-SNP-PROG-404", ex, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return error("REPE-SNP-PROG-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/datos/vigencias")
    public ResponseEntity<RepeApiResponse<List<Map<String, Object>>>> vigencias(@RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(RepeApiResponse.ok(
                    "REPE-SNP-VIG", "Vigencias con histórico publicado consultadas correctamente.",
                    snapshotService.listarVigencias(idCorporativo)));
        } catch (Exception ex) {
            return error("REPE-SNP-VIG-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/datos/empresas")
    public ResponseEntity<RepeApiResponse<List<Map<String, Object>>>> empresas(
            @RequestParam int idCorporativo,
            @RequestParam int idVigencia) {
        try {
            return ResponseEntity.ok(RepeApiResponse.ok(
                    "REPE-SNP-EMP", "Empresas del histórico consultadas correctamente.",
                    snapshotService.listarEmpresas(idCorporativo, idVigencia)));
        } catch (Exception ex) {
            return error("REPE-SNP-EMP-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/datos")
    public ResponseEntity<RepeApiResponse<Map<String, Object>>> datos(
            @RequestParam int idCorporativo,
            @RequestParam int idVigencia,
            @RequestParam(required = false) Integer idEmpresa,
            @RequestParam(required = false) String titular,
            @RequestParam(defaultValue = "1") int pagina,
            @RequestParam(defaultValue = "50") int tamanioPagina) {
        try {
            return ResponseEntity.ok(RepeApiResponse.ok(
                    "REPE-SNP-DATA", "Datos históricos consultados correctamente.",
                    snapshotService.consultarDatos(
                            idCorporativo, idVigencia, idEmpresa, titular, pagina, tamanioPagina)));
        } catch (Exception ex) {
            return error("REPE-SNP-DATA-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{idEjecucion}")
    public ResponseEntity<RepeApiResponse<Map<String, Object>>> detalle(
            @PathVariable long idEjecucion,
            @RequestParam int idCorporativo) {
        try {
            return ResponseEntity.ok(RepeApiResponse.ok(
                    "REPE-SNP-DET", "Detalle de la sincronización consultado correctamente.",
                    snapshotService.obtenerDetalle(idEjecucion, idCorporativo)));
        } catch (IllegalArgumentException ex) {
            return error("REPE-SNP-DET-404", ex, HttpStatus.NOT_FOUND);
        } catch (Exception ex) {
            return error("REPE-SNP-DET-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/ejecutar")
    public ResponseEntity<RepeApiResponse<Map<String, Object>>> ejecutar(
            @RequestBody RepeSnapshotEjecucionRequest request) {
        try {
            if (request == null || request.getIdCorporativo() == null || request.getIdUsuario() == null) {
                throw new IllegalArgumentException("El corporativo y el usuario son requeridos.");
            }
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(RepeApiResponse.ok(
                    "REPE-SNP-RUN", "La sincronización fue registrada y continúa en segundo plano.",
                    snapshotService.iniciar(request.getIdCorporativo(), request.getIdUsuario())));
        } catch (Exception ex) {
            return error("REPE-SNP-RUN-ERR", ex, HttpStatus.BAD_REQUEST);
        }
    }

    private <T> ResponseEntity<RepeApiResponse<T>> error(String code, Exception ex, HttpStatus status) {
        LOGGER.error("REPE snapshot [{}]", code, ex);
        HttpStatus responseStatus = SafeApiError.isInfrastructureFailure(ex)
                ? HttpStatus.SERVICE_UNAVAILABLE
                : status;
        return ResponseEntity.status(responseStatus).body(
                RepeApiResponse.<T>fail(
                        code,
                        SafeApiError.publicMessage(ex, "No fue posible completar la operación. Intenta nuevamente."),
                        null));
    }
}
