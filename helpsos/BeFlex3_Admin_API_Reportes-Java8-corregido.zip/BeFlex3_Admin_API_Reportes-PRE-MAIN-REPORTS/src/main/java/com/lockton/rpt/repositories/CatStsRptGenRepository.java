package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lockton.rpt.models.entities.CatalogoEstatusReporteGen;

@Repository
public interface CatStsRptGenRepository extends JpaRepository<CatalogoEstatusReporteGen, Long> {

}
