package com.lockton.rpt.controllers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lockton.rpt.services.impl.ConfigIndicadoresService;
import com.lockton.rpt.services.impl.ReporteCorporativoService;

import com.lockton.rpt.util.TextUtil;
import com.lockton.rpt.util.SafeApiError;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("beflex/reporte-estadisticas/config")
public class WSConfigIndicadores {

    private final ConfigIndicadoresService service;
    private final ReporteCorporativoService reporteService;

    public WSConfigIndicadores(ConfigIndicadoresService service, ReporteCorporativoService reporteService) {
        this.service = service;
        this.reporteService = reporteService;
    }

    @GetMapping("/secciones")
    public ResponseEntity<Map<String, Object>> secciones(
            @RequestParam(required = false) String idCorporativosRol) {
        return ok(service.listarSecciones(parseIdCorporativosRol(idCorporativosRol)));
    }

    @GetMapping("/secciones/{idSeccion}/indicadores")
    public ResponseEntity<Map<String, Object>> indicadores(
            @RequestParam(required = false) String idCorporativosRol,
            @PathVariable int idSeccion) {
        return ok(service.listarIndicadores(idSeccion, parseIdCorporativosRol(idCorporativosRol)));
    }

    @GetMapping("/parametros-reporte")
    public ResponseEntity<Map<String, Object>> parametrosReporte(
            @RequestParam(required = false) Integer idCorporativo,
            @RequestParam(required = false) String idCorporativosRol) {
        if (idCorporativo == null || idCorporativo <= 0) {
            return ok(Collections.emptyList());
        }
        List<Integer> rol = parseIdCorporativosRol(idCorporativosRol);
        if (rol.isEmpty()) {
            rol = Collections.singletonList(idCorporativo);
        }
        return ok(service.listarParametrosReporte(idCorporativo, rol));
    }

    @PostMapping("/parametros-reporte/guardar")
    public ResponseEntity<Map<String, Object>> guardarParametrosReporte(
            @RequestBody Map<String, Object> body) {
        try {
            Map<String, String> parametros = stringMap(body.get("parametros"));
            Integer idCorporativo = service.resolverIdCorporativoDesdeParametros(parametros);
            if (idCorporativo == null) {
                return error("Indique IdCorporativo en los parámetros del reporte.", HttpStatus.BAD_REQUEST);
            }
            int idUsuario = intFrom(body.get("idUsuario"), 1);
            String nombreUsuario = body.get("nombreUsuario") != null
                    ? String.valueOf(body.get("nombreUsuario")) : "CREA017 UI";
            List<Integer> rol = parseIdCorporativosRolFromBody(body.get("idCorporativosRol"));
            if (rol.isEmpty()) {
                rol = Collections.singletonList(idCorporativo);
            }
            return okSingle(service.guardarParametrosReporte(idCorporativo, parametros,
                    idUsuario, nombreUsuario, rol));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/indicadores/{idIndicador}")
    public ResponseEntity<Map<String, Object>> indicador(
            @RequestParam(required = false) Integer idCorporativo,
            @PathVariable int idIndicador) {
        try {
            if (idCorporativo == null || idCorporativo <= 0) {
                return error("idCorporativo es obligatorio.", HttpStatus.BAD_REQUEST);
            }
            return okSingle(service.obtenerIndicador(idCorporativo, idIndicador));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/indicadores/{idIndicador}/preview")
    public ResponseEntity<Map<String, Object>> preview(
            @PathVariable int idIndicador,
            @RequestBody Map<String, Object> body) {
        try {
            Map<String, String> params = stringMap(body.get("parametros"));
            Integer idCorporativo = service.resolverIdCorporativoDesdeParametros(params);
            return okSingle(service.preview(idCorporativo, idIndicador, params));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/indicadores/{idIndicador}/guardar")
    public ResponseEntity<Map<String, Object>> guardar(
            @PathVariable int idIndicador,
            @RequestBody Map<String, Object> body) {
        try {
            Integer idCorporativo = intFromNullable(body.get("idCorporativo"));
            if (idCorporativo == null) {
                return error("idCorporativo es obligatorio.", HttpStatus.BAD_REQUEST);
            }
            int idUsuario = intFrom(body.get("idUsuario"), 1);
            String nombreUsuario = body.get("nombreUsuario") != null
                    ? String.valueOf(body.get("nombreUsuario")) : "CREA017 UI";
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> parametros = (List<Map<String, Object>>) body.get("parametros");
            if (parametros == null) {
                return error("Se requiere lista parametros.", HttpStatus.BAD_REQUEST);
            }
            return okSingle(service.guardarParametros(idCorporativo, idIndicador, parametros,
                    idUsuario, nombreUsuario));
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/reporte/datos")
    public ResponseEntity<Map<String, Object>> datosReporte(@RequestBody Map<String, Object> body) {
        try {
            Map<String, String> parametros = stringMap(body.get("parametros"));
            Integer idCorporativo = service.resolverIdCorporativoDesdeParametros(parametros);
            if (idCorporativo == null) {
                return error("Indique IdCorporativo en los parámetros del reporte.", HttpStatus.BAD_REQUEST);
            }
            List<Integer> rol = parseIdCorporativosRolFromBody(body.get("idCorporativosRol"));
            if (rol.isEmpty()) {
                return error("Se requiere idCorporativosRol para filtrar indicadores del reporte.",
                        HttpStatus.BAD_REQUEST);
            }
            Integer idSeccion = null;
            if (body.get("idSeccion") != null) {
                int parsed = intFrom(body.get("idSeccion"), 0);
                if (parsed > 0) {
                    idSeccion = parsed;
                }
            }
            return okSingle(reporteService.obtenerDatosReporte(idCorporativo, parametros, rol, idSeccion));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/reporte/generar")
    public ResponseEntity<Map<String, Object>> generarReporte(@RequestBody Map<String, Object> body) {
        try {
            Map<String, String> parametros = stringMap(body.get("parametros"));
            Integer idCorporativo = service.resolverIdCorporativoDesdeParametros(parametros);
            if (idCorporativo == null) {
                return error("Indique IdCorporativo en los parámetros del reporte.", HttpStatus.BAD_REQUEST);
            }
            String formato = body.get("formato") != null ? String.valueOf(body.get("formato")) : "excel";
            List<Integer> rol = parseIdCorporativosRolFromBody(body.get("idCorporativosRol"));
            if (rol.isEmpty()) {
                return error("Se requiere idCorporativosRol para filtrar indicadores del reporte.",
                        HttpStatus.BAD_REQUEST);
            }
            Integer idSeccion = null;
            if (body.get("idSeccion") != null) {
                int parsed = intFrom(body.get("idSeccion"), 0);
                if (parsed > 0) {
                    idSeccion = parsed;
                }
            }
            return okSingle(reporteService.generarReporte(idCorporativo, formato, parametros, rol, idSeccion));
        } catch (IllegalArgumentException ex) {
            return error(ex.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            return error(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private int intFrom(Object value, int defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private Integer intFromNullable(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number) {
            int parsed = ((Number) value).intValue();
            return parsed > 0 ? parsed : null;
        }
        String text = String.valueOf(value).trim();
        if (text.isEmpty() || "null".equalsIgnoreCase(text)) {
            return null;
        }
        try {
            int parsed = Integer.parseInt(text);
            return parsed > 0 ? parsed : null;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private List<Integer> parseIdCorporativosRol(String raw) {
        if (raw == null || TextUtil.isBlank(raw)) {
            return Collections.emptyList();
        }
        List<Integer> out = new ArrayList<>();
        for (String part : raw.split("[,;\\s]+")) {
            if (part == null || TextUtil.isBlank(part)) {
                continue;
            }
            try {
                int parsed = Integer.parseInt(part.trim());
                if (parsed > 0 && !out.contains(parsed)) {
                    out.add(parsed);
                }
            } catch (NumberFormatException ignored) {
                // omitir tokens no numéricos
            }
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private List<Integer> parseIdCorporativosRolFromBody(Object raw) {
        if (raw == null) {
            return Collections.emptyList();
        }
        if (raw instanceof List<?>) {
            List<Integer> out = new ArrayList<>();
            for (Object item : (List<?>) raw) {
                if (item instanceof Number) {
                    int parsed = ((Number) item).intValue();
                    if (parsed > 0 && !out.contains(parsed)) {
                        out.add(parsed);
                    }
                } else if (item != null) {
                    out.addAll(parseIdCorporativosRol(String.valueOf(item)));
                }
            }
            return out;
        }
        return parseIdCorporativosRol(String.valueOf(raw));
    }

    @SuppressWarnings("unchecked")
    private Map<String, String> stringMap(Object raw) {
        if (raw == null) {
            return new HashMap<>();
        }
        Map<String, String> out = new HashMap<>();
        if (raw instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) raw;
            for (Map.Entry<String, Object> e : map.entrySet()) {
                if (e.getValue() != null) {
                    out.put(e.getKey(), String.valueOf(e.getValue()));
                }
            }
        }
        return out;
    }

    private ResponseEntity<Map<String, Object>> ok(List<Map<String, Object>> data) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", data);
        return new ResponseEntity<>(body, HttpStatus.OK);
    }

    private ResponseEntity<Map<String, Object>> okSingle(Map<String, Object> data) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", true);
        body.put("data", data);
        return new ResponseEntity<>(body, HttpStatus.OK);
    }

    private ResponseEntity<Map<String, Object>> error(String message, HttpStatus status) {
        Map<String, Object> body = new HashMap<>();
        body.put("success", false);
        body.put("error", SafeApiError.sanitizeMessage(
                message,
                "No fue posible completar la operación. Intenta nuevamente."));
        return new ResponseEntity<>(body, status);
    }
}
