package com.lockton.rpt.models.dto;

import java.time.LocalDateTime;

public class CatReportesParamsResp_DTO {
    public int catReportesParamsId;
    public int catReportesSPId;
    public int catReportesTipoDatoId;
    public String catReportesParamsLongitud;
    public int catReportesParamsOrden;
    public String catReportesParamsNombre;
    public int ESid;
    public Integer catReportesParamsUsuarioMod;
    public LocalDateTime catReportesParamsFechaMod;
    public Integer catReportesParamsUsuarioDel;
    public LocalDateTime catReportesParamsFechaDel;

    public int getCatReportesParamsId() {
        return catReportesParamsId;
    }
    public void setCatReportesParamsId(int catReportesParamsId) {
        this.catReportesParamsId = catReportesParamsId;
    }
    public int getCatReportesSPId() {
        return catReportesSPId;
    }
    public void setCatReportesSPId(int catReportesSPId) {
        this.catReportesSPId = catReportesSPId;
    }
    public int getCatReportesTipoDatoId() {
        return catReportesTipoDatoId;
    }
    public void setCatReportesTipoDatoId(int catReportesTipoDatoId) {
        this.catReportesTipoDatoId = catReportesTipoDatoId;
    }
    public String getCatReportesParamsLongitud() {
        return catReportesParamsLongitud;
    }
    public void setCatReportesParamsLongitud(String catReportesParamsLongitud) {
        this.catReportesParamsLongitud = catReportesParamsLongitud;
    }
    public int getCatReportesParamsOrden() {
        return catReportesParamsOrden;
    }
    public void setCatReportesParamsOrden(int catReportesParamsOrden) {
        this.catReportesParamsOrden = catReportesParamsOrden;
    }
    public String getCatReportesParamsNombre() {
        return catReportesParamsNombre;
    }
    public void setCatReportesParamsNombre(String catReportesParamsNombre) {
        this.catReportesParamsNombre = catReportesParamsNombre;
    }
    public int getESid() {
        return ESid;
    }
    public void setESid(int eSid) {
        ESid = eSid;
    }
    public Integer getCatReportesParamsUsuarioMod() {
        return catReportesParamsUsuarioMod;
    }
    public void setCatReportesParamsUsuarioMod(Integer catReportesParamsUsuarioMod) {
        this.catReportesParamsUsuarioMod = catReportesParamsUsuarioMod;
    }
    public LocalDateTime getCatReportesParamsFechaMod() {
        return catReportesParamsFechaMod;
    }
    public void setCatReportesParamsFechaMod(LocalDateTime catReportesParamsFechaMod) {
        this.catReportesParamsFechaMod = catReportesParamsFechaMod;
    }
    public Integer getCatReportesParamsUsuarioDel() {
        return catReportesParamsUsuarioDel;
    }
    public void setCatReportesParamsUsuarioDel(Integer catReportesParamsUsuarioDel) {
        this.catReportesParamsUsuarioDel = catReportesParamsUsuarioDel;
    }
    public LocalDateTime getCatReportesParamsFechaDel() {
        return catReportesParamsFechaDel;
    }
    public void setCatReportesParamsFechaDel(LocalDateTime catReportesParamsFechaDel) {
        this.catReportesParamsFechaDel = catReportesParamsFechaDel;
    }
}
