package com.lockton.rpt.models.dto.crea17;

import java.util.Map;

public class PlantillaDocumentoGuardarRequestDTO {
    private Map<String, Object> documento;
    private Integer idUsuario;

    public Map<String, Object> getDocumento() { return documento; }
    public void setDocumento(Map<String, Object> documento) { this.documento = documento; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
