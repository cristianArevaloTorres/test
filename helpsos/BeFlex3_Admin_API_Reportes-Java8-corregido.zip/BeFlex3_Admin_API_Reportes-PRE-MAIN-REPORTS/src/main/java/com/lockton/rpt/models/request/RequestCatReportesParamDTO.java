package com.lockton.rpt.models.request;

public class RequestCatReportesParamDTO {
    
    private int catReportesParamsId;
    private int catReportesSPId;
    private int catReportesTipoDatoId;
    private int catReportesParamsLongitud;
    private int catReportesParamsOrden;
    private String catReportesParamsNombre;
    private String catReportesParamsDesc;
    private int ESid;
    private int catReportesParamsUsuarioAdd;
    private String catReportesParamsFechaAdd;

    // Getters y Setters

    public int getCatReportesParamsId() {
        return catReportesParamsId;
    }

    public void setCatReportesParamsId(int catReportesParamsId) {
        this.catReportesParamsId = catReportesParamsId;
    }

    public int getCatReportesSPId() {
        return catReportesSPId;
    }

    public void setCatReportesSPId(int catReportesSPId) {
        this.catReportesSPId = catReportesSPId;
    }

    public int getCatReportesTipoDatoId() {
        return catReportesTipoDatoId;
    }

    public void setCatReportesTipoDatoId(int catReportesTipoDatoId) {
        this.catReportesTipoDatoId = catReportesTipoDatoId;
    }

    public int getCatReportesParamsLongitud() {
        return catReportesParamsLongitud;
    }

    public void setCatReportesParamsLongitud(int catReportesParamsLongitud) {
        this.catReportesParamsLongitud = catReportesParamsLongitud;
    }

    public int getCatReportesParamsOrden() {
        return catReportesParamsOrden;
    }

    public void setCatReportesParamsOrden(int catReportesParamsOrden) {
        this.catReportesParamsOrden = catReportesParamsOrden;
    }

    public String getCatReportesParamsNombre() {
        return catReportesParamsNombre;
    }

    public void setCatReportesParamsNombre(String catReportesParamsNombre) {
        this.catReportesParamsNombre = catReportesParamsNombre;
    }

    public String getCatReportesParamsDesc() {
        return catReportesParamsDesc;
    }

    public void setCatReportesParamsDesc(String catReportesParamsDesc) {
        this.catReportesParamsDesc = catReportesParamsDesc;
    }

    public int getESid() {
        return ESid;
    }

    public void setESid(int ESid) {
        this.ESid = ESid;
    }

    public int getCatReportesParamsUsuarioAdd() {
        return catReportesParamsUsuarioAdd;
    }

    public void setCatReportesParamsUsuarioAdd(int catReportesParamsUsuarioAdd) {
        this.catReportesParamsUsuarioAdd = catReportesParamsUsuarioAdd;
    }

    public String getCatReportesParamsFechaAdd() {
        return catReportesParamsFechaAdd;
    }

    public void setCatReportesParamsFechaAdd(String catReportesParamsFechaAdd) {
        this.catReportesParamsFechaAdd = catReportesParamsFechaAdd;
    }
    
}
