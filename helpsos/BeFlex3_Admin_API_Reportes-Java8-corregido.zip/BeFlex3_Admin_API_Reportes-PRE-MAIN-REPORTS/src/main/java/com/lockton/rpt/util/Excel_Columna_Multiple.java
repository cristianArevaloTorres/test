package com.lockton.rpt.util;

import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;

/**
 * Tipo de reporte multi-hoja basado 100% en los datos del resultset (no en la posicion/indexTable):
 *  - La columna {@code NombrePestana} define el nombre de cada hoja (una hoja por valor distinto).
 *  - La columna {@code grupo} define a que grupo de {@code bf_RepConf_Columna} pertenece esa hoja,
 *    y con eso se resuelven los encabezados/columnas a mostrar.
 *
 * Pueden venir varios resultsets. Las filas con el mismo {@code NombrePestana}
 * se escriben en una sola hoja y cada valor de {@code grupo} conserva su propia
 * tabla/configuracion dentro de esa hoja.
 */
public class Excel_Columna_Multiple {

    /** Columna del RS que define el nombre de la pestana. */
    private static final String COL_PESTANA = "NombrePestana";
    /** Columna del RS que define el grupo de columnas (coincide con bf_RepConf_Tabla.grupo). */
    private static final String COL_GRUPO = "grupo";

    public static String generar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
                                 Map<String, Object> parametros,
                                 String outputDir) throws Exception {
        SXSSFWorkbook wb = new SXSSFWorkbook(1000);
        wb.setCompressTempFiles(true);
        int sheetsCreated = agregarHojas(wb, resultsets, parametros);

        // Si ninguna pestana aporto filas, no generamos archivo
        if (sheetsCreated == 0) {
            try { wb.close(); } catch (Throwable ignore) {}
            try { wb.dispose(); } catch (Throwable ignore) {}
            return "";
        }

        // 4) Resolver ruta de salida (mismo criterio que Excel_Hoja_Multiple)
        String rutaDir = outputDir;
        Object idEmpObj = parametros.get("idEmpresa");
        if (idEmpObj == null) {
            idEmpObj = String.valueOf(
                    String.valueOf(
                            parametros.getOrDefault("admIdEmpresa",
                                    String.valueOf(
                                            parametros.getOrDefault("empresas",
                                                    parametros.get("empresasIds")
                                            )
                                    )
                            )
                    )
            );
        }
        String idEmp = null;
        if (idEmpObj != null) {
            String raw = String.valueOf(idEmpObj).trim();
            raw = raw.replaceAll("[\\{\\}\\[\\]]", "");
            if (raw.contains(",")) raw = raw.split(",")[0].trim();
            String digits = raw.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) idEmp = digits;
        }
        String subFolder = sanitizarNombreCarpeta(
                String.valueOf(
                        parametros.getOrDefault(
                                "catReportesNombre",
                                parametros.getOrDefault("tituloReporteB1", nombreReportePorId(parametros))
                        )
                )
        );
        if (subFolder == null || subFolder.trim().isEmpty()) subFolder = "Reporte";
        try {
            Class<?> c = Class.forName("com.lockton.rpt.util.Constantes");
            Object v = c.getField("DOCUMENTO_EMPRESA").get(null);
            if (idEmp != null && v != null) {
                String base = String.valueOf(v);
                if (base != null && !base.trim().isEmpty()) {
                    rutaDir = base + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            }
        } catch (Throwable ignore) {
            // Ignorar y probar con variable de entorno
        }
        if (rutaDir == null || ".".equals(rutaDir) || outputDir.equals(rutaDir)) {
            try {
                String base = System.getenv("UPLOAD_FOLDER");
                if (base != null && !base.trim().isEmpty() && idEmp != null) {
                    rutaDir = base + File.separator + "DocumentoEmpresa" + File.separator + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            } catch (Throwable ignore) {
                // Si tampoco esta la variable de entorno, caeremos en outputDir
            }
        }

        String rs = guardarWorkbook(wb, rutaDir, nombreArchivo("Reporte", parametros));
        try { wb.dispose(); } catch (Throwable ignore) {}
        return rs;
    }

    /**
     * Agrega las hojas configurables a un libro ya creado. Esto permite que
     * flujos legacy (como Cobranza) reutilicen el mismo renderizador y sigan
     * controlando el guardado, cifrado y registro de su archivo.
     *
     * @return numero de hojas creadas.
     */
    public static int agregarHojas(
            Workbook wb,
            List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
            Map<String, Object> parametros) {
        Map<String, Map<String, Object>> configPorGrupo =
                indexarConfigPorGrupo(parametros);
        LinkedHashMap<String, DatosHoja> hojas = new LinkedHashMap<>();

        if (resultsets != null) {
            for (ArrayList<LinkedCaseInsensitiveMap<?>> rows : resultsets) {
                if (rows == null || rows.isEmpty()) continue;
                for (LinkedCaseInsensitiveMap<?> row : rows) {
                    if (row == null) continue;
                    String pestana = valorTexto(row.get(COL_PESTANA), "Hoja");
                    String grupo = valorTexto(row.get(COL_GRUPO), "");
                    DatosHoja hoja = hojas.computeIfAbsent(
                            pestana, k -> new DatosHoja());
                    String claveGrupo = normalizeKey(grupo);
                    if (claveGrupo.isEmpty()) claveGrupo = "__sin_grupo__";
                    SeccionGrupo seccion = hoja.secciones.computeIfAbsent(
                            claveGrupo, k -> new SeccionGrupo(grupo));
                    seccion.filas.add(row);
                }
            }
        }

        int sheetsCreated = 0;
        Set<String> nombresUsados = new HashSet<>();
        for (Map.Entry<String, DatosHoja> entradaHoja : hojas.entrySet()) {
            List<SeccionGrupo> seccionesActivas = new ArrayList<>();
            for (SeccionGrupo seccion : entradaHoja.getValue().secciones.values()) {
                Map<String, Object> conf = seccion.grupo.isEmpty()
                        ? null : configPorGrupo.get(normalizeKey(seccion.grupo));
                if (grupoActivo(conf)) seccionesActivas.add(seccion);
            }
            if (seccionesActivas.isEmpty()) continue;

            String sheetName = nombreHojaUnico(
                    sanitizarNombreHoja(entradaHoja.getKey()), nombresUsados);
            Sheet sh = wb.createSheet(sheetName);
            int siguienteFila = 0;
            for (SeccionGrupo seccion : seccionesActivas) {
                Map<String, Object> grupoConf = seccion.grupo.isEmpty()
                        ? null : configPorGrupo.get(normalizeKey(seccion.grupo));
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> columnas = grupoConf == null
                        ? null : (List<Map<String, Object>>) grupoConf.get("columnas");
                siguienteFila = escribirTabla(
                        sh, seccion.filas, columnas, grupoConf,
                        parametros, siguienteFila);
            }
            sheetsCreated++;
        }
        return sheetsCreated;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Map<String, Object>> indexarConfigPorGrupo(Map<String, Object> parametros) {
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        try {
            Object o = parametros == null ? null : parametros.get("reporteConfig");
            if (o instanceof List) {
                for (Map<String, Object> m : (List<Map<String, Object>>) o) {
                    if (m == null) continue;
                    Object g = m.get("grupo");
                    if (g == null) continue;
                    out.put(normalizeKey(String.valueOf(g)), m);
                }
            }
        } catch (Throwable ignore) {}
        return out;
    }

    private static int escribirTabla(
            Sheet sh,
            List<LinkedCaseInsensitiveMap<?>> rows,
            List<Map<String, Object>> columnas,
            Map<String, Object> grupoConf,
            Map<String, Object> parametros,
            int filaInicio) {
        if (rows == null || rows.isEmpty()) return filaInicio;

        // Evitar OOM al auto-ajustar columnas en hojas muy grandes
        boolean allowAutoSize = !(sh instanceof SXSSFSheet) || rows.size() <= 5000;
        try {
            if (allowAutoSize && sh instanceof SXSSFSheet) {
                ((SXSSFSheet) sh).trackAllColumnsForAutoSizing();
            }
        } catch (Throwable ignore) {}

        LinkedCaseInsensitiveMap<?> first = rows.get(0);
        Map<String, String> normalToActual = new HashMap<>();
        if (first != null) {
            for (Object k : first.keySet()) {
                String actual = String.valueOf(k);
                normalToActual.put(normalizeKey(actual), actual);
            }
        }

        List<String> headers = new ArrayList<>();
        List<String> campos = new ArrayList<>();
        List<Integer> tipos = new ArrayList<>();
        List<Integer> anchos = new ArrayList<>();
        List<String> formatos = new ArrayList<>();
        List<String> alineaciones = new ArrayList<>();
        Set<String> camposConfigurados = new LinkedHashSet<>();
        Set<String> camposIncluidos = new LinkedHashSet<>();
        boolean preservarDinamicas = parseBool(
                grupoConf == null ? null
                        : grupoConf.get("preservarColumnasDinamicas"))
                || parseBool(parametros == null ? null
                        : parametros.get("preservarColumnasDinamicas"));
        if (columnas != null && !columnas.isEmpty()) {
            for (Map<String, Object> col : columnas) {
                Object campoObj = col.get("campoOrigen");
                if (campoObj == null) continue;
                String campoCfg = String.valueOf(campoObj);
                String normalizado = normalizeKey(campoCfg);
                camposConfigurados.add(normalizado);
                if (!esVisible(col.get("visible"))) continue;
                String resolved = campoCfg;
                String tryActual = normalToActual.get(normalizado);
                if (tryActual != null) {
                    resolved = tryActual;
                }
                if (esColumnaAuxiliar(resolved)
                        || camposIncluidos.contains(normalizado)) continue;
                camposIncluidos.add(normalizado);
                campos.add(resolved);
                Object encabezado = col.get("encabezado");
                headers.add(encabezado == null
                        ? resolved : String.valueOf(encabezado));
                Integer tipo = null;
                try { Object td = col.get("tipoDato"); if (td != null) tipo = Integer.parseInt(String.valueOf(td)); } catch (Exception ignore) {}
                tipos.add(tipo);
                anchos.add(safeInt(col.get("ancho"), 0));
                formatos.add(col.get("formato") == null
                        ? null : String.valueOf(col.get("formato")));
                alineaciones.add(col.get("alinear") == null
                        ? null : String.valueOf(col.get("alinear")));
            }
        }

        if (preservarDinamicas || columnas == null || columnas.isEmpty()) {
            for (Object k : first.keySet()) {
                String key = String.valueOf(k);
                String normalizado = normalizeKey(key);
                if (esColumnaAuxiliar(key)
                        || camposConfigurados.contains(normalizado)
                        || camposIncluidos.contains(normalizado)) continue;
                camposIncluidos.add(normalizado);
                campos.add(key);
                headers.add(key);
                tipos.add(null);
                anchos.add(0);
                formatos.add(null);
                alineaciones.add(null);
            }
        }

        // Una configuracion obsoleta no debe producir una hoja vacia.
        if (campos.isEmpty() && first != null) {
            for (Object k : first.keySet()) {
                String key = String.valueOf(k);
                if (esColumnaAuxiliar(key)) continue;
                campos.add(key);
                headers.add(key);
                tipos.add(null);
                anchos.add(0);
                formatos.add(null);
                alineaciones.add(null);
            }
        }

        CellStyle headerStyle = crearHeaderStyle(
                sh.getWorkbook(),
                grupoConf != null ? grupoConf.get("colorFondo") : null,
                grupoConf != null ? grupoConf.get("colorLetra") : null
        );
        CellStyle currencyStyle = sh.getWorkbook().createCellStyle();
        short cfmt = sh.getWorkbook().createDataFormat().getFormat("\"$\"#,##0.00");
        currencyStyle.setDataFormat(cfmt);
        CellStyle dateStyle = sh.getWorkbook().createCellStyle();
        dateStyle.setDataFormat(sh.getWorkbook().createDataFormat()
                .getFormat("dd/MM/yyyy"));

        CellStyle[] estilosColumna = new CellStyle[campos.size()];
        String alineacionGrupo = grupoConf == null
                || grupoConf.get("alineacion") == null
                        ? null : String.valueOf(grupoConf.get("alineacion"));
        for (int i = 0; i < campos.size(); i++) {
            String formato = resolveFormatString(formatos.get(i));
            Integer tipo = tipos.get(i);
            if (formato == null) {
                if (tipo != null && tipo == 4) formato = "\"$\"#,##0.00";
                else if (tipo != null && tipo == 3) formato = "dd/MM/yyyy";
            }
            String alineacionCfg = alineaciones.get(i);
            HorizontalAlignment alineacion = resolveAlign(
                    alineacionCfg == null || alineacionCfg.trim().isEmpty()
                            ? alineacionGrupo : alineacionCfg);
            if (formato != null || alineacion != null) {
                CellStyle estilo = sh.getWorkbook().createCellStyle();
                if (formato != null) {
                    estilo.setDataFormat(sh.getWorkbook().createDataFormat()
                            .getFormat(formato));
                }
                if (alineacion != null) estilo.setAlignment(alineacion);
                estilosColumna[i] = estilo;
            }
        }

        int r = filaInicio;
        String titulo = textoNoVacio(grupoConf == null
                ? null : grupoConf.get("tituloTabla"));
        if (titulo != null) {
            Row tituloRow = sh.createRow(r++);
            Cell tituloCell = tituloRow.createCell(0);
            tituloCell.setCellValue(clean(titulo));
            tituloCell.setCellStyle(headerStyle);
        }

        Row hr = sh.createRow(r++);
        int c = 0;
        for (String h : headers) {
            Cell cell = hr.createCell(c++);
            cell.setCellValue(clean(h));
            cell.setCellStyle(headerStyle);
        }

        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Row rr = sh.createRow(r++);
            c = 0;
            for (int i = 0; i < campos.size(); i++) {
                String campo = campos.get(i);
                Integer tipo = (i < tipos.size() ? tipos.get(i) : null);
                Object val = row.get(campo);
                Cell cell = rr.createCell(c++);
                String formatoDesc = formatos.get(i);
                CellStyle estiloColumna = estilosColumna[i];
                boolean isFecha = tipo != null && tipo == 3;
                boolean isMoneda = (tipo != null && tipo == 4);
                boolean fechaPorFormato = formatoDesc != null
                        && formatoDesc.toLowerCase(Locale.ROOT)
                                .startsWith("fecha:");
                if (isFecha || fechaPorFormato) {
                    Date fecha = val instanceof Date
                            ? (Date) val : tryParseDate(val);
                    if (fecha == null) cell.setCellValue("");
                    else {
                        cell.setCellValue(fecha);
                        cell.setCellStyle(estiloColumna == null
                                ? dateStyle : estiloColumna);
                    }
                } else if (val == null) {
                    cell.setCellValue("");
                    if (estiloColumna != null) cell.setCellStyle(estiloColumna);
                } else if (isMoneda) {
                    Double num = tryParseDouble(val);
                    if (num != null) {
                        cell.setCellValue(num);
                        cell.setCellStyle(estiloColumna == null
                                ? currencyStyle : estiloColumna);
                    } else {
                        cell.setCellValue("");
                    }
                } else if (estiloColumna != null) {
                    String formato = resolveFormatString(formatoDesc);
                    boolean texto = isTextFormat(formatoDesc);
                    Double numero = formato != null && !texto
                            ? tryParseDouble(val) : null;
                    if (val instanceof Number && !texto) {
                        cell.setCellValue(((Number) val).doubleValue());
                    } else if (numero != null) {
                        cell.setCellValue(numero);
                    } else {
                        cell.setCellValue(clean(String.valueOf(val)));
                    }
                    cell.setCellStyle(estiloColumna);
                } else if (val instanceof Number) {
                    cell.setCellValue(((Number) val).doubleValue());
                } else if (val instanceof Boolean) {
                    cell.setCellValue((Boolean) val);
                } else if (val instanceof Date) {
                    cell.setCellValue((Date) val);
                } else {
                    cell.setCellValue(clean(String.valueOf(val)));
                }
            }
        }

        if (allowAutoSize) {
            int maxCols = Math.min(headers.size(), 50);
            for (int i = 0; i < maxCols; i++) {
                int ancho = anchos.get(i) == null ? 0 : anchos.get(i);
                if (ancho > 0) {
                    try {
                        int configurado = Math.min(ancho, 255) * 256;
                        sh.setColumnWidth(i,
                                Math.max(sh.getColumnWidth(i), configurado));
                    } catch (Throwable ignore) {}
                    continue;
                }
                try {
                    int anchoAnterior = sh.getColumnWidth(i);
                    sh.autoSizeColumn(i);
                    if (sh.getColumnWidth(i) < anchoAnterior) {
                        sh.setColumnWidth(i, anchoAnterior);
                    }
                } catch (IllegalStateException ise) {
                    // En SXSSF requiere trackAllColumnsForAutoSizing; si falla, ignorar
                } catch (Throwable ignore) {}
            }
        }
        return r + 2;
    }

    private static CellStyle crearHeaderStyle(Workbook wb, Object colorFondoObj, Object colorLetraObj) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        String fondo = colorFondoObj == null ? null : String.valueOf(colorFondoObj);
        String letra = colorLetraObj == null ? null : String.valueOf(colorLetraObj);
        Short fondoIdx = colorFromName(fondo);
        Short letraIdx = colorFromName(letra);
        if (fondoIdx != null) {
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            style.setFillForegroundColor(fondoIdx);
            style.setAlignment(HorizontalAlignment.CENTER);
        } else if (isHexColor(fondo) && style instanceof XSSFCellStyle) {
            try {
                java.awt.Color awt = parseHexColor(fondo);
                ((XSSFCellStyle) style).setFillForegroundColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                style.setAlignment(HorizontalAlignment.CENTER);
            } catch (Exception ignore) {}
        }
        if (letraIdx != null) {
            font.setColor(letraIdx);
        } else if (fondoIdx != null && (fondoIdx.equals(IndexedColors.BLUE.getIndex()))) {
            font.setColor(IndexedColors.WHITE.getIndex());
        } else if (isHexColor(letra) && font instanceof XSSFFont) {
            try {
                java.awt.Color awt = parseHexColor(letra);
                ((XSSFFont) font).setColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
            } catch (Exception ignore) {}
        }
        style.setFont(font);
        return style;
    }

    private static boolean grupoActivo(Map<String, Object> grupoConf) {
        return grupoConf == null || esVisible(grupoConf.get("activo"));
    }

    private static boolean esColumnaAuxiliar(String campo) {
        return campo != null && (COL_PESTANA.equalsIgnoreCase(campo)
                || COL_GRUPO.equalsIgnoreCase(campo));
    }

    private static String valorTexto(Object valor, String fallback) {
        if (valor == null) return fallback;
        String texto = String.valueOf(valor).trim();
        return texto.isEmpty() ? fallback : texto;
    }

    private static String textoNoVacio(Object valor) {
        if (valor == null) return null;
        String texto = String.valueOf(valor).trim();
        return texto.isEmpty() ? null : texto;
    }

    private static boolean parseBool(Object valor) {
        if (valor == null) return false;
        if (valor instanceof Boolean) return (Boolean) valor;
        if (valor instanceof Number) return ((Number) valor).intValue() != 0;
        String texto = String.valueOf(valor).trim();
        return "1".equals(texto) || "true".equalsIgnoreCase(texto)
                || "si".equalsIgnoreCase(texto)
                || "sí".equalsIgnoreCase(texto);
    }

    private static boolean esVisible(Object valor) {
        if (valor == null) return true;
        if (valor instanceof Boolean) return (Boolean) valor;
        if (valor instanceof Number) return ((Number) valor).intValue() != 0;
        String texto = String.valueOf(valor).trim();
        return !("0".equals(texto) || "false".equalsIgnoreCase(texto)
                || "no".equalsIgnoreCase(texto));
    }

    private static int safeInt(Object valor, int fallback) {
        try {
            return valor == null ? fallback
                    : Integer.parseInt(String.valueOf(valor));
        } catch (Exception e) {
            return fallback;
        }
    }

    private static String resolveFormatString(String descripcion) {
        if (descripcion == null) return null;
        String valor = descripcion.trim();
        if (valor.isEmpty()) return null;
        String normalizado = valor.toLowerCase(Locale.ROOT);
        if (normalizado.equals("texto") || normalizado.equals("text")
                || normalizado.equals("@")) return "@";
        if (normalizado.equals("entero")
                || normalizado.equals("integer")) return "0";
        if (normalizado.equals("numero") || normalizado.equals("number")
                || normalizado.equals("decimal")) return "#,##0.00";
        if (normalizado.equals("moneda")
                || normalizado.equals("currency")) return "\"$\"#,##0.00";
        if (normalizado.equals("porcentaje")
                || normalizado.equals("percent")) return "0.00%";
        if (normalizado.startsWith("fecha:")) {
            String patron = valor.substring(6).trim();
            return patron.isEmpty() ? "dd/MM/yyyy" : patron;
        }
        if (normalizado.startsWith("custom:")) {
            String patron = valor.substring(7).trim();
            return patron.isEmpty() ? null : patron;
        }
        return null;
    }

    private static HorizontalAlignment resolveAlign(String descripcion) {
        if (descripcion == null) return null;
        String valor = descripcion.trim().toLowerCase(Locale.ROOT);
        if (valor.equals("izquierda") || valor.equals("left")) {
            return HorizontalAlignment.LEFT;
        }
        if (valor.equals("centro") || valor.equals("center")) {
            return HorizontalAlignment.CENTER;
        }
        if (valor.equals("derecha") || valor.equals("right")) {
            return HorizontalAlignment.RIGHT;
        }
        return null;
    }

    private static boolean isTextFormat(String descripcion) {
        if (descripcion == null) return false;
        String valor = descripcion.trim().toLowerCase(Locale.ROOT);
        return valor.equals("texto") || valor.equals("text")
                || valor.equals("@") || valor.equals("custom:@");
    }

    private static Date tryParseDate(Object valor) {
        if (valor == null) return null;
        if (valor instanceof Date) return (Date) valor;
        String texto = String.valueOf(valor).trim();
        if (texto.isEmpty()) return null;
        for (String patron : new String[]{
                "yyyy-MM-dd HH:mm:ss.SSS", "yyyy-MM-dd HH:mm:ss",
                "yyyy-MM-dd", "dd/MM/yyyy", "MM/dd/yyyy"}) {
            try {
                return new SimpleDateFormat(patron, Locale.ROOT).parse(texto);
            } catch (ParseException ignore) {}
        }
        return null;
    }

    private static final class DatosHoja {
        private final LinkedHashMap<String, SeccionGrupo> secciones =
                new LinkedHashMap<>();
    }

    private static final class SeccionGrupo {
        private final String grupo;
        private final List<LinkedCaseInsensitiveMap<?>> filas =
                new ArrayList<>();

        private SeccionGrupo(String grupo) {
            this.grupo = grupo == null ? "" : grupo;
        }
    }

    private static Short colorFromName(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        if (n.equalsIgnoreCase("Blue") || n.equalsIgnoreCase("Azul")) return IndexedColors.BLUE.getIndex();
        if (n.equalsIgnoreCase("LightBlue") || n.equalsIgnoreCase("Light_Blue") || n.equalsIgnoreCase("Celeste")) return IndexedColors.LIGHT_BLUE.getIndex();
        if (n.equalsIgnoreCase("White") || n.equalsIgnoreCase("Blanco")) return IndexedColors.WHITE.getIndex();
        if (n.equalsIgnoreCase("Black") || n.equalsIgnoreCase("Negro")) return IndexedColors.BLACK.getIndex();
        if (n.equalsIgnoreCase("Red") || n.equalsIgnoreCase("Rojo")) return IndexedColors.RED.getIndex();
        if (n.equalsIgnoreCase("Green") || n.equalsIgnoreCase("Verde")) return IndexedColors.GREEN.getIndex();
        if (n.equalsIgnoreCase("Gray") || n.equalsIgnoreCase("Grey") || n.equalsIgnoreCase("Gris")) return IndexedColors.GREY_50_PERCENT.getIndex();
        return null;
    }

    private static boolean isHexColor(String s) {
        if (s == null) return false;
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v.matches("(?i)^[0-9a-f]{6}$");
    }

    private static java.awt.Color parseHexColor(String s) {
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        int r = Integer.parseInt(v.substring(0, 2), 16);
        int g = Integer.parseInt(v.substring(2, 4), 16);
        int b = Integer.parseInt(v.substring(4, 6), 16);
        return new java.awt.Color(r, g, b);
    }

    private static String guardarWorkbook(Workbook wb, String outputDir, String fileName) throws Exception {
        File dir = new File(outputDir);
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(out)) {
            System.out.println("Escribiendo archivo...");
            wb.write(fos);
        }
        wb.close();
        String outPut = out.getAbsolutePath();
        System.out.println("Archivo generado: " + outPut);
        return outPut;
    }

    private static String nombreArchivo(String prefijo, Map<String, Object> parametros) {
        return NombreArchivoUtil.generarNombre(
                parametros,
                prefijo,
                "yyyyMMddHHmmss",
                true,
                true,
                true,
                true
        );
    }

    private static String sanitizarNombreHoja(String name) {
        if (name == null) return "Hoja";
        String n = name.replaceAll("[\\\\/*?:\\[\\]]", " ").trim();
        return n.isEmpty() ? "Hoja" : n;
    }

    /** Garantiza un nombre de hoja unico y dentro del limite de 31 caracteres de Excel. */
    private static String nombreHojaUnico(String base, java.util.Set<String> usados) {
        String candidate = limit(base, 31);
        int n = 1;
        while (usados.contains(candidate.toLowerCase(Locale.ROOT))) {
            String suf = "_" + (++n);
            candidate = limit(base, 31 - suf.length()) + suf;
        }
        usados.add(candidate.toLowerCase(Locale.ROOT));
        return candidate;
    }

    private static String limit(String s, int max) {
        if (max < 0) max = 0;
        return s.length() <= max ? s : s.substring(0, max);
    }

    private static String normalizeKey(String key) {
        if (key == null) return "";
        return key.replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.ROOT);
    }

    private static Double tryParseDouble(Object v) {
        if (v == null) return null;
        if (v instanceof Number) return ((Number) v).doubleValue();
        String s = String.valueOf(v).trim().replace(",", "");
        try { return Double.parseDouble(s); } catch (Exception ignore) { return null; }
    }

    private static String quitarAcentos(String s) {
        if (s == null) return null;
        String decomposed = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

    private static String sanitizarNombreCarpeta(String s) {
        if (s == null) return null;
        String sinAcentos = quitarAcentos(s);
        String cleaned = sinAcentos.replaceAll("[\\\\/:*?\"<>|]", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        String upper = cleaned.equalsIgnoreCase("CON") || cleaned.equalsIgnoreCase("PRN") ||
                       cleaned.equalsIgnoreCase("AUX") || cleaned.equalsIgnoreCase("NUL") ? "Reporte" : cleaned;
        return upper.isEmpty() ? "Reporte" : upper;
    }

    private static String nombreReportePorId(Map<String, Object> parametros) {
        if (parametros == null) return "Reporte";
        Integer rid = null;
        try { Object o = parametros.get("reporteId"); if (o != null) rid = Integer.parseInt(String.valueOf(o)); } catch (Exception ignore) {}
        if (rid == null) return "Reporte";
        switch (rid) {
            case 2: return "Poblacion";
            case 3: return "Sabana";
            default: return "Reporte";
        }
    }

    // Limpia caracteres no permitidos por XML 1.0 que pueden corromper el XLSX
    private static String clean(String s) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == 0x9 || ch == 0xA || ch == 0xD ||
                (ch >= 0x20 && ch <= 0xD7FF) ||
                (ch >= 0xE000 && ch <= 0xFFFD)) {
                sb.append(ch);
            }
        }
        String out = sb.toString();
        return out.length() > 32766 ? out.substring(0, 32766) : out;
    }
}
