package com.lockton.rpt.models.dto.crea17;

import java.util.ArrayList;
import java.util.List;

public class IndicadorReplicarRequestDTO {
    private List<Integer> idsIndicadorGlobal = new ArrayList<Integer>();
    private Integer idUsuario;

    public List<Integer> getIdsIndicadorGlobal() { return idsIndicadorGlobal; }
    public void setIdsIndicadorGlobal(List<Integer> idsIndicadorGlobal) {
        this.idsIndicadorGlobal = idsIndicadorGlobal == null
                ? new ArrayList<Integer>()
                : idsIndicadorGlobal;
    }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
