package com.lockton.rpt.services.impl;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.Claim;
import com.google.gson.Gson;
import com.lockton.rpt.models.entities.UsuarioToken;
import com.lockton.rpt.repositories.CfgRptGenRepository;
import com.lockton.rpt.services.CryptoBeflexService;
import com.lockton.rpt.services.JwtService;
import org.springframework.stereotype.Service;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtServiceImpl implements JwtService{
private static final Log bitacora = LogFactory.getLog(JwtService.class);
    private final String PUBLIC_KEY_PATH = "C:\\beflex3\\beflex3restfullservices\\server\\public.key";
    private final String PRIVATE_KEY_PATH = "C:\\beflex3\\beflex3restfullservices\\server\\private.key";

    @Autowired
    private CryptoBeflexService crypto;
    @Autowired
    CfgRptGenRepository cfgRptGenRepository;

    @Override
    public Object validarToken(String token) {
        Map<String, Claim> payload = null;
        String dateLast = "";
        try{
            File publicFile = new File(PUBLIC_KEY_PATH);
            if(token.contains("Bearer")){
                token = token.replace("Bearer ","");
            }
            /// Lectura de llave publica
            RSAPublicKey publicKey = readPublicKey(publicFile);
            /// Creacion de verificador
            JWTVerifier jwtVerifier = JWT.require(Algorithm.RSA256(publicKey)).build();
            /// Validacion del token
            Date lastDate = jwtVerifier.verify(token).getExpiresAt();
            payload = jwtVerifier.verify(token).getClaims();
            dateLast = "Token expires at: " + lastDate;
            bitacora.info(dateLast);
        }catch (TokenExpiredException e){
            bitacora.error("Error al validar token: \n" + e);
            return "Unauthorized";
        }catch (Exception e){
            bitacora.info("Error de validacion de token");
            bitacora.info(e.getMessage());
            return "error";
        }
        return payload;
    }

    @Override
    public UsuarioToken getPayloadFromToken(String token) {
        try {

            if(token.contains("Bearer")){
                token = token.replace("Bearer ","");
            }

            String[] pieces = token.split("\\.");
            String b64payload = pieces[1];
            String jsonString = new String(Base64.decodeBase64(b64payload), "UTF-8");

             Gson gson = new Gson();

            // Convertir el JSON string en un objeto
            UsuarioToken usuarioToken = gson.fromJson(jsonString, UsuarioToken.class);
            return usuarioToken;
        } catch (Exception e) {
            // Manejo de excepciones si ocurre algún error durante la decodificación
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String generarTokenUsuario(Map<String, Object> params, String tipo) {
        PrivateKey privateKey = null;
        String jwt = "";
        try{
            //todo
            byte[] keyDataBytes = Files.readAllBytes(Paths.get(PRIVATE_KEY_PATH));
            String keyDataString = new String(keyDataBytes, StandardCharsets.UTF_8);
            keyDataString = keyDataString.replace("-----BEGIN RSA PRIVATE KEY-----", "");
            keyDataString = keyDataString.replace("-----END RSA PRIVATE KEY-----", "");
            privateKey = readPkcs1PrivateKey(Base64.decodeBase64(keyDataString));

            /// Preparar el payload del jwt
            Map<String, Object> claims = new HashMap<String, Object>();
            if (tipo == "empresa"){
                claims.put("nicEmpresa", params.get("nicEmpresa"));
            }else{
                claims.put("n", params.get("n"));
                claims.put("claveEmpleado", params.get("claveEmpleado"));
                claims.put("idEmpresa",params.get("idEmpresa"));
            }
            jwt = Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.RS256, privateKey)
                    .setExpiration(new Date(System.currentTimeMillis() + (60000 * 60 * 6)))
                    .compact();
        }catch (Exception e){
            bitacora.error("Error: " + e.getStackTrace());
        }
        return jwt;
    }

    public String getEncriptPassword(String pass) {
        try {
            byte[] asBytes = java.util.Base64.getDecoder().decode(pass);
            String decodePass = new String(asBytes, StandardCharsets.UTF_8);
    
            String encrypted = crypto.encriptar(decodePass); // llamada directa
    
            Map<String, Object> response = new HashMap<>();
            response.put("exito", true);
            response.put("mensaje", "Se cifro correctamente la cadena");
            response.put("data", encrypted);
            String logMessage = "\n\n\n================== RESPONSE ==================\n" +
                                   response.toString() +
                                "\n=============================================\n\n\n";

            System.out.println(logMessage);
            bitacora.error(logMessage);

    
            return response.get("data").toString();
        } catch (Exception e) {
            String errorMessage = "\n\n\n********** ERROR **********\n" +
            "Causa: " + (e.getCause() != null ? e.getCause().toString() : "Sin causa") + "\n" +
            "Mensaje: " + e.getMessage() +
            "\n***************************\n\n\n";

            System.out.println(errorMessage);
            bitacora.error(errorMessage);

            return null;
        }
    }    

    /// Metodos de lectura y asignacion de claves

    /// Lectura y configuracion de clave publica
    public static RSAPublicKey readPublicKey(File file) throws Exception {
        String key = new String(Files.readAllBytes(file.toPath()), Charset.defaultCharset());

        String publicKeyPEM = key
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PUBLIC KEY-----", "");

        byte[] encoded = Base64.decodeBase64(publicKeyPEM);

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
        return (RSAPublicKey) keyFactory.generatePublic(keySpec);
    }

    /// Lectura de llave privada
    private static PrivateKey readPkcs1PrivateKey(byte[] pkcs1Bytes) throws GeneralSecurityException {
        // Parse ASN.1 structures, to build a PKCS#8 key Java can understand
        int pkcs1Length = pkcs1Bytes.length;
        int totalLength = pkcs1Length + 22;
        byte[] pkcs8Header = new byte[] {
                0x30, (byte) 0x82, (byte) ((totalLength >> 8) & 0xff), (byte) (totalLength & 0xff), 
                0x2, 0x1, 0x0, 
                0x30, 0xD, 0x6, 0x9, 0x2A, (byte) 0x86, 0x48, (byte) 0x86, (byte) 0xF7, 0xD, 0x1, 0x1, 0x1, 0x5, 0x0, 
                0x4, (byte) 0x82, (byte) ((pkcs1Length >> 8) & 0xff), (byte) (pkcs1Length & 0xff) 
        };
        byte[] pkcs8bytes = join(pkcs8Header, pkcs1Bytes);
        return readPkcs8PrivateKey(pkcs8bytes);
    }
    private static PrivateKey readPkcs8PrivateKey(byte[] pkcs8Bytes) throws GeneralSecurityException {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA", "SunRsaSign");
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pkcs8Bytes);
        try {
            return keyFactory.generatePrivate(keySpec);
        } catch (InvalidKeySpecException e) {
            throw new IllegalArgumentException("Formato de llave invalido", e);
        }
    }
    private static byte[] join(byte[] byteArray1, byte[] byteArray2){
        byte[] bytes = new byte[byteArray1.length + byteArray2.length];
        System.arraycopy(byteArray1, 0, bytes, 0, byteArray1.length);
        System.arraycopy(byteArray2, 0, bytes, byteArray1.length, byteArray2.length);
        return bytes;
    }
}
