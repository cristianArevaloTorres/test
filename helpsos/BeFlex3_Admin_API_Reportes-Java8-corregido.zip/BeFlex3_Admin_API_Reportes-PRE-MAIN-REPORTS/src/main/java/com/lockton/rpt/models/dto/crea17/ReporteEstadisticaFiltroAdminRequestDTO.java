package com.lockton.rpt.models.dto.crea17;

public class ReporteEstadisticaFiltroAdminRequestDTO {
    private String clave;
    private String nombre;
    private String descripcion;
    private Integer orden;
    private Boolean esFiltroBase;
    private String observaciones;
    private Integer idCampoValor;
    private Integer idCampoTexto;
    private String tipoControl;
    private Boolean mostrarEnModulo;
    private Integer idUsuario;

    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public Integer getOrden() { return orden; }
    public void setOrden(Integer orden) { this.orden = orden; }

    public Boolean getEsFiltroBase() { return esFiltroBase; }
    public void setEsFiltroBase(Boolean esFiltroBase) { this.esFiltroBase = esFiltroBase; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }

    public Integer getIdCampoValor() { return idCampoValor; }
    public void setIdCampoValor(Integer idCampoValor) { this.idCampoValor = idCampoValor; }

    public Integer getIdCampoTexto() { return idCampoTexto; }
    public void setIdCampoTexto(Integer idCampoTexto) { this.idCampoTexto = idCampoTexto; }

    public String getTipoControl() { return tipoControl; }
    public void setTipoControl(String tipoControl) { this.tipoControl = tipoControl; }

    public Boolean getMostrarEnModulo() { return mostrarEnModulo; }
    public void setMostrarEnModulo(Boolean mostrarEnModulo) { this.mostrarEnModulo = mostrarEnModulo; }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
