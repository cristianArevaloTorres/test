package com.lockton.rpt.util;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xddf.usermodel.XDDFColor;
import org.apache.poi.xddf.usermodel.XDDFLineProperties;
import org.apache.poi.xddf.usermodel.XDDFShapeProperties;
import org.apache.poi.xddf.usermodel.XDDFSolidFillProperties;
import org.apache.poi.xddf.usermodel.chart.AxisCrossBetween;
import org.apache.poi.xddf.usermodel.chart.AxisCrosses;
import org.apache.poi.xddf.usermodel.chart.AxisPosition;
import org.apache.poi.xddf.usermodel.chart.BarDirection;
import org.apache.poi.xddf.usermodel.chart.BarGrouping;
import org.apache.poi.xddf.usermodel.chart.ChartTypes;
import org.apache.poi.xddf.usermodel.chart.LegendPosition;
import org.apache.poi.xddf.usermodel.chart.XDDFBarChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFCategoryAxis;
import org.apache.poi.xddf.usermodel.chart.XDDFChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFChartLegend;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSourcesFactory;
import org.apache.poi.xddf.usermodel.chart.XDDFNumericalDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFLineChartData;
import org.apache.poi.xddf.usermodel.chart.MarkerStyle;
import org.apache.poi.xddf.usermodel.chart.XDDFValueAxis;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.springframework.util.LinkedCaseInsensitiveMap;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFSheetConditionalFormatting;
import org.apache.poi.xssf.usermodel.XSSFConditionalFormattingRule;
import org.apache.poi.ss.usermodel.DataBarFormatting;
import org.apache.poi.ss.usermodel.ConditionalFormattingThreshold.RangeType;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbls;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTTitle;
import org.openxmlformats.schemas.drawingml.x2006.chart.STDLblPos;
import org.openxmlformats.schemas.drawingml.x2006.main.CTRegularTextRun;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextBody;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextCharacterProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextParagraph;

/**
 * Renderizador para reporte BeMobile:
 * - Hoja "Resumen" (por ahora vacía; se llenará después).
 * - Hoja "Detalle": usa el ÚLTIMO resultset devuelto por el SP ff_BeMobile_BF3.
 *
 * Firma estándar requerida por Generadorreportes:
 *
 *   public static void generar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
 *                              Map<String, Object> parametros,
 *                              String outputDir)
 */
public class Excel_Tablas_Graficos {

    private static final Log LOGGER = LogFactory.getLog(Excel_Tablas_Graficos.class);

    private static final byte[] ACCENT_BG_RGB = new byte[] { (byte) 31, (byte) 40, (byte) 52 };
    private static final byte[] ACCENT_FONT_RGB = new byte[] { (byte) 255, (byte) 255, (byte) 255 };

    public static String generar(List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
                               Map<String, Object> parametros,
                               String outputDir) throws Exception {
        // XSSFWorkbook para soportar gráficos.
        XSSFWorkbook wb = new XSSFWorkbook();
        // Inicialización de fuente.
        // Hoja 1: Resumen
        XSSFSheet resumen = wb.createSheet("Resumen");
        escribirResumen(resumen, resultsets, parametros);
        resumen.setDisplayGridlines(false);

        // Hoja 2: Detalle (Último ResultSet de ff_BeMobile_BF3)
        XSSFSheet detalle = wb.createSheet("Detalle");
        ArrayList<LinkedCaseInsensitiveMap<?>> detalleRows = null;
        int detalleIndex = 0;
        if (resultsets != null && !resultsets.isEmpty()) {
            detalleIndex = resultsets.size() - 1;
            detalleRows = resultsets.get(detalleIndex);
        }

        escribirDetalle(detalle, detalleRows, parametros, detalleIndex);
        detalle.setDisplayGridlines(false);
        // Resolución de ruta similar a Excel_Filtros / Excel_Hoja_Multiple
        String rutaDir = outputDir;

        // Resolver idEmpresa efectivo: idEmpresa | admIdEmpresa | primer id de empresas/empresasIds
        Object idEmpObj = parametros.get("idEmpresa");
        if (idEmpObj == null) {
            idEmpObj = firstNonNull(parametros.get("admIdEmpresa"),
                                    parametros.get("empresas"),
                                    parametros.get("empresasIds"));
        }
        String idEmp = null;
        if (idEmpObj != null) {
            String raw = String.valueOf(idEmpObj).trim();
            raw = raw.replaceAll("[\\{\\}\\[\\]]", "");
            if (raw.contains(",")) raw = raw.split(",")[0].trim();
            String digits = raw.replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) idEmp = digits;
        }

        // Determinar subcarpeta del reporte: por nombre de catálogos o por reporteId
        String reporteNombre = String.valueOf(
                firstNonNull(parametros.get("tituloReporteB1"),
                             parametros.get("catReportesNombre"),
                             nombreReportePorId(parametros))
        );
        String subFolder = sanitizarNombreCarpeta(reporteNombre);
        if (subFolder == null || subFolder.trim().isEmpty()) subFolder = "Reporte";

        try {
            String base = Constantes.DOCUMENTO_EMPRESA;
            if (base != null && !base.trim().isEmpty())
                rutaDir = base + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
        } catch (Throwable ignore) {
            // Ignorar y seguir con fallback
        }

        // 2) Fallback: variable de entorno UPLOAD_FOLDER
        if (rutaDir == null || ".".equals(rutaDir) || outputDir.equals(rutaDir)) {
            try {
                String base = System.getenv("UPLOAD_FOLDER");
                if (base != null && !base.trim().isEmpty() && idEmp != null) {
                    rutaDir = base + File.separator + "DocumentoEmpresa" + File.separator
                            + String.valueOf(idEmp) + File.separator + subFolder + File.separator;
                }
            } catch (Throwable ignore) {
                // Si tampoco está la variable de entorno, caeremos en outputDir
            }
        }

        String fileName = NombreArchivoUtil.generarNombre(
                parametros,
                reporteNombre,
                "yyyyMMddHHmm",
                false, // sin sufijo idEmpresa/fileSuffix
                false, // sin caso especial Sábana
                false, // sin caso especial Costos
                false  // sin separador "_" (comportamiento previo base+timestamp)
        );
        try {
            System.out.println("Generando Excel_Tablas_Graficos en: " + rutaDir + " archivo: " + fileName);
            guardarWorkbook(wb, rutaDir, fileName);
            String rs = new File(rutaDir, fileName).getAbsolutePath();
            System.out.println("Archivo generado: " + rs);
            return rs;
        } catch (Exception ex) {
            System.out.println("Error al guardar Excel_Tablas_Graficos: "
                    + (ex.getMessage() == null ? ex.getClass().getName() : ex.getMessage()));
            ex.printStackTrace(System.out);
            throw ex;
        }
    }

    private static void escribirResumen(Sheet sh, List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets,
                                        Map<String, Object> parametros) {
        LOGGER.info("Ejecutando Excel_Tablas_Graficos.escribirResumen");
        if (sh == null) return;

        Workbook wb = sh.getWorkbook();
        CellStyle defaultStyle = obtenerDefaultStyle(wb);
        CellStyle defaultStyleSinBorde = obtenerDefaultStyleSinBorde(wb);
        CellStyle defaultCenter = clonarConAlineacion(defaultStyle, wb, HorizontalAlignment.CENTER);
        Map<HorizontalAlignment, CellStyle> alignCache = new HashMap<>();
        CellStyle titleStyle = crearTitleStyle(wb);
        CellStyle labelStyle = crearLabelStyle(wb);
        CellStyle infoPrimaryStyle = clonarConColorFuente(defaultStyleSinBorde, wb, "#5B6770");
        // Encabezado principal.
        try {
            Font baseInfoFont = wb.getFontAt(infoPrimaryStyle.getFontIndex());
            Font infoFont = wb.createFont();
            infoFont.setFontName(baseInfoFont.getFontName());
            infoFont.setFontHeightInPoints(baseInfoFont.getFontHeightInPoints());
            infoFont.setBold(true);
            infoFont.setItalic(baseInfoFont.getItalic());
            infoFont.setUnderline(baseInfoFont.getUnderline());
            infoFont.setStrikeout(baseInfoFont.getStrikeout());
            if (baseInfoFont instanceof XSSFFont && infoFont instanceof XSSFFont) {
                XSSFColor xc = ((XSSFFont) baseInfoFont).getXSSFColor();
                if (xc != null) {
                    ((XSSFFont) infoFont).setColor(xc);
                } else {
                    infoFont.setColor(baseInfoFont.getColor());
                }
            } else {
                infoFont.setColor(baseInfoFont.getColor());
            }
            infoPrimaryStyle.setFont(infoFont);
        } catch (Exception ignore) {}
        CellStyle headerStyle = crearHeaderStyle(wb, "#737F8B", "White");
        // Estilo para porcentajes con dos decimales (ej. 45.95%)
        short pctFmt = wb.createDataFormat().getFormat("0.00%");
        CellStyle pctStyle = wb.createCellStyle();
        pctStyle.setDataFormat(pctFmt);
        pctStyle.setAlignment(HorizontalAlignment.RIGHT);
        CellStyle totalLabelStyle = wb.createCellStyle();
        totalLabelStyle.cloneStyleFrom(headerStyle);
        totalLabelStyle.setAlignment(HorizontalAlignment.CENTER);
        CellStyle totalNumberStyle = wb.createCellStyle();
        totalNumberStyle.cloneStyleFrom(headerStyle);
        totalNumberStyle.setAlignment(HorizontalAlignment.CENTER);
        totalNumberStyle.setDataFormat(wb.createDataFormat().getFormat("#,##0"));
        CellStyle pctTotalStyle = wb.createCellStyle();
        pctTotalStyle.cloneStyleFrom(headerStyle);
        pctTotalStyle.setDataFormat(pctFmt);
        pctTotalStyle.setAlignment(HorizontalAlignment.CENTER);
        CellStyle legendStyle = crearAccentStyle(wb, HorizontalAlignment.LEFT, true);

        // Mapear resultsets esperados
        ArrayList<LinkedCaseInsensitiveMap<?>> rsHeader =
                (resultsets != null && resultsets.size() > 0) ? resultsets.get(0) : null;
        ArrayList<LinkedCaseInsensitiveMap<?>> rsRazonSocial =
                (resultsets != null && resultsets.size() > 1) ? resultsets.get(1) : null;
        ArrayList<LinkedCaseInsensitiveMap<?>> rsUsoUltimaVersion =
                (resultsets != null && resultsets.size() > 2) ? resultsets.get(2) : null;
        ArrayList<LinkedCaseInsensitiveMap<?>> rsPerfil =
                (resultsets != null && resultsets.size() > 3) ? resultsets.get(3) : null;
        ArrayList<LinkedCaseInsensitiveMap<?>> rsSO =
                (resultsets != null && resultsets.size() > 4) ? resultsets.get(4) : null;
        ArrayList<LinkedCaseInsensitiveMap<?>> rsPeriodo =
                (resultsets != null && resultsets.size() > 5) ? resultsets.get(5) : null;

        int r = 0;

        // --- Encabezado principal (Tipo de reporte / Corporativo / Fecha) ---
        // El SP devuelve: SELECT @_NOMBRE_REPORTE, @varRazonSocial, @varFechaPeticion, @varSoloCorporativo
        // Extraer valores filtrando booleanos (el 4to valor es un BIT)
        Object hdrNom = null;
        Object hdrCorp = null;
        Object hdrFecha = null;
        
        if (rsHeader != null && !rsHeader.isEmpty()) {
            LinkedCaseInsensitiveMap<?> headerRow = rsHeader.get(0);
            if (headerRow != null) {
                // Intentar obtener por nombres de columna primero
                for (Object key : headerRow.keySet()) {
                    String keyStr = String.valueOf(key).toLowerCase();
                    Object val = headerRow.get(key);
                    
                    if (val != null && !(val instanceof Boolean)) {
                        if (hdrNom == null && (keyStr.contains("nombre") || keyStr.contains("reporte"))) {
                            hdrNom = val;
                        } else if (hdrCorp == null && (keyStr.contains("razon") || keyStr.contains("social") || keyStr.contains("corporativo"))) {
                            hdrCorp = val;
                        } else if (hdrFecha == null && (keyStr.contains("fecha") || keyStr.contains("peticion"))) {
                            hdrFecha = val;
                        }
                    }
                }
                
                // Si no se encontró por nombre, extraer valores en orden filtrando booleanos
                List<Object> nonBooleanValues = new ArrayList<>();
                for (Object val : headerRow.values()) {
                    if (val != null && !(val instanceof Boolean) && !String.valueOf(val).equalsIgnoreCase("null")) {
                        nonBooleanValues.add(val);
                    }
                }
                
                // Asignar en orden: primero nombre, segundo razón social, tercero fecha
                if (hdrNom == null && nonBooleanValues.size() > 0) {
                    Object v0 = nonBooleanValues.get(0);
                    // Verificar que no sea una fecha
                    if (!(v0 instanceof Date)) {
                        String v0Str = String.valueOf(v0);
                        if (!v0Str.matches(".*\\d{4}-\\d{2}-\\d{2}.*") && !v0Str.matches(".*\\d{2}/\\d{2}/\\d{4}.*")) {
                            hdrNom = v0;
                        }
                    }
                }
                if (hdrCorp == null && nonBooleanValues.size() > 1) {
                    Object v1 = nonBooleanValues.get(1);
                    if (!(v1 instanceof Date)) {
                        String v1Str = String.valueOf(v1);
                        if (!v1Str.matches(".*\\d{4}-\\d{2}-\\d{2}.*") && !v1Str.matches(".*\\d{2}/\\d{2}/\\d{4}.*")) {
                            hdrCorp = v1;
                        }
                    }
                }
                if (hdrFecha == null) {
                    // Buscar fecha en todos los valores
                    for (Object v : headerRow.values()) {
                        if (v != null && !(v instanceof Boolean)) {
                            if (v instanceof Date) {
                                hdrFecha = v;
                                break;
                            } else {
                                String vStr = String.valueOf(v);
                                if (vStr.matches(".*\\d{4}-\\d{2}-\\d{2}.*") || vStr.matches(".*\\d{2}/\\d{2}/\\d{4}.*")) {
                                    hdrFecha = v;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        String tipoReporte = String.valueOf(firstNonNull(
                hdrNom,
                parametros.get("tituloReporteB1"),
                parametros.get("catReportesNombre"),
                "Reporte de sesiones beMobile"
        ));
        String corporativo = String.valueOf(firstNonNull(
                hdrCorp,
                parametros.get("corporativoNombre"),
                ""
        ));
        String fechaStr;
        if (hdrFecha instanceof Date) {
            fechaStr = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ROOT)
                    .format((Date) hdrFecha);
        } else if (hdrFecha != null) {
            fechaStr = String.valueOf(hdrFecha);
        } else {
            fechaStr = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ROOT)
                    .format(new Date());
        }

        Row r1 = sh.createRow(r++);
        setCellText(r1, 0, "Tipo de reporte:", labelStyle);
        setCellText(r1, 1, tipoReporte, infoPrimaryStyle);

        Row r2 = sh.createRow(r++);
        setCellText(r2, 0, "Corporativo:", labelStyle);
        setCellText(r2, 1, corporativo, infoPrimaryStyle);

        Row r3 = sh.createRow(r++);
        setCellText(r3, 0, "Fecha de Actualización:", labelStyle);
        setCellText(r3, 1, fechaStr, infoPrimaryStyle);

        r += 1; // espacio

        // --- Sección: Sesiones por razón social ---
        Row titleRazon = sh.createRow(r++);
        setCellText(titleRazon, 0, "Sesiones por razón social", titleStyle);
        try {
            sh.addMergedRegion(new CellRangeAddress(titleRazon.getRowNum(), titleRazon.getRowNum(), 0, 5));
        } catch (Throwable ignore) {}
        fillRowWithStyle(titleRazon, 0, 5, titleStyle);

        Row headRazon = sh.createRow(r++);
        String[] encabezadosRazon = new String[] {
                "Razón social", "Total población", "Sesiones",
                "Sesiones únicas activas", "Sesiones únicas", "% de uso**"
        };
        for (int c = 0; c < encabezadosRazon.length; c++) {
            Cell cell = headRazon.createCell(c);
            cell.setCellValue(encabezadosRazon[c]);
            cell.setCellStyle(headerStyle);
        }

        double totalPoblacionRS = 0d;
        double totalSesionesRS = 0d;
        double totalSesionesActRS = 0d;
        double totalSesionesUnicasRS = 0d;
        int rowBeginRazon = r; // Guardar inicio de datos para data bars

        if (rsRazonSocial != null && !rsRazonSocial.isEmpty()) {
            List<String> cols = getColumnNames(rsRazonSocial);
            int idxRaz = findColIndex(cols, "RazonSocial", "Razon social");
            int idxTot = findColIndex(cols, "TotalPoblacion", "Total poblacion");
            int idxSes = findColIndex(cols, "Sesiones");
            int idxSesAct = findColIndex(cols, "SesionesUnicasActivas", "Sesiones unicas activas");
            int idxSesUni = findColIndex(cols, "SesionesUnicas", "Sesiones unicas");
            int idxPct = findColIndex(cols, "PorcentajeUso", "Porcentaje", "%Uso");

            // Aplicar anchos configurados en bf_RepConf_Columna (grupo "RazonSocial")
            Map<String, Object> grpRazon = obtenerGrupoConfigPorNombre(parametros, "RazonSocial", "Razon social", "Razon");
            Map<String, Integer> anchosRazon = extraerAnchosPorCampo(grpRazon);
            Map<String, String> alineacionesRazon = extraerAlineacionesPorCampo(grpRazon);
            aplicarAnchos(sh, anchosRazon, new String[] {
                    "RazonSocial", "TotalPoblacion", "Sesiones",
                    "SesionesUnicasActivas", "SesionesUnicas", "PorcentajeUso"
            });

            for (LinkedCaseInsensitiveMap<?> row : rsRazonSocial) {
                Object[] vals = row.values().toArray();
                Row rr = sh.createRow(r++);
                CellStyle stRaz = stylePorAlign("RazonSocial", alineacionesRazon, wb, defaultStyle, defaultCenter, alignCache);
                setCellValue(rr, 0, getAt(vals, idxRaz), defaultStyle);
                Object vTot = getAt(vals, idxTot);
                Object vSes = getAt(vals, idxSes);
                Object vSesAct = getAt(vals, idxSesAct);
                Object vSesUni = getAt(vals, idxSesUni);
                Object vPct = getAt(vals, idxPct);

                setCellValue(rr, 0, getAt(vals, idxRaz), stRaz);
                setCellValue(rr, 1, vTot, stylePorAlign("TotalPoblacion", alineacionesRazon, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 2, vSes, stylePorAlign("Sesiones", alineacionesRazon, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 3, vSesAct, stylePorAlign("SesionesUnicasActivas", alineacionesRazon, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 4, vSesUni, stylePorAlign("SesionesUnicas", alineacionesRazon, wb, defaultStyle, defaultCenter, alignCache));

                Double pctRow = tryParseDouble(vPct);
                if (pctRow == null) {
                    Double dTot = tryParseDouble(vTot);
                    Double dSesUni = tryParseDouble(vSesUni);
                    if (dTot != null && dTot != 0 && dSesUni != null) {
                        pctRow = dSesUni / dTot;
                    }
                }
                // Si viene en escala 0-100, normalizar a 0-1 para formateo %
                Double pctToWrite = pctRow;
                if (pctToWrite != null && pctToWrite > 1.0) {
                    pctToWrite = pctToWrite / 100.0;
                }
                setPercentCell(rr, 5, pctToWrite, pctStyle);

                totalPoblacionRS += safeDouble(vTot);
                totalSesionesRS += safeDouble(vSes);
                totalSesionesActRS += safeDouble(vSesAct);
                totalSesionesUnicasRS += safeDouble(vSesUni);
            }
        }
        int rowEndRazon = r - 1; // Fin de datos (antes de la fila total si existe)

        // Fila Total para razón social (simple, para mantener compatibilidad con plantilla)
        double porcentajeUsoGlobal = 0d;
        if (totalPoblacionRS > 0 && totalSesionesUnicasRS > 0) {
            porcentajeUsoGlobal = totalSesionesUnicasRS / totalPoblacionRS;
        }

        if (rsRazonSocial != null && !rsRazonSocial.isEmpty()) {
            Row totalRow = sh.createRow(r++);
            setCellText(totalRow, 0, "Total:", totalLabelStyle);
            setCellValue(totalRow, 1, totalPoblacionRS, totalNumberStyle);
            setCellValue(totalRow, 2, totalSesionesRS, totalNumberStyle);
            setCellValue(totalRow, 3, totalSesionesActRS, totalNumberStyle);
            setCellValue(totalRow, 4, totalSesionesUnicasRS, totalNumberStyle);
            setPercentCell(totalRow, 5, porcentajeUsoGlobal, pctTotalStyle);
        }

        r += 1; // espacio
        double leyendaPctUso = porcentajeUsoGlobal;
        double leyendaPctUltima = 0d;
        if (rsUsoUltimaVersion != null && !rsUsoUltimaVersion.isEmpty()) {
            LinkedCaseInsensitiveMap<?> rowUso = rsUsoUltimaVersion.get(0);
            Double uso = findDoubleByAliases(rowUso, "PorcentajeUso", "PorcentajeTotal", "PorcentajeUsuarios");
            Double ultima = findDoubleByAliases(rowUso, "PorcentajeUltimaVersion", "UltimaVersion", "PorcentajeUltima");
            if (uso != null) {
                double normUso = normalizePercentValue(uso);
                if (!Double.isNaN(normUso)) {
                    leyendaPctUso = normUso;
                }
            }
            if (ultima != null) {
                double normUlt = normalizePercentValue(ultima);
                if (!Double.isNaN(normUlt)) {
                    leyendaPctUltima = normUlt;
                }
            }
        }

        // Agregar data bars a la columna de porcentaje (columna 5)
        if (sh instanceof XSSFSheet && rowBeginRazon < rowEndRazon) {
            addDataBarsToPercentageColumn((XSSFSheet) sh, rowBeginRazon, rowEndRazon, 5);
        }

        // --- Sección: Sesiones por Perfil ---
        Row titlePerfil = sh.createRow(r++);
        setCellText(titlePerfil, 0, "Sesiones por Perfil", titleStyle);
        try {
            sh.addMergedRegion(new CellRangeAddress(titlePerfil.getRowNum(), titlePerfil.getRowNum(), 0, 5));
        } catch (Throwable ignore) {}
        fillRowWithStyle(titlePerfil, 0, 5, titleStyle);

        Row headPerfil = sh.createRow(r++);
        String[] encabezadosPerfil = new String[] {
                "Perfil", "Total población", "Sesiones",
                "Sesiones únicas activas", "Sesiones únicas", "% de uso**"
        };
        for (int c = 0; c < encabezadosPerfil.length; c++) {
            Cell cell = headPerfil.createCell(c);
            cell.setCellValue(encabezadosPerfil[c]);
            cell.setCellStyle(headerStyle);
        }

        double totalPoblacionPerfil = 0d;
        double totalSesionesPerfil = 0d;
        double totalSesionesActPerfil = 0d;
        double totalSesionesUnicasPerfil = 0d;
        int rowBeginPerfil = r; // Guardar inicio de datos para data bars

        if (rsPerfil != null && !rsPerfil.isEmpty()) {
            List<String> cols = getColumnNames(rsPerfil);
            int idxPerf = findColIndex(cols, "Perfil");
            int idxTot = findColIndex(cols, "TotalPoblacion", "Total poblacion");
            int idxSes = findColIndex(cols, "Sesiones");
            int idxSesAct = findColIndex(cols, "SesionesUnicasActivas", "Sesiones unicas activas");
            int idxSesUni = findColIndex(cols, "SesionesUnicas", "Sesiones unicas");
            int idxPct = findColIndex(cols, "PorcentajeUso", "Porcentaje", "%Uso");

            Map<String, Object> grpPerfil = obtenerGrupoConfigPorNombre(parametros, "Perfiles");
            Map<String, String> alineacionesPerfil = extraerAlineacionesPorCampo(grpPerfil);

            for (LinkedCaseInsensitiveMap<?> row : rsPerfil) {
                Object[] vals = row.values().toArray();
                Row rr = sh.createRow(r++);
                Object vPerf = getAt(vals, idxPerf);
                Object vTot = getAt(vals, idxTot);
                Object vSes = getAt(vals, idxSes);
                Object vSesAct = getAt(vals, idxSesAct);
                Object vSesUni = getAt(vals, idxSesUni);
                Object vPct = getAt(vals, idxPct);

                setCellValue(rr, 0, vPerf, stylePorAlign("Perfil", alineacionesPerfil, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 1, vTot, stylePorAlign("TotalPoblacion", alineacionesPerfil, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 2, vSes, stylePorAlign("Sesiones", alineacionesPerfil, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 3, vSesAct, stylePorAlign("SesionesUnicasActivas", alineacionesPerfil, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 4, vSesUni, stylePorAlign("SesionesUnicas", alineacionesPerfil, wb, defaultStyle, defaultCenter, alignCache));

                Double pctRow = tryParseDouble(vPct);
                if (pctRow == null) {
                    Double dTot = tryParseDouble(vTot);
                    Double dSesUni = tryParseDouble(vSesUni);
                    if (dTot != null && dTot != 0 && dSesUni != null) {
                        pctRow = dSesUni / dTot;
                    }
                }
                Double pctToWrite = pctRow;
                if (pctToWrite != null && pctToWrite > 1.0) {
                    pctToWrite = pctToWrite / 100.0;
                }
                setPercentCell(rr, 5, pctToWrite, pctStyle);

                totalPoblacionPerfil += safeDouble(vTot);
                totalSesionesPerfil += safeDouble(vSes);
                totalSesionesActPerfil += safeDouble(vSesAct);
                totalSesionesUnicasPerfil += safeDouble(vSesUni);
            }
        }
        int rowEndPerfil = r - 1; // Fin de datos

        if (rsPerfil != null && !rsPerfil.isEmpty()) {
            Row totalPerfil = sh.createRow(r++);
            setCellText(totalPerfil, 0, "Total:", totalLabelStyle);
            setCellValue(totalPerfil, 1, totalPoblacionPerfil, totalNumberStyle);
            setCellValue(totalPerfil, 2, totalSesionesPerfil, totalNumberStyle);
            setCellValue(totalPerfil, 3, totalSesionesActPerfil, totalNumberStyle);
            setCellValue(totalPerfil, 4, totalSesionesUnicasPerfil, totalNumberStyle);
            Double pctTotalPerfil = (totalPoblacionPerfil > 0 && totalSesionesUnicasPerfil > 0)
                    ? (totalSesionesUnicasPerfil / totalPoblacionPerfil)
                    : null;
            setPercentCell(totalPerfil, 5, pctTotalPerfil, pctTotalStyle);
        }

        // Agregar data bars a la columna de porcentaje (columna 5)
        if (sh instanceof XSSFSheet && rowBeginPerfil < rowEndPerfil) {
            addDataBarsToPercentageColumn((XSSFSheet) sh, rowBeginPerfil, rowEndPerfil, 5);
        }

        // Nota aclaratoria bajo la tabla de Perfil
        r++;
        Row notaPerfil = sh.createRow(r++);
        setCellText(notaPerfil, 0,
                "**El porcentaje de uso representa el total de titulares que han iniciado sesión al menos 1 vez en algún dispositivo.",
                legendStyle);
        fillRowWithStyle(notaPerfil, 0, 5, legendStyle);
        sh.addMergedRegion(new CellRangeAddress(notaPerfil.getRowNum(), notaPerfil.getRowNum(), 0, 5));
        r += 2;

        // --- Sección: Sesiones por Uso Sistema Operativo (SO) ---
        Row titleSO = sh.createRow(r++);
        setCellText(titleSO, 0, "Sesiones por Uso Sistema Operativo (SO)", titleStyle);
        try {
            sh.addMergedRegion(new CellRangeAddress(titleSO.getRowNum(), titleSO.getRowNum(), 0, 3));
        } catch (Throwable ignore) {}
        fillRowWithStyle(titleSO, 0, 3, titleStyle);

        Row headSO = sh.createRow(r++);
        String[] encabezadosSO = new String[] { "Razón social", "iOS", "ANDROID", "HARMONYOS" };
        for (int c = 0; c < encabezadosSO.length; c++) {
            Cell cell = headSO.createCell(c);
            cell.setCellValue(encabezadosSO[c]);
            cell.setCellStyle(headerStyle);
        }

        double sumIos = 0, sumAnd = 0, sumHar = 0;
        if (rsSO != null && !rsSO.isEmpty()) {
            List<String> cols = getColumnNames(rsSO);
            int idxRaz = findColIndex(cols, "RazonSocial", "Razon social");
            int idxIos = findColIndex(cols, "IOS");
            int idxAnd = findColIndex(cols, "ANDROID");
            int idxHar = findColIndex(cols, "HARMONYOS");

            Map<String, Object> grpSO = obtenerGrupoConfigPorNombre(parametros, "Uso_SO");
            Map<String, String> alineacionesSO = extraerAlineacionesPorCampo(grpSO);

            for (LinkedCaseInsensitiveMap<?> row : rsSO) {
                Object[] vals = row.values().toArray();
                Row rr = sh.createRow(r++);
                Object vRaz = getAt(vals, idxRaz);
                Object vIos = getAt(vals, idxIos);
                Object vAnd = getAt(vals, idxAnd);
                Object vHar = getAt(vals, idxHar);
                setCellValue(rr, 0, vRaz, stylePorAlign("RazonSocial", alineacionesSO, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 1, vIos, stylePorAlign("IOS", alineacionesSO, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 2, vAnd, stylePorAlign("ANDROID", alineacionesSO, wb, defaultStyle, defaultCenter, alignCache));
                setCellValue(rr, 3, vHar, stylePorAlign("HARMONYOS", alineacionesSO, wb, defaultStyle, defaultCenter, alignCache));
                sumIos += safeDouble(vIos);
                sumAnd += safeDouble(vAnd);
                sumHar += safeDouble(vHar);
            }

            // Fila de totales
            Row totalSO = sh.createRow(r++);
            setCellText(totalSO, 0, "Total:", totalLabelStyle);
            setCellValue(totalSO, 1, sumIos, totalNumberStyle);
            setCellValue(totalSO, 2, sumAnd, totalNumberStyle);
            setCellValue(totalSO, 3, sumHar, totalNumberStyle);

            String soDominante = "DESCONOCIDO";
            double maxValor = sumIos;
            soDominante = "iOS";
            if (sumAnd > maxValor) { maxValor = sumAnd; soDominante = "ANDROID"; }
            if (sumHar > maxValor) { maxValor = sumHar; soDominante = "HARMONYOS"; }

            // Crear gráfica de uso por SO a partir de los totales
            // Calcular startRow: inicio de la tabla SO (titleSO) para alinear la gráfica con la tabla
            try {
                if (sh instanceof XSSFSheet) {
                    int soChartStartRow = titleSO.getRowNum();
                    createChartUsoSO((XSSFSheet) sh, soChartStartRow, 4, sumIos, sumAnd, sumHar);
                }
            } catch (Exception ignore) {}

            // Nota bajo la tabla SO (texto genérico; el mensaje exacto puede ajustarse)
            r++;
            Row notaSO = sh.createRow(r++);
            setCellText(notaSO, 0,
                    "El porcentaje de uso presentado en el gráfico indica que la aplicación se utiliza con mayor frecuencia en dispositivos con SO: "
                            + soDominante,
                    legendStyle);
            fillRowWithStyle(notaSO, 0, 4, legendStyle);
            sh.addMergedRegion(new CellRangeAddress(notaSO.getRowNum(), notaSO.getRowNum() + 1, 0, 4));
            r += 2;
        } else {
            r += 1;
        }

        // --- Sección: Usuarios nuevos por periodo ---
        Row titlePer = sh.createRow(r++);
        setCellText(titlePer, 0, "Usuarios nuevos por periodo", titleStyle);
        try {
            sh.addMergedRegion(new CellRangeAddress(titlePer.getRowNum(), titlePer.getRowNum(), 0, 8));
        } catch (Throwable ignore) {}
        fillRowWithStyle(titlePer, 0, 7, titleStyle);

        int idxGrupo = -1;
        int idxMes = -1;
        List<Integer> idxAnios = new ArrayList<>();

        if (rsPeriodo != null && !rsPeriodo.isEmpty()) {
            LinkedCaseInsensitiveMap<?> first = rsPeriodo.get(0);
            List<String> cols = new ArrayList<>();
            for (Object k : first.keySet()) cols.add(String.valueOf(k));

            idxGrupo = indexWhere(cols, c -> normalizeKey(c).startsWith("grupo"));
            idxMes = indexWhere(cols, c -> normalizeKey(c).startsWith("mes"));
            idxAnios = new ArrayList<>();
            for (int i = 0; i < cols.size(); i++) {
                String nk = normalizeKey(cols.get(i));
                if (nk.matches(".*(2020|2021|2022|2023|2024|2025|2026).*")) {
                    idxAnios.add(i);
                }
            }

            // Encabezados
            Row headPer = sh.createRow(r++);
            int c = 0;
            if (idxGrupo >= 0) {
                Cell cg = headPer.createCell(c++);
                cg.setCellValue("Grupo");
                cg.setCellStyle(headerStyle);
            }
            if (idxMes >= 0) {
                Cell cm = headPer.createCell(c++);
                cm.setCellValue("Mes");
                cm.setCellStyle(headerStyle);
            }
            for (int idx : idxAnios) {
                String nombreCol = cols.get(idx);
                String anio = extraerAnioDesdeNombre(nombreCol);
                Cell ca = headPer.createCell(c++);
                ca.setCellValue(anio == null ? nombreCol : ("Año " + anio));
                ca.setCellStyle(headerStyle);
            }

            double[] sumAnios = new double[idxAnios.size()];

            // Obtener configuración de alineación para Periodo
            Map<String, Object> grpPeriodo = obtenerGrupoConfigPorNombre(parametros, "Periodo", "UsuariosNuevos", "Usuarios nuevos");
            Map<String, String> alineacionesPeriodo = extraerAlineacionesPorCampo(grpPeriodo);

            int dataStartRow = r; // primera fila de datos después del header
            int monthsCount = 0;

            for (LinkedCaseInsensitiveMap<?> row : rsPeriodo) {
                Object[] vals = row.values().toArray();
                Row rr = sh.createRow(r++);
                int cc = 0;
                if (idxGrupo >= 0) {
                    String campoGrupo = cols.get(idxGrupo);
                    setCellValue(rr, cc++, getAt(vals, idxGrupo), 
                            stylePorAlign(campoGrupo, alineacionesPeriodo, wb, defaultStyle, defaultCenter, alignCache));
                }
                if (idxMes >= 0) {
                    String campoMes = cols.get(idxMes);
                    setCellValue(rr, cc++, getAt(vals, idxMes), 
                            stylePorAlign(campoMes, alineacionesPeriodo, wb, defaultStyle, defaultCenter, alignCache));
                }
                for (int i = 0; i < idxAnios.size(); i++) {
                    Object v = getAt(vals, idxAnios.get(i));
                    String campoAnio = cols.get(idxAnios.get(i));
                    setCellValue(rr, cc++, v, 
                            stylePorAlign(campoAnio, alineacionesPeriodo, wb, defaultStyle, defaultCenter, alignCache));
                    sumAnios[i] += safeDouble(v);
                }
                monthsCount++;
            }
            int dataEndRow = r - 1;

            if (dataEndRow > dataStartRow) {
                try {
                    sh.addMergedRegion(new CellRangeAddress(
                            dataStartRow,  // fila inicio
                            dataEndRow,    // fila fin
                            0,             // columna inicio (A)
                            0              // columna fin (A)
                    ));
                } catch (Exception e) {
                    // opcional: log
                }
            }

            Row rowMerged = sh.getRow(dataStartRow);
                if (rowMerged != null) {
                    Cell cellMerged = rowMerged.getCell(0);
                    if (cellMerged != null) {
                        CellStyle st = wb.createCellStyle();
                        st.cloneStyleFrom(cellMerged.getCellStyle());
                        st.setVerticalAlignment(VerticalAlignment.CENTER);
                        cellMerged.setCellStyle(st);
                    }
                }

            // Fila Total
            Row totalPer = sh.createRow(r++);
            int cc = 0;
            if (idxGrupo >= 0) {
                setCellText(totalPer, cc++, "Total:", totalLabelStyle);
            } else if (idxMes >= 0) {
                setCellText(totalPer, cc++, "Total:", totalLabelStyle);
            }
            if (idxMes >= 0 && idxGrupo >= 0) {
                setCellText(totalPer, cc++, "", totalLabelStyle);
            }
            for (double sVal : sumAnios) {
                setCellValue(totalPer, cc++, sVal, totalNumberStyle);
            }

            // Crear gráfica de usuarios nuevos por periodo usando el rango de la tabla
            try {
                if (sh instanceof XSSFSheet && monthsCount > 0 && !idxAnios.isEmpty()) {
                    int colMes = (idxGrupo >= 0) ? 1 : 0;
                    int firstYearCol = colMes + 1;
                    List<String> yearLabels = new ArrayList<>();
                    for (int idx : idxAnios) {
                        String nombreCol = cols.get(idx);
                        String anio = extraerAnioDesdeNombre(nombreCol);
                        yearLabels.add(anio == null ? nombreCol : ("Año " + anio));
                    }
                    int periodoChartStartRow = titlePer.getRowNum();
                    if (rsSO != null && !rsSO.isEmpty() && titleSO != null) {
                        int soChartEnd = titleSO.getRowNum() + 8;
                        if (periodoChartStartRow < soChartEnd) {
                            periodoChartStartRow = soChartEnd + 1;
                        }
                    }
                    createLineChartUsuariosNuevos(
                            (XSSFSheet) sh,
                            periodoChartStartRow,
                            dataStartRow,
                            monthsCount,
                            colMes,
                            firstYearCol,
                            idxAnios.size(),
                            yearLabels
                    );
                }
            } catch (Exception ignore) {}
        }

        // Nota final
        r++;
        Row notaPer = sh.createRow(r++);
        setCellText(notaPer, 0,
                "La tendencia mostrada en el gráfico indica el número de usuarios nuevos registrados por periodo.",
                legendStyle);
        int totalColsPer = (idxGrupo >= 0 ? 1 : 0) + (idxMes >= 0 ? 1 : 0) + idxAnios.size();
        if (totalColsPer <= 0) totalColsPer = 1;
        fillRowWithStyle(notaPer, 0, totalColsPer - 1, legendStyle);
        sh.addMergedRegion(new CellRangeAddress(notaPer.getRowNum(), notaPer.getRowNum(), 0, 7));
        // Crear gráfica de porcentaje de uso (usa el porcentaje global calculado)
        try {
            if (sh instanceof XSSFSheet) {
                int pctChartStartRow = r + 1;

                if (rsSO != null && !rsSO.isEmpty() && titleSO != null) {
                    int soChartEnd = titleSO.getRowNum() + 8;
                    if (pctChartStartRow <= soChartEnd) {
                        pctChartStartRow = soChartEnd + 1;
                    }
                }

                if (rsPeriodo != null && !rsPeriodo.isEmpty() && titlePer != null) {
                    int periodoChartEnd = titlePer.getRowNum() + 18;
                    if (pctChartStartRow <= periodoChartEnd) {
                        pctChartStartRow = periodoChartEnd + 1;
                    }
                }
                
                createBarChartPorcentajeUso((XSSFSheet) sh, pctChartStartRow, 6, porcentajeUsoGlobal);
            }
        } catch (Exception ignore) {}

        String leyendaGrafica = String.format(Locale.ROOT,
                "Del %s%% de los usuarios que han iniciado sesión, sólo el %s%% cuenta con la última versión de beMobile en al menos 1 dispositivo.",
                formatPercentLabel(leyendaPctUso),
                formatPercentLabel(leyendaPctUltima));
        int chartLegendStart = 6 + 4;
        int chartLegendEnd = chartLegendStart + 7;
        int legendRowIndex = 14;
        Row leyendaChartRow = sh.getRow(legendRowIndex);
        if (leyendaChartRow == null) {
            leyendaChartRow = sh.createRow(legendRowIndex);
        }
        for (int i = 1; i <= 2; i++) {
            if (sh.getRow(legendRowIndex + i) == null) {
                sh.createRow(legendRowIndex + i);
            }
        }
        setCellText(leyendaChartRow, chartLegendStart, leyendaGrafica, legendStyle);
        fillRowWithStyle(leyendaChartRow, chartLegendStart, chartLegendEnd, legendStyle);
        try {
            sh.addMergedRegion(new CellRangeAddress(legendRowIndex, legendRowIndex + 2,
                    chartLegendStart, chartLegendEnd));
        } catch (Throwable ignore) {}
    }

    private static void escribirDetalle(Sheet sh, ArrayList<LinkedCaseInsensitiveMap<?>> rows,
            Map<String, Object> parametros, int rsIndex) {
        LOGGER.info("Ejecutando Excel_Tablas_Graficos.escribirDetalle");
        if (rows == null)
            rows = new ArrayList<>();

        // Estilo por defecto (fuente Segoe UI 9)
        CellStyle defaultStyle = obtenerDefaultStyle(sh.getWorkbook());
        // Estilo centrado reutilizable
        CellStyle defaultCenter = clonarConAlineacion(defaultStyle, sh.getWorkbook(), HorizontalAlignment.CENTER);
        Map<HorizontalAlignment, CellStyle> alignCacheDetalle = new HashMap<>();

        // Estilo para fechas DD/MM/YYYY (sin negritas) heredando fuente
        org.apache.poi.ss.usermodel.CellStyle dateStyle = sh.getWorkbook().createCellStyle();
        dateStyle.cloneStyleFrom(defaultStyle);
        short dateFmt = sh.getWorkbook().createDataFormat().getFormat("dd/MM/yyyy");
        dateStyle.setDataFormat(dateFmt);
        // Estilo para moneda MXN $#,##0.00 heredando fuente
        org.apache.poi.ss.usermodel.CellStyle currencyStyle = sh.getWorkbook().createCellStyle();
        currencyStyle.cloneStyleFrom(defaultStyle);
        short cfmt = sh.getWorkbook().createDataFormat().getFormat("\"$\"#,##0.00");
        currencyStyle.setDataFormat(cfmt);

        // Intentar respetar configuración de columnas (bf_RepConf_Columna) enviada en parametros.reporteConfig.
        // Para la hoja Detalle, forzamos el grupo lógico "Detalle" (coincide con bf_RepConf_Tabla.grupo)
        // para encontrar la configuración correcta, independientemente del indexTable usado.
        Object prevGrupoNombre = parametros.get("grupoNombre");
        parametros.put("grupoNombre", "Detalle");
        int indexTableForCfg = rsIndex;
        @SuppressWarnings("unchecked")
        Map<String, Object> grupoConf = obtenerGrupoConfigPrefer(parametros, indexTableForCfg);
        // Restaurar grupoNombre original (si existía) para no contaminar otros usos
        if (prevGrupoNombre != null) {
            parametros.put("grupoNombre", prevGrupoNombre);
        } else {
            parametros.remove("grupoNombre");
        }
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> columnas = grupoConf == null ? null : (List<Map<String, Object>>) grupoConf.get("columnas");

        // Estilo de encabezados según bf_RepConf_Tabla (colorFondo/colorLetra) con fuente Segoe 9 bold
        CellStyle headerStyle = crearHeaderStyle(
                sh.getWorkbook(),
                grupoConf != null ? grupoConf.get("colorFondo") : null,
                grupoConf != null ? grupoConf.get("colorLetra") : null
        );

        List<String> headers = new ArrayList<>();
        List<String> campos = new ArrayList<>();
        // Tipos alineados con 'campos' (si vienen en configuración). 3 = DATETIME, 4 = moneda
        List<Integer> tipos = new ArrayList<>();
        // Metadatos opcionales por columna
        List<Integer> anchos = new ArrayList<>();
        List<String> formatos = new ArrayList<>();
        List<String> alinears = new ArrayList<>();

        // Mapa de normalización: clave normalizada -> clave real del RS
        java.util.Map<String, String> normalToActual = new java.util.HashMap<>();
        if (rows != null && !rows.isEmpty()) {
            LinkedCaseInsensitiveMap<?> first = rows.get(0);
            for (Object k : first.keySet()) {
                String actual = String.valueOf(k);
                normalToActual.put(normalizeKey(actual), actual);
            }
        }

        if (columnas != null && !columnas.isEmpty()) {
            for (Map<String, Object> col : columnas) {
                String campoCfg = String.valueOf(col.get("campoOrigen"));
                String enc = String.valueOf(col.get("encabezado"));
                // Resolver el campo real del RS por normalización (para tolerar espacios/acentos)
                String resolved = campoCfg;
                String try1 = normalToActual.get(normalizeKey(campoCfg));
                if (try1 != null) resolved = try1;
                // Solo agregar si existe en el RS (o si no hay filas aún)
                if (rows.isEmpty() || normalToActual.containsKey(normalizeKey(resolved))) {
                    campos.add(resolved);
                    headers.add(enc);
                    // tipoDato (entero) opcional
                    Integer tipo = null;
                    try { Object td = col.get("tipoDato"); if (td != null) tipo = Integer.parseInt(String.valueOf(td)); } catch (Exception ignore) {}
                    tipos.add(tipo);
                    // ancho / formato / alinear (opcionales)
                    anchos.add(safeInt(col.get("ancho"), 0));
                    formatos.add(col.get("formato") == null ? null : String.valueOf(col.get("formato")));
                    alinears.add(col.get("alinear") == null ? null : String.valueOf(col.get("alinear")));
                }
            }
        } else if (!rows.isEmpty()) {
            // Fallback: si no hay configuración, inferir del RS
            LinkedCaseInsensitiveMap<?> first = rows.get(0);
            for (Object k : first.keySet()) {
                String key = String.valueOf(k);
                campos.add(key);
                headers.add(key);
                tipos.add(null);
                anchos.add(0);
                formatos.add(null);
                alinears.add(null);
            }
        }

        // Fila 1: encabezados
        Row rh = sh.createRow(0);
        int c = 0;
        for (String h : headers) {
            Cell cell = rh.createCell(c++);
            cell.setCellValue(clean(h));
            cell.setCellStyle(headerStyle);
        }

        // Preparar estilos por columna (formato + alineación)
        CellStyle[] colStyles = new CellStyle[campos.size()];
        for (int i = 0; i < campos.size(); i++) {
            String fmtDesc = (i < formatos.size() ? formatos.get(i) : null);
            String fmt = resolveFormatString(fmtDesc);
            HorizontalAlignment align = resolveAlign((i < alinears.size() ? alinears.get(i) : null));
            // Si no hay 'formato', usar tipoDato para setear estilos por defecto
            if (fmt == null) {
                Integer t = (i < tipos.size() ? tipos.get(i) : null);
                if (t != null && t == 4) fmt = "\"$\"#,##0.00";
                else if (t != null && t == 3) fmt = "dd/MM/yyyy";
            }
            if (fmt != null || align != null) {
                CellStyle st = sh.getWorkbook().createCellStyle();
                st.cloneStyleFrom(defaultStyle);
                if (fmt != null) {
                    short df = sh.getWorkbook().createDataFormat().getFormat(fmt);
                    st.setDataFormat(df);
                }
                if (align != null) st.setAlignment(align);
                colStyles[i] = st;
            } else {
                colStyles[i] = null;
            }
        }

        // Configurar anchos fijos donde aplique; si no, dejarlos para autosize
        boolean[] autoSize = new boolean[campos.size()];
        for (int i = 0; i < anchos.size(); i++) {
            int w = anchos.get(i) == null ? 0 : anchos.get(i);
            if (w > 0) {
                int width256 = Math.min(w, 255) * 256;
                try { sh.setColumnWidth(i, width256); } catch (Throwable ignore) {}
                autoSize[i] = false;
            } else {
                autoSize[i] = true;
            }
        }

        // Datos desde fila 2
        int r = 1;
        for (LinkedCaseInsensitiveMap<?> row : rows) {
            Row rr = sh.createRow(r++);
            c = 0;
            for (int i = 0; i < campos.size(); i++) {
                String campo = campos.get(i);
                Integer tipo = (i < tipos.size() ? tipos.get(i) : null);
                Object val = row.get(campo);
                Cell cell = rr.createCell(c++);
                boolean isFecha = (tipo != null && tipo == 3);
                boolean isMoneda = (tipo != null && tipo == 4);
                String fmtDesc = (i < formatos.size() ? formatos.get(i) : null);
                boolean fechaPorFormato = fmtDesc != null && fmtDesc.toLowerCase(java.util.Locale.ROOT).startsWith("fecha:");
                if (isFecha || fechaPorFormato) {
                    Date fecha = null;
                    if (val instanceof Date) {
                        fecha = (Date) val;
                    } else if (val != null) {
                        String s = String.valueOf(val).trim();
                        fecha = tryParseDate(s);
                    }
                    if (fecha != null) {
                        cell.setCellValue(fecha);
                        if (colStyles[i] != null) cell.setCellStyle(colStyles[i]); else cell.setCellStyle(dateStyle);
                    } else {
                        cell.setCellValue("");
                    }
                } else if (isMoneda) {
                    Double num = tryParseDouble(val);
                    if (num != null) {
                        cell.setCellValue(num);
                        if (colStyles[i] != null) cell.setCellStyle(colStyles[i]); else cell.setCellStyle(currencyStyle);
                    } else {
                        cell.setCellValue("");
                    }
                } else if (colStyles[i] != null) {
                    Double num = tryParseDouble(val);
                    if (num != null && !isTextFormat(formatos.get(i))) {
                        cell.setCellValue(num);
                        cell.setCellStyle(colStyles[i]);
                    } else {
                        cell.setCellValue(val == null ? "" : clean(String.valueOf(val)));
                        cell.setCellStyle(colStyles[i]);
                    }
                } else {
                    cell.setCellValue(val == null ? "" : clean(String.valueOf(val)));
                    cell.setCellStyle(defaultStyle);
                }
            }
        }
    }

    private static Object firstNonNull(Object... vals) {
        if (vals == null) return null;
        for (Object v : vals) if (v != null) return v;
        return null;
    }

    private static CellStyle obtenerDefaultStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);

        short lightGray = IndexedColors.GREY_25_PERCENT.getIndex();
        style.setTopBorderColor(lightGray);
        style.setBottomBorderColor(lightGray);
        style.setLeftBorderColor(lightGray);
        style.setRightBorderColor(lightGray);
        Font font = wb.createFont();
        font.setFontName("Segoe UI");
        font.setFontHeightInPoints((short) 9);
        font.setBold(false);
        font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(font);
        return style;
    }

    private static CellStyle obtenerDefaultStyleSinBorde(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setFontName("Segoe UI");
        font.setFontHeightInPoints((short) 9);
        font.setBold(false);
        font.setColor(IndexedColors.BLACK.getIndex());
        style.setFont(font);
        return style;
    }
    private static CellStyle crearTitleStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setFontName("Garamond");
        font.setFontHeightInPoints((short) 12);
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setWrapText(false);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        try {
            if (style instanceof XSSFCellStyle) {
                ((XSSFCellStyle) style).setFillForegroundColor(new XSSFColor(ACCENT_BG_RGB, new DefaultIndexedColorMap()));
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            } else {
                style.setFillForegroundColor(IndexedColors.BLUE_GREY.getIndex());
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            }
            if (font instanceof XSSFFont) {
                ((XSSFFont) font).setColor(new XSSFColor(ACCENT_FONT_RGB, new DefaultIndexedColorMap()));
            } else {
                font.setColor(IndexedColors.WHITE.getIndex());
            }
        } catch (Exception ignore) {}
        style.setFont(font);
        return style;
    }

    private static CellStyle crearLabelStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setFontName("Segoe UI");
        font.setFontHeightInPoints((short) 9);
        font.setBold(true);
        // Aplicar color #5B6770 a etiquetas de las filas 1-3
        try {
            if (font instanceof XSSFFont) {
                ((XSSFFont) font).setColor(new XSSFColor(parseHexColor("#5B6770"), new DefaultIndexedColorMap()));
            } else {
                font.setColor(IndexedColors.BLACK.getIndex());
            }
        } catch (Exception ignore) {
            font.setColor(IndexedColors.BLACK.getIndex());
        }
        style.setFont(font);
        return style;
    }

    private static void setCellText(Row r, int col, String val, CellStyle st) {
        Cell c = r.createCell(col);
        c.setCellValue(val == null ? "" : val);
        if (st != null) c.setCellStyle(st);
    }

    private static void setCellValue(Row r, int col, Object val, CellStyle style) {
        Cell c = r.createCell(col);
        if (val == null) {
            c.setCellValue("");
        } else if (val instanceof Number) {
            c.setCellValue(((Number) val).doubleValue());
        } else if (val instanceof Boolean) {
            c.setCellValue((Boolean) val);
        } else if (val instanceof Date) {
            c.setCellValue((Date) val);
        } else {
            c.setCellValue(clean(String.valueOf(val)));
        }
        c.setCellStyle(style);
    }

    private static void setPercentCell(Row r, int col, Double pct, CellStyle pctStyle) {
        Cell c = r.createCell(col);
        if (pct == null) {
            c.setCellValue("");
        } else {
            c.setCellValue(pct);
        }
        if (pctStyle != null) c.setCellStyle(pctStyle);
    }

    private static Object getValueByPosition(ArrayList<LinkedCaseInsensitiveMap<?>> rs, int rowIndex, int valueIndex) {
        if (rs == null || rs.size() <= rowIndex) return null;
        LinkedCaseInsensitiveMap<?> row = rs.get(rowIndex);
        if (row == null || row.isEmpty()) return null;
        int i = 0;
        for (Object v : row.values()) {
            if (i++ == valueIndex) return v;
        }
        return null;
    }

    private static List<String> getColumnNames(ArrayList<LinkedCaseInsensitiveMap<?>> rs) {
        List<String> cols = new ArrayList<>();
        if (rs == null || rs.isEmpty()) return cols;
        LinkedCaseInsensitiveMap<?> first = rs.get(0);
        for (Object k : first.keySet()) {
            cols.add(String.valueOf(k));
        }
        return cols;
    }

    private static int findColIndex(List<String> cols, String... candidates) {
        if (cols == null || cols.isEmpty() || candidates == null) return -1;
        for (String cand : candidates) {
            if (cand == null) continue;
            String normCand = normalizeKey(cand);
            for (int i = 0; i < cols.size(); i++) {
                if (normalizeKey(cols.get(i)).equals(normCand)) {
                    return i;
                }
            }
        }
        return -1;
    }

    private static int indexWhere(List<String> cols, java.util.function.Predicate<String> pred) {
        if (cols == null || pred == null) return -1;
        for (int i = 0; i < cols.size(); i++) {
            String c = cols.get(i);
            try {
                if (pred.test(c)) return i;
            } catch (Throwable ignore) {}
        }
        return -1;
    }

    private static Object getAt(Object[] vals, int idx) {
        if (vals == null || idx < 0 || idx >= vals.length) return null;
        return vals[idx];
    }

    private static double safeDouble(Object v) {
        Double d = tryParseDouble(v);
        return d == null ? 0d : d;
    }

    private static String extraerAnioDesdeNombre(String nombreCol) {
        if (nombreCol == null) return null;
        String s = nombreCol.replaceAll("[^0-9]", "");
        if (s.length() >= 4) {
            return s.substring(s.length() - 4);
        }
        return null;
    }

    // --- Gráfica: Porcentaje de uso (barra apilada) ---
    private static void createBarChartPorcentajeUso(XSSFSheet sheet, int startRow, int columnCount, double porcentajeUsoData) {
        if (sheet == null) return;

        XSSFDrawing drawing = sheet.createDrawingPatriarch();
        // Ubicar la gráfica a la derecha de las tablas (similar a implementación previa)
        XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, columnCount + 4, 3, columnCount + 11, 13);

        XSSFChart chart = drawing.createChart(anchor);
        chart.setTitleText("PORCENTAJE DE USO");
        chart.setTitleOverlay(false);
// === ESTILO DEL TÍTULO: Garamond 12 negrita ===
CTTitle ctTitle = chart.getCTChart().getTitle();

// Acceder al texto ya creado por POI
CTTextBody txBody = ctTitle.getTx().getRich();
CTTextParagraph p = txBody.getPArray(0);

// Acceder al run existente
CTRegularTextRun run = p.getRArray(0);

// Propiedades de texto
CTTextCharacterProperties rPr = run.isSetRPr()
        ? run.getRPr()
        : run.addNewRPr();

rPr.setSz(1200); // 12 pt
rPr.addNewLatin().setTypeface("Garamond");
rPr.setB(true);


        XDDFChartLegend legend = chart.getOrAddLegend();
        legend.setPosition(LegendPosition.TOP);

        
        XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
        bottomAxis.setVisible(false);

        XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
        leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
        leftAxis.setCrossBetween(AxisCrossBetween.BETWEEN);
        leftAxis.setMaximum(1);
        leftAxis.setVisible(false);

        XDDFDataSource<String> categoria = XDDFDataSourcesFactory.fromArray(new String[] { "Uso" });

        double totalUso = porcentajeUsoData;
        if (totalUso < 0) totalUso = 0;
        if (totalUso > 1) totalUso = 1;

        XDDFNumericalDataSource<Double> userBeMobileHC =
                XDDFDataSourcesFactory.fromArray(new Double[] { totalUso });
        XDDFNumericalDataSource<Double> userSinRegHC =
                XDDFDataSourcesFactory.fromArray(new Double[] { 1 - totalUso });

        XDDFChartData data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);

        XDDFChartData.Series seriesBeMobile = data.addSeries(categoria, userBeMobileHC);
        seriesBeMobile.setTitle("Usuarios con BeMobile", null);

        XDDFChartData.Series seriesSinReg = data.addSeries(categoria, userSinRegHC);
        seriesSinReg.setTitle("Usuarios sin Registro", null);

        chart.plot(data);

        XDDFBarChartData bar = (XDDFBarChartData) data;
        bar.setBarDirection(BarDirection.BAR);
        bar.setBarGrouping(BarGrouping.STACKED);
        bar.setOverlap((byte) 100);

        byte[][] colors = new byte[][] {
                new byte[] { (byte) 52, (byte) 65, (byte) 76 },
                new byte[] { (byte) 204, (byte) 208, (byte) 213 }
        };

        solidFillSeries(data, 0, colors[0]);
        solidFillSeries(data, 1, colors[1]);

        if (chart.getCTChart().getPlotArea().getBarChartArray().length > 0) {
            CTBarSer[] seriesArray = chart.getCTChart().getPlotArea().getBarChartArray(0).getSerArray();
            for (CTBarSer ser : seriesArray) {
                CTDLbls dLbls = ser.isSetDLbls() ? ser.getDLbls() : ser.addNewDLbls();
                dLbls.addNewShowVal().setVal(true);
                dLbls.addNewShowPercent().setVal(false);
                dLbls.addNewShowSerName().setVal(false);
                dLbls.addNewShowCatName().setVal(false);
                dLbls.addNewShowLeaderLines().setVal(false);
                dLbls.addNewDLblPos().setVal(STDLblPos.CTR);
                dLbls.addNewNumFmt().setFormatCode("0.00%");
                dLbls.getNumFmt().setSourceLinked(false);
                dLbls.addNewTxPr();
                dLbls.getTxPr().addNewBodyPr();
                dLbls.getTxPr().addNewP();
                dLbls.getTxPr().getPArray(0).addNewPPr().addNewDefRPr().setB(true);
                dLbls.getTxPr().getPArray(0).getPPr().getDefRPr().addNewSolidFill()
                        .addNewSrgbClr().setVal(new byte[] { (byte) 255, (byte) 255, (byte) 255 });
            }
        }

        chart.getCTChartSpace().addNewSpPr().addNewLn().addNewNoFill();
    }

    private static void solidFillSeries(XDDFChartData data, int index, byte[] color) {
        org.apache.poi.xddf.usermodel.XDDFSolidFillProperties fill =
                new org.apache.poi.xddf.usermodel.XDDFSolidFillProperties(
                        org.apache.poi.xddf.usermodel.XDDFColor.from(color));
        XDDFChartData.Series series = data.getSeries().get(index);
        org.apache.poi.xddf.usermodel.XDDFShapeProperties properties = series.getShapeProperties();
        if (properties == null) {
            properties = new org.apache.poi.xddf.usermodel.XDDFShapeProperties();
        }
        properties.setFillProperties(fill);
        series.setShapeProperties(properties);
    }

    // --- Gráfica: Uso de beMobile por S.O ---
    private static void createChartUsoSO(XSSFSheet sheet, int startRow, int lastDataCol,
                                         double iosTotal, double androidTotal, double harmonyTotal) {
        if (sheet == null) return;
        double total = iosTotal + androidTotal + harmonyTotal;
        if (total <= 0) return;

        double iosPct = iosTotal / total;
        double andPct = androidTotal / total;
        double harPct = harmonyTotal / total;

        XSSFDrawing drawing = sheet.createDrawingPatriarch();
        int endRow = startRow + 8;
        XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0,
                lastDataCol + 5, startRow,
                lastDataCol + 12, endRow);

        XSSFChart chart = drawing.createChart(anchor);
        chart.setTitleText("USO DE BEMOBILE POR S.O");
        chart.setTitleOverlay(false);

        XDDFChartLegend legend = chart.getOrAddLegend();
        legend.setPosition(LegendPosition.TOP);

        XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
        bottomAxis.setVisible(false);

        XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
        leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
        leftAxis.setCrossBetween(AxisCrossBetween.BETWEEN);
        leftAxis.setMaximum(1);
        leftAxis.setVisible(false);

        XDDFDataSource<String> categorias =
                XDDFDataSourcesFactory.fromArray(new String[] { "iOS", "Android", "HARMONYOS" });
        XDDFNumericalDataSource<Double> valores =
                XDDFDataSourcesFactory.fromArray(new Double[] { iosPct, andPct, harPct });

        XDDFChartData data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);
        XDDFChartData.Series series = data.addSeries(categorias, valores);
        series.setTitle("Series", null);

        chart.plot(data);

        XDDFBarChartData bar = (XDDFBarChartData) data;
        bar.setBarDirection(BarDirection.BAR);
        bar.setBarGrouping(BarGrouping.STACKED);
        bar.setOverlap((byte) 100);

        byte[][] colors = new byte[][] {
                new byte[] { (byte) 91, (byte) 103, (byte) 112 },
                new byte[] { (byte) 52, (byte) 65, (byte) 76 },
                new byte[] { (byte) 115, (byte) 127, (byte) 139 }
        };

        int pointCount = series.getCategoryData().getPointCount();
        for (int p = 0; p < pointCount; p++) {
            chart.getCTChart().getPlotArea().getBarChartArray(0).getSerArray(0)
                    .addNewDPt().addNewIdx().setVal(p);
            chart.getCTChart().getPlotArea().getBarChartArray(0).getSerArray(0)
                    .getDPtArray(p).addNewSpPr().addNewSolidFill().addNewSrgbClr()
                    .setVal(colors[Math.min(p, colors.length - 1)]);
        }

        chart.getCTChartSpace().addNewSpPr().addNewLn().addNewNoFill();
    }

    // --- Gráfica: Usuarios nuevos por periodo (líneas) ---
    private static void createLineChartUsuariosNuevos(XSSFSheet sheet,
                                                      int chartStartRow,
                                                      int dataStartRow,
                                                      int monthsCount,
                                                      int colMes,
                                                      int firstYearCol,
                                                      int numYears,
                                                      List<String> yearLabels) {
        if (sheet == null || monthsCount <= 0 || numYears <= 0) return;

        int dataEndRow = dataStartRow + monthsCount - 1;

        XSSFDrawing drawing = sheet.createDrawingPatriarch();
        int chartEndRow = chartStartRow + 18;
        XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0,
                firstYearCol + numYears + 2, chartStartRow,
                firstYearCol + numYears + 12, chartEndRow);

        XSSFChart chart = drawing.createChart(anchor);
        chart.setTitleText("USUARIOS NUEVOS POR PERIODO");
        chart.setTitleOverlay(false);

        XDDFChartLegend legend = chart.getOrAddLegend();
        legend.setPosition(LegendPosition.TOP);

        XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
        XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
        leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
        leftAxis.setCrossBetween(AxisCrossBetween.BETWEEN);
        leftAxis.setMinimum(0);

        XDDFLineChartData data = (XDDFLineChartData) chart.createData(ChartTypes.LINE, bottomAxis, leftAxis);

        XDDFDataSource<String> mesesCategoria = XDDFDataSourcesFactory.fromStringCellRange(
                sheet, new CellRangeAddress(dataStartRow, dataEndRow, colMes, colMes));

        for (int i = 0; i < numYears; i++) {
            int col = firstYearCol + i;
            XDDFNumericalDataSource<Double> serieAnioRange =
                    XDDFDataSourcesFactory.fromNumericCellRange(
                            sheet, new CellRangeAddress(dataStartRow, dataEndRow, col, col));
            XDDFLineChartData.Series seriesAnio =
                    (XDDFLineChartData.Series) data.addSeries(mesesCategoria, serieAnioRange);
            String label = (yearLabels != null && yearLabels.size() > i && yearLabels.get(i) != null)
                    ? yearLabels.get(i)
                    : ("Año " + (i + 1));
            seriesAnio.setTitle(label, null);
            seriesAnio.setMarkerStyle(MarkerStyle.NONE);

            // === ESCALA DE GRISES ===
            int grayStep = 180 / Math.max(1, numYears - 1);
            int gray = 50 + (i * grayStep);

            XDDFSolidFillProperties fill =
                    new XDDFSolidFillProperties(XDDFColor.from(new byte[]{
                            (byte) gray, (byte) gray, (byte) gray
                    }));

            XDDFLineProperties lineProperties = new XDDFLineProperties();
            lineProperties.setFillProperties(fill);
            lineProperties.setWidth(2.0);

            XDDFShapeProperties shapeProperties = new XDDFShapeProperties();
            shapeProperties.setLineProperties(lineProperties);

            seriesAnio.setShapeProperties(shapeProperties);
        }

        chart.plot(data);

        chart.getCTChartSpace().addNewSpPr().addNewLn().addNewNoFill();
    }

    private static CellStyle crearHeaderStyle(Workbook wb, Object colorFondoObj, Object colorLetraObj) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setFontName("Segoe UI");
        font.setFontHeightInPoints((short) 9);
        font.setBold(false);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setWrapText(true);
        String fondo = colorFondoObj == null ? null : String.valueOf(colorFondoObj);
        String letra = colorLetraObj == null ? null : String.valueOf(colorLetraObj);
        Short fondoIdx = colorFromName(fondo);
        Short letraIdx = colorFromName(letra);
        if (fondoIdx != null) {
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            style.setFillForegroundColor(fondoIdx);
            style.setAlignment(HorizontalAlignment.CENTER);
        } else if (isHexColor(fondo) && style instanceof XSSFCellStyle) {
            try {
                java.awt.Color awt = parseHexColor(fondo);
                ((XSSFCellStyle) style).setFillForegroundColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                style.setAlignment(HorizontalAlignment.CENTER);
            } catch (Exception ignore) {}
        }
        // Color de letra: preferir XSSFColor para asegurar aplicación en SXSSF
        try {
            if (font instanceof XSSFFont) {
                java.awt.Color awt = null;
                if (isHexColor(letra)) {
                    awt = parseHexColor(letra);
                } else if (letraIdx != null) {
                    awt = awtFromIndexed(letraIdx);
                }
                if (awt != null) {
                    ((XSSFFont) font).setColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
                } else if (letraIdx != null) {
                    // Fallback a indexado
                    font.setColor(letraIdx);
                }
            } else {
                if (letraIdx != null) font.setColor(letraIdx);
            }
        } catch (Exception ignore) {}
        style.setFont(font);
        return style;
    }

    private static CellStyle crearAccentStyle(Workbook wb, HorizontalAlignment align, boolean wrap) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setFontName("Segoe UI");
        font.setFontHeightInPoints((short) 9);
        font.setBold(false);
        style.setAlignment(align);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setWrapText(wrap);
        try {
            if (style instanceof XSSFCellStyle) {
                ((XSSFCellStyle) style).setFillForegroundColor(new XSSFColor(ACCENT_BG_RGB, new DefaultIndexedColorMap()));
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            } else {
                style.setFillForegroundColor(IndexedColors.BLUE_GREY.getIndex());
                style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            }
            if (font instanceof XSSFFont) {
                ((XSSFFont) font).setColor(new XSSFColor(ACCENT_FONT_RGB, new DefaultIndexedColorMap()));
            } else {
                font.setColor(IndexedColors.WHITE.getIndex());
            }
        } catch (Exception ignore) {}
        style.setFont(font);
        return style;
    }

    private static Short colorFromName(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        if (n.equalsIgnoreCase("Blue") || n.equalsIgnoreCase("Azul")) return IndexedColors.BLUE.getIndex();
        if (n.equalsIgnoreCase("LightBlue") || n.equalsIgnoreCase("Light_Blue") || n.equalsIgnoreCase("Celeste")) return IndexedColors.LIGHT_BLUE.getIndex();
        if (n.equalsIgnoreCase("White") || n.equalsIgnoreCase("Blanco")) return IndexedColors.WHITE.getIndex();
        if (n.equalsIgnoreCase("Black") || n.equalsIgnoreCase("Negro")) return IndexedColors.BLACK.getIndex();
        if (n.equalsIgnoreCase("Red") || n.equalsIgnoreCase("Rojo")) return IndexedColors.RED.getIndex();
        if (n.equalsIgnoreCase("Green") || n.equalsIgnoreCase("Verde")) return IndexedColors.GREEN.getIndex();
        //if (n.equalsIgnoreCase("Gray") || n.equalsIgnoreCase("Grey") || n.equalsIgnoreCase("Gris")) return IndexedColors.GREY_50_PERCENT.getIndex();
        return null;
    }

    private static boolean isHexColor(String s) {
        if (s == null) return false;
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v.matches("(?i)^[0-9a-f]{6}$");
    }

    private static java.awt.Color parseHexColor(String s) {
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        int r = Integer.parseInt(v.substring(0,2), 16);
        int g = Integer.parseInt(v.substring(2,4), 16);
        int b = Integer.parseInt(v.substring(4,6), 16);
        return new java.awt.Color(r,g,b);
    }

    private static java.awt.Color awtFromIndexed(Short idx) {
        if (idx == null) return null;
        if (idx.equals(IndexedColors.WHITE.getIndex())) return java.awt.Color.WHITE;
        if (idx.equals(IndexedColors.BLACK.getIndex())) return java.awt.Color.BLACK;
        if (idx.equals(IndexedColors.RED.getIndex())) return java.awt.Color.RED;
        if (idx.equals(IndexedColors.GREEN.getIndex())) return java.awt.Color.GREEN;
        if (idx.equals(IndexedColors.BLUE.getIndex())) return java.awt.Color.BLUE;
        if (idx.equals(IndexedColors.LIGHT_BLUE.getIndex())) return new java.awt.Color(173, 216, 230);
        //if (idx.equals(IndexedColors.GREY_50_PERCENT.getIndex())) return new java.awt.Color(128, 128, 128);
        return null;
    }

    private static void guardarWorkbook(Workbook wb, String outputDir, String fileName) throws Exception {
        File dir = new File(outputDir);
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(out)) {
            System.out.println("Escribiendo archivo...");
            wb.write(fos);
        }
        wb.close();
        System.out.println("Archivo generado: " + out.getAbsolutePath());
    }

    private static String sanitizarNombreCarpeta(String s) {
        if (s == null) return null;
        String sinAcentos = quitarAcentos(s);
        // Reemplazar caracteres inválidos en rutas Windows y normalizar espacios
        String cleaned = sinAcentos.replaceAll("[\\/:*?\"<>|]", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        // Evitar nombres reservados
        String upper = cleaned.equalsIgnoreCase("CON") || cleaned.equalsIgnoreCase("PRN") ||
                       cleaned.equalsIgnoreCase("AUX") || cleaned.equalsIgnoreCase("NUL") ? "Reporte" : cleaned;
        return upper.isEmpty() ? "Reporte" : upper;
    }

    private static String nombreReportePorId(Map<String, Object> parametros) {
        if (parametros == null) return "Reporte";
        Integer rid = null;
        try { Object o = parametros.get("reporteId"); if (o != null) rid = Integer.parseInt(String.valueOf(o)); } catch (Exception ignore) {}
        if (rid == null) return "Reporte";
        switch (rid) {
            case 2: return "Poblacion";
            case 3: return "Sabana";
            default: return "Reporte";
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> obtenerGrupoConfigPrefer(Map<String, Object> parametros, int index) {
        try {
            Object o = parametros.get("reporteConfig");
            if (o instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) o;
                Object nombre = parametros.get("grupoNombre");
                if (nombre != null) {
                    for (Map<String, Object> m : list) {
                        if (String.valueOf(m.get("grupo")).equalsIgnoreCase(String.valueOf(nombre))) {
                            return m;
                        }
                    }
                }
                // ordenar por indexTable asc
                List<Map<String, Object>> ordered = new ArrayList<>(list);
                ordered.sort((a,b) -> Integer.compare(safeInt(a.get("indexTable"), 0), safeInt(b.get("indexTable"), 0)));
                if (index >= 0 && index < ordered.size()) return ordered.get(index);
            }
        } catch (Throwable ignore) {}
        return null;
    }

    private static Map<String, Object> obtenerGrupoConfigPorNombre(Map<String, Object> parametros, String... nombres) {
        if (parametros == null || nombres == null || nombres.length == 0) return null;
        try {
            Object o = parametros.get("reporteConfig");
            if (o instanceof List) {
                List<Map<String, Object>> list = (List<Map<String, Object>>) o;
                for (Map<String, Object> m : list) {
                    Object g = m.get("grupo");
                    if (g == null) continue;
                    String norm = normalizeKey(String.valueOf(g));
                    for (String n : nombres) {
                        if (normalizeKey(n).equals(norm)) return m;
                    }
                }
            }
        } catch (Exception ignore) {}
        return null;
    }

    private static Map<String, Integer> extraerAnchosPorCampo(Map<String, Object> grupoConf) {
        Map<String, Integer> out = new LinkedHashMap<>();
        if (grupoConf == null) return out;
        try {
            Object colsObj = grupoConf.get("columnas");
            if (colsObj instanceof List) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> cols = (List<Map<String, Object>>) colsObj;
                for (Map<String, Object> col : cols) {
                    String campo = String.valueOf(col.get("campoOrigen"));
                    int ancho = safeInt(col.get("ancho"), 0);
                    out.put(normalizeKey(campo), ancho);
                }
            }
        } catch (Exception ignore) {}
        return out;
    }

    private static Map<String, String> extraerAlineacionesPorCampo(Map<String, Object> grupoConf) {
        Map<String, String> out = new LinkedHashMap<>();
        if (grupoConf == null) return out;
        try {
            Object colsObj = grupoConf.get("columnas");
            if (colsObj instanceof List) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> cols = (List<Map<String, Object>>) colsObj;
                for (Map<String, Object> col : cols) {
                    String campo = String.valueOf(col.get("campoOrigen"));
                    Object al = col.get("alineacion");
                    if (al == null) al = col.get("alinear");
                    if (al != null) {
                        out.put(normalizeKey(campo), String.valueOf(al));
                    }
                }
            }
        } catch (Exception ignore) {}
        return out;
    }

    private static void aplicarAnchos(Sheet sh, Map<String, Integer> anchos, String[] campos) {
        if (sh == null || anchos == null || campos == null) return;
        boolean[] autoSize = new boolean[campos.length];
        for (int i = 0; i < campos.length; i++) {
            String k = normalizeKey(campos[i]);
            Integer w = anchos.get(k);
            if (w != null && w > 0) {
                int width256 = Math.min(w, 255) * 256;
                try { sh.setColumnWidth(i, width256); } catch (Throwable ignore) {}
                autoSize[i] = false;
            }
        }
    }

    private static CellStyle stylePorAlign(String campo,
                                           Map<String, String> alineaciones,
                                           Workbook wb,
                                           CellStyle defaultStyle,
                                           CellStyle defaultCenter,
                                           Map<HorizontalAlignment, CellStyle> cache) {
        if (alineaciones == null || alineaciones.isEmpty()) return defaultStyle;
        String val = alineaciones.get(normalizeKey(campo));
        HorizontalAlignment align = resolveAlign(val);
        if (align == null) return defaultStyle;
        if (align == HorizontalAlignment.CENTER) return defaultCenter;
        if (cache != null && cache.containsKey(align)) return cache.get(align);
        CellStyle st = clonarConAlineacion(defaultStyle, wb, align);
        if (cache != null) cache.put(align, st);
        return st;
    }

    private static CellStyle clonarConAlineacion(CellStyle base, Workbook wb, HorizontalAlignment align) {
        if (align == null) return base;
        CellStyle cs = wb.createCellStyle();
        cs.cloneStyleFrom(base);
        cs.setAlignment(align);
        return cs;
    }

    private static CellStyle clonarConColorFuente(CellStyle base, Workbook wb, String hexColor) {
        CellStyle cs = wb.createCellStyle();
        cs.cloneStyleFrom(base);
        Font baseFont = wb.getFontAt(base.getFontIndex());
        Font f = wb.createFont();
        f.setFontName(baseFont.getFontName());
        f.setFontHeightInPoints(baseFont.getFontHeightInPoints());
        f.setBold(baseFont.getBold());
        f.setItalic(baseFont.getItalic());
        f.setUnderline(baseFont.getUnderline());
        f.setStrikeout(baseFont.getStrikeout());
        if (isHexColor(hexColor) && f instanceof XSSFFont) {
            try {
                java.awt.Color awt = parseHexColor(hexColor);
                ((XSSFFont) f).setColor(new XSSFColor(awt, new DefaultIndexedColorMap()));
            } catch (Exception ignore) {}
        }
        cs.setFont(f);
        return cs;
    }

    private static int safeInt(Object v, int def) {
        try { return Integer.parseInt(String.valueOf(v)); } catch (Exception e) { return def; }
    }

    // Normaliza una clave eliminando acentos, espacios y signos; en minúsculas
    private static String normalizeKey(String s) {
        if (s == null) return "";
        String lower = s.toLowerCase(java.util.Locale.ROOT);
        String decomposed = java.text.Normalizer.normalize(lower, java.text.Normalizer.Form.NFD);
        String noAccents = decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return noAccents.replaceAll("[^a-z0-9]", "");
    }

    private static Double findDoubleByAliases(LinkedCaseInsensitiveMap<?> row, String... aliases) {
        if (row == null || row.isEmpty() || aliases == null) return null;
        for (Object key : row.keySet()) {
            String normKey = normalizeKey(String.valueOf(key));
            for (String alias : aliases) {
                if (normKey.contains(normalizeKey(alias))) {
                    return tryParseDouble(row.get(key));
                }
            }
        }
        return null;
    }

    private static double normalizePercentValue(Double value) {
        if (value == null) return Double.NaN;
        double pct = value;
        if (pct > 1.0) pct = pct / 100.0;
        if (pct < 0) pct = 0;
        if (pct > 1) pct = 1;
        return pct;
    }

    private static String formatPercentLabel(double pct) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(pct * 100);
    }

    private static Date tryParseDate(String s) {
        if (s == null || s.isEmpty()) return null;
        String[] fmts = new String[] {
                "yyyy-MM-dd'T'HH:mm:ss",
                "yyyy-MM-dd HH:mm:ss",
                "yyyy-MM-dd",
                "dd/MM/yyyy",
                "MM/dd/yyyy"
        };
        for (String f : fmts) {
            try {
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(f, java.util.Locale.ROOT);
                sdf.setLenient(false);
                return sdf.parse(s);
            } catch (Exception ignore) {}
        }
        try {
            Double.parseDouble(s);
        } catch (Exception ignore) {}
        return null;
    }

    private static Double tryParseDouble(Object v) {
        if (v == null) return null;
        if (v instanceof Number) return ((Number)v).doubleValue();
        String s = String.valueOf(v).trim().replace(",", "");
        try { return Double.parseDouble(s); } catch (Exception ignore) { return null; }
    }

    private static void fillRowWithStyle(Row row, int startCol, int endCol, CellStyle style) {
        if (row == null || style == null) return;
        for (int c = startCol; c <= endCol; c++) {
            Cell cell = row.getCell(c);
            if (cell == null) cell = row.createCell(c);
            cell.setCellStyle(style);
        }
    }

    private static String resolveFormatString(String desc) {
        if (desc == null) return null;
        String d = desc.trim();
        if (d.isEmpty()) return null;
        String l = d.toLowerCase(java.util.Locale.ROOT);
        if (l.equals("texto") || l.equals("text") || l.equals("@")) return "@";
        if (l.equals("entero") || l.equals("integer")) return "0";
        if (l.equals("numero") || l.equals("number") || l.equals("decimal")) return "#,##0.00";
        if (l.equals("moneda") || l.equals("currency")) return "\"$\"#,##0.00";
        if (l.equals("porcentaje") || l.equals("percent")) return "0.00%";
        if (l.startsWith("fecha:")) return d.substring(6).trim().isEmpty() ? "dd/MM/yyyy" : d.substring(6).trim();
        if (l.startsWith("custom:")) return d.substring(7).trim().isEmpty() ? null : d.substring(7).trim();
        return null;
    }

    private static HorizontalAlignment resolveAlign(String desc) {
        if (desc == null) return null;
        String l = desc.trim().toLowerCase(java.util.Locale.ROOT);
        if (l.isEmpty()) return null;
        if (l.equals("izquierda") || l.equals("left")) return HorizontalAlignment.LEFT;
        if (l.equals("centro") || l.equals("center")) return HorizontalAlignment.CENTER;
        if (l.equals("derecha") || l.equals("right")) return HorizontalAlignment.RIGHT;
        return null;
    }

    private static boolean isTextFormat(String desc) {
        if (desc == null) return false;
        String l = desc.trim().toLowerCase(java.util.Locale.ROOT);
        return l.equals("texto") || l.equals("text") || l.equals("@");
    }

    // Limpia caracteres no permitidos por XML 1.0 que pueden corromper el XLSX
    private static String clean(String s) {
        if (s == null) return null;
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == 0x9 || ch == 0xA || ch == 0xD ||
                (ch >= 0x20 && ch <= 0xD7FF) ||
                (ch >= 0xE000 && ch <= 0xFFFD)) {
                sb.append(ch);
            }
        }
        String out = sb.toString();
        return out.length() > 32766 ? out.substring(0, 32766) : out; // límite Excel
    }

    private static String quitarAcentos(String s) {
        if (s == null) return null;
        String decomposed = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

    /**
     * Agrega barras de datos (data bars) condicionales a la columna de porcentaje.
     * Las barras se muestran proporcionalmente al valor de cada celda (0-100%).
     */
    private static void addDataBarsToPercentageColumn(XSSFSheet sheet, int firstRow, int lastRow, int column) {
        try {
            XSSFSheetConditionalFormatting sheetCF = sheet.getSheetConditionalFormatting();
            
            // Color gris similar al usado en el ejemplo original: #B8BDC4 (184, 189, 196)
            XSSFColor color = new XSSFColor(new byte[] { (byte) 184, (byte) 189, (byte) 196 }, new DefaultIndexedColorMap());
            
            // Rango de celdas: columna de porcentaje desde firstRow hasta lastRow
            CellRangeAddress[] regions = new CellRangeAddress[] {
                new CellRangeAddress(firstRow, lastRow, column, column)
            };
            
            // Crear regla de formato condicional con data bar
            XSSFConditionalFormattingRule condRule = sheetCF.createConditionalFormattingRule(color);
            DataBarFormatting dataBar = condRule.getDataBarFormatting();
            
            // Configurar umbrales: mínimo 0, máximo 1 (100% en formato decimal)
            dataBar.getMinThreshold().setRangeType(RangeType.NUMBER);
            dataBar.getMinThreshold().setValue(0.0);
            dataBar.getMaxThreshold().setRangeType(RangeType.NUMBER);
            dataBar.getMaxThreshold().setValue(1.0);
            
            // Aplicar el formato condicional al rango
            sheetCF.addConditionalFormatting(regions, condRule);
        } catch (Exception e) {
            // Si falla, no interrumpir la generación del reporte
            System.err.println("Error al agregar data bars: " + e.getMessage());
        }
    }
}