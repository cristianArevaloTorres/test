package com.lockton.rpt.models.dto;

import lombok.Data;

@Data
public class ItemReporteDTO {
    private long catRptId;
    private String catRptNombre;
}