package com.lockton.rpt.models.dto;

import java.time.LocalDateTime;

public class CatReportesSPCreateRequest_DTO {
    public Integer catReportesSPId;
    public Integer catReportesId;
    public String catReportesSPNombre;
    public Integer catReportesSPOrden;
    public String catReportesSPDesc;
    public Integer ESid;
    public Integer catReportesSPUsuarioAdd;
    public LocalDateTime catReportesSPFechaAdd;
    public Integer catReportesSPUsuarioMod;
    public LocalDateTime catReportesSPFechaMod;
    public Integer catReportesSPUsuarioDel;
    public LocalDateTime catReportesSPFechaDel;
    public CatReportesParamsRequest_DTO[] parameters;
    
    public Integer getCatReportesSPId() {
        return catReportesSPId;
    }
    public void setCatReportesSPId(Integer catReportesSPId) {
        this.catReportesSPId = catReportesSPId;
    }
    public Integer getCatReportesId() {
        return catReportesId;
    }
    public void setCatReportesId(Integer catReportesId) {
        this.catReportesId = catReportesId;
    }
    public String getCatReportesSPNombre() {
        return catReportesSPNombre;
    }
    public void setCatReportesSPNombre(String catReportesSPNombre) {
        this.catReportesSPNombre = catReportesSPNombre;
    }
    public Integer getCatReportesSPOrden() {
        return catReportesSPOrden;
    }
    public void setCatReportesSPOrden(Integer catReportesSPOrden) {
        this.catReportesSPOrden = catReportesSPOrden;
    }
    public String getCatReportesSPDesc() {
        return catReportesSPDesc;
    }
    public void setCatReportesSPDesc(String catReportesSPDesc) {
        this.catReportesSPDesc = catReportesSPDesc;
    }
    public Integer getESid() {
        return ESid;
    }
    public void setESid(Integer eSid) {
        ESid = eSid;
    }
    public Integer getCatReportesSPUsuarioAdd() {
        return catReportesSPUsuarioAdd;
    }
    public void setCatReportesSPUsuarioAdd(Integer catReportesSPUsuarioAdd) {
        this.catReportesSPUsuarioAdd = catReportesSPUsuarioAdd;
    }
    public LocalDateTime getCatReportesSPFechaAdd() {
        return catReportesSPFechaAdd;
    }
    public void setCatReportesSPFechaAdd(LocalDateTime catReportesSPFechaAdd) {
        this.catReportesSPFechaAdd = catReportesSPFechaAdd;
    }
    public Integer getCatReportesSPUsuarioMod() {
        return catReportesSPUsuarioMod;
    }
    public void setCatReportesSPUsuarioMod(Integer catReportesSPUsuarioMod) {
        this.catReportesSPUsuarioMod = catReportesSPUsuarioMod;
    }
    public LocalDateTime getCatReportesSPFechaMod() {
        return catReportesSPFechaMod;
    }
    public void setCatReportesSPFechaMod(LocalDateTime catReportesSPFechaMod) {
        this.catReportesSPFechaMod = catReportesSPFechaMod;
    }
    public Integer getCatReportesSPUsuarioDel() {
        return catReportesSPUsuarioDel;
    }
    public void setCatReportesSPUsuarioDel(Integer catReportesSPUsuarioDel) {
        this.catReportesSPUsuarioDel = catReportesSPUsuarioDel;
    }
    public LocalDateTime getCatReportesSPFechaDel() {
        return catReportesSPFechaDel;
    }
    public void setCatReportesSPFechaDel(LocalDateTime catReportesSPFechaDel) {
        this.catReportesSPFechaDel = catReportesSPFechaDel;
    }
    public CatReportesParamsRequest_DTO[] getParameters() {
        return parameters;
    }
    public void setParameters(CatReportesParamsRequest_DTO[] parameters) {
        this.parameters = parameters;
    }
}
