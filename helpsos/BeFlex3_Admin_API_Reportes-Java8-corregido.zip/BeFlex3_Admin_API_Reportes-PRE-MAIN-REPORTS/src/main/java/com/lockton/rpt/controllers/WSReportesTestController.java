package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.ResponseAsyncRptDTO;
import com.lockton.rpt.services.GeneradorReportesService;
import com.lockton.rpt.services.ReporteService;
import com.lockton.rpt.services.TestService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;

@Profile("dev")
@RestController
@RequestMapping("/beflex")
@Api(tags = "Controlador de pruebas para reportes")
public class WSReportesTestController {
    
    private static final Log LOGGER = LogFactory.getLog(WSReportesTestController.class);
    
    @Autowired
    GeneradorReportesService generadorDinamico;

    @Autowired
    ReporteService rptService;

    @Autowired
    TestService testService;
    
    @PostMapping("/generadorDinamico/{reporteId}")
    public ResponseEntity<ResponseAsyncRptDTO> GeneradorDinamico(
        @PathVariable int reporteId,
        @RequestBody Map<String,Object> requestMap) throws Exception {
            LOGGER.info("Inicia controller ==> ReportesTestController ==> generadorDinamico... " + requestMap);
            ResponseAsyncRptDTO rsReporte = new ResponseAsyncRptDTO();
            try{
                rsReporte = generadorDinamico.ReporteDinamico(reporteId, requestMap);
            }
            catch(Exception ex) {
                rsReporte.setMensaje("ERROR: " + ex.getMessage() + ". Cause: " + ex.getCause().getMessage());
                return ResponseEntity.status(HttpStatus.CONFLICT).body(rsReporte);
            }
            return ResponseEntity.ok().body(rsReporte);
        }

    @GetMapping("/statusReporte/{id}")
    @ApiOperation("Obtención de estatus de reporte por Id")
    public ResponseEntity<String> StatusReporte(@PathVariable int id) {
        String rs = rptService.ConsultaStatusReporte(id);
        return ResponseEntity.ok(rs);
    }

    @PostMapping("/testPoblacion")
    @ApiOperation("Test de poblacion")
    public ResponseEntity<List<LinkedCaseInsensitiveMap>> TestPoblacion(@RequestBody Map<String, String> consulta) {
        List<LinkedCaseInsensitiveMap> response = new ArrayList();
        response.addAll(testService.reporteDeAsegurados(consulta.get("empresas"),
                    consulta.get("fechaIni"),
                    consulta.get("fechaFin"),
                    consulta.get("estatus"),
                    consulta.get("parentescos"),
                    consulta.get("perfiles"),
                    consulta.get("sueldo"),
                    Integer.valueOf(consulta.get("admIdEmpresa")),
                    Integer.valueOf(consulta.get("admIdPerfil"))));
        return ResponseEntity.ok(response);
    }
}