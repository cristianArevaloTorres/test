package com.lockton.rpt.services.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.lockton.rpt.repositories.ConfigIndicadorJsonSupport;
import com.lockton.rpt.repositories.ConfigIndicadoresDAO;

import com.lockton.rpt.util.TextUtil;

import org.springframework.stereotype.Service;

@Service
public class ConfigPlantillaService {

    private final ConfigIndicadoresDAO dao;

    public ConfigPlantillaService(ConfigIndicadoresDAO dao) {
        this.dao = dao;
    }

    public Map<String, Object> getCatalogos() {
        Map<String, Object> cat = new LinkedHashMap<>();
        cat.put("storedProcedures", dao.getStoredProcedures());
        cat.put("tiposIndicador", IndicadorTipoCatalog.listForApi());
        return cat;
    }

    public List<Map<String, Object>> getStoredProcedureParametros(int idSp) {
        return dao.getStoredProcedureParametros(idSp);
    }

    public List<Map<String, Object>> getStoredProcedureSalidas(int idSp) {
        return dao.getStoredProcedureSalidas(idSp);
    }

    public Map<String, Object> crearStoredProcedureParametro(int idSp, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        String nombre = str(body, "nombreParametro");
        if (TextUtil.isBlank(nombre)) {
            throw new IllegalArgumentException("nombreParametro es obligatorio.");
        }
        String paramSql = str(body, "parametroSql");
        if (TextUtil.isBlank(paramSql)) {
            paramSql = "@" + nombre;
        }
        int id = dao.addStoredProcedureParametro(idSp, nombre, str(body, "nombreVisual"),
                paramSql, TextUtil.isBlank(str(body, "tipoDato")) ? "NVARCHAR" : str(body, "tipoDato"),
                intVal(body.get("orden"), 1), bool(body.get("obligatorio"), false),
                bool(body.get("filtroBase"), false), bool(body.get("visible"), true),
                idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("idParametro", id);
        out.put("parametros", dao.getStoredProcedureParametros(idSp));
        return out;
    }

    public Map<String, Object> actualizarStoredProcedureParametro(int idParametro, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        int idSp = intVal(body.get("idStoredProcedure"), 0);
        int n = dao.updateStoredProcedureParametro(idParametro, str(body, "nombreVisual"),
                str(body, "parametroSql"), TextUtil.isBlank(str(body, "tipoDato")) ? "NVARCHAR" : str(body, "tipoDato"),
                intVal(body.get("orden"), 1), bool(body.get("obligatorio"), false),
                bool(body.get("filtroBase"), false), bool(body.get("visible"), true),
                idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        if (idSp > 0) {
            out.put("parametros", dao.getStoredProcedureParametros(idSp));
        }
        return out;
    }

    public Map<String, Object> eliminarStoredProcedureParametro(int idParametro, int idSp,
            int idUsuario, String nombreUsuario) {
        int n = dao.deleteStoredProcedureParametro(idParametro, idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        out.put("parametros", dao.getStoredProcedureParametros(idSp));
        return out;
    }

    public Map<String, Object> obtenerStoredProcedure(int idSp) {
        Map<String, Object> detalle = dao.getStoredProcedureDetalle(idSp);
        if (detalle.isEmpty()) {
            throw new IllegalArgumentException("Stored procedure de catálogo no encontrado.");
        }
        return detalle;
    }

    public Map<String, Object> crearStoredProcedure(Map<String, Object> body, int idUsuario, String nombreUsuario) {
        int id = dao.addStoredProcedure(str(body, "clave"), str(body, "nombre"), str(body, "nombreReal"),
                str(body, "descripcion"), idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("idStoredProcedure", id);
        out.put("storedProcedure", obtenerStoredProcedure(id));
        return out;
    }

    public Map<String, Object> actualizarStoredProcedure(int idSp, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        int n = dao.updateStoredProcedure(idSp, str(body, "clave"), str(body, "nombre"), str(body, "nombreReal"),
                str(body, "descripcion"), idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        out.put("storedProcedure", obtenerStoredProcedure(idSp));
        return out;
    }

    public Map<String, Object> eliminarStoredProcedure(int idSp, int idUsuario, String nombreUsuario) {
        int n = dao.deleteStoredProcedure(idSp, idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        return out;
    }

    public Map<String, Object> crearStoredProcedureSalida(int idSp, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        int id = dao.addStoredProcedureSalida(idSp, intVal(body.get("indiceResultSet"), 0),
                str(body, "nombreColumna"), str(body, "nombreVisual"),
                TextUtil.isBlank(str(body, "tipoDato")) ? "NVARCHAR" : str(body, "tipoDato"),
                intVal(body.get("orden"), 1), idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("idSalida", id);
        out.put("salidas", dao.getStoredProcedureSalidas(idSp));
        return out;
    }

    public Map<String, Object> actualizarStoredProcedureSalida(int idSalida, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        int idSp = intVal(body.get("idStoredProcedure"), 0);
        int n = dao.updateStoredProcedureSalida(idSalida, str(body, "nombreVisual"),
                TextUtil.isBlank(str(body, "tipoDato")) ? "NVARCHAR" : str(body, "tipoDato"),
                intVal(body.get("orden"), 1), idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        if (idSp > 0) {
            out.put("salidas", dao.getStoredProcedureSalidas(idSp));
        }
        return out;
    }

    public Map<String, Object> eliminarStoredProcedureSalida(int idSalida, int idSp,
            int idUsuario, String nombreUsuario) {
        int n = dao.deleteStoredProcedureSalida(idSalida, idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        out.put("salidas", dao.getStoredProcedureSalidas(idSp));
        return out;
    }

    public List<Map<String, Object>> listarSecciones() {
        return listarSecciones(null);
    }

    public List<Map<String, Object>> listarSecciones(Integer idCorporativo) {
        if (idCorporativo == null || idCorporativo <= 0) {
            return dao.getSecciones(null);
        }
        return filtrarSeccionesPlantillaCorporativo(idCorporativo);
    }

    public Map<String, Object> obtenerSeccion(int idSeccion) {
        return obtenerSeccion(idSeccion, null);
    }

    public Map<String, Object> obtenerSeccion(int idSeccion, Integer idCorporativo) {
        Map<String, Object> seccion = dao.getSeccionDetalle(idSeccion, idCorporativo);
        if (seccion.isEmpty()) {
            throw new IllegalArgumentException("Sección de plantilla no encontrada.");
        }
        if (idCorporativo != null && idCorporativo > 0) {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> indicadores = (List<Map<String, Object>>) seccion.get("indicadores");
            seccion.put("indicadores", filtrarIndicadoresPlantillaCorporativo(indicadores, idCorporativo));
        }
        return seccion;
    }

    public Map<String, Object> crearSeccion(Map<String, Object> body, int idUsuario, String nombreUsuario) {
        int id = dao.addSeccionCatalog(str(body, "clave"), str(body, "nombre"), str(body, "descripcion"),
                intOrNull(body.get("idCorporativo")), idUsuario, nombreUsuario);
        if (body.containsKey("orden") || body.containsKey("mostrarEnReporte") || body.containsKey("textoAdicional")) {
            dao.saveSeccionConfig(id, intOrNull(body.get("idCorporativo")),
                    intVal(body.get("orden"), 1), bool(body.get("mostrarEnReporte"), true),
                    str(body, "textoAdicional"), null, idUsuario, nombreUsuario);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("idSeccion", id);
        return out;
    }

    public Map<String, Object> actualizarSeccion(int idSeccion, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        boolean esSnapshot = body.containsKey("clave") && body.containsKey("nombre")
                && !body.containsKey("orden") && !body.containsKey("textoAdicional")
                && !body.containsKey("textosJson");
        int registros = 0;
        if (esSnapshot) {
            registros = dao.updateSeccionCatalog(idSeccion, str(body, "clave"), str(body, "nombre"),
                    str(body, "descripcion"), idUsuario, nombreUsuario);
        } else {
            if (body.containsKey("clave") || body.containsKey("nombre") || body.containsKey("descripcion")) {
                registros += dao.updateSeccionCatalog(idSeccion, str(body, "clave"), str(body, "nombre"),
                        str(body, "descripcion"), idUsuario, nombreUsuario);
            }
            if (body.containsKey("orden") || body.containsKey("mostrarEnReporte")
                    || body.containsKey("textoAdicional") || body.containsKey("textosJson")) {
                registros += dao.saveSeccionConfig(idSeccion, intOrNull(body.get("idCorporativo")),
                        intVal(body.get("orden"), 1), bool(body.get("mostrarEnReporte"), true),
                        str(body, "textoAdicional"), strOrNull(body, "textosJson"),
                        idUsuario, nombreUsuario);
            }
        }
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", registros);
        out.put("seccion", obtenerSeccion(idSeccion, intOrNull(body.get("idCorporativo"))));
        return out;
    }

    public Map<String, Object> eliminarSeccion(int idSeccion, Integer idCorporativo,
            int idUsuario, String nombreUsuario) {
        int n;
        if (idCorporativo != null && idCorporativo > 0) {
            n = dao.deleteSeccionConfig(idSeccion, idCorporativo, idUsuario, nombreUsuario);
        } else {
            n = dao.deleteSeccion(idSeccion, idUsuario, nombreUsuario);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        return out;
    }

    public Map<String, Object> crearTextoSeccion(int idSeccion, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        Integer idCorp = intOrNull(body.get("idCorporativo"));
        Map<String, Object> seccion = obtenerSeccion(idSeccion, idCorp);
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> textos = (List<Map<String, Object>>) seccion.get("textos");
        Map<String, Object> nuevo = new LinkedHashMap<>();
        nuevo.put("clave", str(body, "clave"));
        nuevo.put("tipoTexto", str(body, "tipoTexto"));
        nuevo.put("textoPlantilla", str(body, "textoPlantilla"));
        nuevo.put("esDinamico", bool(body.get("esDinamico"), false));
        nuevo.put("orden", intVal(body.get("orden"), textos.size() + 1));
        nuevo.put("mostrarEnReporte", bool(body.get("mostrarEnReporte"), true));
        textos.add(nuevo);
        dao.saveSeccionConfig(idSeccion, intOrNull(body.get("idCorporativo")), intVal(seccion.get("CESOrden"), 1),
                bool(seccion.get("CESMostrarEnReporte"), true),
                String.valueOf(seccion.getOrDefault("CESTextoAdicional", "")),
                ConfigIndicadorJsonSupport.toJson(textos), idUsuario, nombreUsuario);
        Map<String, Object> out = new HashMap<>();
        out.put("idTexto", textos.size());
        return out;
    }

    public List<Map<String, Object>> listarIndicadores(int idSeccion) {
        return listarIndicadores(idSeccion, null);
    }

    public List<Map<String, Object>> listarIndicadores(int idSeccion, Integer idCorporativo) {
        return dao.getIndicadores(idCorporativo, idSeccion);
    }

    public Map<String, Object> obtenerIndicador(int idIndicador) {
        return obtenerIndicador(idIndicador, null);
    }

    public Map<String, Object> obtenerIndicador(int idIndicador, Integer idCorporativo) {
        Map<String, Object> detalle = dao.getIndicadorDetalle(idCorporativo, idIndicador);
        if (detalle.isEmpty()) {
            throw new IllegalArgumentException("Indicador de plantilla no encontrado.");
        }
        detalle.put("parametrosEntrada", dao.getIndicadorParametros(null, idIndicador));
        detalle.put("mapeoSalida", dao.getIndicadorMapeo(null, idIndicador));
        Object idSp = detalle.get("IdStoredProcedure");
        if (idSp instanceof Number) {
            int spId = ((Number) idSp).intValue();
            detalle.put("spParametrosCatalogo", dao.getStoredProcedureParametros(spId));
            detalle.put("spSalidasCatalogo", dao.getStoredProcedureSalidas(spId));
        }
        return detalle;
    }

    public Map<String, Object> crearIndicador(int idSeccion, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        requireIndicadorCatalogFields(body);
        int id = dao.addIndicadorCatalog(idSeccion, intOrNull(body.get("idStoredProcedure")),
                str(body, "clave").trim(), str(body, "nombre").trim(), str(body, "descripcion"),
                intOrNull(body.get("idCorporativo")), idUsuario, nombreUsuario);
        if (body.containsKey("tipoClave") || body.containsKey("orden") || body.containsKey("configuracionJson")
                || body.containsKey("ancho") || body.containsKey("alto") || body.containsKey("mostrarTitulo")
                || body.containsKey("mostrarLeyenda") || body.containsKey("mostrarEnReporte")) {
            saveIndicadorConfigFromBody(id, body, idUsuario, nombreUsuario);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("idIndicador", id);
        out.put("indicador", obtenerIndicador(id, intOrNull(body.get("idCorporativo"))));
        return out;
    }

    public Map<String, Object> actualizarIndicador(int idIndicador, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        int idSeccion = intVal(body.get("idSeccion"), 0);
        boolean snapshotOnly = body.containsKey("clave") && !body.containsKey("tipoClave")
                && !body.containsKey("configuracionJson");
        if (snapshotOnly) {
            requireIndicadorCatalogFields(body);
            int n = dao.updateIndicadorCatalog(idIndicador, idSeccion,
                    intOrNull(body.get("idStoredProcedure")), str(body, "clave").trim(),
                    str(body, "nombre").trim(), str(body, "descripcion"), idUsuario, nombreUsuario);
            Map<String, Object> out = new HashMap<>();
            out.put("registrosAfectados", n);
            out.put("indicador", obtenerIndicador(idIndicador, intOrNull(body.get("idCorporativo"))));
            return out;
        }
        int n = saveIndicadorConfigFromBody(idIndicador, body, idUsuario, nombreUsuario);
        if (body.containsKey("clave") || body.containsKey("nombre")) {
            requireIndicadorCatalogFields(body);
            dao.updateIndicadorCatalog(idIndicador, idSeccion, intOrNull(body.get("idStoredProcedure")),
                    str(body, "clave").trim(), str(body, "nombre").trim(), str(body, "descripcion"),
                    idUsuario, nombreUsuario);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        out.put("indicador", obtenerIndicador(idIndicador, intOrNull(body.get("idCorporativo"))));
        return out;
    }

    public Map<String, Object> eliminarIndicador(int idIndicador, Integer idCorporativo,
            int idUsuario, String nombreUsuario) {
        int n;
        if (idCorporativo != null && idCorporativo > 0) {
            n = dao.deleteIndicadorConfig(idIndicador, idCorporativo, idUsuario, nombreUsuario);
        } else {
            n = dao.deleteIndicador(idIndicador, idUsuario, nombreUsuario);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", n);
        return out;
    }

    public Map<String, Object> resetPlantillaCorporativo(List<Integer> idCorporativos,
            int idUsuario, String nombreUsuario) {
        if (idCorporativos == null || idCorporativos.isEmpty()) {
            throw new IllegalArgumentException("Se requiere idCorporativo para restablecer la plantilla corporativa.");
        }
        int total = 0;
        for (Integer idCorporativo : idCorporativos) {
            if (idCorporativo == null || idCorporativo <= 0) {
                continue;
            }
            total += dao.resetPlantillaCorporativo(idCorporativo, idUsuario, nombreUsuario);
            total += clonarPlantillaGeneralParaCorporativo(idCorporativo, idUsuario, nombreUsuario);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", total);
        out.put("idCorporativos", idCorporativos);
        return out;
    }

    public Map<String, Object> eliminarPlantillaCorporativo(List<Integer> idCorporativos,
            int idUsuario, String nombreUsuario) {
        if (idCorporativos == null || idCorporativos.isEmpty()) {
            throw new IllegalArgumentException("Se requiere idCorporativo para eliminar la plantilla corporativa.");
        }
        int total = 0;
        for (Integer idCorporativo : idCorporativos) {
            if (idCorporativo == null || idCorporativo <= 0) {
                continue;
            }
            total += dao.resetPlantillaCorporativo(idCorporativo, idUsuario, nombreUsuario);
        }
        Map<String, Object> out = new HashMap<>();
        out.put("registrosAfectados", total);
        out.put("idCorporativos", idCorporativos);
        return out;
    }

    public Map<String, Object> existePlantillaCorporativo(int idCorporativo) {
        if (idCorporativo <= 0) {
            throw new IllegalArgumentException("Se requiere idCorporativo válido.");
        }
        Map<String, Object> out = new HashMap<>();
        out.put("idCorporativo", idCorporativo);
        out.put("existe", dao.existePlantillaCorporativo(idCorporativo));
        return out;
    }

    private int clonarPlantillaGeneralParaCorporativo(int idCorporativo, int idUsuario, String nombreUsuario) {
        int total = 0;
        List<Integer> rol = Collections.singletonList(idCorporativo);
        for (Map<String, Object> seccion : dao.getSecciones(null)) {
            int idSeccion = intVal(seccion.get("CESidConfiguracionEstadisticasSeccion"), 0);
            if (idSeccion <= 0) {
                continue;
            }
            List<Map<String, Object>> indicadoresAplicables = new ArrayList<>();
            for (Map<String, Object> ind : dao.getIndicadores(null, idSeccion)) {
                int idInd = intVal(ind.get("CEIidConfiguracionEstadisticasIndicador"), 0);
                if (idInd <= 0) {
                    continue;
                }
                List<Integer> idsIndicador = dao.getIndicadorIdsCorporativosPlantilla(idInd);
                if (ConfigIndicadorJsonSupport.indicadorAplicaARol(idsIndicador, rol)) {
                    indicadoresAplicables.add(ind);
                }
            }
            if (indicadoresAplicables.isEmpty()) {
                continue;
            }
            Map<String, Object> generalSec = dao.getSeccionDetalle(idSeccion, null);
            Object textosJson = generalSec.get("TextosJson");
            total += dao.saveSeccionConfig(idSeccion, idCorporativo,
                    intVal(generalSec.get("CESOrden"), 1),
                    bool(generalSec.get("CESMostrarEnReporte"), true),
                    String.valueOf(generalSec.getOrDefault("CESTextoAdicional", "")),
                    textosJson != null ? String.valueOf(textosJson) : null,
                    idUsuario, nombreUsuario);
            for (Map<String, Object> ind : indicadoresAplicables) {
                int idInd = intVal(ind.get("CEIidConfiguracionEstadisticasIndicador"), 0);
                if (idInd <= 0) {
                    continue;
                }
                Map<String, Object> generalInd = dao.getIndicadorDetalle(null, idInd);
                String tipo = str(generalInd, "TipoIndicadorClave");
                if (TextUtil.isBlank(tipo)) {
                    tipo = "TABLA";
                }
                total += dao.saveIndicadorConfig(idInd, idCorporativo, tipo,
                        intVal(generalInd.get("Orden"), 1),
                        intOrNull(generalInd.get("Ancho")),
                        intOrNull(generalInd.get("Alto")),
                        bool(generalInd.get("MostrarTitulo"), true),
                        bool(generalInd.get("MostrarLeyenda"), true),
                        bool(generalInd.get("MostrarEnReporte"), true),
                        strOrNull(generalInd, "ConfiguracionJson"),
                        idUsuario, nombreUsuario);
            }
        }
        return total;
    }

    private List<Map<String, Object>> filtrarSeccionesPlantillaCorporativo(int idCorporativo) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (dao.existePlantillaCorporativo(idCorporativo)) {
            for (Map<String, Object> seccion : dao.getSecciones(idCorporativo)) {
                int idSeccion = intVal(seccion.get("CESidConfiguracionEstadisticasSeccion"), 0);
                if (idSeccion > 0 && dao.hasSeccionConfigCorporativo(idSeccion, idCorporativo)) {
                    out.add(seccion);
                }
            }
            return out;
        }
        List<Integer> rol = Collections.singletonList(idCorporativo);
        for (Map<String, Object> seccion : dao.getSecciones(null)) {
            int idSeccion = intVal(seccion.get("CESidConfiguracionEstadisticasSeccion"), 0);
            if (idSeccion <= 0) {
                continue;
            }
            for (Map<String, Object> ind : dao.getIndicadores(null, idSeccion)) {
                int idInd = intVal(ind.get("CEIidConfiguracionEstadisticasIndicador"), 0);
                if (idInd <= 0) {
                    continue;
                }
                List<Integer> idsIndicador = dao.getIndicadorIdsCorporativosPlantilla(idInd);
                if (ConfigIndicadorJsonSupport.indicadorAplicaARol(idsIndicador, rol)) {
                    out.add(seccion);
                    break;
                }
            }
        }
        return out;
    }

    private List<Map<String, Object>> filtrarIndicadoresPlantillaCorporativo(
            List<Map<String, Object>> indicadores, int idCorporativo) {
        if (indicadores == null || indicadores.isEmpty()) {
            return new ArrayList<>();
        }
        List<Map<String, Object>> out = new ArrayList<>();
        if (dao.existePlantillaCorporativo(idCorporativo)) {
            for (Map<String, Object> ind : indicadores) {
                int idInd = intVal(ind.get("CEIidConfiguracionEstadisticasIndicador"), 0);
                if (idInd > 0 && dao.hasIndicadorConfigCorporativo(idInd, idCorporativo)) {
                    out.add(ind);
                }
            }
            return out;
        }
        List<Integer> rol = Collections.singletonList(idCorporativo);
        for (Map<String, Object> ind : indicadores) {
            int idInd = intVal(ind.get("CEIidConfiguracionEstadisticasIndicador"), 0);
            if (idInd <= 0) {
                continue;
            }
            List<Integer> idsIndicador = dao.getIndicadorIdsCorporativosPlantilla(idInd);
            if (ConfigIndicadorJsonSupport.indicadorAplicaARol(idsIndicador, rol)) {
                out.add(ind);
            }
        }
        return out;
    }

    private void requireIndicadorCatalogFields(Map<String, Object> body) {
        if (TextUtil.isBlank(str(body, "clave").trim())) {
            throw new IllegalArgumentException("La clave del indicador es obligatoria.");
        }
        if (TextUtil.isBlank(str(body, "nombre").trim())) {
            throw new IllegalArgumentException("El nombre del indicador es obligatorio.");
        }
    }

    private int saveIndicadorConfigFromBody(int idIndicador, Map<String, Object> body,
            int idUsuario, String nombreUsuario) {
        String tipoClave = IndicadorTipoCatalog.normalize(
                TextUtil.isBlank(str(body, "tipoClave")) ? str(body, "tipoIndicadorClave") : str(body, "tipoClave"));
        if (TextUtil.isBlank(tipoClave) && body.get("idTipoIndicador") != null) {
            tipoClave = IndicadorTipoCatalog.normalize(
                    IndicadorTipoCatalog.listForApi().stream()
                            .filter(t -> intVal(t.get("ordinal"), 0) == intVal(body.get("idTipoIndicador"), 0))
                            .map(t -> String.valueOf(t.get("CETIClave")))
                            .findFirst().orElse("TABLA"));
        }
        return dao.saveIndicadorConfig(idIndicador, intOrNull(body.get("idCorporativo")),
                TextUtil.isBlank(tipoClave) ? "TABLA" : tipoClave,
                intVal(body.get("orden"), 1), intOrNull(body.get("ancho")), intOrNull(body.get("alto")),
                bool(body.get("mostrarTitulo"), true), bool(body.get("mostrarLeyenda"), true),
                bool(body.get("mostrarEnReporte"), true), strOrNull(body, "configuracionJson"),
                idUsuario, nombreUsuario);
    }

    private String str(Map<String, Object> body, String key) {
        Object v = body.get(key);
        return v != null ? String.valueOf(v) : "";
    }

    private String strOrNull(Map<String, Object> body, String key) {
        Object v = body.get(key);
        return v != null ? String.valueOf(v) : null;
    }

    private int intVal(Object value, int defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private Integer intOrNull(Object value) {
        if (value == null || TextUtil.isBlank(String.valueOf(value))) {
            return null;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    private boolean bool(Object value, boolean defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }
}
