package com.lockton.rpt.repositories.jdbc;

import com.lockton.rpt.repositories.ReporteEstadisticaSnapshotDAO;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class JDBCReporteEstadisticaSnapshotDAO implements ReporteEstadisticaSnapshotDAO {
    private static final int PROCESS_TIMEOUT_SECONDS = 900;
    private final DataSource dataSource;

    public JDBCReporteEstadisticaSnapshotDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public List<Map<String, Object>> listarHistorial(int idCorporativo) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CREPESnapshotHistorial",
                new Object[] { Integer.valueOf(idCorporativo) });
        return set(sets, 0);
    }

    @Override
    public Map<String, Object> obtenerDetalle(long idEjecucion, int idCorporativo) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CREPESnapshotDetalle",
                new Object[] { Long.valueOf(idEjecucion), Integer.valueOf(idCorporativo) });
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("ejecucion", first(sets, 0));
        out.put("pasos", set(sets, 1));
        return out;
    }

    @Override
    public Map<String, Object> obtenerProgreso(long idEjecucion, int idCorporativo) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CREPESnapshotProgreso",
                new Object[] { Long.valueOf(idEjecucion), Integer.valueOf(idCorporativo) });
        return progress(sets);
    }

    @Override
    public Map<String, Object> obtenerActivo(int idCorporativo) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CREPESnapshotActivo",
                new Object[] { Integer.valueOf(idCorporativo) });
        return progress(sets);
    }

    @Override
    public Map<String, Object> obtenerDisponibilidad(int idCorporativo, Integer idVigencia) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CREPESnapshotDisponibilidad",
                new Object[] { Integer.valueOf(idCorporativo), idVigencia });
        Map<String, Object> row = first(sets, 0);
        if (row == null) {
            throw new IllegalStateException("No fue posible validar la disponibilidad del histórico.");
        }
        return row;
    }

    @Override
    public Map<String, Object> iniciar(int idCorporativo, int idUsuario) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_IREPESnapshotIniciar",
                new Object[] { Integer.valueOf(idCorporativo), Integer.valueOf(idUsuario) });
        Map<String, Object> row = first(sets, 0);
        if (row == null) throw new IllegalStateException("No se pudo registrar la ejecución de snapshot.");
        return row;
    }

    @Override
    public void procesar(long idEjecucion) {
        call("dbo.ff_EREPEProcesarHistorico",
                new Object[] { Long.valueOf(idEjecucion), Integer.valueOf(1000) },
                PROCESS_TIMEOUT_SECONDS);
    }

    @Override
    public void marcarError(long idEjecucion, String detalleError) {
        call("dbo.ff_UREPESnapshotMarcarError",
                new Object[] { Long.valueOf(idEjecucion), detalleError });
    }

    @Override
    public List<Map<String, Object>> listarVigencias(int idCorporativo) {
        return set(call("dbo.ff_CREPESnapshotVigencias",
                new Object[] { Integer.valueOf(idCorporativo) }), 0);
    }

    @Override
    public List<Map<String, Object>> listarEmpresas(int idCorporativo, int idVigencia) {
        return set(call("dbo.ff_CREPESnapshotEmpresas",
                new Object[] { Integer.valueOf(idCorporativo), Integer.valueOf(idVigencia) }), 0);
    }

    @Override
    public Map<String, Object> consultarDatos(int idCorporativo, int idVigencia, Integer idEmpresa,
                                              String titular, int pagina, int tamanioPagina) {
        List<List<Map<String, Object>>> sets = call(
                "dbo.ff_CREPESnapshotDatosPaginados",
                new Object[] {
                        Integer.valueOf(idCorporativo), Integer.valueOf(idVigencia), idEmpresa,
                        titular, Integer.valueOf(pagina), Integer.valueOf(tamanioPagina)
                });
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("items", set(sets, 0));
        Map<String, Object> page = first(sets, 1);
        if (page != null) out.putAll(page);
        return out;
    }

    private Map<String, Object> progress(List<List<Map<String, Object>>> sets) {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("ejecucion", first(sets, 0));
        out.put("pasos", set(sets, 1));
        return out;
    }

    private Map<String, Object> first(List<List<Map<String, Object>>> sets, int index) {
        List<Map<String, Object>> rows = set(sets, index);
        return rows.isEmpty() ? null : rows.get(0);
    }

    private List<Map<String, Object>> set(List<List<Map<String, Object>>> sets, int index) {
        return sets.size() > index ? sets.get(index) : new ArrayList<Map<String, Object>>();
    }

    private List<List<Map<String, Object>>> call(String procedure, Object[] parameters) {
        return call(procedure, parameters, 0);
    }

    private List<List<Map<String, Object>>> call(String procedure, Object[] parameters, int queryTimeoutSeconds) {
        StringBuilder sql = new StringBuilder("{call ").append(procedure).append('(');
        for (int i = 0; i < parameters.length; i++) {
            if (i > 0) sql.append(',');
            sql.append('?');
        }
        sql.append(")}");

        List<List<Map<String, Object>>> resultSets = new ArrayList<List<Map<String, Object>>>();
        try (Connection connection = dataSource.getConnection();
             CallableStatement statement = connection.prepareCall(sql.toString())) {
            if (queryTimeoutSeconds > 0) statement.setQueryTimeout(queryTimeoutSeconds);

            for (int i = 0; i < parameters.length; i++) {
                Object value = parameters[i];
                if (value == null) statement.setNull(i + 1, Types.NULL);
                else statement.setObject(i + 1, value);
            }

            boolean hasResult = statement.execute();
            while (true) {
                if (hasResult) {
                    try (ResultSet rs = statement.getResultSet()) {
                        resultSets.add(readRows(rs));
                    }
                } else if (statement.getUpdateCount() == -1) {
                    break;
                }
                hasResult = statement.getMoreResults();
            }
            return resultSets;
        } catch (Exception ex) {
            throw new IllegalStateException(rootMessage(ex), ex);
        }
    }

    private List<Map<String, Object>> readRows(ResultSet rs) throws Exception {
        List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
        ResultSetMetaData md = rs.getMetaData();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<String, Object>();
            for (int i = 1; i <= md.getColumnCount(); i++) {
                row.put(md.getColumnLabel(i), rs.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }

    private String rootMessage(Throwable error) {
        Throwable current = error;
        String message = error.getMessage();
        while (current.getCause() != null) {
            current = current.getCause();
            if (current.getMessage() != null && !current.getMessage().trim().isEmpty()) {
                message = current.getMessage();
            }
        }
        return message == null ? "Error al ejecutar la operación del histórico." : message;
    }
}
