package com.lockton.rpt.repe.dto;

public class RepeReplicarRequest {
    private Integer idCorporativo;
    private Integer idUsuario;

    public Integer getIdCorporativo() { return idCorporativo; }
    public void setIdCorporativo(Integer idCorporativo) { this.idCorporativo = idCorporativo; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
}
