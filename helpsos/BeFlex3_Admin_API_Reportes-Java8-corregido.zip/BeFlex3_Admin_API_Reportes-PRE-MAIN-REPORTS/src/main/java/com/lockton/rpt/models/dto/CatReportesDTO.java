package com.lockton.rpt.models.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CatReportesDTO {
    private Integer catReportesId;
    private String catReportesNombre;
    private String catReportesDesc;
    private Integer catReportesTAId;
    private String catReportesFormato;
    private Integer esid;
    private Integer catReportesUsuarioAdd;
    private LocalDateTime catReportesFechaAdd;
    private Integer catReportesUsuarioMod;
    private LocalDateTime catReportesFechaMod;
    private Integer catTipoReporteId;
    private Integer catReportesNum;
}