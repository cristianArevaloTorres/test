package com.lockton.rpt.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lockton.rpt.models.entities.ConfiguracionReporteGen;

@Repository
public interface CfgRptGenRepository extends JpaRepository<ConfiguracionReporteGen, Long> {
    Optional<String> findCfgRptValorByCfgRptClave(String cfgRptClave);
    List<ConfiguracionReporteGen> findByCfgRptClave(String cfgRptClave);
}
