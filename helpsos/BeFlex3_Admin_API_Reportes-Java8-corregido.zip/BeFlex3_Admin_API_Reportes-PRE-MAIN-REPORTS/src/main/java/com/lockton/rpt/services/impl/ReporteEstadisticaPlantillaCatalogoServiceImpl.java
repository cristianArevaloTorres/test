package com.lockton.rpt.services.impl;

import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaAsignarIndicadoresRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaCatalogoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaDocumentoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaDuplicarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaLienzoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaOrdenIndicadoresRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaPortadaGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaSeccionGuardarRequestDTO;
import com.lockton.rpt.repositories.ReporteEstadisticaPlantillaCatalogoDAO;
import com.lockton.rpt.services.ReporteEstadisticaPlantillaCatalogoService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReporteEstadisticaPlantillaCatalogoServiceImpl
        implements ReporteEstadisticaPlantillaCatalogoService {
    private final ReporteEstadisticaPlantillaCatalogoDAO dao;

    public ReporteEstadisticaPlantillaCatalogoServiceImpl(
            ReporteEstadisticaPlantillaCatalogoDAO dao) {
        this.dao = dao;
    }

    @Override
    public List<Map<String, Object>> listarGlobal(boolean incluirBajas) {
        return dao.listar("GLOBAL", null, incluirBajas);
    }

    @Override
    public List<Map<String, Object>> listarCorporativo(
            int idCorporativo,
            boolean incluirBajas) {
        validarPositivo(idCorporativo, "corporativo");
        return dao.listar("CORPORATIVO", idCorporativo, incluirBajas);
    }

    @Override
    public Map<String, Object> catalogos() {
        return dao.catalogos();
    }

    @Override
    public Map<String, Object> validarNombre(
            String tipo,
            Integer idCorporativo,
            String nombre,
            Integer idPlantilla) {
        String normalizedType = normalizarTipo(tipo, idCorporativo);
        Integer normalizedCorporate = "GLOBAL".equals(normalizedType) ? null : idCorporativo;
        if ("CORPORATIVO".equals(normalizedType)) validarPositivo(normalizedCorporate, "corporativo");
        validarTexto(nombre, 180, "nombre", true);
        validarOpcionalPositivo(idPlantilla, "plantilla");
        return dao.validarNombre(normalizedType, normalizedCorporate, nombre.trim(), idPlantilla);
    }

    @Override
    public Map<String, Object> guardar(PlantillaCatalogoGuardarRequestDTO request) {
        requerido(request, "solicitud");
        String tipo = normalizarTipo(request.getTipo(), request.getIdCorporativo());
        Integer idCorporativo = "GLOBAL".equals(tipo) ? null : request.getIdCorporativo();
        if ("CORPORATIVO".equals(tipo)) {
            validarPositivo(idCorporativo, "corporativo");
        }
        validarPositivo(request.getIdIdioma(), "idioma");
        validarOpcionalPositivo(request.getIdTipoArchivo(), "tipo de archivo");
        validarOpcionalPositivo(request.getIdTamanoDocumento(), "tamaño de documento");
        String orientacion = normalizarOrientacionOpcional(request.getOrientacion());
        validarPositivo(request.getIdUsuario(), "usuario");
        validarTexto(request.getNombre(), 180, "nombre", true);
        validarTexto(request.getDescripcion(), 1200, "descripción", false);
        validarNombreDisponible(tipo, idCorporativo, request.getNombre(), request.getIdPlantilla());
        Map<String, Object> result = dao.guardar(
                request.getIdPlantilla(),
                tipo,
                idCorporativo,
                request.getNombre(),
                request.getDescripcion(),
                request.getIdIdioma(),
                request.getIdTipoArchivo(),
                request.getIdTamanoDocumento(),
                orientacion,
                request.getIdUsuario());
        if (request.getIdPlantilla() == null || request.getIdPlantilla().intValue() <= 0) {
            requirePositiveTemplateId(result,
                    "La base de datos no devolvió un identificador válido para la plantilla.");
        }
        return result;
    }

    @Override
    public Map<String, Object> estatus(
            int idPlantilla,
            CambioEstatusRequestDTO request) {
        validarPositivo(idPlantilla, "plantilla");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        return dao.cambiarEstatus(idPlantilla, request.getIdEstatus(), request.getIdUsuario());
    }

    @Override
    public Map<String, Object> duplicarMismoNivel(
            int idPlantillaOrigen,
            PlantillaDuplicarRequestDTO request) {
        validarPositivo(idPlantillaOrigen, "plantilla origen");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        validarTexto(request.getNombre(), 180, "nombre de la nueva plantilla", true);
        validarTexto(request.getDescripcion(), 1200, "descripción", false);
        validarOpcionalPositivo(request.getIdIdioma(), "idioma");
        validarOpcionalPositivo(request.getIdTipoArchivo(), "tipo de archivo");
        validarOpcionalPositivo(request.getIdTamanoDocumento(), "tamaño de documento");

        String tipoDestino = normalizarTipo(request.getTipoDestino(), request.getIdCorporativo());
        Integer idCorporativo = "GLOBAL".equals(tipoDestino)
                ? null
                : request.getIdCorporativo();
        if ("CORPORATIVO".equals(tipoDestino)) {
            validarPositivo(idCorporativo, "corporativo");
        }
        String orientacion = normalizarOrientacionOpcional(request.getOrientacion());
        validarNombreDisponible(tipoDestino, idCorporativo, request.getNombre(), null);

        Map<String, Object> duplicateResult = dao.duplicarMismoNivel(
                idPlantillaOrigen,
                tipoDestino,
                idCorporativo,
                request.getNombre().trim(),
                request.getIdIdioma(),
                request.getIdUsuario());
        Map<String, Object> result = duplicateResult == null
                ? new LinkedHashMap<>()
                : new LinkedHashMap<>(duplicateResult);

        Integer idPlantillaNueva = obtenerEntero(
                result,
                "IdPlantilla",
                "idPlantilla",
                "IdPlantillaDestino",
                "idPlantillaDestino");
        if (idPlantillaNueva == null || idPlantillaNueva.intValue() <= 0) {
            throw new IllegalStateException("La base de datos no devolvió un identificador válido para la plantilla duplicada.");
        }
        {
            Map<String, Object> updated = dao.guardar(
                    idPlantillaNueva,
                    tipoDestino,
                    idCorporativo,
                    request.getNombre().trim(),
                    request.getDescripcion(),
                    request.getIdIdioma(),
                    request.getIdTipoArchivo(),
                    request.getIdTamanoDocumento(),
                    orientacion,
                    request.getIdUsuario());
            if (updated != null) {
                result.putAll(updated);
            }
        }
        return result;
    }

    @Override
    public Map<String, Object> replicarGlobal(
            int idPlantillaGlobal,
            PlantillaDuplicarRequestDTO request) {
        validarPositivo(idPlantillaGlobal, "plantilla global");
        requerido(request, "solicitud");
        validarPositivo(request.getIdCorporativo(), "corporativo");
        validarPositivo(request.getIdUsuario(), "usuario");
        validarTexto(request.getNombre(), 180, "nombre de la nueva plantilla", true);
        validarTexto(request.getDescripcion(), 1200, "descripción", false);
        validarOpcionalPositivo(request.getIdIdioma(), "idioma");
        validarOpcionalPositivo(request.getIdTipoArchivo(), "tipo de archivo");
        validarOpcionalPositivo(request.getIdTamanoDocumento(), "tamaño de documento");
        String orientacion = normalizarOrientacionOpcional(request.getOrientacion());
        validarNombreDisponible("CORPORATIVO", request.getIdCorporativo(), request.getNombre(), null);

        Map<String, Object> replicateResult = dao.replicarGlobal(
                idPlantillaGlobal,
                request.getIdCorporativo(),
                request.getNombre().trim(),
                request.getIdIdioma(),
                request.getIdUsuario());
        Map<String, Object> result = replicateResult == null
                ? new LinkedHashMap<>()
                : new LinkedHashMap<>(replicateResult);

        Integer idPlantillaNueva = obtenerEntero(
                result,
                "IdPlantilla",
                "idPlantilla",
                "IdPlantillaDestino",
                "idPlantillaDestino");
        if (idPlantillaNueva == null || idPlantillaNueva.intValue() <= 0) {
            throw new IllegalStateException("La base de datos no devolvió un identificador válido para la plantilla replicada.");
        }
        {
            Map<String, Object> updated = dao.guardar(
                    idPlantillaNueva,
                    "CORPORATIVO",
                    request.getIdCorporativo(),
                    request.getNombre().trim(),
                    request.getDescripcion(),
                    request.getIdIdioma(),
                    request.getIdTipoArchivo(),
                    request.getIdTamanoDocumento(),
                    orientacion,
                    request.getIdUsuario());
            if (updated != null) {
                result.putAll(updated);
            }
        }
        return result;
    }

    @Override
    public Map<String, Object> diseno(int idPlantilla) {
        validarPositivo(idPlantilla, "plantilla");
        return dao.obtenerDiseno(idPlantilla);
    }

    @Override
    public Map<String, Object> guardarDiseno(
            int idPlantilla,
            PlantillaGuardarRequestDTO request) {
        validarPositivo(idPlantilla, "plantilla");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        requerido(request.getPlantilla(), "plantilla");
        return dao.guardarDiseno(idPlantilla, request.getPlantilla(), request.getIdUsuario());
    }

    @Override
    public Map<String, Object> guardarDocumento(
            int idPlantilla,
            PlantillaDocumentoGuardarRequestDTO request) {
        validarPositivo(idPlantilla, "plantilla");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        requerido(request.getDocumento(), "documento");
        return dao.guardarDocumento(idPlantilla, request.getDocumento(), request.getIdUsuario());
    }

    @Override
    public Map<String, Object> guardarPortada(
            int idPlantilla,
            PlantillaPortadaGuardarRequestDTO request) {
        validarPositivo(idPlantilla, "plantilla");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        requerido(request.getPortada(), "portada");
        return dao.guardarPortada(idPlantilla, request.getPortada(), request.getIdUsuario());
    }

    @Override
    public Map<String, Object> guardarSeccion(
            int idPlantilla,
            Integer idSeccion,
            PlantillaSeccionGuardarRequestDTO request) {
        validarPositivo(idPlantilla, "plantilla");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        requerido(request.getSeccion(), "sección");
        return dao.guardarSeccion(idPlantilla, idSeccion, request.getSeccion(), request.getIdUsuario());
    }

    @Override
    public Map<String, Object> guardarLienzo(
            int idPlantilla,
            int idSeccion,
            PlantillaLienzoGuardarRequestDTO request) {
        validarPositivo(idPlantilla, "plantilla");
        validarPositivo(idSeccion, "sección");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        requerido(request.getLienzo(), "lienzo");
        return dao.guardarLienzo(idPlantilla, idSeccion, request.getLienzo(), request.getIdUsuario());
    }

    @Override
    public Map<String, Object> asignables(int idPlantilla, Integer idSeccion) {
        validarPositivo(idPlantilla, "plantilla");
        return dao.asignables(idPlantilla, idSeccion);
    }

    @Override
    public Map<String, Object> asignar(
            int idSeccion,
            PlantillaAsignarIndicadoresRequestDTO request) {
        validarPositivo(idSeccion, "sección");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        if (request.getIdsIndicador() == null || request.getIdsIndicador().isEmpty()) {
            throw new IllegalArgumentException("Selecciona al menos un indicador.");
        }
        List<Integer> ids = new ArrayList<>(new LinkedHashSet<>(request.getIdsIndicador()));
        ids.removeIf(value -> value == null || value <= 0);
        if (ids.isEmpty()) {
            throw new IllegalArgumentException("La selección de indicadores no es válida.");
        }
        return dao.asignar(idSeccion, ids, request.getIdUsuario());
    }

    @Override
    public Map<String, Object> ordenarIndicadores(
            int idSeccion,
            PlantillaOrdenIndicadoresRequestDTO request) {
        validarPositivo(idSeccion, "sección");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        if (request.getIdsSeccionIndicador() == null || request.getIdsSeccionIndicador().isEmpty()) {
            throw new IllegalArgumentException("El orden de indicadores es requerido.");
        }
        List<Integer> ids = new ArrayList<Integer>(new LinkedHashSet<Integer>(request.getIdsSeccionIndicador()));
        ids.removeIf(value -> value == null || value.intValue() <= 0);
        if (ids.size() != request.getIdsSeccionIndicador().size()) {
            throw new IllegalArgumentException("El orden contiene asignaciones inválidas o repetidas.");
        }
        return dao.ordenarIndicadores(idSeccion, ids, request.getIdUsuario().intValue());
    }

    @Override
    public Map<String, Object> estatusAsignacion(
            int idSeccionIndicador,
            CambioEstatusRequestDTO request) {
        validarPositivo(idSeccionIndicador, "asignación");
        requerido(request, "solicitud");
        validarPositivo(request.getIdUsuario(), "usuario");
        return dao.cambiarEstatusAsignacion(
                idSeccionIndicador,
                request.getIdEstatus(),
                request.getIdUsuario());
    }



    private int requirePositiveTemplateId(Map<String, Object> result, String message) {
        Integer id = obtenerEntero(result, "IdPlantilla", "idPlantilla", "IdPlantillaDestino", "idPlantillaDestino");
        if (id == null || id.intValue() <= 0) {
            throw new IllegalStateException(message);
        }
        return id.intValue();
    }

    private void validarNombreDisponible(
            String tipo,
            Integer idCorporativo,
            String nombre,
            Integer idPlantilla) {
        Map<String, Object> result = dao.validarNombre(tipo, idCorporativo, nombre.trim(), idPlantilla);
        Object raw = result == null ? null : result.get("Disponible");
        boolean available = raw instanceof Boolean
                ? (Boolean) raw
                : raw != null && ("1".equals(String.valueOf(raw)) || "true".equalsIgnoreCase(String.valueOf(raw)));
        if (!available) {
            Object message = result == null ? null : result.get("Mensaje");
            throw new IllegalArgumentException(message == null
                    ? "Ya existe una plantilla activa con el mismo nombre dentro de este alcance."
                    : String.valueOf(message));
        }
    }

    private void validarTexto(String value, int maxLength, String field, boolean required) {
        String normalized = value == null ? "" : value.trim();
        if (required && normalized.isEmpty()) {
            throw new IllegalArgumentException("El " + field + " es requerido.");
        }
        if (!normalized.isEmpty() && normalized.length() > maxLength) {
            throw new IllegalArgumentException(
                    "El " + field + " no puede exceder " + maxLength + " caracteres.");
        }
    }

    private String normalizarTipo(String tipo, Integer idCorporativo) {
        String value = tipo == null ? "" : tipo.trim().toUpperCase();
        if (value.isEmpty()) {
            value = idCorporativo != null && idCorporativo > 0
                    ? "CORPORATIVO"
                    : "GLOBAL";
        }
        if (!"GLOBAL".equals(value) && !"CORPORATIVO".equals(value)) {
            throw new IllegalArgumentException("El tipo debe ser GLOBAL o CORPORATIVO.");
        }
        return value;
    }


    private String normalizarOrientacionOpcional(String orientacion) {
        String value = orientacion == null ? "" : orientacion.trim().toUpperCase();
        if (value.isEmpty()) {
            return null;
        }
        if (!"HORIZONTAL".equals(value) && !"VERTICAL".equals(value)) {
            throw new IllegalArgumentException("La orientación debe ser HORIZONTAL o VERTICAL.");
        }
        return value;
    }

    private void validarOpcionalPositivo(Integer value, String field) {
        if (value != null && value <= 0) {
            throw new IllegalArgumentException("El " + field + " debe ser mayor a cero.");
        }
    }

    private Integer obtenerEntero(Map<String, Object> source, String... keys) {
        if (source == null || keys == null) {
            return null;
        }
        for (String key : keys) {
            Object value = source.get(key);
            if (value == null || String.valueOf(value).trim().isEmpty()) {
                continue;
            }
            if (value instanceof Number) {
                return ((Number) value).intValue();
            }
            try {
                return Integer.valueOf(String.valueOf(value));
            } catch (NumberFormatException ignored) {
                // Se intenta la siguiente variante de nombre.
            }
        }
        return null;
    }

    private void validarPositivo(Integer value, String field) {
        if (value == null || value <= 0) {
            throw new IllegalArgumentException("El " + field + " es requerido.");
        }
    }

    private void requerido(Object value, String field) {
        if (value == null) {
            throw new IllegalArgumentException("El nodo " + field + " es requerido.");
        }
    }
}
