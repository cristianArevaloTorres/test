package com.lockton.rpt.enumeradores;

/**
 * Catálogo en código que relaciona cada reporte (CatRptId de bf_CatalogoReporteGen)
 * con su idTipoNotificacion en el catálogo de notificaciones de WSBeFlex.
 *
 * Para agregar un reporte nuevo basta con añadir una entrada aquí:
 *   NUEVO_REPORTE(idReporte, idTipoNotificacion)
 */
public enum CatTipoNotificacionReporte {
    DOCUMENTOS_PERSONALIZADOS(1, 57),
    POBLACION(2, 58),
    SABANA_BENEFICIOS(3, 59),
    COMPARATIVO_COSTOS_CREDITOS(4, 60),
    BITACORA_NAVEGACION(5, 61),
    ACCESOS_SOLICITUDES(6, 62),
    ACCESOS_BEMOBILE(7, 63),
    CAMBIOS_CALIFICADOS(8, 64),
    CASA_HABITACION(9, 65),
    COMPENSACION_EMPLEADO(10, 66),
    COBRANZA(11, 67);

    private final int idReporte;
    private final int idTipoNotificacion;

    CatTipoNotificacionReporte(int idReporte, int idTipoNotificacion) {
        this.idReporte = idReporte;
        this.idTipoNotificacion = idTipoNotificacion;
    }

    public int getIdReporte() {
        return idReporte;
    }

    public int getIdTipoNotificacion() {
        return idTipoNotificacion;
    }

    /**
     * Devuelve el idTipoNotificacion para un reporte dado,
     * o null si el reporte no está mapeado (el back destino lo tratará como "Sin mapeo").
     */
    public static Integer resolverIdTipoNotificacion(int idReporte) {
        for (CatTipoNotificacionReporte tipo : values()) {
            if (tipo.idReporte == idReporte) {
                return tipo.idTipoNotificacion;
            }
        }
        return null;
    }
}
