package com.lockton.rpt.services;

public interface CryptoBeflexService {
    String desencriptar(String cipherText);
    String encriptar(String plainText);
    String generateToken(String subject);
    boolean validateToken(String token);
}
