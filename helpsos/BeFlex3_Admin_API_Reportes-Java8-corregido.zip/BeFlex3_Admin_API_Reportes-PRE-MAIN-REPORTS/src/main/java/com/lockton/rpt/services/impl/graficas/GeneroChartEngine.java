package com.lockton.rpt.services.impl.graficas;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import org.springframework.stereotype.Component;

@Component
public class GeneroChartEngine {

    private static final Color COLOR_HOMBRES = new Color(0x2E, 0x9E, 0x5B);
    private static final Color COLOR_MUJERES = new Color(0xE8, 0xB9, 0x23);
    private static final Color OUTLINE = new Color(0x1a, 0x1a, 0x1a);

    public byte[] render(int hombres, int mujeres) throws IOException {
        int total = hombres + mujeres;
        double pctHombres = total == 0 ? 0.0 : hombres * 100.0 / total;
        double pctMujeres = total == 0 ? 0.0 : mujeres * 100.0 / total;

        int width = 1200;
        int height = 750;
        BufferedImage image = ChartSupport.blankImage(width, height);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        double scaleX = width / 10.0;
        double scaleY = height / 10.0;
        g.scale(scaleX, scaleY);

        drawRow(g, ChartSupport.formatCount(hombres) + " Hombres", pctHombres, COLOR_HOMBRES,
                maleSilhouette(), 7.0);
        drawRow(g, ChartSupport.formatCount(mujeres) + " Mujeres", pctMujeres, COLOR_MUJERES,
                femaleSilhouette(), 3.0);

        g.dispose();
        return ChartSupport.pngFromImage(image);
    }

    public String renderBase64(int hombres, int mujeres) throws IOException {
        return java.util.Base64.getEncoder().encodeToString(render(hombres, mujeres));
    }

    private void drawRow(Graphics2D g, String label, double pct, Color color, GeneralPath basePath,
            double yCenter) {
        g.setFont(new Font("SansSerif", Font.BOLD, 18));
        g.setColor(OUTLINE);
        g.drawString(label, 0.6f, (float) (yCenter + 0.9));

        g.setStroke(new BasicStroke(0.08f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER));
        g.setColor(color);
        g.draw(new Line2D.Double(0.6, yCenter + 0.35, 3.8, yCenter + 0.35));

        g.setFont(new Font("SansSerif", Font.BOLD, 32));
        g.setColor(OUTLINE);
        g.drawString(String.format("%.0f%%", pct), 0.6f, (float) (yCenter - 0.5));

        GeneralPath scaled = scaleSilhouette(basePath, 7.2, yCenter, 3.6);
        drawFilledSilhouette(g, scaled, pct, color);
    }

    private GeneralPath scaleSilhouette(GeneralPath path, double centerX, double centerY, double height) {
        double width = height * 0.55;
        double x0 = centerX - width / 2;
        double y0 = centerY - height / 2;
        double x1 = centerX + width / 2;
        double y1 = centerY + height / 2;

        AffineTransform transform = new AffineTransform();
        transform.translate(x0, y0);
        transform.scale(x1 - x0, y1 - y0);
        return new GeneralPath(transform.createTransformedShape(path));
    }

    private void drawFilledSilhouette(Graphics2D g, GeneralPath silhouette, double fillPct, Color fillColor) {
        double pct = Math.max(0, Math.min(100, fillPct));
        java.awt.Shape oldClip = g.getClip();

        g.setStroke(new BasicStroke(0.025f));
        g.setColor(Color.WHITE);
        g.fill(silhouette);
        g.setColor(OUTLINE);
        g.draw(silhouette);

        if (pct <= 0) {
            return;
        }

        Rectangle2D bounds = silhouette.getBounds2D();
        double fillHeight = bounds.getHeight() * (pct / 100.0);
        Rectangle2D fillRect = new Rectangle2D.Double(
                bounds.getX() - 0.05,
                bounds.getMaxY() - fillHeight,
                bounds.getWidth() + 0.10,
                fillHeight);

        g.clip(silhouette);
        g.setColor(fillColor);
        g.fill(fillRect);
        g.setClip(oldClip);

        g.setColor(OUTLINE);
        g.draw(silhouette);
    }

    private GeneralPath maleSilhouette() {
        double[][] points = {
                { 0.50, 0.98 }, { 0.62, 0.90 }, { 0.62, 0.82 }, { 0.78, 0.70 }, { 0.72, 0.64 },
                { 0.58, 0.74 }, { 0.58, 0.52 }, { 0.72, 0.40 }, { 0.72, 0.02 }, { 0.58, 0.02 },
                { 0.50, 0.22 }, { 0.42, 0.02 }, { 0.28, 0.02 }, { 0.28, 0.40 }, { 0.42, 0.52 },
                { 0.42, 0.74 }, { 0.28, 0.64 }, { 0.22, 0.70 }, { 0.38, 0.82 }, { 0.38, 0.90 },
                { 0.50, 0.98 }
        };
        return pathFromPoints(points);
    }

    private GeneralPath femaleSilhouette() {
        double[][] points = {
                { 0.50, 0.98 }, { 0.62, 0.90 }, { 0.62, 0.82 }, { 0.78, 0.70 }, { 0.72, 0.64 },
                { 0.58, 0.74 }, { 0.58, 0.56 }, { 0.82, 0.30 }, { 0.50, 0.02 }, { 0.18, 0.30 },
                { 0.42, 0.56 }, { 0.42, 0.74 }, { 0.28, 0.64 }, { 0.22, 0.70 }, { 0.38, 0.82 },
                { 0.38, 0.90 }, { 0.50, 0.98 }
        };
        return pathFromPoints(points);
    }

    private GeneralPath pathFromPoints(double[][] points) {
        GeneralPath path = new GeneralPath();
        path.moveTo((float) points[0][0], (float) points[0][1]);
        for (int i = 1; i < points.length; i++) {
            path.lineTo((float) points[i][0], (float) points[i][1]);
        }
        path.closePath();
        return path;
    }
}
