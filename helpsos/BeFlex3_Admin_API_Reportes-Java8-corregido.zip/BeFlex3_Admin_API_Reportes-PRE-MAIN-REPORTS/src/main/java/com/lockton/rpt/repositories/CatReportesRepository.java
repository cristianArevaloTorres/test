package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lockton.rpt.models.entities.CatReportes;
import java.util.List;


@Repository
public interface CatReportesRepository extends JpaRepository<CatReportes, Integer> {
    List<CatReportes> findBycatReportesNombre(String nombreReporte);
}
