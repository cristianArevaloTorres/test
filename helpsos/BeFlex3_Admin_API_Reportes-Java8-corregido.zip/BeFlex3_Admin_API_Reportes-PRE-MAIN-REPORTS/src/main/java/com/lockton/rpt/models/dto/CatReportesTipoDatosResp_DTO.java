package com.lockton.rpt.models.dto;

public class CatReportesTipoDatosResp_DTO {
    public int catReportesTipoDatoId;	
    public String catReportesTipoDatoNombre;
    
    public int getCatReportesTipoDatoId() {
        return catReportesTipoDatoId;
    }
    public void setCatReportesTipoDatoId(int catReportesTipoDatoId) {
        this.catReportesTipoDatoId = catReportesTipoDatoId;
    }
    public String getCatReportesTipoDatoNombre() {
        return catReportesTipoDatoNombre;
    }
    public void setCatReportesTipoDatoNombre(String catReportesTipoDatoNombre) {
        this.catReportesTipoDatoNombre = catReportesTipoDatoNombre;
    }
}
