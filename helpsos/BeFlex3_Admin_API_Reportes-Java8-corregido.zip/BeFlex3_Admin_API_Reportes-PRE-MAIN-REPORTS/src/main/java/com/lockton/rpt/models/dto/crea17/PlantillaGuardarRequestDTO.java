package com.lockton.rpt.models.dto.crea17;

import java.util.Map;

public class PlantillaGuardarRequestDTO {
    private Integer idUsuario;
    private Map<String, Object> plantilla;

    public PlantillaGuardarRequestDTO() {}

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
    public Map<String, Object> getPlantilla() { return plantilla; }
    public void setPlantilla(Map<String, Object> plantilla) { this.plantilla = plantilla; }
}
