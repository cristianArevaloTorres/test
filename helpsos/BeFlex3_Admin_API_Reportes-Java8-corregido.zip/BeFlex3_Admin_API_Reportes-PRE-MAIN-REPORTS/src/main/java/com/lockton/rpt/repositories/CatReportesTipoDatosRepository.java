package com.lockton.rpt.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.lockton.rpt.models.entities.CatReportesTipoDatos;

@Repository
public interface CatReportesTipoDatosRepository extends JpaRepository<CatReportesTipoDatos, Integer> {

}
