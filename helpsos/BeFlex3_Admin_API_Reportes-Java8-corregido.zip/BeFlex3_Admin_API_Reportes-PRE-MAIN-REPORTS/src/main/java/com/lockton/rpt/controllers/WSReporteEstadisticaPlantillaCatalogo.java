package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.crea17.ApiResponseDTO;
import com.lockton.rpt.models.dto.crea17.CambioEstatusRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaAsignarIndicadoresRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaCatalogoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaDocumentoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaDuplicarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaLienzoGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaOrdenIndicadoresRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaPortadaGuardarRequestDTO;
import com.lockton.rpt.models.dto.crea17.PlantillaSeccionGuardarRequestDTO;
import com.lockton.rpt.services.ReporteEstadisticaPlantillaCatalogoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/beflex/reporte-estadisticas/crea17/plantillas-catalogo")
public class WSReporteEstadisticaPlantillaCatalogo {
    private final ReporteEstadisticaPlantillaCatalogoService service;

    public WSReporteEstadisticaPlantillaCatalogo(
            ReporteEstadisticaPlantillaCatalogoService service) {
        this.service = service;
    }

    @GetMapping("/catalogos")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> catalogos() {
        return ok("RPE-PLTC-CAT", "Catálogos consultados.", service.catalogos());
    }

    @GetMapping("/global")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> listarGlobal(
            @RequestParam(defaultValue = "true") boolean incluirBajas) {
        return ok("RPE-PLTG-LIST", "Plantillas globales consultadas.",
                service.listarGlobal(incluirBajas));
    }

    @GetMapping("/corporativo/{idCorporativo}")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> listarCorporativo(
            @PathVariable int idCorporativo,
            @RequestParam(defaultValue = "true") boolean incluirBajas) {
        return ok("RPE-PLTC-LIST", "Plantillas corporativas consultadas.",
                service.listarCorporativo(idCorporativo, incluirBajas));
    }

    @GetMapping("/validar-nombre")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> validarNombre(
            @RequestParam String tipo,
            @RequestParam(required = false) Integer idCorporativo,
            @RequestParam String nombre,
            @RequestParam(required = false) Integer idPlantilla) {
        return ok("RPE-PLTC-NAME", "Nombre validado.",
                service.validarNombre(tipo, idCorporativo, nombre, idPlantilla));
    }

    @PostMapping
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardar(
            @RequestBody PlantillaCatalogoGuardarRequestDTO request) {
        return ok("RPE-PLTC-SAVE", "Plantilla registrada.", service.guardar(request));
    }

    @PutMapping("/{idPlantilla}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> actualizar(
            @PathVariable int idPlantilla,
            @RequestBody PlantillaCatalogoGuardarRequestDTO request) {
        request.setIdPlantilla(idPlantilla);
        return ok("RPE-PLTC-UPD", "Plantilla actualizada.", service.guardar(request));
    }

    @PutMapping("/{idPlantilla}/estatus")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatus(
            @PathVariable int idPlantilla,
            @RequestBody CambioEstatusRequestDTO request) {
        return ok("RPE-PLTC-STATUS", "Estatus actualizado.",
                service.estatus(idPlantilla, request));
    }

    @PostMapping("/{idPlantillaOrigen}/duplicar")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> duplicar(
            @PathVariable int idPlantillaOrigen,
            @RequestBody PlantillaDuplicarRequestDTO request) {
        return ok("RPE-PLTC-DUP", "Plantilla duplicada.",
                service.duplicarMismoNivel(idPlantillaOrigen, request));
    }

    @PostMapping("/global/{idPlantillaGlobal}/replicar")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> replicarGlobal(
            @PathVariable int idPlantillaGlobal,
            @RequestBody PlantillaDuplicarRequestDTO request) {
        request.setTipoDestino("CORPORATIVO");
        return ok("RPE-PLTC-REP", "Plantilla global replicada.",
                service.replicarGlobal(idPlantillaGlobal, request));
    }

    @GetMapping("/{idPlantilla}/diseno")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> obtenerDiseno(
            @PathVariable int idPlantilla) {
        return ok("RPE-PLTC-DES", "Diseño consultado.", service.diseno(idPlantilla));
    }

    @PutMapping("/{idPlantilla}/diseno")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardarDiseno(
            @PathVariable int idPlantilla,
            @RequestBody PlantillaGuardarRequestDTO request) {
        return ok("RPE-PLTC-DES-SAVE", "Diseño guardado.",
                service.guardarDiseno(idPlantilla, request));
    }

    @GetMapping("/{idPlantilla}/indicadores")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> indicadoresAsignables(
            @PathVariable int idPlantilla,
            @RequestParam(required = false) Integer idSeccion) {
        return ok("RPE-PLTC-IND", "Indicadores consultados.",
                service.asignables(idPlantilla, idSeccion));
    }

    @PostMapping("/secciones/{idSeccion}/indicadores")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> asignarIndicadores(
            @PathVariable int idSeccion,
            @RequestBody PlantillaAsignarIndicadoresRequestDTO request) {
        return ok("RPE-PLTC-ASG", "Indicadores asignados.",
                service.asignar(idSeccion, request));
    }

    @PutMapping("/secciones/{idSeccion}/indicadores/orden")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> ordenarIndicadores(
            @PathVariable int idSeccion,
            @RequestBody PlantillaOrdenIndicadoresRequestDTO request) {
        return ok("RPE-PLTC-ASG-ORDER", "Orden de indicadores actualizado.",
                service.ordenarIndicadores(idSeccion, request));
    }

    @PutMapping("/secciones/indicadores/{idAsignacion}/estatus")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> cambiarEstatusAsignacion(
            @PathVariable int idAsignacion,
            @RequestBody CambioEstatusRequestDTO request) {
        return ok("RPE-PLTC-ASG-STATUS", "Asignación actualizada.",
                service.estatusAsignacion(idAsignacion, request));
    }

    @PutMapping("/{idPlantilla}/documento")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardarDocumento(
            @PathVariable int idPlantilla,
            @RequestBody PlantillaDocumentoGuardarRequestDTO request) {
        return ok("RPE-PLTC-DOC", "Documento guardado.",
                service.guardarDocumento(idPlantilla, request));
    }

    @PutMapping("/{idPlantilla}/portada")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardarPortada(
            @PathVariable int idPlantilla,
            @RequestBody PlantillaPortadaGuardarRequestDTO request) {
        return ok("RPE-PLTC-COVER", "Portada guardada.",
                service.guardarPortada(idPlantilla, request));
    }

    @PutMapping("/{idPlantilla}/secciones")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> crearSeccion(
            @PathVariable int idPlantilla,
            @RequestBody PlantillaSeccionGuardarRequestDTO request) {
        return ok("RPE-PLTC-SEC", "Sección guardada.",
                service.guardarSeccion(idPlantilla, null, request));
    }

    @PutMapping("/{idPlantilla}/secciones/{idSeccion}")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardarSeccion(
            @PathVariable int idPlantilla,
            @PathVariable int idSeccion,
            @RequestBody PlantillaSeccionGuardarRequestDTO request) {
        return ok("RPE-PLTC-SEC", "Sección guardada.",
                service.guardarSeccion(idPlantilla, idSeccion, request));
    }

    @PutMapping("/{idPlantilla}/secciones/{idSeccion}/lienzo")
    public ResponseEntity<ApiResponseDTO<Map<String, Object>>> guardarLienzo(
            @PathVariable int idPlantilla,
            @PathVariable int idSeccion,
            @RequestBody PlantillaLienzoGuardarRequestDTO request) {
        return ok("RPE-PLTC-CANVAS", "Lienzo guardado.",
                service.guardarLienzo(idPlantilla, idSeccion, request));
    }

    private <T> ResponseEntity<ApiResponseDTO<T>> ok(String code, String message, T data) {
        return ResponseEntity.ok(ApiResponseDTO.ok(code, message, data));
    }
}
