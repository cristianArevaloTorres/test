package com.lockton.rpt.models.entities;


import lombok.Data;

import javax.persistence.*;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "bf_CatReportesSP")
public class CatReportesSP {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "catReportesSPId")
    private Integer catReportesSPId;

    @Column(name = "catReportesId", nullable = false)
    private Integer catReportesId;

    @Column(name = "catReportesSPNombre", length = 50, nullable = false)
    private String catReportesSPNombre;

    @Column(name = "catReportesSPOrden", nullable = false)
    private Integer catReportesSPOrden;

    @Column(name = "catReportesSPDesc", length = 150, nullable = false)
    private String catReportesSPDesc;

    @Column(name = "ESid", nullable = false)
    private Integer Esid;

    @Column(name = "catReportesSPUsuarioAdd", nullable = true)
    private Integer catReportesSPUsuarioAdd;

    @Column(name = "catReportesSPFechaAdd", nullable = false)
    private LocalDateTime catReportesSPFechaAdd;

    @Column(name = "catReportesSPUsuarioMod", nullable = true)
    private Integer catReportesSPUsuarioMod;

    @Column(name = "catReportesSPFechaMod", nullable = true)
    private LocalDateTime catReportesSPFechaMod;

    @Column(name = "catReportesSPUsuarioDel", nullable = true)
    private Integer catReportesSPUsuarioDel;

    @Column(name = "catReportesSPFechaDel", nullable = true)
    private LocalDateTime catReportesSPFechaDel;
}