package com.lockton.rpt.repositories;

import java.util.List;
import java.util.Map;

public interface ReporteEstadisticaSnapshotDAO {
    List<Map<String, Object>> listarHistorial(int idCorporativo);
    Map<String, Object> obtenerDetalle(long idEjecucion, int idCorporativo);
    Map<String, Object> obtenerProgreso(long idEjecucion, int idCorporativo);
    Map<String, Object> obtenerActivo(int idCorporativo);
    Map<String, Object> obtenerDisponibilidad(int idCorporativo, Integer idVigencia);
    Map<String, Object> iniciar(int idCorporativo, int idUsuario);
    void procesar(long idEjecucion);
    void marcarError(long idEjecucion, String detalleError);
    List<Map<String, Object>> listarVigencias(int idCorporativo);
    List<Map<String, Object>> listarEmpresas(int idCorporativo, int idVigencia);
    Map<String, Object> consultarDatos(int idCorporativo, int idVigencia, Integer idEmpresa,
                                      String titular, int pagina, int tamanioPagina);
}
