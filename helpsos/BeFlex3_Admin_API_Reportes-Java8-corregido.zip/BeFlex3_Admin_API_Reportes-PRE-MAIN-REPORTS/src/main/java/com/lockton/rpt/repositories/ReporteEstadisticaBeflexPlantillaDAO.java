package com.lockton.rpt.repositories;

import java.util.List;
import java.util.Map;

/**
 * Acceso aislado al runtime CREA17 consumido por beFlex.
 */
public interface ReporteEstadisticaBeflexPlantillaDAO {
    List<Map<String, Object>> listarPlantillas(
            int idCorporativo,
            Integer idIdioma,
            boolean soloPdf);

    Map<String, Object> obtenerContexto(int idCorporativo);

    List<Map<String, Object>> listarFiltros(int idCorporativo);

    Map<String, Object> obtenerConfiguracion(
            int idCorporativo,
            int idPlantilla);

    List<Map<String, Object>> obtenerOpcionesFiltro(
            int idCorporativo,
            int idVigencia,
            String clave,
            Map<String, Object> filtros);

    Map<String, Object> consultarPlantilla(
            String uidSolicitud,
            int idCorporativo,
            int idVigencia,
            int idPlantilla,
            int idUsuario,
            Map<String, Object> filtros);

    Map<String, Object> obtenerEjecucion(String uidSolicitud);

    Map<String, Object> obtenerDatosFuente(
            int idCorporativo,
            int idPlantilla,
            int idStoredProcedure,
            int maxFilas);
}
