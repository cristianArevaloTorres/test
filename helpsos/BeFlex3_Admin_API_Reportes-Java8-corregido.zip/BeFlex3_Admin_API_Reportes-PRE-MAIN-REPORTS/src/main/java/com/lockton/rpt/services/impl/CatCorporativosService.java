package com.lockton.rpt.services.impl;

import java.util.List;
import java.util.Map;

import com.lockton.rpt.repositories.CatCorporativosDAO;

import org.springframework.stereotype.Service;

@Service
public class CatCorporativosService {

    private final CatCorporativosDAO dao;

    public CatCorporativosService(CatCorporativosDAO dao) {
        this.dao = dao;
    }

    public List<Map<String, Object>> listarCorporativos() {
        return dao.listarCorporativosActivos();
    }
}
