package com.lockton.rpt.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.LinkedCaseInsensitiveMap;

public class SabanaBeneficiosLegacyServiceTest {

    @Test
    public void aplicaFoliosEnOrdenLegacySoloEnGmmYOpcionales() {
        JdbcTemplateStub jdbc = new JdbcTemplateStub();
        jdbc.parametros.put(141, 20);
        jdbc.parametros.put(142, 30);
        jdbc.folios.add(folio(101, 10, "MEM-101"));
        SabanaBeneficiosLegacyService service =
                new SabanaBeneficiosLegacyService(jdbc);

        ArrayList<LinkedCaseInsensitiveMap<?>> gmm = rows(
                row("grupo", "GMM", "IDEmp", 101, "POidPlan", 10,
                        "EMNumeroEmpleado", "000101", "EMIdParentesco", 1),
                row("grupo", "GMM", "IDEmp", 101, "POidPlan", 10,
                        "EMNumeroEmpleado", "000101", "EMIdParentesco", 1),
                row("grupo", "GMM", "IDEmp", 201, "POidPlan", 20,
                        "EMNumeroEmpleado", "000201", "EMIdParentesco", 1),
                row("grupo", "GMM", "IDEmp", 201, "POidPlan", 20,
                        "EMNumeroEmpleado", "000201", "EMIdParentesco", 2));
        ArrayList<LinkedCaseInsensitiveMap<?>> vida = rows(
                row("grupo", "Vida", "Id", 301, "POidPlan", 30,
                        "EMNumeroEmpleado", "000301", "EMIdParentesco", 1));
        LinkedCaseInsensitiveMap<Object> titular =
                row("grupo", "OPC", "Id", 301, "POidPlan", 30,
                        "EMNumeroEmpleado", "000301", "EMIdParentesco", 1);
        LinkedCaseInsensitiveMap<Object> dependienteTres =
                row("grupo", "OPC", "Id", 303, "POidPlan", 30,
                        "EMNumeroEmpleado", "000301", "EMIdParentesco", 3);
        LinkedCaseInsensitiveMap<Object> dependienteDos =
                row("grupo", "OPC", "Id", 302, "POidPlan", 30,
                        "EMNumeroEmpleado", "000301", "EMIdParentesco", 2);
        ArrayList<LinkedCaseInsensitiveMap<?>> opc =
                rows(titular, dependienteTres, dependienteDos);

        Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("idEmpresa", 186);
        service.homologar(Arrays.asList(gmm, vida, opc), parametros);

        assertEquals("MEM-101", gmm.get(0).get("Folio"));
        assertEquals("", gmm.get(1).get("Folio"));
        assertEquals("BIMBO-000201", gmm.get(2).get("Folio"));
        assertEquals("", gmm.get(3).get("Folio"));
        assertFalse(vida.get(0).containsKey("Folio"));
        assertEquals("000301-1", titular.get("Folio"));
        assertEquals("000301-2", dependienteDos.get("Folio"));
        assertEquals("000301-3", dependienteTres.get("Folio"));
    }

    @Test
    public void dentegraSinTitularConservaElFolioBase() {
        JdbcTemplateStub jdbc = new JdbcTemplateStub();
        jdbc.parametros.put(142, 30);
        jdbc.folios.add(folio(401, 30, "BASE-401"));
        SabanaBeneficiosLegacyService service =
                new SabanaBeneficiosLegacyService(jdbc);

        ArrayList<LinkedCaseInsensitiveMap<?>> opc = rows(
                row("grupo", "OPC", "Id", 401, "POidPlan", 30,
                        "EMNumeroEmpleado", "000400", "EMIdParentesco", 2),
                row("grupo", "OPC", "Id", 402, "POidPlan", 30,
                        "EMNumeroEmpleado", "000400", "EMIdParentesco", 3));

        Map<String, Object> parametros =
                Collections.<String, Object>singletonMap("idEmpresa", 186);
        service.homologar(
                Collections.singletonList(opc), parametros);

        assertEquals("BASE-401", opc.get(0).get("Folio"));
        assertEquals("", opc.get(1).get("Folio"));
    }

    @Test
    public void noUsaLaPosicionParaConfundirMascotasConGmm() {
        SabanaBeneficiosLegacyService service =
                new SabanaBeneficiosLegacyService(new JdbcTemplateStub());
        ArrayList<LinkedCaseInsensitiveMap<?>> mascotas = rows(
                row("grupo", "Mascotas", "Id", 1, "POidPlan", 10,
                        "EMNumeroEmpleado", "1", "PONombre", "Mascotas"));

        service.homologar(Collections.singletonList(mascotas),
                Collections.<String, Object>singletonMap("idEmpresa", 186));

        assertFalse(mascotas.get(0).containsKey("Folio"));
    }

    private static LinkedCaseInsensitiveMap<Object> row(Object... values) {
        LinkedCaseInsensitiveMap<Object> row =
                new LinkedCaseInsensitiveMap<>();
        for (int i = 0; i < values.length; i += 2) {
            row.put(String.valueOf(values[i]), values[i + 1]);
        }
        return row;
    }

    @SafeVarargs
    private static ArrayList<LinkedCaseInsensitiveMap<?>> rows(
            LinkedCaseInsensitiveMap<Object>... rows) {
        return new ArrayList<LinkedCaseInsensitiveMap<?>>(
                Arrays.<LinkedCaseInsensitiveMap<?>>asList(rows));
    }

    private static Map<String, Object> folio(
            int empleado, int plan, String valor) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("IdEmpleado", empleado);
        row.put("IdPlan", plan);
        row.put("PFFolio", valor);
        return row;
    }

    private static final class JdbcTemplateStub extends JdbcTemplate {
        private final Map<Integer, Integer> parametros = new LinkedHashMap<>();
        private final List<Map<String, Object>> folios = new ArrayList<>();

        @Override
        public List<Map<String, Object>> queryForList(
                String sql, Object... args) {
            if (sql.contains("ff_GetParametro")) {
                int parametro = ((Number) args[1]).intValue();
                Integer valor = parametros.get(parametro);
                if (valor == null) return Collections.emptyList();
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("paValor", valor);
                return Collections.singletonList(row);
            }
            if (sql.contains("bf_BuscaFoliosPorIdsEmpleado")) {
                return folios;
            }
            if (sql.contains("bf_SolicitudFolio")) {
                return folios;
            }
            return Collections.emptyList();
        }
    }
}
