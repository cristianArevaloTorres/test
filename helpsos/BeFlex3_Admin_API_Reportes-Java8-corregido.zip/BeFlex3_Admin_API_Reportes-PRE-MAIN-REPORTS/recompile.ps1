# Comandos a ejecutar
# Comando 1: mvn clea
$etapas = @("clean", "compile", "package")

foreach ($etapa in $etapas) {
    Write-Host "Ejecutando mvn $etapa..."
    mvn $etapa
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Error: mvn $etapa ha fallado."
        exit 1
    }
    Write-Host "mvn $etapa completado.`n"
}

Write-Host "mvn package completado."

Write-Host "Todos los comandos se han ejecutado exitosamente."
