# Entrega de Constancia Fiscal sobre BAC actualizado

Fecha de preparacion: 2026-10-07

Esta entrega fue construida sobre el codigo actualizado ubicado en:

`C:\Users\sanel\OneDrive\Documentos\loc\BAC\WSBeFlex-EmpAdm-QA`

No se reemplazo el backend con la version anterior. Se conservaron las funciones nuevas de regeneracion de anexos/PDF y se integraron solamente los cambios del flujo de Constancia de Situacion Fiscal.

## Resultado funcional

- Valida el token JWT en `POST /beflex/ProcesaFormatos`.
- Acepta solamente PDF, valida extension, tipo MIME, firma `%PDF-`, contenido legible y limite de 10 MB.
- Ya no exige una cantidad fija de paginas.
- Comprueba que el documento sea una Constancia de Situacion Fiscal.
- Extrae lugar y fecha de emision, fecha normalizada, RFC, CURP, codigo postal, vialidad, numeros exterior e interior, colonia, localidad, municipio, entidad, correo, telefono y regimenes fiscales.
- Valida que RFC y CURP correspondan al empleado antes de guardar.
- Envia al procedimiento `dbo.bf_AltaConstanciaEmpleado` sus 18 parametros reales; no usa el parametro inexistente `JsonCampos`.
- Guarda todos los regimenes encontrados, separados por coma, en `@Regimen`.
- Para la pantalla y el catalogo toma el primer regimen, que es la regla acordada.
- La direccion mostrada en pantalla concatena nombre de vialidad y numero exterior.
- El frontend espera correctamente la respuesta antes de mostrar exito y envia el encabezado de autorizacion.

## Archivos backend incluidos

- `JAVA/src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/ProcesaFormatosDAO.java`
- `JAVA/src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/JDBCProcesaFormatos.java`
- `JAVA/src/main/java/com/lockton/WSBeFlex/POJO/Especiales/DatosConstanciaFiscal.java`
- `JAVA/src/main/java/com/lockton/WSBeFlex/Tools/ConstanciaSATParser.java`
- `JAVA/src/main/java/com/lockton/WSBeFlex/Services/LogicaFfArchivosAdjuntos.java`
- `JAVA/src/main/java/com/lockton/WSBeFlex/REST/WSArchivosAdjuntos.java`

## Archivos frontend incluidos

- `FRONT/src/app/services/API-CoE.service.ts`
- `FRONT/src/app/beflex/master/misdatosfiscalesmaster/misdatosfiscalesmaster.component.ts`

## Base de datos

No se requiere cambio de estructura ni modificacion del procedimiento almacenado para la base revisada:

- Servidor: `(localdb)\MSSQLLocalDB`
- Base: `FlexiForbesv2`
- Procedimiento: `dbo.bf_AltaConstanciaEmpleado`

El archivo `BD/01_VALIDAR_PRERREQUISITOS.sql` es de solo lectura y confirma que el procedimiento conserve exactamente la firma que consume el backend. Debe ejecutarse antes del despliegue. Si marca error, no se debe desplegar hasta alinear el ambiente.

## Verificaciones realizadas

- Compilacion aislada de las clases Java modificadas con Java 11 y dependencias Spring Boot 2.7.18: correcta.
- Prueba del parser con una constancia SAT real: correcta.
- Extraccion comprobada de fecha `2022-09-08`, RFC, CURP, domicilio y regimen fiscal.
- Prueba sintetica de multiples regimenes: correcta; conserva todos y selecciona el primero para pantalla.
- Compilacion TypeScript con `tsc -p src/tsconfig.app.json --noEmit`: correcta.
- Firma del procedimiento en `FlexiForbesv2`: 18 parametros, coincidente con el DAO.
- Funcionalidades de regeneracion presentes en controlador, interfaz y servicio del BAC actualizado: conservadas.

## Aplicacion de la entrega

1. Respaldar o crear una rama en cada repositorio.
2. Copiar el contenido de `JAVA/src` sobre `src` del backend actualizado.
3. Copiar el contenido de `FRONT/src` sobre `src` del frontend actualizado.
4. Ejecutar `BD/01_VALIDAR_PRERREQUISITOS.sql` en la base del ambiente.
5. Compilar backend y frontend.
6. Probar una constancia valida, una constancia de otro empleado, un PDF no fiscal y una constancia con multiples regimenes.

Los comandos sugeridos estan en `COMANDOS_GIT.md`.

## Nota del proyecto backend

La copia local de BAC no contiene metadata `.git`. Ademas, el `pom.xml` depende de `lib/ServiciosLockton/ServiciosLockton/1.1/ServiciosLockton-1.1.jar`; ese binario debe existir en el clon o resolverse desde el repositorio interno para ejecutar el build Maven completo. Estas son condiciones preexistentes y el binario no se incluye en este ZIP.
