package com.lockton.WSBeFlex.DAO.ArchivosAdjuntos;

import com.lockton.WSBeFlex.POJO.Especiales.DatosConstanciaFiscal;

public interface ProcesaFormatosDAO {

    void validarPropietario(int idEmpleado, DatosConstanciaFiscal datos);

    String guardarDatos(int idEmpleado, int idAdministrador, DatosConstanciaFiscal datos);

}
