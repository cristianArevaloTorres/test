# Comandos Git sugeridos

Ejecutar cada bloque dentro de un clon Git real. La carpeta local BAC utilizada para preparar esta entrega no contiene `.git`.

## Backend Java

```powershell
cd "C:\ruta\al\repositorio-backend"
git status --short
git switch -c feature/constancia-fiscal-bac

git add -- `
  src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/ProcesaFormatosDAO.java `
  src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/JDBCProcesaFormatos.java `
  src/main/java/com/lockton/WSBeFlex/POJO/Especiales/DatosConstanciaFiscal.java `
  src/main/java/com/lockton/WSBeFlex/Tools/ConstanciaSATParser.java `
  src/main/java/com/lockton/WSBeFlex/Services/LogicaFfArchivosAdjuntos.java `
  src/main/java/com/lockton/WSBeFlex/REST/WSArchivosAdjuntos.java

git diff --cached --check
git diff --cached --stat
.\mvnw.cmd clean test
git commit -m "fix: completa procesamiento de constancia fiscal"
git push -u origin feature/constancia-fiscal-bac
```

Si el proyecto no incluye Maven Wrapper, reemplazar `.\mvnw.cmd` por `mvn`.

## Frontend Angular

```powershell
cd "C:\ruta\al\repositorio-frontend"
git status --short
git switch -c feature/constancia-fiscal-bac

git add -- `
  src/app/services/API-CoE.service.ts `
  src/app/beflex/master/misdatosfiscalesmaster/misdatosfiscalesmaster.component.ts

git diff --cached --check
git diff --cached --stat
npm ci
.\node_modules\.bin\tsc.cmd -p src/tsconfig.app.json --noEmit
git commit -m "fix: completa carga y mapeo de constancia fiscal"
git push -u origin feature/constancia-fiscal-bac
```

Usar la version de Node definida por el proyecto para el build Angular completo.

## Base de datos

No hay migracion de base de datos. Solo se incluye una validacion de prerrequisitos:

```powershell
sqlcmd -S "(localdb)\MSSQLLocalDB" -d "FlexiForbesv2" -E -b -i ".\BD\01_VALIDAR_PRERREQUISITOS.sql"
```

En otros ambientes, sustituir servidor y base. La opcion `-b` hace que el comando falle si la firma del procedimiento no coincide.
