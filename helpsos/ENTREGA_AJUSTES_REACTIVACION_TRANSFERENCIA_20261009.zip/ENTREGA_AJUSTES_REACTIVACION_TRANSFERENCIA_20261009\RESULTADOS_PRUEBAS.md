# Resultados de validacion local

Fecha: 09/10/2026  
Servidor utilizado: `(localdb)\MSSQLLocalDB`  
Base de datos: `FlexiForbesv2`

## Aplicacion

- Primera ejecucion: se modificaron los dos procedimientos.
- Segunda ejecucion: cero procedimientos modificados; se comprobo la
  idempotencia.
- Cada procedimiento resultante contiene exactamente un comentario `CAT:`.
- El script de rollback se probo dentro de una transaccion externa: restauro
  la logica anterior y despues se revirtio la prueba para conservar aplicados
  los cambios nuevos.

## Procedimientos

- `dbo.bf_ReactivacionEmpleadosTitular`: validacion
  `OK_CONSERVA_FECHA_ALTA_ORIGINAL`.
- `dbo.ff_transferenciaMasivaEmpleado`: validacion
  `OK_REGLA_ROL_APLICADA`.
- No cambiaron los nombres, parametros ni tipos de entrada de los SP.
- La prueba transaccional reactivo temporalmente al empleado `80` de la empresa
  `186`. `EMFechaAdd` conservo exactamente el valor
  `2010-05-29 12:15:01.603` y el resultado fue
  `OK_FECHA_ORIGINAL_CONSERVADA`. Toda la prueba se revirtio.
- La simulacion de seleccion de rol comprobo ambos caminos: para la empresa
  `186` eligio el rol alternativo `1`, y para empresas con default valido
  eligio el default no administrativo de menor ID.

## Revision de consumidores

Se revisaron los flujos de BFlex 3 y del WS Java:

- Angular conserva los endpoints `titulares/reactivacionEmpleado` y
  `titulares/runTransferenciaMasiva`.
- Java sigue invocando `bf_ReactivacionEmpleadosTitular` y
  `ff_transferenciaMasivaEmpleado` con las mismas entradas y respuestas.
- La seleccion de rol y la conservacion de `EMFechaAdd` son reglas internas de
  base de datos.

Conclusion: no se requiere modificar, compilar ni desplegar Angular BFlex 3 ni
el WS Java para estos dos cambios.
