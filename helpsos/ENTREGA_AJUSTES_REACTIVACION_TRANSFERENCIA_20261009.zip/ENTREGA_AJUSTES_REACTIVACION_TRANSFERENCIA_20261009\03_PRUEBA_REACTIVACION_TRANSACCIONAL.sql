/*
  PRUEBA OPCIONAL EN LOCAL.
  Reactiva temporalmente un titular dado de baja, comprueba que EMFechaAdd no
  cambie y revierte todo. Si no existe uno dado de baja, prepara temporalmente
  un titular activo dentro de la misma transaccion. No deja cambios permanentes.
*/
USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa INT;
DECLARE @IdEmpleado INT;
DECLARE @NumeroEmpleado VARCHAR(20);
DECLARE @FechaAddAntes DATETIME;
DECLARE @FechaAddDespues DATETIME;
DECLARE @Usuario INT;
DECLARE @CandidatoSimulado BIT=0;
DECLARE @FechaBajaSimulada DATETIME='2026-10-08 00:00:00.000';

SELECT TOP (1)
    @IdEmpresa=E.EMIdEmpresa,
    @IdEmpleado=E.Id,
    @NumeroEmpleado=E.EMNumeroEmpleado,
    @FechaAddAntes=E.EMFechaAdd
FROM dbo.ff_Empleado E
WHERE E.EMIdEstatus=2
  AND E.EMIdParentesco=1
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.ff_Empleado A
      WHERE A.EMIdEmpresa=E.EMIdEmpresa
        AND A.EMNumeroEmpleado=E.EMNumeroEmpleado
        AND A.EMIdParentesco=1
        AND A.EMIdEstatus=1
  )
ORDER BY E.Id;

IF @IdEmpresa IS NULL
BEGIN
    SELECT TOP (1)
        @IdEmpresa=E.EMIdEmpresa,
        @IdEmpleado=E.Id,
        @NumeroEmpleado=E.EMNumeroEmpleado,
        @FechaAddAntes=E.EMFechaAdd,
        @CandidatoSimulado=1
    FROM dbo.ff_Empleado E
    WHERE E.EMIdEstatus=1
      AND E.EMIdParentesco=1
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.ff_Empleado A
          WHERE A.EMIdEmpresa=E.EMIdEmpresa
            AND A.EMNumeroEmpleado=E.EMNumeroEmpleado
            AND A.EMIdParentesco=1
            AND A.EMIdEstatus=1
            AND A.Id<>E.Id
      )
    ORDER BY E.Id;
END;

SELECT TOP (1) @Usuario=ADIdAdministrador
FROM dbo.ff_administrador
WHERE ADIdEstatus=1
ORDER BY ADIdAdministrador;

IF @Usuario IS NULL
    SET @Usuario=0;

IF @IdEmpresa IS NULL
BEGIN
    SELECT 'SIN_CANDIDATO_LOCAL_PARA_PRUEBA' AS Resultado;
    RETURN;
END;

BEGIN TRANSACTION;
BEGIN TRY
    IF @CandidatoSimulado=1
    BEGIN
        UPDATE dbo.ff_Empleado
        SET EMIdEstatus=2,
            EMFechaBaja=@FechaBajaSimulada
        WHERE Id=@IdEmpleado;

        IF @@ROWCOUNT<>1
            THROW 51000,'No se pudo preparar el candidato transaccional.',1;
    END;

    EXEC dbo.bf_ReactivacionEmpleadosTitular
        @EMIdEmpresa=@IdEmpresa,
        @EMNumeroEmpleado=@NumeroEmpleado,
        @EMFechaReingreso='2026-10-09 00:00:00.000',
        @EMUsuarioUMod=@Usuario;

    SELECT @FechaAddDespues=EMFechaAdd
    FROM dbo.ff_Empleado
    WHERE Id=@IdEmpleado;

    IF NOT
    (
        @FechaAddAntes=@FechaAddDespues
        OR (@FechaAddAntes IS NULL AND @FechaAddDespues IS NULL)
    )
        THROW 51000,'La prueba detecto que EMFechaAdd fue modificada.',1;

    SELECT
        @IdEmpresa AS IdEmpresaPrueba,
        @NumeroEmpleado AS NumeroEmpleadoPrueba,
        @CandidatoSimulado AS CandidatoPreparadoEnTransaccion,
        @FechaAddAntes AS FechaAddAntes,
        @FechaAddDespues AS FechaAddDespues,
        CASE WHEN @FechaAddAntes=@FechaAddDespues
             OR (@FechaAddAntes IS NULL AND @FechaAddDespues IS NULL)
             THEN 'OK_FECHA_ORIGINAL_CONSERVADA'
             ELSE 'ERROR_FECHA_MODIFICADA' END AS Resultado;

    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
