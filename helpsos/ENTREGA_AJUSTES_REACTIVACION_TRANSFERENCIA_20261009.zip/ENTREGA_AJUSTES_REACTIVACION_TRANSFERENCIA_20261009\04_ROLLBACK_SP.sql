/*
  ROLLBACK DE LOS DOS CAMBIOS CAT.
  Utilizar solamente si se requiere regresar a la logica anterior.
*/
USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Salto NVARCHAR(2)=NCHAR(13)+NCHAR(10);

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @ComentarioReactivacion NVARCHAR(500)=
        N'-- CAT: ESTO SE CAMBIO PARA QUE CUMPLIERA CON LO QUE SE SOLICITO QUE ERA CONSERVAR LA FECHA Y HORA DE ALTA ORIGINAL DURANTE LA REACTIVACION.';
    DECLARE @DefReactivacion NVARCHAR(MAX)=
        OBJECT_DEFINITION(OBJECT_ID('dbo.bf_ReactivacionEmpleadosTitular'));
    DECLARE @PatronUmod NVARCHAR(100)=N',EMFechaUmod=GETDATE()';
    DECLARE @Posicion INT;
    DECLARE @Desde INT=1;
    DECLARE @Veces INT=0;

    IF CHARINDEX(@ComentarioReactivacion,@DefReactivacion)>0
    BEGIN
        SET @DefReactivacion=REPLACE(@DefReactivacion,@ComentarioReactivacion+@Salto+@Salto,N'');

        WHILE @Veces<2
        BEGIN
            SET @Posicion=CHARINDEX(@PatronUmod,@DefReactivacion,@Desde);
            IF @Posicion=0
                THROW 51000,'No se pudo reconstruir EMFechaAdd en la reactivacion.',1;

            SET @Posicion=@Posicion+LEN(@PatronUmod);
            SET @DefReactivacion=STUFF
            (
                @DefReactivacion,@Posicion,0,
                @Salto+NCHAR(9)+NCHAR(9)+NCHAR(9)+N',EMFECHAADD=GETDATE()'
            );
            SET @Desde=@Posicion+LEN(@Salto)+4+LEN(N',EMFECHAADD=GETDATE()');
            SET @Veces=@Veces+1;
        END;

        SET @Posicion=CHARINDEX(N'CREATE PROCEDURE',@DefReactivacion);
        IF @Posicion=0
            THROW 51000,'No se encontro CREATE PROCEDURE en bf_ReactivacionEmpleadosTitular.',1;

        SET @DefReactivacion=STUFF
        (
            @DefReactivacion,@Posicion,LEN(N'CREATE PROCEDURE'),N'ALTER PROCEDURE'
        );

        EXEC sys.sp_executesql @DefReactivacion;
    END;

    DECLARE @ComentarioTransferencia NVARCHAR(600)=
        N'-- CAT: ESTO SE CAMBIO PARA QUE CUMPLIERA CON LO QUE SE SOLICITO QUE ERA ASIGNAR EL ROL DEFAULT NO ADMINISTRATIVO O, EN SU AUSENCIA, EL ROL NO ADMINISTRATIVO CON MENOR ID.';
    DECLARE @MarcaFin NVARCHAR(200)=N'-- Actualizar datos EMPLEADO';
    DECLARE @DefTransferencia NVARCHAR(MAX)=
        OBJECT_DEFINITION(OBJECT_ID('dbo.ff_transferenciaMasivaEmpleado'));
    DECLARE @Inicio INT=CHARINDEX(@ComentarioTransferencia,@DefTransferencia);
    DECLARE @Fin INT=CHARINDEX(@MarcaFin,@DefTransferencia,CHARINDEX(@ComentarioTransferencia,@DefTransferencia)+1);
    DECLARE @BloqueAnterior NVARCHAR(MAX);

    IF @Inicio>0
    BEGIN
        IF @Fin=0 OR @Fin<=@Inicio
            THROW 51000,'No se encontro el bloque CAT de transferencia para rollback.',1;

        SET @BloqueAnterior=
            N'-- Recuperar configuracion de rol'+@Salto+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+N'DECLARE @IdRolDestino INT = 0;'+@Salto+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+N'SELECT TOP 1'+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+NCHAR(9)+N'@IdRolDestino = ROIdRol'+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+N'FROM'+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+NCHAR(9)+N'ff_Rol'+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+N'WHERE '+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+NCHAR(9)+N'ROIdEmpresa = @EMIdEmpresa  -- Empresa destino'+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+NCHAR(9)+N'and ROIdEstatus = 1 '+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9)+NCHAR(9)+N'and RODefault=1'+@Salto+
            NCHAR(9)+NCHAR(9)+NCHAR(9);

        SET @DefTransferencia=STUFF(@DefTransferencia,@Inicio,@Fin-@Inicio,@BloqueAnterior);

        SET @Posicion=CHARINDEX(N'CREATE PROCEDURE',@DefTransferencia);
        IF @Posicion=0
            THROW 51000,'No se encontro CREATE PROCEDURE en ff_transferenciaMasivaEmpleado.',1;

        SET @DefTransferencia=STUFF
        (
            @DefTransferencia,@Posicion,LEN(N'CREATE PROCEDURE'),N'ALTER PROCEDURE'
        );

        EXEC sys.sp_executesql @DefTransferencia;
    END;

    COMMIT TRANSACTION;
    SELECT 'ROLLBACK_APLICADO' AS Resultado;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
