# Ajustes de Reactivacion y Transferencia

Servidor local utilizado: `(localdb)\MSSQLLocalDB`  
Base: `FlexiForbesv2`

## Cambios

- `dbo.bf_ReactivacionEmpleadosTitular`: deja de modificar `EMFechaAdd` al
  reactivar al titular y sus dependientes. Conserva la fecha/hora original.
- `dbo.ff_transferenciaMasivaEmpleado`: busca primero el rol activo de menor ID
  que sea default y este asociado a un perfil activo no administrador. Si no
  existe, utiliza el rol activo de menor ID asociado a un perfil activo no
  administrador. Si no existe ningun candidato, revierte la transferencia y
  devuelve el error mediante la respuesta actual del SP.

## Compatibilidad

No se modificaron nombres de SP, parametros de entrada ni columnas de respuesta.
Por ello no se requieren cambios ni despliegues de Angular BFlex 3 ni del WS
Java. Ambos consumidores continúan usando los mismos endpoints y contratos.

## Orden

1. Ejecutar `01_APLICAR_CAMBIOS_SP.sql`.
2. Ejecutar `02_VALIDAR_CAMBIOS_SOLO_LECTURA.sql`.
3. Opcionalmente ejecutar `03_PRUEBA_REACTIVACION_TRANSACCIONAL.sql` en local.
4. `04_ROLLBACK_SP.sql` se conserva solamente para contingencia.

El instalador es transaccional e idempotente. Si la definicion de origen no es
la esperada, se detiene sin aplicar cambios parciales.

## Resultado local

Los cambios quedaron aplicados en `(localdb)\MSSQLLocalDB`, base
`FlexiForbesv2`. La segunda ejecucion no realizo modificaciones adicionales.
Consultar `RESULTADOS_PRUEBAS.md` para el detalle.
