/* VALIDACION POSTERIOR. NO MODIFICA DATOS. */
USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @DefReactivacion NVARCHAR(MAX) =
    OBJECT_DEFINITION(OBJECT_ID('dbo.bf_ReactivacionEmpleadosTitular'));
DECLARE @DefTransferencia NVARCHAR(MAX) =
    OBJECT_DEFINITION(OBJECT_ID('dbo.ff_transferenciaMasivaEmpleado'));

SELECT
    '00_CONTEXTO' AS Bloque,
    CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) AS Servidor,
    DB_NAME() AS BaseDatos,
    GETDATE() AS FechaValidacion;

SELECT
    '01_DEFINICIONES' AS Bloque,
    O.name AS Procedimiento,
    O.modify_date AS FechaModificacion,
    CASE
        WHEN O.name='bf_ReactivacionEmpleadosTitular'
         AND @DefReactivacion LIKE '%CAT: ESTO SE CAMBIO%'
         AND @DefReactivacion NOT LIKE '%EMFECHAADD=GETDATE()%'
            THEN 'OK_CONSERVA_FECHA_ALTA_ORIGINAL'
        WHEN O.name='ff_transferenciaMasivaEmpleado'
         AND @DefTransferencia LIKE '%CAT: ESTO SE CAMBIO%'
         AND @DefTransferencia LIKE '%P.PEAdministrador = 0%'
         AND @DefTransferencia LIKE '%R.RODefault = 1%'
         AND @DefTransferencia LIKE '%ORDER BY R.ROIdRol ASC%'
            THEN 'OK_REGLA_ROL_APLICADA'
        ELSE 'ERROR_REVISAR_DEFINICION'
    END AS Validacion
FROM sys.objects O
WHERE O.object_id IN
(
    OBJECT_ID('dbo.bf_ReactivacionEmpleadosTitular'),
    OBJECT_ID('dbo.ff_transferenciaMasivaEmpleado')
)
ORDER BY O.name;

/* Confirma que no cambiaron los contratos de entrada. */
SELECT
    '02_PARAMETROS_SP' AS Bloque,
    OBJECT_NAME(P.object_id) AS Procedimiento,
    P.parameter_id,
    P.name AS Parametro,
    TYPE_NAME(P.user_type_id) AS Tipo,
    P.max_length,
    P.is_output
FROM sys.parameters P
WHERE P.object_id IN
(
    OBJECT_ID('dbo.bf_ReactivacionEmpleadosTitular'),
    OBJECT_ID('dbo.ff_transferenciaMasivaEmpleado')
)
ORDER BY Procedimiento,P.parameter_id;

/* Simula la seleccion del rol sin ejecutar transferencias. */
;WITH RolesNoAdministrativos AS
(
    SELECT DISTINCT
        R.ROIdEmpresa,
        R.ROIdRol,
        R.RODefault
    FROM dbo.ff_Rol R
    INNER JOIN dbo.ff_Perfil P
        ON P.PEIdRolDefault=R.ROIdRol
       AND P.PEIdEmpresa=R.ROIdEmpresa
       AND P.PEIdEstatus=1
       AND P.PEAdministrador=0
    WHERE R.ROIdEstatus=1
),
Resolucion AS
(
    SELECT
        E.EMidEmpresa,
        MIN(CASE WHEN R.RODefault=1 THEN R.ROIdRol END) AS RolDefaultElegido,
        MIN(R.ROIdRol) AS RolAlternativoElegido
    FROM dbo.ff_Empresa E
    LEFT JOIN RolesNoAdministrativos R
        ON R.ROIdEmpresa=E.EMidEmpresa
    WHERE E.EMidEstatus=1
    GROUP BY E.EMidEmpresa
)
SELECT
    '03_RESUMEN_RESOLUCION_ROLES' AS Bloque,
    SUM(CASE WHEN RolDefaultElegido IS NOT NULL THEN 1 ELSE 0 END) AS EmpresasConDefaultNoAdministrativo,
    SUM(CASE WHEN RolDefaultElegido IS NULL AND RolAlternativoElegido IS NOT NULL THEN 1 ELSE 0 END) AS EmpresasQueUsarianAlternativo,
    SUM(CASE WHEN RolAlternativoElegido IS NULL THEN 1 ELSE 0 END) AS EmpresasSinRolNoAdministrativo
FROM Resolucion;
GO
