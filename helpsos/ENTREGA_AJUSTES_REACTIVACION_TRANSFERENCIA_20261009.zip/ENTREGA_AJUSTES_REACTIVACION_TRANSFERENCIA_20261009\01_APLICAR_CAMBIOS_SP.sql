/*
  AJUSTES SOLICITADOS POR MIDDLEWARE
  Servidor local: (localdb)\MSSQLLocalDB
  Base: FlexiForbesv2

  Objetos:
    - dbo.bf_ReactivacionEmpleadosTitular
    - dbo.ff_transferenciaMasivaEmpleado

  El script valida la definicion esperada, conserva firmas y permisos,
  y puede ejecutarse nuevamente sin duplicar el cambio.
*/

USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Salto NVARCHAR(2) = NCHAR(13) + NCHAR(10);
DECLARE @CambioReactivacion BIT = 0;
DECLARE @CambioTransferencia BIT = 0;

BEGIN TRY
    BEGIN TRANSACTION;

    /* Reactivacion: conservar EMFechaAdd original. */
    DECLARE @ObjetoReactivacion NVARCHAR(300) = N'dbo.bf_ReactivacionEmpleadosTitular';
    DECLARE @ComentarioReactivacion NVARCHAR(500) =
        N'-- CAT: ESTO SE CAMBIO PARA QUE CUMPLIERA CON LO QUE SE SOLICITO QUE ERA CONSERVAR LA FECHA Y HORA DE ALTA ORIGINAL DURANTE LA REACTIVACION.';
    DECLARE @DefReactivacion NVARCHAR(MAX) = OBJECT_DEFINITION(OBJECT_ID(@ObjetoReactivacion));
    DECLARE @PatronFechaAdd NVARCHAR(100) = N',EMFECHAADD=GETDATE()';
    DECLARE @MarcaReactivacion NVARCHAR(200) = N'-- Validar existencia de empleado, activo';
    DECLARE @OcurrenciasFechaAdd INT;
    DECLARE @PosicionCrear INT;

    IF @DefReactivacion IS NULL
        THROW 51000, 'No existe dbo.bf_ReactivacionEmpleadosTitular.', 1;

    SET @OcurrenciasFechaAdd =
        (LEN(@DefReactivacion) - LEN(REPLACE(@DefReactivacion, @PatronFechaAdd, N'')))
        / LEN(@PatronFechaAdd);

    IF CHARINDEX(@ComentarioReactivacion, @DefReactivacion) = 0
    BEGIN
        IF @OcurrenciasFechaAdd <> 2
            THROW 51000, 'La definicion de bf_ReactivacionEmpleadosTitular no coincide con la version esperada: deben existir dos asignaciones a EMFechaAdd.', 1;

        IF CHARINDEX(@MarcaReactivacion, @DefReactivacion) = 0
            THROW 51000, 'No se encontro el punto controlado para documentar el cambio de reactivacion.', 1;

        SET @DefReactivacion = REPLACE(@DefReactivacion, @PatronFechaAdd, N'');
        SET @DefReactivacion = REPLACE
        (
            @DefReactivacion,
            @MarcaReactivacion,
            @ComentarioReactivacion + @Salto + @Salto + @MarcaReactivacion
        );

        SET @PosicionCrear = CHARINDEX(N'CREATE PROCEDURE', @DefReactivacion);
        IF @PosicionCrear = 0
            THROW 51000, 'No se encontro CREATE PROCEDURE en bf_ReactivacionEmpleadosTitular.', 1;

        SET @DefReactivacion = STUFF
        (
            @DefReactivacion,
            @PosicionCrear,
            LEN(N'CREATE PROCEDURE'),
            N'ALTER PROCEDURE'
        );

        EXEC sys.sp_executesql @DefReactivacion;
        SET @CambioReactivacion = 1;
    END
    ELSE IF @OcurrenciasFechaAdd <> 0
        THROW 51000, 'La reactivacion tiene el comentario CAT, pero aun modifica EMFechaAdd.', 1;

    /* Transferencia: rol no administrativo default y alternativa por menor ID. */
    DECLARE @ObjetoTransferencia NVARCHAR(300) = N'dbo.ff_transferenciaMasivaEmpleado';
    DECLARE @ComentarioTransferencia NVARCHAR(600) =
        N'-- CAT: ESTO SE CAMBIO PARA QUE CUMPLIERA CON LO QUE SE SOLICITO QUE ERA ASIGNAR EL ROL DEFAULT NO ADMINISTRATIVO O, EN SU AUSENCIA, EL ROL NO ADMINISTRATIVO CON MENOR ID.';
    DECLARE @DefTransferencia NVARCHAR(MAX) = OBJECT_DEFINITION(OBJECT_ID(@ObjetoTransferencia));
    DECLARE @MarcaInicioTransferencia NVARCHAR(200) = N'-- Recuperar configuracion de rol';
    DECLARE @MarcaFinTransferencia NVARCHAR(200) = N'-- Actualizar datos EMPLEADO';
    DECLARE @InicioTransferencia INT;
    DECLARE @FinTransferencia INT;
    DECLARE @BloqueRol NVARCHAR(MAX);

    IF @DefTransferencia IS NULL
        THROW 51000, 'No existe dbo.ff_transferenciaMasivaEmpleado.', 1;

    IF CHARINDEX(@ComentarioTransferencia, @DefTransferencia) = 0
    BEGIN
        SET @InicioTransferencia = CHARINDEX(@MarcaInicioTransferencia, @DefTransferencia);
        SET @FinTransferencia = CHARINDEX(@MarcaFinTransferencia, @DefTransferencia, @InicioTransferencia + 1);

        IF @InicioTransferencia = 0 OR @FinTransferencia = 0 OR @FinTransferencia <= @InicioTransferencia
            THROW 51000, 'No se encontro el bloque controlado de asignacion de rol en ff_transferenciaMasivaEmpleado.', 1;

        SET @BloqueRol =
            @ComentarioTransferencia + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'DECLARE @IdRolDestino INT = NULL;' + @Salto + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'SELECT TOP (1)' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'@IdRolDestino = R.ROIdRol' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'FROM dbo.ff_Rol R' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'INNER JOIN dbo.ff_Perfil P' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'ON P.PEIdRolDefault = R.ROIdRol' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND P.PEIdEmpresa = @EMIdEmpresa' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND P.PEIdEstatus = 1' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'WHERE R.ROIdEmpresa = @EMIdEmpresa' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND R.ROIdEstatus = 1' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND R.RODefault = 1' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND P.PEAdministrador = 0' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'ORDER BY R.ROIdRol ASC;' + @Salto + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'IF @IdRolDestino IS NULL' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'BEGIN' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'SELECT TOP (1)' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'@IdRolDestino = R.ROIdRol' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'FROM dbo.ff_Rol R' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'INNER JOIN dbo.ff_Perfil P' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'ON P.PEIdRolDefault = R.ROIdRol' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND P.PEIdEmpresa = @EMIdEmpresa' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND P.PEIdEstatus = 1' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'WHERE R.ROIdEmpresa = @EMIdEmpresa' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND R.ROIdEstatus = 1' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'AND P.PEAdministrador = 0' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'ORDER BY R.ROIdRol ASC;' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'END;' + @Salto + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + N'IF @IdRolDestino IS NULL' + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9) + NCHAR(9) + N'THROW 51000, ''No existe un rol activo asociado a un perfil no administrador en la empresa destino.'', 1;' + @Salto + @Salto +
            NCHAR(9) + NCHAR(9) + NCHAR(9);

        SET @DefTransferencia = STUFF
        (
            @DefTransferencia,
            @InicioTransferencia,
            @FinTransferencia - @InicioTransferencia,
            @BloqueRol
        );

        SET @PosicionCrear = CHARINDEX(N'CREATE PROCEDURE', @DefTransferencia);
        IF @PosicionCrear = 0
            THROW 51000, 'No se encontro CREATE PROCEDURE en ff_transferenciaMasivaEmpleado.', 1;

        SET @DefTransferencia = STUFF
        (
            @DefTransferencia,
            @PosicionCrear,
            LEN(N'CREATE PROCEDURE'),
            N'ALTER PROCEDURE'
        );

        EXEC sys.sp_executesql @DefTransferencia;
        SET @CambioTransferencia = 1;
    END;

    /* Validacion de la definicion antes de confirmar la transaccion. */
    SET @DefReactivacion = OBJECT_DEFINITION(OBJECT_ID(@ObjetoReactivacion));
    SET @DefTransferencia = OBJECT_DEFINITION(OBJECT_ID(@ObjetoTransferencia));

    IF CHARINDEX(@ComentarioReactivacion, @DefReactivacion) = 0
       OR CHARINDEX(@PatronFechaAdd, @DefReactivacion) > 0
        THROW 51000, 'Validacion final fallida para bf_ReactivacionEmpleadosTitular.', 1;

    IF CHARINDEX(@ComentarioTransferencia, @DefTransferencia) = 0
       OR CHARINDEX(N'P.PEAdministrador = 0', @DefTransferencia) = 0
       OR CHARINDEX(N'ORDER BY R.ROIdRol ASC', @DefTransferencia) = 0
        THROW 51000, 'Validacion final fallida para ff_transferenciaMasivaEmpleado.', 1;

    COMMIT TRANSACTION;

    SELECT
        CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) AS Servidor,
        DB_NAME() AS BaseDatos,
        @CambioReactivacion AS ReactivacionModificadaEnEstaEjecucion,
        @CambioTransferencia AS TransferenciaModificadaEnEstaEjecucion,
        'CAMBIOS_APLICADOS_Y_VALIDADOS' AS Resultado;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
