-- SERVIDOR: (localdb)\MSSQLLocalDB
-- BASE DE DATOS: FlexiForbesv2
USE [FlexiForbesv2];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
ALTER procedure [dbo].[ff_GetDatosReporteAseguradoConSalarioB3]
	@idEmpresa varchar(max)
	,@FechaInicial VARCHAR(max)
	,@FechaFinal VARCHAR(max)
	,@IdEstatus INT
	,@IdParentesco VARCHAR(max)
	,@IdPerfil VARCHAR(max)
AS
BEGIN
	/*Declare
	@idEmpresa varchar(100) = '517' --516, 517, 518
	,@FechaInicial VARCHAR(30) = '2016-06-01'
	,@FechaFinal VARCHAR(30) = '2017-12-31'
	,@IdEstatus INT = NULL--1,2
	,@IdParentesco VARCHAR(100) = NULL--'1,2,3',-- null, --1,2,3
	,@IdPerfil VARCHAR(100)= NULL--'1792'--null --'1720,1792'*/
	Declare @IdEstatusN INT
			,@IdParentescoN VARCHAR(max)
			,@IdPerfilN VARCHAR(max)
			,@FechaInicio DATE
			,@FechaFin DATE
	
	SET @FechaInicio = CASE WHEN @FechaInicial = '' THEN NULL ELSE @FechaInicial END
	SET @FechaFin = CASE WHEN @FechaFinal = '' THEN NULL ELSE @FechaFinal END
			
	SET @IdEstatusN = CASE WHEN @IdEstatus > 0 THEN @IdEstatus ELSE NULL END
	SET @IdParentescoN = CASE WHEN LEN(@IdParentesco) > 0 THEN @IdParentesco ELSE NULL END
	SET @IdPerfilN = CASE WHEN LEN(@IdPerfil) > 0  THEN @IdPerfil ELSE NULL END
	print 'Este es el parentesco'
	print @IdParentescoN
	
	SELECT 
    --se agregan campos extras
	ISNULL(ESNombre,'') as Estatus--: Activo o Baja
	
	,ISNULL(ADOADD.EMApellidoPaterno, ISNULL(AEADD.ADApellidoPaterno, '')) + ' ' + ISNULL(ADOADD.EMApellidoMaterno, ISNULL(AEADD.ADApellidoMaterno, '')) + ' ' + 
		ISNULL(ADOADD.EMNombre1, ISNULL(AEADD.ADNombres, '')) + ' ' + ISNULL(ADOADD.EMNombre2, '')AS 'Usuario Agregó'--: nombre del administrador que realizó el alta
		,CAST(ADO.EMFechaAdd AS DATETIME) as 'Fecha Registro Sistema'--: fecha de alta, EMFechaAdd
		,ISNULL(ADOMOD.EMApellidoPaterno, ISNULL(AEMOD.ADApellidoPaterno, '')) + ' ' + ISNULL(ADOMOD.EMApellidoMaterno, ISNULL(AEMOD.ADApellidoMaterno, '')) 
		+ ' ' + ISNULL(ADOMOD.EMNombre1, ISNULL(AEMOD.ADNombres, '')) + ' ' + ISNULL(ADOMOD.EMNombre2, '')AS 'Usuario Modificó'--: nombre del administrador que realizó la última modificación
		,CAST(ADO.EMFechaUMod AS DATETIME) as 'Fecha Modificación'--: fecha de modificación, EMFechaMod
		,ISNULL(ADODEL.EMApellidoPaterno, ISNULL(AEDEL.ADApellidoPaterno, '')) + ' ' + ISNULL(ADODEL.EMApellidoMaterno, ISNULL(AEDEL.ADApellidoMaterno, '')) + ' ' + 
		ISNULL(ADODEL.EMNombre1, ISNULL(AEDEL.ADNombres, '')) + ' ' + ISNULL(ADODEL.EMNombre2, '')AS 'Usuario Eliminó'--: nombre del administrador que haya realizado la baja.
		,CAST(ADO.EMFechaDel AS DATETIME) as 'Fecha Baja Sistema'--: EMFechaDel cuando se realizó la baja'
		
		,ADO.Id as 'ID del registro/asegurado'
		
		,ISNULL(ESA.EMNombre,'') as 'Nombre de empresa'
		,ADO.EMIdEmpresa as 'ID de la empresa'
		
		-- fin cambios extras 16102020
		,ADO.Id
		,ISNULL(ADOADD.EMApellidoPaterno, ISNULL(AEADD.ADApellidoPaterno, '')) + ' ' + ISNULL(ADOADD.EMApellidoMaterno, ISNULL(AEADD.ADApellidoMaterno, '')) + ' ' + ISNULL(ADOADD.EMNombre1, ISNULL(AEADD.ADNombres, '')) + ' ' + ISNULL(ADOADD.EMNombre2, '')AS UsuarioAdd
		,CAST(ADO.EMFechaAdd AS DATETIME) 
		,ISNULL(ADOMOD.EMApellidoPaterno, ISNULL(AEMOD.ADApellidoPaterno, '')) + ' ' + ISNULL(ADOMOD.EMApellidoMaterno, ISNULL(AEMOD.ADApellidoMaterno, '')) + ' ' + ISNULL(ADOMOD.EMNombre1, ISNULL(AEMOD.ADNombres, '')) + ' ' + ISNULL(ADOMOD.EMNombre2, '')AS UsuarioMod
		,CAST(ADO.EMFechaUMod AS DATETIME) 
		,ISNULL(ADODEL.EMApellidoPaterno, ISNULL(AEDEL.ADApellidoPaterno, '')) + ' ' + ISNULL(ADODEL.EMApellidoMaterno, ISNULL(AEDEL.ADApellidoMaterno, '')) + ' ' + ISNULL(ADODEL.EMNombre1, ISNULL(AEDEL.ADNombres, '')) + ' ' + ISNULL(ADODEL.EMNombre2, '')AS UsuarioDel
		,CAST(ADO.EMFechaDel AS DATETIME) 

		,ADO.EMAntiguedadGMM
		,ADO.EMApellidoMaterno
		,ADO.EMApellidoPaterno
		,ADO.EMArchivoInformacion
		,(SELECT top 1 ff_TablaEncabezadoDetalle.TEDescripcion FROM ff_TablaEncabezado INNER JOIN ff_TablaEncabezadoDetalle --MOD 10/07/2020 --MOD TOP 1 28/07/2020
		 ON ff_TablaEncabezado.ENClave =ff_TablaEncabezadoDetalle.TEEnClave
		 WHERE  ff_TablaEncabezado.ENIdEmpresa=ADO.EMIdEmpresa and ff_TablaEncabezado.ENNombreCampo='EMArea' 
		 and TEIdDetalle = (SELECT CASE WHEN ISNUMERIC(ADO.EMArea) = 1 THEN CAST(ADO.EMArea AS INT) ELSE 0 END)) as EMArea
		,ADO.EMBeneficioMaximoM
		,ADO.EMBeneficioMaximoP
		,ADO.EMBeneFicioOtorgadoM
		,ADO.EMBeneFicioOtorgadoP
		,ADO.EMBloqueoXSel
		,ADO.EMCalleFiscal
		,ADO.EMCalleFisico
		,ADO.EMCambioPassword
		,ADO.EMCertificado
		,ADO.EMClaveAcceso
		,ADO.EMCodigoPostalFiscal
		,ADO.EMCodigoPostalFisico
		,ADO.EMColoniaFiscal
		,ADO.EMColoniaFisico
		,ADO.EMConsumoAlcohol
		,ADO.EMContinua
		,ADO.EMCorreoElectronico
		,ADO.EMcurp
		,ADO.EMDeduccionesM
		,ADO.EMDeduccionesP
		,ADO.EMDiasVacacionesporGozar
		,ADO.EMEdad
		,(select tado.EsIdNombre from ff_Estado tado where tado.ESidEstado = ADO.EMEstadoFisico) as EMEstadoFisico --MOD 10/07/2020
		,(select tado.EsIdNombre from ff_Estado tado where tado.ESidEstado = ADO.EMEstadoFiscal) as EMEstadoFiscal --MOD 10/07/2020
		,ADO.EMExcedente
		,ADO.EMFecBloqueoXSel
		, CAST(ADO.EMFechaAcceso AS DATETIME) EMFechaAcceso
		, CAST(ADO.EMFechaAdd AS DATETIME) AS EMFechaAdd
		,CAST(ADO.EMFechaAlta AS DATETIME) EMFechaAlta
		, CAST(ADO.EMFechaAntiguedadGMM AS DATETIME) EMFechaAntiguedadGMM
		, CAST(ADO.EMFechaAntiguedadPP AS DATETIME) EMFechaAntiguedadPP
		, CAST(ADO.EMFechaBaja AS DATETIME) EMFechaBaja
		, CAST(ADO.EMFechaDel AS DATETIME) AS EMFechaDel
		, CAST(ADO.EMFechaEstatus AS DATE) EMFechaEstatus
		, CAST(ADO.EMFechaIngresoEmpresa AS DATETIME) EMFechaIngresoEmpresa
		, CAST(ADO.EMFechaIngresoIMSSPP AS DATETIME) EMFechaIngresoIMSSPP
		, CAST(ADO.EMFechaNacimiento AS DATETIME) EMFechaNacimiento
		, CAST(ADO.EMFechaUMod AS DATETIME) AS EMFechaUMod
		,ADO.EMFondoAhorroAcumulado
		,ADO.EMFondoAhorroM
		,ADO.EMFondoAhorroP
		,ADO.EMFumador
		,ADO.EMIdAcceso
		-- MOD 01/08/2021
		--,ADO.EMidCentroCostos
		,(SELECT ff_TablaEncabezadoDetalle.TEDescripcion FROM ff_TablaEncabezado INNER JOIN ff_TablaEncabezadoDetalle --MOD 10/07/2020
		 ON ff_TablaEncabezado.ENClave =ff_TablaEncabezadoDetalle.TEEnClave
		 WHERE  ff_TablaEncabezado.ENIdEmpresa=ADO.EMIdEmpresa and ff_TablaEncabezado.ENNombreCampo='EMidCentroCostos' 
		 and TEIdDetalle = (SELECT CASE WHEN ISNUMERIC(ADO.EMidCentroCostos) = 1 THEN CAST(ADO.EMidCentroCostos AS INT) ELSE 0 END)) as EMidCentroCostos
		,ADO.EMIdContacto
		,ADO.EMIdEmpresa as EMIdEmpresa
		,ISNULL(ESA.EMNombre,'') as EMNombreEmpresa
		,ISNULL(ESNombre,'') as EMIdEstatus
		,ISNULL(JEF.EMApellidoPaterno, '') + ' ' + ISNULL(JEF.EMApellidoMaterno, '') + ' ' + ISNULL(JEF.EMNombre1, '') + ' ' + ISNULL(JEF.EMNombre2, '') as EMIdJefe
		,ISNULL(PAR.PADescripcion,'') AS EMIdParentesco
		,ISNULL(PER.PENombre,'') AS EMIdPerfil
		,ISNULL(ROL.RODescripcionCorta,'') AS EMIdRol
		,ISNULL(SEX.SEDescripcion,'') AS EMIdSexo
		,ADO.EMIdTipoAsegurado
		,ISNULL(SAL.TSDescripcion,'') AS EMIdTipoSalario
		, CAST(ADO.EMSalarioBase AS MONEY) as EMSalarioBase --Mod JDGG06102020
		,ISNULL(TIT.EMApellidoPaterno, '') + ' ' + ISNULL(TIT.EMApellidoMaterno, '') + ' ' + ISNULL(TIT.EMNombre1, '') + ' ' + ISNULL(TIT.EMNombre2, '') AS EMIdTitular
		,ADO.EMIdTransferido
		,ADO.EMMunicipioDelegacionFiscal
		,ADO.EMMunicipioDelegacionFisico
		,ADO.EMNetForbes
		,ADO.EMNombre1
		,ADO.EMNombre2
		,ADO.EMnss
		,ADO.EMNumeroEmpleado
		,ADO.EMObservaciones
		,ISNULL(TED.TEDescripcion,'') AS EMOficina
		,ADO.EMPrestacionesM
		,ADO.EMPrestacionesP
		,ADO.EMPuesto
		,ADO.EMReseteoPassword
		,ADO.EMrfc
		,ADO.EMTelefono
		,ADO.EMTipoDomicilio
		,(SELECT ff_TablaEncabezadoDetalle.TEDescripcion FROM ff_TablaEncabezado INNER JOIN ff_TablaEncabezadoDetalle --MOD 10/07/2020
		 ON ff_TablaEncabezado.ENClave =ff_TablaEncabezadoDetalle.TEEnClave
		 WHERE  ff_TablaEncabezado.ENIdEmpresa=ADO.EMIdEmpresa and ff_TablaEncabezado.ENNombreCampo='EMTipoEmpleado' 
		 and TEIdDetalle = (SELECT CASE WHEN ISNUMERIC(ADO.EMTipoEmpleado) = 1 THEN CAST(ADO.EMTipoEmpleado AS INT) ELSE 0 END)) as EMTipoEmpleado
		,ADO.EMValesM
		,ADO.EMValesP
		,(SELECT ff_TablaEncabezadoDetalle.TEDescripcion FROM ff_TablaEncabezado INNER JOIN ff_TablaEncabezadoDetalle --MOD 10/07/2020
		 ON ff_TablaEncabezado.ENClave =ff_TablaEncabezadoDetalle.TEEnClave
		 WHERE  ff_TablaEncabezado.ENIdEmpresa=ADO.EMIdEmpresa and ff_TablaEncabezado.ENNombreCampo='EMVIP' 
		 and TEIdDetalle = (SELECT CASE WHEN ISNUMERIC(ADO.EMVIP) = 1 THEN CAST(ADO.EMVIP AS INT) ELSE 0 END)) as EMVIP
	, /* CAT: SE REALIZO ESTE AJUSTE RELACIONADO AL REGIMEN CUANDO SE MODIFICA DE FORMA MANUAL, PARA QUE SE REFLEJE EN EL REPORTE. */
COALESCE(
        (SELECT TOP 1 TEDRegimen.TEDescripcion
         FROM dbo.ff_TablaEncabezado TERegimen
         INNER JOIN dbo.ff_TablaEncabezadoDetalle TEDRegimen
            ON TERegimen.ENClave = TEDRegimen.TEEnClave
         WHERE TERegimen.ENIdEmpresa = ADO.EMIdEmpresa
           AND TERegimen.ENNombreCampo = 'EMRegimen'
           AND TEDRegimen.TEIdDetalle = ADO.EMRegimen),
        (SELECT TOP 1 CE.Regimen
         FROM dbo.bf_ConstanciaEmpleado CE
         WHERE CE.IdEmpleado = ADO.Id
         ORDER BY CE.Id DESC)
    ) as EMRegimen
	, (SELECT TOP 1 FechaEmision FROM bf_ConstanciaEmpleado WHERE IdEmpleado = ADO.Id ORDER BY Id DESC) as EMFechaEmision

	FROM ff_Empleado ADO WITH (NOLOCK)
		INNER JOIN ff_Empresa ESA
			ON ADO.EMIdEmpresa = ESA.EMidEmpresa AND ESA.EMidEstatus = 1
		INNER JOIN ff_Parentesco PAR
			ON ADO.EMIdParentesco = PAidParentesco AND PAR.PAidEstatus = 1
		INNER JOIN ff_Perfil PER
			ON ADO.EMIdPerfil = PER.PEIdPerfil AND PER.PEIdEstatus = 1
		INNER JOIN ff_Rol ROL
			ON ADO.EMIdRol = ROL.ROIdRol AND ROL.ROIdEstatus = 1
		INNER JOIN ff_Estatus ES
			ON ADO.EMIdEstatus = Es.ESid
		INNER JOIN ff_Sexo SEX
			ON ADO.EMIdSexo = SEX.SEidSexo AND SEX.SEidEstatus = 1
		LEFT JOIN ff_TipoSalario SAL
			ON ADO.EMIdTipoAsegurado = SAL.idTipoSalario AND TSidEstatus = 1
		
		LEFT JOIN ff_TablaEncabezado TE
			ON ADO.EMIdEmpresa = TE.ENIdEmpresa AND TE.ENNombreCampo LIKE '%EMOficina%'
		LEFT JOIN ff_TablaEncabezadoDetalle TED 
			ON TE.ENClave LIKE TED.TEEnClave AND ADO.EMOficina = TED.TEIdDetalle
		
		LEFT JOIN ff_Empleado JEF
			ON ADO.EMIdJefe = JEF.Id
		LEFT JOIN ff_Empleado TIT
			ON ADO.EMIdTitular = TIT.Id
			
		LEFT JOIN ff_Empleado ADOADD
			ON ADO.EMUsuarioAdd = ADOADD.Id
		LEFT JOIN ff_Empleado ADOMOD
			ON ADO.EMUsuarioUMod = ADOMOD.Id
		LEFT JOIN ff_Empleado ADODEL
			ON ADO.EMUsuarioDel = ADODEL.Id
			
		LEFT JOIN ff_Administrador AEADD
			ON ADO.EMUsuarioAdd = AEADD.ADIdAdministrador
		LEFT JOIN ff_Administrador AEMOD
			ON ADO.EMUsuarioUMod = AEMOD.ADIdAdministrador
		LEFT JOIN ff_Administrador AEDEL
			ON ADO.EMUsuarioDel = AEDEL.ADIdAdministrador
	WHERE 
		(@idEmpresa IS NULL OR ADO.EMIdEmpresa IN 
                        (SELECT ParsedString FROM dbo.ParseStringList(@idEmpresa) 
                             WHERE ParsedString = ADO.EMIdEmpresa))
-- >>> LM03082020
--		AND (@FechaInicio IS NULL OR CAST(ADO.EMFechaAdd AS DATE) >= @FechaInicio)
--		AND (@FechaFin IS NULL OR CAST(ADO.EMFechaAdd AS DATE) <= @FechaFin)


		AND CASE 
		WHEN isnull(@IdEstatusN, -1)=1 and @IdParentescoN is not null
		AND ADO.EMIdEstatus = 1
		-- AND (@FechaInicio IS NULL OR CAST(ADO.EMFechaAdd AS DATE) >= @FechaInicio)
		-- AND (@FechaFin IS NULL OR CAST(ADO.EMFechaAdd AS DATE) <= @FechaFin) 
		THEN 1 

		WHEN isnull(@IdEstatusN, -1)=1 and @IdParentescoN is null		

		AND (@FechaInicio IS NULL OR CAST(ADO.EMFechaAdd AS DATE) >= @FechaInicio)
		AND (@FechaFin IS NULL OR CAST(ADO.EMFechaAdd AS DATE) <= @FechaFin) THEN 1 


		WHEN isnull(@IdEstatusN, -1)=2 and @IdParentescoN is not null
		AND ADO.EMIdEstatus = 2
		-- AND (@FechaInicio IS NULL OR CAST(ADO.EMFechaDel AS DATE) >= @FechaInicio)
		-- AND (@FechaFin IS NULL OR CAST(ADO.EMFechaDel AS DATE) <= @FechaFin) 
		THEN 1 

		WHEN isnull(@IdEstatusN, -1)=2 and @IdParentescoN is null
		AND ADO.EMIdEstatus = 2
		AND (@FechaInicio IS NULL OR CAST(ADO.EMFechaDel AS DATE) >= @FechaInicio)
		AND (@FechaFin IS NULL OR CAST(ADO.EMFechaDel AS DATE) <= @FechaFin) THEN 1 


		WHEN @IdEstatusN IS NULL AND (
		ADO.EMIdEstatus = 1
		AND 
		(@FechaInicio IS NULL OR CAST(ADO.EMFechaAdd AS DATE) >= @FechaInicio)
		AND (@FechaFin IS NULL OR CAST(ADO.EMFechaAdd AS DATE) <= @FechaFin) 
	OR	
		ADO.EMIdEstatus = 2
		AND (@FechaInicio IS NULL OR CAST(ADO.EMFechaDel AS DATE) >= @FechaInicio)
		AND (@FechaFin IS NULL OR CAST(ADO.EMFechaDel AS DATE) <= @FechaFin) 
		)
		THEN 1 

		ELSE 0 END=1
-- >>>> FIN

		-- AND (@IdEstatusN IS NULL OR ADO.EMIdEstatus = @IdEstatusN)
		AND (@IdParentescoN IS NULL OR ADO.EMIdParentesco IN 
								(SELECT ParsedString FROM dbo.ParseStringList(@IdParentescoN) 
									WHERE ParsedString = ADO.EMIdParentesco))
		AND (@IdPerfilN IS NULL OR ADO.EMIdPerfil IN 
								(SELECT ParsedString FROM dbo.ParseStringList(@IdPerfilN) 
									WHERE ParsedString = ADO.EMIdPerfil))
-- By LM20052020 Null Values were not considered in the initial query
--		AND (ADO.EMNumeroEmpleado NOT LIKE '%TEST%' AND ADO.EMNumeroEmpleado NOT LIKE 'PR%')
AND (isnull(ADO.EMNumeroEmpleado,'') NOT LIKE 'TEST%' 
-- AND isnull(ADO.EMNumeroEmpleado,'') NOT LIKE 'PR%'
)
		--AND (TIT.EMNumeroEmpleado NOT LIKE '%TEST%' AND TIT.EMNombre1 NOT LIKE '%TEST%' AND TIT.EMNombre2 NOT LIKE '%TEST%' AND TIT.EMApellidoPaterno NOT LIKE '%TEST%' AND TIT.EMApellidoMaterno NOT LIKE '%TEST%')
		--AND (TIT.EMNumeroEmpleado NOT LIKE 'PR%' AND TIT.EMNombre1 NOT LIKE 'PR%' AND TIT.EMNombre2 NOT LIKE 'PR%' AND TIT.EMApellidoPaterno NOT LIKE 'PR%' AND TIT.EMApellidoMaterno NOT LIKE 'PR%')
	--ORDER BY ADO.EMIdEmpresa,ADO.EMNumeroEmpleado,ADO.EMIdParentesco,ADO.EMApellidoPaterno, ADO.Id
	ORDER BY ADO.EMIdEmpresa,ADO.EMNumeroEmpleado
	
END
GO

