package com.lockton.WSBeFlex.DAO.ArchivosAdjuntos;

public interface ProcesaFormatosDAO {

    void validarPropietario(int idEmpleado, DatosConstanciaFiscal datos);

    String guardarDatos(int idEmpleado, int idAdministrador, DatosConstanciaFiscal datos);

    /** Datos extraidos de una Constancia de Situacion Fiscal. */
    class DatosConstanciaFiscal {
        private String lugarFechaEmision = "";
        private String fechaEmision = "";
        private String rfc = "";
        private String curp = "";
        private String codigoPostal = "";
        private String tipoVialidad = "";
        private String nombreVialidad = "";
        private String noExterior = "";
        private String noInterior = "";
        private String nombreColonia = "";
        private String nombreLocalidad = "";
        private String municipio = "";
        private String nombreEntidadFederativa = "";
        private String correoElectronico = "";
        private String telefono = "";
        private String regimen = "";
        private String primerRegimen = "";

        public String getLugarFechaEmision() { return lugarFechaEmision; }
        public void setLugarFechaEmision(String valor) { lugarFechaEmision = valorSeguro(valor); }
        public String getFechaEmision() { return fechaEmision; }
        public void setFechaEmision(String valor) { fechaEmision = valorSeguro(valor); }
        public String getRfc() { return rfc; }
        public void setRfc(String valor) { rfc = valorSeguro(valor); }
        public String getCurp() { return curp; }
        public void setCurp(String valor) { curp = valorSeguro(valor); }
        public String getCodigoPostal() { return codigoPostal; }
        public void setCodigoPostal(String valor) { codigoPostal = valorSeguro(valor); }
        public String getTipoVialidad() { return tipoVialidad; }
        public void setTipoVialidad(String valor) { tipoVialidad = valorSeguro(valor); }
        public String getNombreVialidad() { return nombreVialidad; }
        public void setNombreVialidad(String valor) { nombreVialidad = valorSeguro(valor); }
        public String getNoExterior() { return noExterior; }
        public void setNoExterior(String valor) { noExterior = valorSeguro(valor); }
        public String getNoInterior() { return noInterior; }
        public void setNoInterior(String valor) { noInterior = valorSeguro(valor); }
        public String getNombreColonia() { return nombreColonia; }
        public void setNombreColonia(String valor) { nombreColonia = valorSeguro(valor); }
        public String getNombreLocalidad() { return nombreLocalidad; }
        public void setNombreLocalidad(String valor) { nombreLocalidad = valorSeguro(valor); }
        public String getMunicipio() { return municipio; }
        public void setMunicipio(String valor) { municipio = valorSeguro(valor); }
        public String getNombreEntidadFederativa() { return nombreEntidadFederativa; }
        public void setNombreEntidadFederativa(String valor) { nombreEntidadFederativa = valorSeguro(valor); }
        public String getCorreoElectronico() { return correoElectronico; }
        public void setCorreoElectronico(String valor) { correoElectronico = valorSeguro(valor); }
        public String getTelefono() { return telefono; }
        public void setTelefono(String valor) { telefono = valorSeguro(valor); }
        public String getRegimen() { return regimen; }
        public void setRegimen(String valor) { regimen = valorSeguro(valor); }
        public String getPrimerRegimen() { return primerRegimen; }
        public void setPrimerRegimen(String valor) { primerRegimen = valorSeguro(valor); }

        private String valorSeguro(String valor) {
            return valor == null ? "" : valor.trim();
        }
    }

}
