# Comandos Git sugeridos

Ejecutar dentro de clones Git reales. La carpeta BAC usada para preparar la entrega no contiene `.git`.

## Backend

```powershell
cd "C:\ruta\al\repositorio-backend"
git status --short
git switch -c feature/constancia-fiscal-bac

git add -- `
  src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/ProcesaFormatosDAO.java `
  src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/JDBCProcesaFormatos.java `
  src/main/java/com/lockton/WSBeFlex/Services/LogicaFfArchivosAdjuntos.java `
  src/main/java/com/lockton/WSBeFlex/REST/WSArchivosAdjuntos.java

git diff --cached --check
git diff --cached --stat
.\mvnw.cmd clean test
git commit -m "fix: completa procesamiento de constancia fiscal"
git push -u origin feature/constancia-fiscal-bac
```

Si no existe Maven Wrapper, utilizar `mvn clean test`. El build completo requiere las dependencias internas del proyecto.

## Frontend

```powershell
cd "C:\ruta\al\repositorio-frontend"
git status --short
git switch -c feature/constancia-fiscal-bac

git add -- `
  src/app/services/API-CoE.service.ts `
  src/app/beflex/master/misdatosfiscalesmaster/misdatosfiscalesmaster.component.ts

git diff --cached --check
git diff --cached --stat
npm ci
.\node_modules\.bin\tsc.cmd -p src/tsconfig.app.json --noEmit
git commit -m "fix: completa carga y mapeo de constancia fiscal"
git push -u origin feature/constancia-fiscal-bac
```

## Validacion de base de datos

No hay migracion. Ejecutar solamente:

```powershell
sqlcmd -S "(localdb)\MSSQLLocalDB" -d "FlexiForbesv2" -E -b -i ".\BD\01_VALIDAR_PRERREQUISITOS.sql"
```
