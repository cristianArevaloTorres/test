# Constancia Fiscal sobre BAC actualizado - sin archivos Java nuevos

Fecha: 2026-10-07

Esta entrega fue preparada sobre el codigo actualizado de `BAC/WSBeFlex-EmpAdm-QA`.

No crea archivos Java adicionales. El modelo de datos de la constancia se integro en `ProcesaFormatosDAO.java` y el parser del SAT se integro en `LogicaFfArchivosAdjuntos.java`.

## Comportamiento incluido

- Lee una Constancia de Situacion Fiscal en PDF.
- Valida token JWT, extension, tipo, firma PDF, limite de 10 MB y contenido legible.
- Extrae fecha, RFC, CURP, codigo postal, domicilio, correo, telefono y regimenes.
- Valida que RFC y CURP correspondan al empleado.
- Muestra la direccion como nombre de vialidad mas numero exterior.
- Cuando existen varios regimenes, muestra/selecciona el primero y guarda todos separados por coma.
- Llama a `dbo.bf_AltaConstanciaEmpleado` con sus 18 parametros reales, sin `JsonCampos`.
- Espera la respuesta del backend antes de mostrar exito en el frontend.
- Conserva las funciones de regeneracion que ya contiene el BAC actualizado.

## Archivos Java existentes modificados

- `JAVA/src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/ProcesaFormatosDAO.java`
- `JAVA/src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/JDBCProcesaFormatos.java`
- `JAVA/src/main/java/com/lockton/WSBeFlex/Services/LogicaFfArchivosAdjuntos.java`
- `JAVA/src/main/java/com/lockton/WSBeFlex/REST/WSArchivosAdjuntos.java`

## Archivos frontend modificados

- `FRONT/src/app/services/API-CoE.service.ts`
- `FRONT/src/app/beflex/master/misdatosfiscalesmaster/misdatosfiscalesmaster.component.ts`

## Base de datos

No se requiere migracion para la base revisada:

- Servidor: `(localdb)\MSSQLLocalDB`
- Base: `FlexiForbesv2`
- Procedimiento: `dbo.bf_AltaConstanciaEmpleado`

`BD/01_VALIDAR_PRERREQUISITOS.sql` solamente valida que el procedimiento tenga la firma esperada. No modifica datos ni objetos.

## Validaciones realizadas

- Las cuatro clases Java afectadas compilaron con Java 11 y dependencias Spring Boot 2.7.18.
- El parser integrado paso una prueba con una constancia SAT real.
- La prueba de multiples regimenes conservo todos y selecciono el primero.
- La validacion TypeScript del frontend termino correctamente.
- La firma del procedimiento tiene los 18 parametros esperados.

## Instalacion

1. Copiar `JAVA/src` sobre `src` del backend actualizado.
2. Copiar `FRONT/src` sobre `src` del frontend actualizado.
3. Ejecutar el script de validacion de `BD` en el ambiente destino.
4. Compilar y probar desde una rama nueva.

Los comandos Git sugeridos estan en `COMANDOS_GIT.md`.

## Limitacion del ambiente local

El build Maven completo depende del archivo interno `ServiciosLockton-1.1.jar`, que no existe en la copia local de BAC y puede requerir acceso interno/VPN. El archivo no forma parte de esta entrega. Esta condicion es previa a los cambios.
