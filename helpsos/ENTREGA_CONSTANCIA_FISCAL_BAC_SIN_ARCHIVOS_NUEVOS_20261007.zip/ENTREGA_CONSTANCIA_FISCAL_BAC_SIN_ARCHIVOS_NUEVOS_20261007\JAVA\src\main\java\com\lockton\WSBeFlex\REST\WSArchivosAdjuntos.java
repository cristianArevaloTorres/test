package com.lockton.WSBeFlex.REST;

import com.lockton.WSBeFlex.Services.FfArchivosAdjuntosService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.LogicaFfArchivosAdjuntos.LimpiezaAnexosResult;
import com.lockton.WSBeFlex.Services.LogicaFfArchivosAdjuntos.MergePdfResult;
import com.lockton.WSBeFlex.Services.LogicaFfArchivosAdjuntos.ProcesaFormatosResult;
import com.lockton.WSBeFlex.POJO.Especiales.LimpiarAnexosRegeneracion;
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;

import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Entities;
import org.jsoup.nodes.Document.OutputSettings;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.util.MultiValueMap;

@RestController
@RequestMapping("beflex")
public class WSArchivosAdjuntos {
  private static final Log bitacora = LogFactory.getLog(WSArchivosAdjuntos.class);

  @Autowired
  FfArchivosAdjuntosService archivosAdjuntos;

  @Autowired
  JwtService jwtService;


@PostMapping("/consentimientos")
public ResponseEntity<?> crearConsentimiento(@RequestParam MultiValueMap<String, String> req) {
    int bplannew = 0;
    System.out.println("\n\n\n\n Parámetros recibidos en consentimientos: " + req + "\n\n\n\n");

    try {
        Map<String, Object> convertedReq = new HashMap<>();
        for (Entry<String, List<String>> entry : req.entrySet()) {
            convertedReq.put(entry.getKey(), entry.getValue().get(0));
        }
         if ("true".equalsIgnoreCase(req.getFirst("generaConsentimiento"))){
            ResponseEntity<?> data;
            data = archivosAdjuntos.crearConsentimiento(convertedReq);
            return data;
        }
        else{
            archivosAdjuntos.crearConsentimiento(convertedReq);
        }
        bplannew = 1;
    } catch (Exception e) {
        bitacora.error(e.getMessage());
        return new ResponseEntity<Void>(HttpStatus.CONFLICT);
    }

    if (bplannew == 1) {
        return new ResponseEntity<Void>(HttpStatus.OK);
    } else {
        return new ResponseEntity<Void>(HttpStatus.CONFLICT);
    }
}

@PostMapping("/consentimientos-regeneracion")
public ResponseEntity<?> consentimientosRegeneracion(@RequestParam MultiValueMap<String, String> req) {
    int bplannew = 0;
    try {
        Map<String, Object> convertedReq = new HashMap<>();
        for (Entry<String, List<String>> entry : req.entrySet()) {
            convertedReq.put(entry.getKey(), entry.getValue().get(0));
        }
        archivosAdjuntos.consentimientosRegeneracion(convertedReq);
        bplannew = 1;
    } catch (Exception e) {
        bitacora.error(e.getMessage());
        return new ResponseEntity<Void>(HttpStatus.CONFLICT);
    }
    return bplannew == 1 ? 
       new ResponseEntity<Void>(HttpStatus.OK)
     : new ResponseEntity<Void>(HttpStatus.CONFLICT);
}

@PostMapping("/merge/pdf")
public ResponseEntity<MergePdfResult> mergePdf(
    @RequestParam("idCorporativo") String idCorporativo,
    @RequestParam("idEmpresa") String idEmpresa,
    @RequestParam("idEmpleado") String idEmpleado,
    @RequestParam("idSolicitud") String idSolicitud,
    @RequestParam("file") String file,
    @RequestParam("anexos") String anexos,
    @RequestParam("consentimeinto") String consentimeinto,
    @RequestParam("numeroEmpleado") String numeroEmpleado
) {
    Map<String, Object> req = new HashMap<>();
    req.put("idCorporativo", idCorporativo);
    req.put("idEmpresa", idEmpresa);
    req.put("idEmpleado", idEmpleado);
    req.put("idSolicitud", idSolicitud);
    req.put("file", file);
    req.put("anexos", anexos);
    req.put("consentimeinto", consentimeinto);
    req.put("numeroEmpleado", numeroEmpleado);

    System.out.println("\n\n\n\n Parámetros recibidos en mergePdf: " + req + "\n\n\n\n");

    MergePdfResult result;

    try {
        result = archivosAdjuntos.mergePdf(req);
    } catch (Exception e) {
        System.out.println("\n\n\n\n Parámetros recibidos en mergePdf catch: " + req + "\n\n\n\n");
        System.out.println("\n\n\n\n Error: " + e + "\n\n\n\n");
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }

    if (result != null) {
        return new ResponseEntity<>(result, HttpStatus.OK);
    } else {
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }
}

@PostMapping("/merge/pdf-regeneracion")
public ResponseEntity<MergePdfResult> mergePdfRegeneracion(
    @RequestParam("idCorporativo") String idCorporativo,
    @RequestParam("idEmpresa") String idEmpresa,
    @RequestParam("idEmpleado") String idEmpleado,
    @RequestParam("idSolicitud") String idSolicitud,
    @RequestParam("file") String file,
    @RequestParam("anexos") String anexos,
    @RequestParam("consentimeinto") String consentimeinto,
    @RequestParam("numeroEmpleado") String numeroEmpleado
) {
    Map<String, Object> req = new HashMap<>();
    req.put("idCorporativo", idCorporativo);
    req.put("idEmpresa", idEmpresa);
    req.put("idEmpleado", idEmpleado);
    req.put("idSolicitud", idSolicitud);
    req.put("file", file);
    req.put("anexos", anexos);
    req.put("consentimeinto", consentimeinto);
    req.put("numeroEmpleado", numeroEmpleado);

    System.out.println("\n\n\n\n Parámetros recibidos en mergePdfConsentimiento: " + req + "\n\n\n\n");
    MergePdfResult result;

    try {
        result = archivosAdjuntos.mergePdfRegeneracion(req);
    } catch (Exception e) {
        System.out.println("\n\n\n\n Parámetros recibidos en mergePdf catch: " + req + "\n\n\n\n");
        System.out.println("\n\n\n\n Error: " + e + "\n\n\n\n");
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }

    if (result != null) {
        return new ResponseEntity<>(result, HttpStatus.OK);
    } else {
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }
}



  @PostMapping("/anexos")
  public ResponseEntity<Void> anexos(@RequestBody Map<String, Object> req) {
    int status = 0;
    try {
      archivosAdjuntos.anexos(req);
      status = 1;
    } catch (Exception e) {
      bitacora.error(e.getMessage());
      return new ResponseEntity<Void>(HttpStatus.CONFLICT);
    }
    if (status == 1) {
      return new ResponseEntity<Void>(HttpStatus.OK);
    } else {
      return new ResponseEntity<Void>(HttpStatus.CONFLICT);
    }
  }
  
@SuppressWarnings("null")
@PostMapping("/limpiar/anexos")
public ResponseEntity<LimpiezaAnexosResult> limpiarAnexos(@RequestParam Map<String, String> req) {
    try {
        LimpiezaAnexosResult result = archivosAdjuntos.limpiarAnexos(req);
        bitacora.error("Resultado de limpiar anexos:"+result);

        return ResponseEntity.ok(result);
    } catch (Exception e) {
        System.out.println(e);
        bitacora.error(e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new LimpiezaAnexosResult(false, e.getMessage(), null));
    }
}



      @PostMapping("/limpiar/anexos-regeneracion")
    public ResponseEntity<Map<String, Object>> limpiarAnexosRegeneracion(
            @RequestBody LimpiarAnexosRegeneracion limpiarAnexosRegeneracionDTO) {
        Map<String, Object> response = new HashMap<>(); 
        try {
            int idEmpleado = limpiarAnexosRegeneracionDTO.getIdEmpleado();
            int idCorporativo = limpiarAnexosRegeneracionDTO.getIdCorporativo();
            int idEmpresa = limpiarAnexosRegeneracionDTO.getIdEmpresa(); 
            int numeroEmpleado  = limpiarAnexosRegeneracionDTO.getNumeroEmpleado();

            List<String> respuesta = archivosAdjuntos.limpiarAnexosRegeneracion(idEmpleado, idCorporativo, idEmpresa, numeroEmpleado);

            if(respuesta == null){
                response.put("ok", false); 
        	    response.put("message", "Error al limpiar anexos regeneracion, respuesta null");
                bitacora.error("Error al limpiar anexos regeneracion");
                return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
            }

            response.put("ok", true); 
            response.put("files", respuesta);
            return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("ok", false); 
        	response.put("message", "Error al limpiar anexos regeneracion");
			bitacora.error("Error: " + e.getMessage());
            return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
        }


    }

  @PostMapping("/convert")
    public ResponseEntity<InputStreamResource> htmlToPdf(@RequestBody String htmlContent) {
        try {
            if (htmlContent == null || htmlContent.trim().isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }

            String path="C:\\beflex3\\beflex3restfullservices\\server\\public\\PdfbeFlexSolutions";
           //String path="C:\\Users\\con_sygno4\\Desktop\\pdf";

            Document doc = Jsoup.parse(htmlContent);
            doc.outputSettings()
                .syntax(OutputSettings.Syntax.xml)
                .escapeMode(Entities.EscapeMode.xhtml)
                .prettyPrint(true);

            String xhtml = doc.html();

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            PdfRendererBuilder builder = new PdfRendererBuilder();
            builder.useFastMode();
            builder.withHtmlContent(xhtml, null);
            builder.toStream(byteArrayOutputStream);
            builder.run();

            byte[] pdfBytes = byteArrayOutputStream.toByteArray();

            try {
                File outputDir = new File(path);
                if (!outputDir.exists()) {
                    outputDir.mkdirs();
                }

                File outputFile = new File(outputDir, "solicitud.pdf");
                try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                    fos.write(pdfBytes);
                    System.out.println("PDF guardado en disco correctamente: " + outputFile.getAbsolutePath());
                }
            } catch (Exception fileSaveException) {
                System.out.println("⚠️ No se pudo guardar el PDF en disco: " + fileSaveException.getMessage());
            }

            // 🔽 Retornar el PDF como respuesta HTTP
            ByteArrayInputStream inputStream = new ByteArrayInputStream(pdfBytes);
            InputStreamResource resource = new InputStreamResource(inputStream);

            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=solicitud.pdf");

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentLength(pdfBytes.length)
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(resource);

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }




    @PostMapping(value = "/ProcesaFormatos", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> procesaFormatos(
            @RequestParam("idEmpleado") int idEmpleado,
            @RequestParam(value = "idAdministrador", defaultValue = "0") int idAdministrador,
            @RequestParam("archivo") MultipartFile archivo,
            @RequestHeader("authorization") String token) {
        try {
            Object jwt = jwtService.validarToken(token);
            if (jwt == null || Objects.equals(jwt.toString(), "error")
                    || Objects.equals(jwt.toString(), "Unauthorized")) {
                return new ResponseEntity<>(
                        ProcesaFormatosResult.error("No autorizado"),
                        HttpStatus.UNAUTHORIZED);
            }

            return archivosAdjuntos.procesaFormatos(idEmpleado, idAdministrador,archivo);

        } catch (Exception e) {
            bitacora.error("Error al validar la solicitud de constancia fiscal", e);
            return new ResponseEntity<>(
                    ProcesaFormatosResult.error("No autorizado"),
                    HttpStatus.UNAUTHORIZED);
        }
    }


}
