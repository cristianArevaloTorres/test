package com.lockton.WSBeFlex.Services;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.Normalizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.lockton.WSBeFlex.Constantes;
import com.lockton.WSBeFlex.DAO.ArchivosAdjuntos.ProcesaFormatosDAO;
import com.lockton.WSBeFlex.DAO.ArchivosAdjuntos.ProcesaFormatosDAO.DatosConstanciaFiscal;
import com.lockton.WSBeFlex.DAO.JDBCDocumento;
import com.lockton.WSBeFlex.DAO.JDBCParametro;
import com.lockton.WSBeFlex.DAO.JDBCPlan;
import com.lockton.WSBeFlex.DAO.JDBCTextosReportes;
import com.lockton.WSBeFlex.DAO.JDBCVigencias;
import com.lockton.WSBeFlex.POJO.Especiales.DocumentoSolicitud;
import com.lockton.WSBeFlex.POJO.Especiales.EmpleadoDocumento;
import com.lockton.WSBeFlex.POJO.Especiales.FfGetParametro;
import com.lockton.WSBeFlex.POJO.Especiales.FfGetVigenciaXEmpresa;
import com.lockton.WSBeFlex.POJO.Especiales.ReportesConsentimientoVida;
import com.lockton.WSBeFlex.POJO.Especiales.VigenciasAnexoRegeneracion;

/**
 * 
 * @author Nicolas Contreras / NikoVonter
 * @since 1.0
 */
@Service
public class LogicaFfArchivosAdjuntos implements FfArchivosAdjuntosService {

    private static final Log bitacora = LogFactory.getLog(LogicaFfArchivosAdjuntos.class);
    private static final long TAMANO_MAXIMO_CONSTANCIA = 10000000L;

    private static ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private JDBCPlan jdbcPlan;

    @Autowired
    private JDBCTextosReportes TextosReportes;

    @Autowired
    private JDBCDocumento newdoc;

    @Autowired
    JDBCVigencias vigencias;

    @Autowired
    JDBCParametro jdbcParametro;

    @Autowired
    FfPreviewBeMobileService ff_beMobile;

    @Autowired
    VigenciasService servicioVigencias;

    @Autowired
    ProcesaFormatosDAO procesaFormatosDAO;

    @Override
    public ResponseEntity<?> crearConsentimiento(Map<String, Object> req) {
        try {
            int idCorporativo = Integer.parseInt((String) req.get("idCorporativo"));
            int idPlanOpcion = Integer.parseInt((String) req.get("idPlanOpcion"));
            int idTitular = Integer.parseInt((String) req.get("idTitular"));
            int idDependiente = Integer.parseInt((String) req.get("idDependiente"));
            int idPlan = Integer.parseInt((String) req.get("idPlan"));
            int idEmpresa = Integer.parseInt((String) req.get("idEmpresa"));
            String numEmpleado = (String) req.get("numEmpleado");
            int idEmpleado = Integer.parseInt((String) req.get("idEmpleado"));
            int idSolicitud = Integer.parseInt((String) req.get("idSolicitud"));
            int idAsegurado = Integer.parseInt((String) req.get("idAsegurado"));
            int num = Integer.parseInt((String) req.get("num"));

            List<ReportesConsentimientoVida> spResults = jdbcPlan.consentimientoVidaDatosGeneralesB3(idTitular,
                    idPlanOpcion, idPlan);
            if (spResults.isEmpty()) {
                return ResponseEntity.notFound().build(); // Si no hay resultados
            }

            ReportesConsentimientoVida spResult = spResults.get(0);
            String cvDataSourceDatos = spResult.getCvDataSourceDatos();
            int inicio = spResult.getCvCampoInicialBeneficiario();
            String prefijo = spResult.getCvCampoPrefijo();

            Object fill = TextosReportes.consultarDatosGeneralesReporte2(idTitular, idDependiente, idPlan, idPlanOpcion,
                    cvDataSourceDatos);

            List<List<Map<String, Object>>> result = convertToListOfListsOfMaps(fill);

            Map<String, Object> mergedData = mergeResults(result);

            mergedData = formatTxt(result, inicio, prefijo);

            sanitizeData(mergedData);

            String sourcePdf = Constantes.UPLOAD_FOLDER + "\\" + spResult.getCvRutaFormato().split("\\.\\.\\/")[1];
            String urlDestination = Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa
                    + "\\Documento_Empleado\\"
                    + getVigencia(idCorporativo) + "\\Consentimientos";
            String ruta = String.format("%s\\%s_consentimientosBeneficiario%s_%s_%s_%s_%s.pdf",
                    urlDestination, numEmpleado, idEmpleado, idSolicitud, idPlan, idAsegurado, num);

            String ruta2 = "DocumentoEmpresa\\" + idEmpresa + "\\Documento_Empleado\\" + getVigencia(idCorporativo)
                    + "\\Consentimientos" + "\\" + numEmpleado + "_consentimientosBeneficiario" + idEmpleado + "_"
                    + idSolicitud + "_" + idPlan + "_" + idAsegurado + "_" + num + ".pdf";

            fillPdf(sourcePdf, ruta, mergedData);
            guardarEmpleadoDocumento(idEmpleado, Integer.toString(idEmpresa), numEmpleado,
                    Integer.toString(idSolicitud), idPlan, Integer.toString(idAsegurado), num, ruta2);

            File file = new File(ruta);
            if (!file.exists()) {
                return ResponseEntity.notFound().build();
            }
            String filename = String.format("%s_consentimientosBeneficiario%s_%s_%s_%s_%s.pdf",
                    numEmpleado, idEmpleado, idSolicitud, idPlan, idAsegurado, num);
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                    .body(Files.readAllBytes(Paths.get(ruta)));

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("ok", false);
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    @Override
    public ResponseEntity<?> consentimientosRegeneracion(Map<String, Object> req) {
        try {
            int idCorporativo = Integer.parseInt((String) req.get("idCorporativo"));
            int idPlanOpcion = Integer.parseInt((String) req.get("idPlanOpcion"));
            int idTitular = Integer.parseInt((String) req.get("idTitular"));
            int idDependiente = Integer.parseInt((String) req.get("idDependiente"));
            int idPlan = Integer.parseInt((String) req.get("idPlan"));
            int idEmpresa = Integer.parseInt((String) req.get("idEmpresa"));
            String numEmpleado = (String) req.get("numEmpleado");
            int idEmpleado = Integer.parseInt((String) req.get("idEmpleado"));
            int idSolicitud = Integer.parseInt((String) req.get("idSolicitud"));
            int idAsegurado = Integer.parseInt((String) req.get("idAsegurado"));
            int num = Integer.parseInt((String) req.get("num"));

            List<ReportesConsentimientoVida> spResults = jdbcPlan.consentimientoVidaDatosGeneralesB3(idTitular,
                    idPlanOpcion, idPlan);
            if (spResults.isEmpty())
                return ResponseEntity.notFound().build();

            List<Object> lstVigencias = ff_beMobile.ObtenerVigenciaActiva(idEmpresa);
            List<?> lstVigencia = (List<?>) lstVigencias.get(0);
            Map<String, Object> vigencia = (Map<String, Object>) lstVigencia.get(0);
            int idVigencia = vigencia.get("VIidVigencia") != null ? (int) vigencia.get("VIidVigencia") : 0;

            ReportesConsentimientoVida spResult = spResults.get(0);
            String cvDataSourceDatos = spResult.getCvDataSourceDatos();
            int inicio = spResult.getCvCampoInicialBeneficiario();
            String prefijo = spResult.getCvCampoPrefijo();
            Object fill = TextosReportes.consultarDatosGeneralesReporte(idTitular, idDependiente, idPlan, idPlanOpcion,
                    cvDataSourceDatos);

            List<List<Map<String, Object>>> result = convertToListOfListsOfMaps(fill);
            Map<String, Object> mergedData = mergeResults(result);
            mergedData = formatTxt(result, inicio, prefijo);
            sanitizeData(mergedData);

            String sourcePdf = Constantes.UPLOAD_FOLDER + "\\" + spResult.getCvRutaFormato().split("\\.\\.\\/")[1];
            String urlDestination = idVigencia > 0
                    ? Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa + "\\Documento_Empleado\\"
                            + getVigencia(idCorporativo) + "\\Consentimientos"
                    : Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa + "\\Solicitud\\";

            String ruta = String.format("%s\\%s_consentimientosBeneficiario%s_%s_%s_%s_%s.pdf",
                    urlDestination, numEmpleado, idEmpleado, idSolicitud, idPlan, idAsegurado, num);
            String ruta2 = "DocumentoEmpresa\\" + idEmpresa + "\\Documento_Empleado\\" + getVigencia(idCorporativo)
                    + "\\Consentimientos" + "\\" + numEmpleado + "_consentimientosBeneficiario" + idEmpleado + "_"
                    + idSolicitud + "_" + idPlan + "_" + idAsegurado + "_" + num + ".pdf";

            fillPdf(sourcePdf, ruta, mergedData);
            guardarEmpleadoDocumento(idEmpleado, Integer.toString(idEmpresa), numEmpleado,
                    Integer.toString(idSolicitud), idPlan, Integer.toString(idAsegurado), num, ruta2);

            File file = new File(ruta);
            if (!file.exists()) {
                return ResponseEntity.notFound().build();
            }
            String filename = String.format("%s_consentimientosBeneficiario%s_%s_%s_%s_%s.pdf",
                    numEmpleado, idEmpleado, idSolicitud, idPlan, idAsegurado, num);
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                    .body(Files.readAllBytes(Paths.get(ruta)));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("ok", false);
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    private void sanitizeData(Map<String, Object> data) {
        data.replaceAll((key, value) -> (value == null || "null".equalsIgnoreCase(value.toString())) ? "" : value);
    }

    static Map<String, Object> formatTxt(List<List<Map<String, Object>>> obj, int i, String prefijo) {

        Map<String, Object> jsonVariable = new HashMap<>();
        List<Map<String, Object>> encabezadoFinal = new ArrayList<>();
        Map<String, Object> leyenda = new HashMap<>();
        Map<String, Object> porcentajes = new HashMap<>();

        for (List<Map<String, Object>> list : obj) {
            if (list.isEmpty()) {
                list.add(Collections.singletonMap("Tabla", "tabla2"));
            }
        }

        if (obj.size() == 1 && "tabla1".equals(obj.get(0).get(0).get("Tabla"))) {
            encabezadoFinal = parseEncabezado(obj.get(0));
        } else if (obj.size() > 1 && ("tabla2".equals(obj.get(1).get(0).get("Tabla")) || obj.get(1).isEmpty())) {
            encabezadoFinal = parseEncabezado(obj.get(0));
            porcentajes = getValueOrDefault(obj, 3);
            leyenda = getValueOrDefault(obj, 2);
            jsonVariable = processInputData(obj.get(1), prefijo, i);
        } else if (obj.size() > 2 && ("tabla2".equals(obj.get(2).get(0).get("Tabla")) || obj.get(2).isEmpty())) {
            encabezadoFinal = parseEncabezado(obj.get(0));
            porcentajes = getValueOrDefault(obj, 3);
            leyenda = getValueOrDefault(obj, 1);
            jsonVariable = processInputData(obj.get(2), prefijo, i);
        } else if (obj.size() > 0 && ("tabla2".equals(obj.get(0).get(0).get("Tabla")) || obj.get(0).isEmpty())) {
            System.out.println("Entro tabla 1");
            encabezadoFinal = parseEncabezado(obj.get(1));
            porcentajes = getValueOrDefault(obj, 3);
            leyenda = getValueOrDefault(obj, 2);
            jsonVariable = processInputData(obj.get(0), prefijo, i);
        } else if (obj.size() > 3 && obj.get(3) != null) {
            System.out.println("Entra a validar y este es el tamaño " + obj.size());
            if ("tabla2".equals(obj.get(3).get(0).get("Tabla")) || obj.get(3).isEmpty()) {
                System.out.println("Entro tabla 1");
                encabezadoFinal = parseEncabezado(obj.get(1));
                porcentajes = getValueOrDefault(obj, 3);
                leyenda = getValueOrDefault(obj, 2);
                jsonVariable = processInputData(obj.get(3), prefijo, i);
            }
            if (obj.size() == 4 && "tablaAuto4".equals(obj.get(0).get(0).get("Tabla"))) {
                System.out.println("estoy en este nuevo");
                encabezadoFinal = parseEncabezado(obj.get(1));
                porcentajes = getValueOrDefault(obj, 3);
                leyenda = getValueOrDefault(obj, 2);
                jsonVariable = obj.get(0).get(0);
            }
        }

        return mergeMaps(encabezadoFinal.isEmpty() ? new HashMap<>() : encabezadoFinal.get(0), jsonVariable, leyenda,
                porcentajes);
    }

    private static List<Map<String, Object>> parseEncabezado(List<Map<String, Object>> encabezado) {
        String json = new Gson().toJson(encabezado);
        String nuevo = json.replace("NULL", "\"\"");
        return new Gson().fromJson(nuevo, List.class);
    }

    private static Map<String, Object> getValueOrDefault(List<List<Map<String, Object>>> obj, int index) {
        return (index < obj.size() && !obj.get(index).isEmpty()) ? obj.get(index).get(0) : new HashMap<>();
    }

    private static Map<String, Object> processInputData(List<Map<String, Object>> input, String prefijo,
            int startIndex) {
        Map<String, Object> jsonVariable = new HashMap<>();
        int count = startIndex;

        for (Map<String, Object> element : input) {
            for (Object x : element.values()) {
                String res = String.valueOf(x).replace("NULL", "\"\"").replace("null", "\"\"");
                if (!"tabla2".equals(res)) {
                    jsonVariable.put(prefijo + (count < 10 ? "0" : "") + count, res);
                    count++;
                }
            }
        }
        return jsonVariable;
    }

    private static Map<String, Object> mergeMaps(Map<String, Object>... maps) {
        Map<String, Object> result = new HashMap<>();
        for (Map<String, Object> map : maps) {
            result.putAll(map);
        }
        return result;
    }

    @Override
    public MergePdfResult mergePdfRegeneracion(Map<String, Object> req) {
        try {
            String idCorporativo = (String) req.get("idCorporativo");
            String idEmpresa = (String) req.get("idEmpresa");
            String otrosAnexos = (String) req.get("anexos");
            String consentimeinto = (String) req.get("consentimeinto");
            String idEmpleado = (String) req.get("idEmpleado");
            String idSolicitud = (String) req.get("idSolicitud");
            String file = (String) req.get("file");
            String numEmpleado = (String) req.get("numeroEmpleado");

            Calendar currentDate = Calendar.getInstance();
            String urlSolicitud = Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa + "\\Solicitud\\";
            String name = "Solicitud_" + idEmpleado + "_" + this.yyyymmdd(currentDate) + "_" + idSolicitud + ".pdf";

            List<File> solicitud = this.searchFiles(urlSolicitud, file);
            List<File> array;

            if (consentimeinto.equals("true")) {
                FfGetParametro pa = null;
                pa = jdbcParametro.obtenerParametro(Integer.parseInt(idCorporativo), 143);

                String urlDestination = Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa
                        + "\\Documento_Empleado\\" + getVigencia(Integer.parseInt(idCorporativo)) + "\\Consentimientos";

                if (Integer.parseInt(idCorporativo) > 0) {
                    urlDestination = Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa
                            + "\\Documento_Empleado\\" + getVigencia(Integer.parseInt(idCorporativo))
                            + "\\Consentimientos";
                } else {
                    urlDestination = Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa
                            + "\\Solicitud\\";
                }
                List<File> anexos = this.searchFiles2(urlDestination, numEmpleado);
                System.out.println("PaValor:" + pa.paValor);
                String p1 = pa.paValor.trim();

                if (p1.equals("1")) {
                    array = anexos;
                    array.addAll(solicitud);
                } else {
                    array = solicitud;
                    array.addAll(anexos);
                }

            } else {
                array = solicitud;
            }

            boolean check = this.pdfMerge(urlSolicitud + "\\" + name, array, Integer.parseInt(idEmpleado),
                    Integer.parseInt(idSolicitud), otrosAnexos);

            if (check) {
                String uri = "DocumentoEmpresa/" + idEmpresa + "/Solicitud";
                return new MergePdfResult(true, uri, name);
            } else {
                return new MergePdfResult(false, null, null);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    @Override
    public MergePdfResult mergePdf(Map<String, Object> req) {
        try {

            String idCorporativo = (String) req.get("idCorporativo");
            String idEmpresa = (String) req.get("idEmpresa");
            String otrosAnexos = (String) req.get("anexos");
            String consentimeinto = (String) req.get("consentimeinto");
            String idEmpleado = (String) req.get("idEmpleado");
            String idSolicitud = (String) req.get("idSolicitud");
            String file = (String) req.get("file");
            String numEmpleado = (String) req.get("numeroEmpleado");

            Calendar currentDate = Calendar.getInstance();
            String urlSolicitud = Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa + "\\Solicitud\\";

            String name = "Solicitud_" + idEmpleado + "_" + this.yyyymmdd(currentDate) + "_" + idSolicitud + ".pdf";

            List<File> solicitud = this.searchFiles(urlSolicitud, file);

            List<File> array;

            if (consentimeinto.equals("true")) {

                FfGetParametro pa = null;
                pa = jdbcParametro.obtenerParametro(Integer.parseInt(idCorporativo), 143);

                String urlDestination = Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa
                        + "\\Documento_Empleado\\" + getVigencia(Integer.parseInt(idCorporativo)) + "\\Consentimientos";

                List<File> anexos = this.searchFiles2(urlDestination, numEmpleado);
                System.out.println("PaValor:" + pa.paValor);
                String p1 = pa.paValor.trim();

                if (p1.equals("1")) {
                    array = anexos;
                    array.addAll(solicitud);
                } else {
                    array = solicitud;
                    array.addAll(anexos);
                }
            } else {
                array = solicitud;
            }

            boolean check = this.pdfMerge(urlSolicitud + "\\" + name, array, Integer.parseInt(idEmpleado),
                    Integer.parseInt(idSolicitud), otrosAnexos);

            if (check) {
                String uri = "DocumentoEmpresa/" + idEmpresa + "/Solicitud";
                Map<String, String> reqLimpieza = new HashMap<>();
                reqLimpieza.put("idCorporativo", idCorporativo);
                reqLimpieza.put("idEmpresa", idEmpresa);
                reqLimpieza.put("numeroEmpleado", numEmpleado);

                LimpiezaAnexosResult limpiezaResult = limpiarAnexos(reqLimpieza);
                if (!limpiezaResult.ok) {
                    System.out.println("Error al limpiar anexos: " + limpiezaResult.getMessage());
                } else {
                    System.out.println("Se limpiaron los anexos: " + limpiezaResult.getMessage());
                }
                return new MergePdfResult(true, uri, name);
            } else {
                return new MergePdfResult(false, null, null);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    @Override
    public LimpiezaAnexosResult limpiarAnexos(Map<String, String> req) {
        try {
            int idCorporativo = Integer.parseInt(req.getOrDefault("idCorporativo", "0").trim());
            String idEmpresa = req.getOrDefault("idEmpresa", "").trim();
            String numEmpleado = req.getOrDefault("numeroEmpleado", "").trim();

            String urlDestination = Constantes.UPLOAD_FOLDER + "\\DocumentoEmpresa\\" + idEmpresa
                    + "\\Documento_Empleado\\" + getVigencia(idCorporativo) + "\\Consentimientos";
            File destinationDir = new File(urlDestination);

            if (!destinationDir.exists()) {
                System.out.println("entro al no existe");
                return new LimpiezaAnexosResult(true, "no existe el directorio", null);
            } else {
                List<File> anexos = this.searchFiles2(urlDestination, numEmpleado);

                if (anexos.isEmpty()) {
                    return new LimpiezaAnexosResult(true, "no se encontraron anexos para el usuario", null);
                } else {
                    for (File anexo : anexos) {
                        Files.deleteIfExists(anexo.toPath());
                    }
                    return new LimpiezaAnexosResult(true, null, anexos);
                }
            }
        } catch (Exception e) {
            return new LimpiezaAnexosResult(false, e.getMessage(), null);
        }
    }

    @Override
    public List<String> limpiarAnexosRegeneracion(int idEmpleado, int idCorporativo, int idEmpresa,
            int numeroEmpleado) {
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("ok", false);
        responseMap.put("message", "error");
        try {
            List<FfGetVigenciaXEmpresa> vigencia = consultarVigenciaPorEmpresa(idCorporativo);

            List<Object> vigenciasRaw = ObtenerVigenciaActiva(idEmpresa);
            System.out.println("vigenciasRaw: " + vigenciasRaw);

            Object vigencias0 = vigenciasRaw.get(0);
            System.out.println("vigencias0: " + vigencias0);

            VigenciasAnexoRegeneracion vigencias = convertObjetoAVibenciasAnexoRegeneracion(vigenciasRaw.get(0));

            if (vigencias.getIdVigencia() == null) {
                return null;
            }

            String urlDestination = String.format("%s\\DocumentoEmpresa\\%s\\Documento_Empleado\\%s\\Consentimientos",
                    Constantes.UPLOAD_FOLDER,
                    String.valueOf(idEmpresa),
                    String.valueOf(vigencias.getIdVigencia()));

        } catch (Exception e) {
            bitacora.error("Error: " + e.getMessage());
            return null;
        }

        return null;
    }

    public static VigenciasAnexoRegeneracion convertObjetoAVibenciasAnexoRegeneracion(Object objectList) {

        VigenciasAnexoRegeneracion vigencias = new VigenciasAnexoRegeneracion();

        List<?> list = (List<?>) objectList;

        Object mapObject = list.get(0);

        if (mapObject instanceof Map) {

            @SuppressWarnings("unchecked")
            Map<String, Object> dataMap = (Map<String, Object>) mapObject;

            Integer VIidVigencia = (Integer) dataMap.get("VIidVigencia");
            String VINombre = (String) dataMap.get("VINombre");
            String VINombreCompuesto = (String) dataMap.get("VINombreCompuesto");

            vigencias.setIdVigencia(VIidVigencia);
            vigencias.setVINombre(VINombre);
            vigencias.setVINombreCompuesto(VINombreCompuesto);
            return vigencias;
        } else {
            System.err.println("The first list element is not a Map.");
            return null;
        }
    }

    public List<Object> ObtenerVigenciaActiva(int idEmpresa) {
        List<Object> cc_beMobile = null;

        try {
            cc_beMobile = ff_beMobile.ObtenerVigenciaActiva(idEmpresa);
        } catch (Exception e) {
            return null;
        }
        if (cc_beMobile.isEmpty()) {
            return null;
        }
        return cc_beMobile;

    }

    @Override
    public AnexosResult anexos(Map<String, Object> req) {
        try {
            int idEmpleado = (int) req.get("idEmpleado");
            int idSolicitud = (int) req.get("idSolicitud");

            JDBCDocumento jdbcDocumento = new JDBCDocumento();
            List<DocumentoSolicitud> anexos = jdbcDocumento.getDocumentoSolicitud(idEmpleado, idSolicitud);

            List<File> array = this.formatAnexos(anexos);

            return new AnexosResult(true, array);

        } catch (Exception e) {
            return new AnexosResult(false, e.getMessage());
        }
    }

    public List<File> formatAnexos(List<DocumentoSolicitud> anexosArray) {
        return anexosArray.stream().map(anexo -> {
            String rutaBruto = anexo.getRuta();
            System.out.println(rutaBruto);

            if (rutaBruto != null && !rutaBruto.isEmpty() && !"null".equalsIgnoreCase(rutaBruto)) {
                String[] rutaSplit = rutaBruto.split("\\.\\./");
                return new File(Constantes.UPLOAD_FOLDER + "\\" + rutaSplit[1]);
            } else {
                return new File(Constantes.UPLOAD_FOLDER + "\\vacio");
            }
        }).collect(Collectors.toList());
    }

    public String yyyymmdd(Calendar date) {
        int year = date.get(Calendar.YEAR);
        int month = date.get(Calendar.MONTH) + 1;
        int day = date.get(Calendar.DAY_OF_MONTH);
        int hour = date.get(Calendar.HOUR_OF_DAY);
        int minute = date.get(Calendar.MINUTE);
        int second = date.get(Calendar.SECOND);

        String formattedDate = String.format("%04d%02d%02d%02d%02d%02d",
                year,
                month,
                day,
                hour,
                minute,
                second);

        return formattedDate;
    }

    public List<File> searchFiles(String raiz, String id) {
        List<File> result = new ArrayList<>();
        try {
            Pattern pattern = Pattern.compile(id);

            File rootDir = new File(raiz);
            if (rootDir.exists() && rootDir.isDirectory()) {
                searchFilesRecursively(rootDir, pattern, result);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
        return result;
    }

    private static void searchFilesRecursively(File dir, Pattern pattern, List<File> result) {
        File[] files = dir.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return pattern.matcher(name).find() || new File(dir, name).isDirectory();
            }
        });

        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    searchFilesRecursively(file, pattern, result);
                } else {
                    result.add(file);
                }
            }
        }
    }

    public List<File> searchFiles2(String raiz, String numeroEmpleado) {
        List<File> result = new ArrayList<>();
        try {
            if (raiz == null || raiz.isEmpty() || numeroEmpleado == null || numeroEmpleado.isEmpty()) {
                throw new IllegalArgumentException("La ruta raíz o el número de empleado no deben ser nulos o vacíos.");
            }

            raiz = raiz.trim();
            numeroEmpleado = numeroEmpleado.trim();

            if (!numeroEmpleado.endsWith("_")) {
                numeroEmpleado = numeroEmpleado + "_";
            }

            Pattern pattern = Pattern.compile("(?i).*" + Pattern.quote(numeroEmpleado) + ".*");

            File rootDir = new File(raiz);
            if (rootDir.exists() && rootDir.isDirectory()) {
                searchFilesRecursively2(rootDir, pattern, result);
            } else {
                System.out.println("El directorio raíz no existe o no es un directorio válido: " + raiz);
            }
        } catch (Exception e) {
            System.out.println("Error en searchFiles: " + e.getMessage());
        }
        return result;
    }

    private void searchFilesRecursively2(File dir, Pattern pattern, List<File> result) {
        File[] files = dir.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return pattern.matcher(name).find() || new File(dir, name).isDirectory();
            }
        });

        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    searchFilesRecursively(file, pattern, result);
                } else {
                    result.add(file);
                }
            }
        } else {
            System.out.println("No se pudieron listar los archivos en el directorio: " + dir.getAbsolutePath());
        }
    }

    public boolean pdfMerge(String nombre, List<File> files, int idEmpleado, int idSolicitud, String otrosAnexos) {
        List<File> mergeList = new ArrayList<>(files);

        if ("true".equalsIgnoreCase(otrosAnexos)) {
            List<DocumentoSolicitud> anexos;
            try {
                anexos = newdoc.getDocumentoSolicitud(idEmpleado, idSolicitud);
                List<File> anexosFiles = new ArrayList<>();
                for (DocumentoSolicitud anexo : anexos) {
                    if (anexo != null && anexo.ruta != null && !anexo.ruta.isEmpty()) {
                        File anexoFile = new File(anexo.ruta);
                        if (anexoFile.exists() && anexoFile.isFile()) {
                            anexosFiles.add(anexoFile);
                        }
                    }
                }
                mergeList.addAll(anexosFiles);
            } catch (Exception e) {
                mergeList = files;
            }
        }

        if (mergeList.isEmpty()) {
            return false;
        }

        PDFMergerUtility merger = new PDFMergerUtility();
        merger.setDestinationFileName(nombre);

        try {
            for (File pdf : mergeList) {
                merger.addSource(pdf);
            }
            merger.mergeDocuments(null);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private int getVigencia(int idCorporativo) {

        return vigencias.consultarVigenciaPorEmpresa(idCorporativo).get(0).getIdVigencia();
    }

    private void guardarEmpleadoDocumento(int idEmpleado, String idEmpresa, String numEmpleado, String idSolicitud,
            int idPlan, String idAsegurado, int num, String ruta) {
        try {
            EmpleadoDocumento dataDoc = new EmpleadoDocumento();

            dataDoc.setIdEmpleado(idEmpleado);
            dataDoc.setIdAdmin(idEmpleado);
            dataDoc.setIdSeccionDocumento(15);
            dataDoc.setIdVigencia(getVigencia(Integer.parseInt(idEmpresa)));
            dataDoc.setNombreDocumento(
                    numEmpleado + "_consentimientosBeneficiario" + idEmpleado + "_" + idSolicitud + "_"
                            + idPlan + "_" + idAsegurado + "_" + num);
            dataDoc.setRutaDocumento(ruta);

            System.out.println("\n\n\n\nDatos que serán guardados: " + dataDoc + "\n\n\n\n");
            // newdoc.crearEmpleadoDocumento(dataDoc);
        } catch (Exception e) {
            System.err.println("Error al guardar el documento del empleado: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static Map<String, Object> mergeResults(List<List<Map<String, Object>>> result) {
        Map<String, Object> mergedMap = new LinkedHashMap<>();

        for (List<Map<String, Object>> list : result) {
            for (Map<String, Object> map : list) {
                mergedMap.putAll(map);
            }
        }

        return mergedMap;
    }

    public static List<List<Map<String, Object>>> convertToListOfListsOfMaps(Object fill) {
        if (!(fill instanceof List<?>)) {
            return Collections.emptyList();
        }

        List<List<Map<String, Object>>> result = new ArrayList<>();

        for (Object outerItem : (List<?>) fill) {
            if (!(outerItem instanceof List<?>)) {
                return Collections.emptyList();
            }

            List<Map<String, Object>> mapList = ((List<?>) outerItem).stream()
                    .filter(innerItem -> innerItem instanceof Map<?, ?>)
                    .map(innerItem -> (Map<String, Object>) innerItem)
                    .collect(Collectors.toList());

            result.add(mapList);
        }

        return result;
    }

    public static CompletableFuture<Boolean> fillPdf(String sourcePDF, String destinationPDF,
            Map<String, Object> data) {

        System.out.println("\n\n\n\n\n\n\nInformacion antes de escribir en el pdf: " + data + "\n\n\n\n\n");
        System.out.println("\n\n\n\n\n\n\nsourcePDF: " + sourcePDF + "\n\n\n\n\n");

        return CompletableFuture.supplyAsync(() -> {
            try (PDDocument document = PDDocument.load(new File(sourcePDF))) {
                PDAcroForm acroForm = document.getDocumentCatalog().getAcroForm();
                if (acroForm != null) {

                    for (Map.Entry<String, Object> entry : data.entrySet()) {
                        PDField field = acroForm.getField(entry.getKey());
                        if (field != null) {
                            String value = entry.getValue() != null ? entry.getValue().toString() : "";

                            if (field instanceof PDTextField) {
                                PDTextField textField = (PDTextField) field;
                                textField.setDefaultAppearance("/Helv 8 Tf 0 g");
                            }

                            field.setValue(value);
                            // System.out.println("Campo '" + entry.getKey() + "' llenado con valor: " +
                            // value);
                        } else {
                            // System.out.println("No se encontró el campo '" + entry.getKey() + "' en el
                            // formulario.");
                        }
                    }

                    acroForm.flatten();
                }

                File destFile = new File(destinationPDF);
                if (!destFile.getParentFile().exists()) {
                    Files.createDirectories(destFile.getParentFile().toPath());
                }

                document.save(destFile);
                return true;
            } catch (IOException e) {
                System.err.println("Error al llenar el PDF: " + e.getMessage());
                try {
                    File destFile = new File(destinationPDF);
                    if (!destFile.exists()) {
                        Files.createDirectories(destFile.getParentFile().toPath());
                        Files.copy(Paths.get(sourcePDF), destFile.toPath());
                        System.out.println("Archivo fuente copiado a la ruta de destino: " + destinationPDF);
                    }
                } catch (IOException ex) {
                    System.err.println("Error al copiar el archivo: " + ex.getMessage());
                }
                return false;
            }
        });
    }

    public List<FfGetVigenciaXEmpresa> consultarVigenciaPorEmpresa(int idEmpresa) {

        List<FfGetVigenciaXEmpresa> list_vpev = null;
        try {
            list_vpev = servicioVigencias.consultarVigenciaPorEmpresa(idEmpresa);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return null;
        }
        if (list_vpev.isEmpty()) {
            return null;
        }
        return list_vpev;
    }

    public static class MergePdfResult {
        private boolean ok;
        private String uri;
        private String file;

        public MergePdfResult(boolean ok, String uri, String file) {
            this.ok = ok;
            this.uri = uri;
            this.file = file;
        }

        public boolean isOk() {
            return ok;
        }

        public String getUri() {
            return uri;
        }

        public String getFile() {
            return file;
        }
    }

    public static class LimpiezaAnexosResult {
        private boolean ok;
        private String message;
        private List<File> files;

        public LimpiezaAnexosResult(boolean ok, String message, List<File> files) {
            this.ok = ok;
            this.message = message;
            this.files = files;
        }

        public boolean isOk() {
            return ok;
        }

        public String getMessage() {
            return message;
        }

        public List<File> getFiles() {
            return files;
        }
    }

    public static class AnexosResult {
        private boolean ok;
        private List<File> anexos;
        private String message;

        public AnexosResult(boolean ok, List<File> anexos) {
            this.ok = ok;
            this.anexos = anexos;
            this.message = null;
        }

        public AnexosResult(boolean ok, String message) {
            this.ok = ok;
            this.anexos = null;
            this.message = message;
        }

        public boolean isOk() {
            return ok;
        }

        public List<File> getAnexos() {
            return anexos;
        }

        public String getMessage() {
            return message;
        }
    }

    @Override
    public ResponseEntity<?> procesaFormatos(int idEmpleado, int idAdministrador, MultipartFile archivo) {
        try {
            validarArchivoConstancia(archivo);
            byte[] contenido = archivo.getBytes();
            String texto;

            try (PDDocument documento = PDDocument.load(contenido)) {
                if (documento.isEncrypted()) {
                    return ResponseEntity.ok(
                            ProcesaFormatosResult.error("El PDF esta protegido y no puede leerse"));
                }
                if (documento.getNumberOfPages() < 1) {
                    return ResponseEntity.ok(
                            ProcesaFormatosResult.error("El PDF no contiene paginas"));
                }
                texto = new PDFTextStripper().getText(documento);
            }

            if (texto == null || texto.trim().isEmpty()) {
                return ResponseEntity.ok(ProcesaFormatosResult.error(
                        "El PDF no contiene texto legible. Descarga nuevamente la constancia original del SAT"));
            }

            String textoNormalizado = normalizarTexto(texto);
            if (!textoNormalizado.contains("CONSTANCIA DE SITUACION FISCAL")) {
                return ResponseEntity.ok(ProcesaFormatosResult.error(
                        "El archivo no corresponde a una Constancia de Situacion Fiscal"));
            }

            DatosConstanciaFiscal datos = ConstanciaSATParser.parsear(texto);
            validarDatosConstancia(datos);
            procesaFormatosDAO.validarPropietario(idEmpleado, datos);
            String nombreArchivo = procesaFormatosDAO.guardarDatos(idEmpleado, idAdministrador, datos);

            return ResponseEntity.ok(ProcesaFormatosResult.exito(
                    "Se obtuvieron los datos correctamente",
                    nombreArchivo,
                    construirCamposRespuesta(datos)));
        } catch (IllegalArgumentException e) {
            bitacora.warn("Constancia fiscal rechazada: " + e.getMessage());
            return ResponseEntity.ok(ProcesaFormatosResult.error(e.getMessage()));
        } catch (IOException e) {
            bitacora.error("No fue posible leer la constancia fiscal", e);
            return ResponseEntity.ok(
                    ProcesaFormatosResult.error("No fue posible leer el archivo PDF"));
        } catch (Exception e) {
            bitacora.error("Error al procesar la constancia fiscal", e);
            return ResponseEntity.internalServerError()
                    .body(ProcesaFormatosResult.error("No fue posible procesar la constancia fiscal"));
        }
    }

    private void validarArchivoConstancia(MultipartFile archivo) throws IOException {
        if (archivo == null || archivo.isEmpty()) {
            throw new IllegalArgumentException("No se recibio un archivo");
        }
        if (archivo.getSize() > TAMANO_MAXIMO_CONSTANCIA) {
            throw new IllegalArgumentException("El archivo excede el limite de 10 MB");
        }

        String nombre = archivo.getOriginalFilename() == null ? "" : archivo.getOriginalFilename();
        if (!nombre.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            throw new IllegalArgumentException("Solamente se permiten archivos PDF");
        }

        String tipo = archivo.getContentType();
        if (tipo != null && !tipo.trim().isEmpty()
                && !"application/pdf".equalsIgnoreCase(tipo)
                && !"application/octet-stream".equalsIgnoreCase(tipo)) {
            throw new IllegalArgumentException("El tipo de archivo recibido no corresponde a un PDF");
        }

        byte[] cabecera = new byte[5];
        int leidos;
        try (java.io.InputStream entrada = archivo.getInputStream()) {
            leidos = entrada.read(cabecera);
        }
        if (leidos != 5 || cabecera[0] != '%' || cabecera[1] != 'P' || cabecera[2] != 'D'
                || cabecera[3] != 'F' || cabecera[4] != '-') {
            throw new IllegalArgumentException("El contenido del archivo no corresponde a un PDF valido");
        }
    }

    private void validarDatosConstancia(DatosConstanciaFiscal datos) {
        List<String> faltantes = new ArrayList<String>();
        agregarFaltante(faltantes, datos.getRfc(), "RFC");
        agregarFaltante(faltantes, datos.getCurp(), "CURP");
        agregarFaltante(faltantes, datos.getFechaEmision(), "fecha de emision");
        agregarFaltante(faltantes, datos.getCodigoPostal(), "codigo postal");
        agregarFaltante(faltantes, datos.getNombreVialidad(), "calle");
        agregarFaltante(faltantes, datos.getMunicipio(), "municipio");
        agregarFaltante(faltantes, datos.getNombreEntidadFederativa(), "entidad federativa");
        agregarFaltante(faltantes, datos.getPrimerRegimen(), "regimen fiscal");

        if (!faltantes.isEmpty()) {
            throw new IllegalArgumentException("No fue posible obtener: " + String.join(", ", faltantes));
        }
        if (!datos.getCodigoPostal().matches("\\d{5}")) {
            throw new IllegalArgumentException("El codigo postal de la constancia no tiene un formato valido");
        }

        validarLongitud(datos.getLugarFechaEmision(), 100, "lugar y fecha de emision");
        validarLongitud(datos.getFechaEmision(), 10, "fecha de emision");
        validarLongitud(datos.getRfc(), 20, "RFC");
        validarLongitud(datos.getCurp(), 30, "CURP");
        validarLongitud(datos.getCodigoPostal(), 10, "codigo postal");
        validarLongitud(datos.getTipoVialidad(), 100, "tipo de vialidad");
        validarLongitud(datos.getNombreVialidad(), 200, "nombre de vialidad");
        validarLongitud(datos.getNoExterior(), 10, "numero exterior");
        validarLongitud(datos.getNoInterior(), 10, "numero interior");
        validarLongitud(datos.getNombreColonia(), 150, "colonia");
        validarLongitud(datos.getNombreLocalidad(), 150, "localidad");
        validarLongitud(datos.getNombreEntidadFederativa(), 150, "entidad federativa");
        validarLongitud(datos.getCorreoElectronico(), 150, "correo electronico");
        validarLongitud(datos.getTelefono(), 20, "telefono");
    }

    private void agregarFaltante(List<String> faltantes, String valor, String nombre) {
        if (valor == null || valor.trim().isEmpty()) {
            faltantes.add(nombre);
        }
    }

    private void validarLongitud(String valor, int maximo, String nombre) {
        if (valor != null && valor.length() > maximo) {
            throw new IllegalArgumentException("El campo " + nombre + " excede la longitud permitida");
        }
    }

    private List<CampoConstancia> construirCamposRespuesta(DatosConstanciaFiscal datos) {
        List<CampoConstancia> campos = new ArrayList<CampoConstancia>();
        campos.add(new CampoConstancia("Lugar y Fecha de Emision", datos.getLugarFechaEmision()));
        campos.add(new CampoConstancia("Fecha de Emision", datos.getFechaEmision()));
        campos.add(new CampoConstancia("RFC", datos.getRfc()));
        campos.add(new CampoConstancia("CURP", datos.getCurp()));
        campos.add(new CampoConstancia("Codigo Postal", datos.getCodigoPostal()));
        campos.add(new CampoConstancia("Tipo de Vialidad", datos.getTipoVialidad()));
        campos.add(new CampoConstancia("Nombre de Vialidad", datos.getNombreVialidad()));
        campos.add(new CampoConstancia("Numero Exterior", datos.getNoExterior()));
        campos.add(new CampoConstancia("Numero Interior", datos.getNoInterior()));
        campos.add(new CampoConstancia("Nombre de la Colonia", datos.getNombreColonia()));
        campos.add(new CampoConstancia("Nombre de la Localidad", datos.getNombreLocalidad()));
        campos.add(new CampoConstancia("Nombre del Municipio", datos.getMunicipio()));
        campos.add(new CampoConstancia("Nombre de la Entidad Federativa", datos.getNombreEntidadFederativa()));
        campos.add(new CampoConstancia("Correo Electronico", datos.getCorreoElectronico()));
        campos.add(new CampoConstancia("Telefono", datos.getTelefono()));
        campos.add(new CampoConstancia("Regimen Fiscal", datos.getPrimerRegimen()));
        return campos;
    }

    private String normalizarTexto(String valor) {
        return Normalizer.normalize(valor == null ? "" : valor, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .replaceAll("\\s+", " ")
                .trim()
                .toUpperCase(Locale.ROOT);
    }

    /** Parser integrado para no agregar mas archivos al proyecto. */
    private static final class ConstanciaSATParser {
        private static final Pattern FECHA_EMISION = Pattern.compile(
                "(?iu)(\\d{1,2})\\s+DE\\s+(ENERO|FEBRERO|MARZO|ABRIL|MAYO|JUNIO|JULIO|AGOSTO|SEPTIEMBRE|OCTUBRE|NOVIEMBRE|DICIEMBRE)\\s+DE\\s+(\\d{4})");
        private static final Pattern FECHA_REGIMEN = Pattern.compile(
                "^(.*?)\\s+(\\d{2}/\\d{2}/\\d{4})(?:\\s+\\d{2}/\\d{2}/\\d{4})?\\s*$");
        private static final Pattern RFC = Pattern.compile(
                "(?iu)(?:^|\\s)([A-Z\\x{00D1}&]{3,4}\\d{6}[A-Z0-9]{3})(?:$|\\s)");
        private static final Pattern CURP = Pattern.compile(
                "(?iu)(?:^|\\s)([A-Z]{4}\\d{6}[HM][A-Z]{5}[A-Z0-9]\\d)(?:$|\\s)");
        private static final Map<String, Integer> MESES = new LinkedHashMap<String, Integer>();

        static {
            MESES.put("ENERO", 1);
            MESES.put("FEBRERO", 2);
            MESES.put("MARZO", 3);
            MESES.put("ABRIL", 4);
            MESES.put("MAYO", 5);
            MESES.put("JUNIO", 6);
            MESES.put("JULIO", 7);
            MESES.put("AGOSTO", 8);
            MESES.put("SEPTIEMBRE", 9);
            MESES.put("OCTUBRE", 10);
            MESES.put("NOVIEMBRE", 11);
            MESES.put("DICIEMBRE", 12);
        }

        private ConstanciaSATParser() {
        }

        private static DatosConstanciaFiscal parsear(String texto) {
            if (texto == null || texto.trim().isEmpty()) {
                throw new IllegalArgumentException("El PDF no contiene texto legible");
            }

            List<String> lineas = limpiarLineas(texto);
            DatosConstanciaFiscal datos = new DatosConstanciaFiscal();

            obtenerEmision(lineas, datos);
            datos.setRfc(extraerValorSimple(lineas, "RFC"));
            datos.setCurp(extraerValorSimple(lineas, "CURP"));
            if (datos.getRfc().isEmpty()) {
                datos.setRfc(buscarPatron(lineas, RFC));
            }
            if (datos.getCurp().isEmpty()) {
                datos.setCurp(buscarPatron(lineas, CURP));
            }

            datos.setCodigoPostal(extraerEntre(lineas,
                    "C(?:O|\\x{00D3})DIGO POSTAL", "TIPO DE VIALIDAD"));
            datos.setTipoVialidad(extraerDespues(lineas, "TIPO DE VIALIDAD"));
            datos.setNombreVialidad(extraerEntre(lineas,
                    "NOMBRE DE VIALIDAD", "N(?:U|\\x{00DA})MERO EXTERIOR"));
            datos.setNoExterior(extraerDespues(lineas, "N(?:U|\\x{00DA})MERO EXTERIOR"));
            datos.setNoInterior(extraerEntre(lineas,
                    "N(?:U|\\x{00DA})MERO INTERIOR", "NOMBRE DE LA COLONIA"));
            datos.setNombreColonia(extraerDespues(lineas, "NOMBRE DE LA COLONIA"));
            datos.setNombreLocalidad(extraerEntre(lineas,
                    "NOMBRE DE LA LOCALIDAD",
                    "NOMBRE DEL MUNICIPIO O DEMARCACI(?:O|\\x{00D3})N TERRITORIAL"));
            datos.setMunicipio(extraerDespues(lineas,
                    "NOMBRE DEL MUNICIPIO O DEMARCACI(?:O|\\x{00D3})N TERRITORIAL"));
            datos.setNombreEntidadFederativa(extraerEntre(lineas,
                    "NOMBRE DE LA ENTIDAD FEDERATIVA", "ENTRE CALLE"));
            datos.setCorreoElectronico(extraerDespues(lineas,
                    "CORREO ELECTR(?:O|\\x{00D3})NICO"));
            datos.setTelefono(extraerTelefono(lineas));
            obtenerRegimenes(lineas, datos);
            return datos;
        }

        private static List<String> limpiarLineas(String texto) {
            List<String> resultado = new ArrayList<String>();
            for (String linea : texto.split("\\R")) {
                String limpia = limpiarEspacios(linea);
                if (!limpia.isEmpty()) {
                    resultado.add(limpia);
                }
            }
            return resultado;
        }

        private static void obtenerEmision(List<String> lineas, DatosConstanciaFiscal datos) {
            for (int i = 0; i < lineas.size(); i++) {
                if (!normalizar(lineas.get(i)).contains("LUGAR Y FECHA DE EMISION")) {
                    continue;
                }

                StringBuilder emision = new StringBuilder();
                String valorEnEtiqueta = lineas.get(i).replaceFirst(
                        "(?iu)^.*?LUGAR\\s+Y\\s+FECHA\\s+DE\\s+EMISI(?:O|\\x{00D3})N\\s*:?[ ]*", "");
                if (!valorEnEtiqueta.isEmpty()) {
                    emision.append(valorEnEtiqueta);
                }

                for (int j = i + 1; j < lineas.size() && j <= i + 5; j++) {
                    String normalizada = normalizar(lineas.get(j));
                    if (normalizada.startsWith("RFC:")
                            || normalizada.contains("DATOS DE IDENTIFICACION")) {
                        break;
                    }
                    if (emision.length() > 0) {
                        emision.append(' ');
                    }
                    emision.append(lineas.get(j));
                    if (FECHA_EMISION.matcher(normalizar(emision.toString())).find()) {
                        break;
                    }
                }

                String lugarFecha = limpiarEspacios(emision.toString());
                datos.setLugarFechaEmision(lugarFecha);
                Matcher fecha = FECHA_EMISION.matcher(normalizar(lugarFecha));
                if (fecha.find()) {
                    int dia = Integer.parseInt(fecha.group(1));
                    int mes = MESES.get(fecha.group(2));
                    int anio = Integer.parseInt(fecha.group(3));
                    datos.setFechaEmision(LocalDate.of(anio, mes, dia)
                            .format(DateTimeFormatter.ISO_LOCAL_DATE));
                }
                return;
            }
        }

        private static String extraerValorSimple(List<String> lineas, String etiqueta) {
            Pattern patron = Pattern.compile(
                    "(?iu)^\\s*" + Pattern.quote(etiqueta) + "\\s*:\\s*(.*?)\\s*$");
            for (String linea : lineas) {
                Matcher matcher = patron.matcher(linea);
                if (matcher.find()) {
                    return limpiarEspacios(matcher.group(1));
                }
            }
            return "";
        }

        private static String extraerEntre(List<String> lineas, String inicio, String fin) {
            Pattern patron = Pattern.compile(
                    "(?iu)" + inicio + "\\s*:\\s*(.*?)\\s+" + fin + "\\s*:");
            for (String linea : lineas) {
                Matcher matcher = patron.matcher(linea);
                if (matcher.find()) {
                    return limpiarEspacios(matcher.group(1));
                }
            }
            return "";
        }

        private static String extraerDespues(List<String> lineas, String etiqueta) {
            Pattern patron = Pattern.compile("(?iu)" + etiqueta + "\\s*:\\s*(.*?)\\s*$");
            for (String linea : lineas) {
                Matcher matcher = patron.matcher(linea);
                if (matcher.find()) {
                    return limpiarEspacios(matcher.group(1));
                }
            }
            return "";
        }

        private static String extraerTelefono(List<String> lineas) {
            Pattern patron = Pattern.compile(
                    "(?iu)TEL\\.\\s*[^:]*LADA\\s*:\\s*(.*?)\\s+N(?:U|\\x{00DA})MERO\\s*:\\s*(.*?)\\s*$");
            for (String linea : lineas) {
                Matcher matcher = patron.matcher(linea);
                if (matcher.find()) {
                    String lada = matcher.group(1).replaceAll("\\D", "");
                    String numero = matcher.group(2).replaceAll("\\D", "");
                    return lada + numero;
                }
            }
            return "";
        }

        private static void obtenerRegimenes(List<String> lineas, DatosConstanciaFiscal datos) {
            int inicio = -1;
            int fin = lineas.size();
            for (int i = 0; i < lineas.size(); i++) {
                String normalizada = normalizar(lineas.get(i));
                if (normalizada.contains("REGIMEN FECHA INICIO FECHA FIN")) {
                    inicio = i + 1;
                    continue;
                }
                if (inicio >= 0 && (normalizada.startsWith("OBLIGACIONES:")
                        || normalizada.contains("SUS DATOS PERSONALES"))) {
                    fin = i;
                    break;
                }
            }
            if (inicio < 0) {
                return;
            }

            List<String> regimenes = new ArrayList<String>();
            for (int i = inicio; i < fin; i++) {
                Matcher matcher = FECHA_REGIMEN.matcher(lineas.get(i));
                if (matcher.find()) {
                    String regimen = limpiarEspacios(matcher.group(1));
                    if (!regimen.isEmpty()) {
                        regimenes.add(regimen);
                    }
                }
            }
            if (!regimenes.isEmpty()) {
                datos.setPrimerRegimen(regimenes.get(0));
                datos.setRegimen(String.join(",", regimenes));
            }
        }

        private static String buscarPatron(List<String> lineas, Pattern patron) {
            for (String linea : lineas) {
                Matcher matcher = patron.matcher(linea);
                if (matcher.find()) {
                    return limpiarEspacios(matcher.group(1));
                }
            }
            return "";
        }

        private static String normalizar(String valor) {
            String sinAcentos = Normalizer.normalize(
                    valor == null ? "" : valor, Normalizer.Form.NFD)
                    .replaceAll("\\p{M}", "");
            return limpiarEspacios(sinAcentos).toUpperCase(Locale.ROOT);
        }

        private static String limpiarEspacios(String valor) {
            return valor == null ? ""
                    : valor.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
        }
    }

    public static class CampoConstancia {
        private final String campo;
        private final String valor;

        public CampoConstancia(String campo, String valor) {
            this.campo = campo;
            this.valor = valor == null ? "" : valor;
        }

        public String getCampo() {
            return campo;
        }

        public String getValor() {
            return valor;
        }
    }

    public static class ProcesaFormatosResult {
        private final boolean exito;
        private final String message;
        private final String nombreArchivo;
        private final List<CampoConstancia> data;

        public ProcesaFormatosResult(boolean exito, String message, String nombreArchivo,
                List<CampoConstancia> data) {
            this.exito = exito;
            this.message = message;
            this.nombreArchivo = nombreArchivo;
            this.data = data;
        }

        public static ProcesaFormatosResult exito(String message, String nombreArchivo,
                List<CampoConstancia> data) {
            return new ProcesaFormatosResult(true, message, nombreArchivo, data);
        }

        public static ProcesaFormatosResult error(String message) {
            return new ProcesaFormatosResult(false, message, null, new ArrayList<CampoConstancia>());
        }

        public boolean isExito() {
            return exito;
        }

        public String getMessage() {
            return message;
        }

        public String getNombreArchivo() {
            return nombreArchivo;
        }

        public List<CampoConstancia> getData() {
            return data;
        }
    }

}
