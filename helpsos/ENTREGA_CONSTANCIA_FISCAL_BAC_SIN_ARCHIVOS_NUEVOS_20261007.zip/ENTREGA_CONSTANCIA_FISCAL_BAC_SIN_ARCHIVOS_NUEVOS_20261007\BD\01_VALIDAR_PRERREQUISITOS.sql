SET NOCOUNT ON;
SET XACT_ABORT ON;

IF OBJECT_ID(N'dbo.bf_AltaConstanciaEmpleado', N'P') IS NULL
BEGIN
    THROW 51000, 'No existe dbo.bf_AltaConstanciaEmpleado en la base actual.', 1;
END;

DECLARE @Esperados TABLE
(
    parameter_id int NOT NULL PRIMARY KEY,
    nombre sysname NOT NULL,
    tipo sysname NOT NULL,
    max_length smallint NOT NULL,
    is_output bit NOT NULL
);

INSERT INTO @Esperados (parameter_id, nombre, tipo, max_length, is_output)
VALUES
    (1,  N'@IdEmpleado',                N'int',      4,   0),
    (2,  N'@IdAdministrador',           N'int',      4,   0),
    (3,  N'@LugarFechaEmision',         N'varchar',  100, 0),
    (4,  N'@FechaEmision',              N'varchar',  10,  0),
    (5,  N'@RFC',                       N'varchar',  20,  0),
    (6,  N'@CURP',                      N'varchar',  30,  0),
    (7,  N'@CodigoPostal',              N'varchar',  10,  0),
    (8,  N'@TipoVialidad',              N'varchar',  100, 0),
    (9,  N'@NombreVialidad',            N'varchar',  200, 0),
    (10, N'@NoExterior',                N'varchar',  10,  0),
    (11, N'@NoInterior',                N'varchar',  10,  0),
    (12, N'@NombreColonia',             N'varchar',  150, 0),
    (13, N'@NombreLocalidad',           N'varchar',  150, 0),
    (14, N'@NombreEntidadFederativa',   N'varchar',  150, 0),
    (15, N'@CorreoElectronico',         N'varchar',  150, 0),
    (16, N'@Telefono',                  N'varchar',  20,  0),
    (17, N'@Regimen',                   N'varchar',  -1,  0),
    (18, N'@NombreArchivo',             N'varchar',  200, 1);

IF EXISTS
(
    SELECT e.parameter_id, e.nombre, e.tipo, e.max_length, e.is_output
    FROM @Esperados AS e
    EXCEPT
    SELECT p.parameter_id, p.name, TYPE_NAME(p.user_type_id), p.max_length, p.is_output
    FROM sys.parameters AS p
    WHERE p.object_id = OBJECT_ID(N'dbo.bf_AltaConstanciaEmpleado')
)
OR EXISTS
(
    SELECT p.parameter_id, p.name, TYPE_NAME(p.user_type_id), p.max_length, p.is_output
    FROM sys.parameters AS p
    WHERE p.object_id = OBJECT_ID(N'dbo.bf_AltaConstanciaEmpleado')
    EXCEPT
    SELECT e.parameter_id, e.nombre, e.tipo, e.max_length, e.is_output
    FROM @Esperados AS e
)
BEGIN
    SELECT
        p.parameter_id,
        p.name,
        TYPE_NAME(p.user_type_id) AS tipo,
        p.max_length,
        p.is_output
    FROM sys.parameters AS p
    WHERE p.object_id = OBJECT_ID(N'dbo.bf_AltaConstanciaEmpleado')
    ORDER BY p.parameter_id;

    THROW 51001, 'La firma de dbo.bf_AltaConstanciaEmpleado no coincide con la requerida por el backend.', 1;
END;

PRINT 'OK: dbo.bf_AltaConstanciaEmpleado tiene los 18 parametros esperados.';
PRINT 'No se requiere migracion de base de datos.';
