import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';

import { EmpleadoService } from '../../../services/empleado.service';
import { DependienteService } from '../../../services/dependiente.service';
import { TitularPut } from '../../../models/titularPut';

import swal from 'sweetalert2';
import { SafeResourceUrl } from '@angular/platform-browser';
import { GLOBAL } from '../../../services/global';
import { Sesion } from '../../../services/sesion.service';

import { Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Bitacora } from '../../../services/bitacora.service';
import { LIST_FORM_ARRAY } from 'src/app/services/constantes';

import { NgxSpinnerService } from 'ngx-spinner';
import {APIService} from '../../../services/API-CoE.service'

import {ANGULAR_UTILS} from 'src/app/services/utils.service';

declare var $;

@Component({
  selector: 'app-misdatosfiscalesmaster',
  templateUrl: './misdatosfiscalesmaster.component.html',
  styleUrls: ['./misdatosfiscalesmaster.component.css']
})
export class MisdatosfiscalesmasterComponent implements OnInit {

  public ANGULAR_UTILS = ANGULAR_UTILS;

  public identity;
  public token;
  public formDatosFiscales: Array<any>;
  public flag = true;
  public status;
  public datosEmpleado: any[] = [];
  public titularPut: TitularPut;
  public arrayCampos: any[] = [];
  public datosFormulario: FormGroup;
  public arrayRFC: any[] = [];
  public varlorRFCReal: string[] = [];
  tablaForm2: FormGroup;
  submited = false;
  public formNombreEtiquetas;
  public formValores;
  public valoresModificados: any[] = [];
  public datosEmpleadoTodos;
  public leyendaCabecera;
  public auxNombreCompleto;
  public objDatosAnteriores;
  private UrlApi;
  private UrlWs;

  public valorCambiosGenerales;

  public trustUrl2: SafeResourceUrl;
  public trustUrl3: SafeResourceUrl;
  public estilo;
  public url3 = '../../../../../../src/app/beflex/shared/nav/nav.component.css';
  public wizard;
  public etiqueta;
  public validaDtosFiscales;

  private banderaMail;
  private plantillaSend;
  private sujeto;
  private bodyHTML;

  public confirmarDatos = false;

  public objetosPlantillaMail = { 'datosActuales': [], 'valores': [] };
  private finalObjAnteriores = { 'nombre': [], 'valor': [] };
  private dtaDatosAnteriores = { 'nombre': [], 'valor': [] };

  private idPagina = '374';
  private paginaActual;
  private ipPrivada;

  public fileConstancia;
  public botonConstancia: boolean = false;
  private datos:any;
  private titularParams;
  private to: string;
  private LSdata = new FormData();

  
  private cc;
  private bcc;
  private adminCorreos;
  public fieldsConfirm = [];

  // Esta configuracion deberia ser tomada de la base de datos, hay indicios que asi se busco realizar en algun tiempo

  public dataSelectList = {
    'estadosFiscales': [],
    'comboSexo': [],
    'comboPerfiles': [],
    'oficinasFiscales': [],
    'comboRol': [],
    'comboCostos': [],
    'comboPuesto': [],
    'comboVip': [],
    'comboArea': [],
    'comboRegimen': []
  };

  public configSelectList: object = {
    'EMIdPerfil': {
      'Valor': 'idPerfil',
      'Descripcion': 'nombrePerfil',
      'ListaDatos': 'comboPerfiles'
    },
    'EMIdSexo': {
      'Valor': 'idSexo',
      'Descripcion': 'descripcion',
      'ListaDatos': 'comboSexo'
    },
    'EMOficina': {
      'Valor': 'TEIdDetalle',
      'Descripcion': 'TEDescripcion',
      'ListaDatos': 'oficinasFiscales'
    },
    'EMArea': {
      'Valor': 'TEIdDetalle',
      'Descripcion': 'TEDescripcion',
      'ListaDatos': 'comboArea'
    },
    'EMEstadoFiscal': {
      'Valor': 'esIdEstado',
      'Descripcion': 'esDescripcion',
      'ListaDatos': 'estadosFiscales'
    },
    'EMEstadoFisico': {
      'Valor': 'esIdEstado',
      'Descripcion': 'esDescripcion',
      'ListaDatos': 'estadosFiscales'
    },
    'EMIdRol': {
      'Valor': 'roIdRol',
      'Descripcion': 'roDescripcionCorta',
      'ListaDatos': 'comboRol'
    },
    'EMidCentroCostos': {
      'Valor': 'TEIdDetalle',
      'Descripcion': 'TEDescripcion',
      'ListaDatos': 'comboCostos'
    },
    'EMTipoEmpleado': {
      'Valor': 'TEIdDetalle',
      'Descripcion': 'TEDescripcion',
      'ListaDatos': 'comboPuesto'
    },
    'EMVIP': {
      'Valor': 'TEIdDetalle',
      'Descripcion': 'TEDescripcion',
      'ListaDatos': 'comboVip'
    },
    'EMRegimen': {
      'Valor': 'TEIdDetalle',
      'Descripcion': 'TEDescripcion',
      'ListaDatos': 'comboRegimen'
    }
  };

  constructor(private _empleadoService: EmpleadoService,
    private _router: Router,
    private fb: FormBuilder,
    private _sesion: Sesion,
    private _bitacora: Bitacora,
    private spinner: NgxSpinnerService,
    private _apiServise: APIService,
    private _dependienteService: DependienteService,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();
    this.wizard = GLOBAL.wizard;
    this.UrlApi = GLOBAL.url3;
    this.UrlWs = GLOBAL.url;
    this.datosFormulario = new FormGroup({});
    if (this.identity) {
      this.identity.reseteo ? (!this.identity.cambio ? this._router.navigate(['/pages/home']) : this._router.navigate(['/pages/home'])) : null;
    }
  }

  async ngOnInit() {
    this.spinner.show();
    this.token = this._empleadoService.getToken();
    //await this.comprobarSesion();
    await this.getLeyendaCabecera();
    await this.builForm();
    await this.getEncabezadoMail();
    await this.getTodosDatosEmpleado();
    await this.getEstados();
    await this.getVip();
    await this.getAreas();
    await this.getOficinas();
    await this.getPuestos();
    await this.getRegimenes();
    await this.getCentroCostos();
    await this.getSexo();
    await this.getPerfil();
    await this.getRol();
    await this.getCorreosAdmin();

    this.objetosPlantillaMail = { datosActuales: [], valores: [] };
    this.finalObjAnteriores = { nombre: [], valor: [] };

    if (this.identity) {
      const resValidacion: any = await this._empleadoService.getParametroCorporativo(this.identity.idEmpresa, 239);
      if(parseInt(resValidacion.valor) == 1)
        this.botonConstancia = true;
      else
        this.botonConstancia = false;

      this.paginaActual = this.document.location.href;
      this.ipPrivada = localStorage.getItem('myIP') || '0.0.0.0';

      const parametroVitacora = {
        idPagina: this.idPagina,
        id: this.identity.id,
        ipPrivada: encodeURIComponent(this.ipPrivada),
        url: encodeURIComponent(this.paginaActual),
        idEmpresa: this.identity.idEmpresa,
        nombrePagina: 0
      };
      this._bitacora.registrarBitacora(parametroVitacora);
    }

  }

  ngAfterContentInit() {
    this.spinner.hide();
  }

  async getEncabezadoMail() {
    try {
      const result = await this._empleadoService.getEncabezadoMail();
      this.banderaMail = result[0];
      const response = await this._empleadoService.getPlantillaDatosTitular();
      this.plantillaSend = response[0];
      this.sujeto = this.plantillaSend['sujeto'].toString();
      this.sujeto = this.sujeto.replace('#NombreEmpresa', this._empleadoService.getIdentity().nomEmpresa);

      this.bodyHTML = this.plantillaSend['plantilla'].toString();
      this.bodyHTML = this.bodyHTML.replace('#NombreUsuarioMod', this.banderaMail['nombre']);
      this.bodyHTML = this.bodyHTML.replace('#NombreTitular', this.banderaMail['nombre']);
      this.bodyHTML = this.bodyHTML.replace('#NumeroTitular', this.banderaMail['numeroEmpleado']);
      this.bodyHTML = this.bodyHTML.replace('#NombreEmpresa', this._empleadoService.getIdentity().nomEmpresa);
    } catch (error) {
      console.log("Erro al enviar el correo:",error);
     }
  }


  async getLeyendaCabecera() {
    try {
      const response = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idEmpresa, 99);
      this.leyendaCabecera = response['paValor'];
    } catch (error) { }
  }


    async getTodosDatosEmpleado() {
      if (!this.identity) return;

      const limpiarNull = (v: string) => v === 'NULL' ? ' ' : v;
      const formatearFecha = (f: any) => f ? new Date(f).toISOString().split('T')[0] : '';

      try {
        const r: any = await this._empleadoService.getInformacionEmpleado(this.identity.id, this.token);
        this.datosEmpleado = { ...r };
        this.datosEmpleadoTodos = { ...r };
        this.auxNombreCompleto = ['EMNombre1', 'EMNombre2', 'EMApellidoPaterno', 'EMApellidoMaterno']
          .reduce((a, k) => ({ ...a, [k]: limpiarNull(r[k]) }), {});
        ['EMFechaNacimiento', 'EMFechaEmision'].forEach(f => this.datosEmpleado[f] = formatearFecha(r[f]));

        const res = await this._empleadoService.getDatosFiscalesV2(this.identity, this.token);
        this.formDatosFiscales = res.data || [];
        this.formDatosFiscales.forEach(i => this.datosFormulario.get(i.nombreCampo)?.setValue(this.datosEmpleado[i.nombreCampo]));
        this.datosFormulario.get('EMRegimen')?.setValue(parseInt(this.datosEmpleado['EMRegimen']) || '');

        const extras = this.formDatosFiscales
          .filter(i => i.confirmacion === 1)
          .map(i => ({ ...i, nombreCampo: i.nombreCampo + 'Confirmacion', etiqueta: i.etiqueta + ' - Confirmación' }));

        this.formDatosFiscales.push(...extras);
        extras.forEach(e => {
          const base = e.nombreCampo.replace('Confirmacion', '');
          this.datosFormulario.addControl(e.nombreCampo, new FormControl(this.datosFormulario.get(base)?.value || ''));
          this.datosEmpleado[e.nombreCampo] = this.datosEmpleado[base];
        });

        this.objDatosAnteriores = this.formDatosFiscales.reduce((a, f) => {
          if (f.nombreCampo in this.datosEmpleado) {
            a.nombre.push(f.nombreCampo);
            a.valor.push(this.datosEmpleado[f.nombreCampo]);
          }
          return a;
        }, { nombre: [], valor: [] });

      } catch (e: any) {
        if (e === 'Unauthorized') {
          swal({ title: '¡La sesión expiró!', html: '<small style="color: grey;">Inicia sesión nuevamente.</small>', type: 'error', confirmButtonText: 'Aceptar' });
          this.logout();
        }
        this.status = 'error';
      }
    }


  get f() {
    return this.datosFormulario.controls;
  }

  builForm() {
    this.datosFormulario = this.fb.group({
      EMIdSexo: new FormControl({ value: '' }),
      EMIdAcceso: new FormControl({ value: '' }),
      EMIdContacto: new FormControl({ value: '' }),
      EMIdEstatus: new FormControl({ value: '' }),
      EMFechaEstatus: new FormControl({ value: '' }),
      EMIdTransferido: new FormControl({ value: '' }),
      EMNumeroEmpleado: new FormControl(''),
      EMCertificado: new FormControl({ value: '' }),
      EMApellidoPaterno: new FormControl({ value: '' }),
      EMApellidoMaterno: new FormControl({ value: '' }),
      EMNombre1: new FormControl({ value: '' }),
      EMNombre2: new FormControl({ value: '' }),
      EMFechaNacimiento: new FormControl({ value: '' }),
      EMEdad: new FormControl({ value: '' }),
      EMFechaIngresoEmpresa: new FormControl({ value: '' }),
      EMFechaBaja: new FormControl({ value: '' }),
      EMFechaAntiguedadGMM: new FormControl({ value: '' }),
      EMAntiguedadGMM: new FormControl({ value: '' }),
      EMPuesto: new FormControl({ value: '' }),
      EMArea: new FormControl({ value: '' }),
      EMOficina: new FormControl({ value: '' }),
      EMrfc: new FormControl({ value: '' }),
      EMcurp: new FormControl({ value: '' }),
      EMnss: new FormControl({ value: '' }),
      EMTipoEmpleado: new FormControl({ value: '' }),
      EMIdTipoAsegurado: new FormControl({ value: '' }),
      EMIdTipoSalario: new FormControl({ value: '' }),
      EMIdSalarioConfidencial: new FormControl({ value: '' }),
      EMSalarioBase: new FormControl({ value: '' }),
      EMSalarioIntegrado: new FormControl({ value: '' }),
      EMSalarioBruto: new FormControl({ value: '' }),
      EMSalarioNeto: new FormControl({ value: '' }),
      EMDeduccionesM: new FormControl({ value: '' }),
      EMDeduccionesP: new FormControl({ value: '' }),
      EMPrestacionesM: new FormControl({ value: '' }),
      EMPrestacionesP: new FormControl({ value: '' }),
      EMFondoAhorroM: new FormControl({ value: '' }),
      EMFondoAhorroP: new FormControl({ value: '' }),
      EMFondoAhorroAcumulado: new FormControl({ value: '' }),
      EMValesM: new FormControl({ value: '' }),
      EMValesP: new FormControl({ value: '' }),
      EMExcedente: new FormControl({ value: '' }),
      EMBeneficioMaximoM: new FormControl({ value: '' }),
      EMBeneficioMaximoP: new FormControl({ value: '' }),
      EMBeneFicioOtorgadoM: new FormControl({ value: '' }),
      EMBeneFicioOtorgadoP: new FormControl({ value: '' }),
      EMTelefono: new FormControl({ value: '' }),
      EMCorreoElectronico: new FormControl({ value: '' }),
      EMArchivoInformacion: new FormControl({ value: '' }),
      EMClaveAcceso: new FormControl({ value: '' }),
      EMObservaciones: new FormControl({ value: '' }),
      EMUsuarioAdd: new FormControl({ value: '' }),
      EMFechaAdd: new FormControl({ value: '' }),
      EMUsuarioUMod: new FormControl({ value: '' }),
      EMFechaUMod: new FormControl({ value: '' }),
      EMUsuarioDel: new FormControl({ value: '' }),
      EMFechaDel: new FormControl({ value: '' }),
      EMVIP: new FormControl({ value: '' }),
      EMIdRol: new FormControl({ value: '' }),
      EMidCentroCostos: new FormControl({ value: '' }),
      EMNetForbes: new FormControl({ value: '' }),
      EMTipoDomicilio: new FormControl({ value: '' }),
      EMCalleFisico: new FormControl({ value: '' }),
      EMColoniaFisico: new FormControl({ value: '' }),
      EMMunicipioDelegacionFisico: new FormControl({ value: '' }),
      EMEstadoFisico: new FormControl({ value: '' }),
      EMCodigoPostalFisico: new FormControl({ value: '' }),
      EMFumador: new FormControl({ value: '' }),
      EMConsumoAlcohol: new FormControl({ value: '' }),
      EMDiasVacacionesporGozar: new FormControl({ value: '' }),
      EMContraseña: new FormControl({ value: '' }),
      EMContinua: new FormControl({ value: '' }),
      EMCalleFiscal: new FormControl({ value: '' }),
      EMColoniaFiscal: new FormControl({ value: '' }),
      EMMunicipioDelegacionFiscal: new FormControl({ value: '' }),
      EMEstadoFiscal: new FormControl({ value: '' }),
      EMCodigoPostalFiscal: new FormControl({ value: '' }),
      EMCambioPassword: new FormControl({ value: '' }),
      EMFechaAcceso: new FormControl({ value: '' }),
      EMBloqueoXSel: new FormControl({ value: '' }),
      EMFecBloqueoXSel: new FormControl({ value: '' }),
      EMReseteoPassword: new FormControl({ value: '' }),
      Desarrollo: new FormControl({ value: '' }),
      EMFechaSincronizacion: new FormControl({ value: '' }),
      EMFechaAsignacionIdADN: new FormControl({ value: '' }),
      EMFechaAlta: new FormControl({ value: '' }),
      EMIdJefe: new FormControl({ value: '' }),
      EMFechaAntiguedadPP: new FormControl({ value: '' }),
      EMSaldoCuentaEmpleadoPP: new FormControl({ value: '' }),
      EMSaldoCuentaEmpresaPP: new FormControl({ value: '' }),
      EMSaldoCuentaExtraordinarioPP: new FormControl({ value: '' }),
      EMFechaIngresoIMSSPP: new FormControl({ value: '' }),
      EMSaldoAcumuladoAportacionEmpleadoPP: new FormControl({ value: '' }),
      EMSaldoAcumuladoAportacionCondicionadaPP: new FormControl({ value: '' }),
      EMSaldoAcumuladoAportacionBasicaPP: new FormControl({ value: '' }),
      EMSaldoAcumuladoAportacionAdicionalPP: new FormControl({ value: '' }),
      EMSalarioPP: new FormControl({ value: '' }),
      EMIdEstadoCivil: new FormControl({ value: '' }),
      EMSaldoSubCuenta_08_PP: new FormControl({ value: '' }),
      EMSaldoSubCuenta_09_PP: new FormControl({ value: '' }),
      EMSaldoSubCuenta_10_PP: new FormControl({ value: '' }),
      EMIEmpleado: new FormControl({ value: '' }),
      EMBDPPensiones: new FormControl({ value: '' }),
      EMBonoCambio: new FormControl({ value: '' }),
      EMBFlexible: new FormControl({ value: '' }),
      EMMatch: new FormControl({ value: '' }),
      EMEmpleadoI: new FormControl({ value: '' }),
      EMIAB: new FormControl({ value: '' }),
      EMEdadRetiro: new FormControl({ value: '' }),
      EMSalarioIMSS: new FormControl({ value: '' }),
      EMSueldoAportacion: new FormControl({ value: '' }),
      EMSueldoPlan: new FormControl({ value: '' }),
      EMBeneficioJubilacion: new FormControl({ value: '' }),
      EMRegimen: new FormControl({ value: '' }),
      EMFechaEmision: new FormControl({ value: '' }),
    });
  }


  submit() {
    this.submited = true;
    if (this.datosFormulario.invalid) {
      return;
    }
  }

  async getDatosFiscalesEmpleado() {
    if (this.identity) {
      try {
        const response = await this._empleadoService.getDatosFiscales(this.identity, this.token);
        this.formDatosFiscales = response.body['data'];
      } catch (error) {
        const errorMessage = <any>error;
        if (errorMessage == 'Unauthorized') {
          swal({
            title: '¡La sesión expiró!',
            html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
            type: 'error',
            confirmButtonText: 'Aceptar',
          });
          this.logout();
        }
        if (errorMessage != null) {
          this.status = 'error';
        }
      }
    }
  }

  getEventPath(event) {
    if (event.path) {
      return event.path;
    }

    const path = [];
    let target = event.target;

    while (target.parentNode) {
      path.push(target);
      target = target.parentNode;
    }

    path.push(document, window);

    return path;
  }

  onKey(event: any) {
    const path = event.path || (event.composedPath && event.composedPath()) || this.getEventPath(event);

    if (path) {
      this.valoresModificados.push(path[0].name);
      this.buttonControlEnabled();
      this.verificaCampo(path[0].name);
    }
  }

  buttonControlDisabled() {
    $('#btnSubmit').attr('disabled', true);
  }

  buttonControlEnabled() {
    $('#btnSubmit').attr('disabled', false);
  }

  onChange(event) {
    const path = event.path || (event.composedPath && event.composedPath());
    if (path) {
      this.valoresModificados.push(path[0].id);
      this.buttonControlEnabled();
    }
  }

  async comprobarSesion() {
    try {
      await this._sesion.comprobarSession(this.token);
    } catch (error) {
      if (error == 'Unauthorized' || error.statusText == 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión de nuevo.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      } else {
        swal({
          title: '¡Error de conexión!',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
      }
    }
  }

  logout() {
    this._empleadoService.logout();
  }

  ocultarDiv() {
    const elemento = document.getElementById('datosF');
    elemento.style.display = 'none';
  }

  mostrarDiv() {
    const elemento = document.getElementById('datosF');
    elemento.style.display = 'block';
  }

  async obtenerValidacionDatosFiscales() {
    try {
      const val = await this._empleadoService.validaModificacionDatosFiscales(this._empleadoService.getIdentity().id);
      this.validaDtosFiscales = val['nDatosModificados'];
      localStorage.setItem('validacionDtos', this.validaDtosFiscales);
    } catch (error) { }
  }

  async dataAccess() {

    let datoConfirmacion;
    let datoNormal;

    Object.keys(this.datosFormulario.controls).forEach(
      campo => {
        if(this.formDatosFiscales.find(x => x.nombreCampo == campo)?.habilitado == 1){
          this.datosFormulario.get(campo).markAsDirty();
          this.datosFormulario.get(campo).markAsTouched();
        }
      });

    for (let i = 0; i < this.formDatosFiscales.length; i++) {
      if (this.formDatosFiscales[i].confirmacion && !this.formDatosFiscales[i].nombreCampo.toUpperCase().includes('CONFIRMACION')) {
        datoNormal = $('#' + this.formDatosFiscales[i].nombreCampo).val();
        datoConfirmacion = $('#' + this.formDatosFiscales[i].nombreCampo + 'Confirmacion').val();
        if (datoNormal != datoConfirmacion) {
          let idControl = this.formDatosFiscales[i].nombreCampo + 'Confirmacion'
          this.datosFormulario.get(idControl).setErrors({confirmedValidator: true, ...this.datosFormulario.get(idControl).errors});
          this.confirmarDatos = true;
          break;
        }
      }
    }

    if (!this.confirmarDatos) {
      this.titularParams = this.getConstruirParametros();
    }

    if (!this.confirmarDatos && this.datosFormulario.valid) {
      this.obtenerValidacionDatosFiscales();

      swal({
        title: '¡Atención!',
        text: '¿Estás de acuerdo en realizar la modificación?',
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.value) {
          // this.ocultarDiv();
          swal({
            title: 'Espere un momento...',
            html: '',
            allowOutsideClick: false,
            onOpen: () => {
              swal.showLoading();
              this.actualizaTitularAjax(this.titularParams);
            },
          });
        }
      });
    } else {
      Object.keys(this.datosFormulario.controls).forEach(controlName => {
        const control = this.datosFormulario.get(controlName);
    
        // Verifica si el control no es válido
        if (control.invalid) {
          console.log(`El control ${controlName} no es válido. Errores:`, control.errors);
        }
      });

      this.confirmarDatos = false;
      swal({
        title: '¡Error en la información!',
        html: '<small style="color: grey; text-align: justify;">Por favor, verifique la información de los campos en rojo.</small>',
        type: 'info',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  actualizaTitularAjax(tP: TitularPut) {
    if (!tP.atributoValor) {
      tP.atributoValor = 'EMFechaAcceso=GETDATE()';
    }

    const token = JSON.parse(localStorage.getItem('tokenB3'));

    const settings = {
      'async': true,
      'crossDomain': true,
      'url': `${this.UrlWs}empleados/empleado/${tP.idEmpleado}/titular?idEmpresa=${tP.idEmpresa}&fechaNacimiento=${tP.fechaNacimiento}&atributoValor=` + encodeURIComponent(`${tP.atributoValor}`),
      'method': 'PUT',
      'headers': { 'cache-control': 'no-cache', 'authorization': token }
    };

    $.ajax(settings).done(async () => {

      this.titularPut = new TitularPut('', '', '', '');
      this.valoresModificados = [];

      const to = this.banderaMail['email'];

      this.enviarMailNotificacion(to, this.sujeto, this.bodyHTML);
      localStorage.setItem('cambios', '1');
      localStorage.setItem('df', '1');
      localStorage.setItem('dfg', '1');

      await this.construirFormularioModificado();
      swal({
        title: '¡Operación Exitosa!',
        type: 'success',
        confirmButtonText: 'Aceptar',
      });



      try {
        const val = await this._empleadoService.validaModificacionDatosFiscales(this._empleadoService.getIdentity().id);
        localStorage.setItem('valorActualModificacion', val['nDatosModificados']);
      } catch (error) { }

      this.mostrarDiv();

    }).fail(() => {

      $.ajax(settings).done(async () => {

        swal({
          title: '¡Operación Exitosa!',
          type: 'success',
          confirmButtonText: 'Aceptar ',
        });


        try {
          const val = await this._empleadoService.validaModificacionDatosFiscales(this._empleadoService.getIdentity().id);
          localStorage.setItem('valorActualModificacion', val['nDatosModificados']);
        } catch (error) { }

        this.titularPut = new TitularPut('', '', '', '');
        this.valoresModificados = [];
        const to = this.banderaMail['email'];

        this.enviarMailNotificacion(to, this.sujeto, this.bodyHTML);
        localStorage.setItem('cambios', '1');
        localStorage.setItem('df', '1');
        localStorage.setItem('dfg', '1');

        this.construirFormularioModificado();

        this.ngOnInit();
        this.mostrarDiv();

      }).fail(() => {
        swal({
          title: '¡La conexion falló!',
          html: '<small style="color: grey; text-align: justify;">No fue posible procesar la petición, Intente mas tarde.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });

        this.construirFormularioModificado();
        this.ngOnInit();
        this.mostrarDiv();

      });

    });
  }

  async construirFormularioModificado() {
    await this.getTodosDatosEmpleado();
    this.mostrarDiv();
  }

  getConstruirParametros() {
    const arregloAux: any[] = [];
    this.titularPut = new TitularPut('', '', '', '');
    this.titularPut.idEmpleado = '' + this._empleadoService.getIdentity().id;
    this.titularPut.idEmpresa = this._empleadoService.getIdentity().idEmpresa;

    const obj = {};

    const arrayForm2 = LIST_FORM_ARRAY;

    const Id = $('#Id').val();
    const EMIdEmpresa = $('#EMIdEmpresa').val();
    const EMIdTitular = $('#EMIdTitular').val();
    const EMIdPerfil = $('#EMIdPerfil').val();
    const EMIdParentesco = $('#EMIdParentesco').val();
    const EMIdSexo = $('#EMIdSexo').val();
    const EMIdAcceso = $('#EMIdAcceso').val();
    const EMIdContacto = $('#EMIdContacto').val();
    const EMIdEstatus = $('#EMIdEstatus').val();
    const EMFechaEstatus = $('#EMFechaEstatus').val();
    const EMIdTransferido = $('#EMIdTransferido').val();
    const EMNumeroEmpleado = $('#EMNumeroEmpleado').val();
    const EMCertificado = $('#EMCertificado').val();
    const EMApellidoPaterno = $('#EMApellidoPaterno').val();
    const EMApellidoMaterno = $('#EMApellidoMaterno').val();
    const EMNombre1 = $('#EMNombre1').val();
    const EMNombre2 = $('#EMNombre2').val();
    const EMFechaNacimiento = $('#EMFechaNacimiento').val();
    const EMEdad = $('#EMEdad').val();
    const EMFechaIngresoEmpresa = $('#EMFechaIngresoEmpresa').val();
    const EMFechaBaja = $('#EMFechaBaja').val();
    const EMFechaAntiguedadGMM = $('#EMFechaAntiguedadGMM').val();
    const EMAntiguedadGMM = $('#EMAntiguedadGMM').val();
    const EMPuesto = $('#EMPuesto').val();
    const EMArea = $('#EMArea').val();
    const EMOficina = $('#EMOficina').val();
    const EMrfc = $('#EMrfc').val();
    const EMcurp = $('#EMcurp').val();
    const EMnss = $('#EMnss').val();
    const EMTipoEmpleado = $('#EMTipoEmpleado').val();
    const EMIdTipoAsegurado = $('#EMIdTipoAsegurado').val();
    const EMIdTipoSalario = $('#EMIdTipoSalario').val();
    const EMIdSalarioConfidencial = $('#EMIdSalarioConfidencial').val();
    const EMSalarioBase = $('#EMSalarioBase').val();
    const EMSalarioIntegrado = $('#EMSalarioIntegrado').val();
    const EMSalarioBruto = $('#EMSalarioBruto').val();
    const EMSalarioNeto = $('#EMSalarioNeto').val();
    const EMDeduccionesM = $('#EMDeduccionesM').val();
    const EMDeduccionesP = $('#EMDeduccionesP').val();
    const EMPrestacionesM = $('#EMPrestacionesM').val();
    const EMPrestacionesP = $('#EMPrestacionesP').val();
    const EMFondoAhorroM = $('#EMFondoAhorroM').val();
    const EMFondoAhorroP = $('#EMFondoAhorroP').val();
    const EMFondoAhorroAcumulado = $('#EMFondoAhorroAcumulado').val();
    const EMValesM = $('#EMValesM').val();
    const EMValesP = $('#EMValesP').val();
    const EMExcedente = $('#EMExcedente').val();
    const EMBeneficioMaximoM = $('#EMBeneficioMaximoM').val();
    const EMBeneficioMaximoP = $('#EMBeneficioMaximoP').val();
    const EMBeneFicioOtorgadoM = $('#EMBeneFicioOtorgadoM').val();
    const EMBeneFicioOtorgadoP = $('#EMBeneFicioOtorgadoP').val();
    const EMTelefono = $('#EMTelefono').val();
    const EMCorreoElectronico = $('#EMCorreoElectronico').val();
    const EMArchivoInformacion = $('#EMArchivoInformacion').val();
    const EMClaveAcceso = $('#EMClaveAcceso').val();
    const EMObservaciones = $('#EMObservaciones').val();
    const EMUsuarioAdd = $('#EMUsuarioAdd').val();
    const EMFechaAdd = $('#EMFechaAdd').val();
    const EMUsuarioUMod = $('#EMUsuarioUMod').val();
    const EMFechaUMod = $('#EMFechaUMod').val();
    const EMUsuarioDel = $('#EMUsuarioDel').val();
    const EMFechaDel = $('#EMFechaDel').val();
    const EMVIP = $('#EMVIP').val();
    const EMIdRol = $('#EMIdRol').val();
    const EMidCentroCostos = $('#EMidCentroCostos').val();
    const EMNetForbes = $('#EMNetForbes').val();
    const EMTipoDomicilio = $('#EMTipoDomicilio').val();
    const EMCalleFisico = $('#EMCalleFisico').val();
    const EMColoniaFisico = $('#EMColoniaFisico').val();
    const EMMunicipioDelegacionFisico = $('#EMMunicipioDelegacionFisico').val();
    const EMEstadoFisico = $('#EMEstadoFisico').val();
    const EMCodigoPostalFisico = $('#EMCodigoPostalFisico').val();
    const EMFumador = $('#EMFumador').val();
    const EMConsumoAlcohol = $('#EMConsumoAlcohol').val();
    const EMDiasVacacionesporGozar = $('#EMDiasVacacionesporGozar').val();
    const EMContraseña = $('#EMContraseña').val();
    const EMContinua = $('#EMContinua').val();
    const EMCalleFiscal = $('#EMCalleFiscal').val();
    const EMColoniaFiscal = $('#EMColoniaFiscal').val();
    const EMMunicipioDelegacionFiscal = $('#EMMunicipioDelegacionFiscal').val();
    const EMEstadoFiscal = $('#EMEstadoFiscal').val();
    const EMCodigoPostalFiscal = $('#EMCodigoPostalFiscal').val();
    const EMCambioPassword = $('#EMCambioPassword').val();
    const EMFechaAcceso = $('#EMFechaAcceso').val();
    const EMBloqueoXSel = $('#EMBloqueoXSel').val();
    const EMFecBloqueoXSel = $('#EMFecBloqueoXSel').val();
    const EMReseteoPassword = $('#EMReseteoPassword').val();
    const Desarrollo = $('#Desarrollo').val();
    const EMFechaSincronizacion = $('#EMFechaSincronizacion').val();
    const EMFechaAsignacionIdADN = $('#EMFechaAsignacionIdADN').val();
    const EMFechaAlta = $('#EMFechaAlta').val();
    const EMIdJefe = $('#EMIdJefe').val();
    const EMFechaAntiguedadPP = $('#EMFechaAntiguedadPP').val();
    const EMSaldoCuentaEmpleadoPP = $('#EMSaldoCuentaEmpleadoPP').val();
    const EMSaldoCuentaEmpresaPP = $('#EMSaldoCuentaEmpresaPP').val();
    const EMSaldoCuentaExtraordinarioPP = $('#EMSaldoCuentaExtraordinarioPP').val();
    const EMFechaIngresoIMSSPP = $('#EMFechaIngresoIMSSPP').val();
    const EMSaldoAcumuladoAportacionEmpleadoPP = $('#EMSaldoAcumuladoAportacionEmpleadoPP').val();
    const EMSaldoAcumuladoAportacionCondicionadaPP = $('#EMSaldoAcumuladoAportacionCondicionadaPP').val();
    const EMSaldoAcumuladoAportacionBasicaPP = $('#EMSaldoAcumuladoAportacionBasicaPP').val();
    const EMSaldoAcumuladoAportacionAdicionalPP = $('#EMSaldoAcumuladoAportacionAdicionalPP').val();
    const EMSalarioPP = $('#EMSalarioPP').val();
    const EMIdEstadoCivil = $('#EMIdEstadoCivil').val();
    const EMSaldoSubCuenta_08_PP = $('#EMSaldoSubCuenta_08_PP').val();
    const EMSaldoSubCuenta_09_PP = $('#EMSaldoSubCuenta_09_PP').val();
    const EMSaldoSubCuenta_10_PP = $('#EMSaldoSubCuenta_10_PP').val();
    const EMIEmpleado = $('#EMIEmpleado').val();
    const EMBDPPensiones = $('#EMBDPPensiones').val();
    const EMBonoCambio = $('#EMBonoCambio').val();
    const EMBFlexible = $('#EMBFlexible').val();
    const EMMatch = $('#EMMatch').val();
    const EMEmpleadoI = $('#EMEmpleadoI').val();
    const EMIAB = $('#EMIAB').val();
    const EMEdadRetiro = $('#EMEdadRetiro').val();
    const EMSalarioIMSS = $('#EMSalarioIMSS').val();
    const EMSueldoAportacion = $('#EMSueldoAportacion').val();
    const EMSueldoPlan = $('#EMSueldoPlan').val();
    const EMBeneficioJubilacion = $('#EMBeneficioJubilacion').val();
    const EMRegimen = $('#EMRegimen').val();
    const EMFechaEmision = $('#EMFechaEmision').val();

    if (Id != undefined) { obj['Id'] = Id; arregloAux.push(obj); }
    if (EMIdEmpresa != undefined) { obj['EMIdEmpresa'] = EMIdEmpresa; arregloAux.push(obj); }
    if (EMIdTitular != undefined) { obj['EMIdTitular'] = EMIdTitular; arregloAux.push(obj); }
    if (EMIdPerfil != undefined) { obj['EMIdPerfil'] = EMIdPerfil; arregloAux.push(obj); }
    if (EMIdParentesco != undefined) { obj['EMIdParentesco'] = EMIdParentesco; arregloAux.push(obj); }
    if (EMIdSexo != undefined) { obj['EMIdSexo'] = EMIdSexo; arregloAux.push(obj); }
    if (EMIdAcceso != undefined) { obj['EMIdAcceso'] = EMIdAcceso; arregloAux.push(obj); }
    if (EMIdContacto != undefined) { obj['EMIdContacto'] = EMIdContacto; arregloAux.push(obj); }
    if (EMIdEstatus != undefined) { obj['EMIdEstatus'] = EMIdEstatus; arregloAux.push(obj); }
    if (EMFechaEstatus != undefined) { obj['EMFechaEstatus'] = EMFechaEstatus; arregloAux.push(obj); }
    if (EMIdTransferido != undefined) { obj['EMIdTransferido'] = EMIdTransferido; arregloAux.push(obj); }
    if (EMNumeroEmpleado != undefined) { obj['EMNumeroEmpleado'] = EMNumeroEmpleado; arregloAux.push(obj); }
    if (EMCertificado != undefined) { obj['EMCertificado'] = EMCertificado; arregloAux.push(obj); }
    if (EMApellidoPaterno != undefined) { obj['EMApellidoPaterno'] = EMApellidoPaterno; arregloAux.push(obj); }
    if (EMApellidoMaterno != undefined) { obj['EMApellidoMaterno'] = EMApellidoMaterno; arregloAux.push(obj); }
    if (EMNombre1 != undefined) { obj['EMNombre1'] = EMNombre1; arregloAux.push(obj); }
    if (EMNombre2 != undefined) { obj['EMNombre2'] = EMNombre2; arregloAux.push(obj); }
    if (EMFechaNacimiento != undefined) { obj['EMFechaNacimiento'] = EMFechaNacimiento; arregloAux.push(obj); }
    if (EMEdad != undefined) { obj['EMEdad'] = EMEdad; arregloAux.push(obj); }
    if (EMFechaIngresoEmpresa != undefined) { obj['EMFechaIngresoEmpresa'] = EMFechaIngresoEmpresa; arregloAux.push(obj); }
    if (EMFechaBaja != undefined) { obj['EMFechaBaja'] = EMFechaBaja; arregloAux.push(obj); }
    if (EMFechaAntiguedadGMM != undefined) { obj['EMFechaAntiguedadGMM'] = EMFechaAntiguedadGMM; arregloAux.push(obj); }
    if (EMAntiguedadGMM != undefined) { obj['EMAntiguedadGMM'] = EMAntiguedadGMM; arregloAux.push(obj); }
    if (EMPuesto != undefined) { obj['EMPuesto'] = EMPuesto; arregloAux.push(obj); }
    if (EMArea != undefined) { obj['EMArea'] = EMArea; arregloAux.push(obj); }
    if (EMOficina != undefined) { obj['EMOficina'] = EMOficina; arregloAux.push(obj); }
    if (EMrfc != undefined) { obj['EMrfc'] = EMrfc; arregloAux.push(obj); }
    if (EMcurp != undefined) { obj['EMcurp'] = EMcurp; arregloAux.push(obj); }
    if (EMnss != undefined) { obj['EMnss'] = EMnss; arregloAux.push(obj); }
    if (EMTipoEmpleado != undefined) { obj['EMTipoEmpleado'] = EMTipoEmpleado; arregloAux.push(obj); }
    if (EMIdTipoAsegurado != undefined) { obj['EMIdTipoAsegurado'] = EMIdTipoAsegurado; arregloAux.push(obj); }
    if (EMIdTipoSalario != undefined) { obj['EMIdTipoSalario'] = EMIdTipoSalario; arregloAux.push(obj); }
    if (EMIdSalarioConfidencial != undefined) { obj['EMIdSalarioConfidencial'] = EMIdSalarioConfidencial; arregloAux.push(obj); }
    if (EMSalarioBase != undefined) { obj['EMSalarioBase'] = EMSalarioBase; arregloAux.push(obj); }
    if (EMSalarioIntegrado != undefined) { obj['EMSalarioIntegrado'] = EMSalarioIntegrado; arregloAux.push(obj); }
    if (EMSalarioBruto != undefined) { obj['EMSalarioBruto'] = EMSalarioBruto; arregloAux.push(obj); }
    if (EMSalarioNeto != undefined) { obj['EMSalarioNeto'] = EMSalarioNeto; arregloAux.push(obj); }
    if (EMDeduccionesM != undefined) { obj['EMDeduccionesM'] = EMDeduccionesM; arregloAux.push(obj); }
    if (EMDeduccionesP != undefined) { obj['EMDeduccionesP'] = EMDeduccionesP; arregloAux.push(obj); }
    if (EMPrestacionesM != undefined) { obj['EMPrestacionesM'] = EMPrestacionesM; arregloAux.push(obj); }
    if (EMPrestacionesP != undefined) { obj['EMPrestacionesP'] = EMPrestacionesP; arregloAux.push(obj); }
    if (EMFondoAhorroM != undefined) { obj['EMFondoAhorroM'] = EMFondoAhorroM; arregloAux.push(obj); }
    if (EMFondoAhorroP != undefined) { obj['EMFondoAhorroP'] = EMFondoAhorroP; arregloAux.push(obj); }
    if (EMFondoAhorroAcumulado != undefined) { obj['EMFondoAhorroAcumulado'] = EMFondoAhorroAcumulado; arregloAux.push(obj); }
    if (EMValesM != undefined) { obj['EMValesM'] = EMValesM; arregloAux.push(obj); }
    if (EMValesP != undefined) { obj['EMValesP'] = EMValesP; arregloAux.push(obj); }
    if (EMExcedente != undefined) { obj['EMExcedente'] = EMExcedente; arregloAux.push(obj); }
    if (EMBeneficioMaximoM != undefined) { obj['EMBeneficioMaximoM'] = EMBeneficioMaximoM; arregloAux.push(obj); }
    if (EMBeneficioMaximoP != undefined) { obj['EMBeneficioMaximoP'] = EMBeneficioMaximoP; arregloAux.push(obj); }
    if (EMBeneFicioOtorgadoM != undefined) { obj['EMBeneFicioOtorgadoM'] = EMBeneFicioOtorgadoM; arregloAux.push(obj); }
    if (EMBeneFicioOtorgadoP != undefined) { obj['EMBeneFicioOtorgadoP'] = EMBeneFicioOtorgadoP; arregloAux.push(obj); }
    if (EMTelefono != undefined) { obj['EMTelefono'] = EMTelefono; arregloAux.push(obj); }
    if (EMCorreoElectronico != undefined) { obj['EMCorreoElectronico'] = EMCorreoElectronico; arregloAux.push(obj); }
    if (EMArchivoInformacion != undefined) { obj['EMArchivoInformacion'] = EMArchivoInformacion; arregloAux.push(obj); }
    if (EMClaveAcceso != undefined) { obj['EMClaveAcceso'] = EMClaveAcceso; arregloAux.push(obj); }
    if (EMObservaciones != undefined) { obj['EMObservaciones'] = EMObservaciones; arregloAux.push(obj); }
    if (EMUsuarioAdd != undefined) { obj['EMUsuarioAdd'] = EMUsuarioAdd; arregloAux.push(obj); }
    if (EMFechaAdd != undefined) { obj['EMFechaAdd'] = EMFechaAdd; arregloAux.push(obj); }
    if (EMUsuarioUMod != undefined) { obj['EMUsuarioUMod'] = EMUsuarioUMod; arregloAux.push(obj); }
    if (EMFechaUMod != undefined) { obj['EMFechaUMod'] = EMFechaUMod; arregloAux.push(obj); }
    if (EMUsuarioDel != undefined) { obj['EMUsuarioDel'] = EMUsuarioDel; arregloAux.push(obj); }
    if (EMFechaDel != undefined) { obj['EMFechaDel'] = EMFechaDel; arregloAux.push(obj); }
    if (EMVIP != undefined) { obj['EMVIP'] = EMVIP; arregloAux.push(obj); }
    if (EMIdRol != undefined) { obj['EMIdRol'] = EMIdRol; arregloAux.push(obj); }
    if (EMidCentroCostos != undefined) { obj['EMidCentroCostos'] = EMidCentroCostos; arregloAux.push(obj); }
    if (EMNetForbes != undefined) { obj['EMNetForbes'] = EMNetForbes; arregloAux.push(obj); }
    if (EMTipoDomicilio != undefined) { obj['EMTipoDomicilio'] = EMTipoDomicilio; arregloAux.push(obj); }
    if (EMCalleFisico != undefined) { obj['EMCalleFisico'] = EMCalleFisico; arregloAux.push(obj); }
    if (EMColoniaFisico != undefined) { obj['EMColoniaFisico'] = EMColoniaFisico; arregloAux.push(obj); }
    if (EMMunicipioDelegacionFisico != undefined) { obj['EMMunicipioDelegacionFisico'] = EMMunicipioDelegacionFisico; arregloAux.push(obj); }
    if (EMEstadoFisico != undefined) { obj['EMEstadoFisico'] = EMEstadoFisico; arregloAux.push(obj); }
    if (EMCodigoPostalFisico != undefined) { obj['EMCodigoPostalFisico'] = EMCodigoPostalFisico; arregloAux.push(obj); }
    if (EMFumador != undefined) { obj['EMFumador'] = EMFumador; arregloAux.push(obj); }
    if (EMConsumoAlcohol != undefined) { obj['EMConsumoAlcohol'] = EMConsumoAlcohol; arregloAux.push(obj); }
    if (EMDiasVacacionesporGozar != undefined) { obj['EMDiasVacacionesporGozar'] = EMDiasVacacionesporGozar; arregloAux.push(obj); }
    if (EMContraseña != undefined) { obj['EMContraseña'] = EMContraseña; arregloAux.push(obj); }
    if (EMContinua != undefined) { obj['EMContinua'] = EMContinua; arregloAux.push(obj); }
    if (EMCalleFiscal != undefined) { obj['EMCalleFiscal'] = EMCalleFiscal; arregloAux.push(obj); }
    if (EMColoniaFiscal != undefined) { obj['EMColoniaFiscal'] = EMColoniaFiscal; arregloAux.push(obj); }
    if (EMMunicipioDelegacionFiscal != undefined) { obj['EMMunicipioDelegacionFiscal'] = EMMunicipioDelegacionFiscal; arregloAux.push(obj); }
    if (EMEstadoFiscal != undefined) { obj['EMEstadoFiscal'] = EMEstadoFiscal; arregloAux.push(obj); }
    if (EMCodigoPostalFiscal != undefined) { obj['EMCodigoPostalFiscal'] = EMCodigoPostalFiscal; arregloAux.push(obj); }
    if (EMCambioPassword != undefined) { obj['EMCambioPassword'] = EMCambioPassword; arregloAux.push(obj); }
    if (EMFechaAcceso != undefined) { obj['EMFechaAcceso'] = EMFechaAcceso; arregloAux.push(obj); }
    if (EMBloqueoXSel != undefined) { obj['EMBloqueoXSel'] = EMBloqueoXSel; arregloAux.push(obj); }
    if (EMFecBloqueoXSel != undefined) { obj['EMFecBloqueoXSel'] = EMFecBloqueoXSel; arregloAux.push(obj); }
    if (EMReseteoPassword != undefined) { obj['EMReseteoPassword'] = EMReseteoPassword; arregloAux.push(obj); }
    if (Desarrollo != undefined) { obj['Desarrollo'] = Desarrollo; arregloAux.push(obj); }
    if (EMFechaSincronizacion != undefined) { obj['EMFechaSincronizacion'] = EMFechaSincronizacion; arregloAux.push(obj); }
    if (EMFechaAsignacionIdADN != undefined) { obj['EMFechaAsignacionIdADN'] = EMFechaAsignacionIdADN; arregloAux.push(obj); }
    if (EMFechaAlta != undefined) { obj['EMFechaAlta'] = EMFechaAlta; arregloAux.push(obj); }
    if (EMIdJefe != undefined) { obj['EMIdJefe'] = EMIdJefe; arregloAux.push(obj); }
    if (EMFechaAntiguedadPP != undefined) { obj['EMFechaAntiguedadPP'] = EMFechaAntiguedadPP; arregloAux.push(obj); }
    if (EMSaldoCuentaEmpleadoPP != undefined) { obj['EMSaldoCuentaEmpleadoPP'] = EMSaldoCuentaEmpleadoPP; arregloAux.push(obj); }
    if (EMSaldoCuentaEmpresaPP != undefined) { obj['EMSaldoCuentaEmpresaPP'] = EMSaldoCuentaEmpresaPP; arregloAux.push(obj); }
    if (EMSaldoCuentaExtraordinarioPP != undefined) { obj['EMSaldoCuentaExtraordinarioPP'] = EMSaldoCuentaExtraordinarioPP; arregloAux.push(obj); }
    if (EMFechaIngresoIMSSPP != undefined) { obj['EMFechaIngresoIMSSPP'] = EMFechaIngresoIMSSPP; arregloAux.push(obj); }
    if (EMSaldoAcumuladoAportacionEmpleadoPP != undefined) { obj['EMSaldoAcumuladoAportacionEmpleadoPP'] = EMSaldoAcumuladoAportacionEmpleadoPP; arregloAux.push(obj); }
    if (EMSaldoAcumuladoAportacionCondicionadaPP != undefined) { obj['EMSaldoAcumuladoAportacionCondicionadaPP'] = EMSaldoAcumuladoAportacionCondicionadaPP; arregloAux.push(obj); }
    if (EMSaldoAcumuladoAportacionBasicaPP != undefined) { obj['EMSaldoAcumuladoAportacionBasicaPP'] = EMSaldoAcumuladoAportacionBasicaPP; arregloAux.push(obj); }
    if (EMSaldoAcumuladoAportacionAdicionalPP != undefined) { obj['EMSaldoAcumuladoAportacionAdicionalPP'] = EMSaldoAcumuladoAportacionAdicionalPP; arregloAux.push(obj); }
    if (EMSalarioPP != undefined) { obj['EMSalarioPP'] = EMSalarioPP; arregloAux.push(obj); }
    if (EMIdEstadoCivil != undefined) { obj['EMIdEstadoCivil'] = EMIdEstadoCivil; arregloAux.push(obj); }
    if (EMSaldoSubCuenta_08_PP != undefined) { obj['EMSaldoSubCuenta_08_PP'] = EMSaldoSubCuenta_08_PP; arregloAux.push(obj); }
    if (EMSaldoSubCuenta_09_PP != undefined) { obj['EMSaldoSubCuenta_09_PP'] = EMSaldoSubCuenta_09_PP; arregloAux.push(obj); }
    if (EMSaldoSubCuenta_10_PP != undefined) { obj['EMSaldoSubCuenta_10_PP'] = EMSaldoSubCuenta_10_PP; arregloAux.push(obj); }
    if (EMIEmpleado != undefined) { obj['EMIEmpleado'] = EMIEmpleado; arregloAux.push(obj); }
    if (EMBDPPensiones != undefined) { obj['EMBDPPensiones'] = EMBDPPensiones; arregloAux.push(obj); }
    if (EMBonoCambio != undefined) { obj['EMBonoCambio'] = EMBonoCambio; arregloAux.push(obj); }
    if (EMBFlexible != undefined) { obj['EMBFlexible'] = EMBFlexible; arregloAux.push(obj); }
    if (EMMatch != undefined) { obj['EMMatch'] = EMMatch; arregloAux.push(obj); }
    if (EMEmpleadoI != undefined) { obj['EMEmpleadoI'] = EMEmpleadoI; arregloAux.push(obj); }
    if (EMIAB != undefined) { obj['EMIAB'] = EMIAB; arregloAux.push(obj); }
    if (EMEdadRetiro != undefined) { obj['EMEdadRetiro'] = EMEdadRetiro; arregloAux.push(obj); }
    if (EMSalarioIMSS != undefined) { obj['EMSalarioIMSS'] = EMSalarioIMSS; arregloAux.push(obj); }
    if (EMSueldoAportacion != undefined) { obj['EMSueldoAportacion'] = EMSueldoAportacion; arregloAux.push(obj); }
    if (EMSueldoPlan != undefined) { obj['EMSueldoPlan'] = EMSueldoPlan; arregloAux.push(obj); }
    if (EMBeneficioJubilacion != undefined) { obj['EMBeneficioJubilacion'] = EMBeneficioJubilacion; arregloAux.push(obj); }
    if (EMRegimen != undefined) { obj['EMRegimen'] = EMRegimen; arregloAux.push(obj); }
    if (EMFechaEmision != undefined) { obj['EMFechaEmision'] = EMFechaEmision; arregloAux.push(obj); }

    this.titularPut.fechaNacimiento = (EMFechaNacimiento == undefined || EMFechaNacimiento == '' || EMFechaNacimiento == null) ? this.datosEmpleado['EMFechaNacimiento'] : EMFechaNacimiento;
    let bandera = false;

    for (let index = 0; index < arrayForm2.length; index++) {
      let element = '';
      if (arregloAux[0][arrayForm2[index]] != undefined) {
        element = arregloAux[0][arrayForm2[index]].toUpperCase();

      }
      if (element != '') {
        bandera = false;
        for (let ix = 0; ix < this.valoresModificados.length; ix++) {
          if (this.valoresModificados[ix] == arrayForm2[index]) {
            bandera = true;
          }
        }
        if (bandera == true) {

          let datoConfirmacion = $('#' + arrayForm2[index] + 'Confirmacion').val();
          if (datoConfirmacion) {

            datoConfirmacion = datoConfirmacion.toUpperCase();

            if (datoConfirmacion == element) {
              this.titularPut.atributoValor += arrayForm2[index] + '=\'' + element + '\',';

              this.objetosPlantillaMail.datosActuales.push(arrayForm2[index]);
              this.objetosPlantillaMail.valores.push(element);

              this.dtaDatosAnteriores.nombre.push(arrayForm2[index]);
              this.dtaDatosAnteriores.valor.push(index);
            } else {
              this.confirmarDatos = true;
              break;
            }

          } else {

            this.titularPut.atributoValor += `${arrayForm2[index]}=\'${element}\',`;

            this.objetosPlantillaMail.datosActuales.push(arrayForm2[index]);
            this.objetosPlantillaMail.valores.push(element);

            this.dtaDatosAnteriores.nombre.push(arrayForm2[index]);
            this.dtaDatosAnteriores.valor.push(index);
          }
        }
      }
      if (element == '') {
        bandera = false;
        for (let ix = 0; ix < this.valoresModificados.length; ix++) {
          if (this.valoresModificados[ix] == arrayForm2[index]) {
            bandera = true;
          }
        }
        if (bandera == true) {
          this.titularPut.atributoValor += arrayForm2[index] + '=\'' + '' + '\',';
        }
      }
    }
    this.titularPut.atributoValor += `EmUsuarioUMod=\'${this._empleadoService.getIdentity().id}\',`;
    this.titularPut.atributoValor = this.titularPut.atributoValor.substring(0, this.titularPut.atributoValor.length - 1);
    return this.titularPut;
  }

  Cancelar() {
    window.history.back();
  }

  async enviarMailNotificacion(to: string, subject: string, plantilla: string) {
    console.clear();
    let valAux = [];

    this.objetosPlantillaMail.datosActuales.map(et => {
      valAux = valAux.concat(this.objDatosAnteriores.nombre
        .map((vval, index) => { if (vval == et) { return index; } }).filter(e => e != undefined)
      );
    });

    this.finalObjAnteriores.valor = this.objDatosAnteriores.valor.filter((v, i) => valAux.find(ind => ind == i));
    this.finalObjAnteriores.nombre = this.objetosPlantillaMail.datosActuales;

    let band: boolean;
    const lista = [];
    for (let i = 0; i < this.formDatosFiscales.length; i++) {
      band = false;
      for (let j = 0; j < this.finalObjAnteriores.nombre.length; j++) {
        if (this.formDatosFiscales[i]['nombreCampo'] == this.finalObjAnteriores.nombre[j]) {
          band = true;
        }
      }
      if (band == true) {
        lista.push(this.formDatosFiscales[i]['etiqueta']);
      }
    }

    let auxPlantilla = plantilla.toString();

    this.finalObjAnteriores.valor = this.objDatosAnteriores.valor.filter((v, i) => valAux.find(ind => ind == i));

    this.finalObjAnteriores.nombre = this.objetosPlantillaMail.datosActuales;

    this.finalObjAnteriores.valor = this.finalObjAnteriores.valor.filter(e => e);

    this.finalObjAnteriores.valor = this.finalObjAnteriores.valor.filter((item,index)=>{
      return this.finalObjAnteriores.valor.indexOf(item) === index;
    })

    this.finalObjAnteriores.nombre = this.finalObjAnteriores.nombre.filter((item,index)=>{
      return this.finalObjAnteriores.nombre.indexOf(item) === index;
    })

    this.objetosPlantillaMail.datosActuales = this.objetosPlantillaMail.datosActuales.filter((item,index)=>{
      return this.objetosPlantillaMail.datosActuales.indexOf(item) === index;
    })

    let cadena = ' ';
    auxPlantilla = auxPlantilla.substring(0, auxPlantilla.indexOf('<TABLE>'));

    for (let i = 0; i < this.finalObjAnteriores.nombre.length; i++) {
      if (lista[i] == 'Estado Fiscal') {
        cadena += `<tr><td>${lista[i]}(anterior)</td><td>${
          this.dataSelectList.estadosFiscales[this.buscarValorEstado(this.dataSelectList.estadosFiscales,
          this.finalObjAnteriores.valor[i])]['esDescripcion']}</td></tr>`;
      } else {
        cadena += `<tr><td>${lista[i]}(anterior)</td><td>${this.finalObjAnteriores.valor[i]}</td></tr>`;
      }
    }

    for (let i = 0; i < this.objetosPlantillaMail.datosActuales.length; i++) {
      if (lista[i] == 'Estado Fiscal') {
        const xvar = this.buscarValorEstado(this.dataSelectList.estadosFiscales, parseInt(this.objetosPlantillaMail.valores[i]));
        cadena += `<tr><td>${lista[i]}<b>(actual)</b></td><td>${this.dataSelectList.estadosFiscales[xvar]['esDescripcion']}</td></tr>`;
      } else {
        cadena += `<tr><td>${lista[i]}<b>(actual)</b></td><td>${this.objetosPlantillaMail.valores[i]}</td></tr>`;
      }
    }

    auxPlantilla = auxPlantilla + `<table border="1"> <thead> <tr> <th>Nombre del Campo</th> <th>Valor</th></tr></thead><tbody>` + cadena + `</tbody></table>`;
    try {
      await this._empleadoService.sendMailUnificado(to,this.cc,'',subject,this.bodyHTML, '','','','',20,this._empleadoService.getToken());
    } catch (error) {
      console.log("Error al enviar el mail", error);
    }

    //this.ngOnInit();
  }

  async getEstados() {
    try {
      const response: any = await this._empleadoService.getEstadosFiscal()
      this.dataSelectList.estadosFiscales = response;
      this.ordenarEstados(this.dataSelectList.estadosFiscales);
    } catch (error) { }
  }

  async getOficinas() {
    try {
      const response: any = await this._empleadoService.getOficinasFiscales(this.identity.idEmpresa);
      this.dataSelectList.oficinasFiscales = response;
    } catch (error) { }
  }

  async getAreas() {
    try {
      const response: any = await this._empleadoService.getVipAreas(this.identity.idEmpresa, 'EMArea');
      this.dataSelectList.comboArea = response;
    } catch (error) { }
  }

  async getVip() {
    try {
      const response: any = await this._empleadoService.getVipAreas(this.identity.idEmpresa, 'EMVIP');
      this.dataSelectList.comboVip = response;
    } catch (error) { }
  }

  async getCentroCostos() {
    this.dataSelectList.comboCostos = [];
    this._empleadoService.getVipAreas(this.identity.idEmpresa, 'EMidCentroCostos').then(
      (response) => this.dataSelectList.comboCostos = <any>response
    );
  }

  async getPuestos() {
    try {
      const response: any = await this._empleadoService.getVipAreas(this.identity.idEmpresa, 'EMTipoEmpleado');
      this.dataSelectList.comboPuesto = response;
    } catch (error) { }
  }

  async getRegimenes() {
    try {
      const response: any = await this._empleadoService.getVipAreas(this.identity.idEmpresa, 'EMRegimen');
      this.dataSelectList.comboRegimen = response;
    } catch (error) { }
  }

  async getSexo() {
    try {
      const response: any = await this._dependienteService.getSexos(this.token);
      this.dataSelectList.comboSexo = response;
    } catch (error) { }
  }

  async getPerfil() {
    try {
      const response: any = await this._dependienteService.getPerfilesT(this.token, this.identity.idEmpresa);
      this.dataSelectList.comboPerfiles = response;
    } catch (error) { }
  }

  async getRol() {
    try {
      const response: any = await this._dependienteService.getRolEmpresa(this.identity.idEmpresa);
      this.dataSelectList.comboRol = response;
    } catch (error) { }
  }

  ordenarEstados(obj) {
    obj.sort((a, b) => a.esDescripcion.localeCompare(b.esDescripcion));
  }

  buscarValorEstado(data, value) {
    return data.map(function (e) { return e.esIdEstado; }).indexOf(value);
  }

  handleUpload(file: FileList) {
    this.fileConstancia = null;
    if (!file || !file.length) return;

    const archivo = file.item(0);
    if (archivo.size > 10000000) {
      swal("El archivo es muy grande", "El archivo no debe exceder 10 MB", 'info');
      $('#file').val('');
      return;
    }

    const esPdf = archivo.name.toLowerCase().endsWith('.pdf')
      && (!archivo.type || archivo.type === 'application/pdf');
    if (!esPdf) {
      swal("¡Cuidado!", "El formato del archivo no es permitido. Debes elegir un archivo con extensión .pdf", 'info');
      $('#file').val('');
      return;
    }

    this.fileConstancia = archivo;
  }
  async cargaDatos(){
    if(this.fileConstancia)
    {
      swal({
        title: 'Obteniendo datos...',
        allowEscapeKey: false,
        allowOutsideClick: false,
        onOpen: async()=>{
          swal.showLoading();
          try{

            await this.obtenerDatos();

            if(this.datos?.exito)
            {
              await this.guardarDocumento();
              $('#file').val('');
              this.fileConstancia = null;
              swal.close();
              swal({
                title: '',
                html: '<p style="color: grey; text-align: center;">'+this.datos.message+'.</p></br> <label><b>Debes revisar que los datos obtenidos de tu constancia son correctos. En caso contrario, puedes editarlos</b></label>',
                type: 'success',
                confirmButtonText: 'Aceptar',
              });
            }
            else
              {
                $('#file').val('');
                this.fileConstancia = null;
                swal({
                  title: '',
                  html: '<p style="color: grey; text-align: center;">'+this.datos.message+'.</p>',
                  type: 'info',
                  confirmButtonText: 'Aceptar',
                });
              }
          }
          catch (error) {
            console.log("Error",error);
            $('#file').val('');
            this.fileConstancia = null;
            const mensaje = error?.error?.message
              || error?.message
              || 'No se pudieron cargar los datos de la constancia.';
            swal({
              title: '',
              html: '<p style="color: grey; text-align: center;">'+mensaje+'</p>',
              type: 'warning',
              confirmButtonText: 'Aceptar',
            });
          }
        }
      });
    }
    else
    {
      swal({
        title: '',
        html: '<p style="color: grey; text-align: center;">No se ha cargado un documento.</p>',
        type: 'info',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  normalizarEtiqueta(valor: string): string {
    return (valor || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/:/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toUpperCase();
  }

  obtenerValor(campos: any[], nombres: string[]): string {
    const etiquetas = nombres.map(nombre => this.normalizarEtiqueta(nombre));
    const exacto = campos.find(x => x.campo
      && etiquetas.includes(this.normalizarEtiqueta(x.campo)));
    const aproximado = exacto || campos.find(x => x.campo
      && etiquetas.some(nombre => this.normalizarEtiqueta(x.campo).includes(nombre)));
    return aproximado?.valor ? String(aproximado.valor).trim() : '';
  }

  async obtenerDatos() {

    const token = this.token;
    const fileToUpload = <File>this.fileConstancia;

    const fData = new FormData();

    fData.append('idEmpleado', this.identity.id);
    fData.append('idAdministrador', '0');
    fData.append('archivo', fileToUpload, fileToUpload.name);

    this.datos = await this._apiServise.datosConstancia(fData, token);

    if (!this.datos?.exito || !Array.isArray(this.datos.data) || this.datos.data.length === 0) {
      return;
    }

    console.log(this.datos);

    const rfc = this.obtenerValor(this.datos.data, ['RFC']);

    const curp = this.obtenerValor(this.datos.data, ['CURP']);

    const codigoPostalRaw = this.obtenerValor(
      this.datos.data,
      ['Código Postal', 'Codigo Postal']
    );

    const nombreVialidadRaw = this.obtenerValor(
      this.datos.data,
      ['Nombre de Vialidad']
    );

    const noExteriorRaw = this.obtenerValor(
      this.datos.data,
      ['Número Exterior', 'Numero Exterior']
    );

    const coloniaRaw = this.obtenerValor(
      this.datos.data,
      ['Nombre de la Colonia']
    );

    const municipioRaw = this.obtenerValor(
      this.datos.data,
      [
        'Nombre del Municipio',
        'Municipio',
        'Demarcación Territorial'
      ]
    );

    const entidadRaw = this.obtenerValor(
      this.datos.data,
      ['Entidad Federativa']
    );

    const correoElectronico = this.obtenerValor(
      this.datos.data,
      ['Correo Electrónico', 'Correo Electronico']
    );

    const telefono = this.obtenerValor(
      this.datos.data,
      ['Teléfono', 'Telefono']
    );

    const fechaEmision = this.obtenerValor(
      this.datos.data,
      ['Fecha de Emisión', 'Fecha de Emision']
    );

    const regimenTexto = this.obtenerValor(
      this.datos.data,
      ['Régimen Fiscal']
    );
    // ==========================
    // Normalización de datos
    // ==========================

    const codigoPostalMatch = codigoPostalRaw.match(/\d{5}/);

    const codigoPostal = codigoPostalMatch
      ? codigoPostalMatch[0]
      : '';

    const nombreVialidad = nombreVialidadRaw.trim();
    const noExterior = noExteriorRaw.trim();

    const coloniaMatch = coloniaRaw.match(
      /Nombre de la Colonia:\s*(.*)/i
    );

    const colonia = coloniaMatch
      ? coloniaMatch[1].trim()
      : coloniaRaw;

    const municipioMatch = municipioRaw.match(
      /Territorial:\s*(.*)/i
    );

    const municipio = municipioMatch
      ? municipioMatch[1].trim()
      : municipioRaw;

    const entidad = entidadRaw
      .replace(/Entre Calle:.*/i, '')
      .trim();

    const calleFiscal =
      `${nombreVialidad} ${noExterior}`.trim();

    // ==========================
    // RFC
    // ==========================

    if (rfc) {

      this.datosEmpleado["EMrfc"] =
        this.datosEmpleado["EMrfcConfirmacion"] =
        rfc;

      this.valoresModificados.push('EMrfc');

      this.datosFormulario.get('EMrfc').setValue(rfc);
      this.datosFormulario.get('EMrfc').updateValueAndValidity();
    }

    // ==========================
    // CURP
    // ==========================

    if (curp) {

      this.datosEmpleado["EMcurp"] =
        this.datosEmpleado["EMcurpConfirmacion"] =
        curp;

      this.valoresModificados.push('EMcurp');

      this.datosFormulario.get('EMcurp').setValue(curp);
      this.datosFormulario.get('EMcurp').updateValueAndValidity();
    }

    // ==========================
    // Código Postal
    // ==========================

    if (codigoPostal) {

      this.datosEmpleado["EMCodigoPostalFiscal"] =
        this.datosEmpleado["EMCodigoPostalFiscalConfirmacion"] =
        codigoPostal;

      this.valoresModificados.push('EMCodigoPostalFiscal');

      this.datosFormulario.get('EMCodigoPostalFiscal')
        .setValue(codigoPostal);

      this.datosFormulario.get('EMCodigoPostalFiscal')
        .updateValueAndValidity();
    }

    // ==========================
    // Calle
    // ==========================

    if (calleFiscal) {

      this.datosEmpleado["EMCalleFiscal"] =
        this.datosEmpleado["EMCalleFiscalConfirmacion"] =
        calleFiscal;

      this.valoresModificados.push('EMCalleFiscal');

      this.datosFormulario.get('EMCalleFiscal')
        .setValue(calleFiscal);

      this.datosFormulario.get('EMCalleFiscal')
        .updateValueAndValidity();
    }

    // ==========================
    // Colonia
    // ==========================

    if (colonia) {

      this.datosEmpleado["EMColoniaFiscal"] =
        this.datosEmpleado["EMColoniaFiscalConfirmacion"] =
        colonia;

      this.valoresModificados.push('EMColoniaFiscal');

      this.datosFormulario.get('EMColoniaFiscal')
        .setValue(colonia);

      this.datosFormulario.get('EMColoniaFiscal')
        .updateValueAndValidity();
    }

    // ==========================
    // Municipio
    // ==========================

    if (municipio) {

      this.datosEmpleado["EMMunicipioDelegacionFiscal"] =
        this.datosEmpleado["EMMunicipioDelegacionFiscalConfirmacion"] =
        municipio;

      this.valoresModificados.push('EMMunicipioDelegacionFiscal');

      this.datosFormulario.get('EMMunicipioDelegacionFiscal')
        .setValue(municipio);

      this.datosFormulario.get('EMMunicipioDelegacionFiscal')
        .updateValueAndValidity();
    }

    // ==========================
    // Correo electrónico
    // ==========================

    if (correoElectronico) {
      this.datosEmpleado["EMCorreoElectronico"] =
        this.datosEmpleado["EMCorreoElectronicoConfirmacion"] =
        correoElectronico;
      this.valoresModificados.push('EMCorreoElectronico');
      this.datosFormulario.get('EMCorreoElectronico').setValue(correoElectronico);
      this.datosFormulario.get('EMCorreoElectronico').updateValueAndValidity();
    }

    // ==========================
    // Teléfono
    // ==========================

    if (telefono) {
      this.datosEmpleado["EMTelefono"] =
        this.datosEmpleado["EMTelefonoConfirmacion"] =
        telefono;
      this.valoresModificados.push('EMTelefono');
      this.datosFormulario.get('EMTelefono').setValue(telefono);
      this.datosFormulario.get('EMTelefono').updateValueAndValidity();
    }

    // ==========================
    // Estado
    // ==========================

    if (entidad && this.dataSelectList.estadosFiscales?.length) {
      const entidadNormalizada = this.normalizarEtiqueta(entidad) === 'MEXICO'
        ? 'ESTADO DE MEXICO'
        : this.normalizarEtiqueta(entidad);
      const estado = this.dataSelectList.estadosFiscales.find(
        e => this.normalizarEtiqueta(e.esDescripcion) === entidadNormalizada
      );

      if (estado) {
        $("#EMEstadoFiscal").val(estado.esIdEstado);
        $("#EMEstadoFiscalConfirmacion").val(estado.esIdEstado);
        this.datosEmpleado["EMEstadoFiscal"] =
          this.datosEmpleado["EMEstadoFiscalConfirmacion"] =
          estado.esIdEstado;
        this.valoresModificados.push('EMEstadoFiscal');
        this.datosFormulario.get('EMEstadoFiscal').setValue(estado.esIdEstado);
        this.datosFormulario.get('EMEstadoFiscal').updateValueAndValidity();
      }
    }

    // ==========================
    // Fecha emisión
    // ==========================

    if (fechaEmision) {

      this.datosEmpleado["EMFechaEmision"] =
        this.datosEmpleado["EMFechaEmisionConfirmacion"] =
        fechaEmision;

      this.valoresModificados.push('EMFechaEmision');

      this.datosFormulario.get('EMFechaEmision')
        .setValue(fechaEmision);

      this.datosFormulario.get('EMFechaEmision')
        .updateValueAndValidity();
    }

    // ==========================
    // Régimen Fiscal
    // ==========================

    if (regimenTexto && this.dataSelectList.comboRegimen?.length) {
      const primerRegimen = regimenTexto.split(',')[0].trim();
      const regimenNormalizado = this.normalizarEtiqueta(primerRegimen)
        .replace(/\bREGIMEN\b/g, '')
        .replace(/\s+/g, ' ')
        .trim();
      const regimenEncontrado = this.dataSelectList.comboRegimen.find((e: any) => {
        const descripcion = this.normalizarEtiqueta(e.TEDescripcion)
          .replace(/\bREGIMEN\b/g, '')
          .replace(/\s+/g, ' ')
          .trim();
        return descripcion.length > 0 && regimenNormalizado.length > 0
          && (descripcion === regimenNormalizado
          || descripcion.includes(regimenNormalizado)
          || regimenNormalizado.includes(descripcion));
      });

      const idRegimen = regimenEncontrado
        ? (regimenEncontrado.TEIdDetalle ?? regimenEncontrado.teidDetalle)
        : null;
      if (idRegimen !== null && idRegimen !== undefined) {
        $('#EMRegimen').val(idRegimen);
        $('#EMRegimenConfirmacion').val(idRegimen);
        this.datosEmpleado["EMRegimen"] =
          this.datosEmpleado["EMRegimenConfirmacion"] =
          idRegimen;
        this.valoresModificados.push('EMRegimen');
        this.datosFormulario.get('EMRegimen')?.setValue(idRegimen);
        this.datosFormulario.get('EMRegimen')?.updateValueAndValidity();
      }
    }

  }
  /*async obtenerDatos()
  {
   // var resultAuth: any = await this._apiServise.authAPI_Beflex();
   var token = this.token
    let fileToUpload = <File>this.fileConstancia;

    const fData = new FormData();
    fData.append('idEmpleado', this.identity.id);
    fData.append('idAdministrador', "0");
    fData.append('archivo', fileToUpload, fileToUpload.name);

    this.datos = await this._apiServise.datosConstancia(fData, token);

        const datosMap = {};

    this.datos.forEach(item => {
      datosMap[item.campo] = item.valor;
    });

    console.log(datosMap);

    if(this.datos.exito)
    {
      this.datosEmpleado["EMrfc"] = this.datosEmpleado["EMrfcConfirmacion"] = this.datos.data.rfc;
      this.valoresModificados.push('EMrfc');
      // this.resetValidacion('EMrfc');
      this.datosFormulario.get('EMrfc').setValue(this.datos.data.rfc);
      this.datosFormulario.get('EMrfc').updateValueAndValidity();

      this.datosEmpleado["EMcurp"] = this.datosEmpleado["EMcurpConfirmacion"] = this.datos.data.curp;
      this.valoresModificados.push('EMcurp');
      // this.resetValidacion('EMcurp');
      this.datosFormulario.get('EMcurp').setValue(this.datos.data.curp);
      this.datosFormulario.get('EMcurp').updateValueAndValidity();

      this.datosEmpleado["EMCodigoPostalFiscal"] = this.datosEmpleado["EMCodigoPostalFiscalConfirmacion"] = this.datos.data.codigoPostal;
      this.valoresModificados.push('EMCodigoPostalFiscal');
      // this.resetValidacion('EMCodigoPostalFiscal');
      this.datosFormulario.get('EMCodigoPostalFiscal').setValue(this.datos.data.codigoPostal);
      this.datosFormulario.get('EMCodigoPostalFiscal').updateValueAndValidity();

      this.datosEmpleado["EMCalleFiscal"] = this.datosEmpleado["EMCalleFiscalConfirmacion"] = `${this.datos.data.tipoVialidad} ${this.datos.data.nombreVialidad} ${this.datos.data.noExterior} ${this.datos.data.noInterior}`;
      this.valoresModificados.push('EMCalleFiscal');
      // this.resetValidacion('EMCalleFiscal');
      this.datosFormulario.get('EMCalleFiscal').setValue(`${this.datos.data.tipoVialidad} ${this.datos.data.nombreVialidad} ${this.datos.data.noExterior} ${this.datos.data.noInterior}`);
      this.datosFormulario.get('EMCalleFiscal').updateValueAndValidity();

      this.datosEmpleado["EMColoniaFiscal"] = this.datosEmpleado["EMColoniaFiscalConfirmacion"] = this.datos.data.nombreColonia;
      this.valoresModificados.push('EMColoniaFiscal');
      // this.resetValidacion('EMColoniaFiscal');
      this.datosFormulario.get('EMColoniaFiscal').setValue(this.datos.data.nombreColonia);
      this.datosFormulario.get('EMColoniaFiscal').updateValueAndValidity();

      this.datosEmpleado["EMMunicipioDelegacionFiscal"] = this.datosEmpleado["EMMunicipioDelegacionFiscalConfirmacion"] = this.datos.data.municipio;      
      this.valoresModificados.push('EMMunicipioDelegacionFiscal');
      // this.resetValidacion('EMMunicipioDelegacionFiscal');
      this.datosFormulario.get('EMMunicipioDelegacionFiscal').setValue(this.datos.data.municipio);      
      this.datosFormulario.get('EMMunicipioDelegacionFiscal').updateValueAndValidity();

      this.datosEmpleado["EMCorreoElectronico"] = this.datosEmpleado["EMCorreoElectronicoConfirmacion"] = this.datos.data.correoElectronico;
      this.valoresModificados.push('EMCorreoElectronico');
      // this.resetValidacion('EMCorreoElectronico');
      this.datosFormulario.get('EMCorreoElectronico').setValue(this.datos.data.correoElectronico);      
      this.datosFormulario.get('EMCorreoElectronico').updateValueAndValidity();
      
      this.datosEmpleado["EMTelefono"] = this.datosEmpleado["EMTelefonoConfirmacion"] = this.datos.data.telefono;
      this.valoresModificados.push('EMTelefono');
      // this.resetValidacion('EMTelefono');
      this.datosFormulario.get('EMTelefono').setValue(this.datos.data.telefono);      
      this.datosFormulario.get('EMTelefono').updateValueAndValidity();

      if (this.dataSelectList.comboRegimen != undefined) {
        var splitRegimen = this.datos.data.regimen.split(",");
        splitRegimen = splitRegimen[0].trim().toUpperCase().replace('INGRESOS', '');

        // if (splitRegimen.includes("ACTIVIDADES EMPRESARIALES")) {
        //   splitRegimen = splitRegimen[0].trim().toUpperCase().replace('ACTIVIDADES', '');
        // }
        
        let palabrasClave = splitRegimen.trim().toUpperCase().replace('RÉGIMEN', '').split(/\s+/).filter(palabra => palabra.length >= 3);;
        
        var regimen = this.dataSelectList.comboRegimen.filter(e => {    
          return palabrasClave.some(palabra => e.TEDescripcion.trim().toUpperCase().includes(palabra));
        });
      
        // var regimen: any = this.dataSelectList.comboRegimen.filter(e => e.TEDescripcion.trim().toUpperCase() == splitRegimen[0].trim().toUpperCase());

        
        if (regimen.length > 0) {
          if (splitRegimen.includes("ACTIVIDADES EMPRESARIALES Y PROFESIONALES")) {
            $("#EMRegimen").val(regimen[1].TEIdDetalle);
            $("#EMRegimenConfirmacion").val(regimen[1].TEIdDetalle);
            this.datosFormulario.get('EMRegimen').setValue(regimen[1].TEIdDetalle);
          }else{
            $("#EMRegimen").val(regimen[0].TEIdDetalle);
            $("#EMRegimenConfirmacion").val(regimen[0].TEIdDetalle);
            this.datosFormulario.get('EMRegimen').setValue(regimen[0].TEIdDetalle);
          }
          
        } 
        else {
          $("#EMRegimen").val(0);
          $("#EMRegimenConfirmacion").val(0);
        }

        this.valoresModificados.push('EMRegimen');
        // this.resetValidacion('EMRegimen');
              
        this.datosFormulario.get('EMRegimen').updateValueAndValidity();
      }

      // Caso Especial en Constancia - Para evitar mover catalogo

      var estado:any = this.datos.data.nombreEntidadFederativa.trim() === 'MEXICO' 
        ? this.dataSelectList.estadosFiscales.filter(e=> e.esDescripcion.trim() == 'ESTADO DE MEXICO')
        : this.dataSelectList.estadosFiscales.filter(e=> e.esDescripcion.trim() == this.datos.data.nombreEntidadFederativa.trim())

      estado.length > 0 
        ? $("#EMEstadoFiscal").val(estado[0].esIdEstado) 
        : $("#EMEstadoFiscal").val(0);
      
        estado.length > 0 
        ? $("#EMEstadoFiscalConfirmacion").val(estado[0].esIdEstado) 
        : $("#EMEstadoFiscalConfirmacion").val(0);

      this.valoresModificados.push('EMEstadoFiscal');
      this.datosFormulario.get('EMEstadoFiscal').setValue(estado[0].esIdEstado);      
      this.datosFormulario.get('EMEstadoFiscal').updateValueAndValidity();

      this.datosEmpleado["EMFechaEmision"] = this.datosEmpleado["EMFechaEmisionConfirmacion"] = this.datos.data.fechaEmision;
      this.datosFormulario.get('EMFechaEmision').setValue(this.datos.data.fechaEmision);      
      this.datosFormulario.get('EMFechaEmision').updateValueAndValidity();

      this.valoresModificados.push('EMFechaEmision');      
    }
  }*/

async guardarDocumento() {
  const path = String(this.datos?.nombreArchivo || '').replace(/\\/g, '/');
  if (!path) {
    throw new Error('No se recibió nombreArchivo');
  }

  const separador = path.lastIndexOf('/');
  if (separador <= 0 || separador === path.length - 1) {
    throw new Error('La ruta recibida para la constancia no es válida');
  }

  const file = <File>this.fileConstancia;
  const ruta = path.substring(0, separador);
  const nombreArchivo = path.substring(separador + 1).replace(/\.[^/.]+$/, '');
  await this._apiServise.guardarConstancia(file, ruta, nombreArchivo, this.token);
 }

  hasErrorMessage(idCampo, errorName): boolean {
    let control = this.datosFormulario.get(idCampo);
    return control.hasError(errorName);
  }

  hasOneErrorMessage(idCampo): number {
    let totalErrors: number = 0;
    let errors: ValidationErrors = this.datosFormulario.get(idCampo).errors;
    if (errors !== null) {
      Object.keys(errors).forEach(keyError => {
        totalErrors++;
      });
      return totalErrors;
    }
    return 0;
  }

  verificaCampo(id) {
    const dato = (<HTMLInputElement>  document.getElementById(id));
    if (dato != null && dato.pattern !== '') {
      if (!dato.value.match('^' + dato.pattern + '$') && (dato.value.length !== 0 && dato.required)) {
        this.datosFormulario.get(id).markAsTouched();
        this.datosFormulario.get(id).markAsDirty();
        this.datosFormulario.get(id).setErrors({unmatchedPatter: true, ...this.datosFormulario.get(id).errors});
      } else if (dato.value.match('^' + dato.pattern + '$')) {
        this.datosFormulario.get(id).setErrors(null);
      }
    }
  }

  resetValidacion(id){
    this.datosFormulario.get(id).setErrors(null);
  }

  async getCorreosAdmin() {
    try {
      this.adminCorreos = await this._empleadoService.getGrupoCorreosAdmin(this.identity.idEmpresa);
      if (this.adminCorreos) {
        for (let index = 0; index < this.adminCorreos.length; index++) {
          const ADMIN_CORREOS = this.adminCorreos[index]['adCorreoElectronico'];
          const ADMIN_CC = this.adminCorreos[index]['gcCorreoCopia'];
          const ADMIN_C_OCULTA = this.adminCorreos[index]['gcCorreoCopiaOculta'];
          if (this.to != null) {
            this.to = this.to.replace(/ /g, '');
            if (ADMIN_CC == true && ADMIN_CC != undefined) {
              this.cc += ADMIN_CORREOS + ',';
              this.cc = this.cc.replace(/ /g, '');
              this.cc = this.cc.replace(/undefined/g, '');
            }
            if (ADMIN_C_OCULTA == true && ADMIN_C_OCULTA != undefined) {
              this.bcc += ADMIN_CORREOS + ',';
              this.bcc = this.bcc.replace(/ /g, '');
            }
          } else {
            this.to = ' ';
            if (ADMIN_CC == true) {
              this.to += ADMIN_CORREOS + ',';
            }
          }
        }
      }
    } catch (error) { }
  }
  
}
