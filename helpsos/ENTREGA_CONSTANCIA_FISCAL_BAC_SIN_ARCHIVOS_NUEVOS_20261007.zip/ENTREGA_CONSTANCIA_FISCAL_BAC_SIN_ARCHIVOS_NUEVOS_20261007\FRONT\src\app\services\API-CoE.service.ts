import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { Router, CanActivate } from '@angular/router';
//import { Observable } from 'rxjs/Observable';
import { Observable, BehaviorSubject } from 'rxjs/Rx';
import { GLOBAL } from './global';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/timeout';

import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { loginGuardService } from './loginguard.service';
import { ReturnStatement } from '@angular/compiler';
import UTILS from './utils.service';

@Injectable({
  providedIn: "root",
})
export class APIService {
  public ApiBeflex: string;

  private password: string;
  private passwordEncriptUrl: string;



  private log(message: string) { }
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      console.error(error); // log to console instead

      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }


  constructor(public _http: HttpClient, private _router: Router, private logVariables: loginGuardService) {
    this.ApiBeflex = GLOBAL.Api_Beflex3;
  }

  authAPI_Beflex() {
    const Usuario = { user: GLOBAL.UserAPI, password: GLOBAL.PasswordAPI };
    return this._http.post(
      `${this.ApiBeflex}api/User/Authenticate`, Usuario).toPromise();
  }


  datosConstancia(FileRequest, Token:string){
    const Headers: HttpHeaders = new HttpHeaders({ 'Authorization': `Bearer ${Token}` });
    return this._http.post(
      `${GLOBAL.url2}ProcesaFormatos`, FileRequest,
      { headers: Headers }
    ).toPromise();
  }

  guardarConstancia(file: File, directorio: string, nombre: string, Token: string) {
    const Headers: HttpHeaders = new HttpHeaders({ 'Authorization': `Bearer ${Token}` });
    const params = new HttpParams()
      .set('directorio', directorio)
      .set('nombre', nombre);
    const formData = new FormData();
    formData.append('file', file, file.name);

    return this._http.post(
      `${GLOBAL.url2}file/upload`,
      formData,
      { headers: Headers, params, responseType: 'text' }
    ).toPromise();
  }



}
