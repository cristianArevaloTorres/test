package com.lockton.WSBeFlex.Tools;

import com.lockton.WSBeFlex.POJO.Especiales.DatosConstanciaFiscal;
import java.text.Normalizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Interpreta el texto extraido de una Constancia de Situacion Fiscal del SAT.
 */
public final class ConstanciaSATParser {

    private static final Pattern FECHA_EMISION = Pattern.compile(
            "(?iu)(\\d{1,2})\\s+DE\\s+(ENERO|FEBRERO|MARZO|ABRIL|MAYO|JUNIO|JULIO|AGOSTO|SEPTIEMBRE|OCTUBRE|NOVIEMBRE|DICIEMBRE)\\s+DE\\s+(\\d{4})");
    private static final Pattern FECHA_REGIMEN = Pattern.compile("^(.*?)\\s+(\\d{2}/\\d{2}/\\d{4})(?:\\s+\\d{2}/\\d{2}/\\d{4})?\\s*$");
    private static final Pattern RFC = Pattern.compile("(?iu)(?:^|\\s)([A-ZÑ&]{3,4}\\d{6}[A-Z0-9]{3})(?:$|\\s)");
    private static final Pattern CURP = Pattern.compile("(?iu)(?:^|\\s)([A-Z]{4}\\d{6}[HM][A-Z]{5}[A-Z0-9]\\d)(?:$|\\s)");

    private static final Map<String, Integer> MESES = new LinkedHashMap<String, Integer>();

    static {
        MESES.put("ENERO", 1);
        MESES.put("FEBRERO", 2);
        MESES.put("MARZO", 3);
        MESES.put("ABRIL", 4);
        MESES.put("MAYO", 5);
        MESES.put("JUNIO", 6);
        MESES.put("JULIO", 7);
        MESES.put("AGOSTO", 8);
        MESES.put("SEPTIEMBRE", 9);
        MESES.put("OCTUBRE", 10);
        MESES.put("NOVIEMBRE", 11);
        MESES.put("DICIEMBRE", 12);
    }

    private ConstanciaSATParser() {
    }

    public static DatosConstanciaFiscal parsear(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("El PDF no contiene texto legible");
        }

        List<String> lineas = limpiarLineas(texto);
        DatosConstanciaFiscal datos = new DatosConstanciaFiscal();

        obtenerEmision(lineas, datos);
        datos.setRfc(extraerValorSimple(lineas, "RFC"));
        datos.setCurp(extraerValorSimple(lineas, "CURP"));

        if (datos.getRfc().isEmpty()) {
            datos.setRfc(buscarPatron(lineas, RFC));
        }
        if (datos.getCurp().isEmpty()) {
            datos.setCurp(buscarPatron(lineas, CURP));
        }

        datos.setCodigoPostal(extraerEntre(lineas, "C[ÓO]DIGO POSTAL", "TIPO DE VIALIDAD"));
        datos.setTipoVialidad(extraerDespues(lineas, "TIPO DE VIALIDAD"));
        datos.setNombreVialidad(extraerEntre(lineas, "NOMBRE DE VIALIDAD", "N[ÚU]MERO EXTERIOR"));
        datos.setNoExterior(extraerDespues(lineas, "N[ÚU]MERO EXTERIOR"));
        datos.setNoInterior(extraerEntre(lineas, "N[ÚU]MERO INTERIOR", "NOMBRE DE LA COLONIA"));
        datos.setNombreColonia(extraerDespues(lineas, "NOMBRE DE LA COLONIA"));
        datos.setNombreLocalidad(extraerEntre(lineas, "NOMBRE DE LA LOCALIDAD", "NOMBRE DEL MUNICIPIO O DEMARCACI[ÓO]N TERRITORIAL"));
        datos.setMunicipio(extraerDespues(lineas, "NOMBRE DEL MUNICIPIO O DEMARCACI[ÓO]N TERRITORIAL"));
        datos.setNombreEntidadFederativa(extraerEntre(lineas, "NOMBRE DE LA ENTIDAD FEDERATIVA", "ENTRE CALLE"));
        datos.setCorreoElectronico(extraerDespues(lineas, "CORREO ELECTR[ÓO]NICO"));
        datos.setTelefono(extraerTelefono(lineas));
        obtenerRegimenes(lineas, datos);

        return datos;
    }

    private static List<String> limpiarLineas(String texto) {
        List<String> resultado = new ArrayList<String>();
        for (String linea : texto.split("\\R")) {
            String limpia = limpiarEspacios(linea);
            if (!limpia.isEmpty()) {
                resultado.add(limpia);
            }
        }
        return resultado;
    }

    private static void obtenerEmision(List<String> lineas, DatosConstanciaFiscal datos) {
        for (int i = 0; i < lineas.size(); i++) {
            if (!normalizar(lineas.get(i)).contains("LUGAR Y FECHA DE EMISION")) {
                continue;
            }

            StringBuilder emision = new StringBuilder();
            String valorEnEtiqueta = lineas.get(i).replaceFirst("(?iu)^.*?LUGAR\\s+Y\\s+FECHA\\s+DE\\s+EMISI[ÓO]N\\s*:?[ ]*", "");
            if (!valorEnEtiqueta.isEmpty()) {
                emision.append(valorEnEtiqueta);
            }

            for (int j = i + 1; j < lineas.size() && j <= i + 5; j++) {
                String normalizada = normalizar(lineas.get(j));
                if (normalizada.startsWith("RFC:") || normalizada.contains("DATOS DE IDENTIFICACION")) {
                    break;
                }
                if (emision.length() > 0) {
                    emision.append(' ');
                }
                emision.append(lineas.get(j));
                if (FECHA_EMISION.matcher(normalizar(emision.toString())).find()) {
                    break;
                }
            }

            String lugarFecha = limpiarEspacios(emision.toString());
            datos.setLugarFechaEmision(lugarFecha);
            Matcher fecha = FECHA_EMISION.matcher(normalizar(lugarFecha));
            if (fecha.find()) {
                int dia = Integer.parseInt(fecha.group(1));
                int mes = MESES.get(fecha.group(2));
                int anio = Integer.parseInt(fecha.group(3));
                datos.setFechaEmision(LocalDate.of(anio, mes, dia).format(DateTimeFormatter.ISO_LOCAL_DATE));
            }
            return;
        }
    }

    private static String extraerValorSimple(List<String> lineas, String etiqueta) {
        Pattern patron = Pattern.compile("(?iu)^\\s*" + Pattern.quote(etiqueta) + "\\s*:\\s*(.*?)\\s*$");
        for (String linea : lineas) {
            Matcher matcher = patron.matcher(linea);
            if (matcher.find()) {
                return limpiarEspacios(matcher.group(1));
            }
        }
        return "";
    }

    private static String extraerEntre(List<String> lineas, String etiquetaInicial, String etiquetaFinal) {
        Pattern patron = Pattern.compile("(?iu)" + etiquetaInicial + "\\s*:\\s*(.*?)\\s+" + etiquetaFinal + "\\s*:");
        for (String linea : lineas) {
            Matcher matcher = patron.matcher(linea);
            if (matcher.find()) {
                return limpiarEspacios(matcher.group(1));
            }
        }
        return "";
    }

    private static String extraerDespues(List<String> lineas, String etiqueta) {
        Pattern patron = Pattern.compile("(?iu)" + etiqueta + "\\s*:\\s*(.*?)\\s*$");
        for (String linea : lineas) {
            Matcher matcher = patron.matcher(linea);
            if (matcher.find()) {
                return limpiarEspacios(matcher.group(1));
            }
        }
        return "";
    }

    private static String extraerTelefono(List<String> lineas) {
        Pattern patron = Pattern.compile("(?iu)TEL\\.\\s*[^:]*LADA\\s*:\\s*(.*?)\\s+N[ÚU]MERO\\s*:\\s*(.*?)\\s*$");
        for (String linea : lineas) {
            Matcher matcher = patron.matcher(linea);
            if (matcher.find()) {
                String lada = matcher.group(1).replaceAll("\\D", "");
                String numero = matcher.group(2).replaceAll("\\D", "");
                return lada + numero;
            }
        }
        return "";
    }

    private static void obtenerRegimenes(List<String> lineas, DatosConstanciaFiscal datos) {
        int inicio = -1;
        int fin = lineas.size();
        for (int i = 0; i < lineas.size(); i++) {
            String normalizada = normalizar(lineas.get(i));
            if (normalizada.contains("REGIMEN FECHA INICIO FECHA FIN")) {
                inicio = i + 1;
                continue;
            }
            if (inicio >= 0 && (normalizada.startsWith("OBLIGACIONES:") || normalizada.contains("SUS DATOS PERSONALES"))) {
                fin = i;
                break;
            }
        }

        if (inicio < 0) {
            return;
        }

        List<String> regimenes = new ArrayList<String>();
        for (int i = inicio; i < fin; i++) {
            Matcher matcher = FECHA_REGIMEN.matcher(lineas.get(i));
            if (matcher.find()) {
                String regimen = limpiarEspacios(matcher.group(1));
                if (!regimen.isEmpty()) {
                    regimenes.add(regimen);
                }
            }
        }

        if (!regimenes.isEmpty()) {
            datos.setPrimerRegimen(regimenes.get(0));
            datos.setRegimen(String.join(",", regimenes));
        }
    }

    private static String buscarPatron(List<String> lineas, Pattern patron) {
        for (String linea : lineas) {
            Matcher matcher = patron.matcher(linea);
            if (matcher.find()) {
                return limpiarEspacios(matcher.group(1));
            }
        }
        return "";
    }

    private static String normalizar(String valor) {
        String sinAcentos = Normalizer.normalize(valor == null ? "" : valor, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
        return limpiarEspacios(sinAcentos).toUpperCase(Locale.ROOT);
    }

    private static String limpiarEspacios(String valor) {
        return valor == null ? "" : valor.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
    }
}
