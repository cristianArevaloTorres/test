# Entrega: migración de Constancia de Situación Fiscal

Fecha de preparación: 2026-10-07

La entrega contiene los cambios necesarios en el servicio Java y el front Angular. No se modifica el repositorio C# original; únicamente se utilizó como referencia funcional.

## Comportamiento implementado

- El endpoint Java `POST /beflex/ProcesaFormatos` recibe `idEmpleado`, `idAdministrador` y `archivo` como `multipart/form-data`.
- Se exige un JWT válido en el encabezado `Authorization`.
- Se valida tamaño máximo de 10 MB, extensión, MIME, firma `%PDF-`, contenido legible y texto de Constancia de Situación Fiscal.
- Ya no se exige una cantidad fija de páginas.
- Se extraen y validan fecha de emisión, RFC, CURP, código postal, dirección, correo, teléfono y regímenes.
- La fecha se entrega al front en formato ISO `yyyy-MM-dd`.
- RFC y CURP se comparan contra `ff_Empleado` cuando el empleado ya tiene esos valores.
- Se registra el historial mediante `bf_AltaConstanciaEmpleado`.
- La carga física del PDF espera la respuesta del servidor antes de mostrar éxito.

## Mapeo hacia la pantalla

| Dato de constancia | Campo de pantalla |
|---|---|
| RFC | `EMrfc` |
| CURP | `EMcurp` |
| Código postal | `EMCodigoPostalFiscal` |
| Nombre de vialidad + número exterior | `EMCalleFiscal` |
| Colonia | `EMColoniaFiscal` |
| Municipio/demarcación | `EMMunicipioDelegacionFiscal` |
| Entidad federativa | `EMEstadoFiscal` (por catálogo) |
| Correo electrónico | `EMCorreoElectronico` |
| Teléfono | `EMTelefono` |
| Fecha de emisión | `EMFechaEmision` |
| Primer régimen localizado | `EMRegimen` (por catálogo) |

Para múltiples regímenes, el primero se usa en `EMRegimen`; la lista completa, separada por comas, se guarda en `bf_ConstanciaEmpleado.Regimen`.

La dirección visible queda deliberadamente como `NombreVialidad + NoExterior`. Tipo de vialidad, número interior y localidad se conservan en el historial, pero no se concatenan en `EMCalleFiscal`.

## Base de datos

No se requiere cambio de esquema ni de procedimiento. En `FlexiForbesv2` se comprobó que `dbo.bf_AltaConstanciaEmpleado` ya recibe los 18 parámetros esperados y persiste los campos históricos acordados.

El archivo `BD/01_VALIDAR_PRERREQUISITOS.sql` sólo valida objetos, columnas y parámetros; no modifica datos ni estructura.

## Orden recomendado

1. Ejecutar el SQL de validación en el ambiente destino.
2. Integrar y desplegar `JAVA`.
3. Probar `POST /beflex/ProcesaFormatos` con JWT y una constancia válida.
4. Integrar y desplegar `FRONT`.
5. Probar la carga, revisión de campos y guardado del formulario fiscal.

## Verificaciones realizadas

- Las seis clases Java incluidas compilan de forma aislada con las dependencias del proyecto.
- El parser se probó con la constancia PDF de muestra del repositorio C#: extrajo correctamente fecha, RFC, CURP, CP, vialidad, exterior, interior, colonia, localidad, municipio, entidad y régimen.
- Se probó un caso con dos regímenes: conserva ambos y selecciona el primero.
- TypeScript completo: `tsc -p src/tsconfig.app.json --noEmit`, sin errores.

La compilación Maven integral requiere acceso a los WSDL internos configurados en `pom.xml`. El build Angular 11 debe ejecutarse con la versión de Node usada por el proyecto; Node 24 no es compatible con su Webpack antiguo.

Consulte `COMANDOS_GIT.md` para integrar y confirmar los archivos.
