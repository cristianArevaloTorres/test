package com.lockton.WSBeFlex.POJO.Especiales;

/**
 * Datos obtenidos de una Constancia de Situacion Fiscal.
 */
public class DatosConstanciaFiscal {

    private String lugarFechaEmision = "";
    private String fechaEmision = "";
    private String rfc = "";
    private String curp = "";
    private String codigoPostal = "";
    private String tipoVialidad = "";
    private String nombreVialidad = "";
    private String noExterior = "";
    private String noInterior = "";
    private String nombreColonia = "";
    private String nombreLocalidad = "";
    private String municipio = "";
    private String nombreEntidadFederativa = "";
    private String correoElectronico = "";
    private String telefono = "";
    private String regimen = "";
    private String primerRegimen = "";

    public String getLugarFechaEmision() {
        return lugarFechaEmision;
    }

    public void setLugarFechaEmision(String lugarFechaEmision) {
        this.lugarFechaEmision = valorSeguro(lugarFechaEmision);
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = valorSeguro(fechaEmision);
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = valorSeguro(rfc);
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = valorSeguro(curp);
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = valorSeguro(codigoPostal);
    }

    public String getTipoVialidad() {
        return tipoVialidad;
    }

    public void setTipoVialidad(String tipoVialidad) {
        this.tipoVialidad = valorSeguro(tipoVialidad);
    }

    public String getNombreVialidad() {
        return nombreVialidad;
    }

    public void setNombreVialidad(String nombreVialidad) {
        this.nombreVialidad = valorSeguro(nombreVialidad);
    }

    public String getNoExterior() {
        return noExterior;
    }

    public void setNoExterior(String noExterior) {
        this.noExterior = valorSeguro(noExterior);
    }

    public String getNoInterior() {
        return noInterior;
    }

    public void setNoInterior(String noInterior) {
        this.noInterior = valorSeguro(noInterior);
    }

    public String getNombreColonia() {
        return nombreColonia;
    }

    public void setNombreColonia(String nombreColonia) {
        this.nombreColonia = valorSeguro(nombreColonia);
    }

    public String getNombreLocalidad() {
        return nombreLocalidad;
    }

    public void setNombreLocalidad(String nombreLocalidad) {
        this.nombreLocalidad = valorSeguro(nombreLocalidad);
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = valorSeguro(municipio);
    }

    public String getNombreEntidadFederativa() {
        return nombreEntidadFederativa;
    }

    public void setNombreEntidadFederativa(String nombreEntidadFederativa) {
        this.nombreEntidadFederativa = valorSeguro(nombreEntidadFederativa);
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = valorSeguro(correoElectronico);
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = valorSeguro(telefono);
    }

    public String getRegimen() {
        return regimen;
    }

    public void setRegimen(String regimen) {
        this.regimen = valorSeguro(regimen);
    }

    public String getPrimerRegimen() {
        return primerRegimen;
    }

    public void setPrimerRegimen(String primerRegimen) {
        this.primerRegimen = valorSeguro(primerRegimen);
    }

    private String valorSeguro(String valor) {
        return valor == null ? "" : valor.trim();
    }
}
