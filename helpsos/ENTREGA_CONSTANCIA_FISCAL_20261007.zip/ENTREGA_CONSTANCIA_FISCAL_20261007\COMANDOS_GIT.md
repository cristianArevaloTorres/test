# Comandos Git sugeridos

Los comandos se ejecutan en los repositorios reales después de copiar sobre ellos el contenido de las carpetas `JAVA` y `FRONT` del ZIP. Las exportaciones analizadas no incluyen `.git`, por eso no se generaron commits automáticamente.

## Repositorio Java

```powershell
git switch -c feature/migracion-constancia-fiscal
git status --short

git add -- `
  src/main/java/com/lockton/WSBeFlex/DAO/ArchivosAdjuntos/JDBCProcesaFormatos.java `
  src/main/java/com/lockton/WSBeFlex/POJO/Especiales/DatosConstanciaFiscal.java `
  src/main/java/com/lockton/WSBeFlex/REST/WSArchivosAdjuntos.java `
  src/main/java/com/lockton/WSBeFlex/Services/FfArchivosAdjuntosService.java `
  src/main/java/com/lockton/WSBeFlex/Services/LogicaFfArchivosAdjuntos.java `
  src/main/java/com/lockton/WSBeFlex/Tools/ConstanciaSATParser.java

git diff --cached --check
git diff --cached
git commit -m "feat: migrar lectura de constancia fiscal al servicio Java"
```

Build en una máquina con acceso a los WSDL internos:

```powershell
.\mvnw.cmd clean test
.\mvnw.cmd package -DskipTests
```

## Repositorio front Angular

```powershell
git switch -c feature/migracion-constancia-fiscal
git status --short

git add -- `
  src/app/services/API-CoE.service.ts `
  src/app/beflex/master/misdatosfiscalesmaster/misdatosfiscalesmaster.component.ts

git diff --cached --check
git diff --cached
git commit -m "feat: completar flujo de constancia fiscal"
```

Validación recomendada con la versión de Node/npm utilizada por el proyecto:

```powershell
npm ci
.\node_modules\.bin\tsc.cmd -p src/tsconfig.app.json --noEmit
npm run build:prod
```

## Publicación

```powershell
git push -u origin feature/migracion-constancia-fiscal
```

No hay un commit ni script DDL de base de datos porque no se requiere un cambio en `FlexiForbesv2`.
