package com.lockton.WSBeFlex.Services;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.lockton.WSBeFlex.Services.LogicaFfArchivosAdjuntos.AnexosResult;
import com.lockton.WSBeFlex.Services.LogicaFfArchivosAdjuntos.LimpiezaAnexosResult;
import com.lockton.WSBeFlex.Services.LogicaFfArchivosAdjuntos.MergePdfResult;
import com.lockton.WSBeFlex.Services.LogicaFfArchivosAdjuntos.ProcesaFormatosResult;

/**
 * <p>
 * Esta interface define los métodos que se implementan en la clase
 * {@link com.lockton.WSBeFlex.Services.LogicaFfArchivosAdjuntos} que representa
 * la lógica de negocio.
 * </p>
 * 
 * @author Nicolas Contreras / NikoVonter
 * @since 1.0
 */
public interface FfArchivosAdjuntosService {

	public ProcesaFormatosResult procesaFormatos(int idEmpleado, int idAdministrador, MultipartFile archivo);

	public ResponseEntity<?> crearConsentimiento(Map<String, Object> req);

	public MergePdfResult mergePdf(Map<String, Object> req);

	public AnexosResult anexos(Map<String, Object> req);

	public LimpiezaAnexosResult limpiarAnexos(Map<String, String> req);

}
