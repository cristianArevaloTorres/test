import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { FormBuilder } from '@angular/forms';
import { EmpresaComboService } from '../../services/empresas.service';
import { EmpleadoService } from 'src/app/services/empleado.service';
import { DependienteService } from 'src/app/services/dependiente.service';
import { TitularesService } from 'src/app/services/titulares.service';
import { ReporteCifrasControlService } from '../../services/cifrasControl/reporte-cifras-control.service';
import swal from 'sweetalert2';
import { GLOBAL } from '../../services/global';
import { DOCUMENT } from '@angular/common';
import { Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Sesion } from '../../services/sesion.service';
import { Bitacora } from '../../services/bitacora.service';
import { BeneficiarioService } from '../../services/beneficiario.service';
import { UserService } from '../../services/asistente/user.service';
import { buscaPlanesPerfilService } from '../../services/buscaPlanesPerfil.service';
import { parametrosAsegurado } from '../../models/parametrosAsegurado';
import { BitacoraService } from 'src/app/services/bitacora-navegacion/bitacora.service';
import { SelectItem } from 'primeng/api';

type Option = { key: string; value: string };
import readXlsxFile from 'read-excel-file';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { ExcelService } from 'src/app/services/excel.service';

declare var $;
@Component({
  selector: 'app-adminsolicitudes',
  templateUrl: './adminsolicitudes.component.html',
  styleUrls: ['./adminsolicitudes.component.css'],
  providers: [EmpresaComboService, DependienteService, Sesion, Bitacora],

})
export class AdminSolicitudesComponent implements OnInit {
  public solicitudValidada = true;
  public busquedaPor = '';
  public timeout;
  public NuevoFormato: any;
  public losDatosCotizador = true;
  public generoExcepcion = false;
  private anexos = false;
  public parametrosAseguradoT: parametrosAsegurado;
  public nombreSolicitud;
  public noSePuedeBorrarArchivoAun = false;
  public elArchivoTieneDatosCruzadosYSeBorro = false;
  public rutaPDFAnexo;
  public solicitud;
  public cotizadorv3;
  public parametro126;
  public system;
  public nombreArchivo;
  private consentimeinto = false;
  public idsegmentarplan: any;
  public solicitudes: any[] = [];
  public solicitudess;
  public valorBusqueda: string;
  public campoBusca = '';
  public loadEditar = true;
  public datosTabla = [null];
  public datosTitul = [null];
  public errorEntrada;
  public errorEntrada2;
  public tituloTabla = '';
  public titulares = 'Titulares';
  public title: string;
  public fullIdentity;
  public identity;
  public urlApi3;
  public ba;
  public api;
  public token;
  public urlApi;
  public wizard;
  public url;
  public urlWs;
  public status;
  public tabWindowId;
  public columnas;
  public columnasObj;
  public colVisibles;
  public colArreglo: any[] = [];
  public auxColumnas: any[] = [];
  public arregloColumnasVisibles: any[] = [];
  displayedColumns: string[] = ['Créditos', 'Descuentos', 'Excedentes', 'Fondo de ahorro', 'Costo coberturas', 'Sobrante créditos', 'Sobrante de excedentes', 'Descuento mensual nómina', 'Costo de coberturas anuales menos créditos anuales',
    'Descuento empleado anual antes de excedentes anuales'];


  public comboVigencias = [];
  public listaSolicitudes1 = [];
  public listaSolicitudesEnc = [];
  public listaSolicitudesVals = [];
  public parametroConfiguraColumna;
  public vigencia = 0;
  public comboEmpresas;

  public iconoAyuda;
  public textAyuda = 'Texto de ayuda Administración de Solicitudes.';
  public estatus = 'Por Autorizar';
  public tipoNotificacion;
  public cuerpoCorreo;

  public buscaArchivoFisicoParametro;
  public archivosFisicos;
  public validaPrefijo;
  public auxNombreCompleto;
  public quitarFirmas = false;
  public quitarSeleccionesAnteriores = false;
  public quitarResumenDescuento = false;

  public columnasVisibles;
  public objAux = {
    'ecIdCuentaConcepto': [],
    'ecOrden': [],
    'ecVisible': []
  };

  public auxAnexoSolicitud = {
    'anexoSolicitud': [],
  };

  public auxPlanSeleccion = {
    'planSeleccion': []
  };

  public btn1;
  public btn2;
  public btn3;
  public btn4;
  public btnI1;
  public btnI2;
  public btnI3;
  public btnI4;

  private banderaMail;
  private plantillaSend;
  private sujeto;
  private bodyHTML;
  public datosMail = [];

  public listaSolicitudes = [];
  public idEmpleado;
  public idEmpresa;
  public numEmpleado;
  public nomEmpleado = '';
  public idEmpre;

  public listaSolicitudesArr = [];

  public page = 1;
  public pageSize = 10;
  public collectionSize = 0;

  public opcionSeleccionada = '';
  public textoFiltro = '';

  public globalVigencia;
  public btn1Dis = false;

  public _url;
  public leyendaError = 'Solo letras*';
  public boolEnvia = false;
  public destinatarios = [];
  public correoAdmin = 'BeFlex@mx.lockton.com';
  /** ID bitácora para envío agrupado (tipoNotificacion == 2); se asigna en aceptar/rechazar/cancelar. */
  private idTipoNotificacionGrupo = 44;

  private readonly ID_NOTIF_SOL_AUTORIZACION = 40;
  private readonly ID_NOTIF_SOL_RECHAZO = 41;
  private readonly ID_NOTIF_SOL_CANCELACION = 42;
  private readonly ID_NOTIF_SOL_REACTIVACION = 43;
  private readonly ID_NOTIF_SOL_GRUPO_AUTORIZACION = 44;
  private readonly ID_NOTIF_SOL_GRUPO_RECHAZO = 45;
  private readonly ID_NOTIF_SOL_GRUPO_CANCELACION = 46;

  private idPagina = '402';
  private paginaActual;
  private ipPrivada;

  public mostrarDatosTabla = false;

  public consultaSinDatos = false;

  // ==================== PROPIEDADES REENVIO SOLICITUD ====================
  @ViewChild('fileInputReenvioMasivo') fileInputReenvioMasivo: ElementRef;
  public mostrarReenvioMasivo = false;
  public archivoReenvioMasivo: File = null;
  public registrosReenvioMasivo: any[] = [];
  public resultadosReenvioMasivo: any[] = [];
  public procesandoReenvioMasivo = false;
  public resumenReenvioMasivo = { total: 0, exitosos: 0, errores: 0 };
  // CREA25 INC-3: avance del lote asíncrono (para el polling / barra de progreso).
  public progresoReenvioMasivo = { procesados: 0, total: 0 };
  public descartadosReenvioMasivo: { fila: number; motivo: string }[] = [];

  public isActiveBtnCancelRequest = false;

  /* Variables de busqueda avanzada */

  // Objeto de errrores
  public errorRep = {
    empresas: false,
    perfiles: false,
    parametroBusqueda1: false,
    parametroBusqueda2: false,
    estatusSolicitudes: false
  };
  public validRep = {
    empresas: false,
    perfiles: false,
    parametroBusqueda1: false,
    parametroBusqueda2: false,
    estatusSolicitudes: false
  };
  public arbol = [];
  public empresasRegistradas: any[] = [];
  public seleccionArbol: any[] = [];
  public tipoOperadorLogico: Option[] = [
    {'key': 'and', 'value':' Y '},
    {'key': 'or', 'value':' O '}
  ];
  public atributoEmpleado: Option[] = [
    {'key': 'EMNumeroEmpleado', 'value':'Número de empleado'},
    {'key': 'EMNombre1', 'value':'Primer nombre'},
    {'key': 'EMNombre2', 'value':'Segundo nombre'},
    {'key': 'EMApellidoPaterno', 'value':'Apellido paterno'},
    {'key': 'EMApellidoMaterno', 'value':'Apellido materno'}
  ];
  public listaEstatus: SelectItem[] = [
    {'value': 'Por Autorizar', 'label':'Por Autorizar'},
    {'value': 'Autorizada', 'label':'Autorizada'},
    {'value': 'Rechazada', 'label':'Rechazada'},
    {'value': 'Cancelada', 'label':'Cancelada'}
  ]
  public tipoOperador: Option[] = [ 
    {'key': 'contiene', 'value':'Contiene'},
    {'key': 'igual', 'value':'Es igual a'},
    {'key': 'noigual', 'value':'No es igual a'}, // != o <>
    {'key': 'iniciapor', 'value':'Comienza por'},
    {'key': 'terminapor', 'value':'Termina con'},
    {'key': 'nocontiene', 'value':'No contiene'} // Not like
  ];
  public esBusquedaAvanzada: boolean = false;
  
  // Objeto de parametros seleccionados
  public parametrosBusqueda: IBusquedaRequest = {
    idEmpresas: [],
    perfiles: [],
    idAtributo1: 'EMNumeroEmpleado',
    idTipoOperador1: 'contiene',
    parametroBusqueda1: '',
    idTipoOperadorAvanzado: 'and',
    idAtributo2: 'EMNumeroEmpleado',
    idTipoOperador2: 'contiene',
    parametroBusqueda2: '',
    idEstatus: ['Por Autorizar'],
    idVigencia: 0,
    BusquedaAvanzada:0
  };

  // Variables reporte solicitud
  public empresas = [];
  public itemsEmpresas: SelectItem[] = []; // Seleccion multiple o todos
  public fechaInicioMin = '';
  public fechaInicioMax = '';
  public fechaFinMin = '';
  public fechaFinMax = '';
  public generoConsulta = false;
  // Formulario busqueda log
  public busqueda = {
    "idEmpresa": "",
    "fechaInicio": "",
    "fechaFin": "",
    "IdAdministrador": 0,
    "idVigencia": 0
  };

  public empresasSeleccionadasReportes = [];

  public tablaSolicitudes;
  public consultaReporteSinDatos = true;
  public mostrarDatosTablaReporte = false;
  public pageR = 1;
  public pageSizeR = 10;
  public collectionSizeR = 0;
  public datosR: any[] = [];

  // Variables modal reactivacion masiva

  public permitirCargaMasiva = false;
  public mostrarVistaPreviaCarga = false;
  public mensajesValidaciones = [];
  public ecabezadosDocumentoCarga = [];
  public filasDocumentoCarga = [];
  public inputFilePicker;

  // Formulario de consulta log
  public fechaFinMinLog = '';
  public fechaInicioMaxLog = '';
  public busquedaLog = {
    "idEmpresa": 0,
    "fechaInicio": "",
    "fechaFin": ""
  };
  public consultaLogSinDatos = false;
  public generoConsultaLog = false;
  public pageS = 1; // Terminacion S sin uso
  public pageSizeS = 10;
  public collectionSizeS = 0;
  public datosS: any[] = [];
  public mostrarDatosTablaLog = false;
  public tablaDocsReporte = [];

  public mostrarReactivacionMasiva = false;

  constructor(
    private _empleadoService: EmpleadoService,
    private _BuscarPlanesv2: buscaPlanesPerfilService,
    private userService: UserService,
    private _beneficiarioService: BeneficiarioService,
    private _titularesService: TitularesService,
    public _cifrasControlService: ReporteCifrasControlService,
    private _dependienteService: DependienteService,
    private _router: Router,
    private _empresaService: EmpresaComboService,
    title: Title,
    private _http: HttpClient,
    @Inject(DOCUMENT) private document: Document,
    private _sesion: Sesion,
    private _bitacora: Bitacora,
    public _BitacoraService: BitacoraService,
    public _excelService: ExcelService,
  ) {
    this.parametrosAseguradoT = new parametrosAsegurado('', '', '', '', '', '', '', '', '');
    this.api = GLOBAL.url3;
    this.urlApi3 = GLOBAL.url3;
    this.title = 'Titulares';
    this.wizard = GLOBAL.wizard;
    this.url = GLOBAL.url;
    this.urlApi = GLOBAL.url;
    this._url = GLOBAL.url;
    this.urlApi = GLOBAL.url;
    this.urlWs = GLOBAL.url2;
    title.setTitle('Beflex - Administracion de solicitudes');
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();

    this.errorRep.parametroBusqueda1 = false;
    this.errorRep.parametroBusqueda2 = false;

    if (this.identity) {
      this.identity.reseteo ? (!this.identity.cambio ? this._router.navigate(['/pages/home']) : this._router.navigate(['/pages/home'])) : null;
    }
    this.inicializarFormulario();
  }

  actualizarRuta() {
    this._router.navigate([this._router.url], { skipLocationChange: false });
  }

  async ngOnInit() {
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();
    try {
      await this._sesion.comprobarSession(this.token);
      if (this.identity) {
        if (localStorage.getItem('isAdmin') != null && localStorage.getItem('isAdmin') != undefined) {
          if (parseInt(localStorage.getItem('isAdmin')) == 1) {
            this.globalVigencia = localStorage.getItem('Idvigencia') ? parseInt(localStorage.getItem('Idvigencia')) : 0;
            try {
              const datos = await this._empleadoService.getDatos(this.identity);
              this.fullIdentity = datos;
            } catch (error) { }
            this.paginaActual = this.document.location.href;
            this.ipPrivada = localStorage.getItem('myIP') || '0.0.0.0';
            const parametroVitacora = {
              idPagina: this.idPagina,
              id: this.identity.id,
              ipPrivada: encodeURIComponent(this.ipPrivada),
              url: encodeURIComponent(this.paginaActual),
              idEmpresa: this.identity.idEmpresa,
              nombrePagina: 'adminsolicitudes.component.html'
            };
            try {
              await this._bitacora.registrarBitacora(parametroVitacora);
            } catch (error) { }
          } else {
            swal({
              title: '¡La sesión expiró!',
              html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
              type: 'error',
              confirmButtonText: 'Aceptar',
            });
            this.logout();
          }
        } else {
          swal({
            title: '¡La sesión expiró!',
            html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
            type: 'error',
            confirmButtonText: 'Aceptar',
          });
          this.logout();
        }
      }
    } catch (error) {
      if (error == 'Unauthorized') {
        swal({
          title: '¡La sesión expiró!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
    }
    if (!this.token) {
      this.logout();
    } else {
      this.getEncabezadoMail();
      this.getMailAdmin();
      await this.consultaEmpresasXadm();
      this.consultaVigencias();
      this.getColumnasEdoCuentaEmpresa();
      this.getParametroBusquedaAcciones();
      this.getParametroBusquedaAcciones2();
      this.getParametroBusquedaArchivosFisicos();
      await this.obtenerEmpresas();
      try {
        const emPrefijo: any = await this._empleadoService.obtenerPrefijoSolicitud(this._empleadoService.getIdentity().idEmpresa);
        this.validaPrefijo = emPrefijo.emPrefijoSolicitud;
      } catch (error) { }
      try {
        const response: any = await this._empleadoService.consultarParametroStatusLeyenda2(this.identity.idEmpresa, 202);
        if (response.paValor == 1) {
          this.quitarFirmas = true;
        }
      } catch (error) { }
      this.buscaAyuda();
      await this.proc_LeeParametro();
      await this.getGrupo();
      await this.getCorreoAdmin();
      try {
        this._empleadoService.consultarParametroStatusLeyenda2(this.identity.idEmpresa, 202).then((response: any) => {
          if (response.paValor == 1) {
            this.quitarFirmas = true;
          }
        }),
          this._empleadoService.consultarParametroStatusLeyenda2(this.identity.idEmpresa, 206).then((response: any) => {
            if (response.paValor == 1) {
              this.quitarSeleccionesAnteriores = true;
            }
          }),
          this._empleadoService.consultarParametroStatusLeyenda2(this.identity.idEmpresa, 228).then((response: any) => {
            if (response.paValor == 1) {
              this.quitarResumenDescuento = true;
            }
          });
      } catch (error) { }
      this.validteBtnCancelRequest();
    }
    this.inputFilePicker = (<HTMLInputElement>document.getElementById('input'));
  }

  logout() {
    localStorage.removeItem('identity');
    localStorage.clear();
    this.identity = null;
    this._router.navigate(['/nic/Admin']);
  }
  public async getParametroBusquedaAcciones() {
    try {
      const response = await this._titularesService.ocultaBtnSolicitudes(this.identity.idEmpresa, this.identity.idRol);
      this.btn1 = true;
      this.btn2 = true;
      this.btn3 = true;
      this.btn4 = true;
      this.btnI1 = true;
      this.btnI2 = true;
      this.btnI3 = true;
      this.btnI4 = true;
      const response1 = response != null ? Object.values(response) : '';
      for (let i = 0; i < response1.length; i++) {
        const lis = response1[i][0];
        const oculta = lis['RBOculta'].split(',');
        for (const para of oculta) {
          switch (para) {
            case 'Aceptar':
              this.btn1 = false;
              this.btnI1 = false;
              break;
            case 'Rechazar':
              this.btn2 = false;
              this.btnI2 = false;
              break;
            case 'Cancelar':
              this.btn3 = false;
              this.btnI3 = false;
              break;
            case 'Reactivar':
              this.btn4 = false;
              this.btnI4 = false;
              break;
          }
        }
      }
    } catch (error) {
      this.btn1 = true;
      this.btn2 = true;
      this.btn3 = true;
      this.btn4 = true;
      this.btnI1 = true;
      this.btnI2 = true;
      this.btnI3 = true;
      this.btnI4 = true;
    }
  }

  public async getParametroBusquedaAcciones2() {
    try {
      const response = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idCorporativo, '231');
      if (response['paValor'] == 'Solicitud') {
        this.tipoNotificacion = 1;
      } else {
        this.tipoNotificacion = 2;
      }
    } catch (error) {
      this.tipoNotificacion = 1;
    }
  }

  cambiaEstatus() {
    this.estatus = (<HTMLInputElement>document.getElementById('selectEstatus')).value;
  }

  async consultaEmpresasXadm() {
    this.empresas = [];
    if (this.identity.idCorporativo != undefined) {
      try {
        const response: any = await this._empresaService.getComboCambioEmpresa(this.identity.idCorporativo, this.identity.id, this.token);
        const emp = [];
        if (response.length > 1) {
          const inicio = { 'IdEmpresa': this.identity.idCorporativo, 'NomEmpresa': 'Todas' };
          emp.push(inicio);
        }
        for (const em of response) {
          if (em.IdEmpresa == this.identity.idEmpresa) {
            emp.push(em);
            break;
          }
        }
        for (const em of response) {
          if (em.IdEmpresa != this.identity.idEmpresa) {
            emp.push(em);
          }
        }
        this.comboEmpresas = emp;
        this.empresas = response;
      } catch (error) { }
    } else {
      try {
        const response = await this._empresaService.getInfoEmpresa(this.identity.idEmpresa);
        const idCorporativo = response['EMidCorporativo'];
        try {
          const response: any = await this._empresaService.getComboCambioEmpresa(this.identity.idCorporativo, this.identity.id, this.token);
          const emp = [];
          if (response.length > 1) {
            const inicio = { 'IdEmpresa': this.identity.idCorporativo, 'NomEmpresa': 'Todas' };
            emp.push(inicio);
          }
          for (const em of response) {
            if (em.IdEmpresa == this.identity.idEmpresa) {
              emp.push(em);
              break;
            }
          }
          for (const em of response) {
            if (em.IdEmpresa != this.identity.idEmpresa) {
              emp.push(em);
            }
          }
          this.comboEmpresas = emp;
          this.empresas = response;
        } catch (error) { }
      } catch (error) { }
    }
  }

  public async consultaVigencias() {
    try {
      const response = await this._cifrasControlService.getConsultaVigenciasXEmpresa(this.identity.idEmpresa);
      this.comboVigencias = response[0];
      if (this.vigencia == 0) {
        if (this.globalVigencia == 0) {
          this.vigencia = this.comboVigencias[0].VIidVigencia;
        } else {
          this.vigencia = this.globalVigencia;
        }
      }
    } catch (error) { }
  }

  public async validaVigencia(vigencia: any) {
    try {
      const response = await this._cifrasControlService.getConsultaVigenciasXId(vigencia);
      const vigen = response[0][0]['VIVigenciaFin'];
      const fechaHoy = new Date();
      const fechaVig = new Date(vigen);
      if (fechaVig < fechaHoy) {
        this.btn1 = false;
        this.btn2 = false;
        this.btn3 = false;
      } else {
        if (this.btnI1) {
          this.btn1 = true;
        }
        if (this.btnI2) {
          this.btn2 = true;
        }
        if (this.btnI3) {
          this.btn3 = true;
        }
      }
    } catch (error) { }
  }

  verificaVigencia() {
    this.btn1Dis = false;
    const vig = (<HTMLInputElement>document.getElementById('selectVigencia')).value;
    this.listaSolicitudes = [];
    this.collectionSize = 0;
    this.validaVigencia(vig);
    this.vigencia = parseInt(vig, 10);
    this.consultaSolicitudesAvanzado(2);
  }

  public async consultaSolicitudesAvanzado(num: any) {
    this.btn1Dis = false;
    this.loadEditar = false;
    this.listaSolicitudesVals = [];
    this.listaSolicitudesEnc = [];
    this.listaSolicitudes1 = [];
    this.mostrarDatosTabla = true;
    this.consultaSinDatos = false;
    this.parametrosBusqueda.idVigencia = this.vigencia;

    if(this.parametrosBusqueda.idEmpresas.length === 0 || this.parametrosBusqueda.idEstatus.length === 0) {
      swal({
        title: '¡Alto!',
        html: 'Selecciona al menos una empresa y estatus de solicitud.',
        type: 'error',
        confirmButtonText: 'Aceptar',
        showConfirmButton: true,
        onOpen: () => {
          swal.hideLoading();
        }
      });
      this.loadEditar = true
      return;
    }
    const parametros = {
      'idEmpresas' : this.parametrosBusqueda.idEmpresas.join(',')
      ,'perfiles' : this.parametrosBusqueda.perfiles.join(',')
      ,'idAtributo1' : this.parametrosBusqueda.idAtributo1
      ,'idTipoOperador1' : this.parametrosBusqueda.idTipoOperador1
      ,'parametroBusqueda1' : this.parametrosBusqueda.parametroBusqueda1
      ,'BusquedaAvanzada' : this.esBusquedaAvanzada ? 1 : 0
      ,'idTipoOperadorAvanzado' : this.parametrosBusqueda.idTipoOperadorAvanzado
      ,'idAtributo2' : this.parametrosBusqueda.idAtributo2
      ,'idTipoOperador2' : this.parametrosBusqueda.idTipoOperador2
      ,'parametroBusqueda2' : this.parametrosBusqueda.parametroBusqueda2
      ,'idEstatus' : this.parametrosBusqueda.idEstatus.join(',')
      ,'idVigencia' : this.parametrosBusqueda.idVigencia
      ,'IdAdministrador': this.identity.id
    }
      try {
        const response = await this._cifrasControlService.busquedaAvanzadaSolicitud(parametros, this.token);
        if(response != null){
          // this.listaSolicitudes1 = response[2];
          this.listaSolicitudesArr = [...response]; // Llenar con resultado de solicitudes
          // for (let i = 0; i < response.length; i++) {
          //   if (typeof (response[i]) === 'object') {
          //     for (const row of response[i]) {
          //       this.listaSolicitudesArr.push(row);
          //     }
          //   }
          // }
          this.filtraPor(response);
        }else{
          this.consultaSinDatos = true;
          this.loadEditar = true;
        }
      } catch (error) {
        this.loadEditar = true;
      }
  }

  public async consultaSolicitudes(num: any) {
    this.btn1Dis = false;
    this.loadEditar = false;
    this.listaSolicitudesVals = [];
    this.listaSolicitudesEnc = [];
    this.listaSolicitudes1 = [];
    this.mostrarDatosTabla = true;
    this.consultaSinDatos = false;
    let emp = (<HTMLInputElement>document.getElementById('selectEmpresa')).value;
    if (emp == this.identity.idCorporativo) {
      emp = '';
      this.idEmpre = true;
      for (const empresa of this.comboEmpresas) {
        if (empresa.IdEmpresa != this.identity.idCorporativo) {
          emp += empresa.IdEmpresa + ',';
        }
      }
      emp = emp.substring(0, emp.length - 1);
    } else {
      this.idEmpre = false;
    }
    const tipoBusqueda = (<HTMLInputElement>document.getElementById('busqueda')).value;
    const valorBusqueda = (<HTMLInputElement>document.getElementById('inputBuscar')).value;
    if (valorBusqueda != '' && tipoBusqueda == '') {
      swal({
        title: '¡Alto!',
        html: 'Ingresa un tipo de busqueda',
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
      });
      this.loadEditar = true;
    } else {
      if (num == 1) {
        try {
          const response = await this._cifrasControlService.getConsultaSolicitudes2(emp, this.vigencia, this.identity.id);
          this.filtraPor(response);
          this.mostrarDatosTabla = true;
        } catch (error) {
          this.loadEditar = true;
        }
      } else {
        try {
          const response = await this._cifrasControlService.getConsultaSolicitudes(emp, this.vigencia, this.identity.id, tipoBusqueda, valorBusqueda);
          this.listaSolicitudes1 = response[2];
          this.listaSolicitudesArr = [];
          for (let i = 0; i < response.length; i++) {
            if (typeof (response[i]) === 'object') {
              for (const row of response[i]) {
                this.listaSolicitudesArr.push(row);
              }
            }
          }
          this.filtraPor(response);
        } catch (error) {
          this.loadEditar = true;
        }
      }
    }
  }

  async filtraPor(res: any) {
    this.listaSolicitudes1 = [];
    this.collectionSize = 0;

    // Poblar tabla de solicitudes
    for(const row of res){
      const solicitudes = [];
      // Llenar propiedades de la solicitud
      solicitudes.push('sel');
      solicitudes.push('imp');
      solicitudes.push(row['Empresa']);
      // Obtener nombre de empresa
      let nomEmp = '';
      for (const empresa of this.comboEmpresas) {
        if (empresa.IdEmpresa == row['Empresa']) {
          nomEmp = empresa.NomEmpresa;
          break;
        }
      }
      solicitudes.push(nomEmp);
      solicitudes.push(row['NumEmpleado']);
      const nombre = row['EMApellidoPaterno'] + ' ' + row['EMApellidoMaterno'] + ' ' + row['EMNombre1'] + ' ' + row['EMNombre2'];
      solicitudes.push(nombre);
      solicitudes.push(row['SONumeroSolicitud']);
      solicitudes.push(this.fecha2(row['SOFechaAdd']));
      solicitudes.push(row['SODetalleEstatus']);
      solicitudes.push(row['1']);
      solicitudes.push(row['6']);
      solicitudes.push(row['5']);
      solicitudes.push(row['nomina']);
      solicitudes.push(row['Anual']);
      solicitudes.push(this.fecha2(row['SOFechaEstatus']));
      solicitudes.push(row['SOUsuarioUMod']);
      this.listaSolicitudes1.push(row);
      this.listaSolicitudesVals.push(solicitudes);
      this.listaSolicitudesEnc.push(row);
    }
    this.loadEditar = true;
    this.collectionSize = this.listaSolicitudes1.length;
    this.consultaSinDatos = this.collectionSize == 0 ? true : false;
  }

  fecha2(fecha1: any) {

    if (fecha1 == null) {
      return '';
    }

    const fecha = new Date(fecha1);
    const y = fecha.getFullYear();
    let m = fecha.getMonth();
    const d = fecha.getDate();
    m = m + 1;
    let mes;
    let dia;
    if (m < 10) {
      mes = '0' + m;
    } else {
      mes = m;
    }
    if (d < 10) {
      dia = '0' + d;
    } else {
      dia = d;
    }
    const fechaactual = dia + '-' + mes + '-' + y;
    return fechaactual;
  }
  fecha() {
    const fecha = new Date();
    const y = fecha.getFullYear();
    let m = fecha.getMonth();
    const d = fecha.getDate();
    m = m + 1;
    let mes;
    let dia;
    if (m < 10) {
      mes = '0' + m;
    } else {
      mes = m;
    }
    if (d < 10) {
      dia = '0' + d;
    } else {
      dia = d;
    }
    const fechaactual = dia + '-' + mes + '-' + y;
    return fechaactual;
  }

  /*******************    PARA LA IMPRESION DE LA SOLICITUD   ********************/
  async imprimirSolicitud(index: any) {
    const sol = this.listaSolicitudesEnc[index]['SOIdSolicitud'];
    const soEstatusSolicitud = this.listaSolicitudesEnc[index]['SOEstatusSolicitud'];
    const soIdEstatus = this.listaSolicitudesEnc[index]['SOIdEstatus'];
    this.generoExcepcion = false;
    this.noSePuedeBorrarArchivoAun = false;
    let validarSolicitud = await this.validarErrorTimerSolicitud(sol, 2);
    this.idEmpresa = this.listaSolicitudesEnc[index]['Empresa'];
    this.idEmpleado = this.listaSolicitudesEnc[index]['SOUsuarioAdd'];
    //if (validarSolicitud) {
    //  await this.obtenerRutasBorrar(this.idEmpleado, sol, "");
    //}

    if (this.noSePuedeBorrarArchivoAun) {
      swal({
        title: '¡No es posible procesar tu solicitud en este momento!',
        html: '<small style="color: grey; text-align: justify;">No es posible procesar tu solicitud en este momento debido a un tiempo de espera agotado. Por favor, inténtalo nuevamente más tarde.</small>',
        type: 'info',
        confirmButtonText: 'Aceptar',
      });
      this.actualizarRuta();
    } else {
      this.traerDatosImp(this.listaSolicitudesEnc[index]['NumEmpleado'], this.listaSolicitudesEnc[index]['Empresa'], sol, soEstatusSolicitud, soIdEstatus);
    }
  }

  public async getParametroBusquedaArchivosFisicos() {
    try {
      const response = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idCorporativo, '103');
      this.buscaArchivoFisicoParametro = response['paValor'];
    } catch (error) { }
  }

  async getDocumento(soIdSolicitud, emPrefijo, params: any, soEstatusSolicitud, soIdEstatus) {
    console.clear();
    var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "");
    var d = new Date();
    var hhmmss = d.toTimeString().slice(0,8).replace(/:/g,"");
    this.generoExcepcion = false;
    this.noSePuedeBorrarArchivoAun = false;
    const vIdEmpleado = params;
    const vIdEmpresa = this.idEmpresa;
    if (this.buscaArchivoFisicoParametro != 1) {
      this.system = localStorage.getItem('systemRead');
      swal({
        title: 'Espere un momento...',
        html: '',
        allowOutsideClick: false,
        onOpen: async (r) => {
          swal.showLoading();
          if ((soEstatusSolicitud === 3 || soEstatusSolicitud === 1) && soIdEstatus === 1) {
            await this.limitedPromise(this.getSolicitudXML(soIdSolicitud, `Solicitud_${vIdEmpleado}_${YYYYMMDD}${hhmmss}_${soIdSolicitud}.pdf`, `DocumentoEmpresa/${vIdEmpresa}/Solicitud/`, emPrefijo, params), 2.5 * 60 * 1000)
              .then(async result => {
                console.log('Promesa completada dentro del límite de tiempo: ', result);
              })
              .catch(async error => {
                console.error('Error: ', error);
                this.generoExcepcion = true;
                await this.validarErrorTimerSolicitud(this.solicitudess, 1);
                await this.obtenerRutasBorrar(this.idEmpleado, this.solicitudess, "");
                swal({
                  title: '¡Intenta más tarde por favor!',
                  html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta más tarde.</small>',
                  type: 'info',
                  confirmButtonText: 'Aceptar',
                });
                this.actualizarRuta();
              });
          } else {
            await this.limitedPromise(this.getSolicitudXML2(soIdSolicitud, `Solicitud_${vIdEmpleado}_${YYYYMMDD}${hhmmss}_${soIdSolicitud}.pdf`, `DocumentoEmpresa/${vIdEmpresa}/Solicitud/`, emPrefijo), 2.5 * 60 * 1000)
              .then(async result => {
                console.log('Promesa completada dentro del límite de tiempo: ', result);
              })
              .catch(async error => {
                console.error('Error: ', error);
                this.generoExcepcion = true;
                await this.validarErrorTimerSolicitud(this.solicitudess, 1);
                await this.obtenerRutasBorrar(this.idEmpleado, this.solicitudess, "");
                swal({
                  title: '¡Intenta más tarde por favor!',
                  html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta más tarde.</small>',
                  type: 'info',
                  confirmButtonText: 'Aceptar',
                });
                this.actualizarRuta();
              });
            ;
          }
        }
      });
    } else {
      swal({
        title: 'Espere un momento...',
        html: '',
        allowOutsideClick: false,
        onOpen: () => {
          swal.showLoading();
          this.obtenerRutas(vIdEmpleado, soEstatusSolicitud, soIdEstatus, soIdSolicitud, emPrefijo, params);
        }
      });
    }
  }

  async obtenerRutas(vIdEmpleado, soEstatusSolicitud, soIdEstatus, soIdSolicitud, emPrefijo, params) {
    console.log("obtenerRutas");
    var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "");
    var d = new Date();
    var hhmmss = d.toTimeString().slice(0,8).replace(/:/g,"");
    const settings = {
      'async': true,
      'crossDomain': true,
      'url': this.urlApi + 'file/empleado/find?idEmpresa=' + this.idEmpresa + '&idSolicitud=' + soIdSolicitud + '&idEmpleado=' + vIdEmpleado,
      'method': 'GET',
      'headers': {
        'cache-control': 'no-cache',
      }
    };
    $.ajax(settings).done(async (response) => {
      this.recuperarSolicitudConAnexo(response, vIdEmpleado, soIdSolicitud);
    }).fail(async (error) => {
      const errorMessage = <any>error;
      if ((soEstatusSolicitud === 3 || soEstatusSolicitud === 1) && soIdEstatus === 1) {
        await this.limitedPromise(this.getSolicitudXML(soIdSolicitud, `Solicitud_${vIdEmpleado}_${YYYYMMDD}${hhmmss}_${soIdSolicitud}.pdf`, `DocumentoEmpresa/${this.idEmpresa}/Solicitud/`, emPrefijo, params), 2.5 * 60 * 1000)
          .then(async result => {
            console.log('Promesa completada dentro del límite de tiempo: ', result);
          })
          .catch(async error => {
            console.error('Error: ', error);
            this.generoExcepcion = true;
            await this.validarErrorTimerSolicitud(this.solicitudess, 1);
            await this.obtenerRutasBorrar(this.idEmpleado, this.solicitudess, "");
            swal({
              title: '¡Intenta más tarde por favor!',
              html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta más tarde.</small>',
              type: 'info',
              confirmButtonText: 'Aceptar',
            });
            this.actualizarRuta();
          });

      } else {
        await this.limitedPromise(this.getSolicitudXML2(soIdSolicitud, `Solicitud_${vIdEmpleado}_${YYYYMMDD}${hhmmss}_${soIdSolicitud}.pdf`, `DocumentoEmpresa/${this.idEmpresa}/Solicitud/`, emPrefijo), 2.5 * 60 * 1000)
          .then(async result => {
            console.log('Promesa completada dentro del límite de tiempo: ', result);
          })
          .catch(async error => {
            console.error('Error: ', error);
            this.generoExcepcion = true;
            await this.validarErrorTimerSolicitud(this.solicitudess, 1);
            await this.obtenerRutasBorrar(this.idEmpleado, this.solicitudess, "");
            swal({
              title: '¡Intenta más tarde por favor!',
              html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta más tarde.</small>',
              type: 'info',
              confirmButtonText: 'Aceptar',
            });
            this.actualizarRuta();
          });
      }
    });
  }

  public async recuperarSolicitudConAnexo(ruta, idEmpleado, idSolicitud) {
    try {
      const result: any = await this._empleadoService.obtenerVariablesSistema();
      const ls = result.upload_FOLDER.toString();
      ruta = ruta.replace(ls, '');
      ruta = ruta.replace(/\\/g, '/');
      const nombreArchivo = `Solicitud_${idEmpleado}_${idSolicitud}.pdf`;
      const settings = {
        'async': true,
        'crossDomain': true,
        'url': `${this.urlApi}file/get-document?ruta=${ruta}`,
        'method': 'GET',
        'headers': {},
        xhrFields: {
          responseType: 'blob'
        },
      };
      $.ajax(settings).done(async (response) => {
        const validaPDF = await this.validarLecutraPDF(idEmpleado, idSolicitud, null);
        if (!this.generoExcepcion && !this.elArchivoTieneDatosCruzadosYSeBorro) {
          this.validarErrorTimerSolicitud(this.solicitudess, 3);
          const blob = new Blob([response], { type: 'application/pdf' });
          const link = document.createElement('a');  // Crear un a=> href
          link.href = window.URL.createObjectURL(blob);
          link.download = `${nombreArchivo}`;
          link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
          setTimeout(function () {
            window.URL.revokeObjectURL(window.URL.createObjectURL(blob));
          }, 100);
          swal({
            title: '¡Listo!',
            type: 'success',
            confirmButtonText: 'Aceptar',
          });
        } else {
          swal({
            title: '¡Intenta mas tarde por favor!',
            html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta mas tarde.</small>',
            type: 'info',
            confirmButtonText: 'Aceptar',
          });
        }
      }).fail((error) => {
        swal({
          title: '¡Error!',
          html: '<small style="color: grey; text-align: justify;">Ha ocurrido un problema al encontrar la solicitud.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
      });
    } catch (error) { }
  }

  async getSolicitudXML(soIdSolicitud: string, nombreArchivo: string, ruta: string, emPrefijoSolicitud: any, params: any) {
   
    console.log("emPrefijoSolicitud", emPrefijoSolicitud);
    this.nombreSolicitud = nombreArchivo;
    this.solicitudess = soIdSolicitud;
    await this.obtenerAnexosPlanesVida();

    if (this.idEmpresa != 369) {
      //Crear solicitud cualquier empresa
      await this.limpiarAnexos();
      await this.createSolicitud2(null, 2);
      await this.recorrerAnexos();

      const settings = {
        async: true,
        crossDomain: true,
        url: `${this.urlApi}file/get-document?ruta=${ruta + this.nombreArchivo}`,
        method: 'GET',
        headers: {},
        xhrFields: {
          responseType: 'blob'
        },
      };

      await $.ajax(settings).done(async (response) => {
        if (this.solicitud != null) {
          await this.obtenerRutasV2(this.idEmpleado, soIdSolicitud, emPrefijoSolicitud);
        } else {
          const validaPDF = await this.validarLecutraPDF(this.idEmpleado, soIdSolicitud, null);
          if (!this.generoExcepcion && !this.elArchivoTieneDatosCruzadosYSeBorro) {
            this.validarErrorTimerSolicitud(this.solicitudess, 3);
            const out = new Blob([response], { type: 'application/pdf' });
            if (this.system === 'iOS') {
              this.solicitud;
              const url2 = URL.createObjectURL(out);
              this.tabWindowId.location.href = url2;
            } else {
              this.solicitud;
              const FileSaver = require('file-saver');
              const url = window.URL.createObjectURL(out);
              FileSaver.saveAs(url, this.nombreArchivo);
            }
            swal({
              title: '¡Listo!',
              type: 'success',
              confirmButtonText: 'Aceptar',
            });
          } else {
            swal({
              title: '¡Intenta mas tarde por favor!',
              html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta mas tarde.</small>',
              type: 'info',
              confirmButtonText: 'Aceptar',
            });
          }
        }
      }).fail(async (error) => {
        await this.obtenerRutasBorrar(this.idEmpleado, this.solicitudess, "");
        swal({
          title: 'Intenta más tarde',
          html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta más tarde.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
      });
    } else {
      //Crear solicitud para SMNYL
      await this.limpiarAnexos();
      await this.createSolicitud(null, 2);
      await this.recorrerAnexos();

      const settings = {
        async: true,
        crossDomain: true,
        url: `${this.urlApi}file/get-document?ruta=${ruta + this.nombreArchivo}`,
        method: 'GET',
        headers: {},
        xhrFields: {
          responseType: 'blob'
        },
      };

      await $.ajax(settings).done(async (response) => {
        if (this.solicitud != null) {
          await this.obtenerRutasV2(this.idEmpleado, soIdSolicitud, emPrefijoSolicitud);
        } else {
          const validaPDF = await this.validarLecutraPDF(this.idEmpleado, soIdSolicitud, null);
          if (!this.generoExcepcion && !this.elArchivoTieneDatosCruzadosYSeBorro) {
            this.validarErrorTimerSolicitud(this.solicitudess, 3);
            const out = new Blob([response], { type: 'application/pdf' });
            if (this.system === 'iOS') {
              this.solicitud;
              const url2 = URL.createObjectURL(out);
              this.tabWindowId.location.href = url2;
            } else {
              this.solicitud;
              const FileSaver = require('file-saver');
              const url = window.URL.createObjectURL(out);
              FileSaver.saveAs(url, this.nombreArchivo);
            }
            swal({
              title: '¡Listo!',
              type: 'success',
              confirmButtonText: 'Aceptar',
            });
          } else {
            swal({
              title: '¡Intenta mas tarde por favor!',
              html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta mas tarde.</small>',
              type: 'info',
              confirmButtonText: 'Aceptar',
            });
          }
        }
      }).fail(async (error) => {
        await this.obtenerRutasBorrar(this.idEmpleado, this.solicitudess, "");
        swal({
          title: 'Intenta más tarde',
          html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta más tarde.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
      });

    }
  }

  async getSolicitudXML2(soIdSolicitud: string, nombreArchivo: string, ruta: string, emPrefijoSolicitud) {
    // emPrefijoSolicitud =5;
    if (emPrefijoSolicitud === 4) {
      const settings = {
        async: true,
        crossDomain: true,
        url: this.urlApi + `solicitud/${soIdSolicitud}/xml/b3/sm`,
        method: 'GET',
        processData: false,
        dataType: 'text'
      };

      $.ajax(settings).done(async (response) => {
        let strResponse = response;

        strResponse = strResponse.replace('</item>', '<preview>false</preview></item>');
        if (this.quitarFirmas) {
          strResponse = strResponse.replace('</item>', '<firmas>true</firmas></item>');
        } else {
          strResponse = strResponse.replace('</item>', '<firmas>false</firmas></item>');
        }
        if (this.quitarSeleccionesAnteriores) {
          strResponse = strResponse.replace('</item>', '<seleccionesanteriores>true</seleccionesanteriores></item>');
        } else {
          strResponse = strResponse.replace('</item>', '<seleccionesanteriores>false</seleccionesanteriores></item>');
        }


        try {
          const resp = await this._empleadoService.convertirPdf(strResponse, ruta, nombreArchivo, emPrefijoSolicitud, this._empleadoService.getToken());
          const settings = {
            async: true,
            crossDomain: true,
            url: `${this.urlApi}file/get-document?ruta=${ruta + nombreArchivo}`,
            method: 'GET',
            headers: {},
            xhrFields: {
              responseType: 'blob'
            },
          };

          $.ajax(settings).done(async (response) => {
            const validaPDF = await this.validarLecutraPDF(this.idEmpleado, soIdSolicitud, null);
            if (!this.generoExcepcion && !this.elArchivoTieneDatosCruzadosYSeBorro) {
              this.validarErrorTimerSolicitud(this.solicitudess, 3);
              const out = new Blob([response], { type: 'application/pdf' });
              if (this.system === 'iOS') {
                const url2 = URL.createObjectURL(out);
                this.tabWindowId.location.href = url2;
              } else {
                const FileSaver = require('file-saver');
                const url = window.URL.createObjectURL(out);
                FileSaver.saveAs(url, nombreArchivo);
              }
              swal({
                title: '¡Listo!',
                type: 'success',
                confirmButtonText: 'Aceptar',
              });
            } else {
              swal({
                title: '¡Intenta mas tarde por favor!',
                html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta mas tarde.</small>',
                type: 'info',
                confirmButtonText: 'Aceptar',
              });
            }
          }).fail((error) => {
            swal({
              title: '¡Error!',
              html: '<small style="color: grey; text-align: justify;">Ha ocurrido un problema al intentar generar la solicitud.</small>',
              type: 'error',
              confirmButtonText: 'Aceptar',
            });
          });
        } catch (error) {
          swal({
            title: '¡Error!',
            html: '<small style="color: grey; text-align: justify;">Ha ocurrido un problema al extraer el archivo XML de la solicitud.</small>',
            type: 'error',
            confirmButtonText: 'Aceptar',
          });
        }
      }, error => {
        console.log("error solicitud");
      });

    } else {
      try {
        const response = await this._empleadoService.generarSolicitudXid(soIdSolicitud);
        let strResponse = response;
        strResponse = strResponse.replace('</item>', '<preview>false</preview></item>');
        if (this.quitarFirmas) {
          strResponse = strResponse.replace('</item>', '<firmas>true</firmas></item>');
        } else {
          strResponse = strResponse.replace('</item>', '<firmas>false</firmas></item>');
        }

        if (this.quitarSeleccionesAnteriores) {
          strResponse = strResponse.replace('</item>', '<seleccionesanteriores>true</seleccionesanteriores></item>');
        } else {
          strResponse = strResponse.replace('</item>', '<seleccionesanteriores>false</seleccionesanteriores></item>');
        }

        if (emPrefijoSolicitud == 5) {
          if (this.quitarResumenDescuento) {
            strResponse = strResponse.replace('</item>', '<descuentos>true</descuentos></item>');
          } else {
            strResponse = strResponse.replace('</item>', '<descuentos>false</descuentos></item>');
          }
        }

        await this._empleadoService.convertirPdf(strResponse, ruta, nombreArchivo, emPrefijoSolicitud, this._empleadoService.getToken());
        const settings = {
          async: true,
          crossDomain: true,
          url: `${this.urlApi}file/get-document?ruta=${ruta + nombreArchivo}`,
          method: 'GET',
          headers: {},
          xhrFields: {
            responseType: 'blob'
          },
        };

        $.ajax(settings).done(async (response) => {
          const validaPDF = await this.validarLecutraPDF(this.idEmpleado, soIdSolicitud, null);
          if (!this.generoExcepcion && !this.elArchivoTieneDatosCruzadosYSeBorro) {
            this.validarErrorTimerSolicitud(this.solicitudess, 3);
            const out = new Blob([response], { type: 'application/pdf' });
            if (this.system === 'iOS') {
              const url2 = URL.createObjectURL(out);
              this.tabWindowId.location.href = url2;
            } else {
              const FileSaver = require('file-saver');
              const url = window.URL.createObjectURL(out);
              FileSaver.saveAs(url, nombreArchivo);
            }
            swal({
              title: '¡Listo!',
              type: 'success',
              confirmButtonText: 'Aceptar',
            });
          } else {
            swal({
              title: '¡Intenta mas tarde por favor!',
              html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta mas tarde.</small>',
              type: 'info',
              confirmButtonText: 'Aceptar',
            });
          }
        }).fail((error) => {
          swal({
            title: '¡Error!',
            html: '<small style="color: grey; text-align: justify;">Ha ocurrido un problema al intentar generar la solicitud.</small>',
            type: 'error',
            confirmButtonText: 'Aceptar',
          });
        });
      } catch (error) {
        swal({
          title: '¡Error!',
          html: '<small style="color: grey; text-align: justify;">Ha ocurrido un problema al extraer el archivo XML de la solicitud.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
      }
    }
  }
  /***********************  texto ayuda   ********************************/
  buscaAyuda() {
    const getHeaders: HttpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'cache-control': 'no-cache'
    });
    this._http
      .get(this._url + 'ayuda/menu/564', { headers: getHeaders })
      .subscribe(
        response => {
          const pagina = response;
          this._http.get(
            this._url +
            'ayuda/empresa/' +
            this.identity.idEmpresa +
            '/pagina?pagina=' +
            pagina['paNombreArchivo'],
            { headers: getHeaders }
          )
            .subscribe(
              response => {
                this.iconoAyuda = 1;
                const textoayuda = response;
                this.textAyuda = textoayuda[0].paTextoAyuda;

              }
            );
        }
      );
  }

  /****************     Selecciones de solicitudes    *****************/
  SeleccionSolicitudT() {
    this.listaSolicitudes = [];
    let bandera = false;
    for (let j = 0; j < this.listaSolicitudesEnc.length; j++) {
      const nom1 = 'radio' + j;
      const r1 = (<HTMLInputElement>document.getElementById(nom1));
      if (r1 != null) {
        if (r1.checked == true) {
          bandera = true;
          break;
        }
      }
    }
    if (!bandera) {
      for (let i = 0; i < this.listaSolicitudesEnc.length; i++) {
        const nom = 'radio' + i;
        const r = (<HTMLInputElement>document.getElementById(nom));
        if (r != undefined || r != null) {
          const sol = this.listaSolicitudesEnc[i]['SOIdSolicitud'];
          this.listaSolicitudes.push(sol);
          r.checked = true;
        }
      }
    } else {
      for (let i = 0; i < this.listaSolicitudesEnc.length; i++) {
        const nom = 'radio' + i;
        const r = (<HTMLInputElement>document.getElementById(nom));
        if (r != undefined || r != null) {
          r.checked = false;
        }
      }
      this.listaSolicitudes = [];
      const r3 = (<HTMLInputElement>document.getElementById('todos')).checked = false;
    }
  }
  SeleccionSolicitud(index: any) {
    let ban = false;
    const sol = this.listaSolicitudesEnc[index]['SOIdSolicitud'];
    for (const sol1 of this.listaSolicitudes) {
      if (sol1 == sol) {
        ban = true;
        break;
      }
    }
    const nomR = 'radio' + index;
    const radio = (<HTMLInputElement>document.getElementById(nomR));
    const detalleestatus = this.listaSolicitudesEnc[index]['SODetalleEstatus'];
    if (this.estatus == 'Todas') {
      if (radio.checked == true && detalleestatus == 'Autorizada') {
        if (this.btnI1) {
          this.btn1Dis = true;
        }
      } else {
        if (this.btnI1) {
          this.btn1Dis = false;
        }
      }
    }
    if (radio.checked == true && ban == false) {
      this.listaSolicitudes.push(sol);
    } else {
      const aux = [];
      for (const sol1 of this.listaSolicitudes) {
        if (sol1 != sol) {
          aux.push(sol1);
        }
      }
      this.listaSolicitudes = aux;
      radio.checked = false;
    }
    this.btn1Dis = true;
    for (const idn of this.listaSolicitudes) {
      for (let i = 0; i < this.listaSolicitudesEnc.length; i++) {
        if (this.listaSolicitudesEnc[i]['SOIdSolicitud'] == idn) {
          const detalleestatusAux = this.listaSolicitudesEnc[i]['SODetalleEstatus'];
          if (detalleestatusAux == 'Por Autorizar') {
            this.btn1Dis = false;
          }
          break;
        }
      }
    }
  }

  /****************     Cambia estatus de Solicitud   *****************/
  async reactivarSolicitud(index: any) {
    this.numEmpleado = this.listaSolicitudesEnc[index]['NumEmpleado'];
    this.idEmpresa = this.listaSolicitudesEnc[index]['Empresa'];
    const idEmp = await this.traerDatos(this.listaSolicitudesEnc[index]['NumEmpleado'], this.listaSolicitudesEnc[index]['Empresa']);
    if (idEmp != 0) {
      const titulo = '¡Espera!';
      const cadena = '¿Deseas reactivar la solicitud?';
      swal({
        title: titulo,
        html: cadena,
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false   // <-Este es para que no permita dar click fuera del swal
      }).then((result) => {
        if (result.value) {
          const sol = this.listaSolicitudesEnc[index]['SOIdSolicitud'];
          const resultado = this.reactivarSol(idEmp, sol);
          this.verificaVigencia();
        }
      });
    } else {
      swal({
        title: '¡Error!',
        html: this.listaSolicitudesEnc[index]['NumEmpleado'] + ' está dado de baja',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  async aceptaSolicitud() {
    const idS = this.listaSolicitudes[0];
    let estat = '';
    const listaAux = [];
    for (const fila of this.listaSolicitudesEnc) {
      if (fila['SOIdSolicitud'] == idS) {
        estat = fila['SODetalleEstatus'];
        break;
      }
    }
    const correosNotificacion = [];
    for (const numS of this.listaSolicitudes) {
      const res = this.listaSolicitudesEnc.find(element => element.SOIdSolicitud == numS);
      if (res.SODetalleEstatus != 'Autorizada') {
        listaAux.push(numS);
        correosNotificacion.push(res.NumEmpleado);
      }
    }
    const dif = this.listaSolicitudes.length - listaAux.length;
    const count = listaAux.length;
    const titulo = '¡Espera!';
    const titulo2 = '¡Hecho!';
    let cadena = '¿Está seguro de Aceptar las ' + count + ' solicitudes seleccionadas?';
    let cadena2 = 'La solicitud ha sido autorizada';
    if (count > 0) {
      if (count == 1 && dif == 0) {
        cadena = '¿Deseas autorizar la solicitud?';
        cadena2 = 'La solicitud ha sido autorizada';
      } else {
        cadena = '¿Deseas autorizar ' + count + ' solicitud(es)? ';
        if (dif > 0) {
          cadena += 'Las solicitudes autorizadas serán descartadas';
        }
        cadena2 = 'Las solicitudes han sido autorizadas';
        if (count == 1) {
          cadena2 = 'La solicitud ha sido autorizada';
        }
      }
      swal({
        title: titulo,
        html: cadena,
        showCancelButton: true,
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
      }).then(async (result) => {
        if (result.value) {
          this.idTipoNotificacionGrupo = this.ID_NOTIF_SOL_GRUPO_AUTORIZACION;
          for (const numSol of listaAux) {
            await this.cambiaEstatusSolicitud('1', 'Autorizada', numSol);
          }
          if (this.tipoNotificacion == 2) {
            await this.enviaMailGrupo();
          }
          swal({
            title: titulo2,
            html: cadena2,
            type: 'success',
            confirmButtonText: 'Aceptar',
            onClose: () => {
              this.verificaVigencia();
            }
          });
        }
      });
    }
  }

  async rechazaSolicitud() {
    const count = this.listaSolicitudes.length;
    const titulo = '¡Espera!';
    let cadena = '¿Deseas rechazar la solicitud?';
    const titulo2 = '¡Hecho!';
    let cadena2 = '¿Deseas rechazar la solicitud?';
    if (count == 1) {
      cadena = '¿Deseas rechazar la solicitud?';
      cadena2 = 'La solicitud ha sido rechazada';
    } else {
      cadena = '¿Deseas rechazar ' + count + ' solicitud(es)?';
      cadena2 = 'Las  solicitudes han sido rechazadas';
    }
    swal({
      title: titulo,
      html: cadena,
      showCancelButton: true,
      confirmButtonText: 'Aceptar',
      cancelButtonText: 'Cancelar',
      allowOutsideClick: false
    }).then(async (result) => {
      if (result.value) {
        this.idTipoNotificacionGrupo = this.ID_NOTIF_SOL_GRUPO_RECHAZO;
        for (const numSol of this.listaSolicitudes) {
          await this.cambiaEstatusSolicitud('5', 'Rechazada', numSol);
        }
        if (this.tipoNotificacion == 2) {
          await this.enviaMailGrupo();
        }
        swal({
          title: titulo2,
          html: cadena2,
          type: 'success',
          confirmButtonText: 'Aceptar',
          onClose: () => {
            this.verificaVigencia();
          }
        });
      }
    });
  }

  async cancelaSolicitud() {
    const count = this.listaSolicitudes.length;
    const titulo = '¡Alto!';
    let cadena = 'Esta acción no puede deshacerse, si se confima la solicitud será cancelada.<br>¿Estás seguro de cancelar la solicitud?';
    const titulo2 = '¡Hecho!';
    let cadena2 = 'La solicitud ha sido cancelada';
    if (count == 1) {
      cadena = 'Esta acción no puede deshacerse, si se confima la solicitud será cancelada.<br>¿Estás seguro de cancelar la solicitud?';
      cadena2 = 'La solicitud ha sido cancelada';
    } else {
      cadena = 'Esta acción no puede deshacerse, si se confima la solicitud será cancelada.<br>¿Estás seguro de cancelar ' + count + ' solicitud(es)?';
      cadena2 = 'Las solicitudes has sido canceladas';
    }
    swal({
      title: titulo,
      html: cadena,
      showCancelButton: true,
      confirmButtonText: 'Aceptar',
      cancelButtonText: 'Cancelar',
      allowOutsideClick: false
    }).then(async (result) => {
      if (result.value) {
        this.idTipoNotificacionGrupo = this.ID_NOTIF_SOL_GRUPO_CANCELACION;
        for (const numSol of this.listaSolicitudes) {
          await this.cambiaEstatusSolicitud('4', 'Cancelada', numSol);
        }
        if (this.tipoNotificacion == 2) {
          await this.enviaMailGrupo();
        }
        swal({
          title: titulo2,
          html: cadena2,
          type: 'success',
          confirmButtonText: 'Aceptar',
          onClose: () => {
            this.verificaVigencia();
          }
        });
      }
    });
  }

  async cambiaEstatusSolicitud(idEstatus: any, comentario: any, idSolicitud) {
    try {
      const response = await this._titularesService.cambiaEstatusSolicitud(idEstatus, comentario, idSolicitud, this.identity.id);
      await this.enviaMail(idSolicitud);
      return response;
    } catch (error) {
      return null;
    }
  }

  async reactivarSol(idEmpleado: any, idSolicitud: any) {
    let emp: any;
    let resultado: any;
    for (let i = 0; i < this.listaSolicitudes1.length; i++) {
      if (this.listaSolicitudes1[i].SOIdSolicitud === idSolicitud) {
        emp = this.listaSolicitudes1[i].Empresa;
      }
    }
    try {
      const FamiliaresDadosdeBaja: any = await this._titularesService.validaFamiliaresEnSolicitud(this.idEmpresa, this.numEmpleado, idSolicitud);
      if (FamiliaresDadosdeBaja[0].length == 0) {
        const response = await this._titularesService.reactivarSolicitud(emp, this.idEmpleado, idSolicitud, this.identity.id);

        if (response[5] != undefined) {
          resultado = response[5][0];
        } else {
          resultado = response[0][0];
        }
        if (parseInt(resultado.Resultado, 10) == 1) {
          swal({
            title: '¡Hecho!',
            html: 'La solicitud ha sido reactivada',
            type: 'success',
            confirmButtonText: 'Aceptar',
            onClose: () => {
              this.enviaMailReactivacion(idSolicitud);
              this.verificaVigencia();
            }
          });
        } else {
          swal({
            title: '¡La solicitud no puede ser reactivada debido a que el empleado ha generado otra solicitud!',
            type: 'warning',
            confirmButtonText: 'Aceptar',
          });
        }
      } else {
        swal({
          title: '¡La solicitud no puede ser reactivada debido a que uno de los Familiares en la solicitud ya fue dado de baja',
          type: 'warning',
          confirmButtonText: 'Aceptar',
        });
      }

    } catch (error) { }
  }

  public async getMailAdmin() {
    try {
      const response = await this._empleadoService.getPlantillaDatosAdmin(this.identity.id, this.identity.idEmpresa);
      this.datosMail = response[0];
    } catch (error) { }
  }

  public async getEncabezadoMail() {
    try {
      const response = await this._empleadoService.getPlantillaDatos(8);
      this.plantillaSend = response[0];
      this.plantillaSend = response[0];
      this.sujeto = this.plantillaSend['sujeto'].toString();
      this.sujeto = this.sujeto.replace('#NombreEmpresa', this._empleadoService.getIdentity().nomEmpresa);
      this.bodyHTML = this.plantillaSend['plantilla'].toString();
      this.cuerpoCorreo = '';
    } catch (error) { }
  }

  private idTipoNotificacionPorEstatusSolicitud(detalleEstatus: string): number {
    if (detalleEstatus === 'Autorizada') {
      return this.ID_NOTIF_SOL_AUTORIZACION;
    }
    if (detalleEstatus === 'Rechazada') {
      return this.ID_NOTIF_SOL_RECHAZO;
    }
    if (detalleEstatus === 'Cancelada') {
      return this.ID_NOTIF_SOL_CANCELACION;
    }
    return this.ID_NOTIF_SOL_AUTORIZACION;
  }

  // CAT: Las notificaciones automaticas de autorizacion, rechazo y cancelacion
  // deben enviarse solo al grupo de administradores configurado, sin agregar
  // el correo del empleado y sin repetir destinatarios entre Para/CC/CCO.
  private obtenerDestinatariosAdministradores(): { to: string; cc: string; bcc: string } {
    const correosUtilizados = new Set<string>();
    const normalizar = (valor: any): string => String(valor || '')
      .split(/[,;]+/)
      .map(correo => correo.trim())
      .filter(correo => {
        if (!correo) {
          return false;
        }
        const clave = correo.toLowerCase();
        if (correosUtilizados.has(clave)) {
          return false;
        }
        correosUtilizados.add(clave);
        return true;
      })
      .join(',');

    return {
      to: normalizar(this.destinatarios[0]),
      cc: normalizar(this.destinatarios[1]),
      bcc: normalizar(this.destinatarios[2])
    };
  }

  public async enviaMail(idSolicitud: any) {
    this.bodyHTML = this.plantillaSend['plantilla'].toString();
    try {
      const response = await this._titularesService.getDatosSolicitudXId(idSolicitud);
      const res = response[0][0];
      let estatus = '';
      if (res['SODetalleEstatus'] == 'Autorizada') {
        estatus = 'Autorizado';
      } else if (res['SODetalleEstatus'] == 'Cancelada') {
        estatus = 'Cancelado';
      } else if (res['SODetalleEstatus'] == 'Rechazada') {
        estatus = 'Rechazado';
      }
      if (this.tipoNotificacion == 2) {
        this.cuerpoCorreo += this.bodyHTML;
        this.cuerpoCorreo = this.cuerpoCorreo.replace('#NombreUsuarioMod', res['']);
        this.cuerpoCorreo = this.cuerpoCorreo.replace('#Estatus', estatus);
        this.cuerpoCorreo = this.cuerpoCorreo.replace('#SolNum', res['Solicitud']);
        this.cuerpoCorreo = this.cuerpoCorreo.replace('#Tipo2', res['PENombre']);
        this.cuerpoCorreo = this.cuerpoCorreo.replace('#NombreEmpleado', res['Nombre']);
        this.cuerpoCorreo = this.cuerpoCorreo.replace('#Fechacreacion', this.fecha2(res['SOFechaAdd']));
        this.cuerpoCorreo = this.cuerpoCorreo.replace('#NombreEmpresa', res['EMNombre']);
      } else {
        this.bodyHTML = this.bodyHTML.replace('#NombreUsuarioMod', res['']);
        this.bodyHTML = this.bodyHTML.replace('#Estatus', estatus);
        this.bodyHTML = this.bodyHTML.replace('#SolNum', res['Solicitud']);
        this.bodyHTML = this.bodyHTML.replace('#Tipo2', res['PENombre']);
        this.bodyHTML = this.bodyHTML.replace('#NombreEmpleado', res['Nombre']);
        this.bodyHTML = this.bodyHTML.replace('#Fechacreacion', new Date(res['SOFechaAdd']));
        this.bodyHTML = this.bodyHTML.replace('#NombreEmpresa', res['EMNombre']);
      }
      const destinatarios = this.obtenerDestinatariosAdministradores();
      const to = destinatarios.to;
      const cc = destinatarios.cc;
      const bcc = destinatarios.bcc;
      if (this.tipoNotificacion != 2) {
        const idTipoNotificacion = this.idTipoNotificacionPorEstatusSolicitud(res['SODetalleEstatus']);
        await this._empleadoService.sendMailUnificado(to, cc, bcc, this.sujeto, this.bodyHTML, '', '', '', '', idTipoNotificacion, this._empleadoService.getToken());
      }
      return to;
    } catch (error) { }
  }

  public async enviaMailReactivacion(idSolicitud: any) {
    this.bodyHTML = this.plantillaSend['plantilla'].toString();
    let estatus = '';
    estatus = 'Reactivado';
    this.bodyHTML = this.bodyHTML.replace('#NombreUsuarioMod', this.datosMail['nombre']);
    this.bodyHTML = this.bodyHTML.replace('#Estatus', estatus);
    this.bodyHTML = this.bodyHTML.replace('#SolNum', idSolicitud);
    this.bodyHTML = this.bodyHTML.replace('#Tipo2', 'Empleado');
    this.bodyHTML = this.bodyHTML.replace('#NombreEmpleado', this.nomEmpleado);
    this.bodyHTML = this.bodyHTML.replace('#Fechacreacion', this.fecha());
    this.bodyHTML = this.bodyHTML.replace('#NombreEmpresa', this.datosMail['empresa']);


    let to = this.datosMail['correo'];
    to = this.destinatarios[0];
    let cc = 'beflex@mx.lockton.com';
    if (this.destinatarios[1].length > 0) {
      cc = this.destinatarios[1];
    }
    const bcc = this.destinatarios[2];
    try {
      await this._empleadoService.sendMailUnificado(to, cc, bcc, this.sujeto, this.bodyHTML, '', '', '', '', this.ID_NOTIF_SOL_REACTIVACION, this._empleadoService.getToken());
      return to;
    } catch (error) { }
  }

  public async enviaMailGrupo() {
    const destinatarios = this.obtenerDestinatariosAdministradores();
    const to = destinatarios.to;
    const cc = destinatarios.cc;
    const bcc = destinatarios.bcc;
    try {
      await this._empleadoService.sendMailUnificado(to, cc, bcc, this.sujeto, this.cuerpoCorreo, '', '', '', '', this.idTipoNotificacionGrupo, this._empleadoService.getToken());
    } catch (error) { }
    this.cuerpoCorreo = '';
  }

  /*      imprimir un documento       */
  imprimirAux() {
    const settings = {
      'async': true,
      'crossDomain': true,
      'url': `${this.urlApi}file/get-document?ruta=DocumentoEmpresa/369/PLANES/Vales de Despensa.pdf`,
      'method': 'GET',
      'headers': {},
      xhrFields: {
        responseType: 'blob'
      },
    };

    return $.ajax(settings).done((response) => {
      return true;
    }).fail((error) => {
      return false;
    });
  }

  /***********************************************    idEmpleado    *******************/
  async traerDatos(numeroEmpleado: any, empresa: any) {
    this.numEmpleado = numeroEmpleado;
    const param = {
      idEmpresa: empresa,
      numeroEmpleado: numeroEmpleado
    };
    return await this._dependienteService.getDependiente(param, this.token).then(async resp => {
      try {
        const emPrefijo: any = await this._empleadoService.obtenerPrefijoSolicitud(this.idEmpresa);
        this.validaPrefijo = emPrefijo.emPrefijoSolicitud;
      } catch (error) { }
      try {
        const response: any = await this._empleadoService.consultarParametroStatusLeyenda2(this.idEmpresa, 202);
        if (response.paValor == 1) {
          this.quitarFirmas = true;
        }
      } catch (error) { }
      this.idEmpleado = resp[0].id;
      this.idEmpresa = resp[0].emidEmpresa;
      this.nomEmpleado = resp[0].EMApellidoPaterno + ' ' + resp[0].EMApellidoMaterno + ' ' + resp[0].EMNombre1 + ' ' + resp[0].EMNombre2;
      return this.idEmpleado;
    }, error => {
      return 0;
    });
  }

  async traerDatosImp(numeroEmpleado: any, empresa: any, sol: any, soEstatusSolicitud: any, soIdEstatus: any) {
    try {
      const emPrefijo: any = await this._empleadoService.obtenerPrefijoSolicitud(empresa);
      this.validaPrefijo = emPrefijo.emPrefijoSolicitud;
    } catch (error) { }
    try {
      const response: any = await this._empleadoService.consultarParametroStatusLeyenda2(empresa, 202);
      if (response.paValor == 1) {
        this.quitarFirmas = true;
      }
    } catch (error) { }
    this.numEmpleado = numeroEmpleado;
    const param = {
      idEmpresa: empresa,
      numeroEmpleado: numeroEmpleado
    };
    return await this._dependienteService.getDependiente(param, this.token).then(resp => {
      const params = resp[0].id;
      this.idEmpleado = resp[0].id;
      this.idEmpresa = resp[0].emidEmpresa;
      this.getDocumento(sol, this.validaPrefijo, params, soEstatusSolicitud, soIdEstatus);
      return this.idEmpleado;
    }, error => {
      this.getDocumento(sol, this.validaPrefijo, this.idEmpleado, soEstatusSolicitud, soIdEstatus);
      return this.idEmpleado;
    });
  }

  /*************************** Encabezados  ****************************************/
  public async getColumnasEdoCuentaEmpresa() {
    const flag = true;
    try {
      const request = await this._empleadoService.getEdoCuenta(this._empleadoService.getIdentity().idEmpresa);

      this.columnas = request;
      if (this.columnas) {

        let anterior = 0;
        let nuevo = 0;
        for (let index = 0; index < this.columnas.length; index++) {
          nuevo = this.columnas[index]['idEdoCuentaConcepto'];
          if (nuevo != anterior) {
            switch (this.columnas[index]['idEdoCuentaConcepto']) {
              case 1:
                this.arregloColumnasVisibles.push('Créditos');
                break;
              case 2:
                this.arregloColumnasVisibles.push('Descuentos');
                break;
              case 3:
                this.arregloColumnasVisibles.push('Excedentes');
                break;
              case 4:
                this.arregloColumnasVisibles.push('Fondo de ahorro');
                break;
              case 5:
                this.arregloColumnasVisibles.push('Costo coberturas');
                break;
              case 6:
                this.arregloColumnasVisibles.push('Sobrante créditos');
                break;
              case 7:
                this.arregloColumnasVisibles.push('Sobrante de excedentes');
                break;
              case 8:
                this.arregloColumnasVisibles.push('Costo de coberturas anuales menos créditos anuales');
                break;
              case 9:
                this.arregloColumnasVisibles.push('Descuento empleado anual antes de excedentes anuales');
                break;
            }
          }
          anterior = nuevo;
        }

        const vAux: any[] = [];
        let bandera: boolean;

        for (let i = 0; i < this.displayedColumns.length; i++) {
          bandera = false;
          for (let j = 0; j < this.arregloColumnasVisibles.length; j++) {
            if (this.displayedColumns[i] == this.arregloColumnasVisibles[j]) {
              bandera = true;
            }
          }
          if (bandera == false) {
            vAux.push(this.displayedColumns[i]);
          }
        }
        this.columnasObj = vAux;
        this.parametroConfiguraColumna = this.columnasObj;
        this.columnasObj = vAux;
      }
    } catch (error) { }
  }

  obtenEmpresa(idEmpresa) {
    let nomEmp = '';
    for (const empresa of this.comboEmpresas) {
      if (empresa.IdEmpresa == idEmpresa) {
        return nomEmp = empresa.NomEmpresa;
      }
    }
  }

ocultaBtnReact(index: any) {

  console.log("listaSolicitudesEnc", this.listaSolicitudesEnc);
  console.log("index", index);

 
  if (!this.listaSolicitudesEnc || !this.listaSolicitudesEnc[index]) {
    console.warn("Elemento no encontrado en listaSolicitudesEnc para index", index);
    return false;
  }

  let bandera = true;

  const date = new Date(this.listaSolicitudesEnc[index]['SOFechaEstatus']);
  const empleado = this.listaSolicitudesEnc[index]['NumEmpleado'];
  const empresa = this.listaSolicitudesEnc[index]['Empresa'];

  for (let i = 0; i < this.listaSolicitudesArr.length; i++) {

    const date2 = new Date(this.listaSolicitudesArr[i]['SOFechaEstatus']);
    const empleado2 = this.listaSolicitudesArr[i]['NumEmpleado'];
    const empresa2 = this.listaSolicitudesArr[i]['Empresa'];

    const num = this.listaSolicitudesEnc[index]['SONumeroSolicitud'].split('-');

    if (empleado === empleado2 && empresa === empresa2) {

      if (date < date2) {
        bandera = false;
        break;
      }

      if (date.getTime() === date2.getTime()) {
        const numA = this.listaSolicitudesArr[i]['SONumeroSolicitud'].split('-');

        if (parseInt(num[0], 10) <= parseInt(numA[0], 10)) {
          if (parseInt(num[0], 10) == parseInt(numA[0], 10)) {
            if (parseInt(num[1], 10) < parseInt(numA[1], 10)) {
              bandera = false;
              break;
            }
          }
        }
      }
    }
  }

  return bandera;
}

  validarInput(parametro: string) {
    const regexpNumber = new RegExp('^[\u00F1\u00D1 A-ZÁ-Üa-zá-ü .]+$');
    const regexpNumber2 = new RegExp('^[a-zA-Z0-9]+$');
    if (this.busquedaPor != 'EMNumeroEmpleado' && parametro.length > 0) {
      if (regexpNumber.test(parametro)) {
        this.errorRep.parametroBusqueda1 = false;
      } else {
        this.errorRep.parametroBusqueda1 = true;
        this.leyendaError = 'Ingresa sólo letras';
      }
    } else {
      if (this.busquedaPor == 'EMNumeroEmpleado' && parametro.length > 0) {
        if (regexpNumber2.test(parametro)) {
          this.errorRep.parametroBusqueda1 = false;
        } else {
          this.leyendaError = 'Ingresa sólo letras y números';
          this.errorRep.parametroBusqueda1 = true;
        }
      } else {
        this.errorRep.parametroBusqueda1 = false;
      }
    }
  }

  cambiarBuscarPor(busquedaPor: string, valorBusqueda: string) {
    this.busquedaPor = this.parametrosBusqueda.idAtributo1;
    valorBusqueda = this.textoFiltro;
    this.validarInput(valorBusqueda);
  }
  // Metodo de busqueda
  verificarInput(input: string = '') {
    let estatus = true;
    if(!this.validarParametros(1)){
      estatus = false;
    }
    if(this.esBusquedaAvanzada && (!this.validarParametros(2))){
      estatus = false;
    }
    this.mostrarDatosTabla = false;
    this.page = 1;
    this.pageSize = 5;
    this.collectionSize = 0;
    if (estatus) {
      this.verificaVigencia();
    }else{
      swal({
        title: '¡Atención!',
        html: 'Los parámetros de búsqueda no son válidos, no se permiten caracteres especiales y campos vacíos.',
        type: 'warning',
        confirmButtonText: 'Aceptar',
        showConfirmButton: true,
        onOpen: () => {
          swal.hideLoading();
        }
      });
    }
  }

  // Validacion de campos de parametro
  public validarParametros(idCampo) {
    let parametrosValidos = true;
    const buscar = idCampo === 1 ? this.parametrosBusqueda.parametroBusqueda1 : this.parametrosBusqueda.parametroBusqueda2;
    const campoAtributo = idCampo === 1 ? this.parametrosBusqueda.idAtributo1 : this.parametrosBusqueda.idAtributo2;

    if(!this.validaContenidoParametroBusqueda(buscar, campoAtributo, idCampo)){
      parametrosValidos = false;
      if(idCampo === 1){
        this.errorRep.parametroBusqueda1 = true;
      }else{
        this.errorRep.parametroBusqueda2 = true;
      }
    }else{
      if(idCampo === 1){
        this.errorRep.parametroBusqueda1 = false;
      }else{
        this.errorRep.parametroBusqueda2 = false;
      }
    }
    return parametrosValidos;
  }
  validaContenidoParametroBusqueda(contenido: string, parametro: string, idCampo: number){
    const regexpCampo  = new RegExp('^[\u00F1\u00D1A-ZÁ-Üa-zá-ü .]+$');
    const regexpNumber2 = new RegExp('^[\u00F1\u00D1A-ZÁ-Üa-zá-ü0-9.]+$');
    let esValido = true;

    // Comprobar contenido de parametros
    if(!(idCampo === 1 && contenido.trim() === '' && !this.esBusquedaAvanzada)){ // Cuando el parametro esta vacio permitir busqueda
      if (contenido === null || contenido === '' || contenido.length === 0 || parametro === '') {
        this.leyendaError = 'Introduce tu búsqueda';
        esValido =  false;
      }else{
        if(parametro === "EMNumeroEmpleado"){ // Validar campo de numero de empleado
          if (!regexpNumber2.test(contenido)) {
            this.leyendaError = 'Ingresa sólo letras y/o números';
            esValido =  false;
          }
        }else{ // Validar campos distintos a numero de empleado
          if (!regexpCampo.test(contenido)) {
            this.leyendaError = 'Ingresa sólo letras';
            esValido =  false;
          }
        }
      }
    }
    return esValido;
  }

  /*- OBTENEMOS LA CONFIGURACION DE ENVIO DE NOTIFICACION ASI COMO EL GRUPO DE ADMINISTRADORES */
  public async proc_LeeParametro() {
    this.boolEnvia = false;
    let salida = '';
    try {
      const response = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idEmpresa, '113');
      salida = response['paValor'];
      const ArrayPlatilla = salida.split(',');
      for (const item of ArrayPlatilla) {
        if (parseInt(item.trim(), 10) == 8) {
          this.boolEnvia = true;
        }
      }
    } catch (error) { }
  }

  public async getGrupo() {
    this.destinatarios[0] = '';
    this.destinatarios[1] = '';
    this.destinatarios[2] = '';
    try {
      const response = await this._cifrasControlService.getGrupoCorreos(8, this.identity.idEmpresa, this.token);
      const response2 = [];
      response2.push(response);
      for (const row of response2[0]) {
        if (row != null && row != undefined) {
          if (row.gcCorreoCopia) {
            this.destinatarios[0] = row.adCorreoElectronico.trim().replace(':', '') + ',' + this.destinatarios[0];
          }
          if (row.gcCorreoCopiaOculta) {
            this.destinatarios[1] = row.adCorreoElectronico.trim() + ',' + this.destinatarios[1];
          }
          if (row.gcCorreoVisible) {
            this.destinatarios[2] = row.adCorreoElectronico.trim() + ',' + this.destinatarios[2];
          }
        }
      }
    } catch (error) { }
  }

  public async getCorreoAdmin() {
    try {
      const response = await this._cifrasControlService.getCorreoAdmin(this.identity.idEmpresa, this.token);
      this.correoAdmin = response[0];
    } catch (error) {
      this.correoAdmin = error.error.text;
    }
  }

  formatNumber(price, digits, thoSeperator, decSeperator, bdisplayprice) {
    let i;
    digits = (typeof digits === 'undefined') ? 2 : digits;
    bdisplayprice = (typeof bdisplayprice === 'undefined') ? true : bdisplayprice;
    thoSeperator = (typeof thoSeperator === 'undefined') ? '.' : thoSeperator;
    decSeperator = (typeof decSeperator === 'undefined') ? ',' : decSeperator;
    price = price.toString();
    const _temp = price.split('.');
    let dig = (digits > 0 && typeof _temp[1] === 'undefined') ? '00' : _temp[1];
    if (bdisplayprice && parseInt(dig, 10) === 0) {
      dig = '-';
    } else
      if (digits > 0) {
        dig = dig.toString();
        if (dig.length > digits) {
          dig = (Math.round(parseFloat('0.' + dig) * Math.pow(10, digits))).toString();
        }
        for (i = dig.length; i < digits; i++) {
          dig += '0';
        }
      }
    let num = _temp[0];
    if (num == '') { num = '0'; }
    let s = num.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    if (digits > 0) {
      s = s + decSeperator + dig;
    }
    return s;
  }

  async obtenerRutasV2(vIdEmpleado, soIdSolicitud, emPrefijo) {
    console.log("obtenerRutas");
    const settings = {
      async: true,
      crossDomain: true,
      url: this.urlApi + 'file/empleado/find?idEmpresa=' + this.idEmpresa + '&idSolicitud=' + soIdSolicitud + '&idEmpleado=' + vIdEmpleado,
      method: 'GET',
      headers: {
        'cache-control': 'no-cache',
      }
    };

    $.ajax(settings).done(async (response) => {
      console.log("recuperarSolicitudConAnexo");
      await this.recuperarSolicitudConAnexo(response, vIdEmpleado, soIdSolicitud);
    }).fail((error) => {
      //console.log("getSolicitudXML");
      //this.getSolicitudXML(soIdSolicitud, `Solicitud_${vIdEmpleado}_${soIdSolicitud}.pdf`, `DocumentoEmpresa/${this._empleadoService.getIdentity().idEmpresa}/Solicitud/`, emPrefijo);
    });
  }

  async obtenerAnexosPlanesVida(): Promise<any> {

    let parametroConfig;
    let parametroConfig2;
    let parametroConfig3;

    try {
      const param126 = await this._empleadoService.getParametro(this.idEmpresa, '126');
      parametroConfig2 = param126['paId'];

      if (parametroConfig2 == 126) {
        this.parametro126 = param126['paValor'].replace(/ /g, "");

        if (this.parametro126 == 1) {
          this.consentimeinto = true;
        }
      }

    } catch (error) {
      console.log("no se pudo obtener un parametro")
    }

    try {
      await this._empleadoService.consultarParametroStatusLeyenda2(this.idEmpresa, 202).then((response: any) => {
        if (response.paValor == 1) {
          this.quitarFirmas = true;
        }
      }),
        await this._empleadoService.consultarParametroStatusLeyenda2(this.idEmpresa, 206).then((response: any) => {
          if (response.paValor == 1) {
            this.quitarSeleccionesAnteriores = true;
          }
        }),
        await this._empleadoService.consultarParametroStatusLeyenda2(this.idEmpresa, 228).then((response: any) => {
          if (response.paValor == 1) {
            this.quitarResumenDescuento = true;
          }
        });
    } catch (error) {
      console.log("erro");
    }

    try {
      /* const param207 = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idEmpresa, '207');
      parametroConfig3 = param207['paValor'].replace(/ /g, "");;

      this.idsegmentarplan = parametroConfig3; */

      await this._empleadoService.getParametro(this.idEmpresa, 207).then(
        (response: any) => {
          this.idsegmentarplan = response.paValor;

          if (this.idsegmentarplan) {
            this.idsegmentarplan = this.idsegmentarplan.replace(/\s/g, '');
            this.idsegmentarplan = Number(this.idsegmentarplan);
          }

        }, error => {
          console.log("Fallo recuperar parametro...");
        }
      );

    } catch (error) {
      console.log("no se pudo obtener parametro 207");
    }



    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.urlApi + "documento/solicitud/empleado/" + this.idEmpleado,
      "method": "GET",
      "headers": {
        "cache-control": "no-cache"
      }
    }

    try {
      $.ajax(settings).done(async (response) => {

        if (response) {
          this.anexos = true;
        }

      }).fail((error) => {
        var errorMessage = <any>error;
        console.log(errorMessage);
      });

    } catch (error) {
      console.log("hubo un error aqui");
    }



    if (this.solicitudess != null && this.solicitudess != undefined) {

      //Peticion ConsultarPlanesVidaV2
      this._beneficiarioService.consultarPlanesVidaV2Sos(this.identity.idCorporativo, this.idEmpleado, this.numEmpleado, this.idEmpresa, this.token).then(
        async (response3: any) => {

          if (response3.length == 1) {
            this.consentimeinto = false;
          }

          localStorage.setItem('planesVida', JSON.stringify(response3));
        }, error => {
          this.losDatosCotizador = false;
          var errorMessage = <any>error;
          console.log('fallo consultarPlanesVidaV2');
        }
      );
      // FIN - Peticion ConsultarPlanesVidaV2

    }

  }

  async recorrerAnexos() {
    localStorage.removeItem('cierreBeneficiarios');
    var planesvida = this._BuscarPlanesv2.anexosPosibles();

    var inicio = {
      "idEmpresa": this.idEmpresa,
      "planesSeleccionados": [
        {
          "costo": null,
          "idempleado": -1,
          "nuevo": null,
          "tcidtarifacosto": -1
        }
      ],
      "planesSeleccionadosOld": [
        {
          "costoOld": null,
          "idempleadoOld": -1,
          "nuevoOld": null,
          "tcidtarifacostoOld": -1
        }
      ],
      "transfer": null
    }

    const datosCotizador = await this.userService.getBuscaPlanesPerfil2(this.idEmpleado, inicio).then(function async(response) {
      return response;
    });


    var n = 0;

    if (planesvida != null) {

      for (let i = 0; i < datosCotizador.datosCotizador.length; i++) {

        if (datosCotizador.datosCotizador[i]['checked'] == "true" || datosCotizador.datosCotizador[i]['checked'] == "True" || datosCotizador.datosCotizador[i]['checked'] == "TRUE") {

          for (const iterator of planesvida) {

            if (iterator.plIdPlan == datosCotizador.datosCotizador[i]['poIdPlan']) {
              n++;
              let plIdPlan = datosCotizador.datosCotizador[i]['poIdPlan'];
              let poIdPlanOpcion = datosCotizador.datosCotizador[i]['poIdPlanOpcion'];
              let idAsegurado = datosCotizador.datosCotizador[i]['id'];


              if (plIdPlan != this.idsegmentarplan) {
                await this.Consentimiento(plIdPlan, poIdPlanOpcion, n, idAsegurado, this.solicitudess);
              } else {

                if (idAsegurado === this.idEmpleado) {
                  await this.Consentimiento(plIdPlan, poIdPlanOpcion, n, idAsegurado, this.solicitudess);
                }

              }


            }
          }

        }

        if (i == (datosCotizador.datosCotizador.length - 1)) {
          //await this.validarAnexos();
          await this.prueba();
        }

      }

    } else {
      // await this.validarAnexos();
      await this.prueba();
    }

  }

  async validarAnexos() {
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.urlApi + "documento/solicitud/empleado/" + this.idEmpleado,
      "method": "GET",
      "headers": {
        "cache-control": "no-cache"
      }
    }

    try {
      await $.ajax(settings).done(async (response) => {

        if (response) {
          this.anexos = true;
        }
        return true;
        //this.crearXMLFinal(2, response3.length);
      }).fail((error) => {
        this.losDatosCotizador = false;
        var errorMessage = <any>error;
        console.log('fallo get 1 sin anexos');
        console.log(errorMessage);

        return true;
        //this.crearXMLFinal(2, response3.length);
      });
    } catch (error) {
      console.log("nuevo error puesto aquí");
      return true;
    }
  }

  async prueba() {
    let url = this.urlWs;
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": url + "merge/pdf",
      "method": "POST",
      "headers": {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      "data": {
        "idCorporativo": this.identity.idCorporativo,
        "idEmpresa": this.idEmpresa,
        "idEmpleado": this.idEmpleado,
        "idSolicitud": this.solicitudess,
        "file": this.nombreSolicitud,
        "anexos": this.anexos,
        "consentimeinto": this.consentimeinto,
        "numeroEmpleado": this.numEmpleado + "_"
      }
    }

    await $.ajax(settings).done(async (response) => {
      try {
        if (response.uri) {
          this.nombreArchivo = encodeURIComponent(response.file);
          this.solicitud = this.urlApi + 'solicitud/get-pdf?ruta=' + encodeURIComponent(response.uri) + '%2F' + encodeURIComponent(response.file);
          this.rutaPDFAnexo = encodeURIComponent(response.uri) + '%2F' + encodeURIComponent(response.file);
          console.log("llego correctamente esta es la url, ", this.solicitud)
        }
      } catch (error) {
        console.log("hubo algo");
      }

    }).fail((error) => {
      this.solicitud = null;
      console.log("No se pudo generar concentimiento");
    });
  }

  async limpiarAnexos() {
    let url = this.urlWs;
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": url + "limpiar/anexos",
      "method": "POST",
      "headers": {
        "Content-Type": "application/x-www-form-urlencoded",
        "token": this.token
      },
      "data": {
        "idCorporativo": this.identity.idCorporativo,
        "idEmpresa": this.idEmpresa,
        "idEmpleado": this.idEmpleado,
        "numeroEmpleado": this.numEmpleado + "_"
      }
    }

    await $.ajax(settings).done((response) => {
    });

  }

  async Consentimiento(plIdPlan: Number, poIdPlanOpcion: Number, n: Number, idAsegurado: Number, solicitudes: Number) {
    let url = this.urlWs;
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": url + "consentimientos",
      "method": "POST",
      "headers": {
        "content-type": "application/x-www-form-urlencoded"
      },
      xhrFields: {
        responseType: 'blob'
      },
      "data": {
        "idTitular": this.idEmpleado,
        "idDependiente": idAsegurado.toString(),
        "idPlan": plIdPlan.toString(),
        "idPlanOpcion": poIdPlanOpcion,
        "idCorporativo": this.identity.idCorporativo,
        "idEmpresa": this.idEmpresa,
        "numEmpleado": this.numEmpleado,
        "idEmpleado": this.identity.id,
        "idSolicitud": solicitudes,
        "idAsegurado": idAsegurado.toString(),
        "num": n
      }
    }

    await $.ajax(settings).done(async (response) => {
    }).fail(async (error) => {
      console.log("no se pueden generar consentimientos");
      await this.obtenerRutasBorrar(this.idEmpleado, this.solicitudess, "");
      swal({
        title: 'Intenta más tarde',
        html: '<small style="color: grey; text-align: justify;">Tiempo de espera agotado, intenta más tarde por favor.</small>',
        type: 'info',
        confirmButtonText: 'Aceptar',
      });
    });

  }


  async obtenerUltimaSolicitud(idEmpleado): Promise<boolean> {
    ///var obj = JSON.stringify(idEmpleado);
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.urlApi + "pintarlog/obtenerultimasolicitud",
      "method": "POST",
      "headers": {
        "content-type": "application/json"
      },
      "processData": false,
      "data": idEmpleado
    }
    try {
      const res = await $.ajax(settings).done(function (response) {
        return true;
      }).fail((error) => {
        return false;
      });
      return res;
    } catch (error) {
      return false;
    }
  }

  async obtenerRutasBorrar(vIdEmpleado, soIdSolicitud, emPrefijo) {
    console.log("obtenerRutas");
    const settings = {
      async: true,
      crossDomain: true,
      url: this.urlApi + 'file/empleado/find/borrar?idEmpresa=' + this.idEmpresa + '&idSolicitud=' + soIdSolicitud + '&idEmpleado=' + vIdEmpleado,
      method: 'GET',
      headers: {
        'cache-control': 'no-cache',
      }
    };

    try {
      await $.ajax(settings);
      console.log("recuperarSolicitudConAnexo");
      console.log("se borro correctamente");
    } catch (error) {
      this.noSePuedeBorrarArchivoAun = true;
      console.log("getSolicitudXML");
      console.log("No existe");
    }
  }


  //Crear solicitud para SMNYL
  async createSolicitud(parmamsString: String, opcion: any): Promise<any> {
    //var parmamsString =null;
    //await this.obtenerAnexosPlanesVida();
    try {

      await this._BuscarPlanesv2.getPlanesPerfilV3(this.idEmpleado, this.token).then(
        (response: any) => {
          this.cotizadorv3 = response;
          var parmams =
          {
            "idEmpleado": this.cotizadorv3.declaraciones['idEmpleado'],
            "idEmpresa": this.cotizadorv3.declaraciones['idEmpresa'],
            "cantidadPago": this.cotizadorv3.declaraciones['cantidadPago'],
            "idConfiguracion": this.cotizadorv3.declaraciones['idConfiguracion'],
            "idEstatusVigencia": this.cotizadorv3.declaraciones['idEstatusVigencia'],
            "idPerfil": this.cotizadorv3.declaraciones['idPerfil'],
            "idVigencia": this.cotizadorv3.declaraciones['idVigencia'],
            "numeroEmpleado": this.cotizadorv3.declaraciones['numeroEmpleado']
          };
          parmamsString = JSON.stringify(parmams);
          //this.paramsSolicitud4 = parmamsString;
        });




    } catch (error) {
      console.log("hubo un error");
    }

    // Inicio de codigo de la generacion de documento
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.urlApi + "documento/solicitud/empleado/" + this.idEmpleado,
      "method": "GET",
      "headers": {
        "cache-control": "no-cache"
      }
    }



    try {
      await $.ajax(settings).done(async (response) => {
        if (response) {
          this.anexos = true;
        }

      }).fail(async (error) => {
        var errorMessage = <any>error;
        console.log(errorMessage);
      });
    } catch (error) {
      console.log("error")
    }


    this.parametrosAseguradoT.idCorporativo = this.identity.idCorporativo;
    this.parametrosAseguradoT.idTitular = this.idEmpleado;
    this.parametrosAseguradoT.numeroEmpleado = this.numEmpleado;
    this.parametrosAseguradoT.idEmpresa = this.idEmpresa;

    await this._beneficiarioService.consultarPlanesVidaV2(this.parametrosAseguradoT, this.token).then(
      async (response3: any) => {

        if (response3.length == 1) {
          this.consentimeinto = false;
        }

        const bene = response3.length;
        var settings = {
          "async": true,
          "crossDomain": true,
          "url": this.urlApi + "solicitud/v2/b3/xml",
          "method": "POST",
          "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
          },
          "processData": false,
          "data": parmamsString,
          "dataType": "text"
        }

        await $.ajax(settings).done(async (response) => {
          console.log('exito xml');
          console.log('creando 4');

          if (opcion == 2) {
            response = response.replace("</item>", "<preview>false</preview></item>");
          } else if (opcion == 1) {
            response = response.replace("</item>", "<preview>true</preview></item>");
          }

          if (this.quitarFirmas) {
            response = response.replace("</item>", "<firmas>true</firmas></item>");
          } else {
            response = response.replace("</item>", "<firmas>false</firmas></item>");
          }

          if (this.quitarSeleccionesAnteriores) {
            response = response.replace("</item>", "<seleccionesanteriores>true</seleccionesanteriores></item>");
          } else {
            response = response.replace("</item>", "<seleccionesanteriores>false</seleccionesanteriores></item>");
          }

          if (this.validaPrefijo == 5) {
            if (this.quitarResumenDescuento) {
              response = response.replace("</item>", "<descuentos>true</descuentos></item>");
            } else {
              response = response.replace("</item>", "<descuentos>false</descuentos></item>");
            }
          }

          response = await String(response);
          var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "");
          var d = new Date();
          var hhmmss = d.toTimeString().slice(0,8).replace(/:/g,"");
          var rutaPDF = {
            'ruta': "DocumentoEmpresa/" + this.idEmpresa + "/Solicitud",
            'archivo': "Solicitud_" + this.idEmpleado + "_" + YYYYMMDD + hhmmss + "_" + this.solicitudess + ".pdf"
          }
          this.nombreSolicitud = rutaPDF.archivo;

          await this._empleadoService.convertirPdf(await String(response), rutaPDF.ruta, rutaPDF.archivo, this.validaPrefijo, this._empleadoService.getToken());


        }).fail((error) => {
          var errorMessage = <any>error;
        });
      }, error => {
        var errorMessage = <any>error;
      }
    );
    // --- fin de codigo de la generacion de documento
    //});
  }


  //Crear solicitud para cualquier empresa
  async createSolicitud2(parmamsString: String, opcion: any): Promise<any> {


    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.urlApi + "documento/solicitud/empleado/" + this.idEmpleado,
      "method": "GET",
      "headers": {
        "cache-control": "no-cache"
      }
    }


    try {
      await $.ajax(settings).done(async (response) => {
        if (response) {
          this.anexos = true;
        }

      }).fail(async (error) => {
        var errorMessage = <any>error;
        console.log(errorMessage);
      });
    } catch (error) {
      console.log("error")
    }



    this.parametrosAseguradoT.idCorporativo = this.identity.idCorporativo;
    this.parametrosAseguradoT.idTitular = this.idEmpleado;
    this.parametrosAseguradoT.numeroEmpleado = this.numEmpleado;
    this.parametrosAseguradoT.idEmpresa = this.idEmpresa;

    await this._beneficiarioService.consultarPlanesVidaV2(this.parametrosAseguradoT, this.token).then(
      async (response3: any) => {

        if (response3.length == 1) {
          this.consentimeinto = false;
        }

        console.log('exito xml');
        console.log('creando 4');
        // const response = await this._empleadoService.generarSolicitudXid(this.solicitudess);
        /* await this._BuscarPlanesv2.getXmlSolicitud(this.identity.id, this.token, opcion).then(
          async (response: any) => { */

        await this._empleadoService.generarSolicitudXid(this.solicitudess).then(
          async (response: any) => {
            console.log('creando 1');
            response = response.replace("</item>", "<preview>false</preview></item>");
            var responseConf = $.parseXML(response);
            var x = responseConf.getElementsByTagName("NuevoFormato")[0];
            x = x.childNodes[0];
            x = x.nodeValue;
            this.NuevoFormato = x;

            if (this.quitarFirmas) {
              response = response.replace("</item>", "<firmas>true</firmas></item>");
            } else {
              response = response.replace("</item>", "<firmas>false</firmas></item>");
            }

            if (this.quitarSeleccionesAnteriores) {
              response = response.replace("</item>", "<seleccionesanteriores>true</seleccionesanteriores></item>");
            } else {
              response = response.replace("</item>", "<seleccionesanteriores>false</seleccionesanteriores></item>");
            }

            if (this.validaPrefijo == 5) {
              if (this.quitarResumenDescuento) {
                response = response.replace("</item>", "<descuentos>true</descuentos></item>");
              } else {
                response = response.replace("</item>", "<descuentos>false</descuentos></item>");
              }
            }
            //validacion para nueva solicitud
            if (this.NuevoFormato == 1) {
              this.validaPrefijo = 6;
              if (this.NuevoFormato == '1') {
                this.validaPrefijo = 6;
                response = response.replace("</item>", "<removeParentesco>0</removeParentesco></item>");
              } else {
                response = response.replace("</item>", "<removeParentesco>1</removeParentesco></item>");

              }
            }

            response = await String(response);
            var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "");
            var d = new Date();
            var hhmmss = d.toTimeString().slice(0,8).replace(/:/g,"");
            var rutaPDF = {
              'ruta': "DocumentoEmpresa/" + this.idEmpresa + "/Solicitud",
              'archivo': "Solicitud_" + this.idEmpleado + "_" + YYYYMMDD + hhmmss + "_" + this.solicitudess + ".pdf"
            }
            this.nombreSolicitud = rutaPDF.archivo;

            await this._empleadoService.convertirPdf(await String(response), rutaPDF.ruta, rutaPDF.archivo, this.validaPrefijo, this._empleadoService.getToken());
          }, async error => {
            console.log("hubo un error acá");
          });
      }, error => {
        var errorMessage = <any>error;
      }
    );
    // --- fin de codigo de la generacion de documento
    //});
  }


  public validacionFechaAprovacion(dataRow: any) {

    if (dataRow['SODetalleEstatus'] == 'Autorizada' && dataRow['SOFechaAprovacion'] == null) {
      return this.fecha2(dataRow['SOFechaEstatus']);
    }

    let valor = dataRow['SOFechaAprovacion'] ? this.fecha2(dataRow['SOFechaAprovacion']) : '';

    return valor;

  }

  async limitedPromise(promise, timeLimit) {
    return Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(new Error('Tiempo límite alcanzado')), timeLimit))
    ]);
  }


  async validarErrorTimerSolicitud(idSolicitud: any, action: any) {
    console.log(idSolicitud);
    var settings = {
      async: true,
      crossDomain: true,
      url: `${this.urlApi}PlanScotiabank/Excepciones/idSolicitud/${idSolicitud}/Action/${action}`,
      method: 'GET',
      headers: {
        'cache-control': 'no-cache',
      }
    };

    try {
      const response = await $.ajax(settings);
      if (response && response.length > 0) {
        const firstResponse = response[0];

        if (action === 1 && firstResponse.Mensaje === "Insertado Con Exito") {
          return false;
        } else if (action === 2) {
          if (firstResponse.Mensaje !== "Lista Vacia") {
            this.solicitudValidada = true;
            await this.obtenerRutasBorrar(this._empleadoService.getIdentity().id, idSolicitud, "");
            return true;
          } else {
            this.solicitudValidada = false;
            return false;
          }
        } else if (action === 3 && firstResponse.Mensaje === "Borrado Con Exito") {
          this.solicitudValidada = false;
          return false;
        } else {
          this.solicitudValidada = false;
          return false;
        }
      } else {
        this.solicitudValidada = false;
        return false;
      }
    } catch (error) {
      return false;
    }

  }

  async validarLecutraPDF(vIdEmpleado, soIdSolicitud, emPrefijo) {
    console.log("obtenerRutas");
    const settings = {
      async: true,
      crossDomain: true,
      url: this.urlApi + 'file/empleado/find/borrarpdf?idEmpresa=' + this.idEmpresa + '&idSolicitud=' + soIdSolicitud + '&idEmpleado=' + vIdEmpleado + '&numeroEmpleado=' + this.numEmpleado,
      method: 'GET',
      headers: {
        'cache-control': 'no-cache',
      }
    };

    try {
      const response = await $.ajax(settings);
      if (response) {
        if (response.includes('DatosCruzadosSeBorro') || response.includes('DatosCruzadosNoSeBorro')) {
          console.log("El archivo tiene datos cruzados y por lo tanto se borro");
          await this.validarErrorTimerSolicitud(soIdSolicitud, 1);
          this.elArchivoTieneDatosCruzadosYSeBorro = true;
        } else {
          this.elArchivoTieneDatosCruzadosYSeBorro = false;
          console.log("El archivo no tiene datos cruzados y por lo tanto no se borro");
          await this.validarErrorTimerSolicitud(soIdSolicitud, 3);
        }
      } else {
        this.elArchivoTieneDatosCruzadosYSeBorro = false;
        console.log("El archivo no tiene datos cruzados y por lo tanto no se borro");
        await this.validarErrorTimerSolicitud(soIdSolicitud, 3);
      }
    } catch (error) {
      this.elArchivoTieneDatosCruzadosYSeBorro = false;
      console.log("El archivo no tiene datos cruzados y por lo tanto no se borro");
      await this.validarErrorTimerSolicitud(soIdSolicitud, 3);
    }
  }

  // ==================== METODOS REENVIO SOLICITUD ====================

  /**
   * Reenvía una solicitud individual
   * @param index Índice de la solicitud en la lista
   */
  async reenviarSolicitud(index: any) {
    const solicitud = this.listaSolicitudesEnc[index];
    const idSolicitud = solicitud['SOIdSolicitud'];
    const detalleEstatus = solicitud['SODetalleEstatus'];

    // Validar que el estatus permita reenvío
    if (detalleEstatus !== 'Autorizada' && detalleEstatus !== 'Por Autorizar') {
      swal({
        title: 'No permitido',
        html: 'Solo se pueden reenviar solicitudes con estatus "Autorizada" o "Por Autorizar"',
        type: 'warning',
        confirmButtonText: 'Aceptar'
      });
      return;
    }

    const nombreEmpleado = [solicitud['EMApellidoPaterno'], solicitud['EMApellidoMaterno'],
      solicitud['EMNombre1'], solicitud['EMNombre2']]
      .filter(v => v && v.toString().trim()).join(' ').trim();
    const numSolicitud = solicitud['SONumeroSolicitud'] || idSolicitud;

    swal({
      title: '¿Reenviar notificación?',
      html: '¿Deseas reenviar la notificación de la solicitud <b>número ' + numSolicitud +
        '</b> del empleado <b>' + (nombreEmpleado || '-') + '</b>?',
      showCancelButton: true,
      confirmButtonText: 'Sí, reenviar',
      cancelButtonText: 'Cancelar',
      allowOutsideClick: false,
      showLoaderOnConfirm: true,
      preConfirm: async () => {
        try {
          const idUsuario = this.fullIdentity?.idUsuario || this.fullIdentity?.id || this.identity.id;
          const resultado: any = await this._titularesService.reenviarSolicitudIndividual(
            idSolicitud, idUsuario, this.token
          );
          return resultado;
        } catch (error) {
          swal.showValidationMessage('Error al reenviar: ' + error.message);
          return null;
        }
      }
    }).then((result) => {
      if (result.value) {
        if (result.value.exito) {
          swal({
            title: '¡Enviado!',
            html: 'Notificación reenviada a: <b>' + (result.value.correo || 'correo del empleado') + '</b>',
            type: 'success',
            confirmButtonText: 'Aceptar'
          });
        } else {
          swal({
            title: 'Error',
            html: result.value.mensaje || 'No se pudo reenviar la notificación',
            type: 'error',
            confirmButtonText: 'Aceptar'
          });
        }
      }
    });
  }

  /**
   * Alterna la visibilidad de la sección de reenvío masivo
   */
  toggleReenvioMasivo() {
    this.mostrarReenvioMasivo = !this.mostrarReenvioMasivo;
    if (!this.mostrarReenvioMasivo) {
      this.limpiarReenvioMasivo();
    }
  }

  /**
   * Limpia los datos de reenvío masivo
   */
  limpiarReenvioMasivo() {
    this.archivoReenvioMasivo = null;
    this.registrosReenvioMasivo = [];
    this.resultadosReenvioMasivo = [];
    this.resumenReenvioMasivo = { total: 0, exitosos: 0, errores: 0 };
    this.progresoReenvioMasivo = { procesados: 0, total: 0 };
    this.descartadosReenvioMasivo = [];
    this.procesandoReenvioMasivo = false;
    // Limpiar el input file
    if (this.fileInputReenvioMasivo) {
      this.fileInputReenvioMasivo.nativeElement.value = '';
    }
  }

  /**
   * Descarga el layout Excel para reenvío masivo (100% client-side, SheetJS).
   * - Con solicitudes seleccionadas en el grid: layout pre-llenado con esos registros.
   * - Sin selección: layout vacío solo con los encabezados.
   */
  descargarLayoutReenvio() {
    const registros = this.obtenerSeleccionParaReenvio();

    // Encabezados + (si hay selección) filas pre-llenadas. AoA para compatibilidad con read-excel-file.
    const data: any[][] = [
      ['NumeroEmpleado', 'NumeroSolicitud'],
      ...registros.map(r => [
        (r.numeroEmpleado || '').toString(),
        (r.numeroSolicitud || '').toString()
      ])
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);

    // Forzar tipo texto '@' en celdas de datos para que Excel no interprete "5-1" como fecha.
    const range = XLSX.utils.decode_range(worksheet['!ref']);
    for (let R = 1; R <= range.e.r; R++) {           // skip header (R=0)
      for (let C = range.s.c; C <= range.e.c; C++) {
        const ref = XLSX.utils.encode_cell({ c: C, r: R });
        const cell = worksheet[ref];
        if (cell && cell.v !== undefined && cell.v !== null) {
          const valor = cell.v.toString();
          cell.t = 's';     // string type
          cell.z = '@';     // text number format
          cell.v = valor;
          cell.w = valor;   // display literal (Excel no lo re-interpreta)
        }
      }
    }
    worksheet['!cols'] = [{ wch: 20 }, { wch: 20 }];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Layout Reenvio');

    // bookSST:true fuerza xl/sharedStrings.xml (read-excel-file 4.x lo exige para re-subir el archivo).
    const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array', bookSST: true });
    const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const nombre = registros.length > 0
      ? `Layout_Reenvio_Seleccion_${registros.length}.xlsx`
      : 'Layout_Reenvio_Masivo.xlsx';
    FileSaver.saveAs(blob, nombre);

    swal({
      title: 'Layout descargado',
      html: registros.length > 0
        ? `Se descargó el layout con <b>${registros.length}</b> registro(s) seleccionado(s) en el archivo <code>${nombre}</code>.`
        : `Se descargó el layout vacío <code>${nombre}</code>.<br>Llénelo con el <b>Número de empleado</b> (obligatorio) y opcionalmente el <b>Número de solicitud</b>, y cárguelo para procesar el reenvío masivo.`,
      type: 'success',
      confirmButtonText: 'Aceptar'
    });
  }

  /**
   * Estructura oficial del layout de reenvío masivo (nombres y orden exactos).
   * Debe coincidir con exportarSeleccionAlLayout() y el endpoint /reenvio/layout-template.
   */
  private readonly COLUMNAS_LAYOUT_REENVIO = ['NumeroEmpleado', 'NumeroSolicitud'];

  /**
   * Valida que la primera fila del archivo corresponda exactamente al layout oficial
   * descargado (mismas columnas, mismo orden, sin columnas de más). No usa hash:
   * solo compara la estructura de encabezados para confirmar que es el layout válido.
   * @param filaHeaders Primera fila del Excel (encabezados)
   * @returns { valido } y un { motivo } legible cuando no lo es
   */
  private validarEstructuraLayoutReenvio(filaHeaders: any[]): { valido: boolean; motivo?: string } {
    const esperadasOriginal = this.COLUMNAS_LAYOUT_REENVIO;
    const esperadas = esperadasOriginal.map(c => c.toLowerCase());

    // Normalizar encabezados y descartar celdas vacías de relleno al final (padding de Excel)
    const headersRaw = (filaHeaders || []).map((h: any) => (h ?? '').toString().trim());
    while (headersRaw.length && headersRaw[headersRaw.length - 1] === '') {
      headersRaw.pop();
    }
    const headers = headersRaw.map(h => h.toLowerCase());

    if (headers.length === 0) {
      return { valido: false, motivo: 'El archivo no tiene una fila de encabezados.' };
    }

    if (headers.length !== esperadas.length) {
      return {
        valido: false,
        motivo: `El layout debe tener exactamente <b>${esperadasOriginal.length}</b> columna(s)
                 (<b>${esperadasOriginal.join(', ')}</b>) y el archivo tiene <b>${headers.length}</b>.`
      };
    }

    for (let i = 0; i < esperadas.length; i++) {
      if (headers[i] !== esperadas[i]) {
        return {
          valido: false,
          motivo: `La columna <b>${i + 1}</b> debe llamarse <b>${esperadasOriginal[i]}</b>
                   y se encontró <b>${headersRaw[i] || '(vacía)'}</b>.`
        };
      }
    }

    return { valido: true };
  }

  /**
   * Procesa el archivo Excel cargado para reenvío masivo
   * @param event Evento del input file
   */
  async cargarArchivoReenvioMasivo(event: any) {
    const archivo = event.target.files[0];
    if (!archivo) return;

    this.archivoReenvioMasivo = archivo;
    this.registrosReenvioMasivo = [];
    this.descartadosReenvioMasivo = [];
    // Al cargar un layout nuevo se limpian los resultados previos (deshabilita "Descargar Log").
    this.resultadosReenvioMasivo = [];

    try {
      const rows = await readXlsxFile(archivo);

      // Validar PRIMERO que la estructura sea la del layout oficial descargado
      // (mismas columnas, mismo orden). Así se rechaza cualquier archivo que no sea el layout.
      const estructura = this.validarEstructuraLayoutReenvio(rows[0] || []);
      if (!estructura.valido) {
        swal({
          title: 'El archivo no es un layout válido',
          html: `<p>El archivo cargado no corresponde al layout de Reenvío Masivo.</p>
                 <p>${estructura.motivo}</p>
                 <p class="text-info">Descarga el layout correcto desde el botón <b>Descargar Layout</b> y vuelve a intentarlo.</p>`,
          type: 'error',
          confirmButtonText: 'Aceptar'
        });
        this.archivoReenvioMasivo = null;
        if (this.fileInputReenvioMasivo) {
          this.fileInputReenvioMasivo.nativeElement.value = '';
        }
        return;
      }

      // Validar encabezados
      if (rows.length < 2) {
        swal({
          title: 'Error',
          html: 'El archivo debe tener al menos una fila de datos además del encabezado',
          type: 'error',
          confirmButtonText: 'Aceptar'
        });
        // Rechazar el archivo: limpiarlo para que no quede "cargado" sin poder procesarse.
        this.archivoReenvioMasivo = null;
        if (this.fileInputReenvioMasivo) {
          this.fileInputReenvioMasivo.nativeElement.value = '';
        }
        return;
      }

      // Validar límite de registros
      if (rows.length > 501) {
        swal({
          title: 'Error',
          html: 'El archivo no puede tener más de 500 registros',
          type: 'error',
          confirmButtonText: 'Aceptar'
        });
        // Rechazar el archivo: limpiarlo para que no quede "cargado" sin poder procesarse.
        this.archivoReenvioMasivo = null;
        if (this.fileInputReenvioMasivo) {
          this.fileInputReenvioMasivo.nativeElement.value = '';
        }
        return;
      }

      // La estructura ya fue validada arriba: NumeroEmpleado (col 1) y NumeroSolicitud (col 2).
      const headers = (rows[0] || []).map((h: any) => (h ?? '').toString().trim().toLowerCase());
      const idxNumEmp = headers.indexOf('numeroempleado');
      const idxNumSol = headers.indexOf('numerosolicitud');

      const corporativoUsuario = this.identity?.idCorporativo;

      // Procesar filas (omitir encabezado) - registrar descartes para trazabilidad (RN003)
      const registros = [];
      const duplicados = new Set();
      const descartados: { fila: number; motivo: string }[] = [];

      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const numeroFila = i + 1;

        // Fila vacía o sin contenido
        if (!row || row.every((c: any) => c === null || c === undefined || c.toString().trim() === '')) {
          descartados.push({ fila: numeroFila, motivo: 'Fila vacía' });
          continue;
        }

        const numEmp = (row[idxNumEmp] ?? '').toString().trim();
        const numSol = idxNumSol >= 0 ? (row[idxNumSol] ?? '').toString().trim() : '';

        if (!numEmp) {
          descartados.push({ fila: numeroFila, motivo: 'NumeroEmpleado vacío' });
          continue;
        }

        // R2-7: el número de solicitud es obligatorio (aplica al llenado manual del layout).
        if (!numSol) {
          descartados.push({ fila: numeroFila, motivo: 'Número de solicitud vacío (obligatorio)' });
          continue;
        }

        // Validar duplicados por (numeroEmpleado + numeroSolicitud)
        const clave = `${numEmp.toUpperCase()}|${numSol}`;
        if (duplicados.has(clave)) {
          descartados.push({ fila: numeroFila, motivo: `Duplicado (Empleado=${numEmp}${numSol ? ', Solicitud=' + numSol : ''})` });
          continue;
        }
        duplicados.add(clave);

        registros.push({
          fila: numeroFila,
          idEmpresa: 0,                       // sin empresa específica; backend busca en todo el corporativo
          idCorporativo: corporativoUsuario,  // corporativo del usuario logueado (cubre todas sus empresas)
          idSolicitud: 0,                     // se resuelve en backend
          idEmpleado: 0,                      // se resuelve en backend
          numeroEmpleado: numEmp,
          numeroSolicitud: numSol
        });
      }

      this.registrosReenvioMasivo = registros;
      this.descartadosReenvioMasivo = descartados;

      // Todos los registros se asocian al corporativo del usuario logueado.
      // El backend busca el empleado en todas las empresas hijas del corporativo.
      const detalleDescartes = descartados.length > 0
        ? `<p class="text-warning"><b>${descartados.length}</b> fila(s) descartada(s); aparecerán en el log al descargar.</p>`
        : '';
      swal({
        title: 'Archivo cargado',
        html: `<p>Se encontraron <b>${registros.length}</b> registros válidos para procesar.</p>${detalleDescartes}`,
        type: descartados.length > 0 ? 'warning' : 'success',
        confirmButtonText: 'Aceptar'
      });

    } catch (error) {
      console.error('Error al leer archivo:', error);
      swal({
        title: 'Error',
        html: 'No se pudo leer el archivo. Verifica que sea un archivo Excel válido.',
        type: 'error',
        confirmButtonText: 'Aceptar'
      });
      // Rechazar el archivo: limpiarlo para que no quede "cargado" sin poder procesarse.
      this.archivoReenvioMasivo = null;
      if (this.fileInputReenvioMasivo) {
        this.fileInputReenvioMasivo.nativeElement.value = '';
      }
    }
  }

  /**
   * Procesa el reenvío masivo de solicitudes
   */
  async procesarReenvioMasivo() {
    if (this.registrosReenvioMasivo.length === 0) {
      swal({
        title: 'Sin registros',
        html: 'No hay registros para procesar. Carga un archivo válido.',
        type: 'warning',
        confirmButtonText: 'Aceptar'
      });
      return;
    }

    const confirmacion = await swal({
      title: 'Confirmar envío',
      html: `Se enviarán <b>${this.registrosReenvioMasivo.length}</b> notificación(es).`,
      showCancelButton: true,
      confirmButtonText: 'Aceptar',
      cancelButtonText: 'Cancelar',
      allowOutsideClick: false
    });

    if (!confirmacion.value) return;

    this.procesandoReenvioMasivo = true;
    this.resultadosReenvioMasivo = [];
    this.progresoReenvioMasivo = { procesados: 0, total: this.registrosReenvioMasivo.length };

    try {
      const idUsuario = this.fullIdentity?.idUsuario || this.fullIdentity?.id || this.identity.id;

      // CREA25 INC-3: 1) arrancar el lote en background (responde de inmediato con idLote).
      const inicio: any = await this._titularesService.reenviarSolicitudMasivo(
        this.registrosReenvioMasivo, idUsuario, this.token
      );

      if (!inicio || inicio.error || !inicio.idLote) {
        throw new Error(inicio && inicio.mensaje ? inicio.mensaje : 'No se pudo iniciar el reenvío masivo');
      }

      // 2) hacer polling del estado hasta que el lote termine (evita el timeout del gateway con 500).
      const estadoFinal: any = await this.esperarLoteReenvioMasivo(inicio.idLote);

      const res = estadoFinal.resultado || {};
      this.resultadosReenvioMasivo = res.resultados || [];
      this.resumenReenvioMasivo = {
        total: estadoFinal.total != null ? estadoFinal.total : (res.totalProcesados || 0),
        exitosos: estadoFinal.totalExitosos != null ? estadoFinal.totalExitosos : (res.totalExitosos || 0),
        errores: estadoFinal.totalErrores != null ? estadoFinal.totalErrores : (res.totalErrores || 0)
      };

      if (estadoFinal.estado === 'ERROR') {
        swal({
          title: 'Error',
          html: 'El proceso de reenvío masivo terminó con un error general. Descarga el log para revisar el detalle.',
          type: 'error',
          confirmButtonText: 'Aceptar'
        });
      } else {
        const exitosos = this.resumenReenvioMasivo.exitosos;
        const errores = this.resumenReenvioMasivo.errores;
        swal({
          title: errores === 0 ? '¡Enviado!' : 'Envío completado con observaciones',
          html: (errores === 0
            ? `Se enviaron correctamente <b>${exitosos}</b> notificación(es).`
            : `Se enviaron <b>${exitosos}</b> notificación(es) correctamente.<br><b>${errores}</b> con error.`)
            + `<br>Revisa la notificación con los resultados descargando el log.`,
          type: errores === 0 ? 'success' : 'warning',
          confirmButtonText: 'Aceptar'
        });
      }

    } catch (error) {
      console.error('Error en reenvío masivo:', error);
      swal({
        title: 'Error',
        html: 'Ocurrió un error al procesar el reenvío masivo',
        type: 'error',
        confirmButtonText: 'Aceptar'
      });
    } finally {
      this.procesandoReenvioMasivo = false;
    }
  }

  /**
   * CREA25 INC-3: hace polling del estado del lote hasta que termine (o falle). Un poll
   * fallido individual no aborta (el lote sigue corriendo en el server). Devuelve el último
   * estado, que al terminar incluye `resultado` con el detalle por registro para el log.
   */
  private async esperarLoteReenvioMasivo(idLote: number): Promise<any> {
    const INTERVALO_MS = 2500;
    const MAX_INTENTOS = 480; // ~20 min de guarda
    let intentos = 0;

    while (intentos < MAX_INTENTOS) {
      await new Promise(resolve => setTimeout(resolve, INTERVALO_MS));
      intentos++;

      let estado: any;
      try {
        estado = await this._titularesService.estadoReenvioMasivo(idLote, this.token);
      } catch (e) {
        // Un poll fallido no aborta el proceso: reintentar en el siguiente ciclo.
        continue;
      }

      if (!estado) { continue; }

      this.progresoReenvioMasivo = {
        procesados: estado.procesados != null ? estado.procesados : this.progresoReenvioMasivo.procesados,
        total: estado.total != null ? estado.total : this.progresoReenvioMasivo.total
      };

      if (estado.estado === 'NO_ENCONTRADO') {
        throw new Error('El lote de reenvío no se encontró en el servidor');
      }
      if (estado.estado && estado.estado !== 'EN_PROCESO') {
        return estado;
      }
    }

    throw new Error('El reenvío masivo excedió el tiempo de espera');
  }

  /**
   * Descarga el log de resultados del reenvío masivo
   */
  descargarLogReenvio() {
    if (this.resultadosReenvioMasivo.length === 0 && this.descartadosReenvioMasivo.length === 0) {
      swal({
        title: 'Sin resultados',
        html: 'No hay resultados para descargar',
        type: 'warning',
        confirmButtonText: 'Aceptar'
      });
      return;
    }

    let contenido = '=== LOG DE REENVIO MASIVO DE SOLICITUDES ===\n';
    contenido += `Fecha: ${new Date().toLocaleString()}\n`;
    contenido += `Procesados: ${this.resumenReenvioMasivo.total} | Exitosos: ${this.resumenReenvioMasivo.exitosos} | Errores: ${this.resumenReenvioMasivo.errores}\n`;
    contenido += `Descartados (no enviados al backend): ${this.descartadosReenvioMasivo.length}\n`;
    contenido += '===============================================\n\n';

    if (this.descartadosReenvioMasivo.length > 0) {
      contenido += '--- FILAS DESCARTADAS (no se enviaron al backend) ---\n';
      this.descartadosReenvioMasivo.forEach(d => {
        contenido += `Fila ${d.fila}: ${d.motivo}\n`;
      });
      contenido += '\n';
    }

    if (this.resultadosReenvioMasivo.length > 0) {
      contenido += '--- FILAS PROCESADAS ---\n';
      this.resultadosReenvioMasivo.forEach(item => {
        contenido += `Fila ${item.fila}: [${item.resultado}] `;
        contenido += `Empresa: ${item.idEmpresa}, Solicitud: ${item.idSolicitud}, Empleado: ${item.idEmpleado}\n`;
        contenido += `  Mensaje: ${item.mensaje}\n`;
        if (item.correoEnviado) {
          contenido += `  Correo: ${item.correoEnviado}\n`;
        }
        contenido += '\n';
      });
    }

    const blob = new Blob([contenido], { type: 'text/plain;charset=utf-8' });
    FileSaver.saveAs(blob, `log-reenvio-masivo-${Date.now()}.txt`);
  }

  /**
   * Verifica si una solicitud puede ser reenviada
   * @param index Índice de la solicitud
   */
  puedeReenviar(index: any): boolean {
    const solicitud = this.listaSolicitudesEnc[index];
    const estatus = solicitud['SODetalleEstatus'];
    return estatus === 'Autorizada' || estatus === 'Por Autorizar';
  }

  /**
   * True si la búsqueda actual incluye al menos una solicitud reenviable (Autorizada/Por Autorizar).
   * Se usa en el HTML para mostrar los checkboxes del grid incluso cuando los botones
   * Aceptar/Rechazar/Cancelar están ocultos por configuración (parámetro ocultaBtnSolicitudes,
   * caso Costco y otras empresas), ya que el reenvío es independiente de esos permisos.
   */
  get tieneAlgunaReenviable(): boolean {
    if (!this.listaSolicitudesEnc) return false;
    for (const s of this.listaSolicitudesEnc) {
      const e = s['SODetalleEstatus'];
      if (e === 'Autorizada' || e === 'Por Autorizar') return true;
    }
    return false;
  }

  /**
   * Devuelve los registros del grid seleccionados via checkbox que son aptos
   * para reenvío (estatus Autorizada o Por Autorizar). Cruza listaSolicitudes
   * (array de SOIdSolicitud marcados) con listaSolicitudesEnc para sacar los
   * IDs internos requeridos por el endpoint masivo.
   */
  obtenerSeleccionParaReenvio(): { fila: number; idEmpresa: number; idCorporativo: number; idSolicitud: number; idEmpleado: number; numeroEmpleado: string; numeroSolicitud: string }[] {
    const seleccion = [];
    const corporativoUsuario = this.identity?.idCorporativo || 0;
    let filaIdx = 1;
    for (const enc of this.listaSolicitudesEnc) {
      filaIdx++;
      const sol = enc['SOIdSolicitud'];
      const estatus = enc['SODetalleEstatus'];
      if (!this.listaSolicitudes.includes(sol)) continue;
      if (estatus !== 'Autorizada' && estatus !== 'Por Autorizar') continue;
      seleccion.push({
        fila: filaIdx,
        idEmpresa: parseInt(enc['Empresa']?.toString() || '0'),
        idCorporativo: corporativoUsuario,
        idSolicitud: parseInt(sol?.toString() || '0'),
        idEmpleado: 0, // el backend lo auto-resuelve desde idSolicitud (obtenerIdEmpleado). El grid no trae SOIdEmpleado, solo NumEmpleado (string)
        numeroEmpleado: (enc['NumEmpleado'] ?? enc['EMNumeroEmpleado'] ?? '').toString().trim(),
        numeroSolicitud: (enc['SONumeroSolicitud'] ?? '').toString().trim()
      });
    }
    return seleccion;
  }

  /**
   * Cuenta los seleccionados aptos para reenvío - usado en el HTML para el badge del botón.
   */
  get totalSeleccionadasParaReenvio(): number {
    return this.obtenerSeleccionParaReenvio().length;
  }

  private validteBtnCancelRequest(): void{
    this._beneficiarioService.getStatusBtnCancelRequest(this.identity.idEmpresa)
      .then( (response: boolean) => {
        this.isActiveBtnCancelRequest = response;
      })
      .catch( error => {
        console.log("Error validteBtnCancelRequest(): ", error);
      });
  }

  public async obtenerEmpresas() {
    try {
      const empresas = [];
      const response: any = await this._empresaService.getComboLogin(this.identity.idCorporativo, this.token);
      if (response) {
        response.forEach(element => empresas.push(element.emidEmpresa));
      }
      this.crearArbolEmpresas(empresas);
    } catch (error) { }
  }

  /* Arbol: Empresa - Perfil */
  public async crearArbolEmpresas(empresas: any[]) {
    try {
      const response: any = await this._BitacoraService.getEmpPerfil(empresas, this.token);
      if (response != null && response != undefined && response.length > 0) {
        const datos = [];
        response.forEach(empresa => {
          const hojas = [];
          empresa.perfiles.forEach(perfil => {
            const hoja = { 'id': perfil.idPerfil, 'name': perfil.nombrePerfil.toUpperCase(), 'child': null, 'selected': false };
            hojas.push(hoja);
          });
          const rama = { 'id': empresa.idEmpresa, 'name': empresa.nombreEmpresa.toUpperCase(), 'child': hojas, 'selected': false };
          datos.push(rama);
          this.parametrosBusqueda.idEmpresas.push(empresa.idEmpresa);
        });
        datos.forEach(padre => padre.child.forEach(hijo => Object.assign(hijo, { 'selected': true })));

        const hojasPadre = { 'id': 0, 'name': 'TODOS', 'child': datos, 'selected': false, 'expandable': false };
        this.arbol = [];
        this.arbol.push(hojasPadre);
      }
    } catch (error) { }
  }

  validarEmpresasAsignar() {
    this.arbol.forEach(padre => {
      padre.child.forEach(empresa => {
        empresa.child.forEach(perfil => {
          if (this.parametrosBusqueda.perfiles.includes(perfil.id) && !this.parametrosBusqueda.idEmpresas.includes(empresa.id)) {
            this.parametrosBusqueda.idEmpresas.push(empresa.id);
          }
        });
      });
    });
  }

  obtenerEmpresasPerfilesSeleccionados() {
    this.parametrosBusqueda.idEmpresas = [];
    this.parametrosBusqueda.perfiles = [];
    this.seleccionArbol.forEach(entry => {
      switch (entry.level) {
        case 1:
          this.parametrosBusqueda.idEmpresas.push(entry.id);
          break;
        case 2:
          this.parametrosBusqueda.perfiles.push(entry.id);
          break;
        default:
          break;
      }
    });
    this.validarEmpresasAsignar();
  }

  public seleccionEmpresa(event) {
    this.seleccionArbol = event;
    this.parametrosBusqueda.idEmpresas = [];
    this.obtenerEmpresasPerfilesSeleccionados();
    if (this.parametrosBusqueda.idEmpresas.length == 0) { // Valida lista empresas
      this.errorRep.empresas = true;
      this.validRep.empresas = false;
    } else {
      this.errorRep.empresas = false;
      this.validRep.empresas = true;
    }
    if (this.parametrosBusqueda.perfiles.length == 0) { // Valida lista de perfiles
      this.errorRep.perfiles = true;
      this.validRep.perfiles = false;
    } else {
      this.errorRep.perfiles = false;
      this.validRep.perfiles = true;
    }
  }

  public inicializarFormulario(){
    this.parametrosBusqueda = {
      idEmpresas: [],
      perfiles: [],
      idAtributo1: 'EMNumeroEmpleado',
      idTipoOperador1: 'contiene',
      parametroBusqueda1: '',
      idTipoOperadorAvanzado: 'and',
      idAtributo2: 'EMNumeroEmpleado',
      idTipoOperador2: 'contiene',
      parametroBusqueda2: '',
      idEstatus: ['Por Autorizar'],
      idVigencia: 0,
      BusquedaAvanzada:0
    };
  }

  public reiniciarFormulario(){
    this.esBusquedaAvanzada = false;
    this.parametrosBusqueda.idAtributo1 =  'EMNumeroEmpleado';
    this.parametrosBusqueda.idTipoOperador1 =  'contiene';
    this.parametrosBusqueda.parametroBusqueda1 =  '';
    this.parametrosBusqueda.idTipoOperadorAvanzado =  'and';
    this.parametrosBusqueda.idAtributo2 =  'EMNumeroEmpleado';
    this.parametrosBusqueda.idTipoOperador2 =  'contiene';
    this.parametrosBusqueda.parametroBusqueda2 =  '';
    this.parametrosBusqueda.idEstatus =  ['Por Autorizar'];
    this.parametrosBusqueda.idVigencia =  0;
    this.parametrosBusqueda.BusquedaAvanzada = 0;

  }

  mostrarModalReporteSolicitud(){
    this.inicializarFormSolicitud();
    $('#modal-consultar-logs').modal('show');
  }

  mostrarModalReactivacionesMasivas(){
    this.limpiarTablaSolicitudes();
    $('#modal-reactivacion').modal('show');
  }

  mostrarModalConsultaLog(){
    this.inicializarFormSolicitudHistorico();
    $('#modal-consulta-log').modal('show');
  }

  // Inicializar formulario de modal
  inicializarFormSolicitud(){
    this.itemsEmpresas = [];
    this.empresasSeleccionadasReportes = [];
    // Empresas default
    this.empresas.forEach(xEmpresa => {
      this.itemsEmpresas.push({value: xEmpresa.IdEmpresa, label: xEmpresa.NomEmpresa});
      this.empresasSeleccionadasReportes.push(xEmpresa.IdEmpresa);
    });
    // Asignar fecha inicio y fin por default 
    let actualFecha = new Date();
    let fechaFindDef = actualFecha.setDate(actualFecha.getDate() + 1);
    let fechaInicioDef = actualFecha.setDate(actualFecha.getDate() - 2);
    this.busqueda.fechaInicio = this.generarFechaTexto(new Date(fechaInicioDef));
    this.busqueda.fechaFin = this.generarFechaTexto(new Date(fechaFindDef));

    this.fechaInicioMax =this.generarFechaTexto(new Date(fechaFindDef));
    this.fechaFinMin =this.generarFechaTexto(new Date(fechaInicioDef));
    this.generoConsulta = false;
  }

  // Inicializar formulario de modal historico
  inicializarFormSolicitudHistorico(){
    let idEmpresaDefault = 0;
    if(this.empresas.length > 0){
      // Buscar empresa del usuario
      let selectEmpresa = this.identity.idEmpresa;
      let empresaEncontrada = this.empresas.find(valEmpresa => valEmpresa.IdEmpresa === selectEmpresa);
      if(empresaEncontrada){
        idEmpresaDefault = selectEmpresa;
      }else{
        idEmpresaDefault = this.empresas[0].IdEmpresa;
      }
    }
    this.busquedaLog.idEmpresa = idEmpresaDefault;
    // Asignar fecha inicio y fin por default 
    let actualFecha = new Date();
    let fechaFindDef = actualFecha.setDate(actualFecha.getDate() + 1);
    let fechaInicioDef = actualFecha.setDate(actualFecha.getDate() - 2);
    this.busquedaLog.fechaInicio = this.generarFechaTexto(new Date(fechaInicioDef));
    this.busquedaLog.fechaFin = this.generarFechaTexto(new Date(fechaFindDef));

    this.fechaInicioMaxLog =this.generarFechaTexto(new Date(fechaFindDef));
    this.fechaFinMinLog =this.generarFechaTexto(new Date(fechaInicioDef));
    this.generoConsultaLog = false;
  }

  generarFechaTexto(fecha: Date){
    const year = fecha.getFullYear();
    const month = String(fecha.getMonth() + 1).padStart(2, '0');
    const day = String(fecha.getDate()).padStart(2, '0');

    const hours = String(fecha.getHours()).padStart(2, '0');
    const minutes = String(fecha.getMinutes()).padStart(2, '0');
    const seconds = String(fecha.getSeconds()).padStart(2, '0');
    let timeStampString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    return timeStampString;
  }

  actualizarLitmitesFecha(){
    this.fechaFinMin = this.formatFecha(this.busqueda.fechaInicio);
    this.fechaInicioMax = this.formatFecha(this.busqueda.fechaFin);
  }
  actualizarLitmitesFechaLog(){
    this.fechaFinMinLog = this.formatFecha(this.busquedaLog.fechaInicio);
    this.fechaInicioMaxLog = this.formatFecha(this.busquedaLog.fechaFin);
  }

  formatFecha(fechaData: string) {
    let now: Date;
    if(fechaData === ''){
      now = new Date();
    }else{
      now = new Date(fechaData);
    }

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');

    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    let timeStampString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    return timeStampString;
  }

  formatFromDate(fechaData: Date) {
    let now: Date;
    if(fechaData === null){
      now = new Date();
    }else{
      now = fechaData;
    }

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');

    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    let timeStampString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    return timeStampString;
  }

  public consultaReporteSol(){
    this.consultaReporteSinDatos = false;
    this.generoConsulta = true;
    this.busqueda.IdAdministrador = this.identity.id;
    if(this.empresasSeleccionadasReportes != null && this.empresasSeleccionadasReportes.length != 0){
      this.busqueda.fechaInicio = this.formatFecha(this.busqueda.fechaInicio);
      this.busqueda.fechaFin = this.formatFecha(this.busqueda.fechaFin);
      this.busqueda.idEmpresa = this.empresasSeleccionadasReportes.join(",");
      this.busqueda.idVigencia = this.vigencia;
      this._cifrasControlService.gerReporteSolicitudReactivar(this.busqueda, this.token).then(
        (result) => {
          if(result && result != undefined){
          this.tablaSolicitudes = result;
          this.datosR = this.tablaSolicitudes;
          this.collectionSizeR = this.datosR.length;
          this.consultaReporteSinDatos = this.collectionSizeR == 0 ? true : false;
        } else {
          this.datosR = this.tablaSolicitudes;
          this.consultaReporteSinDatos = true;
          this.pageR = 1;
          this.pageSizeR = 5;
          this.collectionSizeR = 0;
        }
      });
    }
  }

  descargarReporteSolicitud(){
      const nombreReporte = this.colocarFechaAlNombre(`Reporte_Solicitud_`);
      let keys = ['Id Empresa', 'Empresa', 'Id Solicitud', 'Estatus solicitud', 'Fecha estatus', 'Id Empleado', 'Numero Empleado', 'Nombre', 'Segundo nombre', 'Apellido paterno', 'Apellido materno'];
      if(this.tablaSolicitudes.length > 0){
        let data = this.tablaSolicitudes.map(obj => Object.values(obj));
        try{
          const workbook = this._excelService.reporteExcelFechaCol(keys, data, nombreReporte, 4);
          workbook.xlsx.writeBuffer().then((archivo: any) => {
            const blob = new Blob([archivo], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            FileSaver.saveAs(blob, nombreReporte);
          });
        }catch(e){
          /// console.log("Error: ", e);
          swal({
          html: '<small style="color: grey; text-align: justify;">Ocurrió un error al generar el reporte, intente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
          onOpen: () => swal.hideLoading()
          });
      }
      }else{
        swal({
          html: '<small style="color: grey; text-align: justify;">No se econtraron resultados para generar el reporte, intente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
          onOpen: () => swal.hideLoading()
        });
      } 
    }

    colocarFechaAlNombre(nombreArch: any) {
    const f = new Date();
    let nombre = `${nombreArch}${f.getFullYear()}`;
    let mes;
    let m;
    m = (f.getMonth() < 10) ? `0${f.getMonth()}` : f.getMonth();
    mes = parseInt(m) + 1;
    nombre += (f.getMonth() < 10) ? `0${mes}` : mes;
    nombre += (f.getDate() < 10) ? `0${f.getDate()}` : f.getDate();
    nombre += (f.getHours() < 10) ? `0${f.getHours()}` : f.getHours();
    nombre += (f.getMinutes() < 10) ? `0${f.getMinutes()}` : f.getMinutes();
    nombre += (f.getSeconds() < 10) ? `0${f.getSeconds()}` : f.getSeconds();
    nombre += '.xlsx';
    return nombre;
  }

  // Metodos de reactivacion

  activarCargaArchivo(){
    $('#input').click();
  }

  validaCampoArchivo() {
    this.mostrarVistaPreviaCarga = false;
    this.permitirCargaMasiva = false;
    if ($('#input')[0].files.length > 0) {
      let nameForFile = $('#input')[0].files[0].name;
      nameForFile = nameForFile.length > 35 ? nameForFile.substring(0, 33) + '...' : nameForFile;
      $('#selectedFileName').text(nameForFile);
      if(nameForFile && nameForFile != ''){
        swal({
          title: '',
          html: `<small style="color: grey; text-align: justify;">Cargando documento.</small>`,
          type: 'info',
          onOpen: () => swal.showLoading(),
          allowEscapeKey: false,
          allowOutsideClick: false
        });
        this.validaDocumentoCargado();
      }
    }else{
      $('#selectedFileName').text("Ningún archivo seleccionado.");
      this.mostrarVistaPreviaCarga = false;
      this.mensajesValidaciones = [];
      this.ecabezadosDocumentoCarga = [];
      this.filasDocumentoCarga = [];
    }
  }

  validaDocumentoCargado(){
    if($('#input')[0].files.length > 0){
      const archivo = this.inputFilePicker.files[0];      
      // Lista de MIME types válidos
      const validMimeTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // Excel .xlsx
        'application/vnd.ms-excel', // Excel .xls
        'text/csv', // CSV
        'application/csv', // CSV (algunos navegadores)
      ];
      if (!validMimeTypes.includes(archivo.type)) {
        $('#selectedFileName').text("Ningún archivo seleccionado.");
        swal({
          title: 'Error',
          html: `<small style="color: grey; text-align: justify;">Por favor selecciona un archivo Excel (.xlsx, .xls).</small>`,
          type: 'error',
          confirmButtonText: 'Aceptar',
          onOpen: () => swal.hideLoading()
        });
        return;
      }
      // Leer primer hoja
      readXlsxFile(archivo, { transformData(data) {
        // Remover filas vacias
        return data.filter(row => row.filter(column => column !== null).length > 0);
        }
      }).then((rows) => {
        this.filasDocumentoCarga = [...rows];
        if(this.filasDocumentoCarga.length > 1){
          this.ecabezadosDocumentoCarga = this.filasDocumentoCarga.splice(0,1); // Elimina la primera del encabezado
          let erroresValidacion = [];
          // Validar encabezados
          erroresValidacion = this.validaPlantillaBorrado(this.ecabezadosDocumentoCarga[0]);
          if(erroresValidacion.length > 0){
            $('#selectedFileName').text("Ningún archivo seleccionado.");
            swal({
              title: '¡Error!',
              html: `<small style="color: grey; text-align: justify;">El documento no cumple con la estructura requerida, recuerda usar el archivo generado por el reporte de solicitudes.</small>`,
              type: 'error',
              confirmButtonText: 'Aceptar',
              onOpen: () => swal.hideLoading()
            });
            return;
          }
          // Validar renglones
          this.validaRenglonesDocumento(this.filasDocumentoCarga);
          if(!this.permitirCargaMasiva){
            this.permitirCargaMasiva = false;
            swal({
              title: '¡Error!',
              html: `<small style="color: grey; text-align: justify;">Se encontraron errores, resuelvelos antes de realizar la carga.</small>`,
              type: 'error',
              confirmButtonText: 'Aceptar',
              onOpen: () => swal.hideLoading()
            });
            this.mostrarVistaPreviaCarga = true;
          }else{
            this.mostrarVistaPreviaCarga = true;
            swal({
              title: 'Cargado',
              html: `<small style="color: grey; text-align: justify;">Documento procesado con éxito, haga click en <b>Reactivar solicitudes</b> para realizar la carga.</small>`,
              type: 'info',
              confirmButtonText: 'Aceptar',
              onOpen: () => swal.hideLoading()
            });
          }
        }else{
          $('#selectedFileName').text("Ningún archivo seleccionado.");
          swal({
            title: '¡Error!',
            html: `<small style="color: grey; text-align: justify;">Carga un documento con registros validos.</small>`,
            type: 'error',
            confirmButtonText: 'Aceptar',
            onOpen: () => swal.hideLoading()
          });
        }
      },
      (error) => {
        $('#selectedFileName').text("Ningún archivo seleccionado.");
        swal({
            title: 'Error',
            html: `<small style="color: grey; text-align: justify;">Ocurrió un error, el archivo puede estar dañado, intenta con otro.</small>`,
            type: 'error',
            confirmButtonText: 'Aceptar',
            onOpen: () => swal.hideLoading()
          });
        return;
      });
    }else{
      // Mostrar mensaje de que falta documento
      $('#selectedFileName').text("Ningún archivo seleccionado.");
      swal({
        title: '¡Error!',
        html: `<small style="color: grey; text-align: justify;">Seleccione un archivo.</small>`,
        type: 'error',
        confirmButtonText: 'Aceptar',
        onOpen: () => swal.hideLoading()
      });
    }
  }
  
  validaRenglonesDocumento(renglonesDocumento){
    this.mensajesValidaciones = [];
    this.permitirCargaMasiva = true;
    if(renglonesDocumento != null && renglonesDocumento != undefined){
      for(let row=0; row<renglonesDocumento.length;row++){
        let mensajeError = '';
        // Id Empresa
        if(renglonesDocumento[row][0] == null || !Number.isInteger(Number(renglonesDocumento[row][0]))){
          mensajeError = mensajeError + ' El Id de Empresa debe ser de tipo número entero.';
          this.permitirCargaMasiva = false;
        }
        // Id Solicitud
        if(renglonesDocumento[row][2] == null || !Number.isInteger(Number(renglonesDocumento[row][2]))){
          mensajeError = mensajeError + ' El Id de Solicitud debe ser de tipo número entero.';
          this.permitirCargaMasiva = false;
        }
        // Id empleado
        if(renglonesDocumento[row][5] == null || !Number.isInteger(Number(renglonesDocumento[row][5]))){
          mensajeError = mensajeError + ' El Id de Empleado debe ser de tipo número entero.';
          this.permitirCargaMasiva = false;
        }
        // Numero de empleado
        if(renglonesDocumento[row][6] == null || renglonesDocumento[row][6] == undefined || renglonesDocumento[row][6] === ''){
          mensajeError = mensajeError + ' El número de empleado no puede estar vacío.';
          this.permitirCargaMasiva = false;
        }
        if(mensajeError.trim() != ''){
          this.mensajesValidaciones.push({
            "row": row + 1, 
            "idEmpresa": renglonesDocumento[row][0],
            "empresa": renglonesDocumento[row][1],
            "idSolicitud": renglonesDocumento[row][2],
            "idEmpleado": renglonesDocumento[row][5],
            "empleado": renglonesDocumento[row][6],
            "nombreEmpleado": renglonesDocumento[row][7],
            "mensaje": mensajeError
          });
        }
      }
    }
  }

  validaPlantillaBorrado(encabezadosCol){
    let mensajeErrorPlantilla = [];
    let nombresEncabezados = [
      {"nombre": 'Id Empresa',"indice": 0}
      ,{"nombre": 'Empresa', "indice": 1}
      ,{"nombre": 'Id Solicitud', "indice": 2}
      ,{"nombre": 'Estatus solicitud', "indice": 3}
      ,{"nombre": 'Fecha estatus', "indice": 4}
      ,{"nombre": 'Id Empleado', "indice": 5}
      ,{"nombre": 'Numero Empleado', "indice": 6}
      ,{"nombre": 'Nombre', "indice": 7}
    ];
    if(encabezadosCol != null && encabezadosCol != undefined){
      if(encabezadosCol.length === 11){
        for(let i=0; i<nombresEncabezados.length;i++){
          let indexCol = encabezadosCol.indexOf(nombresEncabezados[i].nombre);
          if(indexCol < 0 || indexCol != nombresEncabezados[i].indice){
            mensajeErrorPlantilla.push(`No se pudo determinar la conlumna ${nombresEncabezados[i].nombre}.`);
          }
        }
      }else{
        mensajeErrorPlantilla.push("El documento no cumple con las columnas necesarias.");
      }
    }else{
      mensajeErrorPlantilla.push("El documento no cumple con las columnas necesarias.");
    }
    return mensajeErrorPlantilla;
  }

   async iniciaReactivaciones(){
      swal({
        title: 'Cargando',
        html: `<small style="color: grey; text-align: justify;">Procesando carga.</small>`,
        type: 'info',
        onOpen: () => swal.showLoading(),
        allowEscapeKey: false,
        allowOutsideClick: false
      });
      let listaSolicitudes = [];
      let empresa = this.identity.idEmpresa;
      let usuarioDel = this.identity.id;
      if(this.filasDocumentoCarga.length > 0){
        for(let i=0; i<this.filasDocumentoCarga.length; i++){
          listaSolicitudes.push(
            {
              "idEmpresa": this.filasDocumentoCarga[i][0],
              "idSolicitud": this.filasDocumentoCarga[i][2],
              "idEmpleado": this.filasDocumentoCarga[i][5],
              "numeroEmpleado": this.filasDocumentoCarga[i][6],
            });
        }
        await this.ejecutaReactivacionSolicitud(empresa, usuarioDel, listaSolicitudes);
      }else{
        swal({
          title: 'Error',
          html: '<small style="color: grey; text-align: justify;">No se han cargado datos, compruebe su documento.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
          onOpen: () => swal.hideLoading()
        });
      }
  }

    async ejecutaReactivacionSolicitud(empresa, usuarioDel, listaSolicitudes){
      let resultBorrado: any = [];
      await this._cifrasControlService.reactivacionMasivaSolicitud(empresa, usuarioDel, listaSolicitudes, this.token).then(response => {
        if (response) {
            resultBorrado = response;
            let total_correctas = 0;
            let total_incorrectas = 0;
            let mensajesCodigoError = [];
          for(let i=0;i<resultBorrado.length; i++){
            if(resultBorrado[i].codigo === 0){
              total_incorrectas++;
              mensajesCodigoError.push(resultBorrado[i].mensaje);
            }else{
              total_correctas++;
            }
          }
          let mensajeUnico = [...new Set(mensajesCodigoError)];
          let leyendaMensajes = '';
          if(mensajeUnico.length > 0){
            leyendaMensajes = 'Motivos de error <br>';
            mensajeUnico.forEach(value => {
              leyendaMensajes = leyendaMensajes + value + ' <br>'
            });
          }
          swal({
            title: 'Completado',
            html: `<small style="color: grey; text-align: justify;">Correctas: ${total_correctas} <br>Incorrectas: ${total_incorrectas}<br>Para más detalles revise el apartado <b>Consulta histórico solicitudes</b></small>`,
            confirmButtonText: 'Aceptar',
            type: 'success'
          }).then((result) => {
            swal.hideLoading();
          });
        }
      }).catch( err => {
        swal({
          title: 'Error',
          html: '<small style="color: grey; text-align: justify;">Error al procesar la solicitud, intente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
      });
    }

  public limpiarTablaSolicitudes(){
    $('#selectedFileName').text("Ningún archivo seleccionado.");
    this.mostrarVistaPreviaCarga = false;
    this.permitirCargaMasiva = false;
    this.mensajesValidaciones = [];
    this.ecabezadosDocumentoCarga = [];
    this.filasDocumentoCarga = [];
    $('#input').value = null;
  }

  /*consulta de documentos */
  async consultaLog(){
    this.mostrarDatosTabla = true;
    this.pageR = 1;
    this.pageSizeR = 5;
    // Datos prueba
    if (this.validarConsulta()) {
      this.generoConsultaLog = true;
      this.tablaDocsReporte = [];
      this.busquedaLog.fechaInicio = this.formatFromDate(new Date(this.busquedaLog.fechaInicio));
      this.busquedaLog.fechaFin = this.formatFromDate(new Date(this.busquedaLog.fechaFin));
      await this._cifrasControlService.getLogReactivacionSolicitud(this.busquedaLog, this.token).then(response => {
        if (response) {
          this.tablaDocsReporte = response;
          this.datosR = this.tablaDocsReporte;
          this.collectionSizeR = this.datosR.length;
          this.consultaLogSinDatos = this.collectionSizeR == 0 ? true : false;
        } else {
          this.datosR = this.tablaDocsReporte;
          this.consultaLogSinDatos = true;
          this.pageR = 1;
          this.pageSizeR = 5;
          this.collectionSizeR = 0;
        }
      }).catch( err => console.log(err));
    } else {
      this.mostrarDatosTablaLog = false;
      this.consultaLogSinDatos = false;
    }
  }

  validarConsulta() {
    if(this.busquedaLog){
      return true;
    }else {return false;}
  }

  descargarHistoricoLog(){
    const nombreReporte = this.colocarFechaAlNombre(`Histórico_Reactivación_Solicitud_`);
    let keys = ['Fecha', 'Empresa', 'ID Solicitud', 'Numero Empleado', 'Resultado', 'Mensaje', 'Usuario'];
    if(this.tablaDocsReporte.length > 0){
      let data = this.tablaDocsReporte.map(obj => [obj.fecha, obj.nombreEmpresa, obj.idSolicitud, obj.numeroEmpleado, obj.estatus, obj.mensaje, obj.nombreUsuario]);
      try{
        const workbook = this._excelService.crearArchivoExcelColFecha(keys, data, nombreReporte);
        workbook.xlsx.writeBuffer().then((archivo: any) => {
          const blob = new Blob([archivo], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          FileSaver.saveAs(blob, nombreReporte);
        });
      }catch(e){
        swal({
        html: '<small style="color: grey; text-align: justify;">Ocurrió un error al generar el reporte, intente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
        onOpen: () => swal.hideLoading()
        });
    }
    }else{
      swal({
        html: '<small style="color: grey; text-align: justify;">No se econtraron resultados para generar el reporte, intente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
        onOpen: () => swal.hideLoading()
      });
    } 
  }

  // Alterna la visibilidad de la sección de reactivacion masiva de solicitudes
  toggleRreactivacionMasiva() {
    this.mostrarReactivacionMasiva = !this.mostrarReactivacionMasiva;
  }

}
export interface IBusquedaRequest {
    idEmpresas: number[],
    perfiles: number[],
    idAtributo1: string,
    idTipoOperador1: string,
    parametroBusqueda1: string,
    BusquedaAvanzada: number,
    idTipoOperadorAvanzado: string,
    idAtributo2: string,
    idTipoOperador2: string,
    parametroBusqueda2: string,
    idEstatus: any[],
    idVigencia: number
}
