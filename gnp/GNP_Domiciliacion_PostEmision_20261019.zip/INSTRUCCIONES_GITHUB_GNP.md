# Cambio GNP: domiciliacion posterior a la emision

## 1. Crear la rama

```powershell
git switch -c feature/gnp-domiciliacion-post-emision
```

Si la rama ya existe:

```powershell
git switch feature/gnp-domiciliacion-post-emision
```

## 2. Revisar y agregar solamente los archivos del cambio

```powershell
git status --short

git add -- `
  ConfiguracionDomiciliacionGNP.sql `
  INSTRUCCIONES_GITHUB_GNP.md `
  LocktonModel/LocktonModel.csproj `
  LocktonModel/IdentityModels.cs `
  LocktonModel/db/ConfiguracionDomiciliacionGNP.cs `
  LocktonModel/db/Convenio.cs `
  LocktonModel/db/LocktonOneDB.cs `
  LocktonModel/VModels/EmisionPoliza.cs `
  LocktonModel/VModels/VFormaDePago.cs `
  LocktonOneWeb/Views/Convenio/FormaPago.cshtml `
  LocktonOneWeb/Controllers/Convenio/ConvenioController.cs `
  LocktonOneWeb/Controllers/Cotizaciones/CotizacionController.cs `
  LocktonServicios/Aseguradoras/GNPInfoService.cs

git diff --cached --stat
git diff --cached
```

## 3. Crear el commit y subir la rama

```powershell
git commit -m "feat(gnp): agrega domiciliacion posterior a la emision"
git push -u origin feature/gnp-domiciliacion-post-emision
```

## 4. Crear el pull request con GitHub CLI

Reemplazar `<rama-destino>` por la rama usada por el equipo, por ejemplo `development`.

```powershell
gh pr create `
  --base <rama-destino> `
  --head feature/gnp-domiciliacion-post-emision `
  --title "GNP - Domiciliacion posterior a la emision" `
  --body "Agrega configuracion por convenio GNP para emitir como intermediario e instalar los datos bancarios despues de una emision exitosa. La emision masiva conserva su flujo actual."
```

## 5. Instalar la tabla en la base local de pruebas

```powershell
sqlcmd -S "(localdb)\MSSQLLocalDB" -d "LocktonOne_DB" -b -i ".\ConfiguracionDomiciliacionGNP.sql"
```

Para otros ambientes se debe sustituir el servidor y la base de datos, y ejecutar el script antes de publicar la aplicacion.

