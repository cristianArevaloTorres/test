namespace LocktonModel.db
{
	using Newtonsoft.Json;
	using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Razor.Tokenizer.Symbols;

    [Table("Convenio")]
    public partial class Convenio
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Convenio()
        {
            CatFormaPago = new HashSet<CatFormaPago>();
            CatTipoContenido = new HashSet<CatTipoContenido>();
            ConfigWS = new HashSet<ConfigWS>();
            EmpresaConvenio = new HashSet<EmpresaConvenio>();
            PaqueteConvenio = new HashSet<PaqueteConvenio>();
            Poliza = new HashSet<Poliza>();
            CoberturasCondicionesEspeciales = new HashSet<CoberturasCondicionesEspeciales>();
            TipoModificaciones = new List<TIPOMODIFICACION_SELECT_Convenio>();

        }

        public int Id { get; set; }

        public int IdEmpresa { get; set; }

        #region 1.- Configuracion servicio aseguradoras
        [Required]
        public string CaratulaPoliza { get; set; }

        [DataType(DataType.DateTime)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [Required]
        public DateTime InicioVigencia { get; set; }

        [DataType(DataType.DateTime)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [Required]
        public DateTime FinVigencia { get; set; }
        public int IdAseguradora { get; set; }

        public string RamoVehiculo { get; set; }
        public string UsoVehiculoOtros {  get; set; }
        public int IdSubRamoVehiculo { get; set; }
        public int IdCatUsoVehiculo { get; set; }

        public int? IdCatTipoContratante { get; set; }
        public int IdCatTipoVigencia { get; set; }
        public int IdCatTipoConvenio { get; set; }
        /// <summary>
        /// Actualmente solo para inbursa, determina la tarifa a consultar en cotizacion
        /// </summary>
        public int? IdTarifa { get; set; }
        [ForeignKey("IdCatTipoContratante")]
        public CatTipoContratante CatTipoContratante { get; set; }
        #endregion

        #region 2.- Configuracion paquetes y coberturas
        [NotMapped]
        public string CapturaJSON { get; set; }

        //public List<VRamoCoberturas> ListaRamoCoberturas { get; set; };
        #endregion

        #region 3.- Parametros de cotizacion

        public string Tarifa { get; set; }

        public string Usuario { get; set; }

        public string Contrasena { get; set; }

        public string CodigoPromocion { get; set; }

        public bool DerechosPrimerRecibo { get; set; }

        public string DerechosPoliza { get; set; }

        public string SumaAsegurada { get; set; }

        public int? optAplicarVF { get; set; }

        public int? optIncluyeBP { get; set; }


        #region Solo para captura en vistas
        [NotMapped]
        public string chkModalidadPago { get; set; }
        [NotMapped]
        public string chkTipoTarjeta { get; set; }
        [NotMapped]
        public string chkTipoUsoVehiculo { get; set; }
        [NotMapped]
        public string chkAdministrador { get; set; }
        
        public string CHKCARTYPE { get; set; }
        [NotMapped]
        public string chkABPPC { get; set; }
        [NotMapped]
        public string ListaCatParentesco { get; set; }
        [NotMapped]
        public List<CatGNPCaratula> CaratulasGNP { get; set; }
        [NotMapped]
        public int IdTipoNegocio { get; set; }
        [NotMapped]
        public bool PermiteCotizacionSoloEnrollment { get; set; }
        #endregion

        #endregion

        #region 4.- Forma de pago

        public int? IdCatSolicitaCancelacion { get; set; }

        public bool Domiciliacion { get; set; }
        public bool DatosBancariosEnrollment {  get; set; }

        //CAT: Expone en la vista el indicador GNP sin agregar una columna nueva a la tabla Convenio.
        [NotMapped]
        public bool AplicaDomiciliacionPostEmision { get; set; }

        #region Solo para captura en vistas forma de pago
        [NotMapped]
        public string chkCatUsuarioSolicitaCancelacion { get; set; }
        #endregion
        #endregion

        #region 5.- Datos adicionales

        public int ZonaCirculacion { get; set; }

        public int CodigoPostal { get; set; }

        public int IntentosCobro { get; set; }

        public string NumeroNegocio { get; set; }

        public string UsuarioAgente { get; set; }
        public string CodigoCliente { get; set; }

        public int Agrupador { get; set; }

        public int Conducto { get; set; }

        public string TRC { get; set; }

        public string CNZD { get; set; }

        public string NEI { get; set; }

        public bool OnLine { get; set; }
        public bool LeapYear { get; set; }
        public int? FLP { get; set; }

        public bool AxaEspecial { get; set; }

        public bool GNPInfoEspecial { get; set; }

        //[Required(ErrorMessage ="Este dato es requerido")]
        public string ZonaCotizacion { get; set; }

        public string CuadroComision { get; set; }
        public string NombreContactoAseguradora { get; set; }
        public string CorreoContactoAseguradora { get; set; }
        public string NombreContactoServicio { get; set; }
        public string CorreoContactoServicio { get; set; }
        public string PersonaNoEmpresa { get; set; }

        public List<TIPOMODIFICACION_SELECT_Convenio> TipoModificaciones { get; set; }

        #endregion

        #region 6.- Condiciones Especiales

        public int GestorCobro { get; set; }

        public string Mit_id_company { get; set; }
        public string Mit_id_branch { get; set; }
        public string Mit_user { get; set; }
        public string Mit_pwd { get; set; }
        public string Mit_Key { get; set; }
        public string Mit_Data0 { get; set; }
        #endregion

        public int ClaveAgente { get; set; }

        public int Comision { get; set; }

        public int Descuento { get; set; }

        public int Observaciones { get; set; }

        public int XMLAdicionales { get; set; }

        public int Agente { get; set; }

        public int PrimerRecibo { get; set; }

        public int ReciboSubSec { get; set; }

        public int EsquemaIndividual { get; set; }

        public int IdCatRamo { get; set; }

        public int IdCatTipoNegocio { get; set; }

        public int IdPaqueteVehiculoConvenio { get; set; }

        public int Estatus { get; set; }

        public string CodigoIntermediario { get; set; }
        public string ProductoAXA { get; set; }
        public string NombreAXA { get; set; }
        public string SerieAXA { get; set; }
        public bool? AplicaPromotores { get; set; }
        [NotMapped]
        public bool AplicaMIT { get; set; }

        [NotMapped]
        public bool AplicaPromotoresValue { get; set; }
        public bool? CargoEnLinea { get; set; }

        public bool AplicaNumeroContrato { get; set; }
        public bool AplicaNumeroContratoUsuarioFinal { get; set; }
        public bool AplicaSegmento { get; set; }
        public bool AplicaSegmentoUsuarioFinal { get; set; }
        public string NumeroPolizaGrupo { get; set; }
        public bool AplicaNumeroEmpleado { get; set; }
        public bool AplicaNumeroEmpleadoUsuarioFinal { get; set; }


        public bool ImprimirRecibosPDF { get; set; }
        public bool Colectividad { get; set; }
        public bool? RequireReimRecibos { get; set; }
        public bool? RequireReimCertificadoInd { get; set; }
        public bool EnvioFormaPagoABA { get; set; }

        public bool CotizaSoloEnrollment { get; set; }

        public string IdCotizacion { get; set; }
        public string IdPoliza {  get; set; }
        public bool OcuparCaratulaOpera {  get; set; }
        public bool UsoCatalogoAXAEMA { get; set; }
        public string Referencia1 { get; set; }

        [NotMapped]
        public List<ConvenioDescuentoEstado> Descuentos { get; set; }
        [NotMapped]
        public List<ConvenioCondicionesParticulares> CondicionesParticulares { get; set; }

        [NotMapped]
        public List<ArchivoConvenio> Archivos { get; set; }
        [NotMapped]
        public List<CondicionGeneralArchivo> ArchivosCondionesGenerales { get; set; }

        [NotMapped]
        public List<ANA_Argumento> Argumentos{ get; set; }

        [NotMapped]
        public List<ConvenioMSI> MSI { get; set; }
        [NotMapped]
        public bool MultiAnual { get; set; }

		[StringLength(maximumLength:16,ErrorMessage = "El contrato debe ser menor a 16 Caracteres")]
        public string Contrato { get; set; }

        [ForeignKey("IdAseguradora")]
        [JsonIgnore]
        public virtual Aseguradora Aseguradora { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[JsonIgnore]
		public virtual ICollection<CatFormaPago> CatFormaPago { get; set; }
		[JsonIgnore]

		public virtual CatRamoVehiculo CatRamoVehiculo { get; set; }		

		[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[JsonIgnore]
		public virtual ICollection<CatTipoContenido> CatTipoContenido { get; set; }
		[JsonIgnore]
		public virtual CatTipoNegocio CatTipoNegocio { get; set; }

        [ForeignKey("IdCatUsoVehiculo")]
		[JsonIgnore]
		public virtual CatUsoVehiculo CatUsoVehiculo { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[JsonIgnore]
		public virtual ICollection<ConfigWS> ConfigWS { get; set; }

		[JsonIgnore]
		[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<EmpresaConvenio> EmpresaConvenio { get; set; }


        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[JsonIgnore]
		public virtual ICollection<PaqueteConvenio> PaqueteConvenio { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[JsonIgnore]
		public virtual ICollection<Poliza> Poliza { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[JsonIgnore]
		public virtual ICollection<CoberturasCondicionesEspeciales> CoberturasCondicionesEspeciales { get; set; }
    }
}
