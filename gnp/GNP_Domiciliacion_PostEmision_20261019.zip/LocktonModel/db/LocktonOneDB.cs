namespace LocktonModel.db
{
    using System.Data.Entity;

    public partial class LocktonOneDB : DbContext
    {
        public LocktonOneDB()
            : base("name=LocktonOneDB")
        {
        }

        public virtual DbSet<C__MigrationHistory> C__MigrationHistory { get; set; }
        public virtual DbSet<Aseguradora> Aseguradora { get; set; }
        public virtual DbSet<AspNetRoles> AspNetRoles { get; set; }
        public virtual DbSet<AspNetUserClaims> AspNetUserClaims { get; set; }
        public virtual DbSet<AspNetUserLogins> AspNetUserLogins { get; set; }
        public virtual DbSet<AspNetUsers> AspNetUsers { get; set; }
        public virtual DbSet<CatAgrupaVehiculo> CatAgrupaVehiculo { get; set; }
        public virtual DbSet<CatBeneficiarioPreferente> CatBeneficiarioPreferente { get; set; }
        public virtual DbSet<CatCatalogoTipoDeducible> CatCatalogoTipoDeducible { get; set; }
        public virtual DbSet<CatCentroCostos> CatCentroCostos { get; set; }
        public virtual DbSet<CatClientesQualitasCondAdicional> CatClientesQualitasCondAdicional { get; set; }
        public virtual DbSet<CatCoberturaPerdidaParcial> CatCoberturaPerdidaParcial { get; set; }
        public virtual DbSet<CatCondicion> CatCondicion { get; set; }
        public virtual DbSet<CatEstadosRepublica> CatEstadosRepublica { get; set; }
        public virtual DbSet<CatFormaPago> CatFormaPago { get; set; }
        public virtual DbSet<CatGenero> CatGenero { get; set; }
        public virtual DbSet<CatGiroBase> CatGiroBase { get; set; }
        public virtual DbSet<CatGNPOpcionesContratarConvenio> CatGNPOpcionesContratarConvenio { get; set; }
        public virtual DbSet<CatImportanciaContenido> CatImportanciaContenido { get; set; }
        public virtual DbSet<CatModalidadFormaPago> CatModalidadFormaPago { get; set; }
        public virtual DbSet<CatNacionalidad> CatNacionalidad { get; set; }
        public virtual DbSet<CatOficinaReferencia> CatOficinaReferencia { get; set; }
        public virtual DbSet<CatPais> CatPais { get; set; }
        public virtual DbSet<CatParentesco> CatParentesco { get; set; }
        public virtual DbSet<CatPeriodicidadFormaPago> CatPeriodicidadFormaPago { get; set; }
        public virtual DbSet<CatPeriodicidadOPL> CatPeriodicidadOPL { get; set; }
        public virtual DbSet<CatPrimaAnualizada> CatPrimaAnualizada { get; set; }
        public virtual DbSet<CatRamoVehiculo> CatRamoVehiculo { get; set; }
        public virtual DbSet<CatSubRamoVehiculo> CatSubRamoVehiculo { get; set; }
        public virtual DbSet<CatTipoCobertura> CatTipoCobertura { get; set; }
        public virtual DbSet<CatTipoComision> CatTipoComision { get; set; }
        public virtual DbSet<CatTipoComparativo> CatTipoComparativo { get; set; }
        public virtual DbSet<CatTipoContenido> CatTipoContenido { get; set; }
        public virtual DbSet<CatTipoContratante> CatTipoContratante { get; set; }
        public virtual DbSet<CatTipoConvenio> CatTipoConvenio { get; set; }
        public virtual DbSet<CatTipoEntradaHistorico> CatTipoEntradaHistorico { get; set; }
        public virtual DbSet<CatTipoFormaPago> CatTipoFormaPago { get; set; }
        public virtual DbSet<CatTipoIdentificacion> CatTipoIdentificacion { get; set; }
        public virtual DbSet<CatTipoModificacion> CatTipoModificacion { get; set; }
        public virtual DbSet<CatTipoNegociacion> CatTipoNegociacion { get; set; }
        public virtual DbSet<CatTipoNegocio> CatTipoNegocio { get; set; }
        public virtual DbSet<CatTipoPaquete> CatTipoPaquete { get; set; }
        public virtual DbSet<CatTipoPersona> CatTipoPersona { get; set; }
        public virtual DbSet<CatTipoPosicion> CatTipoPosicion { get; set; }
        public virtual DbSet<CatTipoProceso> CatTipoProceso { get; set; }
        public virtual DbSet<CatTipoSumaAsegVehiculo> CatTipoSumaAsegVehiculo { get; set; }
        public virtual DbSet<CatTipoUsoVehiculo> CatTipoUsoVehiculo { get; set; }
        public virtual DbSet<CatTipoValidacionMembresia> CatTipoValidacionMembresia { get; set; }
        public virtual DbSet<CatTipoVehiculo> CatTipoVehiculo { get; set; }
        public virtual DbSet<CatTipoVigencia> CatTipoVigencia { get; set; }
        public virtual DbSet<CatUsoVehiculo> CatUsoVehiculo { get; set; }
        public virtual DbSet<CatValorFactura> CatValorFactura { get; set; }
        public virtual DbSet<Cobertura> Cobertura { get; set; }
        public virtual DbSet<CoberturaBase> CoberturaBase { get; set; }
        public virtual DbSet<CoberturasCondicionesEspeciales> CoberturasCondicionesEspeciales { get; set; }
        public virtual DbSet<CondicionEspecial> CondicionEspecial { get; set; }
        public virtual DbSet<ConfiguracionEmpresa> ConfiguracionEmpresa { get; set; }
        //CAT: Registra la tabla independiente de configuracion de domiciliacion GNP en el contexto de datos.
        public virtual DbSet<ConfiguracionDomiciliacionGNP> ConfiguracionDomiciliacionGNP { get; set; }
        public virtual DbSet<ConfigWS> ConfigWS { get; set; }
        public virtual DbSet<ControladorMenu> ControladorMenu { get; set; }
        public virtual DbSet<Convenio> Convenio { get; set; }
        public virtual DbSet<Convenio2> Convenio2 { get; set; }
        public virtual DbSet<ConvenioParentesco> ConvenioParentesco { get; set; }
        public virtual DbSet<ConvenioRamoPaquete> ConvenioRamoPaquete { get; set; }
        public virtual DbSet<Corporativo> Corporativo { get; set; }
        public virtual DbSet<Cotizacion> Cotizacion { get; set; }
        public virtual DbSet<CotizacionAuto> CotizacionAuto { get; set; }
        public virtual DbSet<CotizacionDetalle> CotizacionDetalle { get; set; }
        public virtual DbSet<DetallesSesion> DetallesSesion { get; set; }
        public virtual DbSet<DetalleUsuario> DetalleUsuario { get; set; }
        public virtual DbSet<DetalleUsuarioBeFlex> DetalleUsuarioBeFlex { get; set; }
        public virtual DbSet<DetalleUsuarioEmpresa> DetalleUsuarioEmpresa { get; set; }
        public virtual DbSet<Direccion> Direccion { get; set; }
        public virtual DbSet<Ejecutivo> Ejecutivo { get; set; }
        public virtual DbSet<Empresa> Empresa { get; set; }
        public virtual DbSet<EmpresaConvenio> EmpresaConvenio { get; set; }
        public virtual DbSet<Endoso> Endoso { get; set; }
        public virtual DbSet<EndosoB> EndosoB { get; set; }
        public virtual DbSet<EndosoBTipo> EndosoBTipo { get; set; }
        public virtual DbSet<Enrollment> Enrollment { get; set; }
        public virtual DbSet<InfoBeflex> InfoBeflex { get; set; }
        public virtual DbSet<MapaControlador> MapaControlador { get; set; }
        public virtual DbSet<MarcaVehiculo> MarcaVehiculo { get; set; }
        public virtual DbSet<ModalidadFormaPago> ModalidadFormaPago { get; set; }
        public virtual DbSet<ModeloVehiculo> ModeloVehiculo { get; set; }
        public virtual DbSet<OTRenovacion> OTRenovacion { get; set; }
        public virtual DbSet<Paquete> Paquete { get; set; }
        public virtual DbSet<PaqueteAseguradora> PaqueteAseguradora { get; set; }
        public virtual DbSet<PaqueteConvenio> PaqueteConvenio { get; set; }
        public virtual DbSet<PaqueteDetalle> PaqueteDetalle { get; set; }
        public virtual DbSet<Perfiles> Perfiles { get; set; }
        public virtual DbSet<PerfilesJerarquia> PerfilesJerarquia { get; set; }
        public virtual DbSet<PerfilesRoles> PerfilesRoles { get; set; }
        public virtual DbSet<PeriodicidadFormaPago> PeriodicidadFormaPago { get; set; }
        public virtual DbSet<Persona> Persona { get; set; }
        public virtual DbSet<PersonalizaEmpresaCorreo> PersonalizaEmpresaCorreo { get; set; }
        public virtual DbSet<PersonalizaEmpresaLandF> PersonalizaEmpresaLandF { get; set; }
        public virtual DbSet<Poliza> Poliza { get; set; }
        public virtual DbSet<Recibo> Recibo { get; set; }
        public virtual DbSet<RepresentanteLegal> RepresentanteLegal { get; set; }
        public virtual DbSet<Submarca> Submarca { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }
        public virtual DbSet<Vehiculo> Vehiculo { get; set; }
        public virtual DbSet<AccesoBeneficiarioPreferente> AccesoBeneficiarioPreferente { get; set; }
        public virtual DbSet<AccesoValorFactura> AccesoValorFactura { get; set; }
        public virtual DbSet<CatSolicitaCancelacion> CatSolicitaCancelacion { get; set; }
        public virtual DbSet<CatUsuarioSolicitaCancelacion> CatUsuarioSolicitaCancelacion { get; set; }
        public virtual DbSet<CatZonaCotizacion> CatZonaCotizacion { get; set; }
        public DbSet<CatClavePorcentajeDescuento> CatClavePorcentajeDescuento { get; set; }
        public virtual DbSet<CodigoPostal> CatCodigoPostal { get; set; }
        public virtual DbSet<CatMotivoCancelacion> CatMotivoCancelacion { get; set; }
        public virtual DbSet<PolizaDetalle> PolizaDetalle { get; set; }
        public virtual DbSet<CatBancosAseguradoras> CatBancosAseguradoras { get; set; }
        public virtual DbSet<CatBanco> CatBanco { get; set; }
        public virtual DbSet<EstatusPoliza> CatEstatusPoliza { get; set; }
        public virtual DbSet<TipoEndoso> TipoEndoso { get; set; }
        public virtual DbSet<Sucursal> Sucursal { get; set; }
        public virtual DbSet<Vehiculosdisponibles> Vehiculosdisponibles { get; set; }

        public virtual DbSet<CatParametro> CatParametro { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Aseguradora>()
                .HasMany(e => e.Convenio)
                .WithRequired(e => e.Aseguradora)
                .HasForeignKey(e => e.IdAseguradora)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Aseguradora>()
                .HasMany(e => e.Paquete)
                .WithRequired(e => e.Aseguradora)
                .HasForeignKey(e => e.IdAseguradora)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AspNetRoles>()
                .HasMany(e => e.AspNetUsers)
                .WithMany(e => e.AspNetRoles)
                .Map(m => m.ToTable("AspNetUserRoles").MapLeftKey("RoleId").MapRightKey("UserId"));

            modelBuilder.Entity<AspNetUsers>()
                .HasMany(e => e.AspNetUserClaims)
                .WithRequired(e => e.AspNetUsers)
                .HasForeignKey(e => e.UserId);

            modelBuilder.Entity<AspNetUsers>()
                .HasMany(e => e.AspNetUserLogins)
                .WithRequired(e => e.AspNetUsers)
                .HasForeignKey(e => e.UserId);

            modelBuilder.Entity<CatAgrupaVehiculo>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<CatAgrupaVehiculo>()
                .Property(e => e.Clave)
                .IsUnicode(false);

            modelBuilder.Entity<CatCentroCostos>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.CatCentroCostos)
                .HasForeignKey(e => e.IdCatCentroCostos);

            modelBuilder.Entity<CatClientesQualitasCondAdicional>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.CatClientesQualitasCondAdicional)
                .HasForeignKey(e => e.IdCatClientesQualitasCondAdicional);

            modelBuilder.Entity<CatCoberturaPerdidaParcial>()
                .HasMany(e => e.Cobertura)
                .WithOptional(e => e.CatCoberturaPerdidaParcial)
                .HasForeignKey(e => e.IdCatCoberturaPerdidaParcial);

            modelBuilder.Entity<CatCondicion>()
                .HasMany(e => e.CondicionEspecial)
                .WithRequired(e => e.CatCondicion)
                .HasForeignKey(e => e.IdCatCondicion)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatEstadosRepublica>()
                .Property(e => e.Valor)
                .IsUnicode(false);

            modelBuilder.Entity<CatEstadosRepublica>()
                .HasMany(e => e.Direccion)
                .WithOptional(e => e.CatEstadosRepublica)
                .HasForeignKey(e => e.IdCatEstadosRepublica);

            modelBuilder.Entity<CatEstadosRepublica>()
                .HasMany(e => e.RepresentanteLegal)
                .WithRequired(e => e.CatEstadosRepublica)
                .HasForeignKey(e => e.IdCatEstadosRepublica_Nacimiento)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatGiroBase>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.CatGiroBase)
                .HasForeignKey(e => e.IdCatGiroBase);

            modelBuilder.Entity<CatNacionalidad>()
                .HasMany(e => e.Persona)
                .WithRequired(e => e.CatNacionalidad)
                .HasForeignKey(e => e.IdCatNacionalidad)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatPais>()
                .Property(e => e.Pais)
                .IsUnicode(false);

            modelBuilder.Entity<CatPais>()
                .Property(e => e.Clave)
                .IsUnicode(false);

            modelBuilder.Entity<CatPais>()
                .Property(e => e.Valor)
                .IsUnicode(false);

            modelBuilder.Entity<CatPais>()
                .HasMany(e => e.RepresentanteLegal)
                .WithRequired(e => e.CatPais)
                .HasForeignKey(e => e.IdCatPais_Nacimiento)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatPeriodicidadFormaPago>()
                .HasOptional(e => e.PeriodicidadFormaPago);

            modelBuilder.Entity<CatRamoVehiculo>()
                .HasMany(e => e.Convenio)
                .WithRequired(e => e.CatRamoVehiculo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatRamoVehiculo>()
                .HasMany(e => e.Vehiculo)
                .WithRequired(e => e.CatRamoVehiculo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatTipoCobertura>()
                .HasMany(e => e.Cobertura)
                .WithOptional(e => e.CatTipoCobertura)
                .HasForeignKey(e => e.IdCatTipoCobertura);

            modelBuilder.Entity<Cobertura>()
                .HasMany(e => e.CoberturasCondicionesEspeciales)
                .WithRequired(e => e.Cobertura)
                .HasForeignKey(e => e.IdCobertura)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Cobertura>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<Cobertura>()
               .Property(e => e.Clave)
               .IsUnicode(false);

            modelBuilder.Entity<CatTipoComparativo>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.CatTipoComparativo)
                .HasForeignKey(e => e.IdCatTipoComparativo);

            modelBuilder.Entity<CatTipoContenido>()
                .Property(e => e.Importancia)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoIdentificacion>()
                .Property(e => e.TipoIdentificacion)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoIdentificacion>()
                .Property(e => e.Clave)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoIdentificacion>()
                .HasMany(e => e.RepresentanteLegal)
                .WithRequired(e => e.CatTipoIdentificacion)
                .HasForeignKey(e => e.IdCatTipoIdentificacion)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatTipoNegocio>()
                .HasMany(e => e.Convenio)
                .WithRequired(e => e.CatTipoNegocio)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatTipoPaquete>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoPaquete>()
                .Property(e => e.Clave)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoPersona>()
                .Property(e => e.Persona)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoPersona>()
                .Property(e => e.Clave)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoPersona>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.CatTipoPersona)
                .HasForeignKey(e => e.IdCatTipoPersona);

            modelBuilder.Entity<CatTipoPersona>()
                .HasMany(e => e.Persona1)
                .WithRequired(e => e.CatTipoPersona)
                .HasForeignKey(e => e.IdCatTipoPersona)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatTipoPosicion>()
                .Property(e => e.Posicion)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoPosicion>()
                .Property(e => e.Clave)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoPosicion>()
                .HasMany(e => e.Persona)
                .WithRequired(e => e.CatTipoPosicion)
                .HasForeignKey(e => e.IdCatTipoPosicion)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatTipoSumaAsegVehiculo>()
                .HasMany(e => e.CatValorFactura)
                .WithRequired(e => e.CatTipoSumaAsegVehiculo)
                .HasForeignKey(e => e.IdCatTipoSumaAsegVehiculo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatTipoValidacionMembresia>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoValidacionMembresia>()
                .Property(e => e.Clave)
                .IsUnicode(false);

            modelBuilder.Entity<CatTipoVehiculo>()
                .HasMany(e => e.Vehiculo)
                .WithRequired(e => e.CatTipoVehiculo)
                .HasForeignKey(e => e.IdCatTipoVehiculo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CatUsoVehiculo>()
                .HasMany(e => e.Convenio)
                .WithRequired(e => e.CatUsoVehiculo)
                .HasForeignKey(e => e.IdCatUsoVehiculo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CondicionEspecial>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<CondicionEspecial>()
                .Property(e => e.Valor1)
                .IsUnicode(false);

            modelBuilder.Entity<CondicionEspecial>()
                .Property(e => e.Valor2)
                .IsUnicode(false);

            modelBuilder.Entity<CondicionEspecial>()
                .HasMany(e => e.CoberturasCondicionesEspeciales)
                .WithRequired(e => e.CondicionEspecial)
                .HasForeignKey(e => e.IdCondicionEspecial)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ConfiguracionEmpresa>()
                .Property(e => e.OrdenPaquetes)
                .IsUnicode(false);

            modelBuilder.Entity<ConfiguracionEmpresa>()
                .Property(e => e.MensajePagoReferenciadoCliente)
                .IsUnicode(false);

            modelBuilder.Entity<ConfiguracionEmpresa>()
                .Property(e => e.LigaDescCoberturasCliente)
                .IsUnicode(false);

            modelBuilder.Entity<ConfiguracionEmpresa>()
                .Property(e => e.AvisoCobro)
                .IsUnicode(false);

            modelBuilder.Entity<ConfiguracionEmpresa>()
                .Property(e => e.NombreMembresia)
                .IsUnicode(false);

            modelBuilder.Entity<ControladorMenu>()
                .Property(e => e.Objeto)
                .IsUnicode(false);

            modelBuilder.Entity<ControladorMenu>()
                .Property(e => e.NombreAgrupacion)
                .IsUnicode(false);

            modelBuilder.Entity<ControladorMenu>()
                .HasMany(e => e.Perfiles)
                .WithOptional(e => e.ControladorMenu)
                .HasForeignKey(e => e.IdControlorMenu);

            modelBuilder.Entity<Convenio>()
                .HasMany(e => e.CatFormaPago)
                .WithRequired(e => e.Convenio)
                .HasForeignKey(e => e.IdEmpresa)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Convenio>()
                .HasMany(e => e.CatTipoContenido)
                .WithRequired(e => e.Convenio)
                .HasForeignKey(e => e.IdEmpresa)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Convenio>()
                .HasMany(e => e.ConfigWS)
                .WithRequired(e => e.Convenio)
                .HasForeignKey(e => e.IdConvenio)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Convenio>()
                .HasMany(e => e.EmpresaConvenio)
                .WithRequired(e => e.Convenio)
                .HasForeignKey(e => e.IdConvenio)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Convenio>()
                .HasMany(e => e.PaqueteConvenio)
                .WithRequired(e => e.Convenio)
                .HasForeignKey(e => e.IdConvenio)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Convenio>()
                .HasMany(e => e.Poliza)
                .WithRequired(e => e.Convenio)
                .HasForeignKey(e => e.IdConvenio)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ConvenioRamoPaquete>()
                .Property(e => e.Sobrecomision)
                .HasPrecision(12, 4);

            modelBuilder.Entity<ConvenioRamoPaquete>()
                .Property(e => e.Comision)
                .HasPrecision(12, 4);

            modelBuilder.Entity<ConvenioRamoPaquete>()
                .Property(e => e.Descuento)
                .HasPrecision(12, 4);

            modelBuilder.Entity<Corporativo>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<Corporativo>()
                .Property(e => e.Descripcion)
                .IsUnicode(false);

            modelBuilder.Entity<Corporativo>()
                .HasMany(e => e.Empresa)
                .WithRequired(e => e.Corporativo)
                .HasForeignKey(e => e.IdCorporativo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<DetalleUsuario>()
                .HasMany(e => e.DetalleUsuarioEmpresa)
                .WithOptional(e => e.DetalleUsuario)
                .HasForeignKey(e => e.IdDetalleUsuario);

            modelBuilder.Entity<Direccion>()
                .HasMany(e => e.DetalleUsuario)
                .WithOptional(e => e.Direccion)
                .HasForeignKey(e => e.IdDireccion);

            modelBuilder.Entity<Direccion>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.Direccion)
                .HasForeignKey(e => e.IdDireccion);

            modelBuilder.Entity<Direccion>()
                .HasMany(e => e.Persona)
                .WithRequired(e => e.Direccion)
                .HasForeignKey(e => e.IdDireccion)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Ejecutivo>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<Ejecutivo>()
                .Property(e => e.ApellidoPaterno)
                .IsUnicode(false);

            modelBuilder.Entity<Ejecutivo>()
                .Property(e => e.ApellidoMaterno)
                .IsUnicode(false);

            modelBuilder.Entity<Ejecutivo>()
                .Property(e => e.Correo)
                .IsUnicode(false);

            modelBuilder.Entity<Ejecutivo>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<Ejecutivo>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.Ejecutivo)
                .HasForeignKey(e => e.IdEjecutivo);

            modelBuilder.Entity<Empresa>()
                .Property(e => e.Implant)
                .IsUnicode(false);

            modelBuilder.Entity<Empresa>()
                .Property(e => e.TelefonoGral)
                .IsUnicode(false);

            modelBuilder.Entity<Empresa>()
                .Property(e => e.NombreComercial)
                .IsUnicode(false);

            modelBuilder.Entity<Empresa>()
                .Property(e => e.ClaveEmpresa)
                .IsUnicode(false);

            modelBuilder.Entity<Empresa>()
                .Property(e => e.Entidad)
                .IsFixedLength();

            modelBuilder.Entity<Empresa>()
                .Property(e => e.IdBeflex)
                .IsUnicode(false);

            modelBuilder.Entity<Empresa>()
                .HasMany(e => e.DetalleUsuarioEmpresa)
                .WithOptional(e => e.Empresa)
                .HasForeignKey(e => e.IdEmpresa);

            modelBuilder.Entity<Empresa>()
                .HasMany(e => e.EmpresaConvenio)
                .WithRequired(e => e.Empresa)
                .HasForeignKey(e => e.IdCliente)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Empresa>()
                .HasMany(e => e.Enrollment)
                .WithRequired(e => e.Empresa)
                .HasForeignKey(e => e.IdEmpresa)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Empresa>()
                .HasMany(e => e.InfoBeflex)
                .WithRequired(e => e.Empresa)
                .HasForeignKey(e => e.IdEmpresa)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Empresa>()
               .HasMany(e => e.Sucursales)
               .WithRequired(e => e.Empresa)
               .HasForeignKey(e => e.IdEmpresa)
               .WillCascadeOnDelete(false);

            modelBuilder.Entity<Endoso>()
                .HasMany(e => e.Recibo)
                .WithRequired(e => e.Endoso)
                .HasForeignKey(e => e.IdEndoso)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<EndosoBTipo>()
                .HasMany(e => e.EndosoB)
                .WithRequired(e => e.EndosoBTipo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MapaControlador>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<MapaControlador>()
                .Property(e => e.Accion)
                .IsUnicode(false);

            modelBuilder.Entity<MapaControlador>()
                .Property(e => e.Controler)
                .IsUnicode(false);

            modelBuilder.Entity<MapaControlador>()
                .HasMany(e => e.ControladorMenu)
                .WithOptional(e => e.MapaControlador)
                .HasForeignKey(e => e.IdMapaControlador);

            modelBuilder.Entity<ModeloVehiculo>()
                .HasMany(e => e.Submarca)
                .WithRequired(e => e.ModeloVehiculo)
                .HasForeignKey(e => e.IdModelo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Paquete>()
                .HasMany(e => e.Cobertura)
                .WithOptional(e => e.Paquete)
                .HasForeignKey(e => e.IdPaquete);

            modelBuilder.Entity<Perfiles>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<Perfiles>()
                .HasMany(e => e.DetalleUsuario)
                .WithRequired(e => e.Perfiles)
                .HasForeignKey(e => e.IdPerfil)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Perfiles>()
                .HasMany(e => e.PerfilesRoles)
                .WithRequired(e => e.Perfiles)
                .HasForeignKey(e => e.IdPerfiles)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PerfilesRoles>()
                .Property(e => e.IdRoles)
                .IsFixedLength();

            modelBuilder.Entity<PeriodicidadFormaPago>()
                .Property(e => e.RecargoPagoFraccionado)
                .HasPrecision(12, 4);

            modelBuilder.Entity<Persona>()
                .HasMany(e => e.InfoBeflex)
                .WithRequired(e => e.Persona)
                .HasForeignKey(e => e.IdPersona)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<PersonalizaEmpresaCorreo>()
                .Property(e => e.Asunto)
                .IsUnicode(false);

            modelBuilder.Entity<PersonalizaEmpresaCorreo>()
                .Property(e => e.CC)
                .IsUnicode(false);

            modelBuilder.Entity<PersonalizaEmpresaCorreo>()
                .Property(e => e.CCO)
                .IsUnicode(false);

            modelBuilder.Entity<PersonalizaEmpresaCorreo>()
                .Property(e => e.Cuerpo)
                .IsUnicode(false);

            modelBuilder.Entity<PersonalizaEmpresaCorreo>()
                .Property(e => e.Firma)
                .IsUnicode(false);

            modelBuilder.Entity<PersonalizaEmpresaCorreo>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.PersonalizaEmpresaCorreo)
                .HasForeignKey(e => e.IdPersonalizaEmpresaCorreo);

            modelBuilder.Entity<PersonalizaEmpresaLandF>()
                .Property(e => e.ColorCabeceraMaster)
                .IsUnicode(false);

            modelBuilder.Entity<PersonalizaEmpresaLandF>()
                .Property(e => e.ColorBotones)
                .IsUnicode(false);

            modelBuilder.Entity<PersonalizaEmpresaLandF>()
                .Property(e => e.ColorLabels)
                .IsUnicode(false);

            modelBuilder.Entity<PersonalizaEmpresaLandF>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.PersonalizaEmpresaLandF)
                .HasForeignKey(e => e.IdPersonalizaEmpresaLandF);

            modelBuilder.Entity<Poliza>()
                .HasMany(e => e.Endoso)
                .WithRequired(e => e.Poliza)
                .HasForeignKey(e => e.IdPoliza)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<RepresentanteLegal>()
                .Property(e => e.Nombre)
                .IsUnicode(false);

            modelBuilder.Entity<RepresentanteLegal>()
                .Property(e => e.ApellidoPaterno)
                .IsUnicode(false);

            modelBuilder.Entity<RepresentanteLegal>()
                .Property(e => e.ApellidoMaterno)
                .IsUnicode(false);

            modelBuilder.Entity<RepresentanteLegal>()
                .Property(e => e.Correo)
                .IsUnicode(false);

            modelBuilder.Entity<RepresentanteLegal>()
                .Property(e => e.Telefono)
                .IsUnicode(false);

            modelBuilder.Entity<RepresentanteLegal>()
                .Property(e => e.NumeroIdentificacion)
                .IsUnicode(false);

            modelBuilder.Entity<RepresentanteLegal>()
                .HasMany(e => e.Empresa)
                .WithOptional(e => e.RepresentanteLegal)
                .HasForeignKey(e => e.IdRepresentanteLegal);
        }
    }
}
