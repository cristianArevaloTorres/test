using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LocktonModel.db
{
    //CAT: Se separa la configuracion de domiciliacion GNP para no alterar la estructura de la tabla Convenio.
    [Table("ConfiguracionDomiciliacionGNP")]
    public class ConfiguracionDomiciliacionGNP
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int IdConvenio { get; set; }

        public bool AplicaDomiciliacionPostEmision { get; set; }

        public DateTime FechaCreacion { get; set; }

        public DateTime? FechaModificacion { get; set; }

        [StringLength(128)]
        public string IdUsuarioCreacion { get; set; }

        [StringLength(128)]
        public string IdUsuarioModificacion { get; set; }

        [ForeignKey("IdConvenio")]
        public virtual Convenio Convenio { get; set; }
    }
}
