﻿using System.Collections.Generic;

namespace LocktonModel.VModels
{
    public class VFormaDePago
    {
        public int IdConvenio { get; set; }
        public int IdEmpresa { get; set; }
        public int IdCatSolicitaCancelacion { get; set; }
        public string chkCatUsuarioSolicitaCancelacion { get; set; }
        public bool CargaEnLínea { get; set; }
        public bool RequireReimRecibos { get; set; }
        public bool RequireReimCertificadoInd { get; set; }
        public bool Domiciliacion {  get; set; }
        public bool DatosBancariosEnrollment { get; set; }
        //CAT: Recibe el nuevo check de domiciliacion posterior a la emision para guardarlo en su tabla de configuracion.
        public bool AplicaDomiciliacionPostEmision { get; set; }
        public List<VFormaDePagoPeriodicidad> FormaDePagoPeriodicidad { get; set; }
    }

    public class VFormaDePagoPeriodicidad
    {
        public int IdCatPeriodicidadFormaPago { get; set; }
        public string ModalidadFormaPago { get; set; }
        public string ModalidadFormaPagoAdmin { get; set; }
        public string ModalidadFormaPagoBajas { get; set; }
        public string FormaPago { get; set; }
        public string FormaPagoCobranza { get; set; }
        public decimal RecargoPagoFraccionado { get; set; }
        public string PolizaNegocioOpera { get; set; }
        public string ClaveAgente { get; set; }
        public bool PrimerReciboPdf { get; set; }
        public int IdPolizaMaestra { get; set; }
        public string Sucursal { get; set; }
        public string Producto { get; set; }
        public string NumeroPolizaMaestra { get; set; }
      

    }
}
