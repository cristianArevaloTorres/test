﻿namespace LocktonModel.VModels
{
    using LocktonModel.db;
    using System.Xml;
    public class EmisionPoliza
    {
        private bool respuesta;
        private string mensajeEnvio;
        private string mensajeRespuesta;
        private XmlDocument respuestaServicio;
        private XmlDocument solicitudServicio;
        private Poliza poliza;
        private PolizaCasa polizacasa;
        public EmisionPoliza(bool respuesta, string mensajeEnvio, string mensajeRespuesta, Poliza poliza = null, int? referencia = null, PolizaCasa polizaCasa = null)
        {
            this.respuesta = respuesta;
            this.mensajeEnvio = mensajeEnvio;
            this.mensajeRespuesta = mensajeRespuesta;
            if (respuesta)
            {
                try
                {
                    if (!string.IsNullOrEmpty(mensajeRespuesta))
                    {
                        respuestaServicio = new XmlDocument();
                        respuestaServicio.LoadXml(mensajeRespuesta);
                    }
                    if (!string.IsNullOrEmpty(mensajeEnvio))
                    {
                        solicitudServicio = new XmlDocument();
                        solicitudServicio.LoadXml(mensajeEnvio);
                    }
                }
                catch { }
                this.poliza = poliza;
                this.polizacasa = polizaCasa;
            }

            Referencia = referencia ?? 0;
        }

        public bool Respuesta { get => respuesta; set => respuesta = value; }
        public string MensajeEnvio { get => mensajeEnvio; set => mensajeEnvio = value; }
        public string MensajeRespuesta { get => mensajeRespuesta; set => mensajeRespuesta = value; }
        public XmlDocument RespuestaServicio { get => respuestaServicio; set => respuestaServicio = value; }
        public XmlDocument SolicitudServicio { get => solicitudServicio; set => solicitudServicio = value; }
        public Poliza Poliza { get => poliza; set => poliza = value; }

        public PolizaCasa PolizaCasa { get => polizacasa; set => polizacasa = value; }

        public int Referencia { get; set; }

        //CAT: Transporta el resultado de la domiciliacion sin convertir una poliza ya emitida en una emision fallida.
        public EstatusOperacion EstatusDomiciliacion { get; set; }
    }
}
