﻿using LocktonModel.db;
using LocktonModel.VModels;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LocktonModel.Models
{
    // Para agregar datos de perfil del usuario, agregue más propiedades a su clase ApplicationUser. Visite https://go.microsoft.com/fwlink/?LinkID=317594 para obtener más información.
    public class ApplicationUser : IdentityUser
    {
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            // Tenga en cuenta que el valor de authenticationType debe coincidir con el definido en CookieAuthenticationOptions.AuthenticationType
            ClaimsIdentity userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Agregar aquí notificaciones personalizadas de usuario
            return userIdentity;
        }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
            ((IObjectContextAdapter)this).ObjectContext.CommandTimeout = 300;
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
        public DbSet<ANA_Argumento> ANA_Argumento { get; set; }
        public DbSet<sp_EMPRESA_RamoVehiculo_Permiso> sp_EMPRESA_RamoVehiculo_Permiso { get; set; }
        public DbSet<EmpresaRamoVehiculo> EmpresaRamoVehiculo { get; set; }
        public DbSet<ReporteCostco> ReporteCostco {  get; set; }
        public DbSet<LinkPagoPlantilla> LinkPagoPlantilla {  get; set; }
        public DbSet<Mit_Bitacora> Mit_Bitacora {  get; set; }
        public DbSet<ConvenioCondicionesParticulares> ConvenioCondicionesParticulares {  get; set; }
        public DbSet<Poliza_EstatusAseguradora> Poliza_EstatusAseguradora {  get; set; }
        public DbSet<AvisoInicioBitacora> AvisoInicioBitacora { get; set; }
        public DbSet<CalendarioCobranza> CalendarioCobranza { get; set; }
        public DbSet<ReciboAseguradora_Opera> ReciboAseguradora_Opera {  get; set; }
        public DbSet<CalendarioCobranza_Recibo> CalendarioCobranza_Recibo {  get; set; }
        public DbSet<EmisionProductoBitacora> EmisionProductoBitacora { get; set; }
        public DbSet<EmisionProductoPagoBitacora> EmisionProductoPagoBitacora { get; set; }
        public DbSet<ReciboAseguradora_Estatus> ReciboAseguradora_Estatus { get; set; }
        public DbSet<PolizaProducto> PolizaProducto { get; set; }
        public DbSet<Bitacora_DerivacionOpera> Bitacora_DerivacionOpera {  get; set; }
        public DbSet<PolizaProductoDetalle> PolizaProductoDetalle { get; set; }
        public DbSet<AvisoAutoEspecial> AvisoAutoEspecial { get; set; }
        public DbSet<CatTipoDatoDeducible> CatTipoDatoDeducible { get; set; }
        public DbSet<CatClasificacionLead> CatClasificacionLead { get; set; }
        public DbSet<CatSubClasificacionLead> CatSubClasificacionLead { get; set; }
        public DbSet<ConvenioTarifa> ConvenioTarifa { get; set; }
        public DbSet<SP_TARIFAS_INBURSA_VALIDACION> SP_TARIFAS_INBURSA_VALIDACION { get; set; }
        public DbSet<CatTipoComparativo_Orden> CatTipoComparativo_Orden { get; set; }
        public DbSet<sp_RENOVACION_DatosOT> sp_RENOVACION_DatosOT { get; set; }
        public DbSet<sp_LeadsCasaHabitacion_SELECT_Cotizacion> sp_LeadsCasaHabitacion_SELECT_Cotizacion { get; set; }
        public DbSet<CRM_Bitacora> CRM_Bitacora { get; set; }
        public DbSet<TarifaINBURSA_Ejecucion> TarifaINBURSA_Ejecucion { get; set; }
        public DbSet<EmpresaResetPassword> EmpresaResetPassword { get; set; }
        public DbSet<AltoRiesgo_Aseguradora> AltoRiesgo_Aseguradora { get; set; }
        public DbSet<sp_ALTO_RIESGO_resumen> sp_ALTO_RIESGO_resumen { get; set; }
        public DbSet<ArchivoConvenio> ArchivoConvenio { get; set; }
        public DbSet<PolizaProcesoDerivacion> PolizaProcesoDerivacion { get; set; }
        public DbSet<ArchivoConvenioProducto> ArchivoConvenioProducto { get; set; }
        public DbSet<CondicionGeneralArchivo> CondicionGeneralArchivo { get; set; }
        public DbSet<SP_CondicionesGenerales_Empresa> SP_CondicionesGenerales_Empresa { get; set; }
        public DbSet<CondicionGeneralProceso> CondicionGeneralProceso { get; set; }
        public DbSet<CondicionGeneralBitacora> CondicionGeneralBitacora { get; set; }
        public DbSet<CatTipoDocumento> CatTipoDocumento { get; set; }
        public DbSet<VersionAseguradora> VersionAseguradora { get; set; }
        public DbSet<ArchivoEmpresa> ArchivoEmpresa { get; set; }
        public DbSet<BitacoraCostco> BitacoraCostco { get; set; }
        public DbSet<Micrositio> Micrositio { get; set; }
        public DbSet<CatMicrositio> CatMicrositio { get; set; }
        public DbSet<BitacoraExatec> BitacoraExatec { get; set; }
        public DbSet<EmisionMasiva_Poliza> EmisionMasiva_Poliza { get; set; }
        public DbSet<sp_EMISION_MASIVA_resumen> sp_EMISION_MASIVA_resumen { get; set; }
        public DbSet<sp_GET_CondicionGeneralBitacora> sp_GET_CondicionGeneralBitacora { get; set; }
        public DbSet<ConvenioTipoModificacion> ConvenioTipoModificacion { get; set; }
        public DbSet<AccesoBeneficiarioPreferente> AccesoBeneficiarioPreferente { get; set; }
        public DbSet<AccesoValorFactura> AccesoValorFactura { get; set; }
        public DbSet<Aseguradora> Aseguradora { get; set; }
        public DbSet<sp_COTIZACION_Aseguradoras_Usuario> sp_COTIZACION_Aseguradoras_Usuario { get; set; }
        public DbSet<EmisionMasiva_Poliza_Bitacora> EmisionMasiva_Poliza_Bitacora { get; set; }
        public DbSet<sp_CotizacioneCasaHabitacion> sp_CotizacioneCasaHabitacion { get; set; }
        public DbSet<CatReportesPowerBI> CatReportesPowerBI { get; set; }
        public DbSet<sp_RENOVACIONES_lotes_resumen> sp_RENOVACIONES_lotes_resumen { get; set; }
        public DbSet<sp_RENOVACIONES_lotes_detalle> sp_RENOVACIONES_lotes_detalle { get; set; }
        public DbSet<Phonex_Token> Phonex_Token { get; set; }
        public DbSet<CotizacionAprobacion> CotizacionAprobacion { get; set; }
        public DbSet<CaratulaDeloitteAXA> CaratulaDeloitteAXA { get; set; }
        public DbSet<CaratulaINBURSA> CaratulaINBURSA { get; set; }
        public DbSet<CatMotivoCancelacionPoliza> CatMotivoCancelacionPoliza { get; set; }
        public DbSet<sp_Leads_SELECT_Cotizacion> sp_Leads_SELECT_Cotizacion { get; set; }
        public DbSet<TarifaHOMOLOGADO_Log> TarifaHOMOLOGADO_Log { get; set; }
        public DbSet<TarifaHOMOLOGADO_Ejecucion> TarifaHOMOLOGADO_Ejecucion { get; set; }
        public DbSet<sp_RENOVACIONES_polizas_resumen> sp_RENOVACIONES_polizas_resumen { get; set; }
        public DbSet<sp_RENOVACIONES_polizas_detalle> sp_RENOVACIONES_polizas_detalle { get; set; }
        public DbSet<sp_SEGUIMIENTOCOTIZACION_consulta_notificaciones> sp_SEGUIMIENTOCOTIZACION_consulta_notificaciones { get; set; }
        public DbSet<sp_CONVENIO_SELECT_CoberturasVehiculo> sp_CONVENIO_SELECT_CoberturasVehiculo { get; set; }
        public DbSet<sp_CONVENIO_SELECT_CoberturasEspeciales> sp_CONVENIO_SELECT_CoberturasEspeciales { get; set; }
        public DbSet<TIPOMODIFICACION_SELECT_Convenio> TIPOMODIFICACION_SELECT_Convenio { get; set; }
        public DbSet<sp_Emision_ValidacionNumeroSerie> sp_Emision_ValidacionNumeroSerie { get; set; }
        public DbSet<sp_reporte_polizas_gerencia_instalacion_cobranza> sp_reporte_polizas_gerencia_instalacion_cobranza { get; set; }
        public DbSet<CatAgrupaVehiculo> CatAgrupaVehiculo { get; set; }
        public DbSet<CatBanco> CatBanco { get; set; }
        public DbSet<Facturacion> Facturacion { get; set; }
        public DbSet<CatProfesion> CatProfesion { get; set; }
        public DbSet<CatOcupacion> CatOcupacion { get; set; }
        public DbSet<Notificaciones> Notificaciones { get; set; }
        public DbSet<NotificacionGrupo> NotificacionGrupo { get; set; }
        public DbSet<NotificacionNegocio> NotificacionNegocio { get; set; }
        public DbSet<NotificacionProgramacion> NotificacionProgramacion { get; set; }
        public DbSet<NotificacionPolizas> NotificacionPolizas { get; set; }
        public DbSet<SeguridadSolicitudCambio> SeguridadSolicitudCambio { get; set; }
        public DbSet<API_Process> API_Process { get; set; }
        public DbSet<CatBeneficiarioPreferente> CatBeneficiarioPreferente { get; set; }
        public DbSet<NotificacionServer> NotificacionServer { get; set; }
        public DbSet<CatCarriers> CatCarriers { get; set; }
        public DbSet<CatSistemaOrigen> CatSistemaOrigen { get; set; }
        public DbSet<CatCatalogoTipoDeducible> CatCatalogoTipoDeducible { get; set; }
        public DbSet<CatCentroCostos> CatCentroCostos { get; set; }
        public DbSet<Endoso_PROCESO_Cierre> Endoso_PROCESO_Cierre { get; set; }
        public DbSet<sp_INSERCIONSICAS_ObtieneDatosCliente> sp_INSERCIONSICAS_ObtieneDatosCliente { get; set; }
        public DbSet<sp_InsertDir_Core> sp_InsertDir_Core { get; set; }
        public DbSet<sp_INSERCIONSICAS_ObtieneAgente> sp_INSERCIONSICAS_ObtieneAgente { get; set; }
        public DbSet<CatClientesQualitasCondAdicional> CatClientesQualitasCondAdicional { get; set; }
        public DbSet<CatCoberturaPerdidaParcial> CatCoberturaPerdidaParcial { get; set; }
        public DbSet<CatCondicion> CatCondicion { get; set; }
        public DbSet<CatEstadosRepublica> CatEstadosRepublica { get; set; }
        public DbSet<PolizaCancelacionDocumento> PolizaCancelacionDocumento { get; set; }
        public DbSet<sp_ConsultaPolizas_Canceladas_BeMobile> sp_ConsultaPolizas_Canceladas_BeMobile { get; set; }
        public DbSet<VUsuario> VUsuario { get; set; }
        public DbSet<Permisos> Permisos { get; set; }
        public DbSet<Proventel_Envio> Proventel_Envio { get; set; }
        public DbSet<CatFormaPago> CatFormaPago { get; set; }
        public DbSet<CatGenero> CatGenero { get; set; }
        public DbSet<sp_reporte_bemobile> sp_reporte_bemobile { get; set; }
        public DbSet<CatGiroBase> CatGiroBase { get; set; }
        public DbSet<EmpresaDeloitte> EmpresaDeloitte { get; set; }
        public DbSet<CatGNPOpcionesContratarConvenio> CatGNPOpcionesContratarConvenio { get; set; }
        public DbSet<CatImportanciaContenido> CatImportanciaContenido { get; set; }
        public DbSet<CatModalidadFormaPago> CatModalidadFormaPago { get; set; }
        public DbSet<TipoUsoVehiculo> TipoUsoVehiculo { get; set; }
        public DbSet<Vehiculosdisponibles> Vehiculosdisponibles { get; set; }
        public DbSet<CatMotivoCancelacion> CatMotivoCancelacion { get; set; }
        public DbSet<CatNacionalidad> CatNacionalidad { get; set; }
        public DbSet<CatUsos> CatUsos { get; set; }
        public DbSet<CatUsosConvenio> CatUsosConvenio { get; set; }
        public DbSet<HDI_TipoPaquete> HDI_TipoPaquete { get; set; }
        public DbSet<CatOficinaReferencia> CatOficinaReferencia { get; set; }
        public DbSet<CatParentesco> CatParentesco { get; set; }
        public DbSet<CatPeriodicidadFormaPago> CatPeriodicidadFormaPago { get; set; }
        public DbSet<CatPeriodicidadMultianual> CatPeriodicidadMultianual { get; set; }
        public DbSet<PeriodicidadMultianual> PeriodicidadMultianual { get; set; }
        public DbSet<CatPeriodicidadMultianualCORE> CatPeriodicidadMultianualCORE { get; set; }
        public DbSet<CatPeriodicidadOPL> CatPeriodicidadOPL { get; set; }
        public DbSet<CatPrimaAnualizada> CatPrimaAnualizada { get; set; }
        public DbSet<ConfiguracionEmpresaCotizacion> ConfiguracionEmpresaCotizacion { get; set; }
        public DbSet<CatRamoVehiculo> CatRamoVehiculo { get; set; }
        public DbSet<CatSolicitaCancelacion> CatSolicitaCancelacion { get; set; }
        public DbSet<CatSubRamoVehiculo> CatSubRamoVehiculo { get; set; }
        public DbSet<CatTipoCobertura> CatTipoCobertura { get; set; }
        public DbSet<CatTipoComision> CatTipoComision { get; set; }
        public DbSet<CatTipoComparativo> CatTipoComparativo { get; set; }
        public DbSet<CatTipoContenido> CatTipoContenido { get; set; }
        public DbSet<CatTipoContratante> CatTipoContratante { get; set; }
        public DbSet<CatTipoConvenio> CatTipoConvenio { get; set; }
        public DbSet<CatTipoEntradaHistorico> CatTipoEntradaHistorico { get; set; }
        public DbSet<CatTipoModificacion> CatTipoModificacion { get; set; }
        public DbSet<CatTipoNegociacion> CatTipoNegociacion { get; set; }
        public DbSet<CatTipoNegocio> CatTipoNegocio { get; set; }
        public DbSet<CatTipoPaquete> CatTipoPaquete { get; set; }
        public DbSet<CatTipoPersona> CatTipoPersona { get; set; }
        public DbSet<CatTipoPosicion> CatTipoPosicion { get; set; }
        public DbSet<CatClavePorcentajeDescuento> CatClavePorcentajeDescuento { get; set; }
        public DbSet<CoberturaHDI> CoberturaHDI { get; set; }
        public DbSet<CatDeloitte> CatDeloitte { get; set; }
        public DbSet<CatTipoProceso> CatTipoProceso { get; set; }
        public DbSet<CatTipoSumaAsegVehiculo> CatTipoSumaAsegVehiculo { get; set; }
        public DbSet<CatTipoUsoVehiculo> CatTipoUsoVehiculo { get; set; }
        public DbSet<CatTipoValidacionMembresia> CatTipoValidacionMembresia { get; set; }
        public DbSet<CatTipoVehiculo> CatTipoVehiculo { get; set; }
        public DbSet<CatTipoVigencia> CatTipoVigencia { get; set; }
        public DbSet<CatUsoVehiculo> CatUsoVehiculo { get; set; }
        public DbSet<CatAseguradoraUsoVehiculo> CatAseguradoraUsoVehiculo { get; set; }
        public DbSet<CatUsuarioSolicitaCancelacion> CatUsuarioSolicitaCancelacion { get; set; }
        public DbSet<CatValorFactura> CatValorFactura { get; set; }
        public DbSet<CatZonaCotizacion> CatZonaCotizacion { get; set; }
        public DbSet<Cobertura> Cobertura { get; set; }
        public DbSet<CoberturaBase> CoberturaBase { get; set; }
        public DbSet<CoberturaOpcional> CoberturaOpcional { get; set; }
        public DbSet<CondicionEspecial> CondicionEspecial { get; set; }
        public DbSet<ConfiguracionEmpresa> ConfiguracionEmpresa { get; set; }
        //CAT: Habilita el acceso a la configuracion independiente de domiciliacion GNP desde la aplicacion web.
        public DbSet<ConfiguracionDomiciliacionGNP> ConfiguracionDomiciliacionGNP { get; set; }
        public DbSet<ConfiguracionEmpresaPorProducto> ConfiguracionEmpresaPorProducto { get; set; }
        public DbSet<CatAseguradoraHorario> CatAseguradoraHorario { get; set; }
        public DbSet<ConvenioTipoModificacionProducto> ConvenioTipoModificacionProducto { get; set; }
        public DbSet<ConfigWS> ConfigWS { get; set; }
        public DbSet<ControladorMenu> ControladorMenu { get; set; }
        public DbSet<CatCaratulaAXA> CatCaratulaAXA { get; set; }
        public DbSet<CatCaratulaOperaAXA> CatCaratulaOperaAXA { get; set; }
        public DbSet<CatCaratulaAXA_Index> CatCaratulaAXA_Index { get; set; }
        public DbSet<Convenio> Convenio { get; set; }
        public DbSet<Convenio2> Convenio2 { get; set; }
        public DbSet<ConvenioParentesco> ConvenioParentesco { get; set; }
        public DbSet<ConvenioRamoPaquete> ConvenioRamoPaquete { get; set; }
        public DbSet<Corporativo> Corporativo { get; set; }
        public DbSet<Cotizacion> Cotizacion { get; set; }
        public DbSet<ListaCombo> ListaCombo { get; set; }
        public DbSet<EmisionMasiva_Ejecucion> EmisionMasiva_Ejecucion { get; set; }
        public DbSet<sp_COBRANZA_CalendarioRecibo_Polizas> sp_COBRANZA_CalendarioRecibo_Polizas {  get; set; }
        public DbSet<Bitacora> Bitacora { get; set; }
        public DbSet<BitacoraCotizacionError> BitacoraError { get; set; }
        public DbSet<BitacoraPolizas> BitacoraPolizas { get; set; }
        public DbSet<EndosoCore> EndosoCore { get; set; }
        public DbSet<BitacoraPeticion> BitacoraPeticion { get; set; }
        public DbSet<CotizacionDetalle> CotizacionDetalle { get; set; }
        public DbSet<CotizacionAuto> CotizacionAuto { get; set; }
        public DbSet<ConvenioDescuentoEstado> ConvenioDescuentoEstado { get; set; }
        public DbSet<sp_reporte_discrepancias> sp_reporte_discrepancias {  get; set; }
        public DbSet<sp_reporte_cambioestatuspoliza> sp_reporte_cambioestatuspoliza {  get; set; }
        public DbSet<sp_reporte_cambioestatusrecibo> sp_reporte_cambioestatusrecibo { get; set; }
        public DbSet<DetallePrimerIngreso> DetallePrimerIngreso { get; set; }
        public DbSet<DetallesSesion> DetallesSesion { get; set; }
        public DbSet<PolizaRegistroCobranza> PolizaRegistroCobranza { get; set; }
        public DbSet<DetalleUsuario> DetalleUsuario { get; set; }
        public DbSet<DetalleUsuarioBeFlex> DetalleUsuarioBeFlex { get; set; }
        public DbSet<DetalleUsuariosNoMigrados> DetalleUsuariosNoMigrados { get; set; }
        public DbSet<sp_ObtenerExisteUsuario> sp_ObtenerExisteUsuario { get; set; }
        public DbSet<DetalleUsuarioEmpresa> DetalleUsuarioEmpresa { get; set; }
        public DbSet<Direccion> Direccion { get; set; }
        public DbSet<Empresa> Empresa { get; set; }
        public DbSet<EmpresaConvenio> EmpresaConvenio { get; set; }
        public DbSet<CalendarioCancelacionPoliza> CalendarioCancelacionPoliza { get; set; }

        public DbSet<Endoso> Endoso { get; set; }
        public DbSet<EndosoArchivo> EndosoArchivo { get; set; }
        public DbSet<EndosoB> EndosoB { get; set; }
        public DbSet<EndosoBTipo> EndosoBTipo { get; set; }
        public DbSet<Enrollment> Enrollment { get; set; }
        public DbSet<HistoricoContrasena> HistoricoContrasenas { get; set; }
        public DbSet<InfoBeflex> InfoBeflex { get; set; }
        public DbSet<MapaControlador> MapaControlador { get; set; }
        public DbSet<MarcaVehiculo> MarcaVehiculo { get; set; }
        public DbSet<ModalidadFormaPago> ModalidadFormaPago { get; set; }
        public DbSet<ModeloVehiculo> ModeloVehiculo { get; set; }
        public DbSet<OTRenovacion> OTRenovacion { get; set; }
        public DbSet<Paquete> Paquete { get; set; }
        public DbSet<PaqueteAseguradora> PaqueteAseguradora { get; set; }
        public DbSet<PaqueteConvenio> PaqueteConvenio { get; set; }
        public DbSet<PaqueteDetalle> PaqueteDetalle { get; set; }
        public DbSet<PaqueteDetalleOpcional> PaqueteDetalleOpcional { get; set; }
        public DbSet<CoberturaINBURSAEspecial> CoberturaINBURSAEspecial { get; set; }
        public DbSet<Perfiles> Perfiles { get; set; }
        public DbSet<PerfilesJerarquia> PerfilesJerarquia { get; set; }
        public DbSet<PerfilesRoles> PerfilesRoles { get; set; }
        public DbSet<PeriodicidadFormaPago> PeriodicidadFormaPago { get; set; }
        public DbSet<Persona> Persona { get; set; }
        public DbSet<PersonalizaEmpresaCorreo> PersonalizaEmpresaCorreo { get; set; }
        public DbSet<PersonalizaEmpresaLandF> PersonalizaEmpresaLandF { get; set; }
        public DbSet<Poliza> Poliza { get; set; }
        public DbSet<ReciboAseguradora_Discrepancia> ReciboAseguradora_Discrepancia { get; set; }
        public DbSet<ReciboAseguradora_CambioEstatusPoliza> ReciboAseguradora_CambioEstatusPoliza { get; set; }
        public DbSet<ReciboAseguradora_CambioEstatusRecibo> ReciboAseguradora_CambioEstatusRecibo { get; set; }
        public DbSet<sp_POLIZA_DatosUsuario> sp_POLIZA_DatosUsuario { get; set; }
        public DbSet<sp_POLIZA_DatosPoliza> sp_POLIZA_DatosPoliza { get; set; }
        public DbSet<sp_POLIZA_Recibos> sp_POLIZA_Recibos { get; set; }
        public DbSet<CatCaratulaQUALITAS> CatCaratulaQUALITAS { get; set; }
        public DbSet<ReciboAseguradora_Rechazo> ReciboAseguradora_Rechazo {  get; set; }
        public DbSet<Bitacora_NotificacionesCorreos> Bitacora_NotificacionesCorreos { get; set; }
        public DbSet<Recibo> Recibo { get; set; }
        //public  DbSet<SolicitudEndoso> SolicitudEndoso { get; set; }
        public DbSet<Submarca> Submarca { get; set; }
        public DbSet<sysdiagrams> sysdiagrams { get; set; }
        public DbSet<db.Vehiculo> Vehiculo { get; set; }
        public DbSet<UsuarioSolicitaCancelacion> UsuarioSolicitaCancelacion { get; set; }
        public DbSet<Ejecutivo> Ejecutivoes { get; set; }
        public DbSet<PersonaMoral> PersonaMoral { get; set; }
        public DbSet<RepresentanteLegal> RepresentanteLegals { get; set; }
        public DbSet<PersonaMoralRepresentanteLegal> PersonaMoralRepresentanteLegal { get; set; }
        public DbSet<CatPais> CatPais { get; set; }
        public DbSet<CatTipoIdentificacion> CatTipoIdentificacions { get; set; }
        public DbSet<CoberturasCondicionesEspeciales> CoberturasCondicionesEspeciales { get; set; }
        public DbSet<CoberturaMAPFRERoboParcial> CoberturaMAPFRERoboParcial { get; set; }
        public DbSet<sp_obtener_polizas_core> sp_obtener_polizas_core { get; set; }
        public DbSet<Zendesk> Zendesk { get; set; }
        public DbSet<ZendeskNotificacion> ZendeskNotificacion { get; set; }
        public DbSet<sp_obtener_polizas_core_gerencia_M> sp_obtener_polizas_core_gerencia_M { get; set; }
        public DbSet<PolizaDetalle> PolizaDetalle { get; set; }
        public DbSet<PolizaAliasLog> PolizaAliasLog { get; set; }
        public DbSet<CatBancosAseguradoras> CatBancosAseguradoras { get; set; }
        public DbSet<CatBancosAseguradoraExclusivo> CatBancosAseguradoraExclusivo { get; set; }
        public DbSet<CodigoPostal> CatCodigoPostal { get; set; }
        public DbSet<EstatusPoliza> CatEstatusPoliza { get; set; }
        public DbSet<TipoEndoso> TipoEndoso { get; set; }
        public DbSet<FechaCobroMAPFRE> FechaCobroMAPFRE { get; set; }
        public DbSet<Sucursal> Sucursal { get; set; }
        public DbSet<CatParametro> CatParametro { get; set; }
        public DbSet<ReporteConciliacion> ReporteConciliacion { get; set; }
        public DbSet<EstadisticasCostco> EstadisticasCostco { get; set; }
        public DbSet<ReporteBitacora> ReporteBitacora { get; set; }
        public DbSet<ReporteBitacoraCasa> ReporteBitacoraCasa { get; set; }
        public DbSet<CatGNPCaratula> CatGNPCaratula { get; set; }
        public DbSet<CatGNPCaratulaOpera> CatGNPCaratulaOpera { get; set; }
        public DbSet<CaratulasGNPConvenio> CaratulasGNPConvenio { get; set; }
        public DbSet<sp_CaratulasGNPOpera_Convenio> sp_CaratulasGNPOpera_Convenio { get; set; }
        public DbSet<CaratulaPaquete> CaratulaPaquete { get; set; }
        public DbSet<CatCaratulaPaquete> CatCaratulaPaquete { get; set; }
        public DbSet<CatEstadosGNP> CatEstadosGNP { get; set; }
        public DbSet<CatEstadosAXA> CatEstadosAXA { get; set; }
        public DbSet<CatOficinaContratacion> CatOficinaContratacion { get; set; }
        public DbSet<FormularioContacto> FormularioContacto { get; set; }
        public DbSet<DatDocumento> DatDocumento { get; set; }
        public DbSet<CatArrendadora> CatArrendadora { get; set; }
        public DbSet<DatosOpera> DatosOpera { get; set; }

        public DbSet<CatContactos> CatContactos { get; set; }
        public DbSet<ReportePolizas> ReportePolizas { get; set; }
        public DbSet<ReporteReciboPoliza> ReporteReciboPoliza { get; set; }
        public DbSet<ReporteEmisionesEnLinea> ReporteEmisionesEnLinea { get; set; }
        public DbSet<ReporteEndosos> ReporteEndosos { get; set; }
        public DbSet<ReporteUsuarios> ReporteUsuarios { get; set; }
        public DbSet<ReporteCotizaciones> ReporteCotizaciones { get; set; }
        public DbSet<Contratante> Contratante { get; set; }
        public DbSet<CatVendedor> CatVendedor { get; set; }
        public DbSet<GMX_PlanRelacion> GMX_PlanRelacion { get; set; }   
        public DbSet<ConsultaPolizaInciso> ConsultaPolizaInciso { get; set; }
        public DbSet<sp_GetDataDocumentoCore> sp_GetDataDocumentoCore { get; set; }
        public DbSet<PolizaProcesoMasivo> PolizaProcesoMasivo { get; set; }
        public DbSet<DataEndosoCancelationDocument> DataEndosoCancelationDocument { get; set; }
        public DbSet<PolizasMigradas> PolizasMigradas { get; set; }
        public DbSet<sp_ConsultaPolizas_Migrar_BeMobile> sp_ConsultaPolizas_Migrar_BeMobile { get; set; }
        public DbSet<ReportePolizasCobranzaRechazada> ReportePolizasCobranzaRechazada { get; set; }
        public DbSet<sp_reporte_endosos> sp_reporte_endosos { get; set; }
        public DbSet<CredencialesWebServiceOpera> CredencialesWebServiceOpera { get; set; }
        public DbSet<ZendeskCobranzaFallida> ZendeskCobranzaFallida { get; set; }
        public DbSet<SP_ObtenerAspNetUser> SP_ObtenerAspNetUsers { get; set; }
        public DbSet<sp_RENOVACIONES_lotes_conversiones> sp_RENOVACIONES_lotes_conversiones { get; set; }
        public DbSet<sp_RENOVACIONES_polizas_vencimiento> sp_RENOVACIONES_polizas_vencimiento { get; set; }
        public DbSet<SP_ObtenerAspUser> SP_ObtenerAspUsers { get; set; }
        public DbSet<TarifaQUALITAS> TarifaQUALITAS { get; set; }
        public DbSet<TarifaQUALITASCategoria> TarifaQUALITASCategoria { get; set; }
        public DbSet<Catalogo_No_Proveedor_IKE> Catalogo_No_Proveedor_IKE { get; set; }
        public DbSet<Proveedor_IKE> Proveedor_IKE { get; set; }
        public DbSet<DatosUnidad_IKE> DatosUnidad_IKE { get; set; }
        public DbSet<Tipo_GRUA> Tipo_GRUA { get; set; }
        public DbSet<TarifasProcesos> TarifasProcesos { get; set; }
        public DbSet<TarifaABA> TarifaABA { get; set; }
        public DbSet<TarifaABA_Log> TarifaABA_Log { get; set; }
        public DbSet<TarifaATLAS_Log> TarifaATLAS_Log { get; set; }
        public DbSet<TarifaATLASCategoria> TarifaATLASCategoria { get; set; }
        public DbSet<TarifaATLAS> TarifaATLAS { get; set; }
        public DbSet<TarifaMAPFRE_Log> TarifaMAPFRE_Log { get; set; }
        public DbSet<TarifaMAPFRECategoria> TarifaMAPFRECategoria { get; set; }
        public DbSet<TarifaMAPFRE> TarifaMAPFRE { get; set; }
        public DbSet<TarifaGNP_Log> TarifaGNP_Log { get; set; }
        public DbSet<TarifaANA_Log> TarifaANA_Log { get; set; }
        public DbSet<TarifaGNP> TarifaGNP { get; set; }
        public DbSet<TarifaGNPCategoria> TarifaGNPCategoria { get; set; }
        public DbSet<TarifaMarcasAXA> TarifaMarcasAXA { get; set; }
        public DbSet<TarifaEspecialMarcasAXA> TarifaEspecialMarcasAXA { get; set; }
        public DbSet<TarifaAXA_Log> TarifaAXA_Log { get; set; }
        public DbSet<TarifaEspecialAXA_Log> TarifaEspecialAXA_Log { get; set; }
        public DbSet<TarifaTipoVehiculoAXA> TarifaTipoVehiculoAXA { get; set; }
        public DbSet<TarifaEspecialTipoVehiculoAXA> TarifaEspecialTipoVehiculoAXA { get; set; }
        public DbSet<TarifaAXA> TarifaAXA { get; set; }
        public DbSet<TarifaEspecialAXA> TarifaEspecialAXA { get; set; }
        #region Seguridad
        public DbSet<SeguridadParametros> SeguridadParametros { get; set; }
        public DbSet<EsquemaParametros> EsquemaParametros { get; set; }
        public DbSet<SeguridadEsquema> SeguridadEsquema { get; set; }
        public DbSet<EsquemaComplejidad> EsquemaComplejidad { get; set; }
        public DbSet<ComplejidadContrasenas> ComplejidadContrasenas { get; set; }
        public DbSet<sp_ObtenerEsquemaSeguridad> sp_ObtenerEsquemaSeguridad { get; set; }
        public DbSet<sp_ObtenerComplejidadContrasenas> sp_ObtenerComplejidadContrasenas { get; set; }
        public DbSet<SeguridadValidarUrl> SeguridadValidarUrl { get; set; }
        #endregion
        public DbSet<CatEstadoCivil> CatEstadoCivil { get; set; }
        public DbSet<CatTipoContratanteCasa> CatTipoContratanteCasa { get; set; }
        public DbSet<CatTipoConstruccion> CatTipoConstruccion { get; set; }
        public DbSet<PaqueteConvenioProducto> PaqueteConvenioProducto { get; set; }
        public DbSet<PaqueteDetalleProducto> PaqueteDetalleProducto { get; set; }
        public DbSet<ConvenioProductos> ConvenioProductos { get; set; }
        public DbSet<CatTipoPaqueteProducto> CatTipoPaqueteProducto { get; set; }
        //public DbSet<PeriodicidadFormaPagoProducto> PeriodicidadFormaPagoProducto { get; set; }
        public DbSet<CotizacionCasa> CotizacionCasa { get; set; }
        public DbSet<CoberturaProducto> CoberturaProducto { get; set; }
        public DbSet<CatModalidadFormaPagoProducto> CatModalidadFormaPagoProducto { get; set; }
        public DbSet<CotizacionDatosCasa> CotizacionDatosCasa { get; set; }

        public DbSet<sp_reporte_cotizacionesMascotas_gerencia> sp_reporte_cotizacionesMascotas_gerencia { get; set; }

        //Cambios Casa Habitacion
        //Daniel Zamora
        public DbSet<CatProductos> CatProductos { get; set; }
        public DbSet<AseguradoraProducto> AseguradoraProductos { get; set; }
        public DbSet<CatSubRamoProducto> CatSubRamoProducto { get; set; }
        public DbSet<CatRamoProducto> CatRamoProducto { get; set; }
        public DbSet<ConvenioRamoPaqueteProducto> ConvenioRamoPaqueteProducto { get; set; }
        public DbSet<CatTipoSumaAsegProducto> CatTipoSumaAsegProducto { get; set; }
        public DbSet<CatPeriodicidadFormaPagoProducto> CatPeriodicidadFormaPagoProducto { get; set; }
        public DbSet<PeriodicidadFormaPagoProducto> PeriodicidadFormaPagoProducto { get; set; }
        public DbSet<UsuarioSolicitaCancelacionProducto> UsuarioSolicitaCancelacionProducto { get; set; }
        public DbSet<CatZonaCotizacionProducto> CatZonaCotizacionProducto { get; set; }
        public DbSet<TIPOMODIFICACION_SELECT_Convenio_Producto> TIPOMODIFICACION_SELECT_Convenio_Producto { get; set; }
        public DbSet<PaqueteProducto> PaqueteProducto { get; set; }
        public DbSet<CondicionEspecialProducto> CondicionEspecialProducto { get; set; }
        public DbSet<sp_CONVENIO_SELECT_CoberturasProducto> sp_CONVENIO_SELECT_CoberturasProducto { get; set; }
        public DbSet<sp_CONVENIO_SELECT_CoberturasEspecialesProductos> sp_CONVENIO_SELECT_CoberturasEspecialesProductos { get; set; }
        public DbSet<CoberturasCondicionesEspecialesProducto> CoberturasCondicionesEspecialesProducto { get; set; }
        public DbSet<CatTipoContratanteProducto> CatTipoContratanteProducto { get; set; }
        public DbSet<CotizacionDetalleCasa> CotizacionDetalleCasa { get; set; }
        public DbSet<CatCPCasa> CatCPCasa { get; set; }
        public DbSet<CoberturaBaseProducto> CoberturaBaseProducto { get; set; }
        public DbSet<PolizaCasa> PolizaCasa { get; set; }
        public DbSet<PolizaDetalleCasa> PolizaDetalleCasa { get; set; }
        public DbSet<ModalidadFormaPagoProducto> ModalidadFormaPagoProducto { get; set; }
        public DbSet<DatosOperaCasa> DatosOperaCasa { get; set; }
        public DbSet<CotizacionSinRegistro> CotizacionSinRegistro { get; set; }
        public DbSet<TicketZendeskCobranza> TicketZendeskCobranza { get; set; }

        public DbSet<MAPFRE_Nodo_Empresa> MAPFRE_Nodo_Empresa { get; set; }
        public DbSet<sp_ObtenerLeadsCorrectos> sp_ObtenerLeadsCorrectos { get; set; }
        public DbSet<sp_ObtenerLeadsEmisiones> sp_ObtenerLeadsEmisiones { get; set; }
        public DbSet<sp_ObtenerLeadsCorrectosCasa> sp_ObtenerLeadsCorrectosCasa { get; set; }
        public DbSet<sp_ObtenerLeadsEmisionesCasa> sp_ObtenerLeadsEmisionesCasa { get; set; }
        public DbSet<Auditoria> Auditoria { get; set; }
        public DbSet<CatRegimenFiscal> CatRegimenFiscal { get; set; }
        public DbSet<CatRegimenCapital> CatRegimenCapital { get; set; }
        public DbSet<CatUsoCFDI> CatUsoCFDI { get; set; }

        public DbSet<MFA_Perfiles> MFA_Perfiles { get; set; }
        public DbSet<MFATipoCodigo> MFATipoCodigo { get; set; }
        public DbSet<sp_mfa_get_user> sp_mfa_get_user { get; set; }
        public DbSet<sp_mfa_get_users> sp_mfa_get_users { get; set; }
        public DbSet<CatConfiguracionOrdenamiento> CatConfiguracionOrdenamiento { get; set; }
        public DbSet<BitacoraTicketsCobranza> BitacoraTicketsCobranza { get; set; }
        public DbSet<SP_ObtenerIntentosCobranzaPorDia> SP_ObtenerIntentosCobranzaPorDia { get; set; }
        public DbSet<CatalogoErrorInstalacionDatosBancarios> CatalogoErrorInstalacionDatosBancarios { get; set; }
        public DbSet<SP_GetDocumentosGerenciaDXN> SP_GetDocumentosGerenciaDXN { get; set; }
        public DbSet<TarifaQUALITAS_Log> TarifaQUALITAS_Log { get; set; }
        public DbSet<SelectOptionAdicional> SelectOptionAdicional { get; set; }
        public DbSet<SelectOption> SelectOption { get; set; }
        public DbSet<ConvenioMSI> ConvenioMSI { get; set; }
        public DbSet<CatMesesSinIntereses> CatMesesSinIntereses { get; set; }
        public DbSet<ConfiguracionMSI> ConfiguracionMSI { get; set; }
        public DbSet<sp_MSI_Valida_Aplica> sp_MSI_Valida_Aplica { get; set; }
        public virtual DbSet<RolesNoMostrarsePorPerfil> RolesNoMostrarsePorPerfil { get; set; }
        public virtual DbSet<SeguimientoCotizacionTipo> SeguimientoCotizacionTipo { get; set; }
        public virtual DbSet<SeguimientoCotizacionPlantillas> SeguimientoCotizacionPlantillas { get; set; }
        public DbSet<NotificacionTipo> NotificacionTipo { get; set; }
        public DbSet<NotificacionPlantillas> NotificacionPlantillas { get; set; }
        public DbSet<NotificacionSMTP> NotificacionSMTP { get; set; }
        public DbSet<SeguimientoCotizacionSMTP> SeguimientoCotizacionSMTP { get; set; }
        public DbSet<sp_RENOVACIONES_Decrypt> sp_RENOVACIONES_Decrypt { get; set; }
        public DbSet<UsuarioProcesoMasivo> UsuarioProcesoMasivo { get; set; }
        public DbSet<PeticionProcesoMasivoUsuario> PeticionProcesoMasivoUsuario { get; set; }
        public DbSet<PROCESO_EstadisticasCostco> PROCESO_EstadisticasCostco { get; set; }
        public DbSet<LinkPagoMasivo_Ejecucion> LinkPagoMasivo_Ejecucion { get; set; }
        public DbSet<sp_LINK_PAGO_resumen> sp_LINK_PAGO_resumen { get; set; }
        public DbSet<EndosoBitacora> EndosoBitacora { get; set; }
        public DbSet<LinkPagoMasivo_Poliza> LinkPagoMasivo_Poliza { get; set; }
        public DbSet<PolizaCancelacion> PolizaCancelacion { get; set; }
        public DbSet<sp_POLIZA_ReciboActual> sp_POLIZA_ReciboActual { get; set; }
        public DbSet<sp_obtener_cotizaciones_casa_empresa> sp_obtener_cotizaciones_casa_empresa { get; set; }
        public DbSet<SP_ObtenerUsuariosNoMigradosLoneACore> SP_ObtenerUsuariosNoMigradosLoneACore { get; set; }
        public DbSet<sp_ObtenerXMLS_Poliza> sp_ObtenerXMLS_Poliza { get; set; }
        public DbSet<sp_ObtenerXMLS_Casa> sp_ObtenerXMLS_Casa { get; set; }

        public DbSet<ReciboAseguradora_Bitacora> ReciboAseguradora_Bitacora { get; set; }
        public DbSet<ReciboAseguradora> ReciboAseguradora { get; set; }

        //OHSS 
        //Configuracion Tipo Negocio
        public DbSet<CatConfiguracionMensajeAutoEspecial> CatConfiguracionMensajeAutoEspecial { get; set; }
        public DbSet<ConfiguracionMensajeAutoEspecial> ConfiguracionMensajeAutoEspecial { get; set; }
        //ohss
        //mascotas
        public DbSet<CotizacionProducto> CotizacionProducto { get; set; }
        public DbSet<CotizacionProductoDetalle> CotizacionProductoDetalle { get; set; }
        public DbSet<CoberturaRelacion> CoberturaRelacion { get; set; }

        //Seguimiento Cotizacion
        public DbSet<SeguimientoCotizacion> SeguimientoCotizacion { get; set; }
        public DbSet<SeguimientoCotizacionEmpresa> SeguimientoCotizacionEmpresa { get; set; }
        public DbSet<CostcoMembershipAccess> CostcoMembershipAccess {  get; set; }
        public DbSet<sp_COMPARATIVO_ConcicionesParticulares> sp_COMPARATIVO_ConcicionesParticulares { get; set; }
        public DbSet<sp_RENOVACIONES_ConveniosEmpresa> sp_RENOVACIONES_ConveniosEmpresa { get; set; }
        public DbSet<sp_Emision_ValidaSeriePolizaAnterior> sp_Emision_ValidaSeriePolizaAnterior { get; set; }
        public DbSet<sp_COMPARATIVO_DatosCotizacion> sp_COMPARATIVO_DatosCotizacion { get; set; }
        public DbSet<sp_COMPARATIVO_Coberturas> sp_COMPARATIVO_Coberturas { get; set; }
        public DbSet<sp_COMPARATIVO_Paquetes> sp_COMPARATIVO_Paquetes { get; set; }
        public DbSet<sp_COMPARATIVO_Primas> sp_COMPARATIVO_Primas { get; set; }
        public DbSet<sp_CALENDARIOCOBRANZA_Empresa> sp_CALENDARIOCOBRANZA_Empresa { get; set; }
        public DbSet<sp_CALENDARIOCOBRANZA_REPORTE> sp_CALENDARIOCOBRANZA_REPORTE { get; set; }
        public string ExecuteScalarScript(string _script)
        { 
            return this.Database.SqlQuery<string>(_script).FirstOrDefault();
        }
        public int ExecuteScalarScriptInt(string _script)
        { // Instance.SqlQuery for SP that Generate Views
            return this.Database.SqlQuery<int>(_script).SingleOrDefault();
        }
    }

}


