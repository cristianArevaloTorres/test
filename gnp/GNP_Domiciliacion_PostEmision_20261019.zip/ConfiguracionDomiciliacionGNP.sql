--CAT: Crea una configuracion independiente por convenio para habilitar la domiciliacion posterior a la emision GNP.
IF OBJECT_ID(N'dbo.ConfiguracionDomiciliacionGNP', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ConfiguracionDomiciliacionGNP
    (
        Id INT IDENTITY(1, 1) NOT NULL,
        IdConvenio INT NOT NULL,
        AplicaDomiciliacionPostEmision BIT NOT NULL
            CONSTRAINT DF_ConfiguracionDomiciliacionGNP_Aplica DEFAULT (0),
        FechaCreacion DATETIME NOT NULL
            CONSTRAINT DF_ConfiguracionDomiciliacionGNP_FechaCreacion DEFAULT (GETDATE()),
        FechaModificacion DATETIME NULL,
        IdUsuarioCreacion NVARCHAR(128) NULL,
        IdUsuarioModificacion NVARCHAR(128) NULL,
        CONSTRAINT PK_ConfiguracionDomiciliacionGNP PRIMARY KEY CLUSTERED (Id),
        CONSTRAINT UQ_ConfiguracionDomiciliacionGNP_IdConvenio UNIQUE (IdConvenio),
        CONSTRAINT FK_ConfiguracionDomiciliacionGNP_Convenio
            FOREIGN KEY (IdConvenio) REFERENCES dbo.Convenio (Id)
    );
END;
