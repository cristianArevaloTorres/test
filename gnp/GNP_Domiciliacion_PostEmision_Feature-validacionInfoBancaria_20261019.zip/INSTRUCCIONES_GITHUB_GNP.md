# GNP: domiciliacion posterior a la emision

## Importante sobre esta carpeta

La carpeta `LocktonOneWeb-Feature-validacionInfoBancaria` recibida no contiene el directorio `.git`.
Por esa razon, los comandos Git deben ejecutarse en un clon real del repositorio y sobre la rama
`Feature-validacionInfoBancaria` (o el nombre exacto que aparezca en el remoto).

## 1. Cambiar a la rama correcta

```powershell
git fetch --all --prune
git branch --all
git switch Feature-validacionInfoBancaria
git pull --ff-only origin Feature-validacionInfoBancaria
git branch --show-current
```

Si la rama existe solamente en el remoto:

```powershell
git switch --track origin/Feature-validacionInfoBancaria
```

Después se deben copiar en ese clon los archivos contenidos en este ZIP, conservando sus carpetas.

## 2. Revisar y agregar solamente los archivos del cambio

```powershell
git status --short

git add -- `
  ConfiguracionDomiciliacionGNP.sql `
  INSTRUCCIONES_GITHUB_GNP.md `
  LocktonModel/LocktonModel.csproj `
  LocktonModel/IdentityModels.cs `
  LocktonModel/db/ConfiguracionDomiciliacionGNP.cs `
  LocktonModel/db/Convenio.cs `
  LocktonModel/db/LocktonOneDB.cs `
  LocktonModel/VModels/EmisionPoliza.cs `
  LocktonModel/VModels/VFormaDePago.cs `
  LocktonOneWeb/Views/Convenio/FormaPago.cshtml `
  LocktonOneWeb/Controllers/Convenio/ConvenioController.cs `
  LocktonOneWeb/Controllers/Cotizaciones/CotizacionController.cs `
  LocktonServicios/Aseguradoras/GNPInfoService.cs

git diff --cached --stat
git diff --cached
```

No se debe agregar la carpeta `packages`, ni las carpetas `bin` u `obj`.

## 3. Crear el commit y subir la rama actual

```powershell
git commit -m "feat(gnp): agrega domiciliacion posterior a la emision"
git push -u origin HEAD
```

## 4. Crear el pull request con GitHub CLI

Sustituir `development` si el equipo utiliza otra rama destino.

```powershell
$ramaActual = git branch --show-current

gh pr create `
  --base development `
  --head $ramaActual `
  --title "GNP - Domiciliacion posterior a la emision" `
  --body "Agrega configuracion por convenio GNP para emitir como intermediario e instalar los datos bancarios despues de una emision exitosa. La emision masiva conserva su flujo actual."
```

## 5. Instalar la tabla en la base local de pruebas

```powershell
sqlcmd -S "(localdb)\MSSQLLocalDB" -d "LocktonOne_DB" -b -i ".\ConfiguracionDomiciliacionGNP.sql"
```

El script es idempotente: puede ejecutarse nuevamente sin duplicar la tabla.

## 6. Preparar y compilar la solucion

El Developer Pack requiere abrir PowerShell como administrador:

```powershell
winget install `
  --id Microsoft.DotNet.Framework.DeveloperPack_4 `
  --exact `
  --source winget `
  --accept-package-agreements `
  --accept-source-agreements
```

Restaurar y compilar:

```powershell
$msbuild = "C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe"

& $msbuild .\LocktonOneWeb.sln `
  /t:Restore `
  /p:RestorePackagesConfig=true `
  /m

& $msbuild .\LocktonOneWeb.sln `
  /t:Build `
  /p:Configuration=Debug `
  /m
```

