using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LocktonModel.db
{
    [Table("PeticionPolizaProcesoMasivo")]
    public class PeticionPolizaProcesoMasivo
    {
        [Key]
        public int Id { get; set; }
        public string UserRealizaPeticion { get; set; }
        public int IdUsuario { get; set; }
        public DateTime FechaAlta { get; set; }
        public DateTime? FechaProceso { get; set; }
        public int IdTipoPoliza { get; set; }
        public bool EstatusPeticion { get; set; }
        public string CorreoEnvioReporte { get; set; }
    }
}
