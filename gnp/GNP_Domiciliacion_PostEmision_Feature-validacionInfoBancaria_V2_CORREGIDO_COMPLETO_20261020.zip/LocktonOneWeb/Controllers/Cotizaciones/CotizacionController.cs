﻿
using com.lockton.xml.qualitas.cotizacion.response;
using LocktonModel;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.Chubb.Catalogos;
using LocktonModel.VModels;
using LocktonOneWeb.BitacoraHelper;
using LocktonOneWeb.Controllers.Convenio;
using LocktonOneWeb.Controllers.Polizas;
using LocktonOneWeb.Controllers.Tickets;
using LocktonOneWeb.Controllers.Utils;
using LocktonOneWeb.Helper;
using LocktonServicios.Aseguradoras;
using LocktonServicios.Aseguradoras.ANA;
using LocktonServicios.Aseguradoras.Banorte;
using LocktonServicios.Aseguradoras.Chubb;
using LocktonServicios.AXAFlotillasCotizacion;
using LocktonServicios.Catalogos;
using LocktonServicios.Membresias;
using LocktonServicios.Membresias.COSTCO.DTO;
using LocktonServicios.RegistroUsuarioContratante;
using LocktonServicios.Services.CRM.Ploomes;
using LocktonServicios.SICASProcesaRecuperaInfo;
using LocktonServicios.Utilidades;
using log4net;
using log4net.Appender;
using Microsoft.Ajax.Utilities;
using Microsoft.AspNet.Identity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Serialization;
using static LocktonServicios.Aseguradoras.Chubb.ChubbService;
using static LocktonServicios.DerivacionOpera.DerivaOperaService;

namespace LocktonOneWeb.Controllers.Cotizaciones
{
    public class CotizacionController : BaseController
    {
        ABACHUBBService aBACHUBBService = new ABACHUBBService();
        private ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger(typeof(CotizacionController));
        private mDetalles cot;

        #region 1 Cotiza

        public ActionResult CotizacionAlias(String idUsuario)
        {
            Session["UsuarioReemplazo"] = idUsuario;
            Session["__USUARIO__MULTIPLEASEGURADORA__CLAVE__"] = null;
            Session["__USUARIO__MULTIPLEASEGURADORA__"] = null;
            Session["UserNameUsuarioReemplazo"] = null;
            string userNameRemplazo = GetUserNameRemplazo(idUsuario);
            if (!string.IsNullOrEmpty(userNameRemplazo))
                Session["UserNameUsuarioReemplazo"] = userNameRemplazo;
            return RedirectToAction("CotizacionVehiculo");
        }
        public ActionResult CotizacionAliasOT(String idUsuario, string ot)
        {
            Session["UsuarioReemplazo"] = idUsuario;
            Session["__USUARIO__MULTIPLEASEGURADORA__CLAVE__"] = null;
            Session["__USUARIO__MULTIPLEASEGURADORA__"] = null;
            Session["UserNameUsuarioReemplazo"] = null;
            string userNameRemplazo = GetUserNameRemplazo(idUsuario);
            if (!string.IsNullOrEmpty(userNameRemplazo))
                Session["UserNameUsuarioReemplazo"] = userNameRemplazo;
            return RedirectToAction("CotizacionVehiculo", new { renovacion = ot });
        }
        public ActionResult RecotizacionAlias(String idUsuario, int IdCotizacion)
        {
            Session["UsuarioReemplazo"] = idUsuario;
            Session["__USUARIO__MULTIPLEASEGURADORA__CLAVE__"] = null;
            Session["__USUARIO__MULTIPLEASEGURADORA__"] = null;
            Session["UserNameUsuarioReemplazo"] = null;
            string userNameRemplazo = GetUserNameRemplazo(idUsuario);
            if (!string.IsNullOrEmpty(userNameRemplazo))
                Session["UserNameUsuarioReemplazo"] = userNameRemplazo;
            return RedirectToAction("CotizacionVehiculo", new { IdCotizacion = IdCotizacion });
        }

        public ActionResult RecotizacionDocumentoAlias(String idUsuario, int IdDocto)
        {
            Session["UsuarioReemplazo"] = idUsuario;
            Session["__USUARIO__MULTIPLEASEGURADORA__CLAVE__"] = null;
            Session["__USUARIO__MULTIPLEASEGURADORA__"] = null;
            Session["UserNameUsuarioReemplazo"] = null;
            string userNameRemplazo = GetUserNameRemplazo(idUsuario);
            if (!string.IsNullOrEmpty(userNameRemplazo))
                Session["UserNameUsuarioReemplazo"] = userNameRemplazo;
            return RedirectToAction("CotizacionVehiculo", new { IdDocto = IdDocto });
        }


        public ActionResult CotizacionVehiculo(int IdCotizacion = 0, string NumeroDePoliza = "", string Error = "", string renovacion = "", int IdDocto = 0, string PaquetesIds = "", string AseguradorasIds = "")
        {
            log.Info("Entra al metodo CotizacionVehiculo");
            ViewBag.Mensaje = "";
            @ViewBag.MensajeError = Error;
            CotizacionCompara cotizacionCompara = new CotizacionCompara();
            try
            {

                if (!string.IsNullOrEmpty(NumeroDePoliza))
                {
                    cotizacionCompara.NumeroDePoliza = NumeroDePoliza;
                }



                //PRUEBA HDI
                //new HDIServices().ObtenerFormaPago(485);

                //var datos = new VCorreoCompra();

                //datos.NumeroDePoliza = "Poliza Prueba 123123";
                //datos.NombreCompleto = "Alejandro Romero Piña";
                //datos.NombreAseguradora = "QUALITAS";
                //datos.NombreNegocio = "Costco Demo";
                //datos.Emails = new List<string>();
                //datos.Emails.Add("jose.romero@bkt.consulting");

                //datos.NombreNegocio = "BROVE" + " - " + "BROVE";
                //datos.IdEmpresa = 1042;

                //var emails = new List<string>();
                //emails.Add("alejandro.romero@bkt.consulting");

                //new Cotizar().EnvioCorreoPagoPoliza(new VCorreoCompra() {
                //    NombreCompleto = "Alejandro Romero Piña",
                //    NombreAseguradora = "Qualitas",
                //    NombreNegocio = "LocktonDemo",
                //    NumeroDePoliza = "1290411190",
                //    VehiculoAsegurado = "07435 VW GOLF COMFORTLINE 5P L4 1.4L TSI ABS BA DSG AUT",
                //    IdEmpresa = 1042, Emails = emails,
                //});



                ViewBag.ConvenioValorFactura = false;
                bool usuarioAlias = false;
                log.Info("Entra a obtener RegistroDatosUsuarioActivo");
                DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
                //log.Info("CotizacionVehiculo Obtiene datos del usuario actual");
                if (RegDetalleUsuario.SinRegistro)
                {
                    ViewBag.UsuarioGenerico = 1;
                    //UsuarioMultipleAseguradora(RegDetalleUsuario.IdUsuario);
                }
                else
                {
                    ViewBag.UsuarioGenerico = 0;
                }
                log.Info("Entra a traer UsuarioMultipleAseguradora " + RegDetalleUsuario.IdUsuario);
                var multipleAseguradora = UsuarioMultipleAseguradora(RegDetalleUsuario.IdUsuario);
                cotizacionCompara.UsoHomologado = true;

                if (Session["__USUARIO__MODULO__RENOVACIONES__"] != null
                   && Convert.ToBoolean(Session["__USUARIO__MODULO__RENOVACIONES__"].ToString()))
                {
                    renovacion = Session["__USUARIO__MODULO__RENOVACIONES__OT__"].ToString();
                    cotizacionCompara.PermisoSoloRenovacion = true;
                }


                if (RegDetalleUsuario != null && RegDetalleUsuario.DetalleUsuarioEmpresa.Count() > 0)
                {
                    int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
                    Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);
                    ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);
                    cotizacionCompara.TxtNombreEmpresaUSR = configuracionEmpresa.TxtNombreEmpresaUSR;

                    var primeraCoizacion = db.ConfiguracionEmpresaCotizacion.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);

                    //Validacion Boton Cotizacion
                    if (!configuracionEmpresa.MostrarBotonCotizar && string.IsNullOrEmpty(renovacion))
                    {
                        string iduser = (User.Identity as System.Security.Claims.ClaimsIdentity).FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value;
                        var _detallesUsuario = db.DetalleUsuario.Where(x => x.IdUsuario == iduser).FirstOrDefault();


                        if (_detallesUsuario.IdPerfil == 3)
                            return RedirectToAction("Index", "Home");
                    }

                    if (multipleAseguradora)
                    {
                        log.Info("Entra a obetner ObtienerValorParametro Empresas_NoUsoHomologado");
                        var empresas_NoUsoHomologado = Utilidades.ObtienerValorParametro("Empresas_NoUsoHomologado");
                        if (!string.IsNullOrEmpty(empresas_NoUsoHomologado) && empresas_NoUsoHomologado.Split('|').Contains(IdEmpresa.ToString()))
                        {

                            SqlParameter sqlUserName = new SqlParameter("@UserName", RegDetalleUsuario.IdUsuario);
                            cotizacionCompara.Aseguradoras = db.sp_COTIZACION_Aseguradoras_Usuario.SqlQuery("sp_COTIZACION_Aseguradoras_Usuario @UserName", sqlUserName).ToList();

                            cotizacionCompara.UsoHomologado = false;
                        }
                    }
                    //Meses sin Intereses
                    SqlParameter sqlPolizas = new SqlParameter("@IdEmpresa", IdEmpresa);

                    log.Info("Entra a validar sp_MSI_Valida_Aplica");
                    var msi = db.sp_MSI_Valida_Aplica.SqlQuery("sp_MSI_Valida_Aplica @IdEmpresa", sqlPolizas).FirstOrDefault();
                    if (msi != null)
                    {
                        cotizacionCompara.AplicaMSI = true;
                        cotizacionCompara.MSIEtiqueta = $"Hasta {msi.Meses} meses sin intereses con Bancos participantes";

                    }

                    // 1 aseguradora / 2 paquete
                    //log.Info("CotizacionVehiculo obtener la configuracion de la empresa");
                    ViewBag.IdTipoComparativo = configuracionEmpresa.IdTipoComparativo;
                    //ViewBag.IdTipoComparativo = 3;//OHSS
                    ViewBag.IdTipoDeNegocio = configuracionEmpresa.IdTipoDeNegocio;
                    ViewBag.ComparativoEspecial = configuracionEmpresa.ComparativoEspecial;
                    cotizacionCompara.IdTipoDeNegocio = configuracionEmpresa.IdTipoDeNegocio.Value;

                    //OHSS
                    var listaOpciones = (from config in db.ConfiguracionMensajeAutoEspecial
                                         join cat in db.CatConfiguracionMensajeAutoEspecial
                                         on config.IdConfiguracionMensajeAutoEspecial equals cat.Id
                                         where config.IdEmpresa == IdEmpresa && cat.Estatus == 1 && config.Mostrar == 1
                                         orderby config.Orden
                                         select new OpcionTipoNegocioDTO
                                         {
                                             Descripcion = config.Descripcion,
                                             Orden = config.Orden
                                         }).ToList();
                    // Si no hay opciones configuradas para la empresa, obtener las opciones por defecto
                    if (!listaOpciones.Any())
                    {
                        listaOpciones = (from cat in db.CatConfiguracionMensajeAutoEspecial
                                         where cat.Estatus == 1 && cat.Mostrar == 1
                                         orderby cat.Orden // Asumiendo que hay un campo OrdenDefault en la tabla catálogo
                                         select new OpcionTipoNegocioDTO
                                         {
                                             Descripcion = cat.Descripcion, // O cat.Descripcion si es el mismo campo
                                             Orden = cat.Orden
                                         }).ToList();
                    }

                    ViewBag.OpcionesSeleccionadas = listaOpciones;




                    cotizacionCompara.ComparativoAnual = configuracionEmpresa.ComparativoAnual;
                    cotizacionCompara.MuestraEnvioProventel = (!string.IsNullOrEmpty(renovacion)) ? (configuracionEmpresa.EnvioProventel && configuracionEmpresa.BtnProventelRenovaciones) ? true : false : configuracionEmpresa.EnvioProventel;
                    cotizacionCompara.EnvioProventel = configuracionEmpresa.EnvioProventel;
                    cotizacionCompara.ValidaMembresia = configuracionEmpresa.ValidaMembresiaCostco;
                    //APAGADO 
                    cotizacionCompara.AplicaFechaRetroactiva = false;// usuarioAlias;
                    cotizacionCompara.FechaNacimiento = RegDetalleUsuario.FECHANACIMIENTO;
                    //log.Info("CotizacionVehiculo obtener los catalogos y datos de la empresa");
                    VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa);
                    cotizacionCompara.MostrarUsos = false;
                    cotizacionCompara.IdConvenioGNP = 0;

                    cotizacionCompara.Multianual = configuracionEmpresa.AplicaMultiAnual;

                    if (configuracionEmpresa.ValidaMicrositio && RegDetalleUsuario.SinRegistro)
                    {
                        var micrositio = db.CatMicrositio.FirstOrDefault(a => a.Id == configuracionEmpresa.IdCatMicrositio);

                        if (configuracionEmpresa.IdCatMicrositio == 1 && Session["__Membership__Number__"] == null)
                        {
                            Session.Add("MembershipValidation", RegDetalleUsuario.IdUsuario);



                            return RedirectToAction("Index", "Home");
                        }
                    }

                    if (ConveniosPaquetes.Convenios.Count() > 0)
                    {
                        log.Info("Entra a validar si el negocio EstaEnPeriodoDeEnrollment");
                        bool periodoEnrrollment = EstaEnPeriodoDeEnrollment(IdEmpresa, DateTime.Now);
                        cotizacionCompara.ZonaCirculacion = ConveniosPaquetes.Convenios.FirstOrDefault().ZonaCirculacion;

                        ViewBag.ConvenioValorFactura = ConveniosPaquetes.Convenios.FirstOrDefault().optAplicarVF == 1;
                        ViewBag.IdConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().Id;
                        ViewBag.IdTipoContratante = ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoContratante ?? 0;
                        ViewBag.FechaFinConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().FinVigencia.ToString("dd/MM/yyyy");
                        ViewBag.FechaInicioConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().InicioVigencia.ToString("dd-MM-yyyy");
                        ViewBag.MuestraFechaCotizacion = configuracionEmpresa.AplicaFechaCotizacion && !periodoEnrrollment;
                        cotizacionCompara.RangoFechaCotizacion = configuracionEmpresa.AplicaFechaCotizacion ? configuracionEmpresa.RangoFechaCotizacion : 15;
                        cotizacionCompara.EsFlotilla = configuracionEmpresa.IdTipoDeNegocio == 1 || configuracionEmpresa.IdTipoDeNegocio == 4;
                        ViewBag.EsPreferenteGNP = ((Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').Contains(ConveniosPaquetes.Convenios.FirstOrDefault().IdEmpresa.ToString()) || Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS")) && ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoConvenio.Equals(2));
                        //log.Info("CotizacionVehiculo cargar catalogos de combos");
                        //si es un usuario administrador o de ventas
                        if (cotizacionCompara.AplicaFechaRetroactiva)
                            ViewBag.MuestraFechaCotizacion = true;

                        var convenioGNP = ConveniosPaquetes.Convenios.FirstOrDefault(a => a.IdAseguradora == 2);
                        var convenioQualitas = ConveniosPaquetes.Convenios.FirstOrDefault(a => a.IdAseguradora == 1);
                        if (convenioGNP != null && convenioGNP.GNPInfoEspecial)
                        {
                            cotizacionCompara.MostrarUsos = true;
                            cotizacionCompara.IdConvenioGNP = convenioGNP.Id;
                        }

                        if (convenioQualitas != null)
                        {
                            cotizacionCompara.MostrarUsos = true;
                            cotizacionCompara.IdConvenioGNP = convenioQualitas.Id;
                        }
                        log.Info("Entra a llenar los CombosGenerales");
                        CombosGenerales(ConveniosPaquetes);
                        //OHSS
                        if (ConveniosPaquetes.Convenios.Count() > 0)
                        {
                            var idAseguradoras = ConveniosPaquetes.Convenios.Where(x => x.Estatus == 1).Select(a => a.IdAseguradora).ToList();
                            ViewBag.Convenios = new SelectList(ConveniosPaquetes.Convenios.Where(x => x.Estatus == 1).ToList(), "Id", "CaratulaPoliza");
                            ViewBag.Aseguradoras = db.Aseguradora
                            .Where(x => idAseguradoras.Contains(x.Id))
                            .OrderBy(x => x.Nombre)
                            .Select(x => new { Id = x.Id, Nombre = x.Nombre, x.ClaveHomologado }) // solo los campos necesarios
                            .ToList();

                        }

                        cotizacionCompara.TipoVehiculo = ViewBag.IdTipoVehiculoSelected;
                    }
                    else
                    {//si no tiene convenios
                        ViewBag.IdConvenio = 0;
                        ViewBag.Mensaje = "No cuentas con un convenio para poder cotizar";
                    }

                    if (primeraCoizacion != null)
                    {
                        cotizacionCompara.PrimeraCotizacionPaquete = primeraCoizacion.IdPaquete > 0;
                        cotizacionCompara.PrimeraCotizacionFormaPago = primeraCoizacion.IdFormaPago > 0;
                    }
                }

                if (IdCotizacion > 0)
                {
                    log.Info("IdCotizacion > 0 id " + IdCotizacion);
                    var cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == IdCotizacion);
                    CotizacionAuto CotAuto = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion == IdCotizacion);
                    //log.Info("CotizacionVehiculo obtener la informacion de cotizacion auto,");
                    if (CotAuto != null)
                    {
                        cotizacionCompara.Marca = CotAuto.Marca;
                        cotizacionCompara.Año = CotAuto.Agnio;
                        cotizacionCompara.Modelo = CotAuto.Modelo;
                        cotizacionCompara.Version = CotAuto.Version;
                        cotizacionCompara.Descripcion = CotAuto.Descripcion;

                        cotizacionCompara.ValorFactura = CotAuto.ValorFactura;
                        cotizacionCompara.FechaFactura = CotAuto.FechaFactura;
                        cotizacionCompara.MontoFactura = CotAuto.MontoFactura;

                        cotizacionCompara.MontoDeclarado = CotAuto.MontoDeclarado;

                        cotizacionCompara.Cobertura = CotAuto.Cobertura;
                        cotizacionCompara.FormadePago = CotAuto.FormadePago;
                        cotizacionCompara.MediodePago = CotAuto.MediodePago;
                        cotizacionCompara.ClaveAMIS = CotAuto.Amis;
                        cotizacionCompara.FechaNacimiento = cotizacion.FechaNacimiento;
                        ViewBag.ContieneFechaNacimiento = cotizacion.FechaNacimiento.Value.ToString("yyyy-MM-dd");

                        if (!string.IsNullOrEmpty(cotizacion.CodigoPostal))
                            cotizacionCompara.CodigoPostal = cotizacion.CodigoPostal;
                        if (cotizacion.Edad > 0)
                            cotizacionCompara.Edad = cotizacion.Edad.ToString();
                        if (cotizacion.IdCatGenero != null)
                        {

                            cotizacionCompara.Genero = db.CatGenero.FirstOrDefault(a => a.Id == cotizacion.IdCatGenero).Clave;
                        }

                        cotizacionCompara.AseguradorasIds = AseguradorasIds;
                        cotizacionCompara.PaquetesIds = PaquetesIds;
                        cotizacionCompara.TipoVehiculo = CotAuto.TipoVehiculo;

                        ViewBag.Datos = true;
                    }
                }




                if (!string.IsNullOrEmpty(renovacion))
                {
                    log.Info("Renovación es diferente de vacio " + renovacion);
                    var polizaController = new PolizasController();
                    log.Info("Entra a RecuperaListaRenovacion " + RegDetalleUsuario.IdCliCORE);
                    List<VRenovacion> ListaRenovacion = polizaController.RecuperaListaRenovacion(RegDetalleUsuario.IdCliCORE, false);
                    VRenovacion renova = ListaRenovacion.FirstOrDefault(busca => busca.NumeroDePoliza == renovacion);
                    cotizacionCompara.NumeroDePoliza = renovacion;

                    if (renova != null)
                    {

                        //buscar datos del vehiculo					
                        Aseguradora aseguradora = db.Aseguradora.FirstOrDefault(a => a.ClaveCore == renova.CiaAbreviacion);


                        if (renova.Servicio.Trim().ToUpper() == "MOTO")
                            cotizacionCompara.TipoVehiculo = "3";
                        else if (renova.Servicio.Trim().ToUpper() == "PICKUP")
                            cotizacionCompara.TipoVehiculo = "2";
                        else
                            cotizacionCompara.TipoVehiculo = "1";


                        cotizacionCompara.Marca = renova.Marca;
                        cotizacionCompara.Año = renova.Modelo;
                        cotizacionCompara.ClaveAMIS = renova.Clave;
                        //cotizacionCompara.AseguradoraClaveHomologado = aseguradora.ClaveHomologado;

                        if (aseguradora.Id == 1)//QUALITAS
                            cotizacionCompara.ClaveAMIS = cotizacionCompara.ClaveAMIS.PadLeft(5, '0');

                        log.Info(string.Format("Entra a BuscarAutoMatrizAseguradora claveamis = '{0}', clavehomologado='{1}', tipovehiculo = '{2}'", cotizacionCompara.ClaveAMIS, aseguradora.ClaveHomologado, cotizacionCompara.TipoVehiculo));
                        AmisVehiculo vehiculo = polizaController.BuscarAutoMatrizAseguradora(cotizacionCompara.ClaveAMIS, aseguradora.ClaveHomologado, cotizacionCompara.TipoVehiculo);

                        if (vehiculo != null)
                        {
                            cotizacionCompara.Marca = vehiculo.Marca;
                            cotizacionCompara.Modelo = vehiculo.Modelo;
                            cotizacionCompara.Version = vehiculo.Version;
                            cotizacionCompara.Descripcion = vehiculo.Desc_trim_to_show;
                        }

                        //cotizacionComp.ValorFactura = vehiculo
                        cotizacionCompara.MontoDeclarado = 0;
                        cotizacionCompara.MontoFactura = 0;
                        cotizacionCompara.FechaFactura = DateTime.Now;
                        cotizacionCompara.Cobertura = 0;
                        ViewBag.Datos = true;
                        //cotizacionComp.FormadePago = renova.
                        //cotizacionComp.MediodePago = renova.


                        var parameters = new List<SqlParameter>()
                    {
                       new SqlParameter("@IdDocto",DBNull.Value)
                       , new SqlParameter("@Documento",renova.NumeroDePoliza)
                    };
                        log.Info("Entra a traer sp_RENOVACION_DatosOT");
                        var OT = db.sp_RENOVACION_DatosOT.SqlQuery("sp_RENOVACION_DatosOT @IdDocto,@Documento", parameters.ToArray()).FirstOrDefault();

                        if (OT != null)
                        {
                            if (!string.IsNullOrEmpty(OT.CodigoPostal))
                                cotizacionCompara.CodigoPostal = OT.CodigoPostal;

                            if (OT.FechaNacimiento.HasValue)
                            {
                                ViewBag.ContieneFechaNacimiento = OT.FechaNacimiento.Value.ToString("yyyy-MM-dd");
                                cotizacionCompara.FechaNacimiento = OT.FechaNacimiento;
                            }

                            if (OT.IdCatGenero.HasValue)
                            {
                                var _g = db.CatGenero.FirstOrDefault(a => a.Id == OT.IdCatGenero);
                                cotizacionCompara.Genero = _g.Clave;
                            }

                            if (OT.InicioVigencia > DateTime.Now)
                            {
                                ViewBag.ContieneFechaCotizacion = OT.InicioVigencia.ToString("yyyy-MM-dd");
                                cotizacionCompara.FechaCotizacion = OT.InicioVigencia;
                            }

                            if (OT.IdCatTipoPaquete.HasValue)
                                cotizacionCompara.Cobertura = OT.IdCatTipoPaquete.Value;

                            if (OT.IdFormaPago.HasValue)
                                cotizacionCompara.FormadePago = OT.IdFormaPago.Value;

                            if (OT.IdMedioPago.HasValue)
                                cotizacionCompara.MediodePago = OT.IdMedioPago.Value;
                        }

                    }
                }

                if (IdDocto > 0)
                {
                    log.Info("IdDocto > 0 id " + IdDocto);
                    cotizacionCompara.IdDocto = IdDocto;
                    var polizaController = new PolizasController();
                    //List<VRenovacion> ListaRenovacion = polizaController.RecuperaListaRenovacion(RegDetalleUsuario.IdCliCORE, false);
                    //VRenovacion renova = ListaRenovacion.FirstOrDefault(busca => busca.NumeroDePoliza == renovacion);

                    SqlParameter sqlPoliza = new SqlParameter("@Poliza", "");
                    SqlParameter sqlIdDocto = new SqlParameter("@IdDocto", IdDocto);

                    var detallePoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza,@IdDocto", sqlPoliza, sqlIdDocto).FirstOrDefault();



                    if (detallePoliza != null)
                    {

                        cotizacionCompara.NumeroDePoliza = detallePoliza.NumeroPoliza;

                        //buscar datos del vehiculo					
                        Aseguradora aseguradora = db.Aseguradora.FirstOrDefault(a => a.ClaveCore.Contains(detallePoliza.Aseguradora));

                        cotizacionCompara.Marca = detallePoliza.Marca;
                        cotizacionCompara.Año = detallePoliza.Modelo;
                        cotizacionCompara.ClaveAMIS = detallePoliza.Clave;
                        //cotizacionCompara.AseguradoraClaveHomologado = aseguradora.ClaveHomologado;

                        if (aseguradora.Id == 1)//QUALITAS
                            cotizacionCompara.ClaveAMIS = cotizacionCompara.ClaveAMIS.PadLeft(5, '0');
                        log.Info(string.Format("Entra a BuscarAutoMatrizAseguradora claveamis = '{0}', clavehomologado='{1}', tipovehiculo = '{2}'", cotizacionCompara.ClaveAMIS, aseguradora.ClaveHomologado, cotizacionCompara.TipoVehiculo));
                        AmisVehiculo vehiculo = polizaController.BuscarAutoMatrizAseguradora(cotizacionCompara.ClaveAMIS, aseguradora.ClaveHomologado, cotizacionCompara.TipoVehiculo);

                        if (vehiculo != null)
                        {
                            cotizacionCompara.Marca = vehiculo.Marca;
                            cotizacionCompara.Modelo = vehiculo.Modelo;
                            cotizacionCompara.Version = vehiculo.Version;
                            cotizacionCompara.Descripcion = vehiculo.Desc_trim_to_show;
                        }

                        //cotizacionComp.ValorFactura = vehiculo
                        cotizacionCompara.MontoDeclarado = 0;
                        cotizacionCompara.MontoFactura = 0;
                        cotizacionCompara.FechaFactura = DateTime.Now;
                        cotizacionCompara.Cobertura = 0;
                        ViewBag.Datos = true;
                        //cotizacionComp.FormadePago = renova.
                        //cotizacionComp.MediodePago = renova.                
                    }
                }
                //log.Info("CotizacionVehiculo lista CatUsoVehiculo");
                //ViewBag.TipoVehiculo = new SelectList(db.CatUsoVehiculo.Where(x => x.Estatus == 1).OrderBy(a => a.Clave).ToList(), "Clave", "Nombre");

                //log.Info("Ver Patalla de cotizacion de vehiculo");
                //


            }
            catch (Exception ex)
            {
                log.Info("Surgió una excepción CotizacionVehiculo " + ex.InnerException != null ? ex.InnerException.Message.ToString() : ex.Message.ToString());
            }
            log.Info("Terina bien el metodo CotizacionVehiculo");
            return View(cotizacionCompara);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CotizacionVehiculo(CotizacionCompara cotizacionCompara)//OHSS aqui entra
        {
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);
            ConfiguracionEmpresa configuracion = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);
            var primeraCotizacion = db.ConfiguracionEmpresaCotizacion.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);
            int? idTipoDeNegocio = configuracion.IdTipoDeNegocio;
            CatUsoVehiculo cattipoVehiculo = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == cotizacionCompara.TipoVehiculo);
            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa);

            if (!cotizacionCompara.UsoHomologado)
            {
                cotizacionCompara.Descripcion = cotizacionCompara.DescripcionVehiculo.Split(new string[] { "__X__" }, StringSplitOptions.None)[1];
                cotizacionCompara.DescripcionVehiculo = cotizacionCompara.DescripcionVehiculo.Split(new string[] { "__X__" }, StringSplitOptions.None)[0];

            }

            cotizacionCompara.NombreTipoVehiculo = cattipoVehiculo == null ? string.Empty : cattipoVehiculo.Nombre.ToUpper();

            if (cotizacionCompara.IdUso > 0)
            {
                var catuso = db.CatUsos.FirstOrDefault(a => a.Id == cotizacionCompara.IdUso);

                var clave = "";
                if (cotizacionCompara.AseguradoraClaveHomologado == "QUALITAS")
                    clave = catuso.ClaveQUALITAS;
                else
                    clave = catuso.ClaveGNP == "-" ? catuso.ClaveQUALITAS : catuso.ClaveGNP;

                if (cotizacionCompara.NombreTipoVehiculo.Contains("("))
                    cotizacionCompara.NombreTipoVehiculo = $"{cotizacionCompara.NombreTipoVehiculo.Substring(0, cotizacionCompara.NombreTipoVehiculo.IndexOf('('))} {catuso.Nombre} - {clave}";
                else
                    cotizacionCompara.NombreTipoVehiculo = $"{cotizacionCompara.NombreTipoVehiculo} {catuso.Nombre} - {clave}";

            }

            if (primeraCotizacion != null)
            {
                if (primeraCotizacion.IdPaquete > 0)
                {
                    cotizacionCompara.Cobertura = primeraCotizacion.IdPaquete;
                }

                if (primeraCotizacion.IdFormaPago > 0 && primeraCotizacion.IdMedioPago > 0)
                {
                    var m = db.CatModalidadFormaPago.FirstOrDefault(a => a.Id == primeraCotizacion.IdMedioPago);

                    cotizacionCompara.FormadePago = primeraCotizacion.IdFormaPago;
                    cotizacionCompara.MediodePago = Convert.ToInt32(m.Clave);
                }
            }

            if (idTipoDeNegocio == 3 && ConveniosPaquetes.Convenios.First().ZonaCirculacion == 2)
            {
                cotizacionCompara.CodigoPostal = ConveniosPaquetes.Convenios.First().CodigoPostal.ToString().PadLeft(5, '0');
            }

            if (idTipoDeNegocio == 2
                || (idTipoDeNegocio == 1 && ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoContratante == 2)
                || (idTipoDeNegocio == 1 && ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoContratante == 5)
                || idTipoDeNegocio == 6)
            {
                var datosVaidos = true;

                List<CodigoPostal> cp = db.CatCodigoPostal.Where(a => a.Codigo == cotizacionCompara.CodigoPostal).ToList();
                if (cp == null || !cp.Any())
                {
                    ViewBag.MensajeError = "El Codigo Postal no esta registrado";
                    datosVaidos = false;
                }

                if (datosVaidos)
                {
                    if (!cotizacionCompara.FechaNacimiento.HasValue)
                    {
                        ViewBag.MensajeError = "La Fecha de Nacimiento es Requerida";
                        datosVaidos = false;

                    }
                    else
                    {
                        var edad = Utilidades.CalculaEdad(cotizacionCompara.FechaNacimiento.Value);
                        cotizacionCompara.Edad = edad.ToString();

                        if (edad < 18)
                        {
                            ViewBag.MensajeError = "La edad debe ser mínimo 18";
                            datosVaidos = false;

                        }
                    }
                }


                if (datosVaidos)
                    return RedirectToAction("CotizacionCompara", cotizacionCompara);
                else
                {
                    cotizacionCompara.AplicaFechaRetroactiva = false;
                    ContruyeViewBagsCotizacion(IdEmpresa, configuracion, ConveniosPaquetes, RegDetalleUsuario);
                    return View(cotizacionCompara);
                }
            }
            else
                return RedirectToAction("CotizacionCompara", cotizacionCompara);
        }

        private void ContruyeViewBagsCotizacion(int idEmpresa, ConfiguracionEmpresa configuracion, VEmpConvPaq ConveniosPaquetes, DetalleUsuario RegDetalleUsuario)
        {
            bool periodoEnrrollment = EstaEnPeriodoDeEnrollment(idEmpresa, DateTime.Now);

            ViewBag.IdTipoComparativo = configuracion.IdTipoComparativo;
            ViewBag.IdTipoDeNegocio = configuracion.IdTipoDeNegocio;
            //log.Info("CotizacionVehiculo obtener los catalogos y datos de la empresa");

            ViewBag.ConvenioValorFactura = ConveniosPaquetes.Convenios.FirstOrDefault().optAplicarVF == 1;
            ViewBag.IdConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().Id;
            ViewBag.IdTipoContratante = ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoContratante ?? 0;
            ViewBag.FechaFinConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().FinVigencia.ToString("dd/MM/yyyy");
            ViewBag.FechaInicioConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().InicioVigencia.ToString("dd-MM-yyyy");
            //log.Info("CotizacionVehiculo cargar catalogos de combos");
            CombosGenerales(ConveniosPaquetes);
            ViewBag.MuestraFechaCotizacion = configuracion.AplicaFechaCotizacion && !periodoEnrrollment;

            ViewBag.EsPreferenteGNP = ((Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').Contains(ConveniosPaquetes.Convenios.FirstOrDefault().IdEmpresa.ToString()) || Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS")) && ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoConvenio.Equals(2));
            //ViewBag.TipoVehiculo = new SelectList(db.CatUsoVehiculo.Where(x => x.Estatus == 1).ToList(), "Clave", "Nombre");
            //si es un usuario administrador o de ventas            

            if (RegDetalleUsuario.SinRegistro)
            {
                ViewBag.UsuarioGenerico = 1;
                //UsuarioMultipleAseguradora(RegDetalleUsuario.IdUsuario);
            }
            else
            {
                ViewBag.UsuarioGenerico = 0;
            }
        }

        private string BuscaNumeroDePolizaOTRenovacion(int IdCotizacion)
        {
            string NumeroDePoliza = string.Empty;
            try
            {
                OTRenovacion renovacion = db.OTRenovacion.FirstOrDefault(x => x.IdCotizacion == IdCotizacion);
                if (renovacion != null)
                {
                    NumeroDePoliza = renovacion.NumeroDePoliza;
                }
            }
            catch (Exception ex)
            {
                log.Info("BuscaNumeroDePolizaOTRenovacion: " + ex.Message);
            }

            return NumeroDePoliza;
        }

        #endregion

        #region 1.1 Renovacion

        [HttpGet]
        public ActionResult CotizacionRenovacion(CotizacionCompara cotizacionCompara, bool renovacion = true)
        {
            ViewBag.Mensaje = string.Empty;

            ViewBag.ConvenioValorFactura = false;
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            //log.Info("CotizacionVehiculo Obtiene datos del usuario actual");
            if (RegDetalleUsuario != null && RegDetalleUsuario.DetalleUsuarioEmpresa.Count() > 0)
            {
                int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
                Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);
                ConfiguracionEmpresa configuracion = db.ConfiguracionEmpresa.FirstOrDefault(emp => emp.IdEmpresa == IdEmpresa);

                // 1 aseguradora / 2 paquete
                //log.Info("CotizacionVehiculo obtener la configuracion de la empresa");
                ViewBag.IdTipoComparativo = configuracion.IdTipoComparativo;
                ViewBag.IdTipoDeNegocio = configuracion.IdTipoDeNegocio;
                //log.Info("CotizacionVehiculo obtener los catalogos y datos de la empresa");
                VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa);
                if (ConveniosPaquetes.Convenios.Count() > 0)
                {
                    ViewBag.ConvenioValorFactura = ConveniosPaquetes.Convenios.FirstOrDefault().optAplicarVF == 1;
                    ViewBag.IdConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().Id;
                    ViewBag.IdTipoContratante = ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoContratante ?? 0;
                    //log.Info("CotizacionVehiculo cargar catalogos de combos");
                    CombosGenerales(ConveniosPaquetes);
                }
                else
                {//si no tiene convenios
                    ViewBag.IdConvenio = 0;
                    ViewBag.Mensaje = "No cuentas con un convenio para poder cotizar";
                }
            }

            //ya bienen los datos  
            ViewBag.Datos = true;

            //log.Info("CotizacionVehiculo lista CatUsoVehiculo");
            ViewBag.TipoVehiculo = new SelectList(db.CatUsoVehiculo.Where(x => x.Estatus == 1).OrderBy(a => a.IdCatRamo).ToList(), "Clave", "Nombre");

            //log.Info("Ver Patalla de cotizacion de vehiculo");
            return View(cotizacionCompara);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CotizacionRenovacion(CotizacionCompara cotizacionCompara)
        {
            return RedirectToAction("CotizacionCompara", cotizacionCompara);
        }

        #endregion

        #region 1.2 Cotizacion Cero Comision
        public ActionResult CotizacionCeroAlias(String idUsuario)
        {
            Session["UsuarioReemplazo"] = idUsuario;
            Session["__USUARIO__MULTIPLEASEGURADORA__CLAVE__"] = null;
            Session["__USUARIO__MULTIPLEASEGURADORA__"] = null;
            Session["UserNameUsuarioReemplazo"] = null;
            string userNameRemplazo = GetUserNameRemplazo(idUsuario);
            if (!string.IsNullOrEmpty(userNameRemplazo))
                Session["UserNameUsuarioReemplazo"] = userNameRemplazo;
            return RedirectToAction("CotizacionCero");
        }

        public ActionResult CotizacionCero(int IdCotizacion = 0, string NumeroDePoliza = "", string Error = "")
        {
            ViewBag.Mensaje = "";
            @ViewBag.MensajeError = Error;
            log.Info("CotizacionCero inicio de cotizacion de vehiculo");
            CotizacionCompara cotizacionCompara = new CotizacionCompara();
            if (!string.IsNullOrEmpty(NumeroDePoliza))
            {
                cotizacionCompara.NumeroDePoliza = NumeroDePoliza;
            }

            ViewBag.ConvenioValorFactura = false;
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);

            //log.Info("CotizacionVehiculo Obtiene datos del usuario actual");

            if (RegDetalleUsuario != null && RegDetalleUsuario.DetalleUsuarioEmpresa.Count() > 0)
            {
                int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
                Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);
                ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);

                // 1 aseguradora / 2 paquete
                //log.Info("CotizacionVehiculo obtener la configuracion de la empresa");
                ViewBag.IdTipoComparativo = configuracionEmpresa.IdTipoComparativo;
                ViewBag.IdTipoDeNegocio = configuracionEmpresa.IdTipoDeNegocio;

                cotizacionCompara.AplicaFechaRetroactiva = usuarioAlias;

                //log.Info("CotizacionVehiculo obtener los catalogos y datos de la empresa");
                VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa);
                if (ConveniosPaquetes.Convenios.Count() > 0)
                {
                    bool periodoEnrrollment = EstaEnPeriodoDeEnrollment(IdEmpresa, DateTime.Now);
                    var idAseguradoras = ConveniosPaquetes.Convenios.Select(a => a.IdAseguradora).ToList();
                    ViewBag.Convenios = new SelectList(ConveniosPaquetes.Convenios.ToList(), "Id", "CaratulaPoliza");
                    ViewBag.Aseguradoras = new SelectList(db.Aseguradora.Where(x => idAseguradoras.Contains(x.Id)).OrderBy(x => x.Nombre).ToList(), "Id", "Nombre");
                    ViewBag.ConvenioValorFactura = ConveniosPaquetes.Convenios.FirstOrDefault().optAplicarVF == 1;
                    ViewBag.IdConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().Id;
                    ViewBag.IdTipoContratante = ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoContratante ?? 0;
                    ViewBag.FechaFinConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().FinVigencia.ToString("dd/MM/yyyy");
                    ViewBag.FechaInicioConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().InicioVigencia.ToString("dd-MM-yyyy");
                    ViewBag.MuestraFechaCotizacion = configuracionEmpresa.AplicaFechaCotizacion && !periodoEnrrollment;
                    cotizacionCompara.RangoFechaCotizacion = configuracionEmpresa.AplicaFechaCotizacion ? configuracionEmpresa.RangoFechaCotizacion : 15;
                    cotizacionCompara.EsFlotilla = configuracionEmpresa.IdTipoDeNegocio == 1 || configuracionEmpresa.IdTipoDeNegocio == 4;
                    //log.Info("CotizacionVehiculo cargar catalogos de combos");
                    if (cotizacionCompara.AplicaFechaRetroactiva)
                        ViewBag.MuestraFechaCotizacion = true;
                    CombosGenerales(ConveniosPaquetes);
                }
                else
                {//si no tiene convenios
                    ViewBag.IdConvenio = 0;
                    ViewBag.Mensaje = "No cuentas con un convenio para poder cotizar";
                }
            }

            if (IdCotizacion > 0)
            {
                CotizacionAuto CotAuto = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion == IdCotizacion);
                //log.Info("CotizacionVehiculo obtener la informacion de cotizacion auto,");
                if (CotAuto != null)
                {
                    cotizacionCompara.Marca = CotAuto.Marca;
                    cotizacionCompara.Año = CotAuto.Agnio;
                    cotizacionCompara.Modelo = CotAuto.Modelo;
                    cotizacionCompara.Version = CotAuto.Version;
                    cotizacionCompara.Descripcion = CotAuto.Descripcion;

                    cotizacionCompara.ValorFactura = CotAuto.ValorFactura;
                    cotizacionCompara.FechaFactura = CotAuto.FechaFactura;
                    cotizacionCompara.MontoFactura = CotAuto.MontoFactura;
                    cotizacionCompara.MontoDeclarado = CotAuto.MontoDeclarado;

                    cotizacionCompara.Cobertura = CotAuto.Cobertura;
                    cotizacionCompara.FormadePago = CotAuto.FormadePago;
                    cotizacionCompara.MediodePago = CotAuto.MediodePago;

                    ViewBag.Datos = true;
                }
            }
            //log.Info("CotizacionVehiculo lista CatUsoVehiculo");
            ViewBag.TipoVehiculo = new SelectList(db.CatUsoVehiculo.Where(x => x.Estatus == 1).OrderBy(a => a.IdCatRamo).ToList(), "Clave", "Nombre");

            //log.Info("Ver Patalla de cotizacion de vehiculo");
            return View(cotizacionCompara);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CotizacionCero(CotizacionCompara cotizacionCompara)
        {
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);
            var aseguradora = db.Aseguradora.FirstOrDefault(a => a.Id == cotizacionCompara.IdAseguradora);
            ConfiguracionEmpresa configuracion = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);
            int? idTipoDeNegocio = configuracion.IdTipoDeNegocio;
            CatUsoVehiculo cattipoVehiculo = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == cotizacionCompara.TipoVehiculo);
            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa, cotizacionCompara.IdConvenio);

            cotizacionCompara.NombreTipoVehiculo = cattipoVehiculo == null ? string.Empty : cattipoVehiculo.Nombre.ToUpper();

            if (idTipoDeNegocio == 2 || ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoContratante == 2 || idTipoDeNegocio == 6)
            {
                List<CodigoPostal> cp = db.CatCodigoPostal.Where(a => a.Codigo == cotizacionCompara.CodigoPostal).ToList();

                if (cp == null || !cp.Any())
                {
                    bool periodoEnrrollment = EstaEnPeriodoDeEnrollment(IdEmpresa, DateTime.Now);

                    ViewBag.IdTipoComparativo = configuracion.IdTipoComparativo;
                    ViewBag.IdTipoDeNegocio = configuracion.IdTipoDeNegocio;
                    //log.Info("CotizacionVehiculo obtener los catalogos y datos de la empresa");

                    cotizacionCompara.AplicaFechaRetroactiva = usuarioAlias;

                    var idAseguradoras = ConveniosPaquetes.Convenios.Select(a => a.IdAseguradora).ToList();
                    ViewBag.Aseguradoras = new SelectList(db.Aseguradora.Where(x => idAseguradoras.Contains(x.Id)).OrderBy(x => x.Nombre).ToList(), "Id", "Nombre");
                    ViewBag.Convenios = new SelectList(ConveniosPaquetes.Convenios.ToList(), "Id", "CaratulaPoliza");
                    ViewBag.ConvenioValorFactura = ConveniosPaquetes.Convenios.FirstOrDefault().optAplicarVF == 1;
                    ViewBag.IdConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().Id;
                    ViewBag.IdTipoContratante = ConveniosPaquetes.Convenios.FirstOrDefault().IdCatTipoContratante ?? 0;
                    ViewBag.FechaFinConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().FinVigencia.ToString("dd-MM-yyyy");
                    ViewBag.FechaInicioConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().InicioVigencia.ToString("dd-MM-yyyy");
                    //log.Info("CotizacionVehiculo cargar catalogos de combos");
                    CombosGenerales(ConveniosPaquetes);
                    ViewBag.MuestraFechaCotizacion = configuracion.AplicaFechaCotizacion && !periodoEnrrollment;
                    ViewBag.MensajeError = "El Codigo Postal no esta registrado";
                    ViewBag.TipoVehiculo = new SelectList(db.CatUsoVehiculo.Where(x => x.Estatus == 1).OrderBy(a => a.IdCatRamo).ToList(), "Clave", "Nombre");
                    if (cotizacionCompara.AplicaFechaRetroactiva)
                        ViewBag.MuestraFechaCotizacion = true;
                    return View(cotizacionCompara);
                }

                //return RedirectToAction("CotizacionVehiculo", new { IdCotizacion = 0, Error = "El Codigo Postal no esta registrado" });
                else
                {
                    CotizacionCompara result = CalculaCotizacionCeroComision(cotizacionCompara);
                    CotizacionDetalle detalle = db.CotizacionDetalle.FirstOrDefault(a => a.IdCotizacion == result.IdCotizacion);
                    return RedirectToAction("CotizacionInformacion", "Cotizacion", new { IdCotizacion = detalle.Id, Aseguradora = aseguradora.ClaveHomologado });
                }

            }
            else
            {
                CotizacionCompara result = CalculaCotizacionCeroComision(cotizacionCompara);
                CotizacionDetalle detalle = db.CotizacionDetalle.FirstOrDefault(a => a.IdCotizacion == result.IdCotizacion);
                return RedirectToAction("CotizacionInformacion", "Cotizacion", new { IdCotizacion = detalle.Id, Aseguradora = aseguradora.ClaveHomologado });
            }

        }

        #endregion

        #region 2 Compara

        /// <summary>
        /// Vista de cotizacion compara
        /// </summary>
        /// <param name="cotizacionCompara">parametros para cotizar</param>
        /// <returns></returns>
        public ActionResult CotizacionCompara(CotizacionCompara cotizacionCompara)
        {
            CotizacionCompara cotizacionComparaRespuesta = new CotizacionCompara();
            log.Info("01 Entra Controllador CotizacionCompara + " + DateTime.Now);
            //regresar los valores calculados
            cotizacionComparaRespuesta = CalculaCotizacion(cotizacionCompara);

            if (!cotizacionComparaRespuesta.Exitoso)
            {

                if (cotizacionComparaRespuesta.TipoError == 1)
                    return RedirectToAction("Index", "Home");

            }

            cotizacionComparaRespuesta.ComparativoAnual = cotizacionCompara.ComparativoAnual;

            cotizacionComparaRespuesta.IdDocto = cotizacionCompara.IdDocto;
            cotizacionComparaRespuesta.PermisoSoloRenovacion = cotizacionCompara.PermisoSoloRenovacion;


            log.Info("02 CotizacionCompara regresa vista " + DateTime.Now);
            return View(cotizacionComparaRespuesta);

        }
        public ActionResult _RegistroUsuario(string Nombre, string Nombre2, string ApPaterno, string ApMaterno, string Correo, string Celular, string NombreEmpresaUSR, string CodigoPostal, string FechaNacimiento = null, string Genero = null, string membresia = "")
        {
            RegistroUsuario model = new RegistroUsuario();
            model.Nombre = Nombre;
            model.Nombre2 = Nombre2;
            model.ApPaterno = ApPaterno;
            model.ApMaterno = ApMaterno;
            model.Correo = Correo;
            model.Celular = Celular;
            //model.FechaNacimiento = DateTime.Today;
            model.NombreEmpresaUSR = NombreEmpresaUSR;
            model.CodigoPostal = CodigoPostal;
            string[] formats = {"M/d/yyyy h:mm:ss tt", "M/d/yyyy h:mm tt",
                     "MM/dd/yyyy hh:mm:ss", "M/d/yyyy h:mm:ss",
                     "M/d/yyyy hh:mm tt", "M/d/yyyy hh tt",
                     "M/d/yyyy h:mm", "M/d/yyyy h:mm",
                     "MM/dd/yyyy hh:mm", "M/dd/yyyy hh:mm",
                     "MM/d/yyyy HH:mm:ss.ffffff" };
            model.FechaNacimiento = FechaNacimiento == null ? DateTime.Today : DateTime.ParseExact(FechaNacimiento, formats, new CultureInfo("en-US"), DateTimeStyles.None);
            model.Genero = Genero == null ? "0" : Genero;
            model.NumeroMembresia = membresia;
            ViewBag.CatGener = ViewBag.TipoVehiculo = new SelectList(db.CatGenero.ToList(), "Clave", "Nombre");

            //CAMPOS REFERENCIA
            string iduser = System.Web.HttpContext.Current.User.Identity.GetUserId();
            DetalleUsuario dtlUsuario = db.DetalleUsuario.Where(x => x.IdUsuario == iduser).FirstOrDefault();
            int idEmpresa = (int)dtlUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            var _configuracion = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == idEmpresa);

            model.Referencia1Mostrar = _configuracion.Referencia1Mostrar;
            model.Referencia1Requerido = _configuracion.Referencia1Requerido;
            model.Referencia1Titulo = string.IsNullOrEmpty(_configuracion.Referencia1Titulo) ? "Referencia1" : _configuracion.Referencia1Titulo;

            model.Referencia2Mostrar = _configuracion.Referencia2Mostrar;
            model.Referencia2Requerido = _configuracion.Referencia2Requerido;
            model.Referencia2Titulo = string.IsNullOrEmpty(_configuracion.Referencia2Titulo) ? "Referencia2" : _configuracion.Referencia2Titulo;


            return PartialView(model);
        }

        private bool ExisteLead(string marca, string modelo, string telefono, string empresa)
        {
            var existe = false;
            if (string.IsNullOrEmpty(telefono))
                return existe;
            try
            {
                var parameter = new List<SqlParameter>() {
                new SqlParameter("@Marca",marca),
                new SqlParameter("@Modelo",modelo),
                new SqlParameter("@telefono",telefono),
                new SqlParameter("@Empresa",empresa),
                new SqlParameter("@Autos",true),
                };
                var leads = db.Proventel_Envio.SqlQuery("sp_Proventel_Envio_SELECT @Marca,@Modelo,@telefono,@Empresa,@Autos", parameter.ToArray()).ToList();

                existe = leads.Any();
            }
            catch (Exception ex)
            {
                existe = false;
            }
            return existe;

        }

        private void EnvioProventel(int idCotizacion, bool CotSinRegistro, CotizacionCompara cotizacionCompara)
        {
            try
            {


                var cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == idCotizacion);
                var auto = db.CotizacionAuto.FirstOrDefault(a => a.IdCotizacion == idCotizacion);
                var usuarioCotizacion = db.DetalleUsuario.FirstOrDefault(a => a.Id == cotizacion.IdDetalleUsuario);
                var empresa = $"{usuarioCotizacion.DetalleUsuarioEmpresa.FirstOrDefault().Empresa.RazonSocial} - {usuarioCotizacion.DetalleUsuarioEmpresa.FirstOrDefault().Empresa.ClaveEmpresa}";
                var empleado = (CotSinRegistro) ? "" : usuarioCotizacion.IdEmpleado ?? "";
                var telefono = (CotSinRegistro) ? cotizacionCompara.CelularSR : usuarioCotizacion.TelefonoCelular ?? "";
                double cel = 0;

                if (!ExisteLead(auto.Marca, auto.Modelo, telefono, empresa))
                {


                    double.TryParse((CotSinRegistro) ? cotizacionCompara.CelularSR : usuarioCotizacion.TelefonoCelular, out cel);
                    if (Convert.ToInt32(Utilidades.ObtienerValorParametro("Tomar_Leads_Proventel")) == 1)
                    {
                        var phonex = new PhonexModel();
                        phonex.numerocotizacion = cotizacion.Id.ToString();
                        phonex.numeroempleado = empleado;
                        phonex.nombre = (CotSinRegistro) ? cotizacionCompara.ObtieneNombreCompletoSR() : usuarioCotizacion.ObtieneNombreCompleto();
                        phonex.marca = auto.Marca;
                        phonex.modelo = auto.Modelo;
                        phonex.tipo = auto.TipoVehiculo.Trim() == "1" ? "AUTO" : (auto.TipoVehiculo.Trim() == "3" ? "MOTO" : "PICKUP");
                        phonex.empresa = empresa;
                        phonex.tel = cel;
                        phonex.email = (CotSinRegistro) ? cotizacionCompara.CorreoSR : usuarioCotizacion.Correo;
                        phonex.productid = Convert.ToInt32(Utilidades.ObtienerValorParametro("IDProducto_Proventel_Autos"));
                        var body = JsonConvert.SerializeObject(phonex);
                        var response = Utilidades.EjecutaPhonex(phonex);
                        var envio = new Proventel_Envio();

                        envio.IdCotizacion = idCotizacion;
                        envio.Fecha = DateTime.Now;
                        envio.Request = body;
                        envio.Response = response;
                        envio.TipoProducto = "Autos";
                        envio.IdClasificacionLead = 1;
                        envio.FechaCambioClasificacion = DateTime.Now;
                        if (!CotSinRegistro)
                            envio.IdUser = usuarioCotizacion.Id;
                        db.Proventel_Envio.Add(envio);
                        db.SaveChanges();
                    }
                    else
                    {
                        var Leads = new LeadsModel();
                        Leads.numeroCotizacion = cotizacion.Id.ToString();
                        Leads.numeroEmpleado = empleado;
                        Leads.nombre = (CotSinRegistro) ? cotizacionCompara.ObtieneNombreCompletoSR() : usuarioCotizacion.ObtieneNombreCompleto();
                        Leads.marca = auto.Marca;
                        Leads.modelo = auto.Modelo;
                        Leads.tipo = auto.TipoVehiculo.Trim() == "1" ? "AUTO" : (auto.TipoVehiculo.Trim() == "3" ? "MOTO" : "PICKUP");
                        Leads.empresa = empresa;
                        Leads.telefono = cel;
                        Leads.email = (CotSinRegistro) ? cotizacionCompara.CorreoSR : usuarioCotizacion.Correo;
                        Leads.productID = Convert.ToInt32(Utilidades.ObtienerValorParametro("IDProducto_Leads_Autos"));
                        var body = JsonConvert.SerializeObject(Leads);
                        var response = Utilidades.EjecutaLeads(body);
                        var envio = new Proventel_Envio();

                        envio.IdCotizacion = idCotizacion;
                        envio.Fecha = DateTime.Now;
                        envio.Request = body;
                        envio.Response = response;
                        envio.TipoProducto = "Autos";
                        envio.IdClasificacionLead = 1;
                        envio.FechaCambioClasificacion = DateTime.Now;
                        if (!CotSinRegistro)
                            envio.IdUser = usuarioCotizacion.Id;

                        db.Proventel_Envio.Add(envio);
                        db.SaveChanges();
                    }
                }

            }
            catch (Exception ex)
            {

            }
        }



        private HorarioAseguradora ValidaHoariosServicio(int idAseguradora)
        {
            var today = DateTime.Now;
            var hours = today.Hour;
            var minute = today.Minute;
            var horario = new HorarioAseguradora();
            horario.ServicioFueraLinea = false;
            horario.Mensaje = "";

            var horarioConfigurado = db.CatAseguradoraHorario.FirstOrDefault(a => a.IdAseguradora == idAseguradora && a.Dia == (int)today.DayOfWeek);

            if (horarioConfigurado != null)
            {
                var timebegin = new TimeSpan(horarioConfigurado.HoraInicio, horarioConfigurado.MinutoInicio, 0);
                var timeend = new TimeSpan(horarioConfigurado.HoraFin, horarioConfigurado.MinutoFin, 0);
                var timetoday = new TimeSpan(hours, minute, 0);

                if (timetoday < timebegin || timetoday > timeend)
                {
                    horario.ServicioFueraLinea = true;
                    horario.Mensaje = horarioConfigurado.Mensaje;


                }
            }

            //if (today.DayOfWeek == DayOfWeek.Sunday)
            //{
            //    if (hours < 8 || hours > 20)
            //        fueraHorario = true;
            //}
            //else if (today.DayOfWeek == DayOfWeek.Saturday)
            //{
            //    var timebegin = new TimeSpan(7, 20, 0);
            //    var timeend = new TimeSpan(20, 00, 0);
            //    var timetoday = new TimeSpan(hours, minute, 0);

            //    if (timetoday < timebegin || timetoday > timeend)
            //        fueraHorario = true;
            //}
            //else
            //{
            //    var timebegin = new TimeSpan(7, 20, 0);
            //    var timeend = new TimeSpan(22, 40, 0);
            //    var timetoday = new TimeSpan(hours, minute, 0);

            //    if (timetoday < timebegin || timetoday > timeend)
            //        fueraHorario = true;
            //}

            return horario;
        }

        /// <summary>
        /// vista parcial para presentar resultados del comparativo
        /// </summary>
        /// <param name="IdCotizacion"></param>
        /// <param name="FormadePagoC"></param>
        /// <param name="MediodePagoC"></param>
        /// <param name="CoberturaC"></param>
        /// <returns></returns>

        public ActionResult Comparativo(int IdCotizacion, string FormadePagoC, string MediodePagoC, string DescripcionVehiculo,
            string NumeroDePoliza,
            string CodigoPostal = "", string Edad = "", string Genero = "", string CoberturaC = "", string aseguradora = "",
            string PaquetesIds = "", string AseguradorasIds = "")
        {
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);
            ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);

            // 1 aseguradora / 2 paquete
            //log.Info("CotizacionVehiculo obtener la configuracion de la empresa");
            ViewBag.IdTipoComparativo = configuracionEmpresa.IdTipoComparativo;
            ViewBag.IdTipoDeNegocio = configuracionEmpresa.IdTipoDeNegocio;
            ViewBag.MensajeComprarPoliza = configuracionEmpresa.MensajeBotonComprar;
            CotizacionCompara cotizacionComparaOriginal = new CotizacionCompara();
            cotizacionComparaOriginal.NumeroDePoliza = NumeroDePoliza;

            CotizacionCompara cotizacionComparaRespuesta = new CotizacionCompara();
            //buscar la cotizacion original
            CotizacionAuto DatosCotizacionAuto = new CotizacionAuto();
            DatosCotizacionAuto = db.CotizacionAuto.FirstOrDefault(original => original.IdCotizacion == IdCotizacion);
            CatUsoVehiculo cattipoVehiculo = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == DatosCotizacionAuto.TipoVehiculo);
            Cotizacion cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == IdCotizacion);
            var detalle = db.CotizacionDetalle.Where(a => a.IdCotizacion == IdCotizacion && a.FechaCotizacion.HasValue).FirstOrDefault();
            if (DatosCotizacionAuto != null && IdCotizacion > 0)
            {
                //log.Info("CotizacionVehiculo, parsea a lista de entidad");
                cotizacionComparaOriginal.IdCotizacion = IdCotizacion;
                cotizacionComparaOriginal.IdUso = cotizacion.IdUso ?? 0;
                cotizacionComparaOriginal.TipoVehiculo = DatosCotizacionAuto.TipoVehiculo;
                cotizacionComparaOriginal.AseguradoraClaveHomologado = aseguradora ?? "";
                cotizacionComparaOriginal.Marca = DatosCotizacionAuto.Marca;
                cotizacionComparaOriginal.Año = DatosCotizacionAuto.Agnio;
                cotizacionComparaOriginal.Modelo = DatosCotizacionAuto.Modelo;
                cotizacionComparaOriginal.Version = DatosCotizacionAuto.Version;
                cotizacionComparaOriginal.Descripcion = DatosCotizacionAuto.Descripcion;
                cotizacionComparaOriginal.DescripcionVehiculo = DatosCotizacionAuto.Descripcion;
                cotizacionComparaOriginal.ValorFactura = DatosCotizacionAuto.ValorFactura;
                cotizacionComparaOriginal.FechaFactura = DatosCotizacionAuto.FechaFactura;
                cotizacionComparaOriginal.MontoFactura = DatosCotizacionAuto.MontoFactura;
                cotizacionComparaOriginal.NumeroFactura = cotizacion.NumeroFactura;
                cotizacionComparaOriginal.MontoDeclarado = DatosCotizacionAuto.MontoDeclarado;
                cotizacionComparaOriginal.Cobertura = DatosCotizacionAuto.Cobertura;
                cotizacionComparaOriginal.FormadePago = DatosCotizacionAuto.FormadePago;
                cotizacionComparaOriginal.MediodePago = DatosCotizacionAuto.MediodePago;
                cotizacionComparaOriginal.FechaCotizacion = detalle != null && detalle.FechaCotizacion.HasValue ? detalle.FechaCotizacion.Value : DateTime.Now;
                cotizacionComparaOriginal.FechaNacimiento = cotizacion.FechaNacimiento;
                cotizacionComparaOriginal.IdDocto = cotizacion.IdDocto ?? 0;
                cotizacionComparaOriginal.PaquetesIds = PaquetesIds;
                cotizacionComparaOriginal.AseguradorasIds = AseguradorasIds;

                var _sinRegistro = db.CotizacionSinRegistro.FirstOrDefault(a => a.IdCotizacion == IdCotizacion);

                if (_sinRegistro != null)
                {
                    cotizacionComparaOriginal.NombreSR = _sinRegistro.Nombre;
                    cotizacionComparaOriginal.Nombre2SR = _sinRegistro.Nombre2;
                    cotizacionComparaOriginal.ApPaternoSR = _sinRegistro.ApPaterno;
                    cotizacionComparaOriginal.ApMaternoSR = _sinRegistro.ApMaterno;
                    cotizacionComparaOriginal.CorreoSR = _sinRegistro.Correo;
                    cotizacionComparaOriginal.CelularSR = _sinRegistro.Celular;
                    cotizacionComparaOriginal.nombreEmpresaUSR = _sinRegistro.NombreEmpresaUSR;
                }
            }
            //modifica los valores nuevos
            if (!string.IsNullOrEmpty(FormadePagoC))
            {
                cotizacionComparaOriginal.FormadePago = int.Parse(FormadePagoC);
            }
            else
            {
                cotizacionComparaOriginal.FormadePago = 0;
            }

            int cM = 0;
            if (int.TryParse(MediodePagoC, out cM))
                cotizacionComparaOriginal.MediodePago = cM;
            if (int.TryParse(CoberturaC, out cM))
                cotizacionComparaOriginal.Cobertura = cM;

            cotizacionComparaOriginal.Descripcion = DescripcionVehiculo;

            cotizacionComparaOriginal.CodigoPostal = CodigoPostal;
            cotizacionComparaOriginal.Edad = Edad;
            cotizacionComparaOriginal.Genero = Genero;


            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.ReCotizacion, idCotizacion: cotizacionComparaRespuesta.IdCotizacion, EmpresaId: configuracionEmpresa.IdEmpresa);
            //return RedirectToAction("CotizacionCompara", cotizacionComparaOriginal);
            //regresar los valores calculados
            cotizacionComparaRespuesta = CalculaCotizacion(cotizacionComparaOriginal, true);
            cotizacionComparaRespuesta.IdDocto = cotizacionComparaOriginal.IdDocto;
            ////cotizacionComparaRespuesta.NumeroDePoliza = NumeroDePoliza;
            //ViewBag.FechaInicioRec = cotizacionComparaRespuesta.Comparar.FirstOrDefault().FechaInicio;
            //ViewBag.FechaTerminoRec = cotizacionComparaRespuesta.Comparar.FirstOrDefault().FechaFin;
            //ViewBag.PrimaTotalRec = "";

            CatTipoPaquete catTipoPaquete = db.CatTipoPaquete.Find(cotizacionComparaOriginal.Cobertura);
            if (catTipoPaquete != null)
                cotizacionComparaRespuesta.Cobertura = catTipoPaquete.Id;

            cotizacionComparaRespuesta.NombreTipoVehiculo = cattipoVehiculo == null ? string.Empty : cattipoVehiculo.Nombre.ToUpper();


            if (cotizacionComparaOriginal.IdUso > 0)
            {
                var catuso = db.CatUsos.FirstOrDefault(a => a.Id == cotizacionComparaOriginal.IdUso);
                if (cotizacionComparaRespuesta.NombreTipoVehiculo.Contains("("))
                    cotizacionComparaRespuesta.NombreTipoVehiculo = $"{cotizacionComparaRespuesta.NombreTipoVehiculo.Substring(0, cotizacionComparaRespuesta.NombreTipoVehiculo.IndexOf('('))} {catuso.Nombre} - {catuso.ClaveGNP}";
                else
                    cotizacionComparaRespuesta.NombreTipoVehiculo = $"{cotizacionComparaRespuesta.NombreTipoVehiculo} {catuso.Nombre} - {catuso.ClaveGNP}";
            }
            return PartialView(cotizacionComparaRespuesta);
        }

        /// <summary>
        /// Calcular cotizacion
        /// </summary>
        /// <param name="cotizacionCompara">parametros de la cotizacion</param>
        /// <returns>cotizacion realizada</returns>
        private CotizacionCompara CalculaCotizacion(CotizacionCompara cotizacionCompara, bool recotizacion = false)

        {
            ViewBag.TxtNombreEmpresaUSR = false;
            log.Info("01 CalculaCotizacion inicio");

            CotizacionCompara cotizacionComparaRespuesta = new CotizacionCompara();
            //asigna Numer de poliza
            cotizacionComparaRespuesta.NumeroDePoliza = cotizacionCompara.NumeroDePoliza;
            Cotizar consultar = new Cotizar();
            //log.Info("02 CalculaCotizacion obtiene datos detalle del usuario");
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);



            if (RegDetalleUsuario.SinRegistro)
            {
                ViewBag.UsuarioGenerico = 1;
                cotizacionCompara.ValidaMembresia = false;
                if (Session["__Membership__Number__"] != null && !string.IsNullOrEmpty(Session["__Membership__Number__"].ToString()))
                    RegDetalleUsuario.NumeroMembresia = Session["__Membership__Number__"].ToString();

                if (configuracionEmpresa.ValidaMicrositio)
                {
                    var micrositio = db.CatMicrositio.FirstOrDefault(a => a.Id == configuracionEmpresa.IdCatMicrositio);

                    if (configuracionEmpresa.IdCatMicrositio == 1 && Session["__Membership__Number__"] == null)
                    {
                        Session.Add("MembershipValidation", RegDetalleUsuario.IdUsuario);
                        cotizacionComparaRespuesta.Exitoso = false;
                        cotizacionComparaRespuesta.TipoError = 1; //Redirect to index

                        return cotizacionComparaRespuesta;

                    }
                }

                ViewBag.LogueoRapido = configuracionEmpresa.LogueoRapido ? 1 : 0;

            }
            else
            {
                ViewBag.UsuarioGenerico = 0;
                ViewBag.LogueoRapido = 0;
                cotizacionCompara.ValidaMembresia = configuracionEmpresa.ValidaMembresiaCostco;
            }


            string aseguradora = string.Empty;
            int IdCotizacion = 0;
            string claveAseguradora = string.Empty;

            ViewBag.PaqueteDetalles = new List<PaqueteDetalle>();
            ViewBag.ListaCobertura = new List<Cobertura>();
            string claveHomologadaSeleccionada = cotizacionCompara.Descripcion;
            cotizacionCompara.ClaveHomologadaSeleccionada = claveHomologadaSeleccionada;
            List<Tuple<string, string>> descs = new List<Tuple<string, string>>();
            bool multiple = UsuarioMultipleAseguradora(RegDetalleUsuario.IdUsuario);
            string claveHomologadoAseguradora = UsuarioAseguradoraEmpresa(User.Identity.GetUserName().Contains("generico") ? RegDetalleUsuario.IdUsuario : User.Identity.GetUserName());

            if (RegDetalleUsuario != null)
            {
                //log.Info("03 CalculaCotizacion contiene detalle de la empresa");

                int? idTipoVehiculo = null;
                if (!string.IsNullOrEmpty(cotizacionCompara.TipoVehiculo))
                    idTipoVehiculo = Convert.ToInt32(cotizacionCompara.TipoVehiculo);

                //APAGADO 
                cotizacionCompara.AplicaFechaRetroactiva = false;// usuarioAlias;

                ViewBag.MensajeComprarPoliza = configuracionEmpresa.MensajeBotonComprar;
                if (configuracionEmpresa != null)
                {
                    //ViewBag.IdTipoComparativo = 3;
                    ViewBag.IdTipoComparativo = configuracionEmpresa.IdTipoComparativo;//OHSS
                    //Se agrega configuracion de ordenamiento 
                    ViewBag.IdOrdenamiento = db.Empresa.FirstOrDefault(emp => emp.Id == IdEmpresa).IdOrdenamiento;
                    ViewBag.IdOrden = configuracionEmpresa.IdConfiguracionOrdenamiento;
                    ViewBag.SoloCotizar = db.Empresa.FirstOrDefault(emp => emp.Id == IdEmpresa).SoloCotizar;
                    string iduser = (User.Identity as System.Security.Claims.ClaimsIdentity).FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value;
                    var usuarioFinal = db.DetalleUsuario.FirstOrDefault(x => x.IdUsuario == iduser && x.IdPerfil == 3);
                    ViewBag.Usuarioinal = usuarioFinal != null && !RegDetalleUsuario.SinRegistro ? true : false;

                    VEmpConvPaq ConveniosPaquetes;
                    var catusovehiculo = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == cotizacionCompara.TipoVehiculo);
                    int idCarRamoVehiculo = catusovehiculo.IdCatRamo ?? 1;

                    if (cotizacionCompara.ComparativoAnual)
                    {
                        cotizacionCompara.MediodePago = 0;
                        cotizacionCompara.FormadePago = 1;


                        ConveniosPaquetes = new VEmpConvPaq(IdEmpresa, idCarRamoVehiculo.ToString());
                    }
                    else
                    {
                        //Obtener solo los convenios que deben de aplicar para la forma de pago y medio de pago seleccionados
                        var conveniosAplicables = db.Database.SqlQuery<int>(string.Format("sp_consultar_ConveniosAplicables @IdEmpresa = {0}, @IdFormaPago = {1}, @IdMedioPago = {2}", IdEmpresa, cotizacionCompara.FormadePago, cotizacionCompara.MediodePago)).ToList();
                        ConveniosPaquetes = new VEmpConvPaq(IdEmpresa, conveniosAplicables);
                    }

                    CombosGenerales(ConveniosPaquetes);
                    cotizacionCompara.EsFlotilla = configuracionEmpresa.IdTipoDeNegocio == 1 || configuracionEmpresa.IdTipoDeNegocio == 4;

                    //VALIDA SI VIENE DE RENOVACION Y NO VIENE LA FORMA DE PAGO Y
                    if (cotizacionCompara.FormadePago == 0 && cotizacionCompara.MediodePago == 0)
                    {
                        cotizacionCompara.FormadePago = ConveniosPaquetes.modalidadFormaPagos.FirstOrDefault().IdCatPeriodicidadFormaPago;
                        cotizacionCompara.MediodePago = ConveniosPaquetes.modalidadFormaPagos.FirstOrDefault().IdCatModalidadFormaPago;
                    }

                    List<ModalidadFormaPago> ListaModalidadFormaPago = new List<ModalidadFormaPago>();
                    var administrador = UsuarioAdministrador();
                    int IdConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().Id;
                    ViewBag.IdConvenio = IdConvenio;
                    ListaModalidadFormaPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == IdConvenio
                                                && x.IdCatPeriodicidadFormaPago == cotizacionCompara.FormadePago
                                                && !x.SoloAdministrador).ToList();
                    if (administrador)
                        ListaModalidadFormaPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == IdConvenio
                                                && x.IdCatPeriodicidadFormaPago == cotizacionCompara.FormadePago).ToList();

                    List<CatModalidadFormaPago> listaCat = db.CatModalidadFormaPago.ToList();
                    List<object> listaCombo = new List<object>();

                    if (ListaModalidadFormaPago.Count > 0)
                    {
                        string descripcionMFP = string.Empty;
                        string cve = string.Empty;
                        ListaModalidadFormaPago.ForEach(reg =>
                        {
                            descripcionMFP = listaCat.FirstOrDefault(lcat => lcat.Id == reg.IdCatModalidadFormaPago).Nombre.Trim();
                            cve = listaCat.FirstOrDefault(lcat => lcat.Id == reg.IdCatModalidadFormaPago).Clave.Trim();
                            listaCombo.Add(new { Clave = cve, Nombre = descripcionMFP });
                        });
                    }

                    ViewBag.MedioPago = new SelectList(listaCombo, "Clave", "Nombre");

                    ViewBag.PaqueteDetalles = ConveniosPaquetes.PaqueteDetalles;
                    ViewBag.ListaCobertura = ConveniosPaquetes.listaCoberturas;

                    //OHSS:Se agregan las aseguradoras que se necesitan


                    List<LocktonModel.db.Convenio> convenios = new List<LocktonModel.db.Convenio>();
                    List<LocktonModel.db.Aseguradora> aseguradoras = new List<LocktonModel.db.Aseguradora>();
                    List<CatTipoPaquete> TipoPaqueteResult = new List<CatTipoPaquete>();
                    if (ConveniosPaquetes.Convenios.Count() > 0)
                    {
                        VEmpConvPaq ConveniosPaquetesView = new VEmpConvPaq(IdEmpresa);
                        var idAseguradoras = ConveniosPaquetesView.Convenios.Select(a => a.IdAseguradora).ToList();
                        //ViewBag.Convenios = new SelectList(ConveniosPaquetes.Convenios.ToList(), "Id", "CaratulaPoliza");
                        ViewBag.Aseguradoras = db.Aseguradora
                        .Where(x => idAseguradoras.Contains(x.Id))
                        .OrderBy(x => x.Nombre)
                        .Select(x => new { Id = x.Id, Nombre = x.Nombre, x.ClaveHomologado }) // solo los campos necesarios
                        .ToList();


                    }
                    if (cotizacionCompara.AseguradorasIds != null && cotizacionCompara.AseguradorasIds.Length > 0 && cotizacionCompara.PaquetesIds != null && cotizacionCompara.PaquetesIds.Length > 0 && ConveniosPaquetes.Convenios.Count() > 0)
                    {
                        var idAseguradoras = cotizacionCompara.AseguradorasIds
                                            .Split(',')
                                            .Select(id => int.Parse(id))
                                            .ToList();
                        var idPaquetes = cotizacionCompara.PaquetesIds
                                            .Split(',')
                                            .Select(id => int.Parse(id))
                                            .ToList();

                        aseguradoras = db.Aseguradora
                        .Where(x => idAseguradoras.Contains(x.Id))
                        .ToList();

                        convenios = db.Convenio
                         .Where(a => a.IdEmpresa == IdEmpresa && idAseguradoras.Contains(a.IdAseguradora))
                         .ToList();
                        List<int> todosIdsTipoPaquete = new List<int>();
                        foreach (var convenio in convenios)
                        {
                            VEmpConvPaq conveniosPaquetes = new VEmpConvPaq(convenio.IdEmpresa, convenio.Id);
                            var ids = conveniosPaquetes.PaqueteDetalles
                                                        .Select(x => x.IdCatTipoPaquete)
                                                       .Distinct()
                                                       .ToList();

                            todosIdsTipoPaquete.AddRange(ids);
                        }
                        // Quitar duplicados
                        todosIdsTipoPaquete = todosIdsTipoPaquete.Distinct().ToList();
                        // Filtrar paquetes según lógica

                        TipoPaqueteResult = db.CatTipoPaquete
                               .Where(x => todosIdsTipoPaquete.Contains(x.Id) && idPaquetes.Contains(x.Id) && x.Estatus == 1)
                               .ToList();
                        // Opcional: Eliminar duplicados si es necesario.
                        TipoPaqueteResult = TipoPaqueteResult.DistinctBy(x => x.Id).ToList();
                        ViewBag.Paquetes = TipoPaqueteResult;

                    }
                    else
                    {
                        convenios = ConveniosPaquetes.Convenios;
                    }





                    //descs = consultar.ConsultaDescripcionHomologado(cotizacionCompara.Marca, cotizacionCompara.Año, cotizacionCompara.Modelo, "", aseguradora);
                    //por cada convenio de la empresa
                    foreach (LocktonModel.db.Convenio seguroEmpresa in convenios)
                    {

                        claveAseguradora = string.Empty;
                        var _aseguradora = db.Aseguradora.FirstOrDefault(a => a.Id == seguroEmpresa.IdAseguradora);
                        aseguradora = _aseguradora.ClaveHomologado;

                        var puedeCotizar = true;

                        //SI ES ENROLLMENT PARA QUALITAS SE VALIDARA SI EL CONVENIO ES SOLO PARA ENROLLMENT
                        if (_aseguradora.Id == 1 || _aseguradora.Id == 2)
                        {
                            if (configuracionEmpresa.ConveniosSoloEnrollment)
                            {

                                if (!string.IsNullOrEmpty(cotizacionCompara.NumeroDePoliza)) //RENOVACION
                                {
                                    var ot = db.OTRenovacion.First(a => a.NumeroDePoliza == cotizacionCompara.NumeroDePoliza);
                                    var claveAgenteConvenio = "";
                                    if (_aseguradora.Id == 1)
                                    {
                                        if (cotizacionCompara.FormadePago > 0)
                                        {
                                            var catm = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == cotizacionCompara.MediodePago.ToString());
                                            var modalidad = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == seguroEmpresa.Id && a.IdCatPeriodicidadFormaPago == cotizacionCompara.FormadePago && a.IdCatModalidadFormaPago == catm.Id);
                                            if (modalidad != null)
                                                claveAgenteConvenio = modalidad.ClaveAgenteModalidadFormaPago;
                                        }
                                        else
                                        {
                                            var modalidad = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == seguroEmpresa.Id);
                                            if (modalidad != null)
                                                claveAgenteConvenio = modalidad.ClaveAgenteModalidadFormaPago;
                                        }
                                    }

                                    if (ot.CAgente.Trim() != claveAgenteConvenio.Trim())
                                        puedeCotizar = false;
                                }
                                else if (seguroEmpresa.CotizaSoloEnrollment)
                                    puedeCotizar = false;
                            }
                        }

                        if (_aseguradora.Id == 10 && seguroEmpresa.UsoCatalogoAXAEMA)
                            aseguradora = "AXAEMA";
                        if (!ConveniosPaquetes.Convenios.Any(a => a.IdAseguradora == seguroEmpresa.IdAseguradora))
                            puedeCotizar = false;
                        if (puedeCotizar)
                        {

                            ObtenerFechaCotizacion(configuracionEmpresa, ConveniosPaquetes, seguroEmpresa.IdAseguradora, IdEmpresa, ref cotizacionCompara);

                            //string descripcionVehiculoSeleccionado = string.Empty;

                            foreach (string clave in cotizacionCompara.Descripcion.Split(','))
                            {
                                if (clave.Split('|')[0].ToUpper().Equals(aseguradora.ToUpper()))
                                {
                                    claveAseguradora = clave.Split('|')[1];
                                    break;
                                }
                            }
                            if (!string.IsNullOrEmpty(claveAseguradora))
                            {
                                var convenioRamoPaquete = ConveniosPaquetes.ConvenioRamoPaquetes.FirstOrDefault(x => x.IdConvenio == seguroEmpresa.Id && x.IdCatRamoVehiculo == idCarRamoVehiculo);
                                if (convenioRamoPaquete == null)
                                {
                                    continue;
                                }
                                int idConvenioRamoPaquete = convenioRamoPaquete.Id;
                                cot = consultar.ConsultaParaCotiza(cotizacionCompara, aseguradora, claveAseguradora);

                                if (string.IsNullOrEmpty(cotizacionCompara.Modelo))
                                    cotizacionCompara.Modelo = cot.Catalogo[0].Modelo;


                                if (idTipoVehiculo > 1)
                                {
                                    claveHomologadoAseguradora = cotizacionCompara.AseguradoraClaveHomologado;
                                    descs = consultar.ConsultaDescripcionHomologado(cotizacionCompara.Marca, cotizacionCompara.Año, cotizacionCompara.Modelo, "", claveHomologadoAseguradora, false, idTipoVehiculo);//toma la generica     
                                }
                                else
                                    descs = consultar.ConsultaDescripcionHomologado(cotizacionCompara.Marca, cotizacionCompara.Año, cotizacionCompara.Modelo, "", claveHomologadoAseguradora, multiple, idTipoVehiculo);//toma la generica   


                                if (configuracionEmpresa.IdTipoComparativo == 1)
                                {//todas las aseguradoras mismo paquete
                                    var _idCobertura = cotizacionCompara.Cobertura;

                                    if (_aseguradora.Id == 25)
                                    {
                                        var _paqueteOnLine = db.CatTipoPaquete.FirstOrDefault(a => a.Id == _idCobertura);

                                        if (_paqueteOnLine.Nombre.Trim().ToUpper() == "TOTAL")
                                        {
                                            var _paqueteOffLine = db.CatTipoPaquete.FirstOrDefault(a => a.Nombre.Trim().ToUpper() == "AMPLIA ELID" && !a.OnLine);
                                            _idCobertura = _paqueteOffLine.Id;
                                        }
                                        else
                                        {
                                            var _paqueteOffLine = db.CatTipoPaquete.FirstOrDefault(a => a.Nombre.Trim().ToUpper() == _paqueteOnLine.Nombre.ToUpper().Trim() && !a.OnLine);
                                            _idCobertura = _paqueteOffLine.Id;
                                        }
                                    }

                                    if (!ConveniosPaquetes.PaqueteDetalles.Exists(cobertura => cobertura.IdConvenioRamoPaquete == idConvenioRamoPaquete && cobertura.IdCatTipoPaquete == _idCobertura))
                                    {//no existe el paquete cobertura
                                        continue;
                                    }
                                    try
                                    {
                                        var paquetesConvenio = ConveniosPaquetes.PaqueteConvenio.Where(a => a.IdConvenio == seguroEmpresa.Id && a.IdCatRamoVehiculo == convenioRamoPaquete.IdCatRamoVehiculo && a.IdCatTipoPaquete == _idCobertura).ToList();

                                        foreach (var paqueteConvenio in paquetesConvenio)
                                        {
                                            if (configuracionEmpresa.ComparativoAnual)
                                            {
                                                var _periodicidadFormaPago = db.PeriodicidadFormaPago.FirstOrDefault(a => a.IdConvenio == seguroEmpresa.Id);
                                                var _medio = db.ListaCombo.SqlQuery(string.Format("sp_consultar_ModalidadFormaPagoConvenio @IdConvenio={0}, @IdFormaPago={1}", paqueteConvenio.IdConvenio, _periodicidadFormaPago.IdCatPeriodicidadFormaPago)).FirstOrDefault();
                                                cotizacionCompara.FormadePago = _periodicidadFormaPago.IdCatPeriodicidadFormaPago;
                                                cotizacionCompara.MediodePago = _medio.Id;
                                            }


                                            cotizacionCompara.Descripcion = cotizacionCompara.DescripcionVehiculo;// descs.FirstOrDefault(x => x.Item1.Equals(claveHomologadaSeleccionada)).Item2;
                                            cotizacionComparaRespuesta = consultar.Cotizacion(cotizacionCompara, aseguradora, cot, seguroEmpresa.Id, RegDetalleUsuario, ConveniosPaquetes, _idCobertura, paqueteConvenio.Id, idUsuarioLogin: User.Identity.GetUserId());
                                            cotizacionCompara.Descripcion = claveHomologadaSeleccionada;
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        log.Info("-1-CalculaCotizacion: " + ex.Message);
                                        cotizacionCompara.Descripcion = claveHomologadaSeleccionada;
                                    }
                                }
                                else
                                {
                                    //todos los paquetes disponibles de cada aseguradora
                                    //de cada convenio obtenermos su convenio ramo paquete
                                    //int idConvenioRamoPaquete = ConveniosPaquetes.ConvenioRamoPaquetes.FirstOrDefault(x => x.IdConvenio == seguroEmpresa.Id).Id;
                                    //foreach (int paqIdCatTipoPaquete in ConveniosPaquetes.PaqueteDetalles.Where(y => y.IdConvenioRamoPaquete == idConvenioRamoPaquete).ToList().Select(x => x.IdCatTipoPaquete).Distinct().ToList())
                                    //{
                                    //	try
                                    //	{
                                    //		cotizacionCompara.Cobertura = paqIdCatTipoPaquete;
                                    //		cotizacionCompara.Descripcion = descs.FirstOrDefault(x => x.Item1.Equals(claveHomologadaSeleccionada)).Item2;
                                    //		cotizacionComparaRespuesta = consultar.Cotizacion(cotizacionCompara, aseguradora, cot, seguroEmpresa.Id, RegDetalleUsuario, ConveniosPaquetes, paqIdCatTipoPaquete);
                                    //		cotizacionCompara.Descripcion = claveHomologadaSeleccionada;
                                    //		cotizacionCompara.Cobertura = 0;
                                    //	}
                                    //	catch (Exception ex)
                                    //	{
                                    //		log.Info("-2-CalculaCotizacion: " + ex.Message);
                                    //		cotizacionCompara.Descripcion = claveHomologadaSeleccionada;
                                    //	}
                                    //}



                                    foreach (var paqueteConvenio in ConveniosPaquetes.PaqueteConvenio.Where(a => a.IdCatRamoVehiculo == convenioRamoPaquete.IdCatRamoVehiculo && a.IdConvenio == seguroEmpresa.Id))
                                    {


                                        if (configuracionEmpresa.IdTipoComparativo == 3 && TipoPaqueteResult.Where(x => x.Id == paqueteConvenio.IdCatTipoPaquete).Count() == 0)
                                        {
                                            continue;
                                        }

                                        try
                                        {
                                            if (configuracionEmpresa.ComparativoAnual)
                                            {
                                                var _periodicidadFormaPago = db.PeriodicidadFormaPago.FirstOrDefault(a => a.IdConvenio == seguroEmpresa.Id);
                                                var _medio = db.ListaCombo.SqlQuery(string.Format("sp_consultar_ModalidadFormaPagoConvenio @IdConvenio={0}, @IdFormaPago={1}", paqueteConvenio.IdConvenio, _periodicidadFormaPago.IdCatPeriodicidadFormaPago)).FirstOrDefault();
                                                cotizacionCompara.FormadePago = _periodicidadFormaPago.IdCatPeriodicidadFormaPago;
                                                cotizacionCompara.MediodePago = _medio.Id;
                                            }

                                            cotizacionCompara.Cobertura = paqueteConvenio.IdCatTipoPaquete;
                                            cotizacionCompara.Descripcion = cotizacionCompara.DescripcionVehiculo;// descs.FirstOrDefault(x => x.Item1.Equals(claveHomologadaSeleccionada)).Item2;
                                            cotizacionComparaRespuesta = consultar.Cotizacion(cotizacionCompara, _aseguradora.ClaveHomologado, cot, seguroEmpresa.Id, RegDetalleUsuario, ConveniosPaquetes, paqueteConvenio.IdCatTipoPaquete, paqueteConvenio.Id, idUsuarioLogin: User.Identity.GetUserId());
                                            cotizacionCompara.Descripcion = claveHomologadaSeleccionada;
                                            cotizacionCompara.Cobertura = 0;
                                        }
                                        catch (Exception ex)
                                        {
                                            log.Info("-2-CalculaCotizacion: " + ex.Message);
                                            cotizacionCompara.Descripcion = claveHomologadaSeleccionada;
                                        }
                                    }

                                }
                            }
                        }
                    }


                    ViewBag.FechaInicio = cotizacionCompara.FechaInicio.ToString("dd/MM/yyyy");
                    ViewBag.FechaTermino = cotizacionCompara.FechaFin.ToString("dd/MM/yyyy");

                    //List<Tuple<string, string>> descs = consultar.ConsultaDescripcionHomologado(cotizacionCompara.Marca, cotizacionCompara.Año, cotizacionCompara.Modelo, "", aseguradora);//toma la generica   
                    if (descs.Any())
                    {
                        // descs.FirstOrDefault(x => x.Item1.Equals(claveHomologadaSeleccionada)).Item2;

                        if (!descs.Exists(a => a.Item1 == cotizacionComparaRespuesta.ClaveHomologadaSeleccionada))
                        {
                            descs.Add(Tuple.Create(cotizacionComparaRespuesta.ClaveHomologadaSeleccionada, descs.First().Item2));

                        }

                        ViewBag.DescripcionVehiculo = descs;
                    }
                    cotizacionComparaRespuesta.Descripcion = cotizacionCompara.DescripcionVehiculo;
                    ConsultaHomologacion consultaHomologacion = new ConsultaHomologacion("LocktonOne", "LocktonOne2017");

                    foreach (Comparar item in cotizacionComparaRespuesta.Comparar)
                    {
                        if (string.IsNullOrEmpty(item.ErrorXML))
                        {
                            item.HorarioAseguradora = ValidaHoariosServicio(item.IdAseguradora);

                            if (multiple)
                            {
                                List<Tuple<string, string>> _descs = new List<Tuple<string, string>>();
                                try
                                {
                                    Aseguradora _aseguradora = db.Aseguradora.FirstOrDefault(a => a.Id == item.IdAseguradora);
                                    string _amis = "";
                                    foreach (string clave in claveHomologadaSeleccionada.Split(','))
                                    {
                                        if (clave.Split('|')[0].ToUpper().Equals(_aseguradora.ClaveHomologado.ToUpper()))
                                        {
                                            _amis = clave.Split('|')[1];
                                            break;
                                        }
                                    }
                                    _AmisVehiculos _cars = consultaHomologacion.ConsultarAmisAseguradora(_amis, _aseguradora.ClaveHomologado);
                                    AmisVehiculo _car = _cars.Vehiculos.FirstOrDefault();
                                    List<Tuple<string, string>> _descAseguradoras = consultar.ConsultaDescripcionHomologado(_car.Marca, cotizacionComparaRespuesta.Año, _car.Modelo, "", _aseguradora.ClaveHomologado, false, null);

                                    foreach (Tuple<string, string> desAseg in _descAseguradoras)
                                    {
                                        Tuple<string, string> _itemMatrix = GetItemInMatrix(_aseguradora.ClaveHomologado.ToUpper(), desAseg.Item1, descs);
                                        Tuple<string, string> _exist = _descs.FirstOrDefault(x => x.Item1.Contains(desAseg.Item1));
                                        if (_itemMatrix != null && _exist == null)
                                        {
                                            _descs.Add(Tuple.Create(_itemMatrix.Item1, desAseg.Item2));
                                        }
                                    }
                                    if (!_descs.Exists(a => a.Item1 == cotizacionComparaRespuesta.ClaveHomologadaSeleccionada))
                                    {
                                        if (_descs.Exists(a => a.Item2 == _car.Version))
                                            _descs = _descs.Where(a => a.Item2 != _car.Version).ToList();
                                        _descs.Add(Tuple.Create(cotizacionComparaRespuesta.ClaveHomologadaSeleccionada, _car.Version));

                                    }
                                }
                                catch { }
                                item.DescripcionVehiculoAseguradora = _descs;
                            }
                            else
                                item.DescripcionVehiculoAseguradora = descs;

                            //if (item.Aseguradora == "AXA")
                            //{
                            //ViewBag.FechaTermino = item.FechaFin;
                            //ViewBag.FechaInicio = item.FechaInicio;
                            //}
                        }
                        else
                            item.DescripcionVehiculoAseguradora = descs;

                    }
                    ////guarda informacion
                    IdCotizacion = GuardaCotizaciones(cotizacionComparaRespuesta, RegDetalleUsuario.Id, cotizacionCompara.IdDocto, RegDetalleUsuario.NumeroMembresia ?? "");
                    int IdCotizacionSinRegistro;
                    if (RegDetalleUsuario.SinRegistro)
                    {
                        RegistroUsuario SinRegistro = new RegistroUsuario()
                        {
                            Nombre = cotizacionCompara.NombreSR,
                            Nombre2 = string.IsNullOrEmpty(cotizacionCompara.Nombre2SR) ? "" : cotizacionCompara.Nombre2SR,
                            ApPaterno = cotizacionCompara.ApPaternoSR,
                            ApMaterno = cotizacionCompara.ApMaternoSR,
                            Correo = cotizacionCompara.CorreoSR,
                            Celular = cotizacionCompara.CelularSR,
                            NombreEmpresaUSR = cotizacionCompara.nombreEmpresaUSR,
                            NumeroMembresia = RegDetalleUsuario.NumeroMembresia
                        };
                        cotizacionComparaRespuesta.SinRegistro = SinRegistro;
                        IdCotizacionSinRegistro = GuardaCotizacionSinRegistro(cotizacionComparaRespuesta.SinRegistro, IdCotizacion, 1);
                        cotizacionComparaRespuesta.IdCotizacionSinRegistro = IdCotizacionSinRegistro;
                    }
                    if (!recotizacion)
                    {
                        if (RegDetalleUsuario.SinRegistro)
                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.CotizarAutoSinRegistro, idCotizacion: IdCotizacion, EmpresaId: configuracionEmpresa.IdEmpresa, membresia: RegDetalleUsuario.NumeroMembresia);
                        else
                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.Cotizar, idCotizacion: IdCotizacion, EmpresaId: configuracionEmpresa.IdEmpresa, membresia: RegDetalleUsuario.NumeroMembresia ?? "");
                    }
                    cotizacionComparaRespuesta.IdCotizacion = IdCotizacion;//para recuperar los datos guardados
                    GuardaCotizacionAuto(IdCotizacion, cotizacionCompara, cot);

                    var agregoDetalles = GuardaCotizacionDetalle(IdCotizacion, cotizacionComparaRespuesta);

                    db.Database.ExecuteSqlCommand($"sp_SEGUIMIENTOCOTIZACION_CotizacionAuto @IdCotizacion={IdCotizacion}");

                    //Actualizar si viene de una OT re renovacion NumeroDePoliza
                    if (!string.IsNullOrEmpty(cotizacionCompara.NumeroDePoliza))
                    {
                        ActualizaRenovacion(IdCotizacion, cotizacionCompara.NumeroDePoliza);
                    }

                    if (cotizacionCompara.EnvioProventel && agregoDetalles)
                        EnvioProventel(IdCotizacion, RegDetalleUsuario.SinRegistro, cotizacionCompara);
                }
                ViewBag.TxtNombreEmpresaUSR = configuracionEmpresa.TxtNombreEmpresaUSR;
            }

            ViewBag.Aseguradora = aseguradora;
            ViewBag.CatTipoPaquete = db.CatTipoPaquete.ToList();

            //Regresar lista ordenada
            cotizacionComparaRespuesta = new Cotizar().OrdenamientoComparativo(configuracionEmpresa, cotizacionCompara);

            cotizacionComparaRespuesta.IdEmpresa = IdEmpresa;

            var docPlanes = db.ArchivoEmpresa.Where(a => a.IdEmpresa == IdEmpresa && a.IdTipoDocumento == 3).ToList();

            cotizacionComparaRespuesta.ContieneArchivoPlan = docPlanes.Any();
            cotizacionComparaRespuesta.ComparativoEspecial = configuracionEmpresa.ComparativoEspecial;

            return cotizacionComparaRespuesta;
        }





        private Tuple<string, string> GetItemInMatrix(string aseguradora, string amis, List<Tuple<string, string>> matriz)
        {
            Tuple<string, string> result = null;
            foreach (var desc in matriz)
            {
                foreach (string clave in desc.Item1.Split(','))
                {
                    if (clave.Split('|')[0].ToUpper().Equals(aseguradora.ToUpper()) && clave == amis)
                    {
                        result = desc;
                        break;
                    }
                }
                if (result != null)
                    break;
            }
            return result;
        }
        private string ObtenerAMIS(string claveHomologada, int idAseguradora)
        {
            try
            {
                var _amis = "";
                var aseguradora = db.Aseguradora.FirstOrDefault(a => a.Id == idAseguradora);
                foreach (string clave in claveHomologada.Split(','))
                {
                    if (clave.Split('|')[0].ToUpper().Equals(aseguradora.ClaveHomologado.ToUpper()))
                    {
                        _amis = clave.Split('|')[1];
                        break;
                    }
                }
                return _amis;
            }
            catch (Exception ex)
            {
                log.Info("Error ObtenerAMIS " + claveHomologada + " " + idAseguradora.ToString());
                return string.Empty;
            }

        }
        /// <summary>
        /// Calcular cotizacion
        /// </summary>
        /// <param name="cotizacionCompara">parametros de la cotizacion</param>
        /// <returns>cotizacion realizada</returns>
        private CotizacionCompara CalculaCotizacionCeroComision(CotizacionCompara cotizacionCompara, bool recotizacion = false)
        {
            log.Info("01 CalculaCotizacionCeroComision inicio");
            CotizacionCompara cotizacionComparaRespuesta = new CotizacionCompara();
            //asigna Numer de poliza
            cotizacionComparaRespuesta.NumeroDePoliza = cotizacionCompara.NumeroDePoliza;
            Cotizar consultar = new Cotizar();
            //log.Info("02 CalculaCotizacion obtiene datos detalle del usuario");
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            string aseguradora = string.Empty;
            int IdCotizacion = 0;
            string claveAseguradora = string.Empty;

            ViewBag.PaqueteDetalles = new List<PaqueteDetalle>();
            ViewBag.ListaCobertura = new List<Cobertura>();
            string claveHomologadaSeleccionada = cotizacionCompara.Descripcion;
            cotizacionCompara.ClaveHomologadaSeleccionada = claveHomologadaSeleccionada;
            cotizacionCompara.DescripcionVehiculo = cotizacionCompara.Descripcion;
            //List<Tuple<string, string>> descs = new List<Tuple<string, string>>();
            bool multiple = UsuarioMultipleAseguradora(User.Identity.GetUserId());
            string claveHomologadoAseguradora = UsuarioAseguradoraEmpresa(User.Identity.GetUserId());
            if (RegDetalleUsuario != null)
            {
                //log.Info("03 CalculaCotizacion contiene detalle de la empresa");
                int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;

                ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);

                if (configuracionEmpresa != null)
                {
                    ViewBag.IdTipoComparativo = configuracionEmpresa.IdTipoComparativo;
                    ViewBag.IdOrdenamiento = db.Empresa.FirstOrDefault(emp => emp.Id == IdEmpresa).IdOrdenamiento;
                    VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa, cotizacionCompara.IdConvenio);
                    //CombosGenerales(ConveniosPaquetes);

                    //VALIDA SI VIENE DE RENOVACION Y NO VIENE LA FORMA DE PAGO Y
                    if (cotizacionCompara.FormadePago == 0 && cotizacionCompara.MediodePago == 0)
                    {
                        cotizacionCompara.FormadePago = ConveniosPaquetes.modalidadFormaPagos.FirstOrDefault().IdCatPeriodicidadFormaPago;
                        cotizacionCompara.MediodePago = ConveniosPaquetes.modalidadFormaPagos.FirstOrDefault().IdCatModalidadFormaPago;
                    }

                    List<ModalidadFormaPago> ListaModalidadFormaPago = new List<ModalidadFormaPago>();
                    int IdConvenio = ConveniosPaquetes.Convenios.FirstOrDefault(a => a.IdAseguradora == cotizacionCompara.IdAseguradora).Id;
                    ViewBag.IdConvenio = IdConvenio;
                    var administrador = UsuarioAdministrador();
                    ListaModalidadFormaPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == IdConvenio
                                && x.IdCatPeriodicidadFormaPago == cotizacionCompara.FormadePago
                                && !x.SoloAdministrador).ToList();
                    if (administrador)
                        ListaModalidadFormaPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == IdConvenio && x.IdCatPeriodicidadFormaPago == cotizacionCompara.FormadePago).ToList();
                    List<CatModalidadFormaPago> listaCat = db.CatModalidadFormaPago.ToList();
                    List<object> listaCombo = new List<object>();

                    if (ListaModalidadFormaPago.Count > 0)
                    {
                        string descripcionMFP = string.Empty;
                        string cve = string.Empty;
                        ListaModalidadFormaPago.ForEach(reg =>
                        {
                            descripcionMFP = listaCat.FirstOrDefault(lcat => lcat.Id == reg.IdCatModalidadFormaPago).Nombre.Trim();
                            cve = listaCat.FirstOrDefault(lcat => lcat.Id == reg.IdCatModalidadFormaPago).Clave.Trim();
                            listaCombo.Add(new { Clave = cve, Nombre = descripcionMFP });
                        });
                    }

                    ViewBag.MedioPago = new SelectList(listaCombo, "Clave", "Nombre");

                    //para si es flotilla verificar fechas


                    //DateTime FechaInicio = DateTime.Now;
                    //DateTime FechaTermino = DateTime.Now.AddYears(1);
                    //if (configuracionEmpresa.AplicaFechaCotizacion)
                    //{
                    //    FechaInicio = cotizacionCompara.FechaCotizacion;
                    //    cotizacionCompara.FechaFactura = cotizacionCompara.FechaCotizacion;
                    //    FechaTermino = cotizacionCompara.FechaCotizacion.AddYears(1);
                    //}
                    //if (configuracionEmpresa.AplicaMultiAnual)
                    //{
                    //    CatPeriodicidadFormaPago periodicidad = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == cotizacionCompara.FormadePago);
                    //    if (periodicidad != null)
                    //        FechaTermino = FechaInicio.AddYears(periodicidad.ValorMultiAnual);
                    //}
                    ////obtener la fecha de inicio y fin de la configuracion
                    //if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 1 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 4 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5)//flotilla
                    //{
                    //    //verifica las fechas de inicio
                    //    if (EstaEnPeriodoDeEnrollment(IdEmpresa, FechaInicio))
                    //    {//busca si existe fecha de enrollment
                    //        FechaInicio = ConveniosPaquetes.Convenios[0].InicioVigencia;
                    //    }
                    //    FechaTermino = ConveniosPaquetes.Convenios[0].FinVigencia;
                    //}

                    foreach (LocktonModel.db.Convenio seguroEmpresa in ConveniosPaquetes.Convenios)
                    {

                        ObtenerFechaCotizacion(ConveniosPaquetes.configuracionEmpresa, ConveniosPaquetes, seguroEmpresa.IdAseguradora, IdEmpresa, ref cotizacionCompara);

                        switch (seguroEmpresa.IdAseguradora)
                        {
                            case 1:
                                aseguradora = "QUALITAS";
                                break;
                            case 2:
                                aseguradora = "GNP";
                                break;
                            case 3:
                                aseguradora = "ABA";
                                break;
                            case 10:
                                aseguradora = "AXA";
                                break;
                            case 4:
                                aseguradora = "ATLAS";
                                break;
                            case 25:
                                aseguradora = "INBURSA";
                                break;
                            default:
                                aseguradora = "QUALITAS";
                                break;
                        }

                        //consulta los datos de solicitud de cotizacion
                        int idConvenioRamoPaquete = ConveniosPaquetes.ConvenioRamoPaquetes.FirstOrDefault(x => x.IdConvenio == seguroEmpresa.Id).Id;

                        if (!ConveniosPaquetes.PaqueteDetalles.Exists(cobertura => cobertura.IdConvenioRamoPaquete == idConvenioRamoPaquete && cobertura.IdCatTipoPaquete == cotizacionCompara.Cobertura))
                        {//no existe el paquete cobertura
                            continue;
                        }
                        try
                        {
                            var idPaqueteConvenio = ConveniosPaquetes.PaqueteConvenio.FirstOrDefault(a => a.IdCatTipoPaquete == cotizacionCompara.Cobertura).Id;
                            cotizacionCompara.Descripcion = cotizacionCompara.Descripcion;// descs.FirstOrDefault(x => x.Item1.Equals(claveHomologadaSeleccionada)).Item2;
                            cotizacionComparaRespuesta = consultar.CotizacionCeroComision(cotizacionCompara, aseguradora, cot, seguroEmpresa.Id, RegDetalleUsuario, ConveniosPaquetes, cotizacionCompara.Cobertura, idPaqueteConvenio);
                            //cotizacionCompara.Descripcion = claveHomologadaSeleccionada;
                        }
                        catch (Exception ex)
                        {
                            log.Info("-1-CalculaCotizacion: " + ex.Message);
                        }



                    }

                    ////guarda informacion
                    IdCotizacion = GuardaCotizaciones(cotizacionComparaRespuesta, RegDetalleUsuario.Id, null, RegDetalleUsuario.NumeroMembresia ?? "");
                    if (!recotizacion)
                        GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.Cotizar, idCotizacion: IdCotizacion, EmpresaId: configuracionEmpresa.IdEmpresa);
                    cotizacionComparaRespuesta.IdCotizacion = IdCotizacion;//para recuperar los datos guardados
                    GuardaCotizacionAuto(IdCotizacion, cotizacionCompara, cot);
                    GuardaCotizacionDetalle(IdCotizacion, cotizacionComparaRespuesta);
                    //Actualizar si viene de una OT re renovacion NumeroDePoliza
                    if (!string.IsNullOrEmpty(cotizacionCompara.NumeroDePoliza))
                    {
                        ActualizaRenovacion(IdCotizacion, cotizacionCompara.NumeroDePoliza);
                    }
                }
            }

            //ViewBag.Aseguradora = aseguradora;
            //ViewBag.CatTipoPaquete = db.CatTipoPaquete.ToList();


            return cotizacionComparaRespuesta;
        }
        private void ActualizaRenovacion(int idCotizacion, string NumeroDePoliza)
        {
            OTRenovacion registro = new OTRenovacion();
            try
            {
                registro = db.OTRenovacion.FirstOrDefault(x => x.NumeroDePoliza == NumeroDePoliza && x.Estatus == 1);
                if (registro != null)
                {
                    registro.IdCotizacion = idCotizacion;
                    db.Entry(registro).State = EntityState.Modified;
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("ActualizaRenovacion: " + ex.Message);
            }
        }

        private void CombosGenerales(VEmpConvPaq ConveniosPaquetes)
        {
            try
            {
                List<int> IdsTipoPaquete = ConveniosPaquetes.PaqueteDetalles.Select(x => x.IdCatTipoPaquete).ToList().Distinct().ToList();
                ViewBag.TipoPaquete = new SelectList(db.CatTipoPaquete.Where(ctp => IdsTipoPaquete.Contains(ctp.Id) && ctp.Estatus == 1).ToList(), "Clave", "Nombre");
                //List<CustomDropDown> coberturas = new List<CustomDropDown>();
                //List<CatTipoPaquete> lista = db.CatTipoPaquete.Where(ctp => IdsTipoPaquete.Contains(ctp.Id) && ctp.Estatus == 1).ToList();
                //foreach (CatTipoPaquete itme in lista)
                //{
                //    string desc = TooltipLegend(ConveniosPaquetes.PaqueteDetalles, itme.Id);
                //    coberturas.Add(new CustomDropDown() { Value = itme.Clave, Text = itme.Nombre, Legend = desc });
                //}
                //ViewBag.TipoPaqueteLegend = coberturas;
                //

                //List<int> IdsPeriodicidadPago = ConveniosPaquetes.PeriodicidadFormaPagos.Select(x => x.IdCatPeriodicidadFormaPago).ToList().Distinct().ToList();
                //ViewBag.PeriodicidadPago = new SelectList(db.CatPeriodicidadFormaPago.Where(cpfp => IdsPeriodicidadPago.Contains(cpfp.Id) && cpfp.Estatus == 1).ToList(), "Clave", "Nombre");
                ViewBag.PeriodicidadPago = new SelectList(db.ListaCombo.SqlQuery(string.Format("sp_consultar_Periodicidad @IdEmpresa = {0}", ConveniosPaquetes.Empresa.Id)).ToList(), "Id", "Nombre");
                ViewBag.CatGenero = new SelectList(db.CatGenero.Where(x => x.Estatus == 1).ToList(), "Clave", "Nombre");



                var catUsoVehiculo = db.CatUsoVehiculo.Where(x => x.Estatus == 1).OrderBy(a => a.IdCatRamo).ToList();

                if (ConveniosPaquetes.configuracionEmpresa.CotizarTipoVehiculosConfigurados)
                {
                    catUsoVehiculo = db.CatUsoVehiculo.SqlQuery($"sp_COTIZACION_Aseguradoras_Configuradas {ConveniosPaquetes.configuracionEmpresa.IdEmpresa}").ToList();
                }

                string iduser = (User.Identity as System.Security.Claims.ClaimsIdentity).FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value;
                var _detallesUsuario = db.DetalleUsuario.Where(x => x.IdUsuario == iduser).FirstOrDefault();


                if (_detallesUsuario.IdPerfil == 3)
                {
                    var empresaRamo = db.EmpresaRamoVehiculo.Where(a => a.IdEmpresa == ConveniosPaquetes.configuracionEmpresa.IdEmpresa).ToList();

                    if (empresaRamo != null && empresaRamo.Any())
                    {
                        foreach (var ramo in empresaRamo)
                        {

                            catUsoVehiculo = catUsoVehiculo.Where(a => a.IdCatRamo != ramo.IdCatRamoVehiculo).ToList();
                        }
                    }
                }

                ViewBag.IdTipoVehiculoSelected = "-1";

                if (catUsoVehiculo.Count == 1)
                    ViewBag.IdTipoVehiculoSelected = catUsoVehiculo.First().Clave;

                //if (!ConveniosPaquetes.Convenios.Exists(a => a.IdAseguradora == 25 || a.IdAseguradora == 1))
                //	catUsoVehiculo = catUsoVehiculo.Where(a => a.Id != 13 && a.Id != 14).ToList();

                catUsoVehiculo.Add(new CatUsoVehiculo() { Id = -1, Clave = "-1", Nombre = "Seleccionar Auto" });
                ViewBag.TipoVehiculo = new SelectList(catUsoVehiculo.OrderBy(a => a.IdCatRamo), "Clave", "Nombre");

                ViewBag.IdCatGiroBase = new SelectList(db.CatGiroBase, "Id", "Nombre");
                ViewBag.IdCatEstadosRepublica_Nacimiento = new SelectList(db.CatEstadosRepublica, "Id", "Estado");

                ViewBag.IdEstado = new SelectList(db.CatEstadosRepublica, "Id", "Estado");
                ViewBag.IdAsentamiento = new SelectList(
                    new List<SelectListItem>
                    {
                new SelectListItem {Text = "Seleccione", Value = "99999"}
                    }, "Value", "Text");
            }
            catch (Exception ex)
            {

                log.Info("se genero una excepción en CombosGenerales " + ex.ToString());
            }

        }

        private string TooltipLegend(List<PaqueteDetalle> paqueteDetalles, int idPaquete)
        {
            string descripcion = string.Empty;
            int AseguradoraAnt = 0;
            int AseguradoraNext = 0;
            bool Asigna = true;
            bool titulo = true;
            for (int i = 0; i < paqueteDetalles.Count; i++)
            {

                int idCob = paqueteDetalles[i].IdCobertura;
                Cobertura itmeCobertura = db.Cobertura.FirstOrDefault(x => x.Id == idCob);
                AseguradoraNext = paqueteDetalles[i].IdConvenioRamoPaquete;
                if (i == 0)
                {
                    AseguradoraAnt = paqueteDetalles[0].IdConvenioRamoPaquete;
                }
                else
                {
                    if (Asigna)
                    {
                        AseguradoraAnt = paqueteDetalles[i - 1].IdConvenioRamoPaquete;
                    }
                }
                if (AseguradoraAnt == AseguradoraNext)
                {
                    Asigna = true;
                    if (paqueteDetalles[i].IdCatTipoPaquete == idPaquete)
                    {
                        if (itmeCobertura.Descripcion.ToUpper().IndexOf("DAÑOS MATERIALES") > -1 && paqueteDetalles[i].Deducible > 0)
                        {
                            if (titulo)
                            {
                                int idConvRamPaq = paqueteDetalles[i].IdConvenioRamoPaquete;
                                ConvenioRamoPaquete convenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(x => x.Id == idConvRamPaq);
                                LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == convenioRamoPaquete.IdConvenio);
                                titulo = false;
                                descripcion += convenio.Aseguradora.Nombre.Trim() + "\n";
                            }

                            decimal deducible = paqueteDetalles[i].Deducible / 100;
                            descripcion += "Daños Materiales " + deducible.ToString("p02") + " ";
                        }

                        if (itmeCobertura.Descripcion.ToUpper().IndexOf("ROBO TOTAL") > -1 && paqueteDetalles[i].Deducible > 0)
                        {
                            if (titulo)
                            {
                                int idConvRamPaq = paqueteDetalles[i].IdConvenioRamoPaquete;
                                ConvenioRamoPaquete convenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(x => x.Id == idConvRamPaq);
                                LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == convenioRamoPaquete.IdConvenio);
                                titulo = false;
                                descripcion += convenio.Aseguradora.Nombre.Trim() + "\n";
                            }

                            decimal deducible = paqueteDetalles[i].Deducible / 100;
                            descripcion += "Robo Total " + deducible.ToString("p02") + " ";
                        }

                    }
                }
                else
                {
                    AseguradoraAnt = AseguradoraNext;
                    Asigna = false;
                    i = i - 1;
                    descripcion += "\n";
                    titulo = true;
                }
            }
            return descripcion;
        }

        public bool IsValidEmail(string email)
        {
            string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|" + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)" + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";
            var regex = new Regex(pattern, RegexOptions.IgnoreCase);
            return regex.IsMatch(email);
        }


        public JsonResult SolicitarAprobacionCotizacion(int idCotizacionDetalle, string inicio, string fin)
        {
            var exitoso = true;
            var mensaje = "";

            try
            {
                var aprobacion = new CotizacionAprobacion();
                var cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == idCotizacionDetalle);
                var cotizacionAuto = db.CotizacionAuto.FirstOrDefault(a => a.IdCotizacion == cotizacionDetalle.IdCotizacion);
                var detalleUsuario = db.DetalleUsuario.FirstOrDefault(a => a.Id == cotizacionDetalle.Cotizacion.IdDetalleUsuario);

                if (string.IsNullOrEmpty(detalleUsuario.Correo))
                {
                    exitoso = false;
                    mensaje = "No se cuenta con email valido, ingresa a la sección de perfil y actualiza tu información";
                }

                if (exitoso)
                {
                    var datos = new VCorreoCompra();
                    var aseguradora = db.Aseguradora.FirstOrDefault(a => a.Id == cotizacionDetalle.IdAseguradora);
                    var paquete = db.CatTipoPaquete.FirstOrDefault(a => a.Clave == cotizacionDetalle.Paquete && a.OnLine);
                    var medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == cotizacionAuto.MediodePago.ToString());
                    var formaPago = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == cotizacionAuto.FormadePago);
                    var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == cotizacionDetalle.IdConvenio && a.IdCatPeriodicidadFormaPago == formaPago.Id && a.IdCatModalidadFormaPago == medioPago.Id);

                    datos.Emails = new List<string>();

                    if (!string.IsNullOrEmpty(modalidadFormaPago.Autorizadores))
                    {
                        foreach (var correo in modalidadFormaPago.Autorizadores.Split(';'))
                        {
                            if (IsValidEmail(correo))
                                datos.Emails.Add(correo);
                        }

                    }

                    if (datos.Emails.Any())
                    {
                        var cotizar = new Cotizar();

                        aprobacion.Aprobada = false;
                        aprobacion.FechaCreacion = DateTime.Now;
                        aprobacion.IdCotizacionDetalle = idCotizacionDetalle;
                        aprobacion.Identificador = Guid.NewGuid();
                        aprobacion.IdUsuario = Guid.Parse(detalleUsuario.IdUsuario);

                        db.CotizacionAprobacion.Add(aprobacion);
                        db.SaveChanges();

                        datos.NombreCompleto = detalleUsuario.ObtieneNombreCompleto();
                        datos.EmailEmpleado = detalleUsuario.Correo;
                        datos.NumeroEmpleado = detalleUsuario.IdEmpleado;
                        datos.NombreNegocio = detalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().Empresa.RazonSocial;
                        datos.NombreAseguradora = aseguradora.ClaveHomologado;
                        datos.VehiculoAsegurado = $"{cotizacionAuto.Marca} {cotizacionAuto.Agnio} {cotizacionAuto.Modelo} {cotizacionAuto.Descripcion}";
                        datos.AMIS = cotizacionDetalle.AMIS;
                        datos.Cobertura = paquete.Nombre;
                        datos.PrimaTotal = string.Concat(cotizacionDetalle.PrimaTotalAnual.ToString("C", CultureInfo.CurrentCulture), " MXN");
                        datos.MensajeMedioPago = medioPago.Nombre;
                        datos.FormaPago = formaPago.Nombre;
                        datos.FechaInicio = inicio;
                        datos.FechaFin = fin;
                        datos.URLAceptarSolicitud = Url.Action("AcceptQuoteRequest", "Account", new { code = aprobacion.Identificador }, protocol: Request.Url.Scheme);
                        datos.URLCancelarSolicitud = Url.Action("CancelQuoteRequest", "Account", new { code = aprobacion.Identificador }, protocol: Request.Url.Scheme);
                        datos.Asunto = $"Lockton One – Solicitud de Aprobación - {cotizacionAuto.Marca} {cotizacionAuto.Agnio}";

                        cotizar.EnvioCorreoSolicitudAprobacion(datos);
                    }
                    else
                    {
                        exitoso = false;
                        mensaje = "Correos de autorizadores no configurados. Contacta a tu Administrador";
                    }

                }


            }
            catch (Exception ex)
            {
                exitoso = false;
                mensaje = $"Ocurrio un error: {ex.Message}";
            }

            return Json(new { Exitoso = exitoso, Mensaje = mensaje }, JsonRequestBehavior.AllowGet);

        }



        public JsonResult paquelist(int aniomayor, int idTipoVehiculo)
        {
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            var vehiculo = db.CatRamoVehiculo.Where(x => x.Clave == idTipoVehiculo.ToString()).FirstOrDefault();
            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa);
            List<int> IdsTipoPaquete = ConveniosPaquetes.PaqueteConvenio.Where(a => a.IdCatRamoVehiculo == vehiculo.IdCatRamo).Select(x => x.IdCatTipoPaquete).ToList().Distinct().ToList();
            var isInbursa = ConveniosPaquetes.Convenios.Where(a => a.IdAseguradora == 25).Any();
            //if (aniomayor >= 15 && isInbursa)
            //{
            //    List<CatTipoPaquete> TipoPaqueteAmpliaLimit = db.CatTipoPaquete.Where(x => IdsTipoPaquete.Contains(x.Id) && x.Estatus == 1 && ((x.Nombre == "Amplia" && x.OnLine == false) || (x.Nombre == "Limitada" && x.OnLine == false))).ToList();
            //    return Json(TipoPaqueteAmpliaLimit, JsonRequestBehavior.AllowGet);
            //}
            //else 
            if (isInbursa)
            {
                List<CatTipoPaquete> TipoPaqueteAmpliaLimit = db.CatTipoPaquete.Where(x => IdsTipoPaquete.Contains(x.Id) && x.Estatus == 1 && x.OnLine).ToList();
                if (aniomayor > 15)
                    TipoPaqueteAmpliaLimit = TipoPaqueteAmpliaLimit.Where(a => a.Id != 5).ToList();//No Totales (Amplia Elid)
                if (TipoPaqueteAmpliaLimit != null)
                    TipoPaqueteAmpliaLimit = TipoPaqueteAmpliaLimit.OrderBy(x => x.Posicion).ToList();
                return Json(TipoPaqueteAmpliaLimit, JsonRequestBehavior.AllowGet);
            }
            else
            {
                List<CatTipoPaquete> TipoPaqueteAmpliaLimit = db.CatTipoPaquete.Where(x => IdsTipoPaquete.Contains(x.Id) && x.Estatus == 1).ToList();
                TipoPaqueteAmpliaLimit = TipoPaqueteAmpliaLimit.OrderBy(x => x.Posicion).ToList();
                return Json(TipoPaqueteAmpliaLimit, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult paquelistTest(int aniomayor, int idConvenio)
        {
            LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(convenio.IdEmpresa, idConvenio);

            List<int> IdsTipoPaquete = ConveniosPaquetes.PaqueteDetalles.Select(x => x.IdCatTipoPaquete).ToList().Distinct().ToList();
            if (aniomayor >= 15 && convenio.IdAseguradora == 25)
            {
                List<CatTipoPaquete> TipoPaqueteAmpliaLimit = db.CatTipoPaquete.Where(x => IdsTipoPaquete.Contains(x.Id) && x.Estatus == 1 && ((x.Nombre == "Amplia" && x.OnLine == false) || (x.Nombre == "Limitada" && x.OnLine == false))).ToList();
                return Json(TipoPaqueteAmpliaLimit, JsonRequestBehavior.AllowGet);
            }
            else
            {
                List<CatTipoPaquete> TipoPaqueteAmpliaLimit = db.CatTipoPaquete.Where(x => IdsTipoPaquete.Contains(x.Id) && x.Estatus == 1).ToList();
                return Json(TipoPaqueteAmpliaLimit, JsonRequestBehavior.AllowGet);
            }

        }

        public JsonResult paquelistCotizacionTest(int aniomayor, int idConvenio, int idTipoVehiculo)
        {
            LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(convenio.IdEmpresa, idConvenio);
            var vehiculo = db.CatRamoVehiculo.Where(x => x.Clave == idTipoVehiculo.ToString()).FirstOrDefault();
            var list = new List<ListaGenerica>();
            foreach (var paquete in ConveniosPaquetes.PaqueteConvenio.Where(a => a.IdCatRamoVehiculo == vehiculo.IdCatRamo))
                list.Add(new ListaGenerica() { Id = paquete.Id, Nombre = paquete.NombrePaquete });
            return Json(list, JsonRequestBehavior.AllowGet);

        }

        public JsonResult paquelistAseguradora(int aniomayor, int idAseguradora)
        {
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.IdEmpresa == IdEmpresa && a.IdAseguradora == idAseguradora && a.Estatus == 1);
            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(convenio.IdEmpresa, convenio.Id);

            List<int> IdsTipoPaquete = ConveniosPaquetes.PaqueteDetalles.Select(x => x.IdCatTipoPaquete).ToList().Distinct().ToList();
            if (aniomayor >= 15 && convenio.IdAseguradora == 25)
            {
                List<CatTipoPaquete> TipoPaqueteAmpliaLimit = db.CatTipoPaquete.Where(x => IdsTipoPaquete.Contains(x.Id) && x.Estatus == 1 && ((x.Nombre == "Amplia" && x.OnLine == false) || (x.Nombre == "Limitada" && x.OnLine == false))).ToList();
                return Json(TipoPaqueteAmpliaLimit, JsonRequestBehavior.AllowGet);
            }
            else
            {
                List<CatTipoPaquete> TipoPaqueteAmpliaLimit = db.CatTipoPaquete.Where(x => IdsTipoPaquete.Contains(x.Id) && x.Estatus == 1).ToList();
                return Json(TipoPaqueteAmpliaLimit, JsonRequestBehavior.AllowGet);
            }

        }

        public JsonResult paquelistConvenio(int aniomayor, int idConvenio)
        {
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            int IdEmpresa = (int)RegDetalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(convenio.IdEmpresa, convenio.Id);

            List<int> IdsTipoPaquete = ConveniosPaquetes.PaqueteDetalles.Select(x => x.IdCatTipoPaquete).ToList().Distinct().ToList();
            List<int> IdsFormaPAgo = ConveniosPaquetes.PeriodicidadFormaPagos.Select(a => a.IdCatPeriodicidadFormaPago).Distinct().ToList();
            List<CatTipoPaquete> TipoPaqueteAmpliaLimit = db.CatTipoPaquete.Where(x => IdsTipoPaquete.Contains(x.Id) && x.Estatus == 1).ToList();
            var FormaPago = new SelectList(db.CatPeriodicidadFormaPago.Where(cpfp => IdsFormaPAgo.Contains(cpfp.Id) && cpfp.Estatus == 1).ToList(), "Clave", "Nombre");
            //List<CatPeriodicidadFormaPago> FormaPago = db.CatPeriodicidadFormaPago.Where(a => IdsFormaPAgo.Contains(a.Id)).ToList();
            return Json(new { Paquetes = TipoPaqueteAmpliaLimit, IdAseguradora = convenio.IdAseguradora, FormasPago = FormaPago }, JsonRequestBehavior.AllowGet);


        }

        public JsonResult ExisteClaveAseguradora(string aseguradora, string amis, int year)
        {
            bool existe = false;
            var clave = db.ExecuteScalarScript($"spConsultaDetalleVehiculo '{amis}','{aseguradora}',{year}");

            existe = !string.IsNullOrEmpty(clave);

            return Json(new { Existe = existe }, JsonRequestBehavior.AllowGet);


        }



        public int GuardaCotizaciones(CotizacionCompara DatosCotizacionCompara, int IdUsuario, int? idDocto, string membresia)
        {
            Cotizacion DatosCotizacion = new Cotizacion();
            try
            {
                //DatosCotizacion.IdAseguradora = DatosConvenio.IdAseguradora;
                //DatosCotizacion.IdCotizacionDetalle = 0;//Queryable campo es?
                //DatosCotizacion.IdConvenio = DatosConvenio.Id;
                DatosCotizacion.IdPeriodicidadPago = DatosCotizacionCompara.FormadePago; //ver si lleva la clave de forma de pago
                DatosCotizacion.IdDetalleUsuario = IdUsuario;//id del usuario logueado
                DatosCotizacion.IdTitular = 0;//no lleva
                DatosCotizacion.Estatus = 1; //activo
                DatosCotizacion.IdProcesoMasivo = 0;//no se ocupa
                DatosCotizacion.IdVehiculo = 0;//no se ocupa
                DatosCotizacion.FechaHora = DateTime.Now;
                DatosCotizacion.ValorFactura = DatosCotizacionCompara.MontoFactura;
                DatosCotizacion.FechaFactura = DatosCotizacionCompara.FechaFactura;
                DatosCotizacion.NumeroFactura = DatosCotizacionCompara.NumeroFactura;//no se solicita el numero de factura
                DatosCotizacion.ValorDeclarado = DatosCotizacionCompara.MontoDeclarado;
                DatosCotizacion.SumaLegalizado = 0;
                DatosCotizacion.CodigoPostal = DatosCotizacionCompara.CodigoPostal;
                DatosCotizacion.FechaNacimiento = DatosCotizacionCompara.FechaNacimiento;
                if (!string.IsNullOrEmpty(DatosCotizacionCompara.Edad))
                    DatosCotizacion.Edad = Convert.ToInt16(DatosCotizacionCompara.Edad);
                else if (!string.IsNullOrEmpty(DatosCotizacionCompara.FechaNacimiento.ToString()))
                {
                    Utilidades.CalculaEdad(Convert.ToDateTime(DatosCotizacionCompara.FechaNacimiento));
                }
                if (!string.IsNullOrEmpty(DatosCotizacionCompara.Genero))
                    DatosCotizacion.IdCatGenero = db.CatGenero.Where(x => x.Clave.Equals(DatosCotizacionCompara.Genero)).FirstOrDefault().Id;

                var userIdCotiza = User.Identity.GetUserId();
                var userCotiza = db.DetalleUsuario.FirstOrDefault(a => a.IdUsuario == userIdCotiza);

                DatosCotizacion.IdUsuarioCotiza = userCotiza.Id;
                DatosCotizacion.UserNameCotiza = User.Identity.Name;
                DatosCotizacion.IdUso = DatosCotizacionCompara.IdUso;
                DatosCotizacion.EmisionPersonaMoral = DatosCotizacionCompara.EmisionPersonaMoral;
                DatosCotizacion.Membresia = membresia;
                DatosCotizacion.IdDocto = idDocto;

                DatosCotizacion.Acepto_AvisoPrivacidad_Lockton = true;
                DatosCotizacion.Acepto_TerminosCondiciones_Lockton = true;

                DatosCotizacion.esRenovacionComparativo = DatosCotizacionCompara.esRenovacionComparativo;
                DatosCotizacion.DomicilioFiscal = DatosCotizacionCompara.DomicilioFiscalComparativo;
                DatosCotizacion.Contratante = DatosCotizacionCompara.ContratanteComparativo;

                db.Cotizacion.Add(DatosCotizacion);
                db.SaveChanges();



            }
            catch (Exception ex)
            {
                log.Info("GuardaCotizaciones: " + ex.Message);
            }

            return DatosCotizacion.Id;
        }

        public int GuardaCotizacionesMasivo(CotizacionCompara DatosCotizacionCompara, int IdUsuario, int? idDocto, string membresia)
        {
            Cotizacion DatosCotizacion = new Cotizacion();
            try
            {
                //DatosCotizacion.IdAseguradora = DatosConvenio.IdAseguradora;
                //DatosCotizacion.IdCotizacionDetalle = 0;//Queryable campo es?
                //DatosCotizacion.IdConvenio = DatosConvenio.Id;
                DatosCotizacion.IdPeriodicidadPago = DatosCotizacionCompara.FormadePago; //ver si lleva la clave de forma de pago
                DatosCotizacion.IdDetalleUsuario = IdUsuario;//id del usuario logueado
                DatosCotizacion.IdTitular = 0;//no lleva
                DatosCotizacion.Estatus = 1; //activo
                DatosCotizacion.IdProcesoMasivo = 0;//no se ocupa
                DatosCotizacion.IdVehiculo = 0;//no se ocupa
                DatosCotizacion.FechaHora = DateTime.Now;
                DatosCotizacion.ValorFactura = DatosCotizacionCompara.MontoFactura;
                DatosCotizacion.FechaFactura = DatosCotizacionCompara.FechaFactura;
                DatosCotizacion.NumeroFactura = DatosCotizacionCompara.NumeroFactura;//no se solicita el numero de factura
                DatosCotizacion.ValorDeclarado = DatosCotizacionCompara.MontoDeclarado;
                DatosCotizacion.SumaLegalizado = 0;
                DatosCotizacion.CodigoPostal = DatosCotizacionCompara.CodigoPostal;
                DatosCotizacion.FechaNacimiento = DatosCotizacionCompara.FechaNacimiento;
                if (!string.IsNullOrEmpty(DatosCotizacionCompara.Edad))
                    DatosCotizacion.Edad = Convert.ToInt16(DatosCotizacionCompara.Edad);
                if (!string.IsNullOrEmpty(DatosCotizacionCompara.Genero))
                    DatosCotizacion.IdCatGenero = db.CatGenero.Where(x => x.Clave.Equals(DatosCotizacionCompara.Genero)).FirstOrDefault().Id;


                DatosCotizacion.IdUsuarioCotiza = IdUsuario;
                DatosCotizacion.UserNameCotiza = "";
                DatosCotizacion.IdUso = DatosCotizacionCompara.IdUso;
                DatosCotizacion.EmisionPersonaMoral = DatosCotizacionCompara.EmisionPersonaMoral;
                DatosCotizacion.Membresia = membresia;
                DatosCotizacion.IdDocto = idDocto;

                DatosCotizacion.Acepto_AvisoPrivacidad_Lockton = true;
                DatosCotizacion.Acepto_TerminosCondiciones_Lockton = true;

                db.Cotizacion.Add(DatosCotizacion);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Info("GuardaCotizaciones: " + ex.Message);
            }

            return DatosCotizacion.Id;
        }
        private int GuardaCotizacionSinRegistro(RegistroUsuario cotizacionSinRegistro, int idCotizacion, int idProducto)
        {
            log.Info("GuardaCotizaciones registro de Cotizacion sin registro");
            CotizacionSinRegistro cotizacion = new CotizacionSinRegistro();
            try
            {
                cotizacion.IdCotizacion = idCotizacion;
                cotizacion.Nombre = cotizacionSinRegistro.Nombre;
                cotizacion.Nombre2 = cotizacionSinRegistro.Nombre2;
                cotizacion.ApPaterno = cotizacionSinRegistro.ApPaterno;
                cotizacion.ApMaterno = cotizacionSinRegistro.ApMaterno;
                cotizacion.Correo = cotizacionSinRegistro.Correo;
                cotizacion.Celular = cotizacionSinRegistro.Celular;
                cotizacion.IdProducto = idProducto;
                cotizacion.NombreEmpresaUSR = cotizacionSinRegistro.NombreEmpresaUSR != null ? cotizacionSinRegistro.NombreEmpresaUSR : "";
                db.CotizacionSinRegistro.Add(cotizacion);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Info("GuardaCotizacionSinRegistro: " + ex.Message);
            }

            return cotizacion.Id;
        }
        public void GuardaCotizacionAuto(int IdCotizacion, CotizacionCompara DatosCotizacionCompara, mDetalles cot)
        {
            log.Info("GuardaCotizacionAuto registro de Cotizacion auto");
            CotizacionAuto DatosCotizacionAuto = new CotizacionAuto();
            string amis = string.Empty;
            try
            {
                DatosCotizacionAuto.IdCotizacion = IdCotizacion;
                DatosCotizacionAuto.TipoVehiculo = DatosCotizacionCompara.TipoVehiculo;
                DatosCotizacionAuto.Marca = DatosCotizacionCompara.Marca;
                DatosCotizacionAuto.Agnio = DatosCotizacionCompara.Año;
                DatosCotizacionAuto.Modelo = DatosCotizacionCompara.Modelo;
                DatosCotizacionAuto.Version = DatosCotizacionCompara.Version;
                DatosCotizacionAuto.Descripcion = DatosCotizacionCompara.Descripcion;
                DatosCotizacionAuto.ValorFactura = DatosCotizacionCompara.ValorFactura;
                DatosCotizacionAuto.FechaFactura = DatosCotizacionCompara.FechaFactura;
                DatosCotizacionAuto.MontoFactura = DatosCotizacionCompara.MontoFactura;
                DatosCotizacionAuto.Cobertura = DatosCotizacionCompara.Cobertura;
                DatosCotizacionAuto.FormadePago = DatosCotizacionCompara.FormadePago;
                DatosCotizacionAuto.MediodePago = DatosCotizacionCompara.MediodePago;
                DatosCotizacionAuto.AvisoPrivacidad = true;
                DatosCotizacionAuto.TerminosCondiciones = true;
                DatosCotizacionAuto.FechaAvisoTerminos = DateTime.Now;
                if (cot != null && cot.Catalogo.Exists(x => x.Marca == DatosCotizacionCompara.Marca && x.Modelo == DatosCotizacionCompara.Modelo))
                {
                    amis = cot.Catalogo.FirstOrDefault(x => x.Marca == DatosCotizacionCompara.Marca && x.Modelo == DatosCotizacionCompara.Modelo).CatDescripciones.FirstOrDefault().clave;

                    DatosCotizacionAuto.Descripcion = cot.Catalogo.FirstOrDefault(x => x.Marca == DatosCotizacionCompara.Marca && x.Modelo == DatosCotizacionCompara.Modelo).CatDescripciones.FirstOrDefault().Descripcion;
                }
                DatosCotizacionAuto.Amis = amis;

                DatosCotizacionAuto.Serie = DatosCotizacionCompara.SerieComparativo;

                db.CotizacionAuto.Add(DatosCotizacionAuto);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Info("GuardaCotizacionAuto: " + ex.Message);
            }
        }
        public bool GuardaCotizacionDetalle(int IdCotizacion, CotizacionCompara DatosCotizacionCompara)
        {
            var agrego = false;
            CotizacionDetalle DatosCotizacionDetalle = new CotizacionDetalle();
            try
            {
                if (DatosCotizacionCompara.Comparar.Count > 0)
                {
                    DatosCotizacionCompara.Comparar.ForEach(cotizacion =>
                    {
                        if (string.IsNullOrEmpty(cotizacion.ErrorXML))
                        {
                            int idTipoVehiculo = 0;
                            DatosCotizacionDetalle = new CotizacionDetalle();
                            DatosCotizacionDetalle.XMLSolicitud = cotizacion.XmlEmision;
                            DatosCotizacionDetalle.XMLRecepcion = cotizacion.XmlRespuesta;
                            DatosCotizacionDetalle.FechaSolicitud = DateTime.Now;
                            DatosCotizacionDetalle.IdCotizacion = IdCotizacion;
                            DatosCotizacionDetalle.Estatus = 1;//activo

                            if (int.TryParse(DatosCotizacionCompara.TipoVehiculo, out idTipoVehiculo))
                                DatosCotizacionDetalle.IdVehiculo = idTipoVehiculo;
                            else
                                DatosCotizacionDetalle.IdVehiculo = 1;

                            DatosCotizacionDetalle.IdEnrollment = 0;
                            DatosCotizacionDetalle.Periodicidad = "";
                            DatosCotizacionDetalle.Paquete = cotizacion.Cobertura.ToString();
                            DatosCotizacionDetalle.ClaveCotizacion = string.IsNullOrEmpty(cotizacion.CotizacionClave) ? "" : cotizacion.CotizacionClave;
                            DatosCotizacionDetalle.ClaveVersion = string.IsNullOrEmpty(cotizacion.VersionClave) ? "" : cotizacion.VersionClave;
                            DatosCotizacionDetalle.ClaveIncisoCot = string.IsNullOrEmpty(cotizacion.IncisoCotizacionClave) ? "" : cotizacion.IncisoCotizacionClave;
                            DatosCotizacionDetalle.ClaveIncisoVer = string.IsNullOrEmpty(cotizacion.IncisoVersionClave) ? "" : cotizacion.IncisoVersionClave;
                            DatosCotizacionDetalle.PrimaTotalAnual = decimal.Parse(cotizacion.PrimaTotal);
                            DatosCotizacionDetalle.IdAseguradora = cotizacion.IdAseguradora;
                            DatosCotizacionDetalle.IdConvenio = cotizacion.IdConvenio;
                            DatosCotizacionDetalle.IdPaqueteConvenio = cotizacion.IdPaqueteConvenio;
                            DatosCotizacionDetalle.AMIS = ObtenerAMIS(DatosCotizacionCompara.ClaveHomologadaSeleccionada, cotizacion.IdAseguradora);
                            DatosCotizacionDetalle.CotizacionCero = DatosCotizacionCompara.CotizacionCero;
                            DatosCotizacionDetalle.IdFormaPago = cotizacion.IdFormaPago;
                            DatosCotizacionDetalle.IdMedioPago = cotizacion.IdMedioPago;
                            DatosCotizacionDetalle.FechaCotizacion = cotizacion.FechaCotizacion;
                            DatosCotizacionDetalle.IdCatPeriodicidadMultianual = DatosCotizacionCompara.IdCatPeriodicidadMultianual;
                            db.CotizacionDetalle.Add(DatosCotizacionDetalle);
                            db.SaveChanges();
                            //para llevar el id de la corizacion detalle
                            cotizacion.IdCotizacionDetalle = DatosCotizacionDetalle.Id;
                            agrego = true;
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                log.Info("GuardaCotizacionDetalle: " + ex.Message);
            }
            return agrego;
        }

        private int GuardaCotizacionDetalleCompra(int IdCotizacion, CotizacionCompara DatosCotizacionCompara)
        {
            CotizacionDetalle DatosCotizacionDetalle = new CotizacionDetalle();
            try
            {
                if (DatosCotizacionCompara.Comparar.Count > 0)
                {
                    DatosCotizacionCompara.Comparar.ForEach(cotizacion =>
                    {
                        if (string.IsNullOrEmpty(cotizacion.ErrorXML))
                        {
                            int idTipoVehiculo = 0;
                            DatosCotizacionDetalle = new CotizacionDetalle();
                            DatosCotizacionDetalle.XMLSolicitud = cotizacion.XmlEmision;
                            DatosCotizacionDetalle.XMLRecepcion = cotizacion.XmlRespuesta;
                            DatosCotizacionDetalle.FechaSolicitud = DateTime.Now;
                            DatosCotizacionDetalle.IdCotizacion = IdCotizacion;
                            DatosCotizacionDetalle.Estatus = 1;//activo
                            if (int.TryParse(DatosCotizacionCompara.TipoVehiculo, out idTipoVehiculo))
                                DatosCotizacionDetalle.IdVehiculo = idTipoVehiculo;
                            else
                                DatosCotizacionDetalle.IdVehiculo = 1;
                            DatosCotizacionDetalle.IdEnrollment = 0;
                            DatosCotizacionDetalle.Periodicidad = "";
                            DatosCotizacionDetalle.Paquete = cotizacion.Cobertura.ToString();
                            DatosCotizacionDetalle.ClaveCotizacion = string.IsNullOrEmpty(cotizacion.CotizacionClave) ? "" : cotizacion.CotizacionClave;
                            DatosCotizacionDetalle.ClaveVersion = string.IsNullOrEmpty(cotizacion.VersionClave) ? "" : cotizacion.VersionClave;
                            DatosCotizacionDetalle.ClaveIncisoCot = string.IsNullOrEmpty(cotizacion.IncisoCotizacionClave) ? "" : cotizacion.IncisoCotizacionClave;
                            DatosCotizacionDetalle.ClaveIncisoVer = string.IsNullOrEmpty(cotizacion.IncisoVersionClave) ? "" : cotizacion.IncisoVersionClave;
                            DatosCotizacionDetalle.PrimaTotalAnual = decimal.Parse(cotizacion.PrimaTotal);
                            DatosCotizacionDetalle.IdAseguradora = cotizacion.IdAseguradora;
                            DatosCotizacionDetalle.IdConvenio = cotizacion.IdConvenio;
                            DatosCotizacionDetalle.IdPaqueteConvenio = cotizacion.IdPaqueteConvenio;
                            DatosCotizacionDetalle.AMIS = DatosCotizacionCompara.ClaveAMIS;
                            DatosCotizacionDetalle.CotizacionCero = DatosCotizacionCompara.CotizacionCero;
                            DatosCotizacionDetalle.IdFormaPago = cotizacion.IdFormaPago;
                            DatosCotizacionDetalle.IdMedioPago = cotizacion.IdMedioPago;
                            DatosCotizacionDetalle.FechaCotizacion = cotizacion.FechaCotizacion;
                            db.CotizacionDetalle.Add(DatosCotizacionDetalle);
                            db.SaveChanges();
                            //para llevar el id de la corizacion detalle
                            cotizacion.IdCotizacionDetalle = DatosCotizacionDetalle.Id;
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                log.Info("GuardaCotizacionDetalle: " + ex.Message);
            }
            return DatosCotizacionDetalle.Id;
        }

        public ActionResult GenerarComparativo(int IdCotizacion, int Cobertura = 0, bool idOrdenamiento = true, bool valorFactura = false)
        {
            log.Info("GenerarComparativo inicio generacion de pdf comparativo");
            Cotizar consultar = new Cotizar();
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);

            string RutaPDF = string.Empty;
            try
            {

                RutaPDF = consultar.GenerarComparativo(IdCotizacion, Cobertura, RegDetalleUsuario, db, idOrdenamiento, valorFactura);


                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.ComparativoPDF, idCotizacion: IdCotizacion);
            }
            catch (Exception ex)
            {
                log.Info("GenerarComparativo: " + ex.Message);
            }

            return Json(new { rutaPDF = RutaPDF });
        }

        public ActionResult GenerarComparativoEspecial(int IdCotizacion, int Cobertura = 0, bool idOrdenamiento = true, bool valorFactura = false)
        {
            log.Info("GenerarComparativo inicio generacion de pdf comparativo");
            Cotizar consultar = new Cotizar();
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);

            string RutaPDF = string.Empty;
            try
            {

                RutaPDF = consultar.GenerarComparativoEspecial(IdCotizacion, RegDetalleUsuario, db);

                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.ComparativoPDF, idCotizacion: IdCotizacion);
            }
            catch (Exception ex)
            {
                log.Info("GenerarComparativo: " + ex.Message);
            }

            return Json(new { rutaPDF = RutaPDF });
        }

        #endregion

        #region 3 Informacion

        public ActionResult CotizacionInformacion(int IdCotizacion, string Aseguradora, bool emisionPersonaMoral = false)
        {


            CotizacionDetalle cotizacion = null;
            try
            {
                cotizacion = db.CotizacionDetalle.Find(IdCotizacion);
            }
            catch
            {
                if (cotizacion == null && Debugger.IsAttached)
                {
                    cotizacion = new CotizacionDetalle();
                    cotizacion.XMLRecepcion = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Movimientos><Movimiento TipoMovimiento=\"2\" NoNegocio=\"5041\" NoPoliza=\"\" NoCotizacion=\"0296810865\" NoEndoso=\"\" TipoEndoso=\"21\" NoOTra=\"434965565P\"><DatosAsegurado NoAsegurado=\"\"><Nombre>EMILIO CONTRERAS VILCHIS</Nombre><Direccion>AV SAN FRANCISCO DE LOS ROMO 401 INT NULL, PARQUE INDUSTRIAL SAN FRANCISCO, AGUASCALIENTES, NULL, CP 20304</Direccion><Colonia>PARQUE INDUSTRIAL SAN FRANCISCO</Colonia><Poblacion>AV SAN FRANCISCO DE LOS ROMO</Poblacion><Estado>1</Estado><CodigoPostal>20304</CodigoPostal><NoEmpleado /><Agrupador /></DatosAsegurado><DatosVehiculo NoInciso=\"0001\"><ClaveAmis>03973</ClaveAmis><Modelo>2018</Modelo><DescripcionVehiculo>AUT 4CIL 5PAS 4PTAS QC NAVI 2.4L</DescripcionVehiculo><Uso>1</Uso><Servicio>1</Servicio><Paquete>1</Paquete><Motor /><Serie /><Coberturas NoCobertura=\"1\"><SumaAsegurada>431000</SumaAsegurada><TipoSuma>2</TipoSuma><Deducible>0005</Deducible><Prima>7316.49</Prima></Coberturas><Coberturas NoCobertura=\"3\"><SumaAsegurada>431000</SumaAsegurada><TipoSuma>2</TipoSuma><Deducible>00010</Deducible><Prima>1953.37</Prima></Coberturas><Coberturas NoCobertura=\"4\"><SumaAsegurada>2000000</SumaAsegurada><TipoSuma>2</TipoSuma><Deducible>0000</Deducible><Prima>1617.94</Prima></Coberturas><Coberturas NoCobertura=\"5\"><SumaAsegurada>80000</SumaAsegurada><TipoSuma>2</TipoSuma><Deducible>0</Deducible><Prima>329.3</Prima></Coberturas><Coberturas NoCobertura=\"7\"><SumaAsegurada>3000000</SumaAsegurada><TipoSuma>2</TipoSuma><Deducible>0</Deducible><Prima>400</Prima></Coberturas><Coberturas NoCobertura=\"11\"><SumaAsegurada>2000000</SumaAsegurada><TipoSuma>2</TipoSuma><Deducible>0</Deducible><Prima>291.57</Prima></Coberturas><Coberturas NoCobertura=\"14\"><SumaAsegurada>8560</SumaAsegurada><TipoSuma>2</TipoSuma><Deducible>0</Deducible><Prima>370</Prima></Coberturas><Coberturas NoCobertura=\"34\"><SumaAsegurada>1200000</SumaAsegurada><TipoSuma>3</TipoSuma><Deducible /><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"47\"><SumaAsegurada>3000000</SumaAsegurada><TipoSuma>14</TipoSuma><Deducible>0</Deducible><Prima>174.72</Prima></Coberturas><ConsideracionesAdicionalesDV NoConsideracion=\"0\"><TipoRegla>0</TipoRegla><ValorRegla /></ConsideracionesAdicionalesDV></DatosVehiculo><DatosGenerales><FechaEmision>2019-01-29</FechaEmision><FechaInicio>2019-01-29</FechaInicio><FechaTermino>2020-01-29</FechaTermino><Moneda>0</Moneda><Agente>72803</Agente><FormaPago>C</FormaPago><TarifaValores>1812</TarifaValores><TarifaCuotas>1812</TarifaCuotas><TarifaDerechos>1812</TarifaDerechos><Plazo /><Agencia /><Contrato /><PorcentajeDescuento>48.85</PorcentajeDescuento><ConsideracionesAdicionalesDG NoConsideracion=\"4\"><TipoRegla>1</TipoRegla><ValorRegla>0</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"1\"><TipoRegla>1</TipoRegla><ValorRegla>4</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"31\"><TipoRegla>1</TipoRegla><ValorRegla /></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"13\"><TipoRegla>1</TipoRegla><ValorRegla>S</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"56\"><TipoRegla /><ValorRegla /></ConsideracionesAdicionalesDG></DatosGenerales><Primas><PrimaNeta>6550.65</PrimaNeta><Derecho>500</Derecho><Recargo>0</Recargo><Impuesto>1128.1</Impuesto><PrimaTotal>8178.75</PrimaTotal><Comision>8</Comision></Primas><Recibos NoRecibo=\"1\"><FechaInicio>2019-01-29</FechaInicio><FechaTermino>2020-01-29</FechaTermino><PrimaNeta>6550.65</PrimaNeta><Derecho>500</Derecho><Recargo>0</Recargo><Impuesto>1128.1</Impuesto><PrimaTotal>8178.75</PrimaTotal><Comision>524.05</Comision></Recibos><CodigoError /></Movimiento></Movimientos>";
                }
            }

            //log.Info("Genera el XmlDocument de la cotización seleccionada.");

            var _cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacion.IdCotizacion);
            CotizacionAuto cotizacionauto = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion));
            //Aseguradora aseguradora = db.Aseguradora.Where(x => x.Nombre.Contains(Aseguradora) && x.Estatus.Equals(1)).FirstOrDefault();
            Aseguradora aseguradora = db.Aseguradora.Where(x => x.Id == cotizacion.IdAseguradora && x.Estatus.Equals(1)).FirstOrDefault();
            LocktonModel.db.Convenio convenio = db.Convenio.Find(cotizacion.IdConvenio);
            Empresa empresa = db.Empresa.Find(convenio.IdEmpresa);
            var empresaDeloites = db.CatDeloitte.Select(a => a.IdEmpresa).ToList();
            ConfiguracionEmpresa Configuracion = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == empresa.Id).FirstOrDefault();
            var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == cotizacion.IdPaqueteConvenio);

            string iduser = (User.Identity as System.Security.Claims.ClaimsIdentity).FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value;
            var _detallesUsuario = db.DetalleUsuario.Where(x => x.IdUsuario == iduser).FirstOrDefault();
            if (!Configuracion.MostrarBotonCotizar)
            {
                if (_detallesUsuario.IdPerfil == 3)
                    return RedirectToAction("Index", "Home");
            }


            CatUsoVehiculo catusovehiculo = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == cotizacionauto.TipoVehiculo);


            int idPaquete = Convert.ToInt32(cotizacion.Paquete);
            string paqueteCotizacion = db.CatTipoPaquete.Where(x => x.Id == idPaquete).FirstOrDefault().Nombre;
            CatPeriodicidadFormaPago periodicidad = db.CatPeriodicidadFormaPago.FirstOrDefault(x => x.Id.Equals(cotizacionauto.FormadePago));
            string FormaPago = periodicidad.Nombre;
            int medioPago = cotizacionauto.MediodePago;
            CatModalidadFormaPago _medioPago = db.CatModalidadFormaPago.FirstOrDefault(x => x.Clave.Equals(medioPago.ToString()));
            string medioPa = (medioPago.Equals(0) || medioPago.Equals(1)) ? "Tarjeta" : _medioPago.Nombre;
            //CatTipoContratante _tipoContratante = db.CatTipoContratante.FirstOrDefault(x => x.IdCatTipoContratante.Equals(convenio.IdCatTipoContratante));

            InformacionEmision InfoEmision = new InformacionEmision();
            InfoEmision.Convenio = convenio;
            InfoEmision.MensajeDatosBancarios = string.Empty;
            InfoEmision.ValidaMembresia = Configuracion.ValidaMembresiaCostco;

            InfoEmision.BloqueoNumeroTarjeta = Configuracion.BloqueoNumeroTarjeta;
            InfoEmision.EsFlotilla = Configuracion.IdTipoDeNegocio == 1 || Configuracion.IdTipoDeNegocio == 4;

            var _modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenio.Id && a.IdCatPeriodicidadFormaPago == periodicidad.Id && a.IdCatModalidadFormaPago == _medioPago.Id);

            InfoEmision.EsFacturable = _modalidadFormaPago.Facturable;
            ViewBag.ConYSinDatosBancarios = false;
            ViewBag.SoloCondatosBancarios = false;
            ViewBag.SoloSinDatosBancarios = false;
            if (User.IsInRole("Emisión Con Datos Bancarios") && User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                InfoEmision.EmisionConDatosBancarios = _modalidadFormaPago.SinDatosBancarios;
                ViewBag.ConYSinDatosBancarios = true;
            }
            if (User.IsInRole("Emisión Con Datos Bancarios") && !User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                ViewBag.SoloCondatosBancarios = true;
            }
            if (!User.IsInRole("Emisión Con Datos Bancarios") && User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                ViewBag.SoloSinDatosBancarios = true;
            }

            //else if (_detallesUsuario.IdPerfil == 3)
            //{
            //    InfoEmision.EmisionConDatosBancarios = true;
            //}
            ViewBag.UsuarioFinal = (_detallesUsuario.IdPerfil == 3) ? true : false;
            //if ((aseguradora.Id == 1 || aseguradora.Id == 2 || aseguradora.Id == 5 || aseguradora.Id == 10) && _tipoContratante.IdCatTipoContratante.Equals(2) && Configuracion.IdTipoDeNegocio == 4)
            //{
            //    InfoEmision.EsFlotilla = _tipoContratante.IdCatTipoContratante.Equals(4) ? false : true;
            //    InfoEmision.EsFlotilla = _tipoContratante.IdCatTipoContratante.Equals(2) ? false : InfoEmision.EsFlotilla;
            //}
            //else
            //{
            //    InfoEmision.EsFlotilla = Configuracion.IdTipoDeNegocio == 1 || Configuracion.IdTipoDeNegocio == 4 || Configuracion.IdTipoDeNegocio == 5;
            //}

            if (Configuracion.MostrarMensajeBancario)
            {
                var mensaje = Configuracion.MensajeBancario; //Utilidades.ObtienerValorParametro("Mensaje_Datos_Bancarios_Emision");
                InfoEmision.MensajeDatosBancarios = mensaje;
            }







            //log.Info("Crea el objeto InformacionEmision para contener los datos del formulario así como colocar sus datos precargados.");

            InfoEmision.IdTipoDeNegocio = Configuracion.IdTipoDeNegocio.Value;
            InfoEmision.IdTipoContratante = convenio.IdCatTipoContratante ?? 0;
            InfoEmision.IdCotizacion = IdCotizacion;
            InfoEmision.Cotizacion = _cotizacion;
            //InfoEmision.EmisionPersonaMoral = _cotizacion.EmisionPersonaMoral;
            InfoEmision.Aseguradora = Aseguradora;
            InfoEmision.Empresa = empresa;
            InfoEmision.EmpresaDeloitte = empresaDeloites.Contains(empresa.Id);
            InfoEmision.EsPersonaPoliticamenteExpuesta = false;
            InfoEmision.EsBeneficiarioPreferente = convenio.optIncluyeBP.HasValue ? convenio.optIncluyeBP.Value.Equals(1) ? true : false : false;
            InfoEmision.ConductorHabitual = true;
            InfoEmision.Edad = cotizacion.Cotizacion.Edad;
            InfoEmision.EmisionPersonaMoral = emisionPersonaMoral;
            InfoEmision.CotizacionCero = cotizacion.CotizacionCero;
            //InfoEmision.FechaNacimiento = DateTime.Today.AddYears(-InfoEmision.Edad);
            if (InfoEmision.IdTipoContratante != 1) //Datos Fiscales Empleado
            {
                InfoEmision.DatosUsuario.Direccion = new Direccion();
                InfoEmision.DatosUsuario.Direccion.CodigoPostal = cotizacion.Cotizacion.CodigoPostal;
            }

            //log.Info("Detalle del usuario encontrado");
            bool usuarioAlias = false;
            DetalleUsuario detalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            InfoEmision.PrimerNombre = detalleUsuario.Nombre?.Trim() ?? string.Empty;
            InfoEmision.SegundoNombre = detalleUsuario.NombreDos?.Trim() ?? string.Empty;
            InfoEmision.ApellidoPaterno = detalleUsuario.ApellidoPaterno?.Trim() ?? string.Empty;
            InfoEmision.ApellidoMaterno = detalleUsuario.ApellidoMaterno?.Trim() ?? string.Empty;
            InfoEmision.PrimerNombreEmpleado = detalleUsuario.Nombre?.Trim() ?? string.Empty;
            InfoEmision.SegundoNombreEmpleado = detalleUsuario.NombreDos?.Trim() ?? string.Empty;
            InfoEmision.ApellidoPaternoEmpleado = detalleUsuario.ApellidoPaterno?.Trim() ?? string.Empty;
            InfoEmision.ApellidoMaternoEmpleado = detalleUsuario.ApellidoMaterno?.Trim() ?? string.Empty;
            InfoEmision.RFCEmpleado = string.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC) ? detalleUsuario.RFC : InfoEmision.DatosUsuario.RFC;
            InfoEmision.FechaNacimiento = cotizacion.Cotizacion.FechaNacimiento.HasValue ? cotizacion.Cotizacion.FechaNacimiento.Value : detalleUsuario.FECHANACIMIENTO;
            InfoEmision.Email = string.IsNullOrEmpty(detalleUsuario.Correo) ? "" : detalleUsuario.Correo;
            InfoEmision.TelefonoCel = string.IsNullOrEmpty(detalleUsuario.TelefonoCelular) ? "" : detalleUsuario.TelefonoCelular;
            InfoEmision.AplicaSelectAdicional = Configuracion.SelectAdicionalEmision;
            InfoEmision.SelectAdicionalEtiqueta = Configuracion.SelectAdicionalEmisionNombre ?? "";
            InfoEmision.AplicaNumeroContrato = usuarioAlias ? convenio.AplicaNumeroContrato : convenio.AplicaNumeroContratoUsuarioFinal;
            InfoEmision.AplicaNumeroSegmento = usuarioAlias ? convenio.AplicaSegmento : convenio.AplicaSegmentoUsuarioFinal;
            InfoEmision.AplicaNumeroEmpleado = usuarioAlias ? convenio.AplicaNumeroEmpleado : convenio.AplicaNumeroEmpleadoUsuarioFinal;

            //Meses sin intereses
            if (periodicidad.Id == 1 && _medioPago.Id == 1)
            {
                var parameters = new List<SqlParameter>()
                    {
                         new SqlParameter("@IdEmpresa",convenio.IdEmpresa)
                        ,new SqlParameter("@IdConvenio",convenio.Id)
                    };

                var msi = db.sp_MSI_Valida_Aplica.SqlQuery("sp_MSI_Valida_Aplica @IdEmpresa, @IdConvenio", parameters.ToArray()).FirstOrDefault();

                if (msi != null)
                {
                    InfoEmision.AplicaMSI = true;
                    InfoEmision.IdConvenioMSI = msi.Id;
                }


            }

            if (string.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC))
            {
                if (string.IsNullOrEmpty(detalleUsuario.RFC))
                {
                    if (!string.IsNullOrEmpty(detalleUsuario.ApellidoMaterno) && !string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno))
                        InfoEmision.RFCEmpleado = Utilidades.CalcularRFC(detalleUsuario.Nombre + " " + detalleUsuario.NombreDos
                            , detalleUsuario.ApellidoPaterno
                            , detalleUsuario.ApellidoMaterno
                            , detalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yy"));
                    else
                        InfoEmision.RFCEmpleado = "";

                }
                else
                    InfoEmision.DatosUsuario.RFC = detalleUsuario.RFC;
            }
            InfoEmision.NombreTipoVehiculo = string.Empty;

            if (catusovehiculo != null)
            {

                if (catusovehiculo.Nombre.Contains("("))
                    InfoEmision.NombreTipoVehiculo = $"{catusovehiculo.Nombre.Substring(0, catusovehiculo.Nombre.IndexOf('('))}";
                else
                    InfoEmision.NombreTipoVehiculo = catusovehiculo.Nombre;
            }


            if (_cotizacion.IdUso > 0)
            {
                var catuso = db.CatUsos.FirstOrDefault(a => a.Id == _cotizacion.IdUso);
                var clave = "";

                if (InfoEmision.Aseguradora == "QUALITAS")
                    clave = catuso.ClaveQUALITAS;
                else
                    clave = catuso.ClaveGNP == "-" ? catuso.ClaveQUALITAS : catuso.ClaveGNP;

                InfoEmision.NombreTipoVehiculo = $"{InfoEmision.NombreTipoVehiculo} {catuso.Nombre} - {clave}";
            }

            DetalleUsuarioBeFlex detalleUsuarioBeflex = db.DetalleUsuarioBeFlex.FirstOrDefault(a => a.IdUsuario == detalleUsuario.IdUsuario);
            if (detalleUsuarioBeflex != null)
            {
                InfoEmision.SociedadBeFlex = detalleUsuarioBeflex.Sociedad;
                InfoEmision.ContratanteBeFlex = detalleUsuarioBeflex.Contratante;
                InfoEmision.LocalidadBeFlex = detalleUsuarioBeflex.Localidad;
            }



            if (empresa.Sucursales.Count > 0)
            {
                InfoEmision.AplicaSucursales = true;

            }

            OTRenovacion renovacion = db.OTRenovacion.Where(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion) && x.Estatus.Equals(1)).FirstOrDefault();
            if (renovacion != null)
            {
                //log.Info(string.Concat("Aplica renovación para la póliza: ", renovacion.NumeroDePoliza));
                InfoEmision.ConductorHabitual = false;
                InfoEmision.EsRenovacion = true;
                InfoEmision.NumeroMotor = renovacion.Motor.Trim();
                InfoEmision.NumeroSerie = renovacion.Serie.Trim();
                InfoEmision.Placas = renovacion.Placas.Trim();
                InfoEmision.DatosUsuario.RFC = "";

                if (!string.IsNullOrEmpty(renovacion.ConductorHabitual))
                {
                    var nombres = renovacion.ConductorHabitual.Split(' ');
                    InfoEmision.ApellidoMaterno = "";
                    InfoEmision.ApellidoPaterno = "";
                    InfoEmision.SegundoNombre = "";
                    InfoEmision.PrimerNombre = "";

                    if (nombres.Length >= 4)
                    {
                        InfoEmision.ApellidoMaterno = nombres.Last()?.Trim() ?? string.Empty;
                        InfoEmision.ApellidoPaterno = nombres[nombres.Length - 2]?.Trim() ?? string.Empty;
                        InfoEmision.SegundoNombre = nombres[nombres.Length - 3]?.Trim() ?? string.Empty;
                        InfoEmision.PrimerNombre = "";
                        for (int i = 0; i <= nombres.Length - 4; i++)
                        {
                            InfoEmision.PrimerNombre += nombres[i] + " ";
                        }
                        InfoEmision.PrimerNombre = InfoEmision.PrimerNombre?.Trim() ?? string.Empty;

                    }
                    else if (nombres.Length == 3)
                    {
                        InfoEmision.ApellidoMaterno = nombres[2]?.Trim() ?? string.Empty;
                        InfoEmision.ApellidoPaterno = nombres[1]?.Trim() ?? string.Empty;
                        InfoEmision.PrimerNombre = nombres[0]?.Trim() ?? string.Empty;

                    }
                    else
                        InfoEmision.PrimerNombre = renovacion.ConductorHabitual?.Trim() ?? string.Empty;




                }

                if (convenio.DatosBancariosEnrollment && (_medioPago.Id == 1 || _medioPago.Id == 2 || _medioPago.Id == 6))
                {
                    SqlParameter sqlSerie = new SqlParameter("@Serie", InfoEmision.NumeroSerie);

                    var detallePolizaSerie = db.sp_Emision_ValidaSeriePolizaAnterior.SqlQuery("sp_Emision_ValidaSeriePolizaAnterior @Serie", sqlSerie).FirstOrDefault();


                    if (detallePolizaSerie != null
                        && detallePolizaSerie.IDFPago.HasValue
                        && detallePolizaSerie.IDFPago.Value.ToString() == periodicidad.Clave
                        && (
                            detallePolizaSerie.TPago.ToString() == _medioPago.ClaveBogo
                            || (detallePolizaSerie.TPago == 4
                                && (_medioPago.ClaveBogo == "0" || _medioPago.ClaveBogo == "1"))
                           )
                        && detallePolizaSerie.AseguradoraClave == Aseguradora)
                    {
                        InfoEmision.MismosDatosBancariosEnrollment = true;
                    }

                }
            }

            if ((Session["__USUARIO__MODULO__RENOVACIONES__"] != null
                && Convert.ToBoolean(Session["__USUARIO__MODULO__RENOVACIONES__"].ToString()))
              || (Session["__USUARIO__LOGUEORAPIDO__"] != null && Convert.ToBoolean(Session["__USUARIO__LOGUEORAPIDO__"].ToString()))
                )
            {
                InfoEmision.PermisoSoloRenovacion = true;
            }

            if (_cotizacion.IdDocto > 0)
            {
                //log.Info(string.Concat("Aplica renovación para la póliza: ", renovacion.NumeroDePoliza));

                SqlParameter sqlPoliza = new SqlParameter("@Poliza", "");
                SqlParameter sqlIdDocto = new SqlParameter("@IdDocto", _cotizacion.IdDocto);

                var detallePoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza,@IdDocto", sqlPoliza, sqlIdDocto).FirstOrDefault();



                InfoEmision.ConductorHabitual = false;

                InfoEmision.NumeroMotor = detallePoliza.Motor.Trim();
                InfoEmision.NumeroSerie = detallePoliza.Serie.Trim();
                InfoEmision.Placas = detallePoliza.Placas.Trim();
                InfoEmision.DatosUsuario.RFC = "";

                if (!string.IsNullOrEmpty(detallePoliza.ConductorHabitual))
                {
                    var nombres = detallePoliza.ConductorHabitual.Replace(',', ' ').Split(' ');
                    InfoEmision.ApellidoMaterno = "";
                    InfoEmision.ApellidoPaterno = "";
                    InfoEmision.SegundoNombre = "";
                    InfoEmision.PrimerNombre = "";

                    if (nombres.Length >= 4)
                    {
                        InfoEmision.ApellidoMaterno = nombres.Last()?.Trim() ?? string.Empty;
                        InfoEmision.ApellidoPaterno = nombres[nombres.Length - 2]?.Trim() ?? string.Empty;
                        InfoEmision.SegundoNombre = nombres[nombres.Length - 3]?.Trim() ?? string.Empty;
                        InfoEmision.PrimerNombre = "";
                        for (int i = 0; i <= nombres.Length - 4; i++)
                        {
                            InfoEmision.PrimerNombre += nombres[i] + " ";
                        }
                        InfoEmision.PrimerNombre = InfoEmision.PrimerNombre?.Trim() ?? string.Empty;
                    }
                    else if (nombres.Length == 3)
                    {
                        InfoEmision.ApellidoMaterno = nombres[2]?.Trim() ?? string.Empty;
                        InfoEmision.ApellidoPaterno = nombres[1]?.Trim() ?? string.Empty;
                        InfoEmision.PrimerNombre = nombres[0]?.Trim() ?? string.Empty;

                    }
                    else
                        InfoEmision.PrimerNombre = detallePoliza.ConductorHabitual?.Trim() ?? string.Empty;




                }
            }



            //if (TempData["__INFORMACION_EMISION_COTIZACIONINFORMACION__"] != null)
            //{
            //	InformacionEmision ingresado = (InformacionEmision)TempData["__INFORMACION_EMISION_COTIZACIONINFORMACION__"];
            //	if (!string.IsNullOrEmpty(ingresado.NumeroSerie))
            //		InfoEmision.NumeroSerie = ingresado.NumeroSerie.Trim();
            //	if (!string.IsNullOrEmpty(ingresado.NumeroMotor))
            //		InfoEmision.NumeroMotor = ingresado.NumeroMotor.Trim();
            //	if (!string.IsNullOrEmpty(ingresado.Placas))
            //		InfoEmision.Placas = ingresado.Placas.Trim();
            //}							

            if ((InfoEmision.IdTipoDeNegocio == 5 || InfoEmision.IdTipoDeNegocio == 6) && InfoEmision.EmisionPersonaMoral)
            {

                if (InfoEmision.PersonaMoral == null)
                    InfoEmision.PersonaMoral = new PersonaMoral();
                if (InfoEmision.PersonaMoral.Direccion == null)
                    InfoEmision.PersonaMoral.Direccion = new Direccion();

                if (InfoEmision.PersonaMoralRepresentanteLegal == null)
                    InfoEmision.PersonaMoralRepresentanteLegal = new PersonaMoralRepresentanteLegal();

            }
            //log.Info("Regresa la vista");
            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.ComprarCotizacion, idCotizacionDetalle: IdCotizacion, EmpresaId: empresa.Id);

            //var json = JsonConvert.SerializeObject((UnProxy(db, infoEmision)));

            InfoEmision = GenerateViewsEmision(InfoEmision);

            return View(InfoEmision);

        }

        private InformacionEmision GenerateViewsEmision(InformacionEmision InfoEmision, bool EsError = false, string Msj = "", string Titulo = "", string Icono = "")
        {
            var cotizacion = db.CotizacionDetalle.Find(InfoEmision.IdCotizacion);

            InfoEmision.IdAsentamientoSelected = InfoEmision.IdAsentamiento;
            InfoEmision.Convenio = db.Convenio.FirstOrDefault(a => a.Id == cotizacion.IdConvenio);
            InfoEmision.Empresa = db.Empresa.FirstOrDefault(a => a.Id == InfoEmision.Convenio.IdEmpresa);
            InfoEmision.Tarjeta = new Tarjeta();

            InfoEmision.ZonaCirculacion = InfoEmision.Convenio.ZonaCirculacion;

            var aseguradora = db.Aseguradora.Where(x => x.Id == InfoEmision.Convenio.IdAseguradora && x.Estatus.Equals(1)).FirstOrDefault();
            var cotizacionauto = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion));
            var idPaquete = Convert.ToInt32(cotizacion.Paquete);
            var paqueteCotizacion = db.CatTipoPaquete.Where(x => x.Id == idPaquete).FirstOrDefault().Nombre;
            var Configuracion = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Empresa.Id).FirstOrDefault();
            var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == cotizacion.IdPaqueteConvenio);
            var xmlCotizacionSeleccionada = new XmlDocument();
            var tipoPago = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion)).MediodePago; ;
            var periodicidad = db.CatPeriodicidadFormaPago.FirstOrDefault(x => x.Id.Equals(cotizacionauto.FormadePago));
            var FormaPago = periodicidad.Nombre;
            var medioPago = cotizacionauto.MediodePago;
            var _medioPago = db.CatModalidadFormaPago.FirstOrDefault(x => x.Clave.Equals(medioPago.ToString()));
            var medioPa = (medioPago.Equals(0) || medioPago.Equals(1)) ? "Tarjeta" : _medioPago.Nombre;
            var numTotalRecibos = 0;
            var opcionesSelectAdicional = db.SelectOption.Where(a => a.IdEmpresa == InfoEmision.Empresa.Id).ToList();
            var opcionesAdicionales = new List<SelectOptionAdicional>();
            string iduser = (User.Identity as System.Security.Claims.ClaimsIdentity).FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value;

            if (string.IsNullOrEmpty(InfoEmision.PrimerNombre))
            {
                bool usuarioAlias = false;
                DetalleUsuario detalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
                InfoEmision.PrimerNombre = detalleUsuario.Nombre.Trim();
                InfoEmision.SegundoNombre = detalleUsuario.NombreDos.Trim();
                InfoEmision.ApellidoPaterno = detalleUsuario.ApellidoPaterno.Trim();
                InfoEmision.ApellidoMaterno = detalleUsuario.ApellidoMaterno.Trim();
                InfoEmision.PrimerNombreEmpleado = detalleUsuario.Nombre.Trim();
                InfoEmision.SegundoNombreEmpleado = detalleUsuario.NombreDos.Trim();
                InfoEmision.ApellidoPaternoEmpleado = detalleUsuario.ApellidoPaterno.Trim();
                InfoEmision.ApellidoMaternoEmpleado = detalleUsuario.ApellidoMaterno.Trim();
                InfoEmision.RFCEmpleado = string.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC) ? detalleUsuario.RFC : InfoEmision.DatosUsuario.RFC;
                InfoEmision.FechaNacimiento = cotizacion.Cotizacion.FechaNacimiento.HasValue ? cotizacion.Cotizacion.FechaNacimiento.Value : detalleUsuario.FECHANACIMIENTO;
                InfoEmision.Email = string.IsNullOrEmpty(detalleUsuario.Correo) ? "" : detalleUsuario.Correo;
                InfoEmision.TelefonoCel = string.IsNullOrEmpty(detalleUsuario.TelefonoCelular) ? "" : detalleUsuario.TelefonoCelular;
                InfoEmision.AplicaSelectAdicional = Configuracion.SelectAdicionalEmision;
                InfoEmision.SelectAdicionalEtiqueta = Configuracion.SelectAdicionalEmisionNombre ?? "";
                InfoEmision.AplicaNumeroContrato = usuarioAlias ? InfoEmision.Convenio.AplicaNumeroContrato : InfoEmision.Convenio.AplicaNumeroContratoUsuarioFinal;
                InfoEmision.AplicaNumeroSegmento = usuarioAlias ? InfoEmision.Convenio.AplicaSegmento : InfoEmision.Convenio.AplicaSegmentoUsuarioFinal;
                InfoEmision.AplicaNumeroEmpleado = usuarioAlias ? InfoEmision.Convenio.AplicaNumeroEmpleado : InfoEmision.Convenio.AplicaNumeroEmpleadoUsuarioFinal;
            }

            InfoEmision.FormaPago = periodicidad.Id;
            InfoEmision.IdMedioPago = _medioPago.Id;

            ViewBag.ConYSinDatosBancarios = false;
            ViewBag.SoloCondatosBancarios = false;
            ViewBag.SoloSinDatosBancarios = false;
            var _modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == InfoEmision.Convenio.Id && a.IdCatPeriodicidadFormaPago == periodicidad.Id && a.IdCatModalidadFormaPago == _medioPago.Id);
            if (User.IsInRole("Emisión Con Datos Bancarios") && User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                InfoEmision.EmisionConDatosBancarios = _modalidadFormaPago.SinDatosBancarios;
                ViewBag.ConYSinDatosBancarios = true;
            }
            if (User.IsInRole("Emisión Con Datos Bancarios") && !User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                ViewBag.SoloCondatosBancarios = true;
            }
            if (!User.IsInRole("Emisión Con Datos Bancarios") && User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                ViewBag.SoloSinDatosBancarios = true;
            }

            if (aseguradora.Id != 26)
                xmlCotizacionSeleccionada.LoadXml(cotizacion.XMLRecepcion);

            if (!string.IsNullOrEmpty(Msj))
            {
                Msj = Msj.Replace("\n", " ");
                if (Msj.Contains("Object reference not set to an instance of an object"))
                    Msj = "Ocurrió un error al intentar emitir su póliza, por favor de Intentar nuevamente, si el error persiste contacte a su ejecutivo de cuenta.";
            }

            switch (periodicidad.Id)
            {
                case 1:
                    numTotalRecibos = 1;
                    break;
                case 2:
                    numTotalRecibos = 1;
                    break;
                case 3:
                    numTotalRecibos = 3;
                    break;
                case 4:
                    numTotalRecibos = 11;
                    break;
                case 5:
                    numTotalRecibos = 23;
                    break;
                case 6:
                    numTotalRecibos = 25;
                    break;
            }


            ViewBag.IdEmpresa = InfoEmision.Empresa.Id;
            ViewBag.ISMit = InfoEmision.Convenio.GestorCobro == 2 && (tipoPago == 0 || tipoPago == 1) ? true : false;
            ViewBag.EsPreferenteGNP = ((Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').Contains(InfoEmision.Convenio.IdEmpresa.ToString()) || Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS")) && InfoEmision.Convenio.IdCatTipoConvenio.Equals(2));

            if (paqueteConvenio != null)
                ViewBag.Cobertura = paqueteConvenio.NombrePaquete;

            switch (aseguradora.ClaveHomologado.Trim())
            {
                case "QUALITAS":
                    //log.Info("Es una cotización de Quálitas.");

                    string vehiculo = cotizacionauto.ObtieneDescVehiculo();

                    LocktonServicios.Tarificador.TarificadorClient tarificador = new LocktonServicios.Tarificador.TarificadorClient();


                    var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == cotizacion.Cotizacion.IdPeriodicidadPago).FirstOrDefault();
                    int nodosRecibos = 0;
                    string primerPago = "";
                    string numPagos = "";
                    string totalPorRecibo = "";
                    string fechaInicio = "";
                    string fechaFin = "";
                    string primaTotal = "";
                    if (periodicidad.Nombre.Contains("Mensual") || periodicidad.Nombre.Contains("Contado") || perioricidad.Nombre.Contains("Trimestral") || perioricidad.Nombre.Contains("Semestral") || perioricidad.Nombre.Contains("Anual"))
                    {
                        nodosRecibos = xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos").Count;
                        primerPago = Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos")[0].ChildNodes[6].InnerText).ToString("C", CultureInfo.CurrentCulture);
                        numPagos = nodosRecibos > 1 ? (nodosRecibos - 1).ToString() : nodosRecibos.ToString();
                        totalPorRecibo = nodosRecibos > 1 ? Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos")[1].ChildNodes[6].InnerText).ToString("C", CultureInfo.CurrentCulture) : primerPago;
                        fechaInicio = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/DatosGenerales/FechaInicio")[0].InnerText).ToString("dd/MM/yyyy");
                        fechaFin = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/DatosGenerales/FechaTermino")[0].InnerText).ToString("dd/MM/yyyy");
                        primaTotal = string.Concat(Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Primas/PrimaTotal")[0].InnerText).ToString("C", CultureInfo.CurrentCulture), " MXN");

                    }
                    else
                    {

                        var flotilla = (InfoEmision.Convenio.IdCatTipoVigencia == 1) ? true : false;
                        //if (!convenio.DerechosPrimerRecibo)
                        //{
                        var error = "";
                        var rec = tarificador.GetRecibosOnline(cotizacion.IdConvenio, flotilla, perioricidad.Nombre, Convert.ToDouble(cotizacion.PrimaTotalAnual), Convert.ToDateTime(cotizacion.Cotizacion.FechaFactura.ToString("dd/MM/yyyy"))).ToList();
                        if (rec.Any())
                        {
                            foreach (var item in rec)
                            {
                                error = item.MensajeError;
                            }
                            if (error == "" || error == null)
                            {
                                var primerRecibo = rec.Find(a => a.Index == 0);/*xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos").Count*/;

                                nodosRecibos = rec.Count();/*xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos").Count*/;
                                primerPago = (Math.Truncate(primerRecibo.CobroCorte * 100) / 100).ToString();    /*Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos")[0].ChildNodes[6].InnerText).ToString("C", CultureInfo.CurrentCulture)*/;
                                numPagos = nodosRecibos > 1 ? (nodosRecibos - 1).ToString() : nodosRecibos.ToString();
                                totalPorRecibo = rec.Count == 1 ? "" : (Math.Truncate(rec.Find(a => a.Index == 1).CobroCorte * 100) / 100).ToString();/*nodosRecibos > 1 ? Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos")[1].ChildNodes[6].InnerText).ToString("C", CultureInfo.CurrentCulture) : primerPago;*/
                                fechaInicio = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/DatosGenerales/FechaInicio")[0].InnerText).ToString("dd/MM/yyyy");
                                fechaFin = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/DatosGenerales/FechaTermino")[0].InnerText).ToString("dd/MM/yyyy");
                                primaTotal = string.Concat(Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Primas/PrimaTotal")[0].InnerText).ToString("C", CultureInfo.CurrentCulture), " MXN");
                            }
                            else
                            {
                                if (error.Contains("El convenio no tiene asignado ningún calendario de tipo de pago"))
                                {
                                    nodosRecibos = xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos").Count;
                                    primerPago = Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos")[0].ChildNodes[6].InnerText).ToString("C", CultureInfo.CurrentCulture);
                                    numPagos = nodosRecibos > 1 ? (nodosRecibos - 1).ToString() : nodosRecibos.ToString();
                                    totalPorRecibo = nodosRecibos > 1 ? Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos")[1].ChildNodes[6].InnerText).ToString("C", CultureInfo.CurrentCulture) : primerPago;
                                    fechaInicio = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/DatosGenerales/FechaInicio")[0].InnerText).ToString("dd/MM/yyyy");
                                    fechaFin = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/DatosGenerales/FechaTermino")[0].InnerText).ToString("dd/MM/yyyy");
                                    primaTotal = string.Concat(Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Primas/PrimaTotal")[0].InnerText).ToString("C", CultureInfo.CurrentCulture), " MXN");
                                }
                            }

                        }

                        //}
                        //else
                        //{
                        //    nodosRecibos = xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos").Count;
                        //    primerPago = Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos")[0].ChildNodes[6].InnerText).ToString("C", CultureInfo.CurrentCulture);
                        //    numPagos = nodosRecibos > 1 ? (nodosRecibos - 1).ToString() : nodosRecibos.ToString();
                        //    totalPorRecibo = nodosRecibos > 1 ? Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Recibos")[1].ChildNodes[6].InnerText).ToString("C", CultureInfo.CurrentCulture) : primerPago;
                        //    fechaInicio = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/DatosGenerales/FechaInicio")[0].InnerText).ToString("dd/MM/yyyy");
                        //    fechaFin = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/DatosGenerales/FechaTermino")[0].InnerText).ToString("dd/MM/yyyy");
                        //    primaTotal = string.Concat(Convert.ToDecimal(xmlCotizacionSeleccionada.SelectNodes("Movimientos/Movimiento/Primas/PrimaTotal")[0].InnerText).ToString("C", CultureInfo.CurrentCulture), " MXN");
                        //}


                    }

                    ViewBag.Vehiculo = vehiculo;
                    ViewBag.Año = cotizacionauto.Agnio;

                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = fechaInicio;
                    ViewBag.FechaFin = fechaFin;
                    ViewBag.PrimaTotal = primaTotal;
                    ViewBag.PrimerPago = string.Concat(primerPago, " MXN");
                    ViewBag.NumPagos = Convert.ToInt32(numPagos);
                    ViewBag.TotalPorRecibo = string.Concat(totalPorRecibo, " MXN");

                    break;
                case "GNP":
                    //log.Info("Es una cotización de GNP.");
                    Comparar infoGNP = null;


                    if (paqueteConvenio.Convenio.GNPInfoEspecial)
                        infoGNP = new GNPInfoService().LeeXmlInformacion(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud, numTotalRecibos, paqueteConvenio.Convenio);
                    else
                        infoGNP = new GNPPreferenteService().LeeXmlInformacion(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud, numTotalRecibos);


                    //bool esPool = paqueteConvenio.Convenio.IdCatTipoConvenio.Equals(2);
                    //if (Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').ToList().Contains(paqueteConvenio.Convenio.IdEmpresa.ToString()) ||
                    //                   Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS"))
                    //               {
                    //                   if (!esPool)
                    //                       infoGNP = new GNPInfoService().LeeXmlInformacion(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud, numTotalRecibos, paqueteConvenio.Convenio);
                    //                   else
                    //                       infoGNP = new GNPPreferenteService().LeeXmlInformacion(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud, numTotalRecibos);
                    //               }
                    //               else
                    //                   infoGNP = new GNPService().LeeXmlInformacion(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud, numTotalRecibos);

                    XmlDocument xmlCotizacionEmitida = new XmlDocument();
                    xmlCotizacionEmitida.LoadXml(cotizacion.XMLSolicitud);

                    string _vehiculo = cotizacionauto.ObtieneDescVehiculo();
                    string _primerPago = string.Concat(Convert.ToDecimal(infoGNP.PrimerPago).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    string _totalPorRecibo = _primerPago;

                    decimal _segundoPago;
                    if (decimal.TryParse(infoGNP.SegundoPago, out _segundoPago))
                        _totalPorRecibo = _segundoPago.ToString("C", CultureInfo.CurrentCulture);


                    ViewBag.Vehiculo = _vehiculo;
                    ViewBag.Año = cotizacionauto.Agnio;

                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = infoGNP.FechaInicio;
                    ViewBag.FechaFin = infoGNP.FechaFin;
                    ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(infoGNP.PrimaTotal).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    ViewBag.PrimerPago = _primerPago;
                    ViewBag.NumPagos = infoGNP.NumeroDePagos == 1 ? 0 : infoGNP.NumeroDePagos - 1;
                    ViewBag.TotalPorRecibo = string.Concat(_totalPorRecibo, " MXN");


                    break;
                case "INBURSA":
                    //log.Info("Es una cotización de INBURSA.");
                    Cotizacion cot = db.Cotizacion.First(a => a.Id == cotizacion.IdCotizacion);

                    Comparar infoInbursa = new INBURSAService().LeeXmlRespuesta(cotizacion.XMLRecepcion, idPaquete, Convert.ToInt32(cotizacionauto.Agnio), cot, cotizacion, InfoEmision.Convenio, cotizacionauto.TipoVehiculo);

                    string _vehiculoINBURSA = cotizacionauto.ObtieneDescVehiculo();
                    string _primerPagoINBURSA = string.Concat(Convert.ToDecimal(infoInbursa.PrimerPago).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    string _totalPorReciboINBURSA = _primerPagoINBURSA;

                    decimal _segundoPagoINBURSA;
                    if (decimal.TryParse(infoInbursa.SegundoPago, out _segundoPagoINBURSA))
                        _totalPorReciboINBURSA = _segundoPagoINBURSA.ToString("C", CultureInfo.CurrentCulture);


                    ViewBag.Vehiculo = _vehiculoINBURSA;
                    ViewBag.Año = cotizacionauto.Agnio;
                    ViewBag.Cobertura = string.Format("{0} {1}", paqueteCotizacion, infoInbursa.Bloque); ;
                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = infoInbursa.FechaInicio;
                    ViewBag.FechaFin = infoInbursa.FechaFin;
                    ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(infoInbursa.PrimaTotal).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    ViewBag.PrimerPago = _primerPagoINBURSA;
                    ViewBag.NumPagos = infoInbursa.NumeroDePagos;
                    ViewBag.TotalPorRecibo = string.Concat(_totalPorReciboINBURSA, " MXN");
                    ViewBag.IdArrendadoPlan = new SelectList(
                                              new List<SelectListItem>{
                                                          new SelectListItem { Text = "Personales", Value = ""},
                                                     new SelectListItem { Text = "Plan/Arrendado", Value = "Plan/Arrendado"}

                                                                         }, "Value", "Text", "Personales");

                    ViewBag.Arrendado = new SelectList(db.CatArrendadora.ToList(), "Nombre", "Nombre");

                    ViewBag.Perfil = db.DetalleUsuario.Where(x => x.IdUsuario == iduser).FirstOrDefault().IdPerfil;

                    break;
                case "AXA":
                    log.Info("Es una cotización de AXA.");
                    XmlDocument xmlRequest = new XmlDocument();
                    XmlDocument xmlResponse = new XmlDocument();

                    xmlRequest.LoadXml(cotizacion.XMLSolicitud);
                    xmlResponse.LoadXml(cotizacion.XMLRecepcion);
                    Comparar infoAXA = new Comparar();
                    if (InfoEmision.Convenio.AxaEspecial)
                    {
                        infoAXA = new AXAFlotillaServices().LeeXmlRespuesta(cotizacion.XMLRecepcion, 1, cotizacion.XMLSolicitud, InfoEmision.Convenio);
                        ViewBag.NumeroPolizaAXA = infoAXA.CaratulaCotizacion;
                    }
                    else
                        infoAXA = new AXAService().ReadCarQuoteResponse(xmlResponse, cotizacion.IdConvenio, xmlRequest, Convert.ToInt32(cotizacion.Paquete), cotizacion.IdPaqueteConvenio ?? 0);



                    string _veh = cotizacionauto.ObtieneDescVehiculo();
                    string _ppago = string.Concat(Convert.ToDecimal(infoAXA.PrimerPago).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    string _total = !string.IsNullOrEmpty(infoAXA.SegundoPago) ? Convert.ToDecimal(infoAXA.SegundoPago).ToString("C", CultureInfo.CurrentCulture) : _ppago;

                    ViewBag.Vehiculo = _veh;
                    ViewBag.Año = cotizacionauto.Agnio;

                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = infoAXA.FechaInicio;
                    ViewBag.FechaFin = infoAXA.FechaFin;
                    ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(infoAXA.PrimaTotal).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    ViewBag.PrimerPago = _ppago;
                    ViewBag.NumPagos = infoAXA.NumeroDePagos;
                    ViewBag.TotalPorRecibo = string.Concat(_total, " MXN");

                    break;
                case "ABA":
                    //log.Info("Es una cotización de CHUBB.");

                    CotizacionAuto cotizacionautoAba = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion));
                    construyeInformacionAuto(cotizacionautoAba, cotizacion, paqueteCotizacion, aseguradora, FormaPago, medioPa);
                    break;
                case "ATLAS":
                    //log.Info("Es una cotización de Atlas.");
                    ATLASService atlasService = new ATLASService();
                    Comparar comparar = atlasService.LeeXmlRespuesta(cotizacion.XMLRecepcion, idPaquete, aseguradora.Id, paqueteConvenio.IdPlan, paqueteConvenio.Id);
                    ViewBag.Vehiculo = cotizacionauto.ObtieneDescVehiculo();
                    ViewBag.Año = cotizacionauto.Agnio;
                    ViewBag.Cobertura = paqueteCotizacion;
                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = comparar.FechaInicio;
                    ViewBag.FechaFin = comparar.FechaFin;
                    ViewBag.PrimaTotal = comparar.PrimaTotal;
                    ViewBag.PrimerPago = string.Concat(comparar.PrimerPago, " MXN");
                    ViewBag.NumPagos = comparar.NumeroDePagos - 1;
                    ViewBag.TotalPorRecibo = string.IsNullOrEmpty(comparar.SegundoPago) ? string.Concat(comparar.PrimerPago, " MXN") : string.Concat(comparar.SegundoPago, " MXN");
                    break;
                case "MAPFRE":

                    Comparar infoMAPRE = new MAPFRE().LeeXmlInformacion(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud);
                    string _primerPagoMapfre = string.Concat(Convert.ToDecimal(infoMAPRE.PrimerPago).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    string _totalPorReciboMapfre = _primerPagoMapfre;


                    decimal _segundoPagoMapfre;
                    if (decimal.TryParse(infoMAPRE.SegundoPago, out _segundoPagoMapfre))
                        _totalPorReciboMapfre = _segundoPagoMapfre.ToString("C", CultureInfo.CurrentCulture);


                    ViewBag.Vehiculo = cotizacionauto.ObtieneDescVehiculo(); ;
                    ViewBag.Año = cotizacionauto.Agnio;

                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = infoMAPRE.FechaInicio;
                    ViewBag.FechaFin = infoMAPRE.FechaFin;
                    ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(infoMAPRE.PrimaTotal).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    ViewBag.PrimerPago = _primerPagoMapfre;
                    ViewBag.NumPagos = infoMAPRE.NumeroDePagos;
                    ViewBag.TotalPorRecibo = string.Concat(_totalPorReciboMapfre, " MXN");

                    break;
                case "HDI":

                    var infoHDI = new HDIServices().LeeXmlRespuesta(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud, InfoEmision.Convenio);
                    string _primerPagoHDI = string.Concat(Convert.ToDecimal(infoHDI.PrimerPago).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    string _totalPorReciboHDI = _primerPagoHDI;

                    decimal _segundoPagoHDI;
                    if (decimal.TryParse(infoHDI.SegundoPago, out _segundoPagoHDI))
                        _totalPorReciboHDI = _segundoPagoHDI.ToString("C", CultureInfo.CurrentCulture);


                    ViewBag.Vehiculo = cotizacionauto.ObtieneDescVehiculo(); ;
                    ViewBag.Año = cotizacionauto.Agnio;

                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = infoHDI.FechaInicio;
                    ViewBag.FechaFin = infoHDI.FechaFin;
                    ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(infoHDI.PrimaTotal).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    ViewBag.PrimerPago = _primerPagoHDI;
                    ViewBag.NumPagos = infoHDI.NumeroDePagos;
                    ViewBag.TotalPorRecibo = string.Concat(_totalPorReciboHDI, " MXN");

                    break;
                case "BANORTE":

                    var infoBanorte = new BanorteFlotillaService(InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena).LeeXmlRespuesta(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud, InfoEmision.Convenio);
                    string _primerPagoBanorte = string.Concat(Convert.ToDecimal(infoBanorte.PrimerPago).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    string _totalPorReciboBanorte = _primerPagoBanorte;

                    decimal _segundoPagoBanorte;
                    if (decimal.TryParse(infoBanorte.SegundoPago, out _segundoPagoBanorte))
                        _totalPorReciboBanorte = _segundoPagoBanorte.ToString("C", CultureInfo.CurrentCulture);


                    ViewBag.Vehiculo = cotizacionauto.ObtieneDescVehiculo(); ;
                    ViewBag.Año = cotizacionauto.Agnio;

                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = infoBanorte.FechaInicio;
                    ViewBag.FechaFin = infoBanorte.FechaFin;
                    ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(infoBanorte.PrimaTotal).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    ViewBag.PrimerPago = _primerPagoBanorte;
                    ViewBag.NumPagos = infoBanorte.NumeroDePagos;
                    ViewBag.TotalPorRecibo = string.Concat(_totalPorReciboBanorte, " MXN");

                    break;
                case "ANA":

                    var infoANA = new ANAServices().LeeXmlRespuesta(cotizacion.XMLRecepcion, cotizacion.XMLSolicitud, InfoEmision.Convenio);
                    string _primerPagoANA = string.Concat(Convert.ToDecimal(infoANA.PrimerPago).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    string _totalPorReciboANA = _primerPagoANA;

                    decimal _segundoPagoANA;
                    if (decimal.TryParse(infoANA.SegundoPago, out _segundoPagoANA))
                        _totalPorReciboANA = _segundoPagoANA.ToString("C", CultureInfo.CurrentCulture);


                    ViewBag.Vehiculo = cotizacionauto.ObtieneDescVehiculo(); ;
                    ViewBag.Año = cotizacionauto.Agnio;

                    ViewBag.Aseguradora = aseguradora.ClaveHomologado;
                    ViewBag.FormaDePago = FormaPago;
                    ViewBag.MedioDePago = medioPa;
                    ViewBag.FechaInicio = infoANA.FechaInicio;
                    ViewBag.FechaFin = infoANA.FechaFin;
                    ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(infoANA.PrimaTotal).ToString("C", CultureInfo.CurrentCulture), " MXN");
                    ViewBag.PrimerPago = _primerPagoANA;
                    ViewBag.NumPagos = infoANA.NumeroDePagos;
                    ViewBag.TotalPorRecibo = string.Concat(_totalPorReciboANA, " MXN");

                    break;
            }

            construyeViewbagEmision(aseguradora, InfoEmision.Convenio.Id, InfoEmision.Convenio.IdEmpresa, cotizacion.Id);

            //Meses sin intereses


            if (InfoEmision.AplicaMSI)
            {
                var meses = new ConvenioController().GetConvenioMSI(InfoEmision.Convenio.Id, false).FirstOrDefault(a => a.Id == InfoEmision.IdConvenioMSI);
                meses.FichaTecnica = "";
                meses.Boletin = meses.Boletin.Replace("\t", "").Replace("\n", "");
                ViewBag.ConfiguracionMSI = meses;

                if (periodicidad.Id == 1)//contado
                    ViewBag.FormaDePago = FormaPago + " / MSI";

            }


            bool aplicaBenefMuerteAcc = false;

            if (Configuracion.BitEmpleadoMembresia == true)
            {
                aplicaBenefMuerteAcc = true;
                ViewBag.TexcoCampo = Configuracion.NombreMembresia;
                if (InfoEmision.Empresa.Id.Equals(37))
                    aplicaBenefMuerteAcc = paqueteCotizacion.Equals("Amplia") ? true : false;
            }

            ViewBag.AplicaBenefMuerteAcc = aplicaBenefMuerteAcc;
            ViewBag.TipoPago = tipoPago; //db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion)).MediodePago;

            if (InfoEmision.AplicaSucursales == true)
            {

                ViewBag.IdSucursal = new SelectList(InfoEmision.Empresa.Sucursales, "ClaveSucursal", "Nombre");
            }


            if (TempData["__ERROR_VALIDACION_EMISION__"] != null && EsError)
            {
                ViewBag.Msj = RemoveSpecialChars(TempData["__ERROR_VALIDACION_EMISION__"].ToString());
            }

            ViewBag.Msj = RemoveSpecialChars(Msj);
            ViewBag.EsError = EsError;
            ViewBag.Icono = Icono;
            ViewBag.Titulo = Titulo;

            if (InfoEmision.EsFlotilla || InfoEmision.EmisionPersonaMoral)
            {
                ViewBag.IdRegimenFiscal = new SelectList(db.CatRegimenFiscal.Where(a => a.PersonaMoral), "Id", "Descripcion");
                ViewBag.IdUsoCFDI = new SelectList(db.CatUsoCFDI.Where(a => a.AplicaPersonaMoral), "Id", "Descripcion");
            }
            else
            {
                ViewBag.IdRegimenFiscal = new SelectList(db.CatRegimenFiscal.Where(a => !a.PersonaMoral), "Id", "Descripcion");
                ViewBag.IdUsoCFDI = new SelectList(db.CatUsoCFDI, "Id", "Descripcion");
            }

            opcionesSelectAdicional.ForEach(a =>
            {
                var adicionales = db.SelectOptionAdicional.Where(x => x.IdSelectOption == a.Id).ToList();
                if (adicionales.Any())
                    opcionesAdicionales.AddRange(adicionales);
            });

            ViewBag.IdCatTipoIdentificacion = new SelectList(db.CatTipoIdentificacions, "Id", "TipoIdentificacion");
            ViewBag.IdCatProfesion = new SelectList(db.CatProfesion, "Id", "Profesion");
            ViewBag.IdCatOcupacion = new SelectList(db.CatOcupacion, "Id", "Ocupacion");
            ViewBag.IdCatGiro = new SelectList(db.CatGiroBase, "Id", "Nombre");
            ViewBag.IdRegimenCapital = new SelectList(db.CatRegimenCapital, "Id", "Descripcion");
            ViewBag.SelectOpcion = new SelectList(opcionesSelectAdicional, "Id", "Opcion");
            ViewBag.SelectOpcionAdicional = opcionesAdicionales;
            ViewBag.IdRegimenCapital = new SelectList(db.CatRegimenCapital, "Id", "Descripcion");

            if ((InfoEmision.IdTipoDeNegocio == 5 || InfoEmision.IdTipoDeNegocio == 6) && InfoEmision.EmisionPersonaMoral)
            {
                ViewBag.IdCatGiroBase = new SelectList(db.CatGiroBase, "Id", "Nombre");
                ViewBag.IdCatEstadosRepublica_Nacimiento = new SelectList(db.CatEstadosRepublica, "Id", "Estado");

                ViewBag.IdEstado = new SelectList(db.CatEstadosRepublica, "Id", "Estado");
                ViewBag.IdAsentamiento = new SelectList(
                 new List<SelectListItem>
                 {
                    new SelectListItem {Text = "Seleccione", Value = "99999"}
                 }, "Value", "Text");


            }
            ViewBag.UsuarioFinal = (db.DetalleUsuario.Where(x => x.IdUsuario == iduser).FirstOrDefault().IdPerfil == 3) ? true : false;

            //var _modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == InfoEmision.Convenio.Id && a.IdCatPeriodicidadFormaPago == periodicidad.Id && a.IdCatModalidadFormaPago == _medioPago.Id);

            InfoEmision.EsFacturable = _modalidadFormaPago.Facturable;
            ViewBag.ConYSinDatosBancarios = false;
            ViewBag.SoloCondatosBancarios = false;
            ViewBag.SoloSinDatosBancarios = false;
            if (User.IsInRole("Emisión Con Datos Bancarios") && User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                InfoEmision.EmisionConDatosBancarios = _modalidadFormaPago.SinDatosBancarios;
                ViewBag.ConYSinDatosBancarios = true;
            }
            if (User.IsInRole("Emisión Con Datos Bancarios") && !User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                ViewBag.SoloCondatosBancarios = true;
            }
            if (!User.IsInRole("Emisión Con Datos Bancarios") && User.IsInRole("Emisión Sin Datos Bancarios"))
            {
                ViewBag.SoloSinDatosBancarios = true;
            }

            else if (ViewBag.UsuarioFinal)
            {
                InfoEmision.EmisionConDatosBancarios = true;
            }

            return InfoEmision;
        }

        public string RemoveSpecialChars(string input)
        {
            if (!string.IsNullOrEmpty(input))
                return Regex.Replace(input, @"[^0-9a-zA-ZÀ-ú\._]", " ");
            else
                return input;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult ObtenerCodigosPostales(string CodigoPostal)
        {
            try
            {
                if (!string.IsNullOrEmpty(CodigoPostal))
                {
                    List<CodigoPostal> codigosPostales = db.CatCodigoPostal.Where(x => x.Codigo.Contains(CodigoPostal)).ToList();

                    List<object> _codigosPostales = new List<object>();

                    string codaux = "";
                    string ciudaux = "";
                    string munaux = "";
                    int idesaux = 0;
                    foreach (CodigoPostal codigoPostal in codigosPostales)
                    {
                        if (!codaux.Equals(codigoPostal.Codigo) |
                            !ciudaux.Equals(codigoPostal.Ciudad) |
                            !munaux.Equals(codigoPostal.Municipio) |
                            !idesaux.Equals(codigoPostal.IdEstado))
                        {
                            object colonias = codigosPostales.Select(n => new { n.Id, Colonia = n.Asentamiento });
                            _codigosPostales.Add(
                                new
                                {
                                    codigoPostal.Codigo,
                                    codigoPostal.Ciudad,
                                    codigoPostal.Municipio,
                                    codigoPostal.IdEstado,
                                    colonias
                                });
                        }
                        codaux = codigoPostal.Codigo;
                        ciudaux = codigoPostal.Ciudad;
                        munaux = codigoPostal.Municipio;
                        idesaux = codigoPostal.IdEstado;
                    }
                    return Json(_codigosPostales, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("No fue posible encontrar tu CP.", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(ex.Message, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult ObtenerAsentamientos(string CodigoPostal)
        {
            List<CodigoPostal> asentamientos = (from cp in db.CatCodigoPostal.Where(x => x.Codigo.Equals(CodigoPostal))
                                                select cp).ToList();

            List<object> _asentamientos = new List<object>();
            foreach (CodigoPostal asentamiento in asentamientos)
            {
                _asentamientos.Add(
                    new
                    {
                        asentamiento.Id,
                        asentamiento.Asentamiento
                    });
            }

            return Json(_asentamientos, JsonRequestBehavior.AllowGet);
        }

        public void construyeInformacionAuto(CotizacionAuto CotAuto, CotizacionDetalle cotDetalle, string paqueteCotizacion, Aseguradora aseguradora, string FormaPago, string medioPago)
        {
            var convenio = db.Convenio.FirstOrDefault(a => a.Id == cotDetalle.IdConvenio);
            var _empresasAPI = Utilidades.ObtienerValorParametro("ABAChub_Empresa_API");
            var _abaAPI = false;

            if (!string.IsNullOrEmpty(_empresasAPI))
            {
                var _listaEmpresasAPI = _empresasAPI.Split('|');
                _abaAPI = _listaEmpresasAPI.Any(a => a == convenio.IdEmpresa.ToString());
            }

            if (_abaAPI)
            {
                LocktonServicios.Aseguradoras.Chubb.ChubbService aba = null;

                if (!esProduccion)
                    aba = new LocktonServicios.Aseguradoras.Chubb.ChubbService();
                else
                    aba = new LocktonServicios.Aseguradoras.Chubb.ChubbService(convenio.Usuario, convenio.Contrasena);

                var infoCompara = aba.LeeXmlRespuesta(cotDetalle.XMLRecepcion, cotDetalle.XMLSolicitud, convenio);

                ViewBag.Año = CotAuto.Agnio;
                ViewBag.FechaInicio = infoCompara.FechaInicio;
                ViewBag.FechaFin = infoCompara.FechaFin;
                ViewBag.Vehiculo = CotAuto.ObtieneDescVehiculo();
                ViewBag.Descripcion = CotAuto.ObtieneDescVehiculo();
                ViewBag.Aseguradora = aseguradora.Nombre;
                ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(infoCompara.PrimaTotal).ToString("C", CultureInfo.CurrentCulture), " MXN");
                ViewBag.FormaDePago = FormaPago;
                ViewBag.MedioDePago = medioPago;
                ViewBag.PrimerPago = string.Concat(infoCompara.PrimerPago, " MXN");
                ViewBag.NumPagos = infoCompara.NumeroDePagos - 1;
                ViewBag.TotalPorRecibo = string.Concat(infoCompara.SegundoPago, " MXN");
            }
            else
            {
                ABACHUBBService aba = new ABACHUBBService();
                XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
                xmlCotizacionSeleccionada.LoadXml(cotDetalle.XMLSolicitud);

                LocktonServicios.aba.cotizacion.response.COT cotResult = aba.ToObject<LocktonServicios.aba.cotizacion.response.COT>(cotDetalle.XMLRecepcion);
                string primeroPago = Convert.ToDecimal(cotResult.INCISOS[0].RECIBOS[0].PTOTAL).ToString("C", CultureInfo.CurrentCulture);
                string totalPorRecibo = cotResult.INCISOS[0].RECIBOS.Count() > 1 ? Convert.ToDecimal(cotResult.INCISOS[0].RECIBOS[1].PTOTAL).ToString("C", CultureInfo.CurrentCulture) : primeroPago;
                string descripcionAuto = CotAuto.ObtieneDescVehiculo();
                DateTime inicio = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("COT/DG/INIVIG")[0].InnerText);
                DateTime fin = Convert.ToDateTime(xmlCotizacionSeleccionada.SelectNodes("COT/DG/FINVIG")[0].InnerText);
                ViewBag.Año = xmlCotizacionSeleccionada.SelectNodes("COT/INCISOS/INCISO/MOD")[0].InnerText;

                ViewBag.FechaInicio = inicio.ToString("dd/MM/yyyy");
                ViewBag.FechaFin = fin.ToString("dd/MM/yyyy");
                ViewBag.Vehiculo = descripcionAuto;
                ViewBag.Descripcion = descripcionAuto;
                ViewBag.Aseguradora = aseguradora.Nombre;
                ViewBag.PrimaTotal = string.Concat(Convert.ToDecimal(cotResult.PTOTAL).ToString("C", CultureInfo.CurrentCulture), " MXN");
                ViewBag.FormaDePago = FormaPago;
                ViewBag.MedioDePago = medioPago;
                ViewBag.PrimerPago = string.Concat(primeroPago, " MXN");
                ViewBag.NumPagos = cotResult.INCISOS[0].RECIBOS.Count() > 1 ? cotResult.INCISOS[0].RECIBOS.Count() - 1 : cotResult.INCISOS[0].RECIBOS.Count();
                ViewBag.TotalPorRecibo = string.Concat(totalPorRecibo, " MXN");
            }
        }

        public void construyeViewbagEmision(Aseguradora aseguradora, int idConvenio, int idEmpresa, int idcotizaciondetalle)
        {
            log.Info("Crea variables en el viewBag para la vista del usuario.");
            int anioF = DateTime.Now.AddYears(10).Year;
            List<int> anios = new List<int>();
            for (int anioI = DateTime.Now.Year; anioI <= anioF; anioI++)
            {
                anios.Add(anioI);
            }

            ViewBag.IdBanco = new SelectList((from aseg in db.Aseguradora
                                              join bsas in db.CatBancosAseguradoras on aseg.Id equals bsas.IdAseguradora
                                              join banco in db.CatBanco on bsas.IdBanco equals banco.Id
                                              where bsas.Estatus.Equals(1) && aseg.Id.Equals(aseguradora.Id) && aseg.Estatus.Equals(1)
                                              select banco).ToList(), "BancoId", "Abreviacion");
            ViewBag.IdBanco = new SelectList((from aseg in db.Aseguradora
                                              join bsas in db.CatBancosAseguradoras on aseg.Id equals bsas.IdAseguradora
                                              join banco in db.CatBanco on bsas.IdBanco equals banco.Id
                                              where bsas.Estatus.Equals(1) && aseg.Id.Equals(aseguradora.Id) && aseg.Estatus.Equals(1)
                                              select banco).ToList(), "BancoId", "Abreviacion");
            var catBancoConvenio = db.CatBancosAseguradoraExclusivo.Where(a => a.IdConvenio == idConvenio).ToList();

            ViewBag.IdAnio = new SelectList(anios);
            if (aseguradora.Id == 5)
            {
                var _beneficiarios = db.CatBeneficiarioPreferente.Where(x => x.IdAseguradora == aseguradora.Id && x.IdEmpresa == idEmpresa).ToList();
                ViewBag.IdBeneficiarioPreferente = new SelectList(_beneficiarios, "Id", "Nombre");
            }
            else
            {
                ViewBag.IdBeneficiarioPreferente = aseguradora.Nombre == "INBURSA" ? new SelectList(db.CatBeneficiarioPreferente.Where(x => x.IdAseguradora == aseguradora.Id), "Id", "Nombre") : new SelectList(db.CatBeneficiarioPreferente.Where(x => x.IdAseguradora == aseguradora.Id), "Clave", "Nombre");
            }
            if (catBancoConvenio != null && catBancoConvenio.Count > 0)
                ViewBag.IdBanco = new SelectList((from bsas in catBancoConvenio
                                                  join banco in db.CatBanco on bsas.IdBanco equals banco.Id
                                                  select banco).ToList(), "BancoId", "Abreviacion");

            if (aseguradora.Id == 27)
            {
                var servicioANA = new ANAServices();
                var _bancos = servicioANA.ObtenerBancos(idConvenio, idcotizaciondetalle);

                ViewBag.IdBanco = new SelectList(_bancos, "BancoId", "Abreviacion");
            }

            ViewBag.IdAnio = new SelectList(anios);
            if (aseguradora.Id == 5)
            {
                var _beneficiarios = db.CatBeneficiarioPreferente.Where(x => x.IdAseguradora == aseguradora.Id && x.IdEmpresa == idEmpresa).ToList();
                ViewBag.IdBeneficiarioPreferente = new SelectList(_beneficiarios, "Id", "Nombre");
            }
            else
            {
                ViewBag.IdBeneficiarioPreferente = aseguradora.Nombre == "INBURSA" ? new SelectList(db.CatBeneficiarioPreferente.Where(x => x.IdAseguradora == aseguradora.Id), "Id", "Nombre") : new SelectList(db.CatBeneficiarioPreferente.Where(x => x.IdAseguradora == aseguradora.Id), "Clave", "Nombre");
            }

            ViewBag.IdEstado = new SelectList(db.CatEstadosRepublica, "Id", "Estado");
            // ViewBag.IdNacionalidad = new SelectList(db.CatNacionalidad, "Id", "Nacionalidad");
            //ViewBag.IdugarNacimiento = new SelectList(db.CatNacionalidad, "Id", "Nacionalidad");
            //List<CatParentesco> catParentesco = db.CatParentesco.ToList();
            List<CatParentesco> catParentesco = (from CatParentesco in db.CatParentesco
                                                 join ConvenioParentesco in db.ConvenioParentesco on CatParentesco.Id equals ConvenioParentesco.IdParentesco
                                                 where ConvenioParentesco.IdConvenio == idConvenio && ConvenioParentesco.Estatus == 1
                                                 select CatParentesco).ToList();

            ViewBag.MuestraParentesco = true;

            if (catParentesco.Count == 0)
            {
                catParentesco = db.CatParentesco.ToList();
                ViewBag.MuestraParentesco = false;
            }
            ViewBag.IdParentesco = new SelectList(catParentesco, "Id", "Nombre", catParentesco.FirstOrDefault().Id);
            ViewBag.IdNacionalidad = new SelectList(
                new List<SelectListItem>
                {
                    new SelectListItem { Text = "Seleccione", Value = "99999"},
                    new SelectListItem { Text = "Mexicana", Value = "Mexicana"}
                }, "Value", "Text", "Mexicana");

            ViewBag.IdugarNacimiento = new SelectList(
                new List<SelectListItem>
                {
                    new SelectListItem { Text = "Seleccione", Value = "99999"},
                    new SelectListItem { Text = "México", Value = "México"},
                    new SelectListItem { Text = "Otros", Value = "Otros"}
                }, "Value", "Text", "México");
            ViewBag.IdAsentamiento = new SelectList(
                new List<SelectListItem>
                {
                    new SelectListItem {Text = "Seleccione", Value = "99999"}
                }, "Value", "Text");
            string usuario = (User.Identity as System.Security.Claims.ClaimsIdentity).FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier).Value;
            int perfil = db.DetalleUsuario.Where(x => x.IdUsuario == usuario).FirstOrDefault().IdPerfil;
            if (perfil != 3)
            {
                ViewBag.AccesoBeneficiario = db.AccesoBeneficiarioPreferente.Where(x => x.IdConvenio == idConvenio & x.Estatus == 1).ToList().Count() > 0 ? true : false;
            }
            else
            {
                ViewBag.AccesoBeneficiario = db.AccesoBeneficiarioPreferente.Where(x => x.IdConvenio == idConvenio & x.Estatus == 1 && x.IdCatAccesoBeneficiarioPreferente == 3).ToList().Count() > 0 ? true : false;
            }

        }

        #endregion

        #region 4 emision

        private void RegistraLogInfoEmision(InformacionEmision InfoEmision, string desc)
        {
            try
            {
                var jsonInfo = JsonConvert.SerializeObject(InfoEmision);

                if (InfoEmision.Tarjeta != null && !string.IsNullOrEmpty(InfoEmision.Tarjeta.NumeroTarjeta))
                {
                    var num = InfoEmision.Tarjeta.NumeroTarjeta;
                    var cvv = InfoEmision.Tarjeta.Cvv;

                    InfoEmision.Tarjeta.NumeroTarjeta = "****";
                    InfoEmision.Tarjeta.Cvv = "***";

                    jsonInfo = JsonConvert.SerializeObject(InfoEmision);

                    InfoEmision.Tarjeta.NumeroTarjeta = num;
                    InfoEmision.Tarjeta.Cvv = cvv;

                }

                log.Info($"{desc} {jsonInfo}");

            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
        }

        public ActionResult CotizacionEmision(InformacionEmision InfoEmision)
        {
            var logValidacion = "";

            try
            {
                logValidacion = "json InfoEmision";

                RegistraLogInfoEmision(InfoEmision, "CotizacionEmisiom - InfoEmision al iniciar:");

                string tituloError = InfoEmision.Aseguradora == "INBURSA" ? "Error al Procesar Solicitud" : "Error al Emitir póliza";

                logValidacion = "PersonaMoral validar edad";

                if (InfoEmision.IdTipoDeNegocio != 6 && InfoEmision.IdTipoDeNegocio != 5)
                {

                    DateTime now = DateTime.Today;
                    int age = now.Year - InfoEmision.FechaNacimiento.Year;
                    if (InfoEmision.FechaNacimiento > now.AddYears(-age)) age--;

                    if (age != InfoEmision.Edad
                        && (!InfoEmision.EsFlotilla && !InfoEmision.EmisionPersonaMoral)
                        && InfoEmision.IdTipoDeNegocio != 3) //DIFERENTE A INDIVIDUAL - MENOS CAMPOS
                    {
                        //TempData["__INFORMACION_EMISION_COTIZACIONINFORMACION__"] = InfoEmision;
                        //return RedirectToAction("CotizacionInformacion", "Cotizacion", new { InfoEmision.IdCotizacion, InfoEmision.Aseguradora, EsError = true, Titulo = tituloError, Msj = "La fecha de nacimiento no corresponde con la edad especificada en la cotización (" + InfoEmision.Edad + " años).", Icono = "error", emisionPersonaMoral = InfoEmision.EmisionPersonaMoral });

                        InfoEmision = GenerateViewsEmision(InfoEmision, EsError: true, Titulo: tituloError, Msj: "La fecha de nacimiento no corresponde con la edad especificada en la cotización (" + InfoEmision.Edad + " años).", Icono: "error");
                        return View("CotizacionInformacion", InfoEmision);

                    }
                    string _fecha = InfoEmision.FechaNacimiento.ToString("yyMMdd");
                    string _rfc = "";
                    if (InfoEmision.EsFlotilla)
                        _rfc = InfoEmision.Empresa.RFC;
                    else
                        _rfc = InfoEmision.DatosUsuario.RFC;
                    if (!InfoEmision.EsFlotilla && !_rfc.Contains(_fecha))
                    {
                        //TempData["__INFORMACION_EMISION_COTIZACIONINFORMACION__"] = InfoEmision;
                        //return RedirectToAction("CotizacionInformacion", "Cotizacion", new { InfoEmision.IdCotizacion, InfoEmision.Aseguradora, EsError = true, Titulo = tituloError, Msj = "La fecha de nacimiento no corresponde con el RFC.", Icono = "error", emisionPersonaMoral = InfoEmision.EmisionPersonaMoral });


                        InfoEmision = GenerateViewsEmision(InfoEmision, EsError: true, Titulo: tituloError, Msj: "La fecha de nacimiento no corresponde con el RFC.", Icono: "error");
                        return View("CotizacionInformacion", InfoEmision);


                    }
                }

                logValidacion = "obtener informacion de usuario";

                Poliza poliza = new Poliza();
                bool usuarioAlias = false;
                DetalleUsuario detalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
                //log.Info("Encuentra la cotización seleccionada.");
                CotizacionDetalle cotizacion = db.CotizacionDetalle.Find(InfoEmision.IdCotizacion);
                //int Periodicidad = db.Cotizacion.Where(x => x.Id == cotizacion.IdCotizacion).Select(y => y.IdPeriodicidadPago).FirstOrDefault();
                //log.Info("Genera las consultas e información para el objeto de la emisión.");
                var UserIdentity = User.Identity.GetUserId();
                var _UserIdentity = db.DetalleUsuario.FirstOrDefault(a => a.IdUsuario == UserIdentity);
                CotizacionAuto cotizacionauto = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion));
                if (_UserIdentity.IdPerfil == 3)
                    InfoEmision.ConDatosBancarios = true;
                else if ((_UserIdentity.IdPerfil.Equals(2) || _UserIdentity.IdPerfil.Equals(6) || _UserIdentity.IdPerfil.Equals(4)) && (cotizacionauto.MediodePago == 2 || cotizacionauto.MediodePago == 7))
                    InfoEmision.ConDatosBancarios = true;

                logValidacion = "construccion de objeto de emision";

                ConstruirObjetoEmision(InfoEmision, cotizacion);
                EmisionPolizaClient emisionPolizaClient = new EmisionPolizaClient();

                //Validaciones 
                logValidacion = "ValidarInfoEmision";

                log.Info("Llama al método a ValidarInfoEmision");
                string validacion = ValidarInfoEmision(InfoEmision, cotizacion);
                log.Info("termina de llamar al método a ValidarInfoEmision");

                if (!string.IsNullOrEmpty(validacion))
                {
                    logValidacion = "error en validacion: " + validacion;
                    //TempData["__INFORMACION_EMISION_COTIZACIONINFORMACION__"] = InfoEmision;
                    TempData["__ERROR_VALIDACION_EMISION__"] = validacion;
                    //return RedirectToAction("CotizacionInformacion", "Cotizacion", new { InfoEmision.IdCotizacion, InfoEmision.Aseguradora, EsError = true, Titulo = tituloError, Msj = "", Icono = "error", emisionPersonaMoral = InfoEmision.EmisionPersonaMoral });

                    InfoEmision = GenerateViewsEmision(InfoEmision, EsError: true, Titulo: tituloError, Msj: validacion, Icono: "error");
                    return View("CotizacionInformacion", InfoEmision);

                }

                //Agregar Persona Moral
                logValidacion = "AgregarPersonaMoral";

                if ((InfoEmision.IdTipoDeNegocio == 5 || InfoEmision.IdTipoDeNegocio == 6) && InfoEmision.EmisionPersonaMoral)
                {

                    validacion = AgregarPersonaMoral(ref InfoEmision);
                }

                if (!string.IsNullOrEmpty(validacion))
                {

                    logValidacion = "error en validacion 2: " + validacion;

                    //TempData["__INFORMACION_EMISION_COTIZACIONINFORMACION__"] = InfoEmision;
                    TempData["__ERROR_VALIDACION_EMISION__"] = validacion;
                    //return RedirectToAction("CotizacionInformacion", "Cotizacion", new { InfoEmision.IdCotizacion, InfoEmision.Aseguradora, EsError = true, Titulo = "Error al Emitir póliza", Msj = "", Icono = "error", emisionPersonaMoral = InfoEmision.EmisionPersonaMoral });

                    InfoEmision = GenerateViewsEmision(InfoEmision, EsError: true, Titulo: "Error al Emitir póliza", Msj: validacion, Icono: "error");
                    return View("CotizacionInformacion", InfoEmision);
                }

                RegistraLogInfoEmision(InfoEmision, "CotizacionEmisiom - InfoEmision al emitir:");

                logValidacion = "EmitirPoliza";

                EmisionPoliza emision = null;
                if (cotizacion.CotizacionCero)
                    emision = emisionPolizaClient.EmitirCeroPoliza(InfoEmision);
                else
                    emision = emisionPolizaClient.EmitirPoliza(InfoEmision, User.Identity.GetUserId()); //


                if (emision.Respuesta)
                {
                    log.Info("La emisión de la póliza respondió de forma exitosa. Se procede a generar el cobro.");
                    bool bError = false;
                    bool EntrarOpl = true;
                    string sError = string.Empty;
                    string sNegritas = string.Empty;
                    Contratante contratanteConsulta = new Contratante();

                    if (InfoEmision.EsRenovacion)
                    {
                        //log.Info("Modifica la renovación de la póliza, IdCotizacion " + cotizacion.IdCotizacion.ToString());
                        ModificarRenovacion(cotizacion.IdCotizacion);
                    }
                    else
                    {
                        ModificarRenovacion_Cotizacion(cotizacion.IdCotizacion, cotizacion.Id, InfoEmision.NumeroSerie.Trim(), InfoEmision.Empresa.Id);
                    }

                    /*
                     * Inicia  Deriva usuario contratante Core
                     */
                    InfoEmision.EsPromotor = InfoEmision.Convenio.AplicaPromotores != null ? (bool)InfoEmision.Convenio.AplicaPromotores : false;
                    //if (InfoEmision.EsPromotor)
                    //{
                    ConfiguracionEmpresa ce = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa.Equals(InfoEmision.Empresa.Id));
                    if (InfoEmision.EmisionPersonaMoral)
                    {
                        contratanteConsulta = db.Contratante.Where(x => x.RFC == InfoEmision.PersonaMoral.RFC).FirstOrDefault();
                        if (contratanteConsulta != null)
                        {
                            contratanteConsulta.Nombre = InfoEmision.PersonaMoral.NombreComercial;
                            contratanteConsulta.CodigoPostal = string.IsNullOrEmpty(InfoEmision.PersonaMoral.Direccion.CodigoPostal) ? "" : InfoEmision.PersonaMoral.Direccion.CodigoPostal;
                            db.Entry(contratanteConsulta).State = EntityState.Modified;
                            db.SaveChanges();
                        }
                    }
                    if (InfoEmision.Convenio.IdCatTipoContratante == 1 && ce.IdTipoDeNegocio == 1)
                    {
                        contratanteConsulta = db.Contratante.Where(x => x.RFC == InfoEmision.Empresa.RFC).FirstOrDefault();
                        if (contratanteConsulta != null)
                        {
                            contratanteConsulta.Nombre = InfoEmision.Empresa.NombreComercial;
                            contratanteConsulta.CodigoPostal = string.IsNullOrEmpty(InfoEmision.Empresa.Direccion.CodigoPostal) ? "" : InfoEmision.Empresa.Direccion.CodigoPostal;
                            db.Entry(contratanteConsulta).State = EntityState.Modified;
                            db.SaveChanges();
                        }
                    }
                    else
                    {
                        contratanteConsulta = db.Contratante.Where(x => x.RFC == InfoEmision.DatosUsuario.RFC).FirstOrDefault();
                        if (contratanteConsulta != null && !string.IsNullOrEmpty(contratanteConsulta.RFC) && InfoEmision.DatosUsuario.Direccion != null)
                        {
                            contratanteConsulta.Nombre = InfoEmision.PrimerNombre;
                            contratanteConsulta.SegundoNombre = InfoEmision.SegundoNombre;
                            contratanteConsulta.ApellidoPaterno = InfoEmision.ApellidoPaterno;
                            contratanteConsulta.ApellidoMaterno = InfoEmision.ApellidoMaterno;
                            contratanteConsulta.Email = InfoEmision.Email;
                            contratanteConsulta.telefonoCel = InfoEmision.TelefonoCel;
                            contratanteConsulta.telefonoFijo = InfoEmision.TelefonoFijo;
                            contratanteConsulta.CodigoPostal = string.IsNullOrEmpty(InfoEmision.DatosUsuario.Direccion.CodigoPostal) ? "" : InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                            db.Entry(contratanteConsulta).State = EntityState.Modified;
                            db.SaveChanges();
                        }

                    }


                    //consulta contratante
                    if (contratanteConsulta != null)
                    {
                        InfoEmision.Contratante = contratanteConsulta;
                    }
                    else
                    {
                        AccountController contratante = new AccountController();
                        //genera objecto del contratante 
                        Contratante contratanteUsuario = contratante.GeneraContratante(InfoEmision);
                        if (contratanteUsuario != null)
                        {
                            //genera credenciales
                            string usuario = (InfoEmision.Empresa.NombreComercial.Substring(0, 2) + contratanteUsuario.Id).ToString();
                            string password = (InfoEmision.Empresa.NombreComercial.Substring(0, 2) + contratanteUsuario.Id + "$").Trim().ToString();
                            //deriva usuario al core
                            contratante.DerivaUsuarioFinalContratanteCore(contratanteUsuario, password, InfoEmision.Empresa, usuario);
                            //consulta el usuario actualizado
                            contratanteConsulta = db.Contratante.Where(x => x.Id == contratanteUsuario.Id).FirstOrDefault();
                            // Agrega el idCont del contratante al info para la derivación de la poliza
                            InfoEmision.Contratante = contratanteConsulta;

                        }
                        // }
                    }

                    /*
                     * Termina Derivacion usuario contratante  Core
                     */

                    InfoEmision.XmlsAseguradoras.Add("EmisionSolicitud", emision.SolicitudServicio);
                    InfoEmision.XmlsAseguradoras.Add("EmisionRecepcion", emision.RespuestaServicio);
                    InfoEmision.RutaDescargaPDFsPolizas = Server.MapPath(@"~/Repositorio/Documentos/");
                    InfoEmision.IdBenefCore = 0;

                    if (emision.Poliza != null
                        && !string.IsNullOrEmpty(emision.Poliza.NumeroPoliza)
                        && !string.IsNullOrEmpty(emision.Poliza.UrlPDFPoliza))
                    {
                        TempData["__URL__POLIZA__PDF__"] = emision.Poliza.UrlPDFPoliza;
                    }

                    if ((Session["__USUARIO__MODULO__RENOVACIONES__"] != null
                        && Convert.ToBoolean(Session["__USUARIO__MODULO__RENOVACIONES__"].ToString()))
                        || (Session["__USUARIO__LOGUEORAPIDO__"] != null && Convert.ToBoolean(Session["__USUARIO__LOGUEORAPIDO__"].ToString())))
                    {
                        if (emision.Poliza != null
                            && !string.IsNullOrEmpty(emision.Poliza.NumeroPoliza))
                        {
                            Session["__USUARIO__MODULO__RENOVACIONES__POLIZAEMITIDA__"] = emision.Poliza.NumeroPoliza;

                            if (Session["__USUARIO__LOGUEORAPIDO__"] == null)
                            {
                                var idDocto = Convert.ToInt32(Session["__USUARIO__MODULO__RENOVACIONES__IdDocto__"].ToString());

                                ModificaNotificacionRenovacion(idDocto, emision.Poliza.NumeroPoliza);
                            }
                        }

                    }

                    ReimpresionPolizasController urlReimpresionGNP = new ReimpresionPolizasController();
                    switch (InfoEmision.Aseguradora)
                    {
                        case "QUALITAS":
                            #region QUALITAS

                            if (cotizacion.CotizacionCero)
                            {
                                InfoEmision.Poliza = emision.Poliza;

                                if (InfoEmision.IdBeneficiarioPreferente != null || InfoEmision.IdBeneficiarioPreferente != "0")
                                {
                                    int idbenef = 0;
                                    CatBeneficiarioPreferente benefCore;
                                    if (int.TryParse(InfoEmision.IdBeneficiarioPreferente, out idbenef))
                                    {
                                        benefCore = db.CatBeneficiarioPreferente.Where(x => x.Id == idbenef).FirstOrDefault();
                                        InfoEmision.IdBenefCore = benefCore != null ? benefCore.IdBenefCore != null ? benefCore.IdBenefCore : 0 : 0;
                                    }
                                    else
                                    {
                                        InfoEmision.IdBenefCore = 0;
                                    }


                                }

                                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id, EmpresaId: InfoEmision.Empresa.Id);
                                DerivarOTCore(InfoEmision);
                                InfoEmision.Poliza = db.Poliza.FirstOrDefault(a => a.Id == emision.Poliza.Id);
                                ActualizaPolizaEmision(emision.Poliza.Id);

                                EnviarCorreoSolicitudAlContratante(InfoEmision);
                                return RedirectToAction("ResultEmisionOT", "Cotizacion", new { id = InfoEmision.Poliza.Id, aseg = InfoEmision.Aseguradora });
                            }
                            else
                            {
                                //log.Info("Deserealiza los datos del XML recibido.");
                                Movimientos respuestaEmisionQualitas = null;
                                XmlSerializer serializer = new XmlSerializer(typeof(Movimientos));
                                using (StringReader reader = new StringReader(emision.RespuestaServicio.OuterXml))
                                {
                                    respuestaEmisionQualitas = (Movimientos)(serializer.Deserialize(reader));
                                }
                                InfoEmision.NoPoliza = respuestaEmisionQualitas.Items[0].NoPoliza.Substring(2, 10);
                                TempData["__NumeroPoliza__Emitida__"] = InfoEmision.NoPoliza;

                                if ((Session["__USUARIO__MODULO__RENOVACIONES__"] != null
                                     && Convert.ToBoolean(Session["__USUARIO__MODULO__RENOVACIONES__"].ToString()))
                                     || (Session["__USUARIO__LOGUEORAPIDO__"] != null && Convert.ToBoolean(Session["__USUARIO__LOGUEORAPIDO__"].ToString())))
                                {
                                    {
                                        Session["__USUARIO__MODULO__RENOVACIONES__POLIZAEMITIDA__"] = InfoEmision.NoPoliza;

                                        if (Session["__USUARIO__LOGUEORAPIDO__"] == null)
                                        {
                                            var idDocto = Convert.ToInt32(Session["__USUARIO__MODULO__RENOVACIONES__IdDocto__"].ToString());

                                            ModificaNotificacionRenovacion(idDocto, InfoEmision.NoPoliza);
                                        }
                                    }
                                }
                                //string periodicidad = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales/FormaPago")[0].InnerText;
                                string medioPago = InfoEmision.CotizacionAutoGuardar.MediodePago.ToString();
                                string claveAgente = respuestaEmisionQualitas.Items[0].DatosGenerales[0].Agente;
                                PeriodicidadFormaPago periodicidadFormaPago = new PeriodicidadFormaPago();
                                if (InfoEmision.Convenio.IdAseguradora == 1)
                                {
                                    periodicidadFormaPago = db.PeriodicidadFormaPago.FirstOrDefault(x => x.IdConvenio.Equals(InfoEmision.Convenio.Id) && x.IdCatPeriodicidadFormaPago == cotizacion.IdFormaPago);
                                    var catModalidadPago = db.CatModalidadFormaPago.Where(x => x.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString()).FirstOrDefault();
                                    var ClaveAgenteModalidadFPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == cotizacion.IdFormaPago && x.IdCatModalidadFormaPago == catModalidadPago.Id).FirstOrDefault();
                                    EntrarOpl = ClaveAgenteModalidadFPago.EntrarOPL;
                                }
                                else
                                {
                                    periodicidadFormaPago = db.PeriodicidadFormaPago.FirstOrDefault(x => x.IdConvenio.Equals(InfoEmision.Convenio.Id) && x.IdCatPeriodicidadFormaPago == cotizacion.IdFormaPago && x.ClaveAgente.Equals(claveAgente));

                                }
                                // PeriodicidadFormaPago periodicidadFormaPago = db.PeriodicidadFormaPago.FirstOrDefault(x => x.IdConvenio.Equals(InfoEmision.Convenio.Id) && x.IdCatPeriodicidadFormaPago.Equals(Periodicidad) && x.ClaveAgente.Equals(claveAgente));
                                CatModalidadFormaPago catModalidadFormaPago = db.CatModalidadFormaPago.FirstOrDefault(x => x.Clave.Equals(medioPago));
                                //log.Info(string.Concat("Se consultaron los datos de Periodicidad: ", Periodicidad.ToString(), ", Clave de Agente: ", claveAgente, "y PeriodicidadFormaPago: ", periodicidadFormaPago.IdCatPeriodicidad));
                                if (InfoEmision.Convenio.GestorCobro != 2 && InfoEmision.ConDatosBancarios && !InfoEmision.MismosDatosBancariosEnrollment)
                                {

                                    var formaPagoCobranza = periodicidadFormaPago.FormaPagoCobranza;

                                    if (cotizacion.IdCatPeriodicidadMultianual > 0)
                                    {
                                        var multianual = db.PeriodicidadMultianual.FirstOrDefault(a => a.IdCatPeriodicidadMultianual == cotizacion.IdCatPeriodicidadMultianual && a.IdConvenio == InfoEmision.Convenio.Id && a.IdCatPeriodicidadFormaPago == periodicidadFormaPago.IdCatPeriodicidadFormaPago);
                                        if (multianual != null)
                                            formaPagoCobranza = multianual.FormaPago;
                                    }

                                    RespuestaCobranza LanzateACobrarVato = YLoQuieroAlCentavoPrro(InfoEmision, respuestaEmisionQualitas, formaPagoCobranza, claveAgente, emisionPolizaClient);
                                    bError = LanzateACobrarVato.bError;
                                    sError = LanzateACobrarVato.sError;
                                    sNegritas = LanzateACobrarVato.sNegritas;
                                }
                                //else if (!InfoEmision.ConDatosBancarios && (_UserIdentity.IdPerfil == 2 || _UserIdentity.IdPerfil == 6 || _UserIdentity.IdPerfil == 4))
                                //{
                                //    if (InfoEmision.Empresa.TicketZendesk)
                                //        PloomesProxy.TicketEmisionSinDatoBancario(InfoEmision);

                                //}


                                //log.Info(string.Concat("Resultado de la cobranza: ", bError, " Mensaje: ", sError));

                                //log.Info("Se sobreescribe el paquete del objeto InfoEmision por los ids de la base de datos de CotizacionDetalle y CatTipoPaquete.");
                                InfoEmision.Paquete = cotizacion.Paquete; //Se sobrescribe por los Ids de la base de datos de CotizacionDetalle y CatTipoPaquete

                                int paqueteCotizacion = db.CatTipoPaquete.Where(x => x.Id.ToString().Equals(InfoEmision.Paquete)).FirstOrDefault().Id;

                                Endoso endosoAlta = ConstruirEndoso();

                                List<Recibo> recibos = GenerarListaRecibosQualitas(respuestaEmisionQualitas, InfoEmision);
                                AgregarListaRecibos(endosoAlta, recibos);
                                PolizaDetalle polizaDetalle = new PolizaDetalle();

                                polizaDetalle = ConstuirPolizaDetalle(paqueteCotizacion, 16, 0, Convert.ToDecimal(respuestaEmisionQualitas.Items[0].Primas[0].Recargo), Convert.ToDecimal(respuestaEmisionQualitas.Items[0].Primas[0].Impuesto), Convert.ToDecimal(respuestaEmisionQualitas.Items[0].Primas[0].Comision), periodicidadFormaPago.IdCatPeriodicidadFormaPago, InfoEmision);

                                //log.Info("Comienza el proceso de impresión de la carátula de la póliza.");

                                List<string> reimpresion =
                                   ReimpresionPoliza(
                                       InfoEmision.NoPoliza,
                                       respuestaEmisionQualitas.Items[0].NoNegocio,
                                       respuestaEmisionQualitas.Items[0].DatosGenerales[0].Agente,
                                       emisionPolizaClient
                                       );


                                //log.Info(string.Concat("Procede al guardado de la póliza: ", InfoEmision.NoPoliza));

                                poliza =
                                    GuardarInformacionPoliza(
                                        InfoEmision,
                                        Convert.ToDateTime(respuestaEmisionQualitas.Items[0].DatosGenerales[0].FechaInicio),
                                        Convert.ToDateTime(respuestaEmisionQualitas.Items[0].DatosGenerales[0].FechaTermino),
                                        DateTime.Now,
                                        Convert.ToDecimal(respuestaEmisionQualitas.Items[0].Primas[0].PrimaNeta),
                                        Convert.ToDecimal(respuestaEmisionQualitas.Items[0].Primas[0].PrimaTotal),
                                        bError,
                                        InfoEmision.DetalleUsuario == null ? detalleUsuario.Id : InfoEmision.DetalleUsuario.Id,
                                        paqueteCotizacion,
                                        polizaDetalle,
                                        endosoAlta);

                                if (reimpresion.Count > 0)
                                {
                                    poliza.UrlPDFPoliza = reimpresion[0] ?? "";
                                    poliza.UrlPDFRecibos = reimpresion[1] ?? "";
                                    //log.Info(string.Concat("Recuperó los siguientes documentos del servicio Poliza: ",
                                }
                                if (!string.IsNullOrEmpty(poliza.UrlPDFPoliza))

                                {
                                    TempData["__URL__POLIZA__PDF__"] = poliza.UrlPDFPoliza;
                                }

                                InfoEmision.Poliza = poliza;
                                ReimpresionPolizasController urlReimpresion = new ReimpresionPolizasController();

                                db.SaveChanges();

                                ActualizaPolizaEmision(poliza.Id);

                                if (InfoEmision.RequiereFactura)
                                {
                                    var respuestaFacturacion = new QUALITAService().ResultadoFacturacion(poliza.Id);

                                    if (!respuestaFacturacion.Exitoso)
                                    {
                                        bError = true;
                                        sError += $" {respuestaFacturacion.Mensaje}";
                                    }
                                }

                                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: poliza.Id, EmpresaId: InfoEmision.Empresa.Id);

                                Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                                //PolizaAliasLog(poliza.NumeroPoliza);

                                InfoEmision.UrlReimpresionEncriptada = urlReimpresion.GeneraUrlEncriptada(poliza.NumeroPoliza.ToString());

                                //if (InfoEmision.Convenio.GestorCobro == 2 && (InfoEmision.CotizacionAutoGuardar.MediodePago == 0 || InfoEmision.CotizacionAutoGuardar.MediodePago == 1))
                                //{
                                //    DerivarPolizaCore(InfoEmision);
                                //    DerivarPolizaOpera(poliza);
                                //    EnviarCorreoAlContratante(InfoEmision);
                                //    return RedirectToAction("PagoMit", new { polID = poliza.Id, llamado = "emision" });
                                //}
                            }
                            break;
                        #endregion
                        case "ABA":
                            #region ABA

                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;

                            InfoEmision.Poliza = emision.Poliza;
                            ActualizaPolizaEmision(emision.Poliza.Id);
                            ReimpresionPolizasController urlReimpresionABA = new ReimpresionPolizasController();
                            InfoEmision.UrlReimpresionEncriptada = urlReimpresionABA.GeneraUrlEncriptada(emision.Poliza.NumeroPoliza.ToString());
                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id, EmpresaId: InfoEmision.Empresa.Id);

                            //DerivarPolizaCore(InfoEmision);

                            //DerivarPolizaOpera(InfoEmision.Poliza);

                            //PolizaAliasLog(InfoEmision.Poliza.NumeroPoliza);

                            EnviarCorreoAlContratante(InfoEmision);

                            if (InfoEmision.EsBeneficiarioPreferente)
                            {
                                Cotizar cotizar = new Cotizar();
                                cotizar.EnvioCorreoBP_Chubb(InfoEmision);
                            }
                            if (InfoEmision.Convenio.GestorCobro == 2 && InfoEmision.ConDatosBancarios)
                            {
                                return RedirectToAction("PagoMit", new { polID = emision.Poliza.Id, llamado = "emision" });
                            }
                            else if ((InfoEmision.CotizacionAutoGuardar.MediodePago == 2 || InfoEmision.CotizacionAutoGuardar.MediodePago == 7))
                            {
                                TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito."), EsError = false }*/);
                            }
                            if (InfoEmision.ConDatosBancarios)
                                return RedirectToAction("PagoTarjetaABA", new { polID = emision.Poliza.Id, llamado = "emision" });
                            else
                            {
                                TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                                return RedirectToAction("Index", "Polizas");
                            }
                        #endregion
                        case "GNP":
                            #region GNP
                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;
                            InfoEmision.Poliza = emision.Poliza;
                            ActualizaPolizaEmision(emision.Poliza.Id);

                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id, EmpresaId: InfoEmision.Empresa.Id);
                            bool EsPreferenteGNP = ((Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').Contains(InfoEmision.Convenio.IdEmpresa.ToString()) || Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS")) && InfoEmision.Convenio.IdCatTipoNegocio.Equals(2));
                            /*Redirección de pago con polizas individuales GNP*/
                            //if ((!InfoEmision.EsFlotilla && !EsPreferenteGNP) && (InfoEmision.CotizacionAutoGuardar.MediodePago == 0 || InfoEmision.CotizacionAutoGuardar.MediodePago == 1))
                            //{
                            //	TempData["__INFORMACION_EMISION_GNP__"] = InfoEmision;
                            //	//var empresasNuevosServiciosGNP = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNPInfoService")).Valor;
                            //	//if (empresasNuevosServiciosGNP.Split('|').Contains(InfoEmision.Empresa.Id.ToString()) || empresasNuevosServiciosGNP.Equals("TODAS"))
                            //	//{
                            //	//	return RedirectToAction("PagoTarjetaGNPNuevosServicios", new { polID = emision.Poliza.Id, noCotizacion = InfoEmision.NoCotizacion, idCotizacionDetalle = InfoEmision.IdCotizacion });
                            //	//}
                            //	//else 
                            //	//{
                            //	return RedirectToAction("PagoTarjetaGNP", new { polID = emision.Poliza.Id, noCotizacion = InfoEmision.NoCotizacion, idCotizacionDetalle = InfoEmision.IdCotizacion });
                            //	//}
                            //}
                            /*Intento de derivacion solo para flotillas*/
                            InfoEmision.UrlReimpresionEncriptada = urlReimpresionGNP.GeneraUrlEncriptada(InfoEmision.Poliza.NumeroPoliza != null ? InfoEmision.Poliza.NumeroPoliza.ToString() : "");
                            //DerivarPolizaCore(InfoEmision);

                            //DerivarPolizaOpera(InfoEmision.Poliza);

                            //PolizaAliasLog(InfoEmision.Poliza.NumeroPoliza);

                            EnviarCorreoAlContratante(InfoEmision);

                            //CAT: Conserva la poliza emitida y muestra el estandar de advertencia cuando solo falla la domiciliacion.
                            if (emision.EstatusDomiciliacion != null && !emision.EstatusDomiciliacion.Exitoso)
                            {
                                TempData["EsError"] = true.ToString();
                                TempData["MsjError"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, ", pero no fue posible registrar la domiciliación.");
                                TempData["MsNegritas"] = "Intenta nuevamente desde Mis Pólizas, en la opción Registrar Datos Bancarios, o contacta a tu asesor de servicio.";
                                return RedirectToAction("Index", "Polizas");
                            }

                            if (InfoEmision.Poliza.NumeroPoliza != null)
                            {
                                TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito."), EsError = false }*/);

                            }
                            else
                            {
                                TempData["EsError"] = true.ToString();
                                TempData["MsjExito"] = string.Concat("Tuvimos inconveniente al generar tu poliza");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjError = string.Concat("Tuvimos inconveniente al generar tu poliza"), EsError = true }*/);

                            }

                            break;
                        #endregion
                        case "AXA":
                            #region AXA
                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;
                            poliza = db.Poliza.FirstOrDefault(a => a.Id == emision.Poliza.Id);
                            InfoEmision.Poliza = poliza;
                            ActualizaPolizaEmision(emision.Poliza.Id);
                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id, EmpresaId: InfoEmision.Empresa.Id);
                            if (!InfoEmision.Convenio.AxaEspecial && poliza != null)
                            {
                                AXAService aXAService = new AXAService();
                                if (!string.IsNullOrEmpty(poliza.NumeroPoliza))
                                {
                                    string reimpresion = aXAService.ReimprimePolizaAXAPool(poliza.NumeroPoliza, poliza.Convenio.Usuario, poliza.Convenio.Contrasena);

                                    //DerivarPolizaCore(InfoEmision);
                                    //DerivarPolizaOpera(poliza);
                                    //PolizaAliasLog(poliza.NumeroPoliza);
                                    EnviarCorreoAlContratante(InfoEmision);

                                    TempData["__URL__POLIZA__PDF__"] = reimpresion;
                                    if (InfoEmision.Poliza.NumeroPoliza != null)
                                    {
                                        TempData["EsGNP"] = true.ToString();
                                        TempData["EsAxaEspecial"] = false.ToString();
                                        TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                                        return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito."), EsError = false, EsGNP = true, EsAxaEspecial = false }*/);

                                    }
                                    else
                                    {
                                        TempData["EsError"] = true.ToString();
                                        TempData["MsjExito"] = string.Concat("Tuvimos inconveniente al generar tu poliza");
                                        return RedirectToAction("Index", "Polizas"/*, new { MsjError = string.Concat("Tuvimos inconveniente al generar tu poliza"), EsError = true }*/);

                                    }
                                }
                            }
                            break;
                        #endregion
                        case "ATLAS":
                            #region ATLAS
                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;
                            InfoEmision.Poliza = emision.Poliza;
                            poliza = emision.Poliza;
                            ActualizaPolizaEmision(emision.Poliza.Id);

                            TempData["__URL__POLIZA__PDF__"] = null;
                            TempData["__ATLAS__FILE__PDF__"] = InfoEmision.Poliza.NumeroPoliza;

                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id, EmpresaId: InfoEmision.Empresa.Id);
                            ReimpresionPolizasController urlReimpresionAtlas = new ReimpresionPolizasController();
                            ATLASService service = new ATLASService();
                            InfoEmision.UrlReimpresionEncriptada = urlReimpresionAtlas.GeneraUrlEncriptada(InfoEmision.Poliza.NumeroPoliza != null ? InfoEmision.Poliza.NumeroPoliza.ToString() : "");
                            //genera el inciso par ale core
                            PolizaDetalle detalle = db.PolizaDetalle.Where(x => x.IdPoliza == emision.Poliza.Id).FirstOrDefault();
                            if (detalle != null)
                            {

                                InfoEmision.Inciso = service.GeneraInciso(detalle.XMLRecepcion);
                            }
                            else
                            {
                                InfoEmision.Inciso = "";
                            }

                            //DerivarPolizaCore(InfoEmision);


                            //DerivarPolizaOpera(poliza);

                            //PolizaAliasLog(poliza.NumeroPoliza);

                            EnviarCorreoAlContratante(InfoEmision);
                            if (InfoEmision.Poliza.NumeroPoliza != null)
                            {
                                int IdModalidadPago = InfoEmision.Poliza.PolizaDetalle.FirstOrDefault().IdCatModalidadFormaPago;// db.PolizaDetalle.FirstOrDefault(x => x.IdPoliza == InfoEmision.Poliza.Id).IdCatModalidadFormaPago;
                                if (IdModalidadPago != 3 && IdModalidadPago != 5)
                                {
                                    var responsePasarela = service.PasarelaDePagos(InfoEmision.Poliza.NumeroPoliza);
                                    if (responsePasarela.validacion && !string.IsNullOrEmpty(responsePasarela.Url))
                                    {
                                        if (InfoEmision.ConDatosBancarios)
                                            TempData["__URL__ATLAS__PAGOS__"] = responsePasarela.Url;
                                        else
                                            TempData["__URL__ATLAS__PAGOS__"] = null;
                                    }
                                }

                                TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito."), EsError = false }*/);

                            }
                            else
                            {
                                TempData["EsError"] = true.ToString();
                                TempData["MsjExito"] = string.Concat("Tuvimos inconveniente al generar tu poliza");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjError = string.Concat("Tuvimos inconveniente al generar tu poliza"), EsError = true }*/);

                            }

                            break;
                        #endregion
                        case "INBURSA":
                            #region INBURSA
                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;
                            InfoEmision.Poliza = emision.Poliza;
                            ActualizaPolizaEmision(emision.Poliza.Id);

                            if (InfoEmision.IdBeneficiarioPreferente != null || InfoEmision.IdBeneficiarioPreferente != "0")
                            {
                                int idbenef = 0;
                                CatBeneficiarioPreferente benefCore;
                                if (int.TryParse(InfoEmision.IdBeneficiarioPreferente, out idbenef))
                                {
                                    benefCore = db.CatBeneficiarioPreferente.Where(x => x.Id == idbenef).FirstOrDefault();
                                    InfoEmision.IdBenefCore = benefCore != null ? benefCore.IdBenefCore != null ? benefCore.IdBenefCore : 0 : 0;
                                }
                                else
                                {
                                    InfoEmision.IdBenefCore = 0;
                                }


                            }

                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id, EmpresaId: InfoEmision.Empresa.Id);
                            InfoEmision.Poliza = db.Poliza.FirstOrDefault(a => a.Id == emision.Poliza.Id);

                            DerivarOTCore(InfoEmision);
                            using (var context = new ApplicationDbContext())
                            {
                                InfoEmision.Poliza = context.Poliza.FirstOrDefault(a => a.Id == emision.Poliza.Id);
                            }
                            EnviarCorreoSolicitudAlContratante(InfoEmision);
                            var idempresa = detalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;



                            return RedirectToAction("ResultEmisionOT", "Cotizacion", new { id = InfoEmision.Poliza.Id, aseg = InfoEmision.Aseguradora, idEmpresa = idempresa });
                            break;
                        #endregion
                        case "MAPFRE":
                            #region MAPFRE
                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;
                            InfoEmision.Poliza = emision.Poliza;
                            ActualizaPolizaEmision(emision.Poliza.Id);

                            InfoEmision.UrlReimpresionEncriptada = urlReimpresionGNP.GeneraUrlEncriptada(InfoEmision.Poliza.NumeroPoliza != null ? InfoEmision.Poliza.NumeroPoliza.ToString() : "");
                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id);

                            /*Intento de derivacion solo para flotillas*/
                            //DerivarPolizaCore(InfoEmision);

                            //DerivarPolizaOpera(InfoEmision.Poliza);

                            //PolizaAliasLog(InfoEmision.Poliza.NumeroPoliza);

                            try
                            {
                                EnviarCorreoAlContratante(InfoEmision);
                            }
                            catch { }

                            if (InfoEmision.Poliza.NumeroPoliza != null)
                            {
                                TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito."), EsError = false }*/);

                            }
                            else
                            {
                                TempData["EsError"] = true.ToString();
                                TempData["MsjExito"] = string.Concat("Tuvimos inconveniente al generar tu poliza");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjError = string.Concat("Tuvimos inconveniente al generar tu poliza"), EsError = true }*/);

                            }

                            break;
                        #endregion

                        case "HDI":
                            #region HDI
                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;
                            InfoEmision.Poliza = emision.Poliza;
                            ActualizaPolizaEmision(emision.Poliza.Id);

                            InfoEmision.UrlReimpresionEncriptada = urlReimpresionGNP.GeneraUrlEncriptada(InfoEmision.Poliza.NumeroPoliza != null ? InfoEmision.Poliza.NumeroPoliza.ToString() : "");
                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id);

                            /*Intento de derivacion solo para flotillas*/
                            //DerivarPolizaCore(InfoEmision);

                            //DerivarPolizaOpera(InfoEmision.Poliza);

                            //PolizaAliasLog(InfoEmision.Poliza.NumeroPoliza);

                            try
                            {
                                EnviarCorreoAlContratante(InfoEmision);
                            }
                            catch { }

                            TempData["__URL__HDI__POLIZA__"] = InfoEmision.Poliza.NumeroPoliza;
                            TempData["__URL__POLIZA__PDF__"] = null;
                            TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                            return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito."), EsError = false }*/);

                            break;
                        #endregion

                        case "BANORTE":
                            #region BANORTE
                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;
                            InfoEmision.Poliza = emision.Poliza;
                            ActualizaPolizaEmision(emision.Poliza.Id);

                            InfoEmision.UrlReimpresionEncriptada = urlReimpresionGNP.GeneraUrlEncriptada(InfoEmision.Poliza.NumeroPoliza != null ? InfoEmision.Poliza.NumeroPoliza.ToString() : "");
                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id);

                            /*Intento de derivacion solo para flotillas*/
                            //DerivarPolizaCore(InfoEmision);

                            //DerivarPolizaOpera(InfoEmision.Poliza);

                            //PolizaAliasLog(InfoEmision.Poliza.NumeroPoliza);

                            try
                            {
                                EnviarCorreoAlContratante(InfoEmision);
                            }
                            catch { }

                            TempData["__URL__BANORTE__POLIZA__"] = InfoEmision.Poliza.NumeroPoliza;
                            TempData["__URL__POLIZA__PDF__"] = null;
                            TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                            return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito."), EsError = false }*/);

                            break;
                        #endregion

                        case "ANA":

                            #region ANA

                            TempData["__NumeroPoliza__Emitida__"] = emision.Poliza.NumeroPoliza;

                            InfoEmision.Poliza = emision.Poliza;

                            ActualizaPolizaEmision(emision.Poliza.Id);

                            InfoEmision.UrlReimpresionEncriptada = urlReimpresionGNP.GeneraUrlEncriptada(InfoEmision.Poliza.NumeroPoliza != null ? InfoEmision.Poliza.NumeroPoliza.ToString() : "");
                            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.EmitirCotizacion, idPoliza: emision.Poliza.Id);

                            /*Intento de derivacion solo para flotillas*/
                            //DerivarPolizaCore(InfoEmision);

                            // DerivarPolizaOpera(InfoEmision.Poliza);

                            //PolizaAliasLog(InfoEmision.Poliza.NumeroPoliza);

                            try
                            {
                                EnviarCorreoAlContratante(InfoEmision);
                            }
                            catch { }

                            TempData["__URL__ANA__POLIZA__"] = InfoEmision.Poliza.UrlPDFPoliza;
                            TempData["__URL__POLIZA__PDF__"] = null;
                            TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, " , esta fue emitida con éxito.");
                            return RedirectToAction("Index", "Polizas");

                            break;
                            #endregion
                    }
                    var _proceso = "";
                    try
                    {
                        //_proceso = "DerivarPolizaCore";
                        //DerivarPolizaCore(InfoEmision);

                        //_proceso = "DerivarPolizaOpera";
                        //DerivarPolizaOpera(poliza);

                        //_proceso = "PolizaAliasLog";
                        //PolizaAliasLog(poliza.NumeroPoliza);

                        _proceso = "EnviarCorreoAlContratante";
                        EnviarCorreoAlContratante(InfoEmision);
                    }
                    catch (Exception ex)
                    {
                        log.Info("Error:  " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message) + " // " + _proceso);
                    }

                    //log.Info(string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza));

                    if (!bError)
                    {
                        //log.Info("Cobro exitoso.");
                        if (String.IsNullOrEmpty(InfoEmision.Poliza.NumeroPoliza))
                        {
                            if (InfoEmision.Convenio.IdAseguradora == 1)
                            {
                                if (EntrarOpl == true)
                                {
                                    TempData["EsError"] = bError.ToString();
                                    TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", emision.RespuestaServicio.SelectNodes("Movimientos/Movimiento")[0].Attributes["NoPoliza"].InnerText.Substring(2, 10), ", esta fue emitida y programada con éxito.");
                                    return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", emision.RespuestaServicio.SelectNodes("Movimientos/Movimiento")[0].Attributes["NoPoliza"].InnerText.Substring(2, 10), ", esta fue emitida y programada con éxito."), EsError = bError }*/);
                                }
                                else
                                {
                                    TempData["EsError"] = bError.ToString();
                                    TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", emision.RespuestaServicio.SelectNodes("Movimientos/Movimiento")[0].Attributes["NoPoliza"].InnerText.Substring(2, 10), ", esta fue emitida con éxito");
                                    return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", emision.RespuestaServicio.SelectNodes("Movimientos/Movimiento")[0].Attributes["NoPoliza"].InnerText.Substring(2, 10), ", esta fue emitida con éxito"), EsError = bError }*/);
                                }
                            }
                            else
                            {
                                TempData["EsError"] = bError.ToString();
                                TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", emision.RespuestaServicio.SelectNodes("Movimientos/Movimiento")[0].Attributes["NoPoliza"].InnerText.Substring(2, 10), ", esta fue emitida y programada con éxito.");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", emision.RespuestaServicio.SelectNodes("Movimientos/Movimiento")[0].Attributes["NoPoliza"].InnerText.Substring(2, 10), ", esta fue emitida y programada con éxito."), EsError = bError }*/);
                            }
                        }
                        else
                        {
                            if (InfoEmision.Convenio.IdAseguradora == 1)
                            {
                                if (EntrarOpl == true)
                                {
                                    TempData["EsError"] = bError.ToString();
                                    TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, ", esta fue emitida y programada con éxito.");
                                    return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, ", esta fue emitida y programada con éxito."), EsError = bError }*/);
                                }
                                else
                                {
                                    TempData["EsError"] = bError.ToString();
                                    TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, ", esta fue emitida con éxito.");
                                    return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, ", esta fue emitida con éxito."), EsError = bError }*/);
                                }
                            }
                            else
                            {
                                TempData["EsError"] = bError.ToString();
                                TempData["MsjExito"] = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, ", esta fue emitida y programada con éxito.");
                                return RedirectToAction("Index", "Polizas"/*, new { MsjExito = string.Concat("Tu auto ahora está protegido en la póliza: ", InfoEmision.Poliza.NumeroPoliza, ", esta fue emitida y programada con éxito."), EsError = bError }*/);
                            }
                        }
                    }
                    else
                    {
                        log.Info(string.Concat("Ocurrió el siguiente error: ", sError));
                        TempData["EsError"] = bError.ToString();
                        TempData["MsjError"] = sError.ToString();
                        TempData["MsNegritas"] = sNegritas.ToString();
                        return RedirectToAction("Index", "Polizas"/*, new { MsjError = sError, MsNegritas = sNegritas, EsError = bError }*/);
                    }
                }
                else
                {
                    var mensajeError = emision.MensajeRespuesta + " Por favor llamen al  contact center o a su ejecutivo de servicio para continuar con su trámite.";
                    //TempData["__INFORMACION_EMISION_COTIZACIONINFORMACION__"] = InfoEmision;
                    log.Info(string.Concat("El servicio respondió con lo siguiente: ", emision.MensajeRespuesta));
                    //return RedirectToAction("CotizacionInformacion", "Cotizacion", new { InfoEmision.IdCotizacion, InfoEmision.Aseguradora, EsError = true, Titulo = "Error al Emitir póliza", Msj = mensajeError, Icono = "error", emisionPersonaMoral = InfoEmision.EmisionPersonaMoral });

                    InfoEmision = GenerateViewsEmision(InfoEmision, EsError: true, Titulo: "Error al Emitir póliza", Msj: mensajeError, Icono: "error");
                    return View("CotizacionInformacion", InfoEmision);


                }
            }
            catch (Exception ex)
            {
                //TempData["__INFORMACION_EMISION_COTIZACIONINFORMACION__"] = InfoEmision;
                log.Error(ex);

                log.Info("Error: " + logValidacion);
                //log.Info("Error: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
                //return RedirectToAction("CotizacionInformacion", "Cotizacion", new { InfoEmision.IdCotizacion, InfoEmision.Aseguradora, Titulo = "Error al Emitir póliza", Msj = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message), EsError = true, Icono = "error", emisionPersonaMoral = InfoEmision.EmisionPersonaMoral });

                InfoEmision = GenerateViewsEmision(InfoEmision, EsError: true, Titulo: "Error al Emitir póliza", Msj: (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message), Icono: "error");
                return View("CotizacionInformacion", InfoEmision);

            }
        }

        public void ActualizaPolizaEmision(int idPoliza)
        {
            var poliza = db.Poliza.FirstOrDefault(a => a.Id == idPoliza);
            var userIdCotiza = User.Identity.GetUserId();
            var userCotiza = db.DetalleUsuario.FirstOrDefault(a => a.IdUsuario == userIdCotiza);

            poliza.IdUsuarioEmite = userCotiza.Id;
            poliza.UserNameEmite = User.Identity.Name;

            db.SaveChanges();
        }

        private Direccion ConstruyeDireccion(InformacionEmision infoEmision)
        {
            Direccion direccion = new Direccion();
            try
            {
                log.Info("Inicia mapeo de datos para la dirección que ingresó el usuario.");
                direccion.Calle = infoEmision.DatosUsuario.Direccion.Calle;
                direccion.NumeroExt = infoEmision.DatosUsuario.Direccion.NumeroExt;
                direccion.NumeroInt = infoEmision.DatosUsuario.Direccion.NumeroInt;
                direccion.Colonia = infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
                direccion.Estado = infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Estado;
                direccion.Municipio = infoEmision.DatosUsuario.Direccion.Municipio;
                direccion.CodigoPostal = infoEmision.DatosUsuario.Direccion.CodigoPostal;
                direccion.IdEstado = null;
                direccion.IdMunicipio = null;
                direccion.IdColonia = null;
                direccion.IdCatEstadosRepublica = infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Id;
                direccion.IdCodigoPostal = infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Id;
                direccion.DireccionCompleta = string.Format("{0} {1} {2} {3} Ext. {4} Int. {5} CP. {6}", direccion.Estado, direccion.Municipio, direccion.Colonia, direccion.Calle, direccion.NumeroExt, string.IsNullOrEmpty(direccion.NumeroExt) ? "" : direccion.NumeroInt, direccion.CodigoPostal);
                db.Direccion.Add(direccion);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("Se presentó el siguiente error: ", ex.Message));
            }
            return direccion;
        }

        public void ConstruirObjetoEmision(InformacionEmision InfoEmision, CotizacionDetalle cotizacion)
        {
            if (cotizacion == null && Debugger.IsAttached)
            {


                cotizacion = new CotizacionDetalle();
                cotizacion.XMLRecepcion = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Movimientos><Movimiento TipoMovimiento=\"2\" NoPoliza=\"\" NoCotizacion=\"\" NoEndoso=\"\" TipoEndoso=\"\" NoOTra=\"\" NoNegocio=\"05225\"><DatosAsegurado NoAsegurado=\"\"><Nombre>Yanet Ramirez Ramirez Guerrero</Nombre><Direccion>Paseo de la Reforma 342 Int P7, Juarez, Cuauhtémoc, Ciudad de México, CP 06600 </Direccion><Colonia>Juárez</Colonia><Poblacion>Paseo de la Reforma</Poblacion><Estado>9</Estado><CodigoPostal>06600</CodigoPostal><NoEmpleado>10210</NoEmpleado><Agrupador /></DatosAsegurado><DatosVehiculo NoInciso=\"1\"><ClaveAmis>3973</ClaveAmis><Modelo>2018</Modelo><DescripcionVehiculo>AUT 4CIL 5PAS 4PTAS QC NAVI 2.4L</DescripcionVehiculo><Uso>01</Uso><Servicio>01</Servicio><Paquete>01</Paquete><Motor /><Serie /><Coberturas NoCobertura=\"3\"><SumaAsegurada>0</SumaAsegurada><TipoSuma>03</TipoSuma><Deducible>5</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"4\"><SumaAsegurada>1200000</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"5\"><SumaAsegurada>100000</SumaAsegurada><TipoSuma>15</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"6\"><SumaAsegurada>100000</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"7\"><SumaAsegurada>0</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"11\"><SumaAsegurada>0</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"14\"><SumaAsegurada>0</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"17\"><SumaAsegurada>11000</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"18\"><SumaAsegurada>4000000</SumaAsegurada><TipoSuma>14</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"47\"><SumaAsegurada>1200000</SumaAsegurada><TipoSuma>15</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas></DatosVehiculo><DatosGenerales><FechaEmision>2019-02-06</FechaEmision><FechaInicio>2019-02-06</FechaInicio><FechaTermino>2020-02-06</FechaTermino><Moneda>00</Moneda><Agente>56488</Agente><FormaPago>C</FormaPago><TarifaValores>1711</TarifaValores><TarifaCuotas>1711</TarifaCuotas><TarifaDerechos>1711</TarifaDerechos><Plazo /><Agencia /><Contrato /><PorcentajeDescuento>61.09</PorcentajeDescuento><ConsideracionesAdicionalesDG NoConsideracion=\"4\"><TipoRegla>1</TipoRegla><ValorRegla>0</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"1\"><TipoRegla>1</TipoRegla><ValorRegla>4</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"84\"><TipoRegla /><ValorRegla>06600</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"31\"><TipoRegla>1</TipoRegla><ValorRegla /></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"13\"><TipoRegla>1</TipoRegla><ValorRegla>S</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"34\"><TipoRegla>2</TipoRegla><ValorRegla /></ConsideracionesAdicionalesDG></DatosGenerales><Primas><PrimaNeta /><Derecho>340</Derecho><Recargo /><Impuesto /><PrimaTotal /><Comision /></Primas><CodigoError /></Movimiento></Movimientos>";
            }

            LocktonModel.db.Convenio convenio = db.Convenio.Where(x => x.Id.Equals(cotizacion.IdConvenio)).Include(x => x.CatTipoContratante).FirstOrDefault();

            //CAT: Se carga la bandera solo en la emision web; se hizo de esta forma para no afectar la emision masiva, que conserva el flujo actual.
            if (convenio.IdAseguradora == 2)
            {
                ConfiguracionDomiciliacionGNP configuracionDomiciliacion = db.ConfiguracionDomiciliacionGNP.FirstOrDefault(x => x.IdConvenio == convenio.Id);
                convenio.AplicaDomiciliacionPostEmision = configuracionDomiciliacion != null && configuracionDomiciliacion.AplicaDomiciliacionPostEmision;
            }

            XmlDocument xmlCotizacionSolSeleccionada = new XmlDocument();
            XmlDocument xmlCotizacionRecSeleccionada = new XmlDocument();

            if (InfoEmision.Aseguradora != "BANORTE")
            {
                if (!string.IsNullOrEmpty(cotizacion.XMLSolicitud))
                    xmlCotizacionSolSeleccionada.LoadXml(cotizacion.XMLSolicitud);
                if (!string.IsNullOrEmpty(cotizacion.XMLRecepcion))
                    xmlCotizacionRecSeleccionada.LoadXml(cotizacion.XMLRecepcion);
            }
            InfoEmision.Convenio = convenio;

            // if ((!InfoEmision.EsFlotilla && !InfoEmision.EmisionPersonaMoral) || InfoEmision.IdTipoContratante == 5)//Datos Fiscales Empleado

            if (InfoEmision.IdEstado > 0 && InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica == null)
                InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica = db.CatEstadosRepublica.Find(InfoEmision.IdEstado);

            if (InfoEmision.IdAsentamiento > 0 && InfoEmision.DatosUsuario.Direccion.CatCodigoPostal == null)
                InfoEmision.DatosUsuario.Direccion.CatCodigoPostal = db.CatCodigoPostal.FirstOrDefault(x => x.Id.Equals(InfoEmision.IdAsentamiento));

            //if (InfoEmision.IdTipoContratante == 2 || InfoEmision.IdTipoContratante == 5)
            //{

            //    InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica = db.CatEstadosRepublica.Find(InfoEmision.IdEstado);
            //    InfoEmision.DatosUsuario.Direccion.CatCodigoPostal = db.CatCodigoPostal.FirstOrDefault(x => x.Id.Equals(InfoEmision.IdAsentamiento));
            //}

            //if((InfoEmision.IdTipoDeNegocio == 3 || (InfoEmision.IdTipoDeNegocio == 5 && !InfoEmision.EmisionPersonaMoral))&& InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica == null)
            //{
            //    InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica = db.CatEstadosRepublica.Find(InfoEmision.IdEstado);
            //    InfoEmision.DatosUsuario.Direccion.CatCodigoPostal = db.CatCodigoPostal.FirstOrDefault(x => x.Id.Equals(InfoEmision.IdAsentamiento));

            //}
            //log.Info("Crea Documentos con el Xml de Solicitud y el Xml de Respuesta del servicio de cotización.");



            Empresa empresa = db.Empresa.Where(x => x.Id.Equals(convenio.IdEmpresa)).Include(e => e.CatClientesQualitasCondAdicional)
                                    .Include(e => e.CatGiroBase)
                                    .Include(e => e.CatOficinaReferencia)
                                    .Include(e => e.CatTipoComparativo)
                                    .Include(e => e.CatTipoNegociacion)
                                    .Include(e => e.CatTipoPersona)
                                    .Include(e => e.Corporativo)
                                    .Include(e => e.Direccion)
                                    .Include(e => e.Ejecutivo)
                                    .Include(e => e.PersonalizaEmpresaCorreo)
                                    .Include(e => e.PersonalizaEmpresaLandF)
                                    .Include(e => e.RepresentanteLegal)
                                    .Include(e => e.RepresentanteLegal.CatEstadosRepublica)
                                    .Include(e => e.RepresentanteLegal.CatPais)
                                    .Include(e => e.RepresentanteLegal.CatTipoIdentificacion).FirstOrDefault();

            CatBeneficiarioPreferente benefPreferente = null;

            if (InfoEmision.IdBeneficiarioPreferente != "0" && InfoEmision.EsBeneficiarioPreferente && !string.IsNullOrEmpty(InfoEmision.IdBeneficiarioPreferente))
            {

                benefPreferente = db.CatBeneficiarioPreferente.Where(x => x.Clave == InfoEmision.IdBeneficiarioPreferente.ToString()).FirstOrDefault();
                if (benefPreferente == null && InfoEmision.Aseguradora == "INBURSA")
                {
                    int idbenef = 0;
                    if (int.TryParse(InfoEmision.IdBeneficiarioPreferente, out idbenef))
                    {
                        benefPreferente = db.CatBeneficiarioPreferente.Where(x => x.Id == idbenef).FirstOrDefault();

                    }


                }
            }

            CatParentesco parentesco = db.CatParentesco.Find(InfoEmision.IdParentesco);
            bool usuarioAlias = false;
            DetalleUsuario usuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            CotizacionAuto cotizacionauto = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion));
            var _cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacion.IdCotizacion);
            CatUsoVehiculo catusovehiculo = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == cotizacionauto.TipoVehiculo);

            if (InfoEmision.Aseguradora != "ABA"
                && InfoEmision.Aseguradora != "GNP"
                && InfoEmision.Aseguradora != "ATLAS"
                && InfoEmision.Aseguradora != "INBURSA"
                && cotizacionauto.MediodePago != 2
                && cotizacionauto.MediodePago != 7
                && !InfoEmision.CotizacionCero)
            {

                if (convenio.GestorCobro != 2 && (cotizacion.IdMedioPago != 1 && InfoEmision.Convenio.IdAseguradora == 10))
                {
                    if (InfoEmision.Convenio.IdAseguradora != 10)
                    {
                        InfoEmision.Tarjeta.AnioVencimiento = InfoEmision.IdAnio;
                        InfoEmision.Tarjeta.Carrirer = ObtieneCarrier(InfoEmision.Tarjeta.NumeroTarjeta);
                    }
                    InfoEmision.Tarjeta.Banco = db.CatBanco.Where(x => x.BancoId.Equals(InfoEmision.IdBanco)).FirstOrDefault();
                }
            }
            if (InfoEmision.Aseguradora == "GNP")
            {
                if (Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').ToList().Contains(InfoEmision.Convenio.IdEmpresa.ToString()) ||
                        Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS"))
                {
                    InfoEmision.NoCotizacion = "";
                }
                else
                    InfoEmision.NoCotizacion = new GNPService().ObtenerNoCotizacion(cotizacion.XMLRecepcion);
            }
            else
                InfoEmision.NoCotizacion = "";

            //log.Info("Se obtienen los datos correspondientes al parentesco, usuario, cotizacionAuto, periodicidad y medio de pago");
            //log.Info("Continúa la contrucción del objeto InformacionEmision.");
            InfoEmision.TipoMovimiento = "3";
            InfoEmision.NoPoliza = "";

            InfoEmision.NoEndoso = "";
            InfoEmision.TipoEndoso = "";
            InfoEmision.NoOTra = "";
            InfoEmision.NoNegocio = convenio.NumeroNegocio;
            InfoEmision.NoAsegurado = "";
            InfoEmision.NoInciso = "1";
            InfoEmision.Moneda = "00";
            InfoEmision.NoEmpleado = string.IsNullOrEmpty(usuario.IdEmpleado) ? "" : usuario.IdEmpleado.ToString();
            InfoEmision.XmlsAseguradoras.Add("CotizacionSolicitud", xmlCotizacionSolSeleccionada);
            InfoEmision.XmlsAseguradoras.Add("CotizacionRecepcion", xmlCotizacionRecSeleccionada);
            InfoEmision.Vehiculo = new LocktonModel.VModels.Vehiculo(cotizacionauto.Marca, InfoEmision.NumeroMotor, InfoEmision.NumeroSerie, InfoEmision.Placas);
            InfoEmision.Vehiculo.Año = cotizacionauto.Agnio;
            InfoEmision.Vehiculo.Modelo = cotizacionauto.Modelo;
            InfoEmision.Vehiculo.Descripcion = cotizacionauto.Descripcion;
            InfoEmision.Empresa = empresa;
            InfoEmision.DetalleUsuario = usuario;

            InfoEmision.BeneficiarioPreferente = benefPreferente != null ? benefPreferente.Nombre : InfoEmision.BeneficiarioPreferente;
            InfoEmision.Parentesco = parentesco;
            InfoEmision.CotizacionAutoGuardar = cotizacionauto;
            InfoEmision.NombreTipoVehiculo = string.Empty;

            if (catusovehiculo != null)
            {
                if (catusovehiculo.Nombre.Contains("("))
                    InfoEmision.NombreTipoVehiculo = $"{catusovehiculo.Nombre.Substring(0, catusovehiculo.Nombre.IndexOf('('))}";
                else
                    InfoEmision.NombreTipoVehiculo = $"{catusovehiculo.Nombre}";
            }
        }

        public void ConstruirObjetoEmisionMasivo(InformacionEmision InfoEmision, CotizacionDetalle cotizacion)
        {
            if (cotizacion == null && Debugger.IsAttached)
            {


                cotizacion = new CotizacionDetalle();
                cotizacion.XMLRecepcion = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Movimientos><Movimiento TipoMovimiento=\"2\" NoPoliza=\"\" NoCotizacion=\"\" NoEndoso=\"\" TipoEndoso=\"\" NoOTra=\"\" NoNegocio=\"05225\"><DatosAsegurado NoAsegurado=\"\"><Nombre>Yanet Ramirez Ramirez Guerrero</Nombre><Direccion>Paseo de la Reforma 342 Int P7, Juarez, Cuauhtémoc, Ciudad de México, CP 06600 </Direccion><Colonia>Juárez</Colonia><Poblacion>Paseo de la Reforma</Poblacion><Estado>9</Estado><CodigoPostal>06600</CodigoPostal><NoEmpleado>10210</NoEmpleado><Agrupador /></DatosAsegurado><DatosVehiculo NoInciso=\"1\"><ClaveAmis>3973</ClaveAmis><Modelo>2018</Modelo><DescripcionVehiculo>AUT 4CIL 5PAS 4PTAS QC NAVI 2.4L</DescripcionVehiculo><Uso>01</Uso><Servicio>01</Servicio><Paquete>01</Paquete><Motor /><Serie /><Coberturas NoCobertura=\"3\"><SumaAsegurada>0</SumaAsegurada><TipoSuma>03</TipoSuma><Deducible>5</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"4\"><SumaAsegurada>1200000</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"5\"><SumaAsegurada>100000</SumaAsegurada><TipoSuma>15</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"6\"><SumaAsegurada>100000</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"7\"><SumaAsegurada>0</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"11\"><SumaAsegurada>0</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"14\"><SumaAsegurada>0</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"17\"><SumaAsegurada>11000</SumaAsegurada><TipoSuma>1</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"18\"><SumaAsegurada>4000000</SumaAsegurada><TipoSuma>14</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas><Coberturas NoCobertura=\"47\"><SumaAsegurada>1200000</SumaAsegurada><TipoSuma>15</TipoSuma><Deducible>0</Deducible><Prima>0</Prima></Coberturas></DatosVehiculo><DatosGenerales><FechaEmision>2019-02-06</FechaEmision><FechaInicio>2019-02-06</FechaInicio><FechaTermino>2020-02-06</FechaTermino><Moneda>00</Moneda><Agente>56488</Agente><FormaPago>C</FormaPago><TarifaValores>1711</TarifaValores><TarifaCuotas>1711</TarifaCuotas><TarifaDerechos>1711</TarifaDerechos><Plazo /><Agencia /><Contrato /><PorcentajeDescuento>61.09</PorcentajeDescuento><ConsideracionesAdicionalesDG NoConsideracion=\"4\"><TipoRegla>1</TipoRegla><ValorRegla>0</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"1\"><TipoRegla>1</TipoRegla><ValorRegla>4</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"84\"><TipoRegla /><ValorRegla>06600</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"31\"><TipoRegla>1</TipoRegla><ValorRegla /></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"13\"><TipoRegla>1</TipoRegla><ValorRegla>S</ValorRegla></ConsideracionesAdicionalesDG><ConsideracionesAdicionalesDG NoConsideracion=\"34\"><TipoRegla>2</TipoRegla><ValorRegla /></ConsideracionesAdicionalesDG></DatosGenerales><Primas><PrimaNeta /><Derecho>340</Derecho><Recargo /><Impuesto /><PrimaTotal /><Comision /></Primas><CodigoError /></Movimiento></Movimientos>";
            }

            LocktonModel.db.Convenio convenio = db.Convenio.Where(x => x.Id.Equals(cotizacion.IdConvenio)).Include(x => x.CatTipoContratante).FirstOrDefault();
            XmlDocument xmlCotizacionSolSeleccionada = new XmlDocument();
            XmlDocument xmlCotizacionRecSeleccionada = new XmlDocument();
            if (!string.IsNullOrEmpty(cotizacion.XMLSolicitud))
                xmlCotizacionSolSeleccionada.LoadXml(cotizacion.XMLSolicitud);
            if (!string.IsNullOrEmpty(cotizacion.XMLRecepcion))
                xmlCotizacionRecSeleccionada.LoadXml(cotizacion.XMLRecepcion);

            InfoEmision.Convenio = convenio;

            // if ((!InfoEmision.EsFlotilla && !InfoEmision.EmisionPersonaMoral) || InfoEmision.IdTipoContratante == 5)//Datos Fiscales Empleado
            if (InfoEmision.IdTipoContratante != 1)
            {

                InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica = db.CatEstadosRepublica.Find(InfoEmision.IdEstado);
                InfoEmision.DatosUsuario.Direccion.CatCodigoPostal = db.CatCodigoPostal.FirstOrDefault(x => x.Id.Equals(InfoEmision.IdAsentamiento));
            }
            //log.Info("Crea Documentos con el Xml de Solicitud y el Xml de Respuesta del servicio de cotización.");



            Empresa empresa = db.Empresa.Where(x => x.Id.Equals(convenio.IdEmpresa)).Include(e => e.CatClientesQualitasCondAdicional)
                                    .Include(e => e.CatGiroBase)
                                    .Include(e => e.CatOficinaReferencia)
                                    .Include(e => e.CatTipoComparativo)
                                    .Include(e => e.CatTipoNegociacion)
                                    .Include(e => e.CatTipoPersona)
                                    .Include(e => e.Corporativo)
                                    .Include(e => e.Direccion)
                                    .Include(e => e.Ejecutivo)
                                    .Include(e => e.PersonalizaEmpresaCorreo)
                                    .Include(e => e.PersonalizaEmpresaLandF)
                                    .Include(e => e.RepresentanteLegal)
                                    .Include(e => e.RepresentanteLegal.CatEstadosRepublica)
                                    .Include(e => e.RepresentanteLegal.CatPais)
                                    .Include(e => e.RepresentanteLegal.CatTipoIdentificacion).FirstOrDefault();

            CatBeneficiarioPreferente benefPreferente = null;

            if (InfoEmision.IdBeneficiarioPreferente != "0" && InfoEmision.EsBeneficiarioPreferente && !string.IsNullOrEmpty(InfoEmision.IdBeneficiarioPreferente))
            {

                benefPreferente = db.CatBeneficiarioPreferente.Where(x => x.Clave == InfoEmision.IdBeneficiarioPreferente.ToString()).FirstOrDefault();
                if (benefPreferente == null && InfoEmision.Aseguradora == "INBURSA")
                {
                    int idbenef = 0;
                    if (int.TryParse(InfoEmision.IdBeneficiarioPreferente, out idbenef))
                    {
                        benefPreferente = db.CatBeneficiarioPreferente.Where(x => x.Id == idbenef).FirstOrDefault();

                    }


                }
            }

            CatParentesco parentesco = db.CatParentesco.Find(InfoEmision.IdParentesco);

            CotizacionAuto cotizacionauto = db.CotizacionAuto.FirstOrDefault(x => x.IdCotizacion.Equals(cotizacion.IdCotizacion));
            var _cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacion.IdCotizacion);
            CatUsoVehiculo catusovehiculo = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == cotizacionauto.TipoVehiculo);

            if (InfoEmision.Aseguradora != "ABA"
                && InfoEmision.Aseguradora != "GNP"
                && InfoEmision.Aseguradora != "ATLAS"
                && InfoEmision.Aseguradora != "INBURSA"
                && cotizacionauto.MediodePago != 2
                && cotizacionauto.MediodePago != 7
                && !InfoEmision.CotizacionCero)
            {

                if (convenio.GestorCobro != 2 && (cotizacion.IdMedioPago != 1 && InfoEmision.Convenio.IdAseguradora == 10))
                {
                    if (InfoEmision.Convenio.IdAseguradora != 10)
                    {
                        InfoEmision.Tarjeta.AnioVencimiento = InfoEmision.IdAnio;
                        InfoEmision.Tarjeta.Carrirer = ObtieneCarrier(InfoEmision.Tarjeta.NumeroTarjeta);
                    }
                    InfoEmision.Tarjeta.Banco = db.CatBanco.Where(x => x.BancoId.Equals(InfoEmision.IdBanco)).FirstOrDefault();
                }
            }
            if (InfoEmision.Aseguradora == "GNP")
            {
                if (Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').ToList().Contains(InfoEmision.Convenio.IdEmpresa.ToString()) ||
                        Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS"))
                {
                    InfoEmision.NoCotizacion = "";
                }
                else
                    InfoEmision.NoCotizacion = new GNPService().ObtenerNoCotizacion(cotizacion.XMLRecepcion);
            }
            else
                InfoEmision.NoCotizacion = "";

            //log.Info("Se obtienen los datos correspondientes al parentesco, usuario, cotizacionAuto, periodicidad y medio de pago");
            //log.Info("Continúa la contrucción del objeto InformacionEmision.");
            InfoEmision.TipoMovimiento = "3";
            InfoEmision.NoPoliza = "";

            InfoEmision.NoEndoso = "";
            InfoEmision.TipoEndoso = "";
            InfoEmision.NoOTra = "";
            InfoEmision.NoNegocio = convenio.NumeroNegocio;
            InfoEmision.NoAsegurado = "";
            InfoEmision.NoInciso = "1";
            InfoEmision.Moneda = "00";
            InfoEmision.NoEmpleado = string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdEmpleado) ? "" : InfoEmision.DetalleUsuario.IdEmpleado.ToString();
            InfoEmision.XmlsAseguradoras.Add("CotizacionSolicitud", xmlCotizacionSolSeleccionada);
            InfoEmision.XmlsAseguradoras.Add("CotizacionRecepcion", xmlCotizacionRecSeleccionada);
            InfoEmision.Vehiculo = new LocktonModel.VModels.Vehiculo(cotizacionauto.Marca, InfoEmision.NumeroMotor, InfoEmision.NumeroSerie, InfoEmision.Placas);
            InfoEmision.Vehiculo.Año = cotizacionauto.Agnio;
            InfoEmision.Vehiculo.Modelo = cotizacionauto.Modelo;
            InfoEmision.Vehiculo.Descripcion = cotizacionauto.Descripcion;
            InfoEmision.Empresa = empresa;


            InfoEmision.BeneficiarioPreferente = benefPreferente != null ? benefPreferente.Nombre : InfoEmision.BeneficiarioPreferente;
            InfoEmision.Parentesco = parentesco;
            InfoEmision.CotizacionAutoGuardar = cotizacionauto;

            InfoEmision.NombreTipoVehiculo = string.Empty;

            if (catusovehiculo != null)
            {
                if (catusovehiculo.Nombre.Contains("("))
                    InfoEmision.NombreTipoVehiculo = $"{catusovehiculo.Nombre.Substring(0, catusovehiculo.Nombre.IndexOf('('))}";
                else
                    InfoEmision.NombreTipoVehiculo = $"{catusovehiculo.Nombre}";
            }


        }

        private RespuestaCobranza YLoQuieroAlCentavoPrro(InformacionEmision InfoEmision, Movimientos respuestaEmisionQualitas, string formaPagoCobranza, string claveAgente, EmisionPolizaClient emisionPolizaClient)
        {
            log.Info("Inicia el proceso de cobranza.");
            RespuestaCobranza respuesta = new RespuestaCobranza();
            DatosCobranza datosCobranza = new DatosCobranza();
            datosCobranza = ObtieneObjetoDatosCobranza(
                                    claveAgente,
                                    respuestaEmisionQualitas.Items[0].NoPoliza,
                                    formaPagoCobranza,
                                    respuestaEmisionQualitas.Items[0].NoNegocio,
                                    respuestaEmisionQualitas.Items[0].DatosAsegurado[0].NoEmpleado,
                                    InfoEmision.Email,
                                    InfoEmision.Tarjeta.TitularTarjeta
                                );
            var catModalidadPago = db.CatModalidadFormaPago.Where(x => x.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString()).FirstOrDefault();
            var perio = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            var ModalidadFPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == perio.IdCatPeriodicidadFormaPago && x.IdCatModalidadFormaPago == catModalidadPago.Id).FirstOrDefault();
            //log.Info("Envía el objeto DatosCobranza al OPL");
            var entraropl = ModalidadFPago != null ? ModalidadFPago.EntrarOPL : true;
            switch (InfoEmision.CotizacionAutoGuardar.MediodePago)
            {
                case 0:
                case 1:
                    //log.Info("Construye el objeto de cobranza con los valores para tarjetas.");
                    datosCobranza.AnoVencimiento = InfoEmision.IdAnio.ToString();
                    datosCobranza.ClaveBanco = InfoEmision.IdBanco.ToString();
                    if (InfoEmision.Tarjeta.NumeroTarjeta.Length <= 16)
                    {
                        datosCobranza.CodigoSeguridad = InfoEmision.Tarjeta.Cvv.ToString();
                        datosCobranza.MesVencimiento = InfoEmision.Tarjeta.MesVencimiento.PadLeft(2, '0');
                    }
                    datosCobranza.NumeroTarjeta = InfoEmision.Tarjeta.NumeroTarjeta;
                    datosCobranza.NumeroReintentos = 3;
                    datosCobranza.Rfc = InfoEmision.Empresa.RFC;

                    string tipoTarjeta = InfoEmision.CotizacionAutoGuardar.MediodePago.Equals(0) ? "C" : InfoEmision.CotizacionAutoGuardar.MediodePago.Equals(1) ? "D" : "X";

                    if (Convert.ToBoolean(InfoEmision.Convenio.CargoEnLinea) && InfoEmision.IdBanco == 103)//"AMERICAN EXPRESS"
                    {

                        tipoTarjeta = "AL";

                    }
                    else if (!Convert.ToBoolean(InfoEmision.Convenio.CargoEnLinea) && InfoEmision.IdBanco == 103)//"AMERICAN EXPRESS"
                    {
                        tipoTarjeta = "A";
                    }
                    else if (Convert.ToBoolean(InfoEmision.Convenio.CargoEnLinea) && (tipoTarjeta == "C" || tipoTarjeta == "D") && datosCobranza.NumeroTarjeta.Length <= 16)
                    {
                        tipoTarjeta = "CL";
                    }

                    datosCobranza.TipoTarjeta = tipoTarjeta;

                    //Meses sin intereses
                    if (InfoEmision.IdMSI.HasValue)
                    {
                        var claveMSI = Utilidades.ObtenerClaveBancoMSI(InfoEmision.Convenio.IdAseguradora, InfoEmision.IdBanco, InfoEmision.IdConvenioMSI, InfoEmision.IdMSI);

                        if (!string.IsNullOrEmpty(claveMSI))
                            datosCobranza.TipoTarjeta = claveMSI;
                    }

                    //log.Info("Envía el objeto DatosCobranza al OPL");
                    if (entraropl == true)
                    {
                        var usuarioalias = false;
                        var detUsuario = RegistroDatosUsuarioActivo(ref usuarioalias);
                        //var catContactos = db.CatContactos.SqlQuery("sp_ConsultaUsuarioCore @documento='" + datosCobranza.NumeroPoliza + "'").FirstOrDefault();

                        //if (catContactos != null && !string.IsNullOrEmpty(catContactos.NEmpleado))
                        //{
                        //	var usuarioPoliza = db.DetalleUsuario.FirstOrDefault(a => a.IdEmpleado == catContactos.NEmpleado && a.IdCliCORE == catContactos.IDCli.ToString() && a.IdContCORE == catContactos.IDCont.ToString());
                        //	if (usuarioPoliza != null)
                        //		detUsuario = usuarioPoliza;
                        //}
                        DetalleUsuarioEmpresa detalleusuarioEmpresa = db.DetalleUsuarioEmpresa.FirstOrDefault(a => a.IdDetalleUsuario == detUsuario.Id);
                        Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == detalleusuarioEmpresa.IdEmpresa);
                        var corporativo = db.Corporativo.FirstOrDefault(a => a.Id == empresa.IdCorporativo);
                        datosCobranza.Corporativo = "Corporativo_" + corporativo.Id.ToString();

                        datosCobranza.Negocio = empresa.NombreComercial + " - " + empresa.ClaveEmpresa;

                        log.Info("El negocio está configurado a entrar al opl en PagoTDC Negocio: " + InfoEmision.Empresa.ClaveEmpresa);
                        var resultadoPagoTDC = emisionPolizaClient.PagarConTarjeta(datosCobranza);

                        Cotizar cotizar = new Cotizar();
                        var datos = new VCorreoCompra();
                        datos.IdEmpresa = empresa.Id;
                        datos.NumeroDePoliza = datosCobranza.NumeroPoliza;
                        datos.NombreCompleto = InfoEmision.ObtieneNombreCompleto();
                        datos.NombreAseguradora = "QUALITAS";
                        datos.NombreNegocio = datosCobranza.Negocio;
                        datos.Emails = new List<string>();
                        datos.Emails.Add(InfoEmision.Email);

                        if (!resultadoPagoTDC.Exitoso)
                        {
                            respuesta.sError = string.Format("Su auto se encuentra protegido en la póliza {0}.", datosCobranza.NumeroPoliza);
                            respuesta.sNegritas = string.Format("{0}," + (resultadoPagoTDC.EsReintentable ? " intenta nuevamente desde Mis Pólizas en la opción de Actualizar Datos Bancarios." : " intenta nuevamente desde Mis Pólizas en la opción de Registrar Datos Bancarios."), resultadoPagoTDC.Mensaje);
                            respuesta.bError = true;

                            try
                            {

                                var infoTicket = new BitacoraTicketsCobranza();
                                infoTicket.NumeroPoliza = datosCobranza.NumeroPoliza;
                                infoTicket.TelefonoCelular = InfoEmision.TelefonoCel;
                                infoTicket.TelefonoFijo = InfoEmision.TelefonoFijo;
                                infoTicket.NombreCompleto = InfoEmision.ObtieneNombreCompleto();
                                infoTicket.Email = InfoEmision.Email;
                                infoTicket.FechaRechazo = DateTime.Now;
                                infoTicket.Corporativo = datosCobranza.Corporativo;
                                infoTicket.Negocio = datosCobranza.Negocio;
                                infoTicket.IdEmpresa = empresa.Id;
                                infoTicket.Recibo = "";
                                infoTicket.MedioContacto = "instalación_de_tarjeta";
                                infoTicket.MotivoRechazo = resultadoPagoTDC.MensajeCatalogo;
                                infoTicket.Intento = 0;
                                infoTicket.RazonSocial = empresa.RazonSocial;
                                infoTicket.ClaveEmpresa = empresa.ClaveEmpresa;
                                infoTicket.Titulo = "Mensaje del Servicio de la Aseguradora";
                                infoTicket.Correos = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == empresa.Id).CorreosDContactos;
                                //var idTicket = new EnvioTickets().ZendeskCobroFallido(infoTicket, InfoEmision: InfoEmision);
                                if (resultadoPagoTDC.Mensaje.Contains("Se encontró intermitencia"))
                                {
                                    infoTicket.Correos = db.CatParametro.FirstOrDefault(x => x.Clave == "EmailsServiciosOPl").Valor;
                                    infoTicket.MotivoRechazo = resultadoPagoTDC.MensajeCatalogo;
                                    cotizar.EnvioCorreoErrorOPL(infoTicket);
                                }
                                else
                                {
                                    if (!resultadoPagoTDC.EsReintentable)
                                        cotizar.EnvioCorreoErrorOPL(infoTicket);
                                }
                                //cotizar.EnvioCorreoCobroFallido(datos, empresa.CuentaTOM);
                            }
                            catch (Exception ex)
                            {
                                log.Info(string.Format("Error CRMCobroFallido Poliza:{0} Error:{1}", datosCobranza.NumeroPoliza, ex.Message), ex); ;
                            }
                        }
                        else
                        {
                            try
                            {

                                cotizar.EnvioCorreoPagoPoliza(datos);
                            }
                            catch (Exception ex)
                            {
                                log.Info(string.Format("Error EnvioCorreoPagoPoliza Poliza:{0} Error:{1}", datosCobranza.NumeroPoliza, ex.Message), ex); ;
                            }

                        }
                        GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.QualitasPagoTDC, numeroPoliza: datosCobranza.NumeroPoliza, respuesta: resultadoPagoTDC.Exitoso ? "Exitoso" : "No Exitoso", EmpresaId: empresa.Id);
                    }
                    else
                    {
                        log.Info("El negocio está configurado a no entrar al opl en PagoTDC Negocio: " + InfoEmision.Empresa.ClaveEmpresa);
                    }

                    break;

                case 7:
                    datosCobranza.NumeroReintentos = 3;

                    if (entraropl == true)
                    {
                        log.Info("El negocio está configurado a entrar al opl en Pago referenciado Negocio: " + InfoEmision.Empresa.ClaveEmpresa);
                        if (!string.IsNullOrEmpty(emisionPolizaClient.PagoReferenciado(datosCobranza)))
                        {
                            respuesta.sError = "No fue posible realizar el proceso de Pago Referenciado Sin embargo su póliza se encuentra emitida.";
                            respuesta.sNegritas = "En la sección -Mis Pólizas - puede verificar esta información.";
                            respuesta.bError = true;
                        }
                    }
                    else
                    {
                        log.Info("El negocio está configurado a no entrar al opl en PAgo referenciado Negocio: " + InfoEmision.Empresa.ClaveEmpresa);
                    }

                    GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.QualitasPagoNomina, numeroPoliza: datosCobranza.NumeroPoliza, respuesta: "Exitoso", EmpresaId: InfoEmision.Empresa.Id);
                    break;
                case 2:
                    datosCobranza.NumeroReintentos = 3;

                    if (entraropl == true)
                    {
                        log.Info("El negocio está configurado a entrar al opl en DXN Negocio: " + InfoEmision.Empresa.ClaveEmpresa);
                        if (!string.IsNullOrEmpty(emisionPolizaClient.PagoDescuentoNomina(datosCobranza)))
                        {
                            respuesta.sError = "No fue posible realizar el proceso de descuento por nómina, Sin embargo su póliza se encuentra emitida.";
                            respuesta.sNegritas = "En la sección -Mis Pólizas- puede verificar esta información.";
                            respuesta.bError = true;
                        }
                    }
                    else
                    {
                        log.Info("El negocio está configurado a no entrar al opl en DXN Negocio: " + InfoEmision.Empresa.ClaveEmpresa);
                    }

                    GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.QualitasPagoNomina, numeroPoliza: datosCobranza.NumeroPoliza, respuesta: !respuesta.bError ? "Exitoso" : "No Exitoso", EmpresaId: InfoEmision.Empresa.Id);
                    break;
            }
            return respuesta;
        }

        public class RespuestaCobranza { public bool bError { get; set; } public string sError { get; set; } public string sNegritas { get; set; } }

        private DatosCobranza ObtieneObjetoDatosCobranza(string ClaveAgente, string NumeroPoliza, string Periodicidad, string NumeroNegocio, string NumeroEmpleado, string Email, string TitularTarjeta)
        {
            return new DatosCobranza()
            {
                NumeroPoliza = NumeroPoliza.Substring(2, 10),
                NumeroNegocio = NumeroNegocio,
                ClaveAgente = ClaveAgente,
                CorreoElectronico = Email,
                NombreCompleto = TitularTarjeta,
                NumeroEmpleado = NumeroEmpleado,
                Periodicidad = Periodicidad,
            };
        }
        public void DerivarPolizaCoreMasivo(int idPoliza)
        {
            DerivacionPolizasCore DerivaCore = new DerivacionPolizasCore();
            DerivacionOTRCore DerivaOtrCore = new DerivacionOTRCore();
            InformacionEmision InfoEmision = new InformacionEmision();
            Poliza poliza = db.Poliza.FirstOrDefault(a => a.Id == idPoliza);
            DetalleUsuario detalleUsuario = db.DetalleUsuario.FirstOrDefault(a => a.Id == poliza.IdUsuario);
            LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == poliza.IdConvenio);
            PolizaDetalle polizaDetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == poliza.Id);
            CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == polizaDetalle.IdCotizacionDetalle);
            Cotizacion cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacionDetalle.IdCotizacion);
            Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == convenio.IdEmpresa);
            var configuracion = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == empresa.Id);
            //CatTipoContratante _tipoContratante = db.CatTipoContratante.FirstOrDefault(x => x.IdCatTipoContratante.Equals(convenio.IdCatTipoContratante));
            Aseguradora aseguradora = db.Aseguradora.Where(x => x.Id == cotizacionDetalle.IdAseguradora && x.Estatus.Equals(1)).FirstOrDefault();
            CotizacionAuto cotizacionAuto = db.CotizacionAuto.FirstOrDefault(a => a.IdCotizacion == cotizacion.Id);

            InfoEmision.Poliza = poliza;
            InfoEmision.Convenio = convenio;
            InfoEmision.CotizacionAutoGuardar = cotizacionAuto;
            InfoEmision.DetalleUsuario = detalleUsuario;
            InfoEmision.EsFlotilla = configuracion.IdTipoDeNegocio == 1 || configuracion.IdTipoDeNegocio == 4;// _tipoContratante.IdCatTipoContratante.Equals(4) ? false : true;
            InfoEmision.IdCotizacion = poliza.PolizaDetalle.FirstOrDefault().IdCotizacionDetalle;
            InfoEmision.Aseguradora = aseguradora.ClaveHomologado;
            InfoEmision.Empresa = empresa;
            InfoEmision.EsPersonaPoliticamenteExpuesta = false;
            InfoEmision.EsBeneficiarioPreferente = convenio.optIncluyeBP.HasValue ? convenio.optIncluyeBP.Value.Equals(1) ? true : false : false;
            InfoEmision.ConductorHabitual = true;
            InfoEmision.Edad = cotizacion.Edad;
            InfoEmision.FechaNacimiento = DateTime.Today.AddYears(-InfoEmision.Edad);
            if (poliza != null)
            {
                if (poliza.IdPersonaMoral != null && poliza.IdPersonaMoral > 0)
                {
                    InfoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(x => x.Id == poliza.IdPersonaMoral);
                    InfoEmision.EmisionPersonaMoral = true;
                }
                if (polizaDetalle != null)
                {
                    if (polizaDetalle.IdContratante > 0)
                        InfoEmision.Contratante = db.Contratante.FirstOrDefault(x => x.Id == polizaDetalle.IdContratante);
                    else
                    {
                        AccountController contratante = new AccountController();
                        Contratante contratanteUsuario = contratante.GeneraContratante(InfoEmision);
                        Contratante contratanteConsulta = new Contratante();
                        if (contratanteUsuario != null)
                        {
                            //genera credenciales
                            string usuario = (InfoEmision.Empresa.NombreComercial.Substring(0, 2) + contratanteUsuario.Id).ToString();
                            string password = (InfoEmision.Empresa.NombreComercial.Substring(0, 2) + contratanteUsuario.Id + "$").Trim().ToString();
                            //deriva usuario al core
                            contratante.DerivaUsuarioFinalContratanteCore(contratanteUsuario, password, InfoEmision.Empresa, usuario);
                            //consulta el usuario actualizado
                            contratanteConsulta = db.Contratante.Where(x => x.Id == contratanteUsuario.Id).FirstOrDefault();
                            // Agrega el idCont del contratante al info para la derivación de la poliza
                            InfoEmision.Contratante = contratanteConsulta;
                        }

                    }
                }

            }
            if (!InfoEmision.EsFlotilla)
            {
                InfoEmision.DatosUsuario.Direccion = new Direccion();
                InfoEmision.DatosUsuario.Direccion.CodigoPostal = cotizacion.CodigoPostal;
            }


            InfoEmision.PrimerNombre = detalleUsuario.Nombre;
            InfoEmision.SegundoNombre = detalleUsuario.NombreDos;
            InfoEmision.ApellidoPaterno = detalleUsuario.ApellidoPaterno;
            InfoEmision.ApellidoMaterno = detalleUsuario.ApellidoMaterno;
            if (empresa.Sucursales.Count > 0)
            {
                InfoEmision.AplicaSucursales = true;
                ViewBag.IdSucursal = new SelectList(empresa.Sucursales, "ClaveSucursal", "Nombre");
            }
            OTRenovacion renovacion = db.OTRenovacion.Where(x => x.IdCotizacion.Equals(cotizacion.Id) && x.Estatus.Equals(1)).FirstOrDefault();
            if (renovacion != null)
            {
                InfoEmision.EsRenovacion = true;
                InfoEmision.NumeroMotor = renovacion.Motor.Trim();
                InfoEmision.NumeroSerie = renovacion.Serie.Trim();
                InfoEmision.Placas = renovacion.Placas.Trim();
            }
            else
            {
                InfoEmision.NumeroMotor = poliza.Motor;
                InfoEmision.NumeroSerie = poliza.Serie;
                InfoEmision.Placas = poliza.Placas;

            }

            DerivaCore.DerivaPolizaCore(InfoEmision);
            DerivaOtrCore.DerivaOTCore(InfoEmision);



        }

        public void DerivarPolizaCore(InformacionEmision InfoEmision)
        {
            try
            {
                if (!string.IsNullOrEmpty(InfoEmision.Poliza.NumeroPoliza))
                {
                    DerivacionPolizasCore DerivaCore = new DerivacionPolizasCore();

                    //if (InfoEmision.EsRenovacion)
                    //{
                    //	DerivaCore.DerivaOTPolizaCore(InfoEmision);
                    //}
                    //else
                    //{
                    //	DerivaCore.DerivaPolizaCore(InfoEmision);
                    //}
                    DerivaCore.DerivaPolizaCore(InfoEmision);
                }
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("DerivarPolizaCore Error: ", ex.Message, InfoEmision.Poliza.NumeroPoliza));

            }

        }
        public void RegitraUsuarioBemobile(InformacionEmision informacionEmision)
        {
            ActualizaUsuarioContratanteBemobile actualiza = new ActualizaUsuarioContratanteBemobile();
            Contratante contratanteActualizado = new Contratante();
            //REGISTRA Y ACTUALIZA EL DETALLE DE LA POLIZA Y LLAMA AL SERVICIO PARA ACTUALIZAR EL CONTRATANTE.
            var existeContrante = db.Contratante.Where(x => !string.IsNullOrEmpty(x.IdBemobile) && x.Id == informacionEmision.Contratante.Id).FirstOrDefault();
            if (existeContrante != null)
            {
                contratanteActualizado = existeContrante;
                PolizaDetalle polizaDetalle = db.PolizaDetalle.Where(x => x.IdPoliza == informacionEmision.Poliza.Id).FirstOrDefault();
                if (polizaDetalle != null)
                {
                    polizaDetalle.IdContratante = existeContrante.Id;
                    polizaDetalle.MensajeBemobile = "Se actualizo la poliza con el contratante registrado";
                    db.Entry(polizaDetalle).State = EntityState.Modified;
                    db.SaveChanges();
                    log.Info(string.Format("Genera Contratante y actualiza la poliza :{0}", polizaDetalle.IdPoliza));
                }
            }
            else
            {
                contratanteActualizado = actualiza.RegistraContratante(informacionEmision, informacionEmision.Contratante);
            }

            if (contratanteActualizado != null)
            {
                //generarDocumento
                informacionEmision.Contratante = contratanteActualizado;
                VCorreoCompra Documento = Utilidades.DatosCompraArchivo(informacionEmision);
                //enviar el documento
                if (Documento != null && Documento.ArchivosAdjuntos != null)
                {
                    if (Documento.ArchivosAdjuntos.Count > 0)
                    {
                        Cotizar cotizar = new Cotizar();
                        cotizar.DerivaPolizaBeMobile(Documento, informacionEmision);

                    }
                }
            }

        }
        private void DerivarOTCore(InformacionEmision InfoEmision)
        {
            try
            {
                DerivacionOTRCore DerivaOtrCore = new DerivacionOTRCore();
                DerivaOtrCore.DerivaOTCore(InfoEmision);
                //Thread T1 = new Thread(delegate ()
                //{
                //	DerivaOtrCore.DerivaOTCore(InfoEmision);

                //});
                //T1.Start();
            }
            catch (Exception ex)
            {

            }
        }

        public void PROCESO_DerivarPolizaOpera(Poliza pol)
        {
            DerivacionOperaService derivacion = new DerivacionOperaService();
            int idPersonaMoral = 0;
            bool emisionPersonaMoral = false;
            if (pol.IdPersonaMoral != null && pol.IdPersonaMoral > 0)
            {
                idPersonaMoral = pol.IdPersonaMoral.Value;
                emisionPersonaMoral = true;
            }
            derivacion.derivarOperaPoliza(pol, emisionPersonaMoral, idPersonaMoral);
        }
        public void DerivarPolizaOpera(Poliza pol)
        {
            try
            {
                DerivacionOperaService derivacion = new DerivacionOperaService();
                //Thread T1 = new Thread(delegate ()
                //{
                int idPersonaMoral = 0;
                bool emisionPersonaMoral = false;
                if (pol.IdPersonaMoral != null && pol.IdPersonaMoral > 0)
                {
                    idPersonaMoral = pol.IdPersonaMoral.Value;
                    emisionPersonaMoral = true;
                }
                derivacion.derivarOperaPoliza(pol, emisionPersonaMoral, idPersonaMoral);
                //});
                //T1.Start();
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("DerivarPolizaOpera Error: ", ex.Message, pol.NumeroPoliza));
            }
        }

        private void ModificarRenovacion(int IdCotizacion)
        {
            try
            {
                OTRenovacion renovacion = db.OTRenovacion.Where(x => x.IdCotizacion.Equals(IdCotizacion) && x.Estatus.Equals(1)).FirstOrDefault();
                renovacion.Estatus = 2;
                db.Entry(renovacion).State = EntityState.Modified;
                db.SaveChanges();

                SqlParameter sqlPolizas = new SqlParameter("@Polizas", renovacion.NumeroDePoliza);
                db.Database.ExecuteSqlCommand("spu_Aceptar_DatosRenovacion @Polizas", sqlPolizas);
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("ModificarRenovacion Error: ", ex.Message));
            }
        }

        private void ModificaNotificacionRenovacion(int idDocto, string numeroPolizaEmitida)
        {
            try
            {

                var parameter = new List<SqlParameter>()
                {
                    new SqlParameter("@PolizaEmitida",numeroPolizaEmitida),
                     new SqlParameter("@OT",idDocto)
                };
                db.Database.ExecuteSqlCommand("sp_RENOVACIONES_Emision @PolizaEmitida, @OT", parameter.ToArray());
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("ModificarRenovacion Error: ", ex.Message));
            }
        }

        private void ModificarRenovacion_Cotizacion(int idCotizacion, int idCotizacionDetalle, string numeroSerie, int idEmpresa)
        {
            try
            {

                if (Utilidades.EstaEnPeriodoDeEnrollment(idEmpresa, DateTime.Now))
                {
                    log.Info($"ModificarRenovacion_Cotizacion Datos a Validar: IdCotizacion {idCotizacion} IdCotizacionDetalle {idCotizacionDetalle} Numero Serie {numeroSerie} IdEmpresa {idEmpresa}");

                    SqlParameter sqlIdCotizacionDetalle = new SqlParameter("@IdCotizacionDetalle", idCotizacionDetalle);
                    SqlParameter sqlIdCotizacion = new SqlParameter("@IdCotizcion", idCotizacion);
                    SqlParameter sqlNumeroSerie = new SqlParameter("@NumeroSerie", numeroSerie);
                    db.Database.ExecuteSqlCommand("spu_DatosRenovacion_Cotizacion @IdCotizacionDetalle,@IdCotizcion,@NumeroSerie", sqlIdCotizacionDetalle, sqlIdCotizacion, sqlNumeroSerie);
                }
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("ModificarRenovacion_Cotizacion Error: ", ex.Message));
            }
        }


        public Poliza GuardarInformacionPoliza(InformacionEmision infoEmision, DateTime inicioVigencia, DateTime finVigencia, DateTime fechaEmision, decimal primaNeta, decimal primaTotal, bool pagada, int idUsr, int idCatTipoPaquete, PolizaDetalle polizaDetalle, Endoso endoso)
        {
            Poliza nuevaPoliza = ConstruirPoliza(infoEmision, inicioVigencia, finVigencia, fechaEmision, primaNeta, primaTotal, pagada, idUsr, idCatTipoPaquete);
            nuevaPoliza.Endoso.Add(endoso);
            nuevaPoliza.PolizaDetalle.Add(polizaDetalle);
            db.Poliza.Add(nuevaPoliza);
            return nuevaPoliza;
        }

        public Poliza GuardarInformacionPolizaMasiva(InformacionEmision infoEmision, DateTime inicioVigencia, DateTime finVigencia, DateTime fechaEmision, decimal primaNeta, decimal primaTotal, bool pagada, int idUsr, int idCatTipoPaquete, PolizaDetalle polizaDetalle, Endoso endoso)
        {
            Poliza nuevaPoliza = ConstruirPoliza(infoEmision, inicioVigencia, finVigencia, fechaEmision, primaNeta, primaTotal, pagada, idUsr, idCatTipoPaquete);
            nuevaPoliza.Endoso.Add(endoso);
            nuevaPoliza.PolizaDetalle.Add(polizaDetalle);
            //db.Poliza.Add(nuevaPoliza);
            return nuevaPoliza;
        }

        public List<Recibo> GenerarListaRecibosQualitas(Movimientos respuestaServicio, InformacionEmision informacionEmision)
        {
            List<Recibo> recibos = new List<Recibo>();
            try
            {
                int conteoRecibos = 1;
                MovimientosMovimientoRecibos[] _recibos = respuestaServicio.Items[0].Recibos;
                var primaTotal = respuestaServicio.Items[0].Primas[0].PrimaTotal;
                var fechaEmision = respuestaServicio.Items[0].DatosGenerales[0].FechaEmision;
                LocktonServicios.Tarificador.TarificadorClient tarificador = new LocktonServicios.Tarificador.TarificadorClient();
                ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == informacionEmision.Empresa.Id).FirstOrDefault();
                //var flotilla = ConfigEmpresa.IdTipoDeNegocio == 1;				 
                var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == informacionEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();

                log.Info(string.Concat("Recibos: ", _recibos.Count()));
                if (perioricidad.Nombre.Contains("Mensual") || perioricidad.Nombre.Contains("Contado") || perioricidad.Nombre.Contains("Trimestral") || perioricidad.Nombre.Contains("Semestral"))
                {
                    foreach (MovimientosMovimientoRecibos _recibo in _recibos)
                    {
                        log.Info(string.Concat("recibo: ", _recibo.NoRecibo));
                        string numeroAsegurado = _recibo.NoRecibo;
                        Recibo recibo = new Recibo();
                        recibo.InicioVigencia = Convert.ToDateTime(_recibo.FechaInicio);
                        recibo.FinVigencia = Convert.ToDateTime(_recibo.FechaTermino);
                        recibo.Numero = conteoRecibos;
                        recibo.NoAsegurado = numeroAsegurado;
                        recibo.PrimaNeta = Convert.ToDecimal(_recibo.PrimaNeta);
                        recibo.PrimaTotal = Convert.ToDecimal(_recibo.PrimaTotal);
                        recibo.Recargo = Convert.ToDecimal(_recibo.Recargo);
                        recibo.Impuesto = Convert.ToDecimal(_recibo.Impuesto);
                        recibo.Comision = Convert.ToDecimal(_recibo.Comision);
                        recibo.Derecho = Convert.ToDecimal(_recibo.Derecho);
                        recibos.Add(recibo);
                        conteoRecibos++;
                    }
                }
                else
                {
                    var convenio = db.Convenio.Where(x => x.Id == informacionEmision.Convenio.Id).FirstOrDefault();
                    bool flotilla = (convenio.IdCatTipoVigencia == 1) ? true : false;
                    //if (!convenio.DerechosPrimerRecibo)
                    //{
                    var rec = tarificador.GetRecibosOnline(informacionEmision.Convenio.Id, flotilla, perioricidad.Nombre, Convert.ToDouble(primaTotal), Convert.ToDateTime(Convert.ToDateTime(fechaEmision).ToString("dd/MM/yyyy"))).ToList();
                    if (rec.Any())
                    {
                        var error = "";
                        foreach (var item in rec)
                        {
                            error = item.MensajeError;
                        }
                        if (error == "" || error == null)
                        {
                            foreach (var item in rec)
                            {
                                if (item.Index >= 0)
                                {
                                    Recibo recibo = new Recibo();
                                    recibo.InicioVigencia = Convert.ToDateTime(item.FechaInicio);
                                    recibo.FinVigencia = Convert.ToDateTime(item.FechaFin);
                                    recibo.Numero = conteoRecibos;
                                    recibo.NoAsegurado = conteoRecibos.ToString();
                                    recibo.PrimaNeta = Convert.ToDecimal(item.PrimaNetaRecibo);
                                    recibo.PrimaTotal = Convert.ToDecimal(item.CobroCorte);
                                    recibo.Recargo = Convert.ToDecimal(0);
                                    recibo.Impuesto = Convert.ToDecimal(item.ImpuestoRecibo);
                                    recibo.Comision = Convert.ToDecimal(item.Comision);
                                    recibo.Derecho = Convert.ToDecimal(item.DerechoDePolizaRecibo);
                                    recibos.Add(recibo);
                                    conteoRecibos++;
                                }
                            }
                        }
                        else
                        {
                            if (error.Contains("El convenio no tiene asignado ningún calendario de tipo de pago"))
                            {
                                foreach (MovimientosMovimientoRecibos _recibo in _recibos)
                                {
                                    log.Info(string.Concat("recibo: ", _recibo.NoRecibo));
                                    string numeroAsegurado = _recibo.NoRecibo;
                                    Recibo recibo = new Recibo();
                                    recibo.InicioVigencia = Convert.ToDateTime(_recibo.FechaInicio);
                                    recibo.FinVigencia = Convert.ToDateTime(_recibo.FechaTermino);
                                    recibo.Numero = conteoRecibos;
                                    recibo.NoAsegurado = numeroAsegurado;
                                    recibo.PrimaNeta = Convert.ToDecimal(_recibo.PrimaNeta);
                                    recibo.PrimaTotal = Convert.ToDecimal(_recibo.PrimaTotal);
                                    recibo.Recargo = Convert.ToDecimal(_recibo.Recargo);
                                    recibo.Impuesto = Convert.ToDecimal(_recibo.Impuesto);
                                    recibo.Comision = Convert.ToDecimal(_recibo.Comision);
                                    recibo.Derecho = Convert.ToDecimal(_recibo.Derecho);
                                    recibos.Add(recibo);
                                    conteoRecibos++;
                                }
                            }
                        }

                    }
                    //}
                    //else
                    //{
                    //    foreach (MovimientosMovimientoRecibos _recibo in _recibos)
                    //    {
                    //        log.Info(string.Concat("recibo: ", _recibo.NoRecibo));
                    //        string numeroAsegurado = _recibo.NoRecibo;
                    //        Recibo recibo = new Recibo();
                    //        recibo.InicioVigencia = Convert.ToDateTime(_recibo.FechaInicio);
                    //        recibo.FinVigencia = Convert.ToDateTime(_recibo.FechaTermino);
                    //        recibo.Numero = conteoRecibos;
                    //        recibo.NoAsegurado = numeroAsegurado;
                    //        recibo.PrimaNeta = Convert.ToDecimal(_recibo.PrimaNeta);
                    //        recibo.PrimaTotal = Convert.ToDecimal(_recibo.PrimaTotal);
                    //        recibo.Recargo = Convert.ToDecimal(_recibo.Recargo);
                    //        recibo.Impuesto = Convert.ToDecimal(_recibo.Impuesto);
                    //        recibo.Comision = Convert.ToDecimal(_recibo.Comision);
                    //        recibo.Derecho = Convert.ToDecimal(_recibo.Derecho);
                    //        recibos.Add(recibo);
                    //        conteoRecibos++;
                    //    }
                    //}

                }

            }
            catch (Exception ex)
            {
                log.Info(string.Concat("Se presentó el siguiente error al obtener los recibos: ", ex.Message));
            }
            return recibos;
        }

        public void AgregarListaRecibos(Endoso endosoAlta, List<Recibo> recibos)
        {
            foreach (Recibo recibo in recibos)
            {
                endosoAlta.Recibo.Add(recibo);
            }
        }

        public Endoso ConstruirEndoso()
        {
            //log.Info("Crea endoso de alta para la nueva póliza.");
            return new Endoso()
            {
                IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id,
                Fecha = DateTime.Now,
                ValorAnterior = "Alta",
                ValorActual = "Contratación"
            };
        }

        private Poliza ConstruirPoliza(InformacionEmision informacionEmision, DateTime inicioVigencia, DateTime finVigencia, DateTime fechaEmision, decimal primaNeta, decimal primaTotal, bool pagada, int idUsr, int idCatTipoPaquete)
        {
            Poliza nuevaPoliza = new Poliza();
            nuevaPoliza.NumeroPoliza = informacionEmision.NoPoliza;
            nuevaPoliza.Motor = informacionEmision.Vehiculo.Motor;
            nuevaPoliza.Serie = informacionEmision.Vehiculo.Serie;
            nuevaPoliza.Placas = informacionEmision.Vehiculo.Placas;
            nuevaPoliza.FinVigencia = finVigencia;
            nuevaPoliza.InicioVigencia = inicioVigencia;
            nuevaPoliza.FechaEmision = fechaEmision;
            nuevaPoliza.PrimaNeta = primaNeta;
            nuevaPoliza.PrimaTotal = primaTotal;
            nuevaPoliza.ConductorHabitual = informacionEmision.Convenio.IdCatTipoContratante == 1 ? "" : informacionEmision.ObtieneNombreCompleto();
            nuevaPoliza.Estatus = pagada ? 20 : 1;
            nuevaPoliza.IdUsuario = idUsr;
            nuevaPoliza.IdConvenio = informacionEmision.Convenio.Id;
            nuevaPoliza.IdTipoCobertura = idCatTipoPaquete;
            if (informacionEmision.Convenio.IdCatTipoContratante == 1)
                nuevaPoliza.IdParentesco = 19;
            else
                nuevaPoliza.IdParentesco = informacionEmision.ConductorHabitual || informacionEmision.IdParentesco <= 0 ? db.CatParentesco.FirstOrDefault(x => x.Nombre.Equals("Titular")).Id : informacionEmision.IdParentesco;

            if (informacionEmision.EmisionPersonaMoral)
            {
                nuevaPoliza.IdPersonaMoral = informacionEmision.PersonaMoral.Id;
                nuevaPoliza.IdRepresentanteLegal = informacionEmision.PersonaMoralRepresentanteLegal.Id;

            }

            nuevaPoliza.EmisionSinDatoBancario = !informacionEmision.ConDatosBancarios;
            nuevaPoliza.Acepto_AvisoPrivacidad_Aseguradora = true;
            nuevaPoliza.Acepto_DescuentoPoliza = true;

            return nuevaPoliza;

        }

        public PolizaDetalle ConstuirPolizaDetalle(int idCatTipoPaquete, decimal factorIva, decimal deducible, decimal recargos, decimal impuesto, decimal comision, int idCatPeriodicidadFormaPago, InformacionEmision informacionEmision)
        {
            log.Info("Comienza la construcción del detalle de la póliza.");
            var detalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == informacionEmision.IdCotizacion);
            PolizaDetalle pd = new PolizaDetalle()
            {
                XMLRecepcion = informacionEmision.XmlsAseguradoras["EmisionRecepcion"].OuterXml,
                XMLSolicitud = informacionEmision.XmlsAseguradoras["EmisionSolicitud"].OuterXml,
                IdCatRamoVehiculo = detalle.IdVehiculo,// db.PaqueteConvenio.FirstOrDefault(x => x.IdCatTipoPaquete.Equals(idCatTipoPaquete) && x.IdConvenio.Equals(informacionEmision.Convenio.Id)).IdCatRamoVehiculo,
                Derechos = decimal.TryParse(informacionEmision.Convenio.DerechosPoliza, out decimal derechos) ? derechos : 0.0m,
                Inciso = "",
                RenovacionAutomatica = true,
                Deducible = deducible,
                Recargos = recargos,
                Impuesto = impuesto,
                Comision = comision,
                FactorIva = factorIva,
                MigraOPERA = false,
                UrlPDFPolizaOPERA = "",
                PolizaOPERA = 0,
                OTOpera = 0,
                EndosoOPERA = 0,
                IdCotizacionAuto = informacionEmision.CotizacionAutoGuardar.Id,
                IdCotizacionDetalle = informacionEmision.IdCotizacion,
                IdCatModalidadFormaPago = db.CatModalidadFormaPago.FirstOrDefault(x => x.Clave.Equals(informacionEmision.CotizacionAutoGuardar.MediodePago.ToString())).Id,
                IdCatPeriodicidadFormaPago = idCatPeriodicidadFormaPago,
                //IdDireccion = direccion!= null? direccion.Id : informacionEmision.Empresa.Direccion.Id,
                BenefMuerteAccidental = informacionEmision.BenefMuerteAccidental ?? "",
                MigraBemobile = false,
                BeneficiarioPreferente = informacionEmision.BeneficiarioPreferente,
                IdMSI = informacionEmision.IdMSI
            };

            if ((informacionEmision.IdTipoDeNegocio == 5 || informacionEmision.IdTipoDeNegocio == 6) && informacionEmision.EmisionPersonaMoral)
            {
                pd.IdDireccion = informacionEmision.PersonaMoral.IdDireccion.Value;
            }
            else if (!informacionEmision.EsFlotilla)
            {
                pd.IdDireccion = ConstruyeDireccion(informacionEmision).Id;
            }
            else
            {
                pd.IdDireccion = informacionEmision.Empresa.Direccion.Id;
            }

            pd.XMLRecepcion = pd.XMLRecepcion.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
            pd.XMLSolicitud = pd.XMLSolicitud.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
            return pd;
        }

        public List<string> ReimpresionPoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, EmisionPolizaClient EmisionPolizaClient)
        {
            return EmisionPolizaClient.ReimprimePoliza(NumeroPoliza, NumeroNegocio, ClaveAgente);
        }

        public void EnviarCorreoAlContratante(InformacionEmision informacionEmision)
        {
            try
            {
                log.Info("entra a EnviarCorreoAlContratante");
                Cotizar cotizar = new Cotizar();
                //log.Info("Llamado a método para envío de correo.");
                cotizar.EnvioCorreoEmisionPoliza(informacionEmision, User.Identity.GetUserId());
                log.Info("termina EnviarCorreoAlContratante");
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("EnviarCorreoAlContratante Error: ", ex.Message, informacionEmision.Poliza.NumeroPoliza));
            }
        }

        private void EnviarCorreoSolicitudAlContratante(InformacionEmision informacionEmision)
        {
            Cotizar cotizar = new Cotizar();
            //log.Info("Llamado a método para envío de correo.");
            cotizar.EnvioDeCorreoElectronicoSolicitud(informacionEmision);
        }

        private void EnvioDeCorreoElectronicoSolicitud(OTRenovacion renovacion, string titulo, string subjet, InformacionEmision emision)
        {
            try
            {

                bool usuarioAlias = false;
                DetalleUsuario detUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);

                List<string> emailDestino = new List<string>() { emision.Email };

                //TODO leer de BD

                emailDestino.Add("ventas01@locktonone.mx");
                emailDestino.Add("YRamirez@mx.lockton.com");
                //  log.Info("Creación de datos del cuerpo de correo.");
                VCorreoCompra datosCompra = DatosCompra(renovacion, detUsuario, emision);
                datosCompra.MensajeTitulo = titulo;

                var cotizar = new Cotizar();
                string plantillaCorreo = cotizar.PlantillaDeCorreoSolicitud(datosCompra);
                //log.Info("Llamado a método para envío.");
                cotizar.EnviaCorreo(emailDestino, subjet, plantillaCorreo, datosCompra.ArchivosAdjuntos, renovacion.NumeroDePoliza);
            }
            catch (Exception ex)
            {


                log.Info(string.Concat("Error Al enviar correo Renovación: ", ex.Message));
            }

        }

        private VCorreoCompra DatosCompra(OTRenovacion renovacion, DetalleUsuario detUsuario, InformacionEmision emision)
        {
            VCorreoCompra datos = new VCorreoCompra();
            int IdEmpresa = (int)detUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;
            Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);

            datos.NombreCompleto = emision.ObtieneNombreCompleto();
            datos.NombreCompania = string.IsNullOrWhiteSpace(empresa.Corporativo.Descripcion) ? empresa.RazonSocial : empresa.Corporativo.Descripcion;
            datos.NombreAseguradora = "INBURSA";
            datos.NombreNegocio = empresa.RazonSocial;
            datos.NumeroDePoliza = renovacion.NumeroDePoliza;
            datos.Marca = renovacion.Marca;
            datos.PrimaTotal = string.Concat(renovacion.PrimaTotal.Value.ToString("C", CultureInfo.CurrentCulture), " MXN");
            datos.FechaInicio = renovacion.InicioVigencia.Value.ToString("dd/MM/yyyy");
            datos.FechaFin = renovacion.FinVigencia.Value.ToString("dd/MM/yyyy");
            datos.VehiculoAsegurado = string.Format("{0} {1} {2}", renovacion.Marca, renovacion.Modelo, renovacion.Tipo);
            datos.NumeroSerie = renovacion.Serie;
            var clavePametro = "MensajeCorreoMedioPagoNomina";
            datos.MensajeMedioPago = db.CatParametro.FirstOrDefault(a => a.Clave == clavePametro).Valor;
            //lista de archivos adjuntos
            datos.ArchivosAdjuntos = new List<string>();

            return datos;
        }

        public string ValidarInfoEmision(InformacionEmision infoEmision, CotizacionDetalle cotizacionDetalle)
        {
            log.Info("entra a validar ValidarInfoEmision");
            string error = "";
            //motor, numero serie y plazas
            if (infoEmision.Placas.Trim() == infoEmision.NumeroMotor.Trim())
                error += "El número de Motor debe ser distinto al número de Placas. ";
            if (infoEmision.Placas.Trim() == infoEmision.NumeroSerie.Trim())
                error += "El número de Serie debe ser distinto al número de Placas. ";
            if (infoEmision.NumeroMotor.Trim() == infoEmision.NumeroSerie.Trim())
                error += "El número de Motor debe ser distinto al número de Serie. ";


            //número de serie
            double serie = 0;
            if (double.TryParse(infoEmision.NumeroSerie, out serie))
                error += "El número de Serie debe ser alfanumerico. ";


            if (infoEmision.CotizacionAutoGuardar.MediodePago != 2
                && infoEmision.CotizacionAutoGuardar.MediodePago != 7
                && !infoEmision.CotizacionCero
                && infoEmision.ConDatosBancarios)
            {

                if ((infoEmision.Aseguradora == "AXA" && infoEmision.Convenio.AxaEspecial) || infoEmision.Aseguradora.ToUpper() == "QUALITAS" || (infoEmision.Aseguradora == "GNP" && infoEmision.EsFlotilla))
                {
                    if (!string.IsNullOrEmpty(infoEmision.Tarjeta?.NumeroTarjeta?.Trim()))
                    {
                        if (infoEmision.NumeroMotor.Contains(infoEmision.Tarjeta.NumeroTarjeta))
                            error += "El número de Motor no debe de contener el número de tarjeta. ";

                        if (infoEmision.NumeroSerie.Contains(infoEmision.Tarjeta.NumeroTarjeta))
                            error += "El número de Serie no debe de contener el número de tarjeta. ";
                    }
                }
            }

            var convenio = db.Convenio.FirstOrDefault(a => a.Id == cotizacionDetalle.IdConvenio);

            //if (infoEmision.Aseguradora == "INBURSA"  || deloites.Contains( convenio.IdEmpresa))
            //         {          

            var documentoSerie = ValidaSerieLONE(infoEmision.NumeroSerie, cotizacionDetalle.FechaCotizacion ?? DateTime.Now);

            if (documentoSerie != null && !string.IsNullOrWhiteSpace(documentoSerie.Documento))
                error += string.Format("Hemos identificado que en las últimas 24 horas hubo una petición anterior para esta misma Serie {0}, en caso de duda contacta a tu ejecutivo", documentoSerie.Documento);


            if (!infoEmision.EsRenovacion)
            {
                log.Info("entra a validar el nuemero de serie " + infoEmision.NumeroSerie);

                SqlParameter numeroSerie = new SqlParameter("@NumeroSerie", infoEmision.NumeroSerie);
                SqlParameter fechaInicio = new SqlParameter("@FechaInicio", cotizacionDetalle.FechaCotizacion.Value.ToString("yyyy-MM-dd"));
                var validacionNumeroSerie = db.sp_Emision_ValidacionNumeroSerie.SqlQuery("sp_Emision_ValidacionNumeroSerie @NumeroSerie, @FechaInicio", numeroSerie, fechaInicio).FirstOrDefault();

                if (validacionNumeroSerie != null && !string.IsNullOrWhiteSpace(validacionNumeroSerie.Documento))
                {

                    if (convenio.OnLine)
                    {
                        SqlParameter documento = new SqlParameter("@Documento", validacionNumeroSerie.Documento);
                        bool tieneSolicitudCancelacion = Convert.ToBoolean(db.Database.SqlQuery<int>("sp_ConsultarEstatusDocumento @Documento", documento).SingleOrDefault());
                        if (!tieneSolicitudCancelacion)
                        {
                            log.Info("obtuvo resultado el numero de serie ya existe");
                            if (infoEmision.Aseguradora.ToUpper() == validacionNumeroSerie.Aseguradora.ToUpper())
                                error += string.Format("No es posible generar tu solicitud el número de SERIE ingresado ya se encuentra amparado en otro Documento: {0}, favor de contactar al CAT.", validacionNumeroSerie.Documento);
                            else
                                error += string.Format("No es posible generar tu solicitud el número de SERIE ingresado ya se encuentra amparado en otro Documento: {0}, antes deberás de generar la solicitud de cancelación.", validacionNumeroSerie.Documento);
                        }
                    }
                    else
                        error += string.Format("No es posible generar tu solicitud el número de SERIE ingresado ya se encuentra amparado en otro Documento: {0}, favor de contactar al CAT.", validacionNumeroSerie.Documento);

                }

                if (string.IsNullOrEmpty(error) && cotizacionDetalle.IdAseguradora == 2)
                {
                    var validacionBitacora = ValidaSerieBitacora(infoEmision.NumeroSerie, cotizacionDetalle.IdAseguradora, infoEmision.ObtieneNombreCompleto(), infoEmision.Email, infoEmision.Empresa.TicketZendesk);

                    if (!validacionBitacora.Exitoso)
                        error += validacionBitacora.Mensaje;
                }
            }


            //}
            return error;
        }

        private sp_Emision_ValidacionNumeroSerie ValidaSerieLONE(string serie, DateTime fecha)
        {
            SqlParameter numeroSerie = new SqlParameter("@NumeroSerie", serie);
            SqlParameter fechaInicio = new SqlParameter("@FechaInicio", fecha);

            var validacionNumeroSerie = db.sp_Emision_ValidacionNumeroSerie.SqlQuery("sp_Emision_ValidacionNumeroSerie_LONE @NumeroSerie, @FechaInicio", numeroSerie, fechaInicio).FirstOrDefault();

            return validacionNumeroSerie;
        }


        private EstatusOperacion ValidaSerieBitacora(string numeroSerie, int idAseguradora, string nombre, string email, bool TicketZendesk = false)
        {
            log.Info("entra a validar seire en labitacora " + numeroSerie);
            var resultado = new EstatusOperacion();
            resultado.Exitoso = true;



            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@NumeroSerie",numeroSerie)
                    ,new SqlParameter("@IdAseguradora",idAseguradora)
                };


            var bitacora = db.BitacoraPolizas.SqlQuery("sp_EMISION_BitacoraPoliza_NumeroSerie @NumeroSerie, @IdAseguradora", parameters.ToArray()).FirstOrDefault();

            if (bitacora != null)
            {
                var tickets = new EnvioTickets();

                if (bitacora.IdZendesk == null)
                {
                    resultado.Exitoso = false;
                    resultado.Mensaje = "Existe una solicitud de Emisión previa, si requieres mayor información comunicate al 800-953-40-40";

                    //Generar ticket zendesk
                    if (TicketZendesk)
                    {
                        //var idZendesk = tickets.ZendeskBloqueoSerie(bitacora, nombre, email);
                        var idZendesk = PloomesProxy.TicketBloqueoSerie(bitacora, nombre, email);
                        var _bitacora = db.BitacoraPolizas.FirstOrDefault(a => a.Id == bitacora.Id);

                        _bitacora.IdZendesk = idZendesk;
                        db.SaveChanges();
                    }

                }
                else
                {
                    //var status = tickets.GetStatusTicket(bitacora.IdZendesk.Value);
                    var status = PloomesProxy.StatusTicket(bitacora.IdZendesk.Value);

                    //if (status != "solved" && status != "closed")
                    if (status == 1) //Abierto
                    {
                        resultado.Exitoso = false;
                        resultado.Mensaje = "Existe una solicitud de Emisión previa, si requieres mayor información comunicate al 800-953-40-40";
                    }

                }

            }


            return resultado;
        }
        #endregion

        #region Cotizacion Test

        private SelectList ListUsosConvenio(int idConvenio, int idTipoVehiculo)
        {
            return new SelectList(db.CatUsos.SqlQuery(string.Format("SELECT C.Id,CASE WHEN C.ClaveGNP = '-' THEN   C.Nombre + ' - ' +  C.ClaveQUALITAS ELSE  C.Nombre + ' - ' +  C.ClaveGNP END Nombre, C.ClaveGNP, C.IdTipoVehiculo, C.ClaveQUALITAS FROM CatUsos C INNER JOIN CatUsosConvenio A ON C.Id= A.IDUSo AND A.IdConvenio= {0} AND A.IdTipoVehiculo = {1} ", idConvenio, idTipoVehiculo)).OrderBy(a => a.Nombre).ToList(), "Id", "Nombre");

        }


        public ActionResult CotizacionTest(int Convenio)
        {
            CotizacionCompara cotizacionCompara = new CotizacionCompara();

            LocktonModel.db.Convenio convenio = (db.Convenio.Where(x => x.Id == Convenio).FirstOrDefault() ?? new LocktonModel.db.Convenio());
            int IdEmpresa = convenio.IdEmpresa;
            int IdAseguradora = convenio.IdAseguradora;
            Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);
            ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);
            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa, convenio.Id);
            bool periodoEnrrollment = EstaEnPeriodoDeEnrollment(IdEmpresa, DateTime.Now);

            ViewBag.NombreAseguradora = (db.Aseguradora.Where(x => x.Id == IdAseguradora).FirstOrDefault() ?? new Aseguradora()).Nombre;
            ViewBag.AseguradoraClave = (db.Aseguradora.Where(x => x.Id == IdAseguradora).FirstOrDefault() ?? new Aseguradora()).ClaveHomologado;

            if (IdAseguradora == 10 && convenio.UsoCatalogoAXAEMA)
                ViewBag.AseguradoraClave = "AXAEMA";

            cotizacionCompara.AseguradoraClaveHomologado = ViewBag.AseguradoraClave;
            cotizacionCompara.IdAseguradora = IdAseguradora;
            ViewBag.NombreEmpresa = (db.Empresa.Where(x => x.Id == IdEmpresa).FirstOrDefault() ?? new Empresa()).NombreComercial;
            ViewBag.CodigoPostal = string.Empty;
            if (ConveniosPaquetes.Convenios.FirstOrDefault().ZonaCirculacion == 2)
            {
                ViewBag.CodigoPostal = (db.Empresa.Where(x => x.Id == IdEmpresa).FirstOrDefault() ?? new Empresa()).Direccion.CodigoPostal;
            }

            ViewBag.Convenio = Convenio;
            ViewBag.FechaFinConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().FinVigencia.ToString("dd/MM/yyyy");

            var catUsoVehiculo = db.CatUsoVehiculo.SqlQuery($"sp_COTIZACION_Aseguradoras_Configuradas {ConveniosPaquetes.configuracionEmpresa.IdEmpresa}").ToList();


            ViewBag.TipoVehiculo = new SelectList(catUsoVehiculo.OrderBy(a => a.IdCatRamo), "Clave", "Nombre");

            //ViewBag.TipoVehiculo = new SelectList(db.CatUsoVehiculo.SqlQuery(string.Format("SELECT C.* FROM CatUsoVehiculo C INNER JOIN CatAseguradoraUsoVehiculo A ON C.Clave= A.ClaveUsoVehiculo AND A.IdAseguradora = {0}", IdAseguradora)).OrderBy(a => a.IdCatRamo).ToList(), "Clave", "Nombre");

            List<int> IdsTipoPaquete = ConveniosPaquetes.PaqueteDetalles.Select(x => x.IdCatTipoPaquete).ToList().Distinct().ToList();
            ViewBag.TipoPaquete = new SelectList(db.CatTipoPaquete.Where(ctp => IdsTipoPaquete.Contains(ctp.Id) && ctp.Estatus == 1).ToList(), "Clave", "Nombre");
            List<int> IdsPeriodicidadPago = ConveniosPaquetes.PeriodicidadFormaPagos.Select(x => x.IdCatPeriodicidadFormaPago).ToList().Distinct().ToList();
            ViewBag.PeriodicidadPago = new SelectList(db.CatPeriodicidadFormaPago.Where(cpfp => IdsPeriodicidadPago.Contains(cpfp.Id) && cpfp.Estatus == 1).ToList(), "Clave", "Nombre");
            ViewBag.CatGenero = new SelectList(db.CatGenero.Where(x => x.Estatus == 1).ToList(), "Clave", "Nombre");

            ViewBag.MuestraFechaCotizacion = configuracionEmpresa.AplicaFechaCotizacion && !periodoEnrrollment;
            cotizacionCompara.RangoFechaCotizacion = configuracionEmpresa.AplicaFechaCotizacion ? configuracionEmpresa.RangoFechaCotizacion : 15;
            cotizacionCompara.EsFlotilla = configuracionEmpresa.IdTipoDeNegocio == 1 || configuracionEmpresa.IdTipoDeNegocio == 4;
            ViewBag.EsPreferenteGNP = ((Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').Contains(convenio.IdEmpresa.ToString()) || Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS")) && convenio.IdCatTipoConvenio.Equals(2));
            ViewBag.Usos = ListUsosConvenio(Convenio, 1);

            cotizacionCompara.Multianual = configuracionEmpresa.AplicaMultiAnual;

            return View(cotizacionCompara);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CotizacionTest(CotizacionCompara cotizacionCompara, int IdConvenio, DetalleUsuario detalleUsuario)
        {
            LocktonModel.db.Convenio convenio = (db.Convenio.Where(x => x.Id == IdConvenio).FirstOrDefault() ?? new LocktonModel.db.Convenio());
            int IdEmpresa = convenio.IdEmpresa;
            int IdAseguradora = convenio.IdAseguradora;
            var asegu = db.Aseguradora.FirstOrDefault(a => a.Id == IdAseguradora);
            Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == IdEmpresa);
            ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == IdEmpresa);
            bool usuarioAlias = false;
            detalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);

            var catusovehiculo = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == cotizacionCompara.TipoVehiculo);
            int idCarRamoVehiculo = catusovehiculo.IdCatRamo ?? 1;

            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(IdEmpresa, idCarRamoVehiculo.ToString());
            var paqueteConvenio = ConveniosPaquetes.Convenios.FirstOrDefault(x => x.Id == IdConvenio).PaqueteConvenio.FirstOrDefault(a => a.Id == cotizacionCompara.Cobertura && a.IdCatRamoVehiculo == idCarRamoVehiculo);

            Cotizar consultar = new Cotizar();
            string aseguradora = asegu.ClaveHomologado;
            string claveAseguradora = string.Empty;

            if (asegu.Id == 10 && convenio.UsoCatalogoAXAEMA)
                aseguradora = "AXAEMA";

            foreach (string clave in cotizacionCompara.Descripcion.Split(','))
            {
                if (clave.Split('|')[0].ToUpper().Equals(aseguradora.ToUpper()))
                {
                    claveAseguradora = clave.Split('|')[1];
                    break;
                }
            }

            ObtenerFechaCotizacion(configuracionEmpresa, ConveniosPaquetes, asegu.Id, IdEmpresa, ref cotizacionCompara);

            if (configuracionEmpresa.AplicaFechaCotizacion)
                cotizacionCompara.FechaFactura = cotizacionCompara.FechaCotizacion;

            cot = consultar.ConsultaParaCotiza(cotizacionCompara, aseguradora, claveAseguradora);
            CotizacionCompara cotresp = consultar.Cotizacion(cotizacionCompara, convenio.Aseguradora.ClaveHomologado, cot, IdConvenio, detalleUsuario, ConveniosPaquetes, paqueteConvenio.IdCatTipoPaquete, paqueteConvenio.Id, idUsuarioLogin: User.Identity.GetUserId(), true);

            ViewBag.NombreAseguradora = (db.Aseguradora.Where(x => x.Id == IdAseguradora).FirstOrDefault() ?? new Aseguradora()).Nombre;
            ViewBag.AseguradoraClave = (db.Aseguradora.Where(x => x.Id == IdAseguradora).FirstOrDefault() ?? new Aseguradora()).ClaveHomologado;

            if (IdAseguradora == 10 && convenio.UsoCatalogoAXAEMA)
                ViewBag.AseguradoraClave = "AXAEMA";

            ViewBag.NombreEmpresa = (db.Empresa.Where(x => x.Id == IdEmpresa).FirstOrDefault() ?? new Empresa()).NombreComercial;
            ViewBag.DescripcionCotizada = string.Format("{0} {1} ==> Amis: {2}", cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault().Descripcion.TrimEnd() ?? "", cotizacionCompara.Año, cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault().clave ?? "");
            ViewBag.Convenio = IdConvenio;
            ViewBag.TipoVehiculo = new SelectList(db.CatUsoVehiculo.SqlQuery(string.Format("SELECT C.* FROM CatUsoVehiculo C INNER JOIN CatAseguradoraUsoVehiculo A ON C.Clave= A.ClaveUsoVehiculo AND A.IdAseguradora = {0}", IdAseguradora)).OrderBy(a => a.IdCatRamo).ToList(), "Clave", "Nombre");
            ViewBag.FechaFinConvenio = ConveniosPaquetes.Convenios.FirstOrDefault().FinVigencia.ToString("dd/MM/yyyy");
            ViewBag.Usos = ListUsosConvenio(IdConvenio, 1);
            List<int> IdsTipoPaquete = ConveniosPaquetes.PaqueteDetalles.Select(x => x.IdCatTipoPaquete).ToList().Distinct().ToList();
            ViewBag.TipoPaquete = new SelectList(db.CatTipoPaquete.Where(ctp => IdsTipoPaquete.Contains(ctp.Id) && ctp.Estatus == 1).ToList(), "Clave", "Nombre");
            List<int> IdsPeriodicidadPago = ConveniosPaquetes.PeriodicidadFormaPagos.Select(x => x.IdCatPeriodicidadFormaPago).ToList().Distinct().ToList();
            ViewBag.PeriodicidadPago = new SelectList(db.CatPeriodicidadFormaPago.Where(cpfp => IdsPeriodicidadPago.Contains(cpfp.Id) && cpfp.Estatus == 1).ToList(), "Clave", "Nombre");
            ViewBag.CatGenero = new SelectList(db.CatGenero.Where(x => x.Estatus == 1).ToList(), "Clave", "Nombre");
            PaqueteAseguradora paquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == IdAseguradora && x.IdCatTipoPaquete == paqueteConvenio.IdCatTipoPaquete).FirstOrDefault();
            //if (paquete != null)
            ViewBag.Paquete = paqueteConvenio.NombrePaquete;
            ViewBag.FormaPago = db.CatPeriodicidadFormaPago.Where(x => x.Id == cotizacionCompara.FormadePago).FirstOrDefault().Nombre.ToUpper();
            ViewBag.Error = cotresp.Comparar.FirstOrDefault().ErrorXML;
            ViewBag.MuestraFechaCotizacion = configuracionEmpresa.AplicaFechaCotizacion && !cotizacionCompara.PeriodoEnrollment;


            return View(cotizacionCompara);
        }

        public void ObtenerFechaCotizacion(ConfiguracionEmpresa configuracion, VEmpConvPaq ConveniosPaquetes, int idAseguradora, int idEmpresa, ref CotizacionCompara cotizacionCompara)
        {
            cotizacionCompara.FechaInicio = DateTime.Now;
            cotizacionCompara.FechaFin = DateTime.Now.AddYears(1);
            cotizacionCompara.PeriodoEnrollment = false;

            var convenio = ConveniosPaquetes.Convenios.FirstOrDefault(a => a.IdAseguradora == idAseguradora);

            if (configuracion.AplicaFechaCotizacion)
            {
                cotizacionCompara.FechaInicio = cotizacionCompara.FechaCotizacion;
                cotizacionCompara.FechaFin = cotizacionCompara.FechaCotizacion.AddYears(1);
            }

            if (convenio.IdCatTipoVigencia == 1)//Vigencia Prorrata
                cotizacionCompara.FechaFin = convenio.FinVigencia;

            if (configuracion.AplicaMultiAnual)
            {
                var idMultianual = cotizacionCompara.IdCatPeriodicidadMultianual;
                var catPeriodicidadMultianual = db.CatPeriodicidadMultianual.FirstOrDefault(a => a.Id == idMultianual);

                if (catPeriodicidadMultianual != null)
                {

                    cotizacionCompara.FechaFin = cotizacionCompara.FechaInicio.AddMonths(catPeriodicidadMultianual.Valor);
                }
            }

            cotizacionCompara.PeriodoEnrollment = EstaEnPeriodoDeEnrollment(idEmpresa, cotizacionCompara.FechaInicio);

            if (idAseguradora == 1 || idAseguradora == 3 || idAseguradora == 20 || idAseguradora == 5)
            {
                var _inicio = cotizacionCompara.FechaInicio;
                var caratula = db.CatCaratulaQUALITAS.FirstOrDefault(a => a.IdMes == _inicio.Month && a.IdConvenio == convenio.Id);

                if (caratula != null)
                {
                    cotizacionCompara.FechaFin = caratula.FechaFin;
                }
            }

            //verifica las fechas de inicio
            if (cotizacionCompara.PeriodoEnrollment)
            {//busca si existe fecha de enrollment
                cotizacionCompara.FechaInicio = convenio.InicioVigencia;
                cotizacionCompara.FechaFin = convenio.FinVigencia;
            }


        }

        #endregion

        #region vistas genericas
        //[CustomAuthorize]
        // GET: Cotizacion
        public ActionResult Index()
        {
            bool usuarioAlias = false;
            DetalleUsuario detUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);

            List<VCotizacionesUsuario> cotizacionesUsuario = new List<VCotizacionesUsuario>();
            var cotizaciones = (from cotizacionauto in db.CotizacionAuto
                                join cotizciones in db.Cotizacion on cotizacionauto.IdCotizacion equals cotizciones.Id
                                join CotDetalle in db.CotizacionDetalle on cotizciones.Id equals CotDetalle.IdCotizacion
                                join aseguradora in db.Aseguradora on CotDetalle.IdAseguradora equals aseguradora.Id
                                where cotizciones.IdDetalleUsuario == detUsuario.Id && cotizciones.Estatus == 1
                                select new
                                {
                                    cotizacionauto.IdCotizacion,
                                    aseguradora.Nombre,
                                    cotizacionauto.Marca,
                                    cotizacionauto.Agnio,
                                    cotizacionauto.Modelo,
                                    cotizacionauto.Version,
                                    cotizacionauto.Descripcion,
                                    cotizciones.FechaHora,
                                    CotDetalle.PrimaTotalAnual,
                                    CotDetalle.Paquete,
                                }).ToList();

            if (cotizaciones.Count > 0)
            {
                foreach (var item in cotizaciones)
                {
                    int idPaquete = Convert.ToInt32(item.Paquete);
                    VCotizacionesUsuario coti = new VCotizacionesUsuario()
                    {
                        IdCotizacion = item.IdCotizacion,
                        NombreAseguradora = item.Nombre,
                        Marca = item.Marca,
                        Agnio = item.Agnio,
                        Modelo = item.Modelo,
                        Version = item.Version,
                        Descripcion = item.Descripcion,
                        FechaCotizacion = item.FechaHora,
                        PrimaTotalAnual = item.PrimaTotalAnual,
                        Paquete = db.CatTipoPaquete.Where(x => x.Id == idPaquete).FirstOrDefault().Nombre.ToUpper()
                    };

                    cotizacionesUsuario.Add(coti);
                }
            }

            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.MisCotizaciones);
            return View(cotizacionesUsuario);
        }

        [CustomAuthorize]
        // GET: Cotizacion/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cotizacion cotizacion = db.Cotizacion.Find(id);
            if (cotizacion == null)
            {
                return HttpNotFound();
            }
            return View(cotizacion);
        }
        [CustomAuthorize]
        // GET: Cotizacion/Create
        public ActionResult Create()
        {
            return View();
        }
        [CustomAuthorize]
        // POST: Cotizacion/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,IdAseguradora,IdCotizacionDetalle,FechaHora,ValorFactura,FechaFactura,NumeroFactura,SumaLegalizado")] Cotizacion cotizacion)
        {
            if (ModelState.IsValid)
            {
                //db.Cotizacion.Add(cotizacion);
                //db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(cotizacion);
        }
        [CustomAuthorize]
        // GET: Cotizacion/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cotizacion cotizacion = db.Cotizacion.Find(id);
            if (cotizacion == null)
            {
                return HttpNotFound();
            }
            return View(cotizacion);
        }
        [CustomAuthorize]
        // POST: Cotizacion/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,IdAseguradora,IdCotizacionDetalle,FechaHora,ValorFactura,FechaFactura,NumeroFactura,SumaLegalizado")] Cotizacion cotizacion)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cotizacion).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(cotizacion);
        }
        [CustomAuthorize]
        // GET: Cotizacion/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cotizacion cotizacion = db.Cotizacion.Find(id);
            if (cotizacion == null)
            {
                return HttpNotFound();
            }
            return View(cotizacion);
        }

        // POST: Cotizacion/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Cotizacion cotizacion = db.Cotizacion.Find(id);
            db.Cotizacion.Remove(cotizacion);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        #endregion

        #region Consultas Ajax ComboBox
        public bool UsuarioMultipleAseguradora(string userName)
        {
            bool multiple = false;
            string aseguradora = "";
            string aseguradorasusuario = "";
            int idAseguradora = 0;

            if (System.Web.HttpContext.Current.Session["__USUARIO__MULTIPLEASEGURADORA__"] == null)
            {
                SqlParameter sqlUserName = new SqlParameter("@UserName", userName);
                List<sp_COTIZACION_Aseguradoras_Usuario> aseguradoras = db.sp_COTIZACION_Aseguradoras_Usuario.SqlQuery("sp_COTIZACION_Aseguradoras_Usuario @UserName", sqlUserName).ToList();
                aseguradorasusuario = string.Join(",", aseguradoras.Select(a => a.ClaveHomologado));

                if (aseguradoras.Count > 1)
                {
                    multiple = true;
                }
                else if (aseguradoras.Count > 0)
                {
                    aseguradora = aseguradoras.First().ClaveHomologado;
                    idAseguradora = aseguradoras.First().Id;
                }

                System.Web.HttpContext.Current.Session.Add("__USUARIO__MULTIPLEASEGURADORA__", Convert.ToInt32(multiple));
                System.Web.HttpContext.Current.Session.Add("__USUARIO__MULTIPLEASEGURADORA__CLAVE__", aseguradora);
                System.Web.HttpContext.Current.Session.Add("__USUARIO__MULTIPLEASEGURADORA__KEY__", idAseguradora);
                System.Web.HttpContext.Current.Session.Add("__USUARIO__MULTIPLEASEGURADORA__ASEGURADORAS__", aseguradorasusuario);
            }

            string value = System.Web.HttpContext.Current.Session["__USUARIO__MULTIPLEASEGURADORA__"].ToString();
            int _v = 0;
            if (int.TryParse(value, out _v))
                multiple = Convert.ToBoolean(_v);

            ViewBag.MultipleAseguradora = multiple;
            ViewBag.AseguradorasUsuario = System.Web.HttpContext.Current.Session["__USUARIO__MULTIPLEASEGURADORA__ASEGURADORAS__"].ToString();
            return multiple;

        }
        public string UsuarioAseguradoraEmpresa(string idUser)
        {
            if (System.Web.HttpContext.Current.Session["__USUARIO__MULTIPLEASEGURADORA__CLAVE__"] == null)
                UsuarioMultipleAseguradora(idUser);

            string aseguradora = System.Web.HttpContext.Current.Session["__USUARIO__MULTIPLEASEGURADORA__CLAVE__"].ToString();
            return aseguradora;
        }

        public int UsuarioKeyAseguradoraEmpresa(string userName, string idUser)
        {
            if (System.Web.HttpContext.Current.Session["__USUARIO__MULTIPLEASEGURADORA__KEY__"] == null)
                UsuarioMultipleAseguradora(idUser);

            int aseguradora = Convert.ToInt32(System.Web.HttpContext.Current.Session["__USUARIO__MULTIPLEASEGURADORA__CLAVE__"].ToString());
            return aseguradora;
        }
        public JsonResult ValidaTipoVehiculo(int idTipoVehiculo)
        {
            string userName = User.Identity.GetUserName();

            if (Session["UserNameUsuarioReemplazo"] != null)
                userName = Session["UserNameUsuarioReemplazo"].ToString();

            bool multipleAseguradora = UsuarioMultipleAseguradora(User.Identity.GetUserId());
            SqlParameter sqlUserName = new SqlParameter("@UserName", userName);
            SqlParameter sqlIdTipoVehiculo = new SqlParameter("@IdTipoVehiculo", idTipoVehiculo);
            var aseguradoras = db.ListaCombo.SqlQuery("sp_COTIZACION_Aseguradoras_TipoVehiculo @UserName, @IdTipoVehiculo ", sqlUserName, sqlIdTipoVehiculo).ToList();
            bool redireccionaContacto = !aseguradoras.Any();

            return Json(new { RedireccionaContacto = redireccionaContacto, Aseguradoras = aseguradoras, MultipleAseguradora = multipleAseguradora }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Marcas(string Marca, string Aseguradora = "", int? idTipoVehiculo = null)
        {
            Cotizar consultar = new Cotizar();
            bool usuarioAlias = false;
            DetalleUsuario RegDetalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);

            string user = RegDetalleUsuario.IdUsuario;

            bool multipleAseguradora = UsuarioMultipleAseguradora(user);

            if (!multipleAseguradora && Aseguradora == "")
                Aseguradora = UsuarioAseguradoraEmpresa(user);

            if (!string.IsNullOrEmpty(Aseguradora))
            {
                multipleAseguradora = false;
            }

            if (idTipoVehiculo != null && !AplicaUsoVehiculo(Aseguradora, idTipoVehiculo.ToString()))
            {
                idTipoVehiculo = null;
            }

            List<string> resultado = consultar.ConsultaMarcaHomologado(Marca, Aseguradora, multipleAseguradora, idTipoVehiculo);

            if (!string.IsNullOrWhiteSpace(Marca))
            {
                var detalleUsuarioEmpresa = db.DetalleUsuarioEmpresa
                    .FirstOrDefault(x => x.IdDetalleUsuario == RegDetalleUsuario.Id);

                if (detalleUsuarioEmpresa != null)
                {
                    var configuracionEmpresa = db.ConfiguracionEmpresa
                        .FirstOrDefault(x => x.IdEmpresa == detalleUsuarioEmpresa.IdEmpresa);

                    if (configuracionEmpresa != null &&
                        configuracionEmpresa.AplicaAntiguedadVehiculo &&
                        configuracionEmpresa.AntiguedadVehiculo.HasValue)
                    {
                        int anioMinimo = DateTime.Now.Year - configuracionEmpresa.AntiguedadVehiculo.Value;

                        resultado = resultado
                            .Where(x => int.TryParse(x, out int anio) && anio >= anioMinimo)
                            .ToList();
                    }
                }
            }

            return new JsonResult()
            {
                Data = resultado
            };
        }


        public JsonResult VersionSinHomologado(string aseguradora, string marca, int year, int idTipoVehiculo)
        {
            var versiones = db.VersionAseguradora.SqlQuery($"[CatalogoHomologadoAutos]. [dbo].[spConsultaClavesAseguradoraUnica_NoHomologado] '{marca}',{year},'{aseguradora}',{idTipoVehiculo}").ToList();
            return new JsonResult() { Data = versiones };
        }

        public JsonResult UsosConvenio(int idConvenio, int idTipoVehiculo)
        {
            var usos = ListUsosConvenio(idConvenio, idTipoVehiculo);

            return new JsonResult() { Data = usos };
        }

        private bool AplicaUsoVehiculo(string aseguradora, string idTipoVehiculo)
        {
            if (string.IsNullOrEmpty(aseguradora))
                return false;

            if (aseguradora == "AXAEMA")
                aseguradora = "AXA";

            var _asegurdara = db.Aseguradora.FirstOrDefault(a => a.ClaveHomologado == aseguradora);
            var _uso = db.CatAseguradoraUsoVehiculo.FirstOrDefault(a => a.IdAseguradora == _asegurdara.Id && a.ClaveUsoVehiculo == idTipoVehiculo);

            return _uso != null;
        }
        public JsonResult Bloques(int idTipoCobertura, int idConvenio)
        {
            var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
            ConsultaHomologacion consultaHomologacion = new ConsultaHomologacion();
            CatTipoPaquete tipoPaquete = db.CatTipoPaquete.FirstOrDefault(a => a.Id == idTipoCobertura);
            CostosInbursa data = consultaHomologacion.ConsultarCostosInbursa("", 0, Convert.ToInt32(tipoPaquete.Clave), convenio.IdTarifa ?? 0);
            if (tipoPaquete.Clave == "3")
                data.Costos.ForEach(a => a.Bloque = a.Bloque.Substring(a.Bloque.LastIndexOf("RT")));

            return new JsonResult() { Data = data };
        }

        public JsonResult Agno(string Marca, string Agno, string Aseguradora = "", int? idTipoVehiculo = null)
        {
            Cotizar consultar = new Cotizar();

            string user = User.Identity.GetUserId();

            bool multipleAseguradora = UsuarioMultipleAseguradora(user);

            if (!string.IsNullOrEmpty(Aseguradora))
            {
                multipleAseguradora = false;
            }
            if (!multipleAseguradora && Aseguradora == "")
                Aseguradora = UsuarioAseguradoraEmpresa(user);

            if (idTipoVehiculo != null && !AplicaUsoVehiculo(Aseguradora, idTipoVehiculo.ToString())) //(Aseguradora != "INBURSA" && Aseguradora != "QUALITAS" && Aseguradora != "GNP"))//Actualmente solo aplica para inbursa y Qualitas
            {
                idTipoVehiculo = null;
            }

            return new JsonResult() { Data = consultar.ConsultaAgnoHomologado(Marca, Agno, Aseguradora, multipleAseguradora, idTipoVehiculo) };
        }

        public JsonResult Version(string Marca, string Agno, string Modelo, string Aseguradora = "")
        {
            Cotizar consultar = new Cotizar();
            //string Aseguradora = ""; //"QUALITAS"
            //return new JsonResult() { Data = consultar.ConsultaModelo(Marca, Agno, Modelo, Aseguradora) };
            return new JsonResult() { Data = /*consultar.ConsultaModeloHomologado(Marca, Agno, Modelo, Aseguradora)*/ new List<string>() };
        }

        public JsonResult Descripcion(string Marca, string Agno, string Modelo, string Version, string Aseguradora = "", int? idTipoVehiculo = null)
        {
            Cotizar consultar = new Cotizar();

            string user = User.Identity.GetUserId();

            bool multipleAseguradora = UsuarioMultipleAseguradora(user);

            if (!string.IsNullOrEmpty(Aseguradora))
            {
                multipleAseguradora = false;
            }
            if (!multipleAseguradora && Aseguradora == "")
                Aseguradora = UsuarioAseguradoraEmpresa(user);

            if (idTipoVehiculo != null && !AplicaUsoVehiculo(Aseguradora, idTipoVehiculo.ToString())) //(Aseguradora != "INBURSA" && Aseguradora != "QUALITAS" && Aseguradora != "GNP"))//Actualmente solo aplica para inbursa y Qualitas
            {
                idTipoVehiculo = null;
            }
            //else if (Aseguradora != "INBURSA") idTipoVehiculo = null;

            return new JsonResult() { Data = consultar.ConsultaDescripcionHomologado(Marca, Agno, Modelo, Version, Aseguradora, multipleAseguradora, idTipoVehiculo) };
        }


        //public JsonResult Año(string str)
        //{
        //    JsonResult jsonResult = new JsonResult();
        //    Cotizar consultar = new Cotizar();

        //    var resp = consultar.Consulta(str, ref cot);

        //    jsonResult.Data = resp;
        //    return jsonResult;
        //}

        //public JsonResult Modelos(string str)
        //{
        //    JsonResult jsonResult = new JsonResult();
        //    Cotizar consultar = new Cotizar();

        //    var resp = consultar.Consulta(str, ref cot);

        //    jsonResult.Data = resp;
        //    return jsonResult;
        //}

        //public JsonResult Version(string str)
        //{
        //    JsonResult jsonResult = new JsonResult();
        //    Cotizar consultar = new Cotizar();

        //    var resp = consultar.Consulta(str, ref cot);

        //    jsonResult.Data = resp;
        //    return jsonResult;
        //}

        //public JsonResult Descripcion(string str)
        //{
        //    JsonResult jsonResult = new JsonResult();
        //    Cotizar consultar = new Cotizar();

        //    var resp = consultar.Consulta(str, ref cot);

        //    jsonResult.Data = resp;
        //    return jsonResult;
        //}

        public JsonResult Autos(string str)
        {
            JsonResult jsonResult = new JsonResult();
            Cotizar consultar = new Cotizar();

            List<string> resp = consultar.Consulta(str, ref cot);

            jsonResult.Data = resp;
            return jsonResult;
        }

        //public JsonResult Cotizar(string str)
        //{
        //    JsonResult jsonResult = new JsonResult();
        //    Cotizar consultar = new Cotizar();

        //    var resp = consultar.Consulta(str, ref cot);
        //    var cotresp = consultar.Cotizacion(null, "Qualitas", cot, null, null);

        //    jsonResult.Data = resp;
        //    return jsonResult;
        //}
        private bool UsuarioAdministrador()
        {
            var idUsuario = User.Identity.GetUserId();
            var usuarioFinal = db.DetalleUsuario.FirstOrDefault(x => x.IdUsuario == idUsuario);
            var administrador = usuarioFinal.IdPerfil == 2 || usuarioFinal.IdPerfil == 4 || usuarioFinal.IdPerfil == 6;
            return administrador;
        }

        public JsonResult PeriodicidadMultianual(int IdFormadePago, int IdConvenio)
        {

            var convenio = db.Convenio.FirstOrDefault(a => a.Id == IdConvenio);
            var lista = db.ListaCombo.SqlQuery(string.Format("sp_consultar_PeriodicidadMultianual @IdEmpresa={0}, @IdFormaPago={1}", convenio.IdEmpresa, IdFormadePago)).ToList();

            return Json(lista, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MediodePago(int IdFormadePago, int IdConvenio)
        {
            var administrador = UsuarioAdministrador();
            var convenio = db.Convenio.FirstOrDefault(a => a.Id == IdConvenio);
            var lista = db.ListaCombo.SqlQuery(string.Format("sp_consultar_ModalidadFormaPago @IdEmpresa={0}, @IdFormaPago={1}, @Admin = {2}", convenio.IdEmpresa, IdFormadePago, Convert.ToInt32(administrador))).ToList();

            return Json(lista, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MediodePagoAutos(int IdFormadePago, int IdEmpresa)
        {

            var lista = db.ListaCombo.SqlQuery(string.Format("sp_consultar_ModalidadFormaPago_Configuracion @IdEmpresa={0}, @IdFormaPago={1}, @Admin = 1", IdEmpresa, IdFormadePago)).ToList();

            return Json(lista, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ObtenerFormaPago(int idConvenio, int? idAseguradora)
        {

            var lista = new List<ListaCombo>();

            var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
            var idEmpresa = convenio.IdEmpresa;

            if (idAseguradora.HasValue)
                lista = db.ListaCombo.SqlQuery(string.Format("sp_consultar_Periodicidad @IdEmpresa = {0}, @IdAseguradora = {1}", idEmpresa, idAseguradora)).ToList();
            else
                lista = db.ListaCombo.SqlQuery(string.Format("sp_consultar_Periodicidad @IdEmpresa = {0}", idEmpresa)).ToList();


            return Json(lista, JsonRequestBehavior.AllowGet);
        }

        public JsonResult MediodePagoCompra(int IdFormadePago, int IdConvenio)
        {
            var administrador = UsuarioAdministrador();

            var medioPago = db.ListaCombo.SqlQuery(string.Format("sp_consultar_ModalidadFormaPagoConvenio @IdConvenio={0}, @IdFormaPago={1}", IdConvenio, IdFormadePago)).ToList();
            var formaPago = db.ListaCombo.SqlQuery(string.Format("sp_consultar_PeriodicidadFormaPago @IdConvenio={0}", IdConvenio)).ToList();

            return Json(new { MediosPago = medioPago, FormasPago = formaPago }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult FormadePagoCompra(int IdConvenio)
        {
            var administrador = UsuarioAdministrador();


            var formaPago = db.ListaCombo.SqlQuery(string.Format("sp_consultar_PeriodicidadFormaPago @IdConvenio={0}", IdConvenio)).ToList();

            return Json(new { FormasPago = formaPago }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult FormadePagoCompraEmpresa(int IdConvenio)
        {
            var administrador = UsuarioAdministrador();
            var convenio = db.Convenio.FirstOrDefault(a => a.Id == IdConvenio);

            var parameter = new List<SqlParameter>() {
                new SqlParameter("@IdEmpresa",convenio.IdEmpresa),
                new SqlParameter("@IdAseguradora",convenio.IdAseguradora)
            };

            var formaPago = db.ListaCombo.SqlQuery("sp_consultar_PeriodicidadFormaPago_Empresa @IdEmpresa,@IdAseguradora", parameter.ToArray()).ToList();

            return Json(new { FormasPago = formaPago }, JsonRequestBehavior.AllowGet);
        }



        public JsonResult RecotizacionCompra(int idConvenio, int idCotizacionDetalle, int idFormaPago, int idMedioPago)
        {
            var detalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == idCotizacionDetalle);
            var auto = db.CotizacionAuto.FirstOrDefault(a => a.IdCotizacion == detalle.IdCotizacion);
            var cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == detalle.IdCotizacion);
            var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);

            //validar convenio de la forma y medio de pago seleccionados
            var parameter = new List<SqlParameter>() {
                new SqlParameter("@IdEmpresa",convenio.IdEmpresa),
                new SqlParameter("@IdAseguradora",convenio.IdAseguradora),
                new SqlParameter("@IdFormaPago",idFormaPago),
                new SqlParameter("@IdMedioPago",idMedioPago)
            };

            idConvenio = db.Database.SqlQuery<int>("sp_consultar_CONVENIO_FormaMedioPago @IdEmpresa, @IdAseguradora, @IdFormaPago, @IdMedioPago", parameter.ToArray()).SingleOrDefault();

            VEmpConvPaq ConveniosPaquetes = new VEmpConvPaq(convenio.IdEmpresa, idConvenio);
            bool usuarioAlias = false;
            var detalleUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            var configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == convenio.IdEmpresa);

            Cotizar consultar = new Cotizar();
            CotizacionCompara cotizacionCompara = new CotizacionCompara();
            ObtenerFechaCotizacion(configuracionEmpresa, ConveniosPaquetes, convenio.IdAseguradora, convenio.IdEmpresa, ref cotizacionCompara);
            cotizacionCompara.AseguradoraClaveHomologado = convenio.Aseguradora.ClaveHomologado;
            cotizacionCompara.Año = auto.Agnio;
            cotizacionCompara.ClaveAMIS = detalle.AMIS;
            cotizacionCompara.ClaveHomologadaSeleccionada = detalle.AMIS;
            cotizacionCompara.Cobertura = Convert.ToInt32(detalle.Paquete);
            cotizacionCompara.CodigoPostal = cotizacion.CodigoPostal;
            cotizacionCompara.ComparativoAnual = true;
            cotizacionCompara.Descripcion = auto.Descripcion;
            cotizacionCompara.DetalleUsuario = detalleUsuario;
            cotizacionCompara.Edad = cotizacion.Edad > 0 ? cotizacion.Edad.ToString() : Utilidades.CalculaEdad(detalleUsuario.FECHANACIMIENTO).ToString();
            cotizacionCompara.EsFlotilla = configuracionEmpresa.IdTipoDeNegocio == 1 || configuracionEmpresa.IdTipoDeNegocio == 4;
            cotizacionCompara.FechaCotizacion = detalle.FechaCotizacion ?? DateTime.Now;
            cotizacionCompara.FechaFactura = auto.FechaFactura;
            cotizacionCompara.FormadePago = idFormaPago;
            //	cotizacionCompara.Genero = cotizacion.IdCatGenero;
            cotizacionCompara.IdAseguradora = convenio.IdAseguradora;
            cotizacionCompara.IdConvenio = idConvenio;
            cotizacionCompara.Marca = auto.Marca;
            cotizacionCompara.MediodePago = idMedioPago;
            cotizacionCompara.Modelo = auto.Modelo;
            cotizacionCompara.MontoFactura = auto.MontoFactura;
            cotizacionCompara.IdUso = cotizacion.IdUso ?? 1;
            cotizacionCompara.MontoDeclarado = auto.MontoDeclarado;

            cotizacionCompara.TipoVehiculo = auto.TipoVehiculo;
            cot = consultar.ConsultaParaCotiza(cotizacionCompara, convenio.Aseguradora.ClaveHomologado, detalle.AMIS);

            CotizacionCompara cotresp = consultar.Cotizacion(cotizacionCompara, convenio.Aseguradora.ClaveHomologado, cot, idConvenio, detalleUsuario, ConveniosPaquetes, Convert.ToInt32(detalle.Paquete), detalle.IdPaqueteConvenio.Value, idUsuarioLogin: User.Identity.GetUserId());
            var primaTotal = string.Format("$ {0} MXN", cotresp.Comparar.FirstOrDefault().PrimaTotal);
            var primerPago = string.Format("$ {0} MXN", cotresp.Comparar.FirstOrDefault().PrimerPago);
            var segundoPago = string.Format("$ {0} MXN", cotresp.Comparar.FirstOrDefault().SegundoPago);
            var mostrarPagos = cotresp.Comparar.FirstOrDefault().NumeroDePagos > 1;
            var idGenerado = GuardaCotizacionDetalleCompra(detalle.IdCotizacion, cotresp);
            return Json(new
            {
                IdCotizacionDetalle = idGenerado
                ,
                PrimaTotal = primaTotal
                ,
                PrimerPago = primerPago
                ,
                SegundoPago = segundoPago
                ,
                MostrarPagos = mostrarPagos
            }, JsonRequestBehavior.AllowGet);

        }

        public JsonResult ComparativoAnualActualizaCotizacion(int idDetalle, int idMedioPago)
        {
            var cotizaciondetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == idDetalle);
            //var cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizaciondetalle.IdCotizacion);
            var cotizacionauto = db.CotizacionAuto.FirstOrDefault(a => a.IdCotizacion == cotizaciondetalle.IdCotizacion);
            cotizacionauto.MediodePago = idMedioPago;
            cotizacionauto.FormadePago = cotizaciondetalle.IdFormaPago ?? 0;
            db.SaveChanges();


            return Json(true, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ComparativoAnualObtenerCotizacion(int idDetalle)
        {
            var cotizaciondetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == idDetalle);
            var cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizaciondetalle.IdCotizacion);
            var cotizacionauto = db.CotizacionAuto.FirstOrDefault(a => a.IdCotizacion == cotizaciondetalle.IdCotizacion);
            var periodicidadFormaPago = db.PeriodicidadFormaPago.FirstOrDefault(a => a.IdConvenio == cotizaciondetalle.IdConvenio);
            var convenio = db.Convenio.FirstOrDefault(a => a.Id == cotizaciondetalle.IdConvenio);
            var medio = db.ListaCombo.SqlQuery(string.Format("sp_consultar_ModalidadFormaPagoConvenio @IdConvenio={0}, @IdFormaPago={1}", cotizaciondetalle.IdConvenio, periodicidadFormaPago.IdCatPeriodicidadFormaPago)).FirstOrDefault();
            int idPaquete = Convert.ToInt32(cotizaciondetalle.Paquete);

            cotizacion.IdPeriodicidadPago = periodicidadFormaPago.IdCatPeriodicidadFormaPago;
            cotizacionauto.FormadePago = periodicidadFormaPago.IdCatPeriodicidadFormaPago;
            cotizacionauto.MediodePago = medio.Id;
            db.SaveChanges();

            Comparar infoInbursa = new INBURSAService().LeeXmlRespuesta(cotizaciondetalle.XMLRecepcion, idPaquete, Convert.ToInt32(cotizacionauto.Agnio), cotizacion, cotizaciondetalle, convenio, cotizacionauto.TipoVehiculo);

            return Json(new
            {
                MedioPago = medio.Nombre
                                ,
                FormaPago = periodicidadFormaPago.FormaPago
                                ,
                PrimaTotal = string.Concat("$ ", double.Parse(infoInbursa.PrimaTotal).ToString("N2"), " MXN")
                                ,
                PrimerPago = string.Concat("$ ", double.Parse(infoInbursa.PrimerPago).ToString("N2"), " MXN")
                                ,
                SegundoPago = infoInbursa.SegundoPago == "" ? "" : string.Concat("$ ", double.Parse(infoInbursa.SegundoPago).ToString("N2"), " MXN")
            }, JsonRequestBehavior.AllowGet);
        }


        #endregion

        #region Utiles
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }





        private CatCarriers ObtieneCarrier(string NumeroTarjeta)
        {
            switch (NumeroTarjeta.Substring(0, 1))
            {
                case "3":
                    return db.CatCarriers.Where(x => x.Clave.Equals("AMEX")).FirstOrDefault();
                case "4":
                    return db.CatCarriers.Where(x => x.Clave.Equals("VISA")).FirstOrDefault();
                case "5":
                    return db.CatCarriers.Where(x => x.Clave.Equals("MASTER CARD")).FirstOrDefault();
                case "6":
                    return db.CatCarriers.Where(x => x.Clave.Equals("DISCOVERY CARD")).FirstOrDefault();
                default:
                    return db.CatCarriers.Where(x => x.Clave.Equals("VISA")).FirstOrDefault();
            }
        }

        //public void PolizaAliasLog(String numeroPoliza)
        //{
        //    try
        //    {
        //        Poliza poliza = db.Poliza.Where(x => x.NumeroPoliza.Equals(numeroPoliza)).FirstOrDefault();
        //        string usuario = User.Identity.GetUserId();
        //        DetalleUsuario detalleusuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();
        //        if (poliza != null && (detalleusuario.IdPerfil == 2 || detalleusuario.IdPerfil == 4 || detalleusuario.IdPerfil == 6))
        //        {
        //            db.PolizaAliasLog.Add(new PolizaAliasLog() { IdPoliza = poliza.Id, IdUsuarioAlias = detalleusuario.Id });
        //            db.SaveChanges();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        log.Info("Error al insertar en PolizaAliasLog: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
        //    }
        //}
        #endregion

        #region Vistas Parciales

        public ActionResult CotizacionAuto(string Marca, string DescripcionVehiculo, string ModeloVehiculo, string InicioVigencia, string FinVigencia, string TipoCobertura, string PrimaTotal = "", string Aseguradora = "", string NombreTipoVehiculo = "", string idTipovehiculo = "", bool muestraAviso = true)
        {
            //CotizacionAuto cotAuto = db.CotizacionAuto.FirstOrDefault(x => x.Descripcion.Equals(DescripcionVehiculo) && x.Agnio.Equals(ModeloVehiculo));
            if (!string.IsNullOrWhiteSpace(Aseguradora))
                ViewBag.ImagenAseguradora = string.Concat(Aseguradora, ".png");

            ViewBag.DescripcionVehiculo = DescripcionVehiculo;
            ViewBag.ModeloVehiculo = ModeloVehiculo;
            ViewBag.InicioVigencia = InicioVigencia;
            ViewBag.FinVigencia = FinVigencia;
            ViewBag.TipoCobertura = TipoCobertura;
            ViewBag.PrimaTotal = PrimaTotal;
            if (!string.IsNullOrEmpty(NombreTipoVehiculo))
                ViewBag.NombreTipoVehiculo = NombreTipoVehiculo;
            if (!string.IsNullOrEmpty(idTipovehiculo))
            {
                var tv = db.CatUsoVehiculo.FirstOrDefault(a => a.Clave == idTipovehiculo);
                ViewBag.NombreTipoVehiculo = tv.Nombre;
            }
            //if (!string.IsNullOrEmpty(Marca))
            //    ViewBag.ImgAuto = ObtenerLogoMarca(Marca);
            ViewBag.MuestraAviso = muestraAviso;
            return PartialView();
        }

        private string ObtenerLogoMarca(string Marca)
        {
            List<string> imgs = System.IO.Directory.EnumerateFiles(Server.MapPath(@"~/img/logmarca")).ToList();
            if (Marca != null)
            {
                foreach (string img in imgs)
                {
                    string logo = img.Replace("\\", "/").Split('/').Last();
                    if (logo.ToUpper().Contains(Marca))
                    {
                        return logo;
                    }
                }
            }
            return "car-gray.png";
        }

        #endregion

        #region Envio de correo electronico

        //public JsonResult EnvioCorreo()
        //{
        //    Cotizar correo = new Cotizar();
        //    correo.EnvioDeCorreoElectronico();

        //    return Json(new { Data = true }, JsonRequestBehavior.AllowGet);
        //}

        #endregion

        #region VentanaPagoABA
        public async Task<ActionResult> PagoMit(int polID, string llamado)
        {
            Poliza poliza = db.Poliza.Find(polID);
            bool usuarioAlias = false;
            DetalleUsuario detUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
            poliza.Estatus = 20;
            db.Entry(poliza).State = EntityState.Modified;
            db.SaveChanges();
            string strPolizaID = poliza.NumeroPoliza;
            string url = Url.Action("ResultEmisionMIT", "Cotizacion", new { id = polID, param = 0 }, Request.Url.Scheme);


            Endoso endoso = poliza.Endoso.OrderBy(c => c.Id).FirstOrDefault();
            Recibo recibo = endoso.Recibo.OrderBy(c => c.Numero).FirstOrDefault();

            ComensarPagoURlRequestDTO request = new ComensarPagoURlRequestDTO();
            request.amount = (double)recibo.PrimaTotal;
            request.fh_vigencia = poliza.FinVigencia.ToString("dd/MM/yyyy");
            request.mail_cliente = detUsuario.Correo;
            request.reference = poliza.NumeroPoliza;
            request.UrlReturn = url;
            request.UserID = detUsuario.IdUsuario;
            request.id_company = poliza.Convenio.Mit_id_company;
            request.id_branch = poliza.Convenio.Mit_id_branch;
            request.user = poliza.Convenio.Mit_user;
            request.pwd = poliza.Convenio.Mit_pwd;
            request.Key = poliza.Convenio.Mit_Key;
            request.Data0 = poliza.Convenio.Mit_Data0;

            using (HttpClient client = new HttpClient())
            using (HttpRequestMessage requestMiddleWare = new HttpRequestMessage(HttpMethod.Post, ConfigurationManager.AppSettings["MIT_Middleware"]))
            {
                string json = JsonConvert.SerializeObject(request);
                using (StringContent stringContent = new StringContent(json, Encoding.UTF8, "application/json"))
                {
                    requestMiddleWare.Content = stringContent;
                    using (HttpResponseMessage response = await client.SendAsync(requestMiddleWare).ConfigureAwait(false))
                    {
                        response.EnsureSuccessStatusCode();

                        ViewBag.urlPagoContarjeta = await response.Content.ReadAsStringAsync();
                    }
                }
            }

            return View();
        }

        class ComensarPagoURlRequestDTO
        {
            public double amount { get; set; }
            public string fh_vigencia { get; set; }
            public string mail_cliente { get; set; }
            public string reference { get; set; }
            public string UrlReturn { get; set; }
            public string UserID { get; set; }
            //MIT CONFIGURATION
            public string id_company { get; set; }
            public string id_branch { get; set; }
            public string user { get; set; }
            public string pwd { get; set; }
            public string Key { get; set; }
            public string Data0 { get; set; }

        }

        public ActionResult PagoTarjetaABA(int polID, string llamado)
        {
            try
            {
                Poliza poliza = db.Poliza.Find(polID);
                SqlParameter documento = new SqlParameter("@documento", poliza.NumeroPoliza);
                LocktonModel.db.CatContactos catContactos = db.CatContactos.SqlQuery("sp_ConsultaUsuarioCore @documento", documento).FirstOrDefault();
                bool usuarioAlias = false;
                DetalleUsuario detUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
                poliza.Estatus = 20;
                db.Entry(poliza).State = EntityState.Modified;
                db.SaveChanges();

                var polizadetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == poliza.Id);
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == poliza.IdConvenio);

                var nsp = "va";

                if (polizadetalle.IdCatModalidadFormaPago == 2)
                    nsp = "d";


                string strPolizaID = poliza.NumeroPoliza;
                //string strPolizaID = "KB39300602";
                //string strIncico = poliza.PolizaDetalle.FirstOrDefault().Inciso; }

                if (llamado.Equals("emision"))
                {
                    ViewBag.MensajeExito = string.Format("Tu auto ahora se encuentra asegurado en la póliza {0}. ", strPolizaID);
                }

                string destino = aBACHUBBService.EndpointABA();

                StringBuilder sb = new StringBuilder();

                // Obtenemos la URL (completa) de retorno, que va a utilizar la pagina de cobranza de ABA
                string url = Url.Action("ResultEmision", "Cotizacion", new { id = polID, param = 0 }, Request.Url.Scheme);

                // Clave de la Poliza ( punto de venta)
                sb.AppendFormat("veI={0}+", strPolizaID.Substring(0, 2)); //poliza.convenio.codidoPromocion);
                                                                          // Numero de poliza
                sb.AppendFormat("za={0}+", strPolizaID.Substring(2).Trim());
                // Numero de inciso
                sb.AppendFormat("cis={0}+", 1);
                // Moneda de la Póliza
                sb.AppendFormat("bab={0}+", 1); //1 - Moneda Nacional
                                                // Oficina donde se emitió la póliza
                sb.AppendFormat("kgb={0}+", poliza.Convenio.ZonaCotizacion); // 1 - Monterrey / 2 - México / 3 - Guadalajara
                                                                             // URL a donde hará redirect después de terminar el cobro.(si esta variable queda vacía, el sistema cerrará la ventana del explorador al presionar el botón Finalizar para los navegadores Explorer y Chrome, para Firefox, redireccionará a la web www.abaseguros.com)
                sb.AppendFormat("kli={0}+", url);
                // Consumidor, dato constante proporcionado por Aba para cada negocio (“que subsistema consume el sistema”)
                // WSDEMO / wsventa / wspag /  wsprog / wspyp
                sb.AppendFormat("trc={0}+", poliza.Convenio.TRC);//ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                                 //sb.AppendFormat("trc={0}+", "WSVENTASPYP");//ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                                 // ID del usuario utilizado, dato constante proporcionado por Aba para cada negocio (“que usuario consume el sistema”)
                                                                 // (sera un valor diferente dependiendo del ambiente enque se este trabajando)
                sb.AppendFormat("cnzd={0}+", poliza.Convenio.CNZD); //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente
                                                                    //sb.AppendFormat("cnzd={0}+", "109227"); //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente

                // ID del negocio de cobranza, dato constante proporcionado por Aba (“que negocio se utilizara el contiene las reglas de negocio como calendarización de pagos, avisos Etc…”) (opcional para cuando la programación es especial)
                //PA. Se activa solo para Principal con el valor 225

                // 2016-07-26 AGF Cambio para considerar valores correctos en cliente KANSAS
                if (poliza.Convenio.IntentosCobro != null && !string.IsNullOrEmpty(poliza.Convenio.NEI))
                {
                    sb.AppendFormat("NeI={0}+", poliza.Convenio.NEI);
                }

                // RamoId de acuerdo al Ramo de la póliza.
                sb.AppendFormat("aId={0}+", 3); //Autos
                                                //  Requerir correo electrónico, si se requiere que la interfaz de Cargos en línea, requiera de manera obligatoria el correo electrónico del titular de la tarjeta enviar en “1”, en caso contrario “0” o no enviar.
                sb.AppendFormat("vcr={0}+", 1);
                //  Dirección de correo electrónico, para que aparezca como sugerencia en la interfaz de cargos en línea. Éste parámetro es opcional.
                sb.AppendFormat("vce={0}+", detUsuario.Correo);
                //sb.AppendFormat("vce={0}+", "vguzman@mx.lockton.com");
                //  Varieable para configura los medios de pago a mostrar, se tiene que enviar un string con las siguientes iniciales y el orden que desean que se despliegue en el combo,
                // a = Para AMEX
                // v = Para VISA / MasterCard
                // d = Para Debito y Clabe
                // Ejemplos:
                // av = Amex y Visa / Mastercard
                // va = Visa / MasterCard y Amex
                //sb.AppendFormat("NsP={0}+", "");
                //  Nombre del Tarjetahabiente, asegurado o propietario
                sb.AppendFormat("NmA={0}", detUsuario.ObtieneNombreCompleto());
                if (convenio.EnvioFormaPagoABA)
                    sb.AppendFormat("+NsP={0}", nsp);//  Varieable para configura los medios de pago a mostrar, se tiene que enviar un string con las siguientes iniciales y el orden que desean que se despliegue en el combo,
                                                     // a = Para AMEX
                                                     // v = Para VISA / MasterCard
                                                     // d = Para Debito y Clabe
                                                     // Ejemplos:
                                                     // av = Amex y Visa / Mastercard
                                                     // va = Visa / MasterCard y Amex


                ASCIIEncoding ByteConverter = new ASCIIEncoding();
                string textoEncriptado = Convert.ToBase64String(ByteConverter.GetBytes(sb.ToString()));

                //*****FIN ENCRIPTAR VARIABLES******//
                //
                //string tipoAPP = "0";
                string CadURL = "";
                //*****FORMAR URL PARA LLAMAR INTERFACE ****// 
                CadURL += destino;

                CadURL += "alt=";
                CadURL += textoEncriptado;
                //******************************************//

                ViewBag.urlPagoContarjeta = CadURL;

                log.Info("URL parametro antes de encriptar: &alt=" + sb.ToString());
                log.Info("URL de pago en base64: " + CadURL);

                RegistraOPL(poliza.NumeroPoliza, string.Format("URL PARAMETRO ANTES DE ENCRIPTAR: {0} // URL DE PAGO EN BASE64: {1} ", sb.ToString(), CadURL), "", "Pago Con Tarjeta", 1, false, 3);
                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.PagoTarjetaABA, idPoliza: polID, EmpresaId: poliza.IdAseguradora);
            }
            catch (Exception ex)
            {
                log.Info("Error Método PagoTarjetaABA: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return View();
        }

        public ActionResult ResultEmision(int id = 0)
        {
            try
            {
                log.Info("Resultado llamado PAGOTDC ABA: Emision/ResultEmision?" + string.Join("&", Request.Params.AllKeys.Select(key => key + "=" + Request.Params[key]).ToArray()));

                Poliza poliza = new Poliza();
                poliza = db.Poliza.FirstOrDefault(f => f.Id == id);

                if (poliza == null)
                {
                    ViewBag.mensaje = string.Format(CultureInfo.CurrentCulture, "La póliza {0} no está almacenada en Lockton Cars, favor de reportarlo.", id);
                    return View(poliza);
                }

                poliza.Estatus = 20;
                db.Entry(poliza).State = EntityState.Modified;
                db.SaveChanges();

                string ValueP = Request.Params["retV"];

                string Aut = Request.Params["Aut"];
                string Liq = Request.Params["Liq"];
                string NAut = Request.Params["NAut"];
                string TipOp = Request.Params["TipOp"];
                string Bco = Request.Params["Bco"];
                string UDTar = Request.Params["UDTar"];
                string TipTar = Request.Params["TipTar"];
                string RefProg = Request.Params["RefProg"];
                string mensaje = "Póliza generada correctamente";
                if (ValueP != null)
                {
                    mensaje = Decodificar(ValueP);
                    mensaje = mensaje.Split('=')[2].Split('-')[0];
                }

                switch (Aut)
                {
                    case "0":
                        mensaje = "Rechazado/Salida del Usuario.";
                        break;
                    case "1":
                        mensaje = "Cargo o programación del pago Aprobado.";
                        break;
                    case "2":
                        mensaje = string.Format("Cargo {0} Aprobado, Programación Aprobada. Autorización {1}: {2}", TipTar, Bco, NAut);
                        break;
                    case "3":
                        mensaje = string.Format("Cargo {0} Aprobado, Programación Rechazada. Autorización {1}: {2}", TipTar, Bco, NAut);
                        break;
                    case "4":
                        mensaje = "Salida de Usuario del sistema porque se rebasó el máximo de intentos permitido.";
                        break;
                    case "5":
                        mensaje = "No se encontró monto a cobrar/No existe la póliza en cobranza.";
                        break;
                    case "6":
                        mensaje = "No se pudo iniciar la aplicación de Cargos en línea.";
                        break;
                }
                var exitoso = false;
                if (Aut.Equals("1") || Aut.Equals("2") || Aut.Equals("3"))
                {
                    exitoso = true;
                    poliza.Estatus = 1;
                    db.Entry(poliza).State = EntityState.Modified;
                    db.SaveChanges();

                    PolizaDetalle polizaDetalle = new PolizaDetalle();
                    polizaDetalle = db.PolizaDetalle.FirstOrDefault(y => y.IdPoliza == id);
                    if (polizaDetalle == null)
                    {
                        ViewBag.mensaje = string.Format(CultureInfo.CurrentCulture, "El detalle de póliza {0} no está almacenada en Lockton en LocktonOne, favor de reportarlo.", polizaDetalle.Id);
                        return View(poliza);
                    }
                    polizaDetalle.RefProg = string.IsNullOrEmpty(RefProg) ? "" : RefProg;
                    db.Entry(polizaDetalle).State = EntityState.Modified;
                    db.SaveChanges();
                    //regster in the system core
                    if (polizaDetalle.MigraCORE)
                    {
                        int iddoctocore = polizaDetalle.IdPolizaCORE != null ? Convert.ToInt32(polizaDetalle.IdPolizaCORE) : 0;
                        SqlParameter iddocto = new SqlParameter("@IDDocto", iddoctocore);
                        SqlParameter refprog = new SqlParameter("@RefProg", RefProg ?? "");
                        db.Database.ExecuteSqlCommand("sp_RegistrarRefProgDocumentoCore @IDDocto, @RefProg", iddocto, refprog);
                    }
                }


                ZendeskResultadoPagoTarjetaABA(exitoso, poliza.NumeroPoliza, mensaje);
                RegistraRespuestaOPL(poliza.NumeroPoliza, mensaje, exitoso);
                ViewBag.mensaje = mensaje;
                log.Info(string.Format("Respuesta Ventana CHUBB: {0}", mensaje));

                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.RespuestaPagoTarjetaABA, idPoliza: id, respuesta: mensaje, EmpresaId: poliza.IdAseguradora);


            }
            catch (Exception ex)
            {
                log.Info("Error Método ResultEmision: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return View();
        }

        public ActionResult PagoTarjetaABACore(string strPolizaID, string idGerencia)
        {
            try
            {
                bool usuarioAlias = false;
                //Poliza poliza = db.Poliza.Where(x => x.NumeroPoliza == strPolizaID).FirstOrDefault();
                DetalleUsuario detUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
                //consulta el IDcli de la poliza
                SqlParameter sqldocumento = new SqlParameter("@documento", strPolizaID);
                SqlParameter sqltipoconsulta = new SqlParameter("@TipoConsulta", 1);
                SqlParameter sqliddocto = new SqlParameter("@IDDocto", DBNull.Value);
                SqlParameter sqlDocumento = new SqlParameter("@Documento", strPolizaID);

                LocktonModel.db.CatContactos catContactos = db.CatContactos.SqlQuery("sp_ConsultaUsuarioCore @documento", sqldocumento).FirstOrDefault();
                var datCoreDoumento = db.sp_GetDataDocumentoCore.SqlQuery("sp_GetDataDocumentoCore @TipoConsulta,@IDDocto,@Documento", sqltipoconsulta, sqliddocto, sqlDocumento).FirstOrDefault();
                Empresa empresa = db.Empresa.FirstOrDefault(a => a.IdGerenciaCORE == idGerencia);
                LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.IdEmpresa == empresa.Id && a.IdAseguradora == 3 && a.Estatus == 1);

                string destino = aBACHUBBService.EndpointABA();

                StringBuilder sb = new StringBuilder();

                // Obtenemos la URL (completa) de retorno, que va a utilizar la pagina de cobranza de ABA
                string url = Url.Action("ResultEmisionABACore", "Cotizacion", new { id = datCoreDoumento != null ? datCoreDoumento.IDDocto : 0, param = 0 }, Request.Url.Scheme);

                // Clave de la Poliza ( punto de venta)
                sb.AppendFormat("veI={0}+", strPolizaID.Substring(0, 2)); //poliza.convenio.codidoPromocion);
                                                                          // Numero de poliza
                sb.AppendFormat("za={0}+", strPolizaID.Substring(2));
                // Numero de inciso
                sb.AppendFormat("cis={0}+", 1);
                // Moneda de la Póliza
                sb.AppendFormat("bab={0}+", 1); //1 - Moneda Nacional
                                                // Oficina donde se emitió la póliza
                sb.AppendFormat("kgb={0}+", convenio.ZonaCotizacion); // 1 - Monterrey / 2 - México / 3 - Guadalajara
                                                                      // URL a donde hará redirect después de terminar el cobro.(si esta variable queda vacía, el sistema cerrará la ventana del explorador al presionar el botón Finalizar para los navegadores Explorer y Chrome, para Firefox, redireccionará a la web www.abaseguros.com)
                sb.AppendFormat("kli={0}+", url);
                // Consumidor, dato constante proporcionado por Aba para cada negocio (“que subsistema consume el sistema”)
                // WSDEMO / wsventa / wspag /  wsprog / wspyp
                sb.AppendFormat("trc={0}+", convenio.TRC);//ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                          //sb.AppendFormat("trc={0}+", "WSVENTASPYP");//ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                          // ID del usuario utilizado, dato constante proporcionado por Aba para cada negocio (“que usuario consume el sistema”)
                                                          // (sera un valor diferente dependiendo del ambiente enque se este trabajando)
                sb.AppendFormat("cnzd={0}+", convenio.CNZD); //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente
                                                             //sb.AppendFormat("cnzd={0}+", "109227"); //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente

                // ID del negocio de cobranza, dato constante proporcionado por Aba (“que negocio se utilizara el contiene las reglas de negocio como calendarización de pagos, avisos Etc…”) (opcional para cuando la programación es especial)
                //PA. Se activa solo para Principal con el valor 225

                // 2016-07-26 AGF Cambio para considerar valores correctos en cliente KANSAS
                if (convenio.IntentosCobro != null && !string.IsNullOrEmpty(convenio.NEI))
                {
                    sb.AppendFormat("NeI={0}+", convenio.NEI);
                }

                // RamoId de acuerdo al Ramo de la póliza.
                sb.AppendFormat("aId={0}+", 3); //Autos
                                                //  Requerir correo electrónico, si se requiere que la interfaz de Cargos en línea, requiera de manera obligatoria el correo electrónico del titular de la tarjeta enviar en “1”, en caso contrario “0” o no enviar.
                sb.AppendFormat("vcr={0}+", 1);
                //  Dirección de correo electrónico, para que aparezca como sugerencia en la interfaz de cargos en línea. Éste parámetro es opcional.
                sb.AppendFormat("vce={0}+", !string.IsNullOrEmpty(catContactos.Correo) ? catContactos.Correo : detUsuario.Correo);
                //sb.AppendFormat("vce={0}+", "vguzman@mx.lockton.com");
                //  Varieable para configura los medios de pago a mostrar, se tiene que enviar un string con las siguientes iniciales y el orden que desean que se despliegue en el combo,
                // a = Para AMEX
                // v = Para VISA / MasterCard
                // d = Para Debito y Clabe
                // Ejemplos:
                // av = Amex y Visa / Mastercard
                // va = Visa / MasterCard y Amex
                //sb.AppendFormat("NsP={0}+", "");
                //  Nombre del Tarjetahabiente, asegurado o propietario
                sb.AppendFormat("NmA={0}", !string.IsNullOrEmpty(catContactos.NombreCompleto) ? catContactos.NombreCompleto : detUsuario.ObtieneNombreCompleto());

                if (convenio.EnvioFormaPagoABA)
                    sb.AppendFormat("+NsP={0}", "vda");
                //sb.AppendFormat("NmA={0}", "Victor Guzman");

                ASCIIEncoding ByteConverter = new ASCIIEncoding();
                string textoEncriptado = Convert.ToBase64String(ByteConverter.GetBytes(sb.ToString()));

                //*****FIN ENCRIPTAR VARIABLES******//
                //
                //string tipoAPP = "0";
                string CadURL = "";
                //*****FORMAR URL PARA LLAMAR INTERFACE ****// 
                CadURL += destino;

                CadURL += "alt=";
                CadURL += textoEncriptado;
                //******************************************//

                ViewBag.urlPagoContarjeta = CadURL;

                log.Info("URL parametro antes de encriptar: &alt=" + sb.ToString());
                log.Info("URL de pago en base64: " + CadURL);
                //RegistraOPL(strPolizaID, sb.ToString(), "", "Pago Con Tarjeta", 1, false, convenio.IdAseguradora);
                RegistraOPL(strPolizaID, string.Format("URL PARAMETRO ANTES DE ENCRIPTAR: {0} // URL DE PAGO EN BASE64: {1} ", sb.ToString(), CadURL), "", "Pago Con Tarjeta", 1, false, convenio.IdAseguradora);
                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.PagoTarjetaABACore, numeroPoliza: strPolizaID, EmpresaId: empresa.Id);
            }
            catch (Exception ex)
            {
                log.Info("Error Método PagoTarjetaABACore: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return View();
        }

        public ActionResult ResultEmisionABACore(int id = 0, int param = 0)
        {
            try
            {
                log.Info("Resultado llamado PAGOTDC ABA: Emision/ResultEmision?" + string.Join("&", Request.Params.AllKeys.Select(key => key + "=" + Request.Params[key]).ToArray()));

                string ValueP = Request.Params["retV"];

                string Aut = Request.Params["Aut"];
                string Liq = Request.Params["Liq"];
                string NAut = Request.Params["NAut"];
                string TipOp = Request.Params["TipOp"];
                string Bco = Request.Params["Bco"];
                string UDTar = Request.Params["UDTar"];
                string TipTar = Request.Params["TipTar"];
                string RefProg = Request.Params["RefProg"];
                string mensaje = "Póliza generada correctamente";
                if (ValueP != null)
                {
                    mensaje = Decodificar(ValueP);
                    mensaje = mensaje.Split('=')[2].Split('-')[0];
                }

                switch (Aut)
                {
                    case "0":
                        mensaje = "Rechazado/Salida del Usuario.";
                        break;
                    case "1":
                        mensaje = "Cargo o programación del pago Aprobado.";
                        break;
                    case "2":
                        mensaje = string.Format("Cargo {0} Aprobado, Programación Aprobada. Autorización {1}: {2}", TipTar, Bco, NAut);
                        break;
                    case "3":
                        mensaje = string.Format("Cargo {0} Aprobado, Programación Rechazada. Autorización {1}: {2}", TipTar, Bco, NAut);
                        break;
                    case "4":
                        mensaje = "Salida de Usuario del sistema porque se rebasó el máximo de intentos permitido.";
                        break;
                    case "5":
                        mensaje = "No se encontró monto a cobrar/No existe la póliza en cobranza.";
                        break;
                    case "6":
                        mensaje = "No se pudo iniciar la aplicación de Cargos en línea.";
                        break;
                }
                var exitoso = false;
                if (Aut.Equals("1") || Aut.Equals("2") || Aut.Equals("3"))
                {
                    exitoso = true;
                    SqlParameter iddocto = new SqlParameter("@IDDocto", id);
                    SqlParameter refprog = new SqlParameter("@RefProg", RefProg ?? "");
                    db.Database.ExecuteSqlCommand("sp_RegistrarRefProgDocumentoCore @IDDocto, @RefProg", iddocto, refprog);
                }
                var numeroPoliza = db.Database.SqlQuery<string>("sp_ObtenerDocumento " + id.ToString()).SingleOrDefault();
                ZendeskResultadoPagoTarjetaABA(exitoso, numeroPoliza, mensaje);
                ViewBag.mensaje = mensaje;
                log.Info(string.Format("Respuesta Ventana CHUBB: {0}", mensaje));
                RegistraRespuestaOPL(numeroPoliza, mensaje, exitoso);
                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.RespuestaPagoTarjetaABACore, respuesta: mensaje);

            }
            catch (Exception ex)
            {

                log.Info("Error Método ResultEmisionABACore: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }

            return View();
        }

        private void ZendeskResultadoPagoTarjetaABA(bool exitoso, string numeroPoliza, string mensaje)
        {
            try
            {
                Poliza poliza = db.Poliza.FirstOrDefault(x => x.NumeroPoliza == numeroPoliza);
                var usuarioalias = false;
                var detUsuario = RegistroDatosUsuarioActivo(ref usuarioalias);
                SqlParameter docuemnto = new SqlParameter("@documento", numeroPoliza);
                var catContactos = db.CatContactos.SqlQuery("sp_ConsultaUsuarioCore @documento", docuemnto).FirstOrDefault();

                if (catContactos != null && !string.IsNullOrEmpty(catContactos.NEmpleado))
                {
                    var usuarioPoliza = db.DetalleUsuario.FirstOrDefault(a => a.IdEmpleado == catContactos.NEmpleado && a.IdCliCORE == catContactos.IDCli.ToString() && a.IdContCORE == catContactos.IDCont.ToString());
                    if (usuarioPoliza != null)
                        detUsuario = usuarioPoliza;
                }
                DetalleUsuarioEmpresa detalleusuarioEmpresa = db.DetalleUsuarioEmpresa.FirstOrDefault(a => a.IdDetalleUsuario == detUsuario.Id);
                Empresa empresa = db.Empresa.FirstOrDefault(a => a.Id == detalleusuarioEmpresa.IdEmpresa);
                var corporativo = db.Corporativo.FirstOrDefault(a => a.Id == empresa.IdCorporativo);

                Cotizar cotizar = new Cotizar();
                var datos = new VCorreoCompra();
                datos.IdEmpresa = empresa.Id;
                datos.NumeroDePoliza = numeroPoliza;
                datos.NombreCompleto = catContactos != null ? catContactos.NombreCompleto : "";
                datos.NombreAseguradora = "ABA CHUBB";
                datos.NombreNegocio = empresa.NombreComercial + " - " + empresa.ClaveEmpresa;
                datos.Emails = new List<string>();
                datos.Emails.Add(catContactos.Correo);

                if (!exitoso)
                {
                    var infoTicket = new BitacoraTicketsCobranza();
                    infoTicket.NumeroTarjeta = numeroPoliza;
                    infoTicket.TelefonoCelular = "";
                    infoTicket.TelefonoFijo = "";
                    infoTicket.NombreCompleto = catContactos.NombreCompleto;
                    infoTicket.Email = catContactos.Correo;
                    infoTicket.FechaRechazo = DateTime.Now;
                    infoTicket.Corporativo = "Corporativo_" + corporativo.Id.ToString();
                    infoTicket.IdEmpresa = empresa.Id;
                    infoTicket.Negocio = empresa.NombreComercial + " - " + empresa.ClaveEmpresa;
                    infoTicket.Recibo = "";
                    infoTicket.MedioContacto = "instalación_de_tarjeta";
                    infoTicket.MotivoRechazo = mensaje;
                    infoTicket.Intento = 1;

                    infoTicket.ApellidoPaterno = detUsuario.ApellidoPaterno;
                    infoTicket.Nombre = (detUsuario.Nombre + " " + detUsuario.NombreDos ?? "").Trim();
                    infoTicket.FechaNacimiento = detUsuario.FECHANACIMIENTO;
                    infoTicket.IdOperaCorporativo = corporativo.IdOpera;
                    infoTicket.IdOperaContratante = empresa.IdContratanteOpera ?? 0;
                    infoTicket.NoEmpleado = detUsuario.IdEmpleado;


                    if (empresa.TicketZendesk)
                    {
                        var idTicket = PloomesProxy.TicketInstalacionFallida(infoTicket, (poliza == null) ? true : false);
                        //var idTicket = new EnvioTickets().ZendeskCobroFallido(infoTicket, (poliza == null) ? true : false);
                    }

                    //cotizar.EnvioCorreoCobroFallido(datos, empresa.CuentaTOM);
                }
                else
                {

                    cotizar.EnvioCorreoPagoPoliza(datos);
                }
            }
            catch (Exception ex)
            {
                log.Info("Error Método CRMResultadoPagoTarjetaABA: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
        }
        public ActionResult SolicitudCambioTarjetaABA(string NumeroPoliza, string llamado)
        {
            try
            {
                Poliza poliza = db.Poliza.Where(x => x.NumeroPoliza == NumeroPoliza).FirstOrDefault();
                PolizaDetalle polizaDetalle = db.PolizaDetalle.Where(x => x.IdPoliza == poliza.Id).FirstOrDefault();
                //LocktonModel.db.CatContactos catContactos = db.CatContactos.SqlQuery("sp_ConsultaUsuarioCore @documento=" + poliza.NumeroPoliza).FirstOrDefault();
                bool usuarioAlias = false;
                DetalleUsuario detUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
                string strPolizaID = poliza.NumeroPoliza;
                var tcr = Utilidades.ObtienerValorParametro("ABA_VALOR_TCR");
                string destino = aBACHUBBService.EndpointABA();


                StringBuilder sb = new StringBuilder();
                string RpG = polizaDetalle != null ? polizaDetalle.RefProg : "";
                if (!string.IsNullOrEmpty(RpG))
                {
                    // GET THE URL (ALL) OF RETURN, THAT WENT USE PAGE ABA COLLECTION
                    string url = Url.Action("ResultCambioTarjetaABA", "Cotizacion", new { id = poliza.Id, param = 0 }, Request.Url.Scheme);
                    /* ********************************************************************************************************************************************************************** */
                    // para probar el cambio de tarjeta es necesario los datos que están comentados con /* */ pasarlos al valor de cada parametro y cometar los que tiene
                    /* ********************************************************************************************************************************************************************** */
                    // Clave de la Poliza ( punto de venta)
                    sb.AppendFormat("veI={0}+", strPolizaID.Substring(0, 2));/*CD*/ //poliza.convenio.codidoPromocion);
                                                                                    // Numero de poliza
                    sb.AppendFormat("za={0}+", strPolizaID.Substring(2));/*39001068*/
                    // Numero de inciso
                    sb.AppendFormat("cis={0}+", 1);
                    // Moneda de la Póliza
                    sb.AppendFormat("bab={0}+", 1); //1 - Moneda Nacional
                                                    // Oficina donde se emitió la póliza
                    sb.AppendFormat("kgb={0}+", poliza.Convenio.ZonaCotizacion); // 1 - Monterrey / 2 - México / 3 - Guadalajara
                                                                                 // URL a donde hará redirect después de terminar el cobro.(si esta variable queda vacía, el sistema cerrará la ventana del explorador al presionar el botón Finalizar para los navegadores Explorer y Chrome, para Firefox, redireccionará a la web www.abaseguros.com)
                    sb.AppendFormat("kli={0}+", url);
                    // Consumidor, dato constante proporcionado por Aba para cada negocio (“que subsistema consume el sistema”)
                    // WSDEMO / wsventa / wspag /  wsprog / wspyp
                    sb.AppendFormat("trc={0}+", tcr);/*WSVENTASPROG*/ //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                                      //sb.AppendFormat("trc={0}+", "WSVENTASPYP");//ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                                      // ID del usuario utilizado, dato constante proporcionado por Aba para cada negocio (“que usuario consume el sistema”)
                                                                      // (sera un valor diferente dependiendo del ambiente enque se este trabajando)
                    sb.AppendFormat("cnzd={0}+", poliza.Convenio.CNZD);/*89092*/ //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente
                                                                                 //sb.AppendFormat("cnzd={0}+", "109227"); //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente

                    // ID del negocio de cobranza, dato constante proporcionado por Aba (“que negocio se utilizara el contiene las reglas de negocio como calendarización de pagos, avisos Etc…”) (opcional para cuando la programación es especial)
                    //PA. Se activa solo para Principal con el valor 225

                    // 2016-07-26 AGF Cambio para considerar valores correctos en cliente KANSAS
                    /*para probar es necesario comentar el siguiente if*/
                    /* if (poliza.Convenio.IntentosCobro != null && !string.IsNullOrEmpty(poliza.Convenio.NEI))
                     {
                         sb.AppendFormat("NeI={0}+", poliza.Convenio.NEI);
                     }*/

                    // RamoId de acuerdo al Ramo de la póliza.
                    sb.AppendFormat("aId={0}+", 3); //Autos
                                                    //  Requerir correo electrónico, si se requiere que la interfaz de Cargos en línea, requiera de manera obligatoria el correo electrónico del titular de la tarjeta enviar en “1”, en caso contrario “0” o no enviar.
                    sb.AppendFormat("vcr={0}+", 1);/*0*/
                    //  Dirección de correo electrónico, para que aparezca como sugerencia en la interfaz de cargos en línea. Éste parámetro es opcional.
                    sb.AppendFormat("vce={0}+", detUsuario.Correo);
                    //sb.AppendFormat("vce={0}+", "vguzman@mx.lockton.com");
                    //  Varieable para configura los medios de pago a mostrar, se tiene que enviar un string con las siguientes iniciales y el orden que desean que se despliegue en el combo,
                    // a = Para AMEX
                    // v = Para VISA / MasterCard
                    // d = Para Debito y Clabe
                    // Ejemplos:
                    // av = Amex y Visa / Mastercard
                    // va = Visa / MasterCard y Amex
                    //sb.AppendFormat("NsP={0}+", "");
                    //  Nombre del Tarjetahabiente, asegurado o propietario
                    sb.AppendFormat("NmA={0}+", detUsuario.ObtieneNombreCompleto());
                    //sb.AppendFormat("NmA={0}", "Victor Guzman");

                    // Referencia de pago RefProg
                    sb.AppendFormat("RpG={0}", RpG); /*"965097"*/ //poliza.convenio.codidoPromocion);

                    //*****INICIO ENCRIPTAR VARIABLES******//
                    ASCIIEncoding ByteConverter = new ASCIIEncoding();
                    string textoEncriptado = Convert.ToBase64String(ByteConverter.GetBytes(sb.ToString()));

                    //*****FIN ENCRIPTAR VARIABLES******//

                    string CadURL = "";
                    //*****FORMAR URL PARA LLAMAR INTERFACE ****// 
                    CadURL += destino;

                    CadURL += "alt=";
                    CadURL += textoEncriptado;
                    //******************************************//

                    ViewBag.urlCambioDeTarjeta = CadURL;
                    ViewBag.Mensaje = null;
                    log.Info("URL parametro antes de encriptar: &alt=" + sb.ToString());
                    log.Info("URL de pago en base64: " + CadURL);
                    RegistraOPL(poliza.NumeroPoliza, sb.ToString(), "", "Edición Tarjeta", 4, false, poliza.IdAseguradora);
                }
                else
                {
                    ViewBag.Mensaje = "No existe RefProg";
                    log.Info("Error de modificación de tarjeta no se encontró RefProg de la póliza: " + NumeroPoliza);
                }

                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.SolicitudCambioTarjetaABA, numeroPoliza: NumeroPoliza, EmpresaId: poliza.Id);
            }
            catch (Exception ex)
            {
                log.Info("Error Método SolicitudCambioTarjetaABA: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return View();

        }
        public ActionResult ResultCambioTarjetaABA(int id = 0)
        {
            try
            {
                log.Info("Resultado llamado PAGOTDC ABA: Emision/ResultEmision?" + string.Join("&", Request.Params.AllKeys.Select(key => key + "=" + Request.Params[key]).ToArray()));
                string Aut = Request.Params["Aut"];
                string TipOp = Request.Params["TipOp"];
                string RefProg = Request.Params["RefProg"];
                string mensaje = "Cambio de Tarjeta Correctamente";
                var poliza = db.Poliza.FirstOrDefault(a => a.Id == id);
                switch (Aut)
                {
                    case "0":
                        mensaje = "Rechazo de cambio de tarjeta/Salida del Usuario.";
                        break;
                    case "1":
                        mensaje = "Se realizó correctamente la solicitud de cambio de tarjeta, quedando como referencia: " + RefProg;
                        break;
                }

                if (Aut.Equals("1"))
                {



                    PolizaDetalle polizaDetalle = new PolizaDetalle();
                    polizaDetalle = db.PolizaDetalle.FirstOrDefault(y => y.IdPoliza == id);
                    if (polizaDetalle == null)
                    {
                        ViewBag.mensaje = string.Format(CultureInfo.CurrentCulture, "El detalle de póliza no está almacenada en Lockton en LocktonOne, favor de reportarlo.", polizaDetalle.Id);
                        return View();
                    }
                    polizaDetalle.RefProg = string.IsNullOrEmpty(RefProg) ? "" : RefProg;
                    db.Entry(polizaDetalle).State = EntityState.Modified;
                    db.SaveChanges();
                }

                ViewBag.mensaje = mensaje;
                log.Info(string.Format("Respuesta Ventana CHUBB: {0}", mensaje));

                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.ResultCambioTarjetaABA, idPoliza: id, respuesta: mensaje, EmpresaId: poliza.Id);
                RegistraRespuestaOPL(poliza.NumeroPoliza, mensaje, Aut == "1");
            }
            catch (Exception ex)
            {
                log.Info("Error Método ResultCambioTarjetaABA: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }

            return View();
        }

        public ActionResult SolicitudCambioTarjetaABACore(string NumeroPoliza, string idGerencia, string llamado)
        {
            try
            {
                bool usuarioAlias = false;
                var tcr = Utilidades.ObtienerValorParametro("ABA_VALOR_TCR");

                DetalleUsuario detUsuario = RegistroDatosUsuarioActivo(ref usuarioAlias);
                //consulta el IDcli de la poliza
                SqlParameter sqldocumento = new SqlParameter("@documento", NumeroPoliza);
                SqlParameter sqltipoconsulta = new SqlParameter("@TipoConsulta", 1);
                SqlParameter sqliddocto = new SqlParameter("@IDDocto", DBNull.Value);
                SqlParameter sqlDocumento = new SqlParameter("@Documento", NumeroPoliza);
                LocktonModel.db.CatContactos catContactos = db.CatContactos.SqlQuery("sp_ConsultaUsuarioCore @documento", sqldocumento).FirstOrDefault();

                var datCoreDoumento = db.sp_GetDataDocumentoCore.SqlQuery("sp_GetDataDocumentoCore @TipoConsulta,@IDDocto,@Documento", sqltipoconsulta, sqliddocto, sqlDocumento).FirstOrDefault();
                Empresa empresa = db.Empresa.FirstOrDefault(a => a.IdGerenciaCORE == idGerencia);
                LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(a => a.IdEmpresa == empresa.Id && a.IdAseguradora == 3 && a.Estatus == 1);


                string destino = aBACHUBBService.EndpointABA();


                StringBuilder sb = new StringBuilder();
                string RpG = datCoreDoumento != null ? datCoreDoumento.RefProg : "";
                if (!string.IsNullOrEmpty(RpG))
                {
                    // GET THE URL (ALL) OF RETURN, THAT WENT USE PAGE ABA COLLECTION
                    string url = Url.Action("ResultCambioTarjetaABACore", "Cotizacion", new { id = datCoreDoumento != null ? datCoreDoumento.IDDocto : 0, param = 0 }, Request.Url.Scheme);
                    /* ********************************************************************************************************************************************************************** */
                    // para probar el cambio de tarjeta es necesario los datos que están comentados con /* */ pasarlos al valor de cada parametro y cometar los que tiene
                    /* ********************************************************************************************************************************************************************** */
                    // Clave de la Poliza ( punto de venta)
                    sb.AppendFormat("veI={0}+", NumeroPoliza.Substring(0, 2));/*CD*/ //poliza.convenio.codidoPromocion);
                                                                                     // Numero de poliza
                    sb.AppendFormat("za={0}+", NumeroPoliza.Substring(2));/*39001068*/
                    // Numero de inciso
                    sb.AppendFormat("cis={0}+", 1);
                    // Moneda de la Póliza
                    sb.AppendFormat("bab={0}+", 1); //1 - Moneda Nacional
                                                    // Oficina donde se emitió la póliza
                    sb.AppendFormat("kgb={0}+", convenio.ZonaCotizacion); // 1 - Monterrey / 2 - México / 3 - Guadalajara
                                                                          // URL a donde hará redirect después de terminar el cobro.(si esta variable queda vacía, el sistema cerrará la ventana del explorador al presionar el botón Finalizar para los navegadores Explorer y Chrome, para Firefox, redireccionará a la web www.abaseguros.com)
                    sb.AppendFormat("kli={0}+", url);
                    // Consumidor, dato constante proporcionado por Aba para cada negocio (“que subsistema consume el sistema”)
                    // WSDEMO / wsventa / wspag /  wsprog / wspyp
                    sb.AppendFormat("trc={0}+", tcr);/*WSVENTASPROG*/ //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                                      //sb.AppendFormat("trc={0}+", "WSVENTASPYP");//ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                                      // ID del usuario utilizado, dato constante proporcionado por Aba para cada negocio (“que usuario consume el sistema”)
                                                                      // (sera un valor diferente dependiendo del ambiente enque se este trabajando)
                    sb.AppendFormat("cnzd={0}+", convenio.CNZD);/*89092*/ //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente
                                                                          //sb.AppendFormat("cnzd={0}+", "109227"); //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente

                    // ID del negocio de cobranza, dato constante proporcionado por Aba (“que negocio se utilizara el contiene las reglas de negocio como calendarización de pagos, avisos Etc…”) (opcional para cuando la programación es especial)
                    //PA. Se activa solo para Principal con el valor 225

                    // 2016-07-26 AGF Cambio para considerar valores correctos en cliente KANSAS
                    /*para probar es necesario comentar el siguiente if*/
                    /* if (poliza.Convenio.IntentosCobro != null && !string.IsNullOrEmpty(poliza.Convenio.NEI))
                     {
                         sb.AppendFormat("NeI={0}+", convenio.NEI);
                     }*/

                    // RamoId de acuerdo al Ramo de la póliza.
                    sb.AppendFormat("aId={0}+", 3); //Autos
                                                    //  Requerir correo electrónico, si se requiere que la interfaz de Cargos en línea, requiera de manera obligatoria el correo electrónico del titular de la tarjeta enviar en “1”, en caso contrario “0” o no enviar.
                    sb.AppendFormat("vcr={0}+", 1);/*0*/
                    //  Dirección de correo electrónico, para que aparezca como sugerencia en la interfaz de cargos en línea. Éste parámetro es opcional.
                    sb.AppendFormat("vce={0}+", detUsuario.Correo);
                    //sb.AppendFormat("vce={0}+", "vguzman@mx.lockton.com");
                    //  Varieable para configura los medios de pago a mostrar, se tiene que enviar un string con las siguientes iniciales y el orden que desean que se despliegue en el combo,
                    // a = Para AMEX
                    // v = Para VISA / MasterCard
                    // d = Para Debito y Clabe
                    // Ejemplos:
                    // av = Amex y Visa / Mastercard
                    // va = Visa / MasterCard y Amex
                    //sb.AppendFormat("NsP={0}+", "");
                    //  Nombre del Tarjetahabiente, asegurado o propietario
                    sb.AppendFormat("NmA={0}+", detUsuario.ObtieneNombreCompleto());
                    //sb.AppendFormat("NmA={0}", "Victor Guzman");

                    // Referencia de pago RefProg
                    sb.AppendFormat("RpG={0}", RpG); /*"965097"*/ /*2315*///poliza.convenio.codidoPromocion);

                    //*****INICIO ENCRIPTAR VARIABLES******//
                    ASCIIEncoding ByteConverter = new ASCIIEncoding();
                    string textoEncriptado = Convert.ToBase64String(ByteConverter.GetBytes(sb.ToString()));

                    //*****FIN ENCRIPTAR VARIABLES******//

                    string CadURL = "";
                    //*****FORMAR URL PARA LLAMAR INTERFACE ****// 
                    CadURL += destino;

                    CadURL += "alt=";
                    CadURL += textoEncriptado;
                    //******************************************//

                    ViewBag.urlCambioDeTarjetaCore = CadURL;
                    ViewBag.Mensaje = "";
                    log.Info("URL parametro antes de encriptar: &alt=" + sb.ToString());
                    log.Info("URL de pago en base64: " + CadURL);

                    RegistraOPL(NumeroPoliza, sb.ToString(), "", "Edición Tarjeta", 4, false, convenio.IdAseguradora);

                }
                else
                {
                    ViewBag.Mensaje = "No existe RefProg";
                    log.Info("Error de modificación de tarjeta no se encontró RefProg de la póliza: " + NumeroPoliza);
                }

                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.SolicitudCambioTarjetaABACore, numeroPoliza: NumeroPoliza, EmpresaId: empresa.Id);

            }
            catch (Exception ex)
            {
                log.Info("Error Método SolicitudCambioTarjetaABACore: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return View();

        }
        public ActionResult ResultCambioTarjetaABACore(int id = 0)
        {
            try
            {
                log.Info("Resultado llamado Cambio Tarjeta ABA: Emision/ResultCambioTarjetaABACore?" + string.Join("&", Request.Params.AllKeys.Select(key => key + "=" + Request.Params[key]).ToArray()));
                string Aut = Request.Params["Aut"];
                string TipOp = Request.Params["TipOp"];
                string RefProg = Request.Params["RefProg"];
                string mensaje = "Cambio de Tarjeta Correctamente";

                switch (Aut)
                {
                    case "0":
                        mensaje = "Rechazo de cambio de tarjeta/Salida del Usuario.";
                        break;
                    case "1":
                        mensaje = "Se realizó correctamente la solicitud de cambio de tarjeta, quedando como referencia: " + RefProg;
                        break;
                }

                if (Aut.Equals("1"))
                {
                    SqlParameter iddocto = new SqlParameter("@IDDocto", id);
                    SqlParameter refprog = new SqlParameter("@RefProg", RefProg ?? "");
                    db.Database.ExecuteSqlCommand("sp_RegistrarRefProgDocumentoCore @IDDocto, @RefProg", iddocto, refprog);
                }

                ViewBag.mensaje = mensaje;
                log.Info(string.Format("Respuesta Ventana CHUBB: {0}", mensaje));

                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.ResultCambioTarjetaABACore, idPoliza: id, respuesta: mensaje);

                //RegistraRespuestaOPL(poliza.NumeroPoliza, mensaje, Aut == "1");
            }
            catch (Exception ex)
            {
                log.Info("Error Método ResultCambioTarjetaABACore: " + ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return View();
        }

        public class MitToken
        {
            public int Id { get; set; }
            public string UserID { get; set; }

            public string Referencia { get; set; }

            public string UrlReturn { get; set; }

            public string Token { get; set; }

            public bool Activa { get; set; }
            public string Cc_type { get; set; }
        }

        private WSConsumerSICAS oWSData;
        private wsAuthConfig cfgCredentials;
        private wsAuthUserSICAS cfgCredUser;

        public ServiceSoapClient WsClient { get => wsClient; set => wsClient = value; }

        public WSConsumerSICAS OWSData { get => oWSData; set => oWSData = value; }
        public wsAuthConfig CfgCredentials { get => cfgCredentials; }
        public wsAuthUserSICAS CfgCredUser { get => cfgCredUser; set => cfgCredUser = value; }

        private ServiceSoapClient wsClient;


        [XmlRoot(ElementName = "CENTEROFPAYMENTS")]
        public class CENTEROFPAYMENTS
        {
            public string Reference { get; set; }
            public string Response { get; set; }
            public string Foliocpagos { get; set; }
            public string Auth { get; set; }
            public string Cd_response { get; set; }
            public string Cd_error { get; set; }
            public string Nb_error { get; set; }
            public string Time { get; set; }
            public string Date { get; set; }
            public string Nb_company { get; set; }
            public string Nb_merchant { get; set; }
            public string Cc_type { get; set; }
            public string Tp_operation { get; set; }
            public string Cc_name { get; set; }
            public string Cc_number { get; set; }
            public string Amount { get; set; }
            public string Id_url { get; set; }
            public string Email { get; set; }
            public string Cc_mask { get; set; }

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ResultEmisionMIT(CENTEROFPAYMENTS request)
        {

            Poliza poliza = new Poliza();
            poliza = db.Poliza.FirstOrDefault(f => f.NumeroPoliza == request.Reference);

            if (poliza == null)
            {
                ViewBag.mensaje = string.Format(CultureInfo.CurrentCulture, "La póliza {0} no está almacenada en Lockton Cars, favor de reportarlo.", request.Cc_mask);
                return View(poliza);
            }
            DetalleUsuario usuario = db.DetalleUsuario.FirstOrDefault(f => f.Id == poliza.IdUsuario);
            poliza.Estatus = 1;
            db.Entry(poliza).State = EntityState.Modified;
            db.SaveChanges();

            this.wsClient = new ServiceSoapClient();
            this.oWSData = new WSConsumerSICAS();
            this.cfgCredUser = new wsAuthUserSICAS();
            this.cfgCredentials = new wsAuthConfig();
            ConfiguraCredenciales();

            string respuestaWS = string.Empty;
            try
            {
                wsDataConfig oDataConfig = new wsDataConfig();

                string[] _ctypes = request.Cc_type.Split('/');
                string banco = "";
                if (_ctypes.Length >= 1)
                    banco = _ctypes[1];
                string contCode = usuario.IdContCORE == null ? "10" : usuario.IdContCORE;
                string sCadenaDatos = "CatTarjetas.IDCont|" + contCode + ",CatTarjetas.TCard|1,CatTarjetas.Emisor|" + banco + ",CatTarjetas.Carrier|0,CatTarjetas.Status|0,CatTarjetas.DiaCorte|0,CatTarjetas.Numero|" + request.Cc_mask + ",CatTarjetas.Cuenta|21180063489100535,CatTarjetas.Token|" + request.Cc_mask;
                oDataConfig.PropertyTypeProcess = EnumTypeProcess.WS_SaveData;
                oDataConfig.PropertyWhatMakeExist = EnumSiExisteQueHacer.WS_UsarloNoUpdate;
                oDataConfig.PropertyTypeData = EnumTypeData.WS_Tarjetas;

                string sResponse = WsClient.Procesar_String(sCadenaDatos, oDataConfig, CfgCredentials);
                string tarjeta2 = sResponse.Substring(sResponse.IndexOf("<IDTarjeta>"), sResponse.IndexOf("</IDTarjeta>") - sResponse.IndexOf("<IDTarjeta>"));
                string SCadenaDos = "IDDocto|" + poliza.Id.ToString() + ",TipoPago|0,IDTarjeta|" + tarjeta2 + ",TFieldSol|0";
                oDataConfig.PropertyTypeProcess = EnumTypeProcess.WS_SaveData;
                oDataConfig.PropertyWhatMakeExist = EnumSiExisteQueHacer.WS_UpdateData;
                oDataConfig.PropertyTypeData = EnumTypeData.WS_FormasDePagoDocto;
                string sResponse2 = WsClient.Procesar_String(SCadenaDos, oDataConfig, CfgCredentials);
            }
            catch (Exception ex)
            {
                log.Info("Insertar info en el core: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return Json(true);
        }

        private bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;

        private void ConfiguraCredenciales()
        {
            if (esProduccion)
            {
                cfgCredentials.UserName = "Lock#Mx%2017";
                cfgCredentials.Password = "Mx%2017#Lock";
            }
            else
            {
                cfgCredentials.UserName = "Lock#Mx%2019";
                cfgCredentials.Password = "Lmx%2019#CK";
            }
        }

        private string Decodificar(string strEntrada)
        {
            if (strEntrada != "")
            {
                byte[] decodedBytes = Convert.FromBase64String(strEntrada);
                return Encoding.UTF8.GetString(decodedBytes);
            }
            else
            {
                return string.Empty;
            }
        }


        #endregion

        #region VentanaPagoGNP
        //public ActionResult PagarPolizaGNP(int idPoliza)
        //{
        //    var polizaDetalle = db.PolizaDetalle.Where(x => x.IdPoliza == idPoliza).FirstOrDefault();
        //    var cotizacionDetalle = db.CotizacionDetalle.Where(x => x.Id == polizaDetalle.IdCotizacionDetalle).FirstOrDefault();
        //    return RedirectToAction("PagoTarjetaGNP", new { polID = idPoliza, noCotizacion =cotizacionDetalle.ClaveCotizacion, idCotizacionDetalle=polizaDetalle.IdCotizacionDetalle });

        //}
        public ActionResult PagoTarjetaGNP(int polID, string noCotizacion, int idCotizacionDetalle)
        {
            IGNPService gnpService;
            //14531787  14531660
            string llave = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro("LlaveGNPPagoTDC_Anterior");

            decimal primerPago = 0.0M;
            PolizaDetalle cotizacionDetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdCotizacionDetalle == idCotizacionDetalle);

            var empresasNuevosServicios = Utilidades.ObtienerValorParametro("GNPInfoService");
            bool utilizaNuevosServicios = empresasNuevosServicios.Split('|').Contains(cotizacionDetalle.Poliza.Convenio.IdEmpresa.ToString()) || empresasNuevosServicios.Equals("TODAS");
            if (utilizaNuevosServicios)
            {
                if (!cotizacionDetalle.Poliza.Convenio.GNPInfoEspecial)
                {


                    gnpService = new GNPPreferenteService();
                    primerPago = gnpService.ObtenerPrimerPago(cotizacionDetalle.XMLRecepcion);

                }
                else
                {
                    var _cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == idCotizacionDetalle);
                    gnpService = new GNPInfoService();
                    primerPago = gnpService.ObtenerPrimerPago(_cotizacionDetalle.XMLRecepcion);
                }
            }
            else
            {
                gnpService = new GNPService();
                primerPago = gnpService.ObtenerPrimerPago(cotizacionDetalle.XMLRecepcion);
            }
            //decimal primerPago = gnpService.ObtenerPrimerPago(cotizacionDetalle.XMLRecepcion);
            ViewBag.MensajeExito = string.Format("Tu auto ahora se encuentra asegurado. ");

            InformacionEmision infoEmision = (InformacionEmision)TempData["__INFORMACION_EMISION_GNP__"];
            TempData["__INFORMACION_EMISION_GNP__"] = infoEmision;
            string destino = "https://gnpventamasiva.com.mx/portal/pagotv.aspx?";

            StringBuilder sb = new StringBuilder();


            // Obtenemos la URL (completa) de retorno, que va a utilizar la pagina de cobranza de GNP
            string url = Url.Action("ResultEmisionGNP", "Cotizacion", new { id = polID, param = 0 }, Request.Url.Scheme);

            sb.AppendFormat("TipOP={0}&", "P");

            sb.AppendFormat("IdT={0}&", noCotizacion);

            sb.AppendFormat("Mac={0}&", primerPago);

            sb.AppendFormat("idLlave={0}&", llave);

            sb.AppendFormat("URLResp={0}", url);


            ASCIIEncoding ByteConverter = new ASCIIEncoding();
            string textoEncriptado = Convert.ToBase64String(ByteConverter.GetBytes(sb.ToString()));

            //*****FIN ENCRIPTAR VARIABLES******//
            //
            //string tipoAPP = "0";
            string CadURL = "";
            //*****FORMAR URL PARA LLAMAR INTERFACE ****// 
            CadURL += destino;

            CadURL += sb.ToString();
            //CadURL += textoEncriptado;
            //******************************************//

            ViewBag.urlPagoContarjeta = CadURL;

            log.Info("URL parametro antes de encriptar: &alt=" + sb.ToString());
            log.Info("URL de pago en base64: " + CadURL);

            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.PagoTarjetaGNP, idPoliza: polID, EmpresaId: cotizacionDetalle.Poliza.Convenio.IdEmpresa);
            RegistraOPL(polID.ToString(), sb.ToString(), "", "Pago Con Tarjeta", 1, false, 2);
            return View();
        }

        public ActionResult PagoTarjetaGNPNuevosServicios(int polID, string noCotizacion, int idCotizacionDetalle)
        {
            IGNPService gnpService;
            //14531787  14531660
            string llave = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro("LlaveGNPPagoTDC");
            string tipOP = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro("GNPWSPref_TipoOP");
            string codPromo = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro("GNPWSPref_CodPromo");

            decimal primerPago = 0.0M;
            PolizaDetalle cotizacionDetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdCotizacionDetalle == idCotizacionDetalle);

            var empresasNuevosServicios = Utilidades.ObtienerValorParametro("GNPInfoService");
            bool utilizaInfoService = empresasNuevosServicios.Split('|').Contains(cotizacionDetalle.Poliza.Convenio.IdEmpresa.ToString()) || empresasNuevosServicios.Equals("TODAS");
            if (utilizaInfoService)
            {
                if (cotizacionDetalle.Poliza.Convenio.GNPInfoEspecial)
                {
                    var _cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == idCotizacionDetalle);
                    gnpService = new GNPInfoService();
                    primerPago = gnpService.ObtenerPrimerPago(_cotizacionDetalle.XMLRecepcion);
                }
                else
                {
                    gnpService = new GNPPreferenteService();
                    primerPago = gnpService.ObtenerPrimerPago(cotizacionDetalle.XMLRecepcion);
                }
            }
            else
            {
                gnpService = new GNPService();
                primerPago = gnpService.ObtenerPrimerPago(cotizacionDetalle.XMLRecepcion);
            }
            //decimal primerPago = gnpService.ObtenerPrimerPago(cotizacionDetalle.XMLRecepcion);
            ViewBag.MensajeExito = string.Format("Tu auto ahora se encuentra asegurado. ");

            InformacionEmision infoEmision = (InformacionEmision)TempData["__INFORMACION_EMISION_GNP__"];
            TempData["__INFORMACION_EMISION_GNP__"] = infoEmision;
            string destino = "https://gnpventamasiva.com.mx/portal/pagotv.aspx?";

            StringBuilder sb = new StringBuilder();


            // Obtenemos la URL (completa) de retorno, que va a utilizar la pagina de cobranza de GNP
            string url = Url.Action("ResultEmisionGNPNuevosServicios", "Cotizacion", new { id = polID, param = 0 }, Request.Url.Scheme);

            sb.AppendFormat("TipOP={0}&", tipOP);

            sb.AppendFormat("IdT={0}&", noCotizacion);

            sb.AppendFormat("Mac={0}&", primerPago);

            sb.AppendFormat("codPromo={0}&", codPromo);

            sb.AppendFormat("idLlave={0}&", llave);

            sb.AppendFormat("URLResp={0}", url);


            ASCIIEncoding ByteConverter = new ASCIIEncoding();
            string textoEncriptado = Convert.ToBase64String(ByteConverter.GetBytes(sb.ToString()));

            //*****FIN ENCRIPTAR VARIABLES******//
            //
            //string tipoAPP = "0";
            string CadURL = "";
            //*****FORMAR URL PARA LLAMAR INTERFACE ****// 
            CadURL += destino;

            CadURL += sb.ToString();
            //CadURL += textoEncriptado;
            //******************************************//

            ViewBag.urlPagoContarjeta = CadURL;

            log.Info("URL parametro antes de encriptar: &alt=" + sb.ToString());
            log.Info("URL de pago en base64: " + CadURL);

            GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.PagoTarjetaGNP, idPoliza: polID, EmpresaId: cotizacionDetalle.Poliza.Convenio.IdEmpresa);
            RegistraOPL(polID.ToString(), sb.ToString(), "", "Pago Con Tarjeta", 1, false, 2);
            return View();
        }

        public ActionResult ResultEmisionGNP(int id = 0)
        {
            log.Info("Resultado llamado PAGO TDC GNP: Emision/ResultEmision?" + string.Join("&", Request.Params.AllKeys.Select(key => key + "=" + Request.Params[key]).ToArray()));


            string idt = Request.Params["Idt"];

            string nCon = Request.Params["nCon"];
            string Seg = Request.Params["Seg"];
            string Pol = Request.Params["Pol"];
            string Res = Request.Params["Res"];

            string mensaje = "Error al generar la Poliza";
            if (Res == "1")
            {
                try
                {
                    mensaje = string.Format("Tu auto ahora está protegido en la póliza: {0}, esta fue emitida y programada con éxito.", Pol);

                    //log.Info(string.Format("Se busca poliza con el id: {0}", id));
                    Poliza poliza = new Poliza();
                    poliza = db.Poliza.FirstOrDefault(f => f.Id == id);

                    if (poliza == null)
                    {
                        //log.Info(string.Format("No se encotró la Poliza: {0}", id));
                        ViewBag.mensaje = string.Format(CultureInfo.CurrentCulture, "La póliza {0} no está almacenada en Lockton Cars, favor de reportarlo.", id);
                        return View(poliza);
                    }

                    GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.RespuestaPagoTarjetaGNP, idPoliza: id, respuesta: Res, EmpresaId: poliza.Convenio.IdEmpresa);

                    //log.Info(string.Format("Actualizar el numero de Poliza: {0}", Pol));
                    poliza.Estatus = 1;
                    poliza.NumeroPoliza = Pol;
                    db.Entry(poliza).State = EntityState.Modified;
                    db.SaveChanges();

                    ReimpresionPolizasController urlReimpresionGNP = new ReimpresionPolizasController();
                    InformacionEmision infoEmision = (InformacionEmision)TempData["__INFORMACION_EMISION_GNP__"];
                    //if (infoEmision == null)
                    //{
                    //	log.Info(string.Format("Info Emisión no recuperado "));
                    //}

                    //log.Info(string.Format("Inicia el proceso de reimpresión de Poliza GNP: {0}", Pol));
                    List<string> pdf = new List<string>();
                    //var idpoliza = db.Poliza.Where(x => x.NumeroPoliza == NumeroPoliza).FirstOrDefault();

                    if (infoEmision.Convenio.GNPInfoEspecial)
                    {
                        new GNPInfoService().ReimprimePoliza(Pol, "", poliza.ClaveAgente);
                    }
                    else
                    {
                        new GNPPreferenteService().ReimprimePoliza(Pol, "", poliza.ClaveAgente);
                    }


                    //log.Info(string.Format("Termina el proceso de reimpresión de Poliza GNP: {0}", Pol));
                    poliza.UrlPDFPoliza = pdf.FirstOrDefault();
                    infoEmision.Poliza = poliza;
                    //log.Info(string.Format("Inicia el proceso DerivarPolizaCore: {0}", Pol));
                    infoEmision.UrlReimpresionEncriptada = urlReimpresionGNP.GeneraUrlEncriptada(infoEmision.Poliza.NumeroPoliza != null ? infoEmision.Poliza.NumeroPoliza.ToString() : "");
                    DerivarPolizaCore(infoEmision);

                    //log.Info(string.Format("Inicia el proceso DerivarPolizaOpera: {0}", Pol));
                    DerivarPolizaOpera(infoEmision.Poliza);

                    //log.Info(string.Format("Inicia el proceso EnviarCorreoAlContratante: {0}", Pol));
                    EnviarCorreoAlContratante(infoEmision);

                    RegistraRespuestaOPL(id.ToString(), Pol, Res, true);
                }
                catch (Exception ex)
                {
                    log.Info(string.Format("Error GNP ResultEmisionGNP Número Poliza: {0} Error:", Pol, ex.Message));

                }
            }
            else
            {
                EliminarPoliza(id);
                RegistraRespuestaOPL(id.ToString(), Res, false);
            }



            log.Info(string.Format("Respuesta Venta GNP: {0}", Res));
            TempData["MsjExito"] = mensaje.ToString();
            return RedirectToAction("Index", "Polizas"/*, new { MsjExito = mensaje, EsError = false }*/);
        }

        public ActionResult ResultEmisionGNPNuevosServicios(int id = 0)
        {
            log.Info("Resultado llamado PAGO TDC GNP: Emision/ResultEmision?" + string.Join("&", Request.Params.AllKeys.Select(key => key + "=" + Request.Params[key]).ToArray()));


            //string idt = Request.Params["Idt"];

            string nCon = Request.Params["nCon"];
            string Seg = Request.Params["Seg"];
            string Pol = Request.Params["Pol"];
            string Res = Request.Params["UrlResp"];

            string mensaje = "Error al generar la Poliza";
            if (Res == "1")
            {
                try
                {
                    mensaje = string.Format("Tu auto ahora está protegido en la póliza: {0}, esta fue emitida y programada con éxito.", Pol);

                    //log.Info(string.Format("Se busca poliza con el id: {0}", id));
                    Poliza poliza = db.Poliza.FirstOrDefault(f => f.Id == id);

                    if (poliza == null)
                    {
                        //log.Info(string.Format("No se encotró la Poliza: {0}", id));
                        ViewBag.mensaje = string.Format(CultureInfo.CurrentCulture, "La póliza {0} no está almacenada en Lockton One, favor de reportarlo.", id);
                        return View(poliza);
                    }

                    GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.RespuestaPagoTarjetaGNP, idPoliza: id, respuesta: Res, EmpresaId: poliza.Convenio.IdEmpresa);

                    //log.Info(string.Format("Actualizar el numero de Poliza: {0}", Pol));
                    poliza.Estatus = 1;
                    poliza.NumeroPoliza = Pol;
                    db.Entry(poliza).State = EntityState.Modified;
                    db.SaveChanges();

                    ReimpresionPolizasController urlReimpresionGNP = new ReimpresionPolizasController();
                    InformacionEmision infoEmision = (InformacionEmision)TempData["__INFORMACION_EMISION_GNP__"];
                    //if (infoEmision == null)
                    //{
                    //	log.Info(string.Format("Info Emisión no recuperado "));
                    //}

                    //log.Info(string.Format("Inicia el proceso de reimpresión de Poliza GNP: {0}", Pol));
                    List<string> pdf = new List<string>();
                    //var idpoliza = db.Poliza.Where(x => x.NumeroPoliza == NumeroPoliza).FirstOrDefault();
                    bool esPool = infoEmision.Convenio.IdCatTipoConvenio.Equals(2);
                    bool usarInfoService = Utilidades.ObtienerValorParametro("GNPInfoService").Split('|').Contains(infoEmision.Convenio.IdEmpresa.ToString()) || Utilidades.ObtienerValorParametro("GNPInfoService").Contains("TODAS");

                    if (infoEmision.Convenio.GNPInfoEspecial)
                    {
                        new GNPInfoService().ReimprimePoliza(Pol, "", poliza.ClaveAgente);
                    }
                    else
                    {
                        new GNPPreferenteService().ReimprimePoliza(Pol, "", poliza.ClaveAgente);
                    }


                    //log.Info(string.Format("Termina el proceso de reimpresión de Poliza GNP: {0}", Pol));
                    poliza.UrlPDFPoliza = pdf.FirstOrDefault();
                    infoEmision.Poliza = poliza;
                    //log.Info(string.Format("Inicia el proceso DerivarPolizaCore: {0}", Pol));
                    infoEmision.UrlReimpresionEncriptada = urlReimpresionGNP.GeneraUrlEncriptada(infoEmision.Poliza.NumeroPoliza != null ? infoEmision.Poliza.NumeroPoliza.ToString() : "");
                    DerivarPolizaCore(infoEmision);

                    //log.Info(string.Format("Inicia el proceso DerivarPolizaOpera: {0}", Pol));
                    DerivarPolizaOpera(infoEmision.Poliza);

                    //log.Info(string.Format("Inicia el proceso EnviarCorreoAlContratante: {0}", Pol));
                    EnviarCorreoAlContratante(infoEmision);

                    RegistraRespuestaOPL(id.ToString(), Pol, Res, true);
                }
                catch (Exception ex)
                {
                    log.Info(string.Format("Error GNP ResultEmisionGNP Número Poliza: {0} Error:", Pol, ex.Message));

                }
            }
            else
            {
                EliminarPoliza(id);
                RegistraRespuestaOPL(id.ToString(), Res, false);
            }



            log.Info(string.Format("Respuesta Venta GNP: {0}", Res));
            TempData["MsjExito"] = mensaje.ToString();
            return RedirectToAction("Index", "Polizas"/*, new { MsjExito = mensaje, EsError = false }*/);
        }

        private void EliminarPoliza(int id)
        {
            try
            {
                db.Database.ExecuteSqlCommand(string.Format("sp_POLIZA_Delete @IdPoliza = {0}", id));
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Respuesta Venta GNP Error al eliminar Poliza : {0}", ex.Message));
            }
        }
        #endregion

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult ANAMSI(string vin, int idCotizacionDetalle)
        {
            var servicio = new ANAServices();

            var meses = servicio.ObtenerMeses(vin, idCotizacionDetalle);

            return Json(new { Exitoso = true, Meses = meses });
        }
        public ActionResult ResultEmisionOT(int id, string aseg, int idempresa)
        {
            Poliza poliza = db.Poliza.FirstOrDefault(a => a.Id == id);
            ViewBag.mensaje = string.Format("La Solicitud {0} ha sido enviada exitosamente", poliza.NumeroPoliza);
            ViewBag.Aseguradora = aseg;
            var enEnrollment = EstaEnPeriodoDeEnrollment(idempresa, DateTime.Now);

            ViewBag.EnEnrollment = enEnrollment;
            return View();
        }

        #region Deriva Polizas Core

        //public XmlDocument OTaPoliza(DATAINFOTableInfo InfoPoliza)
        //{
        //    DatDocumentos cambios = new DatDocumentos();
        //    //cambios.IDDocto = InfoPoliza.IDDocto;//id secuencial bogo
        //    cambios.TipoDocto = 1; //constante para actualizar ot  a poliza
        //    //cambios.Documento = InfoPoliza.Solicitud;//numero de poliza
        //    //llenar datos de los calculados
        //    cambios.PrimaNeta = 0;
        //    cambios.Recargos = 0;
        //    cambios.PorRecargos = 0;
        //    cambios.Derechos = 0;
        //    cambios.STotal = 0;
        //    cambios.Impuesto1 = 0;
        //    cambios.PorImp1 = 0;
        //    cambios.PrimaTotal = 0;
        //    cambios.PTotalAdic = 0;
        //    cambios.Comision0 = 0;
        //    cambios.PorCom0 = 0;
        //    cambios.Comision2 = 0;

        //    InfoData actualizaPoliza = new InfoData();
        //    return SerializeToXmlDocument(actualizaPoliza);
        //}


        #endregion

        public JsonResult GetPersonaMoralAutocomplete(string text, int idEmpresa)
        {
            List<PersonaMoralViewModel> personaMoralList = new List<PersonaMoralViewModel>();

            try
            {
                SqlParameter sqltext = new SqlParameter("@text", text);
                SqlParameter sqlidempresa = new SqlParameter("@IdEmpresa", idEmpresa);
                List<PersonaMoral> dataList = db.PersonaMoral.SqlQuery("sp_PersonaMoral_SELECT_Autocomplete  @text, @IdEmpresa", sqltext, sqlidempresa).ToList();
                foreach (PersonaMoral data in dataList)
                {
                    PersonaMoralViewModel personaMoral = new PersonaMoralViewModel();
                    PersonaMoralRepresentanteViewModel representante = new PersonaMoralRepresentanteViewModel();

                    if (data != null)
                    {
                        personaMoral.Actividad = data.Actividad;
                        personaMoral.ClaveEmpresa = data.ClaveEmpresa;
                        personaMoral.FechaConstitucion = data.FechaConstitucion;
                        personaMoral.FolioMercantil = data.FolioMercantil;
                        personaMoral.Id = data.Id;
                        personaMoral.IdCatGiroBase = data.IdCatGiroBase;
                        personaMoral.IdCatTipoPersona = data.IdCatTipoPersona;
                        personaMoral.IdContCORE = data.IdContCORE;
                        personaMoral.IdDireccion = data.IdDireccion;
                        personaMoral.IdEmpresa = data.IdEmpresa;
                        personaMoral.IdRepresentanteLegal = data.IdRepresentanteLegal;
                        personaMoral.NombreComercial = data.NombreComercial;
                        personaMoral.RazonSocial = data.RazonSocial;
                        personaMoral.RFC = data.RFC;

                        Direccion dataDirreccion = db.Direccion.FirstOrDefault(a => a.Id == data.IdDireccion);
                        if (dataDirreccion != null)
                        {
                            personaMoral.DireccionCompleta = dataDirreccion.DireccionCompleta;
                            personaMoral.Calle = dataDirreccion.Calle;
                            personaMoral.NumeroExt = dataDirreccion.NumeroExt;
                            personaMoral.NumeroInt = dataDirreccion.NumeroInt;
                            personaMoral.Colonia = dataDirreccion.Colonia;
                            personaMoral.Estado = dataDirreccion.Estado;
                            personaMoral.Municipio = dataDirreccion.Municipio;
                            personaMoral.CodigoPostal = dataDirreccion.CatCodigoPostal.Codigo;
                            personaMoral.IdEstado = dataDirreccion.IdEstado;
                            personaMoral.IdMunicipio = dataDirreccion.IdMunicipio;
                            personaMoral.IdColonia = dataDirreccion.CatCodigoPostal.Id;
                            personaMoral.IdCatEstadosRepublica = dataDirreccion.IdCatEstadosRepublica;
                            personaMoral.IdCodigoPostal = dataDirreccion.IdCodigoPostal;

                        }

                    }

                    PersonaMoralRepresentanteLegal datarepresentante = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == personaMoral.IdRepresentanteLegal);
                    if (datarepresentante != null)
                    {
                        representante.ApellidoMaterno = datarepresentante.ApellidoMaterno;
                        representante.ApellidoPaterno = datarepresentante.ApellidoPaterno;
                        representante.Correo = datarepresentante.Correo;
                        representante.EsPersonaPoliticamenteExpuesta = datarepresentante.EsPersonaPoliticamenteExpuesta;
                        representante.Estatus = datarepresentante.Estatus;
                        representante.FechaNacimiento = datarepresentante.FechaNacimiento;
                        representante.Id = datarepresentante.Id;
                        representante.IdCatEstadosRepublica_Nacimiento = datarepresentante.IdCatEstadosRepublica_Nacimiento;
                        representante.IdCatPais_Nacimiento = datarepresentante.IdCatPais_Nacimiento;
                        representante.IdCatTipoIdentificacion = datarepresentante.IdCatTipoIdentificacion;
                        representante.IdEmpresa = datarepresentante.IdEmpresa;
                        representante.Nombre = datarepresentante.Nombre;
                        representante.NumeroIdentificacion = datarepresentante.NumeroIdentificacion;
                        representante.Telefono = datarepresentante.Telefono;

                        personaMoral.RepresentanteLegal = representante;

                    }
                    personaMoralList.Add(personaMoral);
                }

            }
            catch (Exception)
            {
                personaMoralList = new List<PersonaMoralViewModel>();
            }
            return Json(personaMoralList, JsonRequestBehavior.AllowGet);
        }

        public void RegistraOPL(string numeroPoliza, string xml, string respuesta, string tipo, int idTipo, bool exitoso, int idAseguradora)
        {
            try
            {
                using (var _db = new ApplicationDbContext())
                {
                    var oplRegistro = new PolizaRegistroCobranza();
                    oplRegistro.Exitoso = exitoso;
                    oplRegistro.Fecha = DateTime.Now;
                    oplRegistro.FechaResponse = DateTime.Now;
                    oplRegistro.IdTipoOPL = idTipo;
                    oplRegistro.NumeroPoliza = numeroPoliza;
                    oplRegistro.Response = respuesta;
                    oplRegistro.TipoOPL = tipo;
                    oplRegistro.Request = xml;
                    oplRegistro.IdAseguradora = idAseguradora;

                    _db.PolizaRegistroCobranza.Add(oplRegistro);
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado RegistraOPL Qualitas: " + ex.Message, ex);
            }
        }

        public void RegistraRespuestaOPL(string numeroPoliza, string respuesta, bool exitoso)
        {
            try
            {
                using (var _db = new ApplicationDbContext())
                {
                    var oplRegistro = _db.PolizaRegistroCobranza.Where(a => a.NumeroPoliza == numeroPoliza).OrderByDescending(a => a.Fecha).FirstOrDefault();
                    oplRegistro.Exitoso = exitoso;
                    oplRegistro.FechaResponse = DateTime.Now;
                    oplRegistro.Response = respuesta;
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado RegistraOPL Qualitas: " + ex.Message, ex);
            }
        }

        public void RegistraRespuestaOPL(string id, string numeroPoliza, string respuesta, bool exitoso)
        {
            try
            {
                using (var _db = new ApplicationDbContext())
                {
                    var oplRegistro = _db.PolizaRegistroCobranza.Where(a => a.NumeroPoliza == id).OrderByDescending(a => a.Fecha).FirstOrDefault();
                    oplRegistro.NumeroPoliza = numeroPoliza;
                    oplRegistro.Exitoso = exitoso;
                    oplRegistro.Fecha = DateTime.Now;
                    oplRegistro.Response = respuesta;
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado RegistraOPL Qualitas: " + ex.Message, ex);
            }
        }

        private string AgregarPersonaMoral(ref InformacionEmision infoEmision)
        {
            string error = "";
            try
            {
                PersonaMoral datos = infoEmision.PersonaMoral;
                PersonaMoralRepresentanteLegal representante = infoEmision.PersonaMoralRepresentanteLegal;
                int idEmpresa = infoEmision.Empresa.Id;
                PersonaMoral personaMoral = new PersonaMoral();
                Direccion direccion = new Direccion();
                PersonaMoralRepresentanteLegal representanteLegal = new PersonaMoralRepresentanteLegal();

                if (string.IsNullOrEmpty(datos.NombreComercial))
                    error += "Datos de Persona Moral - Nombre Comercial es requerido. ";

                if (string.IsNullOrEmpty(datos.RFC))
                    error += "Datos de Persona Moral - RFC es requerido. ";

                if (string.IsNullOrEmpty(datos.RazonSocial))
                    error += "Datos de Persona Moral - Razón es requerido. ";

                if (datos.Direccion.IdColonia == null || datos.Direccion.IdColonia <= 0)
                    error += "Datos de Persona Moral - Dirección es requerida. ";

                if (string.IsNullOrEmpty(representante.Nombre))
                    error += "Datos de Representante Lega - Nombre es requerido. ";

                if (string.IsNullOrEmpty(representante.ApellidoPaterno))
                    error += "Datos de Representante Lega - Apellido Paterno es requerido. ";

                if (string.IsNullOrEmpty(representante.Telefono))
                    error += "Datos de Representante Lega - Teléfono es requerido. ";

                if (string.IsNullOrEmpty(error))
                {
                    if (representante.Id > 0)
                    {
                        PersonaMoralRepresentanteLegal indbRepresentante = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == representante.Id);
                        if (indbRepresentante.Nombre == representante.Nombre)
                            representanteLegal = indbRepresentante;
                    }

                    if (datos.Id > 0)
                    {
                        PersonaMoral indbpersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == datos.Id);
                        if (indbpersonaMoral.NombreComercial == datos.NombreComercial)
                        {
                            personaMoral = indbpersonaMoral;
                        }
                        if (datos.IdDireccion > 0)
                            direccion = db.Direccion.FirstOrDefault(a => a.Id == datos.IdDireccion);
                    }

                    CodigoPostal cp = db.CatCodigoPostal.Where(x => x.Id == datos.Direccion.IdColonia).FirstOrDefault();
                    CatEstadosRepublica estado = db.CatEstadosRepublica.FirstOrDefault(x => x.Id == datos.Direccion.IdEstado);

                    representanteLegal.ApellidoMaterno = representante.ApellidoMaterno ?? "";
                    representanteLegal.ApellidoPaterno = representante.ApellidoPaterno;
                    representanteLegal.Correo = representante.Correo ?? "";
                    representanteLegal.EsPersonaPoliticamenteExpuesta = representante.EsPersonaPoliticamenteExpuesta;
                    representanteLegal.Estatus = true;
                    representanteLegal.FechaNacimiento = representante.FechaNacimiento;
                    representanteLegal.IdCatEstadosRepublica_Nacimiento = representante.IdCatEstadosRepublica_Nacimiento;
                    representanteLegal.IdCatPais_Nacimiento = 1;
                    representanteLegal.IdCatTipoIdentificacion = representante.IdCatTipoIdentificacion;
                    representanteLegal.IdEmpresa = idEmpresa;
                    representanteLegal.Nombre = representante.Nombre;
                    representanteLegal.NumeroIdentificacion = representante.NumeroIdentificacion ?? "";
                    representanteLegal.Telefono = representante.Telefono;

                    if (representanteLegal.Id <= 0)
                        db.PersonaMoralRepresentanteLegal.Add(representanteLegal);

                    db.SaveChanges();

                    if (string.IsNullOrEmpty(datos.Direccion.NumeroInt))
                        direccion.NumeroInt = "";
                    direccion.IdCodigoPostal = cp.Id;
                    direccion.Estado = estado.Estado;
                    direccion.Ciudad = cp.Ciudad;
                    direccion.Colonia = cp.Asentamiento;
                    direccion.IdColonia = datos.Direccion.IdColonia;
                    direccion.Municipio = cp.Municipio;
                    direccion.IdEstado = cp.IdEstado;
                    direccion.CatEstadosRepublica = estado;
                    direccion.CodigoPostal = cp.Codigo;
                    direccion.Calle = datos.Direccion.Calle;
                    direccion.NumeroExt = datos.Direccion.NumeroExt ?? "";
                    direccion.NumeroInt = datos.Direccion.NumeroInt ?? "";
                    direccion.DireccionCompleta = datos.Direccion.Calle + " "
                        + datos.Direccion.NumeroExt
                        + (datos.Direccion.NumeroInt == "" ? "" : " int " + datos.Direccion.NumeroInt)
                        + " " + datos.Direccion.Estado
                        + " " + datos.Direccion.Municipio
                        + " " + datos.Direccion.Colonia
                        + " CP " + datos.Direccion.CodigoPostal;

                    if (direccion.Id == 0)
                        db.Direccion.Add(direccion);

                    db.SaveChanges();

                    personaMoral.Actividad = datos.Actividad ?? "";
                    personaMoral.ClaveEmpresa = "";
                    personaMoral.FechaConstitucion = datos.FechaConstitucion;
                    personaMoral.FolioMercantil = datos.FolioMercantil ?? "";
                    personaMoral.IdCatGiroBase = datos.IdCatGiroBase;
                    personaMoral.IdCatTipoPersona = 4;
                    personaMoral.IdDireccion = direccion.Id;
                    personaMoral.IdEmpresa = idEmpresa;
                    personaMoral.IdRepresentanteLegal = representanteLegal.Id;
                    personaMoral.NombreComercial = datos.NombreComercial;
                    personaMoral.RazonSocial = datos.RazonSocial;
                    personaMoral.RFC = datos.RFC;
                    if (string.IsNullOrEmpty(personaMoral.IdContCORE))
                    {
                        DerivacionPolizasCore DerivaCore = new DerivacionPolizasCore();
                        personaMoral.IdContCORE = DerivaCore.DerivaPersonaMoralCore(personaMoral);
                    }
                    if (personaMoral.Id <= 0)
                        db.PersonaMoral.Add(personaMoral);

                    db.SaveChanges();

                    infoEmision.PersonaMoral = personaMoral;
                    infoEmision.PersonaMoralRepresentanteLegal = representanteLegal;
                }

            }
            catch (Exception ex)
            {
                error = "Ocurrio un error al tratar de agregar los datos de la Persona Moral / Representante Legal";
                log.Error("error AgregarPersonaMoral " + ex.ToString());
            }
            return error;
        }

        public JsonResult GetCoutnPolizasXUsuario(int idcotizacionDetalle)
        {
            string Mensaje = null;
            try
            {
                int idcot = db.CotizacionDetalle.FirstOrDefault(x => x.Id == idcotizacionDetalle).IdCotizacion;
                int idusu = db.Cotizacion.FirstOrDefault(x => x.Id == idcot).IdDetalleUsuario;
                int idempresa = Convert.ToInt32(db.DetalleUsuarioEmpresa.FirstOrDefault(x => x.IdDetalleUsuario == idusu).IdEmpresa);
                Empresa empresa = db.Empresa.FirstOrDefault(x => x.Id == idempresa);
                if (empresa.LimitVehiculos)
                {
                    DetalleUsuario CLI = db.DetalleUsuario.FirstOrDefault(x => x.Id == idusu);
                    if (CLI != null && !string.IsNullOrEmpty(CLI.IdCliCORE))
                    {
                        SqlParameter IDcliente = new SqlParameter("@IDCLI", CLI.IdCliCORE);
                        int Count = Convert.ToInt32(db.Database.SqlQuery<int>("SP_CountPolizasXClienteCore @IDCLI", IDcliente).SingleOrDefault());
                        if (Count >= empresa.LimiteVehiculos)
                            Mensaje = "Has llegado al límite de pólizas que tienes permitido emitir";
                    }

                }
            }
            catch (Exception)
            {
                Mensaje = "Ocurrio Un error al consultar el número de póliza del usuario";
            }
            return Json(Mensaje, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GuardaBitacora(int? idCotizacion)
        {
            string Mensaje = string.Empty;
            try
            {
                GenerateBitacora.GeneraBitacora(User.Identity.GetUserId(), (int)ModuloBitacora.MensajedeRegistroUsuarioSinRegistroAuto, idCotizacion);
                Mensaje = "Success";
            }
            catch (Exception ex)
            {
                Mensaje = "Failed";
            }

            return Json(Mensaje, JsonRequestBehavior.AllowGet);
        }
        [ValidateAntiForgeryToken]
        public JsonResult ValidaRFC(string ApellidoP, DateTime fechNac, string RFC, string sivalidaRFC, bool esAuto = true)
        {
            var mensaje = "";
            try
            {
                if (RFC.Length == 13)
                {
                    string date = fechNac.ToString("yyyy-MM-dd").Replace("-", "");
                    date = date.Substring(2, 6);
                    string rfcAPp = RFC.Substring(0, 2);
                    string rfcFechaNac = RFC.Substring(4, 6);
                    if (ApellidoP.Length > 0)
                    {

                        if (date != rfcFechaNac)
                        {
                            if (esAuto)
                                mensaje = "La fecha de nacimiento del conductor segurado no coincide con el RFC";
                            else
                                mensaje = "La fecha de nacimiento coincide con el RFC";
                        }
                    }
                    else
                    {
                        if (esAuto)
                            mensaje = "El Apellido Paterno del conductor asegurado no debe de ser vacío";
                        else
                            mensaje = "El Apellido Paterno no debe de ser vacío";
                    }
                }
                else
                {
                    if (esAuto)
                        mensaje = "El RFC del conductor asegurado debe de ser a 13 dígitos incluyendo homoclave";
                    else
                        mensaje = "El RFC debe de ser a 13 dígitos incluyendo homoclave";
                }
            }
            catch (Exception ex)
            {
                log.Info("se generó una excepción al validar el RFC " + ex.InnerException != null ? ex.InnerException.Message : ex.Message);
                mensaje = "";
            }
            return Json(mensaje, JsonRequestBehavior.AllowGet);
        }

    }

    public class CustomDropDown
    {
        public string Value { get; set; }
        public string Text { get; set; }
        public string Legend { get; set; }
    }
}

