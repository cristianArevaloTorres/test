USE [FlexiForbesv2]
GO

SET NOCOUNT ON;

-- CAT: CAMBIAR SOLO ESTOS VALORES PARA VALIDAR OTRA EMPRESA O TIPO.
DECLARE @IdEmpresa INT = 949;
DECLARE @IdTipoNotificacion INT = 43;

-- 1. MUESTRA LAS CONFIGURACIONES ACTIVAS PROPIAS Y DEL CORPORATIVO.
SELECT
    E.EMIdEmpresa AS EmpresaConsultada,
    E.EMIdCorporativo,
    C.CNEId AS IdConfiguracion,
    C.CNEIdEmpresa AS EmpresaConfiguracion,
    C.CNEIdTipoNotificacionCorreo AS TipoNotificacion,
    C.CNEIdPlantilla AS IdPlantilla,
    CASE
        WHEN C.CNEIdEmpresa = E.EMIdEmpresa THEN 'DIRECTA'
        ELSE 'CORPORATIVO'
    END AS OrigenConfiguracion
FROM dbo.ff_Empresa E
INNER JOIN dbo.bf_ConfiguracionNotificacionEmpresa C
    ON C.CNEIdEmpresa IN (E.EMIdEmpresa, E.EMIdCorporativo)
WHERE E.EMIdEmpresa = @IdEmpresa
  AND C.CNEIdTipoNotificacionCorreo = @IdTipoNotificacion
  AND C.CNEIdEstatus = 1
ORDER BY
    CASE WHEN C.CNEIdEmpresa = E.EMIdEmpresa THEN 0 ELSE 1 END,
    C.CNEId DESC;

-- 2. IDENTIFICA LA PLANTILLA QUE SELECCIONA LA REGLA DIRECTA/CORPORATIVO.
SELECT
    E.EMIdEmpresa AS EmpresaConsultada,
    X.OrigenConfiguracion,
    X.CNEId AS IdConfiguracionSeleccionada,
    X.CNEIdEmpresa AS EmpresaConfiguracion,
    X.CNEIdPlantilla AS IdPlantillaSeleccionada,
    P.PCTitulo AS TituloPlantilla,
    P.PCSujeto AS SujetoPlantilla,
    P.PCIdEstatus AS EstatusPlantilla
FROM dbo.ff_Empresa E
OUTER APPLY
(
    SELECT TOP (1)
        C.CNEId,
        C.CNEIdEmpresa,
        C.CNEIdPlantilla,
        CASE
            WHEN C.CNEIdEmpresa = E.EMIdEmpresa THEN 'DIRECTA'
            ELSE 'CORPORATIVO'
        END AS OrigenConfiguracion
    FROM dbo.bf_ConfiguracionNotificacionEmpresa C
    WHERE C.CNEIdTipoNotificacionCorreo = @IdTipoNotificacion
      AND C.CNEIdEstatus = 1
      AND C.CNEIdEmpresa IN (E.EMIdEmpresa, E.EMIdCorporativo)
    ORDER BY
        CASE WHEN C.CNEIdEmpresa = E.EMIdEmpresa THEN 0 ELSE 1 END,
        C.CNEId DESC
) X
LEFT JOIN dbo.ff_PlantillaCorreo P
    ON P.PCIdCorreo = X.CNEIdPlantilla
WHERE E.EMIdEmpresa = @IdEmpresa;
GO
