param(
    [string]$RepoFront = 'C:\repo\helpsoso\front'
)

Set-Location -LiteralPath $RepoFront

if (-not (Test-Path -LiteralPath '.git')) {
    throw "Esta carpeta no es un clon Git: $RepoFront"
}

$FrontFiles = @(
    'src/app/beflex/tickets/ticket.component.ts',
    'src/app/beflex/adm-tickets/adm-tickets.component.ts'
)

git status --short -- $FrontFiles
git add -- $FrontFiles
git diff --cached --check

if ($LASTEXITCODE -ne 0) {
    throw 'Git detecto errores en los archivos preparados.'
}

git commit -m "Plantillas dinamicas para notificaciones de tickets"

$Branch = git branch --show-current
if ([string]::IsNullOrWhiteSpace($Branch)) {
    throw 'No fue posible identificar la rama actual.'
}

git push -u origin $Branch
