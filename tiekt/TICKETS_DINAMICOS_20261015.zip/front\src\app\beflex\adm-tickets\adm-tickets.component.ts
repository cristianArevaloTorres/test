import { Component, ElementRef, OnInit, ViewChild, ViewChildren, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { EmpleadoService } from "../../services/empleado.service";
import { TicketService } from "../../services/ticket.service";
import swal from "sweetalert2";
import { GLOBAL } from "../../services/global";
import { Router } from "@angular/router";
import { MonitorTickets } from "../tickets/monitor/monitor.component";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { DatePipe } from '@angular/common'
import { ExcelService } from 'src/app/services/excel.service';
import { NgSelectComponent } from '@ng-select/ng-select';
declare var $: any;


@Component({
  selector: 'app-adm-tickets',
  templateUrl: './adm-tickets.component.html',
  styleUrls: ['./adm-tickets.component.css']
})
export class AdmTicketsComponent implements OnInit {
  public correoEmergencia;
  public ticketForm: FormGroup;
  public ticketMonitorForm: FormGroup;
  public segmentos;
  public Comment;
  public Subject;
  public Empleado;
  public empleados;
  public solicitudes;
  public insumos;
  public url;
  private identityAdmin;
  public uploadedFiles: any[] = [];   // archivos que se muestran en la lista del Input
  public archivosFisicos: any[] = []; // Archivos fisicos que van al Storage
  public btnLimpiar: boolean;
  private contador;
  private to;
  private cc;
  private bcc;
  private adminCorreos;
  private cliente;
  private rutaArchivos;
  private token;
  public verificarCorreoSolicitud;
  public status: any = [];
  selectedValue = [{ id: 1, desc: 'Nuevo' }, { id: 2, desc: 'En Tramite' }]; // esto pre-selecciona los valores NUEVO y EN TRAMITE
  public tickets: any;
  displayedColumns: string[] = ['solicitudDescripcion', 'ticketId', 'nombre', 'estatus', 'etapaAct', 'fechaRegistro', 'fechaRespuesta', 'ticketDescripcion', 'auxEstatus'];
  public displayedColumnsV2 = [
    { campo: 'Tipo de solicitud', campoBd: 'solicitudDescripcion', visible: true, value: '', esGestor: false },
    { campo: 'Ticket', campoBd: 'ticketId', visible: true, value: '', esGestor: false },
    { campo: 'Nombre', campoBd: 'nombre', visible: true, value: '', esGestor: false }

  ];

  public ticketsDescripcion;
  public ticketArchivos;
  public ticketEtapa;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  // ----------------------------------------------------------ADICIONALES---------------------------------------------

  public mostrarAdicionales: boolean = false;
  public esGestor: boolean = false;
  public idAdm: number = 0;
  selectedValueEtapas: number[] = [0];
  public idAsegurado: string = null;
  private datosReporte;
  public etapasTicket: any = [];
  public etapasTicketValue = [];
  public estatusGestor: any = [];
  private idEtapaActual = 0;
  private idEstatusActual = 0;

  private idEtapaElegida = 0;
  private idEstatusElegida = 0;

  private descripcionStatus = "";
  private nombreCliente = "";
  private correoAdmGestor = "";


  public habilitarEtapaDisable = 'initial';
  public habilitarStatusDisable = 'initial';
  public descripcionTicket = "";
  public descripcionTicketRegistrada = "";
  public correoIntroducidoAux;
  public correoIntroducido;
  public correoSeguimiento;

  public mostrarErrorSeguimiento = false;




  public selectedValueEstatus = [];
  @ViewChild('estatusS') estatusGestorSelect: NgSelectComponent;
  @ViewChild('etapaS') etapaGestorSelect: NgSelectComponent;
  @ViewChild('observacionesSeguimiento') textAreObservaciones;
  public empleadoSelecto: number = 0;
  public validacionesOk = true;
  public validacionesOkUlsa = true;
  public ticketSolicitudTramite = '0';
  public ticketSolicitudSolicitud: any = '0';
  public ticketSolicitudObservaciones;
  public idEmpleadoTmp;
  public correoEmpleado = '';
  public validacionIdEmpresa;
  // campos adicionales
  public ContactoA: any;
  public CorreoA: any;
  public Telefono1A: any;
  public Telefono2A: any;
  public HospitalA: any;

  public datosTabla;
  public page = 1;
  public pageSize = 5;
  public collectionSize = 0;
  public archivosCargados: any;
  @ViewChild('controlArchivo') controlArchivo: ElementRef;
  @ViewChild('controlArchivoGestor') controlArchivoGestor: ElementRef;
  public empleadosCargados = false;
  // ----------------------------------------------------------ADICIONALES---------------------------------------------

  //Seccion campos adicionales
  public monitoreoTramite = "0";
  public monitoreoSolicitud = "0";
  public corrreoEmpleadoTmp = "";
  public etapaStatusActual = { nombreEtapa: "", nombreStatus: "" };
  public tituloCerradoRechazado: string = "Requerimientos:";
  public plantillaTipoNotificaciones: any;
  public sujeto: any = "";
  constructor(
    private fb: FormBuilder,
    private _ticketService: TicketService,
    private _empleadoService: EmpleadoService,
    public datepipe: DatePipe,
    private _excelService: ExcelService,
  ) {
    this.ticketForm = this.fb.group({
      asegurado: new FormControl({ value: '', disabled: false }, Validators.required),
      segmento: new FormControl({ value: '', disabled: false }, Validators.required),
      solicitud: new FormControl({ value: '', disabled: false }, Validators.required),
      observaciones: new FormControl({ value: '', disabled: false }, Validators.required),
      archivos: new FormControl({ value: '', disabled: false }, Validators.required),
      correo: new FormControl({ value: '', disabled: false }, Validators.required),
      contactoE: new FormControl({ value: '', disabled: false }, Validators.required),
      correoG: new FormControl({ value: '', disabled: false }, Validators.required),
      tel1: new FormControl({ value: '', disabled: false }, Validators.required),
      tel2: new FormControl({ value: '', disabled: false }, Validators.required),
      hospitalE: new FormControl({ value: '', disabled: false }, Validators.required),
    });
    this.ticketMonitorForm = this.fb.group({
      segmento: new FormControl({ value: '', disabled: false }),
      solicitud: new FormControl({ value: '', disabled: false }),
      status: new FormControl({ value: '', disabled: false }, Validators.required),
      fechaI: new FormControl({ value: '', disabled: false }),
      fechaF: new FormControl({ value: '', disabled: false }),
      etapaTicket: new FormControl({ value: '', disabled: false }),
    });
    this.identityAdmin = JSON.parse(localStorage.getItem('identity'));
    this.rutaArchivos = `/DocumentoEmpresa/${this.identityAdmin.idEmpresa}/Tickets/`;
    this.url = GLOBAL.url;
    this.token = this._empleadoService.getToken();
    this.idAdm = this.identityAdmin.id;
    this.validacionIdEmpresa = this.identityAdmin.idEmpresa;
  }

  public auxTamañoArchivo = 0;

  ngOnInit() {
    this.obtenerSegmentos();
    this.obtenerStatusControl();
    this.limpiarCampos();
    this.obtenerEmpleados();
    if (this.identityAdmin.idEmpresa != "371") {
      this.validacionesOkUlsa = false;
    }
  }

  handleInput($event) {
    if ($event.key == 'Backspace') {
      this.empleadoSelecto = 0;

    }
  }

  setDefault() {
    this.empleadoSelecto = 0;
    this.validacionesOk = true;
  }

  limpiarAsegurados() {
    this.empleadoSelecto = 0;
  }
  onOpen(elem) {

    let value: string = elem.filterInput.nativeElement.value;

    if (elem.filterInput.nativeElement.value == "") {
      elem.close();
    } else if (false) {
      elem.close();

    }

    if (this.identityAdmin.idEmpresa == 371)
      this.validacionesCamposUlsa();
  }

  onSearch(elem) {
    let value: string = elem.filterInput.nativeElement.value;
    if (elem.filterInput.nativeElement.value == "") {
      elem.close();
    } else if (false) {
      elem.close();
    }
  }

  async obtenerEmpleados() {
    swal({
      title: 'Cargando asegurados...',
      allowEscapeKey: false,
      allowOutsideClick: false,
      onOpen: async () => {
        swal.showLoading();
        try {
          const result: any = await this._ticketService.obtenerEmpleados(this.identityAdmin.idEmpresa)
          this.empleados = [];
          this.empleados = [...this.empleados, { id: 0, name: 'Busca asegurado...', numEmpleado: '0', correo: '' }];
          result.forEach(e => {
            e['FullName'] = '';
            if (e.emnumeroEmpleado) {
              e['FullName'] += e.emnumeroEmpleado + "- "
            }
            if (e.EMNombre1 && e.EMNombre1.trim().length > 0) {
              e['FullName'] += e.EMNombre1
            }
            if (e.EMNombre2 && e.EMNombre2.trim().length > 0) {
              e['FullName'] += ' ' + e.EMNombre2
            }
            if (e.EMApellidoPaterno && e.EMApellidoPaterno.trim().length > 0) {
              e['FullName'] += ' ' + e.EMApellidoPaterno
            }
            if (e.EMApellidoMaterno && e.EMApellidoMaterno.trim().length > 0) {
              e['FullName'] += ' ' + e.EMApellidoMaterno
            }
            this.empleados = [...this.empleados, { id: e.Id, name: e['FullName'], numEmpleado: e.emnumeroEmpleado, correo: e.EMCorreoElectronico }];
          });
          swal.close();
          this.empleadoSelecto = 0;
        } catch (error) {
          swal.close();
        }
      }
    });



  }

  async obtenerSegmentos() {
    try {
      const result = await this._ticketService.obtenerTramiteSegmentoAdmin(this.identityAdmin.idCorporativo, this.identityAdmin.idEmpresa)
      this.segmentos = result;
    } catch (error) {
    }


  }

  async obtenerStatusControl() {
    try {
      const result = await this._ticketService.obtenerStatusControl();
      this.status = result
    } catch (error) {
    }
  }

  obtenerCorreosGrupos(data) {
    this.to = null;
    this.cc = '';
    this.bcc = '';
    this.adminCorreos = data;
    if (this.adminCorreos) {
      this.adminCorreos.map((r) => {
        const ADMIN_CORREOS = r['adCorreoElectronico'];
        const ADMIN_CC = r['gcCorreoCopia'];
        const ADMIN_C_OCULTA = r['gcCorreoCopiaOculta']

        if (this.to != null) {
          this.to = this.to.replace(/ /g, "")
          if (ADMIN_CC == true && ADMIN_CC != undefined) {
            this.cc += ADMIN_CORREOS + ","
            this.cc = this.cc.replace(/ /g, "")
            this.cc = this.cc.replace(/undefined/g, "")
          }
          if (ADMIN_C_OCULTA == true && ADMIN_C_OCULTA != undefined) {
            this.bcc += ADMIN_CORREOS + ","
            this.bcc = this.bcc.replace(/ /g, "")
          }

        } else {
          this.to = " ";
          if (ADMIN_CC == true) {
            this.to += ADMIN_CORREOS + ","
          }
        }
      });
    }

    if (this.corrreoEmpleadoTmp) {
      this.cc += this.corrreoEmpleadoTmp;
    }
  }
  obtenerCorreosGruposV2(data) {
    this.to = null;
    this.cc = "";
    this.bcc = "";
    this.adminCorreos = data;
    if (this.adminCorreos) {
      this.to = "";
      this.adminCorreos.map((r) => {
        const ADMIN_CORREOS = r['adCorreoElectronico'];
        this.to += `${ADMIN_CORREOS},`;
      });
    }

    if (this.corrreoEmpleadoTmp) {
      this.to += this.corrreoEmpleadoTmp;
    }
  }

  obtenerCorreosGruposV3(data) {
    this.to = "";
    this.cc = "";
    this.bcc = "";
    this.adminCorreos = data;
    if (this.adminCorreos) {
      this.adminCorreos.map((r) => {
        let to = r['gcCorreoCopia'];
        let cc = r['gcCorreoCopiaOculta']
        let bcc = r['gcCorreoVisible'];

        if (to) {
          this.to += r['adCorreoElectronico'] + ',';
        } else if (cc) {
          this.cc += r['adCorreoElectronico'] + ',';
        } else if (bcc) {
          this.bcc += r['adCorreoElectronico'] + ',';
        }
      });
    }

    if (this.corrreoEmpleadoTmp) {
      this.to += this.corrreoEmpleadoTmp + ',';
    }
  }

  async getConfiguracionNotificacionEmpresa(tipoNotificacion, idEmpleado) {
    try {
      // CAT: Resuelve la plantilla por empresa y tipo: alta, rechazo o cierre.
      const result = await this._ticketService.getConfiguracionNotificacion(this.identityAdmin.idEmpresa, tipoNotificacion, idEmpleado);
      if (!result || !result['plantilla'] || !result['plantilla'][0]
        || !result['plantilla'][0].contenido) {
        throw new Error('No existe una plantilla activa para el tipo de notificación solicitado.');
      }
      this.corrreoEmpleadoTmp = '';
      if (tipoNotificacion == 43) {
        if (result['emCorreoElectronico']) {
          this.corrreoEmpleadoTmp = result['emCorreoElectronico'];
          this.corrreoEmpleadoTmp = this.corrreoEmpleadoTmp.replace(/;/g, "");
        }
      } else if (tipoNotificacion == 44 || tipoNotificacion == 46) {
        if (result['admCorreoElectronico']) {
          this.corrreoEmpleadoTmp = result['admCorreoElectronico'];
          this.corrreoEmpleadoTmp = this.corrreoEmpleadoTmp.replace(/;/g, "");
        }
      }
      this.obtenerCorreosGruposV3(result['correosGrupo']);
      if (result['plantilla'][0].contenido) {
        this.plantillaTipoNotificaciones = result['plantilla'][0].contenido;
      }
      if (result['plantilla'][0].sujeto) {
        this.sujeto = result['plantilla'][0].sujeto;
      }
      return result;
    } catch (error) {
      this.plantillaTipoNotificaciones = null;
      this.sujeto = '';
      console.log('Error obteniendo la configuración de notificación', error);
      return null;
    }

  }

  onChangeEmpleado(event) {
    if (event) {
      if (this.empleadoSelecto == 0 || this.ticketSolicitudTramite == '0' || this.ticketSolicitudSolicitud == '0' || this.ticketSolicitudSolicitud == undefined || this.ticketSolicitudObservaciones == "" || this.ticketSolicitudObservaciones == undefined) {
        this.validacionesOk = true;
        if (this.identityAdmin.idEmpresa == 371) {
          this.validacionesCamposUlsa();
        }
      } else {
        this.validacionesOk = false;
        if (this.identityAdmin.idEmpresa == 371) {
          this.validacionesCamposUlsa();
        }
      }
      this.cliente = event.name;
      this.correoEmpleado = event.correo;
    }
  }

  async onChangeSegmento(event) {
    this.insumos = null;
    this.ticketSolicitudSolicitud = "0";

    if (this.empleadoSelecto == 0 || this.ticketSolicitudTramite == '0' || this.ticketSolicitudSolicitud == '0' || this.ticketSolicitudSolicitud == undefined || this.ticketSolicitudObservaciones == "" || this.ticketSolicitudObservaciones == undefined) {
      this.validacionesOk = true;
    } else {
      this.validacionesOk = false;
    }

    if (this.identityAdmin.idEmpresa == 371) {
      this.validacionesCamposUlsa();
    }


    let idTipoTramite = this.ticketForm.get('segmento').value;
    let idTipoSolicitud = this.ticketForm.get('solicitud').value;
    if ((idTipoTramite == 6 || idTipoTramite == 7) && (idTipoSolicitud == 55 || idTipoSolicitud == 56)) {

      this.mostrarAdicionales = true;
    } else {
      this.mostrarAdicionales = false;
    }

    const path = event.path || (event.composedPath && event.composedPath());

    if (path) {
      this.solicitudes = [];
      let idSolicitud = event.target.value;


      try {
        const response = await this._ticketService.obtenerSolicitudAdmin(idSolicitud);
        this.solicitudes = response;
        this.ticketSolicitudSolicitud = "0";
        this.monitoreoSolicitud = "0";
        let solicitudExiste = $('#solicitud').val();  // Solicitud [0] en caso de cambiar de Estado
        if (solicitudExiste || this.solicitudes[0].solicitudId) {
          await this._ticketService.obtenerInsumos(this.solicitudes[0].solicitudId);
        }
      } catch (error) {

      }

    }
  }

  async onChangeSolicitud(event, solicitudes) {

    if (this.empleadoSelecto == 0 || this.ticketSolicitudTramite == '0' || this.ticketSolicitudSolicitud == '0' || this.ticketSolicitudSolicitud == undefined || this.ticketSolicitudObservaciones == "" || this.ticketSolicitudObservaciones == undefined) {
      this.validacionesOk = true;
    } else {
      this.validacionesOk = false;
    }


    if (this.identityAdmin.idEmpresa == 371)
      this.validacionesCamposUlsa();


    let idTipoTramite = this.ticketForm.get('segmento').value;
    let idTipoSolicitud = this.ticketForm.get('solicitud').value;
    if ((idTipoTramite == 6 || idTipoTramite == 7) && (idTipoSolicitud == 55 || idTipoSolicitud == 56)) {
      this.mostrarAdicionales = true;
    } else {
      this.mostrarAdicionales = false;
    }


    const path = event.path || (event.composedPath && event.composedPath());

    if (path) {
      let idSolicitud = event.target.value;

      if (idSolicitud != 0) {
        try {
          const response = await this._ticketService.obtenerInsumos(idSolicitud);
          this.insumos = response;
        } catch (error) {
        }
      } else {
        this.insumos = null;

      }

      solicitudes.forEach((e) => {
        if (e.solicitudId == idSolicitud) {
          this.verificarCorreoSolicitud = e.solicitudMail;
        }
      });

    }
  }


  handleUpload(event) {
    this.btnLimpiar = false;
    let contadorArchivos = 0;

    Array.from(event.target.files).forEach(e => {
      const regexpNumber = new RegExp('^[A-Za-z0-9]+$');
      let resplit = e['name'].split('.');
      let ext = resplit[1];
      let nomb = resplit[0];
      let invaliNombre = resplit.length > 2 ? true : false;
      // contadorArchivos++;

      if (!regexpNumber.test(nomb)) {
        invaliNombre = true;
      }


      if (invaliNombre) {

        swal({
          title: '¡Atención!',
          type: 'info',
          html:
            '<small style="color: grey; text-align: justify;">' +
            `El archivo <b>${e['name']}</b> no es válido.<br><br>` +
            'El nombre solo puede contener letras y números antes de la extensión.<br><br>' +
            '<b>Ejemplo correcto: Documento123.pdf</b>' +
            '</small>',
          confirmButtonText: 'Aceptar',
        });
        this.controlArchivo.nativeElement.value = '';
        this.controlArchivoGestor.nativeElement.value = '';

      } else if (ext !== 'pdf' && ext !== 'xml' && ext !== 'xlsx' && ext !== 'xls' && ext !== 'doc' && ext !== 'docx') {
        swal({
          title: '¡Atención!',
          type: 'info',
          html: '<small style="color: grey; text-align: justify;">' +
            'Algunos de los archivos seleccionados no cumplen con los formatos aceptados <b>(PDF, XML, XLS, XLSX, DOC, DOCX)</b></small>',
          confirmButtonText: 'Aceptar',
        });
        this.ticketForm.get('archivos').setValue('');
        this.btnLimpiar = false;
        this.controlArchivoGestor.nativeElement.value = '';
      } else {
        if (nomb.length > 50) {
          swal({
            title: '¡Atención!',
            type: 'info',
            html: '<small style="color: grey; text-align: justify;">' +
              'Algunos de los archivos seleccionados tienen nombres invalidos.El numero caracteres permitidos son menos a 50</small>',
            confirmButtonText: 'Aceptar',
          });

          this.ticketForm.get('archivos').setValue('');
          this.controlArchivoGestor.nativeElement.value = '';
          this.btnLimpiar = false;
        } else {

          // Se calcula el tamaño real de los archivos actualmente cargados
          this.auxTamañoArchivo = this.archivosFisicos.reduce(
            (total, archivo) => total + archivo['size'],
            0
          );

          // Se agrega temporalmente el tamaño del nuevo archivo para validar el límite
          const tamañoTotal = this.auxTamañoArchivo + e['size'];

          if (tamañoTotal < 4000000) {
            this.auxTamañoArchivo = tamañoTotal;
            this.uploadedFiles.push(e);
            this.archivosFisicos.push(e);  // Archivos que van al Storare y a la BD
          } else {
            if (contadorArchivos == 0) {
              swal({
                title: '¡Atención!',
                type: 'info',
                html: `<small style="color: grey; text-align: justify;">¡El peso de archivos es mayor a 4MB! </br>
                  `,
                confirmButtonText: 'Aceptar',
              });
              this.controlArchivo.nativeElement.value = '';
              this.controlArchivoGestor.nativeElement.value = '';
              contadorArchivos++;
            }
          }
        }
      }
    });

    if (this.archivosFisicos.length > 0) {
      this.btnLimpiar = true;
      this.controlArchivo.nativeElement.value = '';
      this.controlArchivoGestor.nativeElement.value = '';

    }
  }


  evnDel() {
    this.btnLimpiar = false;
    this.ticketForm.get('archivos').setValue('');
    this.archivosFisicos = [];
    this.auxTamañoArchivo = 0;
    return this.uploadedFiles = [];
  }

  async crearTicketZendesk(ticketId) {
    var token = "";
    try {
      const resultAuth: any = await this._ticketService.authAPI_Beflex();

      token = resultAuth.data.token;
      try {
        const resValidacion: any = await this._empleadoService.getParametroCorporativo(this.identityAdmin.idEmpresa, 236);

        if (resValidacion.valor == '1') {
          //#region Datos Zendesk Ticket
          let listEmpleados = this.empleados;
          const empleado = listEmpleados.find(e => e.id === this.empleadoSelecto)
          const nombreEmpleado = empleado.name;
          this.Empleado = "Número Empleado: " + empleado.numEmpleado + "\nNombre Empleado:" + nombreEmpleado.split('-')[1];

          let listTramite = this.segmentos;
          const segmento = listTramite.find(e => e.segmentoId === parseInt(this.ticketSolicitudTramite));
          this.Comment = "Ticket Beflex: " + ticketId + " \nTrámite: " + segmento.segmentoDescripcion + "\n";

          const admin = JSON.parse(localStorage.getItem('identityAdmin'))[0];
          let listSolicitud = this.solicitudes;
          const solicitud = listSolicitud.find(e => e.solicitudId === parseInt(this.ticketSolicitudSolicitud));
          this.Comment += "Solicitud: " + solicitud.solicitudDescripcion + "\n" + this.Empleado + "\nEmpresa: " + admin.nomEmpresa;
          this.Subject = solicitud.solicitudDescripcion;

          var objZendesk = { subject: this.Subject, comment: this.Comment, requester: nombreEmpleado.split('-')[1], Token: token };

          try {
            const resultZendesk: any = await this._ticketService.crearTicketZendesk(objZendesk);
            if (resultZendesk.exito) {
              var TicketBeflex = { IdTicketBeflex: ticketId, IdTicketZendesk: resultZendesk.data }
              await this._ticketService.actualizarTicketBelfex(TicketBeflex, token);
            }
          } catch (error) {

          }
        }
      } catch (error) {

      }

    } catch (error) { }
  }

  onSubmit() {
    const idSolicitud = this.ticketForm.get('solicitud').value;
    const observaciones = this.ticketForm.get('observaciones').value;
    let correoTicket = this.ticketForm.get('correo').value;

    if (!correoTicket) {
      correoTicket = "";
    }

    this.contador = 0;

    swal({
      title: '¡Atención!',
      type: 'warning',
      html: '<small style="color: grey; text-align: justify;">'
        + '¿Está seguro que están todos los archivos adjuntos? <b>' + '</b></small>',
      confirmButtonText: 'Aceptar',
      cancelButtonText: 'Cancelar',
      showCancelButton: true,
      allowOutsideClick: false,
      allowEscapeKey: false,
      allowEnterKey: false,
    }).then(async (result) => {
      if (result.value) {

        if (!this.validacionesOk && !this.validacionesOkUlsa) {

          if (!this.ticketForm.get('asegurado').value) {

            swal({
              title: '¡Atención!',
              type: 'warning',
              html: '<small style="color: grey; text-align: justify;">' +
                'Selecciona un empleado</small>',
              confirmButtonText: 'Aceptar',
            });

          } else if (this.archivosFisicos.length) {
            swal({
              title: 'Espere un momento...',
              html: '',
              allowOutsideClick: false,
              onOpen: async () => {
                swal.showLoading();

                if (this.mostrarAdicionales) {
                  const contactoE = this.ticketForm.get('contactoE').value;
                  const correoG = this.ticketForm.get('correoG').value;
                  const tel1 = this.ticketForm.get('tel1').value;
                  const tel2 = this.ticketForm.get('tel2').value;
                  const hospitalE = this.ticketForm.get('hospitalE').value;
                  if (!(/^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i.test(correoG))) {
                    swal({
                      title: '¡Atención!',
                      type: 'warning',
                      html: '<small style="color: grey; text-align: justify;">' +
                        'El correo introducido no es correcto</small>',
                      confirmButtonText: 'Aceptar',
                    });


                  } else {
                    try {
                      const result = await this._ticketService.insertarNuevoTicketAdicional(this.ticketForm.get('asegurado').value, idSolicitud, observaciones, this.ticketForm.get('asegurado').value, correoG, contactoE, tel1, tel2, hospitalE);

                      // CAT: Espera la notificacion antes de limpiar los datos de pantalla.
                      await this.obtenerPlantillaTicket(result[0].ticketId, result[0].segmentoDescripcion + ' - ' + result[0].solicitudDescripcion, "");

                      //Se crea ticket Zendesk
                      this.crearTicketZendesk(result[0].ticketId);

                      let auxNumArchivos = Array.from(this.archivosFisicos).length;
                      Array.from(this.archivosFisicos).map((val) => {
                        var form = new FormData();  // LSData es el formData
                        form.append("file", val); // this.LSdata.append("file", inputEl.files.item(0));
                        const settings = {
                          "async": true,
                          "crossDomain": true,
                          "url": this.url + "file/upload?directorio=" + this.rutaArchivos + "&nombre="
                            + `${this.ticketForm.get('asegurado').value}_${result[0].ticketId}_${val['name']
                              .substring(0, val['name'].indexOf("."))}`,
                          "method": "POST",
                          "headers": {
                            "authorization": this.token
                          },
                          "processData": false,
                          "contentType": false,
                          "mimeType": "multipart/form-data",
                          "data": form
                        };

                        $.ajax(settings).done((response) => {
                          this.contador++;
                          this.insertarArchivFisicoBD(result[0].ticketId, this.rutaArchivos, val.name);
                          if (this.contador === auxNumArchivos) {
                            swal({
                              title: '¡Operación Exitosa!',
                              type: 'success',
                              html: '<small style="color: grey; text-align: justify;">'
                                + 'Tu solicitud será atendida con el ticket: <b>' + result[0].ticketId + '</b></small>',
                              confirmButtonText: 'Aceptar',
                            }).then((result) => {
                              if (result) {
                                this.limpiarCampos();
                                this.ngOnInit();
                                this.controlArchivo.nativeElement.value = '';
                                this.evnDel();
                              }
                            });

                          }
                        }).fail((error) => {
                          swal({
                            title: '¡Atención!',
                            type: 'info',
                            html: '<small style="color: grey; text-align: justify;">' +
                              'No fue posible agregar los archivos, favor de contactar a su administrador</small>',
                            confirmButtonText: 'Aceptar',
                          });
                        });
                      });
                    } catch (error) {
                      swal({
                        title: '¡Atención!',
                        type: 'info',
                        html: '<small style="color: grey; text-align: justify;">' +
                          'El nombre de cada archivo no debe contener caracteres especiales como acentos o espacios en blanco.</small>',
                        confirmButtonText: 'Aceptar',
                      });
                    }
                  }
                } else {
                  try {
                    const result = await this._ticketService.insertarNuevoTicket(this.ticketForm.get('asegurado').value, idSolicitud, observaciones, this.ticketForm.get('asegurado').value, correoTicket);
                    // CAT: Espera la notificacion antes de limpiar los datos de pantalla.
                    await this.obtenerPlantillaTicket(result[0].ticketId, result[0].segmentoDescripcion + ' - ' + result[0].solicitudDescripcion, "");

                    //Se crea ticket Zendesk
                    this.crearTicketZendesk(result[0].ticketId);

                    let auxNumArchivos = Array.from(this.archivosFisicos).length;
                    Array.from(this.archivosFisicos).map((val) => {
                      const form = new FormData();  // LSData es el formData
                      form.append("file", val); // this.LSdata.append("file", inputEl.files.item(0));

                      const settings = {
                        "async": true,
                        "crossDomain": true,
                        "url": this.url + "file/upload?directorio=" + this.rutaArchivos + "&nombre="
                          + `${this.ticketForm.get('asegurado').value}_${result[0].ticketId}_${val['name']
                            .substring(0, val['name'].indexOf("."))}`,
                        "method": "POST",
                        "headers": {
                          "authorization": this.token
                        },
                        "processData": false,
                        "contentType": false,
                        "mimeType": "multipart/form-data",
                        "data": form
                      }

                      $.ajax(settings).done((response) => {

                        this.contador++;
                        this.insertarArchivFisicoBD(result[0].ticketId, this.rutaArchivos, val.name);
                        if (this.contador === auxNumArchivos) {
                          swal({
                            title: '¡Operación Exitosa!',
                            type: 'success',
                            html: '<small style="color: grey; text-align: justify;">'
                              + 'Tu solicitud será atendida con el ticket: <b>' + result[0].ticketId + '</b></small>',
                            confirmButtonText: 'Aceptar',
                          }).then((result) => {
                            if (result) {
                              this.limpiarCampos();
                              this.ngOnInit();
                              this.controlArchivo.nativeElement.value = '';
                              this.evnDel();
                            }
                          });
                        }
                      }).fail((error) => {
                        swal({
                          title: '¡Atención!',
                          type: 'info',
                          html: '<small style="color: grey; text-align: justify;">' +
                            'No fue posible agregar los archivos, favor de contactar a su administrador</small>',
                          confirmButtonText: 'Aceptar',
                        });
                      });
                    });
                  } catch (error) {

                    swal({
                      title: '¡Atención!',
                      type: 'info',
                      html: '<small style="color: grey; text-align: justify;">' +
                        'El nombre de cada archivo no debe contener caracteres especiales como acentos o espacios en blanco.</small>',
                      confirmButtonText: 'Aceptar',
                    });
                  }

                }





              },
            }).then((result) => { });
          } else {
            if (this.mostrarAdicionales) {

              const contactoE = this.ticketForm.get('contactoE').value;
              const correoG = this.ticketForm.get('correoG').value;
              const tel1 = this.ticketForm.get('tel1').value;
              const tel2 = this.ticketForm.get('tel2').value;
              const hospitalE = this.ticketForm.get('hospitalE').value;

              if (!(/^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i.test(correoG))) {

                swal({
                  title: '¡Atención!',
                  type: 'warning',
                  html: '<small style="color: grey; text-align: justify;">' +
                    'El correo introducido no es correcto</small>',
                  confirmButtonText: 'Aceptar',
                });

              } else {
                try {
                  const result = await this._ticketService.insertarNuevoTicketAdicional(this.ticketForm.get('asegurado').value, idSolicitud, observaciones, this.ticketForm.get('asegurado').value, correoG, contactoE, tel1, tel2, hospitalE);

                  await this.obtenerPlantillaTicket(result[0].ticketId, result[0].segmentoDescripcion + ' - ' + result[0].solicitudDescripcion, "");

                  //Se crea ticket Zendesk
                  this.crearTicketZendesk(result[0].ticketId);
                  swal({
                    title: '¡Operación Exitosa!',
                    type: 'success',
                    html: '<small style="color: grey; text-align: justify;">'
                      + 'Tu solicitud será atendida con el ticket: <b>' + result[0].ticketId + '</b></small>',
                    confirmButtonText: 'Aceptar',
                  }).then((result) => {
                    if (result) {
                      this.limpiarCampos();
                      this.ngOnInit();
                      this.controlArchivo.nativeElement.value = '';
                      this.evnDel();
                    }
                  });
                } catch (error) {

                }
              }




            } else {
              try {
                const result = await this._ticketService.insertarNuevoTicket(this.ticketForm.get('asegurado').value, idSolicitud, observaciones, this.ticketForm.get('asegurado').value, correoTicket)
                await this.obtenerPlantillaTicket(result[0].ticketId, result[0].segmentoDescripcion + ' - ' + result[0].solicitudDescripcion, "");
                this.crearTicketZendesk(result[0].ticketId);
                swal({
                  title: '¡Operación Exitosa!',
                  type: 'success',
                  html: '<small style="color: grey; text-align: justify;">'
                    + 'Tu solicitud será atendida con el ticket: <b>' + result[0].ticketId + '</b></small>',
                  confirmButtonText: 'Aceptar',
                }).then((result) => {
                  if (result) {
                    this.limpiarCampos();
                    this.ngOnInit();
                    this.controlArchivo.nativeElement.value = '';
                    this.evnDel();
                  }
                });
              } catch (error) { }
            }
          }
        }
      }
    });





  }

  async insertarArchivFisicoBD(ticketId, directorio, nombre) {
    try {
      await this._ticketService.insertaTicketArchivo(ticketId,
        `${this.ticketForm.get('asegurado').value}_${ticketId}_${nombre}`, directorio, this.ticketForm.get('asegurado').value);
    } catch (error) {
    }
  }

  async obtenerPlantillaTicket(idTicket, Segmento, estatus) {
    try {
      const configuracion = await this.getConfiguracionNotificacionEmpresa(
        43,
        this.ticketForm.get('asegurado').value
      );
      if (!configuracion) {
        return;
      }

      try {
        const datosResponsable = await this._ticketService.obtenerResponsableEtapaInicial();
        if (datosResponsable)
          if (datosResponsable[0].length > 0)
            if (datosResponsable[0][0].Etapa_ResponsableCorreo)
              this.to += datosResponsable[0][0].Etapa_ResponsableCorreo + ',';
        // let resultPlantilla = result[0].plantilla;
          this.cliente = this.cliente.replace(/^[^-]+-\s*/, '');
        const resultPlantilla = this.personalizarPlantillaTicket(
          this.plantillaTipoNotificaciones,
          idTicket,
          Segmento,
          'Nuevo',
          this.cliente
        );

        if (this.to) {
          await this.enviarNotificacion(this.sujeto, resultPlantilla, this.to, this.cc, this.bcc, "");
        }
      } catch (error) {

      }

    } catch (error) {

    }

  }

  limpiarCampos() {
    this.ticketForm.get('archivos').setValue('');
    this.ticketForm.get('asegurado').setValue('');
    this.ticketForm.get('observaciones').setValue('');
    this.ticketForm.get('solicitud').setValue('');
    this.ticketForm.get('segmento').setValue('');
    if (this.mostrarAdicionales) {
      this.ticketForm.get('contactoE').setValue('');
      this.ticketForm.get('correoG').setValue('');
      this.ticketForm.get('tel1').setValue('');
      this.ticketForm.get('tel2').setValue('');
      this.ticketForm.get('hospitalE').setValue('');
    }
    this.insumos = null;
    this.btnLimpiar = false;
    this.validacionesOk = true;
    this.validacionesOkUlsa = true;
    this.ticketSolicitudTramite = '0';
    this.ticketSolicitudSolicitud = '0';
  }

  async enviarNotificacion(sujeto, plantilla, to, cc, bcc, txt) {
    try {
      await this._empleadoService.sendMailUnificado(to, cc, bcc, sujeto, plantilla, txt, '', '', '', 21, this._empleadoService.getToken());
      this.to = "";
      this.corrreoEmpleadoTmp = "";
      this.bcc = "";
      this.cc = "";
    } catch (error) { }
  }

  async onSubmitMonitor() {
    let timerInterval;
    this.tickets = new MatTableDataSource<MonitorTickets>([]);
    swal({
      title: 'Cargando datos...',
      html: '',
      allowOutsideClick: false,
      timer: 4000,
      onOpen: () => {
        swal.showLoading();
        timerInterval = setInterval(() => {
        }, 100);
      },
      onClose: () => {
        clearInterval(timerInterval)
      }
    }).then((result) => { });

    const fechaI = this.ticketMonitorForm.controls['fechaI'].value;
    const fechaF = this.ticketMonitorForm.controls['fechaF'].value;
    const fechaI_f = this.datepipe.transform(fechaI, 'yyyy-MM-dd');
    const fechaF_f = this.datepipe.transform(fechaF, 'yyyy-MM-dd');

    let idStatus = '';
    this.ticketMonitorForm.controls['status'].value.forEach(element => {
      idStatus += element.id + ","
    });


    if (idStatus) {

      try {
        const response: any = await this._ticketService.obtenerTiketsAdm(this.identityAdmin.idEmpresa, this.identityAdmin.id,
          this.ticketMonitorForm.controls['segmento'].value, this.ticketMonitorForm.controls['solicitud'].value, idStatus, fechaI_f, fechaF_f);

        swal({
          title: '¡Datos cargados!',
          type: 'success',
          confirmButtonText: 'Aceptar',
        });

        this.datosTabla = response.map(titulares => this.valuesToArray(titulares));
        this.datosReporte = response;

        this.displayedColumns = ['solicitudDescripcion', 'ticketId', 'nombre', 'estatus', 'etapaAct', 'fechaRegistro', 'fechaRespuesta', 'ticketDescripcion', 'auxEstatus'];

        this.displayedColumnsV2 = [
          { campo: 'Estatus', campoBd: 'estatus', visible: true, value: '', esGestor: false },
          { campo: 'Tipo de solicitud', campoBd: 'solicitudDescripcion', visible: true, value: '', esGestor: false },
          { campo: 'Ticket', campoBd: 'ticketId', visible: true, value: '', esGestor: false },


          { campo: 'Certificado', campoBd: 'certificado', visible: true, value: '', esGestor: false },

          { campo: 'Nombre', campoBd: 'nombre', visible: true, value: '', esGestor: false },
          { campo: 'Contacto de Emergencia', campoBd: 'contactoEmergencia', visible: true, value: '', esGestor: false },
          { campo: 'Teléfono1', campoBd: 'tel1', visible: true, value: '', esGestor: false },
          { campo: 'Teléfono2', campoBd: 'tel2', visible: true, value: '', esGestor: false },
          { campo: 'Hospital', campoBd: 'contactoHospital', visible: true, value: '', esGestor: false },
          { campo: 'Correo', campoBd: 'mailTicket', visible: true, value: '', esGestor: false },


          { campo: 'Semaforo', campoBd: 'semaforo', visible: true, value: '', esGestor: false },

          { campo: 'Etapa', campoBd: 'etapaAct', visible: true, value: '', esGestor: false },
          { campo: 'Fecha solicitud', campoBd: 'fechaRegistro', visible: true, value: '', esGestor: false },
          { campo: 'Fecha respuesta', campoBd: 'fechaRespuesta', visible: true, value: '', esGestor: false },
          { campo: 'Observaciones', campoBd: 'ticketDescripcion', visible: true, value: '', esGestor: false },


          { campo: 'estatusId', campoBd: 'estatusId', visible: false, value: '', esGestor: false },
          { campo: 'idEmpleado', campoBd: 'idEmpleado', visible: false, value: '', esGestor: false },
          { campo: 'etapaId', campoBd: 'etapaId', visible: false, value: '', esGestor: false },
        ];


        if (this.identityAdmin.idEmpresa == 371) {

          this.displayedColumns.splice(3, 0, "contactoEmergencia");
          this.displayedColumns.splice(3, 0, "contactoHospital");
          this.displayedColumns.splice(3, 0, "tel1");
          this.displayedColumns.splice(3, 0, "tel2");

          this.displayedColumnsV2.splice(3, 0, { campo: 'contactoEmergencia', campoBd: 'contactoEmergencia', visible: true, value: '', esGestor: false });
          this.displayedColumnsV2.splice(3, 0, { campo: 'contactoHospital', campoBd: 'contactoHospital', visible: true, value: '', esGestor: false });
          this.displayedColumnsV2.splice(3, 0, { campo: '"tel1"', campoBd: '"tel1"', visible: true, value: '', esGestor: false });
          this.displayedColumnsV2.splice(3, 0, { campo: '"tel2"', campoBd: '"tel2"', visible: true, value: '', esGestor: false });

        }
        this.displayedColumnsV2.push({ campo: 'idAdm', campoBd: 'administrador', visible: false, value: '', esGestor: false });
        let datosTablaAux = [];
        let datosTablaAux2 = [];
        let objAdmTmp;
        let statusTmp;
        for (let i = 0; i < this.datosTabla.length; i++) {
          datosTablaAux = [];
          for (let j = 0; j < this.datosTabla[i].length; j++) {

            let campoVisual = this.validaCampo(this.datosTabla[i][j].key);

            if (campoVisual) {

              if (campoVisual.campoBd == "estatusId")
                statusTmp = this.datosTabla[i][j].value;


              if (campoVisual.campoBd == "administrador") {
                objAdmTmp = { campo: campoVisual.campo, campoBd: this.datosTabla[i][j].key, value: this.datosTabla[i][j].value, visible: campoVisual.visible, esGestor: this.identityAdmin.id == this.datosTabla[i][j].value };
              } else {
                datosTablaAux.push({ campo: campoVisual.campo, campoBd: this.datosTabla[i][j].key, value: this.datosTabla[i][j].value, visible: campoVisual.visible, esGestor: false });
              }
            }
          }
          objAdmTmp.esGestor = objAdmTmp.esGestor && statusTmp != 3 && statusTmp != 4;
          datosTablaAux.push(objAdmTmp);
          datosTablaAux2.push(datosTablaAux);
        }
        this.datosTabla = datosTablaAux2;
        for (let i = 0; i < this.datosTabla.length; i++) {

          if (typeof this.datosTabla[i][6].value === 'string') {
            this.datosTabla[i][6].value =
              this.datosTabla[i][6].value.split('T')[0];
          }

          if (typeof this.datosTabla[i][7].value === 'string') {
            this.datosTabla[i][7].value =
              this.datosTabla[i][7].value.split('T')[0];
          }

        }
        this.collectionSize = this.datosTabla.length;
      } catch (error) {
        swal({
          title: '¡Es posible que no tengas tickets!',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });

      }
    }

  }

  validaCampo(campoBd) {
    let obj = null;
    for (let i = 0; i < this.displayedColumnsV2.length; i++) {
      if (this.displayedColumnsV2[i].campoBd == campoBd) {
        obj = this.displayedColumnsV2[i];
      }
    }
    return obj;
  }



  valueTicket(evtn) {
    $('#modal-demo0').on('shown', function () {
      $("#modal-content").scrollTop(0);
    });

    //let idTicket = this.getCampo(evtn, 'Ticket');
    let idTicket = evtn[1].value;


    let settings = {
      "async": true,
      "crossDomain": true,
      "url": this.url + "/tickets/" + idTicket + "/detalle",
      "method": "GET",
      "headers": {}
    }

    $.ajax(settings).done((response) => {
      this.ticketsDescripcion = response.ticketsDescripcion[0];  // Tiene un nivel 0 la propiedad ticketsDescripcion
      this.ticketArchivos = response.ticketsArchivos;
      this.ticketEtapa = response.ticketsEtapa;
      if (this.ticketEtapa) {

        for (let i = 0; i < this.ticketEtapa.length; i++) {
          let fechaTmp: string = this.ticketEtapa[i].ticketEtapaFechaAdd;
          let arrayAux = fechaTmp.split("/");
          this.ticketEtapa[i].ticketEtapaFechaAdd = `${arrayAux[2]}-${arrayAux[0]}-${arrayAux[1]}`;
        }

        this.etapaStatusActual.nombreEtapa = this.ticketEtapa[this.ticketEtapa.length - 1].etapaDescripcion;
        this.etapaStatusActual.nombreStatus = this.ticketEtapa[this.ticketEtapa.length - 1].ticketEstatusDescripcion;

        let nombreStatus: string = this.etapaStatusActual.nombreStatus;

        if (nombreStatus.toLocaleUpperCase() == 'RECHAZADO' || nombreStatus.toLocaleUpperCase() == 'CERRADO') {
          this.tituloCerradoRechazado = "Observaciones:";
        } else {
          this.tituloCerradoRechazado = "Requerimientos:";
        }
      }
    }).fail((error) => { });
  }

  async valueTicketGestor(evtn) {
    $('#modal-demo1').on('shown', function () {
      $("#modal-content").scrollTop(0);
    });
    this.controlArchivo.nativeElement.value = '';
    this.controlArchivoGestor.nativeElement.value = '';

    const idTicket = evtn[1].value;
    this.idEtapaActual = evtn[6].value;
    this.idEstatusActual = evtn[9].value;
    this.idAsegurado = evtn[16].value;
    this.idEmpleadoTmp = evtn[17].value;
    this.nombreCliente = evtn[3].value;
    this.correoEmergencia = evtn[14].value;
    
    if (evtn[3].value){
      this.descripcionTicketRegistrada = evtn[3].value;
      }
    else{
      this.descripcionTicketRegistrada = "";
      }
    this.descripcionTicket = " ";

    this.empleados.forEach(element => {
      if (element.id === this.idEmpleadoTmp) {
        console.log("Empleados",element);
        this.correoEmpleado = element.correo;
      }
    });



    const settings = {
      "async": true,
      "crossDomain": true,
      "url": this.url + "/tickets/" + idTicket + "/detalle",
      "method": "GET",
      "headers": {}
    }

    try {
      const response = await this._ticketService.obtenerEtapasTickets(idTicket);

      this.etapasTicket = response.etapas.map((item: any) => ({
        id: item.ETAPA_ID,
        des: item.ETAPA_DESCRIPCION
      }));

      this.estatusGestor = response.estatus.map((item: any) => ({
        id: item.TicketEstatus_id,
        desc: item.TicketEstatus_Descripcion
      }));


      $.ajax(settings).done((response) => {
        this.ticketsDescripcion = response.ticketsDescripcion[0];  // Tiene un nivel 0 la propiedad ticketsDescripcion
        this.ticketArchivos = response.ticketsArchivos;
        this.ticketEtapa = response.ticketsEtapa;

        if (this.ticketEtapa) {
          for (let i = 0; i < this.ticketEtapa.length; i++) {
            let fechaTmp: string = this.ticketEtapa[i].ticketEtapaFechaAdd;
            let arrayAux = fechaTmp.split("/");
            this.ticketEtapa[i].ticketEtapaFechaAdd = `${arrayAux[2]}-${arrayAux[0]}-${arrayAux[1]}`
          }
          this.etapaStatusActual.nombreEtapa = this.ticketEtapa[this.ticketEtapa.length - 1].etapaDescripcion;
          this.etapaStatusActual.nombreStatus = this.ticketEtapa[this.ticketEtapa.length - 1].ticketEstatusDescripcion;
        }
      }).fail((error) => { });

    } catch (error) {

      swal({
        title: '¡Error al obtener las etapas!',
        type: 'info',
        confirmButtonText: 'Aceptar',
      });
    }

  }

  getArchivo($event, edRutaDocumento, edNombreDocumento) {
    let str = edRutaDocumento;
    str = str.replace(/\\/g, "/");

    edRutaDocumento = str
    const ext = edRutaDocumento.substr(edRutaDocumento.lastIndexOf('.') + 1)
    let strExtension = '';
    switch (ext) {
      case 'xml':
        strExtension = 'application/xml';
        break;
      case 'pdf':
        strExtension = 'application/pdf';
        break;
      // Se puede agregar un catalogó de extensiones
    }


    swal({
      title: 'Espere un momento...',
      html: '',
      allowOutsideClick: false,
      onOpen: () => {
        swal.showLoading();
        const settings = {
          "async": true,
          "crossDomain": true,
          "url": `${this.url}file/get-document?ruta=${edRutaDocumento}`,
          "method": "GET",
          "headers": {},
          xhrFields: {
            responseType: 'blob'
          },
        };

        $.ajax(settings).done((response) => {

          const blob = new Blob([response], { type: strExtension });
          const link = document.createElement('a');  //Crear un a=> href
          link.href = window.URL.createObjectURL(blob);
          link.download = edNombreDocumento;

          link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
          setTimeout(function () {
            window.URL.revokeObjectURL(window.URL.createObjectURL(blob));
          }, 100);
          swal({
            title: '¡Descargado!',
            html: '<small style="color: grey; text-align: justify;">Por favor revisa tu carpeta de descargas.</small>',
            type: 'success',
            confirmButtonText: 'Aceptar',
          });
        }).fail(function () {
          swal({
            title: '¡Archivo no encontrado!',
            html: `<small style="color: grey; text-align: justify;">Actualmente no se encuentra: <b>${edNombreDocumento}</b>.</small>`,
            type: 'info',
            confirmButtonText: 'Aceptar',
          });
        });
      },
    });
  }

  cleanFilters() {
    this.ticketMonitorForm.controls['fechaI'].patchValue('');
    this.ticketMonitorForm.controls['fechaF'].patchValue('');
    this.monitoreoTramite = "0";
    this.selectedValue = [{ id: 1, desc: 'Nuevo' }, { id: 2, desc: 'En Tramite' }]; // esto pre-selecciona los valores NUEVO y EN TRAMITE
    let solicitudesTmp = [];
    this.solicitudes = solicitudesTmp;
    this.datosTabla = null;
  }

  async guardarSeguimiento(observacionesElement: HTMLInputElement) {
    this.idEtapaActual = this.idEtapaElegida;
    this.idEstatusActual = this.idEstatusElegida;

    if (this.selectedValueEstatus.length == 0 && this.etapasTicketValue.length == 0) {
      this.mostrarErrorSeguimiento = true;
    } else {
      try {
        if (this.idEstatusActual == 3 || this.idEstatusActual == 4) {
          const tipoNotificacion = this.idEstatusActual == 3 ? 44 : 46;
          // CAT: Carga la plantilla del estatus antes de registrar y notificar el seguimiento.
          const configuracion = await this.getConfiguracionNotificacionEmpresa(tipoNotificacion, this.identityAdmin.id);
          if (!configuracion) {
            return;
          }
        }
        const datosResponsable = await this._ticketService.obtenerResponsableEtapa(this.ticketsDescripcion.ticketId);
        if (datosResponsable)
          if (datosResponsable[0].length > 0)
            if (datosResponsable[0][0].Etapa_ResponsableCorreo)
              this.to += datosResponsable[0][0].Etapa_ResponsableCorreo + ' ,';
        try {
          const result = await this._ticketService.registraSeguimiento(this.ticketsDescripcion.ticketId, this.idEtapaElegida, this.idEstatusElegida, observacionesElement.value, this.idAdm);

          if ((this.idEstatusActual == 3 || this.idEstatusActual == 4) && this.to) {
            await this.obtenerPlantillaTicketSeguimiento(this.ticketsDescripcion.ticketId, result[2][0].Segmento_descripcion + ' - ' + result[2][0].Solicitud_Descripcion, "", observacionesElement.value);
          }

          if (this.archivosFisicos.length) {
            let auxNumArchivos = Array.from(this.archivosFisicos).length;
            Array.from(this.archivosFisicos).map((val) => {
              const form = new FormData();  // LSData es el formData
              form.append("file", val); // this.LSdata.append("file", inputEl.files.item(0));

              const settings = {
                "async": true,
                "crossDomain": true,
                "url": this.url + "file/upload?directorio=" + this.rutaArchivos + "&nombre="
                  + `${this.idEmpleadoTmp}_${this.ticketsDescripcion.ticketId}_${val['name']
                    .substring(0, val['name'].indexOf("."))}`,
                "method": "POST",
                "headers": {
                  "authorization": this.token
                },
                "processData": false,
                "contentType": false,
                "mimeType": "multipart/form-data",
                "data": form
              }

              $.ajax(settings).done((response) => {
                this.contador++;
                this.insertarArchivFisicoBDSeguimiento(this.ticketsDescripcion.ticketId, this.rutaArchivos, val.name, this.idEmpleadoTmp);

              }).fail((error) => {
                swal({
                  title: '¡Atención!',
                  type: 'info',
                  html: '<small style="color: grey; text-align: justify;">' +
                    'No fue posible agregar los archivos, favor de contactar a su administrador</small>',
                  confirmButtonText: 'Aceptar',
                });
              });
            });
          }
          swal({
            title: '¡Operación Exitosa!',
            type: 'success',
            html: '<small style="color: grey; text-align: justify;">'
              + 'El ticket ha sido actualizado con éxito' + '</b></small>',
            confirmButtonText: 'Aceptar',
          }).then((result) => {
            this.limpiarControlesSeguimiento();
            observacionesElement.value = '';
            $('#modal-demo1').modal('toggle');
            this.onSubmitMonitor();
            this.evnDel();
          });
        } catch (error) {
          swal({
            title: '¡Atención!',
            type: 'info',
            html: '<small style="color: grey; text-align: justify;">' +
              'No fue posible registrar el ticket, favor de contactar a su administrador</small>',
            confirmButtonText: 'Aceptar',
          });

        }
      } catch (error) {

      }
    }
  }

  async insertarArchivFisicoBDSeguimiento(ticketId, directorio, nombre, idAsegurado) {
    try {
      await this._ticketService.insertaTicketArchivo(ticketId, `${idAsegurado}_${ticketId}_${nombre}`, directorio, idAsegurado);
    } catch (error) {
    }
  }


  generarReporteExcel() {

    const datosReporteAux = this.datosTabla.map((fila: any[]) => [

      this.getCampo(fila, 'Estatus')?.value,
      this.getCampo(fila, 'Tipo de solicitud')?.value,
      this.getCampo(fila, 'Ticket')?.value,
      this.getCampo(fila, 'Certificado')?.value,
      this.getCampo(fila, 'Nombre')?.value,
      this.getCampo(fila, 'Contacto de Emergencia')?.value,
      this.getCampo(fila, 'Teléfono1')?.value,
      this.getCampo(fila, 'Teléfono2')?.value,
      this.getCampo(fila, 'Hospital')?.value,
      this.getCampo(fila, 'Correo')?.value,
      '●', 
      this.getCampo(fila, 'Etapa')?.value,
      this.getCampo(fila, 'Fecha solicitud')?.value
        ? this.getCampo(fila, 'Fecha solicitud')?.value.split('T')[0]
        : '',

      this.getCampo(fila, 'Fecha respuesta')?.value
        ? this.getCampo(fila, 'Fecha respuesta')?.value.split('T')[0]
        : '',

      this.getCampo(fila, 'Observaciones')?.value

    ]);

    const encabezadosFinal = [
      "Estatus",
      "Tipo de solicitud",
      "Ticket",
      "Certificado",
      "Nombre",
      "Contacto de Emergencia",
      "Teléfono1",
      "Teléfono2",
      "Hospital",
      "Correo",
      "Semáforo",
      "Etapa",
      "Fecha solicitud",
      "Fecha respuesta",
      "Observaciones"
    ];

    this._excelService.crearExcelBitacoraNavegacion(
      encabezadosFinal,
      datosReporteAux,
      [],
      [],
      'Tickets',
      true,
      false
    );
  }

  cambiarEtapa() {
    if (this.etapasTicketValue.length > 0) {
      if (this.etapasTicketValue[0].id != 0) {
        this.selectedValueEstatus = [];
        this.habilitarStatusDisable = 'none';
      } else {
        this.habilitarStatusDisable = 'initial';
      }
      this.idEstatusElegida = this.idEstatusActual;
      this.idEtapaElegida = this.etapasTicketValue[0].id;
    }
  }

  cambiarStatus() {
    if (this.selectedValueEstatus.length > 0) {
      if (this.selectedValueEstatus[0].id == 3) {
        this.descripcionStatus = "Rechazado";
      }
      if (this.selectedValueEstatus[0].id == 4) {
        this.descripcionStatus = "Cerrado";
      }


      if (this.selectedValueEstatus[0].id != 0) {
        this.etapasTicketValue = [];
        this.habilitarEtapaDisable = 'none';
      } else {
        this.habilitarEtapaDisable = 'initial';
      }

      this.idEtapaElegida = this.idEtapaActual;
      this.idEstatusElegida = this.selectedValueEstatus[0].id;
    }
  }


  async obtenerCorreosSeguimientoGestor(tipoNoticacion) {
    try {
      const result = await this._ticketService.getConfiguracionNotificacion(this.identityAdmin.idEmpresa, tipoNoticacion, this.identityAdmin.id);
      this.correoAdmGestor = result['admCorreoElectronico'];
      this.to = this.correoAdmGestor;
    } catch (error) {

    }

  }

  async obtenerPlantillaTicketSeguimiento(idTicket, Segmento, estatus, Observacion?) {
    try {
      if (!this.plantillaTipoNotificaciones) {
        return;
      }
      const resultPlantilla = this.personalizarPlantillaTicket(
        this.plantillaTipoNotificaciones,
        idTicket,
        Segmento,
        this.descripcionStatus,
        this.nombreCliente,
        Observacion
      );

           this.cc=  this.correoEmergencia + ","+this.correoEmpleado;

          console.log("datos de correo",this.to);
          console.log("datos de correo",this.cc);

      if (this.to) {
        await this.enviarNotificacion(this.sujeto, resultPlantilla, this.to, this.cc, this.bcc, "");
      }
    } catch (error) {

    }
  }

  private personalizarPlantillaTicket(plantilla, idTicket, segmento, estatus, cliente, motivo = '') {
    // CAT: Sustituye las variables admitidas por las plantillas dinamicas de tickets.
    return plantilla
      .replace(/#(?:Ticket_id|IdTicket)/g, idTicket)
      .replace(/#SegmentoTipo/g, segmento)
      .replace(/#Estatus/g, estatus)
      .replace(/#Cliente/g, cliente || '')
      .replace(/#Url/g, window.location.href)
      .replace(/#Motivo/g, motivo || '');
  }

  limpiarControlesSeguimiento() {
    this.etapasTicketValue = [];
    this.selectedValueEstatus = [];
  }

  async getConfiguracionNotificacionCerrado(idNotificacion) {
    try {
      const result = await this._ticketService.getConfiguracionNotificacion(this.identityAdmin.idEmpresa, idNotificacion, this.identityAdmin.id)
      this.obtenerCorreosGrupos(result['correosGrupo']);
    } catch (error) { }
  }

  establecerCorreo() {
    this.correoIntroducido = this.correoIntroducidoAux;
  }

  onObservacionesSolicitud(event) {
    if (this.identityAdmin.idEmpresa == 371)
      this.validacionesCamposUlsa();


    if (this.empleadoSelecto == 0 || this.ticketSolicitudTramite == '0' || this.ticketSolicitudSolicitud == '0' || this.ticketSolicitudSolicitud == undefined || this.ticketSolicitudObservaciones == "" || this.ticketSolicitudObservaciones == undefined) {
      this.validacionesOk = true;
    } else {
      this.validacionesOk = false;
    }
  }

  validacionesCamposUlsa(event?) {
    if (this.validacionesOk || (
      this.ContactoA == undefined || this.ContactoA == ""
      || this.CorreoA == undefined || this.CorreoA == ""
      || this.Telefono1A == undefined || this.Telefono1A == ""
      || this.Telefono2A == undefined || this.Telefono2A == ""
      || this.HospitalA == undefined || this.HospitalA == ""
    )) {
      this.validacionesOkUlsa = true;
    } else {
      this.validacionesOkUlsa = false;
    }
  }

  getRangeLabel = function (page, pageSize, length) {
    const of = this.translate ? this.translate.instant('paginator.of') : 'de';
    if (length === 0 || pageSize === 0) {
      return '0 ' + of + ' ' + length;
    }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    const endIndex = startIndex < length ?
      Math.min(startIndex + pageSize, length) :
      startIndex + pageSize;
    return startIndex + 1 + ' - ' + endIndex + ' ' + of + ' ' + length;
  };

  valuesToArray(obj) {
    const objeto = [];
    Object.keys(obj).map(
      (key) => {
        objeto.push({
          value: obj[key] != 'NULL' ? obj[key] : '',
          key: key
        });
      }
    );
    return objeto;
  }

  esGestor1(fila: any[]): boolean {
    return fila?.some(d => d.campoBd === 'administrador' && d.esGestor);
  }

  noEsGestor2(fila: any[]): boolean {
    return fila?.some(d => d.campoBd === 'administrador' && !d.esGestor);
  }

  getCampo(fila: any[], nombre: string): any {
    return fila?.find(d => d.campo === nombre && d.visible);
  }


get etapasDisabled(): boolean {
  return !this.etapasTicket?.length;
}


}


