param(
    [string]$RepoBac = 'C:\repo\helpsoso\bac'
)

Set-Location -LiteralPath $RepoBac

if (-not (Test-Path -LiteralPath '.git')) {
    throw "Esta carpeta no es un clon Git: $RepoBac"
}

$BacFiles = @(
    'src/main/java/com/lockton/WSBeFlex/DAO/JDBCFfEmpresa.java'
)

git status --short -- $BacFiles
git add -- $BacFiles
git diff --cached --check

if ($LASTEXITCODE -ne 0) {
    throw 'Git detecto errores en los archivos preparados.'
}

git commit -m "Manejo seguro de configuracion de tickets"

$Branch = git branch --show-current
if ([string]::IsNullOrWhiteSpace($Branch)) {
    throw 'No fue posible identificar la rama actual.'
}

git push -u origin $Branch
