# Plantillas dinamicas para tickets

## Contenido

- `front/`: dos componentes Angular modificados.
- `bac/`: un DAO Java modificado; no se agregaron clases Java.
- `BD/`: `ALTER PROCEDURE` y dos consultas de validacion de solo lectura.
- `COMANDOS_GIT/`: scripts separados para preparar, confirmar y publicar cada repositorio.

## Orden recomendado

1. Ejecutar el archivo de `BD` en la base correspondiente.
2. Copiar el contenido de `bac` sobre la raiz del repositorio BAC y desplegarlo.
3. Copiar el contenido de `front` sobre la raiz del repositorio Angular y desplegarlo.

Los scripts Git toman la rama actual mediante `git branch --show-current` y ejecutan `git push -u origin $Branch`.

## Validaciones realizadas

- El procedimiento devolvio las plantillas correctas para las empresas 371, 948 y 949 y los tipos 43, 44 y 46.
- Las plantillas 81, 82, 83, 89, 90 y 91 quedaron sin marcadores pendientes despues de sustituir los datos.
- TypeScript: `tsc -p src/tsconfig.app.json --noEmit`, codigo de salida 0.
- Java: compilacion aislada de `JDBCFfEmpresa.java`, codigo de salida 0.

La compilacion Maven completa requiere los WSDL internos y VPN. El empaquetado Angular completo con Node 24 requiere `NODE_OPTIONS=--openssl-legacy-provider`; el compilador TypeScript si concluyo correctamente.
