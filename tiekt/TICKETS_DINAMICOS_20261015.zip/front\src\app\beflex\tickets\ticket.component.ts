import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import swal from 'sweetalert2';
import {EmpleadoService} from '../../services/empleado.service';
import {EmpresaComboService} from '../../services/empresas.service';
import {FormGroup, FormControl} from '@angular/forms';
import {TicketService} from '../../services/ticket.service';
import {GLOBAL} from '../../services/global';
import {Sesion} from '../../services/sesion.service';
import {Inject} from '@angular/core';
import {DOCUMENT} from '@angular/common';
import {Bitacora} from '../../services/bitacora.service';
import {DomSanitizer, SafeHtml, SafeResourceUrl} from '@angular/platform-browser';
import {MenusService} from '../../services/menus.service';
import { AccesosService } from '../../services/accesos/accesos.service';

declare var $: any;

@Component({
  selector: 'tickets',
  templateUrl: './ticket.component.html',
  styleUrls: ['./ticket.component.css'],
  providers: [TicketService, EmpleadoService, Sesion, Bitacora]
})
export class TicketsComponent implements OnInit {
  public title: string;
  public solicitud = '0';
  public monitoreo = '0';
  public seleccion;
  public uploadedFiles: any[] = [];   // archivos que se muestran en la lista del Input
  public archivosFisicos: any[] = []; // Archivos fisicos que van al Storage
  public btnLimpiar: boolean;
  public segmentos;
  public solicitudes;
  public insumos;
  public url;
  private idCorporativo = this._empleadoService.getIdentity().idCorporativo;
  private idEmpresa = this._empleadoService.getIdentity().idEmpresa;
  private idEmpleado = this._empleadoService.getIdentity().id;
  public auxNombreCompleto;
  private rutaArchivos = `/DocumentoEmpresa/${this.idEmpresa}/Tickets/`;  // idEmpleado_idTicket_NombreArchivo.pdf
  private contador;
  private to;
  private cc;
  private bcc;
  private adminCorreos;
  private identity = this._empleadoService.getIdentity();
  private token;
  private cliente;
  public verificarCorreoSolicitud;
  public url3;
  private idPagina=0;
  private paginaActual;
  private ipPrivada;
  public estilo;
  public wizard;
  public trustUrl2: SafeResourceUrl;
  public auxTamañoArchivo = 0;
  public Comment;
  public Subject;
  public Empleado;
  public idSolicitud;
  public idSegmento;

  public iconoAyuda: number = 0;
  private idMenu=465;
  public textAyuda: string;
  public files: File[] = [];

  public profileForm = new FormGroup({
    segmento: new FormControl(''),
    solicitud: new FormControl(''),
    requerimientos: new FormControl(''),
    archivos: new FormControl(''),
    correo: new FormControl(''),
    contactoEmergencia: new FormControl(''),
    telefono1: new FormControl(''),
    telefono2: new FormControl(''),
    hospitalEmergencia: new FormControl('')
  });
  public CE: any;
  public T1: any;
  public T2: any;
  public HE: any;
  public mail: any;
  public plantillaTipoNotificaciones: any;
  public sujeto: any = '';
@ViewChild('fileInput') fileInput!: ElementRef;
  constructor(
    private sanitizer: DomSanitizer,
    private _router: Router,
    private _empleadoService: EmpleadoService,
    private _ticketService: TicketService,
    private _sesion: Sesion,
    private _bitacora: Bitacora,
    private _empresaService: EmpresaComboService,
    private _menuService: MenusService,
    private _accesos: AccesosService,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.title = 'Tickets';
    this.url = GLOBAL.url;
    this.wizard = GLOBAL.wizard;

    if (this.identity) {
      if (!this.identity.cambio && this.identity.reseteo) {
        this._router.navigate(['/pages/home']);
      } else if (this.identity.cambio && this.identity.reseteo) {
        this._router.navigate(['/pages/home']);
      }
    }
    this.url3 = this.wizard + 'Stilos/General/' + this.identity.idEmpresa + '/Cla' + this.identity.idEmpresa + '.css';
    this.trustUrl2 = this.sanitizer.bypassSecurityTrustResourceUrl(this.url3);
    this.estilo = true;
  }

  async obtenerSegmentos() {
    try {
      const result = await this._ticketService.obtenerTramiteSegmento(this.idCorporativo, this.idEmpresa);
      this.segmentos = result;
    } catch (error) {
    }
  }

  async onChangeSegmento(event) {
    var path = event.path || (event.composedPath && event.composedPath());
    if (path) {
      let idSolicitud = event.target.value;
      try {
        const response = await this._ticketService.obtenerSolicitud(idSolicitud);
        this.solicitudes = response;
        var solicitudExiste = $('#solicitud').val();
        if (solicitudExiste || this.solicitudes[0].solicitudId) {
          try {
            const response = await this._ticketService.obtenerInsumos(this.solicitudes[0].solicitudId);
            this.insumos = response;
          } catch (error) {
          }
        }
      } catch (error) {
      }
    }
  }

  async onChangeSolicitud(event, solicitudes) {
    var path = event.path || (event.composedPath && event.composedPath());
    if (path) {
      let idSolicitud = event.target.value;
      try {
        const response = await this._ticketService.obtenerInsumos(idSolicitud);
        this.insumos = response;
      } catch (error) {
      }
      solicitudes.filter((e) => {
        if (e.solicitudId == idSolicitud) {
          return this.verificarCorreoSolicitud = e.solicitudMail;
        }
      });
    }
  }



  handleUpload(event: any) {

    this.btnLimpiar = false;

    this.files = Array.from(event.target.files || []);
    let contadorArchivos = 0;

    for (const file of this.files) {

      const nombreArchivo = file.name;
      const partes = nombreArchivo.split('.');
      const extension = partes.pop()?.toLowerCase() || '';
      const nombre = partes.join('.');

      // Validar nombre
      const regexpNombre = /^[A-Za-z0-9]+$/;

      if (!regexpNombre.test(nombre)) {

        swal({
          title: '¡Atención!',
          type: 'info',
          html:
            '<small style="color: grey; text-align: justify;">' +
            `El archivo <b>${nombreArchivo}</b> no es válido.<br><br>` +
            'El nombre solo puede contener letras y números antes de la extensión.<br><br>' +
            '<b>Ejemplo correcto: Documento123.pdf</b>' +
            '</small>',
          confirmButtonText: 'Aceptar'
        });

        continue;
      }

      // Validar extensión
      const extensionesPermitidas = [
        'pdf',
        'xml',
        'xlsx',
        'xls',
        'doc',
        'docx'
      ];

      if (!extensionesPermitidas.includes(extension)) {

        swal({
          title: '¡Atención!',
          type: 'info',
          html:
            '<small style="color: grey; text-align: justify;">' +
            'El archivo <b>' + nombreArchivo + '</b> no cumple con los formatos aceptados ' +
            '<b>(PDF, XML, XLS, XLSX, DOC, DOCX)</b>' +
            '</small>',
          confirmButtonText: 'Aceptar'
        });

        continue;
      }

      // Validar longitud
      if (nombre.length > 50) {

        swal({
          title: '¡Atención!',
          type: 'info',
          html:
            '<small style="color: grey; text-align: justify;">' +
            'El nombre del archivo no puede tener más de <b>50 caracteres</b>.' +
            '</small>',
          confirmButtonText: 'Aceptar'
        });

        continue;
      }

      // Evitar archivos duplicados
      const existe = this.archivosFisicos.some(
        x => x.name.toLowerCase() === file.name.toLowerCase()
      );

      if (existe) {

        swal({
          title: '¡Atención!',
          type: 'info',
          html:
            '<small style="color: grey; text-align: justify;">' +
            `El archivo <b>${file.name}</b> ya fue seleccionado.` +
            '</small>',
          confirmButtonText: 'Aceptar'
        });

        continue;
      }

      // Recalcular el tamaño real de los archivos actualmente seleccionados
      this.auxTamañoArchivo = this.archivosFisicos.reduce(
        (total, archivo) => total + archivo.size,
        0
      );

      // Validar tamaño total
      const nuevoTamaño = this.auxTamañoArchivo + file.size;

      if (nuevoTamaño > 4000000) {

        if (contadorArchivos === 0) {

          swal({
            title: '¡Atención!',
            type: 'info',
            html:
              '<small style="color: grey; text-align: justify;">' +
              '¡El peso total de los archivos seleccionados es mayor a <b>4 MB</b>!' +
              '</small>',
            confirmButtonText: 'Aceptar'
          });

          contadorArchivos++;
        }

        continue;
      }

      // Agregar archivo
      this.auxTamañoArchivo = nuevoTamaño;

      this.uploadedFiles.push(file);
      this.archivosFisicos.push(file);
    }

    this.profileForm.get('archivos').setValue('');

    this.btnLimpiar = this.archivosFisicos.length > 0;
  }



  async crearTicketZendesk(ticketId) {
    var token = '';
    try {
      const resultAuth: any = await this._ticketService.authAPI_Beflex();
      token = resultAuth.data.token;
      try {
        const resValidacion: any = await this._empleadoService.getParametroCorporativo(this.idEmpresa, 236);
        if (resValidacion.valor == '1') {
          //#region Datos Zendesk Ticket
          const empleado = this.auxNombreCompleto;
          const nombreEmpelado = empleado.EMNombre1 + ' ' + empleado.EMNombre2 + ' ' + empleado.EMApellidoPaterno + ' ' + empleado.EMApellidoMaterno;
          ;
          this.Empleado = 'Número Empleado: ' + empleado.EMNumeroEmpleado + '\nNombre Empleado: ' + nombreEmpelado;
          try {
            const response: any = await this._empresaService.getInfoEmpresa(empleado.EMIdEmpresa);
            let listTramite = this.segmentos;
            const segmento = listTramite.find(e => e.segmentoId === this.idSegmento);
            this.Comment = 'Ticket Beflex: ' + ticketId + ' \nTrámite: ' + segmento.segmentoDescripcion + '\n';

            let listSolicitud = this.solicitudes;
            const solicitud = listSolicitud.find(e => e.solicitudId === this.idSolicitud);
            this.Comment += 'Solicitud: ' + solicitud.solicitudDescripcion + '\n' + this.Empleado + '\nEmpresa: ' + response.EMNombre;
            this.Subject = solicitud.solicitudDescripcion;

            var objZendesk = {subject: this.Subject, comment: this.Comment, requester: nombreEmpelado, Token: token};


            try {
              const resultZendesk: any = await this._ticketService.crearTicketZendesk(objZendesk);
              if (resultZendesk.exito) {
                var TicketBeflex = {IdTicketBeflex: ticketId, IdTicketZendesk: resultZendesk.data};
                try {
                  await this._ticketService.actualizarTicketBelfex(TicketBeflex, token);
                } catch (error) {
                }
              }
            } catch (error) {

            }
          } catch (error) {
          }
        }
      } catch (error) {
      }
    } catch (error) {
    }
  }

async onSubmit() {
  let idSolicitud = this.profileForm.get('solicitud').value;
  let requerimientos = this.profileForm.get('requerimientos').value;

  this.mail = this.profileForm.get('correo').value || '';

  // contacto emergencia
  this.CE = this.profileForm.get('contactoEmergencia').value;
  this.T1 = this.profileForm.get('telefono1').value;
  this.T2 = this.profileForm.get('telefono2').value;
  this.HE = this.profileForm.get('hospitalEmergencia').value;

  this.idSegmento = parseInt(this.profileForm.get('segmento').value);
  this.idSolicitud = parseInt(idSolicitud);

  this.contador = 0;

  // VALIDACIÓN NUEVA
  
    const confirmacion = await swal({
      title: '¡Atención!',
      type: 'warning',
      html:
        '<small style="color: grey; text-align: justify;">' +
        '¿Está seguro que están todos los archivos adjuntos?</small>',
      confirmButtonText: 'Aceptar',
      cancelButtonText: 'Cancelar',
      showCancelButton: true,
      allowOutsideClick: false,
      allowEscapeKey: false,
      allowEnterKey: false,
    });

    // Si cancela → salir y dejar que cargue archivos
    if (!confirmacion.value) {
      return;
    }
  

  // SI LLEGA AQUÍ → continúa flujo normal
  if (this.archivosFisicos.length) {

    swal({
      title: 'Espere un momento...',
      html: '',
      allowOutsideClick: false,
      onOpen: async () => {

        swal.showLoading();

        try {

          const result = await this._ticketService.insertarNuevoTicket(
            this.idEmpleado,
            idSolicitud,
            requerimientos,
            this.idEmpleado,
            this.mail,
            this.CE,
            this.T1,
            this.T2,
            this.HE
          );

          await this.obtenerPlantillaTicket(
            result[0].ticketId,
            result[0].segmentoDescripcion + ' - ' + result[0].solicitudDescripcion,
            ''
          );

          this.crearTicketZendesk(result[0].ticketId);

          let auxNumArchivos = this.archivosFisicos.length;

          Array.from(this.archivosFisicos).map((val) => {

            const form = new FormData();
            form.append('file', val);

            const settings = {
              async: true,
              crossDomain: true,
              url:
                this.url +
                'file/upload?directorio=' +
                this.rutaArchivos +
                '&nombre=' +
                `${this.idEmpleado}_${result[0].ticketId}_${val.name.substring(0, val.name.indexOf('.'))}`,
              method: 'POST',
              headers: {
                authorization: this.token
              },
              processData: false,
              contentType: false,
              mimeType: 'multipart/form-data',
              data: form
            };

            $.ajax(settings)
              .done(() => {

                this.contador++;

                this.insertarArchivFisicoBD(
                  result[0].ticketId,
                  this.rutaArchivos,
                  val.name
                );

                if (this.contador === auxNumArchivos) {

                  swal({
                    title: '¡Operación Exitosa!',
                    type: 'success',
                    html:
                      '<small style="color: grey; text-align: justify;">' +
                      'Tu solicitud será atendida con el ticket: <b>' +
                      result[0].ticketId +
                      '</b></small>',
                    confirmButtonText: 'Aceptar',
                  }).then(() => {
                    this.actualizarRuta();
                  });

                }

              })
              .fail(() => {

                swal({
                  title: '¡Atención!',
                  type: 'info',
                  html:
                    '<small style="color: grey; text-align: justify;">' +
                    'No fue posible agregar los archivos, favor de contactar a su administrador</small>',
                  confirmButtonText: 'Aceptar',
                });

              });

          });

        } catch (error) {

          swal({
            title: '¡Atención!',
            type: 'info',
            html:
              '<small style="color: grey; text-align: justify;">' +
              'El nombre de cada archivo no debe contener caracteres especiales como acentos o espacios en blanco.</small>',
            confirmButtonText: 'Aceptar',
          });

        }
      }
    });

  } else {

    try {

      const result = await this._ticketService.insertarNuevoTicket(
        this.idEmpleado,
        idSolicitud,
        requerimientos,
        this.idEmpleado,
        this.mail,
        this.CE,
        this.T1,
        this.T2,
        this.HE
      );

      await this.obtenerPlantillaTicket(
        result[0].ticketId,
        result[0].segmentoDescripcion + ' - ' + result[0].solicitudDescripcion,
        ''
      );

      this.crearTicketZendesk(result[0].ticketId);

      swal({
        title: '¡Operación Exitosa!',
        type: 'success',
        html:
          '<small style="color: grey; text-align: justify;">' +
          'Tu solicitud será atendida con el ticket: <b>' +
          result[0].ticketId +
          '</b></small>',
        confirmButtonText: 'Aceptar',
      }).then(() => {
        this.actualizarRuta();
      });

    } catch (error) {
      console.log('No podemos guardar los datos', error);
    }

  }
}

  async insertarArchivFisicoBD(ticketId, directorio, nombre) {
    try {
      await this._ticketService.insertaTicketArchivo(ticketId, `${this.idEmpleado}_${ticketId}_${nombre}`, directorio, this.idEmpleado);
    } catch (error) {

    }
  }

  async obtenerPlantillaTicket(idTicket, Segmento, estatus) {
    try {
      // CAT: Obtiene la plantilla 43 por empresa para eliminar el ID fijo del correo de alta.
      const configuracion = await this.getConfiguracionNotificacionEmpresa();
      if (!configuracion || !configuracion['plantilla'] || !configuracion['plantilla'][0]
        || !configuracion['plantilla'][0].contenido) {
        throw new Error('No existe una plantilla activa para la notificación de generación de ticket.');
      }

      const plantilla = configuracion['plantilla'][0];
      this.plantillaTipoNotificaciones = plantilla.contenido;
      this.sujeto = plantilla.sujeto;
      this.to = this.identity.mfaSettings['email'];
      if (this.mail) {
        this.cc += this.mail.replace(/,/g, '');
      }

      const resultPlantilla = this.personalizarPlantillaTicket(
        this.plantillaTipoNotificaciones,
        idTicket,
        Segmento,
        'Nuevo',
        this.cliente
      );

      await this.enviarNotificacion(this.sujeto, resultPlantilla, this.to.replace(/,/g, ''), this.cc, '', '');
    } catch (error) {
      console.log("Error obteniendo correo",error);
    }
  }

  async getConfiguracionNotificacionEmpresa() {
    try {
      this.to = '';
      this.cc = '';
      this.bcc = '';
      const result = await this._ticketService.getConfiguracionNotificacion(this.idEmpresa, 43, this.idEmpleado);
      const informacionEmpleado = result['informacionEmpleado'];
      const nombreCompleto = informacionEmpleado && informacionEmpleado.length > 0
        ? informacionEmpleado[0].nombreCompleto
        : this.cliente;
      this.obtenerCorreosGrupos(result['correosGrupo'], nombreCompleto);
      return result;
    } catch (error) {
      console.log('Error obteniendo la configuración de notificación', error);
      return null;
    }
  }

  private personalizarPlantillaTicket(plantilla, idTicket, segmento, estatus, cliente, motivo = '') {
    // CAT: Sustituye las variables admitidas por las plantillas dinamicas de tickets.
    return plantilla
      .replace(/#(?:Ticket_id|IdTicket)/g, idTicket)
      .replace(/#SegmentoTipo/g, segmento)
      .replace(/#Estatus/g, estatus)
      .replace(/#Cliente/g, cliente || '')
      .replace(/#Url/g, window.location.href)
      .replace(/#Motivo/g, motivo || '');
  }

  obtenerCorreosGrupos(data, cliente) {
    this.adminCorreos = data;
    this.cliente = cliente;
    if (this.adminCorreos) {
      this.adminCorreos.map((r) => {
        const ADMIN_CORREOS = r['adCorreoElectronico'];
        const ADMIN_CC = r['gcCorreoCopia'];
        const ADMIN_C_OCULTA = r['gcCorreoCopiaOculta'];
        if (this.to != null) {
          this.to = this.to.replace(/ /g, '');
          if (ADMIN_CC == true && ADMIN_CC != undefined) {
            this.cc += ADMIN_CORREOS + ',';
            this.cc = this.cc.replace(/ /g, '');
            this.cc = this.cc.replace(/undefined/g, '');
          }
          if (ADMIN_C_OCULTA == true && ADMIN_C_OCULTA != undefined) {
            this.bcc += ADMIN_CORREOS + ',';
            this.bcc = this.bcc.replace(/ /g, '');
          }

        } else {
          this.to = ' ';
          if (ADMIN_CC == true) {
            this.to += ADMIN_CORREOS + ',';
          }
        }
      });
    }
  }

  async enviarNotificacion(sujeto, plantilla, to, cc, bcc, txt) {
    try {
      await this._empleadoService.sendMailUnificado(to, cc, bcc, sujeto, plantilla, txt, '', '', '', 21, this._empleadoService.getToken());
    } catch (error) {
    }
  }

  evnDel() {
    this.btnLimpiar = false;
    this.profileForm.get('archivos').setValue('');
    this.files = [];
    this.archivosFisicos= [];
    return this.uploadedFiles = [];
  }

  async getDatosEmpleado() {
    try {
      const res: any = await this._empleadoService.getAllEmpleado(this.idEmpleado, this._empleadoService.getToken());
      let datosEmpleadoTodos = res;
      this.auxNombreCompleto = datosEmpleadoTodos;
      if (datosEmpleadoTodos.EMNombre1 == 'NULL') {
        this.auxNombreCompleto.EMNombre1 = ' ';
      } else if (datosEmpleadoTodos.EMNombre2 == 'NULL') {
        this.auxNombreCompleto.EMNombre2 = ' ';
      } else if (datosEmpleadoTodos.EMApellidoPaterno == 'NULL') {
        this.auxNombreCompleto.EMApellidoPaterno = ' ';
      } else if (datosEmpleadoTodos.EMApellidoMaterno == 'NULL') {
        this.auxNombreCompleto.EMApellidoMaterno = ' ';
      }
    } catch (error) {
    }
  }

  async comprobarSesion() {
    try {
      const response = await this._sesion.comprobarSession(this.token);
      var message = response;
      if (this.identity) {
        this.paginaActual = this.document.location.href;
        let myIP = localStorage.getItem('myIP');
        if (!myIP) {
          myIP = '0.0.0.0';
        }
        this.ipPrivada = myIP;
        var parametroBitacora = {
          'idPagina': this.idPagina,
          'id': this.identity.id,
          'ipPrivada': encodeURIComponent(this.ipPrivada),
          'url': encodeURIComponent(this.paginaActual),
          'idEmpresa': this.identity.idEmpresa,
          idMenu: 465
        };
        await this._bitacora.registrarBitacoraPorMenu(parametroBitacora);
      }
    } catch (error) {
      if (error == 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión de nuevo.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      } else if (error.statusText == 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión de nuevo.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      } else {
        swal({
          title: '¡Error de conexión!',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
      }
    }
  }

  logout() {
    this._empleadoService.logout();
  }  


  limpiarCampos() {
    this.profileForm.reset();

    this.insumos = [];
    this.uploadedFiles = [];

    this.fileInput.nativeElement.value = '';

    this.btnLimpiar = false;
    
  }
  versolicitud(opcion: any) {
    if (this.solicitud == '1') {
      this.solicitud = '0';
    } else {
      this.solicitud = '1';
    }
  }

  vermonitoreo(opcion: any) {
    if (this.monitoreo == '1') {
      this.monitoreo = '0';
    } else {
      this.monitoreo = '1';
    }
  }
  
  private async compruebaAcceso(){
    var datoAcceso = this._accesos.getDatosAcceso('/tickets');
    if(datoAcceso === null){
      swal({
        title: '¡Atención!',
        html:
          '<small style="color: grey; text-align: justify;">No tienes permisos para acceder a ésta página.</small>',
        type: 'warning',
        confirmButtonText: 'Aceptar'
      });
      this._router.navigate(['/pages/home']);
    }else{
      this.idMenu = 465;
      if(datoAcceso.idPagina)
        this.idPagina = datoAcceso.idPagina;
      else{
        const response: any = await this._menuService.getMenuById(this.idMenu);
        if(response)
          this.idPagina = response.meIdPagina;
      }
      this.buscaAyuda();  
    }    
  }

  async buscaAyuda() {
    try {
      const response: any = await this._menuService.getAyudaEmpresaId(this.identity.idEmpresa, this.idPagina);
      this.iconoAyuda = 1;
      const [ textoayuda ] = response;
      this.textAyuda = textoayuda.paTextoAyuda;
    } catch (error) {
      this.iconoAyuda = 0;
    }
  }

  ngOnInit() {
    this.token = this._empleadoService.getToken();
    this.comprobarSesion();
    this.compruebaAcceso();
    this.obtenerSegmentos();
    this.limpiarCampos();
    this.getDatosEmpleado();    
  }
 
  async actualizarRuta() {
  this._router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
  this._router.navigate(['/pages/tickets']);
});  }


}
