USE [FlexiForbesv2];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=917,
        @IdVigencia int=4251,
        @IdSolTipo int=1,
        @Desde date=DATEFROMPARTS(YEAR(GETDATE()),MONTH(GETDATE()),1),
        @Hasta date=EOMONTH(GETDATE()),
        @ForzarRecarga bit=0;

IF OBJECT_ID(N'dbo.PrecargaUniversoCobranzaVigencia_BF3_Cache',N'P') IS NULL
    THROW 55310,'Primero instale 01_HOMOLOGAR_COBRANZA_B3_CON_B2_CACHE.sql.',1;

DECLARE @Perfiles dbo.ListInt;

INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT P.PEIdPerfil
FROM dbo.ff_Perfil P WITH(NOLOCK)
WHERE P.PEIdEmpresa=@IdEmpresa
  AND P.PEIdEstatus=1
  AND P.PEAdministrador=0;

IF NOT EXISTS(SELECT 1 FROM @Perfiles)
    THROW 55310,'La empresa no tiene perfiles activos no administradores.',1;

/*
   La pantalla envia idSolTipo=1; la precarga debe usar la misma clave.
   Solo se precarga el mes actual. Los meses historicos, futuros y los rangos
   personalizados se calculan y conservan bajo demanda al solicitar el reporte.
*/
EXEC dbo.PrecargaUniversoCobranzaVigencia_BF3_Cache
     @idEmpresa=@IdEmpresa,
     @idVigencia=@IdVigencia,
     @IdPerfil=@Perfiles,
     @Desde=@Desde,
     @Hasta=@Hasta,
     @idSolTipo=@IdSolTipo,
     @idVencida=1,
     @ForzarRecarga=@ForzarRecarga,
     @EmitirResultado=1;
GO
