USE [FlexiForbesv2];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Errores table
(
    Validacion varchar(80) NOT NULL,
    Detalle varchar(300) NOT NULL
);

INSERT @Errores
SELECT 'OBJETO',V.Objeto
FROM
(
    VALUES
      (N'dbo.ObtenCobranzaConcentrada_B2_CacheCapture'),
      (N'dbo.ff_ObtenCobranzaDesg_Adaptada_B2_CacheCapture'),
      (N'dbo.ff_ObtenDivisionCtos_Adaptado_B2_CacheCapture'),
      (N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'),
      (N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_Cache'),
      (N'dbo.ReporteCobranzaConcentrada_BF3_Cache'),
      (N'dbo.PrecargaUniversoCobranzaVigencia_BF3_Cache')
) V(Objeto)
WHERE OBJECT_ID(V.Objeto,N'P') IS NULL;

IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3')),N'')
       NOT LIKE N'%EXEC dbo.ObtenCobranzaConcentrada%'
    INSERT @Errores VALUES('RUTA DIRECTA','B3 directo no delega en B2.');

IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'dbo.ReporteCobranzaConcentrada_BF3_Cache')),N'')
       NOT LIKE N'%EXEC dbo.bf_CobranzaCache_CargarUnaV2%'
    INSERT @Errores VALUES('WRAPPER CACHE','No carga o valida la particion exacta.');

IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_Cache')),N'')
       NOT LIKE N'%EXEC dbo.ff_ObtenPlanConcentrado_Adaptado%'
    INSERT @Errores VALUES('LECTOR CACHE','No usa el generador de resultsets de B2.');

IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_CobranzaCache_CargarUnaV2')),N'')
       NOT LIKE N'%La ruta homologada necesita una fotografia exacta%'
    INSERT @Errores VALUES('CLAVE CACHE','El cargador no contiene la seleccion exacta homologada.');

IF ISNULL(OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_CobranzaCache_CapturaBasesV2')),N'')
       NOT LIKE N'%OBJECT_ID(N''tempdb..#CobranzaBanwire'')%'
    INSERT @Errores VALUES('CAPTURA CACHE','El capturador no tolera la ruta B2 sin temporales B3.');

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Parametro
    WHERE paIdEmpresa=917
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE'
      AND LTRIM(RTRIM(paValor))='1'
      AND paidEstatus=1
)
    INSERT @Errores VALUES('CONFIGURACION API','COBRANZA_CACHE no esta habilitado para la empresa 917.');

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Parametro
    WHERE paIdEmpresa=0
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE_HORA'
      AND paidEstatus=1
      AND LEN(LTRIM(RTRIM(paValor)))=5
      AND SUBSTRING(LTRIM(RTRIM(paValor)),3,1)=':'
      AND TRY_CONVERT(int,LEFT(LTRIM(RTRIM(paValor)),2)) BETWEEN 0 AND 23
      AND TRY_CONVERT(int,RIGHT(LTRIM(RTRIM(paValor)),2)) BETWEEN 0 AND 59
)
    INSERT @Errores VALUES('CONFIGURACION WORKER','Falta COBRANZA_CACHE_HORA global activa con formato HH:mm.');

IF OBJECT_ID(N'dbo.bf_ControlReporteGen',N'U') IS NULL
    INSERT @Errores VALUES('SEGUIMIENTO','No existe dbo.bf_ControlReporteGen.');

IF OBJECT_ID(N'dbo.VW_ReportesGenFiltro',N'V') IS NULL
    INSERT @Errores VALUES('SEGUIMIENTO','No existe dbo.VW_ReportesGenFiltro.');

IF OBJECT_ID(N'dbo.FF_ConsultaReportesGenFiltro',N'P') IS NULL
    INSERT @Errores VALUES('SEGUIMIENTO','No existe dbo.FF_ConsultaReportesGenFiltro.');

IF EXISTS
(
    SELECT 1
    FROM sys.sql_modules
    WHERE object_id IN
    (
        OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_B2_CacheCapture'),
        OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada_B2_CacheCapture'),
        OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado_B2_CacheCapture'),
        OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'),
        OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_Cache'),
        OBJECT_ID(N'dbo.ReporteCobranzaConcentrada_BF3_Cache'),
        OBJECT_ID(N'dbo.PrecargaUniversoCobranzaVigencia_BF3_Cache')
    )
      AND (uses_ansi_nulls=0 OR uses_quoted_identifier=0)
)
    INSERT @Errores VALUES('OPCIONES ANSI','Hay procedimientos creados sin ANSI_NULLS o QUOTED_IDENTIFIER.');

IF EXISTS(SELECT 1 FROM @Errores)
BEGIN
    SELECT Validacion,Detalle FROM @Errores ORDER BY Validacion;
    THROW 55320,'La instalacion no supero la validacion estructural.',1;
END;

SELECT 'OK' AS Estado,
       'Objetos y rutas de cobranza homologada instalados' AS Detalle;

/* Evidencia de las particiones existentes para la empresa validada. */
SELECT CacheId,FecIni,FecFin,Estado,FilasConcentrada,FilasDesglosada,
       FechaCargaInicio,FechaCargaFin
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH(NOLOCK)
WHERE IdEmpresa=917
  AND IdVigencia=4251
  AND EsUniverso=0
  AND IdSolTipo=1
  AND TRY_CONVERT(date,FecIni)<=CONVERT(date,GETDATE())
  AND TRY_CONVERT(date,FecFin)>=CONVERT(date,GETDATE())
ORDER BY FecIni,FecFin,CacheId DESC;
GO
