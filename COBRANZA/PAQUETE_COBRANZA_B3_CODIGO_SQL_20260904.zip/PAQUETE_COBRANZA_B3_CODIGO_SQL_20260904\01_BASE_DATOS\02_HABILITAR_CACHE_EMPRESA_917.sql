USE [FlexiForbesv2];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=917,
        @Usuario int=1,
        @IdParametro int;

IF OBJECT_ID(N'dbo.ff_Parametro',N'U') IS NULL
    THROW 55330,'No existe dbo.ff_Parametro.',1;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP(1) @IdParametro=paId
    FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=@IdEmpresa
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))='COBRANZA_CACHE'
    ORDER BY paidEstatus DESC,paId DESC;

    IF @IdParametro IS NULL
    BEGIN
        SELECT @IdParametro=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paidEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@IdParametro,@IdEmpresa,'COBRANZA_CACHE','1',
         'Habilita cache B2 homologado de cobranza para la empresa',
         1,@Usuario,GETDATE());
    END
    ELSE
        UPDATE dbo.ff_Parametro WITH(ROWLOCK)
           SET paClase='COBRANZA_CACHE',
               paValor='1',
               paDescripcion='Habilita cache B2 homologado de cobranza para la empresa',
               paidEstatus=1,
               paUsuarioUmod=@Usuario,
               paFechaUmod=GETDATE(),
               paFechaDel=NULL,
               paUsuarioDel=NULL
         WHERE paId=@IdParametro;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Parametro
    WHERE paIdEmpresa=@IdEmpresa
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE'
      AND LTRIM(RTRIM(paValor))='1'
      AND paidEstatus=1
)
    THROW 55330,'No fue posible habilitar COBRANZA_CACHE para la empresa 917.',1;

SELECT paId,paIdEmpresa,LTRIM(RTRIM(paClase)) Clase,
       LTRIM(RTRIM(paValor)) Valor,paidEstatus
FROM dbo.ff_Parametro
WHERE paId=@IdParametro;
GO
