USE [FlexiForbesv2];
GO

SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.bf_ControlReporteGen',N'U') IS NULL
    THROW 55340,'No existe dbo.bf_ControlReporteGen, usado por Seguimiento.',1;

SELECT paId,paIdEmpresa,LTRIM(RTRIM(paClase)) Clase,
       LTRIM(RTRIM(paValor)) Valor,paidEstatus
FROM dbo.ff_Parametro WITH(NOLOCK)
WHERE (paIdEmpresa=917 AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE')
   OR (paIdEmpresa=0 AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE_HORA')
ORDER BY paIdEmpresa,paId DESC;

/* Ejecutar despues de solicitar Cobranza desde la pantalla. */
SELECT TOP(20)
       CRptId,
       CRptFechaSolicitud,
       CRptFechaGeneracion,
       CRptIdEmpresa,
       CRptIdReporte,
       CRptIdEstatus,
       CASE CRptIdEstatus
           WHEN 1 THEN 'EN PROCESO'
           WHEN 2 THEN 'DISPONIBLE'
           WHEN 3 THEN 'ERROR'
           WHEN 4 THEN 'PROGRAMADO'
           WHEN 5 THEN 'DEPURADO'
           WHEN 6 THEN 'SIN DATOS'
           ELSE 'DESCONOCIDO'
       END AS Estatus,
       CRptRuta,
       CRptObservaciones
FROM dbo.bf_ControlReporteGen WITH(NOLOCK)
WHERE CRptIdEmpresa=917
  AND CRptIdReporte=11
ORDER BY CRptId DESC;

SELECT TOP(20)
       CacheId,IdSolTipo,FecIni,FecFin,Estado,
       FilasConcentrada,FilasDesglosada,
       FechaCargaInicio,FechaCargaFin,Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH(NOLOCK)
WHERE IdEmpresa=917
  AND IdVigencia=4251
ORDER BY CacheId DESC;
GO
