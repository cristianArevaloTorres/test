USE [FlexiForbesv2];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Faltantes table
(
    Tipo varchar(20) NOT NULL,
    Objeto sysname NOT NULL
);

IF TYPE_ID(N'dbo.ListInt') IS NULL
    INSERT @Faltantes VALUES('TYPE',N'dbo.ListInt');

INSERT @Faltantes(Tipo,Objeto)
SELECT V.Tipo,V.Objeto
FROM
(
    VALUES
      ('PROCEDURE',N'dbo.ObtenCobranzaConcentrada',N'P'),
      ('PROCEDURE',N'dbo.ff_ObtenCobranzaDesg_Adaptada',N'P'),
      ('PROCEDURE',N'dbo.ff_ObtenDivisionCtos_Adaptado',N'P'),
      ('PROCEDURE',N'dbo.ff_ObtenPlanConcentrado_Adaptado',N'P'),
      ('PROCEDURE',N'dbo.bf_CobranzaCache_CapturaBasesV2',N'P'),
      ('PROCEDURE',N'dbo.bf_CobranzaCache_CargarUnaV2',N'P'),
      ('TABLE',N'dbo.bf_CobranzaCache_ConsultaV2',N'U'),
      ('TABLE',N'dbo.bf_CobranzaCache_ConcentradaV2',N'U'),
      ('TABLE',N'dbo.bf_CobranzaCache_DesglosadaV2',N'U'),
      ('TABLE',N'dbo.bf_CobranzaCache_BanwireV2',N'U'),
      ('TABLE',N'dbo.bf_ControlReporteGen',N'U'),
      ('TABLE',N'dbo.ff_Parametro',N'U'),
      ('TABLE',N'dbo.ff_Empresa',N'U'),
      ('TABLE',N'dbo.ff_Vigencia',N'U'),
      ('TABLE',N'dbo.ff_Perfil',N'U'),
      ('VIEW',N'dbo.VW_ReportesGenFiltro',N'V'),
      ('PROCEDURE',N'dbo.FF_ConsultaReportesGenFiltro',N'P')
) V(Tipo,Objeto,TipoSql)
WHERE OBJECT_ID(V.Objeto,V.TipoSql) IS NULL;

IF EXISTS(SELECT 1 FROM @Faltantes)
BEGIN
    SELECT Tipo,Objeto FROM @Faltantes ORDER BY Tipo,Objeto;
    THROW 55300,'Faltan prerrequisitos de B2 o de la infraestructura cache B3.',1;
END;

SELECT 'OK' AS Estado,
       DB_NAME() AS BaseDatos,
       CONVERT(varchar(128),SERVERPROPERTY('ProductVersion')) AS VersionSql,
       'Prerrequisitos completos' AS Detalle;
GO
