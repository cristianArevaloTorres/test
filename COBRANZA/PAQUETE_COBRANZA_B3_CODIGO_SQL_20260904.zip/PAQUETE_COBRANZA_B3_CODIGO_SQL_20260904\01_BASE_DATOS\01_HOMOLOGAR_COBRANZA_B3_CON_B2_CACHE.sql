/*
   Homologa B3 con B2 y conserva un cache persistente de los dos resultsets base.
   La lectura del cache vuelve a utilizar el generador de resumen de B2, por lo
   que el contrato final permanece en ocho resultsets sin hojas informativas.
*/
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada',N'P') IS NULL
    THROW 55200,'No existe dbo.ObtenCobranzaConcentrada (B2).',1;
IF OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada',N'P') IS NULL
    THROW 55200,'No existe dbo.ff_ObtenCobranzaDesg_Adaptada (B2).',1;
IF OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado',N'P') IS NULL
    THROW 55200,'No existe dbo.ff_ObtenDivisionCtos_Adaptado (B2).',1;
IF OBJECT_ID(N'dbo.bf_CobranzaCache_CapturaBasesV2',N'P') IS NULL
    THROW 55200,'No existe la infraestructura bf_CobranzaCache_*V2.',1;

BEGIN TRY
    BEGIN TRANSACTION;

    DROP PROCEDURE IF EXISTS dbo.ObtenCobranzaConcentrada_B2_CacheCapture;
    DROP PROCEDURE IF EXISTS dbo.ff_ObtenCobranzaDesg_Adaptada_B2_CacheCapture;
    DROP PROCEDURE IF EXISTS dbo.ff_ObtenDivisionCtos_Adaptado_B2_CacheCapture;

    /*
       Copias internas de B2. La unica diferencia es que la ultima rutina no
       emite resultsets cuando el cargador activa el contexto de captura.
    */
    DECLARE @Division nvarchar(max)=
        OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado'));
    SET @Division=REPLACE
    (
        @Division,
        N'[dbo].[ff_ObtenDivisionCtos_Adaptado]',
        N'[dbo].[ff_ObtenDivisionCtos_Adaptado_B2_CacheCapture]'
    );
    DECLARE @PuntoCaptura int=
        CHARINDEX(N'INSERT INTO #tablatemp (NumEMpleado, Paterno',@Division);
    IF @PuntoCaptura=0
        THROW 55201,'No se encontro el punto de captura en la division de costos B2.',1;
    SET @Division=STUFF
    (
        @Division,@PuntoCaptura,0,
        N'IF TRY_CONVERT(bit,SESSION_CONTEXT(N''bf_CobranzaCacheCapturar''))=1
BEGIN
    EXEC dbo.bf_CobranzaCache_CapturaBasesV2;
    RETURN;
END;

'
    );
    EXEC sys.sp_executesql @Division;

    DECLARE @Desglosada nvarchar(max)=
        OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada'));
    SET @Desglosada=REPLACE
    (
        @Desglosada,
        N'[dbo].[ff_ObtenCobranzaDesg_Adaptada]',
        N'[dbo].[ff_ObtenCobranzaDesg_Adaptada_B2_CacheCapture]'
    );
    SET @Desglosada=REPLACE
    (
        @Desglosada,
        N'EXEC dbo.ff_ObtenDivisionCtos_Adaptado',
        N'EXEC dbo.ff_ObtenDivisionCtos_Adaptado_B2_CacheCapture'
    );
    EXEC sys.sp_executesql @Desglosada;

    DECLARE @Concentrada nvarchar(max)=
        OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada'));
    SET @Concentrada=REPLACE
    (
        @Concentrada,
        N'[dbo].[ObtenCobranzaConcentrada]',
        N'[dbo].[ObtenCobranzaConcentrada_B2_CacheCapture]'
    );
    SET @Concentrada=REPLACE
    (
        @Concentrada,
        N'EXEC dbo.ff_ObtenCobranzaDesg_Adaptada',
        N'EXEC dbo.ff_ObtenCobranzaDesg_Adaptada_B2_CacheCapture'
    );
    EXEC sys.sp_executesql @Concentrada;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* El capturador acepta tanto las temporales B3 de tarjeta como la ruta B2. */
DECLARE @Capturador nvarchar(max)=
    OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_CobranzaCache_CapturaBasesV2'));
IF @Capturador NOT LIKE N'%OBJECT_ID(N''tempdb..#CobranzaBanwire'')%'
BEGIN
    SET @Capturador=REPLACE
    (
        @Capturador,
        N'CREATE   PROCEDURE dbo.bf_CobranzaCache_CapturaBasesV2',
        N'ALTER PROCEDURE dbo.bf_CobranzaCache_CapturaBasesV2'
    );
    DECLARE @IniBanwire int=CHARINDEX
        (N'    DELETE FROM dbo.bf_CobranzaCache_BanwireV2 WHERE CacheId = @CacheId;',@Capturador);
    DECLARE @FinBanwire int=CHARINDEX
        (N'    UPDATE dbo.bf_CobranzaCache_ConsultaV2',@Capturador,@IniBanwire);
    IF @IniBanwire=0 OR @FinBanwire=0
        THROW 55203,'No se encontro el bloque Banwire del capturador.',1;

    DECLARE @BloqueBanwire nvarchar(max)=N'    DELETE FROM dbo.bf_CobranzaCache_BanwireV2 WHERE CacheId = @CacheId;
    IF OBJECT_ID(N''tempdb..#isEmpresaTC'') IS NOT NULL
       AND OBJECT_ID(N''tempdb..#CobranzaBanwire'') IS NOT NULL
    BEGIN
        EXEC sys.sp_executesql N''
            IF EXISTS (SELECT 1 FROM #isEmpresaTC)
            BEGIN
                INSERT dbo.bf_CobranzaCache_BanwireV2
                (CacheId,Orden,idEmpleado,CobroTarjeta,Dif,Transaccion,FechaCobro,
                 CodigoAutorizacion,Referencia,ext_ref_cliente,Card,Telefono,mail,Comercio)
                SELECT @pCacheId,ROW_NUMBER() OVER(ORDER BY idEmpleado,Transaccion),idEmpleado,
                       CobroTarjeta,Dif,Transaccion,FechaCobro,CodigoAutorizacion,Referencia,
                       ext_ref_cliente,Card,Telefono,mail,Comercio
                FROM #CobranzaBanwire;
            END;'',N''@pCacheId bigint'',@pCacheId=@CacheId;
        SET @EsTarjeta=1;
    END;

';
    SET @Capturador=STUFF
        (@Capturador,@IniBanwire,@FinBanwire-@IniBanwire,@BloqueBanwire);
    EXEC sys.sp_executesql @Capturador;
END;
GO

/*
   La version homologada siempre usa una clave exacta. Si hubo cambios se
   reconstruye completa porque B2 no implementa el filtro incremental de B3.
*/
DECLARE @Cargador nvarchar(max)=
    OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_CobranzaCache_CargarUnaV2'));
IF @Cargador NOT LIKE N'%La ruta homologada necesita una fotografia exacta%'
BEGIN
    SET @Cargador=REPLACE
    (
        @Cargador,
        N'CREATE   PROCEDURE dbo.bf_CobranzaCache_CargarUnaV2',
        N'ALTER PROCEDURE dbo.bf_CobranzaCache_CargarUnaV2'
    );
    DECLARE @IniExacta int=CHARINDEX
    (
        N'        ELSE
        BEGIN
            SELECT @CacheId=CacheId,@FechaAnterior=FechaFuenteHasta,@Estado=Estado,',
        @Cargador
    );
    DECLARE @FinExacta int=CHARINDEX
        (N'        IF @Estado=''COMPLETA'' SET @TeniaCacheCompleta=1;',@Cargador,@IniExacta);
    IF @IniExacta=0 OR @FinExacta=0
        THROW 55202,'No se encontro la seleccion exacta del cache.',1;

    DECLARE @SeleccionExacta nvarchar(max)=N'        ELSE
        BEGIN
            /* La ruta homologada necesita una fotografia exacta: no sustituirla por un universo. */
            SELECT TOP (1) @CacheId=CacheId,@FechaAnterior=FechaFuenteHasta,@Estado=Estado,
                   @CacheFecIni=FecIni,@CacheFecFin=FecFin
            FROM dbo.bf_CobranzaCache_ConsultaV2
            WHERE IdEmpresa=@idEmpresa AND IdSolTipo=@idSolTipo
              AND FecIni=@FecIni AND FecFin=@FecFin
              AND IdVencida=@idVencida AND IdVigencia=@idVigencia
              AND PerfilHash=@PerfilHash AND EsUniverso=0
            ORDER BY CacheId DESC;
        END;

';
    SET @Cargador=STUFF
        (@Cargador,@IniExacta,@FinExacta-@IniExacta,@SeleccionExacta);
END;

IF @Cargador NOT LIKE N'%B2 no consume #FiltroIncrementalEmps%'
BEGIN
    SET @Cargador=REPLACE
    (
        @Cargador,
        N'            /* Si el SP de empleados no reconoce el filtro temporal, se prioriza igualdad sobre velocidad. */
            IF @idVencida NOT IN (1,10)
               OR ISNULL(OBJECT_DEFINITION(OBJECT_ID(N''dbo.ff_ObtenEmpleadosCob_v2_bf3'')),N'''')
                    NOT LIKE N''%#FiltroIncrementalEmps%''
                SET @Modo=''FULL'';',
        N'            /* B2 no consume #FiltroIncrementalEmps: cualquier cambio exige reconstruccion completa. */
            SET @Modo=''FULL'';'
    );
END;

IF @Cargador NOT LIKE N'%La ruta homologada necesita una fotografia exacta%'
   OR @Cargador NOT LIKE N'%B2 no consume #FiltroIncrementalEmps%'
    THROW 55204,'No fue posible adaptar el cargador de cache.',1;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_CobranzaCache_CargarUnaV2'))<>@Cargador
    EXEC sys.sp_executesql @Cargador;
GO

CREATE OR ALTER PROCEDURE dbo.ObtenCobranzaConcentrada_otro_V2_BF3
    @idEmpresa int=0,
    @idSolTipo int=0,
    @FecIni varchar(16)='',
    @FecFin varchar(16)='',
    @idVencida int=0,
    @IdPerfil dbo.ListInt READONLY,
    @idVIgencia int=0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @IdPerfilB2 int=NULL,@CantidadPerfiles int;
    SELECT @CantidadPerfiles=COUNT(*),
           @IdPerfilB2=CASE WHEN COUNT(*)=1
                            THEN MIN(IdTipoNotificacionCorreo) ELSE NULL END
    FROM @IdPerfil;

    BEGIN TRY
        INSERT dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES
        (
            'cobranza_bf3_ruta_sql',
            CONCAT('ruta=B2_HOMOLOGADA; empresa=',@idEmpresa,
                   '; vigencia=',@idVIgencia,
                   '; perfiles=',@CantidadPerfiles,
                   '; perfilB2=',COALESCE(CONVERT(varchar(20),@IdPerfilB2),'NULL'),
                   '; cache=',COALESCE(TRY_CONVERT(varchar(10),
                       SESSION_CONTEXT(N'bf_CobranzaCacheCapturar')),'0'))
        );
    END TRY
    BEGIN CATCH
    END CATCH;

    IF TRY_CONVERT(bit,SESSION_CONTEXT(N'bf_CobranzaCacheCapturar'))=1
    BEGIN
        EXEC dbo.ObtenCobranzaConcentrada_B2_CacheCapture
             @idEmpresa=@idEmpresa,
             @idSolTipo=@idSolTipo,
             @FecIni=@FecIni,
             @FecFin=@FecFin,
             @idVencida=@idVencida,
             @IdPerfil=@IdPerfilB2;
        RETURN;
    END;

    EXEC dbo.ObtenCobranzaConcentrada
         @idEmpresa=@idEmpresa,
         @idSolTipo=@idSolTipo,
         @FecIni=@FecIni,
         @FecFin=@FecFin,
         @idVencida=@idVencida,
         @IdPerfil=@IdPerfilB2;
END;
GO

CREATE OR ALTER PROCEDURE dbo.ObtenCobranzaConcentrada_otro_V2_BF3_Cache
    @idEmpresa int=0,
    @idSolTipo int=0,
    @FecIni varchar(16)='',
    @FecFin varchar(16)='',
    @idVencida int=0,
    @IdPerfil dbo.ListInt READONLY,
    @idVIgencia int=0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PerfilClave varchar(2000),
            @PerfilHash varbinary(32),
            @CacheId bigint;

    SELECT @PerfilClave=STUFF
    ((
        SELECT ','+CONVERT(varchar(11),P.IdTipoNotificacionCorreo)
        FROM (SELECT DISTINCT IdTipoNotificacionCorreo FROM @IdPerfil) P
        ORDER BY P.IdTipoNotificacionCorreo
        FOR XML PATH(''),TYPE
    ).value('.','varchar(2000)'),1,1,'');
    SET @PerfilClave=ISNULL(@PerfilClave,'');
    SET @PerfilHash=HASHBYTES('SHA2_256',@PerfilClave);

    SELECT TOP(1) @CacheId=CacheId
    FROM dbo.bf_CobranzaCache_ConsultaV2 WITH(NOLOCK)
    WHERE IdEmpresa=@idEmpresa
      AND IdSolTipo=@idSolTipo
      AND FecIni=@FecIni
      AND FecFin=@FecFin
      AND IdVencida=@idVencida
      AND IdVigencia=@idVIgencia
      AND PerfilHash=@PerfilHash
      AND EsUniverso=0
      AND Estado='COMPLETA'
    ORDER BY CacheId DESC;

    IF @CacheId IS NULL
        THROW 51005,'No existe una cache completa para esos parametros.',1;

    CREATE TABLE #ListEmpresas (EMidEmpresa int NOT NULL PRIMARY KEY);
    INSERT #ListEmpresas VALUES(@idEmpresa);

    CREATE TABLE #isEmpresaTC (result int);

    SELECT @FecIni AS FechaInicio,
           @FecFin AS FechaFin,
           @idVIgencia AS idVigencia
    INTO #ParametrosCobranza;

    SELECT CONVERT(int,ROW_NUMBER() OVER(ORDER BY Orden)) AS Id_tablatemp,
           empresa,NumEMpleado,CveEmpl,Paterno,MAterno,Nombre1,Nombre2,Sexo,FechaNac,Edad,
           Confidencial,SueldoMensual,SueldoMensualAnt,SueldoMensualDif,TRANSFERIDO,NumSolicitud,
           Perfil,FechaAutorizacion,MontoGMM,MontoVIDA,MontoOTROSPLANES,CreditosGMM,CreditosViDA,
           MontoTotalCreditos,MontoTotalCreditosAnt,DiferenciaCreditos,MontoTotalSelecciones,
           MontoTotalSeleccionesAnt,SobranteCreditos,MontoPagCred,MontoDescMensual,MontoDescMensualAnt,
           GrupoParentescoGMM,Excedentes,ExcedentesAnt,MontoFondoAhorroMensual,
           MontoFondoAhorroMensualAnt,SobranteExcedentes,DescuentoEmpleadoFH,DescuentoEmpleadoFinal,
           SobranteExceFinal,CoberturaDesc,Q1,Q2,Diferencia,CtoEmpleadoNomSeg,AplicExcedentes,
           NumOficina,NomOficina,POFH,LocalNumber,PagoEmpresa,PagoEmpleado,CentroCostos
    INTO #tablatemp
    FROM dbo.bf_CobranzaCache_ConcentradaV2 WITH(NOLOCK)
    WHERE CacheId=@CacheId;

    SELECT EMPRESA,NUMEMPLEADO,idemp,Paterno,Materno,Nombre1,Nombre2,idSexo,Sexo,FechaNac,Edad,
           Perfil,CVEParentesco,NombreParentesco,TRANSFERIDO,SueldoMensual,NumSolicitud,POidSolicitud,
           PlanD,PlanOpcion,IdGRUPOP,GRUPOPARENTESCO,CVEPO,CVEP,TIPOSUMASEG,VALSUMA,PLOrdenCobranza,
           ImporteAnual,ImportexPeriodo,MontoTotalCreditos,MontoPeridoCreditos,CostoEmpresa,
           CtoEmpresaCash,CtoEmpresa1erexc,CtoEmpresaStoploss,CostoEmpleado,CtoEmpleadoCash,
           CtoEmpleado1erexc,CtoEmpleadoStoploss,CostoEmpleadoExcedente,CostoEmpleadoReal,
           SobranteExcedentes,PrimaNetaAnual,PrimaNetaxPer,idVigencia
    INTO #TablaCobDesg
    FROM dbo.bf_CobranzaCache_DesglosadaV2 WITH(NOLOCK)
    WHERE CacheId=@CacheId;

    INSERT INTO #tablatemp
    (Id_tablatemp,NumEMpleado,Paterno,MAterno,Nombre1,Nombre2,Sexo,Confidencial,TRANSFERIDO,
     NumSolicitud,Perfil,GrupoParentescoGMM,FechaNac,FechaAutorizacion,MontoGMM,MontoVIDA,
     MontoOTROSPLANES,CreditosGMM,CreditosViDA,MontoTotalCreditos,MontoTotalSelecciones,
     SobranteCreditos,MontoPagCred,MontoDescMensual,Q1,Q2,Diferencia,Excedentes,ExcedentesAnt,
     MontoFondoAhorroMensual,SobranteExcedentes,DescuentoEmpleadoFH,DescuentoEmpleadoFinal,
     CtoEmpleadoNomSeg,SobranteExceFinal,CoberturaDesc,AplicExcedentes)
    SELECT ISNULL(MAX(Id_tablatemp),0)+1,'TOTALES: ','','','','','','','','','','','','',
           SUM(MontoGMM),SUM(MontoVIDA),SUM(MontoOTROSPLANES),SUM(CreditosGMM),SUM(CreditosViDA),
           SUM(MontoTotalCreditos),SUM(MontoTotalSelecciones),SUM(SobranteCreditos),SUM(MontoPagCred),
           ISNULL(SUM(MontoDescMensual),0),SUM(Q1),SUM(Q2),SUM(Diferencia),SUM(Excedentes),
           SUM(ExcedentesAnt),SUM(MontoFondoAhorroMensual),SUM(SobranteExcedentes),
           SUM(DescuentoEmpleadoFH),SUM(DescuentoEmpleadoFinal),SUM(CtoEmpleadoNomSeg),
           SUM(SobranteExceFinal),SUM(CoberturaDesc),SUM(AplicExcedentes)
    FROM #tablatemp;

    SELECT empresa,NumEMpleado,CveEmpl,Paterno,MAterno,Nombre1,Nombre2,Sexo,FechaNac,Edad,
           Confidencial,SueldoMensual,ISNULL(SueldoMensualAnt,0) AS SueldoMensualAnt,
           ISNULL(SueldoMensualDif,0) AS SueldoMensualDif,TRANSFERIDO,NumSolicitud,Perfil,
           FechaAutorizacion,GrupoParentescoGMM AS GrupoParentescoGMM,MontoGMM,MontoVIDA,
           MontoOTROSPLANES,CreditosGMM,CreditosViDA,MontoTotalCreditos,
           ISNULL(MontoTotalCreditosAnt,0) AS MontoTotalCreditosAnt,
           ISNULL(MontoTotalCreditos-MontoTotalCreditosAnt,0) AS DiferenciaCreditos,
           MontoTotalSelecciones,ISNULL(MontoTotalSeleccionesAnt,0) AS MontoTotalSeleccionesAnt,
           ISNULL(MontoTotalSelecciones-MontoTotalSeleccionesAnt,0) AS DiferenciaSelecciones,
           SobranteCreditos,MontoPagCred,MontoDescMensual,
           ISNULL(MontoDescMensualAnt,0) AS MontoDescMensualAnt,
           ISNULL(MontoDescMensual-MontoDescMensualAnt,0) AS DiferenciaMonto,Q1,Q2,Diferencia,
           Excedentes,ISNULL(ExcedentesAnt,0) AS ExcedentesAnt,
           ISNULL(Excedentes-ExcedentesAnt,0) AS DiferenciaExcedentes,
           MontoFondoAhorroMensual,ISNULL(MontoFondoAhorroMensualAnt,0) AS MontoFondoAhorroMensualAnt,
           ISNULL(MontoFondoAhorroMensual-MontoFondoAhorroMensualAnt,0) AS DiferenciaFH,
           SobranteExcedentes,AplicExcedentes,DescuentoEmpleadoFH,DescuentoEmpleadoFinal,
           CtoEmpleadoNomSeg,SobranteExceFinal,CoberturaDesc,NumOficina,NomOficina,POFH,LocalNumber,
           CentroCostos AS PagoEmpresa,PagoEmpleado
    FROM #tablatemp
    ORDER BY NumEmpleado;

    EXEC dbo.ff_ObtenPlanConcentrado_Adaptado;
END;
GO

CREATE OR ALTER PROCEDURE dbo.ReporteCobranzaConcentrada_BF3_Cache
    @idEmpresa int=0,
    @idSolTipo int=0,
    @FecIni varchar(16)='',
    @FecFin varchar(16)='',
    @idVencida int=0,
    @IdPerfil dbo.ListInt READONLY,
    @idVIgencia int=0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF TRY_CONVERT(date,@FecIni) IS NULL OR TRY_CONVERT(date,@FecFin) IS NULL
        THROW 51004,'FecIni o FecFin no tienen un formato valido.',1;

    /*
       B2 recibe varchar(10), por lo que su granularidad real es la fecha. La
       normalizacion permite reutilizar la misma fotografia aunque el cliente
       mande 2026-09-30, 20260930 o 2026-09-30 23:59.
    */
    DECLARE @FecIniNormalizada varchar(16)=CONVERT(char(10),TRY_CONVERT(date,@FecIni),120),
            @FecFinNormalizada varchar(16)=CONVERT(char(10),TRY_CONVERT(date,@FecFin),120),
            @Resultado varchar(30);

    IF TRY_CONVERT(date,@FecIniNormalizada)>TRY_CONVERT(date,@FecFinNormalizada)
        THROW 51004,'FecIni no puede ser posterior a FecFin.',1;

    EXEC dbo.bf_CobranzaCache_CargarUnaV2
         @idEmpresa=@idEmpresa,
         @idSolTipo=@idSolTipo,
         @FecIni=@FecIniNormalizada,
         @FecFin=@FecFinNormalizada,
         @idVencida=@idVencida,
         @IdPerfil=@IdPerfil,
         @idVigencia=@idVIgencia,
         @ForzarRecarga=0,
         @EsUniverso=0,
         @Resultado=@Resultado OUTPUT;

    EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_Cache
         @idEmpresa=@idEmpresa,
         @idSolTipo=@idSolTipo,
         @FecIni=@FecIniNormalizada,
         @FecFin=@FecFinNormalizada,
         @idVencida=@idVencida,
         @IdPerfil=@IdPerfil,
         @idVIgencia=@idVIgencia;
END;
GO

/*
   Precarga segura del universo de una vigencia como fotografias de periodos.
   No intenta derivar un mes filtrando el resultado anual: cada particion se
   genera con los parametros exactos de B2. Los rangos personalizados que no
   coincidan con una particion se calculan bajo demanda por el wrapper anterior.
*/
CREATE OR ALTER PROCEDURE dbo.PrecargaUniversoCobranzaVigencia_BF3_Cache
    @idEmpresa int,
    @idVigencia int,
    @IdPerfil dbo.ListInt READONLY,
    @Desde date=NULL,
    @Hasta date=NULL,
    @idSolTipo int=0,
    @idVencida int=1,
    @ForzarRecarga bit=0,
    @EmitirResultado bit=1
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @InicioVigencia date,
            @FinVigencia date,
            @PerfilClave varchar(2000),
            @PerfilHash varbinary(32);

    SELECT @InicioVigencia=CONVERT
           (
               date,
               CASE WHEN VIEnrollmentIni IS NOT NULL AND VIEnrollmentIni<VIVigenciaIni
                    THEN VIEnrollmentIni ELSE VIVigenciaIni END
           ),
           @FinVigencia=CONVERT(date,VIVigenciaFin)
    FROM dbo.ff_Vigencia WITH(NOLOCK)
    WHERE VIidVigencia=@idVigencia;

    IF @InicioVigencia IS NULL OR @FinVigencia IS NULL
        THROW 55210,'La vigencia solicitada no existe.',1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ff_Empresa E WITH(NOLOCK)
        INNER JOIN dbo.ff_Vigencia V WITH(NOLOCK)
            ON V.VIidConfiguracion=E.EMidConfiguracion
        WHERE E.EMidEmpresa=@idEmpresa
          AND V.VIidVigencia=@idVigencia
    )
        THROW 55210,'La vigencia no pertenece a la empresa solicitada.',1;

    SET @Desde=CASE WHEN @Desde IS NULL OR @Desde<@InicioVigencia
                    THEN @InicioVigencia ELSE @Desde END;
    SET @Hasta=CASE WHEN @Hasta IS NULL OR @Hasta>@FinVigencia
                    THEN @FinVigencia ELSE @Hasta END;

    IF @Desde>@Hasta
        THROW 55210,'El rango de precarga no intersecta la vigencia.',1;

    SELECT @PerfilClave=STUFF
    ((
        SELECT ','+CONVERT(varchar(11),P.IdTipoNotificacionCorreo)
        FROM (SELECT DISTINCT IdTipoNotificacionCorreo FROM @IdPerfil) P
        ORDER BY P.IdTipoNotificacionCorreo
        FOR XML PATH(''),TYPE
    ).value('.','varchar(2000)'),1,1,'');
    SET @PerfilClave=ISNULL(@PerfilClave,'');
    SET @PerfilHash=HASHBYTES('SHA2_256',@PerfilClave);

    CREATE TABLE #PeriodosGenerados
    (
        Orden int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        FecIni varchar(16) NOT NULL,
        FecFin varchar(16) NOT NULL,
        Resultado varchar(30) NOT NULL,
        CacheId bigint NULL,
        Estado varchar(20) NULL,
        FilasConcentrada int NULL,
        FilasDesglosada int NULL
    );

    DECLARE @Mes date=DATEFROMPARTS(YEAR(@Desde),MONTH(@Desde),1),
            @InicioPeriodo date,
            @FinPeriodo date,
            @Ini varchar(16),
            @Fin varchar(16),
            @Resultado varchar(30),
            @CacheId bigint;

    WHILE @Mes<=@Hasta
    BEGIN
        SET @InicioPeriodo=CASE WHEN @Mes<@Desde THEN @Desde ELSE @Mes END;
        SET @FinPeriodo=CASE WHEN EOMONTH(@Mes)>@Hasta THEN @Hasta ELSE EOMONTH(@Mes) END;
        SET @Ini=CONVERT(char(10),@InicioPeriodo,120);
        SET @Fin=CONVERT(char(10),@FinPeriodo,120);
        SET @Resultado=NULL;
        SET @CacheId=NULL;

        EXEC dbo.bf_CobranzaCache_CargarUnaV2
             @idEmpresa=@idEmpresa,
             @idSolTipo=@idSolTipo,
             @FecIni=@Ini,
             @FecFin=@Fin,
             @idVencida=@idVencida,
             @IdPerfil=@IdPerfil,
             @idVigencia=@idVigencia,
             @ForzarRecarga=@ForzarRecarga,
             @EsUniverso=0,
             @Resultado=@Resultado OUTPUT;

        SELECT TOP(1) @CacheId=CacheId
        FROM dbo.bf_CobranzaCache_ConsultaV2 WITH(NOLOCK)
        WHERE IdEmpresa=@idEmpresa
          AND IdSolTipo=@idSolTipo
          AND FecIni=@Ini
          AND FecFin=@Fin
          AND IdVencida=@idVencida
          AND IdVigencia=@idVigencia
          AND PerfilHash=@PerfilHash
          AND EsUniverso=0
        ORDER BY CacheId DESC;

        INSERT #PeriodosGenerados
        (FecIni,FecFin,Resultado,CacheId,Estado,FilasConcentrada,FilasDesglosada)
        SELECT @Ini,@Fin,ISNULL(@Resultado,'SIN_RESULTADO'),Q.CacheId,Q.Estado,
               Q.FilasConcentrada,Q.FilasDesglosada
        FROM (VALUES(1)) X(N)
        LEFT JOIN dbo.bf_CobranzaCache_ConsultaV2 Q WITH(NOLOCK)
            ON Q.CacheId=@CacheId;

        SET @Mes=DATEADD(month,1,@Mes);
    END;

    IF @EmitirResultado=1
        SELECT FecIni,FecFin,Resultado,CacheId,Estado,
               FilasConcentrada,FilasDesglosada
        FROM #PeriodosGenerados
        ORDER BY Orden;
END;
GO
