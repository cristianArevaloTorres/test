USE [FlexiForbesv2];
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* Ajustar antes de instalar. Zona horaria del worker: America/Mexico_City. */
DECLARE @Hora varchar(5)='01:00',
        @Usuario int=1,
        @IdParametro int;

IF LEN(@Hora)<>5
   OR SUBSTRING(@Hora,3,1)<>':'
   OR TRY_CONVERT(int,LEFT(@Hora,2)) NOT BETWEEN 0 AND 23
   OR TRY_CONVERT(int,RIGHT(@Hora,2)) NOT BETWEEN 0 AND 59
    THROW 55331,'COBRANZA_CACHE_HORA debe tener formato HH:mm.',1;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP(1) @IdParametro=paId
    FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=0
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))='COBRANZA_CACHE_HORA'
    ORDER BY paidEstatus DESC,paId DESC;

    IF @IdParametro IS NULL
    BEGIN
        SELECT @IdParametro=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paidEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@IdParametro,0,'COBRANZA_CACHE_HORA',@Hora,
         'Horario diario del worker de cache Cobranza (HH:mm America/Mexico_City)',
         1,@Usuario,GETDATE());
    END
    ELSE
        UPDATE dbo.ff_Parametro WITH(ROWLOCK)
           SET paClase='COBRANZA_CACHE_HORA',
               paValor=@Hora,
               paDescripcion='Horario diario del worker de cache Cobranza (HH:mm America/Mexico_City)',
               paidEstatus=1,
               paUsuarioUmod=@Usuario,
               paFechaUmod=GETDATE(),
               paFechaDel=NULL,
               paUsuarioDel=NULL
         WHERE paId=@IdParametro;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT paId,paIdEmpresa,LTRIM(RTRIM(paClase)) Clase,
       LTRIM(RTRIM(paValor)) Valor,paidEstatus
FROM dbo.ff_Parametro
WHERE paId=@IdParametro;
GO
