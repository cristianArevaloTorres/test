# Publica exclusivamente la homologacion del nombre mostrado en la
# notificacion de Cobranza.
# Antes de ejecutarlo, copia la carpeta src del ZIP sobre la raiz de APIREPORTS.

$RepoApi = 'C:\repo\reportes\APIREPORTS'
$Rama = 'ReporteSabanaHomologacionOK-clean'

Set-Location -LiteralPath $RepoApi

if (-not (Test-Path -LiteralPath '.git')) {
    throw "Esta carpeta no es un clon Git: $RepoApi"
}

git switch $Rama
if ($LASTEXITCODE -ne 0) { throw "No se pudo cambiar a $Rama." }

$YaPreparados = @(git diff --cached --name-only)
if ($YaPreparados.Count -gt 0) {
    $YaPreparados
    throw 'Ya existen archivos en staging. Quitalos de staging y vuelve a ejecutar.'
}

git pull --rebase --autostash origin $Rama
if ($LASTEXITCODE -ne 0) {
    throw 'El pull encontro un conflicto. Ejecuta git status antes de continuar.'
}

$Archivo = 'src/main/java/com/lockton/rpt/services/impl/CobranzaServiceImpl.java'
if (-not (Test-Path -LiteralPath $Archivo)) {
    throw "No se encontro el archivo requerido: $Archivo"
}

git add -- $Archivo
if ($LASTEXITCODE -ne 0) { throw 'No se pudo agregar el archivo.' }

Write-Host 'Unico archivo que entrara al commit:'
git diff --cached --name-status

git diff --cached --check
if ($LASTEXITCODE -ne 0) { throw 'Git encontro errores en el archivo preparado.' }

git commit -m 'Homologa nombre en notificacion de Cobranza'
if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear el commit.' }

git push origin $Rama
if ($LASTEXITCODE -ne 0) { throw 'El push fue rechazado.' }

Write-Host 'Push terminado. Solo se publico CobranzaServiceImpl.java.'
