USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @Resultado table
(
    Orden int NOT NULL,
    Modulo varchar(20) NOT NULL,
    Estado varchar(10) NOT NULL,
    Validacion nvarchar(150) NOT NULL,
    Detalle nvarchar(max) NULL
);

DECLARE @Gmm nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaGMM_BF3')),
        @Vida nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaVIDA_BF3')),
        @Opc nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaOPC_BF3'));

INSERT @Resultado VALUES
(10, 'SABANA', CASE WHEN @Gmm LIKE N'%CS.CSPestana = 1 AND EM.EMIdEstatus = 2 AND POS.POidempresa%' THEN 'OK' ELSE 'ERROR' END,
 N'Bajas GMM excluyen empleados activos', N'La definicion instalada debe contener EM.EMIdEstatus = 2.'),
(20, 'SABANA', CASE WHEN @Vida LIKE N'%POS.POIdEstatus in (4,5) AND EM.EMIdEstatus=2 AND CS.CSidTipoSabana=2%' THEN 'OK' ELSE 'ERROR' END,
 N'Bajas Vida excluyen empleados activos', N'La definicion instalada debe contener EM.EMIdEstatus=2.'),
(30, 'SABANA', CASE WHEN @Opc LIKE N'%POS.POIdEstatus in (4,5) AND EM.EMIdEstatus=2 AND CS.CSidTipoSabana=3%' THEN 'OK' ELSE 'ERROR' END,
 N'Bajas Opcionales excluyen empleados activos', N'La definicion instalada debe contener EM.EMIdEstatus=2.');

IF OBJECT_ID(N'dbo.bf_RepConf_Tabla', N'U') IS NOT NULL
BEGIN
    DECLARE @FormatoActivo int =
    (
        SELECT COUNT(DISTINCT UPPER(grupo))
        FROM dbo.bf_RepConf_Tabla
        WHERE catReportesId = 3
          AND ISNULL(activo, 1) = 1
          AND UPPER(ISNULL(colorFondo, N'')) = N'#0D6EFD'
          AND UPPER(ISNULL(colorLetra, N'')) = N'WHITE'
          AND UPPER(grupo) IN (N'GMM', N'VIDA', N'OPC', N'MASCOTAS')
    );

    INSERT @Resultado VALUES
    (40, 'SABANA', CASE WHEN @FormatoActivo = 4 THEN 'OK' ELSE 'ERROR' END,
     N'Configuracion visual B3 disponible',
     CONCAT(N'Grupos con encabezado #0D6EFD y letra blanca: ', @FormatoActivo, N' de 4.'));
END
ELSE
BEGIN
    INSERT @Resultado VALUES
    (40, 'SABANA', 'ERROR', N'Configuracion visual B3 disponible',
     N'No existe dbo.bf_RepConf_Tabla; la generacion configurable no puede aplicar formato.');
END;

INSERT @Resultado
SELECT 50, 'SABANA',
       CASE WHEN COUNT(*) = 0 THEN 'INFO' ELSE 'OK' END,
       N'Empleados observados por QA',
       CASE WHEN COUNT(*) = 0
            THEN N'Los numeros 10178747, 10384500 y 11033846 no existen en esta base; validar en QA empresa 2219.'
            ELSE STRING_AGG(CONCAT(EMNumeroEmpleado, N': EMIdEstatus=', EMIdEstatus), N'; ') END
FROM dbo.ff_Empleado
WHERE EMNumeroEmpleado COLLATE DATABASE_DEFAULT IN
      (N'10178747' COLLATE DATABASE_DEFAULT,
       N'10384500' COLLATE DATABASE_DEFAULT,
       N'11033846' COLLATE DATABASE_DEFAULT);

SELECT Modulo, Estado, Validacion, Detalle
FROM @Resultado
ORDER BY Orden;
GO
