import { Injectable } from '@angular/core';
import { GLOBAL } from '../global';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { timeout } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReporteCobranzaService {

  private url2: string;
  private urlSab: string;

  constructor(private _http: HttpClient) {
    this.url2 = GLOBAL.url5; // APIREPORTES (puerto 8182)
    this.urlSab = GLOBAL.url;  // SAB (puerto 8181)
  }

  private handlerHeaders(token) {
    return new HttpHeaders({ authorization: token });
  }

  getConsultaCobranza(jsonData, token) {
    console.log("getConsultaCobranza:", jsonData);

  if (jsonData.IdsPerfil && Array.isArray(jsonData.IdsPerfil)) {
    jsonData.IdsPerfil = jsonData.IdsPerfil.map(Number);
  }
    const headers = {'authorization': token};
    
    return this._http.post<any>(`${this.url2}cobranza/consultar`,jsonData,{ headers }).pipe(timeout(3600000));
  }

  solicitarCobranza(jsonData: any, token: string) {
    if (jsonData.IdsPerfil && Array.isArray(jsonData.IdsPerfil)) {
      jsonData.IdsPerfil = jsonData.IdsPerfil.map(Number);
    }
    const headers = { 'authorization': token };
    return this._http.post<any>(`${this.url2}cobranza/solicitar`, jsonData, { headers }).toPromise();
  }

  getListaDeArchivos(jsonData, token) {
    console.log("getListaArchivos:", jsonData);
  
    const headers = this.handlerHeaders(token);

  if (jsonData.IdsPerfil && Array.isArray(jsonData.IdsPerfil)) {
    jsonData.IdsPerfil = jsonData.IdsPerfil.map(Number);
  }

    return this._http.post<any>(`${this.url2}cobranza/consultar`,jsonData,{ headers }).toPromise().then(response => {
      console.log("Respuesta del servidor:", response);
      return response;
    })
    .catch(error => {
      console.error("Error en la solicitud:", error);
      throw error;
    });
  }

  public descargarArchivo(idEmpresa: number, archivo: string, token: string): Observable<Blob> {
    const url = `${this.url2}cobranza/descargar?idEmpresa=${idEmpresa}&archivo=${encodeURIComponent(archivo)}`;
    return this._http.get(url, {
      headers: this.handlerHeaders(token),
      responseType: 'blob'
    });
  }
  

  public getVigenciaActiva(idEmpresa, token) {
    return this._http.get<any>(
      `${this.url2}cobranza/getVigenciaActiva?idEmpresa=${idEmpresa}`,
      { headers: this.handlerHeaders(token) }
    ).toPromise();
  }

  public getFechaInicioVigencia(vigencia, token) {
    return this._http.get<string>(
      `${this.url2}cobranza/getFechaInicioVigencia?vigencia=${vigencia}`,
      { headers: this.handlerHeaders(token) }
    ).toPromise();
  }

  public getFechaFinalVigencia(vigencia, token) {
    return this._http.get<string>(
      `${this.url2}cobranza/getFechaFinalVigencia?vigencia=${vigencia}`,
      { headers: this.handlerHeaders(token) }
    ).toPromise();
  }

  public getFechaInicioEnrollment(vigencia, token) {
    return this._http.get<string>(
      `${this.url2}cobranza/getFechaInicioEnrollment?vigencia=${vigencia}`,
      { headers: this.handlerHeaders(token) }
    ).toPromise();
  }

  public getConfiguracionEnvio(idCorporativo, token) {
    return this._http.get<string>(
      `${this.url2}cobranza/getConfiguracionEnvio?idCorporativo=${idCorporativo}`,
      { headers: this.handlerHeaders(token) }
    ).toPromise();
  }

  public getPerfiles(idEmpresa, token) {
    return this._http.get<any>(
      `${this.urlSab}documentoAsig/perfil?idEmpresa=${idEmpresa}&todos=-1`,
      { headers: this.handlerHeaders(token) }
    ).toPromise();
  }

  public getPeriodicidadDePagos(idVigencia, token) {
    return this._http.get<any>(
      `${this.url2}cobranza/getPeriodicidadDePagos?idVigencia=${idVigencia}`,
      { headers: this.handlerHeaders(token) }
    ).toPromise();
  }
}
