package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.services.CobranzaService;
import com.lockton.rpt.util.ReportePathUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("beflex/cobranza")
public class WSCobranzaController {

    private static final Log LOGGER = LogFactory.getLog(WSCobranzaController.class);

    @Autowired
    private CobranzaService cobranzaService;

    @Value("${cobranza.ruta.base}")
    private String rutaBase;

    @PostMapping("/consultar")
    public ResponseEntity<List<Object>> consultar(
            @RequestBody Map<String, Object> body,
            @RequestHeader("authorization") String token) {

        List<Object> list = new LinkedList<>();
        try {
            int idEmpresa     = parseInt(body.get("idEmpresa"));
            int idSolTipo     = parseInt(body.get("idSolTipo"));
            String FecIni     = str(body.get("FecIni"));
            String FecFin     = str(body.get("FecFin"));
            int idVencida     = parseInt(body.get("idVencida"));
            List<Integer> ids = toIntList(body.get("IdsPerfil"));
            String empresa    = str(body.get("empresa"));
            int idCorporativo = parseInt(body.get("idCorporativo"));
            String nomCorp    = str(body.get("nomCorp"));
            String nomAdm     = str(body.get("nomAdm"));
            String nomEmp     = str(body.get("nomEmp"));
            String email      = str(body.get("email"));
            int idVigencia    = parseInt(body.get("idVigencia"));
            int bandera       = parseInt(body.get("bandera"));
            int idUsuario     = body.containsKey("idUsuario") ? parseInt(body.get("idUsuario")) : 0;

            if (!esConsultaDeArchivos(
                    idSolTipo, FecIni, FecFin, idVencida, ids,
                    empresa, nomCorp, nomAdm, nomEmp, email)) {
                Map<String, Object> json = new HashMap<>();
                json.put("error", true);
                json.put("mssError", "La generacion directa de Cobranza esta "
                        + "deshabilitada. Use /beflex/cobranza/solicitar para "
                        + "registrarla en la cola.");
                list.add(json);
                return new ResponseEntity<>(list, HttpStatus.CONFLICT);
            }

            list = cobranzaService.consultaCobranza(idEmpresa, idSolTipo, FecIni, FecFin, idVencida,
                    ids, empresa, idCorporativo, nomCorp, nomAdm, nomEmp, email,
                    idVigencia, bandera, idUsuario, token);

        } catch (Exception e) {
            LOGGER.error("WSCobranzaController.consultar: " + e.getMessage(), e);
            List<Object> err = new ArrayList<>();
            Map<String, Object> json = new HashMap<>();
            json.put("error",    true);
            json.put("mssError", e.getMessage());
            err.add(json);
            return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
        }
        if (list.isEmpty()) return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @PostMapping("/solicitar")
    public ResponseEntity<ResponseGralDTO> solicitar(
            @RequestBody Map<String, Object> body,
            @RequestHeader("authorization") String token) {
        try {
            int idEmpresa     = parseInt(body.get("idEmpresa"));
            int idSolTipo     = parseInt(body.get("idSolTipo"));
            String FecIni     = str(body.get("FecIni"));
            String FecFin     = str(body.get("FecFin"));
            int idVencida     = parseInt(body.get("idVencida"));
            List<Integer> ids = toIntList(body.get("IdsPerfil"));
            String empresa    = str(body.get("empresa"));
            int idCorporativo = parseInt(body.get("idCorporativo"));
            String nomCorp    = str(body.get("nomCorp"));
            String nomAdm     = str(body.get("nomAdm"));
            String nomEmp     = str(body.get("nomEmp"));
            String email      = str(body.get("email"));
            int idVigencia    = parseInt(body.get("idVigencia"));
            int bandera       = parseInt(body.get("bandera"));
            int idUsuario     = body.containsKey("idUsuario") ? parseInt(body.get("idUsuario")) : 0;

            ResponseGralDTO response = cobranzaService.solicitarAsync(idEmpresa, idSolTipo,
                    FecIni, FecFin, idVencida, ids, empresa, idCorporativo,
                    nomCorp, nomAdm, nomEmp, email, idVigencia, bandera,
                    idUsuario, token);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            LOGGER.error("WSCobranzaController.solicitar: " + e.getMessage(), e);
            ResponseGralDTO err = new ResponseGralDTO();
            err.status = false;
            err.messages = e.getMessage();
            return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Descarga un archivo del historial de Cobranza desde la misma ruta
     * fisica utilizada durante su generacion. El navegador no necesita que
     * DocumentoEmpresa este publicado como carpeta estatica de BeFlex.
     */
    @GetMapping("/descargar")
    public ResponseEntity<Resource> descargar(
            @RequestParam int idEmpresa,
            @RequestParam String archivo,
            @RequestHeader("authorization") String token) {
        try {
            File file = ReportePathUtil.archivoCobranza(
                    rutaBase, idEmpresa, archivo);
            if (!file.isFile()) {
                LOGGER.warn("No existe el archivo de Cobranza: "
                        + file.getAbsolutePath());
                return ResponseEntity.notFound().build();
            }

            InputStreamResource resource =
                    new InputStreamResource(new FileInputStream(file));
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(
                            MediaType.APPLICATION_OCTET_STREAM_VALUE))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"" + file.getName() + "\"")
                    .contentLength(file.length())
                    .body(resource);
        } catch (IllegalArgumentException | IllegalStateException e) {
            LOGGER.warn("Solicitud de descarga de Cobranza invalida: "
                    + e.getMessage());
            return ResponseEntity.badRequest().build();
        } catch (IOException e) {
            LOGGER.error("No fue posible descargar el archivo de Cobranza: "
                    + archivo, e);
            return ResponseEntity.status(
                    HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/getVigenciaActiva")
    public ResponseEntity<String> getVigenciaActiva(@RequestParam int idEmpresa,
            @RequestHeader("authorization") String token) {
        try {
            return ResponseEntity.ok(cobranzaService.getVigenciaActiva(idEmpresa) + "");
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return new ResponseEntity<>("-1", HttpStatus.NO_CONTENT);
        }
    }

    @GetMapping("/getFechaInicioVigencia")
    public String getFechaInicioVigencia(@RequestParam int vigencia,
            @RequestHeader("authorization") String token) {
        try { return cobranzaService.getFechaInicioVigencia(vigencia); } catch (Exception e) { return ""; }
    }

    @GetMapping("/getFechaFinalVigencia")
    public String getFechaFinalVigencia(@RequestParam int vigencia,
            @RequestHeader("authorization") String token) {
        try { return cobranzaService.getFechaFinalVigencia(vigencia); } catch (Exception e) { return ""; }
    }

    @GetMapping("/getFechaInicioEnrollment")
    public String getFechaInicioEnrollment(@RequestParam int vigencia,
            @RequestHeader("authorization") String token) {
        try { return cobranzaService.getFechaInicioEnrollment(vigencia); } catch (Exception e) { return ""; }
    }

    @GetMapping("/getConfiguracionEnvio")
    public ResponseEntity<String> getConfiguracionEnvio(@RequestParam int idCorporativo,
            @RequestHeader("authorization") String token) {
        try {
            return ResponseEntity.ok(cobranzaService.getConfiguracionEnvio(idCorporativo) + "");
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return new ResponseEntity<>("-1", HttpStatus.NO_CONTENT);
        }
    }

    @GetMapping("/getPeriodicidadDePagos")
    public ResponseEntity<List<Object>> getPeriodicidadDePagos(@RequestParam int idVigencia,
            @RequestHeader("authorization") String token) {
        try {
            List<Object> list = cobranzaService.getPeriodicidadDePagos(idVigencia);
            if (list.isEmpty()) return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            return ResponseEntity.ok(list);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            List<Object> err = new ArrayList<>();
            err.add(e.getMessage());
            return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private static int parseInt(Object val) {
        return val == null ? 0 : Integer.parseInt(val.toString());
    }

    private static String str(Object val) {
        return val == null ? "null" : val.toString();
    }

    private static boolean esConsultaDeArchivos(
            int idSolTipo, String fecIni, String fecFin, int idVencida,
            List<Integer> idsPerfil, String empresa, String nomCorp,
            String nomAdm, String nomEmp, String email) {
        return idSolTipo == -1
                && "null".equalsIgnoreCase(String.valueOf(fecIni))
                && "null".equalsIgnoreCase(String.valueOf(fecFin))
                && idVencida == -1
                && (idsPerfil == null || idsPerfil.isEmpty())
                && "null".equalsIgnoreCase(String.valueOf(empresa))
                && "null".equalsIgnoreCase(String.valueOf(nomCorp))
                && "null".equalsIgnoreCase(String.valueOf(nomAdm))
                && "null".equalsIgnoreCase(String.valueOf(nomEmp))
                && "null".equalsIgnoreCase(String.valueOf(email));
    }

    @SuppressWarnings("unchecked")
    private static List<Integer> toIntList(Object val) {
        List<Integer> result = new ArrayList<>();
        if (val instanceof List) {
            for (Object item : (List<?>) val) {
                try { result.add(Integer.parseInt(item.toString())); } catch (Exception ignored) {}
            }
        }
        return result;
    }
}
