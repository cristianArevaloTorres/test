USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

/*
  Ajuste complementario e idempotente para ambientes donde la instalacion
  anterior de BF3 ya fue ejecutada. No modifica ningun procedimiento B2.

  Regla: un reporte solicitado como Baja solo puede incluir empleados cuyo
  estado actual sea Baja (EMIdEstatus = 2).
*/

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @Definicion nvarchar(max),
            @Anterior nvarchar(500),
            @Corregido nvarchar(500),
            @Inicio int,
            @Procedimiento int;

    /* GMM BF3: el predicado forma parte del SQL dinamico del procedimiento. */
    SET @Definicion = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaGMM_BF3'));
    IF @Definicion IS NULL
        THROW 50001, 'No existe o no es legible dbo.ff_SabanaGMM_BF3.', 1;

    SET @Anterior = N'WHERE CS.CSidTipoSabana = 1 AND CS.CSPestana = 1 AND POS.POidempresa = ';
    SET @Corregido = N'WHERE CS.CSidTipoSabana = 1 AND CS.CSPestana = 1 AND EM.EMIdEstatus = 2 AND POS.POidempresa = ';

    IF CHARINDEX(@Corregido, @Definicion) = 0
    BEGIN
        IF CHARINDEX(@Anterior, @Definicion) = 0
            THROW 50002, 'No se encontro el bloque esperado de Bajas en ff_SabanaGMM_BF3.', 1;
        SET @Definicion = REPLACE(@Definicion, @Anterior, @Corregido);
        SET @Inicio = CHARINDEX(N'CREATE', UPPER(@Definicion));
        SET @Procedimiento = CHARINDEX(N'PROCEDURE', UPPER(@Definicion), @Inicio);
        IF @Inicio = 0 OR @Procedimiento = 0
            THROW 50007, 'No se pudo convertir ff_SabanaGMM_BF3 a ALTER PROCEDURE.', 1;
        SET @Definicion = STUFF(@Definicion, @Inicio,
                @Procedimiento - @Inicio + LEN(N'PROCEDURE'),
                N'ALTER PROCEDURE');
        EXEC sys.sp_executesql @Definicion;
    END;

    /* Vida BF3: se reemplazan ambos bloques de Bajas de la version instalada. */
    SET @Definicion = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaVIDA_BF3'));
    IF @Definicion IS NULL
        THROW 50003, 'No existe o no es legible dbo.ff_SabanaVIDA_BF3.', 1;

    SET @Anterior = N'WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND CS.CSidTipoSabana=2 AND poidempresa=@idEmpresa';
    SET @Corregido = N'WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND EM.EMIdEstatus=2 AND CS.CSidTipoSabana=2 AND poidempresa=@idEmpresa';

    IF CHARINDEX(@Corregido, @Definicion) = 0
    BEGIN
        IF CHARINDEX(@Anterior, @Definicion) = 0
            THROW 50004, 'No se encontro el bloque esperado de Bajas en ff_SabanaVIDA_BF3.', 1;
        SET @Definicion = REPLACE(@Definicion, @Anterior, @Corregido);
        SET @Inicio = CHARINDEX(N'CREATE', UPPER(@Definicion));
        SET @Procedimiento = CHARINDEX(N'PROCEDURE', UPPER(@Definicion), @Inicio);
        IF @Inicio = 0 OR @Procedimiento = 0
            THROW 50008, 'No se pudo convertir ff_SabanaVIDA_BF3 a ALTER PROCEDURE.', 1;
        SET @Definicion = STUFF(@Definicion, @Inicio,
                @Procedimiento - @Inicio + LEN(N'PROCEDURE'),
                N'ALTER PROCEDURE');
        EXEC sys.sp_executesql @Definicion;
    END;

    /* Opcionales BF3. */
    SET @Definicion = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaOPC_BF3'));
    IF @Definicion IS NULL
        THROW 50005, 'No existe o no es legible dbo.ff_SabanaOPC_BF3.', 1;

    SET @Anterior = N'WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND CS.CSidTipoSabana=3 AND poidempresa=@idEmpresa';
    SET @Corregido = N'WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND EM.EMIdEstatus=2 AND CS.CSidTipoSabana=3 AND poidempresa=@idEmpresa';

    IF CHARINDEX(@Corregido, @Definicion) = 0
    BEGIN
        IF CHARINDEX(@Anterior, @Definicion) = 0
            THROW 50006, 'No se encontro el bloque esperado de Bajas en ff_SabanaOPC_BF3.', 1;
        SET @Definicion = REPLACE(@Definicion, @Anterior, @Corregido);
        SET @Inicio = CHARINDEX(N'CREATE', UPPER(@Definicion));
        SET @Procedimiento = CHARINDEX(N'PROCEDURE', UPPER(@Definicion), @Inicio);
        IF @Inicio = 0 OR @Procedimiento = 0
            THROW 50009, 'No se pudo convertir ff_SabanaOPC_BF3 a ALTER PROCEDURE.', 1;
        SET @Definicion = STUFF(@Definicion, @Inicio,
                @Procedimiento - @Inicio + LEN(N'PROCEDURE'),
                N'ALTER PROCEDURE');
        EXEC sys.sp_executesql @Definicion;
    END;

    COMMIT TRANSACTION;
    SELECT N'OK' AS Estado,
           N'Los procedimientos BF3 de GMM, Vida y Opcionales filtran EMIdEstatus=2 en Bajas.' AS Resultado;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
