package com.lockton.rpt.util;

import java.io.File;
import java.util.Locale;

/** Construye y valida las rutas fisicas usadas por los reportes. */
public final class ReportePathUtil {

    private ReportePathUtil() {
    }

    public static File directorioCobranza(String rutaBase, int idEmpresa) {
        if (idEmpresa <= 0) {
            throw new IllegalArgumentException(
                    "El identificador de empresa debe ser mayor que cero.");
        }
        String base = validarRutaBase(rutaBase);
        return new File(new File(new File(base), String.valueOf(idEmpresa)),
                "Cobranza");
    }

    public static File archivoCobranza(
            String rutaBase, int idEmpresa, String nombreArchivo) {
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre del archivo de Cobranza es obligatorio.");
        }
        String nombre = nombreArchivo.trim();
        if (!nombre.equals(new File(nombre).getName())
                || nombre.contains("/") || nombre.contains("\\")
                || nombre.contains("\r") || nombre.contains("\n")
                || !(nombre.toLowerCase(Locale.ROOT).endsWith(".xls")
                        || nombre.toLowerCase(Locale.ROOT).endsWith(".xlsx"))) {
            throw new IllegalArgumentException(
                    "El nombre del archivo de Cobranza no es valido.");
        }
        return new File(directorioCobranza(rutaBase, idEmpresa),
                nombre);
    }

    static String validarRutaBase(String rutaBase) {
        if (rutaBase == null || rutaBase.trim().isEmpty()
                || "null".equalsIgnoreCase(rutaBase.trim())) {
            throw new IllegalStateException(
                    "No esta configurada la ruta fisica de reportes. "
                    + "Defina COBRANZA_RUTA_BASE o UPLOAD_FOLDER.");
        }
        return rutaBase.trim();
    }
}
