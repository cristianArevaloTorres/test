package com.lockton.rpt.controllers;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

class WSCobranzaControllerTest {

    @TempDir
    Path temporal;

    @Test
    void descargaDesdeLaMismaRutaFisicaDeGeneracion() throws Exception {
        Path base = temporal.resolve("DocumentoEmpresa");
        Path archivo = base.resolve("2185").resolve("Cobranza")
                .resolve("CobranzaPrueba.xlsx");
        Files.createDirectories(archivo.getParent());
        byte[] contenido = new byte[] {1, 2, 3, 4};
        Files.write(archivo, contenido);

        WSCobranzaController controller = new WSCobranzaController();
        ReflectionTestUtils.setField(controller, "rutaBase", base.toString());

        ResponseEntity<Resource> response = controller.descargar(
                2185, "CobranzaPrueba.xlsx", "token-prueba");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals((long) contenido.length,
                response.getHeaders().getContentLength());
        try (InputStream input = response.getBody().getInputStream()) {
            assertArrayEquals(contenido, input.readAllBytes());
        }
    }

    @Test
    void rechazaRecorridoDeRuta() {
        WSCobranzaController controller = new WSCobranzaController();
        ReflectionTestUtils.setField(controller, "rutaBase",
                temporal.toString());

        ResponseEntity<Resource> response = controller.descargar(
                2185, "../secreto.xlsx", "token-prueba");

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
}
