import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ReporteCobranzaService } from 'src/app/services/cobranza/reporte-cobranza.service';
import { EmpleadoService } from 'src/app/services/empleado.service';
import { GLOBAL } from 'src/app/services/global';
import swal from 'sweetalert2';
import { DatePipe } from '@angular/common';
import {EmpresaComboService} from 'src/app/services/empresas.service';
import { ConfSubgrupoService } from 'src/app/services/conf-subgrupo.service';
import { Sesion } from '../../../services/sesion.service';
import { SabanaBeneficiosService } from 'src/app/services/sabanas/sabana-beneficios.service';
import { MenusService } from 'src/app/services/menus.service';
import { BanwireAdmService } from 'src/app/services/banwireadm.service';
import { MensajeRptService } from 'src/app/shared/mensaje-rpt.service';

declare var $:any;
export class Perfil {
  public nomEmpresa: string;
  public idPerfil: string;
  public idEmpresa: string;
  public idCorporativo: string;

  constructor() {
    this.nomEmpresa = '';
    this.idPerfil = '';
    this.idEmpresa = '';
    this.idCorporativo = '';
  }
}

@Component({
  selector: 'app-cobranza',
  templateUrl: './cobranza.component.html',
  styleUrls: ['./cobranza.component.css'],
  providers: [
    NgModel,
    BanwireAdmService,
    DatePipe
  ]
})
export class CobranzaComponent implements OnInit, OnDestroy {

  // ================= Variables para el calendario ================= //
  public fechaInicial;
  public fechaFinal;
  public fechaMinFinal;
  public fechaIniEnrollment;
  public idVencida;
  public paramFechaInicial;
  public paramFechaFinal;
  public fechaInicialVigencia;
  public fechaFinalVigencia;
  public valida_empresa: boolean = true;

  public planesPagoConTarjeta: number[] = new Array();

  // ================= Variablepara Errores ================= //
  public error = {
    fechas: {
      error: false,
      fechasIguales: false,
      fechaMayorIni: false,
      fechaIniNUll: false,
      fechaIniMenorEnroll: false,
    },
    vigencia: false,
    confEnvio: false,
    fechasFin: {
      error: false,
      fechasIguales: false,
      fechaMayorIni: false,
      fechaFinMayorHoy: false,
      fechaFinNUll: false
    }

  };
  public valida = {
    fecha: false
  };
  // ================= Variables para Correo ================= //
  public datosEmail = {
    nombreEmp: '',
    nombreArchivo: '',
    nombreAdministrador: '',
    nombreCorp: '',
    fecha: '',
    correo: ''
  };
  // ================= Variables para Filtro ================= //
  public identity;
  public perfilSelecionado: Perfil;
  // ================= Historial de archivos ================= //
  public listArchivos;
  public archivoEnDescarga: string = '';

  public idCorp;
  public token;

  public solicitandoReporte: boolean = false;

  public vigencias: any [] = [];
  public vigencia;
  public globalVigencia;
  public fechaIniVig;
  public fechaFinVig;
  public fechaMin;

  // texto ayuda///
  public iconoAyuda;
  public textAyuda: string = 'Texto de ayuda Reporte de Cobranza.';
  public _url;
  public listEmpresa;
  public idEmpresa;

  constructor(
    // ================= Variables de Servicios ================= //
    private _cobranzaService: ReporteCobranzaService,
    private _empleadoService: EmpleadoService,
    private datePipe: DatePipe,
    private _confSubgrupo: ConfSubgrupoService,
    private _ComboEmpresaService: EmpresaComboService,
    private _sesion: Sesion,
    private _sabanaBService: SabanaBeneficiosService,
    private _bwadm: BanwireAdmService,
    private _menusService: MenusService,
    private mensajesRpt: MensajeRptService,
  ) {
    this.identity = this._empleadoService.getIdentity();
    this.fechaInicialVigencia = "";
    this.fechaFinalVigencia = "";
    this.idVencida = 1;
    this.perfilSelecionado = new Perfil();
    this._url = GLOBAL.url;
  }

  async ngOnInit() {
    this.token = this._empleadoService.getToken();
    if (!this.identity || !this.identity.idEmpresa) {
      this.errorUnauthorized();
      return;
    }

    this.planesPagoConTarjeta = await this.ObtenerPlanesPagoConTarjeta(this.identity.idEmpresa);
    this.cambiar_estado();
    this.globalVigencia= localStorage.getItem("Idvigencia") ? parseInt(localStorage.getItem("Idvigencia")): 0;

    /******************** Inicio validar sesion   *****************************/
    try {
        await this._sesion.comprobarSession(this.token);
        if (this.identity) {
          const isAdmin = localStorage.getItem('isAdmin') || null;
          if (isAdmin && parseInt(isAdmin,10) == 1) {
              this.cargarPerfil();
              this.getDatosCorreo();
              this.infoCorpo();
          } else {
            this.errorUnauthorized();
          }
        }
    } catch (error) {
      if (error == 'Unauthorized') {
        this.errorUnauthorized();
      }
    }
    /********************  fin validar sesion *********************************/

  }


  async cambiar_estado(){

    if(this.planesPagoConTarjeta.length == 0){

      this.valida_empresa = false;

    }else{

      this.valida_empresa = true;

    }

  }

  async ObtenerPlanesPagoConTarjeta(IdEmpresa): Promise<[]> {

    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this._url + `cotizador/obtenerplanespagocontarjeta?IdEmpresa=${IdEmpresa}`,
      "method": "GET",
      "headers": {
        "content-type": "application/json"
      },

      "processData": false,

    }

    try {

      const res = await $.ajax(settings)

        .done(function (response) {

          return response;

        })

        .fail((error) => {

          return [];

        });

      return res;

    } catch (error) {

      return [];

    }

  }
  
  async getEmpresa(d1){

    this.valida_empresa = true;
    
    var jsonData = {
      
      "d1": d1,
      "idEmpresa": this.identity.idCorporativo,
    
    }
    
    this.listEmpresa = await this._bwadm.getEmpresa(jsonData).toPromise();
    
    for (let i = 0; i < this.listEmpresa.length; i++) {
      
      let objeto = this.listEmpresa[i];
      
      for(let j = 0; j < objeto.length; j++) {
        
        if (objeto[j].idEmpresa === this.identity.idEmpresa) {
          
          let list: any = objeto[j];

          let Empresas: any = new Array(list);

          this.listEmpresa = new Array(Empresas);
        
        }
      
      }
    
    }
  
  }

  guardarEmpresa(v1){

    if(v1 === '0'){

      this.valida_empresa = true;

    }else{

      this.valida_empresa = false;

    }

    this.idEmpresa = v1;

    console.log(this.idEmpresa);

    
  }

  errorUnauthorized() {
    swal({
      title: '¡La sesión expiró!',
      html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
      type: 'error',
      confirmButtonText: 'Aceptar',
    });
    this.logout();
  }

  logout() {
    this._empleadoService.logout();
  }

  public async recargarLista(idVigencia) {

    let bandera = "0";

    if(this.planesPagoConTarjeta.length > 0){

      bandera = "1";

    }

    var jsonData = {

      "idEmpresa": this.perfilSelecionado.idEmpresa,
      "idSolTipo": -1,
      "FecIni": 'null',
      "FecFin": 'null',
      "idVencida": -1,
      "IdsPerfil": [],
      "empresa": 'null',
      "idCorporativo": -1,
      "nomCorp": 'null',
      "nomAdm": 'null',
      "nomEmp": 'null',
      "email": 'null',
      "idVigencia": idVigencia,
      "bandera" : bandera

    };
    
    try {
      const response = await this._cobranzaService.getListaDeArchivos(jsonData, this.token);
      this.listArchivos = [];
      if (response && response[0].error) {
        swal({
          title: '¡Error al recuperar la lista de reportes!',
          html: `<small clas="text-dark">${response[0].mssError}</small>`,
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
      } else {
        if (response && response != "empty") {
          for (let i = 0; i < response.length; i++) {
            if (response[i]) {
              this.listArchivos.push(response[i]);
            }
          }
        }
      }

      this.error.confEnvio = false;
      this.error.vigencia = false;
    } catch (error) {
      this.listArchivos = [];
      if (error) {
        swal.hideLoading();
        swal({
          title: '¡Error al recuperar la lista de reportes!',
          html: `<small clas="text-dark">${error.name}</small>`
          + `<BR/><small clas="text-dark">Estatus: ${error.status}</small>`
          + `<BR/><small clas="text-dark">${error.message}</small>`,
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
      }
    }
  }

  public descargarArchivo(archivo: string): void {
    const idEmpresa = Number(this.perfilSelecionado.idEmpresa);
    if (!archivo || !idEmpresa || this.archivoEnDescarga) {
      return;
    }

    this.archivoEnDescarga = archivo;
    this._cobranzaService.descargarArchivo(idEmpresa, archivo, this.token)
      .subscribe({
        next: (blob: Blob) => {
          const url = window.URL.createObjectURL(blob);
          const enlace = document.createElement('a');
          enlace.href = url;
          enlace.download = archivo;
          document.body.appendChild(enlace);
          enlace.click();
          enlace.remove();
          window.URL.revokeObjectURL(url);
          this.archivoEnDescarga = '';
        },
        error: error => {
          console.error('descargarArchivo => Error:', error);
          this.archivoEnDescarga = '';
          swal({
            title: 'No fue posible descargar el reporte.',
            html: '<small class="text-dark">El archivo no existe en la ruta configurada de API Reports o no se cuenta con acceso.</small>',
            type: 'error',
            confirmButtonText: 'Aceptar'
          });
        }
      });
  }

  async infoCorpo() {
    try {
      const response = await this._ComboEmpresaService.getInfoEmpresa(this.identity.idEmpresa);
      this.idCorp = response['EMidCorporativo'];
    } catch (error) {}
  }

  async cargarPerfil() {
    this.perfilSelecionado.nomEmpresa = this.identity.nomEmpresa.toLocaleUpperCase();
    this.perfilSelecionado.idPerfil = '';
    this.perfilSelecionado.idEmpresa = this.identity.idEmpresa;
    if (this.identity.idCorporativo != undefined){
      this.perfilSelecionado.idCorporativo = this.identity.idCorporativo;
    } else {
      this.perfilSelecionado.idCorporativo = this.idCorp;
    }
    // Perfil se reserva para una etapa posterior. El reporte actual no filtra
    // por perfil y por ello tampoco depende de cargar ese catálogo.
    this.getVigencias();
  }

  descargarExcel(): void {
    if (this.solicitandoReporte) {
      return;
    }
    if (this.validacionDeFechas()) {
      this.consulta();
    }
  }

  async consulta() {
    let cor = 0;
    let bandera = "0";
    let empresa = this.perfilSelecionado.idEmpresa;

    if (this.planesPagoConTarjeta.length > 0) {
      bandera = "1";
      empresa = this.idEmpresa;
    }

    if (this.identity.idCorporativo != undefined) {
      cor = this.identity.idCorporativo;
    } else {
      cor = this.idCorp;
    }

    const jsonData = {
      idEmpresa: empresa,
      // B2 genera Cobranza con tipo de solicitud 1. Mantener el mismo valor
      // evita que B3 consulte un universo funcional diferente.
      idSolTipo: 1,
      FecIni: this.paramFechaInicial.replace("T", " "),
      FecFin: this.paramFechaFinal.replace("T", " "),
      idVencida: 1,
      IdsPerfil: [],
      empresa: this.perfilSelecionado.nomEmpresa,
      idCorporativo: cor,
      nomCorp: this.datosEmail.nombreCorp,
      nomAdm: this.datosEmail.nombreAdministrador,
      nomEmp: this.datosEmail.nombreEmp,
      email: this.datosEmail.correo.trim(),
      idVigencia: this.vigencia,
      bandera: bandera,
      idUsuario: this.identity.id
    };

    this.solicitandoReporte = true;
    try {
      const response = await this._cobranzaService.solicitarCobranza(jsonData, this.token);
      if (response && response.status) {
        this.mensajesRpt.exito(response.messages);
      } else {
        this.mensajesRpt.error(response ? response.messages : 'Error al solicitar el reporte.');
      }
    } catch (error) {
      swal({
        title: '¡El archivo no se generó de manera correcta!',
        html: `<small class="text-dark">${error.name}</small>`
          + `<BR/><small class="text-dark">Estatus: ${error.status}</small>`
          + `<BR/><small class="text-dark">${error.message}</small>`,
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
    } finally {
      this.solicitandoReporte = false;
    }
  }

  public validacionDeFechas(): boolean {
    this.paramFechaInicial = this.fechaInicial;
    this.paramFechaFinal = this.fechaFinal;
    this.resetearErrorFechas();
    if (this.paramFechaInicial == null || this.paramFechaInicial == "") {
      this.error.fechas.error = true;
      this.error.fechas.fechaIniNUll = true;
      return false;
    }

    if (this.paramFechaFinal == null || this.paramFechaFinal == "") {
      this.error.fechasFin.error = true;
      this.error.fechasFin.fechaFinNUll = true;
      return false;
    }

    if ((this.paramFechaInicial != null && this.paramFechaInicial != "") && (this.paramFechaFinal != null && this.paramFechaFinal != "")) {
      if (this.paramFechaInicial < this.fechaIniEnrollment || this.paramFechaInicial < this.fechaMin) {
        this.error.fechas.error = true;
        this.error.fechas.fechaIniMenorEnroll = true;
        return false;
      }

      if (this.paramFechaInicial == this.paramFechaFinal) {  
        this.error.fechas.error = true;
        this.error.fechas.fechasIguales = true;
        this.error.fechasFin.fechasIguales = true;
        return false;
      }

      if (this.paramFechaInicial > this.paramFechaFinal) {    
        this.error.fechas.error = true;
        this.error.fechas.fechaMayorIni = true;
        this.error.fechasFin.fechaMayorIni = true;
        return false;
      }

      if (this.paramFechaFinal > this.fechaMinFinal) {
        this.error.fechasFin.error = true;
        this.error.fechasFin.fechaFinMayorHoy = true;
        return false;
      }
    }
    return true;
  }

  public resetearErrorFechas(): void {
    this.error.fechas.error = false;
    this.error.fechas.fechasIguales = false;
    this.error.fechas.fechaMayorIni = false;
    this.error.fechas.fechaIniNUll = false;
    this.error.fechas.fechaIniMenorEnroll = false;

    this.error.fechasFin.error = false;
    this.error.fechasFin.fechasIguales = false;
    this.error.fechasFin.fechaMayorIni = false;
    this.error.fechasFin.fechaFinNUll = false;
    this.error.fechasFin.fechaFinMayorHoy = false;
    this.valida.fecha = true;
  }

  public getVerFecha(nom): String {
    nom = nom.replace("Cobranza", "").replace(".xls", "");
    let fecha = `Fecha: ${nom.substring(6, 8)}/${nom.substring(4, 6)}/${nom.substring(0, 4)} `
      + `${nom.substring(8, 10)}:${nom.substring(10, 12)}`;
    return fecha;
  }

  public async validarVigenciaActiva() {

    try {
      const response = await this._cobranzaService.getVigenciaActiva(this.perfilSelecionado.idEmpresa, this.token);
      if (response == "-1") {
        this.error.vigencia = true;
      } else {
        this.idVencida = response;

        try {
          const fechInicio = await this._cobranzaService.getFechaInicioEnrollment(this.idVencida, this.token);
          this.fechaInicialVigencia = fechInicio;
          if (this.fechaInicialVigencia) {
            let date = new Date();
            this.fechaFinal = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
            this.fechaMinFinal = this.obtenerLimiteFechaFinal();
            date.setFullYear(this.fechaInicialVigencia.substring(0, 4));
            date.setMonth(this.fechaInicialVigencia.substring(5, 7));
            date.setDate(this.fechaInicialVigencia.substring(8, 10));
            this.fechaInicial = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
            this.fechaIniEnrollment = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
          }
        } catch (error) {
          this.fechaInicialVigencia = error.error.text;
          if (this.fechaInicialVigencia) {
            let date = new Date();
            this.fechaFinal = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
            this.fechaMinFinal = this.obtenerLimiteFechaFinal();
            date.setFullYear(this.fechaInicialVigencia.substring(0, 4));
            date.setMonth(this.fechaInicialVigencia.substring(5, 7) - 1);
            date.setDate(this.fechaInicialVigencia.substring(8, 10));
            this.fechaInicial = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
            this.fechaIniEnrollment = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
          }
        }
        
        try {
          const fechFinal = await this._cobranzaService.getFechaFinalVigencia(this.idVencida, this.token)
          this.fechaFinalVigencia = fechFinal;
        } catch (error) {
          this.fechaFinalVigencia = error.error.text;
        }
        this.fechaMinFinal = this.obtenerLimiteFechaFinal(this.fechaFinalVigencia);

        try {
          const res = await this._cobranzaService.getPeriodicidadDePagos(this.idVencida, this.token);
          let periodicidad = res[0][0];
          if (res && periodicidad) {
            if (periodicidad.PPCantidadPagos && periodicidad.PPCantidadPagos == "") {
              if (periodicidad.PPNombre && periodicidad.PPNombre == "") {
                this.error.confEnvio = true;
              }
            }
          } else {
            this.error.confEnvio = true;
          }
        } catch (error) {
          this.error.confEnvio = true;
        }

      }
    } catch (error) {
      if (error == "-1") {
        this.error.vigencia = true;
      }
    }
  }

  public async validarConfiguracionDeEnvio() {
    let cor = 0;
    if (this.perfilSelecionado.idCorporativo != undefined) {
      cor = this.identity.idCorporativo;
    } else {
      cor = this.idCorp;
    }
    try {
      const response = await this._cobranzaService.getConfiguracionEnvio(cor, this.token);
      if (response == "-1") {
        this.error.confEnvio = true;
      }
    } catch (error) {
      if (error == "-1") {
        this.error.confEnvio = true;
      }
    }
  }

  private async getDatosCorreo() {
    try {
      const datos: any = await this._empleadoService.getDatos(this.identity);
      if (this.identity.clave != '') {
        this.datosEmail.correo = datos.emCorreoElectronico;
        if (!this.datosEmail.correo || this.datosEmail.correo == '') {
          swal({
            title: '¡Aviso, no se cuenta con un correo electrónico registrado!',
            html: `<small clas="text-dark">Correo: "${this.datosEmail.correo}"</small>`,
            type: 'warning',
            confirmButtonText: 'Aceptar',
            timer: 3000
          });
        }
        this.datosEmail.nombreEmp = this.identity.nomEmpresa;
        try {
          const response = await this._confSubgrupo.getCorporativoXId(this.identity.idCorporativo);
          response[0].forEach(element => {
            this.datosEmail.nombreCorp = element.EMNombre;
          });
          this.datosEmail.nombreAdministrador = datos.emNombre1 + ' ' + datos.emApellidoPaterno + ' ' + datos.emApellidoMaterno;
          this.datosEmail.nombreArchivo = 'nuevo.xlxs';
          const f = new Date();
          this.datosEmail.fecha = f.getDate() + '/' + (f.getMonth() + 1) + '/' + f.getFullYear();
        } catch (error) {
          const errorMessage = <any>error;
          if (errorMessage != null) {
            swal({
              title: '¡Error al realizar reporte de sábana de beneficios!',
              html: `<small clas="text-dark">${errorMessage}</small>`,
              type: 'error',
              confirmButtonText: 'Aceptar',
            });
          }
        }
      }
    } catch (error) {}
  }

  ngOnDestroy() {
    swal.close();
    $('#modalAyuda').modal('hide');
    $('body').removeClass('modal-open');
    $('.modal-backdrop').remove();
  }

  /**
   * Permite consultar hasta el cierre del mes actual, sin exceder el fin de
   * la vigencia seleccionada.
   */
  private obtenerLimiteFechaFinal(fechaFinVigencia?: any): string {
    const ahora = new Date();
    const finMesActual = new Date(
      ahora.getFullYear(),
      ahora.getMonth() + 1,
      0,
      23,
      59,
      0,
      0
    );
    const limiteMes = this.datePipe.transform(finMesActual, 'yyyy-MM-ddTHH:mm');
    const limiteVigencia = fechaFinVigencia
      ? this.datePipe.transform(fechaFinVigencia, 'yyyy-MM-ddTHH:mm')
      : null;

    return limiteVigencia && limiteVigencia < limiteMes
      ? limiteVigencia
      : limiteMes;
  }

  async cambiarVigencia() {
    swal({
      title: 'Cargando vigencia...',
      html: '',
      timer: 4000,
      onOpen: () => {
        swal.showLoading();
      }
    });
    this.resetearErrorFechas();
    if(this.vigencia == "") {
      this.error.vigencia = true;
    }
    this.recargarLista(this.vigencia);
    try {
      const fecha = await this._sabanaBService.getEnrollment(this.vigencia, this.token);
      fecha[0].forEach(element => {
        const fin = this.datePipe.transform(element.VIVigenciaFin, 'yyyy-MM-ddTHH:mm');
        const date = new Date();
        const datoActual = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
        if (fin < datoActual) {
          this.fechaFinal = this.datePipe.transform(element.VIVigenciaFin, 'yyyy-MM-ddTHH:mm');
        } else {
          this.fechaFinal = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
        }
        this.fechaMinFinal = this.obtenerLimiteFechaFinal(element.VIVigenciaFin);
        this.fechaInicial = this.datePipe.transform(element.VIEnrollmentIni, 'yyyy-MM-ddTHH:mm');
        this.fechaMin = this.datePipe.transform(element.VIEnrollmentIni, 'yyyy-MM-ddTHH:mm');
      });
    } catch (error) {}
  }

  async getVigencias() {
    try {
      const res = await this._sabanaBService.getVigencias(this.identity.idEmpresa, this.token);
      this.vigencias = [];
      if (res && Array.isArray(res[0]) && res[0].length > 0) {
        res[0].forEach(element => {
          if (this.vigencias.length == 0) {
            this.vigencias.push(element);
          } else if (!this.vigencias.some(v => v.VIidVigencia === element.VIidVigencia)) {
            this.vigencias.push(element);
          }
        });
        if (this.globalVigencia == 0 ) {
          const response = await this._cobranzaService.getVigenciaActiva(this.identity.idEmpresa, this.token);
          if (response != "-1") {
            this.vigencia = response;
            this.recargarLista(this.vigencia);
            const fecha = await this._sabanaBService.getEnrollment(this.vigencia, this.token);
            fecha[0].forEach(element => {
              const fin = this.datePipe.transform(element.VIVigenciaFin, 'yyyy-MM-ddTHH:mm');
              const date = new Date();
              const datoActual = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
              if (fin < datoActual) {
                this.fechaFinal = this.datePipe.transform(element.VIVigenciaFin, 'yyyy-MM-ddTHH:mm');
              } else {
                this.fechaFinal = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
              }
              this.fechaMinFinal = this.obtenerLimiteFechaFinal(element.VIVigenciaFin);
              this.fechaInicial = this.datePipe.transform(element.VIEnrollmentIni, 'yyyy-MM-ddTHH:mm');
              this.fechaMin = this.datePipe.transform(element.VIEnrollmentIni, 'yyyy-MM-ddTHH:mm');
            });
          }
        } else {
          this.vigencia = this.globalVigencia;

          const fecha = await this._sabanaBService.getEnrollment(this.vigencia, this.token);
          fecha[0].forEach(element => {
            const fin = this.datePipe.transform(element.VIVigenciaFin, 'yyyy-MM-ddTHH:mm');
            const date = new Date();
            const datoActual = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
            if (fin < datoActual) {
              this.fechaFinal = this.datePipe.transform(element.VIVigenciaFin, 'yyyy-MM-ddTHH:mm');
            } else {
              this.fechaFinal = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
            }
            this.fechaMinFinal = this.obtenerLimiteFechaFinal(element.VIVigenciaFin);
            this.fechaInicial = this.datePipe.transform(element.VIEnrollmentIni, 'yyyy-MM-ddTHH:mm');
            this.fechaMin = this.datePipe.transform(element.VIEnrollmentIni, 'yyyy-MM-ddTHH:mm');
          });
        }
      } else {
        this.error.vigencia = true;
      }
    } catch (error) {
      this.error.vigencia = true;
      swal({
        title: 'No fue posible cargar las vigencias',
        text: 'Verifica la configuración de la empresa en base de datos y vuelve a intentar.',
        type: 'error',
        confirmButtonText: 'Aceptar'
      });
    }
  }

  async buscaAyuda() {
    const id = 559;
    try {
      const responseAyuda = await this._menusService.getAyudaMenu(id);
      const response: any = await this._menusService.getAyudaEmpresaId(this.identity.idEmpresa, responseAyuda['paNombreArchivo']);

      this.iconoAyuda = 1;
      const [ textoayuda ] = response;
      this.textAyuda = textoayuda.paTextoAyuda;
    } catch (error) {
      this.iconoAyuda = 0;
    }
  }

  public validacionDeFechasFin(): boolean {
    this.paramFechaInicial = this.fechaInicial;
    this.paramFechaFinal = this.fechaFinal;
    this.resetearErrorFechas();
    if (this.paramFechaInicial == null || this.paramFechaInicial == "") {
      this.error.fechas.error = true;
      this.error.fechas.fechaIniNUll = true;
      //this.paramFechaInicial = this.fechaIniEnrollment;
      return false;
    }

    if (this.paramFechaFinal == null || this.paramFechaFinal == "") {
      this.error.fechasFin.error = true;
      this.error.fechasFin.fechaFinNUll = true;
      //const date = new Date();
      //this.paramFechaFinal = this.datePipe.transform(date, 'yyyy-MM-dd');
      return false;
    }

    if ((this.paramFechaInicial != null && this.paramFechaInicial != "") && (this.paramFechaFinal != null && this.paramFechaFinal != "")) {
      if (this.paramFechaInicial < this.fechaIniEnrollment || this.paramFechaInicial < this.fechaMin) {
        this.error.fechas.error = true;
        this.error.fechas.fechaIniMenorEnroll = true;
        return false;
      }

      if (this.paramFechaInicial == this.paramFechaFinal) {
        this.error.fechasFin.error = true;
        this.error.fechas.fechasIguales = true;
        this.error.fechasFin.fechasIguales = true;
        return false;
      }

      if (this.paramFechaInicial > this.paramFechaFinal) {
        this.error.fechasFin.error = true;
        this.error.fechas.fechaMayorIni = true;
        this.error.fechasFin.fechaMayorIni = true;
        return false;
      }

      if (this.paramFechaFinal > this.fechaMinFinal) {
        this.error.fechasFin.error = true;
        this.error.fechasFin.fechaFinMayorHoy = true;
        return false;
      }
    }
    return true;
  }

}
