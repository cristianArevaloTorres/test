import { Component, OnInit } from '@angular/core';
import { SabanaBeneficiosService } from 'src/app/services/sabanas/sabana-beneficios.service';
import { EmpleadoService } from 'src/app/services/empleado.service';
import { DependienteService } from 'src/app/services/dependiente.service';
import { EmpresaComboService } from 'src/app/services/empresas.service';
import { ConfSubgrupoService } from 'src/app/services/conf-subgrupo.service';
import { GLOBAL } from 'src/app/services/global';
import swal from "sweetalert2";
import { ReporteCobranzaService } from 'src/app/services/cobranza/reporte-cobranza.service';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Bitacora } from '../../../services/bitacora.service'
import { MensajeRptService } from 'src/app/shared/mensaje-rpt.service';
declare var $: any;
@Component({
  selector: 'app-sabana-beneficios',
  templateUrl: './sabana-beneficios.component.html',
  styleUrls: ['./sabana-beneficios.component.css'],
  providers: [DependienteService, EmpleadoService, EmpresaComboService, DatePipe, Bitacora]
})
export class SabanaBeneficiosComponent implements OnInit {
  private token: string;
  public identityAdmin;
  public identity;
  public estado = "1";
  // ================= Variables para Vigencias ================= //
  public vigencias;
  public vigencia;
  public idvigencia;
  // ================= Variables para el calendario ================= //
  public fechaInicial;
  public fechaFinal;
  public fechaInicialVigencia;
  public fechaMinFinal;
  public fechaEnrollment;
  public fechaMax;
  public fechaFinalActual;
  public fechaIniActual;
  public fechaInicialMin;
  // ================= Variables para los CheckBox's ================= //
  public isAltas: boolean;
  public isBajas: boolean;
  public confidencial: boolean = false;
  public datosEmail = {
    nombreEmp: '',
    nombreArchivo: '',
    nombreAdministrador: '',
    nombreCorp: '',
    fecha: '',
    correo: ''
  };
  //================== Variables para listas ================ //
  public listArchivos: any[] = [];
  public ruta;
  public globalVigencia;
  // ================= Variablepara Errores ================= //
  public error = {
    error: false,
    fechas: {
      error: false,
      fechasIguales: false,
      fechaMayorIni: false,
      errorFechaInvalida: false,
      errorFechasVacias: false,
      errorFechasVaciasF: false,
      errorFechasF: false,
      errorMenorEnrroll: false
    },
    vigencia: false
  }
  public valida = {
    vigencia: false
  }
  public generandoReporte: boolean = false;

  //texto ayuda///
  public iconoAyuda;
  public textAyuda: string = "Texto de ayuda Reporte de Sabanas.";
  public _url;

  //Variables para registro bitacora:
  private idPagina = '402';
  private paginaActual;
  private ipPrivada;

  constructor(
    private _sabanaBService: SabanaBeneficiosService,
    private _empleadoService: EmpleadoService,
    private _cobranzaService: ReporteCobranzaService,
    private _confSubgrupo: ConfSubgrupoService,
    private datePipe: DatePipe,
    private _http: HttpClient,
    private _bitacora: Bitacora,
    public mensajesRpt: MensajeRptService,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.identity = this._empleadoService.getIdentity();
    this.vigencias = [];
    this.isAltas = true;
    this.isBajas = false;
    this.token = this._empleadoService.getToken();
    this.identityAdmin = JSON.parse(localStorage.getItem('identityAdmin'));
    this._url = GLOBAL.url;
  }

  async ngOnInit() {
    if (!this.identity || !this.identity.idEmpresa) {
      this.mostrarErrorPantalla('No fue posible identificar la empresa de la sesión. Inicia sesión nuevamente.');
      return;
    }
    this.globalVigencia = localStorage.getItem("Idvigencia") ? parseInt(localStorage.getItem("Idvigencia")) : 0;
    this.llenarVigencias();
    this.token = this._empleadoService.getToken();
    this.identityAdmin = JSON.parse(localStorage.getItem('identityAdmin'));
    this.ruta = `${GLOBAL.iconos}/DocumentoEmpresa/${this.identity.idEmpresa}/Sabana/`;
    this.getHistorial();
    this.getDatosCorreo();
    this.validarVigenciaActiva();
    try {
      const response = await this._cobranzaService.getVigenciaActiva(this.identity.idEmpresa, this.token);
      if (response == "-1") {
        this.error.vigencia = true;
      } else {
        var idVencida;
        if (this.globalVigencia == 0) {
          idVencida = response;
        } else {
          idVencida = this.globalVigencia;
        }
        try {
          const fechaEnroll = await this._sabanaBService.getFechaEnroll(idVencida, this.token);
          this.fechaEnrollment = this.normalizarFecha(fechaEnroll, false);
          this.fechaInicial = this.fechaEnrollment;
          this.fechaInicialMin = this.fechaEnrollment;
        } catch (error) {
          const aucfecha = error && error.error ? error.error.text : null;
          this.fechaEnrollment = this.normalizarFecha(aucfecha, false);
          this.fechaInicial = this.fechaEnrollment;
          this.fechaInicialMin = this.fechaEnrollment;
        }
        try {
          const enrollments = await this._sabanaBService.getEnrollment(idVencida, this.token);
          if (enrollments && Array.isArray(enrollments[0])) {
            enrollments[0].forEach((fecha: any) => {
            let date = new Date();
            this.fechaInicial = this.normalizarFecha(fecha.VIEnrollmentIni, false);
            this.fechaInicialMin = this.fechaInicial;
            this.fechaMinFinal = this.normalizarFecha(fecha.VIVigenciaFin, true);
            if (this.fechaFinal == null) {
              this.fechaFinal = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
            }
            });
          }
        } catch (error) {
          this.mostrarErrorPantalla('No fue posible recuperar las fechas de la vigencia seleccionada.');
        }
      }
    } catch (error) {
      if (error == "-1") {
        this.error.vigencia = true;
      }
    }
    if (this.identity) {
      this.paginaActual = this.document.location.href;
      let myIP = localStorage.getItem('myIP');
      if (!myIP)
        myIP = '0.0.0.0';
      this.ipPrivada = myIP;
      var parametroVitacora = {
        'idPagina': this.idPagina,
        'id': this.identity.id,
        'ipPrivada': encodeURIComponent(this.ipPrivada),
        'url': encodeURIComponent(this.paginaActual),
        'idEmpresa': this.identity.idEmpresa,
        'nombrePagina': 'sabana-beneficios.component.html'
      }
      await this._bitacora.registrarBitacora(parametroVitacora);
    }
  }

  ngOnDestroy() {
    $('#modalAyuda').modal('hide');
    $('body').removeClass('modal-open');//eliminamos la clase del body para poder hacer scroll
    $('.modal-backdrop').remove();//eliminamos el backdrop del modal
  }

  public async llenarVigencias() {
    try {
      const res = await this._sabanaBService.getVigencias(this.identity.idEmpresa, this.token);
      this.vigencias = [];
      if (res[0].length > 0) {
        res[0].forEach(vigencia => {
          if (this.vigencias.length == 0) {
            this.vigencias.push(vigencia);
          } else if (!this.vigencias.some(v => v.VIidVigencia === vigencia.VIidVigencia)) {
            this.vigencias.push(vigencia);
          }
        });
        if (this.globalVigencia == 0) {
          try {
            const response = await this._cobranzaService.getVigenciaActiva(this.identity.idEmpresa, this.token);
            if (response == "-1") {
              this.error.vigencia = true;
            } else {
              this.vigencia = this.vigencias[0].VIidVigencia == response ? response : this.vigencias[0].VIidVigencia;
            }
          } catch (error) {
          }
        } else {
          this.vigencia = this.globalVigencia;
        }
      }
    } catch (error) { }
  }

  private async getHistorial() {
    try {
      const response = await this._sabanaBService.getArchivo(this.identity.idEmpresa, this.token)
      if (response && response[0].error) {
        this.listArchivos = [];
      } else {
        this.listArchivos = [];
        this.listArchivos.push(...response);
      }
    } catch (error) {
    }
  }

  private async getDatosCorreo() {
    try {
      const datos: any = await this._empleadoService.getDatos(this.identity);
      if (this.identity.clave != "") {
        this.datosEmail.correo = datos.emCorreoElectronico;
        if (!this.datosEmail.correo || this.datosEmail.correo == "") {
          swal({
            title: '¡Aviso, no se cuenta con un correo electrónico registrado!',
            html: `<small clas="text-dark">Correo: "${this.datosEmail.correo}"</small>`,
            type: 'warning',
            confirmButtonText: 'Aceptar',
            timer: 3000
          });
        }
        this.datosEmail.nombreEmp = this.identity.nomEmpresa;
        try {
          const response = await this._confSubgrupo.getCorporativoXId(this.identity.idCorporativo);
          response[0].forEach(element => {
            this.datosEmail.nombreCorp = element.EMNombre;
          });
          this.datosEmail.nombreAdministrador = datos.emNombre1 + " " + datos.emApellidoPaterno + " " + datos.emApellidoMaterno;
          this.datosEmail.nombreArchivo = "nuevo.xlxs";
          var f = new Date();
          this.datosEmail.fecha = f.getDate() + "/" + (f.getMonth() + 1) + "/" + f.getFullYear();
        } catch (error) {
          var errorMessage = <any>error;
          if (errorMessage != null) {
            swal({
              title: '¡Atención!',
              html: `<small clas="text-dark">${errorMessage}</small>`,
              type: 'warning',
              confirmButtonText: 'Aceptar',
            });
          }
        }
      }
    } catch (error) { }
  }

  public async validarVigencia() {
    swal({
      title: 'Cargando vigencia...',
      html: '',
      timer: 4000,
      onOpen: () => {
        swal.showLoading();
      }
    });
    try {
      const enrollments = await this._sabanaBService.getEnrollment(this.vigencia, this.token);
      enrollments[0].forEach(fecha => {
        let date = new Date();
        let datoFinal = this.datePipe.transform(fecha.VIVigenciaFin, 'yyyy-MM-ddTHH:mm');
        let datoActual = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
        this.fechaInicial = this.datePipe.transform(fecha.VIEnrollmentIni, 'yyyy-MM-ddTHH:mm');
        this.fechaInicialMin = this.datePipe.transform(fecha.VIEnrollmentIni, 'yyyy-MM-ddTHH:mm');
        this.fechaMinFinal = this.datePipe.transform(
          new Date(fecha.VIVigenciaFin).setHours(23, 59, 0, 0),
          "yyyy-MM-ddTHH:mm");
        if (datoFinal < datoActual) {
          this.fechaFinal = this.datePipe.transform(fecha.VIVigenciaFin, 'yyyy-MM-ddTHH:mm');
        } else {
          this.fechaFinal = this.datePipe.transform(date, 'yyyy-MM-ddTHH:mm');
        }
      });
    } catch (error) { }
  }

  public altas(): void {
    this.isAltas = true;
    this.isBajas = false;
  }

  public bajas(): void {
    this.isBajas = true;
    this.isAltas = false;
  }

  /** Cambiar Alta/Baja no debe volver a consultar la vigencia ni sobrescribir fechas. */
  public cambiarEstado(): void {
    this.isAltas = this.estado === '1';
    this.isBajas = this.estado === '2';
    this.resetearErrorFechas();
  }

  private normalizarFecha(valor: any, finDia: boolean): string {
    if (valor == null || String(valor).trim() === '') {
      return null;
    }
    const fecha = String(valor).substring(0, 10);
    return fecha + (finDia ? 'T23:59' : 'T00:00');
  }

  private mostrarErrorPantalla(mensaje: string): void {
    swal({
      title: 'No fue posible cargar la configuración del reporte',
      text: mensaje,
      type: 'error',
      confirmButtonText: 'Aceptar'
    });
  }

  public resetearErrorFechas(): void {
    this.error.fechas.error = false;
    this.error.fechas.fechasIguales = false;
    this.error.fechas.fechaMayorIni = false;
    this.error.error = false;
    this.error.fechas.errorFechaInvalida = false;
    this.error.fechas.errorFechasVacias = false;
    this.error.fechas.errorFechasVaciasF = false;
    this.error.fechas.errorFechasF = false;
    this.error.fechas.errorMenorEnrroll = false;
  }

  public validarCampos(): boolean {
    this.resetearErrorFechas();
    if (this.vigencia == null || this.vigencia == "") {
      this.error.error = true;
      this.error.vigencia = true;
    }

    if (this.fechaInicial == null || this.fechaInicial == "") {
      var fecha;
      this.vigencias.forEach(element => {
        if (element.VIidVigencia == this.vigencia) {
          var fechas = element.lapso;
          var cadena = fechas.split('#');
          fecha = cadena[1];
        }
      });
      //this.fechaInicial = this.fechaInicialVigencia;
      this.fechaInicial = this.datePipe.transform(this.fechaEnrollment, 'yyyy-MM-ddTHH:mm');
    }

    if (this.fechaFinal == null || this.fechaFinal == "") {
      var fecha;
      this.vigencias.forEach(element => {
        if (element.VIidVigencia == this.vigencia) {
          var fechas = element.lapso;
          var cadena = fechas.split('#');
          fecha = cadena[2];
        }
      });
      this.fechaFinal = this.datePipe.transform(fecha, 'yyyy-MM-ddTHH:mm');
      /*const date = new Date();
      this.fechaFinal = this.datePipe.transform(date, 'yyyy-MM-dd');*/
    }

    if (this.fechaInicial == this.fechaFinal) {
      this.error.error = true;
      this.error.fechas.error = true;
      this.error.fechas.fechasIguales = true;
      return false;
    }

    if (this.fechaInicial > this.fechaFinal) {
      this.error.error = true;
      this.error.fechas.error = true;
      this.error.fechas.fechaMayorIni = true;
      return false;
    }

    if (this.error.error) {
      return false;
    } else {
      return true;
    }
  }

  public async validarVigenciaActiva() {
    try {
      const response = await this._cobranzaService.getVigenciaActiva(this.identity.idEmpresa, this.token);
      if (response == "-1") {
        this.error.vigencia = true;
      } else {
        // getFechaInicioVigencia(idVigencia)
        var idVencida;
        if (this.globalVigencia == 0) {
          idVencida = response;
        } else {
          idVencida = this.globalVigencia;
        }
        try {
          const fechInicio = await this._cobranzaService.getFechaInicioVigencia(idVencida, this.token);
          this.fechaInicialVigencia = fechInicio;
        } catch (error) {
          this.fechaInicialVigencia = error.error.text;
        }
      }
    } catch (error) {
      if (error == "-1") {
        this.error.vigencia = true;
      }
    }
  }

  public async generarReporte() {
    if (this.generandoReporte) {
      return;
    }
    if (this.validarFechas()) {
      if (this.validarCampos()) {
        let estatus = parseInt(this.estado);
        this.generandoReporte = true;
        try {
          const response = await this._sabanaBService.generarReporte(this.identity.id, this.identity.idEmpresa, this.fechaInicial + ":00", this.fechaFinal + ":00", estatus, this.vigencia, this.datosEmail.nombreCorp, this.datosEmail.nombreAdministrador, this.datosEmail.nombreEmp, this.datosEmail.correo, this.confidencial, this.token);
           if (response.status)
              this.mensajesRpt.exito(response.messages);
            else
              this.mensajesRpt.warning(response.messages);
        } catch (error) {
          const mensaje = error && error.error && error.error.messages
            ? error.error.messages
            : 'No fue posible solicitar el reporte. Verifica la configuración y vuelve a intentar.';
          this.mensajesRpt.error(mensaje);
        } finally {
          this.generandoReporte = false;
        }
      }
    } else {
      swal({
        title: 'Cuidado',
        text: 'Revisa que ambos campos de fecha sean válidos.',
        type: 'warning',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  validarFinal(event) {
    if (event.length > 0) {
      this.resetearErrorFechas();
      let horaFinActual = this.datePipe.transform(this.fechaFinalActual, "HH:mm");
      let horaFin = this.datePipe.transform(event, "HH:mm");
      let fecha = new Date();
      if (event > this.fechaMinFinal) {
      } else {
        if (horaFin == horaFinActual)
          this.fechaFinal = this.datePipe.transform(new Date(event).setHours(23, 59, 0, 0), "yyyy-MM-ddTHH:mm");
        else
          this.fechaFinal = event;
      }
      this.fechaFinalActual = this.fechaFinal;

      let resultado = this.validarFechas2(true);
    } else {
      this.resetearErrorFechas();
      let resultado = this.validarFechas2(true);
    }
  }

  validarInicio(event) {
    let horaIniActual, horaFin;

    if (event.length > 0) {
      this.resetearErrorFechas();
      horaIniActual = this.datePipe.transform(this.fechaIniActual, "HH:mm");
      horaFin = this.datePipe.transform(event, "HH:mm");
      if (horaFin == horaIniActual) {
        this.fechaInicial = this.datePipe.transform(new Date(event).setHours(0, 0, 0, 0), "yyyy-MM-ddTHH:mm");
      } else {
        this.fechaInicial = event;
      }

      this.fechaIniActual = this.fechaInicial;
      let resultado = this.validarFechas2(true);
    } else {
      this.resetearErrorFechas();
      let resultado = this.validarFechas2(true);
    }

  }

  /*Metodo para validar fechas*/
  private validarFechas2(resultado) {
    if (this.fechaInicial == null || this.fechaInicial == "") {
      resultado = false;
      this.error.error = true;
      this.error.fechas.error = true;
      this.error.fechas.errorFechaInvalida = true;
    }
    if (this.fechaFinal == null || this.fechaFinal == "") {
      resultado = false;
      this.error.error = true;
      this.error.fechas.errorFechasF = true;
      this.error.fechas.errorFechaInvalida = true;
    }
    if (this.fechaInicial != "" && this.fechaFinal != "") {
      if (this.fechaInicial == this.fechaFinal) {
        resultado = false;
        this.error.error = true;
        this.error.fechas.error = true;
        this.error.fechas.fechasIguales = true;
      }
      if (this.fechaInicial > this.fechaFinal) {
        resultado = false;
        this.error.error = true;
        this.error.fechas.error = true;
        this.error.fechas.fechaMayorIni = true;
      }
      if (this.fechaInicial < this.fechaInicialMin) {
        resultado = false;
        this.error.error = true;
        this.error.fechas.error = true;
        this.error.fechas.errorMenorEnrroll = true;
      }
    }
    if (this.fechaInicial == "") {
      resultado = false;
      this.error.error = true;
      this.error.fechas.error = true;
      this.error.fechas.errorFechasVacias = true;
    }
    if (this.fechaFinal == "") {
      resultado = false;
      this.error.error = true;
      this.error.fechas.errorFechasF = true;
      this.error.fechas.errorFechasVaciasF = true;
    }

    return resultado;
  }

  validarFechas() {
    let validation: boolean;
    if (this.fechaInicial == "") {
      this.fechaInicial = null;
    }
    if (this.fechaFinal == "") {
      this.fechaFinal = null;
    }

    if ((this.fechaInicial == null && this.fechaFinal != null) || (this.fechaFinal == null && this.fechaInicial != null)) {
      validation = false;
    } else if (this.fechaInicial != null && this.fechaFinal != null) {
      if (this.fechaInicial < this.fechaInicialMin)
        validation = false;
      else
        validation = Date.parse(this.fechaFinal) > Date.parse(this.fechaInicial);
    } else {
      validation = true;
    }

    return validation;
  }

  buscaAyuda() {
    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    this._http
      .get(this._url + 'ayuda/menu/578', { headers: getHeaders })
      .subscribe(
        response => {
          const pagina = response;
          this._http.get(
            this._url +
            'ayuda/empresa/' +
            this.identity.idEmpresa +
            '/pagina?pagina=' +
            pagina['paNombreArchivo'],
            { headers: getHeaders }
          )
            .subscribe(
              response => {
                this.iconoAyuda = 1;
                const textoayuda = response;
                this.textAyuda = textoayuda[0].paTextoAyuda;

              },
              error => {
                const errorMessage = <any>error;
                this.iconoAyuda = 0;
              }
            );
        },
        error => {
          const errorMessage = <any>error;
          console.log("No se encontro texto de ayuda.");
        }
      );
  }

}
