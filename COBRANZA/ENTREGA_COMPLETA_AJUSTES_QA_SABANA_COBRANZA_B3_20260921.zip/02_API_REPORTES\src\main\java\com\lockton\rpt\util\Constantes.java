package com.lockton.rpt.util;

import java.io.File;

public class Constantes {
/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>BD_SERVER </p>
	 * <p><b>Valor: </b>"serverName":"port";databaseName="databaseName" </p>
	 */
	public static final String BD_SERVER = System.getenv("BD_SERVER");
	
	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>BD_USER </p>
	 * <p><b>Valor: </b>"userBD" </p>
	 */
	public static final String BD_USER = System.getenv("BD_USER");
	
	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>BD_PASSWORD </p>
	 * <p><b>Valor: </b>"passwordBD" </p>
	 */
	public static final String BD_PASSWORD = System.getenv("BD_PASSWORD");
	
	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>UPLOAD_FOLDER </p>
	 * <p><b>Valor: </b>ruta donde se almacenaran los archivos (por ejemplo, "C:/uploadedFiles/").</p>
	 */
	public static final String UPLOAD_FOLDER = System.getenv("UPLOAD_FOLDER");
	
	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>XSL_SOLICITUD </p>
	 * <p><b>Valor: </b>ruta donde estan almacenados los archivos xsl que se necesitan para los formato pdf. </p>
	 */
	public static final String XSL_SOLICITUD = System.getenv("XSL_SOLICITUD");
	
	/**
	 * <p>Valor asignado compuesto de la constante UPLOAD_FOLDER+"/DocumentoEmpresa"</p>
	 */
	public static final String DOCUMENTO_EMPRESA = rutaDocumentoEmpresa(UPLOAD_FOLDER);

	private static String rutaDocumentoEmpresa(String uploadFolder) {
		if (uploadFolder == null || uploadFolder.trim().isEmpty()) {
			return null;
		}
		return new File(uploadFolder.trim(), "DocumentoEmpresa").getPath()
				+ File.separator;
	}
	public static final String XSL_PREFIJO1 = "style.xsl";
	public static final String XSL_PREFIJO2 = "deloitte.xsl";
        
        public static final String XSL_PREFIJO5 = "comercialM.xsl";

	public static final String XSL_PREFIJO4 = "segurosMonterrey.xsl";
	public static final String XSL_PREFIJO0 = "ch.xsl";
        public static final String XSL_PREFIJO6 = "Scotiabank.xsl";
        public static final String AUTHORIZATION_PATH = System.getenv("AUTHORIZATION_PATH") + "/secure";
//	public static final String AUTORIZACION_PATH = "https://www.demolockton.com.mx:3000/secure";
//	public static final String AUTORIZACION_PATH = "https://www.belockton.com:3000/secure";
	//public static final String AUTORIZACION_PATH = "http://localhost:3200/secure";
	
	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>SEND_MAIL </p>
	 * <p><b>Valor: </b>ruta donde se envían correos electrónicos.</p>
	 */
	public static final String SEND_MAIL = System.getenv("SMTP_RELAY") + "/WSBeFlex/beflex/empleados/EnviarCorreoMasivo";
	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>OPERA_USER </p>
	 * <p><b>Valor: </b>usuario para acceso a Opera.</p>
	 */
	public static final String OPERA_USER = System.getenv("OPERA_USER");
	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>OPERA_PASSWORD </p>
	 * <p><b>Valor: </b>password para acceso a Opera.</p>
	 */
	public static final String OPERA_PASSWORD = System.getenv("OPERA_PASSWORD");
        
        /**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>SEC_ADM_USER </p>
	 * <p><b>Valor: </b>usuario para acceso a la api de segurida de lockton.</p>
	 */
        public static final String SEC_ADM_USER = System.getenv("SEC_ADM_USER");
        
        /**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>SEC_ADM_PASS </p>
	 * <p><b>Valor: </b>password para acceso a la api de seguridad de lockton.</p>
	 */
        public static final String SEC_ADM_PASS = System.getenv("SEC_ADM_PASS");
        
        /**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>SEC_ADM_GUID </p>
	 * <p><b>Valor: </b>identificador de la aplicación para el usuario de la api de seguridad de lockton.</p>
	 */
        public static final String SEC_ADM_GUID = System.getenv("SEC_ADM_GUID");
        
        /**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>BEF_APP_GUID </p>
	 * <p><b>Valor: </b>Identificacion de la aplicación de beflex para el manejo de los MFA.</p>
	 */
        public static final String BEF_APP_GUID = System.getenv("BEF_APP_GUID");
        
        /**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>SEC_API_URL </p>
	 * <p><b>Valor: </b>Url de la api de seguridad de lockton.</p>
	 */
        public static final String SEC_API_URL = System.getenv("SEC_API_URL");

	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>CORREO_MAIL</p>
	 * <p><b>Valor: </b>Correo remitente</p>
	 */
	public static final String CORREO_MAIL = System.getenv("CORREO_MAIL");

	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>PASS_MAIL</p>
	 * <p><b>Valor: </b>PW del correo remitente</p>
	 */
	public static final String PASS_MAIL = System.getenv("PASS_MAIL");

	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>HOST_MAIL_OUTLOOK</p>
	 * <p><b>Valor: </b>Host para envio de correo, en este caso enfocado a Outlook</p>
	 */
	public static final String HOST_MAIL = System.getenv("HOST_MAIL");

	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>PORT_MAIL_OUTLOOK</p>
	 * <p><b>Valor: </b>Host para envio de correo, en este caso enfocado a Outlook</p>
	 */
	public static final String PORT_MAIL = System.getenv("PORT_MAIL");

	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>KEY_AES256</p>
	 * <p><b>Valor: </b>Llave para Encryptar y Desencryptar para Login</p>
	 */
	public static final String KEY_AES256 = "2b7e151628aed2a6abf7158809cf4f3c";

	/**
	 * <p>Valor asignado desde una variable de entorno.</p>
	 * <p><b>Variable: </b>KEY_IV</p>
	 * <p><b>Valor: </b>Llave para Encryptar y Desencryptar para Login</p>
	 */
	public static final String KEY_IV = "000102030405060708090a0b0c0d0e0f";

	/**
	 * <p>Valor asignado para el limite de llamadas.</p>
	 * <p><b>Variable: </b>REQUEST_LIMIT</p>
	 * <p><b>Valor: </b>Numero de veces que se puede llamar una api</p>
	 */
	public static final String REQUEST_LIMIT = "10";

	/**
	 * <p>Valor asignado para el Tiempo que tiene que esperar para poder hacer otro llamado.</p>
	 * <p><b>Variable: </b>MINUTE_LIMIT</p>
	 * <p><b>Valor: </b>Numero de Minutos que tiene que esperar para hacer otro llamado.</p>
	 */
	public static final String MINUTE_LIMIT = "1";

	/**
	 *  <p>Valores que quedan excluidos al consultar todos los valores de configuracion para el proceso de pago con tarjeta</p>
	 *  <p><b>Variable: </b>CONFIG_VALUES_EXCEPT</p>
	 */
	public static String[] CONFIG_VALUES_EXCEPT = {"private_key"};
}
