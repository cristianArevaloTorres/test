package com.lockton.rpt.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;

import org.junit.jupiter.api.Test;

class ReportePathUtilTest {

    @Test
    void construyeUnaSolaRutaFisicaPorEmpresa() {
        File archivo = ReportePathUtil.archivoCobranza(
                "C:/reportes/DocumentoEmpresa", 2185, "Cobranza.xlsx");

        assertEquals("Cobranza.xlsx", archivo.getName());
        assertEquals("Cobranza", archivo.getParentFile().getName());
        assertEquals("2185", archivo.getParentFile().getParentFile().getName());
    }

    @Test
    void rechazaConfiguracionDeRutaAusente() {
        assertThrows(IllegalStateException.class,
                () -> ReportePathUtil.directorioCobranza(null, 2185));
        assertThrows(IllegalStateException.class,
                () -> ReportePathUtil.directorioCobranza("null", 2185));
    }

    @Test
    void rechazaNombresQueIntentanSalirDeCobranza() {
        assertThrows(IllegalArgumentException.class,
                () -> ReportePathUtil.archivoCobranza(
                        "C:/reportes/DocumentoEmpresa", 2185,
                        "../secreto.xlsx"));
        assertThrows(IllegalArgumentException.class,
                () -> ReportePathUtil.archivoCobranza(
                        "C:/reportes/DocumentoEmpresa", 2185,
                        "otro.pdf"));
    }

    @Test
    void rechazaEmpresaInvalida() {
        assertThrows(IllegalArgumentException.class,
                () -> ReportePathUtil.directorioCobranza(
                        "C:/reportes/DocumentoEmpresa", 0));
    }
}
