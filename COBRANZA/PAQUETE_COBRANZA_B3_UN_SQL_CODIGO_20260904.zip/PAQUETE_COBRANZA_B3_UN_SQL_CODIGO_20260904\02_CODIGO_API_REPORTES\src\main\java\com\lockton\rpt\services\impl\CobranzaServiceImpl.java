package com.lockton.rpt.services.impl;

import com.lockton.rpt.dao.JDBCCobranza;
import com.lockton.rpt.enumeradores.EstatusReporte;
import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.models.entities.ControlReporteGen;
import com.lockton.rpt.repositories.CtlRptGenRepository;
import com.lockton.rpt.services.CobranzaService;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CobranzaServiceImpl implements CobranzaService {

    private static final Log LOGGER = LogFactory.getLog(CobranzaServiceImpl.class);

    // catReportesSPId para ff_Cobranza_v2
    private static final int REPORTE_ID_COBRANZA = 11;

    @Autowired
    private JDBCCobranza jdbcCobranza;

    @Autowired
    private CtlRptGenRepository ctlRptGenRepository;

    @Value("${cobranza.ruta.base}")
    private String rutaBase;

    private void debug(String etapa, String detalle) {
        LOGGER.info("COBRANZA-DEBUG " + etapa + " " + detalle);
    }

    @Override
    public List<Object> consultaCobranza(
            int idEmpresa, int idSolTipo, String FecIni, String FecFin,
            int idVencida, List<Integer> IdsPerfil, String empresa, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email,
            int idVigencia, int bandera, int idUsuario) {

        Long rptId = registrarSeguimiento(idUsuario, idEmpresa);
        try {
            List<Object> result = jdbcCobranza.consultaCobranza(
                    idEmpresa, idSolTipo, FecIni, FecFin, idVencida, IdsPerfil,
                    empresa, idCorporativo, nomCorp, nomAdm, nomEmp, email,
                    idVigencia, bandera, rutaBase);

            String ruta = extraerRuta(result, idEmpresa);
            actualizarSeguimientoPorResultado(rptId, result, ruta);
            return result;
        } catch (Exception e) {
            LOGGER.error("CobranzaServiceImpl.consultaCobranza: " + e.getMessage(), e);
            actualizarSeguimiento(rptId, EstatusReporte.ERROR, e.getMessage(), "");
            throw e;
        }
    }

    @Override
    public ResponseGralDTO solicitarAsync(
            int idEmpresa, int idSolTipo, String FecIni, String FecFin,
            int idVencida, List<Integer> IdsPerfil, String empresa, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email,
            int idVigencia, int bandera, int idUsuario) {

        ResponseGralDTO response = new ResponseGralDTO();
        Long rptId = registrarSeguimiento(idUsuario, idEmpresa);
        if (rptId == 0L) {
            debug("cobranza_solicitar_error", "No se pudo registrar la solicitud idEmpresa=" + idEmpresa);
            response.status = false;
            response.messages = "No se pudo registrar la solicitud.";
            return response;
        }

        debug("cobranza_solicitar_inicio",
            "rptId=" + rptId + " idEmpresa=" + idEmpresa + " idVigencia=" + idVigencia
            + " FecIni=" + FecIni + " FecFin=" + FecFin + " bandera=" + bandera
            + " perfiles=" + IdsPerfil);

        CompletableFuture.runAsync(() -> {
            try {
                debug("cobranza_sp_inicio", "rptId=" + rptId + " thread=" + Thread.currentThread().getName());
                List<Object> result = jdbcCobranza.consultaCobranza(
                        idEmpresa, idSolTipo, FecIni, FecFin, idVencida, IdsPerfil,
                        empresa, idCorporativo, nomCorp, nomAdm, nomEmp, email,
                        idVigencia, bandera, rutaBase);
                String ruta = extraerRuta(result, idEmpresa);
                boolean esError = esRespuestaError(result);
                if (esError) {
                    String msg = mensajeRespuesta(result);
                    EstatusReporte estatus = esRespuestaSinDatos(result)
                            ? EstatusReporte.SIN_DATOS : EstatusReporte.ERROR;
                    debug(estatus == EstatusReporte.SIN_DATOS
                            ? "cobranza_sp_sin_datos" : "cobranza_sp_error",
                            "rptId=" + rptId + " msg=" + msg);
                    actualizarSeguimiento(rptId, estatus, msg, "");
                } else if (ruta.isEmpty()) {
                    String msg = "El reporte termino sin devolver la ruta del archivo.";
                    debug("cobranza_sp_error", "rptId=" + rptId + " msg=" + msg);
                    actualizarSeguimiento(rptId, EstatusReporte.ERROR, msg, "");
                } else {
                    debug("cobranza_sp_ok", "rptId=" + rptId + " ruta=" + ruta);
                    actualizarSeguimiento(rptId, EstatusReporte.DISPONIBLE, "", ruta);
                }
            } catch (Exception e) {
                LOGGER.error("CobranzaServiceImpl.solicitarAsync: " + e.getMessage(), e);
                debug("cobranza_sp_error", "rptId=" + rptId + " error=" + e.getMessage());
                actualizarSeguimiento(rptId, EstatusReporte.ERROR, e.getMessage(), "");
            }
        });

        response.status = true;
        response.messages = "Solicitud generada con éxito con Id:" + rptId;
        return response;
    }

    @Override public int    getVigenciaActiva(int idEmpresa)       { return jdbcCobranza.getVigenciaActiva(idEmpresa); }
    @Override public String getFechaInicioVigencia(int vigencia)    { return jdbcCobranza.getFechaInicioVigencia(vigencia); }
    @Override public String getFechaFinalVigencia(int vigencia)     { return jdbcCobranza.getFechaFinalVigencia(vigencia); }
    @Override public String getFechaInicioEnrollment(int vigencia)  { return jdbcCobranza.getFechaInicioEnrollment(vigencia); }
    @Override public int    getConfiguracionEnvio(int idCorporativo){ return jdbcCobranza.getPeriocidad(idCorporativo); }
    @Override public List<Object> getPeriodicidadDePagos(int v)     { return jdbcCobranza.getPeriodicidadDePagos(v); }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private Long registrarSeguimiento(int idUsuario, int idEmpresa) {
        try {
            ControlReporteGen ent = new ControlReporteGen();
            ent.setCRptIdUsuarioSolicitud(idUsuario);
            ent.setCRptIdReporte(REPORTE_ID_COBRANZA);
            ent.setCRptFechaSolicitud(new Date());
            ent.setCRptIdEmpresa(idEmpresa);
            ent.setCRptRuta("");
            ent.setCRptIdEstatus(EstatusReporte.EN_PROCESO.getNumVal());
            ent.setCRptUsuarioAdd(idUsuario);
            ent.setCRptFechaAdd(new Date());
            ent.setCRptParams("");
            ctlRptGenRepository.save(ent);
            return ent.getCRptId();
        } catch (Exception e) {
            LOGGER.warn("No se pudo registrar seguimiento: " + e.getMessage());
            return 0L;
        }
    }

    private void actualizarSeguimiento(Long id, EstatusReporte estatus, String obs, String ruta) {
        if (id == null || id == 0) return;
        try {
            ctlRptGenRepository.findById(id).ifPresent(ent -> {
                ent.setCRptFechaGeneracion(new Date());
                ent.setCRptIdEstatus(estatus.getNumVal());
                ent.setCRptObservaciones(obs != null && obs.length() > 500 ? obs.substring(0, 500) : obs);
                if (ruta != null && !ruta.isEmpty()) ent.setCRptRuta(ruta);
                ctlRptGenRepository.save(ent);
            });
        } catch (Exception e) {
            LOGGER.warn("No se pudo actualizar seguimiento: " + e.getMessage());
        }
    }

    private void actualizarSeguimientoPorResultado(
            Long rptId, List<Object> result, String ruta) {
        if (esRespuestaError(result)) {
            actualizarSeguimiento(rptId,
                    esRespuestaSinDatos(result)
                            ? EstatusReporte.SIN_DATOS : EstatusReporte.ERROR,
                    mensajeRespuesta(result), "");
        } else if (ruta == null || ruta.isEmpty()) {
            actualizarSeguimiento(rptId, EstatusReporte.ERROR,
                    "El reporte termino sin devolver la ruta del archivo.", "");
        } else {
            actualizarSeguimiento(rptId, EstatusReporte.DISPONIBLE, "", ruta);
        }
    }

    static boolean esRespuestaError(List<Object> result) {
        return result != null && !result.isEmpty()
                && result.get(0) instanceof Map
                && Boolean.TRUE.equals(
                        ((Map<?, ?>) result.get(0)).get("error"));
    }

    static boolean esRespuestaSinDatos(List<Object> result) {
        if (!esRespuestaError(result)) return false;
        Map<?, ?> error = (Map<?, ?>) result.get(0);
        if (Boolean.TRUE.equals(error.get("sinDatos"))) return true;
        String mensaje = String.valueOf(error.get("mssError"));
        return mensaje.toLowerCase(java.util.Locale.ROOT)
                .contains("no se encontraron coincidencias");
    }

    private static String mensajeRespuesta(List<Object> result) {
        if (!esRespuestaError(result)) return "Error desconocido";
        Object mensaje = ((Map<?, ?>) result.get(0)).get("mssError");
        return mensaje == null ? "Error desconocido" : String.valueOf(mensaje);
    }

    /** Extracts the full file path from the List<Object> returned by consultaCobranza. */
    @SuppressWarnings("unchecked")
    private String extraerRuta(List<Object> result, int idEmpresa) {
        try {
            if (result == null || result.isEmpty()) return "";
            Object first = result.get(0);
            if (first instanceof String) {
                return rutaBase + idEmpresa + "/Cobranza/" + first;
            }
            // result may be a List<String> wrapped in an outer list
            if (first instanceof List) {
                List<?> inner = (List<?>) first;
                if (!inner.isEmpty() && inner.get(0) instanceof String) {
                    return rutaBase + idEmpresa + "/Cobranza/" + inner.get(0);
                }
            }
            // result may be a Map with error key – not a file
            if (first instanceof Map) {
                Map<?, ?> m = (Map<?, ?>) first;
                if (Boolean.TRUE.equals(m.get("error"))) return "";
            }
        } catch (Exception ignore) {}
        return "";
    }
}
