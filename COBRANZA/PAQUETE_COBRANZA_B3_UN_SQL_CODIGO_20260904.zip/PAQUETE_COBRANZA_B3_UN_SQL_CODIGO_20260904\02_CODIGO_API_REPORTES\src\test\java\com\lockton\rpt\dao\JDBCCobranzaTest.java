package com.lockton.rpt.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.util.LinkedCaseInsensitiveMap;

public class JDBCCobranzaTest {

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void normalizaCacheAlContratoDeConsultaDirecta() {
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                new ArrayList<>();

        ArrayList<LinkedCaseInsensitiveMap> informacion = new ArrayList<>();
        informacion.add(row(
                "NombrePestana", "Información",
                "grupo", "Informacion",
                "Empresa", "Empresa QA"));
        resultsets.add(informacion);

        ArrayList<LinkedCaseInsensitiveMap> concentrada = new ArrayList<>();
        concentrada.add(row(
                "NombrePestana", "Concentrada",
                "grupo", "Concentrada",
                "empresa", "Empresa QA",
                "NumEMpleado", "100"));
        resultsets.add(concentrada);

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> normalizados =
                JDBCCobranza.normalizarContratoCobranza(resultsets);

        assertEquals(1, normalizados.size());
        assertEquals(2, normalizados.get(0).get(0).size());
        assertEquals("Empresa QA", normalizados.get(0).get(0).get("empresa"));
        assertEquals("100", normalizados.get(0).get(0).get("NumEMpleado"));
        assertFalse(normalizados.get(0).get(0).containsKey("NombrePestana"));
        assertFalse(normalizados.get(0).get(0).containsKey("grupo"));
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void conservaSinCambiosElContratoDeConsultaDirecta() {
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                new ArrayList<>();
        ArrayList<LinkedCaseInsensitiveMap> desglosada = new ArrayList<>();
        desglosada.add(row("EMPRESA", 186, "NUMEMPLEADO", "100", "CVEP", "GMM"));
        resultsets.add(desglosada);

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> normalizados =
                JDBCCobranza.normalizarContratoCobranza(resultsets);

        assertEquals(resultsets, normalizados);
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void aceptaResultsetsQueNoSonArrayList() {
        LinkedCaseInsensitiveMap row = row(
                "empresa", "Empresa QA", "NumEMpleado", "100");
        Map<String, Object> resultado = new LinkedHashMap<>();
        resultado.put("#result-set-1", new LinkedList<>(Arrays.asList(row)));

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                JDBCCobranza.extraerResultsets(resultado);

        assertEquals(1, resultsets.size());
        assertEquals("100", resultsets.get(0).get(0).get("NumEMpleado"));
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void convierteMapGenericoAlContratoCaseInsensitive() {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("EMPRESA", "Empresa QA");
        row.put("NUMEMPLEADO", "200");
        Map<String, Object> resultado = new LinkedHashMap<>();
        resultado.put("#result-set-1", Arrays.asList(row));

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                JDBCCobranza.extraerResultsets(resultado);

        assertEquals("200", resultsets.get(0).get(0).get("numempleado"));
    }

    @Test
    public void ignoraConfiguracionAnclaQueNoCubreTodoElResultset() {
        Map<String, String> parcial = new LinkedHashMap<>();
        parcial.put("numempleado", "Número empleado");

        assertFalse(JDBCCobranza.configuracionColumnasCompleta(
                parcial, Arrays.asList("NumEMpleado", "MontoGMM")));
    }

    @Test
    public void aceptaConfiguracionCompletaSinImportarMayusculas() {
        Map<String, String> completa = new LinkedHashMap<>();
        completa.put("numempleado", "Número empleado");
        completa.put("montogmm", "Monto GMM");

        assertEquals(true, JDBCCobranza.configuracionColumnasCompleta(
                completa, Arrays.asList("NumEMpleado", "MontoGMM")));
    }

    @Test
    public void compactaFechaComoLaPortadaB2() {
        assertEquals("20260831", JDBCCobranza.fechaCompacta("2026-08-31 13:19"));
        assertEquals("20260831", JDBCCobranza.fechaCompacta("20260831"));
        assertEquals("", JDBCCobranza.fechaCompacta(null));
    }

    @Test
    public void portadaUsaElRangoRecibidoEnLosFiltros() {
        assertEquals("15/07/2026 al 21/08/2026",
                JDBCCobranza.rangoFechasPortada(
                        "2026-07-15 00:00", "2026-08-21 23:59"));
        assertEquals("01/09/2025 al 01/09/2026",
                JDBCCobranza.rangoFechasPortada(
                        "2025-09-01", "2026-09-01"));
    }

    @Test
    public void distingueConceptoDelNombreDelPlanEnTotalesB2() {
        String[] base = {"Clave de plan", "Clave de cobertura",
                "Nombre del plan", "Importe", "Prima", "Empresa",
                "Empleado", "Excedentes", "Real", "Sobrante"};

        String[] concepto = JDBCCobranza.ajustarCabeceraTotal(
                "Total por coberturas", base,
                Arrays.asList("CVEP", "CVEPO", "Concepto", "Importe",
                        "Prima", "Empresa", "Empleado", "Excedentes",
                        "Real", "Sobrante"), false);

        assertEquals("Concepto", concepto[2]);
        assertEquals("Nombre del plan", base[2]);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static LinkedCaseInsensitiveMap row(Object... values) {
        LinkedCaseInsensitiveMap row = new LinkedCaseInsensitiveMap();
        for (int i = 0; i < values.length; i += 2) {
            row.put(String.valueOf(values[i]), values[i + 1]);
        }
        return row;
    }
}
