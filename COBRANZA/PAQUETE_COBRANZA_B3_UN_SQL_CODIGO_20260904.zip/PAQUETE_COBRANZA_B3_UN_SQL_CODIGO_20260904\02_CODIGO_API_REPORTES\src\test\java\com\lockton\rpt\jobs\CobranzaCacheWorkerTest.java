package com.lockton.rpt.jobs;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import com.lockton.rpt.dao.JDBCCobranza;

public class CobranzaCacheWorkerTest {

    @Test
    public void ejecutaUnaVezAlDiaDespuesDeLaHoraConfigurada() {
        LocalDate hoy = LocalDate.of(2026, 9, 4);
        LocalTime programada = LocalTime.of(1, 0);

        assertFalse(CobranzaCacheWorker.debeEjecutar(
                hoy, LocalTime.of(0, 59), programada, null));
        assertTrue(CobranzaCacheWorker.debeEjecutar(
                hoy, LocalTime.of(1, 0), programada, null));
        assertTrue(CobranzaCacheWorker.debeEjecutar(
                hoy, LocalTime.of(12, 0), programada, null));
        assertFalse(CobranzaCacheWorker.debeEjecutar(
                hoy, LocalTime.of(12, 0), programada, hoy));
    }

    @Test
    public void limitaLaPrecargaAlMesActual() {
        CobranzaCacheWorker.Periodo periodo = CobranzaCacheWorker.periodoMes(
                LocalDate.of(2026, 9, 4),
                LocalDate.of(2026, 5, 2),
                LocalDate.of(2027, 5, 2));

        assertEquals(LocalDate.of(2026, 9, 1), periodo.desde);
        assertEquals(LocalDate.of(2026, 9, 30), periodo.hasta);
    }

    @Test
    public void respetaLosLimitesDeLaVigenciaDentroDelMes() {
        CobranzaCacheWorker.Periodo periodo = CobranzaCacheWorker.periodoMes(
                LocalDate.of(2027, 5, 1),
                LocalDate.of(2026, 5, 2),
                LocalDate.of(2027, 5, 2));

        assertEquals(LocalDate.of(2027, 5, 1), periodo.desde);
        assertEquals(LocalDate.of(2027, 5, 2), periodo.hasta);
    }

    @Test
    public void enviaAlDaoElMesActualConLaVigenciaDetectada() {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        JDBCCobranza cobranza = mock(JDBCCobranza.class);
        Map<String, Object> objetivo = new LinkedHashMap<>();
        objetivo.put("EMidEmpresa", 917);
        objetivo.put("IdVigencia", 4251);
        objetivo.put("InicioEfectivo", java.sql.Date.valueOf("2026-05-02"));
        objetivo.put("FinEfectivo", java.sql.Date.valueOf("2027-05-02"));

        when(jdbc.queryForList(anyString(), any(Object.class)))
                .thenReturn(Collections.singletonList(objetivo));
        when(cobranza.precalcularCobranzaEmpresa(
                917, 4251, "2026-09-01", "2026-09-30", 1, null, null))
                .thenReturn(1);

        CobranzaCacheWorker worker = new CobranzaCacheWorker(jdbc, cobranza);

        assertTrue(worker.ejecutarEmpresas(LocalDate.of(2026, 9, 4)));
        verify(cobranza).precalcularCobranzaEmpresa(
                917, 4251, "2026-09-01", "2026-09-30", 1, null, null);
    }
}
