package com.lockton.rpt.services.impl;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

public class CobranzaServiceImplTest {

    @Test
    public void reconoceSolamenteLaRespuestaFuncionalSinDatos() {
        List<Object> respuesta = error(
                "No se encontraron coincidencias para los rangos o filtros seleccionados.",
                true);

        assertTrue(CobranzaServiceImpl.esRespuestaError(respuesta));
        assertTrue(CobranzaServiceImpl.esRespuestaSinDatos(respuesta));
    }

    @Test
    public void unaFallaDeExcelSeRegistraComoError() {
        List<Object> respuesta = error(
                "No fue posible escribir el archivo Excel.", false);

        assertTrue(CobranzaServiceImpl.esRespuestaError(respuesta));
        assertFalse(CobranzaServiceImpl.esRespuestaSinDatos(respuesta));
    }

    private static List<Object> error(String mensaje, boolean sinDatos) {
        Map<String, Object> detalle = new HashMap<>();
        detalle.put("error", true);
        detalle.put("sinDatos", sinDatos);
        detalle.put("mssError", mensaje);
        List<Object> result = new ArrayList<>();
        result.add(detalle);
        return result;
    }
}
