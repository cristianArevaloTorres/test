package com.lockton.rpt.jobs;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.lockton.rpt.dao.JDBCCobranza;

/**
 * Precarga diaria y secuencial del mes actual para las empresas que habilitan
 * explicitamente COBRANZA_CACHE=1. Los rangos historicos o futuros se generan
 * bajo demanda para evitar trabajo y fotografias innecesarias.
 */
@Component
public class CobranzaCacheWorker {

    private static final Logger LOGGER = LoggerFactory.getLogger(CobranzaCacheWorker.class);
    private static final ZoneId ZONA = ZoneId.of("America/Mexico_City");
    private static final DateTimeFormatter HORA_FORMATO = DateTimeFormatter.ofPattern("HH:mm");

    private static final String SQL_HORA =
            "SELECT TOP (1) LTRIM(RTRIM(paValor)) "
          + "FROM dbo.ff_Parametro WITH (NOLOCK) "
          + "WHERE paIdEmpresa=0 "
          + "  AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE_HORA' "
          + "  AND paidEstatus=1 "
          + "ORDER BY paId DESC";

    /*
     * El worker exige una habilitacion explicita por empresa. Una configuracion
     * global de COBRANZA_CACHE puede habilitar el uso bajo demanda, pero nunca
     * provoca una precarga masiva de todas las empresas.
     */
    private static final String SQL_OBJETIVOS =
            "WITH Configuracion AS "
          + "( "
          + "  SELECT P.paIdEmpresa,LTRIM(RTRIM(P.paValor)) AS Valor, "
          + "         ROW_NUMBER() OVER(PARTITION BY P.paIdEmpresa ORDER BY P.paId DESC) AS rn "
          + "  FROM dbo.ff_Parametro P WITH (NOLOCK) "
          + "  WHERE P.paIdEmpresa>0 "
          + "    AND UPPER(LTRIM(RTRIM(P.paClase)))='COBRANZA_CACHE' "
          + "    AND P.paidEstatus=1 "
          + ") "
          + "SELECT E.EMidEmpresa,V.IdVigencia,V.InicioEfectivo,V.FinEfectivo "
          + "FROM Configuracion C "
          + "INNER JOIN dbo.ff_Empresa E WITH (NOLOCK) ON E.EMidEmpresa=C.paIdEmpresa "
          + "CROSS APPLY "
          + "( "
          + "  SELECT TOP (1) VI.VIidVigencia AS IdVigencia, "
          + "         CONVERT(date,CASE WHEN VI.VIEnrollmentIni IS NOT NULL "
          + "                       AND VI.VIEnrollmentIni<VI.VIVigenciaIni "
          + "                  THEN VI.VIEnrollmentIni ELSE VI.VIVigenciaIni END) AS InicioEfectivo, "
          + "         CONVERT(date,VI.VIVigenciaFin) AS FinEfectivo "
          + "  FROM dbo.ff_Vigencia VI WITH (NOLOCK) "
          + "  WHERE VI.VIidConfiguracion=E.EMidConfiguracion "
          + "    AND VI.VITipoNegocio=1 "
          + "    AND ? BETWEEN CONVERT(date,CASE WHEN VI.VIEnrollmentIni IS NOT NULL "
          + "                                      AND VI.VIEnrollmentIni<VI.VIVigenciaIni "
          + "                                 THEN VI.VIEnrollmentIni ELSE VI.VIVigenciaIni END) "
          + "              AND CONVERT(date,VI.VIVigenciaFin) "
          + "  ORDER BY VI.VIVigenciaIni DESC,VI.VIidVigencia DESC "
          + ") V "
          + "WHERE C.rn=1 AND C.Valor='1' AND E.EMidEstatus=1 "
          + "ORDER BY E.EMidEmpresa";

    private final JdbcTemplate jdbcTemplate;
    private final JDBCCobranza cobranza;
    private volatile LocalDate ultimaEjecucion;

    public CobranzaCacheWorker(JdbcTemplate jdbcTemplate, JDBCCobranza cobranza) {
        this.jdbcTemplate = jdbcTemplate;
        this.cobranza = cobranza;
    }

    @Scheduled(
        fixedDelayString = "${cobranza.cache.worker.poll-ms:60000}",
        initialDelayString = "${cobranza.cache.worker.initial-delay-ms:60000}")
    public void revisarHorario() {
        ZonedDateTime ahora = ZonedDateTime.now(ZONA);
        if (ahora.toLocalDate().equals(ultimaEjecucion)) return;

        LocalTime horaProgramada = obtenerHoraProgramada();
        if (horaProgramada == null
                || !debeEjecutar(ahora.toLocalDate(), ahora.toLocalTime(),
                        horaProgramada, ultimaEjecucion)) {
            return;
        }

        synchronized (this) {
            if (!debeEjecutar(ahora.toLocalDate(), ahora.toLocalTime(),
                    horaProgramada, ultimaEjecucion)) {
                return;
            }
            if (ejecutarEmpresas(ahora.toLocalDate())) {
                ultimaEjecucion = ahora.toLocalDate();
            }
        }
    }

    private LocalTime obtenerHoraProgramada() {
        try {
            List<String> valores = jdbcTemplate.query(
                    SQL_HORA, (rs, rowNum) -> rs.getString(1));
            if (valores.isEmpty() || valores.get(0) == null) return null;
            return LocalTime.parse(valores.get(0).trim(), HORA_FORMATO);
        } catch (DateTimeParseException e) {
            LOGGER.error("COBRANZA_CACHE_HORA no tiene formato HH:mm; worker deshabilitado: {}",
                    e.getParsedString());
            return null;
        } catch (Exception e) {
            LOGGER.warn("No se pudo leer COBRANZA_CACHE_HORA; worker deshabilitado temporalmente: {}",
                    e.getMessage());
            return null;
        }
    }

    boolean ejecutarEmpresas(LocalDate hoy) {
        List<Map<String, Object>> objetivos;
        try {
            objetivos = jdbcTemplate.queryForList(SQL_OBJETIVOS, Date.valueOf(hoy));
        } catch (Exception e) {
            LOGGER.error("No fue posible obtener empresas configuradas para cache de Cobranza", e);
            return false;
        }

        int completas = 0;
        int errores = 0;
        for (Map<String, Object> objetivo : objetivos) {
            int idEmpresa = ((Number) objetivo.get("EMidEmpresa")).intValue();
            int idVigencia = ((Number) objetivo.get("IdVigencia")).intValue();
            LocalDate inicioVigencia = fecha(objetivo.get("InicioEfectivo"));
            LocalDate finVigencia = fecha(objetivo.get("FinEfectivo"));
            Periodo periodo = periodoMes(hoy, inicioVigencia, finVigencia);
            if (periodo == null) continue;

            int resultado = cobranza.precalcularCobranzaEmpresa(
                    idEmpresa, idVigencia,
                    periodo.desde.toString(), periodo.hasta.toString(),
                    1, null, null);
            if (resultado == 1) completas++;
            else errores++;
        }

        LOGGER.info("Worker cache Cobranza finalizado. Fecha={}, empresas={}, completas={}, errores={}",
                hoy, objetivos.size(), completas, errores);
        return true;
    }

    static boolean debeEjecutar(LocalDate hoy, LocalTime horaActual,
            LocalTime horaProgramada, LocalDate ultimaEjecucion) {
        return (ultimaEjecucion == null || !ultimaEjecucion.equals(hoy))
                && !horaActual.isBefore(horaProgramada);
    }

    static Periodo periodoMes(LocalDate hoy, LocalDate inicioVigencia,
            LocalDate finVigencia) {
        LocalDate desde = hoy.withDayOfMonth(1);
        LocalDate hasta = hoy.with(TemporalAdjusters.lastDayOfMonth());
        if (inicioVigencia != null && inicioVigencia.isAfter(desde)) desde = inicioVigencia;
        if (finVigencia != null && finVigencia.isBefore(hasta)) hasta = finVigencia;
        return desde.isAfter(hasta) ? null : new Periodo(desde, hasta);
    }

    private static LocalDate fecha(Object value) {
        if (value instanceof Date) return ((Date) value).toLocalDate();
        return value == null ? null : LocalDate.parse(String.valueOf(value).substring(0, 10));
    }

    static final class Periodo {
        final LocalDate desde;
        final LocalDate hasta;

        Periodo(LocalDate desde, LocalDate hasta) {
            this.desde = desde;
            this.hasta = hasta;
        }
    }
}
