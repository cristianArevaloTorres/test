# Instalacion de Cobranza B3

Esta carpeta contiene unicamente los objetos y optimizaciones necesarios para
instalar el flujo final de Cobranza B3. B2 no se modifica.

Ejecutar sin cargas de Cobranza activas y en este orden:

1. `01_INSTALAR_CACHE_Y_REPORTE_B3.sql`
2. `02_INDICES_RENDIMIENTO_B3.sql`
3. `03_OPTIMIZAR_DESGLOSADA_B3.sql`
4. `04_CREAR_RUTAS_LEGACY_OPT_B3.sql`
5. `05_MOTOR_DIVISION_SET_B3.sql`
6. `06_DESGLOSADA_ETAPAS_SET_B3.sql`
7. `07_CONCENTRADA_ETAPAS_SET_B3.sql`
8. `08_INTEGRAR_FLUJO_UNICO_SET_B3.sql`
9. `09_VALIDAR_FLUJO_UNICO_B3.sql`

El script `09` no ejecuta una carga ni modifica datos funcionales. Valida que
el flujo tradicional y el flujo de cache converjan al motor SET, que existan
los objetos esperados y que no se hayan conectado objetos B2 al motor B3.
Antes de ejecutarlo deben revisarse `@IdEmpresa` y `@IdVigencia`.

En una base DEV que ya recibio `01` a `04`, para reinstalar solamente la
version SET final se pueden ejecutar `05` a `09`, igualmente sin cargas
activas.

Las configuraciones por empresa, cargas, monitores y comparaciones estan fuera
de esta carpeta, en `SQL_02_ADICIONALES/COBRANZA`.
