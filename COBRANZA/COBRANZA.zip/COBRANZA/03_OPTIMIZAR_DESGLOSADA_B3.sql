/*
   SEGUNDA OPTIMIZACION DE COBRANZA: DESGLOSADA / DIVISION DE COSTOS


*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Proc sysname=N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR',
        @Def nvarchar(max),
        @Upper nvarchar(max),
        @PosExec int,
        @PosInsert int,
        @PosOrden int,
        @PosProc int,
        @Bloque nvarchar(max),
        @Needle nvarchar(1000);

IF OBJECT_ID(@Proc,N'P') IS NULL
    THROW 52300,'No existe dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR.',1;

SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Proc));

IF @Def IS NULL
    THROW 52301,'No se pudo leer la definicion del procedimiento Desglosada.',1;

/* El JOIN principal usa empresa+empleado; el indice legacy de esta tabla
   temporal comienza por numero de empleado y no sirve bien para ese acceso. */
IF @Def NOT LIKE N'%BF_CACHE_PERF_DESG_SOURCE_INDEX_V1%'
BEGIN
    SET @Upper=UPPER(@Def);
    SET @PosInsert=CHARINDEX(N'INSERT INTO #TABLACOBDESG',@Upper);
    IF @PosInsert=0
        THROW 52304,'No se encontro el INSERT de #TablaCobDesg.',1;

    SET @Bloque=N'
 /* BF_CACHE_PERF_DESG_SOURCE_INDEX_V1 */
 CREATE NONCLUSTERED INDEX IX_BF_ff_Empleadotemp_EmpresaEmpleado
     ON #ff_Empleadotemp(EMidEmpresa,EMidAnt);

';
    SET @Def=STUFF(@Def,@PosInsert,0,@Bloque);
    SET @Upper=UPPER(@Def);
    SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
    SET @Def=N'ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
    EXEC sys.sp_executesql @Def;
    SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Proc));
END;

/* Cada vigencia tiene cardinalidades muy distintas. Evita reutilizar para la
   Desglosada el plan compilado con otra vigencia o conjunto de perfiles. */
IF @Def NOT LIKE N'%BF_CACHE_PERF_DESG_RECOMPILE_V1%'
BEGIN
    SET @Needle=N'ORDER BY S.SONUMEMPLEADO, PL.PLORDENCOBRANZA, POS.POIDPLANOPCIONSELECCION, POS.POANEXO, POS.POIDPLANOPCION, POS.POEDAD, POS.POIDGRUPOPARENTESCO';
    SET @Upper=UPPER(@Def);
    SET @PosOrden=CHARINDEX(@Needle,@Upper);
    IF @PosOrden=0
        THROW 52305,'No se encontro el ORDER BY del INSERT Desglosada.',1;

    SET @Def=STUFF(@Def,@PosOrden+LEN(@Needle),0,
                   N' OPTION (RECOMPILE) /* BF_CACHE_PERF_DESG_RECOMPILE_V1 */');
    SET @Upper=UPPER(@Def);
    SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
    SET @Def=N'ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
    EXEC sys.sp_executesql @Def;
    SET @Def=OBJECT_DEFINITION(OBJECT_ID(@Proc));
END;

IF @Def NOT LIKE N'%BF_CACHE_PERF_DESG_TEMP_INDEX_V1%'
BEGIN
    SET @Upper=UPPER(@Def);
    SET @PosExec=CHARINDEX(
        N'EXEC DBO.FF_OBTENDIVISIONCTOS_ADAPTADO_BF3_NOUSAR',@Upper);

    IF @PosExec=0
        THROW 52302,'No se encontro la llamada a ff_ObtenDivisionCtos_Adaptado_bf3_NOUSAR.',1;

    SET @Bloque=N'
 /* BF_CACHE_PERF_DESG_TEMP_INDEX_V1
    La rutina de division consulta y actualiza #TablaCobDesg miles de veces.
    Estos indices viven solamente durante esta ejecucion del reporte. */
 IF EXISTS (SELECT 1 FROM #TablaCobDesg)
 BEGIN
     CREATE NONCLUSTERED INDEX IX_BF_TablaCobDesg_Empleado
         ON #TablaCobDesg(EMPRESA,NUMEMPLEADO)
         INCLUDE(idemp,ImportexPeriodo,CVEPO,CVEP,PLOrdenCobranza);

     CREATE NONCLUSTERED INDEX IX_BF_TablaCobDesg_Actualizar
         ON #TablaCobDesg(EMPRESA,idemp,CVEPO,CVEP);

     CREATE NONCLUSTERED INDEX IX_BF_TablaCobDesg_NumEmpleado
         ON #TablaCobDesg(NUMEMPLEADO);
 END;

 BEGIN TRY
     INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
     SELECT ''cobranza_desg_pre_division'',
            CONCAT(''filas_desglosada='',COUNT_BIG(*))
     FROM #TablaCobDesg;
 END TRY BEGIN CATCH END CATCH;

';

    SET @Def=STUFF(@Def,@PosExec,0,@Bloque);

    /* Convertir CREATE PROCEDURE a ALTER PROCEDURE sin depender de espacios. */
    SET @Upper=UPPER(@Def);
    SET @PosProc=CHARINDEX(N'PROCEDURE',@Upper);
    IF @PosProc=0
        THROW 52303,'La definicion recuperada no contiene PROCEDURE.',1;

    SET @Def=N'ALTER '+SUBSTRING(@Def,@PosProc,LEN(@Def));
    EXEC sys.sp_executesql @Def;
END;

/* Consultas repetidas por cada plan dentro de la division de costos. */
IF OBJECT_ID(N'dbo.ff_GMMDesgCob',N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.indexes
       WHERE object_id=OBJECT_ID(N'dbo.ff_GMMDesgCob')
         AND name=N'IX_BF_GMMDesgCob_EmpresaPlanConcepto'
   )
BEGIN
    CREATE INDEX IX_BF_GMMDesgCob_EmpresaPlanConcepto
        ON dbo.ff_GMMDesgCob(GDidEmpresa,GDidPlanOpcion,GDidConcepto)
        INCLUDE(GDMonto);
END;

IF OBJECT_ID(N'dbo.ff_CompensacionPlanOpcion',N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.indexes
       WHERE object_id=OBJECT_ID(N'dbo.ff_CompensacionPlanOpcion')
         AND name=N'IX_BF_CompPlanOpcion_PlanCompensacion'
   )
BEGIN
    CREATE INDEX IX_BF_CompPlanOpcion_PlanCompensacion
        ON dbo.ff_CompensacionPlanOpcion(CPidPlanOpcion,CPidCompensacion);
END;

IF OBJECT_ID(N'dbo.ff_EdoCuentaCobranza',N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.indexes
       WHERE object_id=OBJECT_ID(N'dbo.ff_EdoCuentaCobranza')
         AND name=N'IX_BF_Cobranza_EmpresaNumeroCompSolicitud'
   )
BEGIN
    CREATE INDEX IX_BF_Cobranza_EmpresaNumeroCompSolicitud
        ON dbo.ff_EdoCuentaCobranza
           (ECidEmpresa,ECNumeroEmpleado,ECidCompensacion,ECidSolicitud);
END;

IF OBJECT_ID(N'dbo.ff_ValidaSAVida',N'U') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1 FROM sys.indexes
       WHERE object_id=OBJECT_ID(N'dbo.ff_ValidaSAVida')
         AND name=N'IX_BF_ValidaSA_VigenciaEstatusEmpleadoPlan'
   )
BEGIN
    CREATE INDEX IX_BF_ValidaSA_VigenciaEstatusEmpleadoPlan
        ON dbo.ff_ValidaSAVida
           (VSidVigencia,VSidEstatus,VSidEmpleado,VSidPlanOpcion)
        INCLUDE(VSSumaAsegurada);
END;

SELECT N'OK' AS Estado,
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID(@Proc))
                      LIKE N'%BF_CACHE_PERF_DESG_TEMP_INDEX_V1%'
            THEN N'Procedimiento Desglosada optimizado'
            ELSE N'ERROR: no se encontro el marcador'
       END AS Detalle;

SELECT T.name AS Tabla,I.name AS Indice
FROM sys.indexes I
INNER JOIN sys.tables T ON T.object_id=I.object_id
WHERE I.name IN
      (N'IX_BF_GMMDesgCob_EmpresaPlanConcepto',
       N'IX_BF_CompPlanOpcion_PlanCompensacion',
       N'IX_BF_Cobranza_EmpresaNumeroCompSolicitud',
       N'IX_BF_ValidaSA_VigenciaEstatusEmpleadoPlan')
ORDER BY T.name,I.name;
