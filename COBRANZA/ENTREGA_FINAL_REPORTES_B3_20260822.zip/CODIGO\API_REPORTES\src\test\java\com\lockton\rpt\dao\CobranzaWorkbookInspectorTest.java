package com.lockton.rpt.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

/** Inspector repetible del contrato de Cobranza. B2 siempre es el patron. */
public class CobranzaWorkbookInspectorTest {

    private static final List<String> B2_SHEETS = Arrays.asList(
            "Informacion", "Concentrada", "Desglosada",
            "Total por coberturas", "Planes_Parentesco");
    private static final DataFormatter FORMATTER = new DataFormatter(Locale.ROOT);

    @Test
    public void b2DefineHojasColumnasYPortada() throws Exception {
        File b2 = workbookFromProperty("cobranza.b2");
        Assumptions.assumeTrue(b2.isFile(),
                "Use -Dcobranza.b2=<archivo.xlsx> para inspeccionar B2");

        try (Workbook workbook = open(b2)) {
            assertEquals(B2_SHEETS, sheetNames(workbook));
            assertInfoContract(workbook.getSheet("Informacion"));
            assertHeaders(workbook.getSheet("Concentrada"), "Concentrada", 57);
            assertHeaders(workbook.getSheet("Desglosada"), "Desglosada", 43);
            assertHeaders(workbook.getSheet("Planes_Parentesco"), "Planes_Parentesco", 12);
            assertTotalHeaders(workbook.getSheet("Total por coberturas"));
            printWorkbook("PATRON_B2", workbook);
        }
    }

    @Test
    public void informaDiferenciasDelB3SuministradoContraB2() throws Exception {
        File b2 = workbookFromProperty("cobranza.b2");
        File b3 = workbookFromProperty("cobranza.b3");
        Assumptions.assumeTrue(b2.isFile() && b3.isFile(),
                "Use -Dcobranza.b2 y -Dcobranza.b3 para comparar archivos");

        try (Workbook patron = open(b2); Workbook candidato = open(b3)) {
            System.out.println("INSPECTOR hojas B2=" + sheetNames(patron));
            System.out.println("INSPECTOR hojas B3=" + sheetNames(candidato));
            compareByPosition(patron.getSheetAt(1), candidato.getSheetAt(1),
                    new int[] {1}, "Concentrada");
            compareByPosition(patron.getSheetAt(2), candidato.getSheetAt(2),
                    new int[] {1, 11, 19, 20}, "Desglosada");
            compareByPosition(patron.getSheetAt(4), candidato.getSheetAt(4),
                    new int[] {0, 1}, "Planes_Parentesco");
            printWorkbook("CANDIDATO_B3", candidato);
        }
    }

    private static void assertInfoContract(Sheet sheet) {
        assertTrue(text(sheet, 0, 0).startsWith("Empresa: "));
        assertTrue(text(sheet, 6, 0).startsWith("INFORMACI"));
        assertTrue(!text(sheet, 6, 4).isEmpty(),
                "La portada debe contener el rango de información");
    }

    private static void assertHeaders(Sheet sheet, String group, int size)
            throws Exception {
        assertEquals(Arrays.asList(expectedHeaders(group, size)),
                rowValues(sheet.getRow(0), size), "Encabezados de " + group);
    }

    private static void assertTotalHeaders(Sheet sheet) throws Exception {
        List<String> ten = Arrays.asList(expectedHeaders("Total por coberturas", 10));
        List<String> tenConcepto = new ArrayList<>(ten);
        tenConcepto.set(2, "Concepto");
        List<String> five = Arrays.asList(expectedHeaders("Total por coberturas", 5));
        int blocks = 0;
        for (Row row : sheet) {
            if (!"Clave de plan".equals(text(row, 0))) continue;
            List<String> values = rowValues(row, row.getLastCellNum());
            assertTrue(values.equals(ten) || values.equals(tenConcepto) || values.equals(five),
                    "Bloque desconocido en fila " + (row.getRowNum() + 1) + ": " + values);
            blocks++;
        }
        assertTrue(blocks >= 2, "B2 debe contener varios bloques de totales");
    }

    private static String[] expectedHeaders(String group, int size) throws Exception {
        Method method = JDBCCobranza.class.getDeclaredMethod(
                "getCabecera", String.class, int.class, int.class);
        method.setAccessible(true);
        return (String[]) method.invoke(null, group, size, 0);
    }

    private static void compareByPosition(Sheet b2, Sheet b3, int[] keyColumns,
            String label) {
        int columnsB2 = maxColumns(b2);
        int columnsB3 = maxColumns(b3);
        int headerDiffs = positionalDifferences(b2.getRow(0), b3.getRow(0),
                Math.max(columnsB2, columnsB3));

        Map<String, Row> rowsB2 = keyedRows(b2, keyColumns);
        Map<String, Row> rowsB3 = keyedRows(b3, keyColumns);
        int common = 0;
        int rowsWithDifferences = 0;
        int cellsWithDifferences = 0;
        for (Map.Entry<String, Row> entry : rowsB2.entrySet()) {
            Row candidate = rowsB3.get(entry.getKey());
            if (candidate == null) continue;
            common++;
            int differences = positionalDifferences(entry.getValue(), candidate,
                    Math.max(columnsB2, columnsB3));
            if (differences > 0) rowsWithDifferences++;
            cellsWithDifferences += differences;
        }

        System.out.println("INSPECTOR " + label
                + " columnasB2=" + columnsB2
                + " columnasB3=" + columnsB3
                + " diferenciasEncabezado=" + headerDiffs
                + " filasB2=" + rowsB2.size()
                + " filasB3=" + rowsB3.size()
                + " llavesComunes=" + common
                + " filasDiferentes=" + rowsWithDifferences
                + " celdasDiferentes=" + cellsWithDifferences);
    }

    private static Map<String, Row> keyedRows(Sheet sheet, int[] columns) {
        Map<String, Row> result = new LinkedHashMap<>();
        for (int r = 1; r <= sheet.getLastRowNum(); r++) {
            Row row = sheet.getRow(r);
            if (row == null) continue;
            List<String> parts = new ArrayList<>();
            boolean empty = true;
            for (int column : columns) {
                String value = text(row, column).trim();
                parts.add(value);
                if (!value.isEmpty()) empty = false;
            }
            if (empty || parts.get(0).toUpperCase(Locale.ROOT).startsWith("TOTAL")) continue;
            result.putIfAbsent(String.join("\u001f", parts), row);
        }
        return result;
    }

    private static int positionalDifferences(Row left, Row right, int columns) {
        int differences = 0;
        for (int c = 0; c < columns; c++) {
            if (!text(left, c).equals(text(right, c))) differences++;
        }
        return differences;
    }

    private static void printWorkbook(String label, Workbook workbook) {
        for (Sheet sheet : workbook) {
            System.out.println("INSPECTOR " + label + " hoja=" + sheet.getSheetName()
                    + " filas=" + (sheet.getLastRowNum() + 1)
                    + " columnas=" + maxColumns(sheet)
                    + " fusiones=" + sheet.getNumMergedRegions());
        }
    }

    private static int maxColumns(Sheet sheet) {
        int max = 0;
        for (Row row : sheet) max = Math.max(max, row.getLastCellNum());
        return max;
    }

    private static List<String> rowValues(Row row, int size) {
        List<String> values = new ArrayList<>();
        for (int i = 0; i < size; i++) values.add(text(row, i));
        return values;
    }

    private static String text(Sheet sheet, int row, int column) {
        return text(sheet.getRow(row), column);
    }

    private static String text(Row row, int column) {
        if (row == null) return "";
        Cell cell = row.getCell(column, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
        return cell == null ? "" : FORMATTER.formatCellValue(cell).trim();
    }

    private static Workbook open(File file) throws Exception {
        return new XSSFWorkbook(new FileInputStream(file));
    }

    private static File workbookFromProperty(String name) {
        String value = System.getProperty(name, "");
        return value.isEmpty() ? new File("__missing__") : new File(value);
    }

    private static List<String> sheetNames(Workbook workbook) {
        List<String> names = new ArrayList<>();
        for (Sheet sheet : workbook) names.add(sheet.getSheetName());
        return names;
    }
}
