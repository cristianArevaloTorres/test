# Rutas de código

## API Reportes

Copiar el contenido de `API_REPORTES` sobre la raíz del proyecto:

`BeFlex3_Admin_API_Reportes-ReporteSabanaHomologacionOK-clean`

Se incluyen `pom.xml`, código principal, utilidades, pruebas e inspector local.

## Front B3

Copiar el contenido de `FRONT_B3` sobre la raíz del proyecto:

`BeFlex3-EmpAdm-QA`

Incluye los componentes modificados de Cobranza y Sábana de beneficios.

## No incluido

Los proyectos B2 no tienen modificaciones requeridas. No copiar archivos de
esta entrega en `WSBeFlex-EmpAdm-QA` ni en `BeflexProduccion-QA`.

