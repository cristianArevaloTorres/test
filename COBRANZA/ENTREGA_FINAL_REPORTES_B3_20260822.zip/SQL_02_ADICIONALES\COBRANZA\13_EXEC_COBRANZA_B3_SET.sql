/*
   EJECUCION B3 OPTIMIZADA PARA COMPARAR CONTRA LA BASE B2 / LEGACY

   Ejecuta directamente el motor SET; no depende del valor de sistema del
   enrutador publico. Usa exactamente la misma cache, rango y perfiles que el
   script 12 cuando se deja la misma empresa y vigencia.

   Empresa  : 1807
   Vigencia : 4320. Cambiar solamente @IdVigencia a 3993 para la anterior.
   Evidencia: activar Ctrl+Shift+F en SSMS antes de ejecutar y guardar como
              COBRANZA_B3_SET_1807_4320.rpt.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=1807,
        @IdVigencia int=4320,
        @CacheId bigint,
        @IdSolTipo int,
        @IdVencida int,
        @FecIni varchar(16),
        @FecFin varchar(16),
        @PerfilClave varchar(2000),
        @Inicio datetime2(3)=SYSDATETIME();

IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET',N'P') IS NULL
    THROW 53410,'Falta el procedimiento optimizado dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET. Ejecute primero los SQL 05 a 08 de instalacion.',1;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_ConsultaV2',N'U') IS NULL
    THROW 53411,'Falta dbo.bf_CobranzaCache_ConsultaV2 para recuperar los parametros de comparacion.',1;

SELECT TOP (1)
       @CacheId=C.CacheId,
       @IdSolTipo=C.IdSolTipo,
       @IdVencida=C.IdVencida,
       @FecIni=C.FecIni,
       @FecFin=C.FecFin,
       @PerfilClave=C.PerfilClave
FROM dbo.bf_CobranzaCache_ConsultaV2 AS C WITH (NOLOCK)
WHERE C.IdEmpresa=@IdEmpresa
  AND C.IdVigencia=@IdVigencia
  AND C.EsUniverso=1
  AND C.Estado='COMPLETA'
ORDER BY COALESCE(C.FechaCargaFin,C.FechaCargaInicio) DESC,C.CacheId DESC;

IF @CacheId IS NULL
    THROW 53412,'No existe una cache universo COMPLETA para la empresa y vigencia indicadas.',1;

DECLARE @Perfiles dbo.ListInt;

INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT TRY_CONVERT(int,S.value)
FROM STRING_SPLIT(ISNULL(@PerfilClave,''),',') AS S
WHERE TRY_CONVERT(int,S.value) IS NOT NULL;

IF NOT EXISTS(SELECT 1 FROM @Perfiles)
    THROW 53413,'La cache seleccionada no contiene perfiles validos.',1;

SELECT N'B3_SET' AS Ejecucion,
       N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET' AS Procedimiento,
       @CacheId AS CacheId,@IdEmpresa AS IdEmpresa,@IdVigencia AS IdVigencia,
       @IdSolTipo AS IdSolTipo,@IdVencida AS IdVencida,
       @FecIni AS FecIni,@FecFin AS FecFin,@PerfilClave AS PerfilClave,
       @Inicio AS FechaInicio;

EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET
     @idEmpresa=@IdEmpresa,
     @idSolTipo=@IdSolTipo,
     @FecIni=@FecIni,
     @FecFin=@FecFin,
     @idVencida=@IdVencida,
     @IdPerfil=@Perfiles,
     @idVIgencia=@IdVigencia;

SELECT N'FIN_B3_SET' AS Ejecucion,
       @Inicio AS FechaInicio,
       SYSDATETIME() AS FechaFin,
       DATEDIFF_BIG(millisecond,@Inicio,SYSDATETIME()) AS Milisegundos;
