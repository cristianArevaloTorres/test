/*
   EXPORTACION DE EVIDENCIA DE BD - COBRANZA B3 ZURICH SANTANDER

   Todos los bloques son SELECT. No carga, actualiza ni elimina datos.
   Vigencia predeterminada: 4320. Para la anterior cambie @IdVigencia a 3993.

   Active Resultados a archivo (Ctrl+Shift+F) para guardar todos los bloques en
   un .rpt, o guarde cada cuadricula como CSV. El campo Resultado identifica el
   contenido de cada cuadricula.
*/
SET NOCOUNT ON;

DECLARE @IdEmpresa int=1807,
        @IdVigencia int=4320,
        @CacheId bigint,
        @IdVencida int;

/* 00. Vigencias reales de la configuracion de Zurich. */
SELECT N'00_VIGENCIAS_REALES' AS Resultado,
       E.EMidEmpresa,E.EMNombre,E.EMidConfiguracion,
       V.VIidVigencia,V.VIVigenciaIni,V.VIVigenciaFin,V.VIEnrollmentIni,
       V.VITipoNegocio,
       CASE WHEN V.VIidVigencia=@IdVigencia THEN 1 ELSE 0 END AS EsSeleccionada
FROM dbo.ff_Empresa AS E WITH (NOLOCK)
INNER JOIN dbo.ff_Vigencia AS V WITH (NOLOCK)
        ON V.VIidConfiguracion=E.EMidConfiguracion
WHERE E.EMidEmpresa=@IdEmpresa
  AND V.VITipoNegocio=1
ORDER BY V.VIVigenciaIni DESC,V.VIidVigencia DESC;

/* Cache completa mas reciente de la vigencia elegida. */
SELECT TOP (1) @CacheId=C.CacheId,@IdVencida=C.IdVencida
FROM dbo.bf_CobranzaCache_ConsultaV2 AS C WITH (NOLOCK)
WHERE C.IdEmpresa=@IdEmpresa
  AND C.IdVigencia=@IdVigencia
  AND C.EsUniverso=1
  AND C.Estado='COMPLETA'
ORDER BY COALESCE(C.FechaCargaFin,C.FechaCargaInicio) DESC,C.CacheId DESC;

IF @CacheId IS NULL
    THROW 53310,'No existe cache universo COMPLETA para empresa 1807 y la vigencia solicitada.',1;

/* 01. Historial y estado de caches para la vigencia. */
SELECT N'01_CONTROL_CACHE' AS Resultado,C.*
FROM dbo.bf_CobranzaCache_ConsultaV2 AS C WITH (NOLOCK)
WHERE C.IdEmpresa=@IdEmpresa
  AND C.IdVigencia=@IdVigencia
ORDER BY C.CacheId DESC;

/* 02. Base Concentrada utilizada para construir el reporte. */
SELECT N'02_CONCENTRADA_V2' AS Resultado,C.*
FROM dbo.bf_CobranzaCache_ConcentradaV2 AS C WITH (NOLOCK)
WHERE C.CacheId=@CacheId
ORDER BY C.Orden;

/* 03. Base Desglosada utilizada para construir el reporte. */
SELECT N'03_DESGLOSADA_V2' AS Resultado,D.*
FROM dbo.bf_CobranzaCache_DesglosadaV2 AS D WITH (NOLOCK)
WHERE D.CacheId=@CacheId
ORDER BY D.Orden;

/* 04. Datos de tarjeta, si la empresa/rango los genera. */
IF OBJECT_ID(N'dbo.bf_CobranzaCache_BanwireV2',N'U') IS NOT NULL
BEGIN
    SELECT N'04_BANWIRE_V2' AS Resultado,B.*
    FROM dbo.bf_CobranzaCache_BanwireV2 AS B WITH (NOLOCK)
    WHERE B.CacheId=@CacheId
    ORDER BY B.Orden;
END;

/* 05. Bitacora completa de la carga seleccionada. */
IF OBJECT_ID(N'dbo.bf_CobranzaCache_Log',N'U') IS NOT NULL
BEGIN
    SELECT N'05_LOG_CACHE' AS Resultado,L.*
    FROM dbo.bf_CobranzaCache_Log AS L WITH (NOLOCK)
    WHERE L.CacheId=@CacheId
    ORDER BY L.LogId;
END;

/* 06. Evidencia de la ruta SQL SET para esa empresa/vigencia. */
IF OBJECT_ID(N'dbo.bf_RepConf_Debug',N'U') IS NOT NULL
BEGIN
    SELECT N'06_DEBUG_RUTA_SET' AS Resultado,D.*
    FROM dbo.bf_RepConf_Debug AS D WITH (NOLOCK)
    WHERE D.detalle LIKE CONCAT(N'%empresa=',@IdEmpresa,N'%')
      AND D.detalle LIKE CONCAT(N'%vigencia=',@IdVigencia,N'%')
    ORDER BY D.id DESC;
END;

/* 07. Configuracion que determina orden de grupos/hojas. */
IF OBJECT_ID(N'dbo.bf_RepConf_Tabla',N'U') IS NOT NULL
BEGIN
    SELECT N'07_CONFIGURACION_HOJAS' AS Resultado,T.*
    FROM dbo.bf_RepConf_Tabla AS T WITH (NOLOCK)
    WHERE T.catReportesId=11
      AND T.idEmpresa IN(0,@IdEmpresa)
    ORDER BY CASE WHEN T.idEmpresa=@IdEmpresa THEN 0 ELSE 1 END,
             T.indexTable,T.grupo;
END;

/* 08. Configuracion de columnas del reporte 11. */
IF OBJECT_ID(N'dbo.bf_RepConf_Columna',N'U') IS NOT NULL
BEGIN
    SELECT N'08_CONFIGURACION_COLUMNAS' AS Resultado,C.*
    FROM dbo.bf_RepConf_Columna AS C WITH (NOLOCK)
    WHERE C.catReportesId=11
      AND C.idEmpresa IN(0,@IdEmpresa)
    ORDER BY CASE WHEN C.idEmpresa=@IdEmpresa THEN 0 ELSE 1 END,
             C.grupo,C.orden;
END;

/*
   09-13. Cache de resultsets mantenida por la aplicacion Java, si esas tablas
   existen en la base. Estas contienen la forma ya separada por hoja/bloque.
*/
IF OBJECT_ID(N'dbo.bf_CobranzaCache_Concentrada',N'U') IS NOT NULL
    EXEC sys.sp_executesql
         N'SELECT N''09_APP_CONCENTRADA'' AS Resultado,*
           FROM dbo.bf_CobranzaCache_Concentrada WITH (NOLOCK)
           WHERE ccdIdEmpresa=@E AND ccdIdVigencia=@V AND ccdIdVencida=@D
           ORDER BY ccdId;',N'@E int,@V int,@D int',
         @E=@IdEmpresa,@V=@IdVigencia,@D=@IdVencida;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_Desglosada',N'U') IS NOT NULL
    EXEC sys.sp_executesql
         N'SELECT N''10_APP_DESGLOSADA'' AS Resultado,*
           FROM dbo.bf_CobranzaCache_Desglosada WITH (NOLOCK)
           WHERE ccdIdEmpresa=@E AND ccdIdVigencia=@V AND ccdIdVencida=@D
           ORDER BY ccdId;',N'@E int,@V int,@D int',
         @E=@IdEmpresa,@V=@IdVigencia,@D=@IdVencida;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_TotCoberturas',N'U') IS NOT NULL
    EXEC sys.sp_executesql
         N'SELECT N''11_APP_TOTAL_COBERTURAS'' AS Resultado,*
           FROM dbo.bf_CobranzaCache_TotCoberturas WITH (NOLOCK)
           WHERE ccdIdEmpresa=@E AND ccdIdVigencia=@V AND ccdIdVencida=@D
           ORDER BY ccdId;',N'@E int,@V int,@D int',
         @E=@IdEmpresa,@V=@IdVigencia,@D=@IdVencida;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_TotCoberturasP',N'U') IS NOT NULL
    EXEC sys.sp_executesql
         N'SELECT N''12_APP_TOTAL_COBERTURAS_PARENTESCO'' AS Resultado,*
           FROM dbo.bf_CobranzaCache_TotCoberturasP WITH (NOLOCK)
           WHERE ccdIdEmpresa=@E AND ccdIdVigencia=@V AND ccdIdVencida=@D
           ORDER BY ccdId;',N'@E int,@V int,@D int',
         @E=@IdEmpresa,@V=@IdVigencia,@D=@IdVencida;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_PlanesParentesco',N'U') IS NOT NULL
    EXEC sys.sp_executesql
         N'SELECT N''13_APP_PLANES_PARENTESCO'' AS Resultado,*
           FROM dbo.bf_CobranzaCache_PlanesParentesco WITH (NOLOCK)
           WHERE ccdIdEmpresa=@E AND ccdIdVigencia=@V AND ccdIdVencida=@D
           ORDER BY ccdId;',N'@E int,@V int,@D int',
         @E=@IdEmpresa,@V=@IdVigencia,@D=@IdVencida;

/* 14. Resumen final para comprobar que se exporto el CacheId correcto. */
SELECT N'14_RESUMEN_EXPORTACION' AS Resultado,@IdEmpresa AS IdEmpresa,
       @IdVigencia AS IdVigencia,@IdVencida AS IdVencida,@CacheId AS CacheId,
       (SELECT COUNT_BIG(*) FROM dbo.bf_CobranzaCache_ConcentradaV2 WITH (NOLOCK)
        WHERE CacheId=@CacheId) AS FilasConcentrada,
       (SELECT COUNT_BIG(*) FROM dbo.bf_CobranzaCache_DesglosadaV2 WITH (NOLOCK)
        WHERE CacheId=@CacheId) AS FilasDesglosada;
