/*
   EJECUCION DE REFERENCIA B2 / LEGACY PARA COMPARAR RESULTADOS

   El Java de B2 invoca historicamente:
       dbo.ObtenCobranzaConcentrada_otro_V2_BF3

   Durante la homologacion, antes de sustituir el enrutador publico, ese
   procedimiento se conservo como:
       dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY

   Por eso este EXEC representa el comportamiento original usado como linea
   base. No modifica codigo ni objetos de B2. Puede tardar lo mismo que el
   proceso anterior (incluso horas); ejecutarlo en una ventana independiente.

   Empresa  : 1807
   Vigencia : 4320. Cambiar solamente @IdVigencia a 3993 para la anterior.
   Evidencia: activar Ctrl+Shift+F en SSMS antes de ejecutar y guardar como
              COBRANZA_BASE_B2_LEGACY_1807_4320.rpt.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=1807,
        @IdVigencia int=4320,
        @CacheId bigint,
        @IdSolTipo int,
        @IdVencida int,
        @FecIni varchar(16),
        @FecFin varchar(16),
        @PerfilClave varchar(2000),
        @Inicio datetime2(3)=SYSDATETIME();

IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY',N'P') IS NULL
    THROW 53400,'Falta el procedimiento de referencia dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY. Ejecute primero el SQL 04.',1;

IF OBJECT_ID(N'dbo.bf_CobranzaCache_ConsultaV2',N'U') IS NULL
    THROW 53401,'Falta dbo.bf_CobranzaCache_ConsultaV2 para recuperar los mismos parametros usados por B3.',1;

SELECT TOP (1)
       @CacheId=C.CacheId,
       @IdSolTipo=C.IdSolTipo,
       @IdVencida=C.IdVencida,
       @FecIni=C.FecIni,
       @FecFin=C.FecFin,
       @PerfilClave=C.PerfilClave
FROM dbo.bf_CobranzaCache_ConsultaV2 AS C WITH (NOLOCK)
WHERE C.IdEmpresa=@IdEmpresa
  AND C.IdVigencia=@IdVigencia
  AND C.EsUniverso=1
  AND C.Estado='COMPLETA'
ORDER BY COALESCE(C.FechaCargaFin,C.FechaCargaInicio) DESC,C.CacheId DESC;

IF @CacheId IS NULL
    THROW 53402,'No existe una cache universo COMPLETA para la empresa y vigencia indicadas.',1;

DECLARE @Perfiles dbo.ListInt;

INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT TRY_CONVERT(int,S.value)
FROM STRING_SPLIT(ISNULL(@PerfilClave,''),',') AS S
WHERE TRY_CONVERT(int,S.value) IS NOT NULL;

IF NOT EXISTS(SELECT 1 FROM @Perfiles)
    THROW 53403,'La cache seleccionada no contiene perfiles validos.',1;

SELECT N'BASE_B2_LEGACY' AS Ejecucion,
       N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY' AS Procedimiento,
       @CacheId AS CacheId,@IdEmpresa AS IdEmpresa,@IdVigencia AS IdVigencia,
       @IdSolTipo AS IdSolTipo,@IdVencida AS IdVencida,
       @FecIni AS FecIni,@FecFin AS FecFin,@PerfilClave AS PerfilClave,
       @Inicio AS FechaInicio;

EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY
     @idEmpresa=@IdEmpresa,
     @idSolTipo=@IdSolTipo,
     @FecIni=@FecIni,
     @FecFin=@FecFin,
     @idVencida=@IdVencida,
     @IdPerfil=@Perfiles,
     @idVIgencia=@IdVigencia;

SELECT N'FIN_BASE_B2_LEGACY' AS Ejecucion,
       @Inicio AS FechaInicio,
       SYSDATETIME() AS FechaFin,
       DATEDIFF_BIG(millisecond,@Inicio,SYSDATETIME()) AS Milisegundos;
