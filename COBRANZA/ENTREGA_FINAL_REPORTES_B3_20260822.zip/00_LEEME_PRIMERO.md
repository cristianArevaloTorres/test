# Entrega final Reportes B3 - Cobranza y Sabana

La entrega esta separada para poder tomar la instalacion sin mezclarla con
cargas, pruebas, monitores o contingencias.

## Instalacion

- `SQL_01_INSTALACION/COBRANZA`: objetos, indices, motor SET e integracion del
  flujo final B3. Ejecutar `01` a `09` conforme a su archivo `00`.
- `SQL_01_INSTALACION/SABANA`: stored procedures V2 y homologacion del orden de
  columnas. Ejecutar `01` y `02` conforme a su archivo `00`.

## Scripts que no forman parte de la instalacion

- `SQL_02_ADICIONALES/COBRANZA`: configuracion por empresa, cargas reales,
  menu, monitores, evidencia, contingencia y comparacion legacy-B2 contra B3.
- `SQL_02_ADICIONALES/SABANA`: configuracion opcional de passwords.

## Codigo

- `CODIGO/API_REPORTES`: archivos modificados del API y pruebas.
- `CODIGO/FRONT_B3`: componentes modificados de Cobranza y Sabana.

Las rutas internas a partir de `src`, `scripts` y `pom.xml` se conservaron para
copiar cada archivo sobre el proyecto correspondiente.

## Alcance y validacion

- B2 permanece intacto.
- La portada de Cobranza ya no contiene vigencias, meses ni observaciones
  fijas; utiliza BD y el rango recibido por los filtros.
- El flujo B3 tradicional y el de cache usan el mismo motor SET.
- El orden de hojas/columnas de Sabana se obtiene de los resultsets y la
  configuracion de BD.
- Suite Maven del API y build de produccion del frontend: correctos.
- `MANIFEST_SHA256.txt` permite verificar la integridad de la entrega.
