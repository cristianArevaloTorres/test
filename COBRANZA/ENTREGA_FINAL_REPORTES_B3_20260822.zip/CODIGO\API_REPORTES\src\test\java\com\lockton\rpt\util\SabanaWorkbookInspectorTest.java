package com.lockton.rpt.util;

import java.io.File;
import java.io.FileInputStream;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

/** Inspector de evidencias B2/B3 de la Sabana de Beneficios. */
public class SabanaWorkbookInspectorTest {

    private static final DataFormatter FORMATTER =
            new DataFormatter(Locale.ROOT);

    @Test
    public void comparaEvidenciasPorEmpresa() throws Exception {
        String dir = System.getProperty("sabana.evidencia.dir", "");
        Assumptions.assumeTrue(!dir.trim().isEmpty(),
                "Use -Dsabana.evidencia.dir=<directorio>");

        List<String[]> pares = Arrays.asList(
                new String[] {"CORTEVA", "20260818115023 CORTEVA B2.xlsx",
                        "20260818140850 CORTEVA B3 CICLO 2.xlsx"},
                new String[] {"SSGT", "20260818121106 SSGT b2.xlsx",
                        "20260818141026 SSGT B3 CICLO 2.xlsx"},
                new String[] {"ATT", "20260818122435 ATT B2.xlsx",
                        "20260818140620 ATT B3 CICLO 2.xlsx"},
                new String[] {"BH", "20260818123058 bh b2.xlsx",
                        "20260818140432 BH B3 ciclo 2.xlsx"});

        for (String[] par : pares) {
            File b2 = new File(dir, par[1]);
            File b3 = new File(dir, par[2]);
            Assumptions.assumeTrue(b2.isFile() && b3.isFile(),
                    "Faltan evidencias de " + par[0]);
            try (Workbook patron = open(b2); Workbook candidato = open(b3)) {
                comparar(par[0], patron, candidato);
            }
        }
    }

    private static void comparar(String empresa, Workbook b2, Workbook b3) {
        System.out.println("SABANA " + empresa + " hojasB2=" + nombres(b2));
        System.out.println("SABANA " + empresa + " hojasB3=" + nombres(b3));

        Map<String, Sheet> hojasB2 = indexar(b2);
        Map<String, Sheet> hojasB3 = indexar(b3);
        Set<String> todas = new LinkedHashSet<>();
        todas.addAll(hojasB2.keySet());
        todas.addAll(hojasB3.keySet());
        for (String clave : todas) {
            Sheet patron = hojasB2.get(clave);
            Sheet candidato = hojasB3.get(clave);
            if (patron == null || candidato == null) {
                System.out.println("SABANA " + empresa + " hoja=" + clave
                        + " estado=" + (patron == null ? "SOLO_B3" : "SOLO_B2"));
                continue;
            }
            Header h2 = header(patron);
            Header h3 = header(candidato);
            List<String> extras = diferencia(h3.values, h2.values);
            List<String> faltantes = diferencia(h2.values, h3.values);
            List<String> comunesB2 = interseccion(h2.values, h3.values);
            List<String> comunesB3 = interseccion(h3.values, h2.values);
            System.out.println("SABANA " + empresa
                    + " hojaB2='" + patron.getSheetName() + "'"
                    + " hojaB3='" + candidato.getSheetName() + "'"
                    + " filasB2=" + (patron.getLastRowNum() + 1)
                    + " filasB3=" + (candidato.getLastRowNum() + 1)
                    + " headerRowB2=" + (h2.row + 1)
                    + " headerRowB3=" + (h3.row + 1)
                    + " colsB2=" + h2.values.size()
                    + " colsB3=" + h3.values.size()
                    + " extrasB3=" + extras
                    + " faltantesB3=" + faltantes
                    + " ordenComunIgual=" + comunesB2.equals(comunesB3));
            if ("CORTEVA".equals(empresa)
                    && "vida".equals(clave)) {
                System.out.println("SABANA_DUPLICADOS CORTEVA VIDA"
                        + " B2=" + duplicadosExactos(patron, h2.row)
                        + " B3=" + duplicadosExactos(candidato, h3.row)
                        + " llavesB2=" + llavesIdentidad(patron, h2)
                        + " llavesB3=" + llavesIdentidad(candidato, h3));
            }
            if (!h2.values.equals(h3.values)) {
                System.out.println("SABANA_HEADERS " + empresa
                        + " hoja='" + patron.getSheetName() + "' B2=" + h2.values);
                System.out.println("SABANA_HEADERS " + empresa
                        + " hoja='" + candidato.getSheetName() + "' B3=" + h3.values);
            }
        }
    }

    private static int llavesIdentidad(Sheet sheet, Header header) {
        List<String> identity = Arrays.asList("No. Empleado", "Certificado",
                "Paterno", "Materno", "Nombres", "Parentesco");
        List<Integer> columns = new ArrayList<>();
        for (String name : identity) {
            String key = normalizar(name);
            for (int c = 0; c < header.values.size(); c++) {
                if (key.equals(normalizar(header.values.get(c)))) {
                    columns.add(c);
                    break;
                }
            }
        }
        Set<String> keys = new LinkedHashSet<>();
        for (int r = header.row + 1; r <= sheet.getLastRowNum(); r++) {
            Row row = sheet.getRow(r);
            if (row == null) continue;
            List<String> parts = new ArrayList<>();
            for (int column : columns) {
                parts.add(text(row.getCell(column)));
            }
            keys.add(String.join("\u001f", parts));
        }
        return keys.size();
    }

    private static int duplicadosExactos(Sheet sheet, int headerRow) {
        Set<String> signatures = new LinkedHashSet<>();
        int rows = 0;
        for (int r = headerRow + 1; r <= sheet.getLastRowNum(); r++) {
            Row row = sheet.getRow(r);
            if (row == null) continue;
            List<String> values = values(row);
            if (values.stream().allMatch(String::isEmpty)) continue;
            rows++;
            signatures.add(String.join("\u001f", values));
        }
        return rows - signatures.size();
    }

    private static Header header(Sheet sheet) {
        Header best = new Header(0, new ArrayList<>());
        int limit = Math.min(sheet.getLastRowNum(), 20);
        for (int r = 0; r <= limit; r++) {
            Row row = sheet.getRow(r);
            if (row == null) continue;
            List<String> values = values(row);
            if (values.size() > best.values.size()) best = new Header(r, values);
        }
        return best;
    }

    private static List<String> values(Row row) {
        List<String> result = new ArrayList<>();
        int last = Math.max(0, row.getLastCellNum());
        for (int c = 0; c < last; c++) result.add(text(row.getCell(c)));
        while (!result.isEmpty() && result.get(result.size() - 1).isEmpty()) {
            result.remove(result.size() - 1);
        }
        return result;
    }

    private static List<String> diferencia(List<String> left, List<String> right) {
        Set<String> rightKeys = new LinkedHashSet<>();
        for (String value : right) rightKeys.add(normalizar(value));
        List<String> result = new ArrayList<>();
        for (String value : left) {
            if (!rightKeys.contains(normalizar(value))) result.add(value);
        }
        return result;
    }

    private static List<String> interseccion(List<String> left, List<String> right) {
        Set<String> rightKeys = new LinkedHashSet<>();
        for (String value : right) rightKeys.add(normalizar(value));
        List<String> result = new ArrayList<>();
        for (String value : left) {
            if (rightKeys.contains(normalizar(value))) result.add(normalizar(value));
        }
        return result;
    }

    private static Map<String, Sheet> indexar(Workbook workbook) {
        Map<String, Sheet> result = new LinkedHashMap<>();
        for (Sheet sheet : workbook) {
            result.putIfAbsent(normalizar(sheet.getSheetName()), sheet);
        }
        return result;
    }

    private static List<String> nombres(Workbook workbook) {
        List<String> result = new ArrayList<>();
        for (Sheet sheet : workbook) result.add(sheet.getSheetName());
        return result;
    }

    private static String normalizar(String value) {
        String normalized = Normalizer.normalize(
                value == null ? "" : value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .replaceAll("[^A-Za-z0-9]", "")
                .toLowerCase(Locale.ROOT);
        return normalized;
    }

    private static String text(Cell cell) {
        return cell == null ? "" : FORMATTER.formatCellValue(cell).trim();
    }

    private static Workbook open(File file) throws Exception {
        try (FileInputStream input = new FileInputStream(file)) {
            return new XSSFWorkbook(input);
        }
    }

    private static final class Header {
        private final int row;
        private final List<String> values;

        private Header(int row, List<String> values) {
            this.row = row;
            this.values = values;
        }
    }
}
