# Scripts adicionales de Sabana

`01_CONFIGURAR_PASSWORDS_EXCEL_OPCIONAL.sql` no forma parte de la instalacion
obligatoria. Contiene valores `PRUEBA` y solo debe ejecutarse despues de
cambiar empresa y passwords por valores autorizados.
