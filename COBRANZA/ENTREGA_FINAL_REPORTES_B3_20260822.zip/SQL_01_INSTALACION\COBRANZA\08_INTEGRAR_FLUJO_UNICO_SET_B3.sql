/*
   PUNTO DE ENTRADA UNICO B3

   Tanto el flujo tradicional como bf_CobranzaCache_CargarUnaV2 llaman a
   dbo.ObtenCobranzaConcentrada_otro_V2_BF3. Desde este script ese punto de
   entrada siempre consume la rama SET optimizada.

   Los procedimientos LEGACY/OPT permanecen instalados como respaldo tecnico,
   pero no participan en el flujo normal y no hay bandera de version SQL.
   La configuracion por empresa sigue decidiendo solamente CACHE/TRADICIONAL.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET',N'P') IS NULL
    THROW 52700,'Falta instalar la rama SET B3 con los scripts 05, 06 y 07.',1;
IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3_LEGACY',N'P') IS NULL
    THROW 52701,'Falta la copia de respaldo LEGACY creada por el script 04.',1;

DECLARE @Def nvarchar(max)=N'
CREATE OR ALTER PROCEDURE dbo.ObtenCobranzaConcentrada_otro_V2_BF3
    @idEmpresa int=0,
    @idSolTipo int=0,
    @FecIni varchar(16)='''',
    @FecFin varchar(16)='''',
    @idVencida int=0,
    @IdPerfil dbo.ListInt READONLY,
    @idVIgencia int=0
AS
BEGIN
    SET NOCOUNT ON;
    /* BF3_FLUJO_UNICO_SET_V1 */
    BEGIN TRY
        INSERT dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES(''cobranza_bf3_ruta_sql'',
               CONCAT(''ruta=SET_UNICA; empresa='',@idEmpresa,''; vigencia='',@idVIgencia,
                      ''; cache='',ISNULL(TRY_CONVERT(varchar(10),SESSION_CONTEXT(N''bf_CobranzaCacheCapturar'')),''0'')));
    END TRY BEGIN CATCH END CATCH;

    EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_SET
         @idEmpresa=@idEmpresa,@idSolTipo=@idSolTipo,@FecIni=@FecIni,@FecFin=@FecFin,
         @idVencida=@idVencida,@IdPerfil=@IdPerfil,@idVIgencia=@idVIgencia;
END;';
EXEC sys.sp_executesql @Def;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3'))
   NOT LIKE N'%BF3_FLUJO_UNICO_SET_V1%'
    THROW 52702,'No quedo instalado el punto de entrada unico B3.',1;

/* Las banderas antiguas se dejan sin efecto para evitar configuraciones
   contradictorias. El wrapper ya no las consulta. */
UPDATE dbo.ff_Parametro
SET paValor='0',paDescripcion='Sin uso: Cobranza B3 consume siempre motor SET unico',
    paFechaUmod=GETDATE()
WHERE UPPER(LTRIM(RTRIM(ISNULL(paClase,'')))) IN('COBRANZA_SQL_OPT_V2','COBRANZA_SQL_SET_V3')
  AND LTRIM(RTRIM(ISNULL(paValor,'')))<>'0';

SELECT N'OK' Estado,
       N'dbo.ObtenCobranzaConcentrada_otro_V2_BF3 -> ..._SET' FlujoB3,
       N'Cache y tradicional comparten calculo; B2 intacto' Alcance;
