/*
   SIMULACION SQL DEL REPORTE DE COBRANZA B3 - ZURICH SANTANDER

   Empresa  : 1807
   Vigencia : 4320 por defecto; cambie solamente @IdVigencia a 3993 para la
              vigencia anterior.

   IMPORTANTE
   - La portada ya no usa una vigencia ni meses fijos: toma el rango recibido
     por los filtros y la empresa/periodicidad consultadas en BD.
   - Este EXEC devuelve los mismos resultsets que consume el generador.
   - Ejecutarlo en SSMS no crea por si solo el archivo XLSX; el archivo se crea
     al solicitar Cobranza desde el menu/API de B3.
   - Reutiliza la ultima cache universo COMPLETA. No fuerza una recarga.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=1807,
        @IdVigencia int=4320,
        @CacheId bigint,
        @IdSolTipo int,
        @IdVencida int,
        @FecIni varchar(16),
        @FecFin varchar(16),
        @PerfilClave varchar(2000);

IF OBJECT_ID(N'dbo.ReporteCobranzaConcentrada_BF3_Cache',N'P') IS NULL
    THROW 53300,'Falta dbo.ReporteCobranzaConcentrada_BF3_Cache.',1;

SELECT TOP (1)
       @CacheId=C.CacheId,
       @IdSolTipo=C.IdSolTipo,
       @IdVencida=C.IdVencida,
       @FecIni=C.FecIni,
       @FecFin=C.FecFin,
       @PerfilClave=C.PerfilClave
FROM dbo.bf_CobranzaCache_ConsultaV2 AS C WITH (NOLOCK)
WHERE C.IdEmpresa=@IdEmpresa
  AND C.IdVigencia=@IdVigencia
  AND C.EsUniverso=1
  AND C.Estado='COMPLETA'
ORDER BY COALESCE(C.FechaCargaFin,C.FechaCargaInicio) DESC,C.CacheId DESC;

IF @CacheId IS NULL
    THROW 53301,'No existe una cache universo COMPLETA para empresa 1807 y la vigencia solicitada.',1;

DECLARE @Perfiles dbo.ListInt;

INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT TRY_CONVERT(int,S.value)
FROM STRING_SPLIT(ISNULL(@PerfilClave,''),',') AS S
WHERE TRY_CONVERT(int,S.value) IS NOT NULL;

IF NOT EXISTS(SELECT 1 FROM @Perfiles)
    THROW 53302,'La cache no contiene perfiles validos.',1;

/* Esta primera cuadricula identifica exactamente los parametros usados. */
SELECT N'PARAMETROS_EXEC' AS Resultado,
       @CacheId AS CacheId,@IdEmpresa AS IdEmpresa,@IdVigencia AS IdVigencia,
       @IdSolTipo AS IdSolTipo,@IdVencida AS IdVencida,
       @FecIni AS FecIni,@FecFin AS FecFin,
       (SELECT COUNT(*) FROM @Perfiles) AS CantidadPerfiles;

/*
   Salida esperada:
     Informacion, Concentrada, Desglosada,
     cinco bloques de Total por coberturas y Planes_Parentesco.
*/
EXEC dbo.ReporteCobranzaConcentrada_BF3_Cache
     @idEmpresa=@IdEmpresa,
     @idSolTipo=@IdSolTipo,
     @FecIni=@FecIni,
     @FecFin=@FecFin,
     @idVencida=@IdVencida,
     @IdPerfil=@Perfiles,
     @idVIgencia=@IdVigencia;
