# Instalacion de Sabana de beneficios B3

Ejecutar en este orden:

1. `01_INSTALAR_SP_SABANA_V2.sql`
2. `02_HOMOLOGAR_ORDEN_COLUMNAS_CICLO2.sql`

El primer script instala los stored procedures V2. El segundo instala la
configuracion que homologa el orden de columnas de las empresas verificadas
contra B2 y al final muestra la validacion de encabezados.

La configuracion de passwords no forma parte de la instalacion; esta separada
en `SQL_02_ADICIONALES/SABANA`.

Tambien deben desplegarse los archivos correspondientes de
`CODIGO/API_REPORTES` y `CODIGO/FRONT_B3`. El orden final de hojas depende del
orden de los resultsets/configuracion de BD y del generador, no de un indice
Java fijo por empresa.
