# Scripts adicionales de Cobranza B3

Estos archivos no forman parte de la instalacion obligatoria. Se ejecutan solo
cuando corresponda a la empresa, prueba u operacion indicada.

## Configuracion y cargas

- `01_CONFIGURAR_EMPRESA_WORKER.sql`: configura empresa y horario del worker;
  revisar `@IdEmpresa` y `@HoraWorker`.
- `02_CONFIGURAR_CACHE_ZURICH_1807.sql`: activa cache para Zurich, empresa 1807.
- `03_CARGA_INICIAL_ZURICH_1807.sql`: carga las vigencias 4320 y 3993.
- `05_ASIGNAR_MENU_COBRANZA_ZURICH.sql`: asigna el menu; inicia en vista previa
  con `@Aplicar=0`.
- `09_CARGA_VALIDACION_EMPRESA_186.sql`: reconstruye hasta cuatro vigencias de
  la empresa 186 para una prueba real.

## Monitoreo y evidencia

- `04_MONITOREAR_ZURICH_1807.sql`: monitor Zurich de solo lectura.
- `06_EXEC_SIMULACION_REPORTE_ZURICH.sql`: devuelve los resultsets del reporte
  desde la cache completa; no crea el XLSX.
- `07_SELECTS_POST_EJECUCION.sql`: evidencia de tablas, cache, resultados y
  logs; contiene solo SELECT.
- `08_MONITOR_GENERAL_SOLO_LECTURA.sql`: seguimiento general de una carga.
- `10_VALIDAR_CACHE_BASE.sql`: validacion posterior a configuracion/carga;
  inicialmente espera empresa 186 y cuatro vigencias completas.

## Contingencia

- `11_LIBERAR_CARGAS_ATORADAS.sql`: cambia a ERROR una carga abandonada despues
  de comprobar que ya no existe una sesion procesandola. Revisar variables;
  contiene `@Aplicar=1`.

## Comparacion B2 contra B3

1. Activar Resultados a archivo (`Ctrl+Shift+F`) en SSMS.
2. Ejecutar `12_EXEC_COBRANZA_BASE_B2_LEGACY.sql` y guardar la salida.
3. Ejecutar `13_EXEC_COBRANZA_B3_SET.sql` con la misma empresa y vigencia.
4. Confirmar que la primera cuadricula tenga el mismo CacheId, rango, perfiles
   y demas parametros; despues comparar los resultsets en el mismo orden.

El script `12` usa la copia congelada del procedimiento original consumido por
B2 y puede tardar horas. El `13` ejecuta directamente el motor SET de B3. Los
dos estan configurados para empresa 1807, vigencia 4320; para la anterior se
cambia unicamente `@IdVigencia` a 3993. Ninguno crea el XLSX ni modifica B2.
