USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

/*
    HOMOLOGACION DE COLORES - COBRANZA B3 (catReportesId = 11)

    Referencia verificada en archivos B2:
      Portada "Informacion":       #007FFF (Azure Color Wheel)
      Encabezados de datos:         #6699CC (Blue Gray)

    B3 utilizaba Gray/#808080. Este script actualiza solamente la
    configuracion visual del reporte de Cobranza. No modifica hojas,
    columnas, registros, filtros, importes ni procedimientos almacenados.

    IMPORTANTE:
    El generador vigente de Cobranza tambien tenia el color codificado en
    JDBCCobranza.java. Por eso este SQL debe desplegarse junto con el archivo
    Java incluido en la entrega.
*/

DECLARE @ReporteId int = 11,
        @FilasActualizadas int = 0;

BEGIN TRY
    IF OBJECT_ID(N'dbo.bf_RepConf_Tabla', N'U') IS NULL
        THROW 52201, 'No existe dbo.bf_RepConf_Tabla en FlexiForbesv2.', 1;

    IF OBJECT_ID(N'dbo.bf_CatReportes', N'U') IS NOT NULL
       AND NOT EXISTS
       (
           SELECT 1
           FROM dbo.bf_CatReportes
           WHERE catReportesId = @ReporteId
             AND UPPER(LTRIM(RTRIM(catReportesNombre))) COLLATE Latin1_General_100_BIN2 = N'COBRANZA'
       )
        THROW 52202, 'El catReportesId 11 no corresponde al reporte de Cobranza.', 1;

    BEGIN TRANSACTION;

    /* Portada, tanto global como especifica por empresa. */
    UPDATE dbo.bf_RepConf_Tabla
       SET colorFondo = N'#007FFF'
     WHERE catReportesId = @ReporteId
       AND UPPER(LTRIM(RTRIM(grupo))) COLLATE Latin1_General_100_BIN2 = N'INFORMACION'
       AND UPPER(LTRIM(RTRIM(ISNULL(colorFondo,N'')))) COLLATE Latin1_General_100_BIN2
           IN (N'GRAY',N'GREY',N'#808080',N'#6699CC');

    SET @FilasActualizadas = @FilasActualizadas + @@ROWCOUNT;

    /* Encabezados de todas las hojas y bloques de datos. */
    UPDATE dbo.bf_RepConf_Tabla
       SET colorFondo = N'#6699CC'
     WHERE catReportesId = @ReporteId
       AND UPPER(LTRIM(RTRIM(grupo))) COLLATE Latin1_General_100_BIN2 <> N'INFORMACION'
       AND UPPER(LTRIM(RTRIM(ISNULL(colorFondo,N'')))) COLLATE Latin1_General_100_BIN2
           IN (N'GRAY',N'GREY',N'#808080');

    SET @FilasActualizadas = @FilasActualizadas + @@ROWCOUNT;

    IF (
        SELECT COUNT(*)
        FROM dbo.bf_RepConf_Tabla
        WHERE idEmpresa = 0
          AND catReportesId = @ReporteId
          AND UPPER(LTRIM(RTRIM(grupo))) COLLATE Latin1_General_100_BIN2 = N'INFORMACION'
          AND colorFondo COLLATE Latin1_General_100_BIN2 = N'#007FFF'
    ) <> 1
        THROW 52203, 'La configuracion global de Informacion no quedo con #007FFF.', 1;

    IF (
        SELECT COUNT(*)
        FROM dbo.bf_RepConf_Tabla
        WHERE idEmpresa = 0
          AND catReportesId = @ReporteId
          AND UPPER(LTRIM(RTRIM(grupo))) COLLATE Latin1_General_100_BIN2 <> N'INFORMACION'
          AND colorFondo COLLATE Latin1_General_100_BIN2 = N'#6699CC'
    ) <> 11
        THROW 52204, 'No se encontraron los once bloques globales de Cobranza con #6699CC.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.bf_RepConf_Tabla
        WHERE catReportesId = @ReporteId
          AND UPPER(LTRIM(RTRIM(ISNULL(colorFondo,N'')))) COLLATE Latin1_General_100_BIN2
              IN (N'GRAY',N'GREY',N'#808080')
    )
        THROW 52205, 'Aun existen configuraciones de Cobranza B3 con el gris anterior.', 1;

    COMMIT TRANSACTION;

    SELECT @FilasActualizadas AS FilasActualizadas,
           N'#007FFF' AS ColorPortada,
           N'#6699CC' AS ColorEncabezados,
           N'Generar una cobranza nueva despues de desplegar API Reports.' AS SiguientePaso;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
