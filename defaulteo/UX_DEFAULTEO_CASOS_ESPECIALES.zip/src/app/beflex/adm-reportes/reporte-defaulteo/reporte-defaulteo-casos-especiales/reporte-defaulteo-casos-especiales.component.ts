import { Component, ElementRef, OnDestroy, OnInit } from '@angular/core';
import { MenusService } from 'src/app/services/menus.service';
import { GLOBAL } from "../../../../services/global";
import { EmpleadoService } from "../../../../services/empleado.service";
import { EmpresaThemeService } from '../../../../services/empresa-theme.service';

@Component({
  selector: 'app-reporte-defaulteo-casos-especiales',
  templateUrl: './reporte-defaulteo-casos-especiales.component.html',
  styleUrls: [
    '../reporte-defaulteo.component.css',
    './reporte-defaulteo-casos-especiales.component.css'
  ]
})
export class ReporteDefaulteoCasosEspecialesComponent implements OnInit, OnDestroy {

  private stopCompanyTheme: () => void = null;

  public title: string;
  public banner;
  public urlWs;
  public identity;
  public id;

  constructor(
    private _menuService: MenusService,
    private _empleadoService: EmpleadoService,
    private empresaTheme: EmpresaThemeService,
    private elementRef: ElementRef<HTMLElement>
  ) {
    this.title = 'Crear y Actualizar Solicitudes Casos especiales';
    this.urlWs = GLOBAL.url2;
  }

  ngOnInit() {
    this.stopCompanyTheme = this.empresaTheme.applyTo(this.elementRef.nativeElement);
    this.banner = this._menuService.getbackground();
    this.identity = this._empleadoService.getIdentity();
    this.menuId();
  }

  ngOnDestroy() {
    if (this.stopCompanyTheme) {
      this.stopCompanyTheme();
    }
  }

  menuId() {
    let informacion = JSON.parse(localStorage.getItem("MenuPadre"));
    if (informacion != "undefined") {
      this.id = informacion;
    } else {
      this.id = null;
    }
  }

}
