# Comandos Git — mejora UX de Defaulteo de casos especiales

Este bloque agrega únicamente los cinco archivos de presentación modificados y el servicio que traduce la configuración visual legacy de cada empresa. No incluye servicios de negocio, archivos de ambiente, backend ni la pantalla nueva de Defaulteo 1, 2 y 3 que ya no se utilizará.

```powershell
$RepoFront = 'C:\RUTA\AL\CLON\BeFlex3'
Set-Location -LiteralPath $RepoFront

if (-not (Test-Path -LiteralPath '.git')) {
    throw "Esta carpeta no es un clon Git. Ajusta `$RepoFront: $RepoFront"
}

$FrontFiles = @(
    'src/app/beflex/adm-reportes/reporte-defaulteo/reporte-defaulteo-casos-especiales/reporte-defaulteo-casos-especiales.component.ts',
    'src/app/beflex/adm-reportes/reporte-defaulteo/reporte-defaulteo-casos-especiales/reporte-defaulteo-casos-especiales.component.html',
    'src/app/beflex/adm-reportes/reporte-defaulteo/reporte-defaulteo-casos-especiales/reporte-defaulteo-casos-especiales.component.css',
    'src/app/beflex/adm-reportes/reporte-defaulteo/tabla-defaulteo-casos-especiales/tabla-defaulteo-casos-especiales.component.html',
    'src/app/beflex/adm-reportes/reporte-defaulteo/tabla-defaulteo-casos-especiales/tabla-defaulteo-casos-especiales.component.css',
    'src/app/services/empresa-theme.service.ts'
)

$Missing = @($FrontFiles | Where-Object { -not (Test-Path -LiteralPath $_) })
if ($Missing.Count -gt 0) {
    throw "Faltan archivos en el frontend:`n$($Missing -join "`n")"
}

git remote -v
git branch --show-current
git status --short -- $FrontFiles

$Unexpected = @(git diff --cached --name-only | Where-Object { $_ -notin $FrontFiles })
if ($Unexpected.Count -gt 0) {
    throw "Hay archivos previamente preparados que no pertenecen a esta entrega:`n$($Unexpected -join "`n")"
}

git add -- $FrontFiles
git diff --cached --check
if ($LASTEXITCODE -ne 0) {
    throw 'Git detectó errores en los cambios preparados.'
}

git diff --cached --name-status
git commit -m "Mejora UX y tematización de defaulteo de casos especiales"
if ($LASTEXITCODE -ne 0) {
    throw 'No fue posible crear el commit del frontend.'
}

$Branch = "$(git branch --show-current)".Trim()
if ([string]::IsNullOrWhiteSpace($Branch)) {
    throw 'No se pudo determinar la rama actual.'
}

git push -u origin $Branch
```

Después del `push`, verifica:

```powershell
git status --short
git log -1 --oneline
git branch -vv
```

Los demás cambios locales que pudieran aparecer en `git status` no se agregan al commit, porque el bloque utiliza una lista explícita de archivos.
