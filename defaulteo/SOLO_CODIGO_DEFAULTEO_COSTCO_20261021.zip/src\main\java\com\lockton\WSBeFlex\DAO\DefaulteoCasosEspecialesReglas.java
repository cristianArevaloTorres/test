package com.lockton.WSBeFlex.DAO;

import java.util.Map;

/** Reglas de homologacion entre casos especiales y el defaulteo individual. */
final class DefaulteoCasosEspecialesReglas {

    private DefaulteoCasosEspecialesReglas() {
    }

    /**
     * El tipo 3 conserva la seleccion anterior y agrega los dependientes
     * elegibles; el proceso individual lo ejecuta con la regla def1.
     */
    static String normalizarTipoMotor(String tipoDefaulteo) {
        if (tipoDefaulteo == null) {
            return null;
        }

        String tipo = tipoDefaulteo.trim().toLowerCase();
        if ("3".equals(tipo) || "def3".equals(tipo)) {
            return "def1";
        }
        if ("1".equals(tipo) || "def1".equals(tipo)) {
            return "def1";
        }
        if ("2".equals(tipo) || "def2".equals(tipo)) {
            return "def2";
        }
        return tipoDefaulteo.trim();
    }

    /**
     * Conserva una sola tarifa por familiar. La misma tarifa para familiares
     * distintos se mantiene porque forma parte de su seleccion individual.
     */
    static boolean agregarTarifaCostoUnica(Map<String, String> tarifas,
            Object idTarifaCosto, Object costo, Object idEmpleado) {
        Integer tarifa = aEntero(idTarifaCosto);
        Integer empleado = aEntero(idEmpleado);
        if (tarifas == null || tarifa == null || empleado == null || costo == null) {
            return false;
        }

        String costoTexto = String.valueOf(costo).trim();
        if (costoTexto.isEmpty() || "null".equalsIgnoreCase(costoTexto)) {
            return false;
        }

        String clave = tarifa + "|" + empleado;
        if (!tarifas.containsKey(clave)) {
            tarifas.put(clave,
                    "<TarifaCosto TCidTarifaCosto=\"" + tarifa
                    + "\" Costo=\"" + costoTexto
                    + "\" idEmpleado=\"" + empleado
                    + "\"></TarifaCosto>");
        }
        return true;
    }

    static String construirXmlTarifas(Map<String, String> tarifas) {
        StringBuilder xml = new StringBuilder("<ROOT>");
        if (tarifas != null) {
            for (String tarifa : tarifas.values()) {
                xml.append(tarifa);
            }
        }
        return xml.append("</ROOT>").toString();
    }

    private static Integer aEntero(Object valor) {
        if (valor == null) {
            return null;
        }
        if (valor instanceof Number) {
            return ((Number) valor).intValue();
        }
        try {
            return Integer.valueOf(String.valueOf(valor).trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
