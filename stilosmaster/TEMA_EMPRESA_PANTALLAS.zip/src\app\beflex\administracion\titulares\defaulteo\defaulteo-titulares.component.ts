import { Component, ElementRef, OnDestroy, OnInit } from '@angular/core';
import { MenusService } from 'src/app/services/menus.service';
import { GLOBAL } from '../../../../services/global';
import { EmpleadoService } from '../../../../services/empleado.service';
import { EmpresaThemeService } from '../../../../services/empresa-theme.service';

@Component({
  selector: 'app-defaulteo-titulares',
  templateUrl: './defaulteo-titulares.component.html',
  styleUrls: ['./defaulteo-titulares.component.css']
})
export class DefaulteoTitularesComponent implements OnInit, OnDestroy {

  private stopCompanyTheme: () => void = null;

  public title: string;
  public banner;
  public urlWs;
  public identity;

  public id;
  public iconoAyuda;
  public textAyuda;

  constructor(
    private _menuService: MenusService,
    private _empleadoService: EmpleadoService,
    private empresaTheme: EmpresaThemeService,
    private elementRef: ElementRef<HTMLElement>
  ) {
    this.title = 'Defaulteo de solicitudes';
    this.urlWs = GLOBAL.url2;
  }

  ngOnInit() {
    this.stopCompanyTheme = this.empresaTheme.applyTo(this.elementRef.nativeElement);
    this.banner = this._menuService.getbackground();
    this.identity = this._empleadoService.getIdentity();
    this.menuId();
  }

  ngOnDestroy() {
    if (this.stopCompanyTheme) {
      this.stopCompanyTheme();
    }
  }

  menuId() {
    const informacion = JSON.parse(localStorage.getItem('MenuPadre'));
    if (informacion !== 'undefined') {
      this.id = informacion;
    } else {
      this.id = null;
    }
  }
}
