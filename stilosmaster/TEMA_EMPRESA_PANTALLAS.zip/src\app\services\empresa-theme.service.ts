import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';

interface EmpresaThemeColors {
  primary: string;
  primaryHover: string;
  primaryRgb: string;
  onPrimary: string;
  accentText: string;
  fontFamily: string;
  buttonFontFamily: string;
  buttonFontSize: string;
  buttonFontWeight: string;
}

@Injectable({ providedIn: 'root' })
export class EmpresaThemeService {

  private readonly defaultTheme: EmpresaThemeColors = {
    primary: '#0B73A8',
    primaryHover: '#09628F',
    primaryRgb: '11, 115, 168',
    onPrimary: '#FFFFFF',
    accentText: '#0B73A8',
    fontFamily: '',
    buttonFontFamily: '',
    buttonFontSize: '',
    buttonFontWeight: ''
  };

  constructor(@Inject(DOCUMENT) private document: Document) { }

  /**
   * Traduce las clases legacy del CSS de cada empresa a variables que pueden
   * consumir los componentes nuevos. Devuelve una funcion para liberar los
   * listeners cuando se abandona la pantalla.
   */
  public applyTo(host: HTMLElement): () => void {
    if (!host || !this.document || !this.document.defaultView) {
      return () => undefined;
    }

    let active = true;
    const timers: number[] = [];
    const links: HTMLLinkElement[] = [];
    const update = () => {
      if (active) {
        this.writeVariables(host, this.readTheme());
      }
    };
    const schedule = () => {
      [0, 100, 350, 1000].forEach(delay => {
        timers.push(this.document.defaultView.setTimeout(update, delay));
      });
    };
    const onStylesheetLoad = () => schedule();
    const bindCompanyLinks = () => {
      const candidates = Array.prototype.slice.call(
        this.document.querySelectorAll('link[rel="stylesheet"]')
      ) as HTMLLinkElement[];

      candidates
        .filter(link => this.isCompanyStylesheet(link))
        .forEach(link => {
          if (links.indexOf(link) === -1) {
            links.push(link);
            link.addEventListener('load', onStylesheetLoad);
          }
        });
    };

    bindCompanyLinks();
    schedule();

    const observer = typeof MutationObserver !== 'undefined'
      ? new MutationObserver(mutations => {
        const companyStyleChanged = mutations.some(mutation => {
          if (mutation.type === 'attributes') {
            return this.isCompanyStylesheet(mutation.target as HTMLLinkElement);
          }
          return Array.prototype.slice.call(mutation.addedNodes).some((node: Node) =>
            this.nodeContainsCompanyStylesheet(node)
          );
        });

        if (companyStyleChanged) {
          bindCompanyLinks();
          schedule();
        }
      })
      : null;

    if (observer) {
      observer.observe(this.document.documentElement, {
        attributes: true,
        attributeFilter: ['href'],
        childList: true,
        subtree: true
      });
    }

    return () => {
      active = false;
      timers.forEach(timer => this.document.defaultView.clearTimeout(timer));
      links.forEach(link => link.removeEventListener('load', onStylesheetLoad));
      if (observer) {
        observer.disconnect();
      }
    };
  }

  private readTheme(): EmpresaThemeColors {
    const wrapper = this.document.createElement('div');
    const baseTextProbe = this.document.createElement('span');
    const textProbe = this.document.createElement('span');
    const baseButtonProbe = this.document.createElement('button');
    const buttonProbe = this.document.createElement('button');

    wrapper.setAttribute('aria-hidden', 'true');
    wrapper.style.cssText = 'position:fixed;left:-10000px;top:-10000px;visibility:hidden;pointer-events:none;';
    textProbe.className = 'text-general-color';
    buttonProbe.className = 'btn-general-color';
    baseButtonProbe.type = 'button';
    buttonProbe.type = 'button';
    baseTextProbe.textContent = 'Base';
    textProbe.textContent = 'Tema';
    baseButtonProbe.textContent = 'Base';
    buttonProbe.textContent = 'Tema';
    wrapper.appendChild(baseTextProbe);
    wrapper.appendChild(textProbe);
    wrapper.appendChild(baseButtonProbe);
    wrapper.appendChild(buttonProbe);
    this.document.body.appendChild(wrapper);

    const view = this.document.defaultView;
    const baseTextStyle = view.getComputedStyle(baseTextProbe);
    const textStyle = view.getComputedStyle(textProbe);
    const baseButtonStyle = view.getComputedStyle(baseButtonProbe);
    const buttonStyle = view.getComputedStyle(buttonProbe);
    const primary = this.usableColor(buttonStyle.backgroundColor)
      ? buttonStyle.backgroundColor
      : this.defaultTheme.primary;
    const rgb = this.toRgb(primary);

    const theme: EmpresaThemeColors = {
      primary,
      primaryHover: this.darkenedRgb(rgb, 0.86),
      primaryRgb: rgb.join(', '),
      onPrimary: this.usableColor(buttonStyle.color)
        ? buttonStyle.color
        : this.defaultTheme.onPrimary,
      accentText: this.usableColor(textStyle.color)
        ? textStyle.color
        : primary,
      fontFamily: textStyle.fontFamily !== baseTextStyle.fontFamily ? textStyle.fontFamily : '',
      buttonFontFamily: buttonStyle.fontFamily !== baseButtonStyle.fontFamily ? buttonStyle.fontFamily : '',
      buttonFontSize: buttonStyle.fontSize !== baseButtonStyle.fontSize ? buttonStyle.fontSize : '',
      buttonFontWeight: buttonStyle.fontWeight !== baseButtonStyle.fontWeight ? buttonStyle.fontWeight : ''
    };

    this.document.body.removeChild(wrapper);
    return theme;
  }

  private writeVariables(host: HTMLElement, theme: EmpresaThemeColors): void {
    host.style.setProperty('--empresa-primary', theme.primary);
    host.style.setProperty('--empresa-primary-hover', theme.primaryHover);
    host.style.setProperty('--empresa-primary-rgb', theme.primaryRgb);
    host.style.setProperty('--empresa-on-primary', theme.onPrimary);
    host.style.setProperty('--empresa-accent-text', theme.accentText);
    this.writeOptionalVariable(host, '--empresa-font-family', theme.fontFamily);
    this.writeOptionalVariable(host, '--empresa-button-font-family', theme.buttonFontFamily);
    this.writeOptionalVariable(host, '--empresa-button-font-size', theme.buttonFontSize);
    this.writeOptionalVariable(host, '--empresa-button-font-weight', theme.buttonFontWeight);
  }

  private writeOptionalVariable(host: HTMLElement, name: string, value: string): void {
    if (value) {
      host.style.setProperty(name, value);
    } else {
      host.style.removeProperty(name);
    }
  }

  private isCompanyStylesheet(link: HTMLLinkElement): boolean {
    return !!link && link.tagName === 'LINK'
      && String(link.href || '').toLowerCase().indexOf('/stilos/general/') >= 0;
  }

  private nodeContainsCompanyStylesheet(node: Node): boolean {
    if (!node || node.nodeType !== 1) {
      return false;
    }
    const element = node as HTMLElement;
    if (element.tagName === 'LINK' && this.isCompanyStylesheet(element as HTMLLinkElement)) {
      return true;
    }
    return !!element.querySelector && Array.prototype.slice.call(
      element.querySelectorAll('link[rel="stylesheet"]')
    ).some((link: HTMLLinkElement) => this.isCompanyStylesheet(link));
  }

  private usableColor(value: string): boolean {
    const normalized = String(value || '').replace(/\s/g, '').toLowerCase();
    return !!normalized && normalized !== 'transparent' && normalized !== 'rgba(0,0,0,0)';
  }

  private toRgb(color: string): number[] {
    const rgbMatch = String(color || '').match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
    if (rgbMatch) {
      return [Number(rgbMatch[1]), Number(rgbMatch[2]), Number(rgbMatch[3])];
    }

    const hexMatch = String(color || '').trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
    if (hexMatch) {
      const normalized = hexMatch[1].length === 3
        ? hexMatch[1].split('').map(value => value + value).join('')
        : hexMatch[1];
      return [
        parseInt(normalized.substring(0, 2), 16),
        parseInt(normalized.substring(2, 4), 16),
        parseInt(normalized.substring(4, 6), 16)
      ];
    }

    return [11, 115, 168];
  }

  private darkenedRgb(rgb: number[], factor: number): string {
    return 'rgb(' + rgb.map(value => Math.max(0, Math.round(value * factor))).join(', ') + ')';
  }
}
