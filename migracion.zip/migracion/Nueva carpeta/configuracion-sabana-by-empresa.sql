-- ============================================================================
-- SCRIPT 0 — UNIVERSO COMPLETO: todas las hojas y columnas del reporte
-- Ejecutar SIEMPRE primero para orientarse.
-- ============================================================================
DECLARE @emp         INT = 186;   -- empresa objetivo AQUI USE DELOIITE
DECLARE @reporte     INT = 3;     -- 3 = Sábana de Beneficios 11 PARA REPORTE DE COBRANZA 
DECLARE @grupo       NVARCHAR(100) = 'Opcionales';  -- grupo/hoja a operar (ver Script 0)

-- 0A: Hojas configuradas (empresa propia + globales)
SELECT
    t.idEmpresa,
    CASE WHEN t.idEmpresa = @emp THEN 'empresa_propia'
         WHEN t.idEmpresa = 0   THEN 'global_fallback'
         ELSE 'otra'
    END                                        AS origen,
    t.indexTable                               AS orden_resultset,
    t.grupo,
    t.agruparPorColumna,
    t.columnaGrupo,
    t.activo,
    t.tituloTabla,
    t.colorFondo,
    t.colorLetra
FROM dbo.bf_RepConf_Tabla t
WHERE t.catReportesId = @reporte
  AND t.idEmpresa     IN (@emp, 0)
ORDER BY t.idEmpresa DESC, t.indexTable;

-- 0B: Columnas configuradas por hoja (empresa propia + globales)
SELECT
    c.idEmpresa,
    CASE WHEN c.idEmpresa = @emp THEN 'empresa_propia'
         WHEN c.idEmpresa = 0   THEN 'global_fallback'
         ELSE 'otra'
    END                                        AS origen,
    c.grupo,
    c.orden,
    c.campoOrigen,
    c.encabezado,
    c.visible,
    c.ancho,
    c.formato
FROM dbo.bf_RepConf_Columna c
WHERE c.catReportesId = @reporte
  AND c.idEmpresa     IN (@emp, 0)
ORDER BY c.idEmpresa DESC, c.grupo, c.orden;

-- 0C: Resumen — cuántas columnas por hoja (útil para ver qué hojas tienen config propia)
SELECT
    c.grupo,
    SUM(CASE WHEN c.idEmpresa = @emp THEN 1 ELSE 0 END) AS cols_empresa_propia,
    SUM(CASE WHEN c.idEmpresa = 0    THEN 1 ELSE 0 END) AS cols_global,
    SUM(CASE WHEN c.visible = 1      THEN 1 ELSE 0 END) AS cols_visibles,
    SUM(CASE WHEN c.visible = 0      THEN 1 ELSE 0 END) AS cols_ocultas
FROM dbo.bf_RepConf_Columna c
WHERE c.catReportesId = @reporte
  AND c.idEmpresa     IN (@emp, 0)
GROUP BY c.grupo
ORDER BY c.grupo;

-- 0D: Mapeo grupo → pestañas dinámicas
-- Un grupo con agruparPorColumna=1 genera N pestañas según los valores DISTINTOS
-- de NombrePestana (o columnaGrupo) que devuelve el SP para ese resultset.
-- Las pestañas dinámicas NO tienen fila propia en bf_RepConf_Tabla.
-- Para ocultarlas individualmente: cambiar ff_ConfiguracionSabana.CSPestana=0
-- para el plan opcion correspondiente (lo convierte en columna extra, no pestaña).
-- Para ocultar el grupo COMPLETO (todas sus sub-pestañas): Script 6 con activo=0.
SELECT
    t.grupo,
    t.agruparPorColumna,
    t.columnaGrupo,
    CASE t.agruparPorColumna
        WHEN 1 THEN 'Genera N pestañas dinámicas según ' + ISNULL(t.columnaGrupo,'NombrePestana') + ' del SP'
        ELSE        'Genera 1 pestaña fija con nombre del grupo'
    END AS como_genera_pestanas,
    t.indexTable AS orden_resultset,
    t.idEmpresa,
    CASE WHEN t.idEmpresa = @emp THEN 'empresa_propia' ELSE 'global_fallback' END AS origen
FROM dbo.bf_RepConf_Tabla t
WHERE t.catReportesId = @reporte
  AND t.idEmpresa     IN (@emp, 0)
ORDER BY t.idEmpresa DESC, t.indexTable;

-- 0E: TODAS las pestañas que genera el reporte (incluye las dinámicas)
-- bf_RepConf_Tabla solo tiene los GRUPOS (GMM, Vida, Opcionales, Mascotas).
-- Las sub-pestañas dinámicas (VIDA SA FIJA, DEDUCIBLE, etc.) vienen de
-- ff_ConfiguracionSabana.CSAlias donde CSPestana=1 para ese grupo.
-- CSPestana=0 → el plan se convierte en COLUMNA, no pestaña (no aparece en Excel).
SELECT
    CASE cs.CSidTipoSabana
        WHEN 1 THEN 'GMM'
        WHEN 2 THEN 'Vida'
        WHEN 3 THEN 'Opcionales'
    END                                                   AS grupo,
    cs.CSAlias                                            AS nombre_pestana_en_excel,
    CASE cs.CSPestana
        WHEN 1 THEN 'PESTAÑA — aparece en Excel'
        WHEN 0 THEN 'columna extra — NO aparece como pestaña'
    END                                                   AS tipo,
    cs.CSidPlanOpcion,
    cs.CSidVigencia
FROM dbo.ff_ConfiguracionSabana cs
INNER JOIN dbo.ff_Empresa e
    ON cs.CSidConfiguracion = e.EMidConfiguracion
WHERE e.EMidEmpresa    = @emp
  AND cs.CSIdEstatus    = 1
  AND cs.CSidTipoSabana IN (1, 2, 3)
ORDER BY cs.CSidTipoSabana, cs.CSPestana DESC, cs.CSAlias;



-- ============================================================================
-- SCRIPT 1 — VALIDAR (ANTES): ver la hoja y sus columnas actuales
-- Ejecutar ANTES de cualquier cambio para tener el estado de referencia.
-- ============================================================================

DECLARE @emp         INT = 186;   -- empresa objetivo AQUI USE DELOIITE
DECLARE @reporte     INT = 3;     -- 3 = Sábana de Beneficios 11 PARA REPORTE DE COBRANZA 
DECLARE @grupo       NVARCHAR(100) = 'GMM';  -- grupo/hoja a operar (ver Script 0)


SELECT 'HOJA' AS tipo, t.idEmpresa, t.grupo, t.indexTable AS orden_hoja,
       t.activo, t.agruparPorColumna, t.tituloTabla, NULL AS orden_col,
       NULL AS campoOrigen, NULL AS encabezado, NULL AS ancho, NULL AS formato
FROM dbo.bf_RepConf_Tabla t
WHERE t.catReportesId = @reporte
  AND t.idEmpresa     IN (@emp, 0)
  AND t.grupo         = @grupo

UNION ALL

SELECT 'COLUMNA', c.idEmpresa, c.grupo, NULL,
       c.visible, NULL, NULL, c.orden,
       c.campoOrigen, c.encabezado, c.ancho, c.formato
FROM dbo.bf_RepConf_Columna c
WHERE c.catReportesId = @reporte
  AND c.idEmpresa     IN (@emp, 0)
  AND c.grupo         = @grupo
ORDER BY tipo DESC, orden_col;


-- ============================================================================
-- SCRIPT 2 — MODIFICAR ENCABEZADO DE UNA COLUMNA
-- Cambia el texto que aparece como cabecera en el Excel.
-- Si la empresa no tiene config propia para esa columna, primero copiarla (Script 5).
-- ============================================================================

DECLARE @emp     INT          = 186;
DECLARE @reporte INT          = 3;
DECLARE @grupo   NVARCHAR(100)= 'GMM';
DECLARE @orden   INT          = 5;      -- orden de la columna (ver Script 0B)
DECLARE @nuevo_encabezado NVARCHAR(200) = 'Mi Nuevo Encabezado';

-- ANTES
SELECT orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = @emp
  AND grupo = @grupo AND orden = @orden;

UPDATE dbo.bf_RepConf_Columna
SET    encabezado = @nuevo_encabezado
WHERE  catReportesId = @reporte
  AND  idEmpresa     = @emp
  AND  grupo         = @grupo
  AND  orden         = @orden;

-- DESPUES
SELECT orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = @emp
  AND grupo = @grupo AND orden = @orden;



-- ============================================================================
-- SCRIPT 3 — OCULTAR / MOSTRAR UNA COLUMNA  (visible = 0 / 1)
-- visible=0: el SP sigue devolviendo el campo pero NO aparece en el Excel.
-- ============================================================================

DECLARE @emp     INT          = 186;
DECLARE @reporte INT          = 3;
DECLARE @grupo   NVARCHAR(100)= 'GMM';
DECLARE @orden   INT          = 7;
DECLARE @visible BIT          = 0;   -- 0 = ocultar, 1 = mostrar

-- ANTES
SELECT orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = @emp
  AND grupo = @grupo AND orden = @orden;

UPDATE dbo.bf_RepConf_Columna
SET    visible = @visible
WHERE  catReportesId = @reporte
  AND  idEmpresa     = @emp
  AND  grupo         = @grupo
  AND  orden         = @orden;

-- DESPUES
SELECT orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = @emp
  AND grupo = @grupo AND orden = @orden;



-- ============================================================================
-- SCRIPT 4 — AGREGAR UNA COLUMNA NUEVA
-- Usa el siguiente orden disponible (max+1) para no pisar las existentes.
-- campoOrigen debe coincidir EXACTAMENTE con el nombre de columna que devuelve el SP.
-- ============================================================================

DECLARE @emp     INT          = 186;
DECLARE @reporte INT          = 3;
DECLARE @grupo   NVARCHAR(100)= 'GMM';
DECLARE @campoOrigen  NVARCHAR(200) = 'NombreColumnaDelSP';  -- exacto, case-insensitive
DECLARE @encabezado   NVARCHAR(200) = 'Encabezado Visible';
DECLARE @visible      BIT           = 1;
DECLARE @ancho        INT           = 20;   -- ancho en caracteres aprox; NULL = auto
DECLARE @formato      NVARCHAR(100) = NULL; -- p.ej. '#,##0.00' para moneda; NULL = texto

-- Ver cuál es el siguiente orden disponible para este grupo/empresa
SELECT MAX(orden) + 1 AS siguiente_orden
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte
  AND idEmpresa     = @emp
  AND grupo         = @grupo;

-- ANTES: estado del grupo
SELECT orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = @emp AND grupo = @grupo
ORDER BY orden;

DECLARE @siguiente_orden INT;
SELECT @siguiente_orden = MAX(orden) + 1
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = @emp AND grupo = @grupo;

INSERT INTO dbo.bf_RepConf_Columna
    (idEmpresa, catReportesId, grupo, orden, campoOrigen, encabezado, visible, ancho, formato)
VALUES
    (@emp, @reporte, @grupo, @siguiente_orden, @campoOrigen, @encabezado, @visible, @ancho, @formato);

-- DESPUES
SELECT orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = @emp AND grupo = @grupo
ORDER BY orden;



-- ============================================================================
-- SCRIPT 5 — COPIAR CONFIG GLOBAL (idEmpresa=0) A EMPRESA PROPIA
-- Usar cuando la empresa no tiene filas propias en bf_RepConf_Columna para un grupo
-- y quieres personalizar sin afectar a las demás empresas que usan el global.
-- ============================================================================

DECLARE @emp     INT          = 186;
DECLARE @reporte INT          = 3;
DECLARE @grupo   NVARCHAR(100)= 'GMM';

-- Ver qué existe globalmente
SELECT orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = 0 AND grupo = @grupo
ORDER BY orden;

-- Copiar solo las que NO existen ya para la empresa
INSERT INTO dbo.bf_RepConf_Columna
    (idEmpresa, catReportesId, grupo, orden, campoOrigen, encabezado, visible, ancho, formato)
SELECT
    @emp, catReportesId, grupo, orden, campoOrigen, encabezado, visible, ancho, formato
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte
  AND idEmpresa     = 0
  AND grupo         = @grupo
  AND NOT EXISTS (
      SELECT 1 FROM dbo.bf_RepConf_Columna x
      WHERE x.catReportesId = @reporte
        AND x.idEmpresa     = @emp
        AND x.grupo         = @grupo
        AND x.orden         = dbo.bf_RepConf_Columna.orden
  );

-- DESPUES
SELECT orden, campoOrigen, encabezado, visible
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = @reporte AND idEmpresa = @emp AND grupo = @grupo
ORDER BY orden;



-- ============================================================================
-- SCRIPT 6 — OCULTAR / MOSTRAR UNA HOJA COMPLETA
-- visible=0 en bf_RepConf_Tabla excluye la pestaña del Excel generado.
-- Si no existe fila propia, se inserta (override) antes de ocultar.
-- ============================================================================

DECLARE @emp        INT          = 186;
DECLARE @reporte    INT          = 3;
DECLARE @grupo      NVARCHAR(100)= 'Mascotas';  -- nombre exacto del grupo (ver Script 0A)
DECLARE @activo     BIT          = 0;            -- 0 = ocultar, 1 = mostrar
DECLARE @usuario    INT          = 1;            -- ID de usuario para auditoría

-- ANTES
SELECT idEmpresa, grupo, indexTable, activo, tituloTabla
FROM dbo.bf_RepConf_Tabla
WHERE catReportesId = @reporte AND idEmpresa IN (@emp, 0) AND grupo = @grupo;

IF EXISTS (
    SELECT 1 FROM dbo.bf_RepConf_Tabla
    WHERE catReportesId = @reporte AND idEmpresa = @emp AND grupo = @grupo
)
BEGIN
    -- Ya tiene fila propia: solo actualizar
    UPDATE dbo.bf_RepConf_Tabla
    SET    activo = @activo
    WHERE  catReportesId = @reporte AND idEmpresa = @emp AND grupo = @grupo;
END
ELSE
BEGIN
    -- No tiene fila propia: insertar override copiando la global
    INSERT INTO dbo.bf_RepConf_Tabla
        (idEmpresa, catReportesId, grupo, columnaGrupo, agruparPorColumna,
         indexTable, tituloTabla, espacioIzquierda, espacioDerecha,
         alineacion, colorFondo, colorLetra, activo, repConfTablaUsuarioAdd)
    SELECT
        @emp, catReportesId, grupo, columnaGrupo, agruparPorColumna,
        indexTable, tituloTabla, espacioIzquierda, espacioDerecha,
        alineacion, colorFondo, colorLetra, @activo, @usuario
    FROM dbo.bf_RepConf_Tabla
    WHERE catReportesId = @reporte AND idEmpresa = 0 AND grupo = @grupo;
END

-- DESPUES
SELECT idEmpresa, grupo, indexTable, activo, tituloTabla
FROM dbo.bf_RepConf_Tabla
WHERE catReportesId = @reporte AND idEmpresa IN (@emp, 0) AND grupo = @grupo;