/*
   Horario diario del worker de cache de Cobranza.
   Ajuste @Hora antes de ejecutar. Zona usada por Java: America/Mexico_City.
   El script es idempotente: actualiza el parametro global si ya existe.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Hora varchar(5)='01:00',
        @Clase char(30)='COBRANZA_CACHE_HORA',
        @PaId int;

IF LEN(@Hora)<>5
   OR SUBSTRING(@Hora,3,1)<>':'
   OR TRY_CONVERT(int,LEFT(@Hora,2)) NOT BETWEEN 0 AND 23
   OR TRY_CONVERT(int,RIGHT(@Hora,2)) NOT BETWEEN 0 AND 59
    THROW 51600,'COBRANZA_CACHE_HORA debe tener formato HH:mm (00:00 a 23:59).',1;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP (1) @PaId=paId
    FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=0
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE_HORA'
    ORDER BY paId DESC;

    IF @PaId IS NULL
    BEGIN
        SELECT @PaId=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH (UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paidEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@PaId,0,@Clase,@Hora,
         'Horario diario worker cache cobranza (HH:mm, America/Mexico_City)',
         1,1,GETDATE());
    END
    ELSE
    BEGIN
        UPDATE dbo.ff_Parametro
           SET paClase=@Clase,
               paValor=@Hora,
               paDescripcion='Horario diario worker cache cobranza (HH:mm, America/Mexico_City)',
               paidEstatus=1,
               paUsuarioUmod=1,
               paFechaUmod=GETDATE()
         WHERE paId=@PaId AND paIdEmpresa=0;
    END;

    COMMIT TRANSACTION;

    SELECT paId,paIdEmpresa,LTRIM(RTRIM(paClase)) AS paClase,
           LTRIM(RTRIM(paValor)) AS paValor,paidEstatus
    FROM dbo.ff_Parametro
    WHERE paId=@PaId AND paIdEmpresa=0;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
