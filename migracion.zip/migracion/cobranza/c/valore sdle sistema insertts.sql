SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa INT = 186;
DECLARE @Clase VARCHAR(30) = 'COBRANZA_CACHE';
DECLARE @ParametroCache INT;

BEGIN TRY
    BEGIN TRANSACTION;

    /*
       Primero localiza un parametro COBRANZA_CACHE ya existente para la
       empresa. Los bloqueos solamente protegen esta configuracion mientras
       se decide si se actualiza o se inserta.
    */
    SELECT TOP (1)
        @ParametroCache = paId
    FROM dbo.ff_Parametro WITH (UPDLOCK, HOLDLOCK)
    WHERE paIdEmpresa = @IdEmpresa
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase, '')))) = @Clase
    ORDER BY paidEstatus DESC, paId DESC;

    /*
       Repara el registro 200/186 creado por la version anterior del script,
       que podia quedar con paClase vacio. No modifica el registro global
       200/0 ni los parametros Beflex2 de otras empresas.
    */
    IF @ParametroCache IS NULL
       AND EXISTS
       (
           SELECT 1
           FROM dbo.ff_Parametro WITH (UPDLOCK, HOLDLOCK)
           WHERE paId = 200
             AND paIdEmpresa = @IdEmpresa
             AND NULLIF(LTRIM(RTRIM(ISNULL(paClase, ''))), '') IS NULL
       )
    BEGIN
        SET @ParametroCache = 200;
    END;

    IF @ParametroCache IS NULL
    BEGIN
        SELECT @ParametroCache = ISNULL(MAX(paId), 0) + 1
        FROM dbo.ff_Parametro WITH (UPDLOCK, HOLDLOCK);

        INSERT dbo.ff_Parametro
        (
            paId,
            paIdEmpresa,
            paClase,
            paValor,
            paDescripcion,
            paidEstatus,
            paUsuarioAdd,
            paFechaAdd
        )
        VALUES
        (
            @ParametroCache,
            @IdEmpresa,
            @Clase,
            '1',
            'Habilita cache V2 de cobranza para la empresa',
            1,
            0,
            GETDATE()
        );
    END
    ELSE
    BEGIN
        UPDATE dbo.ff_Parametro
        SET paClase = @Clase,
            paValor = '1',
            paDescripcion = 'Habilita cache V2 de cobranza para la empresa',
            paidEstatus = 1,
            paUsuarioUmod = 0,
            paFechaUmod = GETDATE()
        WHERE paId = @ParametroCache
          AND paIdEmpresa = @IdEmpresa;
    END;

    COMMIT TRANSACTION;

    SELECT
        paId,
        paIdEmpresa,
        LTRIM(RTRIM(paClase)) AS Clase,
        LTRIM(RTRIM(paValor)) AS Valor,
        paidEstatus
    FROM dbo.ff_Parametro
    WHERE paIdEmpresa = @IdEmpresa
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase, '')))) = @Clase;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;
