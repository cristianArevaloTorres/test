SET NOCOUNT ON;

/* Deben aparecer como maximo cuatro vigencias por empresa configurada. */
SELECT
    CacheId,
    IdEmpresa,
    IdVigencia,
    PerfilClave,
    FecIni,
    FecFin,
    EsUniverso,
    Estado,
    FechaCargaInicio,
    FechaCargaFin,
    DATEDIFF(SECOND,FechaCargaInicio,FechaCargaFin) AS SegundosCarga,
    FilasConcentrada,
    FilasDesglosada,
    Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (NOLOCK)
WHERE IdEmpresa=186
ORDER BY EsUniverso DESC,IdVigencia DESC,CacheId DESC;

/* La consulta debe devolver 4 despues de que termine el worker nocturno. */
SELECT COUNT(DISTINCT IdVigencia) AS VigenciasUniversoCompletas
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (NOLOCK)
WHERE IdEmpresa=186
  AND EsUniverso=1
  AND Estado='COMPLETA';

/* El detalle operativo queda en la propia particion, sin usar el log
   compartido bf_RepConf_Debug. */
SELECT TOP (20) CacheId,IdEmpresa,IdVigencia,Estado,
       FechaCargaInicio,FechaCargaFin,Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (NOLOCK)
WHERE IdEmpresa=186
ORDER BY CacheId DESC;

/* Detalle técnico exclusivo de Cobranza; no bloquea el log compartido. */
SELECT TOP (100) Fecha,Etapa,Detalle
FROM dbo.bf_CobranzaCache_Log WITH (NOLOCK)
ORDER BY LogId DESC;
