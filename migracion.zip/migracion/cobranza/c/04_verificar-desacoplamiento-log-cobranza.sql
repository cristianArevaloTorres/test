SET NOCOUNT ON;

SELECT P.name AS Procedimiento,
       CASE WHEN M.definition LIKE N'%bf_RepConf_Debug%' THEN 'ERROR: usa log compartido'
            ELSE 'OK: desacoplado' END AS Estado,
       CASE WHEN M.definition LIKE N'%bf_CobranzaCache_Log%' THEN 1 ELSE 0 END AS UsaLogCobranza
FROM sys.procedures P
INNER JOIN sys.sql_modules M ON M.object_id=P.object_id
WHERE P.name IN
      (N'ff_Cobranza_v2',N'ff_CobranzaSincronizacion_V3_bf3',
       N'ObtenCobranzaConcentrada_otro_V2_BF3',N'ff_ObtenEmpleadosCob_v2_bf3')
ORDER BY P.name;

IF EXISTS
(
    SELECT 1
    FROM sys.procedures P
    INNER JOIN sys.sql_modules M ON M.object_id=P.object_id
    WHERE P.name IN
          (N'ff_Cobranza_v2',N'ff_CobranzaSincronizacion_V3_bf3',
           N'ObtenCobranzaConcentrada_otro_V2_BF3',N'ff_ObtenEmpleadosCob_v2_bf3')
      AND M.definition LIKE N'%bf_RepConf_Debug%'
)
    THROW 51800,'Todavia existe un SP de Cobranza ligado a bf_RepConf_Debug.',1;

SELECT TOP (50) Fecha,Etapa,Detalle
FROM dbo.bf_CobranzaCache_Log WITH (NOLOCK)
ORDER BY LogId DESC;
