SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa int=186,
        @Resultado varchar(30),
        @IdVigencia int,
        @FecIni varchar(16),
        @FecFin varchar(16);

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Parametro
    WHERE paIdEmpresa=@IdEmpresa
      AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE'
      AND LTRIM(RTRIM(paValor))='1'
      AND paidEstatus=1
)
    THROW 51700,'La empresa no tiene COBRANZA_CACHE=1.',1;

DECLARE @Perfiles dbo.ListInt;

INSERT @Perfiles(IdTipoNotificacionCorreo)
SELECT DISTINCT PEIdPerfil
FROM dbo.ff_Perfil WITH (NOLOCK)
WHERE PEIdEmpresa=@IdEmpresa
  AND PEIdEstatus=1
  AND PEAdministrador=0;

IF NOT EXISTS (SELECT 1 FROM @Perfiles)
    THROW 51701,'La empresa no tiene perfiles activos no administradores.',1;

DECLARE @Vigencias TABLE
(
    Orden int IDENTITY(1,1) PRIMARY KEY,
    IdVigencia int NOT NULL,
    FecIni varchar(16) NOT NULL,
    FecFin varchar(16) NOT NULL
);

INSERT @Vigencias(IdVigencia,FecIni,FecFin)
SELECT TOP (4)
       V.VIidVigencia,
       CONVERT(varchar(16),
           CASE WHEN V.VIEnrollmentIni IS NOT NULL
                     AND V.VIEnrollmentIni<V.VIVigenciaIni
                THEN V.VIEnrollmentIni
                ELSE V.VIVigenciaIni
           END,120),
       CONVERT(varchar(16),
           CASE WHEN V.VIVigenciaFin<GETDATE()
                THEN V.VIVigenciaFin
                ELSE DATEADD(MINUTE,-1,
                     DATEADD(DAY,1,CONVERT(datetime,CONVERT(date,GETDATE()))))
           END,120)
FROM dbo.ff_Empresa E WITH (NOLOCK)
INNER JOIN dbo.ff_Vigencia V WITH (NOLOCK)
    ON V.VIidConfiguracion=E.EMidConfiguracion
WHERE E.EMidEmpresa=@IdEmpresa
  AND E.EMidEstatus=1
  AND V.VITipoNegocio=1
ORDER BY V.VIVigenciaIni DESC,V.VIidVigencia DESC;

SELECT @IdEmpresa AS IdEmpresa,
       (SELECT COUNT(*) FROM @Perfiles) AS Perfiles,
       IdVigencia,FecIni,FecFin
FROM @Vigencias
ORDER BY Orden;

DECLARE @Orden int=1,
        @Total int=(SELECT COUNT(*) FROM @Vigencias);

WHILE @Orden<=@Total
BEGIN
    SELECT @IdVigencia=IdVigencia,
           @FecIni=FecIni,
           @FecFin=FecFin
    FROM @Vigencias
    WHERE Orden=@Orden;

    RAISERROR('Actualizando universo %d de %d. Vigencia=%d, rango=%s a %s',
              10,1,@Orden,@Total,@IdVigencia,@FecIni,@FecFin) WITH NOWAIT;

    EXEC dbo.InsertaCobranzaConcentrada_otro_V2_BF3_Cache
         @idEmpresa=@IdEmpresa,
         @idSolTipo=0,
         @FecIni=@FecIni,
         @FecFin=@FecFin,
         @idVencida=1,
         @IdPerfil=@Perfiles,
         @idVIgencia=@IdVigencia,
         @ForzarRecarga=1,
         @PrecargarUltimas4=0,
         @EmitirResultado=1,
         @EsUniverso=1;

    SET @Orden+=1;
END;

EXEC dbo.bf_CobranzaCache_LimpiarVigenciasV2 @idEmpresa=@IdEmpresa;

SELECT CacheId,IdEmpresa,IdVigencia,PerfilClave,FecIni,FecFin,
       EsUniverso,Estado,FechaCargaInicio,FechaCargaFin,
       DATEDIFF(SECOND,FechaCargaInicio,FechaCargaFin) AS SegundosCarga,
       FilasConcentrada,FilasDesglosada,Mensaje
FROM dbo.bf_CobranzaCache_ConsultaV2 WITH (NOLOCK)
WHERE IdEmpresa=@IdEmpresa
  AND EsUniverso=1
ORDER BY IdVigencia DESC,CacheId DESC;
