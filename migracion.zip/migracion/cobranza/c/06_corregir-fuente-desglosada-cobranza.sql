/*
    Corrige la fuente del detalle del reporte de Cobranza.

    Problema confirmado:
      - dbo.ff_CobranzaSincronizacion_V3_bf3 sincroniza las selecciones hacia
        dbo.ff_PlanOpcionSeleccionCobranza2.
      - dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR leia la tabla historica
        dbo.ff_PlanOpcionSeleccionCobranza (sin el sufijo 2).

    Este script modifica solamente esa referencia dentro del procedimiento.
    Es idempotente y valida que ambas tablas tengan el mismo contrato.

    Despues de aplicarlo ejecute:
      03_actualizar-universos-cache-cobranza.sql
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Procedimiento nvarchar(300) =
            N'dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR',
        @ReferenciaAnterior nvarchar(300) =
            N'FROM dbo.ff_planopcionseleccionCobranza POS WITH (NOLOCK)',
        @ReferenciaNueva nvarchar(300) =
            N'FROM dbo.ff_planopcionseleccionCobranza2 POS WITH (NOLOCK)',
        @Definicion nvarchar(max),
        @NuevaDefinicion nvarchar(max),
        @PosicionCreate int;

IF OBJECT_ID(@Procedimiento, N'P') IS NULL
    THROW 51900,
        'No existe dbo.ff_ObtenCobranzaDesg_Adaptada_bf3_NOUSAR.', 1;

IF OBJECT_ID(N'dbo.ff_PlanOpcionSeleccionCobranza', N'U') IS NULL
    THROW 51901,
        'No existe dbo.ff_PlanOpcionSeleccionCobranza.', 1;

IF OBJECT_ID(N'dbo.ff_PlanOpcionSeleccionCobranza2', N'U') IS NULL
    THROW 51902,
        'No existe dbo.ff_PlanOpcionSeleccionCobranza2.', 1;

-- Las dos tablas deben tener las mismas columnas, tipos y nulabilidad.
IF EXISTS
(
    SELECT C.column_id,C.name,C.system_type_id,C.user_type_id,
           C.max_length,C.precision,C.scale,C.is_nullable
    FROM sys.columns C
    WHERE C.object_id=OBJECT_ID(N'dbo.ff_PlanOpcionSeleccionCobranza')
    EXCEPT
    SELECT C.column_id,C.name,C.system_type_id,C.user_type_id,
           C.max_length,C.precision,C.scale,C.is_nullable
    FROM sys.columns C
    WHERE C.object_id=OBJECT_ID(N'dbo.ff_PlanOpcionSeleccionCobranza2')
)
OR EXISTS
(
    SELECT C.column_id,C.name,C.system_type_id,C.user_type_id,
           C.max_length,C.precision,C.scale,C.is_nullable
    FROM sys.columns C
    WHERE C.object_id=OBJECT_ID(N'dbo.ff_PlanOpcionSeleccionCobranza2')
    EXCEPT
    SELECT C.column_id,C.name,C.system_type_id,C.user_type_id,
           C.max_length,C.precision,C.scale,C.is_nullable
    FROM sys.columns C
    WHERE C.object_id=OBJECT_ID(N'dbo.ff_PlanOpcionSeleccionCobranza')
)
    THROW 51903,
        'Las tablas Cobranza y Cobranza2 no tienen el mismo contrato.', 1;

SET @Definicion=OBJECT_DEFINITION(OBJECT_ID(@Procedimiento));

IF CHARINDEX(@ReferenciaNueva,@Definicion)>0
BEGIN
    PRINT 'La fuente Desglosada ya apunta a Cobranza2. No se requieren cambios.';
END
ELSE
BEGIN
    IF CHARINDEX(@ReferenciaAnterior,@Definicion)=0
        THROW 51904,
            'No se encontro la referencia esperada a la tabla historica.', 1;

    IF CHARINDEX(@ReferenciaAnterior,@Definicion,
                 CHARINDEX(@ReferenciaAnterior,@Definicion)+1)>0
        THROW 51905,
            'La referencia historica aparece mas de una vez; revise el SP.', 1;

    SET @NuevaDefinicion=REPLACE(
        @Definicion,@ReferenciaAnterior,@ReferenciaNueva);

    SET @PosicionCreate=CHARINDEX(
        N'CREATE PROCEDURE',UPPER(@NuevaDefinicion));
    IF @PosicionCreate=0
        THROW 51906,
            'No se encontro CREATE PROCEDURE en la definicion.', 1;

    SET @NuevaDefinicion=STUFF(
        @NuevaDefinicion,@PosicionCreate,LEN(N'CREATE PROCEDURE'),
        N'ALTER PROCEDURE');

    EXEC sys.sp_executesql @NuevaDefinicion;
    PRINT 'Fuente Desglosada corregida: ahora lee Cobranza2.';
END;

IF OBJECT_DEFINITION(OBJECT_ID(@Procedimiento))
        NOT LIKE N'%FROM dbo.ff_planopcionseleccionCobranza2 POS WITH (NOLOCK)%'
    THROW 51907,
        'La validacion posterior no encontro la fuente Cobranza2.', 1;

SELECT
    N'OK' AS Resultado,
    @Procedimiento AS Procedimiento,
    N'dbo.ff_PlanOpcionSeleccionCobranza2' AS FuenteDesglosada,
    N'Ejecute 03_actualizar-universos-cache-cobranza.sql' AS SiguientePaso;

