/*
    Compatibilidad de intercalacion para dbo.ff_orquestadorReportes.

    Corrige exclusivamente la comparacion entre:
      - dbo.ParamValor.ParamNombre (TVP)
      - dbo.bf_CatReportesParams.catReportesParamsNombre (catalogo)

    Algunas bases conservan estas columnas con collations diferentes. No se
    cambia la collation de la base, tablas, columnas ni tipos existentes.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'dbo.ff_orquestadorReportes', N'P') IS NULL
    THROW 51540, 'Falta dbo.ff_orquestadorReportes.', 1;
IF TYPE_ID(N'dbo.ParamValor') IS NULL
    THROW 51540, 'Falta el tipo tabla dbo.ParamValor.', 1;
IF OBJECT_ID(N'dbo.bf_CatReportesParams', N'U') IS NULL
    THROW 51540, 'Falta dbo.bf_CatReportesParams.', 1;
GO

DECLARE @Def nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_orquestadorReportes')),
        @Upper nvarchar(max),
        @ParamPos int,
        @CatalogoPos int,
        @ParamEnd int,
        @CatalogoEnd int,
        @ParamSearch int = 1,
        @CatalogoSearch int,
        @CandidateParamPos int,
        @CandidateCatalogoPos int,
        @CandidateParamEnd int,
        @CandidateCatalogoEnd int,
        @BestGap int = 2147483647,
        @Gap int,
        @Between nvarchar(1000),
        @Tail nvarchar(200),
        @EarlierEnd int,
        @LaterEnd int,
        @ProcPos int,
        @Resultado varchar(30) = 'YA_COMPATIBLE';

IF @Def IS NULL
    THROW 51541, 'No se pudo leer la definicion de dbo.ff_orquestadorReportes.', 1;

/*
   V2 no depende de alias ni de espacios. Busca el par de columnas que se
   compara con '=' y acepta, por ejemplo:
     pv.ParamNombre = p.catReportesParamsNombre
     [valor].[ParamNombre]=[cfg].[catReportesParamsNombre]
     cfg.catReportesParamsNombre = entrada.ParamNombre
*/
IF CHARINDEX(N'BF_REPORTES_COLLATION_COMPAT_V2', @Def) = 0
BEGIN
    SET @Upper = UPPER(@Def) COLLATE Latin1_General_100_CI_AS;

    WHILE 1=1
    BEGIN
        SET @CandidateParamPos = CHARINDEX(N'PARAMNOMBRE', @Upper, @ParamSearch);
        IF @CandidateParamPos = 0 BREAK;

        SET @CandidateParamEnd = @CandidateParamPos + LEN(N'PARAMNOMBRE') - 1;
        IF SUBSTRING(@Def,@CandidateParamEnd+1,1)=N']'
            SET @CandidateParamEnd+=1;

        SET @CatalogoSearch=1;
        WHILE 1=1
        BEGIN
            SET @CandidateCatalogoPos = CHARINDEX(N'CATREPORTESPARAMSNOMBRE', @Upper, @CatalogoSearch);
            IF @CandidateCatalogoPos = 0 BREAK;

            SET @CandidateCatalogoEnd = @CandidateCatalogoPos + LEN(N'CATREPORTESPARAMSNOMBRE') - 1;
            IF SUBSTRING(@Def,@CandidateCatalogoEnd+1,1)=N']'
                SET @CandidateCatalogoEnd+=1;

            SET @Gap=ABS(@CandidateParamPos-@CandidateCatalogoPos);
            IF @Gap<1000 AND @Gap<@BestGap
            BEGIN
                IF @CandidateParamPos<@CandidateCatalogoPos
                    SET @Between=SUBSTRING(@Def,@CandidateParamEnd+1,@CandidateCatalogoPos-@CandidateParamEnd-1);
                ELSE
                    SET @Between=SUBSTRING(@Def,@CandidateCatalogoEnd+1,@CandidateParamPos-@CandidateCatalogoEnd-1);

                IF CHARINDEX(N'=',@Between)>0
                BEGIN
                    SELECT @ParamPos=@CandidateParamPos,
                           @CatalogoPos=@CandidateCatalogoPos,
                           @ParamEnd=@CandidateParamEnd,
                           @CatalogoEnd=@CandidateCatalogoEnd,
                           @BestGap=@Gap;
                END;
            END;

            SET @CatalogoSearch=@CandidateCatalogoPos+LEN(N'CATREPORTESPARAMSNOMBRE');
        END;

        SET @ParamSearch=@CandidateParamPos+LEN(N'PARAMNOMBRE');
    END;

    IF @ParamPos IS NULL OR @CatalogoPos IS NULL
        THROW 51542, 'No se encontro una comparacion entre ParamNombre y catReportesParamsNombre en ff_orquestadorReportes. No se modifico el procedimiento.', 1;

    /* Insertar desde la posicion mayor para no desplazar la posicion menor. */
    SET @EarlierEnd=CASE WHEN @ParamEnd<@CatalogoEnd THEN @ParamEnd ELSE @CatalogoEnd END;
    SET @LaterEnd=CASE WHEN @ParamEnd>@CatalogoEnd THEN @ParamEnd ELSE @CatalogoEnd END;

    SET @Tail=UPPER(LTRIM(SUBSTRING(@Def,@LaterEnd+1,200))) COLLATE Latin1_General_100_CI_AS;
    IF LEFT(@Tail,7)<>N'COLLATE'
        SET @Def=STUFF(@Def,@LaterEnd+1,0,N' COLLATE DATABASE_DEFAULT');

    SET @Tail=UPPER(LTRIM(SUBSTRING(@Def,@EarlierEnd+1,200))) COLLATE Latin1_General_100_CI_AS;
    IF LEFT(@Tail,7)<>N'COLLATE'
        SET @Def=STUFF(@Def,@EarlierEnd+1,0,N' COLLATE DATABASE_DEFAULT');

    /* El comentario queda dentro de la expresion y permite verificar idempotencia. */
    SET @Def=STUFF(@Def,@EarlierEnd+1,0,N' /* BF_REPORTES_COLLATION_COMPAT_V2 */');

    SET @ProcPos = CHARINDEX(N'PROCEDURE', UPPER(@Def));
    IF @ProcPos = 0
        SET @ProcPos = PATINDEX(N'%[^A-Z]PROC[^A-Z]%',N' '+UPPER(@Def)+N' ');
    IF @ProcPos = 0
        THROW 51543, 'La definicion de ff_orquestadorReportes no contiene PROC o PROCEDURE.', 1;

    SET @Def = N'ALTER ' + SUBSTRING(@Def, @ProcPos, LEN(@Def));
    EXEC sys.sp_executesql @Def;
    SET @Resultado = 'AJUSTADO';
END;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_orquestadorReportes'))
   NOT LIKE N'%BF_REPORTES_COLLATION_COMPAT_V2%'
    THROW 51544, 'No fue posible verificar el ajuste de collation del orquestador.', 1;

DECLARE @CollationTipo sysname,
        @CollationCatalogo sysname;

SELECT @CollationTipo = C.collation_name
FROM sys.table_types TT
INNER JOIN sys.columns C ON C.object_id = TT.type_table_object_id
WHERE SCHEMA_NAME(TT.schema_id) = N'dbo'
  AND TT.name = N'ParamValor'
  AND C.name = N'ParamNombre';

SELECT @CollationCatalogo = C.collation_name
FROM sys.columns C
WHERE C.object_id = OBJECT_ID(N'dbo.bf_CatReportesParams')
  AND C.name = N'catReportesParamsNombre';

SELECT
    N'OK' AS Estado,
    @Resultado AS Resultado,
    CONVERT(sysname, DATABASEPROPERTYEX(DB_NAME(), 'Collation')) AS CollationBase,
    @CollationTipo AS CollationParamValor,
    @CollationCatalogo AS CollationCatalogo;
GO
