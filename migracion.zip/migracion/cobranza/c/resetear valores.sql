USE FlexiForbesv2;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET LOCK_TIMEOUT 30000;

DECLARE @IdEmpresa INT = 186;

-- Revisar lo que será eliminado
SELECT
    IdEmpresa,
    IdVigencia,
    PerfilClave,
    Estado,
    FilasConcentrada,
    FilasDesglosada,
    FechaCargaInicio,
    FechaCargaFin
FROM dbo.bf_CobranzaCache_ConsultaV2
WHERE IdEmpresa = @IdEmpresa
ORDER BY IdVigencia DESC, CacheId DESC;

BEGIN TRY
    BEGIN TRANSACTION;

    /*
      Al eliminar ConsultaV2 se eliminan automáticamente sus filas hijas
      de ConcentradaV2, DesglosadaV2 y BanwireV2 por ON DELETE CASCADE.
    */
    DELETE FROM dbo.bf_CobranzaCache_ConsultaV2
    WHERE IdEmpresa = @IdEmpresa;

    -- Control utilizado por el job Java
    DELETE FROM dbo.bf_CobranzaCache_Ctrl
    WHERE ccIdEmpresa = @IdEmpresa;

    /*
      Limpieza del caché anterior/EAV, si esas tablas existen.
      Se utiliza SQL dinámico para que el script no falle si alguna no está.
    */
    IF OBJECT_ID(N'dbo.bf_CobranzaCache_Concentrada', N'U') IS NOT NULL
        DELETE FROM dbo.bf_CobranzaCache_Concentrada
        WHERE ccdIdEmpresa = @IdEmpresa;

    IF OBJECT_ID(N'dbo.bf_CobranzaCache_Desglosada', N'U') IS NOT NULL
        DELETE FROM dbo.bf_CobranzaCache_Desglosada
        WHERE ccdIdEmpresa = @IdEmpresa;

    IF OBJECT_ID(N'dbo.bf_CobranzaCache_TotCoberturas', N'U') IS NOT NULL
        DELETE FROM dbo.bf_CobranzaCache_TotCoberturas
        WHERE ccdIdEmpresa = @IdEmpresa;

    IF OBJECT_ID(N'dbo.bf_CobranzaCache_TotCoberturasP', N'U') IS NOT NULL
        DELETE FROM dbo.bf_CobranzaCache_TotCoberturasP
        WHERE ccdIdEmpresa = @IdEmpresa;

    IF OBJECT_ID(N'dbo.bf_CobranzaCache_PlanesParentesco', N'U') IS NOT NULL
        DELETE FROM dbo.bf_CobranzaCache_PlanesParentesco
        WHERE ccdIdEmpresa = @IdEmpresa;

    COMMIT TRANSACTION;

    SELECT 'OK' AS Estado, 'Caché eliminado para la empresa 186' AS Detalle;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;
GO