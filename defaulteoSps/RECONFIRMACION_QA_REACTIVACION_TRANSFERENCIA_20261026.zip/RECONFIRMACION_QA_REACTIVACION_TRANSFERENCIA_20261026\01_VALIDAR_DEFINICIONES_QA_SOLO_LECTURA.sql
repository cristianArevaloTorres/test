USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*
  SOLO LECTURA.
  Confirma que los tres procedimientos de QA contienen las reglas entregadas.
*/

DECLARE @DefReactivacion NVARCHAR(MAX) =
    OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_ReactivacionEmpleadosTitular'));
DECLARE @DefMasiva NVARCHAR(MAX) =
    OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_transferenciaMasivaEmpleado'));
DECLARE @DefIndividual NVARCHAR(MAX) =
    OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_cambioEMpresa'));

/*
  Huellas de la version de referencia probada en la base local.
  Una huella distinta puede deberse a formato/comentarios; por eso tambien se
  valida la logica de cada procedimiento.
*/
DECLARE @HashReactivacion VARCHAR(64) = CONVERT
(
    VARCHAR(64),
    HASHBYTES('SHA2_256', CONVERT(VARBINARY(MAX), @DefReactivacion)),
    2
);
DECLARE @HashMasiva VARCHAR(64) = CONVERT
(
    VARCHAR(64),
    HASHBYTES('SHA2_256', CONVERT(VARBINARY(MAX), @DefMasiva)),
    2
);
DECLARE @HashIndividual VARCHAR(64) = CONVERT
(
    VARCHAR(64),
    HASHBYTES('SHA2_256', CONVERT(VARBINARY(MAX), @DefIndividual)),
    2
);

DECLARE @HashReferenciaReactivacion VARCHAR(64) =
    '57B57F4519BE268468EE8B1C3B5D7F99F5ADE1A5BD57924BE901D8F60E323EC6';
DECLARE @HashReferenciaMasiva VARCHAR(64) =
    'CCD63D827A8E85DDC7AB6294AE601229BA497EE4446861BDD1F90AF8CC97B154';
DECLARE @HashReferenciaIndividual VARCHAR(64) =
    '14DF71948595966E45E02F9A52A53304CE2B753419FC694C3376485EF85BF8A8';

/* Normalización para que espacios, saltos, corchetes y mayúsculas no alteren la validación. */
DECLARE @NormReactivacion NVARCHAR(MAX) = UPPER(ISNULL(@DefReactivacion, N''));
DECLARE @NormMasiva NVARCHAR(MAX) = UPPER(ISNULL(@DefMasiva, N''));
DECLARE @NormIndividual NVARCHAR(MAX) = UPPER(ISNULL(@DefIndividual, N''));

SELECT @NormReactivacion = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
           @NormReactivacion, N' ', N''), NCHAR(9), N''), NCHAR(13), N''),
           NCHAR(10), N''), N'[', N''), N']', N'');
SELECT @NormMasiva = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
           @NormMasiva, N' ', N''), NCHAR(9), N''), NCHAR(13), N''),
           NCHAR(10), N''), N'[', N''), N']', N'');
SELECT @NormIndividual = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
           @NormIndividual, N' ', N''), NCHAR(9), N''), NCHAR(13), N''),
           NCHAR(10), N''), N'[', N''), N']', N'');

DECLARE @OcurrenciasNoAdminMasiva INT =
    (LEN(@NormMasiva) - LEN(REPLACE(@NormMasiva, N'P.PEADMINISTRADOR=0', N'')))
    / LEN(N'P.PEADMINISTRADOR=0');
DECLARE @OcurrenciasOrdenMasiva INT =
    (LEN(@NormMasiva) - LEN(REPLACE(@NormMasiva, N'ORDERBYR.ROIDROLASC', N'')))
    / LEN(N'ORDERBYR.ROIDROLASC');
DECLARE @OcurrenciasNoAdminIndividual INT =
    (LEN(@NormIndividual) - LEN(REPLACE(@NormIndividual, N'P.PEADMINISTRADOR=0', N'')))
    / LEN(N'P.PEADMINISTRADOR=0');
DECLARE @OcurrenciasOrdenIndividual INT =
    (LEN(@NormIndividual) - LEN(REPLACE(@NormIndividual, N'ORDERBYR.ROIDROLASC', N'')))
    / LEN(N'ORDERBYR.ROIDROLASC');

DECLARE @Resultado TABLE
(
    Orden INT NOT NULL,
    Procedimiento SYSNAME NOT NULL,
    FechaModificacion DATETIME NULL,
    HuellaSHA256 VARCHAR(64) NULL,
    VersionExactaReferencia VARCHAR(2) NOT NULL,
    Resultado VARCHAR(10) NOT NULL,
    Detalle VARCHAR(500) NOT NULL
);

INSERT INTO @Resultado
SELECT
    1,
    'dbo.bf_ReactivacionEmpleadosTitular',
    O.modify_date,
    @HashReactivacion,
    CASE WHEN @HashReactivacion = @HashReferenciaReactivacion THEN 'SI' ELSE 'NO' END,
    CASE
        WHEN @DefReactivacion IS NULL THEN 'ERROR'
        WHEN @NormReactivacion LIKE N'%EMFECHAADD=GETDATE()%' THEN 'ERROR'
        WHEN @NormReactivacion NOT LIKE N'%EMFECHAUMOD=GETDATE()%' THEN 'ERROR'
        WHEN @NormReactivacion NOT LIKE N'%EMIDESTATUS=1%' THEN 'ERROR'
        ELSE 'OK'
    END,
    CASE
        WHEN @DefReactivacion IS NULL
            THEN 'El procedimiento no existe en esta base.'
        WHEN @NormReactivacion LIKE N'%EMFECHAADD=GETDATE()%'
            THEN 'Aun actualiza EMFechaAdd; no conserva la fecha/hora original.'
        WHEN @NormReactivacion NOT LIKE N'%EMFECHAUMOD=GETDATE()%'
            THEN 'No se encontro la actualización de la fecha de modificación.'
        WHEN @NormReactivacion NOT LIKE N'%EMIDESTATUS=1%'
            THEN 'No se encontro la activación del empleado.'
        ELSE 'Conserva EMFechaAdd y mantiene la actualización de auditoría/reactivación.'
    END
FROM (VALUES (OBJECT_ID(N'dbo.bf_ReactivacionEmpleadosTitular'))) V(object_id)
LEFT JOIN sys.objects O ON O.object_id = V.object_id;

INSERT INTO @Resultado
SELECT
    2,
    'dbo.ff_transferenciaMasivaEmpleado',
    O.modify_date,
    @HashMasiva,
    CASE WHEN @HashMasiva = @HashReferenciaMasiva THEN 'SI' ELSE 'NO' END,
    CASE
        WHEN @DefMasiva IS NULL THEN 'ERROR'
        WHEN @NormMasiva NOT LIKE N'%R.RODEFAULT=1%' THEN 'ERROR'
        WHEN @NormMasiva NOT LIKE N'%R.ROIDESTATUS=1%' THEN 'ERROR'
        WHEN @NormMasiva NOT LIKE N'%P.PEIDESTATUS=1%' THEN 'ERROR'
        WHEN @OcurrenciasNoAdminMasiva < 2 THEN 'ERROR'
        WHEN @OcurrenciasOrdenMasiva < 2 THEN 'ERROR'
        WHEN @NormMasiva NOT LIKE N'%IF@IDROLDESTINOISNULL%' THEN 'ERROR'
        ELSE 'OK'
    END,
    CASE
        WHEN @DefMasiva IS NULL
            THEN 'El procedimiento no existe en esta base.'
        WHEN @NormMasiva NOT LIKE N'%R.RODEFAULT=1%'
            THEN 'No se encontro la prioridad RODefault = 1.'
        WHEN @NormMasiva NOT LIKE N'%R.ROIDESTATUS=1%'
          OR @NormMasiva NOT LIKE N'%P.PEIDESTATUS=1%'
            THEN 'No se encontraron las validaciones de rol y perfil activos.'
        WHEN @OcurrenciasNoAdminMasiva < 2 OR @OcurrenciasOrdenMasiva < 2
            THEN 'No se confirmaron la regla no administrativa y su fallback.'
        WHEN @NormMasiva NOT LIKE N'%IF@IDROLDESTINOISNULL%'
            THEN 'No se encontro el bloque de selección alternativa.'
        ELSE 'Regla default/no administrativa y fallback confirmados.'
    END
FROM (VALUES (OBJECT_ID(N'dbo.ff_transferenciaMasivaEmpleado'))) V(object_id)
LEFT JOIN sys.objects O ON O.object_id = V.object_id;

INSERT INTO @Resultado
SELECT
    3,
    'dbo.ff_cambioEMpresa',
    O.modify_date,
    @HashIndividual,
    CASE WHEN @HashIndividual = @HashReferenciaIndividual THEN 'SI' ELSE 'NO' END,
    CASE
        WHEN @DefIndividual IS NULL THEN 'ERROR'
        WHEN @NormIndividual NOT LIKE N'%SET@IDROL=NULL%' THEN 'ERROR'
        WHEN @NormIndividual NOT LIKE N'%R.RODEFAULT=1%' THEN 'ERROR'
        WHEN @NormIndividual NOT LIKE N'%R.ROIDESTATUS=1%' THEN 'ERROR'
        WHEN @NormIndividual NOT LIKE N'%P.PEIDESTATUS=1%' THEN 'ERROR'
        WHEN @OcurrenciasNoAdminIndividual < 2 THEN 'ERROR'
        WHEN @OcurrenciasOrdenIndividual < 2 THEN 'ERROR'
        WHEN @NormIndividual NOT LIKE N'%IF@IDROLISNULL%' THEN 'ERROR'
        ELSE 'OK'
    END,
    CASE
        WHEN @DefIndividual IS NULL
            THEN 'El procedimiento no existe en esta base.'
        WHEN @NormIndividual NOT LIKE N'%SET@IDROL=NULL%'
            THEN 'El flujo individual aun depende del rol recibido.'
        WHEN @NormIndividual NOT LIKE N'%R.RODEFAULT=1%'
            THEN 'No se encontro la prioridad RODefault = 1.'
        WHEN @NormIndividual NOT LIKE N'%R.ROIDESTATUS=1%'
          OR @NormIndividual NOT LIKE N'%P.PEIDESTATUS=1%'
            THEN 'No se encontraron las validaciones de rol y perfil activos.'
        WHEN @OcurrenciasNoAdminIndividual < 2 OR @OcurrenciasOrdenIndividual < 2
            THEN 'No se confirmaron la regla no administrativa y su fallback.'
        WHEN @NormIndividual NOT LIKE N'%IF@IDROLISNULL%'
            THEN 'No se encontro el bloque de selección alternativa.'
        ELSE 'Flujo individual homologado con la regla de transferencia masiva.'
    END
FROM (VALUES (OBJECT_ID(N'dbo.ff_cambioEMpresa'))) V(object_id)
LEFT JOIN sys.objects O ON O.object_id = V.object_id;

SELECT
    '00_CONTEXTO' AS Bloque,
    CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) AS Servidor,
    DB_NAME() AS BaseDatos,
    GETDATE() AS FechaValidacion;

SELECT
    '01_RESULTADO_POR_OBJETO' AS Bloque,
    Procedimiento,
    FechaModificacion,
    HuellaSHA256,
    VersionExactaReferencia,
    Resultado,
    Detalle
FROM @Resultado
ORDER BY Orden;

SELECT
    '02_DICTAMEN' AS Bloque,
    CASE
        WHEN EXISTS (SELECT 1 FROM @Resultado WHERE Resultado <> 'OK')
            THEN 'ERROR_REVISAR_OBJETOS_ANTES_DE_VALIDAR'
        WHEN EXISTS
        (
            SELECT 1
            FROM @Resultado
            WHERE VersionExactaReferencia <> 'SI'
        )
            THEN 'OK_LOGICA_INTEGRADA_VERSION_TEXTO_DIFERENTE'
        ELSE 'OK_VERSION_EXACTA_Y_LOGICA_INTEGRADA'
    END AS Dictamen;

/* Información explícita para aclarar qué fecha se conserva. */
SELECT
    '03_ACLARACION_REACTIVACION' AS Bloque,
    CASE WHEN @NormReactivacion LIKE N'%EMFECHAADD=GETDATE()%'
         THEN 'SE_ACTUALIZA' ELSE 'SE_CONSERVA' END AS EMFechaAdd,
    CASE WHEN @NormReactivacion LIKE N'%EMFECHAALTA=@EMFECHAREINGRESO%'
         THEN 'TOMA_FECHA_REINGRESO' ELSE 'REVISAR_DEFINICION' END AS EMFechaAlta,
    CASE WHEN @NormReactivacion LIKE N'%EMFECHAINGRESOEMPRESA=@EMFECHAREINGRESO%'
         THEN 'TOMA_FECHA_REINGRESO' ELSE 'REVISAR_DEFINICION' END AS EMFechaIngresoEmpresa;
GO

