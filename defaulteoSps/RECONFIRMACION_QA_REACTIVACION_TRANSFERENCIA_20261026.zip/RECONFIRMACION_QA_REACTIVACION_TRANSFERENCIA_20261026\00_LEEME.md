# Reconfirmación QA: reactivación y transferencia

Este paquete es **solo de lectura**. No contiene `ALTER`, `UPDATE`, `INSERT`,
`DELETE` ni ejecuta los procedimientos de negocio.

## Objetos validados

1. `dbo.bf_ReactivacionEmpleadosTitular`
   - Debe conservar `EMFechaAdd`, que es la fecha/hora original de creación del
     registro.
2. `dbo.ff_transferenciaMasivaEmpleado`
   - Debe seleccionar primero el rol activo `RODefault = 1`, asociado a un
     perfil activo `PEAdministrador = 0`, tomando el menor `ROIdRol`.
   - Si no existe, debe tomar el menor rol activo asociado a un perfil activo
     no administrador.
3. `dbo.ff_cambioEMpresa`
   - Es la corrección posterior del flujo individual y debe aplicar la misma
     selección que la transferencia masiva.

## Orden de ejecución

1. Ejecutar `01_VALIDAR_DEFINICIONES_QA_SOLO_LECTURA.sql`.
2. Confirmar que los tres objetos devuelvan `OK`.
   - `OK_VERSION_EXACTA_Y_LOGICA_INTEGRADA`: QA contiene exactamente la misma
     definición probada localmente.
   - `OK_LOGICA_INTEGRADA_VERSION_TEXTO_DIFERENTE`: la regla está presente,
     pero el texto difiere (por ejemplo, por formato o comentarios); conviene
     guardar el resultado para revisarlo.
3. Completar los parámetros al inicio de
   `02_VALIDAR_DATOS_PRUEBA_QA_SOLO_LECTURA.sql` con los empleados utilizados
   por negocio y ejecutarlo. Para comprobar la reactivación se necesita el
   valor de `EMFechaAdd` capturado antes de la prueba; sin ese dato el resultado
   quedará como `PENDIENTE`, no como aprobado.
4. Guardar pantallazos de los resultados para incorporarlos a la matriz.

## Interpretación de la fecha de reactivación

El alcance implementado conserva `EMFechaAdd` (alta técnica/original del
registro). `EMFechaAlta`, `EMFechaIngresoEmpresa` y `EMFechaAntiguedadGMM`
pueden tomar la fecha de reingreso. Si negocio entiende "fecha de alta" como
`EMFechaAlta`, la implementación actual no cumple esa interpretación y debe
aclararse antes de dar el visto bueno.

## Alcance de esta reconfirmación

El paquete confirma los objetos desplegados y los datos resultantes en la base
de datos donde se ejecute. No confirma por sí solo que Java esté desplegado ni
prueba el caso límite en el que la empresa destino no tenga ningún rol marcado
como default antes de invocar `dbo.ff_cambioEMpresa`.

