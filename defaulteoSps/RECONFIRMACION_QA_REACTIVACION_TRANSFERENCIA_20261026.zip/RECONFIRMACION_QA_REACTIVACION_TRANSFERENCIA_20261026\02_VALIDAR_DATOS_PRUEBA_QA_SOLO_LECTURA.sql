USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* ===================== COMPLETAR CON DATOS DE QA ===================== */
DECLARE @IdEmpresaReactivacion INT = NULL;
DECLARE @NumeroEmpleadoReactivado VARCHAR(20) = NULL;
DECLARE @FechaAddAntesReactivacion DATETIME = NULL;

DECLARE @IdEmpresaDestinoTransferencia INT = NULL;
DECLARE @IdEmpleadoTransferenciaMasiva INT = NULL;
DECLARE @IdEmpleadoTransferenciaIndividual INT = NULL;
/* ==================================================================== */

/*
  REACTIVACION
  Comparar EMFechaAdd contra el valor capturado antes de la prueba.
  EMFechaAlta y EMFechaIngresoEmpresa pueden contener la fecha de reingreso.
*/
IF @IdEmpresaReactivacion IS NULL OR @NumeroEmpleadoReactivado IS NULL
BEGIN
    SELECT
        '01_REACTIVACION' AS Bloque,
        'CAPTURAR @IdEmpresaReactivacion Y @NumeroEmpleadoReactivado' AS Resultado;
END
ELSE
BEGIN
    SELECT
        '01_REACTIVACION' AS Bloque,
        E.ID,
        E.EMIdEmpresa,
        E.EMNumeroEmpleado,
        E.EMIdParentesco,
        E.EMIdTitular,
        E.EMIdEstatus,
        @FechaAddAntesReactivacion AS FechaHoraOriginalCapturadaAntes,
        E.EMFechaAdd AS FechaHoraOriginalQueDebeConservarse,
        E.EMFechaUMod AS FechaUltimaModificacion,
        E.EMFechaAlta AS FechaAltaNegocioOReingreso,
        E.EMFechaIngresoEmpresa,
        E.EMFechaBaja,
        CASE
            WHEN @FechaAddAntesReactivacion IS NULL
                THEN 'PENDIENTE_CAPTURAR_FECHA_ADD_ANTES'
            WHEN E.EMFechaAdd = @FechaAddAntesReactivacion
             AND E.EMIdEstatus = 1
                THEN 'OK_FECHA_ADD_CONSERVADA_Y_EMPLEADO_ACTIVO'
            WHEN E.EMFechaAdd <> @FechaAddAntesReactivacion
                THEN 'ERROR_FECHA_ADD_CAMBIO'
            ELSE 'ERROR_REVISAR_ESTATUS_REACTIVACION'
        END AS Resultado
    FROM dbo.ff_Empleado E
    WHERE E.EMIdEmpresa = @IdEmpresaReactivacion
      AND E.EMNumeroEmpleado = @NumeroEmpleadoReactivado
      AND E.EMIdParentesco = 1
    ORDER BY E.EMIdParentesco, E.ID;
END;

/*
  TRANSFERENCIA
  Calcula la misma selección incluida en ambos SP y la compara con el rol
  almacenado en el empleado transferido.
*/
IF @IdEmpresaDestinoTransferencia IS NULL
   OR
   (
       @IdEmpleadoTransferenciaMasiva IS NULL
       AND @IdEmpleadoTransferenciaIndividual IS NULL
   )
BEGIN
    SELECT
        '02_TRANSFERENCIA' AS Bloque,
        'CAPTURAR EMPRESA DESTINO Y AL MENOS UN ID DE EMPLEADO TRANSFERIDO' AS Resultado;
END
ELSE
BEGIN
    DECLARE @RolDefaultEsperado INT = NULL;
    DECLARE @RolAlternativoEsperado INT = NULL;
    DECLARE @RolEsperado INT = NULL;

    SELECT TOP (1)
        @RolDefaultEsperado = R.ROIdRol
    FROM dbo.ff_Rol R
    INNER JOIN dbo.ff_Perfil P
        ON P.PEIdRolDefault = R.ROIdRol
       AND P.PEIdEmpresa = @IdEmpresaDestinoTransferencia
       AND P.PEIdEstatus = 1
    WHERE R.ROIdEmpresa = @IdEmpresaDestinoTransferencia
      AND R.ROIdEstatus = 1
      AND R.RODefault = 1
      AND P.PEAdministrador = 0
    ORDER BY R.ROIdRol ASC;

    SELECT TOP (1)
        @RolAlternativoEsperado = R.ROIdRol
    FROM dbo.ff_Rol R
    INNER JOIN dbo.ff_Perfil P
        ON P.PEIdRolDefault = R.ROIdRol
       AND P.PEIdEmpresa = @IdEmpresaDestinoTransferencia
       AND P.PEIdEstatus = 1
    WHERE R.ROIdEmpresa = @IdEmpresaDestinoTransferencia
      AND R.ROIdEstatus = 1
      AND P.PEAdministrador = 0
    ORDER BY R.ROIdRol ASC;

    SET @RolEsperado = ISNULL(@RolDefaultEsperado, @RolAlternativoEsperado);

    DECLARE @PruebasTransferencia TABLE
    (
        TipoPrueba VARCHAR(15) NOT NULL,
        IdEmpleado INT NOT NULL
    );

    IF @IdEmpleadoTransferenciaMasiva IS NOT NULL
        INSERT INTO @PruebasTransferencia (TipoPrueba, IdEmpleado)
        VALUES ('MASIVA', @IdEmpleadoTransferenciaMasiva);

    IF @IdEmpleadoTransferenciaIndividual IS NOT NULL
        INSERT INTO @PruebasTransferencia (TipoPrueba, IdEmpleado)
        VALUES ('INDIVIDUAL', @IdEmpleadoTransferenciaIndividual);

    SELECT
        '02_TRANSFERENCIA' AS Bloque,
        T.TipoPrueba,
        E.ID AS IdEmpleado,
        E.EMNumeroEmpleado,
        E.EMIdEmpresa AS EmpresaActual,
        @IdEmpresaDestinoTransferencia AS EmpresaDestinoEsperada,
        E.EMIdRol AS RolAsignado,
        @RolDefaultEsperado AS RolDefaultNoAdministrativo,
        @RolAlternativoEsperado AS RolAlternativoNoAdministrativo,
        @RolEsperado AS RolEsperado,
        CASE
            WHEN E.ID IS NULL THEN 'ERROR_EMPLEADO_NO_EXISTE'
            WHEN E.EMIdEmpresa <> @IdEmpresaDestinoTransferencia
                THEN 'ERROR_EMPRESA_DESTINO_NO_COINCIDE'
            WHEN @RolEsperado IS NULL
                THEN 'ERROR_EMPRESA_SIN_ROL_NO_ADMINISTRATIVO'
            WHEN E.EMIdRol = @RolEsperado
                THEN 'OK_ROL_ASIGNADO_CORRECTAMENTE'
            ELSE 'ERROR_ROL_ASIGNADO_NO_COINCIDE'
        END AS Resultado
    FROM @PruebasTransferencia T
    LEFT JOIN dbo.ff_Empleado E ON E.ID = T.IdEmpleado
    ORDER BY T.TipoPrueba;

    SELECT DISTINCT
        '03_CANDIDATOS_ROL_DESTINO' AS Bloque,
        R.ROIdRol,
        R.RODefault,
        R.ROIdEstatus,
        P.PEIdPerfil,
        P.PENombre,
        P.PEAdministrador,
        P.PEIdEstatus,
        CASE
            WHEN R.ROIdRol = @RolEsperado THEN 'ROL_ESPERADO'
            ELSE 'OTRO_CANDIDATO'
        END AS Clasificacion
    FROM dbo.ff_Rol R
    INNER JOIN dbo.ff_Perfil P
        ON P.PEIdRolDefault = R.ROIdRol
       AND P.PEIdEmpresa = @IdEmpresaDestinoTransferencia
    WHERE R.ROIdEmpresa = @IdEmpresaDestinoTransferencia
      AND R.ROIdEstatus = 1
      AND P.PEIdEstatus = 1
      AND P.PEAdministrador = 0
    ORDER BY R.RODefault DESC, R.ROIdRol, P.PEIdPerfil;
END;
GO

