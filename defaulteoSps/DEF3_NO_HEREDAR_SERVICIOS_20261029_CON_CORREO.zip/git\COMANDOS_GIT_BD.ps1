# Completa solamente estos valores antes de ejecutar.
$Repo = "PEGA_AQUI_LA_RUTA_DEL_REPOSITORIO"
$RamaDestino = "PEGA_AQUI_LA_RAMA_DESTINO"
$RutaScripts = "PEGA_AQUI_LA_RUTA_RELATIVA_DE_LOS_SCRIPTS_BD"

Set-Location -LiteralPath $Repo
git switch $RamaDestino
git pull --ff-only origin $RamaDestino

# Scripts que se liberan: dos motores, wrapper y validacion.
git add -- "$RutaScripts/01_ALTER_DOS_SP_NO_HEREDAR_SERVICIOS.sql"
git add -- "$RutaScripts/01B_ALTER_WRAPPER_MULTIVIGENCIA.sql"
git add -- "$RutaScripts/04_VALIDAR_INSTALACION.sql"

git status
git diff --cached
git commit -m "Corrige servicios y planes de dependientes en defaulteo tipo 3"
git push origin $RamaDestino
