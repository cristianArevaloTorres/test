USE [FlexiForbesv2];
GO

SET NOCOUNT ON;

/* Valida los dos motores que asignan selecciones y planes basicos. */
SELECT
    O.name AS procedimiento,
    O.modify_date AS fechaModificacion,
    CASE
        WHEN OBJECT_DEFINITION(O.object_id) LIKE '%CAT 2026-10-29%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%POO.POOpcionForzosa = ''1''%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%PF.TCidTipoTarifa = 2%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%PF.Id = PO.POIdEmpleado%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%BasicosIndividualesCandidatos%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%BasicosGrupalesBase%'
            THEN 'CORRECCION_INSTALADA'
        ELSE 'REVISAR'
    END AS resultado
FROM sys.objects O
WHERE O.object_id IN
(
    OBJECT_ID('dbo.ff_CBuscaPlanEspejoTest'),
    OBJECT_ID('dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3')
)
ORDER BY O.name;

IF
(
    SELECT COUNT(*)
    FROM sys.objects O
    WHERE O.object_id IN
    (
        OBJECT_ID('dbo.ff_CBuscaPlanEspejoTest'),
        OBJECT_ID('dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3')
    )
      AND OBJECT_DEFINITION(O.object_id) LIKE '%CAT 2026-10-29%'
      AND OBJECT_DEFINITION(O.object_id) LIKE '%POO.POOpcionForzosa = ''1''%'
      AND OBJECT_DEFINITION(O.object_id) LIKE '%PF.TCidTipoTarifa = 2%'
      AND OBJECT_DEFINITION(O.object_id) LIKE '%PF.Id = PO.POIdEmpleado%'
      AND OBJECT_DEFINITION(O.object_id) LIKE '%BasicosIndividualesCandidatos%'
      AND OBJECT_DEFINITION(O.object_id) LIKE '%BasicosGrupalesBase%'
) <> 2
    THROW 51000, 'La correccion no esta instalada en los dos motores de defaulteo.', 1;

/* Valida la carga de tarifas grupales historicas del wrapper multivigencia. */
SELECT
    O.name AS procedimiento,
    O.modify_date AS fechaModificacion,
    CASE
        WHEN OBJECT_DEFINITION(O.object_id)
                 LIKE '%CAT 2026-10-29: la tarifa historica grupal es tipo 2%'
         AND OBJECT_DEFINITION(O.object_id)
                 LIKE '%WHERE tc.tcidtipotarifa=2%'
            THEN 'CORRECCION_INSTALADA'
        ELSE 'REVISAR'
    END AS resultado
FROM sys.objects O
WHERE O.object_id =
      OBJECT_ID('dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3');

IF NOT EXISTS
(
    SELECT 1
    FROM sys.objects O
    WHERE O.object_id =
          OBJECT_ID('dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3')
      AND OBJECT_DEFINITION(O.object_id)
              LIKE '%CAT 2026-10-29: la tarifa historica grupal es tipo 2%'
      AND OBJECT_DEFINITION(O.object_id)
              LIKE '%WHERE tc.tcidtipotarifa=2%'
)
    THROW 51000, 'La correccion grupal no esta instalada en el wrapper multivigencia.', 1;

SELECT 'VALIDACION_OK' AS resultado;
GO

