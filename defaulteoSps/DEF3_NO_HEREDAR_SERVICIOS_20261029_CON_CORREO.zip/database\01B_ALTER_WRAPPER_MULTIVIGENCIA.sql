USE [FlexiForbesv2];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO



/* ALTER dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3 */

ALTER PROCEDURE [dbo].[ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3]
@idempresa int, @idempleado int, @tmpplanesseleccionados nvarchar(MAX), @tmpplanesseleccionadosold nvarchar(MAX), @transfer varchar(6) = null,@idVigenciaD int,@idVigenciaDestino int = NULL
WITH EXEC AS CALLER
AS
BEGIN
	-- CAT: def3 calcula elegibilidad y tarifas en la vigencia destino;
	-- def1 conserva el comportamiento de la vigencia anterior.
	DECLARE @idVigenciaCalculo INT
	SET @idVigenciaCalculo = CASE WHEN @transfer = 'def3'
		THEN ISNULL(NULLIF(@idVigenciaDestino, 0), @idVigenciaD)
		ELSE @idVigenciaD END

	DECLARE @idoc INT,
	@numeroempleado VARCHAR(20),
	@idperfil INT,
	-- MOD 21102019
	@sobrantecred MONEY

	--variables tope nuevo
	declare @topeIdPlanOpcion int,
		@topePrimaTotal money,
		@topePrimaNeta money,
		@topeIdPlan int



	SELECT @numeroempleado = emnumeroempleado,
			@idempresa =      emidempresa,
			@idperfil =       emidperfil
	FROM   dbo.ff_empleado WITH (NOLOCK)
	WHERE  id = @idempleado
	AND    emidtitular = 1
	AND    emidestatus = 1

	CREATE TABLE #tmpplanesseleccionados
		(
			tcidtarifacosto INT,
			nuevo           VARCHAR(2),
			costo           MONEY,
			idempleado      INT

			 INDEX [IX_TCidTarifaCosto] CLUSTERED ([TCidTarifaCosto])
		)

	CREATE TABLE #tmpplanesseleccionadosold
		(
			tcidtarifacosto INT,
			nuevo           VARCHAR(2),
			costo           MONEY,
			idempleado      INT

			INDEX [IX_TCidTarifaCosto] CLUSTERED ([TCidTarifaCosto])
		)

	INSERT INTO #tmpplanesseleccionadosold
	SELECT *
	FROM   openjson (@tmpplanesseleccionadosold)
			WITH ( tcidtarifacosto INT N'$.tcidtarifacostoOld', nuevo VARCHAR(2) N'$.nuevoOld', costo MONEY N'$.costoOld', idempleado INT N'$.idempleadoOld' );

	INSERT INTO #tmpplanesseleccionados
	SELECT *
	FROM   openjson (@tmpplanesseleccionados)
			WITH ( tcidtarifacosto INT N'$.tcidtarifacosto', nuevo VARCHAR(2) N'$.nuevo', costo MONEY N'$.costo', idempleado INT N'$.idempleado' );

	UPDATE #tmpplanesseleccionados
	SET    nuevo = 'N'
	WHERE  CAST(tcidtarifacosto AS varchar(10))+'-'+CAST(idempleado AS VARCHAR(10)) NOT IN
					(
						SELECT CAST(o.tcidtarifacosto AS VARCHAR(10))+'-'+CAST(o.idempleado AS VARCHAR(10))
						FROM   #tmpplanesseleccionadosold o
					)

	UPDATE #tmpplanesseleccionadosold
	SET    nuevo = 'U'
	FROM   #tmpplanesseleccionadosold u
	WHERE  CAST(tcidtarifacosto AS VARCHAR(10))+'-'+CAST(idempleado AS VARCHAR(10)) NOT IN
					(
						SELECT CAST(o.tcidtarifacosto AS VARCHAR(10))+'-'+CAST(o.idempleado AS VARCHAR(10))
						FROM   #tmpplanesseleccionados o
					)


	/* INICIO Obtener correspondencia de Script por empresa*/
	DECLARE @IsV32 bit
	SELECT @IsV32 = Activo
				FROM ff_PlanesPerfilScript
				WHERE EMIdEmpresa = @idempresa
	/* FIN Obtener correspondencia de Script por empresa*/

	--IF @idempresa in (368,369)
	IF(@IsV32 = 1)
	BEGIN
	  ------------------------------------------------------------------------------------------------------------------------------------------------

	  PRINT 'INICIO 2'
	  EXEC ff_cbuscaplanesperfil_v32TestMultivigenciaBF3 @idempleado,@transfer,@idVigenciaCalculo

	  ------------------------------------------------------------------------------------------------------------------------------------------------
	END
	ELSE
	BEGIN

		-- ################################################################################################
        print 'SE METIO AQUI CARLOS***********************************************'
		DECLARE @idEstatusVigencia INT

		CREATE TABLE #tempplanesempleadosvalidos
		(
			idplanopcion INT NULL,
			idempleado INT NULL,
			paso VARCHAR(1) NULL

			INDEX [IX_IDPLANOPCION] CLUSTERED ([IDPLANOPCION]),
			INDEX [IX_IDEMPLEADO] NONCLUSTERED ([IDEMPLEADO])
		)
/*
		IF (dbo.verificacc(@idEmpleado) = 1)
			SET @idEstatusVigencia = 1
		ELSE
			SET @idEstatusVigencia = 6
*/
		INSERT INTO #tempplanesempleadosvalidos
			SELECT vcidplanopcion AS idplanopcion,
					0,
					'2' AS paso
			FROM dbo.ff_planopcionvigencia WITH (NOLOCK, READUNCOMMITTED)
				INNER JOIN dbo.ff_vigencia WITH (NOLOCK, READUNCOMMITTED) ON vitiponegocio = 1
				AND vcidvigencia=viidvigencia
				--AND viidestatus= @idEstatusVigencia *multivigencia
				AND vcidestatus= 2
				AND vcidvigencia = @idVigenciaCalculo
				INNER JOIN dbo.ff_empresa WITH (NOLOCK, READUNCOMMITTED) ON viidconfiguracion = emidconfiguracion
				INNER JOIN dbo.ff_planopcionperfil WITH (NOLOCK, READUNCOMMITTED)  ON vcidplanopcion = ppidplanopcion
			WHERE emidempresa = @idEmpresa
				AND vcidestatus = 2
				AND ppidestatus = 1
				AND ppidperfil= @IdPerfil

		-- ################################################################################################
		INSERT INTO #tempplanesempleadosvalidos
		SELECT DISTINCT a.psidplanopcion AS IDPLANOPCION,
						B.id	AS IDEMPLEADO,
						'3'	AS PASO
		FROM   ff_empleado b WITH (NOLOCK, READUNCOMMITTED)
			INNER JOIN #tempplanesempleadosvalidos t WITH (NOLOCK, READUNCOMMITTED) ON emnumeroempleado = @NumeroEmpleado
			AND emidempresa = @idempresa
			INNER JOIN dbo.ff_planopcionsexo a WITH (NOLOCK, READUNCOMMITTED) ON a.psidplanopcion = t.idplanopcion
			AND b.emidsexo = a.psidsexo
		WHERE  B.emidestatus = 1
		OPTION (KEEPFIXED PLAN)

		DELETE #tempplanesempleadosvalidos
		WHERE  paso = '2'



		-- ################################################################################################
		DECLARE @IDVIGENCIAANT INT
		SET @IDVIGENCIAANT = (
			SELECT virenovada
			FROM ff_vigencia
			WHERE viidvigencia = @idVigenciaCalculo )

		CREATE TABLE #empleadosplanopcion
		(
			ppidplanopcion INT NULL,
			idempleado INT NULL,
			emidparentesco INT NULL,
			emidsexo INT NULL,
			emedad INT NULL,
			paso INT NULL,
			tipocosto INT NULL

			INDEX [IX_PPIDPLANOPCION] NONCLUSTERED ([PPIDPLANOPCION]),
			INDEX [IX_idempleado] CLUSTERED ([idempleado]),
			INDEX [IX_emidparentesco] NONCLUSTERED ([emidparentesco])
		)

		CREATE TABLE #empleado
		(
			id INT,
			emnumeroempleado VARCHAR(20) NULL,
			emapellidomaterno VARCHAR(30) NULL,
			emapellidopaterno VARCHAR(30) NULL,
			emnombre1 VARCHAR(70) NULL,
			emnombre2 VARCHAR(30) NULL,
			emidempresa INT NULL,
			emidparentesco INT NULL,
			emidsexo INT NULL,
			emedad INT NULL,
			emsalariobase MONEY,
			emidperfil INT NULL,
			emidestatus INT NULL

			INDEX [IX_id] CLUSTERED ([id]),
			INDEX [IX_emidempresa] NONCLUSTERED ([emidempresa]),
			INDEX [IX_emidparentesco] NONCLUSTERED ([emidparentesco]),
			INDEX [IX_EMIdPerfil] NONCLUSTERED ([EMIdPerfil])
		)

		INSERT INTO #empleado
		SELECT id,
			emnumeroempleado,
			emapellidomaterno,
			emapellidopaterno,
			emnombre1,
			emnombre2,
			emidempresa,
			emidparentesco,
			emidsexo,
			dbo.regresaedadempleado(id),
			emsalariobase,
			emidperfil,
			emidestatus
		FROM ff_empleado WITH (NOLOCK, READUNCOMMITTED)
		WHERE emidempresa =	@idempresa
			AND emidestatus=1
			AND emnumeroempleado=@NumeroEmpleado

		INSERT INTO #empleadosplanopcion

			SELECT a.ppidplanopcion,
				id AS idempleado,
				emidparentesco,
				emidsexo,
				emedad,
				4 AS paso,
				0
			FROM #empleado b WITH (NOLOCK, READUNCOMMITTED)
				INNER JOIN dbo.ff_planopcionparentescoedad a WITH (NOLOCK, READUNCOMMITTED) ON b.emidparentesco = a.ppidparentesco
			WHERE b.emidestatus = 1
				AND emnumeroempleado = @NUMEROEMPLEADO
				AND emidempresa = @idempresa
				AND emedad BETWEEN ppedadmin AND ppedadmax
				AND ppidestatus = 1
				AND CAST(a.ppidplanopcion AS VARCHAR(20)) + '-' + CAST(id AS VARCHAR(20))
					IN (
						SELECT CAST(idplanopcion AS VARCHAR(20)) + '-' + CAST(idempleado AS VARCHAR(20))
						FROM #tempplanesempleadosvalidos
						WHERE paso = '3'
					)
					-- ## LM27102020
					-- and not exists (select '' from dbo.ff_planopcionseleccion c where c.poidplanopcion = a.ppidplanopcion AND c.poidvigencia = @IDVIGENCIAANT)
			UNION

			SELECT a.ppidplanopcion,
				id AS idempleado,
				emidparentesco,
				emidsexo,
				emedad,
				4 AS paso,
				0
			FROM #empleado b WITH (NOLOCK, READUNCOMMITTED)
				INNER JOIN dbo.ff_planopcionparentescoedad a WITH (NOLOCK, READUNCOMMITTED) ON b.emidparentesco = a.ppidparentesco
				INNER JOIN dbo.ff_planopcionseleccion c WITH (NOLOCK, READUNCOMMITTED) ON b.id = c.poidempleado
			WHERE emidempresa = @idempresa
				AND b.emidestatus = 1
				AND emnumeroempleado = @NUMEROEMPLEADO
				AND emedad BETWEEN ppedadminr AND ppedadmaxr
				AND ppidestatus = 1
				AND CAST(a.ppidplanopcion AS VARCHAR(20)) + '-' + CAST(id AS VARCHAR(20))
					IN (
						SELECT CAST(idplanopcion AS VARCHAR(20)) + '-' + CAST(idempleado AS VARCHAR(20))
						FROM #tempplanesempleadosvalidos
						WHERE paso = '3'
					)
				AND c.poidplanopcion = a.ppidplanopcion
				AND c.poidvigencia = @IDVIGENCIAANT
				OPTION (keep plan)

		UPDATE epo
		SET    tipocosto = 1
		FROM   ff_empresa e WITH (NOLOCK, READUNCOMMITTED)
			   INNER JOIN ff_ramo r WITH (NOLOCK, READUNCOMMITTED)
					   ON e.emidcorporativo = r.raidcorporativo
			   INNER JOIN ff_plan p WITH (NOLOCK, READUNCOMMITTED)
					   ON r.raidramo = p.plidramo
			   INNER JOIN ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
					   ON p.plidplan = po.poidplan
			   INNER JOIN #empleadosplanopcion epo WITH (NOLOCK, READUNCOMMITTED)
					   ON po.poidplanopcion = epo.ppidplanopcion
		WHERE  E.emidempresa = @idEmpresa
			   AND p.plidestatus = 1
			   AND p.pltipocosto = 1
			   AND po.poidestatus = 1
		-- ################################################################################################

		DECLARE @NUCLEOFAMILIAR CHAR(1),
			@GpoTitular INTEGER

		SELECT @NUCLEOFAMILIAR = conucleofamiliarforzoso
		FROM dbo.ff_empresa e WITH (NOLOCK, READUNCOMMITTED)
			INNER JOIN dbo.ff_configuracion c WITH (NOLOCK, READUNCOMMITTED)
				ON e.emidconfiguracion = c.coidconfiguracion
		WHERE emidempresa = @idEmpresa

		CREATE TABLE #planopciongrupoparentesco
		 (
			ppidplanopcion INT,
			gpidgrupoparentesco INT,
			cantidad INT,
			nucleofamiliar INT

			INDEX [IX_PPIDPLANOPCION] NONCLUSTERED  ([PPIDPLANOPCION]),
			INDEX [IX_gpidgrupoparentesco] NONCLUSTERED ([gpidgrupoparentesco])
		 )

		DECLARE @PlanOpcionGrupoParentesco AS TABLE
		(
			ppidplanopcion INT,
			gpidgrupoparentesco INT,
			cantidad INT,
			nucleofamiliar INT
		)

		 /*************** PASO 1 AGRUPAR LOS POSIBLES GRUPOS PARENTESCOS *********************/

		INSERT INTO @PlanOpcionGrupoParentesco
		SELECT EPO.ppidplanopcion,
			gpidgrupoparentesco,
			0 AS Cantidad,
			1 AS NucleoFamiliar
		FROM   dbo.ff_grupoparentescoparentesco
			INNER JOIN #empleadosplanopcion EPO WITH (NOLOCK, READUNCOMMITTED)
				ON gpidparentesco = emidparentesco
		WHERE  tipocosto = 1
			AND gpidsexo IS NULL
			AND gpidgrupoparentesco IN
				(
					SELECT DISTINCT gpidgrupoparentesco
					FROM   dbo.ff_grupoparentescoparentesco gp1 WITH (NOLOCK, READUNCOMMITTED)
					WHERE  CAST(gpidparentesco AS VARCHAR(3)) + '-' + CAST(gpcantidad AS VARCHAR(3))
						IN (
							SELECT CAST(emidparentesco AS VARCHAR(3)) + '-' + CAST(Count(*) AS VARCHAR(3))
							FROM #empleadosplanopcion
							WHERE ppidplanopcion = EPO.ppidplanopcion
								AND emidparentesco IN( 1, 2, 3 )
							GROUP  BY emidparentesco
							)
					GROUP  BY gp1.gpidgrupoparentesco
					HAVING Sum(gpcantidad) =
							(
							SELECT Sum(gpcantidad)
							FROM   dbo.ff_grupoparentescoparentesco gp2 WITH ( NOLOCK, READUNCOMMITTED)
							WHERE  gp2.gpidgrupoparentesco = gp1.gpidgrupoparentesco
							)
			AND
				(
					SELECT Count(*)
					FROM   dbo.ff_grupoparentescoparentesco gpp WITH (NOLOCK, READUNCOMMITTED)
					WHERE  gpp.gpidgrupoparentesco = gp1.gpidgrupoparentesco
						AND gpp.gpidparentesco = 1) = 1)
						OR tipocosto = 1
						AND gpidgrupoparentesco IN
							(
							SELECT DISTINCT gpidgrupoparentesco
							FROM   dbo.ff_grupoparentescoparentesco gp1 WITH (NOLOCK, READUNCOMMITTED)
							WHERE  gpidsexo IS NOT NULL
								AND CAST(gpidparentesco AS VARCHAR(3)) + '-' + CAST(gpidsexo AS VARCHAR(3)) + '-' + CAST(gpcantidad AS VARCHAR(3))
									IN (
										SELECT CAST(emidparentesco AS VARCHAR (3)) + '-'
												+ CAST( CASE WHEN Count(*) > 1 THEN 0
														ELSE emidsexo END AS VARCHAR(3)) + '-' + CAST(Count(*) AS VARCHAR (3))
										FROM #empleadosplanopcion
										WHERE ppidplanopcion = EPO.ppidplanopcion
											AND emidparentesco IN( 1, 2, 3 )
										GROUP BY emidparentesco, emidsexo
										)
							GROUP  BY gp1.gpidgrupoparentesco
							HAVING Sum(gpcantidad) = (
													SELECT Sum(gpcantidad)
													FROM  dbo.ff_grupoparentescoparentesco gp2 WITH (NOLOCK, READUNCOMMITTED)
													WHERE gp2.gpidgrupoparentesco = gp1.gpidgrupoparentesco)
														AND (
															SELECT Count(*)
															FROM   dbo.ff_grupoparentescoparentesco gpp WITH (NOLOCK, READUNCOMMITTED)
															WHERE  gpp.gpidgrupoparentesco = gp1.gpidgrupoparentesco
																AND gpp.gpidparentesco = 1) = 1
															)
													GROUP  BY EPO.ppidplanopcion, ff_grupoparentescoparentesco.gpidgrupoparentesco

		/************PASO 2, INSERTAR EL NUMERO DE MIEMBROS DE CADA GRUPO PARENTESCO**********/

		UPDATE @PlanOpcionGrupoParentesco
		SET	cantidad = (
						SELECT Sum(gpcantidad)
						FROM   @PlanOpcionGrupoParentesco c
							INNER JOIN dbo.ff_grupoparentescoparentesco d WITH (NOLOCK, READUNCOMMITTED)
								ON c.gpidgrupoparentesco = d.gpidgrupoparentesco
						WHERE  c.ppidplanopcion = a.ppidplanopcion
							AND d.gpidgrupoparentesco = b.gpidgrupoparentesco
						)
			FROM   @PlanOpcionGrupoParentesco a
				INNER JOIN dbo.ff_grupoparentescoparentesco b WITH (NOLOCK, READUNCOMMITTED)
					ON a.gpidgrupoparentesco = b.gpidgrupoparentesco
			WHERE  a.nucleofamiliar = 1

		/**************PASO 3  si se desea unicamente el nucleo familiar se eliminan los demas*************************/
		IF( @NucleoFamiliar = '1' )
			BEGIN
				DELETE @PlanOpcionGrupoParentesco
				WHERE  nucleofamiliar = 1
					AND ppidplanopcion NOT IN (
												SELECT poidplanopcion
												FROM   ff_plan AS PL
													INNER JOIN ff_planopcion AS PO  WITH (NOLOCK, READUNCOMMITTED)
														ON PL.plidplan = PO.poidplan
												WHERE  plidestatus = 1
													AND plgrupoparentescoforzozo = 1
												)
					AND CAST(ppidplanopcion AS VARCHAR(5)) + '-' + CAST(gpidgrupoparentesco AS VARCHAR(3))
						NOT IN (
								SELECT CAST(p.ppidplanopcion AS VARCHAR(5)) + '-'
									 + CAST(p.gpidgrupoparentesco AS VARCHAR(3))
								FROM   @PlanOpcionGrupoParentesco p
								WHERE  p.nucleofamiliar = 1
								GROUP  BY p.ppidplanopcion, p.gpidgrupoparentesco, p.cantidad
								HAVING p.cantidad = (
													SELECT MAX(cantidad)
													FROM   @PlanOpcionGrupoParentesco
													WHERE ppidplanopcion = p.ppidplanopcion
														AND nucleofamiliar = 1
													)
								)
			END

		INSERT INTO @PlanOpcionGrupoParentesco
		SELECT poidplanopcion,
			   @GpoTitular,
			   1 AS Cantidad,
			   2 AS NucleoFamiliar
		FROM   dbo.ff_plan WITH (NOLOCK, READUNCOMMITTED)
			   INNER JOIN dbo.ff_planopcion WITH (NOLOCK, READUNCOMMITTED)
					   ON plidplan = poidplan
		WHERE  plcoberturaforzosatitular = '1'
			   AND poidplanopcion IN (SELECT DISTINCT ppidplanopcion
									  FROM   @PlanOpcionGrupoParentesco)

		TRUNCATE TABLE #planopciongrupoparentesco

		INSERT INTO #planopciongrupoparentesco
		SELECT *
		FROM   @PlanOpcionGrupoParentesco

		-- ################################################################################################
		SET NOCOUNT OFF
		CREATE TABLE #tmpplanesflexibles
		(
			id INTEGER NULL,
			emapellidomaterno VARCHAR(50) NULL,
			emapellidopaterno VARCHAR(50) NULL,
			emnombre1 VARCHAR(50) NULL,
			emnombre2 VARCHAR(50) NULL,
			emidparentesco INTEGER NULL,
			tcidtarifacosto INTEGER NULL,
			tcidtarifa INTEGER NULL,
			tcidplanopcion INTEGER NULL,
			tcidtipotarifa INTEGER NULL,
			tcidgrupoparentesco INTEGER NULL,
			tcidparentesco INTEGER NULL,
			tcidsexo INTEGER NULL,
			tcedad INTEGER NULL,
			tcidtipofumador INTEGER NULL,
			tcprimaneta MONEY NULL,
			tcprimatotal MONEY NULL,
			poidplanopcion INTEGER NULL,
			poidplan INTEGER NULL,
			ponombre VARCHAR(50) NULL,
			podescripcion VARCHAR(150) NULL,
			pocaptura CHAR(1) NULL,
			plnombre VARCHAR(50) NULL,
			pldescripcion VARCHAR(150),
			plidramo INTEGER NULL,
			plcoberturaforzosatitular VARCHAR(1),
			ranombre VARCHAR(50) NULL,
			radescripcion VARCHAR(150) NULL,
			parentescosdescripcion VARCHAR(150) NULL,
			idparentesco INTEGER NULL,
			padescripcion VARCHAR(150) NULL,
			checked VARCHAR(10) NULL,
			visible VARCHAR(10) NULL,
			enabled VARCHAR(10) NULL,
			htmlcontrol VARCHAR(500) NULL,
			cantidad INTEGER NULL,
			archivo VARCHAR(200) NULL,
			raimg VARCHAR(200) NULL,
			plimg VARCHAR(200) NULL,
			poimg VARCHAR(200) NULL,
			raorden INT NULL,
			plorden INT NULL,
			poorden INT NULL,
			-- MOD JLVS 131011
			archivoplan VARCHAR(200) NULL,
			plAyuda VARCHAR(MAX) NULL

			INDEX [IX_ID] NONCLUSTERED ([ID]),
			INDEX [IX_TCIdTarifaCosto] CLUSTERED ([TCIdTarifaCosto]),
			INDEX [IX_ff_tcidplanopcion] NONCLUSTERED ([tcidplanopcion]),
			INDEX [IX_ff_tcidGRUPOPARENTESCO] NONCLUSTERED ([tcidGRUPOPARENTESCO]),
			INDEX [IX_ff_poidplanopcion] NONCLUSTERED ([poidplanopcion])
		)

		CREATE TABLE #mensajes
		(
			descripcion VARCHAR(200) NULL,
			tipo VARCHAR(100) NULL
		)

		/***********************************************/
		/*	Valida SAMI PARA PLANES DE VIDA        */
		/***********************************************/
		CREATE TABLE #saempleado
		(
			idempleado INT NULL,
			idplanopcion INT NULL,
			sa MONEY NULL

			INDEX [IX_idempleado] NONCLUSTERED ([idempleado]),
			INDEX [IX_idplanopcion] CLUSTERED ([idplanopcion])
		)

		CREATE TABLE #primascompuestas
		(
			vsidempleado INT NULL,
			poidplanopcion INT NULL,
			primatotal MONEY NULL

			INDEX [IX_VSidEmpleado] NONCLUSTERED ([VSidEmpleado]),
			INDEX [IX_POidPlanOpcion] CLUSTERED ([POidPlanOpcion])
		)

		CREATE TABLE #creditosotorgadospendientes
		(
			idcompensacion INT NULL,
			cantidad MONEY NULL

			INDEX [IX_idCompensacion] CLUSTERED ([idCompensacion])
		)

		CREATE TABLE #creditosotorgados
		(
			idcompensacion INT NULL,
			cantidad MONEY NULL

			INDEX [IX_idCompensacion] CLUSTERED ([idCompensacion])
		)

		CREATE TABLE #creditosotorgadosex
		(
			idcompensacion INT NULL,
			cantidad MONEY NULL

			INDEX [IX_idCompensacion] CLUSTERED ([idCompensacion])
		)

		CREATE TABLE #calculo_selecciones
		(
			tcidplanopcion INT NULL,
			total MONEY NULL

			INDEX [IX_tcidplanopcion] CLUSTERED  ([tcidplanopcion])
		)

		CREATE TABLE #descuento_nomina
		(
			tcidplanopcion INT NULL,
			total MONEY NULL

			INDEX [IX_tcidplanopcion] CLUSTERED ([tcidplanopcion])
		)

		CREATE TABLE #planescreditos
		(
			tcidplanopcion INT NULL,
			total MONEY NULL,
			--MOD 21102019
			Saldo MONEY NULL,
			Orden INT

			INDEX [IX_tcidplanopcion] CLUSTERED ([tcidplanopcion])
		)



		-- ##################################################################################################
		SET nocount ON
		DECLARE @idvigencia INT
		DECLARE @muestrasueldo INT
		DECLARE @temporales INT
		DECLARE @tmpseleccion INT
		DECLARE @grupop INTEGER
		DECLARE @grupopant INTEGER
		DECLARE @planopcion INTEGER
		DECLARE @vigenciainicio datetime
		DECLARE @idtarifa AS INTEGER

		SELECT @nucleofamiliar = conucleofamiliarforzoso
		FROM dbo.ff_configuracion AS c WITH (NOLOCK, READUNCOMMITTED)
			INNER JOIN dbo.ff_empresa AS e WITH (NOLOCK, READUNCOMMITTED)
				ON c.coidconfiguracion = e.emidconfiguracion
		WHERE emidempresa = @idempresa

		print 'nucleo familiar for ' + @nucleofamiliar
		print 'corte1'

		SELECT @idperfil = emidperfil
		FROM dbo.ff_empleado WITH (NOLOCK, READUNCOMMITTED)
		WHERE id = @idempleado
			AND emidtitular = 1
			AND emidestatus = 1

		SELECT @gpotitular = gp.gpidgrupoparentesco
		FROM dbo.ff_grupoparentescoparentesco gp WITH (NOLOCK, READUNCOMMITTED)
		WHERE gp.gpcantidad = 1
			AND gp.gpidparentesco = 1
			AND (
				gpidsexo =
					(
						SELECT emidsexo
						FROM dbo.ff_empleado WITH (NOLOCK, READUNCOMMITTED)
						WHERE id = @idempleado
					)
				OR gpidsexo IS NULL
				)
		GROUP BY gp.gpidgrupoparentesco HAVING (
										SELECT sum(gpcantidad)
										FROM dbo.ff_grupoparentescoparentesco WITH (NOLOCK, READUNCOMMITTED)
										WHERE gp.gpidgrupoparentesco = gpidgrupoparentesco) = 1
										OPTION (keep plan)

		IF (dbo.verificacc(@idempleado) = 1)
			SET @idestatusvigencia = 1
		ELSE
			SET @idestatusvigencia = 6

		SELECT @idvigencia = viidvigencia,
			@vigenciainicio = vivigenciaini
		FROM dbo.ff_vigencia WITH (NOLOCK, READUNCOMMITTED)
			INNER JOIN dbo.ff_empresa  WITH (NOLOCK, READUNCOMMITTED)
				ON viidconfiguracion = emidconfiguracion WHERE vitiponegocio = 1
				AND viidvigencia = @idVigenciaCalculo
				AND emidempresa = @idempresa
				OPTION (keep plan)

		SET @idtarifa = (
						SELECT taidtarifa
						FROM ff_tarifa
						WHERE taidvigencia = @idvigencia
						)




		IF EXISTS(
				SELECT cpidcondicionplan
				FROM dbo.ff_condicionplan WITH (NOLOCK)
				WHERE cpidtipocondicion = 15
					AND cpidempresa = @idEmpresa
					AND cpidperfil = @idPerfil
					AND cpidestatus=1
				)
			BEGIN
			print 'Entro agregar el titular'

			INSERT INTO #planopciongrupoparentesco
				SELECT ppidplanopcion,
					r.rcidgrupoparentesco,
					r.rccantidad,
					rccondicion
				FROM #planopciongrupoparentesco
					INNER JOIN dbo.ff_resultadocondicionplan r WITH (NOLOCK)
						ON ppidplanopcion = r.rcidplanopcion
					INNER JOIN dbo.ff_condicionplan WITH (NOLOCK)
						ON r.rcidcondicionplan = cpidcondicionplan
						AND cpidtipocondicion = 15
				WHERE cpidempresa = @idempresa
					AND cpidperfil = @idPerfil
					AND nucleofamiliar = r.rccantidad
					AND (
						SELECT count(ppidplanopcion)
						FROM #planopciongrupoparentesco tmp
						WHERE tmp.ppidplanopcion = r.rcidplanopcion
							AND gpidgrupoparentesco = r.rcidgrupoparentesco
							AND r.rccantidad=cantidad) = 0

			print 'corte2'
			END


		INSERT INTO #tmpplanesflexibles
		SELECT DISTINCT e.id,
                e.emapellidomaterno,
                e.emapellidopaterno,
                e.emnombre1,
                e.emnombre2,
                e.emidparentesco,
                tcidtarifacosto,
                tcidtarifa,
                tcidplanopcion,
                tcidtipotarifa,
                tcidgrupoparentesco,
                tcidparentesco,
                e.emidsexo,
                tcedad,
                tcidtipofumador,
                tcprimaneta,
                CASE
                  WHEN vssumaasegurada = 0 THEN tcprimatotal
                  WHEN vssumaasegurada IS NULL THEN tcprimatotal
                  ELSE vsprimaanual
                END                             AS TCPrimaTotal,
                po.poidplanopcion,
                po.poidplan,
                po.ponombre,
                po.podescripcion,
                po.pocaptura,
                p.plnombre,
                p.pldescripcion,
                p.plidramo,
                p.plcoberturaforzosatitular,
                r.ranombre,
                r.radescripcion,
                par.padescripcion               AS PARENTESCOSDESCRIPCION,
                tc.tcidparentesco               AS IDPARENTESCO,
                par.padescripcion,
                'false'                         AS Checked,
                'true'                          AS Visible,
                'true'                          AS Enabled,
                'N'                             AS HTMLControl,
                1                               AS cantidad,
                '..\DocumentoEmpresa\'
                + Cast(@idempresa AS VARCHAR(20)) + '\'
                + docarpeta + '\' + dodocumento AS archivo,
                raimagengif,
                plimagengif,
                poimagengif,
                r.raorden,
                p.plorden,
                po.poorden,
                '0',
                NULL
		FROM #empleado e
			INNER JOIN #empleadosplanopcion v  WITH (NOLOCK, READUNCOMMITTED) ON e.id=v.idempleado
			INNER JOIN dbo.ff_TarifaCosto_hist tc WITH (READUNCOMMITTED) ON tc.tcidplanopcion=v.ppidplanopcion
				AND tcidparentesco=e.emidparentesco
				AND tcidsexo=e.emidsexo
				AND tcedad=e.emedad
				AND tcidtarifa = @IdTarifa
				AND tcidestatus = 1
			INNER JOIN dbo.ff_planopcion po WITH (READUNCOMMITTED) ON tc.tcidplanopcion=po.poidplanopcion
			INNER JOIN dbo.ff_plan p WITH (READUNCOMMITTED) ON p.plidplan=po.poidplan
			INNER JOIN dbo.ff_ramo r WITH (READUNCOMMITTED) ON r.raidramo=p.plidramo
			INNER JOIN dbo.ff_parentesco par WITH (READUNCOMMITTED) ON par.paidparentesco=tc.tcidparentesco
			LEFT OUTER JOIN dbo.ff_tarifa trf ON tc.tcidtarifa=trf.taidtarifa
				AND trf.taidestatus = 2
			LEFT OUTER JOIN dbo.ff_documentos doc WITH (READUNCOMMITTED) ON po.poidarchivoinformacion=doc.doid
			LEFT OUTER JOIN dbo.ff_validasavida vs WITH (READUNCOMMITTED) ON vsidempleado=id
			AND vsidplanopcion=tcidplanopcion
			AND vsidvigencia=@idvigencia
		WHERE emnumeroempleado=@NUMEROEMPLEADO
			AND emidempresa=@idempresa
			AND trf.taidvigencia=@idvigencia
		UNION
		SELECT DISTINCT e.id,
			e.emapellidomaterno,
			e.emapellidopaterno,
			e.emnombre1,
			e.emnombre2,
			e.emidparentesco,
			tcidtarifacosto,
			tcidtarifa,
			tcidplanopcion,
			tcidtipotarifa,
			tcidgrupoparentesco,
			tcidparentesco,
			e.emidsexo,
			tcedad,
			tcidtipofumador,
			tcprimaneta,
			tcprimatotal,
			po.poidplanopcion,
			po.poidplan,
			po.ponombre,
			po.podescripcion,
			po.pocaptura,
			p.plnombre,
			p.pldescripcion,
			p.plidramo,
			p.plcoberturaforzosatitular,
			r.ranombre,
			r.radescripcion,
			gpr.gpdescripcion      AS parentescosdescripcion,
			tc.tcidgrupoparentesco AS idparentesco,
			par.padescripcion,
			'false' AS checked,
			'true'  AS visible,
			'true'  AS enabled,
			'N'     AS htmlcontrol,
			v.cantidad,
			'..\DocumentoEmpresa\'+CAST(@IDEMPRESA AS VARCHAR(20))+'\'+DOCarpeta+'\'+DODocumento AS archivo,
			RAImagenGif,
			PLImagenGif,
			POImagenGif,
			r.raorden,
			p.plorden,
			po.poorden,
			'0',
			NULL
		FROM dbo.ff_TarifaCosto_hist tc WITH (NOLOCK,READUNCOMMITTED)
			INNER JOIN dbo.ff_planopcion po WITH (READUNCOMMITTED) ON tc.tcidplanopcion=po.poidplanopcion
				AND tc.tcidtarifa = @IdTarifa
				AND tc.tcidestatus = 1
			INNER JOIN dbo.ff_plan p WITH (READUNCOMMITTED) ON p.plidplan=po.poidplan
			INNER JOIN dbo.ff_ramo r WITH (READUNCOMMITTED) ON r.raidramo=p.plidramo
			LEFT OUTER JOIN dbo.ff_documentos doc WITH (READUNCOMMITTED) ON po.poidarchivoinformacion=doc.doid
			INNER JOIN #planopciongrupoparentesco v  WITH (NOLOCK, READUNCOMMITTED) ON v.ppidplanopcion=tc.tcidplanopcion
				AND tcidgrupoparentesco=v.gpidgrupoparentesco
			INNER JOIN #empleado e  WITH (NOLOCK, READUNCOMMITTED) ON e.id
			IN
			(
				SELECT x.idempleado
				FROM   #empleadosplanopcion x
				WHERE  x.ppidplanopcion=tc.tcidplanopcion
			)
			AND e.emidparentesco
			IN
			(
				SELECT y.gpidparentesco
				FROM   dbo.ff_grupoparentescoparentesco y WITH (NOLOCK,READUNCOMMITTED)
				WHERE  y.gpidgrupoparentesco=tc.tcidgrupoparentesco
			)
			INNER JOIN dbo.ff_grupoparentesco gpr WITH (READUNCOMMITTED) ON gpr.gpidgrupoparentesco=tc.tcidgrupoparentesco
				AND
				(
					tcidsexo=e.emidsexo OR tcidsexo IS NULL
				)
			INNER JOIN dbo.ff_parentesco par WITH (NOLOCK,READUNCOMMITTED) ON par.paidparentesco=e.emidparentesco
			LEFT OUTER JOIN dbo.ff_tarifa trf  WITH (NOLOCK, READUNCOMMITTED) ON tc.tcidtarifa=trf.taidtarifa
				AND trf.taidestatus=2
		-- CAT 2026-10-29: la tarifa historica grupal es tipo 2; con tipo 1 no se cargaba.
		WHERE tc.tcidtipotarifa=2
			AND trf.taidvigencia=@idvigencia
		ORDER BY tcidtarifacosto



		PRINT 'Actualiza prima perfil'

		UPDATE tmp
		SET    tcprimaneta = tpprimaneta,
				tcprimatotal = tpprimatotal
		FROM   ff_tarifacostoperfil
				INNER JOIN #tmpplanesflexibles TMP WITH (NOLOCK, READUNCOMMITTED)
						ON tpidperfil = @idPerfil
							AND tpidtarifa = tcidtarifa
							AND tpidplanopcion = tcidplanopcion
		WHERE  tpidestatus = 1

		--ALTER TABLE #tmpplanesflexibles ADD plAyuda VARCHAR(MAX) NULL;

		UPDATE tmp
		SET    tmp.archivoplan = '..\DocumentoEmpresa\'
									+ CAST(@idempresa AS VARCHAR(20)) + '\'
									+ docarpeta + '\' + dodocumento
		FROM   #tmpplanesflexibles TMP
				INNER JOIN ff_plan PL WITH (NOLOCK, READUNCOMMITTED)
						ON TMP.poidplan = PL.plidplan
				INNER JOIN ff_documentos D WITH (NOLOCK, READUNCOMMITTED)
						ON PL.plidarchivoinformacion = D.doid

		UPDATE tmp
		SET    tmp.plAyuda=pl.PLAYUDA
		FROM   #tmpplanesflexibles TMP
				INNER JOIN ff_plan PL WITH (NOLOCK, READUNCOMMITTED)
						ON TMP.poidplan = PL.plidplan

		UPDATE tmp
		SET    tcprimaneta = tcrtarifatotal,
				tcprimatotal = tcrtarifatotal
		FROM   #empleado e
				INNER JOIN #empleado ee WITH (NOLOCK, READUNCOMMITTED)
						ON e.emnumeroempleado = ee.emnumeroempleado
							AND ee.emidparentesco = 1
				INNER JOIN #tmpplanesflexibles TMP WITH (NOLOCK, READUNCOMMITTED)
						ON e.id = TMP.id
				INNER JOIN bf_tarifacostorango tr WITH (NOLOCK, READUNCOMMITTED)
						ON TMP.poidplanopcion = tr.tcridplanopcion
							AND tcidsexo = ISNULL(tcridsexo, e.emidsexo)
							AND ISNULL(TMP.tcidparentesco, TMP.tcidgrupoparentesco) =
								ISNULL(tcridparentesco, tcridgrupoparentesco)
		WHERE  ee.emsalariobase BETWEEN tcrrangovalorinicial
			AND tcrrangovalorfinal
			AND tr.tcridestatus = 1
			AND ISNULL(tcridperfil, @idPerfil) = @idPerfil

		UPDATE tmp
		SET    tcprimaneta = e.emsalariobase * tcrtarifatotal,
				tcprimatotal = e.emsalariobase * tcrtarifatotal
		FROM   #tmpplanesflexibles TMP
				INNER JOIN bf_tarifacostorango tr WITH (NOLOCK, READUNCOMMITTED)
						ON TMP.poidplanopcion = tr.tcridplanopcion
				INNER JOIN ff_empleado e WITH (READUNCOMMITTED)
						ON TMP.id = e.id
		WHERE  tr.tcridestatus = 1
				AND tcridcampo = 35
				AND dbo.Regresaedad(emfechaingresoempresa,
															(
															SELECT CASE WHEN Getdate() > @VigenciaInicio
																THEN Getdate()
																ELSE @VigenciaInicio
																END
															)
									) BETWEEN tcrrangovalorinicial AND tcrrangovalorfinal
				AND tr.tcridsexo IS NULL
				AND ISNULL(tmp.tcidparentesco, tmp.tcidgrupoparentesco) =
					ISNULL(tcridparentesco, tcridgrupoparentesco)
				AND ISNULL(tcridperfil, @idPerfil) = @idPerfil

		--Recuperar tope
		CREATE TABLE #datosCotizadorPlanTopes(
			topeIdPlanOpcion int,
			topePrimaTotal money,
			topePrimaNeta money,
			topeIdPlan int
		);
		IF((select count(*) from bf_PlanCotizador where PCNumeroEmpleado = @NUMEROEMPLEADO and PCIdEmpresa = @idempresa
		and POIdPlan in (select PPidPlan from ff_PlanesParametros where PPidEmpresa = @idempresa)) > 0)
			BEGIN
			declare @indexPPlan int;

			select @indexPPlan = (select count(*)  from dbo.bf_plancotizador  WITH (NOLOCK) where poNombre like '%TOPE%' and PCNumeroEmpleado = @NUMEROEMPLEADO
				and PCIdEmpresa = @idempresa and poIdPlan in (select PPidPlan from ff_PlanesParametros where PPidEmpresa = @idempresa))

			INSERT INTO #datosCotizadorPlanTopes
			select poIdPlanOpcion as topeIdPlanOpcion, tcPrimaTotal as topePrimaTotal, tcPrimaNeta as topePrimaNeta, POIdPlan as topeIdPlan from dbo.bf_plancotizador  WITH (NOLOCK)
			where poNombre like '%TOPE%' and PCNumeroEmpleado = @NUMEROEMPLEADO and PCIdEmpresa = @idempresa and poIdPlan in (select PPidPlan from ff_PlanesParametros where PPidEmpresa = @idempresa)

			WHILE @indexPPlan > 0
				BEGIN
					select top 1 @topeIdPlanOpcion = topeIdPlanOpcion,
						@topePrimaTotal = topePrimaTotal,
						@topePrimaNeta = topePrimaNeta,
						@topeIdPlan = topeIdPlan  from #datosCotizadorPlanTopes


						update #tmpplanesflexibles set tcPrimaTotal = @topePrimaTotal, tcPrimaNeta = @topePrimaNeta
							where poIdPlanOpcion = @topeIdPlanOpcion
							and poIdPlan = @topeIdPlan

						update #tmpplanesflexibles set Checked='false', Visible='false', Enabled='false'
							where POIdPlan = @topeIdPlan
							and tcprimatotal >= @topePrimaTotal
							and poIdPlanOpcion != @topeIdPlanOpcion


					--print '--- Ciclo ---'
					DELETE TOP (1) FROM #datosCotizadorPlanTopes
					set @indexPPlan = @indexPPlan - 1;
				END;
			END

		/********************************************************************/
		/********** EVALUA LOS PLANES QUE NO DEBEN DE SER VISIBLES***********/
		/********************************************************************/
		UPDATE #tmpplanesflexibles
		SET    visible = 'FALSE'
		FROM   #tmpplanesflexibles tmp
			   INNER JOIN dbo.ff_plan pl WITH (NOLOCK, READUNCOMMITTED)
					   ON tmp.poidplan = pl.plidplan
		WHERE  plvisible = '0'

		/********************************************************************/
		/********** EVALUA LOS PLANES QUE NO DEBEN DE SER VISIBLES***********/
		/********************************************************************/
		/**************************************************
		**********************PROCESO DE DAFAULTEO
		**************************************************/
		PRINT 'PROCESO DE DAFAULTEO'

		SELECT @Temporales = Count(tcidtarifacosto)
		FROM   #tmpplanesseleccionados
		WHERE  tcidtarifacosto = -1

		SELECT *
		FROM   #tmpplanesseleccionados
		WHERE  tcidtarifacosto = -1

        print '**********************PROCESO DEFAULTEO ****************************************0'
		print @Temporales

		IF @Temporales = 1
		  BEGIN
			  EXEC dbo.Ff_cbuscaplanespejoTestMultivigenciaBF3

				@numeroempleado,
				@idEmpleado,
				@idEmpresa,
				@idPerfil,
				@GpoTitular,
				@NUCLEOFAMILIAR,
				@transfer,
				@idVigenciaD,
				@idVigenciaDestino

			  UPDATE tmp
			  SET    tmp.tcprimatotal = TC.tcprimatotal
			  FROM   #tmpplanesflexibles TMP
					 INNER JOIN ff_TarifaCosto_hist TC WITH (NOLOCK, READUNCOMMITTED)
							 ON TMP.tcidtarifacosto = TC.tcidtarifacosto
			  WHERE  tmp.tcprimatotal = 0
					 AND tmp.tcprimaneta > 0
					 AND checked = 'true'
		  /*********************  EVALUA LOS CANDADOS  ****************************/

			  EXECUTE dbo.Ff_cevaluacandados @idEmpleado, @idEmpresa, @NumeroEmpleado

		  /************************************ NEW*********************************/
		  END
		ELSE
		  BEGIN
			  EXEC dbo.Ff_cbuscaplanselecciones
				@numeroempleado,
				@idEmpleado,
				@idEmpresa,
				@GpoTitular,
				@NUCLEOFAMILIAR
		  END

		IF @IdEmpleado = 151044
		BEGIN
			print 'entro a hacer visible planes'
			UPDATE #tmpplanesflexibles
			SET visible ='false'
			WHERE poidplan=1174

			UPDATE #tmpplanesflexibles
			SET visible ='true'
			WHERE poidplan=460
		END
		ELSE IF @IdEmpresa =174
		BEGIN
			UPDATE #tmpplanesflexibles
			SET visible ='false'
			WHERE poidplan=460
		END

		IF @Idempresa=173 AND @numeroempleado='1'
		BEGIN
			UPDATE #tmpplanesflexibles
			SET tcprimaneta=18875.74, tcprimatotal=18875.74
			WHERE id= 154589
				AND tcidplanopcion = 3871

			UPDATE #tmpplanesflexibles
			SET tcprimaneta = 23455.2, tcprimatotal= 23455.2
			WHERE id=154590
				AND tcidplanopcion = 3871

			UPDATE #tmpplanesflexibles
			SET tcprimaneta= 18701.8,
			tcprimatotal= 18701.8
			WHERE id= 489692 AND tcidplanopcion = 3871
		END


		/********************************************************************/
		/********** EVALUA LOS PLANES QUE NO DEBEN DE SER VISIBLES***********/
		/********************************************************************/
		UPDATE #tmpPlanesFlexibles
		SET checked = 'FALSE'
		WHERE Visible = 'false'
		/********************************************************************/
		/******************* EVALUA GP HIJOS ********************************/
		/********************************************************************/
		UPDATE #tmpplanesflexibles
		SET    checked = 'false'
		FROM   #tmpplanesflexibles pf WITH (NOLOCK, READUNCOMMITTED)
			INNER JOIN #tmpplanesseleccionados tmp2 WITH (NOLOCK, READUNCOMMITTED)
				ON pf.id = tmp2.idempleado
				AND tmp2.nuevo = 'N'
			INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
				ON pf.poidplanopcion = po.poidplanopcion
			INNER JOIN dbo.ff_planrelacion pr WITH (NOLOCK, READUNCOMMITTED)
				ON po.poidplan = pr.pridplan
		WHERE  checked = 'true'
			AND pf.tcidtarifacosto IN (
										SELECT tmp1.tcidtarifacosto
										FROM   #tmpplanesseleccionados tmp1
											INNER JOIN dbo.ff_TarifaCosto_hist tc1 WITH (NOLOCK, READUNCOMMITTED)
												ON tmp1.tcidtarifacosto = tc1.tcidtarifacosto
													AND tc1.tcidtarifa = @IdTarifa
													AND tc1.tcidestatus = 2
											INNER JOIN dbo.ff_planopcion po1 WITH (NOLOCK, READUNCOMMITTED)
												ON tc1.tcidplanopcion = po1.poidplanopcion
											INNER JOIN dbo.ff_planrelacion pr1 WITH(NOLOCK, READUNCOMMITTED)
												ON po1.poidplan = pr1.pridplan
										WHERE  pf.id = tmp1.idempleado
											AND pr1.prverificador = '1'
											AND pr1.pridplanrelacion =
												pr.pridplanrelacion
											AND nuevo IS NULL
										)
			AND pr.prverificador = '1'
			AND (
					SELECT Count(idempleado)
					FROM   #tmpplanesseleccionados tmp2
					WHERE  tmp2.nuevo = 'N'
				) = 1
		OPTION (keep PLAN)

		/********************************************************************/
		/******************* QUE NO SE REPITAN ENTRE PLANES ********************************/
		/********************************************************************/

		UPDATE #tmpplanesflexibles
		SET    checked = 'false'
		FROM   #tmpplanesflexibles pf
			   INNER JOIN #tmpplanesseleccionados tmp2 WITH (NOLOCK, READUNCOMMITTED)
					   ON pf.id = tmp2.idempleado
			   INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
					   ON pf.poidplanopcion = po.poidplanopcion
			   INNER JOIN dbo.ff_planrelacion pr WITH (NOLOCK, READUNCOMMITTED)
					   ON po.poidplan = pr.pridplan
		WHERE  tmp2.nuevo = 'N'
			   AND pr.prverificador = '2'
			   AND pf.poidplan IN (SELECT poidplan
								   FROM   #tmpplanesflexibles psel
										INNER JOIN #tmpplanesseleccionados sel
											ON psel.tcidtarifacosto = sel.tcidtarifacosto
											AND sel.nuevo = 'N'
								  )
			   AND pr.pridestatus = 1
			   AND pf.checked = 'true'
			   AND (
						SELECT Count(tmp2.idempleado)
						FROM   #tmpplanesseleccionados tmp2
						WHERE  tmp2.nuevo = 'N'
					) = 1
			   AND pr.prverificador = '2'
			   AND pf.tcidtarifacosto IN (
											SELECT tmp1.tcidtarifacosto
											FROM   dbo.ff_planrelacion pr1 WITH (NOLOCK,READUNCOMMITTED)
												INNER JOIN dbo.ff_planopcion po1 WITH (NOLOCK, READUNCOMMITTED)
													ON pr1.pridplan = po1.poidplan
												INNER JOIN dbo.ff_TarifaCosto_hist tc1 WITH(NOLOCK,READUNCOMMITTED)
													ON po1.poidplanopcion = tc1.tcidplanopcion
													AND tc1.tcidtarifa = @IdTarifa
													AND tc1.tcidestatus = 2
												INNER JOIN #tmpplanesseleccionados tmp1
													ON tc1.tcidtarifacosto = tmp1.tcidtarifacosto
											WHERE pr1.pridplanrelacion = pr.pridplanrelacion
											   AND pr1.prverificador = '2'
											   AND pr1.pridestatus = 1
											   AND tmp1.idempleado = pf.id
											   AND nuevo IS NULL
										)
			OPTION (KEEP PLAN)


		/*******ACTUALIZA TARIFAS MENSUALES FIJAS **************************/

		UPDATE #tmpplanesflexibles
		SET    tcprimatotal = tcprimaneta * po.pomeses
		FROM   #tmpplanesflexibles pf
			   INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
					ON pf.poidplanopcion = po.poidplanopcion
		WHERE  po.poidtipocosto = 3

		UPDATE #tmpplanesflexibles
		SET    tcprimatotal = e.embeneficiootorgadom
		FROM   #tmpplanesflexibles pf
			   INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
					ON pf.poidplanopcion = po.poidplanopcion
			   INNER JOIN ff_empleado e WITH (NOLOCK, READUNCOMMITTED)
					ON pf.id = e.id
		WHERE  pf.emidparentesco = 1
			   AND po.poidtipocosto = 4
			   AND e.emidparentesco = 1

		UPDATE #tmpplanesflexibles
		SET    tcprimatotal = CASE
								WHEN ISNULL(e.emfechaalta, Getdate()) < vivigenciaini
							  THEN
								tcprimatotal
								ELSE ( tcprimatotal / 365 ) *
			   Datediff(dd, ISNULL(e.emfechaalta, Getdate()), vivigenciafin)
			   END
		FROM   #tmpplanesflexibles pf
			   INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
					ON pf.poidplanopcion = po.poidplanopcion
			   INNER JOIN ff_vigencia
					ON viidvigencia = @idVigencia
			   INNER JOIN ff_empleado e WITH (NOLOCK, READUNCOMMITTED)
					ON pf.id = e.id
		WHERE  po.poidtipocosto = 5

		-- ###########################################################################################################

		DECLARE @tmpPlanesFlexibles AS TABLE
		(
			id INTEGER NULL,
			emapellidomaterno VARCHAR (50) NULL,
			emapellidopaterno VARCHAR(50) NULL,
			emnombre1 VARCHAR(50) NULL,
			emnombre2 VARCHAR(50) NULL,
			emidparentesco INTEGER NULL,
			tcidtarifacosto INTEGER NULL,
			tcidtarifa INTEGER NULL,
			tcidplanopcion INTEGER NULL,
			tcidtipotarifa INTEGER NULL,
			tcidgrupoparentesco INTEGER NULL,
			tcidparentesco INTEGER NULL,
			tcidsexo INTEGER NULL,
			tcedad INTEGER NULL,
			tcidtipofumador INTEGER NULL,
			tcprimaneta MONEY NULL,
			tcprimatotal MONEY NULL,
			poidplanopcion INTEGER NULL,
			poidplan INTEGER NULL,
			ponombre VARCHAR(50) NULL,
			podescripcion VARCHAR(150) NULL,
			pocaptura CHAR(1) NULL,
			plnombre VARCHAR(50) NULL,
			pldescripcion VARCHAR(150),
			plidramo INTEGER NULL,
			plcoberturaforzosatitular VARCHAR(1),
			ranombre VARCHAR(50) NULL,
			radescripcion VARCHAR(150) NULL,
			parentescosdescripcion VARCHAR(150) NULL,
			idparentesco INTEGER NULL,
			padescripcion VARCHAR(150) NULL,
			checked VARCHAR(10) NULL,
			visible VARCHAR(10) NULL,
			enabled VARCHAR(10) NULL,
			htmlcontrol VARCHAR(500) NULL,
			cantidad INTEGER NULL,
			archivo VARCHAR(200) NULL,
			raimg VARCHAR(200) NULL,
			plimg VARCHAR(200) NULL,
			poimg VARCHAR(200) NULL,
			raorden INT NULL,
			plorden INT NULL,
			poorden INT NULL,
			archivoplan VARCHAR(200) NULL,
			plAyuda varchar(MAX) NULL
		)

		DECLARE @Contador SMALLINT,
			@i SMALLINT,
			@GrupoParentesco VARCHAR(50)

		SET @Contador = 0
		SET @i = 1
		SET @GrupoParentesco=''

		INSERT INTO @tmpPlanesFlexibles
		SELECT * FROM #tmpplanesflexibles

		/*****************************************************************************/
		/* ACTUALIZA TARIFAS DE PLANES EN CASO DE CAMBIOS CALIFICADOS           */
		/*****************************************************************************/

		DECLARE @PagosTotal INT,
			@PagosHechos INT

		SELECT @PagosTotal = count(vcidvigenciacalendariopago)
		FROM dbo.ff_vigenciacalendariopago WITH (NOLOCK,READUNCOMMITTED)
		INNER JOIN dbo.ff_perfil  WITH (NOLOCK, READUNCOMMITTED)
			ON vcidperiodicidadpago = peidperiodicidadnomina
		WHERE vcidvigencia= @idvigencia
			AND peidperfil = @idPerfil OPTION (keep plan)

		SELECT @PagosHechos = count(vcidvigenciacalendariopago)
		FROM dbo.ff_vigenciacalendariopago WITH (NOLOCK)
		INNER JOIN dbo.ff_perfil  WITH (NOLOCK, READUNCOMMITTED)
			ON vcidperiodicidadpago = peidperiodicidadnomina
		WHERE vcidvigencia= @idvigencia
			AND peidperfil = @idPerfil AND vcfechapago <= getdate()

		OPTION (keep plan)

		/*********************************************************************/
		/* ACTUALIZA EL VALOR DE Valida SAMI PARA PLANES DE VIDA        */
		/*********************************************************************/

		INSERT INTO #primascompuestas
		SELECT vsidempleado,
			   po.poidplanopcion,
			   Sum(vsprimaanual) AS PrimaTotal
		FROM   dbo.ff_planopcioncompuesto  WITH (NOLOCK, READUNCOMMITTED)
			   INNER JOIN dbo.ff_planopcion po  WITH (NOLOCK, READUNCOMMITTED)
					   ON pcidplanopcion = poidplanopcion
			   INNER JOIN dbo.ff_validasavida  WITH (NOLOCK, READUNCOMMITTED)
					   ON pcidplanopcionintegrante = vsidplanopcion
			   INNER JOIN @tmpPlanesFlexibles
					   ON vsidempleado = id
						  AND tcidplanopcion = po.poidplanopcion
		WHERE  pocoberturacompuesta = '1'
			   AND vsidestatus = 1
		GROUP  BY vsidempleado,
				  po.poidplanopcion
		OPTION (keep PLAN)

		INSERT INTO #primascompuestas
		SELECT tmpPlanesFlexibles1.id,
			   po.poidplanopcion,
			   Sum(tmpPlanesFlexibles.tcprimatotal) AS PrimaTotal
		FROM   dbo.ff_planopcioncompuesto WITH (NOLOCK, READUNCOMMITTED)
			   INNER JOIN dbo.ff_planopcion po  WITH (NOLOCK, READUNCOMMITTED)
					   ON pcidplanopcion = poidplanopcion
			   INNER JOIN @tmpPlanesFlexibles AS tmpPlanesFlexibles1
					   ON pcidplanopcion = tmpPlanesFlexibles1.poidplanopcion
			   INNER JOIN @tmpPlanesFlexibles AS tmpPlanesFlexibles
					   ON pcidplanopcionintegrante = tmpPlanesFlexibles.poidplanopcion
						  AND tmpPlanesFlexibles1.id = tmpPlanesFlexibles.id
		WHERE  po.pocoberturacompuesta = '1'
			   AND po.poidtiposumaasegurada = 0
			   AND po.poidestatus = 1
		GROUP  BY tmpPlanesFlexibles1.id,
				  po.poidplanopcion
		OPTION (keep PLAN)

		UPDATE #tmpplanesflexibles
		SET    tcprimatotal = pc.primatotal
		FROM   #tmpplanesflexibles tmp
			   INNER JOIN #primascompuestas pc WITH (NOLOCK, READUNCOMMITTED)
					   ON tmp.poidplanopcion = pc.poidplanopcion
						  AND tmp.id = pc.vsidempleado
		OPTION (keep PLAN)


		/***********************************************/
		/* Valida SAMI PARA PLANES DE VIDA        */
		/***********************************************/

		INSERT INTO #saempleado
		SELECT DISTINCT vsidempleado,
						pcidplanopcionintegrante,
						vssumaasegurada
		FROM   dbo.ff_planopcioncompuesto POC  WITH (NOLOCK, READUNCOMMITTED)
			   INNER JOIN dbo.ff_planopcion PO  WITH (NOLOCK, READUNCOMMITTED)
					   ON pcidplanopcion = PO.poidplanopcion
			   INNER JOIN #tmpplanesflexibles tmp
					   ON po.poidplanopcion = tmp.poidplanopcion
			   INNER JOIN dbo.ff_validasavida  WITH (NOLOCK, READUNCOMMITTED)
					   ON pcidplanopcionintegrante = vsidplanopcion
						  AND tmp.id = vsidempleado
		WHERE  po.pocoberturacompuesta = '1'
			   AND tmp.checked = 'true'
			   AND vsidestatus = 1
		UNION ALL
		SELECT DISTINCT vsidempleado,
						vsa.vsidplanopcion,
						vssumaasegurada
		--CALCULA SUMA ASEGURADA DE LAS COBERTURAS SELECCIONADAS
		FROM   dbo.ff_planopcioncompuesto POC  WITH (NOLOCK, READUNCOMMITTED)
			   INNER JOIN dbo.ff_planopcion PO  WITH (NOLOCK, READUNCOMMITTED)
					   ON pcidplanopcion = PO.poidplanopcion
			   INNER JOIN dbo.ff_plan pl  WITH (NOLOCK, READUNCOMMITTED)
					   ON PO.poidplan = pl.plidplan
			   INNER JOIN #tmpplanesflexibles tmp WITH (NOLOCK, READUNCOMMITTED)
					   ON po.poidplanopcion = tmp.poidplanopcion
			   INNER JOIN dbo.ff_validasavida vsa  WITH (NOLOCK, READUNCOMMITTED)
					   ON PO.poidplanopcion = vsidplanopcion
						  AND tmp.id = vsidempleado
		WHERE  po.pocoberturacompuesta = '0'
			   AND tmp.checked = 'true'
			   AND vsidestatus = 1
		OPTION (keep PLAN)

		/************************************************************************/
		/************ TRUNCA EL COSTO DEL PLAN CON LA SAMI **********************/
		/************************************************************************/

		DROP TABLE #PrimasCompuestas

		/************************************************************************/
		/************ MODIFICA COSTO POR PLAN SELECCIÃ“N **********************/
		/************************************************************************/
		SELECT DISTINCT paidparentesco,
						p.panombre
		INTO   #tmpplanescostoseleccion
		FROM   #tmpplanesflexibles tmp
			   INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
					   ON tmp.poidplanopcion = PO.poidplanopcion
			   INNER JOIN ff_parentesco p WITH (NOLOCK, READUNCOMMITTED)
					   ON p.paidparentesco = tmp.idparentesco
		WHERE  poidestatus = 1
			   AND tmp.checked = 'true'
			   AND poidtipocosto = 7

		SET @Contador = ISNULL((SELECT MAX(paidparentesco)
								FROM   #tmpplanescostoseleccion), 0)

		IF @Contador > 0
		  BEGIN
			  WHILE @i <= @Contador
				BEGIN
					SET @GrupoParentesco = @GrupoParentesco
						+ ISNULL(
								(
									SELECT Rtrim(panombre)
									FROM #tmpplanescostoseleccion
									WHERE paidparentesco = @i
								),'')
					SET @i = @i + 1
				END

			  IF @GrupoParentesco <> ''
				BEGIN
					UPDATE tmp
					SET    tcprimatotal = t.tcprimatotal,
						   tcprimaneta = t.tcprimatotal
					FROM   #tmpplanesflexibles tmp
						   INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED
									  )
								   ON tmp.poidplanopcion = PO.poidplanopcion
									  AND PO.poidtipocosto = 7
						   INNER JOIN ff_grupoparentesco gp WITH (NOLOCK,
									  READUNCOMMITTED)
								   ON gp.gpnombre = @GrupoParentesco
						   INNER JOIN ff_TarifaCosto_hist t WITH (NOLOCK, READUNCOMMITTED)
								   ON t.tcidtarifa = tmp.tcidtarifa
									  AND t.tcidplanopcion = tmp.poidplanopcion
									  AND t.tcidtipotarifa = 2
									  AND t.tcidgrupoparentesco = gp.gpidgrupoparentesco
					WHERE  poidtipocosto = 7
						   AND tmp.tcidparentesco = 1
				END
		  END

		-- ##########################################################################################################################################
		/********************************************************************/
		/********************CALCULA CREDITOS********************************/
		/********************************************************************/
		--creditos plan basico

		DECLARE @Creditos MONEY
		DECLARE @Creditos1 MONEY SET @Creditos1 = 0.00
		DECLARE @Creditos2 MONEY SET @Creditos2 = 0.00
		DECLARE @Creditos3 MONEY SET @Creditos3 = 0.00
		DECLARE @CreditosOtorgados AS TABLE
			(
				idcompensacion INT NULL,
				cantidad MONEY NULL )

		delete @tmpPlanesFlexibles

		INSERT INTO @tmpPlanesFlexibles SELECT * FROM #tmpPlanesFlexibles
		INSERT INTO @CreditosOtorgados SELECT * FROM #creditosotorgados

		INSERT INTO @CreditosOtorgados
			SELECT DISTINCT pbidcompensacion,
				sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL
					THEN pbcantidad
					WHEN pbcantidad = 0 OR pbcantidad IS NULL
					THEN (pbporcentaje/100.00)* tcprimatotal end
					)/cantidad
			FROM dbo.ff_planbasico pb WITH (NOLOCK, READUNCOMMITTED)
			LEFT OUTER JOIN dbo.ff_planbasicodetalle pbd WITH (NOLOCK, READUNCOMMITTED)
				ON pb.pbidplanbasico = pbd.pbidplanbasico
			INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
				ON pb.pbidplanopcion = po.poidplanopcion
			INNER JOIN @tmpPlanesFlexibles
				ON pbidplanopcion =	tcidplanopcion
			INNER JOIN dbo.ff_tarifa trf WITH (NOLOCK, READUNCOMMITTED)
				ON tcidtarifa = trf.taidtarifa
			WHERE pbidperfil = @idPerfil
				AND pb.pbidestatus = 1
				AND pbformacredito = '1'
				AND pbd.pbidestatus = 1
				AND po.poautorizacion = 0
				AND tcidtarifacosto IN
									(
										SELECT DISTINCT tmp.tcidtarifacosto
										FROM @tmpPlanesFlexibles tmp
										WHERE tmp.poidplanopcion = pbidplanopcion
											AND tmp.idparentesco = ISNULL(pbidparentesco, pbidgrupoparentesco)
									)
				AND trf.taidvigencia = @idvigencia
				AND tcidparentesco = pbidparentesco
			GROUP BY pbidcompensacion, tcprimatotal,pbporcentaje, cantidad
			OPTION (keep plan)

		INSERT INTO @CreditosOtorgados
		SELECT DISTINCT pbidcompensacion,
			sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL
				THEN pbcantidad
				WHEN pbcantidad = 0 OR pbcantidad IS NULL
				THEN (pbporcentaje/100.00)* tcprimatotal end) /cantidad
		FROM dbo.ff_planbasico pb WITH (NOLOCK, READUNCOMMITTED)
		LEFT OUTER JOIN dbo.ff_planbasicodetalle pbd WITH (NOLOCK, READUNCOMMITTED)
			ON pb.pbidplanbasico = pbd.pbidplanbasico
		INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
			ON pb.pbidplanopcion = po.poidplanopcion
		INNER JOIN @tmpPlanesFlexibles
			ON pbidplanopcion = tcidplanopcion
			AND tcidgrupoparentesco = pbidgrupoparentesco
		INNER JOIN dbo.ff_tarifa trf WITH (NOLOCK, READUNCOMMITTED)
			ON tcidtarifa = trf.taidtarifa
		WHERE pbidperfil = @idPerfil
			AND pb.pbidestatus = 1
			AND pbidgrupoparentesco IN (
										SELECT DISTINCT tmp.tcidgrupoparentesco
										FROM @tmpPlanesFlexibles tmp
										WHERE tmp.poidplan = po.poidplan
											AND checked = 'TRUE'
										)
			AND pbformacredito = '0'
			AND pbd.pbidestatus = 1
			AND po.poautorizacion = 0
			AND trf.taidvigencia = @idvigencia
		GROUP BY pbidcompensacion, tcprimatotal, pbporcentaje, cantidad
		OPTION (keep plan)

		INSERT INTO @CreditosOtorgados
		SELECT DISTINCT pbidcompensacion,
			Sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
				 WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN  ( pbporcentaje / 100.00 ) * tcprimatotal
				END) / cantidad
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
			   LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanbasico = PBD.pbidplanbasico
			   INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanopcion = PO.poidplanopcion
			   INNER JOIN @tmpPlanesFlexibles
					ON pbidplanopcion = tcidplanopcion
					AND tcidgrupoparentesco = pbidgrupoparentesco
			   INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
					ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
			AND PB.pbidestatus = 1
			AND pbformacredito = '2'
			AND pbidgrupoparentesco IN (SELECT DISTINCT TMP.tcidgrupoparentesco
										FROM   @tmpPlanesFlexibles TMP
										WHERE  TMP.poidplan = PO.poidplan)
			AND PBD.pbidestatus = 1
			AND PO.poautorizacion = 0
			AND TRF.taidvigencia = @idvigencia
		GROUP  BY pbidcompensacion, tcprimatotal, pbporcentaje, cantidad
		OPTION (keep PLAN)

		-- El grupo parentesco mÃ¡ximo
		INSERT INTO @CreditosOtorgados
		SELECT DISTINCT pbidcompensacion,
			Sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
					WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN ( pbporcentaje / 100.00 ) * tcprimatotal
				END) / cantidad
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
			   LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanbasico = PBD.pbidplanbasico
			   INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanopcion = PO.poidplanopcion
			   INNER JOIN @tmpPlanesFlexibles
					ON pbidplanopcion = tcidplanopcion
					AND tcidgrupoparentesco = pbidgrupoparentesco
			   INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
					ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
			AND PB.pbidestatus = 1
			AND pbformacredito = '3'
			AND pbidgrupoparentesco IN (SELECT TOP 1 TMP.tcidgrupoparentesco
										FROM @tmpPlanesFlexibles TMP
										INNER JOIN ff_grupoparentesco
											ON TMP.tcidgrupoparentesco = gpidgrupoparentesco
										WHERE  TMP.poidplan = PO.poidplan
										ORDER  BY gpcantidad DESC)
			AND PBD.pbidestatus = 1
			AND PO.poautorizacion = 0
			AND TRF.taidvigencia = @idvigencia
		GROUP  BY pbidcompensacion, tcprimatotal, pbporcentaje, cantidad
		OPTION (keep PLAN)

		-- CompensaciÃ³n Vacaciones MOD BAT 04/12/2009

		INSERT INTO @CreditosOtorgados
		SELECT DISTINCT pbidcompensacion,
			Sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
				WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN ( pbporcentaje / 100.00 ) * tcprimatotal
				END) / cantidad
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
			   LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanbasico = PBD.pbidplanbasico
			   INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplan = PO.poidplan
			   INNER JOIN @tmpPlanesFlexibles
					ON PO.poidplanopcion = tcidplanopcion
					AND tcidparentesco = pbidparentesco
					AND checked = 'TRUE'
			   INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
					ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
			   AND PB.pbidestatus = 1
			   AND pbformacredito = '4'
			   AND PBD.pbidestatus = 1
			   AND PO.poautorizacion = 0
			   AND TRF.taidvigencia = @idvigencia
			   AND tcidtarifacosto IN (SELECT DISTINCT TMP.tcidtarifacosto
									   FROM   @tmpPlanesFlexibles TMP
									   WHERE  TMP.poidplan = PO.poidplan
											  AND TMP.idparentesco = ISNULL(pbidparentesco, pbidgrupoparentesco)
											  AND checked = 'TRUE')
		GROUP  BY pbidcompensacion, tcprimatotal, pbporcentaje, cantidad
		OPTION (keep PLAN)

		UPDATE #tmpplanesflexibles
		SET    tcprimatotal = 0
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
			   LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanbasico = PBD.pbidplanbasico
			   INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplan = PO.poidplan
			   INNER JOIN #tmpplanesflexibles
					ON PO.poidplanopcion = tcidplanopcion
					AND tcidparentesco = pbidparentesco
					AND checked = 'TRUE'
			   INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
					ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
			   AND PB.pbidestatus = 1
			   AND pbformacredito = '4'
			   AND PO.poautorizacion = 0
			   AND TRF.taidvigencia = @idvigencia
			   AND tcidtarifacosto IN (SELECT DISTINCT TMP.tcidtarifacosto
									   FROM   #tmpplanesflexibles TMP
									   WHERE  TMP.poidplan = PO.poidplan
											  AND TMP.idparentesco = ISNULL(
												  pbidparentesco, pbidgrupoparentesco)
											  AND checked = 'TRUE')
			   AND PBD.pbidestatus = 1

		DELETE @tmpPlanesFlexibles

		INSERT INTO @tmpPlanesFlexibles
		SELECT *
		FROM   #tmpplanesflexibles

		INSERT INTO @CreditosOtorgados
		SELECT DISTINCT pbidcompensacion,
			Sum(CASE
			WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
			WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN( pbporcentaje / 100.00 ) * tcprimatotal
			END) / cantidad
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
			   LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanbasico = PBD.pbidplanbasico
			   INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanopcion = PO.poidplanopcion
			   INNER JOIN @tmpPlanesFlexibles
					ON PO.poidplanopcion = tcidplanopcion
					AND tcidparentesco = pbidparentesco
					AND checked = 'TRUE'
			   INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
					ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
			   AND PB.pbidestatus = 1
			   AND pbformacredito = '5'
			   AND PBD.pbidestatus = 1
			   AND PO.poautorizacion = 0
			   AND tcidtarifacosto IN (SELECT DISTINCT TMP.tcidtarifacosto
									   FROM   @tmpPlanesFlexibles TMP
									   WHERE  TMP.poidplan = PO.poidplan
											  AND TMP.idparentesco = ISNULL(pbidparentesco, pbidgrupoparentesco)
											  AND checked = 'TRUE')
			   AND TRF.taidvigencia = @idvigencia
		GROUP  BY pbidcompensacion, tcprimatotal, pbporcentaje, cantidad
		OPTION (keep PLAN)

		INSERT INTO @CreditosOtorgados
		SELECT DISTINCT pbidcompensacion,
			Sum(CASE
			WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
			WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN ( pbporcentaje / 100.00 ) * tcprimatotal
			END) / cantidad
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
			   LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplanbasico = PBD.pbidplanbasico
			   INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
					ON PB.pbidplan = PO.poidplan
			   INNER JOIN @tmpPlanesFlexibles
					ON PO.poidplanopcion = tcidplanopcion
					AND tcidparentesco = pbidparentesco
					AND checked = 'TRUE'
			   INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
					ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
			   AND PB.pbidestatus = 1
			   AND pbformacredito = '6'
			   AND PO.poautorizacion = 0
			   AND PBD.pbidestatus = 1
			   AND tcidtarifacosto IN (SELECT DISTINCT TMP.tcidtarifacosto
									   FROM   @tmpPlanesFlexibles TMP
									   WHERE  TMP.poidplan = PO.poidplan
											  AND TMP.idparentesco = ISNULL(pbidparentesco, pbidgrupoparentesco)
											  AND checked = 'TRUE')
			   AND TRF.taidvigencia = @idvigencia
		GROUP  BY pbidcompensacion, tcprimatotal, pbporcentaje, cantidad
		OPTION (keep PLAN)


		--CrÃ©ditos compensaciones TOTALES
		INSERT INTO @CreditosOtorgados
		SELECT coidcompensacion,
			   ISNULL(Sum(cetotalcreditos), 0.00)
		FROM   dbo.ff_compensacion WITH (NOLOCK, READUNCOMMITTED)
			INNER JOIN dbo.ff_compensacionconfiguracion WITH (NOLOCK, READUNCOMMITTED)
				ON coidcompensacion = ccidcompensacion
			INNER JOIN dbo.ff_compensacionempleado WITH (NOLOCK, READUNCOMMITTED)
				ON coidcompensacion = ceidcompensacion
		WHERE  coidestatus = 1
			   AND ccidperfil = @idPerfil
			   AND ccexcedente = '0'
			   AND ceidempleado = @idEmpleado
		GROUP  BY coidcompensacion
		OPTION (keep PLAN)

		INSERT INTO @CreditosOtorgados
		SELECT DISTINCT pbidcompensacion,
			Sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
			WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN( pbporcentaje / 100.00 ) * tcprimatotal
			END) / cantidad
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
			LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
				ON PB.pbidplanbasico = PBD.pbidplanbasico
			INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
				ON PB.pbidplanopcion = PO.poidplanopcion
			INNER JOIN @tmpPlanesFlexibles
				ON PO.poidplanopcion = tcidplanopcion
				AND tcidparentesco = pbidparentesco
			INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
				ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
			   AND PB.pbidestatus = 1
			   AND pbformacredito = '7'
			   AND PBD.pbidestatus = 1
			   AND PO.poautorizacion = 0
			   AND id IN (SELECT DISTINCT TMP.id
						  FROM   @tmpPlanesFlexibles TMP
						  WHERE  TMP.poidplan = PO.poidplan
								 AND checked = 'TRUE')
			   AND TRF.taidvigencia = @idvigencia
		GROUP  BY pbidcompensacion,
				  tcprimatotal,
				  pbporcentaje,
				  cantidad
		OPTION (keep PLAN)

		--
		IF @idEmpresa = 288
		BEGIN
			DECLARE @EmFechaIngreso datetime, @valor MONEY, @VIP INT, @Porcentaje MONEY SET @valor=0

			SELECT @emfechaingreso = emfechaingresoempresa ,
					@vip = emvip
			FROM  ff_empleado with(READUNCOMMITTED)
			WHERE  id = @idEmpleado

			SELECT @valor= round(ISNULL((datediff(dd, @EmFechaIngreso,
				   CASE WHEN vivigenciaini -getdate()>0 THEN vivigenciaini
						ELSE getdate()
						END)/365.25), 0), 2)
			FROM dbo.ff_empresa e
			INNER JOIN ff_vigencia WITH (NOLOCK, READUNCOMMITTED)
				ON	e.emidconfiguracion = viidconfiguracion
			WHERE e.emidempresa=@idEmpresa
				AND e.emidestatus=1
				AND viidvigencia = @idVigenciaCalculo

			SELECT @Porcentaje =
				CASE WHEN @VIP= 1 THEN 1
					WHEN @VIP= 0 AND @valor BETWEEN 3 AND 4.99 THEN .2
					WHEN @VIP= 0 AND @valor BETWEEN 5 AND 9.99 THEN .4
					WHEN @VIP= 0 AND @valor BETWEEN 10 AND 14.99 THEN .6
					WHEN @VIP= 0 AND @valor BETWEEN 15 AND 19.99 THEN .8
					WHEN @VIP= 0 AND @valor >= 20 THEN 1 END

			INSERT INTO @CreditosOtorgados
			SELECT DISTINCT pbidcompensacion,
				@Porcentaje * ( Sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
										WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN ( pbporcentaje / 100.00 ) * tcprimatotal
										END) / cantidad )
			FROM   dbo.ff_planbasico pb WITH (NOLOCK, READUNCOMMITTED)
				LEFT OUTER JOIN dbo.ff_planbasicodetalle pbd WITH (NOLOCK, READUNCOMMITTED)
					ON pb.pbidplanbasico = pbd.pbidplanbasico
				INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
					ON pb.pbidplanopcion = po.poidplanopcion
				INNER JOIN @tmpPlanesFlexibles
					ON po.poidplanopcion = tcidplanopcion
					AND tcidparentesco = pbidparentesco
				INNER JOIN dbo.ff_tarifa trf WITH (NOLOCK, READUNCOMMITTED)
					ON tcidtarifa = trf.taidtarifa
			WHERE  pbidperfil = @idPerfil
			   AND pb.pbidestatus = 1
			   AND pbformacredito = '8'
			   AND pbd.pbidestatus = 1
			   AND po.poautorizacion = 0
			   AND tcidtarifacosto IN (SELECT DISTINCT tmp.tcidtarifacosto
									   FROM   @tmpPlanesFlexibles tmp
									   WHERE  tmp.poidplan = po.poidplan
											  AND tmp.idparentesco = ISNULL(pbidparentesco, pbidgrupoparentesco ))
			   AND trf.taidvigencia = @idvigencia
			GROUP  BY pbidcompensacion, tcprimatotal, pbporcentaje, cantidad
			OPTION (keep PLAN)
			END


		 --CrÃ©ditos compensaciones EXCEDENTES

		INSERT INTO #creditosotorgadosex
		SELECT coidcompensacion,
			ISNULL(Sum(cetotalcreditos), 0.00)
		FROM   dbo.ff_compensacion WITH (NOLOCK, READUNCOMMITTED)
			INNER JOIN dbo.ff_compensacionconfiguracion WITH (NOLOCK, READUNCOMMITTED)
				ON coidcompensacion = ccidcompensacion
			INNER JOIN dbo.ff_compensacionempleado WITH (NOLOCK, READUNCOMMITTED)
				ON coidcompensacion = ceidcompensacion
		WHERE  coidestatus = 1
			AND ccidperfil = @idPerfil
			AND ccexcedente = '1'
			AND ceidempleado = @idEmpleado
			AND CCCreditos = 1
		GROUP  BY coidcompensacion
		OPTION (keep PLAN)


		/******************** CALCULA CREDITOS PENDIENTES ********************************/

		SET @idtarifa = (SELECT taidtarifa FROM ff_tarifa WHERE taidvigencia = @idvigencia)

		INSERT INTO #creditosotorgadospendientes
		SELECT pbidcompensacion,
			Sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
					WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN ( pbporcentaje / 100.00 ) * tcprimatotal
				END)
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
		LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
			ON PB.pbidplanbasico = PBD.pbidplanbasico
		INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
			ON PB.pbidplanopcion = PO.poidplanopcion
		INNER JOIN dbo.ff_TarifaCosto_hist WITH (NOLOCK, READUNCOMMITTED)
			ON pbidplanopcion = tcidplanopcion
			AND tcidparentesco = pbidparentesco
			AND tcidtarifa = @IdTarifa
			AND tcidestatus = 2
		INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
			ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
		   AND PB.pbidestatus = 1
		   AND PBD.pbidestatus = 1
		   AND pbformacredito = '1'
		   AND PO.poautorizacion = 1
		   AND tcidtarifacosto IN (SELECT DISTINCT TMP.tcidtarifacosto
								   FROM   @tmpPlanesFlexibles TMP
								   WHERE  TMP.poidplanopcion = pbidplanopcion
										  AND TMP.idparentesco = ISNULL(pbidparentesco, pbidgrupoparentesco))
		   AND TRF.taidvigencia = @idvigencia
		GROUP  BY pbidcompensacion
		OPTION (KEEP PLAN)


		INSERT INTO #creditosotorgadospendientes
		SELECT pbidcompensacion,
			Sum(CASE WHEN pbporcentaje = 0 OR pbporcentaje IS NULL THEN pbcantidad
					 WHEN pbcantidad = 0 OR pbcantidad IS NULL THEN ( pbporcentaje / 100.00 ) * tcprimatotal
				   END)
		FROM   dbo.ff_planbasico PB WITH (NOLOCK, READUNCOMMITTED)
		LEFT OUTER JOIN dbo.ff_planbasicodetalle PBD WITH (NOLOCK, READUNCOMMITTED)
			ON PB.pbidplanbasico = PBD.pbidplanbasico
		INNER JOIN dbo.ff_planopcion PO WITH (NOLOCK, READUNCOMMITTED)
			ON PB.pbidplanopcion = PO.poidplanopcion
		INNER JOIN dbo.ff_TarifaCosto_hist WITH (NOLOCK, READUNCOMMITTED)
			ON pbidplanopcion = tcidplanopcion
			AND tcidgrupoparentesco = pbidgrupoparentesco
			AND tcidtarifa = @IdTarifa
			AND tcidestatus = 2
		INNER JOIN dbo.ff_tarifa TRF WITH (NOLOCK, READUNCOMMITTED)
			ON tcidtarifa = TRF.taidtarifa
		WHERE  pbidperfil = @idPerfil
			AND PB.pbidestatus = 1
			AND pbidgrupoparentesco IN (SELECT DISTINCT TMP.tcidgrupoparentesco
										FROM   @tmpPlanesFlexibles TMP
										WHERE  TMP.poidplan = PO.poidplan
												AND checked = 'TRUE')
			AND pbformacredito = '0'
			AND PBD.pbidestatus = 1
			AND PO.poautorizacion = 1
			AND TRF.taidvigencia = @idvigencia
		GROUP  BY pbidcompensacion
		OPTION (keep PLAN)

		TRUNCATE TABLE #CreditosOtorgados

		INSERT INTO #CreditosOtorgados
		SELECT * FROM @CreditosOtorgados

		--#############################################################################################################################################
		---SE OBTIENE EL MONTO DE LOS COSTOS Y DE LOS CREDITOS
		DECLARE @Favor MONEY
		DECLARE @Costo MONEY
		DECLARE @resta REAL
		DECLARE @DescuentoNomina MONEY
		DECLARE @saldo REAL
		DECLARE @CreditosEx MONEY
		DECLARE @CostoTotal REAL
		DECLARE @DDisponible MONEY
		DECLARE @CreditosCompletos MONEY

		SELECT @Creditos = ISNULL(sum(cantidad), 0.00)
		FROM #creditosotorgados
		OPTION (KEEP PLAN)

		SELECT @CreditosEX = ISNULL(sum(cantidad), 0.00)
		FROM #creditosotorgadosex
		OPTION (KEEP PLAN)

		SELECT @DescuentoNomina = dbo.calculadescuentonomina(@idEmpleado) * 12
		/**se le aumentan lso creditos de escedentes para el calculo**/

		SET @creditoscompletos = @creditos + @creditosex SELECT @creditos = @creditos + @creditosex
		/**************CALCULO DE BENEFICIOS******************/
		/********AGRUPADO POR PLANOPCION***********************/
		/**1.- OBTENGO EL TOTAL A PAGAR***/

		INSERT INTO #calculo_selecciones
		SELECT tcidplanopcion,
			   Sum(tcprimatotal / cantidad) AS TOTAL
		FROM   #tmpplanesflexibles
		WHERE  checked = 'true'
			AND poidplanopcion NOT IN (SELECT poidplanopcion
										  FROM   ff_planopcion
										  WHERE  povalorsumaasegurada = 1)
		GROUP  BY tcidplanopcion, tcprimatotal, cantidad
		OPTION (KEEP PLAN)

		/**********CALCULO DE BENEFICIOS QUE NO SE PAGAN CON CREDITOS ********/
		/********AGRUPADO POR PLANOPCION***********************/
		/***2.- OBTENGO LOS PLANES QUE NO SE PAGAN CON CREDITOS Y SON DESCUENTO NOMINA******/

		INSERT INTO #descuento_nomina
		SELECT tcidplanopcion,
			Sum(tcprimatotal / cantidad) AS TOTAL
		FROM   #tmpplanesflexibles
		INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
			ON tcidplanopcion = po.poidplanopcion
		WHERE  checked = 'true'
			AND tcidplanopcion NOT IN (SELECT DISTINCT cpidplanopcion
										FROM   dbo.ff_compensacionplanopcion WITH (NOLOCK, READUNCOMMITTED)
										WHERE  cpidcompensacion IN (
																	SELECT DISTINCT idcompensacion
																	FROM   #creditosotorgados
																	UNION
																	SELECT DISTINCT idcompensacion
																	FROM   #creditosotorgadosex))
			AND po.poidplanopcion NOT IN (SELECT poidplanopcion
											FROM   ff_planopcion
											INNER JOIN ff_plan
												ON poidplan = plidplan
											WHERE  plfondodeahorro = 1)
		GROUP  BY tcidplanopcion, tcprimatotal, cantidad
		OPTION (KEEP PLAN)

		 /***3.- OBTENGO LA DIFERENCIA DE LOS CREDITOS DISPONIBLES Y LOS QUE SE UTILIZEN A PAGAR******/

		INSERT INTO #planescreditos
		SELECT tcidplanopcion,
			Sum(tcprimatotal / cantidad) AS TOTAL,Sum(tcprimatotal) *0 as Saldo,PLOrdenCobranza as orden    -- MOD 21102019 se agrega columna
		FROM   #tmpplanesflexibles
			INNER JOIN dbo.ff_planopcion po WITH (NOLOCK, READUNCOMMITTED)
			ON tcidplanopcion = po.poidplanopcion
			INNER JOIN dbo.ff_plan P WITH (NOLOCK, READUNCOMMITTED) ON P.PLidPlan = po.POidPlan  -- MOD 21102019
		WHERE  checked = 'true'
			AND tcidplanopcion IN (SELECT DISTINCT cpidplanopcion
									FROM   ff_compensacionplanopcion WITH (NOLOCK, READUNCOMMITTED)
									WHERE  cpidcompensacion IN (
																 SELECT DISTINCT idcompensacion
																 FROM   #creditosotorgados
																 UNION
																 SELECT DISTINCT idcompensacion
																 FROM   #creditosotorgadosex))
			AND po.poidplanopcion NOT IN (SELECT poidplanopcion
											FROM   ff_planopcion
											INNER JOIN ff_plan
												ON poidplan = plidplan
											WHERE  plfondodeahorro = 1)
		GROUP  BY tcidplanopcion, tcprimatotal, cantidad,PLOrdenCobranza --MOD 21102019
		OPTION (KEEP PLAN)
-- MOD 22102019
		SELECT *
		INTO #planespaso
		from #planescreditos ORDER BY Orden
		delete #planescreditos
		INSERT INTO #planescreditos
		select tcidplanopcion,SUM(total),0,Orden
		FROM  #planespaso
		GROUP BY tcidplanopcion, Orden
-- FIND MOD 22102019
-- MOD 21102019
		UPDATE #planescreditos SET Saldo=total
		DECLARE @idcompensacion INT,@cantidad AS MONEY
		DECLARE Pago_cred CURSOR FOR

		select idcompensacion, SUM(cantidad) /*COD ANT cantidad*/ from #CreditosOtorgados
		Left JOIN ff_Compensacion c WITH (NOLOCK, READUNCOMMITTED) on c.COidCompensacion = idcompensacion
		GROUP BY idcompensacion, COOrden -- MOD 22102019
		order by COOrden

   		OPEN Pago_cred
		FETCH NEXT FROM Pago_cred
		INTO @idcompensacion, @cantidad
		WHILE @@FETCH_STATUS = 0
		BEGIN
			DECLARE @tcidplanopcion INT, @total MONEY, @SaldoOP MONEY, @Orden INT
			DECLARE Pago_plan CURSOR FOR
				SELECT #planescreditos.*
				from #planescreditos
				INNER JOIN ff_CompensacionPlanOpcion WITH(READUNCOMMITTED, NOLOCK) ON CPidPlanOpcion = tcidplanopcion AND CPidCompensacion = @idcompensacion
				WHERE Saldo>0
				order by orden
				OPEN Pago_plan
				FETCH NEXT FROM Pago_plan
				INTO @tcidplanopcion, @total,@SaldoOP,@Orden
				WHILE @@FETCH_STATUS = 0  AND  @cantidad>0 --MOD 22102019
				BEGIN
					UPDATE #planescreditos SET Saldo = CASE WHEN @SaldoOP>@cantidad THEN @SaldoOP-@cantidad ELSE 0 END WHERE tcidplanopcion = @tcidplanopcion
					SET @cantidad= CASE WHEN @SaldoOP>=@cantidad THEN 0 ELSE @cantidad-@SaldoOP END
				FETCH NEXT FROM Pago_plan
				INTO @tcidplanopcion, @total,@SaldoOP,@Orden
				END
				CLOSE Pago_plan
				DEALLOCATE Pago_plan
		FETCH NEXT FROM Pago_cred
		INTO @idcompensacion, @cantidad
		END
		CLOSE Pago_cred
		DEALLOCATE Pago_cred

		--Actualiza saldos
  /* COD ANTERIOR
  		SELECT @saldo = @creditos - ISNULL(Sum(total), 0)
		FROM   #planescreditos
 FIN COD ANTERIOR */
		SELECT @saldo= sum(Saldo)*-1
		FROM #planescreditos

		SELECT @sobrantecred = @creditos - (Sum(total) - Sum(Saldo))
		FROM   #planescreditos

		SET @sobrantecred= CASE WHEN @sobrantecred<0 THEN 0 ELSE @sobrantecred END
--FIN MOD 21102019

		/*********4.- OBTENGO SALDO A FAVOR CON CREDITOS O SUMO A DESCUENTO NOMINA LA DIFERENCIA******/
		IF(@Saldo < 0)
		BEGIN
			INSERT INTO #descuento_nomina
			VALUES(0, @Saldo*(-1))
		END

		SELECT @Costo = ISNULL(sum(total), 0)
		FROM #descuento_nomina

		SELECT @CostoTotal = ISNULL(sum(total), 0)
		FROM #calculo_selecciones

		SELECT @Creditos = @Creditos - @CreditosEX

		/*SE OBTIENEN LO CREDITOS SOBRANTES DE  EXCEDENTES */
		DELETE #creditosotorgadosex

		IF(@Saldo > 0)
		BEGIN
			IF (@Saldo > @CreditosEX)
			BEGIN
				INSERT INTO #creditosotorgadosex(cantidad)
				VALUES(@CreditosEX)--FIN MOD
			END
			ELSE
			BEGIN
				INSERT INTO #creditosotorgadosex(cantidad)
				VALUES(@Saldo)
				SELECT @Saldo = 0
			END
		END
		ELSE
		BEGIN
			INSERT INTO #creditosotorgadosex(cantidad)
			VALUES(0)
		END

		--###############################################################################################################################################
		DECLARE @Bandera INT
		DECLARE @ExedeLimite INT,
			@MontoBPSF MONEY,
			@ExcedeDescuentoCompensacion SMALLINT,
			@costoNonomina MONEY
		DECLARE @MontosOBRANTE MONEY,
			@NumEmpleado VARCHAR(20)
		DECLARE @IdConfiguracion INT,
			@PeridicidadNombre VARCHAR(150),
			@CantidadPago INT

		SET @ExedeLimite= 0

		DECLARE @CostoRegalo MONEY,
			@COSTOGMM MONEY,
			@COSTOEXC MONEY,
			@CRED MONEY
		DECLARE @PaginaInicio VARCHAR(200)
		DECLARE @edocuenta TABLE
		(
			tipo VARCHAR(1) NULL,
			descripcion VARCHAR(200) NULL,
			cantidad MONEY NULL,
			abono CHAR(1) NULL
		)
		DECLARE @tmpBotones TABLE
		(
		boton VARCHAR(250),
		tipo int
		)

		/*************************************************************************/
		/********************EJECUCION DE FORMULAS********************************/
		/*************************************************************************/
		/**SE VALIDA SI EXISTEN FORMULAS PARA LOS PLANES, PARA ABRIR EL CURSOR UNICAMENTE CUANDO SE TENGAN FORMULAS**/

		SELECT @Bandera = Count(poidplanopcion)
		FROM   dbo.ff_planopcion WITH (NOLOCK)
		WHERE  poidformula > 0
			AND poidformula IS NOT NULL
			AND poidplanopcion IN(SELECT DISTINCT tcidplanopcion
									 FROM   #tmpplanesflexibles)

		SELECT @idPerfil = emidperfil,
			@CRED = emsalariobase * .02,
			@NumEmpleado = emnumeroempleado --MOD BAT
		FROM   dbo.ff_empleado WITH (NOLOCK, READUNCOMMITTED)
		WHERE  id = @idEmpleado

		SELECT @IdConfiguracion = viidconfiguracion
		FROM   ff_vigencia WITH (NOLOCK, READUNCOMMITTED)
		WHERE  viidvigencia = @IdVigencia

		SELECT @PeridicidadNombre = ppnombre,
			@CantidadPago = ppcantidadpagos
		FROM   dbo.ff_periodicidadpago WITH (NOLOCK, READUNCOMMITTED)
		INNER JOIN dbo.ff_perfil WITH (NOLOCK, READUNCOMMITTED)
			ON ppidperiodicidadpago = peidperiodicidadnomina
			AND peidperfil = @idPerfil

		IF @Bandera > 0
		BEGIN
			DECLARE @Resultado FLOAT
			DECLARE @idFormula INTEGER
			DECLARE @idPlanOpcion INTEGER
			DECLARE @total_registros INTEGER
			DECLARE @contador_registros INTEGER

			CREATE TABLE #formulas_planes
			(
				[id_formulas_planes] [INT] IDENTITY(1, 1) PRIMARY KEY,
				[idformula]          [INT] NOT NULL,
				[idplanopcion]       [INT] NOT NULL
			)

			INSERT INTO #formulas_planes
			SELECT DISTINCT poidformula,
							poidplanopcion
			FROM   dbo.ff_planopcion WITH (NOLOCK)
			WHERE  poidformula IS NOT NULL
					AND poidformula > 0
					AND poidplanopcion IN (SELECT DISTINCT poidplanopcion
										FROM   #tmpplanesflexibles)
			OPTION (KEEP PLAN)

			SET @total_registros = 0
			SET @total_registros = ISNULL((SELECT Count(*)
											FROM   #formulas_planes), 0)
			SET @contador_registros = 1

			WHILE @total_registros > 0
				AND @contador_registros <= @total_registros
			BEGIN
				SELECT @idFormula = idformula,
						@idPlanOpcion = idplanopcion
				FROM   #formulas_planes
				WHERE  id_formulas_planes = @contador_registros

				EXEC dbo.Ff_traecamposformula
					@idFormula,
					@idEmpleado,
					@Resultado output

				UPDATE #tmpplanesflexibles
				SET    tcprimatotal = @Resultado
				WHERE  tcidplanopcion = @idPlanOpcion

				SET @contador_registros = @contador_registros + 1
			END

			DROP TABLE #formulas_planes
		  END


		 /*************************************************************************/
		 /******************FIN DE EJECUCION DE FORMULAS***************************/
		 /*************************************************************************/
		IF @idEmpresa IN(122, 439)
		BEGIN
			DELETE #calculo_selecciones
			/**1.- OBTENGO EL TOTAL A PAGAR***/
			INSERT INTO #calculo_selecciones
				SELECT tcidplanopcion, sum(tcprimatotal/ cantidad) AS total
				FROM #tmpplanesflexibles
				WHERE checked = 'true'
				GROUP BY tcidplanopcion, tcprimatotal, cantidad
				OPTION (KEEP PLAN)

			SELECT @CostoTotal = sum(total)
			FROM #calculo_selecciones
		END

		/********  VALIDO SI EL COSTO ES MAYOR A SU DESCUENTO POR NOMINA  *********/

		--TODO QUERY SIN DESBLOQUEAR TABLA
		PRINT 'COMIENZA PROCESO IDENTIFICADO'
		IF EXISTS(
			SELECT tcidplanopcion
			FROM #calculo_selecciones
			WHERE tcidplanopcion IN(
									SELECT poidplanopcion
									FROM ff_planopcion WITH(READUNCOMMITTED, NOLOCK)
									WHERE poidestatus=1 AND poidplan IN(
																		SELECT idplan
																		FROM bf_planformapagonovalido WITH(READUNCOMMITTED, NOLOCK)
																		WHERE idestatus=1
																		)
									)
				) AND @idEmpresa <> 456
		BEGIN
			SET @costoNonomina = @CreditosCompletos - ISNULL((
															SELECT sum(total)
															FROM #calculo_selecciones
															WHERE tcidplanopcion IN(
																					SELECT poidplanopcion
																					FROM ff_planopcion WITH(READUNCOMMITTED, NOLOCK)
																					WHERE poidestatus=1
																						AND poidplan IN(
																										SELECT idplan
																										FROM bf_planformapagonovalido WITH(READUNCOMMITTED, NOLOCK)
																										WHERE idestatus=1
																					)
																)) , 0)
			print 'DESCUENTO X NÃ“MINA'
			print @costoNonomina

			IF (@costoNonomina < 0)
			BEGIN
				SET @ExcedeDescuentoCompensacion =1
			END
		END


		IF @IdEmpresa IN(616, 367, 717)
		BEGIN
			DECLARE @MontoDescuentoPlanes MONEY,
				@SalarioMonto MONEY

			SET @porcentaje = .5

			SELECT @SalarioMonto = (emsalariobase * @porcentaje) * 12
			FROM ff_empleado WITH(READUNCOMMITTED, NOLOCK)
			WHERE id=@idEmpleado

			SET @MontoDescuentoPlanes = ISNULL((SELECT sum(total)
												FROM #calculo_selecciones
												WHERE tcidplanopcion IN(
																		SELECT poidplanopcion
																		FROM ff_planopcion WITH(READUNCOMMITTED, NOLOCK)
																		WHERE poidestatus=1
																			AND poidplan IN(1693, 1675, 1674, 1686, 1607, 1609, 1624, 1608, 1606, 1842)
																		)
												), 0)
			IF (@DescuentoNomina < ( @Costo - @MontoDescuentoPlanes))
				OR @MontoDescuentoPlanes > @SalarioMonto

			BEGIN
				SET @ExedeLimite =1
				print @MontoDescuentoPlanes
				print @SalarioMonto
			END
			ELSE
				SET @ExedeLimite =0
			END
			ELSE
			BEGIN
				IF (@Costo > @DescuentoNomina)
					SET @ExedeLimite =1
				END

				IF (@ExedeLimite=1)   OR  @ExcedeDescuentoCompensacion= 1
				BEGIN
					UPDATE #tmpPlanesFlexibles
					SET checked = 'false'

					IF (SELECT COUNT(TCidTarifaCosto) from #TmpPlanesSeleccionadosOld) > 1
					BEGIN
					   UPDATE #tmpPlanesFlexibles
					   SET checked = 'true'
					   where CAST(TCidTarifaCosto as varchar(15)) +'-'+ CAST(id as varchar(10)) in (
							SELECT CAST(TCidTarifaCosto as varchar(15))+'-'+ CAST(idempleado as varchar(10))
							FROM #TmpPlanesSeleccionadosOld)
					END
					ELSE
					BEGIN
						EXEC ff_CEvaluaCandados @IdEmpleado,@idempresa,@NumEmpleado
					END

					/********************************************************************/
					/********** EVALUA LOS PLANES QUE NO DEBEN DE SER VISIBLES***********/
					/********************************************************************/
					UPDATE #tmpplanesflexibles
					SET	visible = 'FALSE'
					from	#tmpplanesflexibles tmp
					INNER JOIN dbo.ff_plan pl  WITH (NOLOCK, READUNCOMMITTED)
						ON	tmp.poidplan = pl.plidplan
					WHERE plvisible = '0'

					IF @ExcedeDescuentoCompensacion = 1
					BEGIN
						IF @idEmpresa NOT IN (616,367,717)
						BEGIN
							IF @idEmpresa =122
								BEGIN
									INSERT INTO #mensajes
									VALUES(
											'LA SELECCION EXCEDE EL MONTO DEL COMBO DE BENEFICIOS, MODIFICA TUS ELECCIONES.',
											'Error'
										)
								END
								ELSE
								BEGIN
									INSERT INTO #mensajes
									VALUES (
											'LA SELECCION EXCEDE EL MONTO DE LA COMPENSACIÃ“N FLEXIBLE, MODIFICA TUS ELECCIONES.',
											'Error'
											)
								END
						END
						ELSE
						BEGIN
							INSERT INTO #mensajes
							VALUES (
									'LA SELECCION EXCEDE EL MONTO DE LA BOLSA FLEXIBLE, MODIFICA TUS ELECCIONES.',
									'Error'
									)
						END
					END
					ELSE
					BEGIN
						INSERT INTO #mensajes
							VALUES (
									'LA SELECCION EXCEDE LA CANTIDAD A DESCONTAR POR NÃ“MINA, MODIFICA TUS ELECCIONES.',
									'Error'
									)
					END

					SET @ExedeLimite=1
					print 'LIMITE GASTO'
					print @ExedeLimite
					print 'COSTO'
					print @Costo
					print 'LIMITE GASTO'
					print @DescuentoNomina
						  /**************CALCULO DE BENEFICIOS******************/
						   /********AGRUPADO POR PLANOPCION***********************/
					IF @idEmpresa <> 439
					BEGIN
						DELETE #calculo_selecciones
						INSERT INTO #calculo_selecciones
						SELECT tcidplanopcion, sum(tcprimatotal/ cantidad) AS total
						FROM #tmpplanesflexibles
						WHERE checked = 'true'
						GROUP BY tcidplanopcion, tcprimatotal, cantidad
						OPTION (keep plan)
					 END
						   /**********CALCULO DE BENEFICIOS QUE NO SE PAGAN CON CREDITOS ********/
						   /********AGRUPADO POR PLANOPCION***********************/
					DELETE #descuento_nomina















/***2.- OBTENGO LOS PLANES QUE NO SE PAGAN CON CREDITOS Y SON DESCUENTO NOMINA******/
INSERT INTO #descuento_nomina
SELECT tcidplanopcion,
       Sum(tcprimatotal / cantidad) AS TOTAL
FROM   #tmpplanesflexibles WITH (NOLOCK, READUNCOMMITTED)
       INNER JOIN dbo.ff_planopcion po  WITH (NOLOCK, READUNCOMMITTED)
               ON tcidplanopcion = po.poidplanopcion
WHERE  checked = 'true'
       AND tcidplanopcion NOT IN (SELECT DISTINCT cpidplanopcion
                                  FROM   dbo.ff_compensacionplanopcion WITH (
                                         NOLOCK)
                                  WHERE  cpidcompensacion IN
                                         (SELECT DISTINCT idcompensacion
                                          FROM   #creditosotorgados))
GROUP  BY tcidplanopcion,
          tcprimatotal,
          cantidad
OPTION (keep PLAN)

DELETE #planescreditos

/***3.- OBTENGO LA DIFERENCIA DE LOS CREDITOS DISPONIBLES Y LOS QUE SE UTILIZEN A PAGAR******/
INSERT INTO #planescreditos
SELECT tcidplanopcion,
       Sum(tcprimatotal / cantidad) AS TOTAL,Sum(tcprimatotal / cantidad),PLOrdenCobranza  --MOD 28102019
FROM   #tmpplanesflexibles
       INNER JOIN dbo.ff_planopcion po  WITH (NOLOCK, READUNCOMMITTED)
               ON po.poidplanopcion = tcidplanopcion
		INNER JOIN dbo.ff_plan P WITH (NOLOCK, READUNCOMMITTED) ON P.PLidPlan = po.POidPlan --MOD 28102019
WHERE  checked = 'true'
       AND tcidplanopcion IN (SELECT DISTINCT cpidplanopcion
                              FROM   dbo.ff_compensacionplanopcion WITH (NOLOCK)
                              WHERE  cpidcompensacion IN
                                     (SELECT DISTINCT idcompensacion
                                      FROM   #creditosotorgados))
GROUP  BY tcidplanopcion,
          tcprimatotal,
          cantidad,
		  PLOrdenCobranza --MOD 28102019
OPTION (keep PLAN)

--MOD 21102019
/* COD ANTERIOR
SELECT @Saldo = @creditos - Sum(total)
FROM   #planescreditos
FIN COD ANTERIO */

SELECT @saldo =SUM(SALDO)*-1
FROM #planescreditos

SELECT @sobrantecred = @creditos - (Sum(total) - Sum(Saldo))
FROM   #planescreditos
SET @sobrantecred= CASE WHEN @sobrantecred<0 THEN 0 END
-- FIN  MOD 21102019


/*********4.- OBTENGO SALDO A FAVOR CON CREDITOS O SUMO A DESCUENTO NOMINA LA DIFERENCIA******/
IF( @Saldo < 0 )
	INSERT INTO #descuento_nomina
	VALUES (0, @Saldo * ( -1 ))

	SELECT @Costo = sum(total)
	FROM #descuento_nomina

	SELECT @CostoTotal = sum(total)
	FROM #calculo_selecciones

	SELECT @DDisponible = ISNULL(@DescuentoNomina, 0.00) - ISNULL(@Costo, 0.00)
      /******************************************************************************/
      /******** MODIFICACION PARA MOSTRAR O NO EL SUELDO DEL EMPLEADO ***************/
      /******************************************************************************/
	SELECT @MuestraSueldo = 1

	IF EXISTS(
		SELECT emidsalarioconfidencial
		FROM   dbo.ff_empleado WITH (NOLOCK, READUNCOMMITTED)
		WHERE  id = @idEmpleado AND emidsalarioconfidencial = 1)
	BEGIN
		SELECT @MuestraSueldo = 0
	END

	IF EXISTS(
		SELECT peidperfil
		FROM   dbo.ff_perfil WITH (NOLOCK, READUNCOMMITTED)
		WHERE  peidperfil = @idPerfil AND pemuestrasueldo = 0)
	BEGIN
		SELECT @MuestraSueldo = 0
	END

	IF ( @MuestraSueldo = 1 ) AND @IdEmpresa IN(
												SELECT emidempresa
												 FROM   ff_empresa
												 WHERE  emidestatus = 1
														AND emcostoxperiodo = 1
														AND emidempresa = @IdEmpresa)
	BEGIN
      -- MOD BAT 18052014
      INSERT INTO @edocuenta
      VALUES ('1', 'DESCUENTO MÃXIMO ' + @PeridicidadNombre
			+ ' POR NÃ“MINA ', @DescuentoNomina / @CantidadPago, '0')

      -- MOD BAT 18072006
      INSERT INTO @edocuenta
      SELECT '3', 'DESCUENTO ' + @PeridicidadNombre
             + ' DISPONIBLE ', @DDisponible / @CantidadPago, '1'
	END
	ELSE IF ( @MuestraSueldo = 1 )
	BEGIN
      INSERT INTO @edocuenta
      VALUES     ('1', 'DESCUENTO MÃXIMO ANUAL POR NÃ“MINA ',
                  @DescuentoNomina,'0')

      INSERT INTO @edocuenta
      SELECT '3', 'DESCUENTO ANUAL DISPONIBLE ',
             @DDisponible, '1'
	END

/***********************FIN MODIFICACION 11/04/2006***************/
/*****************************************************************/
IF @IdEmpresa IN(173, 174, 236, 247, 248, 261, 92, 93)
BEGIN
	-- MOD BAT 18072006
	INSERT INTO @edocuenta
	VALUES('2', 'CRÃ‰DITOS ' +@PeridicidadNombre + ' OTORGADOS', @Creditos/ @CantidadPago, '0')
	-- MOD BAT 18072006
	INSERT INTO @edocuenta VALUES('3', 'COSTO SELECCIÃ“N ' +@PeridicidadNombre, @CostoTotal/@CantidadPago, '0')
END
ELSE
BEGIN
	INSERT INTO @edocuenta
	VALUES('2' , 'TOTAL CRÃ‰DITOS ', @Creditos/@CantidadPago, '0')

	INSERT INTO @edocuenta
	VALUES('3', 'TUS SELECCIONES AL FINAL DE LA VIGENCIA ', @CostoTotal/ @CantidadPago, '0')
END

IF (@sobrantecred > 0) -- COD ANTERIOR (@Saldo > 0)FIN MOD 21102019
	IF @IdEmpresa=174
	BEGIN
	BEGIN
		INSERT INTO @edocuenta
		VALUES('4', 'CRÃ‰DITOS NO UTILIZADOS ', @sobrantecred, '1')
	END
	END
	ELSE IF @IdConfiguracion = 26
	BEGIN
		INSERT INTO @edocuenta VALUES('4', 'CRÃ‰DITOS NO UTILIZADOS ', @sobrantecred, '1')
	END
	ELSE
	BEGIN
		INSERT INTO @edocuenta VALUES('4', 'CRÃ‰DITOS DISPONIBLES', @sobrantecred/@CantidadPago, '1')
	END
	ELSE
	BEGIN
		INSERT INTO @edocuenta VALUES('4', 'CRÃ‰DITOS DISPONIBLES', 0.00, '1')
	END

	IF( @Costo > 0)
	BEGIN
		INSERT INTO @edocuenta SELECT '4', 'DESCUENTO ' + @PeridicidadNombre, @Costo/@CantidadPago, '0'
	END
	ELSE
	BEGIN
		INSERT INTO @edocuenta SELECT '4', 'DESCUENTO ' + @PeridicidadNombre, @Costo/@CantidadPago, '0'
	END
END
ELSE --  if 1=2
BEGIN
	SELECT @DDisponible = ISNULL(@DescuentoNomina, 0.00) - ISNULL(@Costo, 0.00)

	/******************************************************************************/
	/******** MODIFICACION PARA MOSTRAR O NO EL SUELDO DEL EMPLEADO ***************/
	/******************************************************************************/
	SELECT @MuestraSueldo = 1

	IF EXISTS(
			SELECT emidsalarioconfidencial
			FROM   dbo.ff_empleado WITH (NOLOCK, READUNCOMMITTED)
			WHERE  id = @idEmpleado AND emidsalarioconfidencial = 1)
	BEGIN
		SELECT @MuestraSueldo = 0
	END

	IF EXISTS(
			SELECT peidperfil
			FROM   dbo.ff_perfil WITH (NOLOCK, READUNCOMMITTED)
			WHERE  peidperfil = @idPerfil AND pemuestrasueldo = 0)
	BEGIN
		SELECT @MuestraSueldo = 0
	END

	IF ( @MuestraSueldo = 1 ) AND @IdEmpresa IN(
												SELECT emidempresa
												FROM   ff_empresa
												WHERE  emidestatus = 1
													AND emcostoxperiodo = 1
												AND emidempresa = @IdEmpresa)
	BEGIN
		  -- MOD BAT 18052014
      INSERT INTO @edocuenta
      VALUES     ('1',
                  'DESCUENTO MÃXIMO ' + @PeridicidadNombre
                  + ' POR NÃ“MINA ',
                  @DescuentoNomina / @CantidadPago,
                  '0')

      -- MOD BAT 18072006
      INSERT INTO @edocuenta
      SELECT '3',
             'DESCUENTO ' + @PeridicidadNombre
             + ' DISPONIBLE ',
             @DDisponible / @CantidadPago,
             '1'
	END
	ELSE IF ( @MuestraSueldo = 1 )
	BEGIN
		INSERT INTO @edocuenta
		VALUES     ('1',
                  'DESCUENTO MÃXIMO ANUAL POR NÃ“MINA ',
                  @DescuentoNomina,
                  '0')

		INSERT INTO @edocuenta
		SELECT '3',
             'DESCUENTO ANUAL DISPONIBLE ',
             @DDisponible,
             '1'
  END
/***********************FIN MODIFICACION 11/04/2006***************/
/*****************************************************************/


	IF @IdConfiguracion  in (86)
	BEGIN
		DECLARE @DESCU MONEY,
			@COMPENSAC INT

		SET @COMPENSAC = ISNULL((
								SELECT embeneficiomaximom
								FROM ff_empleado
								WHERE id=@idEmpleado) * 12, 0)

		INSERT INTO @edocuenta
		VALUES ('1',
			'DESCUENTO MAXIMO NOMINA',
			@COMPENSAC / @CantidadPago,
			'0')

		INSERT INTO @edocuenta
		VALUES ('3',
					'COSTO SELECCIÃ“N ' + @PeridicidadNombre,
					@CostoTotal / @CantidadPago,
					'0')
	END

	IF @IdConfiguracion  in (132,165)
	BEGIN
		DECLARE @DESCC MONEY
		SET @DESCC = (SELECT SUM (TCPRIMATOTAL) FROM #tmpPlanesFlexibles WHERE TCIDPLANOPCION IN (7020,7023) )
		SET @DESCC = ISNULL(@DESCC,0)

		INSERT INTO @edocuenta
		VALUES ('2',
			'PUNTOS ' + @PeridicidadNombre + ' OTORGADOS',
			@Creditos / @CantidadPago,
			'0')

		INSERT INTO @edocuenta
		VALUES ('3',
			'COSTO SELECCIÃ“N ' + @PeridicidadNombre,
			@CostoTotal / @CantidadPago,
			'0')

		INSERT INTO @edocuenta
		VALUES ('9',
			'APORTACIÃ“N BASICA ' + @PeridicidadNombre,
			@DESCC / @CantidadPago,
			'0')
	END


	IF @IdEmpresa IN(
					SELECT emidempresa
					FROM ff_empresa
					WHERE emidestatus=1
						AND emcostoxperiodo = 1
						AND emidempresa = @IdEmpresa
						AND emidempresa NOT IN (570, 571, 572, 367, 717))
	BEGIN
		INSERT INTO @edocuenta VALUES('2', 'CRÃ‰DITOS ' +@PeridicidadNombre + ' OTORGADOS', @Creditos/ @CantidadPago, '0')
		INSERT INTO @edocuenta VALUES('3', 'COSTO SELECCIÃ“N ' +@PeridicidadNombre, @CostoTotal/@CantidadPago, '0')
	END
	ELSE IF @IdEmpresa>65 AND @IdEmpresa NOT IN(173, 174, 570, 571, 572, 367, 717)
	BEGIN
		INSERT INTO @edocuenta VALUES('2', 'CRÃ‰DITOS ' +@PeridicidadNombre, @Creditos/ @CantidadPago, '0')
		INSERT INTO @edocuenta VALUES('3', 'COSTO ' +@PeridicidadNombre, @CostoTotal/ @CantidadPago, '0')
	END
	ELSE IF @idEmpresa NOT IN (570, 571, 572, 367, 717)
	BEGIN
		INSERT INTO @edocuenta VALUES('2', 'TOTAL CRÃ‰DITOS '+@PeridicidadNombre, @Creditos/@CantidadPago, '0')
		INSERT INTO @edocuenta VALUES('3', 'TUS SELECCIONES '+@PeridicidadNombre, @CostoTotal/@CantidadPago, '0')
	END

	IF(@sobrantecred > 0)
	BEGIN
		IF @IdConfiguracion IN (132, 165)
		BEGIN
			INSERT INTO @edocuenta VALUES('4', 'PUNTOS DISPONIBLES '+@PeridicidadNombre, @sobrantecred/@CantidadPago, '1')
		END

		IF @IdEmpresa IN(173)
		BEGIN
			INSERT INTO @edocuenta
			VALUES('4', 'CRÃ‰DITOS '+@PeridicidadNombre+ ' DISPONIBLES', @sobrantecred/@CantidadPago, '1')
		END
		ELSE IF @IdEmpresa IN(174)
		BEGIN
			INSERT INTO @edocuenta VALUES('4', 'CRÃ‰DITOS '+@PeridicidadNombre+ ' NO UTILIZADOS', @sobrantecred/@CantidadPago, '1')

			IF @IdEmpresa IN (174) AND (
										SELECT count(idempleado)
										FROM #tmpplanesseleccionadosold) < 2
			BEGIN
				INSERT INTO #mensajes VALUES('Los crÃ©ditos no utilizados se perderan y no podrÃ¡s ocuparlos despuÃ©s.', 'Error')
			END
		END
		ELSE IF @IdEmpresa > 65 AND @IdEmpresa NOT IN(
														SELECT emidempresa
														FROM ff_empresa
														WHERE emidestatus=1 AND emcostoxperiodo = 1)
		BEGIN
			INSERT INTO @edocuenta VALUES('4', 'CRÃ‰DITOS '+@PeridicidadNombre+ ' DISPONIBLES', @sobrantecred/@CantidadPago, '1')
		END
		ELSE IF @IdConfiguracion=26
		--Verificar por parÃ¡metro
		BEGIN
			INSERT INTO @edocuenta VALUES
				(
					'4',
					'CRÃ‰DITOS '+ @PeridicidadNombre+ ' NO UTILIZADOS ',
					@sobrantecred / @CantidadPago,
					'1'
				)
		END
		ELSE IF @idEmpresa NOT IN ( 570,571,572,367,717 )
		BEGIN
			INSERT INTO @edocuenta VALUES
				(
					'4',
					'CRÃ‰DITOS DISPONIBLES '+ @PeridicidadNombre,
					@sobrantecred /@CantidadPago,
					'1'
				)
		END
	END
	ELSE
	BEGIN
		IF @IdEmpresa > 65 AND @idEmpresa NOT IN ( 570,571,572,367,717)
		BEGIN
			INSERT INTO @edocuenta VALUES
				(
					'4',
					'CRÃ‰DITOS DISPONIBLES',
					0.00,
					'1'
				)
		END
		ELSE
		IF @idEmpresa NOT IN ( 570,571,572,367,717)
		BEGIN
			INSERT INTO @edocuenta VALUES
				(
					'4',
					'CRÃ‰DITOS DISPONIBLES ',
					0.00,
					'1'
				)
		END

		IF @IdEmpresa IN (570,571,572)
		BEGIN
			INSERT INTO @edocuenta values('4','PUNTOS DISPONIBLES', 0.00,'1')
		END
	END

	SET @costoregalo = 0

	IF EXISTS(
				SELECT cpidcondicionplan
				FROM dbo.ff_condicionplan WITH (NOLOCK, READUNCOMMITTED)
				WHERE cpidtipocondicion = 14 AND cpidempresa = @idempresa)
	BEGIN
		SELECT @costoregalo = (
								SELECT DISTINCT tcprimatotal
								FROM #tmpplanesflexibles a
								INNER JOIN ff_resultadocondicionplan b WITH (NOLOCK, READUNCOMMITTED)
									ON a.poidplanopcion = b.rcidplanopcion
								INNER JOIN ff_detallecondicionplan AS c WITH (NOLOCK, READUNCOMMITTED)
									ON b.rcidcondicionplan = c.dcidcondicionplan
								INNER JOIN ff_condicionplan AS e  WITH (NOLOCK, READUNCOMMITTED)
									ON c.dcidcondicionplan = e.cpidcondicionplan
								WHERE a.checked = 'true' AND idparentesco = 1
									AND c.dcidgrupoparentesco = a.tcidgrupoparentesco
									AND e.cpidtipocondicion = 14
									AND e.cpidempresa = @idempresa)
	END

	IF(@Costo > 0)
	BEGIN
		IF (@Costo > @CostoRegalo) AND @idEmpresa NOT IN (570, 571, 572, 367, 717)
		BEGIN
			INSERT INTO @edocuenta
			SELECT '4', 'DESCUENTO ' + @PeridicidadNombre, (@Costo - @CostoRegalo)/ @CantidadPago, '0'
		END
		ELSE IF @IdEmpresa IN(
								SELECT emidempresa
								FROM ff_empresa
								WHERE emidestatus=1 AND emcostoxperiodo = 1
									AND emidempresa NOT IN (570, 571, 572, 367, 717))
		BEGIN
			INSERT INTO @edocuenta
			SELECT '4', 'DESCUENTO ' + @PeridicidadNombre+' NOMINA', (@Costo)/@CantidadPago, '0'
		END
		ELSE IF @IdEmpresa NOT IN (570, 571, 572, 367, 717)
		BEGIN
			INSERT INTO @edocuenta
			SELECT '4', 'DESCUENTO ' + @PeridicidadNombre, (@Costo)/@CantidadPago, '0'
		END
	END
	ELSE
	BEGIN
		INSERT INTO @edocuenta
		SELECT top 1 '4', 'DESCUENTO ' + @PeridicidadNombre, 0.00 , '0'
	END

	print 'FIN'



	IF @idEmpresa IN (570, 571, 572)
	BEGIN
		INSERT INTO @edocuenta
		SELECT '4', 'DESCUENTO EMPLEADO ' +@PeridicidadNombre, (@Costo)/@CantidadPago, '0'

		INSERT INTO @edocuenta
		SELECT '9', 'DESCUENTO ADICIONAL '+@PeridicidadNombre, ((@Costo) /@CantidadPago) - (@DESCC/@CantidadPago), '0'
	END --BD

	IF @idEmpresa IN (367, 717)--ace
	BEGIN
		IF (@COMPENSAC/@CantidadPago - (@Costo)/@CantidadPago)>=0
		BEGIN
			INSERT INTO @edocuenta
			SELECT '4', 'DESCUENTO NOMINA '+@PeridicidadNombre, (@Costo/@CantidadPago), '0'

			INSERT INTO @edocuenta
			SELECT '7', 'SOBRANTE DESCUENTO MAXIMO ', (@COMPENSAC/@CantidadPago) - (@Costo/@CantidadPago), '0'
		END
		ELSE
		BEGIN
			INSERT INTO @edocuenta
			SELECT '4', 'DESCUENTO NOMINA '+ @PeridicidadNombre, (@COMPENSAC/@CantidadPago), '0'

			INSERT INTO @edocuenta
			SELECT '4', 'PAGO REFERENCIADO ', abs((@COMPENSAC/@CantidadPago)-(@Costo/@CantidadPago)), '0'
		END
	END --ACE
END

/***************
********************************************************/
--------sacar el parametro 222 para ver si validar el candado 41
/***********************************************************************/
declare @ValorPar varchar(200);

exec ff_GetParametroValor @idEmpresa, 222, @ValorPar OUTPUT

set @ValorPar = ISNULL(@ValorPar,'');

--print 'valor del parametro 222'
--print @ValorPar
/***********************************************************************/
--VALIDA QUE EL EMPLEADO NO TENGA UNA SOLICITUD PENDIENTE DE AUTORIZAR PARA DEJARLO SELECCIONAR
IF NOT EXISTS(
			SELECT SOIdSolicitud
			FROM dbo.ff_solicitud  WITH (NOLOCK)
			WHERE SOIdEmpleado = @idEmpleado AND SOEstatusSolicitud = 99)
BEGIN
	IF (@Transfer = 'True')
	BEGIN
	/*PROCESO DE TRANSFERENCIA, MOSTRAR LOS PLANES INHABILITADOS Y HABILITAR UN BOTON PARA REALIZAR LA BAJA DEL EMPLEADO*/

		UPDATE #tmpPlanesFlexibles
		SET enabled = 'false'
		-- candado 41 - inicio 1
		print 'valida parametro 222 - 1'
		if(@ValorPar <> '')
		begin
			EXEC ff_evaluaCandado_41 @idEmpresa, @idEmpleado;
		end
		-- candado 41 - fin 1
		SELECT  id, EMApellidoMaterno, EMApellidoPaterno, EMNombre1, EMNombre2, EMIdParentesco, TCidTarifaCosto, TCidTarifa, TCidPlanOpcion,
					TCidTipoTarifa, TCidGrupoParentesco, TCidParentesco, TCidSexo, TCEdad, TCidTipoFumador, TCPrimaNeta, TCPrimaTotal, POidPlanoPCION,
					POidPlan, PONombre, PODescripcion, POCaptura, PLNombre, PLDescripcion, PLidRamo, PLCoberturaForzosaTitular, RANombre, RADescripcion,
					PARENTESCOSDESCRIPCION, IDPARENTESCO, PADESCRIPCION, Checked, Visible, Enabled, HTMLControl, cantidad, archivo, RAimg, PLimg, POimg,
					raorden, plorden, poorden, ArchivoPlan
		FROM #tmpPlanesFlexibles
		WHERE visible = 'true'
		AND checked = 'true'
		ORDER BY raorden, plorden, poorden, idparentesco, EMIdParentesco
		OPTION (KEEP PLAN)

		INSERT INTO @tmpBotones
		SELECT 'EquivalenciaPlanes' AS Boton , 5 AS tipo
	END
	ELSE
	BEGIN
		IF (@Transfer = 'Perfil')
		BEGIN
			/*PROCESO DE TRANSFERENCIA, MOSTRAR LOS PLANES INHABILITADOS Y HABILITAR UN BOTON PARA REALIZAR LA BAJA DEL EMPLEADO*/
			UPDATE #tmpPlanesFlexibles
			SET enabled = 'false'
			-- candado 41 - inicio 2
			print 'valida parametro 222 - 2'
			if(@ValorPar <> '')
			begin
				EXEC ff_evaluaCandado_41 @idEmpresa, @idEmpleado;
			end
			-- candado 41 - fin 2
			SELECT  id, EMApellidoMaterno, EMApellidoPaterno, EMNombre1, EMNombre2, EMIdParentesco, TCidTarifaCosto, TCidTarifa, TCidPlanOpcion, TCidTipoTarifa, TCidGrupoParentesco, TCidParentesco, TCidSexo, TCEdad, TCidTipoFumador, TCPrimaNeta, TCPrimaTotal,
			POidPlanoPCION, POidPlan, PONombre, PODescripcion, POCaptura, PLNombre, PLDescripcion, PLidRamo, PLCoberturaForzosaTitular, RANombre, RADescripcion, PARENTESCOSDESCRIPCION, IDPARENTESCO, PADESCRIPCION, Checked, Visible, Enabled,
			HTMLControl, cantidad, archivo, RAimg, PLimg, POimg, raorden, plorden,  poorden, ArchivoPlan
			FROM #tmpPlanesFlexibles
			WHERE visible = 'true' and checked = 'true'
			ORDER BY raorden, plorden, poorden, idparentesco, EMIdParentesco
			OPTION (KEEP PLAN)

			INSERT INTO @tmpBotones
			SELECT 'CambioPerfil' AS Boton , 6 AS tipo
		END
		ELSE
		BEGIN
			--  ACTUALIZAR PLANES PARA HABILITAR O DESHABILITAR --
			--MOD BAT
			UPDATE tmp
			SET Enabled = CASE WHEN p.PLEnabled = 0 THEN 'false'
							WHEN  p.PLEnabled = 1 AND p.PLEnabledDependiente=0 AND tmp.emidparentesco <> 1 THEN 'false' ELSE 'true' END
			--ANT UPDATE tmp  SET Enabled= CASE p.PLEnabled WHEN 1 THEN 'true' ELSE 'false' END
			FROM #tmpPlanesFlexibles tmp
			INNER JOIN ff_Plan p  WITH (NOLOCK, READUNCOMMITTED)
				ON p.PLIdPlan=POIDPlan
			WHERE tmp.visible = 'true' AND tmp.Enabled='true'

			-- FIN MOD
			--MOD BAT 270818
			if @IdConfiguracion=27
			BEGIN
				UPDATE #tmpPlanesFlexibles
				SET TCPrimaTotal=TCPrimaTotal*-1,TCPrimaNeta=TCPrimaNeta*-1
				WHERE POidPlanoPCION in(7277,7278,7280,7340,7343,7342)
				--MOD BAT 280818
				IF @idEmpleado IN(544511,544514,544518,544528,544529,544575,544600,544665,544615,544618)
				BEGIN
					UPDATE #tmpPlanesFlexibles
					SET PLNombre = '* PARA TU COTIZACIÃ“N CONTACTA AL ASESOR LOCKTON'
					WHERE POidPlan =1860
				END
				--FIN MOD
			END

			--FIN MOD 270818

			--MOD BAT FUERZA A PONER NO VISIBLES PLANES CON RESTRICCIÃ“N 280818
			/********************************************************************/
			/********** EVALUA LOS PLANES QUE NO DEBEN DE SER VISIBLES***********/
			/********************************************************************/


			UPDATE #tmpPlanesFlexibles
			SET VISIBLE = 'FALSE'
			FROM  #tmpPlanesFlexibles tmp
			INNER JOIN dbo.ff_validaSAVida VS WITH (NOLOCK, READUNCOMMITTED)
				ON id = VSidEmpleado
			WHERE	VSIDESTATUS <> 1
				AND VSidPlanOpcion = tcidplanopcion
				AND VSIDVIGENCIA = @idvigencia

			/********** FIN MOD 280818 ***********/

			DECLARE @COCotizadorNuevo AS INT

			SET @COCotizadorNuevo = (
									SELECT COCotizadorNuevo
									FROM FF_CONFIGURACION
									WHERE COidConfiguracion = (
																SELECT EMidConfiguracion
																FROM FF_EMPRESA
																WHERE EMIDEMPRESA = @idempresa
																)
									)

			--IF ((@idempresa = 71) OR (@idempresa = 72) OR (@idempresa = 73))
			IF (@COCotizadorNuevo = 1)
			BEGIN
				IF @idempresa in(SELECT emidempresa from ff_empresa where emidestatus=1 AND emcostoxperiodo = 1)
				BEGIN
					print 'entro a cambiar costos'
					--  ACTUALIZAR PLANES PARA HABILITAR O DESHABILITAR --
					-- MOD BAT
					UPDATE tmp  SET Enabled =
						CASE WHEN p.PLEnabled = 0 THEN 'false'
						WHEN  p.PLEnabled = 1 AND p.PLEnabledDependiente=0 and tmp.emidparentesco<>1 THEN 'false' else 'true' END
					--ANT UPDATE tmp  SET Enabled= CASE p.PLEnabled WHEN 1 THEN 'true' ELSE 'false' END
					FROM #tmpPlanesFlexibles tmp
					INNER JOIN ff_Plan p  WITH (NOLOCK, READUNCOMMITTED)
						ON p.PLIdPlan=POIDPlan
					WHERE tmp.visible = 'true' AND tmp.Enabled='true'
                    -- candado 41 - inicio 3
					print 'valida parametro 222 - 3'
					if(@ValorPar <> '')
					begin
						EXEC ff_evaluaCandado_41 @idEmpresa, @idEmpleado;
					end
					-- candado 41 - fin 3
					SELECT   id, EMApellidoMaterno, EMApellidoPaterno, EMNombre1, EMNombre2, EMIdParentesco, TCidTarifaCosto, TCidTarifa, TCidPlanOpcion,
						TCidTipoTarifa, TCidGrupoParentesco, TCidParentesco, TCidSexo, TCEdad, TCidTipoFumador,
						CASE PLidRamo WHEN 347 THEN TCPrimaNeta ELSE TCPrimaNeta/@CantidadPago END AS TCPrimaNeta, --mod BAT
						CASE PLidRamo WHEN 347 THEN TCPrimaTotal ELSE TCPrimaTotal/@CantidadPago END AS TCPrimaTotal, POidPlanoPCION, POidPlan, PONombre, PODescripcion, POCaptura, PLNombre, PLDescripcion, PLidRamo, PLCoberturaForzosaTitular, RANombre, RADescripcion, PARENTESCOSDESCRIPCION, IDPARENTESCO, PADESCRIPCION, Checked, Visible, Enabled, HTMLControl, cantidad, archivo, RAimg, PLimg, POimg, raorden, plorden , poorden,ArchivoPlan, gpidGrupo, gpGrupoEtiqueta, gpRutaImagenGrupo,plAyuda
					FROM #tmpPlanesFlexibles
					INNER JOIN bf_GrupoPlanesCorporativo  WITH (NOLOCK, READUNCOMMITTED)
						ON POidPlan = gpidPlan AND gpidEstatus= 1
					WHERE    visible = 'true'
					ORDER BY gpidGrupo,raorden, plorden, poorden, idparentesco, EMIdParentesco
					OPTION (KEEP PLAN)
				END
				ELSE
				BEGIN
					-- candado 41 - inicio 4
					print 'valida parametro 222 - 4'
					if(@ValorPar <> '')
					begin
						EXEC ff_evaluaCandado_41 @idEmpresa, @idEmpleado;
					end
					-- candado 41 - fin 4
					SELECT   id, EMApellidoMaterno, EMApellidoPaterno, EMNombre1, EMNombre2, EMIdParentesco, TCidTarifaCosto, TCidTarifa, TCidPlanOpcion,
									TCidTipoTarifa, TCidGrupoParentesco, TCidParentesco, TCidSexo, TCEdad, TCidTipoFumador, TCPrimaNeta, TCPrimaTotal, POidPlanoPCION,
									POidPlan, PONombre, PODescripcion, POCaptura, PLNombre, PLDescripcion, PLidRamo, PLCoberturaForzosaTitular, RANombre, RADescripcion,
									PARENTESCOSDESCRIPCION, IDPARENTESCO, PADESCRIPCION, Checked, Visible, Enabled, HTMLControl, cantidad, archivo, RAimg, PLimg, POimg,
									raorden, plorden , poorden , ArchivoPlan, gpidGrupo,gpGrupoEtiqueta, gpRutaImagenGrupo,plAyuda
					FROM #tmpPlanesFlexibles
					INNER JOIN bf_GrupoPlanesCorporativo  WITH (NOLOCK, READUNCOMMITTED)
						ON POidPlan = gpidPlan AND gpidEstatus= 1
					WHERE  visible = 'true'
					ORDER BY gpidGrupo,raorden, plorden, poorden, idparentesco, EMIdParentesco
					OPTION (KEEP PLAN)
				END
			END
			ELSE
			BEGIN
				IF @idempresa in(SELECT emidempresa from ff_empresa where emidestatus=1 AND emcostoxperiodo = 1)
				BEGIN
					print 'entro a cambiar costos'
					-- candado 41 - inicio 5
					print 'valida parametro 222 - 5'
					if(@ValorPar <> '')
					begin
						EXEC ff_evaluaCandado_41 @idEmpresa, @idEmpleado;
					end
					-- candado 41 - fin 5
					SELECT   id, EMApellidoMaterno, EMApellidoPaterno, EMNombre1, EMNombre2, EMIdParentesco, TCidTarifaCosto, TCidTarifa, TCidPlanOpcion,
						TCidTipoTarifa, TCidGrupoParentesco, TCidParentesco, TCidSexo, TCEdad, TCidTipoFumador,
						CASE PLidRamo WHEN 347 THEN TCPrimaNeta ELSE TCPrimaNeta/@CantidadPago END AS TCPrimaNeta,  --mod BAT
						CASE PLidRamo WHEN 347 THEN TCPrimaTotal ELSE TCPrimaTotal/@CantidadPago END AS TCPrimaTotal, POidPlanoPCION, POidPlan, PONombre, PODescripcion, POCaptura, PLNombre, PLDescripcion, PLidRamo, PLCoberturaForzosaTitular, RANombre, RADescripcion, PARENTESCOSDESCRIPCION, IDPARENTESCO, PADESCRIPCION, Checked, Visible, Enabled, HTMLControl, cantidad, archivo, RAimg, PLimg, POimg, raorden, plorden , poorden,ArchivoPlan
					FROM #tmpPlanesFlexibles
					WHERE visible = 'true'
					ORDER BY raorden, plorden, poorden, idparentesco, EMIdParentesco
					OPTION (KEEP PLAN)
				END
				ELSE
				BEGIN
					-- candado 41 - inicio 6
					print 'valida parametro 222 - 6'
					if(@ValorPar <> '')
					begin
						EXEC ff_evaluaCandado_41 @idEmpresa, @idEmpleado;
					end
					-- candado 41 - fin 6
					SELECT  id, EMApellidoMaterno, EMApellidoPaterno, EMNombre1, EMNombre2, EMIdParentesco, TCidTarifaCosto, TCidTarifa, TCidPlanOpcion,
								TCidTipoTarifa, TCidGrupoParentesco, TCidParentesco, TCidSexo, TCEdad, TCidTipoFumador, TCPrimaNeta, TCPrimaTotal, POidPlanoPCION,
								POidPlan, PONombre, PODescripcion, POCaptura, PLNombre, PLDescripcion, PLidRamo, PLCoberturaForzosaTitular, RANombre, RADescripcion,
								PARENTESCOSDESCRIPCION, IDPARENTESCO, PADESCRIPCION, Checked, Visible, Enabled, HTMLControl, cantidad, archivo, RAimg, PLimg, POimg,
								raorden, plorden , poorden , ArchivoPlan
					FROM #tmpPlanesFlexibles
					WHERE visible = 'true'
					ORDER BY raorden, plorden, poorden, idparentesco, EMIdParentesco
					OPTION (KEEP PLAN)
				END
			END

			/*VALIDA QUE SI EXISTAN PLANES A COTIZAR PARA QUE TE MUESTRE LOS BOTONES*/
			-- MOD BAT 19072006
			SET @Bandera=0

			SELECT @Bandera = COUNT(TCidTarifaCosto)
			FROM #tmpPlanesFlexibles
			-- INICIA MOD BAT 06072017
			WHERE Checked = 'true'

		   IF @Bandera>0 AND @ExedeLimite=0
		   BEGIN
				DECLARE @TextoBoton varchar(50), @Result int
						  --ID DE LA EMPRESA,ID DEL PARAMETRO,TEXTO DE SALIDA
				EXECUTE @Result = dbo.ff_GetParametroValor @idEmpresa,18,@TextoBoton OUT

			IF @TextoBoton=''
			BEGIN
			  SET @TextoBoton = 'Guardar CotizaciÃ³n'
			END

			IF @TextoBoton<>'NOVISIBLE'
			BEGIN
				INSERT INTO @tmpBotones
				SELECT @TextoBoton AS Boton, 1 as tipo
			END

			EXECUTE @Result = dbo.ff_GetParametroValor @idEmpresa,19,@TextoBoton OUT

			IF      @TextoBoton=''
			BEGIN
			  set @TextoBoton = 'Imprimir CotizaciÃ³n'
			END
			--MOD BAT 08112016
			  IF @TextoBoton<>'NOVISIBLE'
			  BEGIN
					INSERT INTO @tmpBotones
				   SELECT @TextoBoton AS Boton, 3 as tipo
			  END   --END MOD  08112016
			EXECUTE @Result = dbo.ff_GetParametroValor @idEmpresa,20,@TextoBoton OUT

			IF      @TextoBoton=''
			BEGIN
			  set @TextoBoton = 'Generar Solicitud'
			END


			IF ISNULL((SELECT sum(cantidad) FROM @edocuenta WHERE descripcion LIKE '%PAGO REFERENCIADO%'),0)>0
			BEGIN
				INSERT INTO #Mensajes
				VALUES ('LA SELECCION ES MAYOR A TU DESCUENTO MAXIMO. TENDRAS QUE HACER EL PAGO DE LA DIFERENCIA.','Error')
			END

			IF @idEmpresa in(197,166,167,506,546,547,548) -- MOD BAT Parametrizar condiciÃ³n de no sobrante de crÃ©ditos
			BEGIN
				--IF ISNULL((SELECT sum(cantidad) FROM @edocuenta WHERE descripcion LIKE '%CRÃ‰DITOS DISPO%'),0)<=0
				--IF ISNULL((SELECT sum(cantidad) FROM @edocuenta WHERE descripcion LIKE '%CRÃ‰DITOS MENSUAL DISPONIBLES%'),0)<=0
				IF ISNULL((SELECT sum(cantidad) FROM @edocuenta WHERE tipo=4 and abono=1),0)<=0
				BEGIN
					INSERT INTO @tmpBotones
					SELECT @TextoBoton AS Boton, 7 as tipo
				END
				ELSE
				BEGIN
					IF @idempresa=197
					BEGIN
						SET @TextoBoton = 'No puedes generar solicitud existen sobrantes'
						--INSERT INTO @tmpBotones
						--SELECT '<INPUT class="ClaBoton" onclick="" Enabled="false" type="button" value="'+@TextoBoton+'"/>' as Boton
					END
					ELSE
					BEGIN
						INSERT INTO #Mensajes
						VALUES('MODIFICA TU SELECCIÃ“N DE DÃAS, NO TE PUEDEN SOBRAR CRÃ‰DITOS.','Error')
						SET @TextoBoton = 'No puedes generar solicitud existen sobrantes'
					END
				END
			END
			ELSE
			BEGIN
			  --MOD BAT 08112016
			  IF @TextoBoton<>'NOVISIBLE'
			  BEGIN
				INSERT INTO @tmpBotones
				SELECT @TextoBoton AS Boton, 7 as tipo
			  END   --END MOD  08112016
			  --    FIN MOD BAT 02/12/2009
			  -- FIN MOD BAT 19072006
			END
		END

		IF (@Transfer = 'Cancel')
		BEGIN
			/*PROCESO DE TRANSFERENCIA, MOSTRAR LOS PLANES INHABILITADOS Y HABILITAR UN BOTON PARA REALIZAR LA BAJA DEL EMPLEADO*/
			INSERT INTO @tmpBotones
			SELECT @TextoBoton AS Boton, 4 as tipo
		END
	END
END

END

ELSE
BEGIN
	-- candado 41 - inicio 7
		print 'valida parametro 222 - 7'
		if(@ValorPar <> '')
		begin
			EXEC ff_evaluaCandado_41 @idEmpresa, @idEmpleado;
		end
	-- candado 41 - fin 7
	SELECT  id, EMApellidoMaterno, EMApellidoPaterno, EMNombre1, EMNombre2, EMIdParentesco, TCidTarifaCosto, TCidTarifa, TCidPlanOpcion, TCidTipoTarifa, TCidGrupoParentesco, TCidParentesco, TCidSexo, TCEdad, TCidTipoFumador, TCPrimaNeta, TCPrimaTotal, POidPlanoPCION, POidPlan, PONombre, PODescripcion, POCaptura, PLNombre, PLDescripcion, PLidRamo, PLCoberturaForzosaTitular, RANombre, RADescripcion, PARENTESCOSDESCRIPCION, IDPARENTESCO, PADESCRIPCION,
      Checked, Visible, 'false' as Enabled, HTMLControl, cantidad, archivo, RAimg, PLimg, POimg, raorden, plorden,  poorden
	FROM #tmpPlanesFlexibles
	WHERE visible = 'true' and checked = 'true'
	ORDER BY raorden, plorden, poorden, idparentesco, EMIdParentesco
	OPTION (KEEP PLAN)

	INSERT INTO @tmpBotones
	SELECT '<B>"Solicitud pendiente de autorizaciÃ³n"</B>' AS Boton,  0 AS tipo
END

SELECT DISTINCT descripcion as descripcionMensaje, tipo
FROM #Mensajes
OPTION (KEEP PLAN)

--MOD BAT
IF (SELECT COUNT ( ECidEdocuentaConcepto )
	FROM [dbo].[ff_EdoCuentaConcepto]
	WHERE ECidConfiguracion = @IdConfiguracion
		AND ECidEstatus = 1
		AND ECVisible=0
		AND ECNombre like 'CrÃ©di%')>0 and @IdConfiguracion NOT IN(104,109)
BEGIN
	DELETE @edocuenta
	WHERE (descripcion LIKE 'crÃ©%' OR descripcion LIKE 'Descu%')
		AND descripcion NOT IN('DESCUENTO MÃXIMO ANUAL POR NÃ“MINA ','DESCUENTO ANUAL DISPONIBLE ')
END
-- MOD BAT abril 2016
ELSE IF @idEmpresa=439
BEGIN
	SET @MontoBPSF = ISNULL((
							SELECT SUM(CETotalCreditos)
							FROM FF_Compensacionempleado WITH(NOLOCK, READUNCOMMITTED)
							WHERE CEIdCompensacion=211 and CEIDempleado=@idEmpleado),0)

	INSERT INTO @edocuenta
	VALUES('3','BOLSA PREVISIÃ“N SOCIAL FLEX ' +@PeridicidadNombre , @MontoBPSF/ @CantidadPago,'0')

	INSERT INTO @edocuenta
	VALUES('7','SOBRANTE BOLSA PREV. SOCIAL FLEX '+@PeridicidadNombre, (SELECT SUM(Cantidad) FROM #CreditosOtorgadosEX)/ @CantidadPago,'1')
	--MOD BAT
	SET @MontosOBRANTE = (SELECT SUM(CANTIDAD) FROM @edocuenta WHERE tipo=4 and abono=1 )
	--PRINT 'SOBRANTE '
	--PRINT @MontosOBRANTE
	--PRINT @MontoBPSF/12
	IF @MontosOBRANTE>(@MontoBPSF/12) and @MontosOBRANTE>0
	BEGIN
		UPDATE @edocuenta SET CANTIDAD=CANTIDAD-(@MontoBPSF/ @CantidadPago) where tipo=4 and abono=1
	END
	--FIN MOD
	UPDATE C SET descripcion = ECDescripcion
	FROM @edocuenta C
	INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=2 AND ECIdEdoCuentaConcepto=1 AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
	WHERE ECIDESTATUS = 1
END
-- fin  mod BAT abril 2016
ELSE IF (
		SELECT COUNT ( ECidEdocuentaConcepto )
		FROM [dbo].[ff_EdoCuentaConcepto]
		WHERE ECidConfiguracion = @IdConfiguracion
			AND ECidEstatus = 1
			AND ECVisible=0
			AND ECNombre like 'NVCrÃ©di%' )>0
BEGIN
	DECLARE @DESC VARCHAR(200)
	SET @DESC =ISNULL((SELECT COUNT ( ECidEdocuentaConcepto )
	FROM [dbo].[ff_EdoCuentaConcepto]
	WHERE ECidConfiguracion = @IdConfiguracion AND ECidEstatus = 1
		AND ECVisible=0 AND ECidEdoCuentaConcepto=15),'')

	DELETE @edocuenta
	WHERE (descripcion LIKE 'crÃ©%')

	IF @DESC<>''
	BEGIN
		UPDATE @edocuenta SET descripcion=REPLACE(descripcion,'DESCUENTO MÃXIMO','CAPACIDAD DE DESCUENTO')
		WHERE descripcion LIKE '%DESCUENTO MÃXIMO%'
		UPDATE @edocuenta SET descripcion=REPLACE(descripcion,'DESCUENTO','CAPACIDAD DE DESCUENTO')
		WHERE descripcion LIKE 'DESCUENTO%' AND descripcion LIKE '%DISPONIBLE'
		DELETE @edocuenta
		WHERE (descripcion LIKE 'COSTO SELECCIÃ“N%' ) or (descripcion LIKE 'COSTO A%' )
	END
END

IF @IdConfiguracion =25
BEGIN
	--SET @CRED =  ISNULL(.02*(SELECT  sum(cantidad)  FROM #CreditosOtorgados WHERE idcompensacion=70),0)
	SET @COSTOEXC =
		CASE WHEN @idPerfil IN(492,1705) THEN .5*(SELECT SUM(TCPRIMATOTAL)FROM #tmpPlanesFlexibles WHERE TCIDPLANOPCION in(5142,5916))   ELSE 0 END
	SET @COSTOEXC = ISNULL(@COSTOEXC,0)
	--SET @COSTOGMM = CASE WHEN @idPerfil IN(492,1705) AND @CRED<600 THEN @CRED*12 WHEN @idPerfil IN(492,1705) AND @CRED>600 THEN 600*12 WHEN @idPerfil IN(490,1706,1707,1708,1760,1761,1762) THEN @CRED*12 ELSE 0 END
	SET @COSTOGMM = CASE WHEN @idPerfil IN(492,1705,1706,1707,1708,1760,1761,1762) AND @CRED<600 THEN @CRED*12 WHEN @idPerfil IN(492,1705,1706,1707,1708,1760,1761,1762) AND @CRED>600 THEN 600*12 WHEN @idPerfil IN(490) THEN @CRED*12 ELSE 0 END

	--INSERT INTO @edocuenta
	--SELECT '9', 'DESCUENTO A' + @PeridicidadNombre, (@COSTOEXC +@COSTOGMM) /@CantidadPago, '0'

	IF @idPerfil IN( 492,490,1705,1706,1707,1708,1760,1761,1762)--MOD AFDP
	BEGIN
		INSERT INTO @edocuenta
		SELECT '7', 'DESCUENTO ' + @PeridicidadNombre, (@COSTOEXC +@COSTOGMM) /@CantidadPago, '0'
	END

	IF @idPerfil IN( 492,1705) --MOD AFDP
	BEGIN
		if (SELECT  SUM(CANTIDAD)-((@COSTOEXC*2)/12) FROM @edocuenta WHERE TIPO = 4 AND abono = 0) < 0
		BEGIN
			--    PRINT 'eNTRO'
			--SELECT  * from @edocuenta WHERE TIPO IN(3,4) AND abono = 0
			INSERT INTO @edocuenta values('4','CRÃ‰DITOS DISPONIBLES '+@PeridicidadNombre, (SELECT (CANTIDAD-((@COSTOEXC*2)/12))*-1 FROM @edocuenta WHERE TIPO= 4 AND ABONO=0),'1')
			UPDATE @edocuenta SET CANTIDAD= 0 WHERE TIPO = 4 AND abono = 0
			UPDATE @edocuenta SET CANTIDAD= CANTIDAD-((@COSTOEXC*2)/12) WHERE TIPO= 3 AND abono = 0
		END
		ELSE
		BEGIN
			UPDATE @edocuenta SET CANTIDAD= CANTIDAD-((@COSTOEXC*2)/12) WHERE TIPO IN(3,4) AND abono = 0
		END
	END

    IF @idPerfil IN(492,490,1705,1706,1707,1708,1760,1761,1762)--MOD AFDP
    BEGIN
		UPDATE @edocuenta SET CANTIDAD = CANTIDAD + (SELECT CANTIDAD FROM @edocuenta WHERE TIPO = 4 AND abono = 0) WHERE TIPO = '7' AND abono = 0
    END
	--SELECT '9', 'DESCUENTO A' + @PeridicidadNombre, 1200 /@CantidadPago, '0'
    ELSE IF @idPerfil NOT IN(492,490,1705,1706,1707,1708,1760,1761,1762) --MOD AFDP
    BEGIN
		DELETE @edocuenta WHERE TIPO IN(9,7)
    END
END



IF (@IdConfiguracion IN(53,62,74,87,25,104,114,155,27,97))
BEGIN
	UPDATE C SET descripcion=ECDescripcion
    FROM @edocuenta C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=3 AND ECIdEdoCuentaConcepto=5
		AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1

    UPDATE C SET descripcion = ECDescripcion
    FROM @edocuenta C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=2 AND ECIdEdoCuentaConcepto=1
		AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1

    UPDATE C SET descripcion = ECDescripcion
    FROM @edocuenta C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=4 AND ECIdEdoCuentaConcepto=10
		AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1

    UPDATE C SET descripcion=ECDescripcion
    FROM @edocuenta C
    INNER JOIN ff_EdoCuentaConcepto  WITH (NOLOCK, READUNCOMMITTED)
		ON C.TIPO = 4  AND ECIdEdoCuentaConcepto = 6
			AND ECidConfiguracion = @IdConfiguracion AND C.abono = 1
    WHERE ECIDESTATUS = 1
            AND C.Abono = 1

    DELETE @edocuenta
    WHERE TIPO = 4
		AND Abono = 1
		AND Cantidad = 0

    UPDATE C SET descripcion = ECDescripcion + CASE @idPerfil WHEN 492 THEN ' y Excesos' ELSE '' END
    FROM @edocuenta C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=9 AND ECIdEdoCuentaConcepto=9 AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1

    UPDATE C SET descripcion = ECDescripcion+ ' MENSUAL'
    FROM @edocuenta C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
	ON  C.TIPO=7 AND ECidEdoCuentaConcepto=11 AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1

    DELETE @edocuenta WHERE descripcion='DESCUENTO MENSUAL DISPONIBLE'

    IF @IdConfiguracion=27
    BEGIN
		UPDAte C SET descripcion = descripcion + ' Mensual'
		FROM @edocuenta C
    END
	--MOD 22102019 SE MODIFICA PARA QUE SE MUESTRE EN PANTALLA
	IF @IdConfiguracion=25
    BEGIN
	 Update @edocuenta set tipo= CASE tipo WHEN 4 THEN 7 WHEN 7 THEN 4 END where TIPO IN(4,7) AND abono=0
	END
	--FIN MOD 22102019

END

/*INICIO NUEVO ESTADO CUENTA*/

DECLARE	@valorParametro varchar(100)

EXEC	[dbo].[ff_GetParametroValor]
		@Empresa = @idEmpresa,
		@Parametro = 205,
		@Valor = @valorParametro OUTPUT

--SELECT	@valorParametro as N'@Valor'
/*
print 'PeridicidadNombre '
print @PeridicidadNombre
print 'CantidadPago '
print @CantidadPago
print 'DescuentoNomina  '
print @DescuentoNomina
print '@DDisponible  '
print @DDisponible
*/
if ( @valorParametro = '1' )
BEGIN
	/*
	INSERT INTO @edocuenta
      VALUES ('1', 'DESCUENTO MÃXIMO ' + @PeridicidadNombre
			+ ' POR NÃ“MINA ', @DescuentoNomina / @CantidadPago, '0')
			*/
	DECLARE @edocuentaParametro TABLE
		(
			tipo VARCHAR(1) NULL,
			descripcion VARCHAR(200) NULL,
			cantidad MONEY NULL,
			abono CHAR(1) NULL,
			orden int NULL
		)
	insert into @edocuentaParametro
		select tipo, descripcion, cantidad, abono, null from @edocuenta

	UPDATE C SET descripcion=ECDescripcion + ' - ' + @PeridicidadNombre, cantidad=(@DescuentoNomina / @CantidadPago), orden= ECorden
    FROM @edocuentaParametro C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=1 AND ECIdEdoCuentaConcepto=20
		AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1

	UPDATE C SET descripcion=ECDescripcion + ' - ' + @PeridicidadNombre, cantidad=(@DDisponible / @CantidadPago), orden= ECorden
    FROM @edocuentaParametro C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=3 AND ECIdEdoCuentaConcepto=21
		AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1

     UPDATE C SET descripcion = ECDescripcion+ ' - ' + @PeridicidadNombre, orden= ECorden
    FROM @edocuentaParametro C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=2 AND ECIdEdoCuentaConcepto=1
		AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1
        UPDATE C SET descripcion = ECDescripcion+ ' - ' + @PeridicidadNombre, orden= ECorden
    FROM @edocuentaParametro C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=4 AND ECIdEdoCuentaConcepto=10
		AND ECidConfiguracion=@IdConfiguracion AND C.abono = 0
    WHERE ECIDESTATUS = 1

	--declare @montoSOB money;
	--	set @montoSOB = isnull(@MontosOBRANTE, 0);

	--UPDATE C SET descripcion = ECDescripcion+ ' - ' + @PeridicidadNombre, cantidad = @montoSOB, orden= ECorden
 --   FROM @edocuentaParametro C
 --   INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
	--	ON  C.TIPO=3 AND ECIdEdoCuentaConcepto=8
	--	AND ECidConfiguracion=@IdConfiguracion AND C.abono = 1
 --   WHERE ECIDESTATUS = 1

 --       UPDATE C SET descripcion=ECDescripcion+ ' - ' + @PeridicidadNombre,  cantidad = @Creditos/@CantidadPago, orden= ECorden
 --   FROM @edocuentaParametro C
 --   INNER JOIN ff_EdoCuentaConcepto  WITH (NOLOCK, READUNCOMMITTED)
	--	ON C.TIPO = 4  AND ECIdEdoCuentaConcepto = 6
	--		AND ECidConfiguracion = @IdConfiguracion AND C.abono = 1
 --   WHERE ECIDESTATUS = 1
 --           AND C.Abono = 1

 -- MOD JLVS 141019
	declare @montoSOB money;

	        SET @montoSOB =(SELECT  cantidad
		    FROM @edocuentaParametro C
    		WHERE C.TIPO = 2  AND  C.abono = 0)-(SELECT  cantidad
		    FROM @edocuentaParametro C
    		WHERE C.TIPO = 4  AND  C.abono = 1)

		set @montoSOB = isnull(@montoSOB, 0);
	UPDATE C SET descripcion = ECDescripcion+ ' - ' + @PeridicidadNombre, cantidad = @montoSOB, orden= ECorden
    FROM @edocuentaParametro C
    INNER JOIN [dbo].[ff_EdoCuentaConcepto]  WITH (NOLOCK, READUNCOMMITTED)
		ON  C.TIPO=3 AND ECIdEdoCuentaConcepto=8
		AND ECidConfiguracion=@IdConfiguracion AND C.abono = 1
    WHERE ECIDESTATUS = 1

        UPDATE C SET descripcion=ECDescripcion+ ' - ' + @PeridicidadNombre,  cantidad = cantidad/*/@CantidadPago*/, orden= ECorden
    FROM @edocuentaParametro C
    INNER JOIN ff_EdoCuentaConcepto  WITH (NOLOCK, READUNCOMMITTED)
		ON C.TIPO = 4  AND ECIdEdoCuentaConcepto = 6
			AND ECidConfiguracion = @IdConfiguracion AND C.abono = 1
    WHERE ECIDESTATUS = 1
            AND C.Abono = 1

 -- MOD JLVS 141019

END

/*FIN NUEVO ESTADO CUENTA*/
--PRUEBA DEL ESTADO DE CUENTA
--delete from @edocuenta where tipo in (1,2,3);
--TERMINA PRUEBA

--modificando totales del edoCuenta aplicando excedentes.

declare @excedenteCalculo money,
@excedenteTotal money,
@excedenteMenos money;

SELECT @excedenteCalculo = ISNULL(Sum(cetotalcreditos), 0.00)
FROM   dbo.ff_compensacion WITH (NOLOCK, READUNCOMMITTED)
    INNER JOIN dbo.ff_compensacionconfiguracion WITH (NOLOCK, READUNCOMMITTED)
        ON coidcompensacion = ccidcompensacion
    INNER JOIN dbo.ff_compensacionempleado WITH (NOLOCK, READUNCOMMITTED)
        ON coidcompensacion = ceidcompensacion
WHERE  coidestatus = 1
    AND ccidperfil = @idPerfil
    AND ccexcedente = '1'
    AND ceidempleado = @idEmpleado
    AND CCCreditos = 0
GROUP  BY coidcompensacion
OPTION (keep PLAN)

--print 'excedente del empleado';
--print ISNULL(@excedenteCalculo, 0.00);

IF (ISNULL(@excedenteCalculo, 0.00) <> 0.00)
BEGIN
	print 'Excedentes en Edo'
	select @excedenteMenos = ISNULL(Sum(tcprimatotal), 0.00) from #tmpPlanesFlexibles where checked = 'TRUE' and poidplan in (
		select plidplan from ff_plan where plidplan in (
			select POIdplan from #tmpPlanesFlexibles where checked = 'TRUE'
		) and PLFondodeAhorro = 1
	);
	--print'saco que resta';
	--print @excedenteMenos;
	set @excedenteMenos = (@excedenteMenos/@CantidadPago);
	--print @excedenteMenos;
	--print @CantidadPago;
	set @excedenteCalculo = (@excedenteCalculo/@CantidadPago) - @excedenteMenos;
	--print @excedenteCalculo
	select @excedenteTotal = cantidad from @edocuenta
		where tipo = 4 and abono = 0;
	IF (ISNULL(@excedenteTotal, 0.00) <> 0.00)
	BEGIN
		IF (@excedenteTotal > @excedenteCalculo)
		BEGIN
			--print 'total al que le va a quitar'
			--print @excedenteTotal
			set @excedenteTotal  = (@excedenteTotal - @excedenteCalculo);
			--print @excedenteTotal
		END
		ELSE
		BEGIN
			set @excedenteTotal  = 0.00;
		END

		update @edocuenta set cantidad = @excedenteTotal
		where tipo = 4 and abono = 0;

	END



END
ELSE
BEGIN
--Parte para validar los planes y restarlos
print 'Excedentes edo else';
	select @excedenteMenos = ISNULL(Sum(tcprimatotal), 0.00) from #tmpPlanesFlexibles where checked = 'TRUE' and poidplan in (
		select plidplan from ff_plan where plidplan in (
			select POIdplan from #tmpPlanesFlexibles where checked = 'TRUE'
		) and PLFondodeAhorro = 1
	);
	--print @excedenteMenos;
	set @excedenteMenos = (@excedenteMenos/@CantidadPago);
	--print @excedenteMenos;
	select @excedenteTotal = cantidad from @edocuenta
		where tipo = 4 and abono = 0;

	IF (ISNULL(@excedenteTotal, 0.00) <> 0.00)
	BEGIN
		IF (@excedenteTotal > @excedenteMenos)
		BEGIN
			--print 'total al que le va a quitar'
			--print @excedenteTotal
			set @excedenteTotal  = (@excedenteTotal + @excedenteMenos);
			--print @excedenteTotal
		END
		ELSE
		BEGIN
			set @excedenteTotal  = 0.00;
		END

		update @edocuenta set cantidad = @excedenteTotal
		where tipo = 4 and abono = 0;
	END
END

--select @excedenteCalculo, (@excedenteCalculo/@CantidadPago), @CantidadPago
--termina modificacion excedentes

if ( @valorParametro = '1' )
BEGIN
--con parametro
	SELECT tipo,
		descripcion,
		ISNULL(Sum(cantidad), 0.00) AS cantidad,
		abono
	FROM @edocuentaParametro
	GROUP BY tipo,
		descripcion,
		abono,
		orden
	ORDER  BY orden
OPTION (keep PLAN)
end
else
begin
--normal
	SELECT tipo,
		descripcion,
		ISNULL(Sum(cantidad), 0.00) AS cantidad,
		abono
	FROM @edocuenta
	GROUP BY tipo,
		descripcion,
		abono
	ORDER  BY tipo
	OPTION (keep PLAN)
end

SET @PaginaInicio = (SELECT ISNULL(Rtrim(pavalor), '../Comun/incio.aspx')
					FROM ff_parametro
					INNER JOIN ff_empresa WITH (NOLOCK, READUNCOMMITTED)
						ON paidempresa = emidcorporativo
                     WHERE  paid = 71 AND emidempresa = @idEmpresa)

IF @PaginaInicio = '../WizardEnrollment/bf_WizardEnrollment.aspx'
	AND @idEmpresa NOT IN(114, 115, 185, 186, 187, 188, 248, 249, 66, 67, 92, 93, 262, 236, 261,290, 332)
BEGIN
	SELECT boton FROM @tmpBotones WHERE boton = '-'
END
ELSE IF ( @PaginaInicio = '../WizardEnrollment/bf_WizardEnrollment.aspx') AND @idEmpresa
IN(114, 115, 185, 186, 187, 188, 248, 249, 66, 67, 92, 93, 262, 236, 261, 290,332)
BEGIN
	SELECT * FROM @tmpBotones WHERE boton LIKE '%GuardaCotizacion%'
END
ELSE
BEGIN
	SELECT * FROM @tmpBotones OPTION (keep plan)
END

SELECT ff_plan.plsami,
       PLO.povalorsumaasegurada,
       emp.emsalariobase,
       tm.id,
       tcidtarifacosto,
       tcidtarifa,
       tcidplanopcion,
       tcprimaneta,
       tcprimatotal,
       tm.poidplanopcion,
       tm.poidplan,
       tm.plnombre,
       tm.pldescripcion
FROM   #tmpplanesflexibles AS tm
LEFT JOIN ff_plan WITH (NOLOCK, READUNCOMMITTED)
	ON plidplan = poidplan
RIGHT JOIN ff_planopcion AS PLO WITH (NOLOCK, READUNCOMMITTED)
	ON PLO.poidplan = plidplan
	AND PLO.poidplanopcion = tm.tcidplanopcion
	AND povalorsumaasegurada IS NOT NULL
	AND povalorsumaasegurada != '0.00'
INNER JOIN ff_empleado AS emp WITH (NOLOCK, READUNCOMMITTED)
	ON tm.id = emp.id
	AND emp.emidparentesco = 1
WHERE  checked = 'true'
	AND tm.idparentesco = 1
	AND tm.poidplan IN (SELECT plidplan
						FROM   ff_plan
						WHERE  plsami != '0.00'
							AND plidplan IN (SELECT poidplan
											FROM   #tmpplanesflexibles
											WHERE  checked = 'true'
											)
						)

END
--------------------------------------------------------------------------------------------------------------------------------------------
--mod iogf
IF @idEmpresa = 572
BEGIN
	EXEC ff_insertabectonMenores @idEmpresa, 451, @idEmpleado
END
END
GO

