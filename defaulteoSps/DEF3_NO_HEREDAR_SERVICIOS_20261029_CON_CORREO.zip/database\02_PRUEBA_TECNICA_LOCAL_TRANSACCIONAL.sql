USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

/*
  CAT: prueba tecnica local de los dos motores def3.

  La prueba usa datos QADEF3D-186 ya existentes en la base local y agrega
  selecciones y un plan basico sinteticos dentro de una transaccion. Todo se
  revierte al final.

  Resultado esperado en ambos SP:
    - opcion individual opcional: solo titular;
    - opcion forzosa: titular y dependiente;
    - tarifa grupal: titular y dependiente del grupo vigente.
    - plan basico del dependiente nuevo: seleccionado.
*/

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Solicitud
    WHERE SOIdSolicitud = 3279087
      AND SOIdEmpleado = 7314560
      AND SOIdEmpresa = 186
)
    THROW 51000, 'No existe el fixture local QADEF3D-186.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanOpcion
    WHERE POIdPlanOpcion = 12959
      AND POOpcionForzosa = '1'
)
    THROW 51000, 'La opcion 12959 ya no esta configurada como forzosa.', 1;

DECLARE
    @ActualOpcionalTitular BIT,
    @ActualOpcionalDependiente BIT,
    @ActualForzosaTitular BIT,
    @ActualForzosaDependiente BIT,
    @ActualGrupalTitular BIT,
    @ActualGrupalDependiente BIT,
    @ActualBasicoDependiente BIT,
    @MultiOpcionalTitular BIT,
    @MultiOpcionalDependiente BIT,
    @MultiForzosaTitular BIT,
    @MultiForzosaDependiente BIT,
    @MultiGrupalTitular BIT,
    @MultiGrupalDependiente BIT,
    @MultiBasicoDependiente BIT;

BEGIN TRY
    BEGIN TRANSACTION;

    /*
      Plan basico sintetico del dependiente nuevo. Se revierte junto con toda
      la prueba y valida que no se pierdan sus coberturas obligatorias cuando
      el titular ya cuenta con selecciones anteriores.
    */
    DECLARE @IdPlanBasicoPrueba INT;

    INSERT INTO dbo.ff_PlanBasico
    (
        PBidVigencia, PBidPerfil, PBidPlanOpcion, PBFlexible,
        PBParentescoDefaulteo, PBFormaCredito, PBidEstatus,
        PBUsuarioAdd, PBFechaAdd, PBUsuarioUMod, PBFechaUMod,
        PBIdPlan, PBSoloCotizacion
    )
    VALUES
    (
        438, 18966, 1775, '0', 1, '0', 1,
        0, GETDATE(), 0, GETDATE(), 2050, 0
    );

    SET @IdPlanBasicoPrueba = SCOPE_IDENTITY();

    INSERT INTO dbo.ff_PlanBasicoDetalle
    (
        PBidPlanBasico, PBConsecutivo, PBidParentesco,
        PBidEstatus, PBUsuarioAdd, PBFechaAdd, PBUsuarioUMod, PBFechaUMod
    )
    VALUES
    (
        @IdPlanBasicoPrueba, 1, 2,
        1, 0, GETDATE(), 0, GETDATE()
    );

    /* Seleccion forzosa previa, registrada solamente para el titular. */
    INSERT INTO dbo.ff_PlanOpcionSeleccion
    (
        POIdPlanOpcionSeleccion,
        POIdEmpresaFlexiForbes,
        POIdEmpresa,
        PONumeroEmpleado,
        POIdEmpleado,
        POIdParentesco,
        POEdad,
        POIdGrupoParentesco,
        POIdPlanOpcion,
        POTarifaNeta,
        POIdSolicitud,
        POAnexo,
        POCostoRestante,
        POIdPeriodicidadPago,
        PORequiereAutorizacion,
        POIdVigencia,
        PODefaulteo,
        POIdEstatus,
        POUsuarioAdd,
        POFechaAdd,
        POAutorizado
    )
    VALUES
    (
        -910000001, 'S001', 186, 'QADEF3D-186', 7314560, 1, 41, NULL,
        12959, 0, 3279087, 0, 0, 8, '0', 438, 0, 1, 0, GETDATE(), 1
    );

    /* Seleccion grupal previa con un grupo diferente al grupo vigente. */
    INSERT INTO dbo.ff_PlanOpcionSeleccion
    (
        POIdPlanOpcionSeleccion,
        POIdEmpresaFlexiForbes,
        POIdEmpresa,
        PONumeroEmpleado,
        POIdEmpleado,
        POIdParentesco,
        POEdad,
        POIdGrupoParentesco,
        POIdPlanOpcion,
        POTarifaNeta,
        POIdSolicitud,
        POAnexo,
        POCostoRestante,
        POIdPeriodicidadPago,
        PORequiereAutorizacion,
        POIdVigencia,
        PODefaulteo,
        POIdEstatus,
        POUsuarioAdd,
        POFechaAdd,
        POAutorizado
    )
    VALUES
    (
        -910000002, 'S001', 186, 'QADEF3D-186', 7314560, NULL, 41, 11,
        12955, 0, 3279087, 0, 0, 8, '0', 438, 0, 1, 0, GETDATE(), 1
    );

    CREATE TABLE #tmpPlanesFlexibles
    (
        id INT NULL,
        EMApellidoMaterno VARCHAR(50) NULL,
        EMApellidoPaterno VARCHAR(50) NULL,
        EMNombre1 VARCHAR(50) NULL,
        EMNombre2 VARCHAR(50) NULL,
        EMIdParentesco INT NULL,
        TCIdTarifaCosto INT NULL,
        TCIdTarifa INT NULL,
        TCIdPlanOpcion INT NULL,
        TCIdTipoTarifa INT NULL,
        TCIdGrupoParentesco INT NULL,
        TCIdParentesco INT NULL,
        TCIdSexo INT NULL,
        TCEdad INT NULL,
        TCIdTipoFumador INT NULL,
        TCPrimaNeta MONEY NULL,
        TCPrimaTotal MONEY NULL,
        POIdPlanOpcion INT NULL,
        POIdPlan INT NULL,
        PONombre VARCHAR(50) NULL,
        PODescripcion VARCHAR(150) NULL,
        POCaptura CHAR(1) NULL,
        PLNombre VARCHAR(50) NULL,
        PLDescripcion VARCHAR(150) NULL,
        PLIdRamo INT NULL,
        PLCoberturaForzosaTitular VARCHAR(1) NULL,
        RANombre VARCHAR(50) NULL,
        RADescripcion VARCHAR(150) NULL,
        ParentescosDescripcion VARCHAR(150) NULL,
        IDPARENTESCO INT NULL,
        PADescripcion VARCHAR(150) NULL,
        Checked VARCHAR(10) NULL,
        Visible VARCHAR(10) NULL,
        Enabled VARCHAR(10) NULL,
        HTMLControl VARCHAR(500) NULL,
        Cantidad INT NULL,
        Archivo VARCHAR(200) NULL,
        RAImg VARCHAR(200) NULL,
        PLImg VARCHAR(200) NULL,
        POImg VARCHAR(200) NULL,
        RAOrden INT NULL,
        PLOrden INT NULL,
        POOrden INT NULL,
        ArchivoPlan VARCHAR(200) NULL,
        PLAyuda VARCHAR(MAX) NULL
    );

    /*
      1769: opcion individual opcional existente en la solicitud del fixture.
      1775: plan basico sintetico para el dependiente nuevo.
      12959: opcion individual forzosa agregada dentro de la transaccion.
      12955: opcion grupal agregada dentro de la transaccion.
    */
    INSERT INTO #tmpPlanesFlexibles
    (
        id, EMIdParentesco, TCIdPlanOpcion, TCIdTipoTarifa,
        TCIdGrupoParentesco, TCIdParentesco, POIdPlanOpcion,
        POIdPlan, IDPARENTESCO, Checked, Visible, Enabled
    )
    VALUES
        (7314560, 1, 1769, 1, NULL, 1, 1769, 549, 1, 'false', 'true', 'true'),
        (7314561, 2, 1769, 1, NULL, 2, 1769, 549, 2, 'false', 'true', 'true'),
        (7314560, 1, 1775, 1, NULL, 1, 1775, 2050, 1, 'false', 'true', 'true'),
        (7314561, 2, 1775, 1, NULL, 2, 1775, 2050, 2, 'false', 'true', 'true'),
        (7314560, 1, 12959, 1, NULL, 1, 12959, 3521, 1, 'false', 'true', 'true'),
        (7314561, 2, 12959, 1, NULL, 2, 12959, 3521, 2, 'false', 'true', 'true'),
        (7314560, 1, 12955, 2, 12, NULL, 12955, 3518, 12, 'false', 'true', 'true'),
        (7314561, 2, 12955, 2, 12, NULL, 12955, 3518, 12, 'false', 'true', 'true');

    EXEC dbo.ff_CBuscaPlanEspejoTest
        @NUMEROEMPLEADO = 'QADEF3D-186',
        @idEmpleado = 7314560,
        @idEmpresa = 186,
        @idPerfil = 18966,
        @GpoTitular = 1,
        @NUCLEOFAMILIAR = '0',
        @transfer = 'def3',
        @idVigenciaDestino = 438;

    SELECT
        @ActualOpcionalTitular = MAX(CASE WHEN POIdPlanOpcion = 1769 AND id = 7314560 AND Checked = 'true' THEN 1 ELSE 0 END),
        @ActualOpcionalDependiente = MAX(CASE WHEN POIdPlanOpcion = 1769 AND id = 7314561 AND Checked = 'true' THEN 1 ELSE 0 END),
        @ActualForzosaTitular = MAX(CASE WHEN POIdPlanOpcion = 12959 AND id = 7314560 AND Checked = 'true' THEN 1 ELSE 0 END),
        @ActualForzosaDependiente = MAX(CASE WHEN POIdPlanOpcion = 12959 AND id = 7314561 AND Checked = 'true' THEN 1 ELSE 0 END),
        @ActualGrupalTitular = MAX(CASE WHEN POIdPlanOpcion = 12955 AND id = 7314560 AND Checked = 'true' THEN 1 ELSE 0 END),
        @ActualGrupalDependiente = MAX(CASE WHEN POIdPlanOpcion = 12955 AND id = 7314561 AND Checked = 'true' THEN 1 ELSE 0 END),
        @ActualBasicoDependiente = MAX(CASE WHEN POIdPlanOpcion = 1775 AND id = 7314561 AND Checked = 'true' THEN 1 ELSE 0 END)
    FROM #tmpPlanesFlexibles;

    UPDATE #tmpPlanesFlexibles
    SET Checked = 'false', Visible = 'true', Enabled = 'true';

    EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
        @NUMEROEMPLEADO = 'QADEF3D-186',
        @idEmpleado = 7314560,
        @idEmpresa = 186,
        @idPerfil = 18966,
        @GpoTitular = 1,
        @NUCLEOFAMILIAR = '0',
        @transfer = 'def3',
        @idVigencia = 438,
        @idVigenciaDestino = 438;

    SELECT
        @MultiOpcionalTitular = MAX(CASE WHEN POIdPlanOpcion = 1769 AND id = 7314560 AND Checked = 'true' THEN 1 ELSE 0 END),
        @MultiOpcionalDependiente = MAX(CASE WHEN POIdPlanOpcion = 1769 AND id = 7314561 AND Checked = 'true' THEN 1 ELSE 0 END),
        @MultiForzosaTitular = MAX(CASE WHEN POIdPlanOpcion = 12959 AND id = 7314560 AND Checked = 'true' THEN 1 ELSE 0 END),
        @MultiForzosaDependiente = MAX(CASE WHEN POIdPlanOpcion = 12959 AND id = 7314561 AND Checked = 'true' THEN 1 ELSE 0 END),
        @MultiGrupalTitular = MAX(CASE WHEN POIdPlanOpcion = 12955 AND id = 7314560 AND Checked = 'true' THEN 1 ELSE 0 END),
        @MultiGrupalDependiente = MAX(CASE WHEN POIdPlanOpcion = 12955 AND id = 7314561 AND Checked = 'true' THEN 1 ELSE 0 END),
        @MultiBasicoDependiente = MAX(CASE WHEN POIdPlanOpcion = 1775 AND id = 7314561 AND Checked = 'true' THEN 1 ELSE 0 END)
    FROM #tmpPlanesFlexibles;

    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT
    'VIGENCIA_ACTUAL' AS motor,
    @ActualOpcionalTitular AS opcionalTitular,
    @ActualOpcionalDependiente AS opcionalDependiente,
    @ActualForzosaTitular AS forzosaTitular,
    @ActualForzosaDependiente AS forzosaDependiente,
    @ActualGrupalTitular AS grupalTitular,
    @ActualGrupalDependiente AS grupalDependiente,
    @ActualBasicoDependiente AS basicoDependienteNuevo
UNION ALL
SELECT
    'MULTIVIGENCIA',
    @MultiOpcionalTitular,
    @MultiOpcionalDependiente,
    @MultiForzosaTitular,
    @MultiForzosaDependiente,
    @MultiGrupalTitular,
    @MultiGrupalDependiente,
    @MultiBasicoDependiente;

IF NOT
(
    @ActualOpcionalTitular = 1
    AND @ActualOpcionalDependiente = 0
    AND @ActualForzosaTitular = 1
    AND @ActualForzosaDependiente = 1
    AND @ActualGrupalTitular = 1
    AND @ActualGrupalDependiente = 1
    AND @ActualBasicoDependiente = 1
    AND @MultiOpcionalTitular = 1
    AND @MultiOpcionalDependiente = 0
    AND @MultiForzosaTitular = 1
    AND @MultiForzosaDependiente = 1
    AND @MultiGrupalTitular = 1
    AND @MultiGrupalDependiente = 1
    AND @MultiBasicoDependiente = 1
)
    THROW 51000, 'Fallo la prueba: alguno de los dos SP no cumple la regla esperada.', 1;

SELECT 'PRUEBA_OK_SIN_CAMBIOS_PERMANENTES' AS resultado;
GO
