package com.lockton.WSBeFlex.DAO;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

class JDBCFfTitularCasosEspecialesTest {

    @Test
    void conservaLaReglaPropiaDeActualizacionDeDependientes() {
        assertEquals("def3", DefaulteoCasosEspecialesReglas.normalizarTipoMotor("def3"));
        assertEquals("def3", DefaulteoCasosEspecialesReglas.normalizarTipoMotor("3"));
        assertEquals("def3", DefaulteoCasosEspecialesReglas.normalizarTipoMotor(" DEF3 "));
    }

    @Test
    void conservaLosDemasTiposReconocidosPorElMotor() {
        assertEquals("def1", DefaulteoCasosEspecialesReglas.normalizarTipoMotor("def1"));
        assertEquals("def2", DefaulteoCasosEspecialesReglas.normalizarTipoMotor("def2"));
    }

    @Test
    void usaLaVigenciaSeleccionadaComoDestino() {
        assertEquals(2027, DefaulteoCasosEspecialesReglas.resolverIdVigenciaDestino(2027, 2026));
    }

    @Test
    void usaLaVigenciaVigenteCuandoNoHaySeleccionada() {
        assertEquals(2026, DefaulteoCasosEspecialesReglas.resolverIdVigenciaDestino(0, 2026));
    }

    @Test
    void tipoTresConservaLaVigenciaAnteriorRealComoRespaldo() {
        assertEquals(2025, DefaulteoCasosEspecialesReglas.resolverIdVigenciaAnteriorMotor(
                "def3", Integer.valueOf(2025), Integer.valueOf(2026)));
    }

    @Test
    void tipoTresUsaDestinoSiNoRecibeVigenciaAnterior() {
        assertEquals(2026, DefaulteoCasosEspecialesReglas.resolverIdVigenciaAnteriorMotor(
                "def3", null, Integer.valueOf(2026)));
    }

    @Test
    void tiposLegadosConservanElContratoDeVigenciaDestino() {
        assertEquals(2026, DefaulteoCasosEspecialesReglas.resolverIdVigenciaAnteriorMotor(
                "def1", Integer.valueOf(2025), Integer.valueOf(2026)));
        assertEquals(2026, DefaulteoCasosEspecialesReglas.resolverIdVigenciaAnteriorMotor(
                "def2", Integer.valueOf(2025), Integer.valueOf(2026)));
    }

    @Test
    void evitaDuplicarLaMismaTarifaDelMismoFamiliar() {
        Map<String, String> tarifas = new LinkedHashMap<>();

        assertTrue(DefaulteoCasosEspecialesReglas.agregarTarifaCostoUnica(tarifas, 101, "250.50", 9001));
        assertTrue(DefaulteoCasosEspecialesReglas.agregarTarifaCostoUnica(tarifas, 101, "250.50", 9001));

        assertEquals(1, tarifas.size());
        assertEquals(
                "<ROOT><TarifaCosto TCidTarifaCosto=\"101\" Costo=\"250.50\" idEmpleado=\"9001\"></TarifaCosto></ROOT>",
                DefaulteoCasosEspecialesReglas.construirXmlTarifas(tarifas));
    }

    @Test
    void conservaLaMismaTarifaCuandoCorrespondeAOtroFamiliar() {
        Map<String, String> tarifas = new LinkedHashMap<>();

        assertTrue(DefaulteoCasosEspecialesReglas.agregarTarifaCostoUnica(tarifas, 101, "250.50", 9001));
        assertTrue(DefaulteoCasosEspecialesReglas.agregarTarifaCostoUnica(tarifas, 101, "180.25", 9002));

        assertEquals(2, tarifas.size());
    }

    @Test
    void aceptaIdsNumericosDevueltosPorJdbc() {
        Map<String, String> tarifas = new LinkedHashMap<>();

        assertTrue(DefaulteoCasosEspecialesReglas.agregarTarifaCostoUnica(
                tarifas, BigDecimal.valueOf(101), BigDecimal.valueOf(250.50), BigDecimal.valueOf(9001)));

        assertEquals(1, tarifas.size());
    }

    @Test
    void descartaFilasSinIdentificadoresValidos() {
        Map<String, String> tarifas = new LinkedHashMap<>();

        assertFalse(DefaulteoCasosEspecialesReglas.agregarTarifaCostoUnica(tarifas, null, "250.50", 9001));
        assertFalse(DefaulteoCasosEspecialesReglas.agregarTarifaCostoUnica(tarifas, 101, null, 9001));
        assertFalse(DefaulteoCasosEspecialesReglas.agregarTarifaCostoUnica(tarifas, 101, "250.50", null));
        assertTrue(tarifas.isEmpty());
    }
}
