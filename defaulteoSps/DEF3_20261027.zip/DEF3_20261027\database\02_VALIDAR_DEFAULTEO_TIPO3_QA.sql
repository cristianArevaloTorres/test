USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*
  VALIDACION FUNCIONAL - DEFAULTEO DE CASOS ESPECIALES, TIPO 3

  SOLO LECTURA. No crea ni modifica informacion.

  Sustituir los dos identificadores por las solicitudes generadas en QA:
    - Antes: solicitud que todavia contiene al dependiente.
    - Despues: solicitud creada despues de eliminarlo y ejecutar el defaulteo.
*/
DECLARE @SolicitudAntes INT = 3296331;
DECLARE @SolicitudDespues INT = 3296332;

DECLARE @IdEmpresa INT;
DECLARE @IdEmpleado INT;
DECLARE @NumeroEmpleado VARCHAR(20);

SELECT
    @IdEmpresa = S.SOIdEmpresa,
    @IdEmpleado = S.SOIdEmpleado,
    @NumeroEmpleado = S.SONumEmpleado
FROM dbo.ff_Solicitud S
WHERE S.SOIdSolicitud = @SolicitudDespues;

IF @IdEmpleado IS NULL
BEGIN
    SELECT
        @IdEmpresa = S.SOIdEmpresa,
        @IdEmpleado = S.SOIdEmpleado,
        @NumeroEmpleado = S.SONumEmpleado
    FROM dbo.ff_Solicitud S
    WHERE S.SOIdSolicitud = @SolicitudAntes;
END;

/* 00. Confirma que los cuatro procedimientos corregidos estan instalados. */
SELECT
    '00_OBJETOS_INSTALADOS' AS bloque,
    O.name AS procedimiento,
    CASE WHEN P.object_id IS NULL THEN 'FALTA_CORRECCION'
         ELSE 'CORRECCION_INSTALADA'
    END AS resultado
FROM
(
    VALUES
        ('ff_CBuscaPlanEspejoTest'),
        ('ff_CBuscaPlanEspejoTestMultivigenciaBF3'),
        ('ff_CBuscaPlanesPerfil_V31Test'),
        ('ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3')
) O(name)
LEFT JOIN sys.parameters P
    ON P.object_id = OBJECT_ID('dbo.' + O.name)
   AND P.name = '@idVigenciaDestino'
ORDER BY O.name;

/* 01. Datos generales de las solicitudes comparadas. */
SELECT
    '01_SOLICITUDES' AS bloque,
    CASE S.SOIdSolicitud
        WHEN @SolicitudAntes THEN 'ANTES'
        WHEN @SolicitudDespues THEN 'DESPUES'
    END AS momento,
    S.SOIdSolicitud,
    S.SOIdEmpresa,
    S.SOIdEmpleado,
    S.SONumEmpleado,
    S.SOIdVigencia,
    S.SOEstatusSolicitud,
    S.SOFechaAdd,
    S.SOImporteTotal,
    S.SOImportePerido
FROM dbo.ff_Solicitud S
WHERE S.SOIdSolicitud IN (@SolicitudAntes, @SolicitudDespues)
ORDER BY S.SOIdSolicitud;

/*
  02. Familia actual.
  El dependiente eliminado debe aparecer INACTIVO o dejar de formar parte
  de esta familia; los familiares conservados deben continuar ACTIVOS.
*/
SELECT
    '02_FAMILIA_ACTUAL' AS bloque,
    E.Id AS idFamiliar,
    E.EMNumeroEmpleado,
    LTRIM(RTRIM(CONCAT(
        ISNULL(E.EMNombre1, ''), ' ', ISNULL(E.EMNombre2, ''), ' ',
        ISNULL(E.EMApellidoPaterno, ''), ' ', ISNULL(E.EMApellidoMaterno, '')
    ))) AS familiar,
    PA.PANombre AS parentesco,
    E.EMEdad,
    E.EMIdEstatus,
    E.EMFechaEstatus,
    CASE WHEN E.EMIdEstatus = 1 THEN 'ACTIVO' ELSE 'INACTIVO' END AS estadoActual
FROM dbo.ff_Empleado E
LEFT JOIN dbo.ff_Parentesco PA
    ON PA.PAidParentesco = E.EMIdParentesco
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMNumeroEmpleado = @NumeroEmpleado
ORDER BY E.EMIdParentesco, E.Id;

/*
  03. Familiares, grupos y planes de ambas solicitudes.
  Resultado esperado:
    - El dependiente eliminado no aparece en DESPUES.
    - Las opciones todavia elegibles se conservan.
    - El grupo parentesco y los importes corresponden a la familia actual.
*/
SELECT
    '03_PLANES_ANTES_DESPUES' AS bloque,
    CASE PS.POIdSolicitud
        WHEN @SolicitudAntes THEN 'ANTES'
        ELSE 'DESPUES'
    END AS momento,
    PS.POIdSolicitud,
    PS.POIdEmpleado AS idFamiliar,
    LTRIM(RTRIM(CONCAT(
        ISNULL(E.EMNombre1, ''), ' ', ISNULL(E.EMNombre2, ''), ' ',
        ISNULL(E.EMApellidoPaterno, ''), ' ', ISNULL(E.EMApellidoMaterno, '')
    ))) AS familiar,
    PA.PANombre AS parentesco,
    GP.GPNombre AS grupoParentesco,
    PL.PLNombre AS planNombre,
    PO.PONombre AS opcion,
    PS.POIdPlanOpcion,
    PS.POTarifaNeta,
    PS.POIdEstatus
FROM dbo.ff_PlanOpcionSeleccion PS
LEFT JOIN dbo.ff_Empleado E
    ON E.Id = PS.POIdEmpleado
LEFT JOIN dbo.ff_Parentesco PA
    ON PA.PAidParentesco = PS.POIdParentesco
LEFT JOIN dbo.ff_GrupoParentesco GP
    ON GP.GPidGrupoParentesco = PS.POIdGrupoParentesco
LEFT JOIN dbo.ff_PlanOpcion PO
    ON PO.POidPlanOpcion = PS.POIdPlanOpcion
LEFT JOIN dbo.ff_Plan PL
    ON PL.PLidPlan = PO.POidPlan
WHERE PS.POIdSolicitud IN (@SolicitudAntes, @SolicitudDespues)
ORDER BY
    PS.POIdSolicitud,
    PL.PLNombre,
    PO.PONombre,
    PS.POIdEmpleado;

/* 04. Compara los planes del titular y muestra si el grupo fue recalculado. */
;WITH Antes AS
(
    SELECT
        PS.POIdPlanOpcion,
        MAX(PL.PLNombre) AS planNombre,
        MAX(PO.PONombre) AS opcionNombre,
        MAX(PS.POIdGrupoParentesco) AS grupoId,
        MAX(GP.GPNombre) AS grupoNombre,
        MAX(PS.POTarifaNeta) AS costoTitular
    FROM dbo.ff_PlanOpcionSeleccion PS
    INNER JOIN dbo.ff_Solicitud S
        ON S.SOIdSolicitud = PS.POIdSolicitud
    LEFT JOIN dbo.ff_PlanOpcion PO
        ON PO.POidPlanOpcion = PS.POIdPlanOpcion
    LEFT JOIN dbo.ff_Plan PL
        ON PL.PLidPlan = PO.POidPlan
    LEFT JOIN dbo.ff_GrupoParentesco GP
        ON GP.GPidGrupoParentesco = PS.POIdGrupoParentesco
    WHERE PS.POIdSolicitud = @SolicitudAntes
      AND PS.POIdEmpleado = S.SOIdEmpleado
    GROUP BY PS.POIdPlanOpcion
),
Despues AS
(
    SELECT
        PS.POIdPlanOpcion,
        MAX(PL.PLNombre) AS planNombre,
        MAX(PO.PONombre) AS opcionNombre,
        MAX(PS.POIdGrupoParentesco) AS grupoId,
        MAX(GP.GPNombre) AS grupoNombre,
        MAX(PS.POTarifaNeta) AS costoTitular
    FROM dbo.ff_PlanOpcionSeleccion PS
    INNER JOIN dbo.ff_Solicitud S
        ON S.SOIdSolicitud = PS.POIdSolicitud
    LEFT JOIN dbo.ff_PlanOpcion PO
        ON PO.POidPlanOpcion = PS.POIdPlanOpcion
    LEFT JOIN dbo.ff_Plan PL
        ON PL.PLidPlan = PO.POidPlan
    LEFT JOIN dbo.ff_GrupoParentesco GP
        ON GP.GPidGrupoParentesco = PS.POIdGrupoParentesco
    WHERE PS.POIdSolicitud = @SolicitudDespues
      AND PS.POIdEmpleado = S.SOIdEmpleado
    GROUP BY PS.POIdPlanOpcion
)
SELECT
    '04_COMPARACION_PLANES_TITULAR' AS bloque,
    COALESCE(A.POIdPlanOpcion, D.POIdPlanOpcion) AS POIdPlanOpcion,
    COALESCE(A.planNombre, D.planNombre) AS planNombre,
    COALESCE(A.opcionNombre, D.opcionNombre) AS opcionNombre,
    A.grupoNombre AS grupoAntes,
    D.grupoNombre AS grupoDespues,
    A.costoTitular AS costoAntes,
    D.costoTitular AS costoDespues,
    CASE
        WHEN A.POIdPlanOpcion IS NULL THEN 'AGREGADO_EN_DESPUES'
        WHEN D.POIdPlanOpcion IS NULL THEN 'QUITADO_EN_DESPUES_REVISAR_ELEGIBILIDAD'
        WHEN ISNULL(A.grupoId, -1) <> ISNULL(D.grupoId, -1)
            THEN 'MISMO_PLAN_GRUPO_RECALCULADO'
        ELSE 'MISMO_PLAN_CONSERVADO'
    END AS resultado
FROM Antes A
FULL OUTER JOIN Despues D
    ON D.POIdPlanOpcion = A.POIdPlanOpcion
ORDER BY planNombre, opcionNombre;
GO
