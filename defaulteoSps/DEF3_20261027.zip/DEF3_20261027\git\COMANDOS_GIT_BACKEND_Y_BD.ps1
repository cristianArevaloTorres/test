$ErrorActionPreference = "Stop"

# PEGA AQUI los tres valores antes de ejecutar.
$Repo = "PEGA_AQUI_LA_RUTA_DEL_REPO_BACKEND"
$RamaBase = "PEGA_AQUI_LA_RAMA_BASE"
$RamaDestino = "PEGA_AQUI_LA_RAMA_DESTINO"

if ($Repo -like "PEGA_AQUI*" -or
    $RamaBase -like "PEGA_AQUI*" -or
    $RamaDestino -like "PEGA_AQUI*") {
    throw "Primero completa Repo, RamaBase y RamaDestino."
}

Set-Location -LiteralPath $Repo

if ((git rev-parse --is-inside-work-tree 2>$null) -ne "true") {
    throw "La ruta indicada no es un repositorio Git."
}

if (@(git status --porcelain).Count -gt 0) {
    throw "El repositorio tiene cambios pendientes. Guardalos antes de preparar la rama."
}

git fetch origin --prune
if ($LASTEXITCODE -ne 0) { throw "Fallo git fetch." }

$ExisteLocal = $null -ne (git branch --list $RamaDestino)
git ls-remote --exit-code --heads origin $RamaDestino *> $null
$ExisteRemota = $LASTEXITCODE -eq 0

if ($ExisteLocal) {
    git switch $RamaDestino
    if ($LASTEXITCODE -ne 0) { throw "No se pudo abrir la rama destino local." }
    if ($ExisteRemota) {
        git pull --ff-only origin $RamaDestino
        if ($LASTEXITCODE -ne 0) { throw "No se pudo actualizar la rama destino." }
    }
} elseif ($ExisteRemota) {
    git switch --track -c $RamaDestino "origin/$RamaDestino"
    if ($LASTEXITCODE -ne 0) { throw "No se pudo crear la rama local desde origin." }
} else {
    git switch $RamaBase
    if ($LASTEXITCODE -ne 0) {
        git switch --track -c $RamaBase "origin/$RamaBase"
    }
    if ($LASTEXITCODE -ne 0) { throw "No se pudo abrir la rama base." }

    git pull --ff-only origin $RamaBase
    if ($LASTEXITCODE -ne 0) { throw "No se pudo actualizar la rama base." }

    git switch -c $RamaDestino
    if ($LASTEXITCODE -ne 0) { throw "No se pudo crear la rama destino." }
}

Write-Host "Rama preparada: $RamaDestino" -ForegroundColor Green
Write-Host "Copia ahora el contenido de backend y database del ZIP al repositorio." -ForegroundColor Yellow
Read-Host "Cuando termines de copiar los archivos, presiona ENTER"

$Archivos = @(
    "src/main/java/com/lockton/WSBeFlex/DAO/DefaulteoCasosEspecialesReglas.java",
    "src/main/java/com/lockton/WSBeFlex/DAO/JDBCFfTitular.java",
    "src/main/java/com/lockton/WSBeFlex/Services/DefaulteoAvanzadoAsyncRunner.java",
    "src/test/java/com/lockton/WSBeFlex/DAO/JDBCFfTitularCasosEspecialesTest.java",
    "database/01_ALTER_DEFAULTEO_TIPO3.sql",
    "database/02_VALIDAR_DEFAULTEO_TIPO3_QA.sql",
    "database/03_ROLLBACK_DEFAULTEO_TIPO3.sql"
)

foreach ($Archivo in $Archivos) {
    if (-not (Test-Path -LiteralPath $Archivo -PathType Leaf)) {
        throw "Falta copiar el archivo: $Archivo"
    }
}

git status --short
git diff -- $Archivos
git add -- $Archivos

Write-Host "Archivos preparados para commit:" -ForegroundColor Cyan
git diff --cached --name-status
git diff --cached --stat

$Confirmacion = Read-Host "Escribe SI para crear el commit y hacer push"
if ($Confirmacion -ne "SI") {
    throw "Proceso detenido antes del commit."
}

git commit -m "Corrige defaulteo tipo 3 al eliminar dependientes"
if ($LASTEXITCODE -ne 0) { throw "Fallo git commit." }

git push -u origin $RamaDestino
if ($LASTEXITCODE -ne 0) { throw "Fallo git push." }

git status
Write-Host "Commit y push terminados en: $RamaDestino" -ForegroundColor Green
