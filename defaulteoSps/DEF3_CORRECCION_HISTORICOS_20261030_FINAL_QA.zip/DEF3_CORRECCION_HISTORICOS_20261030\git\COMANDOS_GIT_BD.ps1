# Este archivo solamente contiene los comandos sugeridos.
# Completa los valores PEGA_AQUI antes de ejecutarlos en tu repositorio Git.

$RepoBD = "PEGA_AQUI_LA_RUTA_DEL_REPOSITORIO_BD"
$RamaDestinoBD = "PEGA_AQUI_EL_BRANCH_DESTINO"
$RutaPaquete = "PEGA_AQUI_LA_RUTA_RELATIVA_DEF3_CORRECCION_HISTORICOS_20261030"

Set-Location -LiteralPath $RepoBD

# Actualiza el branch destino antes de agregar la entrega.
git fetch origin --prune
git switch $RamaDestinoBD
git pull --ff-only origin $RamaDestinoBD

# Agrega solamente el paquete de la correccion de base de datos.
git add -- "$RutaPaquete"

# Revisa exactamente lo que se incluira en el commit.
git status
git diff --cached --stat
git diff --cached

# Confirma y publica los cambios.
git commit -m "Corrige historicos en defaulteo de casos especiales"
git push origin $RamaDestinoBD

