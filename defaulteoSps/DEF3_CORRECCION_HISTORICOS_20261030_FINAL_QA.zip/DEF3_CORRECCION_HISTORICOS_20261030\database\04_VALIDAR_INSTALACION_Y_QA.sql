USE [FlexiForbesv2];
GO

SET NOCOUNT ON;

DECLARE @Motores TABLE
(
    Procedimiento SYSNAME NOT NULL PRIMARY KEY,
    ParametrosEsperados INT NOT NULL
);

INSERT INTO @Motores (Procedimiento, ParametrosEsperados)
VALUES
    ('ff_CBuscaPlanEspejoTest', 8),
    ('ff_CBuscaPlanEspejoTestMultivigenciaBF3', 9);

SELECT
    M.Procedimiento,
    O.modify_date AS fechaModificacion,
    COUNT(P.parameter_id) AS parametros,
    CASE
        WHEN O.object_id IS NOT NULL
         AND COUNT(P.parameter_id) = M.ParametrosEsperados
         AND OBJECT_DEFINITION(O.object_id) LIKE '%CAT 2026-10-30%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%S.SOEstatusSolicitud IN (1, 3, 4)%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%PS.POIdEstatus IN (1, 4, 10)%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%PO.POIdEstatus IN (1, 4, 10)%'
         AND OBJECT_DEFINITION(O.object_id) LIKE '%Anterior.POIdEstatus IN (1, 4, 10)%'
         AND OBJECT_DEFINITION(O.object_id) NOT LIKE '%PO.POIdEstatus = 1%'
         AND OBJECT_DEFINITION(O.object_id) NOT LIKE '%Anterior.POIdEstatus = 1%'
         AND OBJECT_DEFINITION(O.object_id) NOT LIKE '%PF.IDPARENTESCO = ISNULL(PO.POIdParentesco, PF.IDPARENTESCO)%'
            THEN 'CORRECCION_INSTALADA'
        ELSE 'REVISAR'
    END AS resultado
FROM @Motores M
LEFT JOIN sys.objects O
    ON O.object_id = OBJECT_ID('dbo.' + M.Procedimiento)
LEFT JOIN sys.parameters P
    ON P.object_id = O.object_id
GROUP BY
    M.Procedimiento,
    M.ParametrosEsperados,
    O.object_id,
    O.modify_date;

IF EXISTS
(
    SELECT 1
    FROM @Motores M
    LEFT JOIN sys.objects O
        ON O.object_id = OBJECT_ID('dbo.' + M.Procedimiento)
    OUTER APPLY
    (
        SELECT COUNT(*) AS Parametros
        FROM sys.parameters P
        WHERE P.object_id = O.object_id
    ) X
    WHERE O.object_id IS NULL
       OR X.Parametros <> M.ParametrosEsperados
       OR OBJECT_DEFINITION(O.object_id) NOT LIKE '%CAT 2026-10-30%'
       OR OBJECT_DEFINITION(O.object_id) NOT LIKE '%S.SOEstatusSolicitud IN (1, 3, 4)%'
       OR OBJECT_DEFINITION(O.object_id) NOT LIKE '%PS.POIdEstatus IN (1, 4, 10)%'
       OR OBJECT_DEFINITION(O.object_id) NOT LIKE '%PO.POIdEstatus IN (1, 4, 10)%'
       OR OBJECT_DEFINITION(O.object_id) NOT LIKE '%Anterior.POIdEstatus IN (1, 4, 10)%'
       OR OBJECT_DEFINITION(O.object_id) LIKE '%PO.POIdEstatus = 1%'
       OR OBJECT_DEFINITION(O.object_id) LIKE '%Anterior.POIdEstatus = 1%'
       OR OBJECT_DEFINITION(O.object_id) LIKE '%PF.IDPARENTESCO = ISNULL(PO.POIdParentesco, PF.IDPARENTESCO)%'
)
    THROW 51000, 'La correccion historica def3 no esta instalada en ambos motores.', 1;

/* La correccion grupal multivigencia del 29/10 debe permanecer instalada. */
IF OBJECT_DEFINITION
   (
       OBJECT_ID('dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3')
   ) NOT LIKE '%WHERE tc.tcidtipotarifa=2%'
    THROW 51000, 'El wrapper multivigencia no conserva la tarifa grupal tipo 2.', 1;

/* Evidencia opcional del caso QA. En local puede devolver cero filas. */
SELECT
    S.SOIdSolicitud,
    S.SOIdEmpleado,
    S.SOIdEmpresa,
    S.SOIdVigencia,
    S.SOEstatusSolicitud,
    PO.POIdEmpleado,
    PO.POIdParentesco,
    PO.POIdGrupoParentesco,
    PO.POIdPlanOpcion,
    PO.POIdEstatus,
    O.PODescripcion
FROM dbo.ff_Solicitud S WITH (NOLOCK, READUNCOMMITTED)
INNER JOIN dbo.ff_PlanOpcionSeleccion PO WITH (NOLOCK, READUNCOMMITTED)
    ON PO.POIdSolicitud = S.SOIdSolicitud
LEFT JOIN dbo.ff_PlanOpcion O WITH (NOLOCK, READUNCOMMITTED)
    ON O.POIdPlanOpcion = PO.POIdPlanOpcion
WHERE S.SOIdSolicitud IN (3296354, 3296355)
ORDER BY S.SOIdSolicitud, PO.POIdEmpleado, PO.POIdPlanOpcion;

SELECT 'VALIDACION_OK' AS resultado;
GO
