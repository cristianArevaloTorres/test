﻿namespace LocktonOneWeb.Controllers.Polizas
{
	public class PolizaCore
	{
	}

	public partial class InfoData
	{
		public DatDocumentos DatDocumentos { get; set; }

		public DatDoctoDetail DatDoctoDetail { get; set; }

		public CatDirecciones CatDirecciones { get; set; }

        public CatContactos catContactos { get; set; }
        public DatReciboss DatRecibos { get; set; }
    }

	public partial class DatDocumentos
	{
		public string IDDocto { get; set; }
		public string IDPolMta { get; set; }
		public string TipoDocto { get; set; }
		public string Solicitud { get; set; }
		public string Documento { get; set; }
		public string Inciso { get; set; }
		public string DAnterior { get; set; }
		public string DPosterior { get; set; }
		public string IDCli { get; set; }
		public string IDDir { get; set; }
		public string IDGrupo { get; set; }
		public string IDSGrupo { get; set; }
		public string IDSSGrupo { get; set; }
		public string IDAgente { get; set; }
		public string IDFPago { get; set; }
		public string IDMon { get; set; }
		public string IDSRamo { get; set; }
		public string IDEjecut { get; set; }
		public string IDVend { get; set; }
		public string IDEjecutCob { get; set; }
		public string IDEjecutRec { get; set; }
		public string IDEjecutCia { get; set; }
		public string IDDespacho { get; set; }
		public string IDGerencia { get; set; }
		public string IDLineBuss { get; set; }
		public string IDBenef { get; set; }
		public string IDYo { get; set; }
		public string CCobro { get; set; }
		public string TCCobro { get; set; }
		public string TPago { get; set; }
		public string TVenta { get; set; }
		public string IDCalPagos { get; set; }
		public string Renovacion { get; set; }
		public string FAntiguedad { get; set; }
		public string FDesde { get; set; }
		public string FHasta { get; set; }
		public string FSolicitud { get; set; }
		public string FCaptura { get; set; }
		public string FEnvio { get; set; }
		public string FRecepcion { get; set; }
		public string FConversion { get; set; }
		public string FEmision { get; set; }
		public string FEntrega { get; set; }
		public string FRevision { get; set; }
		public string FRevision2 { get; set; }
		public string FCotizacion { get; set; }
		public string FStatus { get; set; }
		public string MotStatus { get; set; }
		public string SubMotStatus { get; set; }
		public string Status { get; set; }
		public string StatusCob { get; set; }
		public string StatusUser { get; set; }
		public string FolioNo { get; set; }
		public string ReferenciaPago { get; set; }
		public string PrimaNeta { get; set; }
		public string Descuento { get; set; }
		public string PorDesc { get; set; }
		public string ExtraPrima { get; set; }
		public string PorExtraP { get; set; }
		public string Recargos { get; set; }
		public string PorRecargos { get; set; }
		public string Derechos { get; set; }
		public string GastosAdm { get; set; }
		public string STotal { get; set; }
		public string Impuesto1 { get; set; }
		public string PorImp1 { get; set; }
		public string Impuesto2 { get; set; }
		public string PorImp2 { get; set; }
		public string Impuesto3 { get; set; }
		public string PorImp3 { get; set; }
		public string FondoInv { get; set; }
		public string Ajuste { get; set; }
		public string PrimaTotal { get; set; }
		public string PrimaAdic1 { get; set; }
		public string PrimaAdic2 { get; set; }
		public string PrimaAdic3 { get; set; }
		public string PrimaAdic4 { get; set; }
		public string PrimaAdic5 { get; set; }
		public string PTotalAdic { get; set; }
		public string Comision0 { get; set; }
		public string PorCom0 { get; set; }
		public string Comision1 { get; set; }
		public string PorCom1 { get; set; }
		public string Comision2 { get; set; }
		public string PorCom2 { get; set; }
		public string Comision3 { get; set; }
		public string PorCom3 { get; set; }
		public string Comision4 { get; set; }
		public string PorCom4 { get; set; }
		public string Comision5 { get; set; }
		public string PorCom5 { get; set; }
		public string Comision6 { get; set; }
		public string PorCom6 { get; set; }
		public string Comision7 { get; set; }
		public string PorCom7 { get; set; }
		public string Comision8 { get; set; }
		public string PorCom8 { get; set; }
		public string Comision9 { get; set; }
		public string PorCom9 { get; set; }
		public string Comision10 { get; set; }
		public string PorCom10 { get; set; }
		public string Comision11 { get; set; }
		public string PorCom11 { get; set; }
		public string TCDocto { get; set; }
		public string Referencia1 { get; set; }
		public string Referencia2 { get; set; }
		public string Referencia3 { get; set; }
		public string Referencia4 { get; set; }
		public string Referencia5 { get; set; } // CAT Renovación automática: expone el dato que SICAS almacena para reportar la aceptación.
		public string Concepto { get; set; }
		public string Notas { get; set; }
		public string ClasDocto { get; set; }
		public string APDP { get; set; }
		public string CCP { get; set; }
		public string CCE { get; set; }
		public string DPPR { get; set; }
		public string DPRS { get; set; }
		public string Renovable { get; set; }
		public string StatusRen { get; set; }
		public string PorcentRen { get; set; }
		public string IDUserR { get; set; }
		public string IDUserC { get; set; }
		public string UserReviso { get; set; }
		public string UserReviso2 { get; set; }
		public string UserCotizo { get; set; }
		public string IDDAnt { get; set; }
		public string IDDPost { get; set; }
		public string MarcarFinish { get; set; }
		public string IsEspecial { get; set; }
		public string IsProduction { get; set; }
		public string IsCoaseguro { get; set; }
		public string IsReaseguro { get; set; }
		public string Comentario { get; set; }
		public string IncInic { get; set; }
		public string Prefijo { get; set; }
		public string AutoInc { get; set; }
		public string FieldOpen1 { get; set; }
		public string FieldOpen2 { get; set; }
		public string FieldOpen3 { get; set; }
		public string FieldOpen4 { get; set; }
		public string FieldText1 { get; set; }
		public string FieldText2 { get; set; }
		public string FieldMemo1 { get; set; }
		public string FieldMemo2 { get; set; }
		public string Fieldstring1 { get; set; }
		public string Fieldstring2 { get; set; }
		public string FieldFecha1 { get; set; }
		public string FieldFecha2 { get; set; }
		public string IDMCtrol { get; set; }
		public string IDVendOK { get; set; }
		public string FactPet { get; set; }
		public string FactProc { get; set; }
		public string RetCom { get; set; }
		public string IDVendB { get; set; }
		public string IDFee { get; set; }
		public string FCarta { get; set; }
		public string IDDespCancel { get; set; }
		public string IDUserCancel { get; set; }
		public bool Exitoso { get; set; }
		public string MensajeError { get; set; }
	}

	public partial class DatDoctoDetail
	{
		public string IDDetail { get; set; }
		public string IDDocto { get; set; }
		public string IDInc { get; set; }
		public string IDAseg { get; set; }
		public string IDDir { get; set; }
		public string CEVIC { get; set; }
		public string Clave { get; set; }
		public string Marca { get; set; }
		public string Tipo { get; set; }
		public string Transmision { get; set; }
		public string Puertas { get; set; }
		public string Modelo { get; set; }
		public string Serie { get; set; }
		public string Motor { get; set; }
		public string Repuve { get; set; }
		public string Placas { get; set; }
		public string IDEdoCircula { get; set; }
		public string EstadoCircula { get; set; }
		public string Color { get; set; }
		public string Ocupantes { get; set; }
		public string Servicio { get; set; }
		public string UsoVehiculo { get; set; }
		public string Cochera { get; set; }
		public string TipoCarga { get; set; }
		public string Tonelaje { get; set; }
		public string LocalizadorCia { get; set; }
		public string LozalizadorSerie { get; set; }
		public string EqEsp { get; set; }
		public string EqEspSAseg { get; set; }
		public string Adap { get; set; }
		public string AdapSAseg { get; set; }
		public string RemDescripcion { get; set; }
		public string RemMarca { get; set; }
		public string RemTipo { get; set; }
		public string RemModelo { get; set; }
		public string RemClave { get; set; }
		public string RemPlacas { get; set; }
		public string RemSerie { get; set; }
		public string RemSAseg { get; set; }
		public string IDProdCR { get; set; }
		public string TFlotilla { get; set; }
		public string ReqInsp { get; set; }
		public string Coaseguro { get; set; }
		public string Tempo { get; set; }
		public string Incremento { get; set; }
		public string PIncre { get; set; }
		public string Modulos { get; set; }
		public string IDSecond { get; set; }
		public string TipoObra { get; set; }
		public string DescripcionObra { get; set; }
		public string TipoInmueble { get; set; }
		public string Muros { get; set; }
		public string Techos { get; set; }
		public string EntrePisos { get; set; }
		public string Sotanos { get; set; }
		public string Mezzanines { get; set; }
		public string Pisos { get; set; }
		public string Nivel { get; set; }
		public string PlantaP { get; set; }
		public string Colindantes { get; set; }
		public string SuperficieTotal { get; set; }
		public string SubSuelo { get; set; }
		public string TraficVehic { get; set; }
		public string CalculoSReg { get; set; }
		public string Giro { get; set; }
		public string Uso { get; set; }
		public string TipoContra { get; set; }
		public string CercaRio { get; set; }
		public string CercaMar { get; set; }
		public string Multiclausula { get; set; }
		public string AnioC { get; set; }
		public string Azotea { get; set; }
		public string Mercancia { get; set; }
		public string IDEmpaque { get; set; }
		public string IDEmbalaje { get; set; }
		public string IDTipoMerc { get; set; }
		public string Observaciones { get; set; }
		public string Origen { get; set; }
		public string Destino { get; set; }
		public string TipoDeclara { get; set; }
		public string SAAdic1 { get; set; }
		public string SAAdic2 { get; set; }
		public string SAAdic3 { get; set; }
		public string DeducibleTra { get; set; }
		public string Capacidad { get; set; }
		public string Puerto { get; set; }
		public string BaseAerea { get; set; }
		public string Tripulantes { get; set; }
		public string Clausulas { get; set; }
		public string Limites { get; set; }
		public string ValorCasco { get; set; }
		public string DedVuelo { get; set; }
		public string DedTierra { get; set; }
		public string Clase { get; set; }
		public string NombreBarca { get; set; }
		public string Manga { get; set; }
		public string Eslora { get; set; }
		public string Puntual { get; set; }
		public string TonelajeB { get; set; }
		public string Bandera { get; set; }
		public string MaterialF { get; set; }
		public string ValorEmbarca { get; set; }
		public string Redes { get; set; }
		public string Trailer { get; set; }
		public string Contrato { get; set; }
		public string Folio { get; set; }
		public string TipoFia { get; set; }
		public string ProdFia { get; set; }
		public string Monto { get; set; }
		public string Amortizacion { get; set; }
		public string TarifaFia { get; set; }
		public string ValorContrato { get; set; }
		public string PContrato { get; set; }
		public string FInicioObl { get; set; }
		public string FFinObl { get; set; }
		public string Relativo { get; set; }
		public string NumEmp { get; set; }
		public string NumObr { get; set; }
		public string NumVend { get; set; }
		public string IDSolicitante { get; set; }
		public string Base { get; set; }
		public string BonifCia { get; set; }
		public string Bonif { get; set; }
		public string PorBonifCia { get; set; }
		public string PorBonif { get; set; }
		public string Deducible { get; set; }
		public string SumaAseg { get; set; }
		public string IDMonContrato { get; set; }
		public string TCContrato { get; set; }
		public string MontoTCContrato { get; set; }
		public string FAdic1 { get; set; }
		public string FAdic2 { get; set; }
		public string MRiesgosCub { get; set; }
		public string MCondEsp { get; set; }
		public string MDeducibles { get; set; }
		public string MExclusiones { get; set; }
		public string MSujetoA { get; set; }
		public string IsPolMasterNom { get; set; }
		public string CobExtranjero { get; set; }
		public string TipoProd { get; set; }
		public string TiempoProd { get; set; }
		public string TipoHist { get; set; }
		public string NotasObs { get; set; }
		public string TipoMercancia { get; set; }
		public string ValorAseg { get; set; }
		public string Transito { get; set; }
		public string Tarfia { get; set; }

		public string Cobertura { get; set; }
	}

	public partial class CatDirecciones
	{
		public string IDDir { get; set; }
		public string Calle { get; set; }
		public string NOExt { get; set; }
		public string NOInt { get; set; }
		public string CPostal { get; set; }
		public string Colonia { get; set; }
		public string Poblacion { get; set; }
		public string Ciudad { get; set; }
		public string Pais { get; set; }
		public string Telefono1 { get; set; }
		public string Telefono2 { get; set; }
		public string Telefono3 { get; set; }
		public string Telefono4 { get; set; }
		public string Telefono5 { get; set; }
		public string Telefono6 { get; set; }
		public string TipoDir { get; set; }
		public string GMaps { get; set; }
		public string Indicaciones { get; set; }
		public string IDMens { get; set; }
		public string CodEdo { get; set; }
		public string CodCd { get; set; }
		public string CodPMD { get; set; }
		public string CodCol { get; set; }
		public string CodPais { get; set; }
		public string FieldText1 { get; set; }
		public string FieldText2 { get; set; }
		public string FieldInt1 { get; set; }
		public string FieldInt2 { get; set; }
		public string FieldFecha1 { get; set; }
		public string FieldFecha2 { get; set; }
		public string FieldBit1 { get; set; }
		public string FieldBit2 { get; set; }

	}

	public partial class DatosCliente
	{
		public string IDCli { get; set; }
		public string IDCont { get; set; }
		public string IDGrupo { get; set; }
		public string IDSGrupo { get; set; }
		public string IDEjecut { get; set; }
		public string IDDirec { get; set; }
		public string IDDespacho { get; set; }
		public string IDGerencia { get; set; }
	}

	public partial class CatContactos
	{
		public string IDCont { get; set; } //Int (4) Contacto - ID  - Requerido
		public string TipoEnt { get; set; } //TinyInt (1) Entidad - 0 Fisica 1 Moral  - Requerido
		public string ApellidoP { get; set; } //nVarChar (40) Apellido Paterno - Depende de TipoEnt  - Requerido
		public string ApellidoM { get; set; } //nVarChar (40) Apellido Materno
		public string Nombre { get; set; } //nVarChar (40) Nombre(s) - Depende de TipoEnt  - Requerido
		public string Titulo { get; set; } //nVarChar (20) Titulo
		public string FechaNac { get; set; } //smallDateTime (8) Fecha Nacimiento
		public string Edad { get; set; } //smallInt (2) Edad
		public string Sexo { get; set; } //TinyInt (1) Sexo - 0 Mas 1 Fem 
		public string EdoCivil { get; set; } //nVarChar (20) Estado Civil
		public string RazonSocial { get; set; } //nVarChar (200) Razón Social - Depende de TipoEnt  - Requerido
		public string NombreCompleto { get; set; } //nVarChar (200) Nombre Completo - Nunca Enviar 
		public string FechaConst { get; set; } //smallDateTime (8) Fecha Constitución
		public string CantEmpleados { get; set; } //Int (4) Empleados
		public string RFC { get; set; } //nVarChar (25) Registro Federal de Contribuyente
		public string CURP { get; set; } //nVarChar (30) C.U.R.P.
		public string Abreviacion { get; set; } //nVarChar (30) Alias
		public string Expediente { get; set; } //nVarChar (30) Expediente
		public string Nacionalidad { get; set; } //nVarChar (40) Nacionalidad
		public string Idioma { get; set; } //smallInt (2) Idioma
		public string LugarNac { get; set; } //nVarChar (40) Lugar Nacimiento
		public string IDEdoNac { get; set; } //TinyInt (1) ID Estado Nacimiento - Catalogo 
		public string EstadoNac { get; set; } //nVarChar (40) Estado Nacimiento
		public string CargoGub { get; set; } //nVarChar (250) Cargo en Gobierno
		public string Giro { get; set; } //nVarChar (250) Giro
		public string Actividad { get; set; } //nVarChar (250) Actividad
		public string NumPasaporte { get; set; } //nVarChar (25) Pasaporte
		public string NumID { get; set; } //nVarChar (25) Identificación
		public string NSS { get; set; } //nVarChar (30) No. Seguridad Social
		public string NAfore { get; set; } //nVarChar (30) No. de Afore
		public string LicenciaTipo { get; set; } //nVarChar (20) Tipo Licencia
		public string LicenciaNum { get; set; } //nVarChar (30) No. Licencia
		public string IDEmpresa { get; set; } //Int (4) Empresa (Trabajo) - Catalogo a IDCont 
		public string Profesion { get; set; } //nVarChar (60) Profesión
		public string Puesto { get; set; } //nVarChar (60) Puesto
		public string Trato { get; set; } //nVarChar (60) Trato
		public string Departamento { get; set; } //nVarChar (60) Departamento
		public string FechaIniEmpl { get; set; } //smallDateTime (8) Fecha Ingreso
		public string Horario { get; set; } //nVarChar (60) Horario
		public string Percepcion { get; set; } //Float (8) Sueldo
		public string NEmpleado { get; set; } //nVarChar (30) No. de Empleado
		public string Clasifica { get; set; } //smallInt (2) Clasificación - Catalogo 
		public string EMail1 { get; set; } //nVarChar (80) Correo 1
		public string EMail2 { get; set; } //nVarChar (80) Correo 2
		public string URL { get; set; } //nVarChar (50) URL
		public string RedSocial1 { get; set; } //nVarChar (50) Red Social Face Book
		public string RedSocial2 { get; set; } //nVarChar (50) Red Social Twitter
		public string RedSocial3 { get; set; } //nVarChar (50) Red Social o Skype
		public string Telefono1 { get; set; } //nVarChar (50) Teléfono 1 - Tipo Telefono|Numero 
		public string Telefono2 { get; set; } //nVarChar (50) Teléfono 2 - Tipo Telefono|Numero 
		public string Telefono3 { get; set; } //nVarChar (50) Teléfono 3 - Tipo Telefono|Numero 
		public string Telefono4 { get; set; } //nVarChar (50) Teléfono 4 - Tipo Telefono|Numero 
		public string IDUser { get; set; } //smallInt (2) ID Usuario - Catalogo/NO Enviar 
		public string FechaCap { get; set; } //smallDateTime (8) Fecha Captura
		public string Obs { get; set; } //nText (0) Observaciones
		public string SendMail { get; set; } //Bit (1) Envió por Mail
		public string FtoMail { get; set; } //TinyInt (1) Formato de Mail - Catalogo 
		public string SendPhone { get; set; } //Bit (1) Envió SMS
		public string Religion { get; set; } //nVarChar (30) Religión
		public string TSanguineo { get; set; } //nVarChar (10) Tipo Sanguíneo
		public string ObsSalud { get; set; } //nText (0) Observaciones Sobre Salud
		public string FileNamePhoto1 { get; set; } //nVarChar (50) Fotografía
		public string ClaveBit { get; set; } //nVarChar (30) Clave Bitácora - No Enviar 
		public string TIngreso { get; set; } //smallInt (2) Como se Ingreso - Catalogo 
		public string FEntero { get; set; } //smallInt (2) Como se entero - Catalogo 
		public string TSIngreso { get; set; } //Int (4) Origen del Ingreso - Catalogo 
		public string TIngresoNombre { get; set; } //nVarChar (60) Nombre Evento
		public string ClaveTKM { get; set; } //nVarChar (20) Clave TMK
		public string GAfinidad { get; set; } //Int (4) Grupo Afinidad - Catalogo 
		public string CCosto { get; set; } //nVarChar (30) Centro de Costo
		public string GreenClient { get; set; } //TinyInt (1) Cliente Verde - Catalogo 
		public string FGreenClient { get; set; } //smallDateTime (8) Fecha Cliente Verde
		public string AvisoPriv { get; set; } //TinyInt (1) Aviso de Privacidad - Catalogo 
		public string FAvisoPriv { get; set; } //smallDateTime (8) Fecha Aviso Privacidad
		public string FolletoInf { get; set; } //TinyInt (1) Folleto Informativo - Catalogo 
		public string FFolletoInf { get; set; } //smallDateTime (8) Fecha Folleto Informativo
		public string WebMailLogin { get; set; } //nVarChar (80) Correo para acceso WEB
		public string WebPassword { get; set; } //nVarChar (150) Contraseña
		public string WebStatus { get; set; } //TinyInt (1) Estatus del Acceso - Catalogo 0 ACtivo 1 Inactivo 
		public string WebIDProfile { get; set; } //Int (4) Perfil de Acceso - Catalogo 
		public string WebCodeAuth { get; set; } //nVarChar (250) Código de Autorización
		public string WebTCAP { get; set; } //Bit (1) Términos y Condiciones Av. Priv - Priv 
		public string Comentario { get; set; } //nText (0) Comentario
		public string IDCtrolImp { get; set; } //Int (4) Control de Importación - No Enviar 
		public string FieldText1 { get; set; } //nVarChar (100) Campo de Texto Abierto
		public string FieldText2 { get; set; } //nVarChar (100) Campo de Texto Abierto
		public string FieldText3 { get; set; } //nVarChar (100) Campo de Texto Abierto
		public string FieldMemo1 { get; set; } //nText (0) Campo Memo Abierto
		public string FieldMemo2 { get; set; } //nText (0) Campo Memo Abierto
		public string FieldMemo3 { get; set; } //nText (0) Campo Memo Abierto
		public string FieldInt1 { get; set; } //Int (4) Campo Entero Abierto
		public string FieldInt2 { get; set; } //Int (4) Campo Entero Abierto
		public string FieldInt3 { get; set; } //Int (4) Campo Entero Abierto
		public string FieldFecha1 { get; set; } //smallDateTime (8) Campo Fecha Abierto
		public string FieldFecha2 { get; set; } //smallDateTime (8) Campo Fecha Abierto
		public string FieldFecha3 { get; set; } //smallDateTime (8) Campo Fecha Abierto
		public string FieldBit1 { get; set; } //Bit (1) Cambio Bit Abierto
		public string FieldBit2 { get; set; } //Bit (1) Cambio Bit Abierto
		public string FieldBit3 { get; set; } //Bit (1) Cambio Bit Abierto
		public string FecNoUtil { get; set; } //smallDateTime (8) Fecha de No utilizacion - No Enviar 
		public string IDBEEmpresa { get; set; } //Int (4) Empresa de Beneifcios - Catalogo 

    }
    public partial class DatReciboss
    {
        public string IDRecibo { get; set; }      
        public string PrimaTotal { get; set; }
        public string PrimaNeta { get; set; }
        public string Recargos { get; set; }
        public string Derechos { get; set; }
        public string Impuesto1 { get; set; }
        public string STotal { get; set; }
        public string Comision0 { get; set; }
        public string PrimaNetaOrg { get; set; }
        public string PrimaTotalOrg { get; set; }
		public string FDesde { get; set; }
		public string FHasta { get; set; }
		public string FGeneracion { get; set; }
		public string FLimPago { get; set; }
	}
}
