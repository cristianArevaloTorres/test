﻿namespace LocktonOneWeb.Controllers.Polizas
{
    using LocktonModel.db;
    using LocktonModel.Models;
    using LocktonModel.VModels;
    using LocktonServicios.DerivacionCore;
    using LocktonServicios.Membresias.COSTCO.DTO;
    using log4net;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Xml;
    using System.Xml.Serialization;
    using TSMexico.CoDe.Rnd;

    public class DerivacionPolizasCore : DerivacionCore
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(DerivacionPolizasCore));
        private ApplicationDbContext db = new ApplicationDbContext();

        public DerivacionPolizasCore() : base()
        {
        }

        public RespuestaWS ConsultarPolizasXUsuario(string IdCliente)
        {
            log.Info(string.Format("Comienza a consultar la poliza al Core del usuario: {0} ", IdCliente));
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.REPORT;
                OWSData.KeyCode = "HLOCKWS_006";
                OWSData.Page = 1;
                OWSData.ItemForPage = 1000;
                OWSData.ConditionsAdd =
                    string.Concat(
                        "Cliente;0;0;",
                        IdCliente,
                        ";",
                        IdCliente,
                        ";-1;1;DatDocumentos.IDCli!Status;2;0;0|1|2|3|4;Vigente|Cancelada|Renovada|NO Renovada|Vencida;-1;1;DatDocumentos.Status!TipoDocto;0;0;1;Solo Polizas;-1;-1;DatDocumentos.TipoDocto");
                OWSData.InfoSort = "DatDocumentos.FDesde DESC";

                respuestaWS.Mensaje = WsClient.ProcesarWS(OWSData);

                log.Info(string.Format("Obtenemos el resultado del core ", respuestaWS.Mensaje));
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                log.Info(string.Format("Ocurrio un error al recuperar las polizas del core", (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message)));
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return respuestaWS;
        }

        public RespuestaWS ConsultarPolizasSolicitudesXUsuario(string IdCliente)
        {
            log.Info(string.Format("Comienza a consultar la poliza al Core del usuario: {0} ", IdCliente));
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.REPORT;
                OWSData.KeyCode = "HLOCKWS_006";
                OWSData.Page = 1;
                OWSData.ItemForPage = 250;
                OWSData.ConditionsAdd =
                    string.Concat(
                        "Cliente;0;0;",
                        IdCliente,
                        ";",
                        IdCliente,
                        ";-1;1;DatDocumentos.IDCli!Status;2;0;0|1|2|3|4;Vigente|Cancelada|Renovada|NO Renovada|Vencida;-1;1;DatDocumentos.Status!TipoDocto;2;0;1|0;Polizas|Solicitudes;-1;-1;DatDocumentos.TipoDocto");
                OWSData.InfoSort = "DatDocumentos.FDesde DESC";

                respuestaWS.Mensaje = WsClient.ProcesarWS(OWSData);

            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                log.Info(string.Format("Ocurrio un error al recuperar las polizas del core", (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message)));
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return respuestaWS;
        }
        public RespuestaWS ConsultarPolizasXGerencia(string IdGerencia)
        {
            log.Info(string.Format("Comienza a consultar la poliza al Core de la gerencia: {0} ", IdGerencia));
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.REPORT;
                OWSData.KeyCode = "HLOCKWS_006";
                OWSData.Page = 1;
                OWSData.ItemForPage = 1000;
                OWSData.ConditionsAdd =
                    string.Concat(
                        "Gerencia;0;0;",
                        IdGerencia,
                        ";",
                        IdGerencia,
                        ";-1;1;DatDocumentos.IDGerencia!Status;2;0;0|1|2|3|4;Vigente|Cancelada|Renovada|NO Renovada|Vencida;-1;1;DatDocumentos.Status!TipoDocto;0;0;1;Solo Polizas;-1;-1;DatDocumentos.TipoDocto");
                OWSData.InfoSort = "DatDocumentos.FDesde DESC";

                respuestaWS.Mensaje = WsClient.ProcesarWS(OWSData);

            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                log.Info(string.Format("Ocurrio un error al recuperar las polizas del core", (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message)));
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
            }
            return respuestaWS;
        }

        public RespuestaWS ConsultarRenovacionesOT(string IdCliente)
        {
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.REPORT;
                OWSData.KeyCode = "HLOCKWS_006";
                OWSData.Page = 1;
                OWSData.ItemForPage = 1000;

                OWSData.ConditionsAdd =
                    string.Concat(
                        "Cliente;0;0;",
                        IdCliente,
                        ";",
                        IdCliente,
                        ";-1;1;DatDocumentos.IDCli!Status;2;0;0|1|2|3|4;Vigente|Cancelada|Renovada|NO Renovada|Vencida;-1;-1;DatDocumentos.Status!TipoDocto;0;0;0;Solo Ordenes;-1;-1;DatDocumentos.TipoDocto");
                OWSData.InfoSort = "DatDocumentos.FDesde DESC";

                respuestaWS.Mensaje = WsClient.ProcesarWS(OWSData);
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("ConsultarRenovacionesOT IdCliente: " + IdCliente + " " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return respuestaWS;
        }

        public RespuestaWS ConsultarRenovacionesOTGerencia(string IdGerencia)
        {
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.REPORT;
                OWSData.KeyCode = "HLOCKWS_006";
                OWSData.Page = 1;
                OWSData.ItemForPage = 30;

                OWSData.ConditionsAdd =
                string.Concat(
                        "Gerencia;0;0;",
                        IdGerencia,
                        ";",
                        IdGerencia,
                        ";-1;1;DatDocumentos.IDGerencia!Status;0;0;0;Vigente;-1;-1;DatDocumentos.Status!TipoDocto;0;0;0;Solo Ordenes;-1;-1;DatDocumentos.TipoDocto!ClasDocto;0;0;3;Enrollment;-1;-1;DatDocumentos.ClasDocto");
                OWSData.InfoSort = "DatDocumentos.IdDocto DESC";
                respuestaWS.Mensaje = WsClient.ProcesarWS(OWSData);

            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("ConsultarRenovacionesOTGerencia IdGerencia: " + IdGerencia + " " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return respuestaWS;
        }

        public RespuestaWS ConsultarRenovacionesOTSerie(string serie, string IdGerencia)
        {
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.REPORT;
                OWSData.KeyCode = "HLOCKWS_006";
                OWSData.Page = 1;
                OWSData.ItemForPage = 30;

                OWSData.ConditionsAdd =
                string.Concat(
                        "Gerencia;0;0;",
                        IdGerencia,
                        ";",
                        IdGerencia,
                        ";-1;1;DatDocumentos.IDGerencia!Serie;0;0;",
                        serie,
                        ";",
                        serie,
                        ";-1;1;DatDoctoDetail.Serie!Status;0;0;0;Vigente;-1;-1;DatDocumentos.Status!TipoDocto;0;0;0;Solo Ordenes;-1;-1;DatDocumentos.TipoDocto!ClasDocto;2;0;3;Enrollment;-1;-1;DatDocumentos.ClasDocto");
                OWSData.InfoSort = "DatDocumentos.IdDocto DESC";
                respuestaWS.Mensaje = WsClient.ProcesarWS(OWSData);
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("ConsultarRenovacionesOTSerie Serie: " + serie + " " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return respuestaWS;
        }

        public RespuestaWS ConsultarRenovacionesOTNumeroEmpleado(string numEmpleado, string IdGerencia)
        {
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.REPORT;
                OWSData.KeyCode = "HLOCKWS_006";
                OWSData.Page = 1;
                OWSData.ItemForPage = 30;

                OWSData.ConditionsAdd =
                string.Concat(
                         "Gerencia;0;0;",
                        IdGerencia,
                        ";",
                        IdGerencia,
                        ";-1;1;DatDocumentos.IDGerencia!NumeroEmpleado;0;0;",
                        numEmpleado,
                        ";",
                        numEmpleado,
                        ";-1;1;CatContactos.NEmpleado!Status;0;0;0;Vigente;-1;-1;DatDocumentos.Status!TipoDocto;0;0;0;Solo Ordenes;-1;-1;DatDocumentos.TipoDocto!ClasDocto;0;0;3;Enrollment;-1;-1;DatDocumentos.ClasDocto");
                OWSData.InfoSort = "DatDocumentos.IdDocto DESC";
                respuestaWS.Mensaje = WsClient.ProcesarWS(OWSData);
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("ConsultarRenovacionesOTNumeroEmpleado numEmpleado: " + numEmpleado + " " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return respuestaWS;
        }
        public RespuestaWS ConsultarRenovacionesOTDocumento(string documento, string IdGerencia)
        {
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.REPORT;
                OWSData.KeyCode = "HLOCKWS_006";
                OWSData.Page = 1;
                OWSData.ItemForPage = 30;

                OWSData.ConditionsAdd =
               string.Concat(
                        "Gerencia;0;0;",
                        IdGerencia,
                        ";",
                        IdGerencia,
                        ";-1;1;DatDocumentos.IDGerencia!Solicitud;0;0;",
                        documento,
                        ";",
                        documento,
                        ";-1;1;DatDocumentos.Solicitud!Status;0;0;0;Vigente;-1;-1;DatDocumentos.Status!TipoDocto;0;0;0;Solo Ordenes;-1;-1;DatDocumentos.TipoDocto!ClasDocto;0;0;3;Enrollment;-1;-1;DatDocumentos.ClasDocto");
                OWSData.InfoSort = "DatDocumentos.IdDocto DESC";
                respuestaWS.Mensaje = WsClient.ProcesarWS(OWSData);
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("ConsultarRenovacionesOTDocumento documento: " + documento + " " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return respuestaWS;
        }
        public RespuestaWS InsertarPolizaCORE(string xmlEnvioBogo)
        {
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.CredentialsUserSICAS = CfgCredUser;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.DATA;
                OWSData.KeyCode = "HWCAPTURE";
                OWSData.TProc = LocktonServicios.SICASProcesaRecuperaInfo.eTypeProceData.Save_Data;
                OWSData.CreateCobranza = true;
                OWSData.DataXML =
                    WsClient.ProcesarEncrip3DES(
                        "%SOnlineBOGO2001-2015WS#",
                        "Lock#Mx%",
                        xmlEnvioBogo
                        );

                string respuestaServicioBogo = WsClient.ProcesarWS(OWSData);
                //log.Info(xmlEnvioBogo);
                //log.Info(respuestaServicioBogo);

                if (respuestaServicioBogo.Contains("PROCESSDATA"))
                {
                    xmlDoc.LoadXml(respuestaServicioBogo);
                    respuestaWS.Respuesta = xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/RESPONSETXT")[0].InnerText == "SUCESS" ? true : false;
                    if (!respuestaWS.Respuesta)
                    {
                        log.Info(string.Concat("El Servicio respondió con el siguiente Error: ", xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/Message")[0].InnerText));
                        throw new Exception(string.Concat("El Servicio respondió con el siguiente Error: ", xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/Message")[0].InnerText));
                    }
                }

                respuestaWS.Mensaje = respuestaServicioBogo;
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("InsertarPolizaCORE XML: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }
            return respuestaWS;
        }

        public RespuestaWS InsertarDireccionCORE(string xmlEnvioBogo)
        {
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.CredentialsUserSICAS = CfgCredUser;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.DATA;
                OWSData.KeyCode = "HADDRESS";
                OWSData.TProc = LocktonServicios.SICASProcesaRecuperaInfo.eTypeProceData.Save_Data;
                OWSData.DataXML =
                    WsClient.ProcesarEncrip3DES(
                        "%SOnlineBOGO2001-2015WS#",
                        "Lock#Mx%",
                        xmlEnvioBogo
                        );

                string respuestaServicioBogo = WsClient.ProcesarWS(OWSData);
                xmlDoc.LoadXml(respuestaServicioBogo);
                respuestaWS.Respuesta = Convert.ToInt32(xmlDoc.SelectNodes("NewDataSet/DATAINFO/Sucess")[0].InnerText).Equals(1) ? true : false;

                if (!respuestaWS.Respuesta)
                {
                    log.Info(string.Concat("El Servicio respondió con el siguiente Error: ", xmlDoc.SelectNodes("NewDataSet/DATAINFO/Message")[0].InnerText));
                    throw new Exception(string.Concat("El Servicio respondió con el siguiente Error: ", xmlDoc.SelectNodes("NewDataSet/DATAINFO/Message")[0].InnerText));
                }

                respuestaWS.Mensaje = respuestaServicioBogo;
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("InsertarDireccionCORE XML: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
                log.Info("InsertarDireccionCORE XML: " + xmlEnvioBogo);
            }
            return respuestaWS;
        }

        public RespuestaWS InsertarContactoCORE(string xmlEnvioBogo)
        {
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                OWSData.Credentials = CfgCredentials;
                OWSData.CredentialsUserSICAS = CfgCredUser;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.DATA;
                OWSData.KeyCode = "HDATACONTACT"; //HCONTACT
                OWSData.TProc = LocktonServicios.SICASProcesaRecuperaInfo.eTypeProceData.Save_Data;
                OWSData.DataXML =
                    WsClient.ProcesarEncrip3DES(
                        "%SOnlineBOGO2001-2015WS#",
                        "Lock#Mx%",
                        xmlEnvioBogo
                        );

                string respuestaServicioBogo = WsClient.ProcesarWS(OWSData);
                //log.Info(xmlEnvioBogo);
                //log.Info(respuestaServicioBogo);
                if (respuestaServicioBogo.Contains("PROCESSDATA"))
                {
                    xmlDoc.LoadXml(respuestaServicioBogo);
                    respuestaWS.Respuesta = xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/RESPONSETXT")[0].InnerText == "SUCESS" ? true : false;
                    if (respuestaWS.Respuesta)
                    {
                        log.Info(string.Concat("El Servicio respondió con el siguiente Error: ", xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/Message")[0].InnerText));
                        throw new Exception(string.Concat("El Servicio respondió con el siguiente Error: ", xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/Message")[0].InnerText));
                    }
                }
                respuestaWS.Mensaje = respuestaServicioBogo;
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("InsertarContactoCORE: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }
            return respuestaWS;
        }

        private bool ActualizarPolizaDerivada(int IdPoliza, string IdDerivacion)
        {
            PolizaDetalle polizaDetalle = new PolizaDetalle();
            XmlDocument xmlDoc = new XmlDocument();

            try
            {
                polizaDetalle = db.PolizaDetalle.FirstOrDefault(x => x.IdPoliza == IdPoliza);
                if (polizaDetalle != null)
                {
                    xmlDoc.LoadXml(IdDerivacion);
                    //polizaDetalle.IdPolizaCORE = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
                    //polizaDetalle.MigraCORE = true;
                    //db.Entry(polizaDetalle).State = EntityState.Modified;
                    //db.SaveChanges();
                    int idPoliza = polizaDetalle.IdPoliza;
                    string idPolizaCore = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;

                    SqlParameter id = new SqlParameter("@IdPoliza", IdPoliza);
                    SqlParameter idCore = new SqlParameter("@IdPolizaCORE", idPolizaCore);

                    db.Database.ExecuteSqlCommand("sp_POLIZADETALLE_Update @IdPoliza,@IdPolizaCORE", id, idCore);
                    //db.Database.ExecuteSqlCommand(string.Format("Execute sp_POLIZADETALLE_Update @IdPoliza = {0}, @IdPolizaCORE = '{1}'", IdPoliza, idPolizaCore));
                    log.Info("ActualizarPolizaDerivada actuliza IdPoliza" + IdPoliza.ToString() + " -> IdPolizaCORE: " + idPolizaCore);

                    string recibosPolizaCore = xmlDoc.SelectNodes("NewDataSet/DATAINFO/ListRecibos")[0].InnerText;
                    bool actualizacionRecibos = ActualizarReciboslocktonOne(polizaDetalle.IdPoliza, recibosPolizaCore);
                    bool ActualizarRecibosCore = ConsultarRecibosAseguradora(polizaDetalle.IdPoliza);
                    if (!actualizacionRecibos && !ActualizarRecibosCore)
                    {
                        return false;
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                log.Info("ActualizarPolizaDerivada XML: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return false;
        }

        private bool ActualizarPolizaDerivadaCasa(int IdPoliza, string IdDerivacion)
        {
            PolizaDetalleCasa polizaDetalle = new PolizaDetalleCasa();
            XmlDocument xmlDoc = new XmlDocument();

            try
            {
                polizaDetalle = db.PolizaDetalleCasa.FirstOrDefault(x => x.IdPoliza == IdPoliza);
                if (polizaDetalle != null)
                {
                    xmlDoc.LoadXml(IdDerivacion);
                    //polizaDetalle.IdPolizaCORE = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
                    //polizaDetalle.MigraCORE = true;
                    //db.Entry(polizaDetalle).State = EntityState.Modified;
                    //db.SaveChanges();
                    int idPoliza = polizaDetalle.IdPoliza;
                    string idPolizaCore = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;

                    SqlParameter id = new SqlParameter("@IdPoliza", IdPoliza);
                    SqlParameter idCore = new SqlParameter("@IdPolizaCORE", idPolizaCore);

                    db.Database.ExecuteSqlCommand("sp_POLIZADETALLECASA_Update @IdPoliza,@IdPolizaCORE", id, idCore);
                    //db.Database.ExecuteSqlCommand(string.Format("Execute sp_POLIZADETALLE_Update @IdPoliza = {0}, @IdPolizaCORE = '{1}'", IdPoliza, idPolizaCore));
                    log.Info("ActualizarPolizaDerivada actuliza IdPoliza" + IdPoliza.ToString() + " -> IdPolizaCORE: " + idPolizaCore);

                    string recibosPolizaCore = xmlDoc.SelectNodes("NewDataSet/DATAINFO/ListRecibos")[0].InnerText;
                    bool actualizacionRecibos = ActualizarReciboslocktonOne_Casa(polizaDetalle.IdPoliza, recibosPolizaCore);
                    bool ActualizarRecibosCore = ConsultarRecibosAseguradora_Casa(polizaDetalle.IdPoliza);
                    if (!actualizacionRecibos && !ActualizarRecibosCore)
                    {
                        return false;
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                log.Info("ActualizarPolizaDerivada XML: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return false;
        }

        private bool ActualizarPolizaDerivadaProducto(int IdPoliza, string IdDerivacion)
        {
            var polizaDetalle = new PolizaProductoDetalle();
            XmlDocument xmlDoc = new XmlDocument();

            try
            {
                polizaDetalle = db.PolizaProductoDetalle.FirstOrDefault(x => x.IdPoliza == IdPoliza);
                if (polizaDetalle != null)
                {
                    xmlDoc.LoadXml(IdDerivacion);
                    //polizaDetalle.IdPolizaCORE = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
                    //polizaDetalle.MigraCORE = true;
                    //db.Entry(polizaDetalle).State = EntityState.Modified;
                    //db.SaveChanges();
                    int idPoliza = polizaDetalle.IdPoliza;
                    string idPolizaCore = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
                    string NumeroPoliza = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NumSolicitud")[0].InnerText;

                    SqlParameter id = new SqlParameter("@IdPoliza", IdPoliza);
                    SqlParameter idCore = new SqlParameter("@IdPolizaCORE", idPolizaCore);
                    SqlParameter solicitud = new SqlParameter("@Solicitud", NumeroPoliza);

                    db.Database.ExecuteSqlCommand("sp_POLIZADETALLEPRODUCTO_Update @IdPoliza,@IdPolizaCORE,@Solicitud", id, idCore, solicitud);
                    //db.Database.ExecuteSqlCommand(string.Format("Execute sp_POLIZADETALLE_Update @IdPoliza = {0}, @IdPolizaCORE = '{1}'", IdPoliza, idPolizaCore));
                    log.Info("ActualizarPolizaDerivada actuliza IdPoliza" + IdPoliza.ToString() + " -> IdPolizaCORE: " + idPolizaCore);

                    //string recibosPolizaCore = xmlDoc.SelectNodes("NewDataSet/DATAINFO/ListRecibos")[0].InnerText;
                    //bool actualizacionRecibos = ActualizarReciboslocktonOne(polizaDetalle.IdPoliza, recibosPolizaCore);
                    //bool ActualizarRecibosCore = ConsultarRecibosAseguradora(polizaDetalle.IdPoliza);
                    //if (!actualizacionRecibos && !ActualizarRecibosCore)
                    //{
                    //    return false;
                    //}

                    return true;
                }
            }
            catch (Exception ex)
            {
                log.Info("ActualizarPolizaDerivada XML: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return false;
        }

        #region Polizas Core

        public void DerivaOTPolizaCore(InformacionEmision InfoEmision)
        {
            string xmlEnvioBogo = DerivaOTPoliza(InfoEmision);
            if (!string.IsNullOrEmpty(xmlEnvioBogo))
            {
                RespuestaWS respuesta = InsertarPolizaCORE(xmlEnvioBogo);
                if (respuesta.Mensaje.Contains("NewIDValue"))
                {//derivacion correcta, actualizar poliza detalle con el id regresado y estatus derivado
                    ActualizarPolizaDerivada(InfoEmision.Poliza.PolizaDetalle.FirstOrDefault().IdPoliza, respuesta.Mensaje);
                }
                else
                {
                    PolizaDetalle polizaDetalle = new PolizaDetalle();
                    int idPoliza = InfoEmision.Poliza.PolizaDetalle.FirstOrDefault().IdPoliza;
                    polizaDetalle = db.PolizaDetalle.FirstOrDefault(x => x.IdPoliza == idPoliza);
                    XmlDocument xmlDocc = new XmlDocument();
                    xmlDocc.LoadXml(respuesta.Mensaje);
                    polizaDetalle.MensajeCore = xmlDocc.SelectNodes("/NewDataSet/PROCESSDATA/MESSAGE")[0].InnerText;
                    db.Entry(polizaDetalle).State = EntityState.Modified;
                    db.SaveChanges();
                }
            }
        }

        private string DerivaOTPoliza(InformacionEmision InfoEmision)
        {
            InfoData Datos = new InfoData();
            //genera seccion DatDocumentos
            Datos.DatDocumentos = RegistroDatosDerivaOTPoliza(InfoEmision);

            //genera xml
            return GeneraXml(Datos);
        }

        private DatDocumentos RegistroDatosDerivaOTPoliza(InformacionEmision InfoEmision)
        {
            DatDocumentos DatoDocumento = new DatDocumentos();
            try
            {
                System.Collections.Generic.List<LocktonModel.db.PolizaDetalle> polDetalle = new System.Collections.Generic.List<LocktonModel.db.PolizaDetalle>(InfoEmision.Poliza.PolizaDetalle);
                DatoDocumento.IDDocto = InfoEmision.NoPoliza;
                DatoDocumento.TipoDocto = "1";//siempre uno
                DatoDocumento.Documento = InfoEmision.Poliza.NumeroPoliza;//Documento | 3190166283     es el numero de poliza
                DatoDocumento.PrimaNeta = InfoEmision.Poliza.PrimaNeta.ToString();//PrimaNeta | 3924.1
                DatoDocumento.Recargos = polDetalle[0].Recargos.ToString();//Recargos | 0.00
                DatoDocumento.PorRecargos = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/Primas/Recargo")[0].InnerText;
                DatoDocumento.Derechos = polDetalle[0].Derechos.ToString();//Derechos | 360
                DatoDocumento.STotal = InfoEmision.Poliza.PrimaNeta.ToString();
                DatoDocumento.Impuesto1 = polDetalle[0].Impuesto.ToString();//Impuesto1 | 591.28
                DatoDocumento.PorImp1 = polDetalle[0].FactorIva.ToString();
                DatoDocumento.PrimaTotal = InfoEmision.Poliza.PrimaTotal.ToString();//PrimaTotal | 4286.76
                DatoDocumento.PTotalAdic = InfoEmision.Poliza.PrimaTotal.ToString();//PrimaTotal | 4286.76
                DatoDocumento.Comision0 = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/Recibos/Comision")[0].InnerText;
                DatoDocumento.PorCom0 = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/Primas/Comision")[0].InnerText;
                //DatoDocumento.Comision2 = "";
            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaOTPoliza: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }
            return DatoDocumento;
        }
        public string DerivaPersonaMoralCore(PersonaMoral data)
        {
            string IdCont = "";
            RespuestaWS GenContacto = DerivaContactoCore(data);

            if (GenContacto.Mensaje.Contains("NewIDValue"))
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(GenContacto.Mensaje);
                IdCont = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
            }
            return IdCont;
        }
        public void DerivaPolizaCore(InformacionEmision InfoEmision)
        {
            string IdCont = String.Empty;

            if ((string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdCliCORE) && string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdContCORE)))
            {
                IdCont = DerivaUsuarioFinalCore(InfoEmision).ToString();
            }
            else
            {
                IdCont = InfoEmision.DetalleUsuario.IdContCORE;
            }
            //--------------> Continuar aquí mañana 16/04/2019.
            if ((InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5) && InfoEmision.EmisionPersonaMoral)
            {
                IdCont = InfoEmision.PersonaMoral.IdContCORE;
            }
            if (InfoEmision.Contratante == null)
            {
                RespuestaWS GenContacto = DerivaContactoCore(InfoEmision);
                if (GenContacto.Mensaje.Contains("NewIDValue"))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(GenContacto.Mensaje);
                    IdCont = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
                }
            }
            /*
             */
            if (InfoEmision.Contratante != null)
            {
                IdCont = InfoEmision.Contratante.IdContCore;
                DerivaContactoCore(InfoEmision);
            }
            if (InfoEmision.Poliza == null)
            {
                log.Info("DerivaPolizaCore: Objeto Poliza NULL, Número Poliza:" + InfoEmision.NoPoliza);
                if (!string.IsNullOrEmpty(InfoEmision.NoPoliza.Trim()))
                {
                    Poliza poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == InfoEmision.NoPoliza);
                    InfoEmision.Poliza = poliza;
                }
            }

            if (InfoEmision.Poliza != null && InfoEmision.Convenio == null)
            {
                log.Info("DerivaPolizaCore: Objeto Convenio NULL, Número Poliza:" + InfoEmision.NoPoliza);
                Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == InfoEmision.Poliza.IdConvenio);
                InfoEmision.Convenio = convenio;
                InfoEmision.Poliza.Convenio = convenio;
            }
            string xmlEnvioBogo = DerivaPolizaNueva(InfoEmision, IdCont);
            if (!string.IsNullOrEmpty(xmlEnvioBogo))
            {
                RespuestaWS respuesta = InsertarPolizaCORE(xmlEnvioBogo);
                log.Info("respuesta al InsertarPolizaCORE " + respuesta.Mensaje);
                if (respuesta.Mensaje.Contains("NewIDValue"))
                {
                    //derivacion correcta, actualizar poliza detalle con el id regresado y estatus derivado
                    ActualizarPolizaDerivada(InfoEmision.Poliza.PolizaDetalle.FirstOrDefault().IdPoliza, respuesta.Mensaje);
                }
                else
                {
                    PolizaDetalle polizaDetalle = new PolizaDetalle();
                    int idPolizadetalle = InfoEmision.Poliza.PolizaDetalle.FirstOrDefault().Id;
                    polizaDetalle = db.PolizaDetalle.FirstOrDefault(x => x.Id == idPolizadetalle);
                    XmlDocument xmlDocc = new XmlDocument();
                    log.Info(" Error al derivar póliza al core XML envío " + xmlEnvioBogo);
                    xmlDocc.LoadXml(respuesta.Mensaje);
                    if (respuesta.Mensaje.Contains("MsgError"))
                        polizaDetalle.MensajeCore = xmlDocc.SelectNodes("/NewDataSet/DATAINFO/MsgError")[0].InnerText;
                    else if (respuesta.Mensaje.Contains("MESSAGE"))
                        polizaDetalle.MensajeCore = xmlDocc.SelectNodes("/NewDataSet/PROCESSDATA/MESSAGE")[0].InnerText;
                    else
                        polizaDetalle.MensajeCore = respuesta.Mensaje;
                    db.Entry(polizaDetalle).State = EntityState.Modified;
                    db.SaveChanges();
                }

            }
        }
        public void prueba(string xmlEnvioBogo)
        {
            RespuestaWS respuesta = InsertarPolizaCORE(xmlEnvioBogo);
            var a = 1;

        }

        public void DerivaPolizaCoreCasaHabitacion(InformacionEmision InfoEmision)
        {
            string IdCont = String.Empty;

            if ((string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdCliCORE) && string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdContCORE)))
            {
                IdCont = DerivaUsuarioFinalCoreCasa(InfoEmision).ToString();
            }
            else
            {
                IdCont = InfoEmision.DetalleUsuario.IdContCORE;
            }
            //--------------> Continuar aquí mañana 16/04/2019.
            if ((InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5) && InfoEmision.EmisionPersonaMoral)
            {
                IdCont = InfoEmision.PersonaMoral.IdContCORE;
            }

            if (InfoEmision.PolizaCasa == null)
            {
                log.Info("DerivaPolizaCore: Objeto Poliza NULL, Número Poliza:" + InfoEmision.NoPoliza);
                if (!string.IsNullOrEmpty(InfoEmision.NoPoliza.Trim()))
                {
                    PolizaCasa polizaCasa = db.PolizaCasa.FirstOrDefault(a => a.NumeroPoliza == InfoEmision.NoPoliza);
                    InfoEmision.PolizaCasa = polizaCasa;
                }
            }

            if (InfoEmision.Poliza != null && InfoEmision.Convenio == null)
            {
                log.Info("DerivaPolizaCore: Objeto Convenio NULL, Número Poliza:" + InfoEmision.NoPoliza);
                Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == InfoEmision.Poliza.IdConvenio);
                InfoEmision.Convenio = convenio;
                InfoEmision.Poliza.Convenio = convenio;
            }
            string xmlEnvioBogo = DerivaPolizaNuevaCasa(InfoEmision, IdCont);
            if (!string.IsNullOrEmpty(xmlEnvioBogo))
            {
                RespuestaWS respuesta = InsertarPolizaCORE(xmlEnvioBogo);
                if (respuesta.Mensaje.Contains("NewIDValue"))
                {
                    //derivacion correcta, actualizar poliza detalle con el id regresado y estatus derivado
                    ActualizarPolizaDerivadaCasa(InfoEmision.PolizaCasaDetalle.IdPoliza, respuesta.Mensaje);
                }
                else
                {
                    PolizaDetalleCasa polizaDetalle = new PolizaDetalleCasa();
                    int idPolizadetalle = InfoEmision.PolizaCasa.Id;
                    polizaDetalle = db.PolizaDetalleCasa.FirstOrDefault(x => x.IdPoliza == idPolizadetalle);
                    XmlDocument xmlDocc = new XmlDocument();
                    xmlDocc.LoadXml(respuesta.Mensaje);
                    polizaDetalle.MensajeCore = xmlDocc.SelectNodes("/NewDataSet/DATAINFO/MsgError")[0].InnerText;
                    db.Entry(polizaDetalle).State = EntityState.Modified;
                    db.SaveChanges();
                }

            }
        }

        public void DerivaPolizaCoreProducto(InformacionEmision InfoEmision)
        {
            string IdCont = String.Empty;

            if ((string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdCliCORE) && string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdContCORE)))
            {
                IdCont = DerivaUsuarioFinalCoreCasa(InfoEmision).ToString();
            }
            else
            {
                IdCont = InfoEmision.DetalleUsuario.IdContCORE;
            }
            //--------------> Continuar aquí mañana 16/04/2019.
            if ((InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5) && InfoEmision.EmisionPersonaMoral)
            {
                IdCont = InfoEmision.PersonaMoral.IdContCORE;
            }

            if (InfoEmision.PolizaProducto == null)
            {
                log.Info("DerivaPolizaCore: Objeto Poliza NULL, Número Poliza:" + InfoEmision.NoPoliza);
                if (!string.IsNullOrEmpty(InfoEmision.NoPoliza.Trim()))
                {
                    var polizaProducto = db.PolizaProducto.FirstOrDefault(a => a.NumeroPoliza == InfoEmision.NoPoliza);
                    InfoEmision.PolizaProducto = polizaProducto;
                }
            }

            if (InfoEmision.PolizaProducto != null && InfoEmision.Convenio == null)
            {
                log.Info("DerivaPolizaCore: Objeto Convenio NULL, Número Poliza:" + InfoEmision.NoPoliza);
                Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == InfoEmision.Poliza.IdConvenio);
                InfoEmision.Convenio = convenio;
                InfoEmision.Poliza.Convenio = convenio;
            }

            string xmlEnvioBogo = DerivaPolizaNuevaProducto(InfoEmision, IdCont);
            if (!string.IsNullOrEmpty(xmlEnvioBogo))
            {
                RespuestaWS respuesta = InsertarPolizaCORE(xmlEnvioBogo);
                if (respuesta.Mensaje.Contains("NewIDValue"))
                {
                    //derivacion correcta, actualizar poliza detalle con el id regresado y estatus derivado
                    ActualizarPolizaDerivadaProducto(InfoEmision.PolizaProducto.Id, respuesta.Mensaje);
                }
                else
                {
                    var polizaDetalle = new PolizaProductoDetalle();
                    int idPolizadetalle = InfoEmision.PolizaProductoDetalle.Id;
                    polizaDetalle = db.PolizaProductoDetalle.FirstOrDefault(x => x.IdPoliza == idPolizadetalle);
                    XmlDocument xmlDocc = new XmlDocument();
                    xmlDocc.LoadXml(respuesta.Mensaje);
                    polizaDetalle.MensajeCore = xmlDocc.SelectNodes("/NewDataSet/DATAINFO/MsgError")[0].InnerText;
                    db.Entry(polizaDetalle).State = EntityState.Modified;
                    db.SaveChanges();
                }

            }
        }

        public void DerivaPolizaOTCoreProducto(InformacionEmision InfoEmision)
        {
            string IdCont = String.Empty;

            if ((string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdCliCORE) && string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdContCORE)))
            {
                IdCont = DerivaUsuarioFinalCoreCasa(InfoEmision).ToString();
            }
            else
            {
                IdCont = InfoEmision.DetalleUsuario.IdContCORE;
            }
            //--------------> Continuar aquí mañana 16/04/2019.
            if ((InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5) && InfoEmision.EmisionPersonaMoral)
            {
                IdCont = InfoEmision.PersonaMoral.IdContCORE;
            }

            if (InfoEmision.PolizaProducto == null)
            {
                log.Info("DerivaPolizaCore: Objeto Poliza NULL, Número Poliza:" + InfoEmision.NoPoliza);
                if (!string.IsNullOrEmpty(InfoEmision.NoPoliza.Trim()))
                {
                    var polizaProducto = db.PolizaProducto.FirstOrDefault(a => a.NumeroPoliza == InfoEmision.NoPoliza);
                    InfoEmision.PolizaProducto = polizaProducto;
                }
            }

            if (InfoEmision.PolizaProducto != null && InfoEmision.Convenio == null)
            {
                log.Info("DerivaPolizaCore: Objeto Convenio NULL, Número Poliza:" + InfoEmision.NoPoliza);
                Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == InfoEmision.Poliza.IdConvenio);
                InfoEmision.Convenio = convenio;
                InfoEmision.Poliza.Convenio = convenio;
            }

            string xmlEnvioBogo = DerivaPolizaOTProducto(InfoEmision, IdCont);
            if (!string.IsNullOrEmpty(xmlEnvioBogo))
            {
                RespuestaWS respuesta = InsertarPolizaCORE(xmlEnvioBogo);
                if (respuesta.Mensaje.Contains("NewIDValue"))
                {
                    //derivacion correcta, actualizar poliza detalle con el id regresado y estatus derivado
                    ActualizarPolizaDerivadaProducto(InfoEmision.PolizaProducto.Id, respuesta.Mensaje);
                }
                else
                {
                    var polizaDetalle = new PolizaProductoDetalle();
                    int idPolizadetalle = InfoEmision.PolizaProductoDetalle.Id;
                    polizaDetalle = db.PolizaProductoDetalle.FirstOrDefault(x => x.IdPoliza == idPolizadetalle);
                    XmlDocument xmlDocc = new XmlDocument();
                    xmlDocc.LoadXml(respuesta.Mensaje);
                    polizaDetalle.MensajeCore = xmlDocc.SelectNodes("/NewDataSet/DATAINFO/MsgError")[0].InnerText;
                    db.Entry(polizaDetalle).State = EntityState.Modified;
                    db.SaveChanges();
                }

            }
        }

        private int DerivaUsuarioFinalCore(InformacionEmision infoEmision)
        {
            InsercionSICASClient insertaBD = new InsercionSICASClient();
            DatosCliente respuestaWS = new DatosCliente();
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            try
            {
                ObjetoBD objeto = new ObjetoBD();
                objeto.Modulo = Modulo.Usuario;
                objeto.Opcion = OpcionBD.Insercion;
                objeto.Metodo = Metodo.InsertaUsuarioFinal;
                objeto.Valores = new string[2][];
                //if (infoEmision.ConductorHabitual)
                //{
                //    objeto.Valores[0] = new string[] { infoEmision.DetalleUsuario.Nombre + " " + infoEmision.DetalleUsuario.NombreDos, infoEmision.DetalleUsuario.ApellidoPaterno, infoEmision.DetalleUsuario.ApellidoMaterno, infoEmision.Email, infoEmision.DetalleUsuario.Correo, "Usu4r10$lO" };
                //    objeto.Valores[1] = new string[] { infoEmision.DatosUsuario.Direccion.Calle, infoEmision.DatosUsuario.Direccion.NumeroExt, infoEmision.DatosUsuario.Direccion.NumeroInt, infoEmision.DatosUsuario.Direccion.CodigoPostal, infoEmision.DatosUsuario.Direccion.Colonia, infoEmision.DatosUsuario.Direccion.Municipio, infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Estado };
                //}
                //else
                //{
                cCoDeRnd Decodificador = new cCoDeRnd("SICASSecuryte_SICASWS_Online");
                string pwdUsr = Decodificador.Encrypt("Usu4r10$lO");
                string Calle = "Av. SantaFe";
                string NumeroExt = "481";
                string NumeroInt = "19";
                string CP = "";
                string Asentamiento = "Cuajimalpa";
                string Municipio = "Cruz Manca";
                string Estado = "CDMX";

                Direccion direccion = infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion;
                if (direccion != null)
                {
                    Calle = string.IsNullOrEmpty(direccion.Calle) ? Calle : direccion.Calle; ;
                    NumeroExt = string.IsNullOrEmpty(direccion.NumeroExt) ? NumeroExt : direccion.NumeroExt;
                    NumeroInt = string.IsNullOrEmpty(direccion.NumeroInt) ? NumeroInt : direccion.NumeroInt;
                    CP = string.IsNullOrEmpty(direccion.CodigoPostal) ? CP : direccion.CodigoPostal;

                    if (direccion.CatCodigoPostal != null)
                    {
                        Asentamiento = string.IsNullOrEmpty(direccion.CatCodigoPostal.Asentamiento) ? Asentamiento : direccion.CatCodigoPostal.Asentamiento;
                        Municipio = string.IsNullOrEmpty(direccion.CatCodigoPostal.Municipio) ? Asentamiento : direccion.CatCodigoPostal.Municipio;
                        if (direccion.CatCodigoPostal.CatEstadosRepublica != null)
                            Estado = string.IsNullOrEmpty(direccion.CatCodigoPostal.CatEstadosRepublica.Estado) ? Estado : direccion.CatCodigoPostal.CatEstadosRepublica.Estado;
                    }

                }


                objeto.Valores[0] = new string[] { !string.IsNullOrEmpty(infoEmision.DetalleUsuario.NombreDos) ? infoEmision.DetalleUsuario.Nombre + " " + infoEmision.DetalleUsuario.NombreDos : infoEmision.DetalleUsuario.Nombre, infoEmision.DetalleUsuario.ApellidoPaterno, infoEmision.DetalleUsuario.ApellidoMaterno, infoEmision.DetalleUsuario.Correo, infoEmision.DetalleUsuario.Correo, pwdUsr, infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("yyyy/MM/dd"), (DateTime.Now.Year - infoEmision.DetalleUsuario.FECHANACIMIENTO.Year).ToString(), infoEmision.DetalleUsuario.GENERO.Equals("Masculino") ? "1" : "2", string.IsNullOrEmpty(infoEmision.DetalleUsuario.RFC) ? "" : infoEmision.DetalleUsuario.RFC, infoEmision.Empresa.IdGerenciaCORE, infoEmision.TelefonoCel, infoEmision.TelefonoFijo, "1" };
                //objeto.Valores[1] = new string[] {
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.Calle) ? "Av. SantaFe" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.Calle,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.NumeroExt) ? "481" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.NumeroExt,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.NumeroInt) ? "19" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.NumeroInt,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CodigoPostal) ? "" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CodigoPostal,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatCodigoPostal.Asentamiento) ? "Cuajimalpa" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatCodigoPostal.Asentamiento,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatCodigoPostal.Municipio) ? "Cruz Manca" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatCodigoPostal.Municipio,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatEstadosRepublica.Estado) ? "CDMX" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatEstadosRepublica.Estado,
                //                                infoEmision.Empresa.Corporativo.IdGrupoCORE };
                objeto.Valores[1] = new string[] { Calle, NumeroExt, NumeroInt, CP, Asentamiento, Municipio, Estado, infoEmision.Empresa.Corporativo.IdGrupoCORE };
                //}

                string ejecutaBD = insertaBD.EjecucionBaseDatos(objeto).RespuestaJSON;
                ejecutaBD = ejecutaBD.Replace("[", "").Replace("]", "");
                ClienteInsertadoCore cliente = serializer.Deserialize<ClienteInsertadoCore>(ejecutaBD);
                log.Info(string.Concat("Se insertó correctamente el cliente: ", cliente.IdCliente.ToString(), " contacto: ", cliente.IdContacto.ToString()));
                DetalleUsuario dtUsr = db.DetalleUsuario.Find(infoEmision.DetalleUsuario.Id);
                dtUsr.IdCliCORE = cliente.IdCliente.ToString();
                dtUsr.IdContCORE = cliente.IdContacto.ToString();
                infoEmision.DetalleUsuario.IdCliCORE = cliente.IdCliente.ToString();
                infoEmision.DetalleUsuario.IdContCORE = cliente.IdContacto.ToString();
                db.Entry(dtUsr).State = EntityState.Modified;
                db.SaveChanges();
                return cliente.IdContacto;
            }
            catch (Exception ex)
            {
                log.Info("DerivaUsuarioFinalCore: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
                return -1;
            }
        }
        private int DerivaUsuarioFinalCoreCasa(InformacionEmision infoEmision)
        {
            InsercionSICASClient insertaBD = new InsercionSICASClient();
            DatosCliente respuestaWS = new DatosCliente();
            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            try
            {
                ObjetoBD objeto = new ObjetoBD();
                objeto.Modulo = Modulo.Usuario;
                objeto.Opcion = OpcionBD.Insercion;
                objeto.Metodo = Metodo.InsertaUsuarioFinal;
                objeto.Valores = new string[2][];
                //if (infoEmision.ConductorHabitual)
                //{
                //    objeto.Valores[0] = new string[] { infoEmision.DetalleUsuario.Nombre + " " + infoEmision.DetalleUsuario.NombreDos, infoEmision.DetalleUsuario.ApellidoPaterno, infoEmision.DetalleUsuario.ApellidoMaterno, infoEmision.Email, infoEmision.DetalleUsuario.Correo, "Usu4r10$lO" };
                //    objeto.Valores[1] = new string[] { infoEmision.DatosUsuario.Direccion.Calle, infoEmision.DatosUsuario.Direccion.NumeroExt, infoEmision.DatosUsuario.Direccion.NumeroInt, infoEmision.DatosUsuario.Direccion.CodigoPostal, infoEmision.DatosUsuario.Direccion.Colonia, infoEmision.DatosUsuario.Direccion.Municipio, infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Estado };
                //}
                //else
                //{
                cCoDeRnd Decodificador = new cCoDeRnd("SICASSecuryte_SICASWS_Online");
                string pwdUsr = Decodificador.Encrypt("Usu4r10$lO");
                string Calle = "Av. SantaFe";
                string NumeroExt = "481";
                string NumeroInt = "19";
                string CP = "";
                string Asentamiento = "Cuajimalpa";
                string Municipio = "Cruz Manca";
                string Estado = "CDMX";

                Direccion direccion = infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion;
                if (direccion != null)
                {
                    Calle = string.IsNullOrEmpty(direccion.Calle) ? Calle : direccion.Calle; ;
                    NumeroExt = string.IsNullOrEmpty(direccion.NumeroExt) ? NumeroExt : direccion.NumeroExt;
                    NumeroInt = string.IsNullOrEmpty(direccion.NumeroInt) ? NumeroInt : direccion.NumeroInt;
                    CP = string.IsNullOrEmpty(direccion.CodigoPostal) ? CP : direccion.CodigoPostal;

                    if (direccion.CatCodigoPostal != null)
                    {
                        Asentamiento = string.IsNullOrEmpty(direccion.CatCodigoPostal.Asentamiento) ? Asentamiento : direccion.CatCodigoPostal.Asentamiento;
                        Municipio = string.IsNullOrEmpty(direccion.CatCodigoPostal.Municipio) ? Asentamiento : direccion.CatCodigoPostal.Municipio;
                        if (direccion.CatCodigoPostal.CatEstadosRepublica != null)
                            Estado = string.IsNullOrEmpty(direccion.CatCodigoPostal.CatEstadosRepublica.Estado) ? Estado : direccion.CatCodigoPostal.CatEstadosRepublica.Estado;
                    }

                }


                objeto.Valores[0] = new string[] { !string.IsNullOrEmpty(infoEmision.DetalleUsuario.NombreDos) ? infoEmision.DetalleUsuario.Nombre + " " + infoEmision.DetalleUsuario.NombreDos : infoEmision.DetalleUsuario.Nombre, infoEmision.DetalleUsuario.ApellidoPaterno, infoEmision.DetalleUsuario.ApellidoMaterno, infoEmision.DetalleUsuario.Correo, infoEmision.DetalleUsuario.Correo, pwdUsr, infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("yyyy/MM/dd"), (DateTime.Now.Year - infoEmision.DetalleUsuario.FECHANACIMIENTO.Year).ToString(), infoEmision.DetalleUsuario.GENERO.Equals("Masculino") ? "1" : "2", string.IsNullOrEmpty(infoEmision.DetalleUsuario.RFC) ? "" : infoEmision.DetalleUsuario.RFC, infoEmision.Empresa.IdGerenciaCORE, infoEmision.TelefonoCel, infoEmision.TelefonoFijo, "1" };
                //objeto.Valores[1] = new string[] {
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.Calle) ? "Av. SantaFe" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.Calle,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.NumeroExt) ? "481" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.NumeroExt,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.NumeroInt) ? "19" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.NumeroInt,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CodigoPostal) ? "" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CodigoPostal,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatCodigoPostal.Asentamiento) ? "Cuajimalpa" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatCodigoPostal.Asentamiento,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatCodigoPostal.Municipio) ? "Cruz Manca" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatCodigoPostal.Municipio,
                //                                string.IsNullOrEmpty(infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatEstadosRepublica.Estado) ? "CDMX" : infoEmision.Poliza.PolizaDetalle.FirstOrDefault().Direccion.CatEstadosRepublica.Estado,
                //                                infoEmision.Empresa.Corporativo.IdGrupoCORE };
                objeto.Valores[1] = new string[] { Calle, NumeroExt, NumeroInt, CP, Asentamiento, Municipio, Estado, infoEmision.Empresa.Corporativo.IdGrupoCORE };
                //}

                string ejecutaBD = insertaBD.EjecucionBaseDatos(objeto).RespuestaJSON;
                ejecutaBD = ejecutaBD.Replace("[", "").Replace("]", "");
                ClienteInsertadoCore cliente = serializer.Deserialize<ClienteInsertadoCore>(ejecutaBD);
                log.Info(string.Concat("Se insertó correctamente el cliente: ", cliente.IdCliente.ToString(), " contacto: ", cliente.IdContacto.ToString()));
                DetalleUsuario dtUsr = db.DetalleUsuario.Find(infoEmision.DetalleUsuario.Id);
                dtUsr.IdCliCORE = cliente.IdCliente.ToString();
                dtUsr.IdContCORE = cliente.IdContacto.ToString();
                infoEmision.DetalleUsuario.IdCliCORE = cliente.IdCliente.ToString();
                infoEmision.DetalleUsuario.IdContCORE = cliente.IdContacto.ToString();
                db.Entry(dtUsr).State = EntityState.Modified;
                db.SaveChanges();
                return cliente.IdContacto;
            }
            catch (Exception ex)
            {
                log.Info("DerivaUsuarioFinalCore: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
                return -1;
            }
        }
        public class ClienteInsertadoCore { public int IdCliente; public int IdContacto; }

        private string DerivaPolizaNueva(InformacionEmision InfoEmision, string IdCont)
        {
            InfoData Datos = new InfoData();
            //genera seccion DatDocumentos
            if (!InfoEmision.EsPromotor)
            {
                Datos.DatDocumentos = RegistroDatosDerivaPolizaNueva(InfoEmision);
                Datos.DatDoctoDetail = RegistroDetalleDerivaPolizaNueva(InfoEmision, IdCont);
            }
            else
            {
                Datos.DatDocumentos = RegistroDatosDerivaPolizaNuevaPromotores(InfoEmision);
                Datos.DatDoctoDetail = RegistroDetalleDerivaPolizaNuevaPromotores(InfoEmision, IdCont);
            }
            if (Datos.DatDocumentos.Exitoso)
                //genera xml
                return GeneraXml(Datos);
            else
            {
                PolizaDetalle polizaDetalle = new PolizaDetalle();
                int idPolizadetalle = InfoEmision.Poliza.PolizaDetalle.FirstOrDefault().Id;
                polizaDetalle = db.PolizaDetalle.FirstOrDefault(x => x.Id == idPolizadetalle);
                polizaDetalle.MensajeCore = Datos.DatDocumentos.MensajeError;
                db.Entry(polizaDetalle).State = EntityState.Modified;
                db.SaveChanges();

                return string.Empty;
            }
        }
        private string DerivaPolizaNuevaCasa(InformacionEmision InfoEmision, string IdCont)
        {
            InfoData Datos = new InfoData();
            //genera seccion DatDocumentos
            Datos.DatDocumentos = RegistroDatosDerivaPolizaCasaNueva(InfoEmision);
            Datos.DatDoctoDetail = RegistroDetalleDerivaPolizaNuevaCasa(InfoEmision, IdCont);

            if (Datos.DatDocumentos.Exitoso)
                //genera xml
                return GeneraXml(Datos);
            else
            {
                PolizaDetalleCasa polizaDetalle = new PolizaDetalleCasa();
                int idPolizadetalle = InfoEmision.PolizaCasaDetalle.Id;
                polizaDetalle = db.PolizaDetalleCasa.FirstOrDefault(x => x.Id == idPolizadetalle);
                polizaDetalle.MensajeCore = Datos.DatDocumentos.MensajeError;
                db.Entry(polizaDetalle).State = EntityState.Modified;
                db.SaveChanges();

                return string.Empty;
            }
        }

        private string DerivaPolizaNuevaProducto(InformacionEmision InfoEmision, string IdCont)
        {
            InfoData Datos = new InfoData();
            //genera seccion DatDocumentos
            Datos.DatDocumentos = RegistroDatosDerivaPolizaProductoNueva(InfoEmision);
            Datos.DatDoctoDetail = RegistroDetalleDerivaPolizaNuevaProducto(InfoEmision, IdCont);

            if (Datos.DatDocumentos.Exitoso)
                //genera xml
                return GeneraXml(Datos);
            else
            {

                int idPolizadetalle = InfoEmision.PolizaProductoDetalle.Id;
                var polizaDetalle = db.PolizaProductoDetalle.FirstOrDefault(x => x.Id == idPolizadetalle);
                polizaDetalle.MensajeCore = Datos.DatDocumentos.MensajeError;
                db.Entry(polizaDetalle).State = EntityState.Modified;
                db.SaveChanges();

                return string.Empty;
            }
        }

        private string DerivaPolizaOTProducto(InformacionEmision InfoEmision, string IdCont)
        {
            InfoData Datos = new InfoData();
            //genera seccion DatDocumentos
            Datos.DatDocumentos = RegistroDatosDerivaPolizaOTProducto(InfoEmision);
            Datos.DatDoctoDetail = RegistroDetalleDerivaPolizaNuevaProducto(InfoEmision, IdCont);

            if (Datos.DatDocumentos.Exitoso)
                //genera xml
                return GeneraXml(Datos);
            else
            {

                int idPolizadetalle = InfoEmision.PolizaProductoDetalle.Id;
                var polizaDetalle = db.PolizaProductoDetalle.FirstOrDefault(x => x.Id == idPolizadetalle);
                polizaDetalle.MensajeCore = Datos.DatDocumentos.MensajeError;
                db.Entry(polizaDetalle).State = EntityState.Modified;
                db.SaveChanges();

                return string.Empty;
            }
        }

        private DatDocumentos RegistroDatosDerivaPolizaNueva(InformacionEmision InfoEmision)
        {
            DatDocumentos DatoDocumento = new DatDocumentos();
            ApplicationDbContext db = new ApplicationDbContext();
            DatoDocumento.Exitoso = true;
            string _c = "";
            var cotizaciondetalle = db.CotizacionDetalle.Find(InfoEmision.IdCotizacion);
            var cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizaciondetalle.IdCotizacion);

            try
            {

                _c = "polDetalle";

                System.Collections.Generic.List<LocktonModel.db.PolizaDetalle> polDetalle = new System.Collections.Generic.List<LocktonModel.db.PolizaDetalle>(InfoEmision.Poliza.PolizaDetalle);
                var _pdetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == InfoEmision.Poliza.Id);
                _c = "polDetaObtieneDatosClienteDerCORElle";
                if (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdCliCORE) || string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdContCORE))
                {
                    log.Info("RegistroDatosDerivaPolizaNueva: IdCliCORE ó IdContCORRE invalidos ");
                }
                //string Agente = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales/Agente")[0].InnerText;
                DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.DetalleUsuario.IdCliCORE, InfoEmision.DetalleUsuario.IdContCORE, InfoEmision.Empresa.IdGerenciaCORE);
                _c = "periodicidadFormaPago";
                PeriodicidadFormaPago periodicidadFormaPago = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
                _c = "Subramo";
                string Subramo = db.CatSubRamoVehiculo.Where(x => x.IdCatSubRamo == InfoEmision.Convenio.IdSubRamoVehiculo).Select(y => y.Clave).FirstOrDefault();
                //RespuestaWS datacoreAgente = new RespuestaWS(false, "");
                //if(InfoEmision.Convenio.ClaveAgente > 0)
                //    datacoreAgente = ObtieneIdAgente(InfoEmision.Convenio.ClaveAgente.ToString());

                //DatoDocumento.IDDocto = InfoEmision.NoPoliza; //no lleva por que es nuevo
                _c = "Subramo";
                DatoDocumento.IDDocto = "-1";
                DatoDocumento.TipoDocto = "1";//siempre uno
                _c = "DetalleUsuario";
                DatoDocumento.IDCli = InfoEmision.DetalleUsuario.IdCliCORE;//IDCLICORE de detalleusuario
                DatoDocumento.IDSRamo = Subramo;//IDSRamo | 17 AUTOMOVILES INDIVIDUALES
                _c = "IdGrupoCORE";
                DatoDocumento.IDGrupo = InfoEmision.Empresa.Corporativo.IdGrupoCORE;//IDGrupo | 40--63
                _c = "IDSGrupo";
                DatoDocumento.IDSGrupo = datacoreCliente.IDSGrupo;//IDGrupo | 40
                _c = "ObtieneIdAgente";
                AseguradoraAgenteCore aseguradoraAgenteCore = new AseguradoraAgenteCore();
                if (InfoEmision.Convenio.IdAseguradora == 1 || InfoEmision.Convenio.IdAseguradora == 27)
                {
                    var catModalidadPago = db.CatModalidadFormaPago.Where(x => x.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString()).FirstOrDefault();
                    var perio = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
                    var ClaveAgenteModalidadFPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == perio.IdCatPeriodicidadFormaPago && x.IdCatModalidadFormaPago == catModalidadPago.Id).FirstOrDefault();
                    aseguradoraAgenteCore = ObtieneIdAgente(ClaveAgenteModalidadFPago.ClaveAgenteModalidadFormaPago);
                }
                else
                {
                    aseguradoraAgenteCore = ObtieneIdAgente(periodicidadFormaPago.ClaveAgente);
                }
                if (aseguradoraAgenteCore != null)
                {
                    DatoDocumento.IDAgente = aseguradoraAgenteCore.IdAgente;// "22";//IDAgente | 10--
                }

                if (!aseguradoraAgenteCore.Exitoso)
                {
                    DatoDocumento.Exitoso = false;
                    DatoDocumento.MensajeError = aseguradoraAgenteCore.Mensaje;
                }

                _c = "IDFPago";
                DatoDocumento.IDFPago = _pdetalle.CatPeriodicidadFormaPago?.ClaveBogo ?? _pdetalle.IdCatPeriodicidadFormaPago.ToString();//IDFPago | 4

                if (InfoEmision.Convenio.IdAseguradora == 1 && cotizaciondetalle.IdCatPeriodicidadMultianual > 0)
                {
                    var multianualCore = db.CatPeriodicidadMultianualCORE.FirstOrDefault(a => a.IdCatPeriodicidadMultianual == cotizaciondetalle.IdCatPeriodicidadMultianual && a.IdCatPeriodicidadFormaPago == cotizaciondetalle.IdFormaPago);
                    if (multianualCore != null)
                    {
                        DatoDocumento.IDFPago = multianualCore.IDFPago_Core.ToString();
                    }
                }

                DatoDocumento.IDMon = "1";//IDMon | 1 Moneda Nacional
                _c = "IDEjecut";
                DatoDocumento.IDEjecut = datacoreCliente.IDEjecut;//IDEjecut | 25--39
                DatoDocumento.IDVend = "7";//IDVend | 1---


                _c = "PrimaNeta";
                DatoDocumento.FDesde = InfoEmision.Poliza.InicioVigencia.ToString("dd/MM/yyyy");//FDesde | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FHasta = InfoEmision.Poliza.FinVigencia.ToString("dd/MM/yyyy");//FHasta | 01 / 11 / 2019 12:00:00 a.m.
                DatoDocumento.PrimaNeta = InfoEmision.Poliza.PrimaNeta.ToString();//PrimaNeta | 3924.1
                _c = "Derechos";
                DatoDocumento.Derechos = polDetalle[0].Derechos.ToString();//Derechos | 360
                _c = "STotal";
                DatoDocumento.STotal = (InfoEmision.Poliza.PrimaNeta + polDetalle[0].Derechos + polDetalle[0].Recargos).ToString();
                _c = "Impuesto1";
                DatoDocumento.Impuesto1 = polDetalle[0].Impuesto.ToString(); //Impuesto1 | 591.28
                _c = "PrimaTotal";
                DatoDocumento.PorImp1 = polDetalle[0].FactorIva.ToString(); //Iva
                _c = "FactorIva";
                DatoDocumento.PrimaTotal = InfoEmision.Poliza.PrimaTotal.ToString();//PrimaTotal | 4286.76
                DatoDocumento.Status = "0";//Status | 0   Status_TXT == VIGENTE
                _c = "Concepto";
                DatoDocumento.Concepto = string.Concat(InfoEmision.CotizacionAutoGuardar.Marca, " ", InfoEmision.CotizacionAutoGuardar.Descripcion);//"Automoviles Individuales";//Concepto | MARCH SENSE 1.6L AUT. 05 OCUP.   
                _c = "IDDespacho";
                DatoDocumento.IDDespacho = datacoreCliente.IDDespacho;//IDDespacho | 28--49
                _c = "IDGerencia";
                DatoDocumento.IDGerencia = InfoEmision.Empresa.IdGerenciaCORE;//IDGerencia | 27   Empresa--50
                DatoDocumento.StatusCob = "1";//StatusCob | 1 no pagada, Si la forma de pago es contado o anual se marca la poliza como pagada 2
                DatoDocumento.TCCobro = "1";//TCCobro | 1 compañia
                                            //DatoDocumento.StatusUser = "";//StatusUser | 4
                if (!InfoEmision.ConDatosBancarios)
                    DatoDocumento.StatusUser = "30";

                DatoDocumento.TVenta = "5";//TVenta | 5	On-Line
                _c = "TPago";
                DatoDocumento.TPago = _pdetalle.CatModalidadFormaPago.ClaveBogo;//TPago | 3 1a1 CatModalidadFormaPago
                DatoDocumento.ClasDocto = "4";//ClasDocto | 4 NUEVA
                DatoDocumento.IDLineBuss = InfoEmision.EsFlotilla ? "1" : "2"; ;//IDLineBuss | 1 LOCKTON MÉXICO
                DatoDocumento.DAnterior = "SOLICITUD NUEVA";//DAnterior | SOLICITUD NUEVA
                DatoDocumento.CCobro = "1";//CCobro | 0? 1 Agente 2 Compañia
                _c = "Referencia1";
                if (InfoEmision.EsFlotilla && InfoEmision.Poliza != null && InfoEmision.Poliza.Convenio != null)
                {
                    DatoDocumento.Referencia1 = InfoEmision.Poliza.Convenio.CaratulaPoliza;
                    //DatoDocumento.Notas = InfoEmision.Poliza.Convenio.CaratulaPoliza;
                }
                else
                {
                    DatoDocumento.Referencia1 = "POLIZA INDIVIDUAL";//Referencia1 |
                                                                    //DatoDocumento.Notas = "POLIZA INDIVIDUAL";//Notas | LOCKTON EMPLEADOS MENSUAL 2018 - 2019
                }

                DatoDocumento.Notas = "";
                if (!string.IsNullOrEmpty(InfoEmision.SelectOpcionConcatenada))
                    DatoDocumento.Notas = InfoEmision.SelectOpcionConcatenada;

                if (!string.IsNullOrEmpty(cotizacion.Membresia))
                    DatoDocumento.Notas = $" Membresia Costco: {cotizacion.Membresia}";

                if (InfoEmision.EsBeneficiarioPreferente)
                {
                    _c = "Referencia2";
                    DatoDocumento.Referencia2 = InfoEmision.BeneficiarioPreferente;
                }
                _c = "Referencia3";
                DatoDocumento.Referencia3 = !string.IsNullOrEmpty(InfoEmision.UrlReimpresionEncriptada) ? InfoEmision.UrlReimpresionEncriptada : InfoEmision.Poliza.UrlPDFPoliza;//Referencia3 | http://qbcenter.qualitas.com.mx/poliza/p3190166283.pdf
                DatoDocumento.IsEspecial = "0";//IsEspecial | 0
                                               //DatoDocumento.Comentario = "";//Comentario | no se captura
                _c = "FSolicitud";
                DatoDocumento.FSolicitud = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//Fsolicitud | 13 / 03 / 2019 12:00:00 a.m.
                _c = "FEmision";
                DatoDocumento.FEmision = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//FEmision | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FRecepcion = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//FRecepcion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FConversion = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//FConversion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FEnvio = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//FEnvio | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.Documento = InfoEmision.Poliza.NumeroPoliza;//Documento | 3190166283     es el numero de poliza de la aseguradora
                _c = "Recargos";
                DatoDocumento.Recargos = polDetalle[0].Recargos.ToString();//Recargos | 0.00
                _c = "Referencia4";
                DatoDocumento.Referencia4 = InfoEmision.IdSucursal != 0 ? InfoEmision.IdSucursal.ToString() : "";
                _c = "Referencia5";
                DatoDocumento.Referencia5 = polDetalle[0].FechaDecisionRenovacionAutomaticaUtc.HasValue
                    ? (polDetalle[0].RenovacionAutomatica ? "SI" : "NO")
                    : ""; // CAT Renovación automática: no deriva como aceptación un valor histórico sin evidencia de decisión.
                if (periodicidadFormaPago.IdPolizaMaestra.HasValue)
                {
                    DatoDocumento.IDPolMta = periodicidadFormaPago.IdPolizaMaestra.ToString();

                }
                if (!string.IsNullOrEmpty(InfoEmision.Inciso))
                {
                    DatoDocumento.Inciso = InfoEmision.Inciso;
                }

                //TarifaDesc | 57
                //DatDoctoDetail.DescuentoAutos | 57

            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message) + ". Referencia linea: " + _c);
            }
            return DatoDocumento;
        }

        private DatDocumentos RegistroDatosDerivaPolizaCasaNueva(InformacionEmision InfoEmision)
        {
            DatDocumentos DatoDocumento = new DatDocumentos();
            ApplicationDbContext db = new ApplicationDbContext();
            DatoDocumento.Exitoso = true;
            string _c = "";
            try
            {

                _c = "polDetalle";

                LocktonModel.db.PolizaDetalleCasa polDetalle = InfoEmision.PolizaCasaDetalle;
                _c = "polDetaObtieneDatosClienteDerCORElle";
                if (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdCliCORE) || string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdContCORE))
                {
                    log.Info("RegistroDatosDerivaPolizaNueva: IdCliCORE ó IdContCORRE invalidos ");
                }
                //string Agente = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales/Agente")[0].InnerText;
                DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.DetalleUsuario.IdCliCORE, InfoEmision.DetalleUsuario.IdContCORE, InfoEmision.Empresa.IdGerenciaCORE);
                //_c = "periodicidadFormaPago";
                //int formaPago = Convert.ToInt32(InfoEmision.PolizaCasa.FormaPago);
                //int idConvenioProducto = InfoEmision.ConvenioProducto.Id;
                //List<PeriodicidadFormaPagoProducto> periodicidadFormaPago = db.PeriodicidadFormaPagoProducto.Where(x => x.IdConvenioProducto.Equals(idConvenioProducto) && x.IdCatPeriodicidadFormaPagoProducto.Equals(formaPago)).ToList();
                _c = "Subramo";
                string Subramo = "29";//db.CatSubRamoVehiculo.Where(x => x.IdCatSubRamo == InfoEmision.Convenio.IdSubRamoVehiculo).Select(y => y.Clave).FirstOrDefault();
                                      //RespuestaWS datacoreAgente = new RespuestaWS(false, "");
                                      //if(InfoEmision.Convenio.ClaveAgente > 0)
                                      //    datacoreAgente = ObtieneIdAgente(InfoEmision.Convenio.ClaveAgente.ToString());

                //DatoDocumento.IDDocto = InfoEmision.NoPoliza; //no lleva por que es nuevo
                _c = "";
                string IdCont = "";
                RespuestaWS GenContacto = DerivaContactoCore(InfoEmision);

                if (GenContacto.Mensaje.Contains("NewIDValue"))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(GenContacto.Mensaje);
                    IdCont = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
                }
                DatoDocumento.IDYo = IdCont;
                _c = "Subramo";
                DatoDocumento.IDDocto = "-1";
                DatoDocumento.TipoDocto = "1";//siempre uno
                _c = "DetalleUsuario";
                DatoDocumento.IDCli = InfoEmision.DetalleUsuario.IdCliCORE;//IDCLICORE de detalleusuario
                DatoDocumento.IDSRamo = Subramo;//IDSRamo | 29
                _c = "IdGrupoCORE";
                DatoDocumento.IDGrupo = InfoEmision.Empresa.Corporativo.IdGrupoCORE;//IDGrupo | 40--63
                _c = "IDSGrupo";
                DatoDocumento.IDSGrupo = datacoreCliente.IDSGrupo;//IDGrupo | 40
                _c = "ObtieneIdAgente";
                AseguradoraAgenteCore aseguradoraAgenteCore = new AseguradoraAgenteCore();
                aseguradoraAgenteCore = ObtieneIdAgente(InfoEmision.ConvenioProducto.UsuarioAgente.ToString()); //Tomar clave agente
                if (aseguradoraAgenteCore != null)
                {
                    DatoDocumento.IDAgente = aseguradoraAgenteCore.IdAgente;// "22";//IDAgente | 10--
                }
                if (!aseguradoraAgenteCore.Exitoso)
                {
                    DatoDocumento.Exitoso = false;
                    DatoDocumento.MensajeError = aseguradoraAgenteCore.Mensaje;
                }

                //_c = "Concepto";
                //DatoDocumento.Concepto = InfoEmision.Paquete;

                _c = "IDFPago";
                //DatoDocumento.IDFPago = InfoEmision.PolizaCasa.FormaPago?.ClaveBogo ?? polDetalle.IdCatPeriodicidadFormaPagoProducto.ToString();//IDFPago | 4
                var mtodoPago = int.Parse(InfoEmision.PolizaCasa.MetodoPago);
                var frmPago = int.Parse(InfoEmision.PolizaCasa.FormaPago);
                var catModalidadFPago = db.CatModalidadFormaPagoProducto.Where(x => x.Id.Equals(mtodoPago)).FirstOrDefault();
                var perioricidadFPago = db.CatPeriodicidadFormaPagoProducto.Where(x => x.Id.Equals(frmPago)).FirstOrDefault();
                DatoDocumento.IDFPago = perioricidadFPago.ClaveBogo;
                DatoDocumento.IDMon = "1";//IDMon | 1 Moneda Nacional
                _c = "IDEjecut";
                DatoDocumento.IDEjecut = datacoreCliente.IDEjecut;//IDEjecut | 26
                DatoDocumento.IDVend = "7";//IDVend | 1---


                _c = "PrimaNeta";
                DatoDocumento.FDesde = InfoEmision.PolizaCasa.Inicio_Vigencia.ToString("dd/MM/yyyy");//FDesde | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FHasta = InfoEmision.PolizaCasa.Fin_Vigencia.ToString("dd/MM/yyyy");//FHasta | 01 / 11 / 2019 12:00:00 a.m.
                DatoDocumento.PrimaNeta = (Convert.ToDecimal((InfoEmision.PolizaCasa.Prima_Total)) / ((polDetalle.FactorIva / 100) + 1)).ToString();//InfoEmision.PolizaCasa.Prima_Total.ToString();//PrimaNeta | 3924.1
                _c = "Derechos";
                DatoDocumento.Derechos = "0";// polDetalle.Derechos.ToString();//Derechos | 360
                _c = "STotal";
                DatoDocumento.STotal = (Convert.ToDecimal(DatoDocumento.PrimaNeta) + 0 + polDetalle.Recargos).ToString();
                _c = "Impuesto1";
                DatoDocumento.Impuesto1 = (Convert.ToDecimal(DatoDocumento.PrimaNeta) * (polDetalle.FactorIva / 100)).ToString(); //Impuesto1 | 591.28
                _c = "PrimaTotal";
                DatoDocumento.PorImp1 = polDetalle.FactorIva.ToString(); //Iva
                _c = "FactorIva";
                DatoDocumento.PrimaTotal = InfoEmision.PolizaCasa.Prima_Total.ToString();//PrimaTotal | 4286.76
                DatoDocumento.Status = "0";//Status | 0   Status_TXT == VIGENTE
                _c = "Concepto";//TipoContratante + Año + Paquete
                var dbCatTipoContratante = db.CatTipoContratanteCasa.Where(x => x.Clave.Equals(InfoEmision.PolizaCasa.Codigo_Producto) || x.ClaveEjecutivo == InfoEmision.PolizaCasa.Codigo_Producto).FirstOrDefault();
                var cotizacion = db.CotizacionDatosCasa.Where(x => x.Id.Equals(InfoEmision.PolizaCasa.IdCotizacion)).FirstOrDefault();
                DatoDocumento.Concepto = dbCatTipoContratante.Nombre + " / " + cotizacion.AnioConstruccion + " / " + InfoEmision.Paquete;
                _c = "IDDespacho";
                DatoDocumento.IDDespacho = datacoreCliente.IDDespacho;//IDDespacho | 28--49
                _c = "IDGerencia";
                DatoDocumento.IDGerencia = InfoEmision.Empresa.IdGerenciaCORE;//IDGerencia | 27   Empresa--50
                DatoDocumento.StatusCob = "1";//StatusCob | 1 no pagada, Si la forma de pago es contado o anual se marca la poliza como pagada 2
                DatoDocumento.TCCobro = "1";//TCCobro | 1 compañia
                                            //DatoDocumento.StatusUser = "";//StatusUser | 4
                DatoDocumento.TVenta = "5";//TVenta | 5	On-Line
                _c = "TPago";
                DatoDocumento.TPago = catModalidadFPago.ClaveBogo;//TPago | 3 1a1 CatModalidadFormaPago
                DatoDocumento.ClasDocto = "4";//ClasDocto | 4 NUEVA
                DatoDocumento.IDLineBuss = "2"; ;//IDLineBuss | 1 LOCKTON MÉXICO
                DatoDocumento.DAnterior = "SOLICITUD NUEVA";//DAnterior | SOLICITUD NUEVA
                DatoDocumento.CCobro = "1";//CCobro | 0? 1 Agente 2 Compañia
                if (!string.IsNullOrEmpty(cotizacion.Membresia))
                    DatoDocumento.Notas = $" Membresia Costco: {cotizacion.Membresia}";

                _c = "Referencia3";
                DatoDocumento.IsEspecial = "0";//IsEspecial | 0
                                               //DatoDocumento.Comentario = "";//Comentario | no se captura
                _c = "FSolicitud";
                DatoDocumento.FSolicitud = InfoEmision.PolizaCasa.Fecha.ToString("dd/MM/yyyy");//Fsolicitud | 13 / 03 / 2019 12:00:00 a.m.
                _c = "FEmision";
                DatoDocumento.FEmision = InfoEmision.PolizaCasa.Fecha.ToString("dd/MM/yyyy");//FEmision | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FRecepcion = InfoEmision.PolizaCasa.Fecha.ToString("dd/MM/yyyy");//FRecepcion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FConversion = InfoEmision.PolizaCasa.Fecha.ToString("dd/MM/yyyy");//FConversion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FEnvio = InfoEmision.PolizaCasa.Fecha.ToString("dd/MM/yyyy");//FEnvio | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.Documento = InfoEmision.PolizaCasa.NumeroPoliza;//Documento | 3190166283     es el numero de poliza de la aseguradora
                _c = "Recargos";
                DatoDocumento.Recargos = polDetalle.Recargos.ToString();//Recargos | 0.00
                DatoDocumento.IDPolMta = "0";

            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message) + ". Referencia linea: " + _c);
            }
            return DatoDocumento;
        }

        private DatDocumentos RegistroDatosDerivaPolizaProductoNueva(InformacionEmision InfoEmision)
        {
            DatDocumentos DatoDocumento = new DatDocumentos();
            ApplicationDbContext db = new ApplicationDbContext();
            DatoDocumento.Exitoso = true;
            string _c = "";
            try
            {

                _c = "polDetalle";

                var polDetalle = InfoEmision.PolizaProductoDetalle;
                var cotizacionDetalle = db.CotizacionProductoDetalle.Where(x => x.Id.Equals(polDetalle.IdCotizacionDetalle)).FirstOrDefault();
                var cotizacion = db.CotizacionProducto.Where(x => x.Id.Equals(polDetalle.IdCotizacion)).FirstOrDefault();
                var valorIVA = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("IVA"));

                _c = "polDetaObtieneDatosClienteDerCORElle";

                if (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdCliCORE) || string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdContCORE))
                {
                    log.Info("RegistroDatosDerivaPolizaNueva: IdCliCORE ó IdContCORRE invalidos ");
                }
                //string Agente = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales/Agente")[0].InnerText;
                DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.DetalleUsuario.IdCliCORE, InfoEmision.DetalleUsuario.IdContCORE, InfoEmision.Empresa.IdGerenciaCORE);
                //_c = "periodicidadFormaPago";
                //int formaPago = Convert.ToInt32(InfoEmision.PolizaCasa.FormaPago);
                //int idConvenioProducto = InfoEmision.ConvenioProducto.Id;
                //List<PeriodicidadFormaPagoProducto> periodicidadFormaPago = db.PeriodicidadFormaPagoProducto.Where(x => x.IdConvenioProducto.Equals(idConvenioProducto) && x.IdCatPeriodicidadFormaPagoProducto.Equals(formaPago)).ToList();
                _c = "Subramo";
                ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Empresa.Id).FirstOrDefault();
                string Subramo = "53";
                if (configuracionEmpresa.EsClienteAffinity)
                    Subramo = "52";
                //db.CatSubRamoVehiculo.Where(x => x.IdCatSubRamo == InfoEmision.Convenio.IdSubRamoVehiculo).Select(y => y.Clave).FirstOrDefault();
                //RespuestaWS datacoreAgente = new RespuestaWS(false, "");
                //if(InfoEmision.Convenio.ClaveAgente > 0)
                //    datacoreAgente = ObtieneIdAgente(InfoEmision.Convenio.ClaveAgente.ToString());

                //DatoDocumento.IDDocto = InfoEmision.NoPoliza; //no lleva por que es nuevo
                _c = "";
                string IdCont = "";
                RespuestaWS GenContacto = DerivaContactoCore(InfoEmision);

                if (GenContacto.Mensaje.Contains("NewIDValue"))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(GenContacto.Mensaje);
                    IdCont = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
                }
                DatoDocumento.IDYo = IdCont;
                _c = "Subramo";
                DatoDocumento.IDDocto = "-1";
                DatoDocumento.TipoDocto = "1";//siempre uno
                _c = "DetalleUsuario";
                DatoDocumento.IDCli = InfoEmision.DetalleUsuario.IdCliCORE;//IDCLICORE de detalleusuario
                DatoDocumento.IDSRamo = Subramo;//IDSRamo | 29
                _c = "IdGrupoCORE";
                DatoDocumento.IDGrupo = InfoEmision.Empresa.Corporativo.IdGrupoCORE;//IDGrupo | 40--63
                _c = "IDSGrupo";
                DatoDocumento.IDSGrupo = datacoreCliente.IDSGrupo;//IDGrupo | 40
                _c = "ObtieneIdAgente";
                AseguradoraAgenteCore aseguradoraAgenteCore = new AseguradoraAgenteCore();
                aseguradoraAgenteCore = ObtieneIdAgente(InfoEmision.ConvenioProducto.ClaveAgente.ToString()); //Tomar clave agente
                if (aseguradoraAgenteCore != null)
                {
                    DatoDocumento.IDAgente = aseguradoraAgenteCore.IdAgente;// "22";//IDAgente | 10--
                }
                if (!aseguradoraAgenteCore.Exitoso)
                {
                    DatoDocumento.Exitoso = false;
                    DatoDocumento.MensajeError = aseguradoraAgenteCore.Mensaje;
                }

                //_c = "Concepto";
                //DatoDocumento.Concepto = InfoEmision.Paquete;

                _c = "IDFPago";
                //DatoDocumento.IDFPago = InfoEmision.PolizaCasa.FormaPago?.ClaveBogo ?? polDetalle.IdCatPeriodicidadFormaPagoProducto.ToString();//IDFPago | 4
                var mtodoPago = polDetalle.IdCatModalidadFormaPago;
                var frmPago = polDetalle.IdCatPeriodicidadFormaPago;
                var catModalidadFPago = db.CatModalidadFormaPagoProducto.Where(x => x.Id == mtodoPago).FirstOrDefault();
                var perioricidadFPago = db.CatPeriodicidadFormaPagoProducto.Where(x => x.Id == frmPago).FirstOrDefault();
                DatoDocumento.IDFPago = perioricidadFPago.ClaveBogo;
                DatoDocumento.IDMon = "1";//IDMon | 1 Moneda Nacional
                _c = "IDEjecut";
                DatoDocumento.IDEjecut = datacoreCliente.IDEjecut;//IDEjecut | 26
                DatoDocumento.IDVend = "7";//IDVend | 1---


                _c = "PrimaNeta";
                DatoDocumento.FDesde = InfoEmision.PolizaProducto.InicioVigencia.ToString("dd/MM/yyyy");//FDesde | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FHasta = InfoEmision.PolizaProducto.FinVigencia.ToString("dd/MM/yyyy");//FHasta | 01 / 11 / 2019 12:00:00 a.m.
                DatoDocumento.PrimaNeta = InfoEmision.PolizaProducto.PrimaNeta.ToString();
                _c = "Derechos";
                DatoDocumento.Derechos = polDetalle.Derechos.ToString();
                _c = "STotal";
                DatoDocumento.STotal = (Convert.ToDecimal(DatoDocumento.PrimaNeta) + 0 + polDetalle.Derechos).ToString();
                _c = "Impuesto1";
                DatoDocumento.Impuesto1 = polDetalle.Impuesto.ToString();
                _c = "PrimaTotal";
                DatoDocumento.PorImp1 = valorIVA.Valor;
                _c = "FactorIva";
                DatoDocumento.PrimaTotal = InfoEmision.PolizaProducto.PrimaTotal.ToString();//PrimaTotal | 4286.76
                DatoDocumento.Status = "0";//Status | 0   Status_TXT == VIGENTE
                _c = "Concepto";//TipoContratante + Año + Paquete



                DatoDocumento.Concepto = (InfoEmision.PolizaProducto.IdTipoMascota == 1 ? "PERRO" : "GATO") + " / " + InfoEmision.PolizaProducto.NombreMascota + " / " + InfoEmision.PolizaProducto.Raza + " / " + InfoEmision.PolizaProducto.Color + " / " + InfoEmision.PolizaProducto.Genero + " / " + InfoEmision.ColorNariz + " / " + InfoEmision.ColorOjo + " / " + InfoEmision.PolizaProducto.Caracteristicas + " / " + InfoEmision.Enfermedades + " / " + InfoEmision.Chip;
                _c = "IDDespacho";
                DatoDocumento.IDDespacho = datacoreCliente.IDDespacho;//IDDespacho | 28--49
                _c = "IDGerencia";
                DatoDocumento.IDGerencia = InfoEmision.Empresa.IdGerenciaCORE;//IDGerencia | 27   Empresa--50
                DatoDocumento.StatusCob = "1";//StatusCob | 1 no pagada, Si la forma de pago es contado o anual se marca la poliza como pagada 2
                DatoDocumento.TCCobro = "1";//TCCobro | 1 compañia
                                            //DatoDocumento.StatusUser = "";//StatusUser | 4
                DatoDocumento.TVenta = "5";//TVenta | 5	On-Line
                _c = "TPago";
                DatoDocumento.TPago = catModalidadFPago.ClaveBogo;//TPago | 3 1a1 CatModalidadFormaPago
                DatoDocumento.ClasDocto = "4";//ClasDocto | 4 NUEVA
                DatoDocumento.IDLineBuss = "2"; ;//IDLineBuss | 1 LOCKTON MÉXICO
                DatoDocumento.DAnterior = "SOLICITUD NUEVA";//DAnterior | SOLICITUD NUEVA
                DatoDocumento.CCobro = "1";//CCobro | 0? 1 Agente 2 Compañia

                if (!string.IsNullOrEmpty(cotizacion.Membresia))
                    DatoDocumento.Notas = $" Membresia Costco: {cotizacion.Membresia}";

                _c = "Referencia3";
                DatoDocumento.IsEspecial = "0";//IsEspecial | 0
                                               //DatoDocumento.Comentario = "";//Comentario | no se captura
                _c = "FSolicitud";
                DatoDocumento.FSolicitud = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//Fsolicitud | 13 / 03 / 2019 12:00:00 a.m.
                _c = "FEmision";
                DatoDocumento.FEmision = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//FEmision | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FRecepcion = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//FRecepcion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FConversion = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//FConversion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FEnvio = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//FEnvio | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.Documento = InfoEmision.PolizaProducto.NumeroPoliza;//Documento | 3190166283     es el numero de poliza de la aseguradora
                _c = "Recargos";
                DatoDocumento.Recargos = "0.00";//Recargos | 0.00
                DatoDocumento.IDPolMta = "0";

            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message) + ". Referencia linea: " + _c);
            }
            return DatoDocumento;
        }

        private DatDocumentos RegistroDatosDerivaPolizaOTProducto(InformacionEmision InfoEmision)
        {
            DatDocumentos DatoDocumento = new DatDocumentos();
            ApplicationDbContext db = new ApplicationDbContext();
            DatoDocumento.Exitoso = true;
            string _c = "";
            try
            {

                _c = "polDetalle";

                var polDetalle = InfoEmision.PolizaProductoDetalle;
                var cotizacionDetalle = db.CotizacionProductoDetalle.Where(x => x.Id.Equals(polDetalle.IdCotizacionDetalle)).FirstOrDefault();
                var cotizacion = db.CotizacionProducto.Where(x => x.Id.Equals(polDetalle.IdCotizacion)).FirstOrDefault();
                var valorIVA = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("IVA"));

                _c = "polDetaObtieneDatosClienteDerCORElle";

                if (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdCliCORE) || string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdContCORE))
                {
                    log.Info("RegistroDatosDerivaPolizaNueva: IdCliCORE ó IdContCORRE invalidos ");
                }
                //string Agente = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales/Agente")[0].InnerText;
                DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.DetalleUsuario.IdCliCORE, InfoEmision.DetalleUsuario.IdContCORE, InfoEmision.Empresa.IdGerenciaCORE);
                //_c = "periodicidadFormaPago";
                //int formaPago = Convert.ToInt32(InfoEmision.PolizaCasa.FormaPago);
                //int idConvenioProducto = InfoEmision.ConvenioProducto.Id;
                //List<PeriodicidadFormaPagoProducto> periodicidadFormaPago = db.PeriodicidadFormaPagoProducto.Where(x => x.IdConvenioProducto.Equals(idConvenioProducto) && x.IdCatPeriodicidadFormaPagoProducto.Equals(formaPago)).ToList();
                _c = "Subramo";
                ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Empresa.Id).FirstOrDefault();
                string Subramo = "53";
                if (configuracionEmpresa.EsClienteAffinity)
                    Subramo = "52";
                //db.CatSubRamoVehiculo.Where(x => x.IdCatSubRamo == InfoEmision.Convenio.IdSubRamoVehiculo).Select(y => y.Clave).FirstOrDefault();
                //RespuestaWS datacoreAgente = new RespuestaWS(false, "");
                //if(InfoEmision.Convenio.ClaveAgente > 0)
                //    datacoreAgente = ObtieneIdAgente(InfoEmision.Convenio.ClaveAgente.ToString());

                //DatoDocumento.IDDocto = InfoEmision.NoPoliza; //no lleva por que es nuevo
                _c = "";
                string IdCont = "";
                RespuestaWS GenContacto = DerivaContactoCore(InfoEmision);

                if (GenContacto.Mensaje.Contains("NewIDValue"))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(GenContacto.Mensaje);
                    IdCont = xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText;
                }
                DatoDocumento.IDYo = IdCont;
                _c = "Subramo";
                DatoDocumento.IDDocto = "-1";
                DatoDocumento.TipoDocto = "0";//siempre uno
                _c = "DetalleUsuario";
                DatoDocumento.IDCli = InfoEmision.DetalleUsuario.IdCliCORE;//IDCLICORE de detalleusuario
                DatoDocumento.IDSRamo = Subramo;//IDSRamo | 29
                _c = "IdGrupoCORE";
                DatoDocumento.IDGrupo = InfoEmision.Empresa.Corporativo.IdGrupoCORE;//IDGrupo | 40--63
                _c = "IDSGrupo";
                DatoDocumento.IDSGrupo = datacoreCliente.IDSGrupo;//IDGrupo | 40
                _c = "ObtieneIdAgente";
                AseguradoraAgenteCore aseguradoraAgenteCore = new AseguradoraAgenteCore();
                aseguradoraAgenteCore = ObtieneIdAgente(InfoEmision.ConvenioProducto.ClaveAgente.ToString()); //Tomar clave agente
                if (aseguradoraAgenteCore != null)
                {
                    DatoDocumento.IDAgente = aseguradoraAgenteCore.IdAgente;// "22";//IDAgente | 10--
                }
                if (!aseguradoraAgenteCore.Exitoso)
                {
                    DatoDocumento.Exitoso = false;
                    DatoDocumento.MensajeError = aseguradoraAgenteCore.Mensaje;
                }

                //_c = "Concepto";
                //DatoDocumento.Concepto = InfoEmision.Paquete;

                _c = "IDFPago";
                //DatoDocumento.IDFPago = InfoEmision.PolizaCasa.FormaPago?.ClaveBogo ?? polDetalle.IdCatPeriodicidadFormaPagoProducto.ToString();//IDFPago | 4
                var mtodoPago = polDetalle.IdCatModalidadFormaPago;
                var frmPago = polDetalle.IdCatPeriodicidadFormaPago;
                var catModalidadFPago = db.CatModalidadFormaPagoProducto.Where(x => x.Id == mtodoPago).FirstOrDefault();
                var perioricidadFPago = db.CatPeriodicidadFormaPagoProducto.Where(x => x.Id == frmPago).FirstOrDefault();
                DatoDocumento.IDFPago = perioricidadFPago.ClaveBogo;
                DatoDocumento.IDMon = "1";//IDMon | 1 Moneda Nacional
                _c = "IDEjecut";
                DatoDocumento.IDEjecut = datacoreCliente.IDEjecut;//IDEjecut | 26
                DatoDocumento.IDVend = "7";//IDVend | 1---


                _c = "PrimaNeta";
                DatoDocumento.FDesde = InfoEmision.PolizaProducto.InicioVigencia.ToString("dd/MM/yyyy");//FDesde | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FHasta = InfoEmision.PolizaProducto.FinVigencia.ToString("dd/MM/yyyy");//FHasta | 01 / 11 / 2019 12:00:00 a.m.
                DatoDocumento.PrimaNeta = InfoEmision.PolizaProducto.PrimaNeta.ToString();
                _c = "Derechos";
                DatoDocumento.Derechos = polDetalle.Derechos.ToString();
                _c = "STotal";
                DatoDocumento.STotal = (Convert.ToDecimal(DatoDocumento.PrimaNeta) + 0 + polDetalle.Derechos).ToString();
                _c = "Impuesto1";
                DatoDocumento.Impuesto1 = polDetalle.Impuesto.ToString();
                _c = "PrimaTotal";
                DatoDocumento.PorImp1 = valorIVA.Valor;
                _c = "FactorIva";
                DatoDocumento.PrimaTotal = InfoEmision.PolizaProducto.PrimaTotal.ToString();//PrimaTotal | 4286.76
                DatoDocumento.Status = "0";//Status | 0   Status_TXT == VIGENTE
                _c = "Concepto";//TipoContratante + Año + Paquete



                DatoDocumento.Concepto = (InfoEmision.PolizaProducto.IdTipoMascota == 1 ? "PERRO" : "GATO") + " / " + InfoEmision.PolizaProducto.NombreMascota + " / " + InfoEmision.PolizaProducto.Raza + " / " + InfoEmision.PolizaProducto.Color + " / " + InfoEmision.PolizaProducto.Genero + " / " + InfoEmision.ColorNariz + " / " + InfoEmision.ColorOjo + " / " + InfoEmision.PolizaProducto.Caracteristicas + " / " + InfoEmision.Enfermedades + " / " + InfoEmision.Chip;
                _c = "IDDespacho";
                DatoDocumento.IDDespacho = datacoreCliente.IDDespacho;//IDDespacho | 28--49
                _c = "IDGerencia";
                DatoDocumento.IDGerencia = InfoEmision.Empresa.IdGerenciaCORE;//IDGerencia | 27   Empresa--50
                DatoDocumento.StatusCob = "1";//StatusCob | 1 no pagada, Si la forma de pago es contado o anual se marca la poliza como pagada 2
                DatoDocumento.TCCobro = "1";//TCCobro | 1 compañia
                                            //DatoDocumento.StatusUser = "";//StatusUser | 4
                DatoDocumento.TVenta = "5";//TVenta | 5	On-Line
                _c = "TPago";
                DatoDocumento.TPago = catModalidadFPago.ClaveBogo;//TPago | 3 1a1 CatModalidadFormaPago
                DatoDocumento.ClasDocto = "4";//ClasDocto | 4 NUEVA
                DatoDocumento.IDLineBuss = "2"; ;//IDLineBuss | 1 LOCKTON MÉXICO
                DatoDocumento.DAnterior = "SOLICITUD NUEVA";//DAnterior | SOLICITUD NUEVA
                DatoDocumento.CCobro = "1";//CCobro | 0? 1 Agente 2 Compañia

                if (!string.IsNullOrEmpty(cotizacion.Membresia))
                    DatoDocumento.Notas = $" Membresia Costco: {cotizacion.Membresia}";

                _c = "Referencia3";
                DatoDocumento.IsEspecial = "0";//IsEspecial | 0
                                               //DatoDocumento.Comentario = "";//Comentario | no se captura
                _c = "FSolicitud";
                DatoDocumento.FSolicitud = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//Fsolicitud | 13 / 03 / 2019 12:00:00 a.m.
                _c = "FEmision";
                DatoDocumento.FEmision = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//FEmision | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FRecepcion = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//FRecepcion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FConversion = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//FConversion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FEnvio = InfoEmision.PolizaProducto.FechaEmision.ToString("dd/MM/yyyy");//FEnvio | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.Documento = "Solicitud-001";//Documento | 3190166283     es el numero de poliza de la aseguradora
                _c = "Recargos";
                DatoDocumento.Recargos = "0.00";//Recargos | 0.00
                DatoDocumento.IDPolMta = "0";

            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message) + ". Referencia linea: " + _c);
            }
            return DatoDocumento;
        }

        private DatDoctoDetail RegistroDetalleDerivaPolizaNueva(InformacionEmision InfoEmision, string IdCont)
        {
            DatDoctoDetail DatosDetalle = new DatDoctoDetail();

            try
            {
                DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.DetalleUsuario.IdCliCORE, InfoEmision.DetalleUsuario.IdContCORE, InfoEmision.Empresa.IdGerenciaCORE);
                DatosDetalle.IDDir = datacoreCliente.IDDirec;
                //DatDocumentos.IDDir | 696
                if (InfoEmision.EsBeneficiarioPreferente)
                {
                    DatosDetalle.IDAseg = InfoEmision.DetalleUsuario.IdContCORE;
                }
                else
                {
                    if (!string.IsNullOrEmpty(IdCont))
                    {
                        DatosDetalle.IDAseg = IdCont;
                    }
                }
                CotizacionDetalle cotizacion = null;
                cotizacion = db.CotizacionDetalle.Find(InfoEmision.IdCotizacion);
                var _cot = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacion.IdCotizacion);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == cotizacion.IdPaqueteConvenio);
                var _pdetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == InfoEmision.Poliza.Id);
                var catRamo = db.CatRamoVehiculo.FirstOrDefault(a => a.IdCatRamo == _pdetalle.IdCatRamoVehiculo);

                int idPaquete = Convert.ToInt32(cotizacion.Paquete);
                var paquete = db.PaqueteAseguradora.Where(x => x.IdCatTipoPaquete == idPaquete && x.IdAseguradora == cotizacion.IdAseguradora && x.IdCatSubRamo == InfoEmision.Convenio.IdSubRamoVehiculo).FirstOrDefault();
                DatosDetalle.IDProdCR = paquete != null && paquete.IDProductoCore.HasValue ? paquete.IDProductoCore.ToString() : "";

                DatosDetalle.Servicio = "AUTO";

                if (catRamo != null)
                    DatosDetalle.Servicio = catRamo.Nombre.ToUpper();

                    //switch (catRamo.IdCatRamo)
                    //{
                    //    case 2: DatosDetalle.Servicio = "AUTO"; break;
                    //    case 3: DatosDetalle.Servicio = "PICKUP"; break;
                    //    case 4: DatosDetalle.Servicio = "MOTO"; break;
                    //    case 5: DatosDetalle.Servicio = "CAMION"; break;
                    //    default: DatosDetalle.Servicio = "AUTO"; break;
                    //}
                //DatDoctoDetail.IDAseg | 16577
                //DatosDetalle.IDProdCR = "";//DatDoctoDetail.IDProdCR | 379

                //DatosDetalle.IDDocto = InfoEmision.NoPoliza;
                //DatosDetalle.IDDir = "931"; //obtener el de la empresa si es 
                //if (!InfoEmision.EsRenovacion)
                //{
                //    if(InfoEmision.Direccion.Id == 0 && InfoEmision.Convenio.IdCatTipoNegocio == 1)
                //    {
                //        RespuestaWS datacoreAgente = DerivaDireccionCore(InfoEmision);
                //        DatosDetalle.IDDir = "";
                //    }
                //}

                DatosDetalle.UsoVehiculo = "PARTICULAR";//DatDoctoDetail.UsoVehiculo | PARTICULAR todos son particular

                if (_cot.IdUso.HasValue && _cot.IdUso > 0)
                {
                    var uso = db.CatUsos.FirstOrDefault(a => a.Id == _cot.IdUso);
                    DatosDetalle.UsoVehiculo = uso.Nombre;
                }

                DatosDetalle.Marca = InfoEmision.CotizacionAutoGuardar.Marca;//DatDoctoDetail.Marca | NISSAN
                DatosDetalle.Modelo = InfoEmision.CotizacionAutoGuardar.Agnio;//DatDoctoDetail.Modelo | 2015
                DatosDetalle.Tipo = string.Concat(InfoEmision.CotizacionAutoGuardar.Modelo, " ", InfoEmision.CotizacionAutoGuardar.Version, " ", InfoEmision.CotizacionAutoGuardar.Descripcion);//DatDoctoDetail.Tipo | MARCH SENSE 1.6L AUT. 05 OCUP.
                DatosDetalle.Clave = cotizacion.AMIS;// InfoEmision.CotizacionAutoGuardar.Amis;//DatDoctoDetail.Clave | 2142

                DatosDetalle.Serie = InfoEmision.Poliza.Serie;//DatDoctoDetail.Serie | 3N1CK3CDXFL229601
                DatosDetalle.Motor = InfoEmision.Poliza.Motor;//DatDoctoDetail.Motor | HR16828054H
                DatosDetalle.Placas = InfoEmision.Poliza.Placas;//DatDoctoDetail.Placas | 938ZWG
                DatosDetalle.EstadoCircula = InfoEmision.Direccion.Estado;//DatDoctoDetail.EstadoCircula | DISTRITO FEDERAL
                DatosDetalle.TipoProd = paqueteConvenio.NombrePaquete;
                //DatosDetalle.Repuve = "";//DatDoctoDetail.Repuve | 2142     No se captura
                //DatosDetalle.CEVIC = "";//DatDoctoDetail.CEVIC | 2142       No se capturan
            }
            catch (Exception ex)
            {
                log.Info("RegistroDetalleDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return DatosDetalle;
        }
        private DatDoctoDetail RegistroDetalleDerivaPolizaNuevaCasa(InformacionEmision InfoEmision, string IdCont)
        {
            DatDoctoDetail DatosDetalle = new DatDoctoDetail();

            try
            {
                //DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.DetalleUsuario.IdCliCORE, InfoEmision.DetalleUsuario.IdContCORE, InfoEmision.Empresa.IdGerenciaCORE);
                //DatosDetalle.IDDir = datacoreCliente.IDDirec;
                //DatDocumentos.IDDir | 696
                // DerivaDireccionNueva(InfoEmision);
                DatosDetalle.IDDir = DerivaDireccionCore(InfoEmision);

                DatosDetalle.IDAseg = "0";
                DatosDetalle.TipoInmueble = "CONDOMINIO HORIZONTAL";
                DatosDetalle.Muros = "CONCRETO";
                DatosDetalle.Techos = "CONCRETO";
                DatosDetalle.Servicio = "CASA HABITACION";
                //DatosDetalle.TipoContra = InfoEmision.PolizaCasa.Codigo_Producto;
                CatTipoContratanteCasa catTipoContratanteCasa = db.CatTipoContratanteCasa.Where(x => x.Clave.Equals(InfoEmision.PolizaCasa.Codigo_Producto) || x.ClaveEjecutivo == InfoEmision.PolizaCasa.Codigo_Producto).FirstOrDefault();
                DatosDetalle.TipoContra = catTipoContratanteCasa.ClaveCore.ToString();
                CatTipoPaqueteProducto catTipoPqtProd = db.CatTipoPaqueteProducto.Where(x => x.Nombre.Equals(InfoEmision.PolizaCasa.Codigo_Plan) && x.IdCatProducto == 2).FirstOrDefault();
                DatosDetalle.IDProdCR = catTipoPqtProd.IDProductoCore.ToString();
                var cotizacion = db.CotizacionDatosCasa.Where(x => x.Id.Equals(InfoEmision.PolizaCasa.IdCotizacion)).FirstOrDefault();
                DatosDetalle.AnioC = cotizacion.AnioConstruccion.ToString();

                //DatosDetalle.IDProdCR --CatTipoPaqueteProducto.IdProductoCore
            }
            catch (Exception ex)
            {
                log.Info("RegistroDetalleDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return DatosDetalle;
        }

        private DatDoctoDetail RegistroDetalleDerivaPolizaNuevaProducto(InformacionEmision InfoEmision, string IdCont)
        {
            DatDoctoDetail DatosDetalle = new DatDoctoDetail();

            try
            {
                //DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.DetalleUsuario.IdCliCORE, InfoEmision.DetalleUsuario.IdContCORE, InfoEmision.Empresa.IdGerenciaCORE);
                //DatosDetalle.IDDir = datacoreCliente.IDDirec;
                //DatDocumentos.IDDir | 696
                // DerivaDireccionNueva(InfoEmision);
                DatosDetalle.IDDir = DerivaDireccionCore(InfoEmision);

                DatosDetalle.IDAseg = IdCont;
                DatosDetalle.Servicio = "MASCOTAS";
                //DatosDetalle.TipoContra = InfoEmision.PolizaCasa.Codigo_Producto;


                var polDetalle = InfoEmision.PolizaProductoDetalle;
                var cotizacionDetalle = db.CotizacionProductoDetalle.Where(x => x.Id.Equals(polDetalle.IdCotizacionDetalle)).FirstOrDefault();
                int idPlan = int.Parse(cotizacionDetalle.IdPlan);
                var pcProducto = db.PaqueteConvenioProducto.FirstOrDefault(a => a.IdConvenioProductos == InfoEmision.ConvenioProducto.Id && a.IdPlan == idPlan);
                CatTipoPaqueteProducto catTipoPqtProd = db.CatTipoPaqueteProducto.FirstOrDefault(a => a.Id == pcProducto.IdCatTipoPaquete);
                DatosDetalle.IDProdCR = catTipoPqtProd.IDProductoCore.ToString();


                //DatosDetalle.IDProdCR --CatTipoPaqueteProducto.IdProductoCore
            }
            catch (Exception ex)
            {
                log.Info("RegistroDetalleDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return DatosDetalle;
        }
        private DatDocumentos RegistroDatosDerivaPolizaNuevaPromotores(InformacionEmision InfoEmision)
        {
            DatDocumentos DatoDocumento = new DatDocumentos();
            DatoDocumento.Exitoso = true;
            var _c = "";
            try
            {

                _c = "polDetalle";

                System.Collections.Generic.List<LocktonModel.db.PolizaDetalle> polDetalle = new System.Collections.Generic.List<LocktonModel.db.PolizaDetalle>(InfoEmision.Poliza.PolizaDetalle);
                _c = "polDetaObtieneDatosClienteDerCORElle";
                if (string.IsNullOrEmpty(InfoEmision.Contratante.IdCliCore) || string.IsNullOrEmpty(InfoEmision.Contratante.IdContCore))
                {
                    log.Info("RegistroDatosDerivaPolizaNueva: IdCliCORE ó IdContCORRE invalidos ");
                }
                //string Agente = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales/Agente")[0].InnerText;
                DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.Contratante.IdCliCore, InfoEmision.Contratante.IdContCore, InfoEmision.Empresa.IdGerenciaCORE);
                _c = "periodicidadFormaPago";
                PeriodicidadFormaPago periodicidadFormaPago = db.PeriodicidadFormaPago.Where(x => x.IdConvenio.Equals(InfoEmision.Poliza.IdConvenio)).Distinct().FirstOrDefault();
                _c = "Subramo";
                string Subramo = db.CatSubRamoVehiculo.Where(x => x.IdCatSubRamo == InfoEmision.Convenio.IdSubRamoVehiculo).Select(y => y.Clave).FirstOrDefault();
                //RespuestaWS datacoreAgente = new RespuestaWS(false, "");
                //if(InfoEmision.Convenio.ClaveAgente > 0)
                //    datacoreAgente = ObtieneIdAgente(InfoEmision.Convenio.ClaveAgente.ToString());

                //DatoDocumento.IDDocto = InfoEmision.NoPoliza; //no lleva por que es nuevo
                _c = "Subramo";
                DatoDocumento.IDDocto = "-1";
                DatoDocumento.TipoDocto = "1";//siempre uno
                _c = "DetalleUsuario";
                DatoDocumento.IDCli = InfoEmision.Contratante.IdCliCore;//IDCLICORE de detalleusuario
                DatoDocumento.IDSRamo = Subramo;//IDSRamo | 17 AUTOMOVILES INDIVIDUALES
                _c = "IdGrupoCORE";
                DatoDocumento.IDGrupo = InfoEmision.Empresa.Corporativo.IdGrupoCORE;//IDGrupo | 40--63
                _c = "IDSGrupo";
                DatoDocumento.IDSGrupo = datacoreCliente.IDSGrupo;//IDGrupo | 40
                _c = "ObtieneIdAgente";
                AseguradoraAgenteCore aseguradoraAgenteCore = ObtieneIdAgente(periodicidadFormaPago.ClaveAgente);
                if (aseguradoraAgenteCore != null)
                {
                    DatoDocumento.IDAgente = aseguradoraAgenteCore.IdAgente;// "22";//IDAgente | 10--
                }
                if (!aseguradoraAgenteCore.Exitoso)
                {
                    DatoDocumento.Exitoso = false;
                    DatoDocumento.MensajeError = aseguradoraAgenteCore.Mensaje;
                }
                _c = "IDFPago";
                DatoDocumento.IDFPago = polDetalle[0].CatPeriodicidadFormaPago?.ClaveBogo ?? polDetalle[0].IdCatPeriodicidadFormaPago.ToString();//IDFPago | 4
                DatoDocumento.IDMon = "1";//IDMon | 1 Moneda Nacional
                _c = "IDEjecut";
                DatoDocumento.IDEjecut = datacoreCliente.IDEjecut;//IDEjecut | 25--39
                DatoDocumento.IDVend = !string.IsNullOrEmpty(InfoEmision.Contratante.IdPromotor.ToString()) ? InfoEmision.Contratante.IdPromotor.ToString() : "0";//IDVend | 1---


                _c = "PrimaNeta";
                DatoDocumento.FDesde = InfoEmision.Poliza.InicioVigencia.ToString("dd/MM/yyyy");//FDesde | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FHasta = InfoEmision.Poliza.FinVigencia.ToString("dd/MM/yyyy");//FHasta | 01 / 11 / 2019 12:00:00 a.m.
                DatoDocumento.PrimaNeta = InfoEmision.Poliza.PrimaNeta.ToString();//PrimaNeta | 3924.1
                _c = "Derechos";
                DatoDocumento.Derechos = polDetalle[0].Derechos.ToString();//Derechos | 360
                _c = "STotal";
                DatoDocumento.STotal = (InfoEmision.Poliza.PrimaNeta + polDetalle[0].Derechos).ToString();
                _c = "Impuesto1";
                DatoDocumento.Impuesto1 = polDetalle[0].Impuesto.ToString(); //Impuesto1 | 591.28
                _c = "PrimaTotal";
                DatoDocumento.PorImp1 = polDetalle[0].FactorIva.ToString(); //Iva
                _c = "FactorIva";
                DatoDocumento.PrimaTotal = InfoEmision.Poliza.PrimaTotal.ToString();//PrimaTotal | 4286.76
                DatoDocumento.Status = "0";//Status | 0   Status_TXT == VIGENTE
                _c = "Concepto";
                DatoDocumento.Concepto = string.Concat(InfoEmision.CotizacionAutoGuardar.Marca, " ", InfoEmision.CotizacionAutoGuardar.Descripcion);//"Automoviles Individuales";//Concepto | MARCH SENSE 1.6L AUT. 05 OCUP.   
                _c = "IDDespacho";
                DatoDocumento.IDDespacho = datacoreCliente.IDDespacho;//IDDespacho | 28--49
                _c = "IDGerencia";
                DatoDocumento.IDGerencia = InfoEmision.Empresa.IdGerenciaCORE;//IDGerencia | 27   Empresa--50
                DatoDocumento.StatusCob = "1";//StatusCob | 1 no pagada, Si la forma de pago es contado o anual se marca la poliza como pagada 2
                DatoDocumento.TCCobro = "1";//TCCobro | 1 compañia
                                            //DatoDocumento.StatusUser = "";//StatusUser | 4
                DatoDocumento.TVenta = "5";//TVenta | 5	On-Line
                _c = "TPago";
                DatoDocumento.TPago = polDetalle[0].CatModalidadFormaPago.ClaveBogo;//TPago | 3 1a1 CatModalidadFormaPago
                DatoDocumento.ClasDocto = "4";//ClasDocto | 4 NUEVA
                DatoDocumento.IDLineBuss = InfoEmision.EsFlotilla ? "1" : "2";//IDLineBuss | 1 LOCKTON MÉXICO
                DatoDocumento.DAnterior = "SOLICITUD NUEVA";//DAnterior | SOLICITUD NUEVA
                DatoDocumento.CCobro = "1";//CCobro | 0? 1 Agente 2 Compañia
                _c = "Referencia1";
                if (InfoEmision.EsFlotilla && InfoEmision.Poliza != null && InfoEmision.Poliza.Convenio != null)
                {
                    DatoDocumento.Referencia1 = InfoEmision.Poliza.Convenio.CaratulaPoliza;
                    DatoDocumento.Notas = InfoEmision.Poliza.Convenio.CaratulaPoliza;
                }
                else
                {
                    DatoDocumento.Referencia1 = "POLIZA INDIVIDUAL";//Referencia1 |
                    DatoDocumento.Notas = "POLIZA INDIVIDUAL";//Notas | LOCKTON EMPLEADOS MENSUAL 2018 - 2019
                }

                _c = "Referencia3";
                DatoDocumento.Referencia3 = !string.IsNullOrEmpty(InfoEmision.UrlReimpresionEncriptada) ? InfoEmision.UrlReimpresionEncriptada : InfoEmision.Poliza.UrlPDFPoliza;//Referencia3 | http://qbcenter.qualitas.com.mx/poliza/p3190166283.pdf
                DatoDocumento.IsEspecial = "0";//IsEspecial | 0
                                               //DatoDocumento.Comentario = "";//Comentario | no se captura
                _c = "FSolicitud";
                DatoDocumento.FSolicitud = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//Fsolicitud | 13 / 03 / 2019 12:00:00 a.m.
                _c = "FEmision";
                DatoDocumento.FEmision = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//FEmision | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FRecepcion = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//FRecepcion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FConversion = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//FConversion | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.FEnvio = InfoEmision.Poliza.FechaEmision.ToString("dd/MM/yyyy");//FEnvio | 13 / 03 / 2019 12:00:00 a.m.
                DatoDocumento.Documento = InfoEmision.Poliza.NumeroPoliza;//Documento | 3190166283     es el numero de poliza de la aseguradora
                _c = "Recargos";
                DatoDocumento.Recargos = polDetalle[0].Recargos.ToString();//Recargos | 0.00
                _c = "Referencia4";
                DatoDocumento.Referencia4 = InfoEmision.IdSucursal != 0 ? InfoEmision.IdSucursal.ToString() : "";
                _c = "Referencia5";
                DatoDocumento.Referencia5 = polDetalle[0].FechaDecisionRenovacionAutomaticaUtc.HasValue
                    ? (polDetalle[0].RenovacionAutomatica ? "SI" : "NO")
                    : ""; // CAT Renovación automática: mantiene sin etiqueta los históricos o flujos donde no se mostró el aviso.
                //TarifaDesc | 57
                //DatDoctoDetail.DescuentoAutos | 57
            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message) + ". Referencia linea: " + _c);
            }
            return DatoDocumento;
        }

        private DatDoctoDetail RegistroDetalleDerivaPolizaNuevaPromotores(InformacionEmision InfoEmision, string IdCont)
        {
            DatDoctoDetail DatosDetalle = new DatDoctoDetail();

            try
            {
                DatosCliente datacoreCliente = ObtieneDatosClienteDerCORE(InfoEmision.Contratante.IdCliCore, InfoEmision.Contratante.IdContCore, InfoEmision.Empresa.IdGerenciaCORE);
                DatosDetalle.IDDir = datacoreCliente.IDDirec;
                //DatDocumentos.IDDir | 696
                if (InfoEmision.EsBeneficiarioPreferente)
                {
                    DatosDetalle.IDAseg = InfoEmision.Contratante.IdCliCore;
                }
                else
                {
                    if (!string.IsNullOrEmpty(IdCont))
                    {
                        DatosDetalle.IDAseg = IdCont;
                    }
                }
                CotizacionDetalle cotizacion = null;
                cotizacion = db.CotizacionDetalle.Find(InfoEmision.IdCotizacion);
                var _cot = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacion.IdCotizacion);
                int idPaquete = Convert.ToInt32(cotizacion.Paquete);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == cotizacion.IdPaqueteConvenio);
                var paquete = db.PaqueteAseguradora.Where(x => x.IdCatTipoPaquete == idPaquete && x.IdAseguradora == cotizacion.IdAseguradora && x.IdCatSubRamo == InfoEmision.Convenio.IdSubRamoVehiculo).FirstOrDefault();
                DatosDetalle.IDProdCR = paquete != null && paquete.IDProductoCore.HasValue ? paquete.IDProductoCore.ToString() : "";

                //DatDoctoDetail.IDAseg | 16577
                //DatosDetalle.IDProdCR = "";//DatDoctoDetail.IDProdCR | 379

                //DatosDetalle.IDDocto = InfoEmision.NoPoliza;
                //DatosDetalle.IDDir = "931"; //obtener el de la empresa si es 
                //if (!InfoEmision.EsRenovacion)
                //{
                //    if(InfoEmision.Direccion.Id == 0 && InfoEmision.Convenio.IdCatTipoNegocio == 1)
                //    {
                //        RespuestaWS datacoreAgente = DerivaDireccionCore(InfoEmision);
                //        DatosDetalle.IDDir = "";
                //    }
                //}

                DatosDetalle.UsoVehiculo = "PARTICULAR";//DatDoctoDetail.UsoVehiculo | PARTICULAR todos son particular

                if (_cot.IdUso.HasValue && _cot.IdUso > 0)
                {
                    var uso = db.CatUsos.FirstOrDefault(a => a.Id == _cot.IdUso);
                    DatosDetalle.UsoVehiculo = uso.Nombre;
                }


                DatosDetalle.Marca = InfoEmision.CotizacionAutoGuardar.Marca;//DatDoctoDetail.Marca | NISSAN
                DatosDetalle.Modelo = InfoEmision.CotizacionAutoGuardar.Agnio;//DatDoctoDetail.Modelo | 2015
                DatosDetalle.Tipo = string.Concat(InfoEmision.CotizacionAutoGuardar.Modelo, " ", InfoEmision.CotizacionAutoGuardar.Version, " ", InfoEmision.CotizacionAutoGuardar.Descripcion);//DatDoctoDetail.Tipo | MARCH SENSE 1.6L AUT. 05 OCUP.
                DatosDetalle.Clave = cotizacion.AMIS;// InfoEmision.CotizacionAutoGuardar.Amis;//DatDoctoDetail.Clave | 2142

                DatosDetalle.Serie = InfoEmision.Poliza.Serie;//DatDoctoDetail.Serie | 3N1CK3CDXFL229601
                DatosDetalle.Motor = InfoEmision.Poliza.Motor;//DatDoctoDetail.Motor | HR16828054H
                DatosDetalle.Placas = InfoEmision.Poliza.Placas;//DatDoctoDetail.Placas | 938ZWG
                DatosDetalle.EstadoCircula = InfoEmision.Direccion.Estado;//DatDoctoDetail.EstadoCircula | DISTRITO FEDERAL
                DatosDetalle.TipoProd = paqueteConvenio.NombrePaquete;
                //DatosDetalle.Repuve = "";//DatDoctoDetail.Repuve | 2142     No se captura
                //DatosDetalle.CEVIC = "";//DatDoctoDetail.CEVIC | 2142       No se capturan
            }
            catch (Exception ex)
            {
                log.Info("RegistroDetalleDerivaPolizaNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return DatosDetalle;
        }
        private string GeneraXml(InfoData Datos)
        {
            string resultado = string.Empty;
            XmlSerializerNamespaces NameSpacesVacio = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            XmlSerializer SerializaXML = new XmlSerializer(typeof(InfoData));
            XmlWriterSettings ConfiguraXml = new XmlWriterSettings();
            ConfiguraXml.Indent = true;
            ConfiguraXml.OmitXmlDeclaration = true;

            try
            {
                using (StringWriter stream = new StringWriter())
                {
                    using (XmlWriter EscribeXml = XmlWriter.Create(stream, ConfiguraXml))
                    {
                        SerializaXML.Serialize(EscribeXml, Datos, NameSpacesVacio);
                        resultado = stream.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info("GeneraXml: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return resultado;
        }

        public string DerivaDireccionCore(InformacionEmision InfoEmision)
        {
            var parameters = new List<SqlParameter>() {
            new SqlParameter("@Calle", InfoEmision.Direccion.Calle)
            , new SqlParameter("@NoExt", InfoEmision.Direccion.NumeroExt??"")
            ,new SqlParameter("@NoInt", InfoEmision.Direccion.NumeroInt??"")
           ,new SqlParameter("@CPostal", InfoEmision.Direccion.CodigoPostal)
           , new SqlParameter("@Colonia", InfoEmision.Direccion.Colonia??"")
            ,new SqlParameter("@Poblacion", InfoEmision.Direccion.Municipio)
           , new SqlParameter("@Ciudad", InfoEmision.Direccion.Estado)
           , new SqlParameter("@Telefono1", InfoEmision.TelefonoCel)
           , new SqlParameter("@Telefono2", InfoEmision.TelefonoFijo)
            };


            //var query = string.Format("sp_InsertDir_Core @Calle = '{0}',@NoExt= '{1}',@NoInt= '{2}',@CPostal= '{3}',@Colonia= '{4}',@Poblacion= '{5}',@Ciudad= '{6}',@Telefono1= '{7}',@Telefono2= '{8}'", InfoEmision.Direccion.Calle, InfoEmision.Direccion.NumeroExt, InfoEmision.Direccion.NumeroInt, InfoEmision.Direccion.CodigoPostal, InfoEmision.Direccion.Colonia, InfoEmision.Direccion.Municipio, InfoEmision.Direccion.Estado, InfoEmision.TelefonoCel, InfoEmision.TelefonoFijo);
            var datos = db.Database.SqlQuery<string>("sp_InsertDir_Core @Calle,@NoExt,@NoInt,@CPostal,@Colonia,@Poblacion,@Ciudad,@Telefono1,@Telefono2", parameters.ToArray()).FirstOrDefault();

            return datos;
        }

        private string DerivaDireccionNueva(InformacionEmision InfoEmision)
        {
            InfoData Datos = new InfoData();
            //genera seccion DatDocumentos
            Datos.CatDirecciones = RegistroDatosDerivaDireccionNueva(InfoEmision);

            //genera xml
            return GeneraXml(Datos);
        }

        private CatDirecciones RegistroDatosDerivaDireccionNueva(InformacionEmision InfoEmision)
        {
            CatDirecciones DatoDocumento = new CatDirecciones();
            try
            {
                System.Collections.Generic.List<LocktonModel.db.PolizaDetalle> polDetalle = new System.Collections.Generic.List<LocktonModel.db.PolizaDetalle>(InfoEmision.Poliza.PolizaDetalle);
                string Agente = InfoEmision.XmlsAseguradoras["CotizacionRecepcion"].SelectNodes("Movimientos/Movimiento/DatosGenerales/Agente")[0].InnerText;

                //DatoDocumento.IDDir = ""; en alta debe regresarlo
                DatoDocumento.Calle = InfoEmision.Direccion.Calle;
                DatoDocumento.NOExt = InfoEmision.Direccion.NumeroExt;
                DatoDocumento.NOInt = InfoEmision.Direccion.NumeroInt;
                DatoDocumento.CPostal = InfoEmision.Direccion.CodigoPostal;
                DatoDocumento.Colonia = InfoEmision.Direccion.Colonia;
                DatoDocumento.Poblacion = InfoEmision.Direccion.Municipio;
                DatoDocumento.Ciudad = InfoEmision.Direccion.Ciudad;
                DatoDocumento.Pais = "MÉXICO";
                DatoDocumento.Telefono1 = InfoEmision.TelefonoCel;
                DatoDocumento.Telefono2 = InfoEmision.TelefonoFijo;
                DatoDocumento.IDDir = "-1";
                DatoDocumento.IDMens = "1";
            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaDireccionNueva: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }
            return DatoDocumento;
        }

        public RespuestaWS DerivaContactoCore(InformacionEmision InfoEmision)
        {
            string xmlEnvioBogo = DerivaContactoNuevo(InfoEmision);
            RespuestaWS respuesta = new RespuestaWS(false, "");
            if (!string.IsNullOrEmpty(xmlEnvioBogo))
            {
                respuesta = InsertarContactoCORE(xmlEnvioBogo);
            }
            return respuesta;
        }

        public RespuestaWS DerivaContactoCore(PersonaMoral data)
        {
            string xmlEnvioBogo = DerivaContactoNuevo(data);
            RespuestaWS respuesta = new RespuestaWS(false, "");
            if (!string.IsNullOrEmpty(xmlEnvioBogo))
            {
                respuesta = InsertarContactoCORE(xmlEnvioBogo);
            }
            return respuesta;
        }

        private string DerivaContactoNuevo(InformacionEmision InfoEmision)
        {
            InfoData Datos = new InfoData();
            //genera seccion DatDocumentos
            Datos.catContactos = RegistroDatosDerivaContactoNuevo(InfoEmision);

            //genera xml
            return GeneraXml(Datos);
        }

        private string DerivaContactoNuevo(PersonaMoral data)
        {
            InfoData Datos = new InfoData();
            //genera seccion DatDocumentos
            Datos.catContactos = RegistroDatosDerivaContactoNuevo(data);

            //genera xml
            return GeneraXml(Datos);
        }

        private CatContactos RegistroDatosDerivaContactoNuevo(InformacionEmision InfoEmision)
        {
            CatContactos catContactos = new CatContactos();
            try
            {
                if (InfoEmision.Contratante != null && !string.IsNullOrEmpty(InfoEmision.Contratante.IdContCore))
                {
                    catContactos.IDCont = InfoEmision.Contratante.IdContCore;
                    catContactos.ApellidoP = InfoEmision.Contratante.ApellidoPaterno;
                    catContactos.ApellidoM = InfoEmision.Contratante.ApellidoMaterno;
                    catContactos.Nombre = !string.IsNullOrEmpty(InfoEmision.Contratante.SegundoNombre) ? InfoEmision.Contratante.Nombre + " " + InfoEmision.Contratante.SegundoNombre : InfoEmision.Contratante.Nombre;
                    catContactos.FechaNac = InfoEmision.Contratante.FechaNacimiento.ToString("dd/MM/yyyy");
                    catContactos.RFC = InfoEmision.Contratante.RFC;
                }
                else
                {
                    if (InfoEmision.PersonaMoral != null && InfoEmision.EmisionPersonaMoral)
                    {
                        catContactos.IDCont = "-1";//por que es nuevo
                        catContactos.TipoEnt = "1"; //0 Fisica 1 Moral
                        catContactos.RazonSocial = InfoEmision.PersonaMoral.RazonSocial;
                        catContactos.NombreCompleto = InfoEmision.PersonaMoral.NombreComercial;
                        catContactos.RFC = InfoEmision.PersonaMoral.RFC;
                        catContactos.Abreviacion = InfoEmision.PersonaMoral.ClaveEmpresa;
                    }
                    else
                    {
                        catContactos.IDCont = "-1";//por que es nuevo
                        catContactos.TipoEnt = "0"; //0 Fisica 1 Moral
                        catContactos.ApellidoP = InfoEmision.ApellidoPaterno;
                        catContactos.ApellidoM = InfoEmision.ApellidoMaterno;
                        catContactos.Nombre = InfoEmision.PrimerNombre + (string.IsNullOrEmpty(InfoEmision.SegundoNombre) ? "" : (" " + InfoEmision.SegundoNombre));
                        catContactos.FechaNac = InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy");
                        catContactos.Nacionalidad = "Mexicana";
                    }
                }
                //catContactos.RFC = 
                //catContactos.LugarNac = InfoEmision.IdugarNacimiento == 1 ? "México" : "Otros";
            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaContactoNuevo: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }
            return catContactos;
        }

        private CatContactos RegistroDatosDerivaContactoNuevo(PersonaMoral data)
        {
            CatContactos catContactos = new CatContactos();
            try
            {
                catContactos.IDCont = "-1";//por que es nuevo
                catContactos.TipoEnt = "1"; //0 Fisica 1 Moral
                catContactos.RazonSocial = data.RazonSocial;
                catContactos.NombreCompleto = data.NombreComercial;
                catContactos.RFC = data.RFC;
                catContactos.Abreviacion = data.ClaveEmpresa;
            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaContactoNuevo: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }
            return catContactos;
        }

        #endregion

        #region Consultas al Core con WS y SqlClient
        public DatosCliente ObtieneDatosClienteDerCORE(string IDCli, string IdCont, string IdGerencia)
        {
            DatosCliente respuestaWS = new DatosCliente();
            try
            {
                SqlParameter idcli = new SqlParameter("@IdCli", IDCli);
                SqlParameter idcont = new SqlParameter("@IdCont", IdCont);
                SqlParameter idgerencia = new SqlParameter("@IdGerencia", IdGerencia);

                var query = string.Format("sp_INSERCIONSICAS_ObtieneDatosCliente @IdCli, @IdCont, @IdGerencia");
                var datos = db.sp_INSERCIONSICAS_ObtieneDatosCliente.SqlQuery(query, idcli, idcont, idgerencia).FirstOrDefault();

                respuestaWS.IDCli = datos.IDCli.ToString();
                respuestaWS.IDCont = datos.IDCont.ToString();
                respuestaWS.IDDespacho = datos.IDDespacho == null ? string.Empty : datos.IDDespacho.ToString();
                respuestaWS.IDDirec = datos.IDDirec.ToString();
                respuestaWS.IDEjecut = datos.IDEjecut.ToString();
                respuestaWS.IDGerencia = datos.IDGerencia == null ? string.Empty : datos.IDGerencia.ToString();
                respuestaWS.IDGrupo = datos.IDGrupo.ToString();
                respuestaWS.IDSGrupo = datos.IDSGrupo.ToString();

                //InsercionSICASClient insertaBD = new InsercionSICASClient();

                //         System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();

                //             ObjetoBD objeto = new ObjetoBD();
                //             objeto.Modulo = Modulo.Usuario;
                //             objeto.Opcion = OpcionBD.Consulta;
                //             objeto.Metodo = Metodo.ObtieneDatosClienteDerCORE;
                //             objeto.Valores = new string[1][];
                //             objeto.Valores[0] = new string[] { IDCli, IdCont, IdGerencia };

                //             string ejecutaBD = insertaBD.EjecucionBaseDatos(objeto).RespuestaJSON;
                //             ejecutaBD = ejecutaBD.Replace("[", "").Replace("]", "");

                //             respuestaWS = serializer.Deserialize<DatosCliente>(ejecutaBD);
            }
            catch (Exception ex)
            {
                log.Info("ObtieneDatosClienteDerCORE: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }

            return respuestaWS;
        }

        public AseguradoraAgenteCore ObtieneIdAgente(string ClaveAgente)
        {
            InsercionSICASClient insertaBD = new InsercionSICASClient();
            //RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            var respuesta = new AseguradoraAgenteCore();

            System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            try
            {
                SqlParameter claveagente = new SqlParameter("@ClaveAgente", ClaveAgente);
                var agente = db.sp_INSERCIONSICAS_ObtieneAgente.SqlQuery("sp_INSERCIONSICAS_ObtieneAgente @ClaveAgente", claveagente).FirstOrDefault();

                if (agente == null || agente.IdAgente <= 0)
                {
                    respuesta.Exitoso = false;
                    respuesta.Mensaje = "No se encontró Agente, Clave agente: '" + ClaveAgente + "'";
                    log.Info("ObtieneIdAgente: " + "No se encontró Agente, Clave agente: '" + ClaveAgente + "'");
                }
                else
                {
                    respuesta.Exitoso = true;
                    respuesta.IdAgente = agente.IdAgente.ToString();
                    respuesta.IdAseg = agente.IdAseguradora.ToString();

                }
                //ObjetoBD objeto = new ObjetoBD();
                //objeto.Modulo = Modulo.Usuario;
                //objeto.Opcion = OpcionBD.Consulta;
                //objeto.Metodo = Metodo.ObtieneIdAgente;
                //objeto.Valor = ClaveAgente;
                //objeto.Valores = new string[1][];
                //objeto.Valores[0] = new string[] { "" };

                //string ejecutaBD = insertaBD.EjecucionBaseDatos(objeto).RespuestaJSON;
                //ejecutaBD = ejecutaBD.Replace("[", "").Replace("]", "");
                ////respuestaWS = serializer.Deserialize<RespuestaWS>(ejecutaBD);

                //return serializer.Deserialize<AseguradoraAgenteCore>(ejecutaBD);
            }
            catch (Exception ex)
            {
                respuesta.Exitoso = false;
                respuesta.Mensaje = ex.Message;
                log.Info("ObtieneIdAgente: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }
            return respuesta;
        }
        public class AseguradoraAgenteCore
        {
            public string IdAseg { get; set; }
            public string IdAgente { get; set; }
            public bool Exitoso { get; set; }
            public string Mensaje { get; set; }
        }

        public class EjecutivoCore { public string IDEjecut { get; set; } }

        public ClaveAgenteNumeroNegocio ObtieneClaveAgenteNumeroNegocio(string IdAgente, string IdGerencia)
        {
            InsercionSICASClient insertaBD = new InsercionSICASClient();
            List<List<string>> valores = new List<List<string>>();
            ClaveAgenteNumeroNegocio respuestaWS = new ClaveAgenteNumeroNegocio();

            try
            {
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();

                ObjetoBD otjeto = new ObjetoBD();
                otjeto = new ObjetoBD();

                otjeto.Modulo = Modulo.Usuario;
                otjeto.Opcion = OpcionBD.Consulta;
                otjeto.Metodo = Metodo.ObtieneClaveAgenteNumeroNegocio;
                otjeto.Valores = new string[1][];
                otjeto.Valores[0] = new string[] { IdAgente, IdGerencia }; ;

                string ejecutaBD = insertaBD.EjecucionBaseDatos(otjeto).RespuestaJSON;
                respuestaWS = serializer.Deserialize<ClaveAgenteNumeroNegocio>(ejecutaBD.Replace("[", "").Replace("]", ""));

                return respuestaWS;
            }
            catch (Exception)
            {
                //respuestaWS.Respuesta = false;
                //respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                return respuestaWS;
            }
        }
        #endregion

        #region Actualizar RecibosLocktonOne
        public bool ActualizarReciboslocktonOne(int IdPoliza, string ListRecibosCore)
        {
            try
            {
                var listRecibosCore = ListRecibosCore.Split(',');
                int i = 1;
                foreach (var RecibosCore in listRecibosCore)
                {
                    Recibo recibo = new Recibo();
                    var Endoso = db.Endoso.FirstOrDefault(x => x.IdPoliza == IdPoliza && x.IdTipoEndoso == 1);
                    int IdEndoso = Endoso != null ? Endoso.Id : 0;
                    recibo = db.Recibo.FirstOrDefault(x => x.IdEndoso == IdEndoso && x.Numero == i);
                    if (recibo != null)
                    {
                        recibo.IDReciboCore = Convert.ToInt32(RecibosCore);
                        db.Entry(recibo).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                    i++;
                }
                log.Info("ActualizarReciboslocktonOne Termina de asignar id del recivo del core");
                return true;
            }
            catch (Exception ex)
            {
                log.Info("ActualizarReciboslocktonOne Se generó una excepción al asignar el id del recibo del core error: " + ex.InnerException != null ? ex.InnerException.Message : ex.Message);

                return false;
            }

        }

        public bool ActualizarReciboslocktonOne_Casa(int IdPoliza, string ListRecibosCore)
        {
            try
            {
                var listRecibosCore = ListRecibosCore.Split(',');
                int i = 1;
                foreach (var RecibosCore in listRecibosCore)
                {
                    Recibo recibo = new Recibo();
                    var Endoso = db.Endoso.FirstOrDefault(x => x.IdPolizaCasa == IdPoliza && x.IdTipoEndoso == 1);
                    int IdEndoso = Endoso != null ? Endoso.Id : 0;
                    recibo = db.Recibo.FirstOrDefault(x => x.IdEndoso == IdEndoso && x.Numero == i);
                    if (recibo != null)
                    {
                        recibo.IDReciboCore = Convert.ToInt32(RecibosCore);
                        db.Entry(recibo).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                    i++;
                }
                log.Info("ActualizarReciboslocktonOne Termina de asignar id del recivo del core");
                return true;
            }
            catch (Exception ex)
            {
                log.Info("ActualizarReciboslocktonOne Se generó una excepción al asignar el id del recibo del core error: " + ex.InnerException != null ? ex.InnerException.Message : ex.Message);

                return false;
            }

        }
        #endregion
        #region Actualizar Recibo al core
        public bool ConsultarRecibosAseguradora(int IdPoliza)
        {
            var Endoso = db.Endoso.FirstOrDefault(x => x.IdPoliza == IdPoliza && x.IdTipoEndoso == 1);
            int IdEndoso = Endoso != null ? Endoso.Id : 0;
            var recibo = db.Recibo.Where(x => x.IdEndoso == IdEndoso).ToList();
            foreach (var recibolocton in recibo)
            {
                string xmlEnvioBogo = DerivaRecibosActualizados(recibolocton);
                RespuestaWS respuesta = ActualizarRecibosCore(xmlEnvioBogo);
                if (respuesta.Mensaje.Contains("NewIDValue"))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(respuesta.Mensaje);
                    var idrecibo = Convert.ToInt32(xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText);
                }
            }

            return true;
        }

        public bool ConsultarRecibosAseguradora_Casa(int IdPoliza)
        {
            var Endoso = db.Endoso.FirstOrDefault(x => x.IdPolizaCasa == IdPoliza && x.IdTipoEndoso == 1);
            int IdEndoso = Endoso != null ? Endoso.Id : 0;
            var recibo = db.Recibo.Where(x => x.IdEndoso == IdEndoso).ToList();
            foreach (var recibolocton in recibo)
            {
                string xmlEnvioBogo = DerivaRecibosActualizados(recibolocton);
                RespuestaWS respuesta = ActualizarRecibosCore(xmlEnvioBogo);
                if (respuesta.Mensaje.Contains("NewIDValue"))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(respuesta.Mensaje);
                    var idrecibo = Convert.ToInt32(xmlDoc.SelectNodes("NewDataSet/DATAINFO/NewIDValue")[0].InnerText);
                }
            }

            return true;
        }

        public string DerivaRecibosActualizados(Recibo Recibo)
        {
            log.Info("Entra al método DerivaRecibosActualizados IdRecibo = " + Recibo.Id + ", IdReciboCore = " + Recibo.IDReciboCore);
            InfoData Datos = new InfoData();
            try
            {
                //generate section DatRecibos
                Datos.DatRecibos = RegistroDatosDerivaRecibosActualizados(Recibo);


            }
            catch (Exception ex)
            {

                log.Info("Error DerivaRecibosActualizados: " + ex.Message);
            }
            //generate xml
            return GeneraXml(Datos);
        }

        private DatReciboss RegistroDatosDerivaRecibosActualizados(Recibo recibo)
        {
            DatReciboss DatoRecibo = new DatReciboss();
            var _c = "";
            try
            {
                _c = "IdRecibo";
                DatoRecibo.IDRecibo = recibo.IDReciboCore.ToString();
                _c = "PrimaNeta";
                DatoRecibo.PrimaNeta = recibo.PrimaNeta.ToString();
                _c = "PrimaTotal";
                DatoRecibo.PrimaTotal = recibo.PrimaTotal.ToString();
                _c = "Recargos";
                DatoRecibo.Recargos = recibo.Recargo.ToString();
                _c = "Impuesto1";
                DatoRecibo.Impuesto1 = recibo.Impuesto.ToString();
                _c = "Comisión0";
                DatoRecibo.Comision0 = recibo.Comision.ToString();
                _c = "STotal";
                DatoRecibo.STotal = (recibo.PrimaNeta + recibo.Derecho).ToString();
                _c = "Derechos";
                DatoRecibo.Derechos = recibo.Derecho.ToString();
                _c = "PrimaNetaOrg";
                DatoRecibo.PrimaNetaOrg = recibo.PrimaNeta.ToString();
                _c = "PrimaTotalOrg";
                DatoRecibo.PrimaTotalOrg = recibo.PrimaTotal.ToString();
                _c = "FDesde";
                DatoRecibo.FDesde = recibo.InicioVigencia.ToString();
                _c = "FHasta";
                DatoRecibo.FHasta = recibo.FinVigencia.ToString();
                _c = "FGeneracion";
                DatoRecibo.FGeneracion = recibo.InicioVigencia.ToString();
                _c = "FLimPago";
                DatoRecibo.FLimPago = recibo.FinVigencia.ToString();
            }
            catch (Exception ex)
            {
                log.Info("RegistroDatosDerivaRecibosActualizados: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message) + ". Referencia linea: " + _c);
            }

            return DatoRecibo;
        }
        #endregion
        public RespuestaWS ActualizarRecibosCore(string xmlEnvioBogo)
        {
            log.Info("Entra en el método ActualizarRecibosCore");
            RespuestaWS respuestaWS = new RespuestaWS(false, "Inicio");
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                OWSData.Credentials = CfgCredentials;
                //OWSData.CredentialsUserSICAS = CfgCredUser;
                OWSData.TypeFormat = LocktonServicios.SICASProcesaRecuperaInfo.eTypeFormat.XML;
                OWSData.KeyProcess = LocktonServicios.SICASProcesaRecuperaInfo.eKeyProcess.DATA;
                OWSData.KeyCode = "HWRECIBO";
                OWSData.TProc = LocktonServicios.SICASProcesaRecuperaInfo.eTypeProceData.Save_Data;
                OWSData.DataXML =
                    WsClient.ProcesarEncrip3DES(
                        "%SOnlineBOGO2001-2015WS#",
                        "Lock#Mx%",
                        xmlEnvioBogo
                        );

                string respuestaServicioBogo = WsClient.ProcesarWS(OWSData);
                if (respuestaServicioBogo.Contains("PROCESSDATA"))
                {
                    xmlDoc.LoadXml(respuestaServicioBogo);
                    respuestaWS.Respuesta = xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/RESPONSETXT")[0].InnerText == "SUCESS" ? true : false;
                    if (!respuestaWS.Respuesta)
                    {
                        log.Info(string.Concat("El Servicio respondió con el siguiente Error en ActualizarRecibosCore: ", xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/Message")[0].InnerText));
                        throw new Exception(string.Concat("El Servicio respondió con el siguiente Error: ", xmlDoc.SelectNodes("NewDataSet/PROCESSDATA/Message")[0].InnerText));
                    }
                }

                respuestaWS.Mensaje = respuestaServicioBogo;
            }
            catch (Exception ex)
            {
                respuestaWS.Respuesta = false;
                respuestaWS.Mensaje = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                log.Info("ActualizarRecibosCore XML: " + (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message));
            }
            return respuestaWS;
        }
    }
    public class ClaveAgenteNumeroNegocio { public string NumeroNegocio; public string ClaveAgente; }
}
