﻿using DocumentFormat.OpenXml.EMMA;
using DocumentFormat.OpenXml.Office2010.Excel;
using DocumentFormat.OpenXml.Presentation;
using ExcelDataReader;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonOneWeb.Helper;
using LocktonServicios.ConsultaClientesOpera;
using LocktonServicios.HDIAutos;
using log4net;
using Microsoft.Ajax.Utilities;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

namespace LocktonOneWeb.Controllers.Convenio
{
    public class ConvenioController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger(typeof(ConvenioController));

        public ConvenioController()
        {

        }
        #region Vistas parciales

        #region 1.- Configuración servicio aseguradora

        /// <summary>
        /// Configuración servicio aseguradora
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult ServicioAseguradora(int IdEmpresa, int IdConvenio = 0)
        {
            //obtener configuracionConvenio
            ConfiguracionEmpresa dbCfgEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            LocktonModel.db.Convenio ElConvenio = new LocktonModel.db.Convenio();
            ElConvenio.IdEmpresa = IdEmpresa;
            ElConvenio.Id = -1;
            ElConvenio.InicioVigencia = DateTime.Now;
            ElConvenio.FinVigencia = DateTime.Now.AddYears(1);
            // CAT Renovación automática: los convenios nuevos nacen sin mostrar el aviso hasta que se configure expresamente.
            ElConvenio.MostrarAvisoRenovacionAutomatica = false;

            if (IdConvenio > 0)
            {
                ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == IdConvenio);
            }

            ServicioAseguradoraBox();

            ViewBag.ShowContratente = dbCfgEmpresa.IdTipoDeNegocio == 1 || dbCfgEmpresa.IdTipoDeNegocio == 4;
            ViewBag.ReadOnly = CommonMethods.GetReadOnlyPermissionAgreement();
            ElConvenio.IdTipoNegocio = dbCfgEmpresa.IdTipoDeNegocio ?? 0;
            ElConvenio.PermiteCotizacionSoloEnrollment = dbCfgEmpresa.ConveniosSoloEnrollment;

            return View(ElConvenio);
        }

        public ActionResult ServicioAseguradoraProducto(int IdEmpresa, int IdCatProducto, int IdConvenio = 0)
        {
            //obtener configuracionConvenio
            ConfiguracionEmpresa dbCfgEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            ConvenioProductos ElConvenio = new ConvenioProductos();
            ElConvenio.IdEmpresa = IdEmpresa;
            ElConvenio.Id = -1;
            ElConvenio.IdCatProducto = IdCatProducto;
            ElConvenio.InicioVigencia = DateTime.Now;
            ElConvenio.FinVigencia = DateTime.Now.AddYears(1);

            if (IdConvenio > 0)
                ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == IdConvenio);

            ServicioAseguradoraBoxOtrosProductos(IdCatProducto);

            ViewBag.ReadOnly = CommonMethods.GetReadOnlyPermissionAgreement();

            return View(ElConvenio);
        }

        /// <summary>
        /// guarda
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ServicioAseguradora(LocktonModel.db.Convenio Captura)
        {

            Captura.IdCatUsoVehiculo = 1;

            // CAT Renovación automática: exige el aviso legal solo cuando el convenio habilita su presentación en emisión.
            if (Captura.MostrarAvisoRenovacionAutomatica && string.IsNullOrWhiteSpace(Captura.MensajeRenovacionAutomatica))
            {
                ModelState.AddModelError("MensajeRenovacionAutomatica", "El mensaje de renovación automática es requerido.");
            }

            if (ModelState.IsValid)
            {
                LocktonModel.db.Convenio ElConvenio = new LocktonModel.db.Convenio();
                if (Captura.Id > 0)
                {//actualiza
                    ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == Captura.Id);
                    ElConvenio.CaratulaPoliza = Captura.CaratulaPoliza;
                    ElConvenio.InicioVigencia = Captura.InicioVigencia;
                    ElConvenio.FinVigencia = Captura.FinVigencia;
                    ElConvenio.IdAseguradora = Captura.IdAseguradora;
                    ElConvenio.RamoVehiculo = Captura.RamoVehiculo;
                    ElConvenio.UsoVehiculoOtros = Captura.UsoVehiculoOtros;
                    ElConvenio.IdSubRamoVehiculo = Captura.IdSubRamoVehiculo;
                    //ElConvenio.IdCatUsoVehiculo = Captura.IdCatUsoVehiculo;
                    ElConvenio.IdCatTipoContratante = Captura.IdCatTipoContratante;
                    ElConvenio.IdCatTipoVigencia = Captura.IdCatTipoVigencia;
                    ElConvenio.IdCatTipoConvenio = Captura.IdCatTipoConvenio;
                    ElConvenio.OnLine = Captura.OnLine;
                    ElConvenio.AxaEspecial = Captura.AxaEspecial;
                    ElConvenio.UsoCatalogoAXAEMA = Captura.UsoCatalogoAXAEMA;
                    ElConvenio.GNPInfoEspecial = Captura.GNPInfoEspecial;
                    ElConvenio.Colectividad = Captura.Colectividad;
                    ElConvenio.LeapYear = Captura.LeapYear;
                    ElConvenio.FLP = Captura.FLP;
                    ElConvenio.CotizaSoloEnrollment = Captura.CotizaSoloEnrollment;
                    ElConvenio.IdTarifa = Captura.IdTarifa;
                    ElConvenio.OcuparCaratulaOpera = Captura.OcuparCaratulaOpera;
                    // CAT Renovación automática: guarda la configuración que controlará el aviso en la emisión de este convenio.
                    ElConvenio.MostrarAvisoRenovacionAutomatica = Captura.MostrarAvisoRenovacionAutomatica;
                    ElConvenio.MensajeRenovacionAutomatica = Captura.MensajeRenovacionAutomatica;
                    db.Entry(ElConvenio).State = EntityState.Modified;
                }
                else
                {//nuevo
                 //Captura.Id = 0;
                    Captura.RequireReimCertificadoInd = false;
                    Captura.RequireReimRecibos = false;
                    db.Convenio.Add(Captura);
                }
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Captura)), $"{Captura.GetType()}");

                return RedirectToAction("PaquetesCoberturas", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.Id });
            }

            ServicioAseguradoraBox();
            ConfiguracionEmpresa dbCfgEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == Captura.IdEmpresa);

            ViewBag.ShowContratente = dbCfgEmpresa.IdTipoDeNegocio == 1 || dbCfgEmpresa.IdTipoDeNegocio == 4;
            ViewBag.ReadOnly = CommonMethods.GetReadOnlyPermissionAgreement();

            return View(Captura);
        }

        /// <summary>
        /// Luis Daniel Zamora Garcia
        /// guarda
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ServicioAseguradoraProducto(ConvenioProductos Captura)
        {
            if (ModelState.IsValid)
            {
                LocktonModel.db.ConvenioProductos ElConvenio = new LocktonModel.db.ConvenioProductos();
                if (Captura.Id > 0)
                {//actualiza
                    ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == Captura.Id);
                    ElConvenio.CaratulaPoliza = Captura.CaratulaPoliza;
                    ElConvenio.InicioVigencia = Captura.InicioVigencia;
                    ElConvenio.FinVigencia = Captura.FinVigencia;
                    ElConvenio.IdAseguradoraProducto = Captura.IdAseguradoraProducto;
                    ElConvenio.RamoProducto = Captura.RamoProducto;
                    ElConvenio.IdSubRamoProducto = Captura.IdSubRamoProducto;
                    ElConvenio.IdCatTipoContratante = Captura.IdCatTipoContratante;
                    ElConvenio.IdCatTipoVigencia = Captura.IdCatTipoVigencia;
                    ElConvenio.IdCatTipoConvenio = Captura.IdCatTipoConvenio;
                    ElConvenio.OnLine = Captura.OnLine;
                    db.Entry(ElConvenio).State = EntityState.Modified;
                }
                else
                {//nuevo
                 //Captura.Id = 0;
                    db.ConvenioProductos.Add(Captura);
                }

                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Captura)), $"{Captura.GetType()}");

                return RedirectToAction("PaquetesCoberturasProducto", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.Id });
            }

            ServicioAseguradoraBoxOtrosProductos(Captura.IdCatProducto);
            return View(Captura);
        }

        /// <summary>
        /// Carga lista para  Combos, ChkBox, RadioButtons
        /// </summary>
        private void ServicioAseguradoraBox()
        {
            ViewBag.ComboAseguradora = new List<SelectListItem>(db.Aseguradora.Where(e => e.Estatus == 1).Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));
            ViewBag.ListaCatRamoVehiculo = db.CatRamoVehiculo.ToList();//integrar campo estatus y traer solo los activos

            ViewBag.ListaUsoVehiculoOtros = db.CatUsoVehiculo.Where(a => a.Estatus == 1 && a.IdCatRamo == 10).ToList();

            ViewBag.ComboSubRamoVehiculo = new List<SelectListItem>(db.CatSubRamoVehiculo.Select(col => new SelectListItem { Value = col.IdCatSubRamo.ToString(), Text = col.Nombre })); // db.CatRamoVehiculo.ToList();//Crear subramo y traer solo los activos
            ViewBag.ComboCatUsoVehiculo = new List<SelectListItem>(db.CatUsoVehiculo.Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));
            ViewBag.ComboCatTipoContratante = new List<SelectListItem>(db.CatTipoContratante.Select(col => new SelectListItem { Value = col.IdCatTipoContratante.ToString(), Text = col.Nombre }));
            ViewBag.ComboCatTipoVigencia = new List<SelectListItem>(db.CatTipoVigencia.Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));
            ViewBag.ComboCatTipoConvenio = new List<SelectListItem>(db.CatTipoConvenio.Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));
            ViewBag.IdCatUsos = new List<SelectListItem>(db.CatUsos.Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));

            ViewBag.ComboTafia = new List<SelectListItem>(db.ConvenioTarifa.Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));

        }

        #endregion

        /// <summary
        /// Luis Daniel Zamora Garcia
        /// Carga lista para  Combos, CHkBox, RadioButtons Para Otros Productos
        /// </summary>
        private void ServicioAseguradoraBoxOtrosProductos(int IdCatProducto)
        {
            ViewBag.ComboAseguradora = new List<SelectListItem>(db.AseguradoraProductos.Where(e => e.Estatus == 1 && e.IdCatProducto == IdCatProducto).Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));
            ViewBag.ListaCatRamoProducto = db.CatRamoProducto.Where(c => c.IdCatProducto == IdCatProducto).ToList();//integrar campo estatus y traer solo los activos
            ViewBag.ComboSubRamoProducto = new List<SelectListItem>(db.CatSubRamoProducto.Select(col => new SelectListItem { Value = col.IdCatSubRamoProducto.ToString(), Text = col.Nombre })); // db.CatRamoVehiculo.ToList();//Crear subramo y traer solo los activos
                                                                                                                                                                                                 //ViewBag.ComboCatUsoVehiculo = new List<SelectListItem>(db.CatUsoVehiculo.Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));
            ViewBag.ComboCatTipoContratante = new List<SelectListItem>(db.CatTipoContratanteProducto.Where(e => e.IdCatProducto == IdCatProducto).Select(col => new SelectListItem { Value = col.IdCatTipoContratante.ToString(), Text = col.Nombre }));
            ViewBag.ComboCatTipoVigencia = new List<SelectListItem>(db.CatTipoVigencia.Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));
            ViewBag.ComboCatTipoConvenio = new List<SelectListItem>(db.CatTipoConvenio.Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));
        }

        #endregion

        #region 2.- Configuración paquetes y coberturas

        /// <summary>
        /// Configuración paquetes y coberturas	
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult PaquetesCoberturas(int IdEmpresa, int IdConvenio)
        {
            //obtener configuracionConvenio
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            LocktonModel.db.Convenio ElConvenio = new LocktonModel.db.Convenio();

            if (IdConvenio > 0)
                ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == IdConvenio);
            else
                return HttpNotFound();

            PaquetesCoberturasBox(ElConvenio.RamoVehiculo, ConfigEmpresa.OrdenPaquetes, ElConvenio.IdAseguradora, ElConvenio.OnLine);

            string tabRamoVehiculo = string.Join(",", ElConvenio.RamoVehiculo);

            List<ConvenioRamoPaquete> ListaConvenioRamoPaquete = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == IdConvenio && tabRamoVehiculo.Contains(x.IdCatRamoVehiculo.ToString())).ToList();
            List<PaqueteDetalle> ListaPaqueteDetalle = new List<PaqueteDetalle>();
            List<PaqueteDetalleOpcional> ListaPaqueteDetalleOpcional = new List<PaqueteDetalleOpcional>();
            List<PaqueteConvenio> ListaPaqueteConvenio = new List<PaqueteConvenio>();
            if (ListaConvenioRamoPaquete is null)
            {
                ListaConvenioRamoPaquete = new List<ConvenioRamoPaquete>();
            }
            else
            {
                //obtener los paquetes de cada ramo del convenio
                ListaConvenioRamoPaquete.ForEach(paquetes =>
                {
                    ListaPaqueteDetalle.AddRange(db.PaqueteDetalle.Where(x => x.IdConvenioRamoPaquete == paquetes.Id).ToList());
                    ListaPaqueteDetalleOpcional.AddRange(db.PaqueteDetalleOpcional.Where(x => x.IdConvenioRamoPaquete == paquetes.Id).ToList());
                    ListaPaqueteConvenio.AddRange(db.PaqueteConvenio.Where(x => x.IdConvenio == IdConvenio && x.IdCatRamoVehiculo == paquetes.IdCatRamoVehiculo));
                    paquetes.Usos = string.Join(",", db.CatUsosConvenio.Where(a => a.IdConvenio == IdConvenio && a.IdTipoVehiculo == paquetes.IdCatRamoVehiculo).Select(a => a.IdUso));
                });
            }
            //buscamos si existen datos ya guardado

            //ListaPaqueteConvenio = db.PaqueteConvenio.Where(x => x.IdConvenio == IdConvenio && tabRamoVehiculo.Contains(x.IdCatRamoVehiculo.ToString())).ToList();
            if (ListaPaqueteConvenio is null)
            {
                ListaPaqueteConvenio = new List<PaqueteConvenio>();
            }
            LocktonModel.db.Empresa Empresa = new LocktonModel.db.Empresa();
            Empresa = db.Empresa.Where(X => X.Id == ConfigEmpresa.IdEmpresa).FirstOrDefault();
            ViewBag.ListaConvenioRamoPaquete = ListaConvenioRamoPaquete;
            ViewBag.ListaPaqueteDetalle = ListaPaqueteDetalle;
            ViewBag.ListaPaqueteDetalleOpcional = ListaPaqueteDetalleOpcional;
            ViewBag.ListaPaqueteConvenio = ListaPaqueteConvenio;
            ViewBag.IdAsegura = ElConvenio.IdAseguradora;
            ViewBag.IdTipoNegocio = ConfigEmpresa.IdTipoDeNegocio;

            SqlParameter _pAseguradora = new SqlParameter("@IdAseguradora", ElConvenio.IdAseguradora);

            ViewBag.IdCatUsos = new List<SelectListItem>(db.CatUsos.SqlQuery("sp_CONVENIO_SELECT_CatUsos @IdAseguradora", _pAseguradora).Select(col => new SelectListItem { Value = col.Id.ToString(), Text = col.Nombre }));

            return View(ElConvenio);
        }

        /// <summary>
        /// Configuración paquetes y coberturas	
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult PaquetesCoberturasProducto(int IdEmpresa, int IdConvenio)
        {
            //obtener configuracionConvenio
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            ConvenioProductos ElConvenio = new ConvenioProductos();

            if (IdConvenio > 0)
                ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == IdConvenio);
            else
                return HttpNotFound();

            PaquetesCoberturasBoxProductos(ElConvenio.RamoProducto, ConfigEmpresa.OrdenPaquetes, ElConvenio.IdAseguradoraProducto, ElConvenio.OnLine, ElConvenio.IdCatProducto);

            string tabRamoVehiculo = string.Join(",", ElConvenio.RamoProducto);

            List<ConvenioRamoPaqueteProducto> ListaConvenioRamoPaquete = db.ConvenioRamoPaqueteProducto.Where(x => x.IdConvenioProductos == IdConvenio ).ToList();
            List<PaqueteDetalleProducto> ListaPaqueteDetalle = new List<PaqueteDetalleProducto>();
            List<PaqueteConvenioProducto> ListaPaqueteConvenio = new List<PaqueteConvenioProducto>();

            if (ListaConvenioRamoPaquete is null)
            {
                ListaConvenioRamoPaquete = new List<ConvenioRamoPaqueteProducto>();
            }
            else
            {
                //obtener los paquetes de cada ramo del convenio
                ListaConvenioRamoPaquete.ForEach(paquetes =>
                {
                    //ListaPaqueteDetalle.AddRange(db.PaqueteDetalleProducto.Where(x => x.IdConvenioRamoPaquete == paquetes.Id && x.IdCatProducto == ElConvenio.IdCatProducto).ToList());
                    ListaPaqueteConvenio.AddRange(db.PaqueteConvenioProducto.Where(x => x.IdConvenioProductos == IdConvenio && x.IdCatRamoProducto == paquetes.IdCatRamoProducto && x.IdCatProducto == ElConvenio.IdCatProducto));
                });

                ListaPaqueteConvenio.ForEach(paquetesC =>
                {
                    ListaPaqueteDetalle.AddRange(db.PaqueteDetalleProducto.Where(x => x.IdPaqueteConvenio == paquetesC.Id).ToList());
                    
                });
            }
            //buscamos si existen datos ya guardado

            //ListaPaqueteConvenio = db.PaqueteConvenio.Where(x => x.IdConvenio == IdConvenio && tabRamoVehiculo.Contains(x.IdCatRamoVehiculo.ToString())).ToList();
            if (ListaPaqueteConvenio is null)
            {
                ListaPaqueteConvenio = new List<PaqueteConvenioProducto>();
            }
            LocktonModel.db.Empresa Empresa = new LocktonModel.db.Empresa();
            Empresa = db.Empresa.Where(X => X.Id == ConfigEmpresa.IdEmpresa).FirstOrDefault();
            ViewBag.ListaConvenioRamoPaquete = ListaConvenioRamoPaquete;
            ViewBag.ListaPaqueteDetalle = ListaPaqueteDetalle;
            ViewBag.ListaPaqueteConvenio = ListaPaqueteConvenio;
            ViewBag.IdAsegura = ElConvenio.IdAseguradoraProducto;

            return View(ElConvenio);
        }

        /// <summary>
        /// Configuración paquetes y coberturas	
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PaquetesCoberturasGuarda(GuardaCoberturas DatosCoberturas) //int List<VRamoCoberturas> ListaRamoCoberturas
        {
            int IdConvenioRamoPaquete = 0;
            ConvenioRamoPaquete regConvenioRamoPaquete = new ConvenioRamoPaquete();
            if (DatosCoberturas is null)
                return HttpNotFound();
            try
            {
                ConvenioRamoPaquete ConRamoPaquete = new ConvenioRamoPaquete();
                PaqueteDetalle PaqDetalle = new PaqueteDetalle();

                //paquete convenio si lleva depreciacion
                if (DatosCoberturas.PaqueteConvenio.Count > 0)
                {
                    GuardaPaqueteConvenio(DatosCoberturas.IdConvenio, DatosCoberturas.PaqueteConvenio);
                    //int totalPaquetesConvenio = db.PaqueteConvenio.Where(x => x.IdConvenio == DatosCoberturas.IdConvenio).Count();

                    ////elimina paquetes borrados
                    //if (totalPaquetesConvenio != DatosCoberturas.PaqueteConvenio.Count)
                    //{
                    //	EliminaPaquete(DatosCoberturas);
                    //}

                }

                if (DatosCoberturas.PaqueteCoberturas.Count > 0 && DatosCoberturas.RamosVehiculos.Count > 0)
                {
                    List<ConvenioRamoPaquete> ListaConvenioRamoPaquete = new List<ConvenioRamoPaquete>();
                    ListaConvenioRamoPaquete = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == DatosCoberturas.IdConvenio).ToList();

                    List<PaqueteDetalle> ListaPaqueteDetalle = new List<PaqueteDetalle>();
                    List<PaqueteDetalleOpcional> ListaPaqueteDetalleOpcional = new List<PaqueteDetalleOpcional>();
                    if (ListaConvenioRamoPaquete != null)
                    {
                        //obtener los paquetes de cada ramo del convenio
                        ListaConvenioRamoPaquete.ForEach(paquetes =>
                        {
                            ListaPaqueteDetalle.AddRange(db.PaqueteDetalle.Where(x => x.IdConvenioRamoPaquete == paquetes.Id).ToList());
                            ListaPaqueteDetalleOpcional.AddRange(db.PaqueteDetalleOpcional.Where(x => x.IdConvenioRamoPaquete == paquetes.Id).ToList());
                        });
                    }


                    //Eliminar UsusActuales
                    var usosDB = db.CatUsosConvenio.Where(a => a.IdConvenio == DatosCoberturas.IdConvenio).ToList();

                    if (usosDB.Any())
                    {
                        db.CatUsosConvenio.RemoveRange(usosDB);
                        db.SaveChanges();
                    }

                    DatosCoberturas.RamosVehiculos.ForEach(ramos =>
                    {
                        regConvenioRamoPaquete = new ConvenioRamoPaquete();
                        regConvenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(x => x.IdConvenio == DatosCoberturas.IdConvenio && x.IdCatRamoVehiculo == ramos.RamoVehiculo);

                        if (regConvenioRamoPaquete != null)
                        {//actualizar
                            IdConvenioRamoPaquete = ActualizarRegistroConvenioRamoPaquete(regConvenioRamoPaquete, ramos);
                        }
                        else
                        {//nuevo
                            IdConvenioRamoPaquete = GuardaRegistroConvenioRamoPaquete(ramos, DatosCoberturas.IdConvenio);
                        }

                        //Ingresas Usos por tipo de vehiculo
                        if (!string.IsNullOrEmpty(ramos.Usos))
                        {
                            foreach (var uso in ramos.Usos.Split(','))
                            {
                                var usoConvenio = new CatUsosConvenio();
                                usoConvenio.IdConvenio = DatosCoberturas.IdConvenio;
                                usoConvenio.IdUso = Convert.ToInt32(uso);
                                usoConvenio.IdTipoVehiculo = ramos.RamoVehiculo;

                                db.CatUsosConvenio.Add(usoConvenio);
                                db.SaveChanges();
                            }
                        }


                        //un registro de convenioRamoPaquete por cada Paquete configurado
                        if (ramos.Paquetes.Length > 0)
                        {
                            string[] Paquetes = ramos.Paquetes.Split(',');
                            foreach (string paquete in Paquetes)
                            {
                                //elimina si han quitado de la lista
                                if (ListaPaqueteDetalle.Exists(r => r.IdConvenioRamoPaquete == IdConvenioRamoPaquete && r.IdPaqueteConvenio.ToString() == paquete))
                                {
                                    ListaPaqueteDetalle.Where(x => x.IdConvenioRamoPaquete == IdConvenioRamoPaquete && x.IdPaqueteConvenio.ToString() == paquete).ToList().ForEach(regGuardado =>
                                    {
                                        //busca si viene en el listado para guardar o actualizar sino eliminarlo
                                        if (!DatosCoberturas.PaqueteCoberturas.Exists(busca => busca.Ramo == ramos.RamoVehiculo
                                                                                                //&& busca.Paquete == regGuardado.IdCatTipoPaquete 
                                                                                                && busca.Cobertura == regGuardado.IdCobertura
                                                                                                && busca.IdPaqueteConvenio == regGuardado.IdPaqueteConvenio))
                                        {
                                            EliminaRegistroPaqueteDetalle(regGuardado);
                                        }
                                    });
                                }

                                //elimina si han quitado de la lista
                                if (ListaPaqueteDetalleOpcional.Exists(r => r.IdConvenioRamoPaquete == IdConvenioRamoPaquete && r.IdPaqueteConvenio.ToString() == paquete))
                                {
                                    ListaPaqueteDetalleOpcional.Where(x => x.IdConvenioRamoPaquete == IdConvenioRamoPaquete && x.IdPaqueteConvenio.ToString() == paquete).ToList().ForEach(regGuardado =>
                                    {
                                        //busca si viene en el listado para guardar o actualizar sino eliminarlo
                                        if (!DatosCoberturas.PaqueteCoberturasOpcionales.Exists(busca => busca.Ramo == ramos.RamoVehiculo
                                                                                                //&& busca.Paquete == regGuardado.IdCatTipoPaquete 
                                                                                                && busca.Cobertura == regGuardado.IdCobertura
                                                                                                && busca.IdPaqueteConvenio == regGuardado.IdPaqueteConvenio))
                                        {
                                            EliminaRegistroPaqueteDetalleOpcional(regGuardado);
                                        }
                                    });
                                }

                                //las coberturas por paquete
                                DatosCoberturas.PaqueteCoberturas.Where(busca => busca.Ramo == ramos.RamoVehiculo && busca.IdPaqueteConvenio.ToString() == paquete).ToList().ForEach(pCobertura =>
                                {
                                    //valida si existe un registro para la misma covertura
                                    if (ListaPaqueteDetalle.Exists(reg => reg.IdConvenioRamoPaquete == IdConvenioRamoPaquete
                                                                        //&& reg.IdCatTipoPaquete.ToString() == paquete 
                                                                        && reg.IdCobertura == pCobertura.Cobertura
                                                                        && reg.IdPaqueteConvenio == pCobertura.IdPaqueteConvenio))
                                    {//actualizar registro
                                        ActualizaRegistroPaqueteDetalle(ListaPaqueteDetalle.FirstOrDefault(reg => reg.IdConvenioRamoPaquete == IdConvenioRamoPaquete
                                                                                                                //&& reg.IdCatTipoPaquete.ToString() == paquete 
                                                                                                                && reg.IdCobertura == pCobertura.Cobertura
                                                                                                                && reg.IdPaqueteConvenio == pCobertura.IdPaqueteConvenio), pCobertura, IdConvenioRamoPaquete);
                                    }
                                    else
                                    {
                                        GuardaRegistroPaqueteDetalle(pCobertura, IdConvenioRamoPaquete);
                                    }
                                });

                                //las coberturas opcionales por paquete
                                if (DatosCoberturas.PaqueteCoberturasOpcionales != null)
                                {
                                    DatosCoberturas.PaqueteCoberturasOpcionales.Where(busca => busca.Ramo == ramos.RamoVehiculo && busca.IdPaqueteConvenio.ToString() == paquete).ToList().ForEach(pCobertura =>
                                    {
                                        //valida si existe un registro para la misma covertura
                                        if (ListaPaqueteDetalleOpcional.Exists(reg => reg.IdConvenioRamoPaquete == IdConvenioRamoPaquete
                                                                            //&& reg.IdCatTipoPaquete.ToString() == paquete 
                                                                            && reg.IdCobertura == pCobertura.Cobertura
                                                                            && reg.IdPaqueteConvenio == pCobertura.IdPaqueteConvenio))
                                        {//actualizar registro
                                            ActualizaRegistroPaqueteDetalleOpcional(ListaPaqueteDetalleOpcional.FirstOrDefault(reg => reg.IdConvenioRamoPaquete == IdConvenioRamoPaquete
                                                                                                                    //&& reg.IdCatTipoPaquete.ToString() == paquete 
                                                                                                                    && reg.IdCobertura == pCobertura.Cobertura
                                                                                                                    && reg.IdPaqueteConvenio == pCobertura.IdPaqueteConvenio), pCobertura, IdConvenioRamoPaquete);
                                        }
                                        else
                                        {
                                            GuardaRegistroPaqueteDetalleOpcional(pCobertura, IdConvenioRamoPaquete);
                                        }
                                    });
                                }
                            }
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("PaquetesCoberturasGuarda " + ex.Message);
                //error por ajax json
            }
            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, DatosCoberturas)), $"{DatosCoberturas.GetType()}", idEmpresa: DatosCoberturas.IdEmpresa);
            //si todo sale bien, siguiente pantalla
            return Json(Url.Action("ParametrosCotizacion", new { IdEmpresa = DatosCoberturas.IdEmpresa, IdConvenio = DatosCoberturas.IdConvenio }));

        }

        /// <summary>
        /// Configuración paquetes y coberturas	
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PaquetesCoberturasGuardaProducto(GuardaCoberturasProducto DatosCoberturas) //int List<VRamoCoberturas> ListaRamoCoberturas
        {
            int IdConvenioRamoPaquete = 0;
            ConvenioRamoPaqueteProducto regConvenioRamoPaquete = new ConvenioRamoPaqueteProducto();
            if (DatosCoberturas is null)
                return HttpNotFound();
            try
            {
                ConvenioRamoPaqueteProducto ConRamoPaquete = new ConvenioRamoPaqueteProducto();
                PaqueteDetalleProducto PaqDetalle = new PaqueteDetalleProducto();

                //paquete convenio si lleva depreciacion
                if (DatosCoberturas.PaqueteConvenio.Count > 0)
                {
                    GuardaPaqueteConvenioProducto(DatosCoberturas.IdConvenioProducto, DatosCoberturas.PaqueteConvenio);
                    //int totalPaquetesConvenio = db.PaqueteConvenio.Where(x => x.IdConvenio == DatosCoberturas.IdConvenio).Count();

                    ////elimina paquetes borrados
                    //if (totalPaquetesConvenio != DatosCoberturas.PaqueteConvenio.Count)
                    //{
                    //	EliminaPaquete(DatosCoberturas);
                    //}

                }

                if (DatosCoberturas.PaqueteCoberturas.Count > 0 && DatosCoberturas.RamoProductos.Count > 0)
                {
                    List<ConvenioRamoPaqueteProducto> ListaConvenioRamoPaquete = new List<ConvenioRamoPaqueteProducto>();
                    ListaConvenioRamoPaquete = db.ConvenioRamoPaqueteProducto.Where(x => x.IdConvenioProductos == DatosCoberturas.IdConvenioProducto).ToList();

                    List<PaqueteDetalleProducto> ListaPaqueteDetalle = new List<PaqueteDetalleProducto>();
                    var paquetesConvenio = db.PaqueteConvenioProducto.Where(a => a.IdConvenioProductos == DatosCoberturas.IdConvenioProducto).ToList();
                    if (paquetesConvenio != null)
                    {
                        //obtener los paquetes de cada ramo del convenio
                        paquetesConvenio.ForEach(paquetes =>
                        {
                            ListaPaqueteDetalle.AddRange(db.PaqueteDetalleProducto.Where(x => x.IdPaqueteConvenio == paquetes.Id).ToList());
                        });
                    }

                    DatosCoberturas.RamoProductos.ForEach(ramos =>
                    {
                        regConvenioRamoPaquete = new ConvenioRamoPaqueteProducto();
                        regConvenioRamoPaquete = db.ConvenioRamoPaqueteProducto.FirstOrDefault(x => x.IdConvenioProductos == DatosCoberturas.IdConvenioProducto && x.IdCatRamoProducto == ramos.RamoProducto);

                        if (regConvenioRamoPaquete != null)
                        {//actualizar
                            IdConvenioRamoPaquete = ActualizarRegistroConvenioRamoPaqueteProducto(regConvenioRamoPaquete, ramos, DatosCoberturas.IdConvenioProducto);
                        }
                        else
                        {//nuevo
                            IdConvenioRamoPaquete = GuardaRegistroConvenioRamoPaqueteProducto(ramos, DatosCoberturas.IdConvenioProducto);
                        }

                        //un registro de convenioRamoPaquete por cada Paquete configurado
                        if (ramos.Paquetes.Length > 0)
                        {
                            string[] Paquetes = ramos.Paquetes.Split(',');
                            foreach (string paquete in Paquetes)
                            {
                                //elimina si han quitado de la lista
                                if (ListaPaqueteDetalle.Exists(r =>  r.IdPaqueteConvenio.ToString() == paquete))
                                {
                                    ListaPaqueteDetalle.Where(x =>  x.IdPaqueteConvenio.ToString() == paquete).ToList().ForEach(regGuardado =>
                                    {
                                        //busca si viene en el listado para guardar o actualizar sino eliminarlo
                                        if (!DatosCoberturas.PaqueteCoberturas.Exists(busca => busca.Ramo == ramos.RamoProducto
                                                                                                //&& busca.Paquete == regGuardado.IdCatTipoPaquete 
                                                                                                && busca.Cobertura == regGuardado.IdCobertura
                                                                                                && busca.IdPaqueteConvenioProducto == regGuardado.IdPaqueteConvenio))
                                        {
                                            EliminaRegistroPaqueteDetalleProducto(regGuardado);
                                        }
                                    });
                                }

                                //las coberturas por paquete
                                DatosCoberturas.PaqueteCoberturas.Where(busca => busca.Ramo == ramos.RamoProducto && busca.IdPaqueteConvenioProducto.ToString() == paquete).ToList().ForEach(pCobertura =>
                                {
                                    //valida si existe un registro para la misma covertura
                                    if (ListaPaqueteDetalle.Exists(reg => 
                                                                        //reg.IdConvenioRamoPaquete == IdConvenioRamoPaquete
                                                                        //&& reg.IdCatTipoPaquete.ToString() == paquete 
                                                                         reg.IdCobertura == pCobertura.Cobertura
                                                                        && reg.IdPaqueteConvenio == pCobertura.IdPaqueteConvenioProducto))
                                    {//actualizar registro
                                        ActualizaRegistroPaqueteDetalleProducto(ListaPaqueteDetalle.FirstOrDefault(
                                                                                                                //reg => reg.IdConvenioRamoPaquete == IdConvenioRamoPaquete
                                                                                                                //&& reg.IdCatTipoPaquete.ToString() == paquete 
                                                                                                                reg => reg.IdCobertura == pCobertura.Cobertura
                                                                                                                && reg.IdPaqueteConvenio == pCobertura.IdPaqueteConvenioProducto), pCobertura, IdConvenioRamoPaquete);
                                    }
                                    else
                                    {
                                        GuardaRegistroPaqueteDetalleProducto(pCobertura, IdConvenioRamoPaquete, DatosCoberturas.IdConvenioProducto);
                                    }
                                });
                            }
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("PaquetesCoberturasGuarda " + ex.Message);
                //error por ajax json
            }

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, DatosCoberturas)), $"{DatosCoberturas.GetType()}", idEmpresa: DatosCoberturas.IdEmpresa);

            //si todo sale bien, siguiente pantalla
            return Json(Url.Action("ParametrosCotizacionProducto", new { IdEmpresa = DatosCoberturas.IdEmpresa, IdConvenio = DatosCoberturas.IdConvenioProducto }));

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult PaquetesCoberturasAgregaPaquete(int idConvenio, int idCatRamo, int idCatTipoPaquete, string nombre)
        {
            bool success = true;
            string message = "";

            try
            {
                var exists = db.PaqueteConvenio.FirstOrDefault(a => a.IdConvenio == idConvenio && a.IdCatRamoVehiculo == idCatRamo && a.NombrePaquete.ToUpper().Trim() == nombre.ToUpper().Trim());
                if (exists == null)
                {
                    var convenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(a => a.IdConvenio == idConvenio && a.IdCatRamoVehiculo == idCatRamo);
                    if (convenioRamoPaquete == null)
                    {
                        convenioRamoPaquete = new ConvenioRamoPaquete();
                        convenioRamoPaquete.IdCatRamoVehiculo = idCatRamo;
                        convenioRamoPaquete.IdConvenio = idConvenio;

                        db.ConvenioRamoPaquete.Add(convenioRamoPaquete);
                    }
                    var paqueteConvenio = new PaqueteConvenio();
                    paqueteConvenio.IdCatRamoVehiculo = idCatRamo;
                    paqueteConvenio.IdConvenio = idConvenio;
                    paqueteConvenio.IdCatTipoPaquete = idCatTipoPaquete;
                    paqueteConvenio.NombrePaquete = nombre;
                    paqueteConvenio.AplicaDepreciacion = false;
                    paqueteConvenio.PorcentajeAplicaDepreciacion = 0;

                    db.PaqueteConvenio.Add(paqueteConvenio);
                    db.SaveChanges();

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                    {
                        ConvenioRamoPaquete = CommonMethods.UnProxy(db, convenioRamoPaquete),
                        PaqueteConvenio = CommonMethods.UnProxy(db, paqueteConvenio)
                    }), "dynamic");
                }
                else
                {
                    success = false;
                    message = "Ya existe un paquete con el mismo nombre";
                }
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,


            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult PaquetesCoberturasAgregaPaqueteProducto(int idConvenio,
                                                                  int idCatRamo,
                                                                  int idCatTipoPaquete,
                                                                  string nombre,
                                                                  int idCatProducto,
                                                                  int idCatTipoContratanteCasa)
        {
            bool success = true;
            string message = "";

            try
            {
                var exists = db.PaqueteConvenioProducto.FirstOrDefault(a => a.IdConvenioProductos == idConvenio && a.IdCatRamoProducto == idCatRamo && a.NombrePaquete.ToUpper().Trim() == nombre.ToUpper().Trim());
                if (exists == null)
                {
                    var convenioRamoPaquete = db.ConvenioRamoPaqueteProducto.FirstOrDefault(a => a.IdConvenioProductos == idConvenio && a.IdCatRamoProducto == idCatRamo);
                    if (convenioRamoPaquete == null)
                    {
                        convenioRamoPaquete = new ConvenioRamoPaqueteProducto();
                        convenioRamoPaquete.IdCatRamoProducto = idCatRamo;
                        convenioRamoPaquete.IdConvenioProductos = idConvenio;

                        db.ConvenioRamoPaqueteProducto.Add(convenioRamoPaquete);
                    }
                    var paqueteConvenio = new PaqueteConvenioProducto();
                    paqueteConvenio.IdCatRamoProducto = idCatRamo;
                    paqueteConvenio.IdConvenioProductos = idConvenio;
                    paqueteConvenio.IdCatTipoPaquete = idCatTipoPaquete;
                    paqueteConvenio.NombrePaquete = nombre;
                    paqueteConvenio.AplicaDepreciacion = false;
                    paqueteConvenio.PorcentajeAplicaDepreciacion = 0;
                    paqueteConvenio.IdCatProducto = idCatProducto;
                    paqueteConvenio.IdCatTipoContratanteCasa = idCatTipoContratanteCasa;

                    db.PaqueteConvenioProducto.Add(paqueteConvenio);
                    db.SaveChanges();

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                    {
                        ConvenioRamoPaquete = CommonMethods.UnProxy(db, convenioRamoPaquete),
                        PaqueteConvenio = CommonMethods.UnProxy(db, paqueteConvenio)
                    }), "dynamic");
                }
                else
                {
                    success = false;
                    message = "Ya existe un paquete con el mismo nombre";
                }
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,


            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult PaquetesCoberturasEliminaPaquete(int idPaqueteConvenio, bool EsCasaHabitacion = false)
        {
            bool success = true;
            string message = "";

            try
            {
                if (EsCasaHabitacion)
                {
                    var detalles = db.PaqueteDetalleProducto.Where(a => a.IdPaqueteConvenio == idPaqueteConvenio).ToList();
                    if (detalles != null && detalles.Any())
                    {
                        db.PaqueteDetalleProducto.RemoveRange(detalles);
                        db.SaveChanges();
                    }
                    var paquete = db.PaqueteConvenioProducto.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                    db.PaqueteConvenioProducto.Remove(paquete);
                    db.SaveChanges();
                }
                else
                {
                    var detalles = db.PaqueteDetalle.Where(a => a.IdPaqueteConvenio == idPaqueteConvenio).ToList();
                    if (detalles != null && detalles.Any())
                    {
                        db.PaqueteDetalle.RemoveRange(detalles);
                        db.SaveChanges();
                    }
                    var paquete = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                    db.PaqueteConvenio.Remove(paquete);
                    db.SaveChanges();
                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(idPaqueteConvenio), $"{idPaqueteConvenio.GetType()}");
                }
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,


            }, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// Carga lista para  Combos, ChkBox, RadioButtons
        /// </summary>
        private void PaquetesCoberturasBox(string RamoVehiculo, string OrdenPaquetes, int IdAseguradora, bool convenioOnline)
        {
            int idPaquete = db.Paquete.Where(x => x.IdAseguradora == IdAseguradora).Select(x => x.Id).FirstOrDefault();
            string tabRamoVehiculo = string.Join(",", RamoVehiculo);
            ViewBag.ListaCatRamoVehiculo = db.CatRamoVehiculo.ToList().Where(x => tabRamoVehiculo.Contains(x.IdCatRamo.ToString())).ToList();//integrar campo estatus y traer solo los activos
            ViewBag.ListaCatTipoPaquete = db.CatTipoPaquete.Where(x => x.OnLine == convenioOnline).ToList();
            ViewBag.ComboListaCoberturas = new List<SelectListItem>(db.Cobertura.Where(x => x.IdPaquete == IdAseguradora).OrderBy(x=> x.Clave).ToList().Select(col => new SelectListItem { Value = col.Id.ToString(), Text = string.Concat(col.Clave, " - ", col.Descripcion) }));
            ViewBag.ComboListaCoberturasOpcionales = new List<SelectListItem>(db.CoberturaOpcional.Where(x => x.IdPaquete == IdAseguradora).ToList().Select(col => new SelectListItem { Value = col.Id.ToString(), Text = string.Concat(col.Clave, " - ", col.Descripcion) }));
        }

        /// <summary>
        /// Carga lista para  Combos, ChkBox, RadioButtons
        /// </summary>
        private void PaquetesCoberturasBoxProductos(string RamoVehiculo, string OrdenPaquetes, int IdAseguradora, bool convenioOnline, int IdCatProducto)
        {
            int idPaquete = db.PaqueteProducto.Where(x => x.IdAseguradoraProducto == IdAseguradora).Select(x => x.Id).FirstOrDefault();
            string tabRamoVehiculo = string.Join(",", RamoVehiculo);
            ViewBag.ListaCatRamoVehiculo = db.CatRamoProducto.ToList().Where(x=> x.IdCatProducto == IdCatProducto).ToList();//integrar campo estatus y traer solo los activos
            ViewBag.ListaCatTipoPaquete = db.CatTipoPaqueteProducto.Where(x => x.OnLine == convenioOnline && x.IdCatProducto == IdCatProducto).ToList();

            ViewBag.ComboListaCoberturasPropietario = new List<SelectListItem>(db.CoberturaProducto
                                                                                        .Where(x => x.IdPaqueteProducto == IdAseguradora)
                                                                                        .OrderBy(x=> x.Clave)
                                                                                        .ToList()
                                                                                        .Select(col => new SelectListItem
                                                                                        {
                                                                                            Value = col.Id.ToString(),
                                                                                            Text = string.Concat(col.Clave, " - ", col.Descripcion)
                                                                                        }));

            //ViewBag.ComboListaCoberturasArrendatario = new List<SelectListItem>(db.CoberturaProducto.Where(x => x.IdPaqueteProducto == IdAseguradora && x.IdCatTipoContratanteCasa == 2).ToList()
            //																.Select(col => new SelectListItem
            //																{
            //																	Value = col.Id.ToString(),
            //																	Text = string.Concat(col.Clave, " - ", col.Descripcion)
            //																}));

            //ViewBag.ComboListaCoberturasArrendador = new List<SelectListItem>(db.CoberturaProducto.Where(x => x.IdPaqueteProducto == IdAseguradora && x.IdCatTipoContratanteCasa == 3).ToList()
            //																.Select(col => new SelectListItem
            //																{
            //																	Value = col.Id.ToString(),
            //																	Text = string.Concat(col.Clave, " - ", col.Descripcion)
            //																}));

            ViewBag.ComboContratantes = new List<SelectListItem>(db.CatTipoContratanteCasa.Where(x => x.Estatus == true)
                                                                                          .ToList()
                                                                                          .Select(col => new SelectListItem
                                                                                          {
                                                                                              Value = col.Id.ToString(),
                                                                                              Text = string.Concat(col.Clave, " - ", col.Nombre)
                                                                                          }));
            ViewBag.ComboContratantes.Insert(0, new SelectListItem { Text = "--Seleccione--", Value = "" });
        }

        /// <summary>
        /// vista parcial para agregar coberturas segun sea indicada
        /// </summary>
        /// <param name="Id">id de la cobertura, importanta para la generacion de los id por fila</param>
        /// <param name="Descripcion">la descripcion de la cobertura</param>
        /// <returns>vista parcial-fila cobertura</returns>
        public ActionResult AgregaCobertura(int Id, string Descripcion, int IdAseguradora, string Region, string IdPaquete, int IdRegistro = 0)
        {
            ViewBag.Id = Id;
            //ViewBag.Descripcion = Descripcion;
            ViewBag.Region = Region;
            ViewBag.IdPaquete = IdPaquete;
            ViewBag.ComboTipoSuma = new SelectList(db.CatTipoSumaAsegVehiculo.Where(res => res.IdAseguradora == IdAseguradora && res.Estatus == 1), "Id", "Nombre");

            PaqueteDetalle registro = new PaqueteDetalle();
            if (IdRegistro > 0)
            {
                registro = db.PaqueteDetalle.First(x => x.Id == IdRegistro);
            }
            else
            {
                registro.Descripcion = string.Empty;
            }

            ViewBag.RegPaqueteDetalle = registro;
            ViewBag.NombreCobertura = db.Cobertura.FirstOrDefault(x => x.Id == Id);
            ViewBag.TipoDeducible = new SelectList(db.CatTipoDatoDeducible, "Id", "Nombre");

            return PartialView(registro);
        }

        public ActionResult AgregaCoberturaOpcional(int Id, string Descripcion, int IdAseguradora, string Region, string IdPaquete, int IdRegistro = 0)
        {
            ViewBag.Id = Id;
            //ViewBag.Descripcion = Descripcion;
            ViewBag.Region = Region;
            ViewBag.IdPaquete = IdPaquete;
            ViewBag.ComboTipoSuma = new SelectList(db.CatTipoSumaAsegVehiculo.Where(res => res.IdAseguradora == IdAseguradora && res.Estatus == 1), "Id", "Nombre");

            PaqueteDetalleOpcional registro = new PaqueteDetalleOpcional();
            if (IdRegistro > 0)
            {
                registro = db.PaqueteDetalleOpcional.First(x => x.Id == IdRegistro);
            }
            else
            {
                registro.Descripcion = string.Empty;
            }

            ViewBag.RegPaqueteDetalle = registro;
            ViewBag.NombreCobertura = db.CoberturaOpcional.FirstOrDefault(x => x.Id == Id);
            ViewBag.TipoDeducible = new SelectList(db.CatTipoDatoDeducible, "Id", "Nombre");

            return PartialView(registro);
        }

        /// <summary>
        /// vista parcial para agregar coberturas segun sea indicada
        /// </summary>
        /// <param name="Id">id de la cobertura, importanta para la generacion de los id por fila</param>
        /// <param name="Descripcion">la descripcion de la cobertura</param>
        /// <returns>vista parcial-fila cobertura</returns>
        public ActionResult AgregaCoberturaProducto(int Id,
                                                    string Descripcion,
                                                    int IdAseguradora,
                                                    string Region,
                                                    string IdPaquete,
                                                    int idCatProducto,
                                                    int IdRegistro = 0)
        {
            ViewBag.Id = Id;
            //ViewBag.Descripcion = Descripcion;
            ViewBag.Region = Region;
            ViewBag.IdPaquete = IdPaquete;
            ViewBag.ComboTipoSuma = new SelectList(db.CatTipoSumaAsegVehiculo.Where(res => res.IdAseguradora == IdAseguradora && res.Estatus == 1), "Id", "Nombre");

            if(idCatProducto == 3)
                ViewBag.ComboTipoSuma = new SelectList(db.CatTipoSumaAsegVehiculo.Where(res => res.IdAseguradora == 1 && res.Estatus == 1), "Id", "Nombre");

            PaqueteDetalleProducto registro = new PaqueteDetalleProducto();
            if (IdRegistro > 0)
            {
                registro = db.PaqueteDetalleProducto.First(x => x.Id == IdRegistro);
            }
            else
            {
                registro.Descripcion = string.Empty;
            }

            ViewBag.RegPaqueteDetalle = registro;
            ViewBag.NombreCobertura = db.CoberturaProducto.FirstOrDefault(x => x.Id == Id);
            ViewBag.TipoDeducible = new SelectList(db.CatTipoDatoDeducible, "Id", "Nombre");
            return PartialView(registro);
        }

        private int ActualizarRegistroConvenioRamoPaquete(ConvenioRamoPaquete Original, VRamoCoberturas ramos)
        {
            try
            {
                //primero el convenio ramo paquete
                Original.Comision = ramos.Comision;
                Original.Sobrecomision = ramos.Sobrecomision;
                Original.Descuento = ramos.Descuento;
                Original.UDI = ramos.UDI;
                Original.UDIClave = ramos.UDIClave;
                Original.CesionDeComision = ramos.CesionComision;
                Original.Tarifa = ramos.Tarifa;
                Original.Producto = ramos.Producto;
                Original.TipoCarga = ramos.TipoCarga;
                db.Entry(Original).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, CommonMethods.UnProxy(db, Original))), $"{Original.GetType()}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return Original.Id;
        }

        private int ActualizarRegistroConvenioRamoPaqueteProducto(ConvenioRamoPaqueteProducto Original, VRamoCoberturasProducto ramos, int IdConvenio)
        {
            try
            {
                var Ramo = db.ConvenioProductos.Where(c => c.Id == IdConvenio).SingleOrDefault();
                //primero el convenio ramo paquete
                Original.Comision = ramos.Comision;
                Original.Sobrecomision = ramos.Sobrecomision;
                Original.Descuento = ramos.Descuento;
                Original.UDI = ramos.UDI;
                Original.CesionDeComision = ramos.CesionComision;
                Original.IdCatProducto = Ramo.IdCatProducto;

                db.Entry(Original).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, CommonMethods.UnProxy(db, Original))), $"{Original.GetType()}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return Original.Id;
        }

        private int GuardaRegistroConvenioRamoPaquete(VRamoCoberturas ramos, int IdConvenio)
        {
            //primero el convenio ramo paquete
            ConvenioRamoPaquete ConRamoPaquete = new ConvenioRamoPaquete();
            ConRamoPaquete.Comision = ramos.Comision;
            ConRamoPaquete.Sobrecomision = ramos.Sobrecomision;
            ConRamoPaquete.Descuento = ramos.Descuento;
            ConRamoPaquete.UDI = ramos.UDI;
            ConRamoPaquete.UDIClave = ramos.UDIClave;
            ConRamoPaquete.CesionDeComision = ramos.CesionComision;
            ConRamoPaquete.Tarifa = ramos.Tarifa;
            ConRamoPaquete.Producto = ramos.Producto;
            ConRamoPaquete.IdConvenio = IdConvenio;
            ConRamoPaquete.IdCatRamoVehiculo = ramos.RamoVehiculo;
            ConRamoPaquete.TipoCarga = ramos.TipoCarga;
            db.ConvenioRamoPaquete.Add(ConRamoPaquete);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, CommonMethods.UnProxy(db, ConRamoPaquete))), $"{ConRamoPaquete.GetType()}");

            return ConRamoPaquete.Id;
        }

        private int GuardaRegistroConvenioRamoPaqueteProducto(VRamoCoberturasProducto ramos, int IdConvenio)
        {
            var Ramo = db.ConvenioProductos.Where(c => c.Id == IdConvenio).SingleOrDefault();
            //primero el convenio ramo paquete
            ConvenioRamoPaqueteProducto ConRamoPaquete = new ConvenioRamoPaqueteProducto();
            ConRamoPaquete.Comision = ramos.Comision;
            ConRamoPaquete.Sobrecomision = ramos.Sobrecomision;
            ConRamoPaquete.Descuento = ramos.Descuento;
            ConRamoPaquete.UDI = ramos.UDI;
            ConRamoPaquete.CesionDeComision = ramos.CesionComision;
            ConRamoPaquete.IdCatProducto = Ramo.IdCatProducto;
            ConRamoPaquete.IdConvenioProductos = IdConvenio;
            ConRamoPaquete.IdCatRamoProducto = ramos.RamoProducto;
            db.ConvenioRamoPaqueteProducto.Add(ConRamoPaquete);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, CommonMethods.UnProxy(db, ConRamoPaquete))), $"{ConRamoPaquete.GetType()}");

            return ConRamoPaquete.Id;
        }

        private void EliminaRegistroPaqueteDetalle(PaqueteDetalle registro)
        {
            db.PaqueteDetalle.Remove(registro);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, CommonMethods.UnProxy(db, registro))), $"{registro.GetType()}");
        }

        private void EliminaRegistroPaqueteDetalleOpcional(PaqueteDetalleOpcional registro)
        {
            db.PaqueteDetalleOpcional.Remove(registro);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, CommonMethods.UnProxy(db, registro))), $"{registro.GetType()}");
        }

        private void EliminaRegistroPaqueteDetalleProducto(PaqueteDetalleProducto registro)
        {
            db.PaqueteDetalleProducto.Remove(registro);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, registro)), $"{registro.GetType()}");
        }

        private void ActualizaRegistroPaqueteDetalle(PaqueteDetalle Original, VCoberturas Registro, int IdConvenioRamoPaquete)
        {
            try
            {
                //Registro.Estatus = Estatus;
                Original.TipoSumaAsegurada = Registro.TipoSuma;
                Original.SumaAsegurada = Registro.SumaAsegurada ?? "0";
                Original.SumaAseguradaHomologada = Registro.SumaAseguradaHomologada ?? Registro.SumaAsegurada ?? "0";
                Original.Deducible = Registro.Porcentaje;
                Original.IdTipoDatoDeducible = Registro.IdTipoDatoDeducible;
                Original.Descripcion = Registro.Descripcion;

                db.Entry(Original).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Original)), $"{Original.GetType()}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private void ActualizaRegistroPaqueteDetalleOpcional(PaqueteDetalleOpcional Original, VCoberturas Registro, int IdConvenioRamoPaquete)
        {
            try
            {
                //Registro.Estatus = Estatus;
                Original.TipoSumaAsegurada = Registro.TipoSuma;
                Original.SumaAsegurada = Registro.SumaAsegurada ?? "0";
                Original.Deducible = Registro.Porcentaje;
                Original.IdTipoDatoDeducible = Registro.IdTipoDatoDeducible;
                Original.Descripcion = Registro.Descripcion;

                db.Entry(Original).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Original)), $"{Original.GetType()}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }


        private void ActualizaRegistroPaqueteDetalleProducto(PaqueteDetalleProducto Original, VCoberturasProducto Registro, int IdConvenioRamoPaquete)
        {
            try
            {
                //Registro.Estatus = Estatus;
                Original.TipoSumaAsegurada = Registro.TipoSuma;
                Original.SumaAsegurada = Registro.SumaAsegurada ?? "0";
                Original.Deducible = Registro.Porcentaje;
                Original.Descripcion = Registro.Descripcion;
                Original.TextoDeducible = Registro.TextoDeducible;

                db.Entry(Original).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Original)), $"{Original.GetType()}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private void GuardaRegistroPaqueteDetalle(VCoberturas Registro, int IdConvenioRamoPaquete)
        {
            PaqueteDetalle PaqDetalle = new PaqueteDetalle();
            PaqDetalle.TipoSumaAsegurada = Registro.TipoSuma;
            PaqDetalle.SumaAsegurada = Registro.SumaAsegurada ?? "0";
            PaqDetalle.SumaAseguradaHomologada = Registro.SumaAseguradaHomologada ?? Registro.SumaAsegurada ?? "0";
            PaqDetalle.Deducible = Registro.Porcentaje;
            PaqDetalle.Descripcion = Registro.Descripcion;
            PaqDetalle.IdPaqueteConvenio = Registro.IdPaqueteConvenio;
            PaqDetalle.IdConvenioRamoPaquete = IdConvenioRamoPaquete;
            PaqDetalle.IdCatTipoPaquete = Registro.IdCatTipoPaquete;
            PaqDetalle.IdCobertura = Registro.Cobertura;
            PaqDetalle.IdTipoDatoDeducible = Registro.IdTipoDatoDeducible;

            db.PaqueteDetalle.Add(PaqDetalle);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, PaqDetalle)), $"{PaqDetalle.GetType()}");
        }

        private void GuardaRegistroPaqueteDetalleOpcional(VCoberturas Registro, int IdConvenioRamoPaquete)
        {
            PaqueteDetalleOpcional PaqDetalle = new PaqueteDetalleOpcional();
            PaqDetalle.TipoSumaAsegurada = Registro.TipoSuma;
            PaqDetalle.SumaAsegurada = Registro.SumaAsegurada ?? "0";
            PaqDetalle.Deducible = Registro.Porcentaje;
            PaqDetalle.Descripcion = Registro.Descripcion;
            PaqDetalle.IdPaqueteConvenio = Registro.IdPaqueteConvenio;
            PaqDetalle.IdConvenioRamoPaquete = IdConvenioRamoPaquete;
            PaqDetalle.IdCatTipoPaquete = Registro.IdCatTipoPaquete;
            PaqDetalle.IdCobertura = Registro.Cobertura;
            PaqDetalle.IdTipoDatoDeducible = Registro.IdTipoDatoDeducible;

            db.PaqueteDetalleOpcional.Add(PaqDetalle);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, PaqDetalle)), $"{PaqDetalle.GetType()}");
        }

        private void GuardaRegistroPaqueteDetalleProducto(VCoberturasProducto Registro, int IdConvenioRamoPaquete, int IdConvenio)
        {
            var Ramo = db.ConvenioProductos.Where(c => c.Id == IdConvenio).SingleOrDefault();

            PaqueteDetalleProducto PaqDetalle = new PaqueteDetalleProducto();
            PaqDetalle.IdCatProducto = Ramo.IdCatProducto;
            PaqDetalle.TipoSumaAsegurada = Registro.TipoSuma;
            PaqDetalle.SumaAsegurada = Registro.SumaAsegurada ?? "0";
            PaqDetalle.Deducible = Registro.Porcentaje;
            PaqDetalle.Descripcion = Registro.Descripcion;
            PaqDetalle.IdPaqueteConvenio = Registro.IdPaqueteConvenioProducto;
            PaqDetalle.IdConvenioRamoPaquete = IdConvenioRamoPaquete;
            PaqDetalle.IdCatTipoPaquete = Registro.IdCatTipoPaqueteProducto;
            PaqDetalle.IdCobertura = Registro.Cobertura;

            db.PaqueteDetalleProducto.Add(PaqDetalle);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, PaqDetalle)), $"{PaqDetalle.GetType()}");
        }

        /// <summary>
        /// Guarda lista paquete convenio %covertura
        /// </summary>
        /// <param name="IdConvenio">Id del convenio al que pertenece</param>
        /// <param name="Registros">listado de paquete convenio</param>
        private void GuardaPaqueteConvenio(int IdConvenio, List<VPaqueteConvenio> Registros)
        {
            //buscamos si existen datos ya guardado
            List<PaqueteConvenio> ListaPaqueteConvenio = new List<PaqueteConvenio>();
            ListaPaqueteConvenio = db.PaqueteConvenio.Where(x => x.IdConvenio == IdConvenio).ToList();
            PaqueteConvenio RegistroOriginal = new PaqueteConvenio();
            if (ListaPaqueteConvenio.Count > 0)
            {//guarda nuevos y actualiza
                Registros.ForEach(registro =>
                {
                    if (ListaPaqueteConvenio.Exists(busca => busca.Id == registro.Id))
                    {//actualizar
                        RegistroOriginal = ListaPaqueteConvenio.First(busca => busca.Id == registro.Id);
                        ActualizarRegistroPaqueteConvenio(RegistroOriginal, registro);
                    }
                    else
                    {//guarda nuevos
                        GuardaRegistroPaqueteDetalle(IdConvenio, registro);
                    }
                });
            }
            else
            {//guarda nuevos
                Registros.ForEach(registro =>
                {
                    GuardaRegistroPaqueteDetalle(IdConvenio, registro);
                });
            }
        }

        /// <summary>
        /// Guarda lista paquete convenio %covertura
        /// </summary>
        /// <param name="IdConvenio">Id del convenio al que pertenece</param>
        /// <param name="Registros">listado de paquete convenio</param>
        private void GuardaPaqueteConvenioProducto(int IdConvenio, List<VPaqueteConvenioProducto> Registros)
        {
            //buscamos si existen datos ya guardado
            List<PaqueteConvenioProducto> ListaPaqueteConvenio = new List<PaqueteConvenioProducto>();
            ListaPaqueteConvenio = db.PaqueteConvenioProducto.Where(x => x.IdConvenioProductos == IdConvenio).ToList();
            PaqueteConvenioProducto RegistroOriginal = new PaqueteConvenioProducto();
            if (ListaPaqueteConvenio.Count > 0)
            {//guarda nuevos y actualiza
                Registros.ForEach(registro =>
                {
                    if (ListaPaqueteConvenio.Exists(busca => busca.Id == registro.Id))
                    {//actualizar
                        RegistroOriginal = ListaPaqueteConvenio.First(busca => busca.Id == registro.Id);
                        ActualizarRegistroPaqueteConvenioProducto(RegistroOriginal, registro);
                    }
                    else
                    {//guarda nuevos
                        GuardaRegistroPaqueteDetalleProducto(IdConvenio, registro);
                    }
                });
            }
            else
            {//guarda nuevos
                Registros.ForEach(registro =>
                {
                    GuardaRegistroPaqueteDetalleProducto(IdConvenio, registro);
                });
            }
        }

        /// <summary>
        /// actualiza el registro de paquete detalle depreciacion
        /// </summary>
        /// <param name="Original">registro original en db</param>
        /// <param name="Registro">registro nuevo</param>
        private void ActualizarRegistroPaqueteConvenio(PaqueteConvenio Original, VPaqueteConvenio Registro)
        {
            try
            {
                //primero el convenio ramo paquete
                //Original.IdCatRamoVehiculo = Registro.Ramo;
                //Original.IdCatTipoPaquete = Registro.Paquete;
                Original.AplicaDepreciacion = Registro.AplicaDepreciacion;
                Original.NombrePaquete = Registro.NombrePaquete;
                Original.IdPlan = Registro.IdPlan;
                Original.ClavePlan = Registro.ClavePlan;
                Original.IdPlanPersonaMoral = Registro.IdPlanPersonaMoral;
                Original.Condicion34 = Registro.Condicion34;
                Original.AplicaValorConvenido = Registro.AplicaValorConvenido;
                Original.CoberturaAdicionalAIG = Registro.CoberturaAdicionalAIG;

                double porcentaje = Registro.AplicaDepreciacion ? Registro.PorcentajeAplicaDepreciacion : 0;
                Original.PorcentajeAplicaDepreciacion = porcentaje;
                Original.ReimpresionRC = Registro.ReimpresionRC;
                Original.TipoRegla34 = Registro.TipoRegla34;

                db.Entry(Original).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Original)), $"{Original.GetType()}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// actualiza el registro de paquete detalle depreciacion
        /// </summary>
        /// <param name="Original">registro original en db</param>
        /// <param name="Registro">registro nuevo</param>
        private void ActualizarRegistroPaqueteConvenioProducto(PaqueteConvenioProducto Original, VPaqueteConvenioProducto Registro)
        {
            try
            {
                //primero el convenio ramo paquete
                //Original.IdCatRamoVehiculo = Registro.Ramo;
                //Original.IdCatTipoPaquete = Registro.Paquete;
                Original.AplicaDepreciacion = Registro.AplicaDepreciacion;
                Original.NombrePaquete = Registro.NombrePaquete;
                double porcentaje = Registro.AplicaDepreciacion ? Registro.PorcentajeAplicaDepreciacion : 0;
                Original.PorcentajeAplicaDepreciacion = porcentaje;

                db.Entry(Original).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Original)), $"{Original.GetType()}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// guarda el registro de paquete detalle depreciacion
        /// </summary>
        /// <param name="IdConvenio">Id del convenio</param>
        /// <param name="Registro">registro a guardar</param>
        private void GuardaRegistroPaqueteDetalle(int IdConvenio, VPaqueteConvenio Registro)
        {

            PaqueteConvenio PaqDetalle = new PaqueteConvenio();
            PaqDetalle.IdConvenio = IdConvenio;
            PaqDetalle.IdCatRamoVehiculo = Registro.Ramo;
            PaqDetalle.IdCatTipoPaquete = Registro.Paquete;
            PaqDetalle.AplicaDepreciacion = Registro.AplicaDepreciacion;
            double porcentaje = Registro.AplicaDepreciacion ? Registro.PorcentajeAplicaDepreciacion : 0;
            PaqDetalle.PorcentajeAplicaDepreciacion = porcentaje;
            PaqDetalle.NombrePaquete = Registro.NombrePaquete;
            PaqDetalle.IdPlan = Registro.IdPlan;
            PaqDetalle.ClavePlan = Registro.ClavePlan;
            PaqDetalle.IdPlanPersonaMoral = Registro.IdPlanPersonaMoral;
            PaqDetalle.Condicion34 = Registro.Condicion34;
            PaqDetalle.TipoRegla34 = Registro.TipoRegla34;
            PaqDetalle.AplicaValorConvenido = Registro.AplicaValorConvenido;
            PaqDetalle.CoberturaAdicionalAIG = Registro.CoberturaAdicionalAIG;

            db.PaqueteConvenio.Add(PaqDetalle);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, PaqDetalle)), $"{PaqDetalle.GetType()}");
        }

        private void GuardaRegistroPaqueteDetalleProducto(int IdConvenio, VPaqueteConvenioProducto Registro)
        {
            var Ramo = db.ConvenioProductos.Where(c => c.Id == IdConvenio).SingleOrDefault();

            PaqueteConvenioProducto PaqDetalle = new PaqueteConvenioProducto();
            PaqDetalle.IdConvenioProductos = IdConvenio;
            PaqDetalle.IdCatRamoProducto = Registro.Ramo;
            PaqDetalle.IdCatTipoPaquete = Registro.Paquete;
            PaqDetalle.AplicaDepreciacion = Registro.AplicaDepreciacion;
            double porcentaje = Registro.AplicaDepreciacion ? Registro.PorcentajeAplicaDepreciacion : 0;
            PaqDetalle.PorcentajeAplicaDepreciacion = porcentaje;
            PaqDetalle.NombrePaquete = (Registro.NombrePaquete != null) ? Registro.NombrePaquete : string.Empty;
            PaqDetalle.IdCatProducto = Ramo.IdCatProducto;
            db.PaqueteConvenioProducto.Add(PaqDetalle);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, PaqDetalle)), $"{PaqDetalle.GetType()}");
        }

        /// <summary>
        /// Elimina Los paquetes posterior a las coberturas
        /// </summary>
        /// <param name="paquetes"></param>
        private void EliminaPaquete(GuardaCoberturas paquetes)
        {
            List<PaqueteConvenio> paquetesConvenio = new List<PaqueteConvenio>();
            paquetesConvenio = db.PaqueteConvenio.Where(x => x.IdConvenio == paquetes.IdConvenio).ToList();
            paquetesConvenio.ForEach(paquete =>
            {

                paquetesConvenio = db.PaqueteConvenio.Where(x => x.IdConvenio == paquetes.IdConvenio && x.IdCatTipoPaquete == paquete.IdCatTipoPaquete).ToList();


            });
            EliminaCoberturas(paquetesConvenio);
        }
        /// <summary>
        /// Elimina las coberturas por paquete no seleccionado
        /// </summary>
        private void EliminaCoberturas(List<PaqueteConvenio> paquetes)
        {
            try
            {
                List<PaqueteDetalle> coberturas = new List<PaqueteDetalle>();

                paquetes.ForEach(paquete =>
                {
                    int convenioRamoPaquete = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == paquete.IdConvenio).FirstOrDefault().Id;

                    coberturas = db.PaqueteDetalle.Where(x => x.IdCatTipoPaquete == paquete.IdCatTipoPaquete && x.IdConvenioRamoPaquete == convenioRamoPaquete).ToList();

                });
                if (coberturas.Count > 0)
                {
                    coberturas.ForEach(cobertura =>
                    {
                        db.PaqueteDetalle.Remove(cobertura);
                    });
                    paquetes.ForEach(paquete =>
                    {
                        IQueryable<PaqueteConvenio> item = db.PaqueteConvenio.Where(x => x.IdCatTipoPaquete == paquete.IdCatTipoPaquete && x.IdConvenio == paquete.IdConvenio);
                    });
                    db.SaveChanges();
                }
                else
                {
                    if (coberturas.Count == 0 && paquetes.Count > 0)
                    {
                        paquetes.ForEach(paquete =>
                        {
                            db.PaqueteConvenio.Remove(paquete);
                        });
                        db.SaveChanges();
                    }
                }

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, paquetes)), $"{paquetes.GetType()}");
            }
            catch (Exception)
            {
            }

        }
        #endregion

        #region 3.- Parámetros de cotización

        /// <summary>
        /// Parámetros de cotización
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult ParametrosCotizacion(int IdEmpresa, int IdConvenio)
        {
            //obtener configuracionConvenio
            ConfiguracionEmpresa dbCfgEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            LocktonModel.db.Convenio ElConvenio = new LocktonModel.db.Convenio();
            if (IdConvenio > 0)
                ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == IdConvenio);
            else
                return HttpNotFound();

            ParametrosCotizacionBox();
            //carga info para checkbox
            ElConvenio.chkTipoUsoVehiculo = string.Join(",", db.TipoUsoVehiculo.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdCatTipoUsoVehiculo).ToList());
            ElConvenio.chkAdministrador = string.Join(",", db.AccesoValorFactura.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdCatAccesoValorFactura).ToList());
            ElConvenio.chkABPPC = string.Join(",", db.AccesoBeneficiarioPreferente.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdCatAccesoBeneficiarioPreferente).ToList());
            ElConvenio.ListaCatParentesco = string.Join(",", db.ConvenioParentesco.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdParentesco).ToList());

            ViewBag.Aseguradora = ElConvenio.Aseguradora == null ? "" : ElConvenio.Aseguradora.Nombre;
            return View(ElConvenio);
        }

        /// <summary>
        /// Parámetros de cotización
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult ParametrosCotizacionProducto(int IdEmpresa, int IdConvenio)
        {
            //obtener configuracionConvenio
            ConfiguracionEmpresa dbCfgEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            LocktonModel.db.ConvenioProductos ElConvenio = new LocktonModel.db.ConvenioProductos();
            if (IdConvenio > 0)
                ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == IdConvenio);
            else
                return HttpNotFound();

            ParametrosCotizacionBox();
            //carga info para checkbox
            ElConvenio.chkTipoUsoVehiculo = string.Join(",", db.TipoUsoVehiculo.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdCatTipoUsoVehiculo).ToList());
            ElConvenio.chkAdministrador = string.Join(",", db.AccesoValorFactura.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdCatAccesoValorFactura).ToList());
            ElConvenio.chkABPPC = string.Join(",", db.AccesoBeneficiarioPreferente.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdCatAccesoBeneficiarioPreferente).ToList());
            ElConvenio.ListaCatParentesco = string.Join(",", db.ConvenioParentesco.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdParentesco).ToList());

            return View(ElConvenio);
        }

        /// <summary>
        /// Parámetros de cotización
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ParametrosCotizacion(LocktonModel.db.Convenio Captura)
        {
            LocktonModel.db.Convenio ElConvenio = new LocktonModel.db.Convenio();
            ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == Captura.Id);

            if (ModelState.IsValid)
            {


                if (Captura.Id > 0)
                {//actualiza

                    ElConvenio.Tarifa = Captura.Tarifa;
                    ElConvenio.Usuario = Captura.Usuario;
                    ElConvenio.Contrasena = Captura.Contrasena;
                    ElConvenio.CodigoPromocion = Captura.CodigoPromocion;

                    ElConvenio.DerechosPrimerRecibo = Captura.DerechosPrimerRecibo;
                    ElConvenio.DerechosPoliza = Captura.DerechosPoliza;
                    ElConvenio.SumaAsegurada = Captura.SumaAsegurada;

                    ElConvenio.IdCatTipoNegocio = Captura.IdCatTipoNegocio;
                    ElConvenio.ClaveAgente = Captura.ClaveAgente;
                    ElConvenio.Contrato = Captura.Contrato;
                    ElConvenio.optAplicarVF = Captura.optAplicarVF;
                    if (!string.IsNullOrEmpty(Captura.NumeroPolizaGrupo))
                        ElConvenio.NumeroPolizaGrupo = Captura.NumeroPolizaGrupo;

                    ElConvenio.optIncluyeBP = Captura.optIncluyeBP;
                    if (!string.IsNullOrEmpty(Captura.CodigoIntermediario))
                        ElConvenio.CodigoIntermediario = Captura.CodigoIntermediario;
                    if (!string.IsNullOrEmpty(Captura.ProductoAXA))
                        ElConvenio.ProductoAXA = Captura.ProductoAXA;
                    if (!string.IsNullOrEmpty(Captura.NombreAXA))
                        ElConvenio.NombreAXA = Captura.NombreAXA;
                    if (!string.IsNullOrEmpty(Captura.SerieAXA))
                        ElConvenio.SerieAXA = Captura.SerieAXA;
                    if (!string.IsNullOrEmpty(Captura.IdCotizacion))
                        ElConvenio.IdCotizacion = Captura.IdCotizacion;
                    if (!string.IsNullOrEmpty(Captura.IdPoliza))
                        ElConvenio.IdPoliza = Captura.IdPoliza;
                    ElConvenio.CHKCARTYPE = Captura.CHKCARTYPE;
                    db.Entry(ElConvenio).State = EntityState.Modified;
                    db.SaveChanges();
                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Captura)), $"{Captura.GetType()}");
                    //guarda los grupos de checkBox

                    //modalidad de pago
                    //GuardaModalidadPago(Captura.Id, Captura.chkModalidadPago);

                    //tipos de tarjeta
                    //GuardaTipoTarjeta(Captura.Id, Captura.chkTipoTarjeta);

                    //tipo uso de vehiculo
                    GuardaTipoUsoVehiculo(Captura.Id, Captura.chkTipoUsoVehiculo);

                    //Acceso aplica valor factura
                    GuardaAccesoValorFactura(Captura.Id, Captura.chkAdministrador);

                    //Acceso aplica beneficiario preferente
                    GuardaAccesoBeneficiarioPreferente(Captura.Id, Captura.chkABPPC);

                    //lista Parentesco
                    GuardaConvenioParentesco(Captura.Id, Captura.ListaCatParentesco);

                    return RedirectToAction("FormaPago", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.Id });
                }
                else
                {//no existe previo registro
                    return HttpNotFound();
                }
            }
            //si no es valido
            ParametrosCotizacionBox();

            ViewBag.Aseguradora = Captura.Aseguradora == null ? "" : Captura.Aseguradora.Nombre;

            return View(Captura);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ParametrosCotizacionProducto(LocktonModel.db.ConvenioProductos Captura)
        {
            if (ModelState.IsValid)
            {
                LocktonModel.db.ConvenioProductos ElConvenio = new LocktonModel.db.ConvenioProductos();

                if (Captura.Id > 0)
                {//actualiza
                    ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == Captura.Id);
                    ElConvenio.Tarifa = Captura.Tarifa;
                    ElConvenio.Usuario = Captura.Usuario;
                    ElConvenio.Contrasena = Captura.Contrasena;
                    ElConvenio.CodigoPromocion = Captura.CodigoPromocion;

                    ElConvenio.DerechosPrimerRecibo = Captura.DerechosPrimerRecibo;
                    ElConvenio.DerechosPoliza = Captura.DerechosPoliza;
                    ElConvenio.SumaAsegurada = Captura.SumaAsegurada;

                    ElConvenio.IdCatTipoNegocio = Captura.IdCatTipoNegocio;

                    ElConvenio.optAplicarVF = Captura.optAplicarVF;
                    if (!string.IsNullOrEmpty(Captura.NumeroPolizaGrupo))
                        ElConvenio.NumeroPolizaGrupo = Captura.NumeroPolizaGrupo;

                    ElConvenio.optIncluyeBP = Captura.optIncluyeBP;
                    if (!string.IsNullOrEmpty(Captura.CodigoIntermediario))
                        ElConvenio.CodigoIntermediario = Captura.CodigoIntermediario;
                    if (!string.IsNullOrEmpty(Captura.ProductoAXA))
                        ElConvenio.ProductoAXA = Captura.ProductoAXA;
                    if (!string.IsNullOrEmpty(Captura.NombreAXA))
                        ElConvenio.NombreAXA = Captura.NombreAXA;
                    if (!string.IsNullOrEmpty(Captura.SerieAXA))
                        ElConvenio.SerieAXA = Captura.SerieAXA;
                    db.Entry(ElConvenio).State = EntityState.Modified;
                    db.SaveChanges();

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Captura)), $"{Captura.GetType()}");
                    //guarda los grupos de checkBox

                    //modalidad de pago
                    //GuardaModalidadPago(Captura.Id, Captura.chkModalidadPago);

                    //tipos de tarjeta
                    //GuardaTipoTarjeta(Captura.Id, Captura.chkTipoTarjeta);

                    //tipo uso de vehiculo
                    //GuardaTipoUsoVehiculo(Captura.Id, Captura.chkTipoUsoVehiculo);

                    //Acceso aplica valor factura
                    //GuardaAccesoValorFactura(Captura.Id, Captura.chkAdministrador);

                    //Acceso aplica beneficiario preferente
                    //GuardaAccesoBeneficiarioPreferente(Captura.Id, Captura.chkABPPC);

                    //lista Parentesco
                    //GuardaConvenioParentesco(Captura.Id, Captura.ListaCatParentesco);

                    return RedirectToAction("FormaPagoProducto", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.Id });
                }
                else
                {//no existe previo registro
                    return HttpNotFound();
                }
            }
            //si no es valido
            ParametrosCotizacionBox();
            return View(Captura);
        }
        /// <summary>
        /// carga de lista y combos
        /// </summary>
        private void ParametrosCotizacionBox()
        {
            ViewBag.ListaCatTipoUsoVehiculo = db.CatTipoUsoVehiculo.Where(x => x.Estatus == 1).ToList();
            ViewBag.IdListaCatParentesco = new SelectList(db.CatParentesco, "Id", "Nombre");
        }

        private List<int> ListaChecks(string ChkLista)
        {
            List<int> ListaIds = new List<int>();
            string[] lista = { };
            if (ChkLista != null)
            {
                if (ChkLista.Trim().Length > 0)
                {
                    lista = ChkLista.Split(',');
                    foreach (string item in lista)
                        ListaIds.Add(int.Parse(item));
                }
            }
            return ListaIds;
        }

        private void GuardaRegistroTipoUsoVehiculo(int IdConvenio, int IdCat)
        {
            TipoUsoVehiculo RegistroNUevo = new TipoUsoVehiculo();
            RegistroNUevo.IdConvenio = IdConvenio;
            RegistroNUevo.IdCatTipoUsoVehiculo = IdCat;
            RegistroNUevo.Estatus = 1;
            db.TipoUsoVehiculo.Add(RegistroNUevo);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, RegistroNUevo)), $"{RegistroNUevo.GetType()}");
        }

        private void ActualizaRegistroTipoUsoVehiculo(TipoUsoVehiculo Registro, int Estatus)
        {
            Registro.Estatus = Estatus;
            db.Entry(Registro).State = EntityState.Modified;
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Registro)), $"{Registro.GetType()}");
        }

        private void GuardaTipoUsoVehiculo(int IdConvenio, string ChkLista)
        {
            List<int> listaIdChks = ListaChecks(ChkLista);
            List<int> Encontrados = new List<int>();
            //buscamos si existen datos ya guardado
            List<TipoUsoVehiculo> DatosTipoUsoVehiculo = new List<TipoUsoVehiculo>();
            DatosTipoUsoVehiculo = db.TipoUsoVehiculo.Where(busca => busca.IdConvenio == IdConvenio).ToList();
            if (DatosTipoUsoVehiculo.Count > 0)
            {//guarda nuevos y actualiza
             //los nuevos datos
                listaIdChks.ForEach(IdChk =>
                {
                    if (DatosTipoUsoVehiculo.Exists(busca => busca.IdCatTipoUsoVehiculo == IdChk))
                    {//marcar como encontrado
                        Encontrados.Add(IdChk);
                    }
                    else
                    {//agregar
                        GuardaRegistroTipoUsoVehiculo(IdConvenio, IdChk);
                    }
                });
                //Revisar los que ya se encontraban guardados
                DatosTipoUsoVehiculo.ForEach(dato =>
                {
                    if (Encontrados.Exists(y => y == dato.IdCatTipoUsoVehiculo))
                    {//verifica si no esta activo, activarlo
                        if (dato.Estatus != 1)
                        {
                            ActualizaRegistroTipoUsoVehiculo(dato, 1);
                        }
                    }
                    else//si no esta en la lista nueva, desactivarlo
                    {
                        ActualizaRegistroTipoUsoVehiculo(dato, 2);
                    }
                });
            }
            else
            {//guarda nuevos
                listaIdChks.ForEach(IdChk =>
                {
                    GuardaRegistroTipoUsoVehiculo(IdConvenio, IdChk);
                });
            }
        }

        private void GuardaRegistroAccesoValorFactura(int IdConvenio, int IdCat)
        {
            AccesoValorFactura RegistroNUevo = new AccesoValorFactura();
            RegistroNUevo.IdConvenio = IdConvenio;
            RegistroNUevo.IdCatAccesoValorFactura = IdCat;
            RegistroNUevo.Estatus = 1;
            db.AccesoValorFactura.Add(RegistroNUevo);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, RegistroNUevo)), $"{RegistroNUevo.GetType()}");
        }

        private void ActualizaRegistroAccesoValorFactura(AccesoValorFactura Registro, int Estatus)
        {
            Registro.Estatus = Estatus;
            db.Entry(Registro).State = EntityState.Modified;
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Registro)), $"{Registro.GetType()}");
        }

        private void GuardaAccesoValorFactura(int IdConvenio, string ChkLista)
        {
            List<int> listaIdChks = ListaChecks(ChkLista);
            List<int> Encontrados = new List<int>();
            //buscamos si existen datos ya guardado
            List<AccesoValorFactura> DatosAccesoValorFactura = new List<AccesoValorFactura>();
            DatosAccesoValorFactura = db.AccesoValorFactura.Where(busca => busca.IdConvenio == IdConvenio).ToList();
            if (DatosAccesoValorFactura.Count > 0)
            {//guarda nuevos y actualiza
             //los nuevos datos
                listaIdChks.ForEach(IdChk =>
                {
                    if (DatosAccesoValorFactura.Exists(busca => busca.IdCatAccesoValorFactura == IdChk))
                    {//marcar como encontrado
                        Encontrados.Add(IdChk);
                    }
                    else
                    {//agregar
                        GuardaRegistroAccesoValorFactura(IdConvenio, IdChk);
                    }
                });
                //Revisar los que ya se encontraban guardados
                DatosAccesoValorFactura.ForEach(dato =>
                {
                    if (Encontrados.Exists(y => y == dato.IdCatAccesoValorFactura))
                    {//verifica si no esta activo, activarlo
                        if (dato.Estatus != 1)
                        {
                            ActualizaRegistroAccesoValorFactura(dato, 1);
                        }
                    }
                    else//si no esta en la lista nueva, desactivarlo
                    {
                        ActualizaRegistroAccesoValorFactura(dato, 2);
                    }
                });
            }
            else
            {//guarda nuevos
                listaIdChks.ForEach(IdChk =>
                {
                    GuardaRegistroAccesoValorFactura(IdConvenio, IdChk);
                });
            }
        }

        private void GuardaRegistroAccesoBeneficiarioPreferente(int IdConvenio, int IdCat)
        {
            AccesoBeneficiarioPreferente RegistroNUevo = new AccesoBeneficiarioPreferente();
            RegistroNUevo.IdConvenio = IdConvenio;
            RegistroNUevo.IdCatAccesoBeneficiarioPreferente = IdCat;
            RegistroNUevo.Estatus = 1;
            db.AccesoBeneficiarioPreferente.Add(RegistroNUevo);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, RegistroNUevo)), $"{RegistroNUevo.GetType()}");
        }

        private void ActualizaRegistroAccesoBeneficiarioPreferente(AccesoBeneficiarioPreferente Registro, int Estatus)
        {
            Registro.Estatus = Estatus;
            db.Entry(Registro).State = EntityState.Modified;
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Registro)), $"{Registro.GetType()}");
        }

        private void GuardaAccesoBeneficiarioPreferente(int IdConvenio, string ChkLista)
        {
            List<int> listaIdChks = ListaChecks(ChkLista);
            List<int> Encontrados = new List<int>();
            //buscamos si existen datos ya guardado
            List<AccesoBeneficiarioPreferente> DatosAccesoBeneficiarioPreferente = new List<AccesoBeneficiarioPreferente>();
            DatosAccesoBeneficiarioPreferente = db.AccesoBeneficiarioPreferente.Where(busca => busca.IdConvenio == IdConvenio).ToList();
            if (DatosAccesoBeneficiarioPreferente.Count > 0)
            {//guarda nuevos y actualiza
             //los nuevos datos
                listaIdChks.ForEach(IdChk =>
                {
                    if (DatosAccesoBeneficiarioPreferente.Exists(busca => busca.IdCatAccesoBeneficiarioPreferente == IdChk))
                    {//marcar como encontrado
                        Encontrados.Add(IdChk);
                    }
                    else
                    {//agregar
                        GuardaRegistroAccesoBeneficiarioPreferente(IdConvenio, IdChk);
                    }
                });
                //Revisar los que ya se encontraban guardados
                DatosAccesoBeneficiarioPreferente.ForEach(dato =>
                {
                    if (Encontrados.Exists(y => y == dato.IdCatAccesoBeneficiarioPreferente))
                    {//verifica si no esta activo, activarlo
                        if (dato.Estatus != 1)
                        {
                            ActualizaRegistroAccesoBeneficiarioPreferente(dato, 1);
                        }
                    }
                    else//si no esta en la lista nueva, desactivarlo
                    {
                        ActualizaRegistroAccesoBeneficiarioPreferente(dato, 2);
                    }
                });
            }
            else
            {//guarda nuevos
                listaIdChks.ForEach(IdChk =>
                {
                    GuardaRegistroAccesoBeneficiarioPreferente(IdConvenio, IdChk);
                });
            }
        }

        private void GuardaRegistroConvenioParentesco(int IdConvenio, int IdCat)
        {
            ConvenioParentesco RegistroNUevo = new ConvenioParentesco();
            RegistroNUevo.IdConvenio = IdConvenio;
            RegistroNUevo.IdParentesco = IdCat;
            RegistroNUevo.Estatus = 1;
            db.ConvenioParentesco.Add(RegistroNUevo);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, RegistroNUevo)), $"{RegistroNUevo.GetType()}");
        }

        private void ActualizaRegistroConvenioParentesco(ConvenioParentesco Registro, int Estatus)
        {
            Registro.Estatus = Estatus;
            db.Entry(Registro).State = EntityState.Modified;
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Registro)), $"{Registro.GetType()}");
        }

        private void GuardaConvenioParentesco(int IdConvenio, string ChkLista)
        {
            List<int> listaIdChks = ListaChecks(ChkLista);
            List<int> Encontrados = new List<int>();
            //buscamos si existen datos ya guardado
            List<ConvenioParentesco> DatosConvenioParentesco = new List<ConvenioParentesco>();
            DatosConvenioParentesco = db.ConvenioParentesco.Where(busca => busca.IdConvenio == IdConvenio).ToList();
            if (DatosConvenioParentesco.Count > 0)
            {//guarda nuevos y actualiza
             //los nuevos datos
                listaIdChks.ForEach(IdChk =>
                {
                    if (DatosConvenioParentesco.Exists(busca => busca.IdParentesco == IdChk))
                    {//marcar como encontrado
                        Encontrados.Add(IdChk);
                    }
                    else
                    {//agregar
                        GuardaRegistroConvenioParentesco(IdConvenio, IdChk);
                    }
                });
                //Revisar los que ya se encontraban guardados
                DatosConvenioParentesco.ForEach(dato =>
                {
                    if (Encontrados.Exists(y => y == dato.IdParentesco))
                    {//verifica si no esta activo, activarlo
                        if (dato.Estatus != 1)
                        {
                            ActualizaRegistroConvenioParentesco(dato, 1);
                        }
                    }
                    else//si no esta en la lista nueva, desactivarlo
                    {
                        ActualizaRegistroConvenioParentesco(dato, 2);
                    }
                });
            }
            else
            {//guarda nuevos
                listaIdChks.ForEach(IdChk =>
                {
                    GuardaRegistroConvenioParentesco(IdConvenio, IdChk);
                });
            }
        }
        #endregion

        #region 4.- Forma de pago

        /// <summary>
        /// Forma de pago
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult FormaPago(int IdEmpresa, int IdConvenio)
        {
            ConfiguracionEmpresa dbCfgEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            LocktonModel.db.Convenio ElConvenio = new LocktonModel.db.Convenio();
            if (IdConvenio > 0)
                ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == IdConvenio);
            else
                return HttpNotFound();

            //CAT: Carga como desactivada la domiciliacion posterior cuando el convenio GNP aun no tiene configuracion.
            if (ElConvenio.IdAseguradora == 2)
            {
                ConfiguracionDomiciliacionGNP configuracionDomiciliacion = db.ConfiguracionDomiciliacionGNP.FirstOrDefault(x => x.IdConvenio == IdConvenio);
                ElConvenio.AplicaDomiciliacionPostEmision = configuracionDomiciliacion != null && configuracionDomiciliacion.AplicaDomiciliacionPostEmision;
            }

            ParametrosFormaPago(IdConvenio, dbCfgEmpresa.AplicaMultiAnual);
            //carga info para checkbox
            ElConvenio.chkCatUsuarioSolicitaCancelacion = string.Join(",", db.UsuarioSolicitaCancelacion.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList().Select(y => y.IdCatUsuarioSolicitaCancelacion).ToList());
            ViewBag.ModalidadFormaPago = db.ModalidadFormaPago.Where(x => x.IdConvenio == IdConvenio).ToList();


            List<ListaCombo> polizasMaestras = db.ListaCombo.SqlQuery("sp_obtener_select_polizamaestra_core").ToList();
            polizasMaestras.Add(new ListaCombo() { Id = 0, Nombre = "Selecciona" });
            ViewBag.PolizasMaestra = new SelectList(polizasMaestras, "Id", "Nombre");

            ElConvenio.MSI = GetConvenioMSI(IdConvenio, false);
            ElConvenio.MultiAnual = dbCfgEmpresa.AplicaMultiAnual;

            return View(ElConvenio);
        }

        public JsonResult ObtenerPeriodicidadMultianual(int idConvenio, int idCatPeriodicidadFormaPago)
        {
            var multianual = new List<PeriodicidadMultianual>();
            try
            {
                multianual = db.PeriodicidadMultianual.Where(a => a.IdConvenio == idConvenio && a.IdCatPeriodicidadFormaPago == idCatPeriodicidadFormaPago).ToList();


            }
            catch (Exception ex)
            {

            }
            return Json(new
            {
                Data = multianual


            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ValidaMensajeAseguradora(int id, int idAseguradora)
        {

            var cobertura = db.Cobertura.FirstOrDefault(d => d.Id == id);
            var mostrarMensaje = false;
            var mensaje = "";

            switch (idAseguradora)
            {
                case 3:
                    if (cobertura.Clave == "1")
                    {
                        mostrarMensaje = true;
                        mensaje = $"Asegurese de agregar la cobertura 25 -  Cap Daños Materiales";
                    }
                    if (cobertura.Clave == "2")
                    {
                        mostrarMensaje = true;
                        mensaje = $"Asegurese de agregar la cobertura 45 -  Cap Robo Total";
                    }
                    break;
            }

            return Json(new
            {
                MuestraMensaje = mostrarMensaje,
                Mensaje = mensaje


            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GuardarPeriodicidadMultianual(int idConvenio, int idCatPeriodicidadFormaPago, List<PeriodicidadMultianual> multianuales)
        {
            bool success = true;
            string message = "";

            try
            {


                var actuales = db.PeriodicidadMultianual.Where(a => a.IdConvenio == idConvenio && a.IdCatPeriodicidadFormaPago == idCatPeriodicidadFormaPago).ToList();

                if (actuales != null && actuales.Any())
                {
                    db.PeriodicidadMultianual.RemoveRange(actuales);
                    db.SaveChanges();
                }

                if (multianuales != null && multianuales.Any())
                {
                    db.PeriodicidadMultianual.AddRange(multianuales);
                    db.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);
        }

        public List<ConvenioMSI> GetConvenioMSI(int idConvenio, bool casaHabitacion)
        {
            var model = db.ConvenioMSI.Where(a => a.IdConvenio == idConvenio && a.CasaHabitacion == casaHabitacion).OrderBy(a => a.Inicio).ToList();
            var bancos = db.CatBanco.ToList();
            var meses = db.CatMesesSinIntereses.ToList();

            model.ForEach(a =>
            {
                if (db.ConfiguracionMSI.Where(x => x.IdConvenioMSI == a.Id).Any())
                {
                    a.Bancos = db.ConfiguracionMSI.Where(x => x.IdConvenioMSI == a.Id).ToList();

                    foreach (var banco in a.Bancos)
                    {
                        var _b = bancos.FirstOrDefault(y => y.Id == banco.IdBanco);

                        banco._Banco = _b.Abreviacion;
                        banco._BancoId = _b.BancoId;
                        banco._Meses = meses.FirstOrDefault(z => z.Id == banco.IdMSI).Descripcion;

                        if (banco.esDefault)
                            a.BancoDefault = banco;
                    }



                }
            });

            return model;
        }

        public FileResult LayoutCalendarioCobranza()
        {
            var path = $@"{System.Web.HttpContext.Current.Server.MapPath("~/Repositorio/Layouts/CalendarioCobranza.xlsx")}";
            byte[] archivo = null;

            archivo = System.IO.File.ReadAllBytes(path);

            return File(archivo, "application/octet-stream", "CalendarioCobranza.xlsx");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult UploadFileCalendarioCobranza(int idMedioPago, int idFormaPago, int idconvenio)
        {

            string message = "Datos Cargados exitosamente";
            bool complete = true;
            try
            {
                //  Get all files from Request object  
                HttpFileCollectionBase files = Request.Files;
                HttpPostedFileBase file = files[0];
                Stream stream = file.InputStream;

                // We return the interface, so that
                IExcelDataReader reader = null;


                if (file.FileName.EndsWith(".xls"))
                {
                    reader = ExcelReaderFactory.CreateBinaryReader(stream);
                }
                else if (file.FileName.EndsWith(".xlsx"))
                {
                    reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                }
                else
                {
                    complete = false;
                    message = "Archivo no valido";
                }
                if (complete)
                {
                    ExcelDataSetConfiguration conf = new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    };
                    DataSet result = reader.AsDataSet(conf);
                    reader.Close();

                    DataTable table = result.Tables[0];

                    if (table.Rows.Count > 0)
                    {
                        var convenio = db.Convenio.FirstOrDefault(a => a.Id == idconvenio);

                        var calendario = db.CalendarioCobranza.FirstOrDefault(a => a.IdConvenio == idconvenio && a.IdFormaPago == idFormaPago && a.IdMedioPago == idMedioPago);

                        if (calendario == null)
                        {
                            calendario = new LocktonModel.db.CalendarioCobranza();

                            calendario.IdEmpresa = convenio.IdEmpresa;
                            calendario.IdMedioPago = idMedioPago;
                            calendario.IdFormaPago = idFormaPago;
                            calendario.IdConvenio = idconvenio;
                            calendario.Fecha = DateTime.Now;
                            calendario.Usuario = User.Identity.Name;
                            calendario.IdUsuario = User.Identity.GetUserId();

                            db.CalendarioCobranza.Add(calendario);
                            db.SaveChanges();
                        }
                        else
                        {
                            calendario.Fecha = DateTime.Now;
                            db.SaveChanges();

                            var recibos = db.CalendarioCobranza_Recibo.Where(a => a.IdCalendario == calendario.Id).ToList();

                            if (recibos.Any())
                            {
                                db.CalendarioCobranza_Recibo.RemoveRange(recibos);
                                db.SaveChanges();
                            }
                        }


                        SubirExcelCalendarioCobro(table, calendario.Id);
                    }
                    else
                    {
                        complete = false;
                        message = "Archivo no valido";
                    }



                }
            }
            catch (Exception ex)
            {
                complete = false;
                message = "Ocurrió un error al tratar de procesar el archivo  " + ex.Message;
            }
            return Json(new
            {
                Message = message,
                Complete = complete
            }, JsonRequestBehavior.AllowGet);
        }


        public static void SubirExcelCalendarioCobro(DataTable excel, int id)
        {
            DataColumn _FK = new DataColumn("IdCalendario");
            _FK.DefaultValue = id;
            excel.Columns.Add(_FK);

            try
            {
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString()))
                {
                    connection.Open();

                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                    {
                        bulkCopy.BulkCopyTimeout = int.MaxValue;
                        bulkCopy.DestinationTableName = "dbo.CalendarioCobranza_Recibo";
                        bulkCopy.ColumnMappings.Add("IdCalendario", "IdCalendario");
                        bulkCopy.ColumnMappings.Add("No. Recibo", "NoRecibo");
                        bulkCopy.ColumnMappings.Add("Fecha de Cobro", "FechaCobro");
                        bulkCopy.ColumnMappings.Add("1er. Reintento", "FechaReintentoUno");
                        bulkCopy.ColumnMappings.Add("2do. Reintento", "FechaReintentoDos");
                        bulkCopy.ColumnMappings.Add("3er. Reintento", "FechaReintentoTres");

                        // Write from the source to the destination.
                        bulkCopy.WriteToServer(excel);
                    }


                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public ActionResult _MSI(int idConvenio, bool casaHabitacion)
        {
            var model = GetConvenioMSI(idConvenio, casaHabitacion);
            return PartialView(model);
        }

        [HttpPost]
        public ActionResult _MSI(string boletin, string inicio, string fin, bool indefinida, int idConvenio, bool casaHabitacion)
        {
            var model = new List<ConvenioMSI>();
            var path = "";
            var nombre = "";
            var exitoso = true;
            var mensaje = "";

            var _inicio = DateTime.Parse(inicio);
            var _fin = DateTime.Parse(fin);

            var actuales = db.ConvenioMSI.Where(a => a.IdConvenio == idConvenio).ToList();

            if (actuales.Any())
                actuales = actuales.Where(a => a._Estatus == "Activo").ToList();

            if (indefinida && actuales.Any())
            {
                exitoso = false;
                mensaje = "Ya existe una configuracion de Meses sin Intereses con Fecha Indefinida";
            }

            if (exitoso)
            {

                if (_inicio > _fin && !indefinida)
                {
                    exitoso = false;
                    mensaje = "La fecha de inicio no puede ser mayor a la fecha final";

                }

                if (exitoso)
                {
                    if (!indefinida)
                    {
                        //actuales = actuales.Where(a => a.Inicio >= _inicio && a.Fin <= _fin).ToList();
                        if (actuales.Exists(a => a.Inicio >= _inicio && a.Fin <= _fin))
                        {
                            exitoso = false;
                            mensaje = "Ya existe alguna configuracon de meses sin intereses en las fechas indicadas";
                        }

                        //actuales = actuales.Where(a => a.Inicio >= _inicio &&  _fin <= a.Fin).ToList();
                        if (actuales.Exists(a => a.Inicio >= _inicio && _fin <= a.Fin))
                        {
                            exitoso = false;
                            mensaje = "Ya existe alguna configuracon de meses sin intereses en las fechas indicadas";
                        }
                    }

                    if (exitoso)
                    {
                        if (Request.Files != null && Request.Files.Count > 0)
                        {
                            var filesPosted = Request.Files;
                            var files = new List<HttpPostedFileBase>();

                            for (var i = 0; i < Request.Files.Count; i++)
                                files.Add(filesPosted[i]);

                            var Ruta = System.Web.HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/Convenio/");
                            path = Path.Combine(Ruta, idConvenio.ToString(), "MSI");

                            Directory.CreateDirectory(path);

                            foreach (var file in files)
                            {
                                var guid = Guid.NewGuid().ToString();

                                nombre = file.FileName;
                                path = path + "\\" + guid + "_" + file.FileName;

                                file.SaveAs(path);

                            }
                        }

                        var _msi = new ConvenioMSI();

                        _msi.IdConvenio = idConvenio;
                        _msi.Boletin = boletin ?? "";
                        _msi.Nombre = nombre;
                        _msi.FichaTecnica = path;
                        _msi.Indefinida = indefinida;
                        _msi.Inicio = indefinida ? DateTime.Now : _inicio;
                        _msi.Fin = indefinida ? DateTime.Now : _fin;
                        _msi.CasaHabitacion = casaHabitacion;

                        db.ConvenioMSI.Add(_msi);
                        db.SaveChanges();

                    }
                }

            }

            ViewBag.ErrorMessage = mensaje;
            model = GetConvenioMSI(idConvenio, casaHabitacion);
            return PartialView(model);

        }

        [HttpPost]
        public ActionResult _MSIModificar(int id, string boletin, int idConvenio, bool casaHabitacion, string inicio, string fin, bool indefinida)
        {

            var path = "";
            var nombre = "";
            var exitoso = true;
            var cambioArchivo = false;
            var mensaje = "";
            DateTime _inicio;
            DateTime _fin;
            if (string.IsNullOrEmpty(inicio) || !DateTime.TryParse(inicio, out _inicio))
                _inicio = DateTime.Today;
            else
                _inicio = DateTime.Parse(inicio);


            if (string.IsNullOrEmpty(inicio) || !DateTime.TryParse(inicio, out _fin))
                _fin = DateTime.Today;
            else
                _fin = DateTime.Parse(fin);

            if (_inicio > _fin && !indefinida)
            {
                exitoso = false;
                mensaje = "La fecha de inicio no puede ser mayor a la fecha final";

            }

            if (Request.Files != null && Request.Files.Count > 0)
            {
                var filesPosted = Request.Files;
                var files = new List<HttpPostedFileBase>();

                for (var i = 0; i < Request.Files.Count; i++)
                    files.Add(filesPosted[i]);

                var Ruta = System.Web.HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/Convenio/");
                path = Path.Combine(Ruta, idConvenio.ToString(), "MSI");

                Directory.CreateDirectory(path);

                foreach (var file in files)
                {
                    var guid = Guid.NewGuid().ToString();

                    nombre = file.FileName;
                    path = path + "\\" + guid + "_" + file.FileName;

                    file.SaveAs(path);

                }
                cambioArchivo = true;
            }

            var _msi = db.ConvenioMSI.FirstOrDefault(a => a.Id == id);
            if (exitoso)
            {
                _msi.Boletin = boletin ?? "";
                _msi.Indefinida = indefinida;
                _msi.Inicio = indefinida ? DateTime.Now : _inicio;
                _msi.Fin = indefinida ? DateTime.Now : _fin;
                if (cambioArchivo)
                {
                    _msi.Nombre = nombre;
                    _msi.FichaTecnica = path;
                }

                db.SaveChanges();
            }

            ViewBag.ErrorMessage = mensaje;

            return RedirectToAction("_MSI", new { idConvenio, casaHabitacion });

        }

        public JsonResult InicializaBancosMSI(int idConvenio, int idAseguradora)
        {

            List<CatBancosAseguradoraExclusivo> bancosConvenio = new List<CatBancosAseguradoraExclusivo>();


            var bancosAseguradora = new SelectList((from aseg in db.Aseguradora
                                                    join bsas in db.CatBancosAseguradoras on aseg.Id equals bsas.IdAseguradora
                                                    join banco in db.CatBanco on bsas.IdBanco equals banco.Id
                                                    where bsas.Estatus.Equals(1) && aseg.Id == idAseguradora && aseg.Estatus.Equals(1)
                                                    orderby banco.Abreviacion
                                                    select banco).ToList(), "Id", "Abreviacion");

            var meses = new SelectList(db.CatMesesSinIntereses.OrderBy(a => a.Id), "Id", "Descripcion");
            return Json(new
            {
                Meses = meses,
                Bancos = bancosAseguradora

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult EliminarConfiguracionMSI(int id)
        {
            bool success = true;
            string message = "";

            try
            {

                var bancos = db.ConfiguracionMSI.Where(a => a.IdConvenioMSI == id).ToList();

                if (bancos.Any())
                {
                    db.ConfiguracionMSI.RemoveRange(bancos);
                    db.SaveChanges();
                }

                var configuracion = db.ConvenioMSI.FirstOrDefault(a => a.Id == id);

                db.ConvenioMSI.Remove(configuracion);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);
        }

        public FileResult DescargarFichaTecnica(int id)
        {
            var archivo = db.ConvenioMSI.FirstOrDefault(a => a.Id == id);
            byte[] bytes = null;

            try
            {

                bytes = System.IO.File.ReadAllBytes(archivo.FichaTecnica);

                return File(bytes, "application/octet-stream", archivo.Nombre);
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return File(new byte[0], "application/octet-stream", archivo.Nombre);
            }
        }

        public FileResult DescargarFichaTecnicaMascota(int id, bool EsAfinidad = false)
        {
            try
            {
                byte[] bytes = null;
                if (EsAfinidad)
                    bytes = System.IO.File.ReadAllBytes(Server.MapPath("~/img") + @"/Costco/seguro-costco-msi.png");
                else
                    bytes = System.IO.File.ReadAllBytes(Server.MapPath("~/img") + @"/MSI/seguro-msi.png");
                return File(bytes, "application/octet-stream", "Mascotas_MSI.png");
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return File(new byte[0], "application/octet-stream", "Mascotas_MSI.png");
            }
        }


        public FileResult DescargarFichaCoberturaComplementaria(int id)
        {
            var convenio = db.Convenio.FirstOrDefault(a => a.Id == id);
            var archivo = db.ArchivoEmpresa.FirstOrDefault(a => a.IdEmpresa == convenio.IdEmpresa && a.IdTipoDocumento == 2);

            try
            {
                byte[] bytes = null;

                bytes = System.IO.File.ReadAllBytes(archivo.Ruta);

                return File(bytes, "application/octet-stream", archivo.Nombre);
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return File(new byte[0], "application/octet-stream", archivo.Nombre);
            }
        }

        private void DesactivaMSIDefault(int idConvenioMSI)
        {
            var existente = db.ConfiguracionMSI.FirstOrDefault(a => a.IdConvenioMSI == idConvenioMSI && a.esDefault);

            if (existente != null)
            {
                existente.esDefault = false;

                db.SaveChanges();

            }
        }

        public JsonResult AgregarBancoMSI(int idConvenioMSI, int idBanco, int idMSI, string clave, string VIN, bool esDefault)
        {
            bool valid = false;
            string message = "";
            var id = 0;
            try
            {
                var exist = db.ConfiguracionMSI.FirstOrDefault(a => a.IdConvenioMSI == idConvenioMSI && a.IdBanco == idBanco && a.IdMSI == idMSI);
                if (exist == null)
                {
                    if (esDefault)
                        DesactivaMSIDefault(idConvenioMSI);

                    var banco = new ConfiguracionMSI();
                    banco.IdConvenioMSI = idConvenioMSI;
                    banco.IdBanco = idBanco;
                    banco.IdMSI = idMSI;
                    banco.Clave = clave;
                    banco.VIN = VIN;
                    banco.esDefault = esDefault;

                    db.ConfiguracionMSI.Add(banco);
                    db.SaveChanges();

                    id = banco.Id;

                    valid = true;
                    message = "Se agregó la opción";
                }
                else
                {
                    valid = false;
                    message = "La configuración ingresada ya existe registrada";
                }


            }
            catch (Exception ex)
            {
                message = ex.Message;
                valid = false;
            }
            return Json(new { IsValid = valid, Message = message, Id = id }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ActualizarBancoMSI(int id, string clave, string VIN, bool esDefault)
        {
            bool valid = false;
            string message = "";

            try
            {
                var banco = db.ConfiguracionMSI.FirstOrDefault(a => a.Id == id);
                if (banco != null)
                {
                    if (esDefault)
                        DesactivaMSIDefault(banco.IdConvenioMSI);

                    banco.Clave = clave;
                    banco.VIN = VIN;
                    banco.esDefault = esDefault;

                    db.SaveChanges();

                    valid = true;
                    message = "Se agregó la opción";
                }
                else
                {
                    valid = false;
                    message = "No se encontró la configuración";
                }


            }
            catch (Exception ex)
            {
                message = ex.Message;
                valid = false;
            }
            return Json(new { IsValid = valid, Message = message, Id = id }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult EliminarBancoMSI(int id)
        {
            bool success = true;
            string message = "";

            try
            {

                var banco = db.ConfiguracionMSI.First(a => a.Id == id);


                db.ConfiguracionMSI.Remove(banco);
                db.SaveChanges();


            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult EliminarCalendario(int idConvenio, int idFormaPago, int idMedioPago)
        {
            bool success = true;
            string message = "";

            try
            {

                var _calendario = db.CalendarioCobranza.FirstOrDefault(a => a.IdConvenio == idConvenio && a.IdFormaPago == idFormaPago && a.IdMedioPago == idMedioPago);

                if(_calendario!= null)
                {
                    var _recibos = db.CalendarioCobranza_Recibo.Where(a => a.IdCalendario == _calendario.Id).ToList();

                    db.CalendarioCobranza_Recibo.RemoveRange(_recibos);

                    db.SaveChanges();

                    db.CalendarioCobranza.Remove(_calendario);

                    db.SaveChanges();
                }

               

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Forma de pago
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult FormaPagoProducto(int IdEmpresa, int IdConvenio)
        {
            ConfiguracionEmpresa dbCfgEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            LocktonModel.db.ConvenioProductos ElConvenio = new LocktonModel.db.ConvenioProductos();
            if (IdConvenio > 0)
                ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == IdConvenio);
            else
                return HttpNotFound();

            ParametrosFormaPagoProducto(IdConvenio, dbCfgEmpresa.AplicaMultiAnual, ElConvenio.IdCatProducto);
            //carga info para checkbox
            ElConvenio.chkCatUsuarioSolicitaCancelacion = string.Join(",", db.UsuarioSolicitaCancelacionProducto.Where(x => x.IdConvenioProducto == IdConvenio && x.Estatus == 1 && x.IdCatProducto == ElConvenio.IdCatProducto).ToList().Select(y => y.IdCatUsuarioSolicitaCancelacion).ToList());
            ViewBag.ModalidadFormaPagoProducto = db.ModalidadFormaPagoProducto.Where(x => x.IdConvenio == IdConvenio).ToList();


            List<ListaCombo> polizasMaestras = db.ListaCombo.SqlQuery("sp_obtener_select_polizamaestra_core").ToList();
            polizasMaestras.Add(new ListaCombo() { Id = 0, Nombre = "Selecciona" });
            ViewBag.PolizasMaestra = new SelectList(polizasMaestras, "Id", "Nombre");

            ElConvenio.MSI = GetConvenioMSI(IdConvenio, true);

            return View(ElConvenio);
        }

        /// <summary>
        /// Forma de pago
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult FormaPagoGuarda(VFormaDePago Captura)
        {
            if (Captura is null)
                return HttpNotFound();
            LocktonModel.db.Convenio ElConvenio = new LocktonModel.db.Convenio();
            try
            {
                ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == Captura.IdConvenio);
                ElConvenio.IdCatSolicitaCancelacion = Captura.IdCatSolicitaCancelacion;
                ElConvenio.CargoEnLinea = Captura.CargaEnLínea;
                ElConvenio.RequireReimRecibos = Captura.RequireReimRecibos;
                ElConvenio.RequireReimCertificadoInd = Captura.RequireReimCertificadoInd;
                ElConvenio.Domiciliacion = Captura.Domiciliacion;
                ElConvenio.DatosBancariosEnrollment = Captura.DatosBancariosEnrollment;

                //CAT: Guarda la nueva bandera fuera de Convenio y solamente para la aseguradora GNP.
                if (ElConvenio.IdAseguradora == 2)
                    GuardaConfiguracionDomiciliacionGNP(Captura.IdConvenio, Captura.AplicaDomiciliacionPostEmision);

                db.Entry(ElConvenio).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, Captura)), $"{Captura.GetType()}");
                //guarda los grupos de checkBox
                GuardaPeriodicidadFormaPago(Captura.IdConvenio, Captura.FormaDePagoPeriodicidad);

                //usuario que puede solicitar la cancelacion
                GuardaUsuarioSolicitaCancelacion(Captura.IdConvenio, Captura.chkCatUsuarioSolicitaCancelacion);
            }
            catch (Exception ex)
            {
                Console.WriteLine("FormaPagoGuarda" + ex.Message);
                return RedirectToAction("FormaPago", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.IdConvenio });
            }

            return Json(Url.Action("DatosAdicionales", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.IdConvenio }));
        }

        //CAT: Realiza el alta o actualizacion de una sola configuracion de domiciliacion por convenio GNP.
        private void GuardaConfiguracionDomiciliacionGNP(int idConvenio, bool aplicaDomiciliacionPostEmision)
        {
            ConfiguracionDomiciliacionGNP configuracion = db.ConfiguracionDomiciliacionGNP.FirstOrDefault(x => x.IdConvenio == idConvenio);
            string idUsuario = User.Identity.GetUserId();

            if (configuracion == null)
            {
                if (!aplicaDomiciliacionPostEmision)
                    return;

                configuracion = new ConfiguracionDomiciliacionGNP
                {
                    IdConvenio = idConvenio,
                    AplicaDomiciliacionPostEmision = true,
                    FechaCreacion = DateTime.Now,
                    IdUsuarioCreacion = idUsuario
                };

                db.ConfiguracionDomiciliacionGNP.Add(configuracion);
                return;
            }

            configuracion.AplicaDomiciliacionPostEmision = aplicaDomiciliacionPostEmision;
            configuracion.FechaModificacion = DateTime.Now;
            configuracion.IdUsuarioModificacion = idUsuario;
            db.Entry(configuracion).State = EntityState.Modified;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult FormaPagoGuardaProducto(VFormaDePagoProducuto Captura)
        {
            if (Captura is null)
                return HttpNotFound();
            LocktonModel.db.ConvenioProductos ElConvenio = new LocktonModel.db.ConvenioProductos();
            try
            {
                ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == Captura.IdConvenioProducto);
                ElConvenio.IdCatSolicitaCancelacion = Captura.IdCatSolicitaCancelacion;
                ElConvenio.CargoEnLinea = Captura.CargaEnLínea;

                ElConvenio.Mit_id_company = Captura.Mit_id_company;
                ElConvenio.Mit_id_branch = Captura.Mit_id_branch;
                ElConvenio.Mit_user = Captura.Mit_user;
                ElConvenio.Mit_pwd = Captura.Mit_pwd;
                ElConvenio.Mit_user_online = Captura.Mit_user_online;
                ElConvenio.Mit_pwd_online = Captura.Mit_pwd_online;
                ElConvenio.Mit_Key = Captura.Mit_Key;
                ElConvenio.Mit_Data0 = Captura.Mit_Data0;
                ElConvenio.DatosBancariosEnrollment = Captura.DatosBancariosEnrollment;

                db.Entry(ElConvenio).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, ElConvenio)), $"{ElConvenio.GetType()}");
                //guarda los grupos de checkBox
                GuardaPeriodicidadFormaPagoProducto(Captura.IdConvenioProducto, Captura.FormaDePagoPeriodicidad, ElConvenio.IdCatProducto);

                //usuario que puede solicitar la cancelacion
                GuardaUsuarioSolicitaCancelacionProducto(Captura.IdConvenioProducto, Captura.chkCatUsuarioSolicitaCancelacion);
            }
            catch (Exception ex)
            {
                Console.WriteLine("FormaPagoGuarda" + ex.Message);
                return RedirectToAction("FormaPago", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.IdConvenioProducto });
            }

            return Json(Url.Action("DatosAdicionalesProductos", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.IdConvenioProducto, IdCatProducto = ElConvenio.IdCatProducto }));
        }

        private void ParametrosFormaPago(int IdConvenio, bool multianual)
        {
            if (IdConvenio > 0)
                ViewBag.ListaPeriodicidadFormaPago = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == IdConvenio && x.Estatus == 1).ToList();
            ViewBag.chkCatPeriodicidadFormaPago = db.CatPeriodicidadFormaPago.Where(x => x.Estatus == 1 && x.MultiAnual == multianual).ToList();
            ViewBag.RadioCatSolicitaCancelacion = db.CatSolicitaCancelacion.Where(x => x.Estatus == 1).ToList();
            ViewBag.ListaSolicitaCancelacionPoliza = db.CatUsuarioSolicitaCancelacion.Where(x => x.Estatus == 1).ToList();
            ViewBag.ListaCatModalidadFormaPago = db.CatModalidadFormaPago.Where(x => x.Estatus == 1).ToList();

            ViewBag.ListaCatPeriodicidadMultianual = db.CatPeriodicidadMultianual.Where(x => x.Estatus == 1).ToList();

        }

        private void ParametrosFormaPagoProducto(int IdConvenio, bool multianual, int IdCatProducto)
        {
            if (IdConvenio > 0)
                ViewBag.ListaPeriodicidadFormaPago = db.PeriodicidadFormaPagoProducto.Where(x => x.IdConvenioProducto == IdConvenio &&
                                                                                            x.IdCatProducto == IdCatProducto &&
                                                                                            x.Estatus == 1).ToList();

            ViewBag.chkCatPeriodicidadFormaPago = db.CatPeriodicidadFormaPagoProducto.Where(x => x.Estatus == 1 &&
                                                                                            x.MultiAnual == multianual &&
                                                                                            x.IdCatProducto == IdCatProducto).ToList();

            ViewBag.RadioCatSolicitaCancelacion = db.CatSolicitaCancelacion.Where(x => x.Estatus == 1).ToList();
            ViewBag.ListaSolicitaCancelacionPoliza = db.CatUsuarioSolicitaCancelacion.Where(x => x.Estatus == 1).ToList();
            ViewBag.ListaCatModalidadFormaPago = db.CatModalidadFormaPagoProducto.Where(x => x.Estatus == 1 && x.IdCatProducto == IdCatProducto).ToList();


        }

        private void GuardaRegistroUsuarioSolicitaCancelacion(int IdConvenio, int IdCatUsuarioSolicitaCancelacion)
        {
            UsuarioSolicitaCancelacion gUsuarioSolicitaCancelacion = new UsuarioSolicitaCancelacion();
            gUsuarioSolicitaCancelacion.IdConvenio = IdConvenio;
            gUsuarioSolicitaCancelacion.IdCatUsuarioSolicitaCancelacion = IdCatUsuarioSolicitaCancelacion;
            gUsuarioSolicitaCancelacion.Estatus = 1;
            db.UsuarioSolicitaCancelacion.Add(gUsuarioSolicitaCancelacion);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, gUsuarioSolicitaCancelacion)), $"{gUsuarioSolicitaCancelacion.GetType()}");
        }

        private void GuardaRegistroUsuarioSolicitaCancelacionProducto(int IdConvenio, int IdCatUsuarioSolicitaCancelacion)
        {

            UsuarioSolicitaCancelacion gUsuarioSolicitaCancelacion = new UsuarioSolicitaCancelacion();
            gUsuarioSolicitaCancelacion.IdConvenio = IdConvenio;
            gUsuarioSolicitaCancelacion.IdCatUsuarioSolicitaCancelacion = IdCatUsuarioSolicitaCancelacion;
            gUsuarioSolicitaCancelacion.Estatus = 1;
            db.UsuarioSolicitaCancelacion.Add(gUsuarioSolicitaCancelacion);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, gUsuarioSolicitaCancelacion)), $"{gUsuarioSolicitaCancelacion.GetType()}");
        }

        private void ActualizaRegistroUsuarioSolicitaCancelacion(UsuarioSolicitaCancelacion DatoUsuarioSolicitaCancelacion, int Estatus)
        {
            DatoUsuarioSolicitaCancelacion.Estatus = Estatus;
            db.Entry(DatoUsuarioSolicitaCancelacion).State = EntityState.Modified;
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, DatoUsuarioSolicitaCancelacion)), $"{DatoUsuarioSolicitaCancelacion.GetType()}");
        }

        private void ActualizaRegistroUsuarioSolicitaCancelacionProducto(UsuarioSolicitaCancelacionProducto DatoUsuarioSolicitaCancelacion, int Estatus)
        {
            DatoUsuarioSolicitaCancelacion.Estatus = Estatus;
            db.Entry(DatoUsuarioSolicitaCancelacion).State = EntityState.Modified;
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, DatoUsuarioSolicitaCancelacion)), $"{DatoUsuarioSolicitaCancelacion.GetType()}");
        }

        private void GuardaUsuarioSolicitaCancelacion(int IdConvenio, string ChkLista)
        {
            List<int> listaIdChks = ListaChecks(ChkLista);
            List<int> Encontrados = new List<int>();
            //buscamos si existen datos ya guardado
            List<UsuarioSolicitaCancelacion> ListaDatos = new List<UsuarioSolicitaCancelacion>();
            ListaDatos = db.UsuarioSolicitaCancelacion.Where(busca => busca.IdConvenio == IdConvenio).ToList();
            if (ListaDatos.Count > 0)
            {//guarda nuevos y actualiza
             //los nuevos datos
                listaIdChks.ForEach(IdChk =>
                {
                    if (ListaDatos.Exists(busca => busca.IdCatUsuarioSolicitaCancelacion == IdChk))
                    {//marcar como encontrado
                        Encontrados.Add(IdChk);
                    }
                    else
                    {//agregar
                        GuardaRegistroUsuarioSolicitaCancelacion(IdConvenio, IdChk);
                    }
                });
                //Revisar los que ya se encontraban guardados
                ListaDatos.ForEach(dato =>
                {
                    if (Encontrados.Exists(y => y == dato.IdCatUsuarioSolicitaCancelacion))
                    {//verifica si no esta activo, activarlo
                        if (dato.Estatus != 1)
                        {
                            ActualizaRegistroUsuarioSolicitaCancelacion(dato, 1);
                        }
                    }
                    else//si no esta en la lista nueva, desactivarlo
                    {
                        ActualizaRegistroUsuarioSolicitaCancelacion(dato, 2);
                    }
                });
            }
            else
            {//guarda nuevos
                listaIdChks.ForEach(IdChk =>
                {
                    GuardaRegistroUsuarioSolicitaCancelacion(IdConvenio, IdChk);
                });
            }
        }
        private void GuardaUsuarioSolicitaCancelacionProducto(int IdConvenio, string ChkLista)
        {
            List<int> listaIdChks = ListaChecks(ChkLista);
            List<int> Encontrados = new List<int>();
            //buscamos si existen datos ya guardado
            List<UsuarioSolicitaCancelacionProducto> ListaDatos = new List<UsuarioSolicitaCancelacionProducto>();
            ListaDatos = db.UsuarioSolicitaCancelacionProducto.Where(busca => busca.IdConvenioProducto == IdConvenio).ToList();
            if (ListaDatos.Count > 0)
            {//guarda nuevos y actualiza
             //los nuevos datos
                listaIdChks.ForEach(IdChk =>
                {
                    if (ListaDatos.Exists(busca => busca.IdCatUsuarioSolicitaCancelacion == IdChk))
                    {//marcar como encontrado
                        Encontrados.Add(IdChk);
                    }
                    else
                    {//agregar
                        GuardaRegistroUsuarioSolicitaCancelacion(IdConvenio, IdChk);
                    }
                });
                //Revisar los que ya se encontraban guardados
                ListaDatos.ForEach(dato =>
                {
                    if (Encontrados.Exists(y => y == dato.IdCatUsuarioSolicitaCancelacion))
                    {//verifica si no esta activo, activarlo
                        if (dato.Estatus != 1)
                        {
                            ActualizaRegistroUsuarioSolicitaCancelacionProducto(dato, 1);
                        }
                    }
                    else//si no esta en la lista nueva, desactivarlo
                    {
                        ActualizaRegistroUsuarioSolicitaCancelacionProducto(dato, 2);
                    }
                });
            }
            else
            {//guarda nuevos
                listaIdChks.ForEach(IdChk =>
                {
                    GuardaRegistroUsuarioSolicitaCancelacion(IdConvenio, IdChk);
                });
            }
        }

        private void GuardaRegistroPeriodicidadFormaPago(int IdConvenio, VFormaDePagoPeriodicidad registro, int idaseguradora)
        {
            PeriodicidadFormaPago gPeriodicidadFormaPago = new PeriodicidadFormaPago();
            gPeriodicidadFormaPago.IdConvenio = IdConvenio;
            gPeriodicidadFormaPago.IdCatPeriodicidadFormaPago = registro.IdCatPeriodicidadFormaPago;
            gPeriodicidadFormaPago.FormaPago = registro.FormaPago;
            gPeriodicidadFormaPago.FormaPagoCobranza = registro.FormaPagoCobranza;
            gPeriodicidadFormaPago.RecargoPagoFraccionado = registro.RecargoPagoFraccionado;
            gPeriodicidadFormaPago.PolizaNegocioOpera = registro.PolizaNegocioOpera;
            gPeriodicidadFormaPago.ClaveAgente = registro.ClaveAgente;
            gPeriodicidadFormaPago.PrimerReciboPdf = registro.PrimerReciboPdf;
            gPeriodicidadFormaPago.Estatus = 1;
            if (registro.IdPolizaMaestra > 0)
                gPeriodicidadFormaPago.IdPolizaMaestra = registro.IdPolizaMaestra;

            db.PeriodicidadFormaPago.Add(gPeriodicidadFormaPago);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, gPeriodicidadFormaPago)), $"{gPeriodicidadFormaPago.GetType()}");
            //guarda la modalidad forma de pago
            GuardaModalidadFormaPago(IdConvenio, gPeriodicidadFormaPago.IdCatPeriodicidad, registro.IdCatPeriodicidadFormaPago, registro.ModalidadFormaPago, idaseguradora, registro.ModalidadFormaPagoAdmin, registro.ModalidadFormaPagoBajas);
        }

        private void GuardaRegistroPeriodicidadFormaPagoProducto(int IdConvenio, VFormaDePagoPeriodicidadProducto registro, int idaseguradora, int IdProducto)
        {
            var ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == IdConvenio);

            PeriodicidadFormaPagoProducto gPeriodicidadFormaPago = new PeriodicidadFormaPagoProducto();
            gPeriodicidadFormaPago.IdConvenioProducto = IdConvenio;
            gPeriodicidadFormaPago.IdCatPeriodicidadFormaPagoProducto = registro.IdCatPeriodicidadFormaPagoProducto;
            gPeriodicidadFormaPago.FormaPago = registro.FormaPago;
            gPeriodicidadFormaPago.FormaPagoCobranza = registro.FormaPagoCobranza;
            gPeriodicidadFormaPago.RecargoPagoFraccionado = registro.RecargoPagoFraccionado;
            gPeriodicidadFormaPago.PolizaNegocioOpera = registro.PolizaNegocioOpera;
            gPeriodicidadFormaPago.ClaveAgente = registro.ClaveAgente;
            gPeriodicidadFormaPago.PrimerReciboPdf = registro.PrimerReciboPdf;
            gPeriodicidadFormaPago.Estatus = 1;
            gPeriodicidadFormaPago.IdCatProducto = ElConvenio.IdCatProducto;
            if (registro.IdPolizaMaestra > 0)
                gPeriodicidadFormaPago.IdPolizaMaestra = registro.IdPolizaMaestra;

            db.PeriodicidadFormaPagoProducto.Add(gPeriodicidadFormaPago);
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, gPeriodicidadFormaPago)), $"{gPeriodicidadFormaPago.GetType()}");

            //guarda la modalidad forma de pago
            GuardaModalidadFormaPago_Producto(IdConvenio, gPeriodicidadFormaPago.IdCatPeriodicidad, registro.IdCatPeriodicidadFormaPagoProducto, registro.ModalidadFormaPago, idaseguradora, registro.ModalidadFormaPagoAdmin, IdProducto);
        }

        private void ActualizaRegistroPeriodicidadFormaPago(PeriodicidadFormaPago gPeriodicidadFormaPago, VFormaDePagoPeriodicidad registro, int idaseguradora)
        {
            gPeriodicidadFormaPago.IdCatPeriodicidadFormaPago = registro.IdCatPeriodicidadFormaPago;
            gPeriodicidadFormaPago.FormaPago = registro.FormaPago;
            gPeriodicidadFormaPago.FormaPagoCobranza = registro.FormaPagoCobranza;
            gPeriodicidadFormaPago.RecargoPagoFraccionado = registro.RecargoPagoFraccionado;
            gPeriodicidadFormaPago.PolizaNegocioOpera = registro.PolizaNegocioOpera;
            gPeriodicidadFormaPago.ClaveAgente = registro.ClaveAgente;
            gPeriodicidadFormaPago.PrimerReciboPdf = registro.PrimerReciboPdf;
            gPeriodicidadFormaPago.Estatus = 1;
            if (registro.IdPolizaMaestra > 0)
                gPeriodicidadFormaPago.IdPolizaMaestra = registro.IdPolizaMaestra;
            else if (gPeriodicidadFormaPago.IdPolizaMaestra.HasValue)
                gPeriodicidadFormaPago.IdPolizaMaestra = null;
            gPeriodicidadFormaPago.Sucursal = registro.Sucursal;
            gPeriodicidadFormaPago.Producto = registro.Producto;
            gPeriodicidadFormaPago.NumeroPolizaMaestra = registro.NumeroPolizaMaestra;
            db.Entry(gPeriodicidadFormaPago).State = EntityState.Modified;
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, gPeriodicidadFormaPago)), $"{gPeriodicidadFormaPago.GetType()}");

            //guarda la modalidad forma de pago
            GuardaModalidadFormaPago(gPeriodicidadFormaPago.IdConvenio, gPeriodicidadFormaPago.IdCatPeriodicidad, registro.IdCatPeriodicidadFormaPago, registro.ModalidadFormaPago, idaseguradora, registro.ModalidadFormaPagoAdmin, registro.ModalidadFormaPagoBajas);
        }

        private void ActualizaRegistroPeriodicidadFormaPagoProducto(PeriodicidadFormaPagoProducto gPeriodicidadFormaPago, VFormaDePagoPeriodicidadProducto registro, int idaseguradora, int IdProducto)
        {

            gPeriodicidadFormaPago.IdCatPeriodicidadFormaPagoProducto = registro.IdCatPeriodicidadFormaPagoProducto;
            gPeriodicidadFormaPago.FormaPago = registro.FormaPago;
            gPeriodicidadFormaPago.FormaPagoCobranza = registro.FormaPagoCobranza;
            gPeriodicidadFormaPago.RecargoPagoFraccionado = registro.RecargoPagoFraccionado;
            gPeriodicidadFormaPago.PolizaNegocioOpera = registro.PolizaNegocioOpera;
            gPeriodicidadFormaPago.ClaveAgente = registro.ClaveAgente;
            gPeriodicidadFormaPago.PrimerReciboPdf = registro.PrimerReciboPdf;
            gPeriodicidadFormaPago.Estatus = 1;
            if (registro.IdPolizaMaestra > 0)
                gPeriodicidadFormaPago.IdPolizaMaestra = registro.IdPolizaMaestra;
            else if (gPeriodicidadFormaPago.IdPolizaMaestra.HasValue)
                gPeriodicidadFormaPago.IdPolizaMaestra = null;
            gPeriodicidadFormaPago.Sucursal = registro.Sucursal;
            gPeriodicidadFormaPago.Producto = registro.Producto;
            gPeriodicidadFormaPago.NumeroPolizaMaestra = registro.NumeroPolizaMaestra;
            db.Entry(gPeriodicidadFormaPago).State = EntityState.Modified;
            db.SaveChanges();

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, gPeriodicidadFormaPago)), $"{gPeriodicidadFormaPago.GetType()}");
            //guarda la modalidad forma de pago
            GuardaModalidadFormaPago_Producto(gPeriodicidadFormaPago.IdConvenioProducto, gPeriodicidadFormaPago.IdCatPeriodicidad, registro.IdCatPeriodicidadFormaPagoProducto, registro.ModalidadFormaPago, idaseguradora, registro.ModalidadFormaPagoAdmin, IdProducto);
        }

        private void GuardaPeriodicidadFormaPago(int IdConvenio, List<VFormaDePagoPeriodicidad> FormaDePagoPeriodicidad)
        {
            List<int> Encontrados = new List<int>();
            //buscamos si existen datos ya guardado
            List<PeriodicidadFormaPago> ListaDatos = new List<PeriodicidadFormaPago>();
            List<PeriodicidadFormaPago> Posted = new List<PeriodicidadFormaPago>();

            ListaDatos = db.PeriodicidadFormaPago.Where(busca => busca.IdConvenio == IdConvenio).ToList();
            var convenio = db.Convenio.Where(x => x.Id == IdConvenio).FirstOrDefault();
            foreach (VFormaDePagoPeriodicidad item in FormaDePagoPeriodicidad)
            {
                PeriodicidadFormaPago inDB = ListaDatos.Find(x => x.IdCatPeriodicidadFormaPago == item.IdCatPeriodicidadFormaPago);
                if (inDB != null)
                {
                    Posted.Add(inDB);
                }
            }
            if (ListaDatos.Count > 0)
            {//guarda nuevos y actualiza
             //los nuevos datos
                FormaDePagoPeriodicidad.ForEach(Registro =>
                {
                    if (ListaDatos.Exists(busca => busca.IdCatPeriodicidadFormaPago == Registro.IdCatPeriodicidadFormaPago))
                    {//marcar como encontrado
                        ActualizaRegistroPeriodicidadFormaPago(ListaDatos.Find(x => x.IdCatPeriodicidadFormaPago == Registro.IdCatPeriodicidadFormaPago), Registro, convenio.IdAseguradora);
                    }
                    else
                    {//agregar
                        GuardaRegistroPeriodicidadFormaPago(IdConvenio, Registro, convenio.IdAseguradora);
                    }
                });
                //elimina
                IEnumerable<PeriodicidadFormaPago> toDelete = ListaDatos.Except(Posted);
                if (toDelete != null && toDelete.Any())
                {
                    db.PeriodicidadFormaPago.RemoveRange(toDelete);
                    db.SaveChanges();
                }
            }
            else
            {//guarda nuevos
                FormaDePagoPeriodicidad.ForEach(registro =>
                {
                    GuardaRegistroPeriodicidadFormaPago(IdConvenio, registro, convenio.IdAseguradora);
                });
            }
        }

        private void GuardaPeriodicidadFormaPagoProducto(int IdConvenio, List<VFormaDePagoPeriodicidadProducto> FormaDePagoPeriodicidad, int IdProducto)
        {
            List<int> Encontrados = new List<int>();
            //buscamos si existen datos ya guardado
            List<PeriodicidadFormaPagoProducto> ListaDatos = new List<PeriodicidadFormaPagoProducto>();
            List<PeriodicidadFormaPagoProducto> Posted = new List<PeriodicidadFormaPagoProducto>();

            ListaDatos = db.PeriodicidadFormaPagoProducto.Where(busca => busca.IdConvenioProducto == IdConvenio).ToList();
            var convenio = db.ConvenioProductos.Where(x => x.Id == IdConvenio).FirstOrDefault();
            foreach (VFormaDePagoPeriodicidadProducto item in FormaDePagoPeriodicidad)
            {
                PeriodicidadFormaPagoProducto inDB = ListaDatos.Find(x => x.IdCatPeriodicidadFormaPagoProducto == item.IdCatPeriodicidadFormaPagoProducto);
                if (inDB != null)
                {
                    Posted.Add(inDB);
                }
            }
            if (ListaDatos.Count > 0)
            {//guarda nuevos y actualiza
             //los nuevos datos
                FormaDePagoPeriodicidad.ForEach(Registro =>
                {
                    if (ListaDatos.Exists(busca => busca.IdCatPeriodicidadFormaPagoProducto == Registro.IdCatPeriodicidadFormaPagoProducto))
                    {//marcar como encontrado
                        ActualizaRegistroPeriodicidadFormaPagoProducto(ListaDatos.Find(x => x.IdCatPeriodicidadFormaPagoProducto == Registro.IdCatPeriodicidadFormaPagoProducto), Registro, convenio.IdAseguradoraProducto, IdProducto);
                    }
                    else
                    {//agregar
                        GuardaRegistroPeriodicidadFormaPagoProducto(IdConvenio, Registro, convenio.IdAseguradoraProducto, IdProducto);
                    }
                });
                //elimina
                IEnumerable<PeriodicidadFormaPagoProducto> toDelete = ListaDatos.Except(Posted);
                if (toDelete != null && toDelete.Any())
                {
                    db.PeriodicidadFormaPagoProducto.RemoveRange(toDelete);
                    db.SaveChanges();

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, toDelete)), $"{toDelete.GetType()}");
                }
            }
            else
            {//guarda nuevos
                FormaDePagoPeriodicidad.ForEach(registro =>
                {
                    GuardaRegistroPeriodicidadFormaPagoProducto(IdConvenio, registro, convenio.IdAseguradoraProducto, IdProducto);
                });
            }
        }

        private void GuardaModalidadFormaPagoProducto(int IdConvenio, int IdCatPeriodicidad, int IdCatPeriodicidadFormaPago, string ModalidadFormaPago, int idaseguradora, string ModalidadFormaPagoAdmin, int idProducto)
        {//para prueba
            List<ModalidadFormaPagoProducto> registros = db.ModalidadFormaPagoProducto.Where(reg => reg.IdConvenio == IdConvenio && reg.IdCatPeriodicidad == IdCatPeriodicidad && reg.IdCatPeriodicidadFormaPago == IdCatPeriodicidadFormaPago).ToList();
            if (registros.Count > 0)
            {// borra lo previo
                registros.ForEach(x =>
                {
                    db.ModalidadFormaPagoProducto.Remove(x);
                    db.SaveChanges();
                });
            }
            if (!string.IsNullOrEmpty(ModalidadFormaPago))
            {// guarda lo nuevo
                string[] idsFormaPago = ModalidadFormaPago.Split(',');
                string[] idsFormaPagoAdmin = null;
                if (!string.IsNullOrEmpty(ModalidadFormaPagoAdmin))
                    idsFormaPagoAdmin = ModalidadFormaPagoAdmin.Split(',');
                ModalidadFormaPagoProducto reg = new ModalidadFormaPagoProducto();
                foreach (string idFormaPago in idsFormaPago)
                {
                    var modadlidad = idFormaPago.Split('/');
                    reg = new ModalidadFormaPagoProducto
                    {
                        IdConvenio = IdConvenio,
                        IdCatPeriodicidad = IdCatPeriodicidad,
                        IdCatPeriodicidadFormaPago = IdCatPeriodicidadFormaPago,
                        IdCatModalidadFormaPago = int.Parse(modadlidad[0]),
                        Estatus = 1,
                        ClaveAgenteModalidadFormaPago = modadlidad[1],
                        CaratulaOperaModalidadFromaPago = modadlidad[2],
                        EntrarOPL = Convert.ToBoolean(modadlidad[3]),
                        SoloAdministrador = idsFormaPagoAdmin != null && idsFormaPagoAdmin.Contains(modadlidad[0]),
                        IdCatProducto = idProducto
                    };
                }
                db.ModalidadFormaPagoProducto.Add(reg);
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, reg)), $"{reg.GetType()}");
            }
        }

        private void GuardaModalidadFormaPago(int IdConvenio
            , int IdCatPeriodicidad
            , int IdCatPeriodicidadFormaPago
            , string ModalidadFormaPago
            , int idaseguradora
            , string ModalidadFormaPagoAdmin
            , string ModalidadFormaPagoBajas
           )
        {//para prueba
            List<ModalidadFormaPago> registros = db.ModalidadFormaPago.Where(reg => reg.IdConvenio == IdConvenio && reg.IdCatPeriodicidad == IdCatPeriodicidad && reg.IdCatPeriodicidadFormaPago == IdCatPeriodicidadFormaPago).ToList();
            if (registros.Count > 0)
            {// borra lo previo
                registros.ForEach(x =>
                {
                    db.ModalidadFormaPago.Remove(x);
                    db.SaveChanges();
                });
            }
            if (!string.IsNullOrEmpty(ModalidadFormaPago))
            {// guarda lo nuevo
                string[] idsFormaPago = ModalidadFormaPago.Split(',');
                string[] idsFormaPagoAdmin = null;
                string[] idsFormaPagoBajas = null;
                if (!string.IsNullOrEmpty(ModalidadFormaPagoAdmin))
                    idsFormaPagoAdmin = ModalidadFormaPagoAdmin.Split(',');
                if (!string.IsNullOrEmpty(ModalidadFormaPagoBajas))
                    idsFormaPagoBajas = ModalidadFormaPagoBajas.Split(',');
                ModalidadFormaPago reg = new ModalidadFormaPago();
                foreach (string idFormaPago in idsFormaPago)
                {
                    var modadlidad = idFormaPago.Split('/');
                    var _idCatModalidad = int.Parse(modadlidad[0]);

                    if (idaseguradora == 1 || idaseguradora == 27)
                    {

                        reg = new ModalidadFormaPago
                        {
                            IdConvenio = IdConvenio
                            ,
                            IdCatPeriodicidad = IdCatPeriodicidad
                            ,
                            IdCatPeriodicidadFormaPago = IdCatPeriodicidadFormaPago
                            ,
                            IdCatModalidadFormaPago = _idCatModalidad
                            ,
                            Estatus = 1
                            ,
                            ClaveAgenteModalidadFormaPago = modadlidad[1]
                            ,
                            CaratulaOperaModalidadFromaPago = modadlidad[2]
                            ,
                            EntrarOPL = Convert.ToBoolean(modadlidad[3])
                            ,
                            SoloAdministrador = idsFormaPagoAdmin != null && idsFormaPagoAdmin.Contains(modadlidad[0])
                            ,
                            BajaAutomatica = idsFormaPagoBajas != null && idsFormaPagoBajas.Contains(modadlidad[0])
                             ,
                            RequiereAprobacion = Convert.ToBoolean(modadlidad[4])
                            ,
                            Autorizadores = modadlidad[5]
                            ,
                            Facturable = Convert.ToBoolean(modadlidad[6])
                            ,
                            SinDatosBancarios = Convert.ToBoolean(modadlidad[7])
                            ,
                            ImprimirRecibos = false

                        };
                    }
                    else
                    {

                        reg = new ModalidadFormaPago
                        {
                            IdConvenio = IdConvenio
                            ,
                            IdCatPeriodicidad = IdCatPeriodicidad
                            ,
                            IdCatPeriodicidadFormaPago = IdCatPeriodicidadFormaPago
                            ,
                            IdCatModalidadFormaPago = _idCatModalidad
                            ,
                            Estatus = 1
                            ,
                            ClaveAgenteModalidadFormaPago = null
                            ,
                            CaratulaOperaModalidadFromaPago = null
                            ,
                            EntrarOPL = false
                            ,
                            SoloAdministrador = idsFormaPagoAdmin != null && idsFormaPagoAdmin.Contains(modadlidad[0])
                              ,
                            BajaAutomatica = idsFormaPagoBajas != null && idsFormaPagoBajas.Contains(modadlidad[0])
                            ,
                            Autorizadores = modadlidad[2]
                            ,
                            RequiereAprobacion = Convert.ToBoolean(modadlidad[1])
                            ,
                            Facturable = Convert.ToBoolean(modadlidad[3])
                            ,
                            SinDatosBancarios = Convert.ToBoolean(modadlidad[4])
                             ,
                            ImprimirRecibos = Convert.ToBoolean(modadlidad[5])
                        };
                    }
                    db.ModalidadFormaPago.Add(reg);
                    db.SaveChanges();

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, reg)), $"{reg.GetType()}");
                }
            }


        }

        private void GuardaModalidadFormaPago_Producto(int IdConvenio,
                                                        int IdCatPeriodicidad,
                                                        int IdCatPeriodicidadFormaPago,
                                                        string ModalidadFormaPago,
                                                        int idaseguradora,
                                                        string ModalidadFormaPagoAdmin,
                                                        int CatProducto)
        {//para prueba
            List<ModalidadFormaPagoProducto> registros = db.ModalidadFormaPagoProducto.Where(reg => reg.IdConvenio == IdConvenio
                                                                                && reg.IdCatPeriodicidad == IdCatPeriodicidad
                                                                                && reg.IdCatPeriodicidadFormaPago == IdCatPeriodicidadFormaPago).ToList();
            if (registros.Count > 0)
            {// borra lo previo
                registros.ForEach(x =>
                {
                    db.ModalidadFormaPagoProducto.Remove(x);
                    db.SaveChanges();
                });
            }
            if (!string.IsNullOrEmpty(ModalidadFormaPago))
            {// guarda lo nuevo
                string[] idsFormaPago = ModalidadFormaPago.Split(',');
                string[] idsFormaPagoAdmin = null;
                if (!string.IsNullOrEmpty(ModalidadFormaPagoAdmin))
                    idsFormaPagoAdmin = ModalidadFormaPagoAdmin.Split(',');
                ModalidadFormaPagoProducto reg = new ModalidadFormaPagoProducto();
                foreach (string idFormaPago in idsFormaPago)
                {
                    if (idaseguradora == 1)
                    {
                        var modadlidad = idFormaPago.Split('/');
                        reg = new ModalidadFormaPagoProducto
                        {
                            IdConvenio = IdConvenio
                            ,
                            IdCatPeriodicidad = IdCatPeriodicidad
                            ,
                            IdCatPeriodicidadFormaPago = IdCatPeriodicidadFormaPago
                            ,
                            IdCatModalidadFormaPago = int.Parse(modadlidad[0])
                            ,
                            Estatus = 1
                            ,
                            ClaveAgenteModalidadFormaPago = modadlidad[1]
                            ,
                            CaratulaOperaModalidadFromaPago = modadlidad[2]
                            ,
                            EntrarOPL = Convert.ToBoolean(modadlidad[3])
                            ,
                            SoloAdministrador = idsFormaPagoAdmin != null && idsFormaPagoAdmin.Contains(modadlidad[0])
                            ,
                            IdCatProducto = CatProducto
                        };
                    }
                    else
                    {
                        reg = new ModalidadFormaPagoProducto
                        {
                            IdConvenio = IdConvenio
                            ,
                            IdCatPeriodicidad = IdCatPeriodicidad
                            ,
                            IdCatPeriodicidadFormaPago = IdCatPeriodicidadFormaPago
                            ,
                            IdCatModalidadFormaPago = int.Parse(idFormaPago)
                            ,
                            Estatus = 1
                            ,
                            ClaveAgenteModalidadFormaPago = null
                            ,
                            CaratulaOperaModalidadFromaPago = null
                            ,
                            EntrarOPL = false
                            ,
                            SoloAdministrador = idsFormaPagoAdmin != null && idsFormaPagoAdmin.Contains(idFormaPago)
                            ,
                            IdCatProducto = CatProducto
                        };
                    }
                    db.ModalidadFormaPagoProducto.Add(reg);
                    db.SaveChanges();

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, reg)), $"{reg.GetType()}");
                }
            }
        }
        #endregion

        #region 5.- Datos adicionales

        /// <summary>
        /// Datos adicionales
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult DatosAdicionales(int IdEmpresa, int IdConvenio)
        {
            //obtener configuracionConvenio
            ConfiguracionEmpresa dbCfgEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == IdEmpresa);
            LocktonModel.db.Convenio ElConvenio = new LocktonModel.db.Convenio();
            if (IdConvenio > 0)
            {
                ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == IdConvenio);
                ViewBag.AplicaPromotores = ElConvenio.AplicaPromotores != null ? (bool)ElConvenio.AplicaPromotores : false;
            }
            else
                return HttpNotFound();

            DatosAdicionalesBox();
            SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", IdConvenio);
            ElConvenio.TipoModificaciones = db.TIPOMODIFICACION_SELECT_Convenio.SqlQuery("sp_TIPOMODIFICACION_SELECT_Convenio @IdConvenio", sqlidconvenio).ToList();
            ElConvenio.Archivos = db.ArchivoConvenio.Where(a => a.IdConvenio == IdConvenio).ToList();
            ElConvenio.ArchivosCondionesGenerales = db.CondicionGeneralArchivo.Where(a => a.IdConvenio == IdConvenio).ToList();
            ElConvenio.Argumentos = db.ANA_Argumento.Where(a => a.IdConvenio == IdConvenio).ToList();

            if (ElConvenio.ArchivosCondionesGenerales.Any())
            {
                foreach (var file in ElConvenio.ArchivosCondionesGenerales)
                {

                    var tipo = db.CatRamoVehiculo.FirstOrDefault(a => a.IdCatRamo == file.IdTipoVehiculo);

                    file.TipoVehiculo = tipo.Nombre;
                }
            }

            return View(ElConvenio);
        }

        /// <summary>
        /// Datos adicionales
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult DatosAdicionalesProductos(int IdEmpresa, int IdConvenio, int IdCatProducto)
        {
            //obtener configuracionConvenio
            ConfiguracionEmpresaPorProducto dbCfgEmpresa = db.ConfiguracionEmpresaPorProducto.FirstOrDefault(x => x.IdEmpresa == IdEmpresa && x.IdProducto == IdCatProducto);
            LocktonModel.db.ConvenioProductos ElConvenio = new LocktonModel.db.ConvenioProductos();
            if (IdConvenio > 0)
            {
                ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == IdConvenio);
                ViewBag.AplicaPromotores = ElConvenio.AplicaPromotores != null ? (bool)ElConvenio.AplicaPromotores : false;
            }
            else
                return HttpNotFound();

            DatosAdicionalesBoxProducto(IdCatProducto);
            SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", IdConvenio);
            //ElConvenio.TipoModificaciones = db.TIPOMODIFICACION_SELECT_Convenio_Producto.SqlQuery("sp_TIPOMODIFICACION_SELECT_Convenio_Productos @IdConvenio", sqlidconvenio).ToList();
            ElConvenio.Archivos = db.ArchivoConvenioProducto.Where(a => a.IdConvenio == IdConvenio).ToList();
            return View(ElConvenio);
        }

        public JsonResult SubirArchivoConvenio(int? IdConvenio)
        {
            bool success = true;
            string message = "";
            try
            {
                var filesPosted = Request.Files;
                var files = new List<HttpPostedFileBase>();

                for (var i = 0; i < Request.Files.Count; i++)
                    files.Add(filesPosted[i]);


                var Ruta = System.Web.HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/Convenio/");

                var path = Path.Combine(Ruta, IdConvenio.ToString());

                Directory.CreateDirectory(path);

                var idUsuario = CommonMethods.GetUserId();

                foreach (var file in files)
                {
                    var archivo = new ArchivoConvenio();
                    var guid = Guid.NewGuid().ToString();

                    archivo.IdConvenio = IdConvenio ?? 0;
                    archivo.Fecha = DateTime.Now;
                    archivo.IdUsuario = idUsuario;
                    archivo.Nombre = file.FileName;

                    var fileName = path + "\\" + guid + "_" + file.FileName;

                    file.SaveAs(fileName);
                    archivo.Ruta = fileName;

                    db.ArchivoConvenio.Add(archivo);
                    db.SaveChanges();

                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }

            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);

        }
        public FileResult DescargarArchivoById(int id)
        {
            var archivo = db.ArchivoConvenio.FirstOrDefault(a => a.Id == id);
            byte[] bytes = null;

            bytes = System.IO.File.ReadAllBytes(archivo.Ruta);

            return File(bytes, "application/octet-stream", archivo.Nombre);
        }

        public JsonResult EliminarArchivo(int id)
        {
            bool success = true;
            string message = "";

            try
            {

                var archivo = db.ArchivoConvenio.FirstOrDefault(a => a.Id == id);

                System.IO.File.Delete(archivo.Ruta);

                db.ArchivoConvenio.Remove(archivo);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SubirArchivoCondicionGeneralConvenio(int? IdConvenio, int idTipoVehiculo)
        {
            bool success = true;
            string message = "";
            try
            {
                var filesPosted = Request.Files;
                var files = new List<HttpPostedFileBase>();
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == IdConvenio);

                for (var i = 0; i < Request.Files.Count; i++)
                    files.Add(filesPosted[i]);


                var Ruta = System.Web.HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/CondicionGeneral/");

                var path = Path.Combine(Ruta, IdConvenio.ToString());

                Directory.CreateDirectory(path);

                var idUsuario = CommonMethods.GetUserId();

                foreach (var file in files)
                {
                    var archivo = new CondicionGeneralArchivo();
                    var guid = Guid.NewGuid().ToString();

                    archivo.IdConvenio = IdConvenio ?? 0;
                    archivo.Fecha = DateTime.Now;
                    archivo.IdUsuario = idUsuario;
                    archivo.Nombre = file.FileName;
                    archivo.IdAseguradora = convenio.IdAseguradora;
                    archivo.IdTipoVehiculo = idTipoVehiculo;

                    var fileName = path + "\\" + guid + "_" + file.FileName;

                    file.SaveAs(fileName);
                    archivo.Ruta = fileName;

                    db.CondicionGeneralArchivo.Add(archivo);
                    db.SaveChanges();

                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }

            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);

        }
        public FileResult DescargarArchivoCondicionGeneralById(int id)
        {
            var archivo = db.CondicionGeneralArchivo.FirstOrDefault(a => a.Id == id);
            byte[] bytes = null;

            try
            {
                if (!System.IO.File.Exists(archivo.Ruta))
                {

                    bytes = System.IO.File.ReadAllBytes(archivo.Ruta);

                    return File(bytes, "application/octet-stream", archivo.Nombre);
                }
                else
                    return File(new byte[0], "application/octet-stream", archivo.Nombre);
            }
            catch (Exception ex)
            {
                log.Error(ex);
                return File(new byte[0], "application/octet-stream", archivo.Nombre);
            }
        }

        public JsonResult EliminarArchivoCondicionGeneral(int id)
        {
            bool success = true;
            string message = "";

            try
            {

                var archivo = db.CondicionGeneralArchivo.FirstOrDefault(a => a.Id == id);

                System.IO.File.Delete(archivo.Ruta);

                db.CondicionGeneralArchivo.Remove(archivo);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SubirArchivoConvenioProducto(int? IdConvenio)
        {
            bool success = true;
            string message = "";
            try
            {
                var filesPosted = Request.Files;
                var files = new List<HttpPostedFileBase>();

                for (var i = 0; i < Request.Files.Count; i++)
                    files.Add(filesPosted[i]);


                var Ruta = System.Web.HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/ConvenioProducto/");

                var path = Path.Combine(Ruta, IdConvenio.ToString());

                Directory.CreateDirectory(path);

                var idUsuario = CommonMethods.GetUserId();

                foreach (var file in files)
                {
                    var archivo = new ArchivoConvenioProducto();
                    var guid = Guid.NewGuid().ToString();

                    archivo.IdConvenio = IdConvenio ?? 0;
                    archivo.Fecha = DateTime.Now;
                    archivo.IdUsuario = idUsuario;
                    archivo.Nombre = file.FileName;

                    var fileName = path + "\\" + guid + "_" + file.FileName;

                    file.SaveAs(fileName);
                    archivo.Ruta = fileName;

                    db.ArchivoConvenioProducto.Add(archivo);
                    db.SaveChanges();

                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }

            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);

        }
        public FileResult DescargarArchivoProductoById(int id)
        {
            var archivo = db.ArchivoConvenioProducto.FirstOrDefault(a => a.Id == id);
            byte[] bytes = null;

            bytes = System.IO.File.ReadAllBytes(archivo.Ruta);

            return File(bytes, "application/octet-stream", archivo.Nombre);
        }

        public JsonResult EliminarArchivoProducto(int id)
        {
            bool success = true;
            string message = "";

            try
            {

                var archivo = db.ArchivoConvenioProducto.FirstOrDefault(a => a.Id == id);

                System.IO.File.Delete(archivo.Ruta);

                db.ArchivoConvenioProducto.Remove(archivo);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// Datos adicionales
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DatosAdicionales(LocktonModel.db.Convenio Captura)
        {
            LocktonModel.db.Convenio ElConvenio = db.Convenio.FirstOrDefault(reg => reg.Id == Captura.Id);
            if (ModelState.IsValid)
            {
                if (Captura.TipoModificaciones.Where(a => a.Selected).Any())
                {



                    ElConvenio.ZonaCirculacion = Captura.ZonaCirculacion;

                    ElConvenio.CodigoPostal = Captura.CodigoPostal;
                    ElConvenio.IntentosCobro = Captura.IntentosCobro;
                    ElConvenio.NumeroNegocio = Captura.NumeroNegocio;
                    ElConvenio.UsuarioAgente = Captura.UsuarioAgente;
                    ElConvenio.CodigoCliente = Captura.CodigoCliente ?? "";
                    ElConvenio.AplicaPromotores = Captura.AplicaPromotoresValue;

                    if (ElConvenio.IdAseguradora == 1)
                    {
                        ElConvenio.AplicaNumeroContrato = Captura.AplicaNumeroContrato;
                        ElConvenio.AplicaSegmento = Captura.AplicaSegmento;
                        ElConvenio.AplicaSegmentoUsuarioFinal = Captura.AplicaSegmentoUsuarioFinal;
                        ElConvenio.AplicaNumeroContratoUsuarioFinal = Captura.AplicaNumeroContratoUsuarioFinal;
                        ElConvenio.AplicaNumeroEmpleado = Captura.AplicaNumeroEmpleado;
                        ElConvenio.AplicaNumeroEmpleadoUsuarioFinal = Captura.AplicaNumeroEmpleadoUsuarioFinal;
                    }

                    if (Captura.IdAseguradora == 3)
                    {
                        ElConvenio.Agrupador = Captura.Agrupador;
                        ElConvenio.Conducto = Captura.Conducto;
                        ElConvenio.TRC = Captura.TRC;
                        ElConvenio.CNZD = Captura.CNZD;
                        ElConvenio.NEI = Captura.NEI;
                        ElConvenio.ZonaCotizacion = Captura.ZonaCotizacion;
                        //ElConvenio.ImprimirRecibosPDF = Captura.ImprimirRecibosPDF;
                        ElConvenio.NombreContactoAseguradora = Captura.NombreContactoAseguradora;
                        ElConvenio.CorreoContactoAseguradora = Captura.CorreoContactoAseguradora;
                        ElConvenio.NombreContactoServicio = Captura.NombreContactoServicio;
                        ElConvenio.CorreoContactoServicio = Captura.CorreoContactoServicio;
                        ElConvenio.PersonaNoEmpresa = Captura.PersonaNoEmpresa;
                        ElConvenio.Referencia1 = Captura.Referencia1;
                    }
                    if (Captura.IdAseguradora == 5)
                    {
                        ElConvenio.CuadroComision = Captura.CuadroComision;
                    }

                    //var tipoMovimientoToDelete = Captura.TipoModificaciones.Where(a => a.Id.HasValue && !a.Selected).ToList();
                    //var tipoMovimientoToAdd = Captura.TipoModificaciones.Where(a => !a.Id.HasValue && a.Selected).ToList();

                    //if (tipoMovimientoToDelete.Any())
                    //{

                    //    var scriptDelete = string.Format("DELETE FROM ConvenioTipoModificacion WHERE Id IN ({0})", string.Join(",", tipoMovimientoToDelete.Select(a => a.Id)));
                    //    db.Database.ExecuteSqlCommand(scriptDelete);
                    //}
                    //if (tipoMovimientoToAdd.Any())
                    //{
                    //    var scriptAdd = "";
                    //    foreach (var toAdd in tipoMovimientoToAdd)
                    //    {
                    //        scriptAdd += string.Format("INSERT INTO ConvenioTipoModificacion SELECT {0}, {1};", ElConvenio.Id, toAdd.IdTipoModificacion);
                    //    }
                    //    db.Database.ExecuteSqlCommand(scriptAdd);
                    //}

                    foreach (var tipomodificacion in Captura.TipoModificaciones)
                    {
                        if (tipomodificacion.Id.HasValue)
                        {
                            var exist = db.ConvenioTipoModificacion.FirstOrDefault(a => a.IdConvenio == ElConvenio.Id && a.Id == tipomodificacion.Id);

                            if (tipomodificacion.Selected)
                            {
                                exist.DocumentoObligatorio = tipomodificacion.DocumentoObligatorio;
                                exist.ObligatorioUsuarioFinal = tipomodificacion.ObligatorioUsuarioFinal;
                                exist.ObligatorioAdministrador = tipomodificacion.ObligatorioAdministrador;

                                db.SaveChanges();
                            }
                            else
                            {
                                db.ConvenioTipoModificacion.Remove(exist);
                                db.SaveChanges();
                            }
                        }
                        else if (tipomodificacion.Selected)
                            AgregarConvenioTipoModificacion(tipomodificacion, ElConvenio.Id);

                    }

                    db.Entry(ElConvenio).State = EntityState.Modified;
                    db.SaveChanges();

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, ElConvenio)), $"{ElConvenio.GetType()}");

                    return RedirectToAction("CondicionesEspeciales", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.Id });
                }
                ViewBag.MensajeError = "Debe activar al menos un Tipo de Modificaci&oacute;n";
            }
            ViewBag.AplicaPromotores = ElConvenio.AplicaPromotores != null ? (bool)ElConvenio.AplicaPromotores : false;
            //si no es valido
            DatosAdicionalesBox();
            ElConvenio.Archivos = db.ArchivoConvenio.Where(a => a.IdConvenio == Captura.Id).ToList();
            ElConvenio.Argumentos = db.ANA_Argumento.Where(a => a.IdConvenio == Captura.Id).ToList();
            return View(Captura);
        }

        private void AgregarConvenioTipoModificacion(TIPOMODIFICACION_SELECT_Convenio item, int idConvenio)
        {
            try
            {
                var tipoModificacion = new ConvenioTipoModificacion();
                tipoModificacion.IdTipoModificacion = item.IdTipoModificacion;
                tipoModificacion.DocumentoObligatorio = item.DocumentoObligatorio;
                tipoModificacion.ObligatorioUsuarioFinal = item.ObligatorioUsuarioFinal;
                tipoModificacion.ObligatorioAdministrador = item.ObligatorioAdministrador;
                tipoModificacion.IdConvenio = idConvenio;

                db.ConvenioTipoModificacion.Add(tipoModificacion);
                db.SaveChanges();
            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// Datos adicionales
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DatosAdicionalesProductos(LocktonModel.db.ConvenioProductos Captura)
        {
            LocktonModel.db.ConvenioProductos ElConvenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == Captura.Id);
            if (ModelState.IsValid)
            {
                //if (Captura.TipoModificaciones.Where(a => a.Selected).Any())
                //{



                ElConvenio.ZonaCirculacion = Captura.ZonaCirculacion;

                ElConvenio.CodigoPostal = Captura.CodigoPostal;
                ElConvenio.IntentosCobro = Captura.IntentosCobro;
                ElConvenio.NumeroNegocio = Captura.NumeroNegocio;
                ElConvenio.UsuarioAgente = Captura.UsuarioAgente;
                ElConvenio.AplicaPromotores = Captura.AplicaPromotoresValue;

                if (ElConvenio.IdAseguradoraProducto == 1)
                {
                    ElConvenio.AplicaNumeroContrato = Captura.AplicaNumeroContrato;
                    ElConvenio.AplicaSegmento = Captura.AplicaSegmento;
                    ElConvenio.AplicaSegmentoUsuarioFinal = Captura.AplicaSegmentoUsuarioFinal;
                    ElConvenio.AplicaNumeroContratoUsuarioFinal = Captura.AplicaNumeroContratoUsuarioFinal;
                }

                if (Captura.IdAseguradoraProducto == 3)
                {
                    ElConvenio.Agrupador = Captura.Agrupador;
                    ElConvenio.Conducto = Captura.Conducto;
                    ElConvenio.TRC = Captura.TRC;
                    ElConvenio.CNZD = Captura.CNZD;
                    ElConvenio.NEI = Captura.NEI;
                    ElConvenio.ZonaCotizacion = Captura.ZonaCotizacion;
                    ElConvenio.ImprimirRecibosPDF = Captura.ImprimirRecibosPDF;
                }
                if (Captura.IdAseguradoraProducto == 5)
                {
                    ElConvenio.CuadroComision = Captura.CuadroComision;
                }


                //var tipoMovimientoToDelete = Captura.TipoModificaciones.Where(a => a.Id.HasValue && !a.Selected).Select(a => a.Id).ToList();
                //var tipoMovimientoToAdd = Captura.TipoModificaciones.Where(a => !a.Id.HasValue && a.Selected).ToList();

                //if (tipoMovimientoToDelete.Any())
                //{
                //	var movesDel = db.ConvenioTipoModificacionProducto.Where(a => tipoMovimientoToDelete.Contains(a.Id)).ToList();

                //	db.ConvenioTipoModificacionProducto.RemoveRange(movesDel);
                //}
                //if (tipoMovimientoToAdd.Any())
                //{
                //	var movesAdd = new List<ConvenioTipoModificacionProducto>();
                //	foreach (var toAdd in tipoMovimientoToAdd)
                //	{
                //		var _mov = new ConvenioTipoModificacionProducto();
                //		_mov.IdTipoModificacionProducto = toAdd.IdTipoModificacion;
                //		_mov.IdConvenioProducto = ElConvenio.Id;

                //		movesAdd.Add(_mov);
                //	}

                //	if (movesAdd.Any())
                //	{
                //		db.ConvenioTipoModificacionProducto.AddRange(movesAdd);
                //		db.SaveChanges();
                //	}
                //}

                db.Entry(ElConvenio).State = EntityState.Modified;
                db.SaveChanges();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, ElConvenio)), $"{ElConvenio.GetType()}");

                //return RedirectToAction("CondicionesEspecialesProducto", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.Id });
                //return RedirectToAction("CondicionesEspeciales", new { IdEmpresa = Captura.IdEmpresa, IdConvenio = Captura.Id });
                //return Json(Url.Action("Configuracion", "Empresas", new { Id = Captura.IdEmpresa }));
                return RedirectToAction("Configuracion", "Empresas", new { Id = Captura.IdEmpresa });
                //}
                //ViewBag.MensajeError = "Debe activar al menos un Tipo de Modificacion";
            }
            ViewBag.AplicaPromotores = ElConvenio.AplicaPromotores != null ? (bool)ElConvenio.AplicaPromotores : false;
            //si no es valido
            DatosAdicionalesBox();

            ElConvenio.Archivos = db.ArchivoConvenioProducto.Where(a => a.IdConvenio == Captura.Id).ToList();
            return View(Captura);
        }

        private void DatosAdicionalesBox()
        {
            //List<SelectListItem> list = db.CatOficinaContratacion.ToList().ConvertAll(a =>
            //{
            //    return new SelectListItem()
            //    {
            //        Text = a.Oficina,
            //        Value = a.Id,
            //        Selected = false
            //    };
            //});
            SelectList list = new SelectList(db.CatOficinaContratacion.ToList(), "Id", "Oficina");
            //List<SelectListItem> list = new List<SelectListItem>();
            //list.Add(new SelectListItem() { Text = "Monterrey", Value = "1" });
            //list.Add(new SelectListItem() { Text = "Mexico", Value = "2" });
            //list.Add(new SelectListItem() { Text = "Guadalajara", Value = "3" });

            ViewBag.RadioCatZonaCotizacion = db.CatZonaCotizacion.Where(x => x.Estatus == 1).ToList();
            ViewBag.ZonaCotizacionChubb = list;
        }

        private void DatosAdicionalesBoxProducto(int IdCatProducto)
        {
            //List<SelectListItem> list = db.CatOficinaContratacion.ToList().ConvertAll(a =>
            //{
            //    return new SelectListItem()
            //    {
            //        Text = a.Oficina,
            //        Value = a.Id,
            //        Selected = false
            //    };
            //});
            SelectList list = new SelectList(db.CatOficinaContratacion.ToList(), "Id", "Oficina");
            //List<SelectListItem> list = new List<SelectListItem>();
            //list.Add(new SelectListItem() { Text = "Monterrey", Value = "1" });
            //list.Add(new SelectListItem() { Text = "Mexico", Value = "2" });
            //list.Add(new SelectListItem() { Text = "Guadalajara", Value = "3" });

            ViewBag.RadioCatZonaCotizacion = db.CatZonaCotizacionProducto.Where(x => x.Estatus == 1 && x.IdCatProducto == IdCatProducto).ToList();
            ViewBag.ZonaCotizacionChubb = list;
        }


        public JsonResult GuardarArgumentoANA(ANA_Argumento argumento)
        {
            bool success = true;
            string message = "";
            try
            {
                var _argumento = db.ANA_Argumento.FirstOrDefault(a => a.IdArgumento == argumento.IdArgumento && a.IdConvenio == argumento.IdConvenio);

                if(_argumento!= null)
                {
                    success = false;
                    message = "Ya existe un Argumento con el mismo valor";
                }else
                {
                    db.ANA_Argumento.Add(argumento);
                    db.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }

            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);

        }

        public JsonResult EliminarArgumentoANA(int id)
        {
            bool success = true;
            string message = "";

            try
            {

                var archivo = db.ANA_Argumento.FirstOrDefault(a => a.Id == id);

               
                db.ANA_Argumento.Remove(archivo);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message


            }, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region 6.- Condiciones especiales

        /// <summary>
        /// Condiciones especiales
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult CondicionesEspeciales(int IdEmpresa, int IdConvenio)
        {
            ViewBag.Error = 0;
            ViewBag.MensajeError = "ninguno";
            LocktonModel.db.Convenio convenio = db.Convenio.FirstOrDefault(reg => reg.Id == IdConvenio);
            ViewBag.CatCondicion = new SelectList(db.CatCondicion, "Id", "Tipo");

            var configuracion = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == convenio.IdEmpresa);

            ViewBag.IdCondicionEspecial = new SelectList(db.CondicionEspecial.Where(x => x.Estatus), "Id", "Descripcion");
            SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", IdConvenio);
            ViewBag.CatCoberturas = db.sp_CONVENIO_SELECT_CoberturasVehiculo.SqlQuery("sp_CONVENIO_SELECT_CoberturasVehiculo @IdConvenio ", sqlidconvenio).ToList();
            //ViewBag.CatCoberturas = new SelectList((from cob in db.Cobertura
            //										join pd in db.PaqueteDetalle on cob.Id equals pd.IdCobertura
            //										join crp in db.ConvenioRamoPaquete on pd.IdConvenioRamoPaquete equals crp.Id
            //										where crp.IdConvenio == IdConvenio
            //										select cob).ToList().Distinct(), "Id", "Descripcion");

            //List<CondicionEspecial> condicionesEspeciales = (from ce in db.CondicionEspecial
            //												 join cce in db.CoberturasCondicionesEspeciales on ce.Id equals cce.IdCondicionEspecial
            //												 where cce.IdConvenio == IdConvenio && ce.Estatus
            //												 select ce).ToList();

            //ViewBag.CoberturasCondicionesEspeciales = (from ce in condicionesEspeciales
            //										   join cce in db.CoberturasCondicionesEspeciales on ce.Id equals cce.IdCondicionEspecial
            //										   where cce.IdConvenio == IdConvenio && ce.Estatus
            //										   select cce).ToList();
            SqlParameter _sqlidconvenio = new SqlParameter("@IdConvenio", IdConvenio);
            ViewBag.CondicionesEspeciales = db.sp_CONVENIO_SELECT_CoberturasEspeciales.SqlQuery("sp_CONVENIO_SELECT_CoberturasEspeciales @IdConvenio", _sqlidconvenio).ToList();
            ViewBag.AplicaMIT = AplicaPagoMIT(IdConvenio);

            convenio.Descuentos = db.ConvenioDescuentoEstado.Where(a => a.IdConvenio == convenio.Id).ToList();
            var estados = db.CatEstadosRepublica.ToList();
            var coberturas = db.Cobertura.Where(a => a.IdPaquete == convenio.IdAseguradora);

            ViewBag.Estados = new SelectList(estados.OrderBy(a => a.Estado).ToList(), "Id", "Estado");
            ViewBag.ComparativoEspecial = configuracion.ComparativoEspecial;

            convenio.Descuentos.ForEach(a => a.Estado = estados.FirstOrDefault(x => x.Id == a.IdEstado).Estado);

            convenio.CondicionesParticulares = db.ConvenioCondicionesParticulares.Where(a => a.IdConvenio == convenio.Id).OrderBy(a => a.Identificador).ToList();
            convenio.CondicionesParticulares.Where(a=>a.IdCobertura>0).ForEach(a => a.Cobertura = coberturas.FirstOrDefault(x => x.Id == a.IdCobertura).Descripcion);

            return View(convenio);
        }

        /// <summary>
        /// Condiciones especiales
        /// </summary>
        /// <returns>vista parcial</returns>
        public ActionResult CondicionesEspecialesProducto(int IdEmpresa, int IdConvenio)
        {
            ViewBag.Error = 0;
            ViewBag.MensajeError = "ninguno";
            LocktonModel.db.ConvenioProductos convenio = db.ConvenioProductos.FirstOrDefault(reg => reg.Id == IdConvenio);
            ViewBag.CatCondicion = new SelectList(db.CatCondicion, "Id", "Tipo");
            ViewBag.IdCondicionEspecial = new SelectList(db.CondicionEspecialProducto.Where(x => x.Estatus), "Id", "Descripcion");
            SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", IdConvenio);
            ViewBag.CatCoberturas = db.sp_CONVENIO_SELECT_CoberturasProducto.SqlQuery("sp_CONVENIO_SELECT_CoberturasProducto @IdConvenio ", sqlidconvenio).ToList();
            //ViewBag.CatCoberturas = new SelectList((from cob in db.Cobertura
            //										join pd in db.PaqueteDetalle on cob.Id equals pd.IdCobertura
            //										join crp in db.ConvenioRamoPaquete on pd.IdConvenioRamoPaquete equals crp.Id
            //										where crp.IdConvenio == IdConvenio
            //										select cob).ToList().Distinct(), "Id", "Descripcion");

            //List<CondicionEspecial> condicionesEspeciales = (from ce in db.CondicionEspecial
            //												 join cce in db.CoberturasCondicionesEspeciales on ce.Id equals cce.IdCondicionEspecial
            //												 where cce.IdConvenio == IdConvenio && ce.Estatus
            //												 select ce).ToList();

            //ViewBag.CoberturasCondicionesEspeciales = (from ce in condicionesEspeciales
            //										   join cce in db.CoberturasCondicionesEspeciales on ce.Id equals cce.IdCondicionEspecial
            //										   where cce.IdConvenio == IdConvenio && ce.Estatus
            //										   select cce).ToList();
            SqlParameter _sqlidconvenio = new SqlParameter("@IdConvenio", IdConvenio);
            ViewBag.CondicionesEspeciales = db.sp_CONVENIO_SELECT_CoberturasEspecialesProductos.SqlQuery("sp_CONVENIO_SELECT_CoberturasEspecialesProductos @IdConvenio", _sqlidconvenio).ToList();
            ViewBag.AplicaMIT = AplicaPagoMIT(IdConvenio);
            return View(convenio);
        }

        /// <summary>
        /// Condiciones especiales
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult GuardaCondicionesEspeciales(VCondicionesEspeciales form)
        {
            LocktonModel.db.Convenio convenio = db.Convenio.Find(form.IdConvenio);
            try
            {
                if (form.CondicionesEspeciales != null && form.CondicionesEspeciales.Count > 0)
                {
                    CondicionEspecial condEsp;

                    foreach (VCondiconEspecial ce in form.CondicionesEspeciales)
                    {
                        //falta revisar que cuando se den de alta no creen registros iguales. 
                        if (ce.IdCondicionEspecial > 0)
                        {
                            condEsp = db.CondicionEspecial.Find(ce.IdCondicionEspecial);
                            if (condEsp != null)
                            {
                                condEsp.IdCatCondicion = ce.Condicion;
                                condEsp.Valor1 = ce.ValorI;
                                condEsp.Valor2 = ce.ValorF;
                                db.Entry(condEsp).State = EntityState.Modified;
                            }
                        }
                        else
                        {
                            condEsp = new CondicionEspecial { Descripcion = ce.Descripcion, CatCondicion = db.CatCondicion.FirstOrDefault(x => x.Id == ce.Condicion), Valor1 = ce.ValorI, Valor2 = ce.ValorF, Estatus = true };
                            db.CondicionEspecial.Add(condEsp);
                            db.SaveChanges();

                            CoberturasCondicionesEspeciales cobCondEsps = new CoberturasCondicionesEspeciales { IdCobertura = db.Cobertura.FirstOrDefault(x => x.Id == ce.Cobertura).Id, IdCondicionEspecial = condEsp.Id, IdConvenio = convenio.Id, IdCatRamoVehiculo = ce.IdCatRamoVehiculo };
                            db.CoberturasCondicionesEspeciales.Add(cobCondEsps);
                        }

                        db.SaveChanges();
                    }
                }
                //Remode special condition
                if (form.Removidos != null && form.Removidos.Count() > 0)
                {
                    for (int r = 0; r < form.Removidos.Count(); r++)
                    {
                        CondicionEspecial condEsp = db.CondicionEspecial.Find(form.Removidos[r]);
                        if (condEsp != null)
                        {
                            condEsp.Estatus = false;
                            db.Entry(condEsp).State = EntityState.Modified;
                            db.SaveChanges();
                        }
                    }
                }
                //
                convenio.GestorCobro = form.GestorCobro;
                convenio.Mit_id_company = form.id_company;
                convenio.Mit_id_branch = form.id_branch;
                convenio.Mit_user = form.user;
                convenio.Mit_pwd = form.pwd;
                convenio.Mit_Key = form.Key;
                convenio.Mit_Data0 = form.Data0;

                db.SaveChanges();
                string IdGerenciaCore = db.Empresa.Where(x => x.Id == convenio.IdEmpresa).Select(x => x.IdGerenciaCORE).FirstOrDefault();
                string ClaveCore = db.Aseguradora.Where(x => x.Id == convenio.IdAseguradora).Select(x => x.ClaveCore).FirstOrDefault();
                if (convenio.IdAseguradora == 1 || convenio.IdAseguradora == 27)
                {
                    var claveagente = (from MFP in db.ModalidadFormaPago
                                       where MFP.IdConvenio == form.IdConvenio
                                       select new
                                       {
                                           MFP.ClaveAgenteModalidadFormaPago
                                       }).Distinct().ToList();
                    foreach (var item in claveagente)
                    {
                        if (!string.IsNullOrEmpty(IdGerenciaCore) && !string.IsNullOrEmpty(ClaveCore) && !string.IsNullOrEmpty(item.ClaveAgenteModalidadFormaPago))
                        {
                            try
                            {
                                DerivaConvenioCore(convenio.Id, convenio.IdAseguradora);
                            }
                            catch (Exception ex)
                            {
                                log.Info("No se pudo derivar el convenio al core:" + ex.Message);
                            }
                        }
                        else
                        {
                            log.Info("No se pudo derivar el convenio al core: IdGerenciaCore: " + IdGerenciaCore + " ClaveCore: " + ClaveCore + " ClaveAgente: " + item.ClaveAgenteModalidadFormaPago);
                        }
                    }

                }
                else
                {
                    string ClaveAgente = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenio.Id).Select(x => x.ClaveAgente).FirstOrDefault();
                    if (!string.IsNullOrEmpty(IdGerenciaCore) && !string.IsNullOrEmpty(ClaveCore) && !string.IsNullOrEmpty(ClaveAgente))
                    {
                        try
                        {
                            DerivaConvenioCore(convenio.Id, convenio.IdAseguradora);
                        }
                        catch (Exception ex)
                        {
                            log.Info("No se pudo derivar el convenio al core:" + ex.Message);
                        }
                    }
                    else
                    {
                        log.Info("No se pudo derivar el convenio al core: IdGerenciaCore: " + IdGerenciaCore + " ClaveCore: " + ClaveCore + " ClaveAgente: " + ClaveAgente);
                    }
                }

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, form)), $"{form.GetType()}");

                return Json(Url.Action("Configuracion", "Empresas", new { Id = form.IdEmpresa }));
            }
            catch (Exception ex)
            {
                ViewBag.Error = 1;
                ViewBag.MensjaeError = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                return RedirectToAction("CondicionesEspeciales", new { IdEmpresa = form.IdEmpresa, IdConvenio = form.IdConvenio });
            }
        }


        /// <summary>
        /// Condiciones especiales
        /// </summary>
        /// <returns>vista parcial</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult GuardaCondicionesEspecialesProducto(VCondicionesEspeciales form)
        {
            LocktonModel.db.ConvenioProductos convenio = db.ConvenioProductos.Find(form.IdConvenio);
            try
            {
                if (form.CondicionesEspeciales != null && form.CondicionesEspeciales.Count > 0)
                {
                    CondicionEspecialProducto condEsp;

                    foreach (VCondiconEspecial ce in form.CondicionesEspeciales)
                    {
                        //falta revisar que cuando se den de alta no creen registros iguales. 
                        if (ce.IdCondicionEspecial > 0)
                        {
                            condEsp = db.CondicionEspecialProducto.Find(ce.IdCondicionEspecial);
                            if (condEsp != null)
                            {
                                condEsp.IdCatCondicion = ce.Condicion;
                                condEsp.Valor1 = ce.ValorI;
                                condEsp.Valor2 = ce.ValorF;
                                db.Entry(condEsp).State = EntityState.Modified;
                            }
                        }
                        else
                        {
                            condEsp = new CondicionEspecialProducto
                            {
                                Descripcion = ce.Descripcion,
                                CatCondicion = db.CatCondicion.FirstOrDefault(x => x.Id == ce.Condicion),
                                Valor1 = ce.ValorI,
                                Valor2 = ce.ValorF,
                                Estatus = true,
                                IdCatProducto = convenio.IdCatProducto
                            };
                            db.CondicionEspecialProducto.Add(condEsp);
                            db.SaveChanges();

                            CoberturasCondicionesEspecialesProducto cobCondEsps = new CoberturasCondicionesEspecialesProducto
                            {
                                IdCoberturaProducto = db.CoberturaProducto.FirstOrDefault(x => x.Id == ce.Cobertura).Id,
                                IdCondicionEspecialProducto = condEsp.Id,
                                IdConvenioProducto = convenio.Id,
                                IdCatRamoProducto = ce.IdCatRamoVehiculo,
                                IdCatProducto = convenio.IdCatProducto
                            };
                            db.CoberturasCondicionesEspecialesProducto.Add(cobCondEsps);
                        }

                        db.SaveChanges();
                    }
                }
                //Remode special condition
                if (form.Removidos != null && form.Removidos.Count() > 0)
                {
                    for (int r = 0; r < form.Removidos.Count(); r++)
                    {
                        CondicionEspecial condEsp = db.CondicionEspecial.Find(form.Removidos[r]);
                        if (condEsp != null)
                        {
                            condEsp.Estatus = false;
                            db.Entry(condEsp).State = EntityState.Modified;
                            db.SaveChanges();
                        }
                    }
                }
                //
                convenio.GestorCobro = form.GestorCobro;
                convenio.Mit_id_company = form.id_company;
                convenio.Mit_id_branch = form.id_branch;
                convenio.Mit_user = form.user;
                convenio.Mit_pwd = form.pwd;
                convenio.Mit_Key = form.Key;
                convenio.Mit_Data0 = form.Data0;

                db.SaveChanges();
                string IdGerenciaCore = db.Empresa.Where(x => x.Id == convenio.IdEmpresa).Select(x => x.IdGerenciaCORE).FirstOrDefault();
                string ClaveCore = db.AseguradoraProductos.Where(x => x.Id == convenio.IdAseguradoraProducto).Select(x => x.ClaveCore).FirstOrDefault();
                string ClaveAgente = db.PeriodicidadFormaPagoProducto.Where(x => x.IdConvenioProducto == convenio.Id).Select(x => x.ClaveAgente).FirstOrDefault();

                if (!string.IsNullOrEmpty(IdGerenciaCore) && !string.IsNullOrEmpty(ClaveCore) && !string.IsNullOrEmpty(ClaveAgente))
                {
                    try
                    {
                        //DerivaConvenioCore(convenio.Id, convenio.IdAseguradora);
                    }
                    catch (Exception ex)
                    {
                        log.Info("No se pudo derivar el convenio al core:" + ex.Message);
                    }
                }
                else
                {
                    log.Info("No se pudo derivar el convenio al core: IdGerenciaCore: " + IdGerenciaCore + " ClaveCore: " + ClaveCore + " ClaveAgente: " + ClaveAgente);
                }

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, form)), $"{form.GetType()}");

                return Json(Url.Action("Configuracion", "Empresas", new { Id = form.IdEmpresa }));
            }
            catch (Exception ex)
            {
                ViewBag.Error = 1;
                ViewBag.MensjaeError = (ex.InnerException != null ? ex.InnerException.Message ?? ex.Message : ex.Message);
                return RedirectToAction("CondicionesEspeciales", new { IdEmpresa = form.IdEmpresa, IdConvenio = form.IdConvenio });
            }
        }

        public void DerivaConvenioCore(int IdConvenio, int idAseguradora)
        {
            string ConnectionString = ConfigurationManager.ConnectionStrings["LocktonOneCore"].ConnectionString;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                if (idAseguradora == 1)
                {
                    using (SqlCommand cmd = new SqlCommand("sp_Derive_Core_Agreement", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@IdConvenioPortal", SqlDbType.Int).Value = IdConvenio;

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    using (SqlCommand cmd = new SqlCommand("sp_deriva_convenio_core", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@IdConvenioPortal", SqlDbType.Int).Value = IdConvenio;

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new { IdConvenio = IdConvenio, IdAsegurado = idAseguradora }), $"dynamic");
        }

        private bool AplicaPagoMIT(int idConvenio)
        {

            List<ModalidadFormaPago> modalidades = db.ModalidadFormaPago.Where(a => a.IdConvenio == idConvenio && (a.IdCatModalidadFormaPago == 1 || a.IdCatModalidadFormaPago == 2)).ToList();
            return modalidades.Any();
        }
        #endregion


        #region Derivacion de convenio

        [HttpGet]
        public ActionResult DerivaConvenio()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DerivaConvenio(string IdEmpresa)
        {
            if (string.IsNullOrEmpty(IdEmpresa))
                return View();

            DerivacionConvenioCore derivacionConvenio = new DerivacionConvenioCore();
            derivacionConvenio.DerivacionConvenio(int.Parse(IdEmpresa));

            CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(IdEmpresa), $"{IdEmpresa.GetType()}");

            return View();
        }

        #endregion

        #region FechaCobroMapfre
        public JsonResult InicializaFechaCobro(int idConvenio)
        {

            List<ListaGenerica> periodicidad = new List<ListaGenerica>();
            List<FechaCobroMAPFRE> fechas = new List<FechaCobroMAPFRE>();
            try
            {
                var ids = new List<int>();//[2,3,4,5,6,7].ToList();
                ids.Add(2);
                ids.Add(3);
                ids.Add(4);
                ids.Add(5);
                ids.Add(6);
                ids.Add(7);
                periodicidad = db.CatPeriodicidadFormaPago.Where(a => a.Estatus == 1 && ids.Contains(a.Id)).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                fechas = db.FechaCobroMAPFRE.Where(a => a.IdConvenio == idConvenio).OrderBy(a => a.IdPeriodicidad).ThenBy(a => a.Fecha).ToList();
                fechas.ForEach(a => a.Periodicidad = periodicidad.FirstOrDefault(p => p.Id == a.IdPeriodicidad).Nombre);
            }
            catch (Exception)
            {

                periodicidad = new List<ListaGenerica>();
                fechas = new List<FechaCobroMAPFRE>();
            }
            return Json(new
            {

                Periodicidades = periodicidad,
                Fechas = fechas

            }, JsonRequestBehavior.AllowGet);
        }



        public JsonResult GuardarFechaCobro(int idConvenio, int periodicidad, string fechaInicio)
        {
            bool success = true;
            string message = "";
            List<FechaCobroMAPFRE> fechas = new List<FechaCobroMAPFRE>();
            try
            {
                var inicio = DateTime.ParseExact(fechaInicio, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);

                if (success)
                {
                    var _saved = db.FechaCobroMAPFRE.Where(a => a.IdConvenio == idConvenio && a.IdPeriodicidad == periodicidad && a.Fecha == inicio).FirstOrDefault();
                    if (_saved == null)
                    {
                        FechaCobroMAPFRE _new = new FechaCobroMAPFRE();
                        _new.IdConvenio = idConvenio;

                        _new.IdPeriodicidad = periodicidad;
                        _new.Fecha = inicio;

                        db.FechaCobroMAPFRE.Add(_new);
                        db.SaveChanges();
                        message = "Fecha de cobro agregada correctamente";

                        CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _new)), $"{_new.GetType()}");

                        var periodicidades = db.CatPeriodicidadFormaPago.Where(a => a.Estatus == 1).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                        fechas = db.FechaCobroMAPFRE.Where(a => a.IdConvenio == idConvenio).OrderBy(a => a.IdPeriodicidad).ThenBy(a => a.Fecha).ToList();
                        fechas.ForEach(a => a.Periodicidad = periodicidades.FirstOrDefault(p => p.Id == a.IdPeriodicidad).Nombre);
                    }
                    else
                    {
                        success = false;
                        message = "Ya existe una Fecha de cobro con la Periodicidad seleccionada";
                    }
                }
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Fechas = fechas

            }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult EliminaFechaCobro(int id, int idConvenio)
        {
            bool success = true;
            string message = "";
            List<FechaCobroMAPFRE> fechas = new List<FechaCobroMAPFRE>();
            try
            {

                var _saved = db.FechaCobroMAPFRE.Where(a => a.Id == id).FirstOrDefault();
                if (_saved != null)
                {

                    db.FechaCobroMAPFRE.Remove(_saved);
                    db.SaveChanges();
                    message = "Fecha de Cobro eliminada correctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _saved)), $"{_saved.GetType()}");

                    var periodicidades = db.CatPeriodicidadFormaPago.Where(a => a.Estatus == 1).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                    fechas = db.FechaCobroMAPFRE.Where(a => a.IdConvenio == idConvenio).OrderBy(a => a.IdPeriodicidad).ThenBy(a => a.Fecha).ToList();
                    fechas.ForEach(a => a.Periodicidad = periodicidades.FirstOrDefault(p => p.Id == a.IdPeriodicidad).Nombre);
                }
                else
                {
                    success = false;
                    message = "No se encontró la información seleccionada";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Fechas = fechas

            }, JsonRequestBehavior.AllowGet);
        }


        #endregion

        #region CaratulaGNP

        public JsonResult InicializaCaratulaGNP(int idConvenio)
        {
            List<ListaGenerica> paquetes = new List<ListaGenerica>();
            List<ListaGenerica> periodicidad = new List<ListaGenerica>();
            List<ListaGenerica> formapago = new List<ListaGenerica>();
            List<ListaGenerica> tipoVehiculo = new List<ListaGenerica>();
            List<ListaGenerica> Vehiculosdisponibles = new List<ListaGenerica>();
            List<CaratulasGNPConvenio> caratulas = new List<CaratulasGNPConvenio>();
            List<sp_CaratulasGNPOpera_Convenio> caratulasOperta = new List<sp_CaratulasGNPOpera_Convenio>();
            try
            {
                var convenio = db.Convenio.FirstOrDefault(x => x.Id == idConvenio);
                ConfiguracionEmpresa ConfEm = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == convenio.IdEmpresa);

                if (convenio.OnLine)
                    paquetes = db.CatTipoPaquete.Where(a => a.Estatus == 1 && a.OnLine).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                else
                    paquetes = db.CatTipoPaquete.Where(a => a.Estatus == 1 && !a.OnLine).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                if (ConfEm.AplicaMultiAnual)
                    periodicidad = db.CatPeriodicidadFormaPago.Where(a => a.Estatus == 1 && a.ValorMultiAnual > 0).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                else
                    periodicidad = db.CatPeriodicidadFormaPago.Where(a => a.Estatus == 1 && a.ValorMultiAnual == 0).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                formapago = db.CatModalidadFormaPago.Where(a => a.Estatus == 1).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                tipoVehiculo = db.CatUsoVehiculo.Where(a => a.Estatus == 1).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                Vehiculosdisponibles = db.Vehiculosdisponibles.OrderBy(a => a.Vehiculodisp).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Vehiculodisp }).ToList();
                SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                SqlParameter _sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                caratulas = db.CaratulasGNPConvenio.SqlQuery("sp_CaratulasGNP_Convenio @IdConvenio ", sqlidconvenio).ToList();
                caratulasOperta = db.sp_CaratulasGNPOpera_Convenio.SqlQuery("sp_CaratulasGNPOpera_Convenio @IdConvenio ", _sqlidconvenio).ToList();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                {
                    Paquetes = paquetes,
                    Periodicidades = periodicidad,
                    FormasPago = formapago,
                    TiposVehiculo = tipoVehiculo,
                    Caratulas = CommonMethods.UnProxy(db, caratulas)

                }), $"dynamic");
            }
            catch (Exception ex)
            {
                paquetes = new List<ListaGenerica>();
                periodicidad = new List<ListaGenerica>();
                formapago = new List<ListaGenerica>();
                tipoVehiculo = new List<ListaGenerica>();
                caratulas = new List<CaratulasGNPConvenio>();
                caratulasOperta = new List<sp_CaratulasGNPOpera_Convenio>();
            }
            return Json(new
            {
                Paquetes = paquetes,
                Periodicidades = periodicidad,
                FormasPago = formapago,
                TiposVehiculo = tipoVehiculo,
                Vehiculosdisponibles = Vehiculosdisponibles,
                Caratulas = caratulas,
                CaratulasOperta = caratulasOperta

            }, JsonRequestBehavior.AllowGet);
        }

       
        public JsonResult GuardarCaratulaGNP(int idConvenio, string caratula, int idPaquete, int? periodicidad, int? formaPago, int inicio, int fin, int tipoVehiculo = 1, int? vehiculoDisponible=null)
        {
            bool success = true;
            string message = "";
            List<CaratulasGNPConvenio> caratulas = new List<CaratulasGNPConvenio>();
            try
            {
                if (string.IsNullOrEmpty(caratula))
                {
                    success = false;
                    message = "Debe de ingresar la caratula";
                }
                if (inicio < 1900)
                {
                    success = false;
                    message = "El año de inicio no puede ser menor que 1900";
                }
                if (inicio > fin)
                {
                    success = false;
                    message = "El año de inicio no puede ser mayor al año final";
                }
                if (success)
                {
                    CatGNPCaratula _saved = db.CatGNPCaratula.Where(a => a.IdConvenio == idConvenio
                                && a.IdTipoPaquete == idPaquete
                                && a.IdPeriodicidad == periodicidad
                                && a.IdFormaPago == formaPago
                                && a.YearInicio == inicio
                               // && a.YearFin == fin
                                && a.IdVehiculoDisponible == vehiculoDisponible
                                && a.IdRamoVehiculo == tipoVehiculo).FirstOrDefault();
                                
                    if (_saved == null)
                    {
                        CatGNPCaratula _new = new CatGNPCaratula();
                        _new.IdConvenio = idConvenio;
                        _new.Clave = caratula;
                        _new.IdTipoPaquete = idPaquete;
                        _new.IdPeriodicidad = periodicidad;
                        _new.IdFormaPago = formaPago;
                        _new.YearInicio = inicio;
                        _new.YearFin = fin;
                        _new.IdRamoVehiculo = tipoVehiculo;
                        _new.IdVehiculoDisponible = vehiculoDisponible;

                        db.CatGNPCaratula.Add(_new);
                        db.SaveChanges();
                        message = "Caratula generada correctamente";
                        SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                        caratulas = db.CaratulasGNPConvenio.SqlQuery("sp_CaratulasGNP_Convenio @IdConvenio ", sqlidconvenio).ToList();
                    }
                    else
                    {
                        success = false;
                        message = "Ya existe una caratula para el Tipo de Paquete, Periodicidad y Forma de pago seleccionados";
                    }
                }
                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                {
                    Success = success,
                    Message = message,
                    Caratulas = CommonMethods.UnProxy(db, caratulas)

                }), $"dynamic");
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GuardarCaratulaGNPOpera(int idConvenio, string caratula, int idpaquete, int periodicidad, int formaPago, int tipoVehiculo = 1)
        {
            bool success = true;
            string message = "";
            List<sp_CaratulasGNPOpera_Convenio> caratulas = new List<sp_CaratulasGNPOpera_Convenio>();
            try
            {
                if (string.IsNullOrEmpty(caratula))
                {
                    success = false;
                    message = "Debe de ingresar la caratula";
                }

                if (success)
                {
                    CatGNPCaratulaOpera _saved = db.CatGNPCaratulaOpera.Where(a => a.IdConvenio == idConvenio
                                && a.IdPeriodicidad == periodicidad
                                && a.IdFormaPago == formaPago
                                && a.IdPaquete == idpaquete
                                && a.IdUsoVehiculo == tipoVehiculo).FirstOrDefault();

                    if (_saved == null)
                    {
                        CatGNPCaratulaOpera _new = new CatGNPCaratulaOpera();
                        _new.IdConvenio = idConvenio;
                        _new.Clave = caratula;
                        _new.IdPaquete = idpaquete;
                        _new.IdPeriodicidad = periodicidad;
                        _new.IdFormaPago = formaPago;
                        _new.IdUsoVehiculo = tipoVehiculo;

                        db.CatGNPCaratulaOpera.Add(_new);
                        db.SaveChanges();
                        message = "Carátula generada correctamente";
                        SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                        caratulas = db.sp_CaratulasGNPOpera_Convenio.SqlQuery("sp_CaratulasGNPOpera_Convenio @IdConvenio ", sqlidconvenio).ToList();
                    }
                    else
                    {
                        success = false;
                        message = "Ya existe una carátula para la Periodicidad, Forma de pago y Tipo Vehiculo seleccionados";
                    }
                }
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult EliminaCaratulaGNP(int idConvenio, int idCaratula)
        {
            bool success = true;
            string message = "";
            List<CaratulasGNPConvenio> caratulas = new List<CaratulasGNPConvenio>();
            try
            {

                CatGNPCaratula _saved = db.CatGNPCaratula.Where(a => a.Id == idCaratula).FirstOrDefault();
                if (_saved != null)
                {

                    db.CatGNPCaratula.Remove(_saved);
                    db.SaveChanges();
                    message = "Caratula eliminada correctamente";
                    SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                    caratulas = db.CaratulasGNPConvenio.SqlQuery("sp_CaratulasGNP_Convenio @IdConvenio ", sqlidconvenio).ToList();
                }
                else
                {
                    success = false;
                    message = "No se encontró la información de la Caratula seleccionada";
                }

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                {
                    Success = success,
                    Message = message,
                    Caratulas = CommonMethods.UnProxy(db, caratulas)

                }), $"dynamic");
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult EliminaCaratulaGNPOperta(int idConvenio, int idCaratula)
        {
            bool success = true;
            string message = "";
            List<sp_CaratulasGNPOpera_Convenio> caratulas = new List<sp_CaratulasGNPOpera_Convenio>();
            try
            {

                CatGNPCaratulaOpera _saved = db.CatGNPCaratulaOpera.Where(a => a.Id == idCaratula).FirstOrDefault();
                if (_saved != null)
                {

                    db.CatGNPCaratulaOpera.Remove(_saved);
                    db.SaveChanges();
                    message = "Caratula eliminada correctamente";
                    SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                    caratulas = db.sp_CaratulasGNPOpera_Convenio.SqlQuery("sp_CaratulasGNPOpera_Convenio @IdConvenio ", sqlidconvenio).ToList();
                }
                else
                {
                    success = false;
                    message = "No se encontró la información de la Caratula seleccionada";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult EditarCaratulaGNP(
    int idCaratula,
    string caratula,
    int idPaquete,
    int? periodicidad,
    int? formaPago,
    int inicio,
    int fin,
    int? tipoVehiculo,
    int? vehiculoDisponible)
        {
            bool success = true;
            string message = "";

            try
            {
                var caratulaEditar = db.CatGNPCaratula
                    .FirstOrDefault(x => x.Id == idCaratula);

                if (caratulaEditar == null)
                {
                    return Json(new
                    {
                        success = false,
                        message = "No se encontró la carátula a editar."
                    });
                }

                caratulaEditar.Clave = caratula;
                caratulaEditar.IdTipoPaquete = idPaquete;
                caratulaEditar.IdPeriodicidad = periodicidad;
                caratulaEditar.IdFormaPago = formaPago;
                caratulaEditar.YearInicio = inicio;
                caratulaEditar.YearFin = fin;
                caratulaEditar.IdRamoVehiculo = tipoVehiculo ?? 1;
                caratulaEditar.IdVehiculoDisponible = vehiculoDisponible;

                db.SaveChanges();

                message = "Carátula editada correctamente.";
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }

            return Json(new
            {
                success = success,
                message = message
            });
        }
        #endregion

        #region CaratulaPaquete

        public JsonResult InicializaCaratulaPaquete(int idConvenio)
        {
            List<ListaGenerica> paquetes = new List<ListaGenerica>();
            List<ListaGenerica> ramos = new List<ListaGenerica>();
            List<CaratulaPaquete> caratulas = new List<CaratulaPaquete>();
            List<CatCaratulaAXA_Index> polizasAXA = new List<CatCaratulaAXA_Index>();
            try
            {
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                SqlParameter sqlidempresa = new SqlParameter("@IdEmpresa", convenio.IdEmpresa);
                polizasAXA = db.CatCaratulaAXA_Index.SqlQuery("sp_CaratulasAXA_Convenio @IdEmpresa", sqlidempresa).Where(a => a.IdConvenio == idConvenio).ToList();
                paquetes = db.CatTipoPaquete.Where(a => a.Estatus == 1 && a.OnLine).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                ramos = db.CatRamoVehiculo.Select(a => new ListaGenerica() { Id = a.IdCatRamo, Nombre = a.Nombre }).ToList();
                caratulas = db.CaratulaPaquete.SqlQuery("sp_CaratulaPaquete_Convenio @IdConvenio ", sqlidconvenio).ToList();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                {
                    Paquetes = paquetes,
                    Ramos = ramos,
                    Caratulas = CommonMethods.UnProxy(db, caratulas),
                    PolizasAXA = CommonMethods.UnProxy(db, polizasAXA)

                }), $"dynamic");

            }
            catch (Exception ex)
            {
                paquetes = new List<ListaGenerica>();
                ramos = new List<ListaGenerica>();
                caratulas = new List<CaratulaPaquete>();
                polizasAXA = new List<CatCaratulaAXA_Index>();
            }
            return Json(new
            {
                Paquetes = paquetes,
                Ramos = ramos,
                Caratulas = caratulas,
                PolizasAXA = polizasAXA,

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult InicializaCatRamoVheiculo(int idConvenio)
        {
            List<ListaGenerica> paquetes = new List<ListaGenerica>();
            List<CatRamoVehiculo> ramos = new List<CatRamoVehiculo>();
            List<CaratulaPaquete> caratulas = new List<CaratulaPaquete>();
            List<CatCaratulaAXA_Index> polizasAXA = new List<CatCaratulaAXA_Index>();
            try
            {
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                SqlParameter sqlidempresa = new SqlParameter("@IdEmpresa", convenio.IdEmpresa);
                polizasAXA = db.CatCaratulaAXA_Index.SqlQuery("sp_CaratulasAXA_Convenio @IdEmpresa", sqlidempresa).Where(a => a.IdConvenio == idConvenio).ToList();
                paquetes = db.CatTipoPaquete.Where(a => a.Estatus == 1 && a.OnLine).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                ramos = db.CatRamoVehiculo.ToList();
                caratulas = db.CaratulaPaquete.SqlQuery("sp_CaratulaPaquete_Convenio @IdConvenio ", sqlidconvenio).ToList();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                {
                    Paquetes = paquetes,
                    Ramos = ramos,
                    Caratulas = CommonMethods.UnProxy(db, caratulas),
                    PolizasAXA = CommonMethods.UnProxy(db, polizasAXA)

                }), $"dynamic");

            }
            catch (Exception)
            {
                paquetes = new List<ListaGenerica>();
                ramos = new List<CatRamoVehiculo>();
                caratulas = new List<CaratulaPaquete>();
                polizasAXA = new List<CatCaratulaAXA_Index>();
            }
            return Json(new
            {
                Paquetes = paquetes,
                Ramos = ramos,
                Caratulas = caratulas,
                PolizasAXA = polizasAXA,

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GuardarCaratulaPaquete(int idConvenio, string caratula, int idPaquete, int idRamo)
        {
            bool success = true;
            string message = "";
            List<CaratulaPaquete> caratulas = new List<CaratulaPaquete>();
            try
            {
                if (string.IsNullOrEmpty(caratula))
                {
                    success = false;
                    message = "Debe de ingresar la caratula";
                }
                if (success)
                {
                    CatCaratulaPaquete _saved = db.CatCaratulaPaquete.Where(a => a.IdConvenio == idConvenio && a.IdTipoPaquete == idPaquete && a.IdCatRamoVehiculo == idRamo).FirstOrDefault();
                    if (_saved == null)
                    {
                        CatCaratulaPaquete _new = new CatCaratulaPaquete();
                        _new.IdConvenio = idConvenio;
                        _new.Clave = caratula;
                        _new.IdTipoPaquete = idPaquete;
                        _new.IdCatRamoVehiculo = idRamo;
                        db.CatCaratulaPaquete.Add(_new);
                        db.SaveChanges();
                        message = "Caratula generada correcctamente";
                        SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                        caratulas = db.CaratulaPaquete.SqlQuery("sp_CaratulaPaquete_Convenio @IdConvenio", sqlidconvenio).ToList();
                    }
                    else
                    {
                        success = false;
                        message = "Ya existe una caratula para el Tipo de Paquete seleccionado";
                    }
                }
                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                {
                    Success = success,
                    Message = message,
                    Caratulas = CommonMethods.UnProxy(db, caratulas)
                }), $"dynamic");
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult EliminaCaratulaPaquete(int idConvenio, int idCaratula)
        {
            bool success = true;
            string message = "";
            List<CaratulaPaquete> caratulas = new List<CaratulaPaquete>();
            try
            {

                CatCaratulaPaquete _saved = db.CatCaratulaPaquete.Where(a => a.Id == idCaratula).FirstOrDefault();
                if (_saved != null)
                {

                    db.CatCaratulaPaquete.Remove(_saved);
                    db.SaveChanges();
                    message = "Caratula eliminada correcctamente";
                    SqlParameter sqlidconvenio = new SqlParameter("@IdConvenio", idConvenio);
                    caratulas = db.CaratulaPaquete.SqlQuery("sp_CaratulaPaquete_Convenio @IdConvenio", sqlidconvenio).ToList();
                }
                else
                {
                    success = false;
                    message = "No se encontró la información de la Caratula seleccionada";
                }
                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                {
                    Success = success,
                    Message = message,
                    Caratulas = CommonMethods.UnProxy(db, caratulas)
                }), $"dynamic");
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region CaratulaAXA
        public ActionResult CaratulaAXA(int id)
        {
            var model = new List<CatCaratulaAXA_Index>();
            SqlParameter sqlidempresa = new SqlParameter("@IdEmpresa", id);
            model = db.CatCaratulaAXA_Index.SqlQuery("sp_CaratulasAXA_Convenio @IdEmpresa", sqlidempresa).ToList();
            ViewBag.IdEmpresa = id;
            return View(model);
        }

        public JsonResult InicializaCaratulaAXA(int idEmpresa)
        {
            List<ListaGenerica> convenios = new List<ListaGenerica>();
            List<ListaGenerica> periodicidad = new List<ListaGenerica>();
            List<ListaGenerica> formapago = new List<ListaGenerica>();

            try
            {
                convenios = db.Convenio.Where(a => a.Estatus == 1 && a.IdEmpresa == idEmpresa).OrderBy(a => a.CaratulaPoliza).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.CaratulaPoliza }).ToList();
                ConfiguracionEmpresa confEmp = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == idEmpresa);
                if (confEmp.AplicaMultiAnual)
                    periodicidad = db.CatPeriodicidadFormaPago.Where(a => a.Estatus == 1 && a.ValorMultiAnual > 0).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                else
                    periodicidad = db.CatPeriodicidadFormaPago.Where(a => a.Estatus == 1 && a.ValorMultiAnual == 0).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();
                formapago = db.CatModalidadFormaPago.Where(a => a.Estatus == 1).OrderBy(a => a.Nombre).Select(a => new ListaGenerica() { Id = a.Id, Nombre = a.Nombre }).ToList();

                CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(new
                {
                    Periodicidades = periodicidad,
                    FormaPagos = formapago,
                    Convenios = convenios
                }), $"dynamic");
            }
            catch (Exception)
            {

                periodicidad = new List<ListaGenerica>();
                convenios = new List<ListaGenerica>();
                formapago = new List<ListaGenerica>();
            }
            return Json(new
            {

                Periodicidades = periodicidad,
                FormaPagos = formapago,
                Convenios = convenios

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GuardarCaratulaAXA(int idConvenio, string poliza, int periodicidad, int formapago, string fechaInicio, string fechaFin)
        {
            bool success = true;
            string message = "";
            try
            {
                if (string.IsNullOrEmpty(poliza))
                {
                    success = false;
                    message = "Debe de ingresar la poliza";
                }
                else
                {

                    var inicio = DateTime.ParseExact(fechaInicio, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    var fin = DateTime.ParseExact(fechaFin, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);

                    //if ((fin - inicio).TotalDays > 31)
                    //{
                    //	success = false;
                    //	message = "El rango de Fechas no debe ser mayor a 31 días";
                    //}

                    if (success)
                    {
                        CatCaratulaAXA _new = new CatCaratulaAXA();
                        _new.IdConvenio = idConvenio;
                        _new.NumeroPoliza = poliza;
                        _new.IdPeriodicidad = periodicidad;
                        _new.IdFormaPago = formapago;
                        _new.FechaInicio = inicio;
                        _new.FechaFin = fin;

                        db.CatCaratulaAXA.Add(_new);
                        db.SaveChanges();
                        message = "Póliza generada correcctamente";

                        CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _new)), $"{_new.GetType()}");
                    }
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message

            }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult EliminaCaratulaAXA(int idCaratula)
        {
            bool success = true;
            string message = "";
            List<CaratulasGNPConvenio> caratulas = new List<CaratulasGNPConvenio>();
            try
            {

                CatCaratulaAXA _saved = db.CatCaratulaAXA.Where(a => a.Id == idCaratula).FirstOrDefault();
                if (_saved != null)
                {

                    db.CatCaratulaAXA.Remove(_saved);
                    db.SaveChanges();
                    message = "Póliza eliminada correcctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _saved)), $"{_saved.GetType()}");

                }
                else
                {
                    success = false;
                    message = "No se encontró la información de la Póliza seleccionada";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region CaratulaOperaAXA

        public JsonResult InicializaCaratulaOperaAXA(int idConvenio)
        {

            List<CatCaratulaOperaAXA> caratulas = new List<CatCaratulaOperaAXA>();
            try
            {

                caratulas = db.CatCaratulaOperaAXA.Where(a => a.IdConvenio == idConvenio).ToList();
            }
            catch (Exception)
            {

                caratulas = new List<CatCaratulaOperaAXA>();
            }
            return Json(new
            {
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult InicializaBancosAseguradora(int idConvenio, int idAseguradora)
        {

            List<CatBancosAseguradoraExclusivo> bancosConvenio = new List<CatBancosAseguradoraExclusivo>();


            var bancosAseguradora = new SelectList((from aseg in db.Aseguradora
                                                    join bsas in db.CatBancosAseguradoras on aseg.Id equals bsas.IdAseguradora
                                                    join banco in db.CatBanco on bsas.IdBanco equals banco.Id
                                                    where bsas.Estatus.Equals(1) && aseg.Id == idAseguradora && aseg.Estatus.Equals(1)
                                                    select banco).ToList(), "Id", "Abreviacion");

            try
            {
                bancosConvenio = ObtenerListaBancosExclusivos(idConvenio);


            }
            catch (Exception)
            {

                bancosConvenio = new List<CatBancosAseguradoraExclusivo>();
            }
            return Json(new
            {
                Exclusivos = bancosConvenio,
                Bancos = bancosAseguradora

            }, JsonRequestBehavior.AllowGet);
        }

        private List<CatBancosAseguradoraExclusivo> ObtenerListaBancosExclusivos(int idConvenio)
        {
            var bancos = db.CatBanco.ToList();
            var bancosConvenio = db.CatBancosAseguradoraExclusivo.Where(a => a.IdConvenio == idConvenio).ToList();
            foreach (var inConvenio in bancosConvenio)
            {
                var cat = bancos.FirstOrDefault(a => a.Id == inConvenio.IdBanco);
                inConvenio.BancoId = cat.BancoId;
                inConvenio.NombreBanco = cat.Nombre;
                inConvenio.Abreviacion = cat.Abreviacion;
            }
            return bancosConvenio;
        }

        public JsonResult EliminaBancoExclusivo(int idConvenio, int idBanco)
        {
            bool success = true;
            string message = "";
            List<CatBancosAseguradoraExclusivo> bancosConvenio = new List<CatBancosAseguradoraExclusivo>();
            try
            {

                CatBancosAseguradoraExclusivo _saved = db.CatBancosAseguradoraExclusivo.Where(a => a.Id == idBanco).FirstOrDefault();
                if (_saved != null)
                {

                    db.CatBancosAseguradoraExclusivo.Remove(_saved);
                    db.SaveChanges();
                    message = "Banco eliminada correcctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _saved)), $"{_saved.GetType()}");

                    bancosConvenio = ObtenerListaBancosExclusivos(idConvenio);
                }
                else
                {
                    success = false;
                    message = "No se encontró la información del Banco seleccionado";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Exclusivos = bancosConvenio,

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GuardarBancoExclusivo(int idConvenio, int idBanco)
        {
            bool success = true;
            string message = "";
            List<CatBancosAseguradoraExclusivo> bancosConvenio = new List<CatBancosAseguradoraExclusivo>();
            try
            {
                var _saved = db.CatBancosAseguradoraExclusivo.Where(a => a.IdConvenio == idConvenio && a.IdBanco == idBanco).FirstOrDefault();
                if (_saved == null)
                {
                    CatBancosAseguradoraExclusivo _new = new CatBancosAseguradoraExclusivo();
                    _new.IdConvenio = idConvenio;
                    _new.IdBanco = idBanco;

                    db.CatBancosAseguradoraExclusivo.Add(_new);
                    db.SaveChanges();
                    message = "Banco exclusivo agregado correctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _new)), $"{_new.GetType()}");

                    bancosConvenio = ObtenerListaBancosExclusivos(idConvenio);
                }
                else
                {
                    success = false;
                    message = "Ya existe el Registro del Banco Seleccionado";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Exclusivos = bancosConvenio,

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GuardarDescuentoEstado(int idConvenio, int idEstado, decimal descuento)
        {
            bool success = true;
            string message = "";

            try
            {
                var _saved = db.ConvenioDescuentoEstado.Where(a => a.IdConvenio == idConvenio && a.IdEstado == idEstado).FirstOrDefault();
                if (_saved == null)
                {
                    var _new = new ConvenioDescuentoEstado();
                    _new.IdConvenio = idConvenio;
                    _new.IdEstado = idEstado;
                    _new.Descuento = descuento;

                    db.ConvenioDescuentoEstado.Add(_new);
                    db.SaveChanges();
                    message = "Descuento agregado correctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _new)), $"{_new.GetType()}");


                }
                else
                {
                    success = false;
                    message = "Ya existe el Registro del Estado Seleccionado";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,


            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult EliminarDescuentoEstado(int id)
        {
            bool success = true;
            string message = "";

            try
            {

                var _saved = db.ConvenioDescuentoEstado.Where(a => a.Id == id).FirstOrDefault();
                if (_saved != null)
                {

                    db.ConvenioDescuentoEstado.Remove(_saved);
                    db.SaveChanges();
                    message = "Descuento eliminado correcctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _saved)), $"{_saved.GetType()}");


                }
                else
                {
                    success = false;
                    message = "No se encontró la información del Banco seleccionado";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,


            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult EliminarCondicionParticular(int id)
        {
            bool success = true;
            string message = "";

            try
            {

                var _saved = db.ConvenioCondicionesParticulares.Where(a => a.Id == id).FirstOrDefault();
                if (_saved != null)
                {

                    db.ConvenioCondicionesParticulares.Remove(_saved);
                    db.SaveChanges();
                    message = "Condición Particular eliminada correcctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _saved)), $"{_saved.GetType()}");


                }
                else
                {
                    success = false;
                    message = "No se encontró información";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,


            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GuardarCondicionParticular(int idConvenio, int id,int? idCobertura, string desc)
        {
            bool success = true;
            string message = "";

            try
            {
                var _saved = db.ConvenioCondicionesParticulares.Where(a => a.IdConvenio == idConvenio && a.Identificador == id ).FirstOrDefault();
                if (_saved == null)
                {
                    var _new = new ConvenioCondicionesParticulares();
                    _new.IdConvenio = idConvenio;
                    _new.Identificador = id;
                    _new.Descripcion = desc;
                    _new.IdCobertura = idCobertura;

                    db.ConvenioCondicionesParticulares.Add(_new);
                    db.SaveChanges();
                    message = "Condición Particular agregada correctamente";

                    //CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _new)), $"{_new.GetType()}");


                }
                else
                {
                    success = false;
                    message = "Ya existe el Registro del identificador ingresado";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,


            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GuardarCaratulaOperaAXA(int idConvenio, string caratula, string fechaInicio, string fechaFin)
        {
            bool success = true;
            string message = "";
            List<CatCaratulaOperaAXA> caratulas = new List<CatCaratulaOperaAXA>();
            try
            {
                if (string.IsNullOrEmpty(caratula))
                {
                    success = false;
                    message = "Debe de ingresar la caratula";
                }
                if (success)
                {


                    CatCaratulaOperaAXA _new = new CatCaratulaOperaAXA();
                    _new.IdConvenio = idConvenio;
                    _new.Caratula = caratula;
                    _new.FechaInicio = DateTime.ParseExact(fechaInicio, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    _new.FechaFin = DateTime.ParseExact(fechaFin, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);


                    db.CatCaratulaOperaAXA.Add(_new);
                    db.SaveChanges();
                    message = "Caratula generada correcctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _new)), $"{_new.GetType()}");

                    caratulas = db.CatCaratulaOperaAXA.Where(a => a.IdConvenio == idConvenio).ToList();

                }
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GuardarRegistroTarifa(string tarifa)
        {
            bool success = true;
            string message = "";

            try
            {
                if (string.IsNullOrEmpty(tarifa))
                {
                    success = false;
                    message = "Debe de ingresar el nombre de la Tarifa";
                }
                if (success)
                {
                    var existe = db.ConvenioTarifa.FirstOrDefault(a => a.Nombre.Trim().ToUpper() == tarifa.Trim().ToUpper());

                    if (existe == null)
                    {
                        ConvenioTarifa _new = new ConvenioTarifa();
                        _new.Nombre = tarifa;
                        _new.FechaCreacion = DateTime.Now;
                        _new.IdUsuarioCreacion = User.Identity.GetUserId();


                        db.ConvenioTarifa.Add(_new);
                        db.SaveChanges();

                        message = "Tarifa generada correcctamente";


                    }
                    else
                    {
                        success = false;
                        message = "Ya existe un registro con el nombre de Tarifa especificado";
                    }
                }
            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,


            }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult EliminaCaratulaOperaAXA(int idConvenio, int idCaratula)
        {
            bool success = true;
            string message = "";
            List<CatCaratulaOperaAXA> caratulas = new List<CatCaratulaOperaAXA>();
            try
            {

                CatCaratulaOperaAXA _saved = db.CatCaratulaOperaAXA.Where(a => a.Id == idCaratula).FirstOrDefault();
                if (_saved != null)
                {

                    db.CatCaratulaOperaAXA.Remove(_saved);
                    db.SaveChanges();
                    message = "Caratula eliminada correcctamente";

                    caratulas = db.CatCaratulaOperaAXA.Where(a => a.IdConvenio == idConvenio).ToList();

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _saved)), $"{_saved.GetType()}");
                }
                else
                {
                    success = false;
                    message = "No se encontró la información de la Caratula seleccionada";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }



        #endregion

        #region CaratulaQUALITAS

        public JsonResult InicializaCaratulaQUALITAS(int idConvenio)
        {
            List<ListaGenerica> meses = new List<ListaGenerica>();
            List<CatCaratulaQUALITAS> caratulas = new List<CatCaratulaQUALITAS>();
            try
            {
                meses = DateTimeFormatInfo.CurrentInfo.MonthNames
                        .Where(p => !string.IsNullOrEmpty(p))
                        .Select((item, index) => new ListaGenerica { Id = index + 1, Nombre = item }).ToList();

                caratulas = db.CatCaratulaQUALITAS.Where(a => a.IdConvenio == idConvenio).OrderBy(a => a.IdMes).ToList();
            }
            catch (Exception)
            {
                meses = new List<ListaGenerica>();
                caratulas = new List<CatCaratulaQUALITAS>();
            }
            return Json(new
            {
                Meses = meses,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GuardarCaratulaQUALITAS(int idConvenio, string mes, int idMes, string fechaInicio, string fechaFin)
        {
            bool success = true;
            string message = "";
            List<CatCaratulaQUALITAS> caratulas = new List<CatCaratulaQUALITAS>();
            try
            {

                CatCaratulaQUALITAS _saved = db.CatCaratulaQUALITAS.Where(a => a.IdConvenio == idConvenio && a.IdMes == idMes).FirstOrDefault();
                if (_saved == null)
                {
                    CatCaratulaQUALITAS _new = new CatCaratulaQUALITAS();
                    _new.IdConvenio = idConvenio;
                    _new.IdMes = idMes;
                    _new.Mes = mes;
                    _new.FechaInicio = DateTime.ParseExact(fechaInicio, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    _new.FechaFin = DateTime.ParseExact(fechaFin, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);

                    db.CatCaratulaQUALITAS.Add(_new);
                    db.SaveChanges();

                    //CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _saved)), $"{_new.GetType()}");

                    message = "Carátula generada correctamente";

                    caratulas = db.CatCaratulaQUALITAS.Where(a => a.IdConvenio == idConvenio).OrderBy(a => a.IdMes).ToList();
                }
                else
                {
                    success = false;
                    message = "Ya existe una caratula para el Tipo de Paquete, Periodicidad y Forma de pago seleccionados";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult EliminaCaratulaQUALITAS(int idConvenio, int idCaratula)
        {
            bool success = true;
            string message = "";
            List<CatCaratulaQUALITAS> caratulas = new List<CatCaratulaQUALITAS>();
            try
            {

                CatCaratulaQUALITAS _saved = db.CatCaratulaQUALITAS.Where(a => a.Id == idCaratula).FirstOrDefault();
                if (_saved != null)
                {

                    db.CatCaratulaQUALITAS.Remove(_saved);
                    db.SaveChanges();
                    message = "Carátula eliminada correctamente";

                    CommonMethods.Audit(MethodBase.GetCurrentMethod().Name, JsonConvert.SerializeObject(CommonMethods.UnProxy(db, _saved)), $"{_saved.GetType()}");

                    caratulas = db.CatCaratulaQUALITAS.Where(a => a.IdConvenio == idConvenio).OrderBy(a => a.IdMes).ToList();
                }
                else
                {
                    success = false;
                    message = "No se encontró la información de la Caratula seleccionada";
                }

            }
            catch (Exception ex)
            {
                success = false;
                message = ex.Message;
            }
            return Json(new
            {
                Success = success,
                Message = message,
                Caratulas = caratulas

            }, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }
}
