﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Bibliography;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.Banorte.Emision;
using LocktonModel.VModels;
using LocktonModel.xmls.GNP.Solicitud;
using LocktonOneWeb.Controllers.Polizas;
using LocktonServicios.DerivacionCore;
using LocktonServicios.OTOperaService;
using log4net;
using Microsoft.Ajax.Utilities;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Web.Hosting;
using System.Web.Http.Results;
using System.Web.Mvc;

namespace LocktonOneWeb.Controllers
{
    public class ReportesProduccionController : Controller
    {
        // GET: Reportes
        private ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger(typeof(PolizasController));

        public ActionResult ReporteEmisionesEnLinea()
        {
            if (!HttpContext.User.IsInRole("Reporte Correos envíos en Linea"))
                return RedirectToAction("Acceso", "ErrorPage");

            // PolizasReporte polizasReporte = new PolizasReporte();
            //falta sacar el drop para seleccion 
            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);
            ViewBag.Gerencia = gerencia;

            return View();
        }

        public ActionResult ReporteInstalacionCobranza()
        {

            if (!HttpContext.User.IsInRole("Reporte de Instalación de Cobranza"))
                return RedirectToAction("Acceso", "ErrorPage");

            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);
            ViewBag.Gerencia = gerencia;


            return View();
        }

        public ActionResult ReporteCobranzaRechazada()
        {
            // PolizasReporte polizasReporte = new PolizasReporte();
            //falta sacar el drop para seleccion 
            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);
            //List<ReportePolizasCobranzaRechazada> reportePolizas = db.ReportePolizasCobranzaRechazada.SqlQuery("sp_reporte_polizas_gerencia_cobranza_rechazada  @gerencia=" + gerencia + "").ToList();
            //ViewBag.Reporte = reportePolizas;
            ViewBag.Gerencia = gerencia;
            //ViewBag.iit = GeneraReporte(reportePolizas);


            return View();
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarCobranzaRechazada(DateTime fechainicio, DateTime fechafin, int idGerencia)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)
                };

            List<ReportePolizasCobranzaRechazada> reportePolizas = db.ReportePolizasCobranzaRechazada.SqlQuery("sp_reporte_polizas_gerencia_cobranza_rechazada  @gerencia, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            var Reportesstring = GeneraReporte(reportePolizas);
            ReportesVM reportes = new ReportesVM();
            reportes.ReportePolizasCobranzaRechazada = reportePolizas.Take(1000).ToList();
            reportes.ReportesString = Reportesstring;
            reportes.NombreArchivo = "Reporte_Polizas_Cobranza_Rechazada" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarInstalacionCobranza(DateTime fechainicio, DateTime fechafin, int idEmpresa)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@IdEmpresa",idEmpresa)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)
                };

            List<sp_reporte_polizas_gerencia_instalacion_cobranza> reportePolizas = db.sp_reporte_polizas_gerencia_instalacion_cobranza.SqlQuery("sp_reporte_polizas_gerencia_instalacion_cobranza  @FechaInicio , @FechaFin , @IdEmpresa ", parameters.ToArray()).ToList();
            var excel = new List<ReporteInstalacionCobranzaVM>();
            foreach (var item in reportePolizas)
            {
                var row = new ReporteInstalacionCobranzaVM();
                row.NumeroPoliza = item.NumeroPoliza;
                row.NumeroEmpleado = item.NumeroEmpleado;
                row.Aseguradora = item.Aseguradora;
                row.Fecha = item.Fecha;
                row.FechaResponse = item.FechaResponse;
                row.SolicitudALaAseguradora = item.Request;
                row.RespuestaDeLaAseguradora = item.Response;
                row.TipoInstalacion = item.TipoOPL;
                row.ResultadoInstalacion = item.ResultadoInstalacion;
                row.Gerencia = row.Gerencia;
                excel.Add(row);
            }

            var Reportesstring = GeneraReporte(excel);
            ReportesVM reportes = new ReportesVM();
            reportes.ExistenRegistros = reportePolizas.Any();
            reportes.RegistrosEncontrados = reportes.ExistenRegistros ? string.Format("Se encontraron {0} registros, puede descargar el excel.", reportePolizas.Count()) : "No se encontrarón registros";
            //reportes.ReporteInstalacionCobranza = reportePolizas.Take(500).ToList();
            reportes.ReportesString = Reportesstring;
            reportes.NombreArchivo = "Reporte_Polizas_Instalacion_Cobranza" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }

        public ActionResult ReporteCalendarioCobranza()
        {


            // PolizasReporte polizasReporte = new PolizasReporte();
            //falta sacar el drop para seleccion 
            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);
            string usuario = User.Identity.GetUserId();
            DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();


            var empresas = (from empre in db.Empresa

                            join DUE in db.DetalleUsuarioEmpresa on detalleUsuario.Id equals DUE.IdDetalleUsuario
                            join CORP in db.Corporativo on empre.IdCorporativo equals CORP.Id
                            where empre.Estatus == 1 && empre.Id != 1 && DUE.IdEmpresa == empre.Id && CORP.Estatus && DUE.Estatus == true
                            select new
                            {
                                Id = empre.IdGerenciaCORE,
                                empre.ClaveEmpresa,
                                empre.RazonSocial,
                                RazonClave = empre.RazonSocial + " - " + empre.ClaveEmpresa,
                                IdCorporativo = CORP.Id,
                                NombreCorporativo = CORP.Nombre
                            }).ToList();
            if (detalleUsuario.IdPerfil == 6 || detalleUsuario.IdPerfil == 1)
            {
                empresas = (from empre in db.Empresa

                            join CORP in db.Corporativo on empre.IdCorporativo equals CORP.Id
                            where empre.Estatus == 1 && empre.Id != 1 && CORP.Estatus
                            select new
                            {
                                Id = empre.IdGerenciaCORE,
                                empre.ClaveEmpresa,
                                empre.RazonSocial,
                                RazonClave = empre.RazonSocial + " - " + empre.ClaveEmpresa,
                                IdCorporativo = CORP.Id,
                                NombreCorporativo = CORP.Nombre
                            }).ToList();
            }
            var corporativosDistintos = empresas
    .Select(e => new
    {
        IdCorporativo = e.IdCorporativo,
        NombreCorporativo = e.NombreCorporativo
    })
    .Distinct()
    .ToList();
            // Crear el SelectList para usar en el DropDownList
            ViewBag.IdCorporativo = new SelectList(corporativosDistintos, "IdCorporativo", "NombreCorporativo");
            ViewBag.IdEmpresa = new SelectList(empresas, "Id", "RazonClave", idEmpresa);
            ViewBag.Gerencia = gerencia;

            return View();
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReporteCalendarioCobranza( List<int> IdEmpresas, int IdCorporativo, bool todos)
        {
            string usuario = User.Identity.GetUserId();
            DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();
            bool soloCorporativo = true;
            string LEmpresas = IdEmpresas != null && IdEmpresas.Count() > 0 ? string.Join(";", IdEmpresas.ToArray()) : "";
            if (!string.IsNullOrEmpty(LEmpresas))
                soloCorporativo = false;
            else
            {
                var perfilesPermitidos = new int[] { 1, 6 };
                if (!perfilesPermitidos.Contains(detalleUsuario.IdPerfil))
                {
                    soloCorporativo = false;
                    // El usuario tiene un perfil restringido, obtenemos sus empresas asignadas.
                    List<string> listaEmpresasFiltradas = db.Empresa
                        .Where(C => C.IdCorporativo == IdCorporativo && C.Estatus == 1)
                        .Join(db.DetalleUsuarioEmpresa,
                              empresa => empresa.Id,
                              due => due.IdEmpresa,
                              (empresa, due) => new { Empresa = empresa, DetalleUsuarioEmpresa = due })
                        .Where(j => j.DetalleUsuarioEmpresa.IdDetalleUsuario == detalleUsuario.Id && j.DetalleUsuarioEmpresa.Estatus == true)
                        .Select(j => j.Empresa.IdGerenciaCORE)
                        .ToList();

                    // Construimos la cadena de empresas a partir de la lista filtrada.
                    LEmpresas = string.Join(";", listaEmpresasFiltradas.ToArray());

                }
            }

            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",LEmpresas)
                    ,new SqlParameter("@Todos",todos)              
                    ,new SqlParameter("@soloCorporativo",soloCorporativo)
                    ,new SqlParameter("@IdCorporativo",IdCorporativo)
                };
            List<sp_CALENDARIOCOBRANZA_REPORTE> reportePolizas = new List<sp_CALENDARIOCOBRANZA_REPORTE>();
            var resultpolizas = db.sp_CALENDARIOCOBRANZA_REPORTE.SqlQuery("sp_CALENDARIOCOBRANZA_REPORTE  @gerencia , @soloCorporativo, @IdCorporativo, @Todos ", parameters.ToArray()).ToList();

        


            //ViewBag.Reporte = reportePolizas;

            var ReportesPolizasString = GeneraReporte(resultpolizas);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteCalendarioCobranza = resultpolizas.Take(1000).ToList();
            reportes.ReportesString = ReportesPolizasString;
            reportes.NombreArchivo = "Reporte_CalendarioCobranza" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }

        public ActionResult ReportePolizas()
        {

            if (!HttpContext.User.IsInRole("Reporte de Polizas"))
                return RedirectToAction("Acceso", "ErrorPage");

            // PolizasReporte polizasReporte = new PolizasReporte();
            //falta sacar el drop para seleccion 
            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);
            string usuario = User.Identity.GetUserId();
            DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();


            var empresas = (from empre in db.Empresa

                            join DUE in db.DetalleUsuarioEmpresa on detalleUsuario.Id equals DUE.IdDetalleUsuario
                            join CORP in db.Corporativo on empre.IdCorporativo equals CORP.Id
                            where empre.Estatus == 1 && empre.Id != 1 && DUE.IdEmpresa == empre.Id && CORP.Estatus && DUE.Estatus == true
                            select new
                            {
                                Id = empre.IdGerenciaCORE,
                                empre.ClaveEmpresa,
                                empre.RazonSocial,
                                RazonClave = empre.RazonSocial + " - " + empre.ClaveEmpresa,
                                IdCorporativo = CORP.Id,
                                NombreCorporativo = CORP.Nombre
                            }).ToList();
            if (detalleUsuario.IdPerfil == 6 || detalleUsuario.IdPerfil == 1)
            {
                empresas = (from empre in db.Empresa

                            join CORP in db.Corporativo on empre.IdCorporativo equals CORP.Id
                            where empre.Estatus == 1 && empre.Id != 1 && CORP.Estatus
                            select new
                            {
                                Id = empre.IdGerenciaCORE,
                                empre.ClaveEmpresa,
                                empre.RazonSocial,
                                RazonClave = empre.RazonSocial + " - " + empre.ClaveEmpresa,
                                IdCorporativo = CORP.Id,
                                NombreCorporativo = CORP.Nombre
                            }).ToList();
            }
            var corporativosDistintos = empresas
    .Select(e => new
    {
        IdCorporativo = e.IdCorporativo,
        NombreCorporativo = e.NombreCorporativo
    })
    .Distinct()
    .ToList();
            // Crear el SelectList para usar en el DropDownList
            ViewBag.IdCorporativo = new SelectList(corporativosDistintos, "IdCorporativo", "NombreCorporativo");
            ViewBag.IdEmpresa = new SelectList(empresas, "Id", "RazonClave", idEmpresa);
            ViewBag.Gerencia = gerencia;

            return View();
        }

        public ActionResult ReporteRecibosPolizas()
        {

            if (!HttpContext.User.IsInRole("Reporte Recibos de Polizas"))
                return RedirectToAction("Acceso", "ErrorPage");

            // PolizasReporte polizasReporte = new PolizasReporte();
            //falta sacar el drop para seleccion 
            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);
            ViewBag.Gerencia = gerencia;

            return View();
        }


        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesPolizas(DateTime fechainicio, DateTime fechafin, List<int> IdEmpresas, int IdCorporativo)
        {
            string usuario = User.Identity.GetUserId();
            DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();
            bool soloCorporativo = true;
            string LEmpresas = IdEmpresas != null && IdEmpresas.Count() > 0 ? string.Join(";", IdEmpresas.ToArray()) : "";
            if (!string.IsNullOrEmpty(LEmpresas))
                soloCorporativo = false;
            else
            {
                var perfilesPermitidos = new int[] { 1, 6 };
                if (!perfilesPermitidos.Contains(detalleUsuario.IdPerfil))
                {
                    soloCorporativo = false;
                    // El usuario tiene un perfil restringido, obtenemos sus empresas asignadas.
                    List<string> listaEmpresasFiltradas = db.Empresa
                        .Where(C => C.IdCorporativo == IdCorporativo && C.Estatus == 1)
                        .Join(db.DetalleUsuarioEmpresa,
                              empresa => empresa.Id,
                              due => due.IdEmpresa,
                              (empresa, due) => new { Empresa = empresa, DetalleUsuarioEmpresa = due })
                        .Where(j => j.DetalleUsuarioEmpresa.IdDetalleUsuario == detalleUsuario.Id && j.DetalleUsuarioEmpresa.Estatus == true)
                        .Select(j => j.Empresa.IdGerenciaCORE)
                        .ToList();

                    // Construimos la cadena de empresas a partir de la lista filtrada.
                    LEmpresas = string.Join(";", listaEmpresasFiltradas.ToArray());

                }
            }

            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",LEmpresas)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)
                    ,new SqlParameter("@soloCorporativo",soloCorporativo)
                    ,new SqlParameter("@IdCorporativo",IdCorporativo)
                };
            List<ReportePolizas> reportePolizas = new List<ReportePolizas>();
            var resultpolizas = db.ReportePolizas.SqlQuery("sp_reporte_polizas_gerencia  @gerencia , @FechaInicio , @FechaFin, @soloCorporativo, @IdCorporativo ", parameters.ToArray()).ToList();
            foreach (var item in resultpolizas)
            {
                string estatus = "";
                string SolicitudCancelacion = "";
                SqlParameter sqldocumento = new SqlParameter("@Documento", item.NumeroPoliza);
                var tieneSolicitudCancelacion = db.DataEndosoCancelationDocument.SqlQuery("DataEndosoCancelationDocument @Documento", sqldocumento).FirstOrDefault();
                if (tieneSolicitudCancelacion != null)
                {
                    var statusEndoso = "";
                    if (tieneSolicitudCancelacion.Status == 1) { statusEndoso = "Cancelado"; } else { statusEndoso = "Vigente"; }
                    if (tieneSolicitudCancelacion.TipoDocumento == 0)
                    {
                        SolicitudCancelacion = "OT de Cancelación: " + tieneSolicitudCancelacion.OrdenTrabajo + ", Estatus: " + statusEndoso;
                    }
                    else if (tieneSolicitudCancelacion.TipoDocumento == 0)
                    {
                        SolicitudCancelacion = "Endoso de Cancelación: " + tieneSolicitudCancelacion.NumeroEndoso + ", Estatus: " + statusEndoso;
                    }

                }
                else
                {
                    SolicitudCancelacion = "";
                }

                var _parameter = new List<SqlParameter>()
                {
                    new SqlParameter("@Documento",item.NumeroPoliza)
                    ,new SqlParameter("@IdGerencia",LEmpresas)
                };
                var canceladoPorCobranza = db.Database.SqlQuery<string>("sp_consultar_estatusCobranza @Documento, @IdGerencia", _parameter.ToArray()).FirstOrDefault();
                if (!string.IsNullOrEmpty(canceladoPorCobranza))
                {
                    estatus = canceladoPorCobranza;
                }
                else
                {
                    estatus = item.Estatus;
                }

                reportePolizas.Add(new ReportePolizas
                {
                    Identificador = item.Identificador,
                    Gerencia = item.Gerencia,
                    NumeroPoliza = item.NumeroPoliza,
                    Forma_pago = item.Forma_pago,
                    Medio_pago = item.Medio_pago,
                    Aseguradora = item.Aseguradora,
                    fecha_inicio = item.fecha_inicio,
                    fecha_fin = item.fecha_fin,
                    FechaCaptura = item.FechaCaptura,
                    PrimaNeta = item.PrimaNeta,
                    PrimaTotal = item.PrimaTotal,
                    IVA = item.IVA,
                    Derechos = item.Derechos,
                    TipoVenta = item.TipoVenta,
                    ClaveVehicular = item.ClaveVehicular,
                    Marca = item.Marca,
                    Version = item.Version,
                    Modelo = item.Modelo,
                    Motor = item.Motor,
                    Serie = item.Serie,
                    Placas = item.Placas,
                    NombreEmpleado = item.NombreEmpleado,
                    Numero_empleado = item.Numero_empleado,
                    Correo = item.Correo,
                    Conductor_Habitual = item.Conductor_Habitual,
                    Estatus = estatus,
                    OTCancelacion = SolicitudCancelacion,
                    Paquete = item.Paquete,
                    PaqueteRenombrado = item.PaqueteRenombrado,
                    UserNameEmite = item.UserNameEmite,
                    Referencia1 = item.Referencia1,
                    Referencia2 = item.Referencia2,
                    Referencia3 = item.Referencia3,
                    Referencia4 = item.Referencia4,
                    // CAT Renovación automática: conserva el estado retornado por el procedimiento para el Excel.
                    Renovacion_Automatica = item.Renovacion_Automatica,
                    Notas = item.Notas,
                    EstatusUsuario = item.EstatusUsuario,
                    MSI = item.MSI,
                    Ciudad = item.Ciudad,
                    Estado = item.Estado,
                    CodigoPostalCotizacion = item.CodigoPostalCotizacion,
                    CodigoPostalEmision = item.CodigoPostalEmision,
                    Producto = item.Producto,
                    SubProducto = item.SubProducto,
                    //TipoVehiculo = item.TipoVehiculo,
                    CoberturaAdicional = item.CoberturaAdicional,
                    BeneficiarioPreferente = item.BeneficiarioPreferente,
                    TipoSumaAsegurada = item.TipoSumaAsegurada,
                    Tipo = item.Tipo,
                    FechaFactura = item.FechaFactura,
                    ValorVehiculo = item.ValorVehiculo,
                    NoFactura = item.NoFactura
                });
            }


            //ViewBag.Reporte = reportePolizas;

            var ReportesPolizasString = GeneraReporte(reportePolizas);
            ReportesVM reportes = new ReportesVM();
            reportes.ReportePolizas = reportePolizas.Take(1000).ToList();
            reportes.ReportesString = ReportesPolizasString;
            reportes.NombreArchivo = "Reporte_Polizas" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }

        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesRecibosPolizas(DateTime fechainicio, DateTime fechafin, int idGerencia)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)
                };
            List<ReporteReciboPoliza> reportePolizas = new List<ReporteReciboPoliza>();
            var resultpolizas = db.ReporteReciboPoliza.SqlQuery("sp_reporte_recibospolizas_gerencia  @gerencia , @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            foreach (var item in resultpolizas)
            {
                string estatus = "";
                string SolicitudCancelacion = "";
                SqlParameter sqldocumento = new SqlParameter("@Documento", item.NumeroPoliza);
                var tieneSolicitudCancelacion = db.DataEndosoCancelationDocument.SqlQuery("DataEndosoCancelationDocument @Documento", sqldocumento).FirstOrDefault();
                if (tieneSolicitudCancelacion != null)
                {
                    var statusEndoso = "";
                    if (tieneSolicitudCancelacion.Status == 1) { statusEndoso = "Cancelado"; } else { statusEndoso = "Vigente"; }
                    if (tieneSolicitudCancelacion.TipoDocumento == 0)
                    {
                        SolicitudCancelacion = "OT de Cancelación: " + tieneSolicitudCancelacion.OrdenTrabajo + ", Estatus: " + statusEndoso;
                    }
                    else if (tieneSolicitudCancelacion.TipoDocumento == 0)
                    {
                        SolicitudCancelacion = "Endoso de Cancelación: " + tieneSolicitudCancelacion.NumeroEndoso + ", Estatus: " + statusEndoso;
                    }

                }
                else
                {
                    SolicitudCancelacion = "";
                }

                var _parameter = new List<SqlParameter>()
                {
                    new SqlParameter("@Documento",item.NumeroPoliza)
                    ,new SqlParameter("@IdGerencia",idGerencia)
                };
                var canceladoPorCobranza = db.Database.SqlQuery<string>("sp_consultar_estatusCobranza @Documento, @IdGerencia", _parameter.ToArray()).FirstOrDefault();
                if (!string.IsNullOrEmpty(canceladoPorCobranza))
                {
                    estatus = canceladoPorCobranza;
                }
                else
                {
                    estatus = item.Estatus;
                }

                reportePolizas.Add(new ReporteReciboPoliza
                {
                    Identificador = item.Identificador,
                    Gerencia = item.Gerencia,
                    NumeroPoliza = item.NumeroPoliza,
                    Forma_pago = item.Forma_pago,
                    Medio_pago = item.Medio_pago,
                    Aseguradora = item.Aseguradora,
                    fecha_inicio = item.fecha_inicio,
                    fecha_fin = item.fecha_fin,
                    FechaCaptura = item.FechaCaptura,
                    PrimaNeta = item.PrimaNeta,
                    PrimaTotal = item.PrimaTotal,
                    IVA = item.IVA,
                    Derechos = item.Derechos,
                    TipoVenta = item.TipoVenta,
                    ClaveVehicular = item.ClaveVehicular,
                    Marca = item.Marca,
                    Version = item.Version,
                    Modelo = item.Modelo,
                    Motor = item.Motor,
                    Serie = item.Serie,
                    Placas = item.Placas,
                    NombreEmpleado = item.NombreEmpleado,
                    Numero_empleado = item.Numero_empleado,
                    Correo = item.Correo,
                    Conductor_Habitual = item.Conductor_Habitual,
                    Estatus = estatus,
                    OTCancelacion = SolicitudCancelacion,
                    Paquete = item.Paquete,
                    PaqueteRenombrado = item.PaqueteRenombrado,
                    UserNameEmite = item.UserNameEmite,
                    Referencia1 = item.Referencia1,
                    Referencia2 = item.Referencia2,
                    Referencia3 = item.Referencia3,
                    Referencia4 = item.Referencia4,
                    Notas = item.Notas,
                    EstatusUsuario = item.EstatusUsuario,
                    MSI = item.MSI,
                    Ciudad = item.Ciudad,
                    Estado = item.Estado,
                    Producto = item.Producto,
                    NumeroRecibo = item.NumeroRecibo,
                    ReciboInicioVigencia = item.ReciboInicioVigencia,
                    ReciboFinVigencia = item.ReciboFinVigencia,
                    ReciboPrimaNeta = item.ReciboPrimaNeta ?? 0,
                    ReciboPrimaTotal = item.ReciboPrimaTotal ?? 0,
                    ReciboComision = item.ReciboComision ?? 0,
                    ReciboDerecho = item.ReciboDerecho ?? 0,
                    ReciboImpuesto = item.ReciboImpuesto ?? 0,
                    ReciboRecargo = item.ReciboRecargo ?? 0
                });
            }


            //ViewBag.Reporte = reportePolizas;

            var ReportesPolizasString = GeneraReporte(reportePolizas);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteReciboPoliza = reportePolizas.Take(1000).ToList();
            reportes.ReportesString = ReportesPolizasString;
            reportes.NombreArchivo = "Reporte_RecibosPolizas" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        public ActionResult ReportePolizasDXN()
        {
            if (!HttpContext.User.IsInRole("Reporte Pólizas DXN"))
                return RedirectToAction("Acceso", "ErrorPage");

            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa && x.Estatus == 1).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa && x.Estatus == 1).FirstOrDefault().IdGerenciaCORE);
            ViewBag.Gerencia = gerencia;
            return View();
        }
        //Reporte de pólizas DXN
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesPolizasDXN(DateTime fechainicio, int idGerencia, bool Esgeneral)
        {
            List<SP_GetDocumentosGerenciaDXN> reportePolizas = new List<SP_GetDocumentosGerenciaDXN>();
            List<SP_GetDocumentosGerenciaDXN> reportePolizasCRecibos = new List<SP_GetDocumentosGerenciaDXN>();
            if (Esgeneral)
            {
                SqlParameter _gerenciaParameter = new SqlParameter("@gerencia", idGerencia);
                reportePolizas = db.SP_GetDocumentosGerenciaDXN.SqlQuery("SP_GetDocumentosGerenciaDXN  @gerencia ", _gerenciaParameter).ToList();
            }
            else
            {
                var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaIni",fechainicio)
                };

                reportePolizas = db.SP_GetDocumentosGerenciaDXN.SqlQuery("SP_GetDocumentosGerenciaDXN  @gerencia , @FechaIni ", parameters.ToArray()).ToList();
            }

            foreach (var item in reportePolizas)
            {
                SqlParameter _numeroPoliza = new SqlParameter("@Poliza", item.Documento);
                List<sp_POLIZA_Recibos> sp_POLIZA_Recibos = db.sp_POLIZA_Recibos.SqlQuery("sp_POLIZA_Recibos @Poliza", _numeroPoliza).ToList();
                if (sp_POLIZA_Recibos != null)
                    sp_POLIZA_Recibos = sp_POLIZA_Recibos.OrderBy(x => x.Serie).ToList();
                int CountNRe = 1;
                foreach (var recibos in sp_POLIZA_Recibos)
                {
                    if (CountNRe == 1)
                        item.PrimerRecibo = Convert.ToDecimal(recibos.PrimaTotal);
                    else if (CountNRe == 2)
                    {
                        item.SegundoRecibo = Convert.ToDecimal(recibos.PrimaTotal);
                        break;
                    }
                    CountNRe++;
                }
                reportePolizasCRecibos.Add(item);
            }
            var Reportesstring = GeneraReporte(reportePolizasCRecibos);
            ReportesVM reportes = new ReportesVM();
            reportes.ReportePolizasDXN = reportePolizasCRecibos.Take(1000).ToList();
            reportes.ReportesString = Reportesstring;
            reportes.NombreArchivo = "Reporte_PolizasDXN" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        //busca pólizas emitidas en línea
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesPolizasEmitidasEnLinea(DateTime fechainicio, DateTime fechafin, int idGerencia)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };
            List<ReporteEmisionesEnLinea> ReporteEmisionesEnLinea = new List<ReporteEmisionesEnLinea>();
            var resultpolizasEmisonesEnLinea = db.ReporteEmisionesEnLinea.SqlQuery("sp_reporte_polizas_Emitidas_Linea_gerencia  @gerencia, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            foreach (var item in resultpolizasEmisonesEnLinea)
            {

                ReporteEmisionesEnLinea.Add(new ReporteEmisionesEnLinea
                {
                    Identificador = item.Identificador,
                    Gerencia = item.Gerencia,
                    NumeroPoliza = item.NumeroPoliza,
                    Aseguradora = item.Aseguradora,
                    FechaCaptura = item.FechaCaptura,
                    Correo_Enviado_A = item.Correo_Enviado_A,
                    UserNameEmite = item.UserNameEmite,
                    Telefono1 = item.Telefono1,
                    Telefono2 = item.Telefono2,
                    EmpresaUSR = item.EmpresaUSR,
                    NombreUSRQueCotizo = item.NombreUSRQueCotizo,
                    // CAT Renovación automática: conserva el estado retornado por el procedimiento para el Excel.
                    Renovacion_Automatica = item.Renovacion_Automatica
                });
            }


            //ViewBag.Reporte = reportePolizas;

            var ReportesEmisionesEnLineaString = GeneraReporte(ReporteEmisionesEnLinea);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteEmisionesEnLinea = ReporteEmisionesEnLinea.Take(1000).ToList();
            reportes.ReportesString = ReportesEmisionesEnLineaString;
            reportes.NombreArchivo = "Reporte_EmisionesEnLinea" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        public ActionResult ReporteUsuarios()
        {
            if (!HttpContext.User.IsInRole("Reporte de Usuarios"))
                return RedirectToAction("Acceso", "ErrorPage");


            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa && x.Estatus == 1).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa && x.Estatus == 1).FirstOrDefault().IdGerenciaCORE);
            ViewBag.Gerencia = gerencia;
            return View();
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesUsuarios(DateTime fechainicio, DateTime fechafin, int idGerencia, bool Esgeneral)
        {
            List<ReporteUsuarios> reporteUsuarios = new List<ReporteUsuarios>();
            if (Esgeneral)
            {
                SqlParameter sqldocumento = new SqlParameter("@gerencia", idGerencia);
                reporteUsuarios = db.ReporteUsuarios.SqlQuery("sp_reporte_usuarios_gerencia @gerencia", sqldocumento).ToList();
            }
            else
            {
                var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };
                reporteUsuarios = db.ReporteUsuarios.SqlQuery("sp_reporte_usuarios_gerencia @gerencia, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            }
            var Reportesstring = GeneraReporte(reporteUsuarios);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteUsuarios = reporteUsuarios.Take(1000).ToList();
            reportes.ReportesString = Reportesstring;
            reportes.NombreArchivo = "Reporte_Usuarios" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        public ActionResult ReporteDiscrepancias()
        {
            if (!HttpContext.User.IsInRole("Consulta de discrepancias"))
                return RedirectToAction("Acceso", "ErrorPage");

            ViewBag.Grupos = new SelectList(db.Corporativo.Where(a => a.Estatus), "Id", "Nombre");
            return View();
        }

        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesDiscrepancia(DateTime fechainicio, DateTime fechafin, int? idAsguradora, int? idEmpresa, string numeroPoliza)
        {

            var ni = "null";

            if (idEmpresa.HasValue)
                ni = idEmpresa.ToString();

            var na = "null";
            if (idAsguradora.HasValue)
                na = idAsguradora.ToString();

            List<sp_reporte_discrepancias> reportePolizas = new List<sp_reporte_discrepancias>();
            reportePolizas = db.sp_reporte_discrepancias.SqlQuery($"sp_reporte_discrepancias  @FechaInicio = '{fechainicio.ToString("yyyy-MM-dd")}', @FechaFin='{fechafin.ToString("yyyy-MM-dd")}', @NumeroPoliza='{numeroPoliza}', @IdEmpresa={ni}, @IdAseguradora={na} ").ToList();




            //ViewBag.Reporte = reportePolizas;

            var ReportesPolizasString = GeneraReporte(reportePolizas);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteDiscrepancias = reportePolizas.Take(1000).ToList();
            reportes.ReportesString = ReportesPolizasString;
            reportes.NombreArchivo = "Reporte_Discrepancias" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }


        public ActionResult ReporteEstatusPolizas()
        {
            if (!HttpContext.User.IsInRole("Reporte Estatus Polizas"))
                return RedirectToAction("Acceso", "ErrorPage");

            ViewBag.Grupos = new SelectList(db.Corporativo.Where(a => a.Estatus), "Id", "Nombre");
            return View();
        }

        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesEstatusPolizas(DateTime fechainicio, DateTime fechafin, int? idAsguradora, int? idEmpresa, string numeroPoliza)
        {

            var ni = "null";

            if (idEmpresa.HasValue)
                ni = idEmpresa.ToString();

            var na = "null";
            if (idAsguradora.HasValue)
                na = idAsguradora.ToString();

            List<sp_reporte_cambioestatuspoliza> reportePolizas = new List<sp_reporte_cambioestatuspoliza>();
            reportePolizas = db.sp_reporte_cambioestatuspoliza.SqlQuery($"sp_reporte_cambioestatuspoliza  @FechaInicio = '{fechainicio.ToString("yyyy-MM-dd")}', @FechaFin='{fechafin.ToString("yyyy-MM-dd")}', @NumeroPoliza='{numeroPoliza}', @IdEmpresa={ni}, @IdAseguradora={na} ").ToList();




            //ViewBag.Reporte = reportePolizas;

            var ReportesPolizasString = GeneraReporte(reportePolizas);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteEstatusPolizas = reportePolizas.Take(1000).ToList();
            reportes.ReportesString = ReportesPolizasString;
            reportes.NombreArchivo = "Reporte_EstatusPoliza" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }




        public ActionResult ReporteEstatusRecibos()
        {
            if (!HttpContext.User.IsInRole("Reporte Estatus Recibos"))
                return RedirectToAction("Acceso", "ErrorPage");

            ViewBag.Grupos = new SelectList(db.Corporativo.Where(a => a.Estatus), "Id", "Nombre");
            return View();
        }

        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesEstatusRecibos(DateTime fechainicio, DateTime fechafin, int? idAsguradora, int? idEmpresa, string numeroPoliza)
        {

            var ni = "null";

            if (idEmpresa.HasValue)
                ni = idEmpresa.ToString();

            var na = "null";
            if (idAsguradora.HasValue)
                na = idAsguradora.ToString();

            List<sp_reporte_cambioestatusrecibo> reportePolizas = new List<sp_reporte_cambioestatusrecibo>();
            reportePolizas = db.sp_reporte_cambioestatusrecibo.SqlQuery($"sp_reporte_cambioestatusrecibo  @FechaInicio = '{fechainicio.ToString("yyyy-MM-dd")}', @FechaFin='{fechafin.ToString("yyyy-MM-dd")}', @NumeroPoliza='{numeroPoliza}', @IdEmpresa={ni}, @IdAseguradora={na} ").ToList();




            //ViewBag.Reporte = reportePolizas;

            var ReportesPolizasString = GeneraReporte(reportePolizas);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteEstatusRecibos = reportePolizas.Take(1000).ToList();
            reportes.ReportesString = ReportesPolizasString;
            reportes.NombreArchivo = "Reporte_EstatusRecibos" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }



        public ActionResult ReporteEndosos()
        {
            if (!HttpContext.User.IsInRole("Reporte de Endosos"))
                return RedirectToAction("Acceso", "ErrorPage");

            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);

            ViewBag.Gerencia = gerencia;
            return View();
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesEndosos(DateTime fechainicio, DateTime fechafin, int idGerencia)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };
            List<ReporteEndosos> reporteEndosos = db.ReporteEndosos.SqlQuery("sp_reporte_endosos_gerencia @gerencia, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            var Reportesstring = GeneraReporte(reporteEndosos);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteEndosos = reporteEndosos.Take(1000).ToList();
            reportes.ReportesString = Reportesstring;
            reportes.NombreArchivo = "Reporte_Endosos" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }

        public ActionResult ReporteCondicionesGenerales()
        {
            if (!HttpContext.User.IsInRole("Reporte de Condiciones Generales"))
                return RedirectToAction("Acceso", "ErrorPage");

            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);

            ViewBag.Gerencia = gerencia;
            return View();
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReporteCondicionesGenerales(DateTime fechainicio, DateTime fechafin, int idGerencia)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };

            var reporteCotizaciones = db.sp_GET_CondicionGeneralBitacora.SqlQuery("sp_GET_CondicionGeneralBitacora @gerencia, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            var Reportesstring = GeneraReporte(reporteCotizaciones);

            ReportesVM reportes = new ReportesVM();
            reportes.ReporteCondicionesGenerales = reporteCotizaciones.Take(1000).ToList();
            reportes.ReportesString = Reportesstring;
            reportes.NombreArchivo = "Reporte_CondicionesGenerales" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }

        public ActionResult ReporteCotizaciones()
        {
            if (!HttpContext.User.IsInRole("Reporte de Cotizaciones"))
                return RedirectToAction("Acceso", "ErrorPage");

            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);

            ViewBag.Gerencia = gerencia;
            return View();
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesCotizaciones(DateTime fechainicio, DateTime fechafin, int idGerencia)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };

            List<ReporteCotizaciones> reporteCotizaciones = db.ReporteCotizaciones.SqlQuery("sp_reporte_COTIZACIONES_gerencia @gerencia, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            var Reportesstring = GeneraReporte(reporteCotizaciones);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteCotizaciones = reporteCotizaciones.Take(1000).ToList();
            reportes.ReportesString = Reportesstring;
            reportes.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }

        public ActionResult ReporteCotizacionesMascotas()
        {
            if (!HttpContext.User.IsInRole("Reporte de Cotizaciones Mascotas"))
                return RedirectToAction("Acceso", "ErrorPage");

            int idEmpresa = (int)Session["EmpresaAdmin"];
            int gerencia = string.IsNullOrEmpty(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE) ? 0 : int.Parse(db.Empresa.Where(x => x.Id == idEmpresa).FirstOrDefault().IdGerenciaCORE);

            ViewBag.Gerencia = gerencia;
            return View();
        }

        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesCotizacionesMascotas(DateTime fechainicio, DateTime fechafin, int idGerencia)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@gerencia",idGerencia)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };

            List<sp_reporte_cotizacionesMascotas_gerencia> reporteCotizaciones = db.sp_reporte_cotizacionesMascotas_gerencia.SqlQuery("sp_reporte_cotizacionesMascotas_gerencia @gerencia, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            var Reportesstring = GeneraReporte(reporteCotizaciones);
            ReportesVM reportes = new ReportesVM();
            reportes.ReporteCotizacionesMascotas = reporteCotizaciones.Take(1000).ToList();
            reportes.ReportesString = Reportesstring;
            reportes.NombreArchivo = "Reporte_CotizacionesMascotas" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }

        public string GeneraReporte<T>(List<T> reporte)
        {
            Type elementType = typeof(T);
            DataSet ds = new DataSet();
            DataTable t1 = new DataTable();
            ds.Tables.Add(t1);

            //Agrega Nombre de las columnas
            foreach (PropertyInfo elemento in elementType.GetProperties())
            {
                Type ColType = Nullable.GetUnderlyingType(elemento.PropertyType) ?? elemento.PropertyType;
                if (!elemento.Name.Contains("1_"))
                {
                    t1.Columns.Add(elemento.Name, ColType);
                }

            }
            //contenido de las columnas
            foreach (T valor in reporte)
            {
                DataRow row = t1.NewRow();

                foreach (PropertyInfo propInfo in elementType.GetProperties())
                {
                    if (!propInfo.Name.Contains("1_"))
                    {
                        row[propInfo.Name] = propInfo.GetValue(valor, null) ?? DBNull.Value;
                    }
                }

                t1.Rows.Add(row);
            }

            Type tipo = reporte.GetType();

            string t = tipo.FullName;
            XLWorkbook book = new XLWorkbook();
            // var hoja = book.Worksheets.Add("Reporte");
            IXLWorksheet worksheet;
            int item2 = t.ToLower().Contains("poliza") ? 1 : t.ToLower().Contains("usuario") ? 2 : t.ToLower().Contains("endoso") ? 3 : t.ToLower().Contains("cotizacion") ? 4 : t.ToLower().Contains("reporteemisionesenlinea") ? 5 : t.ToLower().Contains("leadscorrectos") ? 6 : t.ToLower().Contains("leadsemisiones") ? 7 : t.ToLower().Contains("leadscorrectoscasa") ? 8 : t.ToLower().Contains("leadsemisionescasa") ? 9 : t.ToLower().Contains("obtenerxmls_autos") ? 10 : t.ToLower().Contains("obtenerxmls_casa") ? 11 : 0;

            //HeaderUsuarios headerU = new HeaderUsuarios();
            //List<HeaderUsuarios> EncabezadoU = new List<HeaderUsuarios>();
            //  EncabezadoU.Add(headerU);
            //hoja.Cells("A3:J3").Style.Fill.BackgroundColor = XLColor.MidnightBlue;
            //hoja.Cells("A3:J3").Style.Font.FontColor = XLColor.White;
            //hoja.Row(1).Height = 45;
            ////hoja.Range("B1:I1").Merge();
            //hoja.Cells("B1").Style.Font.FontSize = 24;
            //hoja.Cell(3,1).InsertData(EncabezadoU);
            switch (item2)
            {
                case 1:

                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_Polizas");
                    //ViewBag.NombreArchivo = "Reporte_Polizas" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 2:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_Usuarios");
                    //ViewBag.NombreArchivo = "Reporte_Usuarios" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 3:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_Endosos");
                    //ViewBag.NombreArchivo = "Reporte_Endosos" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 4:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_Cotizaciones");
                    //ViewBag.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 5:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_EmisionesEnLinea");
                    //ViewBag.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 6:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_LeadsCorrectos");
                    //ViewBag.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 7:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_Emisiones");
                    //ViewBag.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 8:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_LeadsCorrectosCasa");
                    //ViewBag.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 9:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_LeadsEmisionesCasa");
                    //ViewBag.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 10:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_XMLS_Autos");
                    //ViewBag.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                case 11:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte_XMLS_Casa");
                    //ViewBag.NombreArchivo = "Reporte_Cotizaciones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
                    //worksheet.Row(1).InsertRowsAbove(1);
                    break;
                default:
                    worksheet = book.Worksheets.Add(ds.Tables[0], "Reporte");
                    break;

            }
            // hoja.Cell(4, 1).InsertData(ds.Tables[0]);
            //hoja.Cell(4, 1).InsertData(reporte);
            //hoja.Cell(4,1).Style.Alignment.WrapText = true;
            System.IO.MemoryStream memory = new System.IO.MemoryStream();
            book.SaveAs(memory);
            //  Session["datosEditorHtml"] = Encoding.ASCII.GetString(memory.ToArray());
            string DocumentoBase64 = Convert.ToBase64String(memory.ToArray());

            return DocumentoBase64.ToString();
            //  book.SaveAs(@"C:\Users\consultorti2\Desktop\Reportes_script\PruebaGenerica"+DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx");

        }

        public ActionResult ReporteLeads()
        {
            if (!HttpContext.User.IsInRole("Reporte Leads"))
                return RedirectToAction("Acceso", "ErrorPage");

            string usuario = User.Identity.GetUserId();
            DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();

            var empresas = (from empre in db.Empresa
                            join CE in db.ConfiguracionEmpresa on empre.Id equals CE.IdEmpresa
                            join DUE in db.DetalleUsuarioEmpresa on detalleUsuario.Id equals DUE.IdDetalleUsuario
                            where (empre.Estatus == 1) && (empre.Id != 1) && CE.EnvioProventel && DUE.IdEmpresa == empre.Id
                            select new
                            {
                                empre.Id,
                                empre.ClaveEmpresa
                            }).ToList();
            if (detalleUsuario.IdPerfil == 6 || detalleUsuario.IdPerfil == 1)
            {
                empresas = (from empre in db.Empresa
                            join CE in db.ConfiguracionEmpresa on empre.Id equals CE.IdEmpresa
                            where (empre.Estatus == 1) && (empre.Id != 1) && CE.EnvioProventel
                            select new
                            {
                                empre.Id,
                                empre.ClaveEmpresa
                            }).ToList();
            }

            ViewBag.IdEmpresa = new SelectList(empresas, "Id", "ClaveEmpresa");
            ViewBag.Inicio = DateTime.Now.AddDays(-7).ToString("dd/MM/yyyy");
            ViewBag.Fin = DateTime.Now.ToString("dd/MM/yyyy");
            return View();
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesLeads(DateTime fechainicio, DateTime fechafin, List<int> IdEmpresas)
        {
            string LEmpresas = IdEmpresas != null && IdEmpresas.Count() > 0 ? string.Join(";", IdEmpresas.ToArray()) : "";
            if (IdEmpresas == null)
            {
                string usuario = User.Identity.GetUserId();
                DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();

                if (detalleUsuario.IdPerfil == 6 || detalleUsuario.IdPerfil == 1)
                {
                    var empresas = (from empre in db.Empresa
                                    join CE in db.ConfiguracionEmpresa on empre.Id equals CE.IdEmpresa
                                    where (empre.Estatus == 1) && (empre.Id != 1) && CE.EnvioProventel
                                    select new
                                    {
                                        empre.Id,
                                    }).ToList();
                    if (empresas.Count > 0)
                    {
                        LEmpresas = string.Join(";", empresas.ToList());
                        LEmpresas = LEmpresas.Replace("{ Id = ", "");
                        LEmpresas = LEmpresas.Replace(" }", "");
                    }
                    else
                        LEmpresas = "0";
                }

                else
                {
                    var empresas = (from empre in db.Empresa
                                    join CE in db.ConfiguracionEmpresa on empre.Id equals CE.IdEmpresa
                                    join DUE in db.DetalleUsuarioEmpresa on detalleUsuario.Id equals DUE.IdDetalleUsuario
                                    where (empre.Estatus == 1) && (empre.Id != 1) && CE.EnvioProventel && DUE.IdEmpresa == empre.Id
                                    select new
                                    {
                                        empre.Id,
                                    }).ToList();
                    if (empresas.Count > 0)
                    {
                        LEmpresas = string.Join(";", empresas.ToList());
                        LEmpresas = LEmpresas.Replace("{ Id = ", "");
                        LEmpresas = LEmpresas.Replace(" }", "");
                    }
                    else
                        LEmpresas = "0";
                }
            }

            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@Empresas",LEmpresas)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };

            var _parameter = new List<SqlParameter>()
                {
                    new SqlParameter("@Empresas",LEmpresas)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };

            List<sp_ObtenerLeadsCorrectos> ReporteCotizacionesLeadsCorrectos = db.sp_ObtenerLeadsCorrectos.SqlQuery("sp_ObtenerLeadsCorrectos @Empresas, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            List<sp_ObtenerLeadsEmisiones> ReporteEmionesLeads = db.sp_ObtenerLeadsEmisiones.SqlQuery("sp_ObtenerLeadsEmisiones @Empresas, @FechaInicio , @FechaFin ", _parameter.ToArray()).ToList();

            ReportesVM reportes = new ReportesVM();
            var Reportesstring = GeneraReporte(ReporteCotizacionesLeadsCorrectos);
            reportes.ReportesString = Reportesstring;
            reportes.sp_ObtenerLeadsCorrectos = ReporteCotizacionesLeadsCorrectos.Take(100).ToList();
            reportes.NombreArchivo = "Leads_Correctos" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            Reportesstring = GeneraReporte(ReporteEmionesLeads);
            reportes.ReportesString2 = Reportesstring;
            reportes.sp_ObtenerLeadsEmisiones = ReporteEmionesLeads.Take(100).ToList();
            reportes.NombreArchivo2 = "Leads_Emisiones" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscarReportesLeadsCasa(DateTime fechainicio, DateTime fechafin, List<int> IdEmpresas)
        {
            string LEmpresas = IdEmpresas != null && IdEmpresas.Count() > 0 ? string.Join(";", IdEmpresas.ToArray()) : "";
            if (IdEmpresas == null)
            {
                string usuario = User.Identity.GetUserId();
                DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();

                if (detalleUsuario.IdPerfil == 6 || detalleUsuario.IdPerfil == 1)
                {
                    var empresas = (from empre in db.Empresa
                                    join CE in db.ConfiguracionEmpresa on empre.Id equals CE.IdEmpresa
                                    where (empre.Estatus == 1) && (empre.Id != 1) && CE.EnvioProventel
                                    select new
                                    {
                                        empre.Id,
                                    }).ToList();
                    if (empresas.Count > 0)
                    {
                        LEmpresas = string.Join(";", empresas.ToList());
                        LEmpresas = LEmpresas.Replace("{ Id = ", "");
                        LEmpresas = LEmpresas.Replace(" }", "");
                    }
                    else
                        LEmpresas = "0";
                }

                else
                {
                    var empresas = (from empre in db.Empresa
                                    join CE in db.ConfiguracionEmpresa on empre.Id equals CE.IdEmpresa
                                    join DUE in db.DetalleUsuarioEmpresa on detalleUsuario.Id equals DUE.IdDetalleUsuario
                                    where (empre.Estatus == 1) && (empre.Id != 1) && CE.EnvioProventel && DUE.IdEmpresa == empre.Id
                                    select new
                                    {
                                        empre.Id,
                                    }).ToList();
                    if (empresas.Count > 0)
                    {
                        LEmpresas = string.Join(";", empresas.ToList());
                        LEmpresas = LEmpresas.Replace("{ Id = ", "");
                        LEmpresas = LEmpresas.Replace(" }", "");
                    }
                    else
                        LEmpresas = "0";
                }
            }

            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@Empresas",LEmpresas)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };

            var _parameter = new List<SqlParameter>()
                {
                    new SqlParameter("@Empresas",LEmpresas)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)

                };

            List<sp_ObtenerLeadsCorrectosCasa> ReporteCotizacionesLeadsCorrectosCasa = db.sp_ObtenerLeadsCorrectosCasa.SqlQuery("sp_ObtenerLeadsCorrectosCasa @Empresas, @FechaInicio , @FechaFin ", parameters.ToArray()).ToList();
            List<sp_ObtenerLeadsEmisionesCasa> ReporteEmionesLeadsCasa = db.sp_ObtenerLeadsEmisionesCasa.SqlQuery("sp_ObtenerLeadsEmisionesCasa @Empresas, @FechaInicio , @FechaFin ", _parameter.ToArray()).ToList();

            ReportesVM reportes = new ReportesVM();
            var Reportesstring = GeneraReporte(ReporteCotizacionesLeadsCorrectosCasa);
            reportes.ReportesString3 = Reportesstring;
            reportes.sp_ObtenerLeadsCorrectosCasa = ReporteCotizacionesLeadsCorrectosCasa.Take(100).ToList();
            reportes.NombreArchivo3 = "Leads_CorrectosCasa" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            Reportesstring = GeneraReporte(ReporteEmionesLeadsCasa);
            reportes.ReportesString4 = Reportesstring;
            reportes.sp_ObtenerLeadsEmisionesCasa = ReporteEmionesLeadsCasa.Take(100).ToList();
            reportes.NombreArchivo4 = "Leads_EmisionesCasa" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";

            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        public ActionResult XMLSPoliza()
        {
            if (!HttpContext.User.IsInRole("Archivos Pólizas y cotizaciones"))
                return RedirectToAction("Acceso", "ErrorPage");

            string usuario = User.Identity.GetUserId();
            DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();

            var empresas = (from empre in db.Empresa
                            join CE in db.ConfiguracionEmpresa on empre.Id equals CE.IdEmpresa
                            join DUE in db.DetalleUsuarioEmpresa on detalleUsuario.Id equals DUE.IdDetalleUsuario
                            where (empre.Estatus == 1) && (empre.Id != 1) && CE.EnvioProventel && DUE.IdEmpresa == empre.Id
                            select new
                            {
                                empre.Id,
                                empre.ClaveEmpresa
                            }).ToList();
            if (detalleUsuario.IdPerfil == 6 || detalleUsuario.IdPerfil == 1)
            {
                empresas = (from empre in db.Empresa
                            join CE in db.ConfiguracionEmpresa on empre.Id equals CE.IdEmpresa
                            where (empre.Estatus == 1) && (empre.Id != 1) && CE.EnvioProventel
                            select new
                            {
                                empre.Id,
                                empre.ClaveEmpresa
                            }).ToList();
            }

            ViewBag.IdEmpresa = new SelectList(empresas, "Id", "ClaveEmpresa");
            ViewBag.Inicio = DateTime.Now.AddDays(-7).ToString("dd/MM/yyyy");
            ViewBag.Fin = DateTime.Now.ToString("dd/MM/yyyy");
            return View();
        }

        [ValidateAntiForgeryToken]
        public JsonResult BuscarXMLS_Autos(int IdTipoProceso, DateTime fechainicio, DateTime fechafin, List<int> IdEmpresas, int? IdAseguradora, string Poliza = null, string NumeroCotizacion = null)
        {
            string LEmpresas = IdEmpresas != null && IdEmpresas.Count() > 0 ? string.Join(";", IdEmpresas.ToArray()) : "";
            if (IdAseguradora == -1)
                IdAseguradora = null;
            var _parameter = new List<SqlParameter>()
                {
                    new SqlParameter("@Empresas",LEmpresas)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)
                    ,new SqlParameter("@IdTipoProceso",IdTipoProceso)
                    ,new SqlParameter("@Poliza",Poliza)
                    ,new SqlParameter("@NumeroCotizacion",NumeroCotizacion)
                    ,new SqlParameter("@IdAseguradora",(object)IdAseguradora ?? DBNull.Value)

                };


            List<sp_ObtenerXMLS_Poliza> Reporte_sp_ObtenerXMLS_autos = db.sp_ObtenerXMLS_Poliza.SqlQuery("sp_ObtenerXMLS_Autos @Empresas, @FechaInicio , @FechaFin, @idTipoProceso, @Poliza, @NumeroCotizacion,@IdAseguradora   ", _parameter.ToArray()).ToList();
            List<int> Reporte_NoCotizaciones = new List<int>();
            List<string> Reporte_NoPoliza = new List<string>();
            if (IdTipoProceso == 2)
            {
                Reporte_NoCotizaciones = Reporte_sp_ObtenerXMLS_autos.Select(x => x.NoCotizacion).Distinct().ToList();
                foreach (var NoCoti in Reporte_NoCotizaciones)
                {
                    var Registros = Reporte_sp_ObtenerXMLS_autos.Where(x => x.NoCotizacion == NoCoti).ToList();
                    foreach (var R in Registros)
                    {
                        if (!string.IsNullOrEmpty(R.XML_Solicitud_Cotizacion))
                        {
                            byte[] mibyte = EscribirXMLS(R.XML_Solicitud_Cotizacion);
                            R._XML_Solicitud_Cotizacion = mibyte;
                            R.XML_Solicitud_Cotizacion = NoCoti + "/" + "Solicitud_COT_" + R.Id + "_" + R.Aseguradora + "_" + R.Paquete + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.XML_Recepcion_Cotizacion))
                        {
                            byte[] mibyte = EscribirXMLS(R.XML_Recepcion_Cotizacion);
                            R._XML_Recepcion_Cotizacion = mibyte;
                            R.XML_Recepcion_Cotizacion = NoCoti + "/" + "Response_COT_" + R.Id + "_" + R.Aseguradora + "_" + R.Paquete + ".txt";
                        }
                    }
                }
            }
            else
            {
                Reporte_NoPoliza = Reporte_sp_ObtenerXMLS_autos.Select(x => x.NumeroPoliza).Distinct().ToList();
                foreach (var NoPo in Reporte_NoPoliza)
                {
                    var Registros = Reporte_sp_ObtenerXMLS_autos.Where(x => x.NumeroPoliza == NoPo).ToList();
                    foreach (var R in Registros)
                    {
                        if (!string.IsNullOrEmpty(R.XML_Solicitud_Cotizacion))
                        {
                            byte[] mibyte = EscribirXMLS(R.XML_Solicitud_Cotizacion);
                            R._XML_Solicitud_Cotizacion = mibyte;
                            R.XML_Solicitud_Cotizacion = NoPo + "/" + "Solicitud_COT_" + R.Id + "_" + R.Aseguradora + "_" + R.Paquete + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.XML_Recepcion_Cotizacion))
                        {
                            byte[] mibyte = EscribirXMLS(R.XML_Recepcion_Cotizacion);
                            R._XML_Recepcion_Cotizacion = mibyte;
                            R.XML_Recepcion_Cotizacion = NoPo + "/" + "Response_COT_" + R.Id + "_" + R.Aseguradora + "_" + R.Paquete + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.XML_Solicitud_Emision))
                        {
                            byte[] mibyte = EscribirXMLS(R.XML_Solicitud_Emision);
                            R._XML_Solicitud_Emision = mibyte;
                            R.XML_Solicitud_Emision = NoPo + "/" + "Solicitud_Emision_" + R.Id + "_" + R.Aseguradora + "_" + R.Paquete + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.XML_Recepcion_Emision))
                        {
                            byte[] mibyte = EscribirXMLS(R.XML_Recepcion_Emision);
                            R._XML_Recepcion_Emision = mibyte;
                            R.XML_Recepcion_Emision = NoPo + "/" + "Response_Emision_" + R.Id + "_" + R.Aseguradora + "_" + R.Paquete + ".txt";
                        }
                    }
                }
            }

            ReportesVM reportes = new ReportesVM();
            using (var memoryStream = new MemoryStream())
            {
                using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true))
                {
                    foreach (var Registros in Reporte_sp_ObtenerXMLS_autos)
                    {
                        if (!string.IsNullOrEmpty(Registros.XML_Solicitud_Cotizacion))
                        {
                            string nombreArchivo = Registros.XML_Solicitud_Cotizacion;
                            byte[] contenidoBytes = Registros._XML_Solicitud_Cotizacion;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._XML_Solicitud_Cotizacion = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.XML_Recepcion_Cotizacion))
                        {
                            string nombreArchivo = Registros.XML_Recepcion_Cotizacion;
                            byte[] contenidoBytes = Registros._XML_Recepcion_Cotizacion;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._XML_Recepcion_Cotizacion = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.XML_Solicitud_Emision))
                        {
                            string nombreArchivo = Registros.XML_Solicitud_Emision;
                            byte[] contenidoBytes = Registros._XML_Solicitud_Emision;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._XML_Solicitud_Emision = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.XML_Recepcion_Emision))
                        {
                            string nombreArchivo = Registros.XML_Recepcion_Emision;
                            byte[] contenidoBytes = Registros._XML_Recepcion_Emision;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._XML_Recepcion_Emision = null;
                        }

                    }


                }

                reportes.sp_ObtenerXMLS_Poliza = Reporte_sp_ObtenerXMLS_autos.Take(100).ToList();
                reportes.ReportesString = Convert.ToBase64String(memoryStream.ToArray());
                reportes.NombreArchivo = "Archivos_autos" + DateTime.Now.ToString("ddmmyyyyhhmmss") + ".zip";
            }
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        public static byte[] EscribirXMLS(string contenido)
        {
            // Usamos MemoryStream para simular la escritura en memoria
            using (MemoryStream memoryStream = new MemoryStream())
            using (StreamWriter streamWriter = new StreamWriter(memoryStream, Encoding.UTF8))
            {
                // Escribimos el contenido en el StreamWriter asociado al MemoryStream
                streamWriter.Write(contenido);
                streamWriter.Flush(); // Aseguramos que el buffer se escriba en el MemoryStream

                // Obtenemos los bytes del MemoryStream
                byte[] bytesEnMemoria = memoryStream.ToArray();
                //log.Info($"El contenido del blog de notas en memoria se ha convertido a un array de {bytesEnMemoria.Length} bytes.");
                return bytesEnMemoria;
            }
        }

        [ValidateAntiForgeryToken]
        public JsonResult BuscarXMLS_Casa(int IdTipoProceso, DateTime fechainicio, DateTime fechafin, List<int> IdEmpresas, string Poliza = null, string NumeroCotizacion = null)
        {
            string LEmpresas = IdEmpresas != null && IdEmpresas.Count() > 0 ? string.Join(";", IdEmpresas.ToArray()) : "";
            var _parameter = new List<SqlParameter>()
                {
                    new SqlParameter("@Empresas",LEmpresas)
                    ,new SqlParameter("@FechaInicio",fechainicio)
                    ,new SqlParameter("@FechaFin",fechafin)
                    ,new SqlParameter("@IdTipoProceso",IdTipoProceso)
                    ,new SqlParameter("@Poliza",Poliza)
                    ,new SqlParameter("@NumeroCotizacion",NumeroCotizacion)

                };


            List<sp_ObtenerXMLS_Casa> Reporte_sp_ObtenerXMLS_casa = db.sp_ObtenerXMLS_Casa.SqlQuery("sp_ObtenerXMLS_Casa @Empresas, @FechaInicio , @FechaFin, @idTipoProceso, @Poliza, @NumeroCotizacion  ", _parameter.ToArray()).ToList();

            List<int> Reporte_NoCotizaciones = new List<int>();
            List<string> Reporte_NoPoliza = new List<string>();
            if (IdTipoProceso == 2)
            {
                Reporte_NoCotizaciones = Reporte_sp_ObtenerXMLS_casa.Select(x => x.Id).Distinct().ToList();
                foreach (var NoCoti in Reporte_NoCotizaciones)
                {
                    var Registros = Reporte_sp_ObtenerXMLS_casa.Where(x => x.Id == NoCoti).ToList();
                    foreach (var R in Registros)
                    {
                        if (!string.IsNullOrEmpty(R.Json_Request_ObtenerPlanes_Cotizacion))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Request_ObtenerPlanes_Cotizacion);
                            R._Json_Request_ObtenerPlanes_Cotizacion = mibyte;
                            R.Json_Request_ObtenerPlanes_Cotizacion = NoCoti + "/" + "Solicitud_COT_" + R.Id + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.Json_Response_ObtenerPlanes_Cotizacion))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Response_ObtenerPlanes_Cotizacion);
                            R._Json_Response_ObtenerPlanes_Cotizacion = mibyte;
                            R.Json_Response_ObtenerPlanes_Cotizacion = NoCoti + "/" + "Response_COT_" + R.Id + ".txt";
                        }
                    }
                }
            }
            else
            {
                Reporte_NoPoliza = Reporte_sp_ObtenerXMLS_casa.Select(x => x.NumeroPoliza).Distinct().ToList();
                foreach (var NoPo in Reporte_NoPoliza)
                {
                    var Registros = Reporte_sp_ObtenerXMLS_casa.Where(x => x.NumeroPoliza == NoPo).ToList();
                    foreach (var R in Registros)
                    {
                        if (!string.IsNullOrEmpty(R.Json_Request_ObtenerPlanes_Cotizacion))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Request_ObtenerPlanes_Cotizacion);
                            R._Json_Request_ObtenerPlanes_Cotizacion = mibyte;
                            R.Json_Request_ObtenerPlanes_Cotizacion = NoPo + "/" + "Solicitud_COT_" + R.Id + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.Json_Response_ObtenerPlanes_Cotizacion))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Response_ObtenerPlanes_Cotizacion);
                            R._Json_Response_ObtenerPlanes_Cotizacion = mibyte;
                            R.Json_Response_ObtenerPlanes_Cotizacion = NoPo + "/" + "Response_COT_" + R.Id + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.Json_Request_Cotizacion_Detalle))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Request_Cotizacion_Detalle);
                            R._Json_Request_Cotizacion_Detalle = mibyte;
                            R.Json_Request_Cotizacion_Detalle = NoPo + "/" + "Solicitud_Cot_Detalle_" + R.Id + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.Json_Response_Cotizacion_Detalle))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Response_Cotizacion_Detalle);
                            R._Json_Response_Cotizacion_Detalle = mibyte;
                            R.Json_Response_Cotizacion_Detalle = NoPo + "/" + "Response_Cot_Detalle_" + R.Id + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.Json_Request_Emision_Adicional))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Request_Emision_Adicional);
                            R._Json_Request_Emision_Adicional = mibyte;
                            R.Json_Request_Emision_Adicional = NoPo + "/" + "Solicitud_Emision_Adicional_" + R.Id + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.Json_Response_Emision_Adicional))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Response_Emision_Adicional);
                            R._Json_Response_Emision_Adicional = mibyte;
                            R.Json_Response_Emision_Adicional = NoPo + "/" + "Response_Emision_Adicional_" + R.Id + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.Json_Request_Emision))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Request_Emision);
                            R._Json_Request_Emision = mibyte;
                            R.Json_Request_Emision = NoPo + "/" + "Solicitud_Emision_" + R.Id + ".txt";
                        }
                        if (!string.IsNullOrEmpty(R.Json_Response_Emision))
                        {
                            byte[] mibyte = EscribirXMLS(R.Json_Response_Emision);
                            R._Json_Response_Emision = mibyte;
                            R.Json_Response_Emision = NoPo + "/" + "Response_Emision_" + R.Id + ".txt";
                        }
                    }
                }
            }
            ReportesVM reportes = new ReportesVM();
            using (var memoryStream = new MemoryStream())
            {
                using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true))
                {
                    foreach (var Registros in Reporte_sp_ObtenerXMLS_casa)
                    {
                        if (!string.IsNullOrEmpty(Registros.Json_Request_ObtenerPlanes_Cotizacion))
                        {
                            string nombreArchivo = Registros.Json_Request_ObtenerPlanes_Cotizacion;
                            byte[] contenidoBytes = Registros._Json_Request_ObtenerPlanes_Cotizacion;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._Json_Request_ObtenerPlanes_Cotizacion = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.Json_Response_ObtenerPlanes_Cotizacion))
                        {
                            string nombreArchivo = Registros.Json_Response_ObtenerPlanes_Cotizacion;
                            byte[] contenidoBytes = Registros._Json_Response_ObtenerPlanes_Cotizacion;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._Json_Response_ObtenerPlanes_Cotizacion = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.Json_Request_Cotizacion_Detalle))
                        {
                            string nombreArchivo = Registros.Json_Request_Cotizacion_Detalle;
                            byte[] contenidoBytes = Registros._Json_Request_Cotizacion_Detalle;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._Json_Request_Cotizacion_Detalle = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.Json_Response_Cotizacion_Detalle))
                        {
                            string nombreArchivo = Registros.Json_Response_Cotizacion_Detalle;
                            byte[] contenidoBytes = Registros._Json_Response_Cotizacion_Detalle;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._Json_Response_Cotizacion_Detalle = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.Json_Request_Emision_Adicional))
                        {
                            string nombreArchivo = Registros.Json_Request_Emision_Adicional;
                            byte[] contenidoBytes = Registros._Json_Request_Emision_Adicional;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._Json_Request_Emision_Adicional = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.Json_Response_Emision_Adicional))
                        {
                            string nombreArchivo = Registros.Json_Response_Emision_Adicional;
                            byte[] contenidoBytes = Registros._Json_Response_Emision_Adicional;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._Json_Response_Emision_Adicional = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.Json_Request_Emision))
                        {
                            string nombreArchivo = Registros.Json_Request_Emision;
                            byte[] contenidoBytes = Registros._Json_Request_Emision;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._Json_Request_Emision = null;
                        }
                        if (!string.IsNullOrEmpty(Registros.Json_Response_Emision))
                        {
                            string nombreArchivo = Registros.Json_Response_Emision;
                            byte[] contenidoBytes = Registros._Json_Response_Emision;

                            var zipEntry = archive.CreateEntry(nombreArchivo);

                            using (var entryStream = zipEntry.Open())
                            using (var contentStream = new MemoryStream(contenidoBytes))
                            {
                                contentStream.CopyTo(entryStream);
                            }
                            Registros._Json_Response_Emision = null;
                        }
                    }


                }

                reportes.sp_ObtenerXMLS_Casa = Reporte_sp_ObtenerXMLS_casa.Take(100).ToList();
                reportes.ReportesString = Convert.ToBase64String(memoryStream.ToArray());
                reportes.NombreArchivo = "Archivos_Casa" + DateTime.Now.ToString("ddmmyyyyhhmmss") + ".zip";
            }
            var JsonResult = Json(reportes, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }
        [ValidateAntiForgeryToken]
        public JsonResult VerificaProducto(int IdEmpresa)
        {
            int _IdEmprsa = Convert.ToInt32(IdEmpresa);
            var empresa = db.Empresa.FirstOrDefault(x => x.Id == _IdEmprsa);
            var ConfEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == empresa.Id);
            var ConfEmpresaProduct = db.ConfiguracionEmpresaPorProducto.FirstOrDefault(x => x.IdEmpresa == empresa.Id);
            bool Autos = (ConfEmpresa == null) ? false : ConfEmpresa.Activo;
            bool Casa = (ConfEmpresaProduct == null) ? false : ConfEmpresaProduct.Activo;




            var JsonResult = Json(new { Autos = Autos, Casa = Casa }, JsonRequestBehavior.AllowGet);
            JsonResult.MaxJsonLength = int.MaxValue;
            return JsonResult;
        }

        [ValidateAntiForgeryToken]
        public JsonResult ValidaAseguradora(int IdEpresa)
        {
            JsonResult jsonResult = new JsonResult();
            try
            {
                var Aseguradoras = db.Convenio.Where(C => C.IdEmpresa == IdEpresa).Join(db.Aseguradora,
              C => C.IdAseguradora,
              A => A.Id,
              (C, A) => new
              {
                  Id = A.Id,
                  ClaveHomologado = A.ClaveHomologado
              }
              ).Distinct().ToList();
                jsonResult = Json(new { Aseguradoras = Aseguradoras, Error = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                log.Info("se generó una excepción ValidaAseguradora() XMLS Polizas " + ex.ToString());
                jsonResult = Json(new { Aseguradoras = "", Error = true }, JsonRequestBehavior.AllowGet);
            }

            jsonResult.MaxJsonLength = int.MaxValue;
            return jsonResult;
        }
        [ValidateAntiForgeryToken]
        public JsonResult BuscaEmpresas(int IdCorporativo)
        {
            JsonResult jsonResult = new JsonResult();
            try
            {
                string usuario = User.Identity.GetUserId();
                DetalleUsuario detalleUsuario = db.DetalleUsuario.Where(x => x.IdUsuario.Equals(usuario)).FirstOrDefault();
                //Busca las empresa que tiene el usuario
                var Empresas = db.Empresa
                       .Where(C => C.IdCorporativo == IdCorporativo && C.Estatus == 1)
                       .Join(db.DetalleUsuarioEmpresa,
                             empresa => empresa.Id,
                             due => due.IdEmpresa,
                             (empresa, due) => new { Empresa = empresa, DetalleUsuarioEmpresa = due })
                       .Where(j => j.DetalleUsuarioEmpresa.IdDetalleUsuario == detalleUsuario.Id && j.DetalleUsuarioEmpresa.Estatus == true)
                       .Select(j => new
                       {
                           Id = j.Empresa.IdGerenciaCORE,
                           RazonSocial = j.Empresa.RazonSocial,
                           ClaveEmpresa = j.Empresa.ClaveEmpresa
                       })
                       .ToList();

                //si es perfil 6 mesa de ayuda o tecnico tendrá accesos a todo
                if (detalleUsuario.IdPerfil == 6 || detalleUsuario.IdPerfil == 1)
                {
                    Empresas = db.Empresa.Where(C => C.IdCorporativo == IdCorporativo && C.Estatus == 1)
                    .Select(empresa => new

                    {
                        //selecciona las propiedades que se necesitan para el dropdown

                        Id = empresa.IdGerenciaCORE,

                        RazonSocial = empresa.RazonSocial,

                        ClaveEmpresa = empresa.ClaveEmpresa

                    })
                    .ToList();
                }
                jsonResult = Json(new { Empresas = Empresas, Error = false }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

                log.Info("se generó una excepción BuscaEmpresas() " + ex.ToString());
                jsonResult = Json(new { Empresas = "", Error = true }, JsonRequestBehavior.AllowGet);
            }
            jsonResult.MaxJsonLength = int.MaxValue;
            return jsonResult;
        }
        //public void GeneraReporte(List<ReportePolizas> reporte)
        //{
        //    List<ReportePolizas> data = new List<ReportePolizas>();
        //    HeaderPolizas header = new HeaderPolizas();
        //    List<HeaderPolizas> Encabezado = new List<HeaderPolizas>();
        //    Encabezado.Add(header);
        //    var book = new XLWorkbook();
        //    var hoja = book.Worksheets.Add("Data_Test_Worksheet");
        //    hoja.Cell(1, 1).InsertData(Encabezado);
        //    hoja.Cell(2, 1).InsertData(reporte);
        //    System.IO.MemoryStream memory = new System.IO.MemoryStream();
        //    book.SaveAs(memory);
        //    //  Session["datosEditorHtml"] = Encoding.ASCII.GetString(memory.ToArray());
        //    var item = Convert.ToBase64String(memory.ToArray());
        //    ViewBag.iit = item.ToString();
        //    book.SaveAs(@"C:\Users\consultorti2\Desktop\Reportes_script\Data_Test.xlsx");
        //}

        //internal class HeaderPolizas
        //{
        //    public string IDDocto { get; set; }

        //    public string RazonSocial { get; set; }

        //    public string NumeroPoliza { get; set; }

        //    public string Forma_pago { get; set; }

        //    public string Medio_pago { get; set; }

        //    public string fecha_inicio { get; set; }

        //    public string fecha_fin { get; set; }

        //    public string PrimaNeta { get; set; }

        //    public string PrimaTotal { get; set; }

        //    public string IVA { get; set; }

        //    public string Marca { get; set; }

        //    public string Version { get; set; }

        //    public string Modelo { get; set; }

        //    public string Motor { get; set; }

        //    public string Serie { get; set; }

        //    public string Placas { get; set; }

        //    public string Cliente_emisor { get; set; }

        //    public string Numero_empleado { get; set; }

        //    public string Correo { get; set; }

        //    public string Conductor_Habitual { get; set; }
        //    public HeaderPolizas()
        //    {
        //        this.IDDocto = "Identificador";
        //        this.RazonSocial = "RazonSocial";
        //        this.NumeroPoliza = "NumeroPoliza";
        //        this.Forma_pago = "Forma_pago";
        //        this.Medio_pago = "Medio_pago";
        //        this.fecha_inicio = "fecha_inicio";
        //        this.fecha_fin = "fecha_fin";
        //        this.PrimaNeta = "PrimaNeta";
        //        this.PrimaTotal = "PrimaTotal";
        //        this.IVA = "IVA";
        //        this.Marca = "Marca";
        //        this.Version = "Version";
        //        this.Modelo = "Modelo";
        //        this.Motor = "Motor";
        //        this.Serie = "Serie";
        //        this.Placas = "Placas";
        //        this.Cliente_emisor = "Cliente_emisor";
        //        this.Numero_empleado = "Numero_empleado";
        //        this.Correo = "Correo";
        //        this.Conductor_Habitual = "Conductor_Habitual";
        //    }
        //}

        //internal class HeaderUsuarios
        //{
        //    public string IDCont { get; set; }
        //    public string Nombre { get; set; }
        //    public string ApellidoP { get; set; }
        //    public string ApellidoM { get; set; }
        //    public string FechaNac { get; set; }
        //    public string Edad { get; set; }
        //    public string Numero_Empleado { get; set; }
        //    public string Usuario_Portal { get; set; }
        //    public string IDEmpleadoBFlex { get; set; }
        //    public string Gerencia { get; set; }

        //    public HeaderUsuarios()
        //    {

        //    this.IDCont          ="Identificador";
        //    this.Nombre          ="Nombre(s)";
        //    this.ApellidoP       ="Apellido Paterno";
        //    this.ApellidoM       ="Apellido Materno";
        //    this.FechaNac        ="Fecha de nacimiento";
        //    this.Edad            ="Edad";
        //    this.Numero_Empleado ="Numero de Empleado";
        //    this.Usuario_Portal  ="Usuario del portal";
        //    this.IDEmpleadoBFlex ="IdBeflex";
        //    this.Gerencia        = "Gerencia";
        //}
        //}
    }

}


