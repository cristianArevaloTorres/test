﻿function revisaChksAceptacion() {
    if ($('#cbTarjetaCredito').prop('checked') && $('#cbAvisoPriv').prop('checked')) {
        $('#btnContratar').show();
    }
    else {
        $('#btnContratar').hide();
    }
}

function muestraCondicionesRenovacion() {
    // CAT Renovación automática: permite declinar sin bloquear la emisión y muestra las condiciones al volver a aceptar.
    if ($('#cbRenovacionAutomatica').prop('checked')) {
        $('#ModalCondicionesRenovacion').modal('show');
    }
}

$(document).on('hidden.bs.modal', '#ModalCondicionesRenovacion', function () {
    // CAT Renovación automática: conserva activo el resumen de compra al cerrar el aviso superpuesto.
    if ($('#ModalConfirmaCompra').is(':visible')) {
        $('body').addClass('modal-open');
    }
});

$(document).ready(function () {
    //$("#DatosUsuario_Direccion_CodigoPostal").autocomplete({
    //    source: function (request, response) {
    //        if ($("#DatosUsuario_Direccion_CodigoPostal").val().length > 4) {
    //            $.blockUI({ message: '<img src="/../img/loader.gif" /> <h3>Buscando Código Postal...</h3>' });
    //            $.ajax({
    //                url: '/Cotizacion/ObtenerCodigosPostales',
    //                datatype: "json",
    //                type:"POST",
    //                data: {
    //                    CodigoPostal: $('#DatosUsuario_Direccion_CodigoPostal').val()
    //                    , __RequestVerificationToken: gettoken()
    //                },
    //                success: function (data) {
    //                    $.unblockUI();
    //                    response($.map(data, function (val, item) {
    //                        return {
    //                            label: val.Codigo,
    //                            value: val.Codigo,
    //                            Codigo: val.Codigo,
    //                            Ciudad: val.Ciudad,
    //                            Municipio: val.Municipio,
    //                            IdEstado: val.IdEstado,
    //                            Colonias: val.colonias
    //                        }
    //                    }));
    //                }
    //            });
    //        }
    //    },
    //    select: function (event, ui) {
    //        $("#IdEstado").val(ui.item.IdEstado);
    //        $("#IdEstado_").val(ui.item.IdEstado);
    //        $("#DatosUsuario_Direccion_Municipio").val(ui.item.Municipio);
    //        $("#DatosUsuario_Direccion_Ciudad").val(ui.item.Ciudad);
    //        var colonias = $("#IdAsentamiento");
    //        $('#IdAsentamiento').find('option').remove().end().append('<option value="99999">Selecciona</option>').val('99999');
    //        var _consColonias = ui.item.Colonias;
    //        $.each(_consColonias, function (imresult) {
    //            colonias.append($("<option />").val(_consColonias[imresult].Id).text(_consColonias[imresult].Colonia));
    //        });
    //    }
    //});
});

function BuscaCodigoPostal(idAsentamiento) {

    var datos = "";
    var codPostal = $('#DatosUsuario_Direccion_CodigoPostal').val();
    if (codPostal != '' && codPostal.length == 5) {
        $.ajax({
            url: '/Cotizacion/ObtenerCodigosPostales',
            type: 'POST',
            datatype: "json",
            data: {
                CodigoPostal: codPostal
                , __RequestVerificationToken: gettoken()
            },
            success: function (data) {
                $.unblockUI();
                datos = {
                    label: data[0].Codigo,
                    value: data[0].Codigo,
                    Codigo: data[0].Codigo,
                    Ciudad: data[0].Ciudad,
                    Municipio: data[0].Municipio,
                    IdEstado: data[0].IdEstado,
                    Colonias: data[0].colonias
                };
                if (datos !== "") {
                    BuscaColonias(datos, idAsentamiento);
                }
            }
        });
    }
    else {
        $.unblockUI();
        return false;
    }
}

function BuscaColonias(datosCodigo, idAsentamiento) {

    
    //var datosCodigo = BuscaCodigoPostal();
    $("#IdEstado").val(datosCodigo.IdEstado);
    $("#IdEstado_").val(datosCodigo.IdEstado);
    $("#DatosUsuario_Direccion_Municipio").val(datosCodigo.Municipio);
    $("#DatosUsuario_Direccion_Ciudad").val(datosCodigo.Ciudad);
    var colonias = $("#IdAsentamiento");
    $('#IdAsentamiento').find('option').remove().end().append('<option value="99999">Selecciona</option>').val('99999');
    var _consColonias = datosCodigo.Colonias;
    $.each(_consColonias, function (imresult) {
        colonias.append($("<option />").val(_consColonias[imresult].Id).text(_consColonias[imresult].Colonia));
    });

    if (idAsentamiento > 0)
        $('#IdAsentamiento').val(idAsentamiento);
}

function getPatterEmail() {
   return new RegExp('^(("[\\w-\\s]+")|([\\w-]+(?:\\.[\\w-]+)*)|("[\\w-\\s]+")([\\w-]+(?:\.[\\w-]+)*))(@((?:[\\w-]+\\.)*\\w[\\w-]{0,66})\\.([a-z]{2,6}(?:\\.[a-z]{2})?)$)|(@\\[?((25[0-5]\\.|2[0-4][0-9]\\.|1[0-9]{2}\\.|[0-9]{1,2}\\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\\]?$)', 'i');

}

function MuestraModalConfirmaCompra() {
    $('#errorPlacas').text('');
    $('#errorPlacas').show();
    $('#errorSerie').text('');
    $('#errorSerie').show();
    $('#errorMotor').text('');
    $('#errorMotor').show();
    $('#errorEmail').text('');
    $('#errorEmail').show();
    $('#errorConfEmail').text('');
    $('#errorConfEmail').show();
    $('#errorTelCel').text('');
    $('#errorTelCel').show();
    $('#errorTelFijo').text('');
    $('#errorTelFijo').show();
    $('#errorPrimerNombre').text('');
    $('#errorPrimerNombre').show();
    $('#errorApellidoPaterno').text('');
    $('#errorApellidoPaterno').show();
    $("#errorCalle").text('');
    $("#errorCalle").show();
    $("#errorIdAsentamiento").text('');
    $("#errorIdAsentamiento").show();
    $('#errorNumEconomico').show();
    $('#errorNumEconomico').text('');
    $('#errorNumSegmento').show();
    $('#errorNumSegmento').text('');

    if (benefMA) {
        $('#errorBenefMuerteAccidental').text('');
        $('#errorBenefMuerteAccidental').show('');
    }

    //if (!esFlotilla || idTipoContratante == 5) {
    //    $('#errorNumeroExterior').text('');
    //    $('#errorNumeroExterior').show();
    //}

    var placas = $('#Placas').val().toUpperCase();
    var numVin = $('#NumeroSerie').val().toUpperCase();
    var numMotor = $('#NumeroMotor').val().toUpperCase();
    var email = $('#Email').val();
    var confEmail = $('#ConfirmaEmail').val();
    var telCel = $('#TelefonoCel').val();
    var telFijo = $('#TelefonoFijo').val();
    var primerNombre = $('#PrimerNombre').val();
    var segundoNombre = $('#SegundoNombre').val();
    var apellidoPaterno = $('#ApellidoPaterno').val();
    var apellidoMaterno = $('#ApellidoMaterno').val();
    var numExt = $('#DatosUsuario_Direccion_NumeroExt').val();
    var valid = true;

    var emisionPersonaMoral = ($("#EmisionPersonaMoral").val() == 'True' || $("#EmisionPersonaMoral").val() == 'true')
    
    if (idTipoContratante == 1) {

        $("#DatosUsuario_RFC").rules("remove", "required");

    }
    else if (!emisionPersonaMoral || $("#DatosUsuario_RFC").val().length > 1) {

       

        if (ValidaCaracteresEspeciales(primerNombre)) {
            $("#errorPrimerNombre").show();
            $("#errorPrimerNombre").text("El primer nombre no debe contener carácteres numéricos ni especiales");
            $("#PrimerNombre").focus();
            valid = false;
        } else {

            //if (!$('#ConductorHabitual').prop('checked')) {
            if (!(primerNombre.length > 2)) {
                $('#errorPrimerNombre').show();
                $('#errorPrimerNombre').text('El Nombre es obligatorio.');
                $('#PrimerNombre').focus();
                valid = false;
                //return false;
            } 

        }

        if (segundoNombre.length > 0 && ValidaCaracteresEspeciales(segundoNombre)) {
            $("#errorSegundoNombre").show();
            $("#errorSegundoNombre").text("El segundo nombre no debe contener carácteres numéricos ni especiales");
            $("#SegundoNombre").focus();
            valid = false;
        }

        if (ValidaCaracteresEspeciales(apellidoPaterno)) {
            $("#errorApellidoPaterno").show();
            $("#errorApellidoPaterno").text("El Apellido Paterno no debe contener carácteres numéricos ni especiales");
            $("#ApellidoPaterno").focus();
            valid = false;
        } else {
            if (!(apellidoPaterno.length > 2)) {
                $('#errorApellidoPaterno').show();
                $('#errorApellidoPaterno').text('El Apellido Paterno es obligatorio.');
                $('#ApellidoPaterno').focus();
                valid = false;
                //  return false;
            }
        }

        if (ValidaCaracteresEspeciales(apellidoMaterno) && apellidoMaterno.length>0) {
            $("#errorApellidoMaterno").show();
            $("#errorApellidoMaterno").text("El Apellido Materno no debe contener caracteres especiales");
            $("#ApellidoMaterno").focus();
            valid = false;
        } 


       // }
    } else {
        $("#DatosUsuario_RFC").rules("remove", "required");
    }

    if ((idTipoNegocio == 6 || idTipoNegocio == 5) && $("#PersonaMoral_RFC").length > 0) {

        var strRFCPM = $("#PersonaMoral_RFC").val();

        if (ValidaRFC_PM(strRFCPM)) {
            $("#errorRFC_PM").hide();
            $("#errorRFC_PM").text("");
        } else {
            $("#errorRFC_PM").show();
            $("#errorRFC_PM").text("El RFC debe de ser a 12 dígitos incluyendo homoclave");
            $("#PersonaMoral_RFC").focus();
            valid = false;
        }
    }

    if ($('#BenefMuerteAccidental').length) {
        // si existe
        if (benefMA && !($('#BenefMuerteAccidental').val().length > 0)) {
            $('#errorBenefMuerteAccidental').show();
            $('#errorBenefMuerteAccidental').text('Este campo es obligatorio');
            $('#BenefMuerteAccidental').focus();
            valid = false;
            //return false;
        }
    }

    var regexNumVIN = new RegExp("[A-NPR-Z0-9]{17}");
    var regexEmail = new RegExp('^(("[\\w-\\s]+")|([\\w-]+(?:\\.[\\w-]+)*)|("[\\w-\\s]+")([\\w-]+(?:\.[\\w-]+)*))(@((?:[\\w-]+\\.)*\\w[\\w-]{0,66})\\.([a-z]{2,6}(?:\\.[a-z]{2})?)$)|(@\\[?((25[0-5]\\.|2[0-4][0-9]\\.|1[0-9]{2}\\.|[0-9]{1,2}\\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\\]?$)', 'i');

    if ($("#IdAsentamiento").val() == '99999') {
        $("#errorIdAsentamiento").text('Seleccione la Colonia');
        valid = false;
        //return false;
    }

    if ($("#DatosUsuario_Direccion_Calle").val() == '') {
        $("#errorCalle").text('La calle es requerida');
        valid = false;
        //return false;
    }

    //if ((!esFlotilla && !emisionPolizaMaestra) || idTipoNegocio == 5) {
    if (numExt == '') {

        $("#errorNumeroExterior").show();
        $("#errorNumeroExterior").text("El número exterior no puede ir vacío");
        $('#DatosUsuario_Direccion_NumeroExt').focus();
        valid = false
    }else
    if (aseg == "QUALITAS") { 

        if (ValidaCaracteresNoExterior(numExt)) {
            $('#errorNumeroExterior').show();
            $('#errorNumeroExterior').text('El número exterior no debe contener caracteres especiales');
            $('#DatosUsuario_Direccion_NumeroExt').focus();
            valid = false
        }
    } else if (idTipoContratante != 1 && numExt!= undefined) {
        var regexNumExt = new RegExp("^([0-9])*$");
        if (!regexNumExt.test(numExt)) {
            $('#errorNumeroExterior').show();
            $('#errorNumeroExterior').text('El número externo debe ser numérico.');
            $('#DatosUsuario_Direccion_NumeroExt').focus();
            valid = false;
           // return false;
        }
        }

    if (idTipoNegocio == 3) {

        if ($("#DatosUsuario_Direccion_CodigoPostal").val() == '') {
            $("#errorCodigoPostal").text('El código postal es requerido');
            $("#errorCodigoPostal").show();
            valid = false;
        }
        else
            $("#errorCodigoPostal").hide();
    }



    if ($('#DatosUsuario_NumeroIdentificacion').length > 0) {
        $('#errorCURP').text('');
        $('#errorNumeroIdentificacion').text('');
        $('#errorNombrePuesto').text('');

        

        //if (!curpValida($("#DatosUsuario_CURP").val())) {
        //    $('#errorCURP').text('CURP no valida');
        //    valid = false;
        //}

        if ($("#DatosUsuario_NumeroIdentificacion").val() == '') {
            $('#errorNumeroIdentificacion').text('Número de Identificación es requerido');
            valid = false;
        }

        if ($("#DatosUsuario_CargoGobiernoFederal").prop('checked') && $("#DatosUsuario_NombreCargoGobiernoFederal").val() == '') {
            $('#errorNombrePuesto').text('Especifique el nombre de puesto federal');
            valid = false;
        }


        //if (!valid)
        //    return false;
    }

    if (aplicaNumeroEconomico && $("#NumeroEconomico").val() == '') {
        $('#errorNumEconomico').show();
        $('#errorNumEconomico').text('El Número Económico es requerido');
        $('#NumeroEconomico').focus();
        valid = false;
        //return false;
    }

    if (aplicaNumeroSegmento && $("#NumeroSegmento").val() == '') {
        $('#errorNumSegmento').show();
        $('#errorNumSegmento').text('El Segmento es requerido');
        $('#NumeroSegmento').focus();
        valid = false;
        //return false;
    }

    if (telFijo!= undefined && telFijo.length < 9)  {
        $('#errorTelFijo').show();
        $('#errorTelFijo').text('El teléfono debe ser de almenos 10 caracteres.');
        $('#TelefonoFijo').focus();
        valid = false;
        //return false;
    }

    if (telCel.length < 9)  {
        $('#errorTelCel').show();
        $('#errorTelCel').text('El teléfono debe ser de almenos 10 caracteres.');
        $('#TelefonoCel').focus();
        valid = false;
        // return false;
    }

    if (numMotor.length < 3) {
   
        $('#errorMotor').show();
        $('#errorMotor').text('El número de motor debe ser mayor a 3 dígitos.');
        $('#NumeroMotor').focus();
        valid = false;
        //return false;
    }



    if (!regexNumVIN.test(numVin)) {   
        $('#errorSerie').show();
        $('#errorSerie').text('El número de serie debe ser de 17 dígitos. No puede llevar Ñ, O ni Q.');
        $('#NumeroSerie').focus();
        valid = false;
        //return false;
    }

    if (placas.length < 2) {
        $('#errorPlacas').show();
        $('#errorPlacas').text('Las placas deben ser especificadas. En caso de no tenerlas escriba SNP o PERMISO');
        $('#Placas').focus();
        valid = false;
        //return false;
    }
    if (placas.length > 7) {
        $('#errorPlacas').show();
        $('#errorPlacas').text('El número de placas no puede ser mayor a 7 carácteres');
        $('#Placas').focus();
        valid = false;

    }

    if (confEmail != email)  {
        $('#errorConfEmail').show();
        $('#errorConfEmail').text('El correo de confirmación no es igual al primero.');
        $('#ConfirmaEmail').focus();
        valid = false;
        //return false;
    }

    if (!regexEmail.test(email)) {
        $('#errorEmail').show();
        $('#errorEmail').text('El correo electrónico no es válido. No se permiten caracteres especiales ni de puntuación excepto ".". Se debe especificar cuando menos 2 segmentos en el dominio');
        $('#Email').focus();
        valid = false;
        //return false;
    }

    if (valid) {

        if ($('#SegundoNombre').val() != null && $('#SegundoNombre').val() != "") {
            $('#conductorHab').text(primerNombre + " " + segundoNombre + " " + apellidoPaterno + " " + apellidoMaterno);
        } else {
            $('#conductorHab').text(primerNombre + " " + apellidoPaterno + " " + apellidoMaterno);
        }

        

     
    }
    return valid;
   


}

function MuestraDivCondHabitual() {
    if ($('#ConductorHabitual').prop('checked')) {
        BlokiarCamposCondHab(conductorEmpleado);
    } else {
        DhesblokiarCamposCondHab();
    }
}

function BlokiarCamposCondHab(conductor) {

    $('#PrimerNombre').attr('readonly', true).val(conductor.PrimerNombre);
    $('#SegundoNombre').attr('readonly', true).val(conductor.SegundoNombre);
    $('#ApellidoPaterno').attr('readonly', true).val(conductor.ApellidoPaterno);
    $('#ApellidoMaterno').attr('readonly', true).val(conductor.ApellidoMaterno);
    $('#DatosUsuario_RFC').val(conductor.RFCConductor);
    $('#IdParentesco').attr('readonly', true).val();//disabled
    if(idTipoNegocio != 3)
    $('#DatosUsuario_Direccion_CodigoPostal').attr('readonly', true);
    $('#IdEstado').attr('readonly', true);//disabled
    $('#DatosUsuario_Direccion_Ciudad').attr('readonly', true);
    $('#DatosUsuario_Direccion_Municipio').attr('readonly', true);
    if (esFlotilla && idTipoContratante != 5) {
        $('#IdAsentamiento').attr('readonly', true);//disabled
        $('#DatosUsuario_Direccion_Calle').attr('readonly', true);
        $('#DatosUsuario_Direccion_NumeroExt').attr('readonly', true);
        $('#DatosUsuario_Direccion_NumeroInt').attr('readonly', true);

    }
}

function DhesblokiarCamposCondHab() {

    $('#PrimerNombre').attr('readonly', false).val('');
    $('#SegundoNombre').attr('readonly', false).val('');
    $('#ApellidoPaterno').attr('readonly', false).val('');
    $('#ApellidoMaterno').attr('readonly', false).val('');
    $('#DatosUsuario_RFC').val('');
    $('#IdParentesco').attr('readonly', false);//disabled
    //if (esFlotilla && idTipoContratante != 5) {
    //	$('#DatosUsuario_Direccion_CodigoPostal').attr('readonly', false).val('');
    //	$('#IdEstado').attr('readonly', false);//disabled
    //	$('#DatosUsuario_Direccion_Ciudad').attr('readonly', false).val('');
    //	$('#DatosUsuario_Direccion_Municipio').attr('readonly', false).val('');
    //	$('#IdAsentamiento').attr('readonly', false);//disabled
    //	$('#DatosUsuario_Direccion_Calle').attr('readonly', false).val('');
    //	$('#DatosUsuario_Direccion_NumeroExt').attr('readonly', false).val('');
    //	$('#DatosUsuario_Direccion_NumeroInt').attr('readonly', false).val('');

    //}
}

function MuestraComboBenefPref() {
    if ($('#EsBeneficiarioPreferente').prop('checked')) {
        $('#cmbNombreBeneficiario').show();
    } else {
        $('#cmbNombreBeneficiario').hide();
    }
}

function MuestraAvisoPrivacidad() {
    $('#ModalDocumentos').modal('show');
    PDFObject.embed("../../Repositorio/Cotizaciones/" + rutaPDF, "#ContenidoPDF");
}

function Bloquea(mostrarSMS) {
    
    var numTarjeta = $("#Tarjeta_NumeroTarjeta").val();
    if (numTarjeta == '')
        $("#temTarjeta").val('');


    if ($("#FormEmision").valid()) {
        $('#ModalConfirmaCompra').modal('hide');

        var idMedioPago = $("#IdMedioPago").val();
        var aseguradora = $("#Aseguradora").val();

        if ((idMedioPago == 1 || idMedioPago == 2) && (aseguradora == "ABA" || aseguradora == "ATLAS") && mostrarSMS) {
            swal({
                title: "",
                text: "A continuación se abrirá la ventana de pago de la aseguradora en la que deberás ingresar tus datos bancarios para la programación del cobro correspondiente de tu Póliza. \n\n Asegurate de habilitar ventanas emergentes desde tu navegador",
                icon: "warning",
                closeModal: false
            }).then(function () {
                doSubmitPoliza();
            })
        }
        else
            doSubmitPoliza();

      

    }
    //else {
    //    var validator = $("#FormEmision").data("validator");
    //    swal('Lockton One', validator.errorList[0].element.id + " - "+ validator.errorList[0].message, 'error');
    //}
}

function doSubmitPoliza() {
    var iOS = getMobileOperatingSystem() == "iOS"
    var aseguradora = $("#Aseguradora").val();
   
    if (iOS)
        $("#modal-iOS").modal("show");
    else {
        if (aseguradora == 'INBURSA') {
            $.blockUI({ message: '<img src="/../img/loader.gif" /> <h3>Procesando Solicitud...</h3><h4>Es indispensable que descargues tu póliza y las condiciones generales, te informamos que te serán enviadas al correo que registraste previamente</h4>' });
        }
        else {
            $.blockUI({ message: '<img src="/../img/loader.gif" /> <h3>Emitiendo Póliza...</h3><h4>Es indispensable que descargues tu póliza y las condiciones generales, te informamos que te serán enviadas al correo que registraste previamente</h4>' });
        }
    }

    $("#btnContratarSubmit").click();
}

function curpValida(curp) {
    var re = /^([A-Z][AEIOUX][A-Z]{2}\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])[HM](?:AS|B[CS]|C[CLMSH]|D[FG]|G[TR]|HG|JC|M[CNS]|N[ETL]|OC|PL|Q[TR]|S[PLR]|T[CSL]|VZ|YN|ZS)[B-DF-HJ-NP-TV-Z]{3}[A-Z\d])(\d)$/,
        validado = curp.match(re);

    if (!validado)  //Coincide con el formato general?
        return false;

    //Validar que coincida el dígito verificador
    function digitoVerificador(curp17) {
        //Fuente https://consultas.curp.gob.mx/CurpSP/
        var diccionario = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ",
            lngSuma = 0.0,
            lngDigito = 0.0;
        for (var i = 0; i < 17; i++)
            lngSuma = lngSuma + diccionario.indexOf(curp17.charAt(i)) * (18 - i);
        lngDigito = 10 - lngSuma % 10;
        if (lngDigito == 10) return 0;
        return lngDigito;
    }

    if (validado[2] != digitoVerificador(validado[1]))
        return false;

    return true; //Validado
}
