using ClosedXML.Excel;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.Banorte.Emision;
using LocktonOneWeb.Controllers;
using LocktonOneWeb.Controllers.Polizas;
using LocktonServicios.Services.EnvioEmail;
using LocktonServicios.Utilidades;
using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;

namespace LocktonOneWeb.Handlers
{
    /// <summary>
    /// Excel → PeticionPolizaProcesoMasivo + PolizaProcesoCarga (staging).
    /// LocktonOneProcess (__ProcesoMasivoCargaPoliza__) pasa el staging a Poliza/PolizaDetalle, PolizaCasa/PolizaDetalleCasa o PolizaProducto/PolizaProductoDetalle.
    /// </summary>
    public static class CargaPolizaMasivaHandler
    {
        public const int TipoAutos = 1;
        public const int TipoHogar = 2;
        public const int TipoMascotas = 3;
        private static readonly ILog log = LogManager.GetLogger(typeof(AccountController));
        public static readonly string[] ColumnasAutos =
        {
            "NumeroPoliza", "Email", "UserName",
            "Empresa", "ClaveAgente", "Aseguradora",
            "Motor", "Serie", "Placas", "Marca", "Modelo", "Anio", "Descripcion", "TipoVehiculo", "ClaveVehicular",
            "InicioVigencia", "FinVigencia", "FechaEmision", "FechaNacimiento",
            "PrimaNeta", "PrimaTotal", "ConductorHabitual", "RFC",
            "TipoCobertura", "Parentesco", "TipoEmision", "EsEmisionPersonaMoral",
            "Derechos", "FormaPago", "Periodicidad",
            "PM_NombreComercial", "PM_RazonSocial", "PM_RFC", "PM_Calle", "PM_NumeroExt", "PM_NumeroInt",
            "PM_CodigoPostal", "PM_Colonia", "PM_FechaConstitucion", "PM_FolioMercantil", "PM_Actividad",
            "RL_Nombre", "RL_ApellidoPaterno", "RL_ApellidoMaterno", "RL_Telefono", "RL_Correo", "RL_FechaNacimiento"
        };

        public static readonly string[] ColumnasObligatoriasPersonaMoral =
        {
            "PM_NombreComercial", "PM_RazonSocial", "PM_RFC", "PM_Calle", "PM_NumeroExt",
            "PM_CodigoPostal", "PM_Colonia",
            "RL_Nombre", "RL_ApellidoPaterno", "RL_ApellidoMaterno", "RL_Telefono", "RL_Correo",
            "RL_FechaNacimiento"
        };

        public static readonly string[] ColumnasHogar =
        {
            "NumeroPoliza", "Email", "IdConvenio", "IdCotizacion", "IdCotizacionAseguradora", "Aseguradora",
            "IdEmisionAseguradora", "Nombre", "ApellidoPaterno", "ApellidoMaterno",
            "MetodoPago_Desc", "PrimaTotal", "CodigoProducto", "CodigoPlan",
            "InicioVigencia", "FinVigencia", "FormaPago", "MetodoPago", "StatusPoliza",
            "FechaCancelacion", "RazonCancelacion", "Estatus",
            "PrimaNeta", "Deducible", "Recargos", "Impuesto", "Comision", "FactorIva", "Derechos",
            "IdPersona", "EsSeguro", "EsBeneficiario", "TipoSeguro", "TipoIdentificacion", "RFC",
            "DetalleNombre", "DetalleApellidoPaterno", "DetalleApellidoMaterno", "Sexo", "FechaNacimiento",
            "MontoBeneficio", "UrlPDFPolizaOPERA", "PolizaOPERA", "OTOpera", "EndosoOPERA",
            "IdPolizaCORE", "CorreoEnvio", "IdMSI",
            "CodigoPostal", "Estado", "Municipio", "Colonia", "Calle", "NumeroExterior", "NumeroInterior", "ReferenciaMIT"
        };

        public static readonly string[] ColumnasMascotas =
        {
            "NumeroPoliza", "Email", "IdConvenio", "IdTipoMascota", "NombreMascota", "Raza", "Color", "Genero",
            "Years", "Months", "Caracteristicas", "EsPedigree",
            "InicioVigencia", "FinVigencia", "FechaEmision", "PrimaNeta", "PrimaTotal", "Estatus", "CodigoPostal",
            "Derechos", "Impuesto", "SumaAsegurada", "Referencia", "ReferenciaPago",
            "UrlPDFPolizaOPERA", "PolizaOPERA", "OTOpera", "EndosoOPERA",
            "IdCotizacion", "IdCotizacionDetalle", "IdCatModalidadFormaPago", "IdCatPeriodicidadFormaPago",
            "IdPolizaCORE", "CorreoEnvio", "IdMSI"
        };

        public static readonly string[] ColumnasRecibos =
        {
            "NumeroPoliza", "Numero", "InicioVigencia", "FinVigencia",
            "PrimaNeta", "PrimaTotal", "Derecho", "Recargo", "Impuesto", "Comision"
        };

        public static readonly string[] ColumnasObligatoriasRecibos =
        {
            "NumeroPoliza", "Numero", "InicioVigencia", "FinVigencia", "PrimaNeta", "PrimaTotal"
        };

        public static readonly string[] ColumnasObligatorias =
        {
            "NumeroPoliza", "Email", "UserName", "Empresa", "ClaveAgente", "Aseguradora",
            "Motor", "Serie", "Placas", "Marca", "Modelo", "TipoVehiculo", "ClaveVehicular",
            "InicioVigencia", "FinVigencia", "FechaEmision", "FechaNacimiento",
            "PrimaNeta", "PrimaTotal", "ConductorHabitual", "RFC",
            "TipoCobertura", "Parentesco", "TipoEmision", "EsEmisionPersonaMoral",
            "Derechos", "FormaPago", "Periodicidad"
        };

        public static bool SelfCheck() =>
            ColumnasAutos.Contains("TipoCobertura") && ColumnasAutos.Contains("Marca")
            && ColumnasHogar.Contains("Calle") && ColumnasMascotas.Contains("NombreMascota")
            && ColumnasObligatorias.All(c => ColumnasAutos.Contains(c))
            && ColumnasObligatoriasRecibos.All(c => ColumnasRecibos.Contains(c));

        public static string NombreHoja(int idTipo)
        {
            switch (idTipo)
            {
                case TipoAutos: return "Autos";
                case TipoHogar: return "Hogar";
                case TipoMascotas: return "Mascotas";
                default: return "Autos";
            }
        }

        public static string[] ColumnasDe(int idTipo)
        {
            switch (idTipo)
            {
                case TipoHogar: return ColumnasHogar;
                case TipoMascotas: return ColumnasMascotas;
                default: return ColumnasAutos;
            }
        }

        public static byte[] LayoutExcel()
        {
            string[] empresas;
            using (var db = new ApplicationDbContext())
            {
                empresas = db.Empresa
                    .Where(e => e.Estatus == 1 && e.Id != 1 && e.RazonSocial != null && e.RazonSocial != "")
                    .Select(e => new { e.RazonSocial, e.ClaveEmpresa })
                    .ToList()
                    .Select(e => string.Format("{0} -- {1}", e.RazonSocial, e.ClaveEmpresa ?? "").Trim())
                    .Distinct()
                    .OrderBy(n => n)
                    .ToArray();
            }
            using (var wb = new XLWorkbook())
            {
                var ws = EscribeHoja(wb, "Autos", ColumnasAutos);
                EscribeHoja(wb, "Recibos", ColumnasRecibos,
                    new HashSet<string>(ColumnasObligatoriasRecibos, StringComparer.OrdinalIgnoreCase));
                EscribeCatalogosYListas(wb, ws, ColumnasAutos, empresas);
                using (var ms = new MemoryStream())
                {
                    wb.SaveAs(ms);
                    return ms.ToArray();
                }
            }
        }

        public static DataTable TablaDeTipo(DataSet set, int idTipo)
        {
            var hoja = NombreHoja(idTipo);
            if (set.Tables.Contains(hoja)) return set.Tables[hoja];
            return set.Tables.Count > 0 ? set.Tables[0] : null;
        }

        public static DataTable TablaRecibos(DataSet set)
        {
            if (set == null) return null;
            foreach (DataTable t in set.Tables)
            {
                if (string.Equals(t.TableName, "Recibos", StringComparison.OrdinalIgnoreCase))
                    return t;
            }
            return null;
        }

        public static bool ValidaColumnas(DataTable table, int idTipo, ref string mensaje)
        {
            var faltantes = ColumnasDe(idTipo).Where(c => !table.Columns.Contains(c)).ToList();
            if (faltantes.Count == 0) return true;
            mensaje = string.Join("<br/>", faltantes.Select(c => $"No se encontró la columna '{c}'. Use la hoja {NombreHoja(idTipo)} del layout."));
            return false;
        }

        /// <summary>
        /// Rechaza filas con campos de ColumnasObligatorias vacíos
        /// (mismos campos marcados Obligatorio en el layout).
        /// </summary>
        public static bool ValidaValoresObligatorios(DataTable table, ref string mensaje)
        {
            if (table == null) return true;
            var valid = true;
            int filaExcel = 2;
            foreach (DataRow row in table.Rows)
            {
                filaExcel++;
                if (EsFilaInstruccionesOVacia(row)) continue;

                var poliza = table.Columns.Contains("NumeroPoliza")
                    ? Convert.ToString(row["NumeroPoliza"])?.Trim()
                    : null;
                if (string.IsNullOrWhiteSpace(poliza))
                    poliza = $"fila {filaExcel}";

                foreach (var col in ColumnasObligatorias)
                {
                    if (!table.Columns.Contains(col)) continue;
                    var valor = row[col];
                    if (valor == null || valor == DBNull.Value
                        || string.IsNullOrWhiteSpace(Convert.ToString(valor)))
                    {
                        valid = false;
                        mensaje += $"NumeroPoliza '{poliza}' (fila Excel ~{filaExcel}): {col} es obligatoria.<br/>";
                    }
                }

                if (Bool(row, "EsEmisionPersonaMoral"))
                {
                    foreach (var col in ColumnasObligatoriasPersonaMoral)
                    {
                        if (!table.Columns.Contains(col))
                        {
                            valid = false;
                            mensaje += $"NumeroPoliza '{poliza}' (fila Excel ~{filaExcel}): {col} es obligatoria si EsEmisionPersonaMoral=1.<br/>";
                            continue;
                        }
                        var valor = row[col];
                        if (valor == null || valor == DBNull.Value
                            || string.IsNullOrWhiteSpace(Convert.ToString(valor)))
                        {
                            valid = false;
                            mensaje += $"NumeroPoliza '{poliza}' (fila Excel ~{filaExcel}): {col} es obligatoria si EsEmisionPersonaMoral=1.<br/>";
                        }
                    }
                }
            }
            return valid;
        }

        public static bool ValidaRecibos(DataTable autos, DataTable recibos, ref string mensaje)
        {
            if (recibos == null)
            {
                mensaje += "No se encontró la hoja Recibos. Use el layout actualizado.<br/>";
                return false;
            }
            var faltantes = ColumnasRecibos.Where(c => !recibos.Columns.Contains(c)).ToList();
            if (faltantes.Count > 0)
            {
                mensaje += string.Join("<br/>", faltantes.Select(c => $"Hoja Recibos: no se encontró la columna '{c}'."));
                mensaje += "<br/>";
                return false;
            }

            var polizas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int filaAuto = 2;
            foreach (DataRow row in autos.Rows)
            {
                filaAuto++;
                if (EsFilaInstruccionesOVacia(row)) continue;
                var n = Celda(row, "NumeroPoliza");
                if (!string.IsNullOrWhiteSpace(n))
                    polizas.Add(n);
            }

            var polizasConRecibo = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var valid = true;
            int filaExcel = 2;
            foreach (DataRow row in recibos.Rows)
            {
                filaExcel++;
                if (EsFilaInstruccionesOVacia(row)) continue;
                var poliza = Celda(row, "NumeroPoliza");
                if (string.IsNullOrWhiteSpace(poliza))
                    poliza = $"fila {filaExcel}";

                foreach (var col in ColumnasObligatoriasRecibos)
                {
                    if (string.IsNullOrWhiteSpace(Celda(row, col)))
                    {
                        valid = false;
                        mensaje += $"Hoja Recibos, NumeroPoliza '{poliza}' (fila Excel ~{filaExcel}): {col} es obligatoria.<br/>";
                    }
                }

                var npol = Celda(row, "NumeroPoliza");
                if (!string.IsNullOrWhiteSpace(npol))
                {
                    if (!polizas.Contains(npol))
                    {
                        valid = false;
                        mensaje += $"Hoja Recibos, NumeroPoliza '{npol}' (fila Excel ~{filaExcel}): no existe en la hoja Autos.<br/>";
                    }
                    else
                        polizasConRecibo.Add(npol);
                }
            }

            if (polizasConRecibo.Count == 0)
            {
                mensaje += "La hoja Recibos no tiene filas. Agregue al menos un recibo por póliza.<br/>";
                return false;
            }
            foreach (var n in polizas)
            {
                if (!polizasConRecibo.Contains(n))
                {
                    valid = false;
                    mensaje += $"NumeroPoliza '{n}': no tiene recibos en la hoja Recibos.<br/>";
                }
            }
            return valid;
        }

        public static void Encolar(DataTable table, int idTipoPoliza, int idUsuario, string userName, string correoReporte = null, DataTable recibos = null)
        {
            using (var db = new ApplicationDbContext())
            {
                var pet = new PeticionPolizaProcesoMasivo
                {
                    UserRealizaPeticion = userName,
                    IdUsuario = idUsuario,
                    FechaAlta = DateTime.Now,
                    IdTipoPoliza = idTipoPoliza,
                    EstatusPeticion = false,
                    CorreoEnvioReporte = correoReporte
                };
                db.PeticionPolizaProcesoMasivo.Add(pet);
                db.SaveChanges();

                var staging = new DataTable();
                staging.Columns.Add("IdPeticion", typeof(int));
                staging.Columns.Add("IdTipoPoliza", typeof(int));
                staging.Columns.Add("Row", typeof(int));
                staging.Columns.Add("IdEstatus", typeof(bool));
                foreach (var col in ColumnasDe(idTipoPoliza))
                    if (!staging.Columns.Contains(col))
                        staging.Columns.Add(col, typeof(string));

                int excelRow = 3;
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    var r = table.Rows[i];
                    if (EsFilaInstruccionesOVacia(r))
                        continue;
                    var nr = staging.NewRow();
                    nr["IdPeticion"] = pet.Id;
                    nr["IdTipoPoliza"] = idTipoPoliza;
                    nr["Row"] = excelRow++;
                    nr["IdEstatus"] = false;
                    foreach (var col in ColumnasDe(idTipoPoliza))
                    {
                        var valor = Celda(r, col);
                        if (col.Equals("EsEmisionPersonaMoral", StringComparison.OrdinalIgnoreCase))
                            valor = NormalizarEsEmisionPersonaMoral(valor);
                        nr[col] = valor;
                    }
                    staging.Rows.Add(nr);
                }

                using (var cn = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString()))
                {
                    cn.Open();
                    using (var bulk = new SqlBulkCopy(cn) { DestinationTableName = "dbo.PolizaProcesoCarga", BulkCopyTimeout = int.MaxValue })
                    {
                        foreach (DataColumn col in staging.Columns)
                            bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                        bulk.WriteToServer(staging);
                    }
                }

                if (recibos != null && idTipoPoliza == TipoAutos)
                    EncolarRecibos(pet.Id, recibos);
            }
        }

        private static void EncolarRecibos(int idPeticion, DataTable recibos)
        {
            var staging = new DataTable();
            staging.Columns.Add("IdPeticion", typeof(int));
            staging.Columns.Add("Row", typeof(int));
            staging.Columns.Add("IdEstatus", typeof(bool));
            foreach (var col in ColumnasRecibos)
                staging.Columns.Add(col, typeof(string));

            int excelRow = 3;
            for (int i = 0; i < recibos.Rows.Count; i++)
            {
                var r = recibos.Rows[i];
                if (EsFilaInstruccionesOVacia(r))
                    continue;
                var nr = staging.NewRow();
                nr["IdPeticion"] = idPeticion;
                nr["Row"] = excelRow++;
                nr["IdEstatus"] = false;
                foreach (var col in ColumnasRecibos)
                    nr[col] = Celda(r, col);
                staging.Rows.Add(nr);
            }
            if (staging.Rows.Count == 0)
                return;

            using (var cn = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString()))
            {
                cn.Open();
                using (var bulk = new SqlBulkCopy(cn) { DestinationTableName = "dbo.ReciboProcesoCarga", BulkCopyTimeout = int.MaxValue })
                {
                    foreach (DataColumn col in staging.Columns)
                        bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                    bulk.WriteToServer(staging);
                }
            }
        }

        public static void ProcesarPendientes()
        {
            log.Info("Entra en metodo ProcesarPendientes");
            using (var db = new ApplicationDbContext())
            {
                var peticiones = db.PeticionPolizaProcesoMasivo
                    .Where(p => !p.EstatusPeticion && p.IdTipoPoliza == TipoAutos)
                    .ToList();
                log.Info("Obtiene datos PeticionPolizaProcesoMasivo");
                foreach (var pet in peticiones)
                {
                   
                    var filas = db.PolizaProcesoCarga
                        .Where(f => f.IdPeticion == pet.Id && !f.IdEstatus)
                        .OrderBy(f => f.Row)
                        .ToList();
                    log.Info("Obtiene datos PolizaProcesoCarga");
                    foreach (var fila in filas)
                    {
                        try
                        {
                            GuardarFila(db, fila, pet);
                            fila.IdEstatus = true;
                            fila.Error = null;
                        }
                        catch (Exception ex)
                        {
                            log.Info("error: " + ex.ToString());
                            fila.IdEstatus = true;
                            fila.Error = ex.InnerException?.Message ?? ex.Message;
                        }
                        db.SaveChanges();
                    }
                    pet.EstatusPeticion = true;
                    pet.FechaProceso = DateTime.Now;
                    db.SaveChanges();

                    if (filas.Count > 0)
                        EnviarReporte(pet, filas);
                }
            }
            log.Info("termina en metodo ProcesarPendientes");
        }

        private static void EnviarReporte(PeticionPolizaProcesoMasivo pet, List<PolizaProcesoCarga> filas)
        {
            if (string.IsNullOrWhiteSpace(pet.CorreoEnvioReporte))
                return;

            var destinatarios = pet.CorreoEnvioReporte.Split(';')
                .Select(c => (c ?? string.Empty).Trim().TrimEnd('.', ',', ';', ' '))
                .Where(c => !string.IsNullOrEmpty(c))
                .ToList();
            if (destinatarios.Count == 0)
                return;

            try
            {
                using (var wb = new XLWorkbook())
                {
                    var ws = wb.Worksheets.Add("Carga de polizas");
                    ws.Cell(1, 1).Value = "NumeroPoliza";
                    ws.Cell(1, 2).Value = "Email";
                    ws.Cell(1, 3).Value = "Estatus";
                    ws.Cell(1, 4).Value = "Mensaje";

                    int r = 2;
                    foreach (var fila in filas)
                    {
                        bool ok = string.IsNullOrEmpty(fila.Error);
                        ws.Cell(r, 1).Value = fila.NumeroPoliza;
                        ws.Cell(r, 2).Value = fila.Email;
                        ws.Cell(r, 3).Value = ok ? "Exitoso" : "Error";
                        ws.Cell(r, 4).Value = ok ? "Póliza procesada." : fila.Error;
                        r++;
                    }

                    using (var ms = new MemoryStream())
                    {
                        wb.SaveAs(ms);
                        ms.Position = 0;
                        var attachments = new List<Attachment>
                        {
                            new Attachment(ms, "ReporteCargaPolizas.xlsx", MediaTypeNames.Application.Octet)
                        };
                        var servicioEmail = new ServicioEmail();
                        string mensajeCorreo = $"Reporte de carga masiva de pólizas generado a la fecha: {DateTime.Now.ToLongDateString()}";
                        servicioEmail.EnviarEmailEnviosOpera(destinatarios, "Reporte carga de pólizas Lockton ONE", mensajeCorreo, attachments);
                    }
                }
            }
            catch
            {
            }
        }

        private static void GuardarFila(ApplicationDbContext db, PolizaProcesoCarga fila, PeticionPolizaProcesoMasivo pet)
        {
            try
            {
                log.Info("Entra  GuardarFila");
                int idParentescoTitular = db.CatParentesco.Where(p => p.Nombre == "Titular").Select(p => p.Id).FirstOrDefault();
                if (idParentescoTitular == 0) idParentescoTitular = 1;

                if (pet.IdTipoPoliza != TipoAutos)
                    throw new InvalidOperationException("por ahora solo se procesan pólizas de Autos.");
                var numero = Celda(fila, "NumeroPoliza");
                if (string.IsNullOrWhiteSpace(numero))
                    throw new InvalidOperationException("NumeroPoliza obligatorio.");
                ResolverConvenioUsuario(db, fila, pet.IdTipoPoliza, out int idConvenio, out int idEmpresa, out var usuario);

                using (var tx = db.Database.BeginTransaction())
                {
                    switch (pet.IdTipoPoliza)
                    {
                        case TipoAutos:
                            GuardarAutos(db, fila, numero, usuario, idConvenio, pet.IdUsuario, pet.UserRealizaPeticion, idParentescoTitular, pet.Id);
                            break;
                        case TipoHogar:
                            GuardarHogar(db, fila, numero, usuario, idConvenio);
                            break;
                        case TipoMascotas:
                            GuardarMascotas(db, fila, numero, usuario, idConvenio, pet.IdUsuario, pet.UserRealizaPeticion);
                            break;
                        default:
                            throw new InvalidOperationException("tipo de póliza no soportado.");
                    }
                    tx.Commit();
                }
            }
            catch (Exception ex)
            {

                log.Info("error GuardarFila: " + ex.ToString());
            }
            
            log.Info("termina  GuardarFila");
        }

        public static List<string> Guardar(DataTable table, int idTipoPoliza, int idUsuarioEmite, string userNameEmite)
        {
            var errores = new List<string>();
            using (var db = new ApplicationDbContext())
            {
                int idParentescoTitular = db.CatParentesco.Where(p => p.Nombre == "Titular").Select(p => p.Id).FirstOrDefault();
                if (idParentescoTitular == 0) idParentescoTitular = 1;

                int excelRow = 3;
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    var r = table.Rows[i];
                    if (EsFilaInstruccionesOVacia(r))
                        continue;
                    int fila = excelRow++;
                    using (var tx = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var numero = Celda(r, "NumeroPoliza");
                            if (string.IsNullOrWhiteSpace(numero))
                            {
                                errores.Add($"Fila {fila}: NumeroPoliza obligatorio.");
                                tx.Rollback();
                                continue;
                            }
                            ResolverConvenioUsuario(db, r, idTipoPoliza, out int idConvenio, out int idEmpresa, out var usuario);

                            switch (idTipoPoliza)
                            {
                                case TipoAutos:
                                    GuardarAutos(db, r, numero, usuario, idConvenio, idUsuarioEmite, userNameEmite, idParentescoTitular, 0);
                                    break;
                                case TipoHogar:
                                    GuardarHogar(db, r, numero, usuario, idConvenio);
                                    break;
                                case TipoMascotas:
                                    GuardarMascotas(db, r, numero, usuario, idConvenio, idUsuarioEmite, userNameEmite);
                                    break;
                                default:
                                    errores.Add($"Fila {fila}: tipo no soportado.");
                                    tx.Rollback();
                                    continue;
                            }
                            tx.Commit();
                        }
                        catch (Exception ex)
                        {
                            tx.Rollback();
                            errores.Add($"Fila {fila}: {ex.InnerException?.Message ?? ex.Message}");
                        }
                    }
                }
            }
            return errores;
        }

        private static void GuardarAutos(ApplicationDbContext db, object r, string numero, DetalleUsuario usuario,
            int idConvenio, int idUsuarioEmite, string userNameEmite, int idParentescoTitular, int idPeticion)
        {
            try
            {
                log.Info("Entra  GuardarAutos");
                if (db.Poliza.Any(p => p.NumeroPoliza == numero))
                    throw new InvalidOperationException($"póliza autos '{numero}' ya existe.");

                FechaO(r, "InicioVigencia", out var inicio);
                FechaO(r, "FinVigencia", out var fin);
                if (inicio == default || fin == default)
                    throw new InvalidOperationException("InicioVigencia y FinVigencia son obligatorios.");
                if (string.IsNullOrWhiteSpace(Celda(r, "PrimaNeta")))
                    throw new InvalidOperationException("PrimaNeta obligatoria.");
                if (string.IsNullOrWhiteSpace(Celda(r, "PrimaTotal")))
                    throw new InvalidOperationException("PrimaTotal obligatoria.");

                FechaO(r, "FechaEmision", out var emision);
                if (emision == default) emision = DateTime.Now;

                var convenio = db.Convenio.First(x => x.Id == idConvenio);
                var idTipoCobertura = ResolverTipoCobertura(db, Nvl(Celda(r, "TipoCobertura"), Celda(r, "IdTipoCobertura")));
                var idParentesco = ResolverParentesco(db, Nvl(Celda(r, "Parentesco"), Celda(r, "IdParentesco")), idParentescoTitular);
                var idModalidad = ResolverModalidad(db, Nvl(Celda(r, "FormaPago"), Celda(r, "IdCatModalidadFormaPago")));
                var idPeriodicidad = ResolverPeriodicidad(db, Nvl(Celda(r, "Periodicidad"), Celda(r, "IdCatPeriodicidadFormaPago")));
                int? idMsi = null;
                var esMoral = Bool(r, "EsEmisionPersonaMoral")
                    || Bool(r, "IdPersonaMoral")
                    || EsPersonaMoral(Celda(r, "TipoEmision"));
                PersonaMoral personaMoral = null;
                if (esMoral)
                    personaMoral = AgregarPersonaMoralMasivo(db, r, convenio.IdEmpresa);
                int? idPersonaMoral = personaMoral?.Id;

                FechaO(r, "FechaNacimiento", out var fechaNac);
                var edad = fechaNac != default ? Utilidades.CalculaEdad(fechaNac) : 0;
                var idTipoVehiculo = ResolverTipoVehiculo(Celda(r, "TipoVehiculo"));
                var paqueteConvenio = ResolverPaqueteConvenio(db, idConvenio, idTipoCobertura, idTipoVehiculo,
                    Nvl(Celda(r, "TipoCobertura"), Celda(r, "IdTipoCobertura")));

                var cot = new Cotizacion
                {
                    IdPeriodicidadPago = idPeriodicidad,
                    IdDetalleUsuario = usuario.Id,
                    IdTitular = usuario.Id,
                    Estatus = 1,
                    IdProcesoMasivo = 1,
                    IdVehiculo = idTipoVehiculo,
                    FechaHora = DateTime.Now,
                    FechaFactura = DateTime.Now,
                    Edad = edad,
                    FechaNacimiento = fechaNac == default ? (DateTime?)null : fechaNac,
                    EmisionPersonaMoral = esMoral,
                    Acepto_AvisoPrivacidad_Lockton = true,
                    Acepto_TerminosCondiciones_Lockton = true
                };
                db.Cotizacion.Add(cot);
                db.SaveChanges();
                log.Info("Guarda  Cotizacion");
                var cotAuto = new CotizacionAuto
                {
                    IdCotizacion = cot.Id,
                    TipoVehiculo = "1",
                    Marca = Celda(r, "Marca"),
                    Modelo = Celda(r, "Modelo"),
                    Agnio = Celda(r, "Anio"),
                    Version = "",
                    Descripcion = Celda(r, "Descripcion"),
                    FechaFactura = DateTime.Now,
                    Cobertura = idTipoCobertura,
                    FormadePago = idPeriodicidad,
                    MediodePago = idModalidad,
                    AvisoPrivacidad = true,
                    TerminosCondiciones = true,
                    FechaAvisoTerminos = DateTime.Now,
                    Amis = Celda(r, "ClaveVehicular"),
                    Serie = Celda(r, "Serie")
                };
                db.CotizacionAuto.Add(cotAuto);
                db.SaveChanges();
                log.Info("Guarda  CotizacionAuto");
                var cotDet = new CotizacionDetalle
                {
                    XMLSolicitud = "",
                    XMLRecepcion = "",
                    FechaSolicitud = DateTime.Now,
                    IdCotizacion = cot.Id,
                    Estatus = 1,
                    IdVehiculo = idTipoVehiculo,
                    Periodicidad = "",
                    Paquete = paqueteConvenio.IdCatTipoPaquete.ToString(),
                    PrimaTotalAnual = Dec(r, "PrimaTotal"),
                    IdAseguradora = convenio.IdAseguradora,
                    IdConvenio = idConvenio,
                    IdPaqueteConvenio = paqueteConvenio.Id,
                    AMIS = Celda(r, "ClaveVehicular"),
                    IdFormaPago = idPeriodicidad,
                    IdMedioPago = idModalidad,
                    FechaCotizacion = DateTime.Now
                };
                db.CotizacionDetalle.Add(cotDet);
                db.SaveChanges();
                log.Info("Guarda  CotizacionDetalle");
                var primaNeta = Dec(r, "PrimaNeta");
                var primaTotal = Dec(r, "PrimaTotal");
                var poliza = new Poliza
                {
                    NumeroPoliza = numero,
                    Motor = Celda(r, "Motor"),
                    Serie = Celda(r, "Serie"),
                    Placas = Celda(r, "Placas"),
                    InicioVigencia = inicio,
                    FinVigencia = fin,
                    FechaEmision = emision,
                    PrimaNeta = primaNeta,
                    PrimaNetaAnualizada = primaNeta,
                    PrimaTotal = primaTotal,
                    PrimaTotalAnualizada = primaTotal,
                    ConductorHabitual = Celda(r, "ConductorHabitual"),
                    Estatus = 1,
                    IdUsuario = usuario.Id,
                    IdConvenio = idConvenio,
                    IdTipoCobertura = idTipoCobertura,
                    IdParentesco = idParentesco,
                    IdPersonaMoral = idPersonaMoral,
                    IdUsuarioEmite = idUsuarioEmite,
                    UserNameEmite = userNameEmite,
                    EmisionSinDatoBancario = true,
                    Acepto_AvisoPrivacidad_Aseguradora = true,
                    Acepto_DescuentoPoliza = true
                };
                db.Poliza.Add(poliza);
                db.SaveChanges();
                log.Info("Guarda  Poliza");
                var contratante = GeneraContratanteMasivo(db, convenio, usuario, r, personaMoral, esMoral, fechaNac);
                db.PolizaDetalle.Add(new PolizaDetalle
                {
                    IdPoliza = poliza.Id,
                    Derechos = Dec(r, "Derechos"),
                    Inciso = "",
                    RenovacionAutomatica = Bool(r, "RenovacionAutomatica"), // CAT Renovación automática: respeta el valor de la carga masiva y evita registrar aceptaciones no informadas.
                    FechaDecisionRenovacionAutomaticaUtc = null, // CAT Renovación automática: una carga masiva no prueba que el aviso se mostró al usuario.
                    FactorIva = 16,
                    IdCotizacionAuto = cotAuto.Id,
                    IdCotizacionDetalle = cotDet.Id,
                    IdCatModalidadFormaPago = idModalidad,
                    IdCatPeriodicidadFormaPago = idPeriodicidad,
                    IdContratante = contratante?.Id,
                    CorreoEnvio = Nvl(Celda(r, "CorreoEnvio"), usuario.Correo),
                    IdMSI = idMsi,
                    IdCatRamoVehiculo = idTipoVehiculo,
                    MigraOPERA = false,
                    MigraCORE = false,
                    MigraBemobile = false
                });
                db.SaveChanges();
                log.Info("Guarda  PolizaDetalle");
                var tipoAlta = db.TipoEndoso.FirstOrDefault(x => x.Clave == "A");
                if (tipoAlta == null)
                    throw new InvalidOperationException("No existe TipoEndoso con Clave 'A'.");
                var endoso = new Endoso
                {
                    IdPoliza = poliza.Id,
                    IdTipoEndoso = tipoAlta.Id,
                    Fecha = emision,
                    ValorAnterior = "Alta",
                    ValorActual = "Contratación",
                    Completado = true,
                    OT = 0,
                    TicketZendesk = 0,
                    GeneroTicketCore = false,
                    GeneroTicketOpera = false,
                    EjecutadoAseguradora = false
                };
                db.Endoso.Add(endoso);
                db.SaveChanges();
                log.Info("Guarda  Endoso");
                GuardarRecibosMasivo(db, idPeticion, numero, endoso.Id);
            }
            catch (Exception ex)
            {
                log.Info("Error GuardarAutos" + ex.ToString());
            }
            
        }

        private static void GuardarRecibosMasivo(ApplicationDbContext db, int idPeticion, string numeroPoliza, int idEndoso)
        {
            log.Info("Entra  GuardarRecibosMasivo");
            if (idPeticion <= 0)
                throw new InvalidOperationException($"NumeroPoliza '{numeroPoliza}': no hay petición para cargar recibos.");

            var filas = db.ReciboProcesoCarga
                .Where(x => x.IdPeticion == idPeticion)
                .ToList()
                .Where(x => string.Equals((x.NumeroPoliza ?? "").Trim(), numeroPoliza.Trim(), StringComparison.OrdinalIgnoreCase))
                .OrderBy(x => x.Row)
                .ToList();
            if (filas.Count == 0)
                throw new InvalidOperationException($"NumeroPoliza '{numeroPoliza}': no hay recibos en staging.");

            foreach (var fila in filas)
            {
                FechaO(fila, "InicioVigencia", out var ini);
                FechaO(fila, "FinVigencia", out var fin);
                if (ini == default || fin == default)
                    throw new InvalidOperationException($"NumeroPoliza '{numeroPoliza}': InicioVigencia y FinVigencia del recibo son obligatorios.");
                if (!Ent(fila, "Numero", out var num) || num <= 0)
                    throw new InvalidOperationException($"NumeroPoliza '{numeroPoliza}': Numero de recibo inválido.");
                var neta = Celda(fila, "PrimaNeta");
                var total = Celda(fila, "PrimaTotal");
                if (string.IsNullOrWhiteSpace(neta) || string.IsNullOrWhiteSpace(total))
                    throw new InvalidOperationException($"NumeroPoliza '{numeroPoliza}': PrimaNeta y PrimaTotal del recibo son obligatorias.");

                db.Recibo.Add(new Recibo
                {
                    IdEndoso = idEndoso,
                    Numero = num,
                    InicioVigencia = ini,
                    FinVigencia = fin,
                    NoAsegurado = num.ToString(),
                    PrimaNeta = Dec(fila, "PrimaNeta"),
                    PrimaTotal = Dec(fila, "PrimaTotal"),
                    Derecho = Dec(fila, "Derecho"),
                    Recargo = Dec(fila, "Recargo"),
                    Impuesto = Dec(fila, "Impuesto"),
                    Comision = Dec(fila, "Comision")
                });
                fila.IdEstatus = true;
                fila.Error = null;
            }
            db.SaveChanges();
            log.Info("Termina guardar Recibos");
        }

        private static void GuardarHogar(ApplicationDbContext db, object r, string numero, DetalleUsuario usuario, int idConvenio)
        {
            if (db.PolizaCasa.Any(p => p.NumeroPoliza == numero))
                throw new InvalidOperationException($"póliza hogar '{numero}' ya existe.");

            FechaO(r, "InicioVigencia", out var inicio);
            FechaO(r, "FinVigencia", out var fin);
            if (inicio == default || fin == default)
                throw new InvalidOperationException("InicioVigencia y FinVigencia son obligatorios.");
            var nombre = Nvl(Celda(r, "Nombre"), usuario.Nombre);
            var apPat = Nvl(Celda(r, "ApellidoPaterno"), usuario.ApellidoPaterno);
            var apMat = Nvl(Celda(r, "ApellidoMaterno"), usuario.ApellidoMaterno);

            var poliza = new PolizaCasa
            {
                NumeroPoliza = numero,
                IdCotizacion = EntO(r, "IdCotizacion", 0),
                IdCotizacionAseguradora = Celda(r, "IdCotizacionAseguradora"),
                Aseguradora = Celda(r, "Aseguradora"),
                IdEmisionAseguradora = Celda(r, "IdEmisionAseguradora"),
                IdConvenio = idConvenio,
                IdUsuario = usuario.Id,
                Nombre = nombre,
                Apellido_Paterno = apPat,
                Apellido_Materno = apMat,
                MetodoPago_Desc = Celda(r, "MetodoPago_Desc"),
                Prima_Total = Dec(r, "PrimaTotal"),
                Codigo_Producto = Celda(r, "CodigoProducto"),
                Codigo_Plan = Celda(r, "CodigoPlan"),
                Inicio_Vigencia = inicio,
                Fin_Vigencia = fin,
                FormaPago = Celda(r, "FormaPago"),
                MetodoPago = Celda(r, "MetodoPago"),
                Status_Poliza = Celda(r, "StatusPoliza"),
                Fecha_Cancelacion = Celda(r, "FechaCancelacion"),
                Razon_Cancelacion = Celda(r, "RazonCancelacion"),
                Estatus = EntO(r, "Estatus", 1),
                Fecha = DateTime.Now,
                Acepto_AvisoPrivacidad_Aseguradora = true,
                Acepto_DescuentoPoliza = true
            };
            db.PolizaCasa.Add(poliza);
            db.SaveChanges();

            db.PolizaDetalleCasa.Add(new PolizaDetalleCasa
            {
                IdPoliza = poliza.Id,
                Prima_Neta = Dec(r, "PrimaNeta"),
                Deducible = Dec(r, "Deducible"),
                Recargos = Dec(r, "Recargos"),
                Impuesto = Dec(r, "Impuesto"),
                Comision = Dec(r, "Comision"),
                FactorIva = Dec(r, "FactorIva", 16),
                Derechos = Dec(r, "Derechos"),
                Id_Persona = Celda(r, "IdPersona"),
                Es_Seguro = Celda(r, "EsSeguro"),
                Es_Beneficiario = Celda(r, "EsBeneficiario"),
                Tipo_Seguro = Celda(r, "TipoSeguro"),
                Tipo_Identificacion = Celda(r, "TipoIdentificacion"),
                RFC = Celda(r, "RFC"),
                Nombre = Nvl(Celda(r, "DetalleNombre"), nombre),
                Apellido_Paterno = Nvl(Celda(r, "DetalleApellidoPaterno"), apPat),
                Apellido_Materno = Nvl(Celda(r, "DetalleApellidoMaterno"), apMat),
                Sexo = Celda(r, "Sexo"),
                Fecha_Nacimiento = Celda(r, "FechaNacimiento"),
                Monto_Beneficio = DecN(r, "MontoBeneficio"),
                Fecha = DateTime.Now,
                UrlPDFPolizaOPERA = Celda(r, "UrlPDFPolizaOPERA"),
                PolizaOPERA = EntN(r, "PolizaOPERA"),
                OTOpera = EntN(r, "OTOpera"),
                EndosoOPERA = EntN(r, "EndosoOPERA"),
                IdPolizaCORE = Celda(r, "IdPolizaCORE"),
                CorreoEnvio = Nvl(Celda(r, "CorreoEnvio"), usuario.Correo),
                IdMSI = EntN(r, "IdMSI"),
                CodigoPostal = Celda(r, "CodigoPostal"),
                Estado = Celda(r, "Estado"),
                Municipio = Celda(r, "Municipio"),
                Colonia = Celda(r, "Colonia"),
                Calle = Celda(r, "Calle"),
                NumeroExterior = Celda(r, "NumeroExterior"),
                NumeroInterior = Celda(r, "NumeroInterior"),
                ReferenciaMIT = Celda(r, "ReferenciaMIT")
            });
            db.SaveChanges();
        }

        private static void GuardarMascotas(ApplicationDbContext db, object r, string numero, DetalleUsuario usuario,
            int idConvenio, int idUsuarioEmite, string userNameEmite)
        {
            if (db.PolizaProducto.Any(p => p.NumeroPoliza == numero && p.IdProducto == 3))
                throw new InvalidOperationException($"póliza mascotas '{numero}' ya existe.");

            FechaO(r, "InicioVigencia", out var inicio);
            FechaO(r, "FinVigencia", out var fin);
            if (inicio == default || fin == default)
                throw new InvalidOperationException("InicioVigencia y FinVigencia son obligatorios.");
            FechaO(r, "FechaEmision", out var emision);
            if (emision == default) emision = DateTime.Now;

            var poliza = new PolizaProducto
            {
                IdProducto = 3,
                NumeroPoliza = numero,
                IdTipoMascota = EntN(r, "IdTipoMascota"),
                NombreMascota = Celda(r, "NombreMascota"),
                Raza = Celda(r, "Raza"),
                Color = Celda(r, "Color"),
                Genero = Celda(r, "Genero"),
                Years = EntO(r, "Years", 0),
                Months = EntO(r, "Months", 0),
                Caracteristicas = Celda(r, "Caracteristicas"),
                esPedigree = Bool(r, "EsPedigree"),
                InicioVigencia = inicio,
                FinVigencia = fin,
                FechaEmision = emision,
                PrimaNeta = Dec(r, "PrimaNeta"),
                PrimaTotal = Dec(r, "PrimaTotal"),
                Estatus = EntO(r, "Estatus", 1),
                IdUsuario = usuario.Id,
                IdConvenio = idConvenio,
                IdUsuarioEmite = idUsuarioEmite,
                UserNameEmite = userNameEmite,
                CodigoPostal = Celda(r, "CodigoPostal"),
                Acepto_AvisoPrivacidad_Aseguradora = true,
                Acepto_DescuentoPoliza = true
            };
            db.PolizaProducto.Add(poliza);
            db.SaveChanges();

            db.PolizaProductoDetalle.Add(new PolizaProductoDetalle
            {
                IdPoliza = poliza.Id,
                Derechos = Dec(r, "Derechos"),
                Impuesto = Dec(r, "Impuesto"),
                SumaAsegurada = Dec(r, "SumaAsegurada"),
                Referencia = Celda(r, "Referencia"),
                ReferenciaPago = Celda(r, "ReferenciaPago"),
                UrlPDFPolizaOPERA = Celda(r, "UrlPDFPolizaOPERA"),
                PolizaOPERA = EntN(r, "PolizaOPERA"),
                OTOpera = EntN(r, "OTOpera"),
                EndosoOPERA = EntN(r, "EndosoOPERA"),
                IdCotizacion = EntO(r, "IdCotizacion", 0),
                IdCotizacionDetalle = EntO(r, "IdCotizacionDetalle", 0),
                IdCatModalidadFormaPago = EntN(r, "IdCatModalidadFormaPago"),
                IdCatPeriodicidadFormaPago = EntN(r, "IdCatPeriodicidadFormaPago"),
                IdPolizaCORE = Celda(r, "IdPolizaCORE"),
                CorreoEnvio = Nvl(Celda(r, "CorreoEnvio"), usuario.Correo),
                IdMSI = EntN(r, "IdMSI")
            });
            db.SaveChanges();
        }

        private static void ResolverConvenioUsuario(ApplicationDbContext db, object r, int idTipo,
            out int idConvenio, out int idEmpresa, out DetalleUsuario usuario)
        {
            idConvenio = 0;
            idEmpresa = 0;
            usuario = null;
            if (idTipo == TipoAutos)
            {
                if (!TryConvenioAutos(db, r, out idConvenio, out idEmpresa, out var errConv))
                    throw new InvalidOperationException(errConv);
            }
            else
            {
                if (!Ent(r, "IdConvenio", out idConvenio) || idConvenio <= 0)
                    throw new InvalidOperationException("IdConvenio inválido.");
                if (!TryConvenio(db, idTipo, idConvenio, out idEmpresa, out var errConv))
                    throw new InvalidOperationException(errConv);
            }
            usuario = BuscarUsuario(db, idEmpresa, Celda(r, "Email"), Celda(r, "UserName"));
            if (usuario == null)
                throw new InvalidOperationException("no hay usuario final activo con Email/UserName en la empresa del convenio.");
        }

        private static bool TryConvenioAutos(ApplicationDbContext db, object r, out int idConvenio, out int idEmpresa, out string error)
        {
            idConvenio = 0;
            idEmpresa = 0;
            error = null;
            if (Ent(r, "IdConvenio", out var idDirecto) && idDirecto > 0)
                return TryConvenio(db, TipoAutos, idDirecto, out idEmpresa, out error) && (idConvenio = idDirecto) > 0;

            var empresa = ResolverEmpresa(db, Celda(r, "Empresa"));
            if (empresa == null)
            {
                error = "Empresa no encontrada. Seleccione un valor del catalogo Empresa.";
                return false;
            }
            var idEmp = empresa.Id;
            idEmpresa = idEmp;

            var aseguradora = ResolverAseguradora(db, Celda(r, "Aseguradora"));
            if (aseguradora == null)
            {
                error = "Aseguradora no encontrada (ClaveCore, Clave o Nombre).";
                return false;
            }

            if (!Ent(r, "ClaveAgente", out var claveAgente) || claveAgente <= 0)
            {
                //error = "ClaveAgente inválida.";
                //return false;
            }

            var idAseg = aseguradora.Id;

            var convenios = db.Convenio.Where(c => c.Estatus == 1 && c.IdEmpresa == idEmp && c.IdAseguradora == idAseg).ToList();
            var idModalidad = ResolverModalidad(db, Nvl(Celda(r, "FormaPago"), Celda(r, "IdCatModalidadFormaPago")));
            var idPeriodicidad = ResolverPeriodicidad(db, Nvl(Celda(r, "Periodicidad"), Celda(r, "IdCatPeriodicidadFormaPago")));

            if (claveAgente > 0)
            {
                var porClave = convenios.Where(c => c.ClaveAgente == claveAgente).ToList();
                if (porClave.Count > 0)
                    convenios = porClave;
            }

            var idsMfp = db.ModalidadFormaPago
                                        .Where(mfp =>
                                            mfp.IdCatPeriodicidadFormaPago == idPeriodicidad &&
                                            mfp.IdCatModalidadFormaPago == idModalidad &&
                                            (claveAgente <= 0 || mfp.ClaveAgenteModalidadFormaPago == claveAgente.ToString()))
                                        .Select(mfp => mfp.IdConvenio);

            var porFormaPago = convenios.Where(c => idsMfp.Contains(c.Id)).ToList();
            if (porFormaPago.Count > 0)
                convenios = porFormaPago;

            if (convenios.Count == 0)
            {
                error = "no hay convenio activo para empresa + aseguradora + forma de pago/periodicidad.";
                return false;
            }

            idConvenio = convenios[0].Id;
            return true;
        }

        private static Empresa ResolverEmpresa(ApplicationDbContext db, string valor)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return null;
            var q = db.Empresa.Where(e => e.Estatus == 1);
            const string sep = " -- ";
            var i = valor.LastIndexOf(sep, StringComparison.Ordinal);
            if (i >= 0)
            {
                var razon = valor.Substring(0, i).Trim();
                var clave = valor.Substring(i + sep.Length).Trim();
                if (!string.IsNullOrEmpty(clave))
                {
                    var porClave = q.FirstOrDefault(e => e.ClaveEmpresa == clave);
                    if (porClave != null) return porClave;
                }
                if (!string.IsNullOrEmpty(razon))
                {
                    var porRazonSep = q.FirstOrDefault(e => e.RazonSocial == razon && e.ClaveEmpresa == clave);
                    if (porRazonSep != null) return porRazonSep;
                    var soloRazon = q.FirstOrDefault(e => e.RazonSocial == razon);
                    if (soloRazon != null) return soloRazon;
                }
            }
            var porRazon = q.FirstOrDefault(e => e.RazonSocial == valor);
            if (porRazon != null) return porRazon;
            var porNombre = q.FirstOrDefault(e => e.NombreComercial == valor);
            if (porNombre != null) return porNombre;
            return q.FirstOrDefault(e => e.ClaveEmpresa == valor);
        }

        private static Aseguradora ResolverAseguradora(ApplicationDbContext db, string valor)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return null;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id))
            {
                var byId = db.Aseguradora.FirstOrDefault(a => a.Id == id && a.Estatus == 1);
                if (byId != null) return byId;
            }
            var up = valor.ToUpper();
            return db.Aseguradora.FirstOrDefault(a => a.Estatus == 1 && (
                a.Clave.ToUpper() == up || a.Nombre.ToUpper() == up
                || (a.ClaveHomologado != null && a.ClaveHomologado.ToUpper() == up)
                || (a.ClaveCore != null && a.ClaveCore.ToUpper() == up)));
        }

        private static int ResolverTipoVehiculo(string valor)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0 || valor.Equals("Auto", StringComparison.OrdinalIgnoreCase))
                return 1;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id) && id > 0)
                return id;
            throw new InvalidOperationException($"TipoVehiculo '{valor}' no es válido. Use Auto.");
        }

        private static int ResolverTipoCobertura(ApplicationDbContext db, string valor)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return 1;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id))
            {
                if (db.CatTipoCobertura.Any(c => c.Id == id)) return id;
                if (db.CatTipoPaquete.Any(c => c.Id == id)) return id;
            }
            var up = valor.ToUpper();
            var cob = db.CatTipoCobertura.FirstOrDefault(c => c.Nombre.ToUpper() == up || c.Clave.ToUpper() == up);
            if (cob != null) return cob.Id;
            var paq = db.CatTipoPaquete.FirstOrDefault(c => c.Nombre.ToUpper() == up || c.Clave.ToUpper() == up);
            if (paq != null) return paq.Id;
            throw new InvalidOperationException($"TipoCobertura '{valor}' no existe en CatTipoCobertura/CatTipoPaquete.");
        }

        private static PaqueteConvenio ResolverPaqueteConvenio(ApplicationDbContext db, int idConvenio,
            int idTipoCobertura, int idTipoVehiculo, string tipoCoberturaExcel)
        {
            var candidatos = db.PaqueteConvenio.Where(p =>
                p.IdConvenio == idConvenio && p.IdCatRamoVehiculo == idTipoVehiculo);

            var paquete = candidatos.FirstOrDefault(p => p.IdCatTipoPaquete == idTipoCobertura);
            if (paquete != null) return paquete;

            var idTipoPaquete = ResolverIdCatTipoPaquete(db, tipoCoberturaExcel, idTipoCobertura);
            paquete = candidatos.FirstOrDefault(p => p.IdCatTipoPaquete == idTipoPaquete);
            if (paquete != null) return paquete;

            throw new InvalidOperationException(
                $"No hay PaqueteConvenio para convenio {idConvenio}, tipo de cobertura {idTipoCobertura} y tipo de vehículo {idTipoVehiculo}.");
        }

        private static int ResolverIdCatTipoPaquete(ApplicationDbContext db, string valor, int idTipoCobertura)
        {
            if (db.CatTipoPaquete.Any(c => c.Id == idTipoCobertura))
                return idTipoCobertura;
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return idTipoCobertura;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id)
                && db.CatTipoPaquete.Any(c => c.Id == id))
                return id;
            var up = valor.ToUpper();
            var paq = db.CatTipoPaquete.FirstOrDefault(c =>
                c.Nombre.ToUpper() == up || c.Clave.ToUpper() == up
                || (c.Alias != null && c.Alias.ToUpper() == up));
            return paq != null ? paq.Id : idTipoCobertura;
        }

        private static int ResolverParentesco(ApplicationDbContext db, string valor, int def)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return def;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id)
                && db.CatParentesco.Any(c => c.Id == id))
                return id;
            var up = valor.ToUpper();
            var cat = db.CatParentesco.FirstOrDefault(c => c.Nombre.ToUpper() == up || c.Clave.ToUpper() == up);
            if (cat != null) return cat.Id;
            throw new InvalidOperationException($"Parentesco '{valor}' no existe en CatParentesco.");
        }

        private static int ResolverModalidad(ApplicationDbContext db, string valor)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return 1;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id)
                && db.CatModalidadFormaPago.Any(c => c.Id == id))
                return id;
            var up = valor.ToUpper();
            var cat = db.CatModalidadFormaPago.FirstOrDefault(c =>
                c.Nombre.ToUpper() == up || c.Clave.ToUpper() == up);
            if (cat != null) return cat.Id;
            throw new InvalidOperationException($"FormaPago '{valor}' no existe en CatModalidadFormaPago.");
        }

        private static int ResolverPeriodicidad(ApplicationDbContext db, string valor)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return 1;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id)
                && db.CatPeriodicidadFormaPago.Any(c => c.Id == id))
                return id;
            var up = valor.ToUpper();
            var cat = db.CatPeriodicidadFormaPago.FirstOrDefault(c =>
                (c.Nombre != null && c.Nombre.ToUpper() == up) || (c.Clave != null && c.Clave.ToUpper() == up));
            if (cat != null) return cat.Id;
            throw new InvalidOperationException($"Periodicidad '{valor}' no existe en CatPeriodicidadFormaPago.");
        }

        private static void ResolverBanco(ApplicationDbContext db, string valor)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id)
                && db.CatBanco.Any(c => c.Id == id || c.BancoId == id))
                return;
            var up = valor.ToUpper();
            if (db.CatBanco.Any(c =>
                (c.Nombre != null && c.Nombre.ToUpper() == up) || (c.Abreviacion != null && c.Abreviacion.ToUpper() == up)))
                return;
            throw new InvalidOperationException($"Banco '{valor}' no existe en CatBanco.");
        }

        private static int? ResolverMsi(ApplicationDbContext db, int idConvenio, string valor)
        {
            valor = (valor ?? "").Trim();
            if (valor.Length == 0) return null;
            if (int.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var id))
            {
                var byId = db.ConvenioMSI.FirstOrDefault(m => m.Id == id && m.IdConvenio == idConvenio);
                if (byId != null) return byId.Id;
            }
            var up = valor.ToUpper();
            var byNom = db.ConvenioMSI.FirstOrDefault(m => m.IdConvenio == idConvenio && m.Nombre != null && m.Nombre.ToUpper() == up);
            if (byNom != null) return byNom.Id;
            throw new InvalidOperationException($"ClaveMSI '{valor}' no existe en ConvenioMSI para el convenio.");
        }

        private static PersonaMoral AgregarPersonaMoralMasivo(ApplicationDbContext db, object r, int idEmpresa)
        {
            var rfc = Celda(r, "PM_RFC");
            var existente = db.PersonaMoral.FirstOrDefault(p => p.IdEmpresa == idEmpresa && p.RFC == rfc);
            if (existente != null)
                return existente;

            var faltantes = ColumnasObligatoriasPersonaMoral
                .Where(c => string.IsNullOrWhiteSpace(Celda(r, c)))
                .ToList();
            if (faltantes.Count > 0)
                throw new InvalidOperationException("Persona moral: faltan " + string.Join(", ", faltantes));

            var codigo = Celda(r, "PM_CodigoPostal");
            var colonia = Celda(r, "PM_Colonia");
            var cps = db.CatCodigoPostal.Where(x => x.Codigo == codigo).ToList();
            var cp = cps.FirstOrDefault(x =>
                    x.Asentamiento != null && x.Asentamiento.Equals(colonia, StringComparison.OrdinalIgnoreCase))
                ?? cps.FirstOrDefault();
            if (cp == null)
                throw new InvalidOperationException($"Persona moral: código postal '{codigo}' no existe.");
            var estado = db.CatEstadosRepublica.FirstOrDefault(x => x.Id == cp.IdEstado);
            if (estado == null)
                throw new InvalidOperationException("Persona moral: estado del CP no encontrado.");

            FechaO(r, "RL_FechaNacimiento", out var fechaNacRl);
            var representante = new PersonaMoralRepresentanteLegal
            {
                Nombre = Celda(r, "RL_Nombre"),
                ApellidoPaterno = Celda(r, "RL_ApellidoPaterno"),
                ApellidoMaterno = Celda(r, "RL_ApellidoMaterno") ?? "",
                Correo = Celda(r, "RL_Correo") ?? "",
                Telefono = Celda(r, "RL_Telefono"),
                EsPersonaPoliticamenteExpuesta = false,
                Estatus = true,
                FechaNacimiento = fechaNacRl == default ? DateTime.Now : fechaNacRl,
                IdCatEstadosRepublica_Nacimiento = cp.IdEstado,
                IdCatPais_Nacimiento = 1,
                IdCatTipoIdentificacion = 1,
                NumeroIdentificacion = "",
                IdEmpresa = idEmpresa
            };
            db.PersonaMoralRepresentanteLegal.Add(representante);
            db.SaveChanges();

            var numExt = Celda(r, "PM_NumeroExt") ?? "";
            var numInt = Celda(r, "PM_NumeroInt") ?? "";
            var calle = Celda(r, "PM_Calle");
            var direccion = new Direccion
            {
                IdCodigoPostal = cp.Id,
                Estado = estado.Estado,
                Ciudad = cp.Ciudad,
                Colonia = cp.Asentamiento,
                IdColonia = cp.Id,
                Municipio = cp.Municipio,
                IdEstado = cp.IdEstado,
                CodigoPostal = cp.Codigo,
                Calle = calle,
                NumeroExt = numExt,
                NumeroInt = numInt,
                DireccionCompleta = calle + " " + numExt
                    + (string.IsNullOrEmpty(numInt) ? "" : " int " + numInt)
                    + " " + estado.Estado + " " + cp.Municipio + " " + cp.Asentamiento + " CP " + cp.Codigo
            };
            db.Direccion.Add(direccion);
            db.SaveChanges();

            FechaO(r, "PM_FechaConstitucion", out var fechaConst);
            var personaMoral = new PersonaMoral
            {
                Actividad = Celda(r, "PM_Actividad") ?? "",
                ClaveEmpresa = "",
                FechaConstitucion = fechaConst == default ? (DateTime?)null : fechaConst,
                FolioMercantil = Celda(r, "PM_FolioMercantil") ?? "",
                IdCatTipoPersona = 4,
                IdDireccion = direccion.Id,
                IdEmpresa = idEmpresa,
                IdRepresentanteLegal = representante.Id,
                NombreComercial = Celda(r, "PM_NombreComercial"),
                RazonSocial = Celda(r, "PM_RazonSocial"),
                RFC = rfc
            };
            try
            {
                personaMoral.IdContCORE = new DerivacionPolizasCore().DerivaPersonaMoralCore(personaMoral);
            }
            catch
            {
                personaMoral.IdContCORE = "";
            }
            db.PersonaMoral.Add(personaMoral);
            db.SaveChanges();
            personaMoral.Direccion = direccion;
            return personaMoral;
        }

        private static Contratante GeneraContratanteMasivo(ApplicationDbContext db, Convenio convenio,
            DetalleUsuario usuario, object r, PersonaMoral personaMoral, bool esMoral, DateTime fechaNac)
        {
            log.Info("entra GeneraContratanteMasivo" );
            var empresa = db.Empresa.FirstOrDefault(e => e.Id == convenio.IdEmpresa);
            var ce = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == convenio.IdEmpresa);
            ParseNombreConductor(Celda(r, "ConductorHabitual"), out var nomCond, out var nom2Cond, out var apPatCond, out var apMatCond);
            var rfcConductor = (Celda(r, "RFC") ?? "").Trim().ToUpper();
            if (string.IsNullOrEmpty(rfcConductor))
                throw new InvalidOperationException("RFC del conductor habitual es obligatorio.");

            var existente = db.Contratante.FirstOrDefault(x => x.RFC == rfcConductor);

            if (existente != null && !string.IsNullOrEmpty(existente.RFC))
                return existente; log.Info("termina GeneraContratanteMasivo");

            var contratante = new Contratante
            {
                SegundoNombre = "",
                ApellidoPaterno = "",
                ApellidoMaterno = "",
                IdPromotor = 7,
                IdContCore = "",
                IdCliCore = "",
                NoEmpleado = "",
                IdBemobile = "",
                FechaCreacion = DateTime.Now
            };

            if (esMoral && personaMoral != null)
            {
                contratante.Nombre = personaMoral.NombreComercial;
                contratante.Email = usuario.Correo;
                contratante.FechaNacimiento = personaMoral.FechaConstitucion ?? DateTime.Now;
                contratante.RFC = personaMoral.RFC;
                contratante.telefonoCel = usuario.TelefonoCelular ?? "";
                contratante.telefonoFijo = usuario.TelefonoCelular ?? "";
                var dir = personaMoral.Direccion ?? (personaMoral.IdDireccion.HasValue
                    ? db.Direccion.FirstOrDefault(d => d.Id == personaMoral.IdDireccion.Value) : null);
                contratante.CodigoPostal = dir?.CodigoPostal ?? "";
            }
            else if (convenio.IdCatTipoContratante == 1 && ce != null && ce.IdTipoDeNegocio == 1 && empresa != null)
            {
                contratante.Nombre = empresa.NombreComercial;
                contratante.Email = "";
                contratante.FechaNacimiento = empresa.FechaConstitucion ?? DateTime.Now;
                contratante.RFC = empresa.RFC;
                contratante.telefonoCel = empresa.TelefonoGral ?? "";
                contratante.telefonoFijo = empresa.TelefonoGral ?? "";
                contratante.CodigoPostal = empresa.Direccion != null ? (empresa.Direccion.CodigoPostal ?? "") : "";
            }
            else
            {
                if (string.IsNullOrEmpty(rfcConductor))
                    throw new InvalidOperationException("RFC del conductor habitual es obligatorio.");
                contratante.Nombre = nomCond;
                contratante.SegundoNombre = nom2Cond ?? "";
                contratante.ApellidoPaterno = apPatCond ?? "";
                contratante.ApellidoMaterno = apMatCond ?? "";
                contratante.Email = Nvl(Celda(r, "Email"), usuario.Correo);
                contratante.FechaNacimiento = fechaNac != default ? fechaNac : DateTime.Now;
                contratante.RFC = rfcConductor;
                contratante.telefonoCel = usuario.TelefonoCelular ?? "";
                contratante.telefonoFijo = usuario.TelefonoCelular ?? "";
                contratante.CodigoPostal = "";
            }

            db.Contratante.Add(contratante);
            db.SaveChanges();
            log.Info("termina GeneraContratanteMasivo");
            return contratante;
        }

        private static void ParseNombreConductor(string texto, out string nombre, out string segundoNombre,
            out string apellidoPaterno, out string apellidoMaterno)
        {
            nombre = segundoNombre = apellidoPaterno = apellidoMaterno = "";
            var p = (texto ?? "").Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (p.Length == 0) return;
            if (p.Length == 1) { nombre = p[0]; return; }
            if (p.Length == 2) { nombre = p[0]; apellidoPaterno = p[1]; return; }
            if (p.Length == 3) { nombre = p[0]; apellidoPaterno = p[1]; apellidoMaterno = p[2]; return; }
            nombre = p[0];
            apellidoMaterno = p[p.Length - 1];
            apellidoPaterno = p[p.Length - 2];
            segundoNombre = string.Join(" ", p.Skip(1).Take(p.Length - 3));
        }

        private static bool EsPersonaMoral(string tipo)
        {
            tipo = (tipo ?? "").Trim().ToUpper();
            return tipo == "MORAL" || tipo == "PM" || tipo == "1";
        }

        private static bool TryConvenio(ApplicationDbContext db, int idTipo, int idConvenio, out int idEmpresa, out string error)
        {
            idEmpresa = 0;
            error = null;
            if (idTipo == TipoAutos)
            {
                var c = db.Convenio.FirstOrDefault(x => x.Id == idConvenio && x.Estatus == 1);
                if (c == null)
                {
                    error = $"convenio autos {idConvenio} no existe o no está activo.";
                    return false;
                }
                idEmpresa = c.IdEmpresa;
                return true;
            }
            int idCat = idTipo == TipoHogar ? 2 : 3;
            var cp = db.ConvenioProductos.FirstOrDefault(x => x.Id == idConvenio && x.Estatus == 1 && x.IdCatProducto == idCat);
            if (cp == null)
            {
                error = $"convenio producto {idConvenio} no existe, no está activo o no corresponde al tipo.";
                return false;
            }
            idEmpresa = cp.IdEmpresa;
            return true;
        }

        private static DetalleUsuario BuscarUsuario(ApplicationDbContext db, int idEmpresa, string email, string userName = null)
        {
            var mail = (email ?? "").Trim().ToUpper();
            var uname = (userName ?? "").Trim().ToUpper();
            if (mail.Length == 0 && uname.Length == 0) return null;

            var q = from u in db.DetalleUsuario
                    join ue in db.DetalleUsuarioEmpresa on u.Id equals ue.IdDetalleUsuario
                    join asp in db.Users on u.IdUsuario equals asp.Id
                    where u.Estatus == true && u.IdPerfil == 3 && ue.IdEmpresa == idEmpresa
                    select new { u, asp };

            if (mail.Length > 0 && uname.Length > 0)
                q = q.Where(x => x.u.Correo.ToUpper() == mail || x.asp.UserName.ToUpper() == uname);
            else if (mail.Length > 0)
                q = q.Where(x => x.u.Correo.ToUpper() == mail);
            else
                q = q.Where(x => x.asp.UserName.ToUpper() == uname);
            return q.Select(x => x.u).FirstOrDefault();
        }

        public static DataTable QuitarFilaInstrucciones(DataTable table)
        {
            if (table == null || table.Rows.Count == 0) return table;
            for (int i = table.Rows.Count - 1; i >= 0; i--)
            {
                if (EsFilaInstruccionesOVacia(table.Rows[i]))
                    table.Rows.RemoveAt(i);
            }
            return table;
        }

        private static bool EsFilaInstruccionesOVacia(DataRow row)
        {
            bool todasVacias = row.ItemArray.All(v => v == null || v == DBNull.Value
                || string.IsNullOrWhiteSpace(Convert.ToString(v)));
            if (todasVacias) return true;

            return row.ItemArray.Any(v =>
            {
                var s = Convert.ToString(v);
                return !string.IsNullOrWhiteSpace(s)
                    && s.IndexOf("obligatorio", StringComparison.OrdinalIgnoreCase) >= 0;
            });
        }

        private static bool EsColumnaFecha(string col)
        {
            if (string.IsNullOrEmpty(col)) return false;
            return col.IndexOf("Fecha", StringComparison.OrdinalIgnoreCase) >= 0
                || col.Equals("InicioVigencia", StringComparison.OrdinalIgnoreCase)
                || col.Equals("FinVigencia", StringComparison.OrdinalIgnoreCase);
        }

        private static IXLWorksheet EscribeHoja(XLWorkbook wb, string nombre, string[] cols, HashSet<string> obligatorias = null)
        {
            var ws = wb.Worksheets.Add(nombre);
            if (obligatorias == null)
                obligatorias = new HashSet<string>(ColumnasObligatorias, StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < cols.Length; i++)
            {
                var cell = ws.Cell(1, i + 1);
                cell.Value = cols[i];
                cell.Style.Font.Bold = true;
                string ayuda = null;
                if (obligatorias.Contains(cols[i]))
                    ayuda = "Obligatorio";
                else if (ColumnasObligatoriasPersonaMoral.Contains(cols[i]))
                    ayuda = "Obligatorio si EsEmisionPersonaMoral=1";
                else if (cols[i].Equals("Anio", StringComparison.OrdinalIgnoreCase))
                    ayuda = "Año del vehículo. Opcional";
                else if (cols[i].Equals("Descripcion", StringComparison.OrdinalIgnoreCase))
                    ayuda = "Texto libre. Opcional";
                else if (cols[i].Equals("RFC", StringComparison.OrdinalIgnoreCase))
                    ayuda = "Obligatorio. RFC del conductor habitual";
                else if (cols[i].StartsWith("PM_") || cols[i].StartsWith("RL_"))
                    ayuda = "Opcional. Persona moral";
                if (cols[i].Equals("ConductorHabitual", StringComparison.OrdinalIgnoreCase))
                    ayuda = "Obligatorio. Nombres, apellido paterno, apellido materno";
                if (cols[i].Equals("RFC", StringComparison.OrdinalIgnoreCase))
                    ayuda = "Obligatorio. RFC del conductor habitual";
                if (EsColumnaFecha(cols[i]))
                    ayuda = string.IsNullOrEmpty(ayuda)
                        ? "Formato dd/MM/yyyy"
                        : ayuda + ". Formato dd/MM/yyyy";
                if (!string.IsNullOrEmpty(ayuda))
                    ws.Cell(2, i + 1).Value = ayuda;
                ws.Column(i + 1).Width = Math.Min(50, Math.Max(cols[i].Length + 3, 12));
            }
            ws.Row(2).Style.Font.Italic = true;
            ws.Row(2).Style.Font.FontColor = XLColor.FromArgb(0, 176, 240);
            ws.SheetView.FreezeRows(2);
            try { ws.Columns().AdjustToContents(); }
            catch { /* ponytail: sin fuentes en el servidor el autofit falla; queda Width por longitud del encabezado */ }
            return ws;
        }

        private static void EscribeCatalogosYListas(XLWorkbook wb, IXLWorksheet wsDatos, string[] cols, string[] empresas = null)
        {
            var cat = wb.Worksheets.Add("Catalogos");
            var colorAyuda = XLColor.FromArgb(0, 176, 240);
            EscribeColumnaCatalogo(cat, wsDatos, cols, 1, "TipoVehiculo", new[] { "Auto" }, colorAyuda);
            EscribeColumnaCatalogo(cat, wsDatos, cols, 2, "TipoCobertura", new[]
            {
                "Amplia", "Limitada", "Plus", "Total", "RC", "Platino"
            }, colorAyuda);
            EscribeColumnaCatalogo(cat, wsDatos, cols, 3, "Parentesco", new[]
            {
                "Titular", "Mamá", "Papá", "Hermana", "Hermano", "Esposa", "Esposo",
                "Prima", "Primo", "Abuelo", "Abuela", "Tío", "Tía", "Hijo", "Hija",
                "Amiga", "Amigo", "Otro", "Otra"
            }, colorAyuda);
            EscribeColumnaCatalogo(cat, wsDatos, cols, 4, "TipoEmision", new[] { "Tradicional" }, colorAyuda);
            EscribeColumnaCatalogo(cat, wsDatos, cols, 5, "EsEmisionPersonaMoral", new[]
            {
                "0 - No (persona física)",
                "1 - Sí (persona moral)"
            }, colorAyuda);
            EscribeColumnaCatalogo(cat, wsDatos, cols, 6, "Aseguradora", new[]
            {
                "QUALITAS", "GNP", "CHUBB", "ATLAS", "MAPFRE", "AXA", "HDI", "INBURSA", "BANORTE", "ANA"
            }, colorAyuda);
            EscribeColumnaCatalogo(cat, wsDatos, cols, 7, "FormaPago", new[]
            {
                "Pago con tarjeta de crédito",
                "Pago con tarjeta de débito",
                "Descuento nómina",
                "Depósito bancario",
                "Referenciado"
            }, colorAyuda);
            EscribeColumnaCatalogo(cat, wsDatos, cols, 8, "Periodicidad", new[]
            {
                "Contado", "Trimestral", "Mensual", "Quincenal", "Catorcenal", "Semanal", "Semestral"
            }, colorAyuda);
            var listaEmpresas = (empresas != null && empresas.Length > 0)
                ? empresas
                : new[] { "(sin empresas activas)" };
            EscribeColumnaCatalogo(cat, wsDatos, cols, 9, "Empresa", listaEmpresas, colorAyuda);
        }

        private static void EscribeColumnaCatalogo(IXLWorksheet cat, IXLWorksheet wsDatos, string[] cols,
            int colCat, string titulo, string[] valores, XLColor colorAyuda)
        {
            var header = cat.Cell(1, colCat);
            header.Value = titulo;
            header.Style.Font.Bold = true;
            header.Style.Font.FontColor = XLColor.White;
            header.Style.Fill.BackgroundColor = XLColor.Black;
            header.Style.Border.OutsideBorder = XLBorderStyleValues.Medium;
            header.Style.Border.OutsideBorderColor = colorAyuda;
            for (int i = 0; i < valores.Length; i++)
            {
                var celda = cat.Cell(i + 2, colCat);
                celda.Value = valores[i];
                celda.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                celda.Style.Border.OutsideBorderColor = XLColor.Black;
            }
            var ancho = Math.Max(titulo.Length + 2, valores.Max(v => v.Length) + 2);
            cat.Column(colCat).Width = Math.Min(50, Math.Max(14, ancho));

            int destCol = Array.FindIndex(cols, c => c.Equals(titulo, StringComparison.OrdinalIgnoreCase)) + 1;
            if (destCol <= 0) return;
            string letra = XLHelper.GetColumnLetterFromNumber(colCat);
            int ultima = valores.Length + 1;
            var dv = wsDatos.Range(3, destCol, 500, destCol).SetDataValidation();
            dv.List($"=Catalogos!${letra}$2:${letra}${ultima}", true);
            dv.IgnoreBlanks = true;
            dv.InCellDropdown = true;
            dv.ShowErrorMessage = true;
            dv.ErrorTitle = titulo;
            dv.ErrorMessage = $"Seleccione un valor de Catalogos ({titulo}).";
        }

        private static string Celda(object src, string col)
        {
            if (src is DataRow r)
            {
                if (!r.Table.Columns.Contains(col) || r[col] == null || r[col] == DBNull.Value)
                    return "";
                return r[col].ToString().Trim();
            }
            var p = src.GetType().GetProperty(col);
            var v = p?.GetValue(src);
            return v == null ? "" : v.ToString().Trim();
        }

        private static string Nvl(string a, string b) => string.IsNullOrWhiteSpace(a) ? (b ?? "") : a;

        private static bool Ent(object r, string col, out int v) =>
            int.TryParse(Celda(r, col), NumberStyles.Any, CultureInfo.InvariantCulture, out v);

        private static int EntO(object r, string col, int def) => Ent(r, col, out var v) ? v : def;

        private static int? EntN(object r, string col)
        {
            var s = Celda(r, col);
            if (string.IsNullOrEmpty(s)) return null;
            return int.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var v) ? v : (int?)null;
        }

        private static decimal Dec(object r, string col, decimal def = 0)
        {
            var s = Celda(r, col);
            if (string.IsNullOrEmpty(s)) return def;
            if (decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var v)) return v;
            if (decimal.TryParse(s, NumberStyles.Any, CultureInfo.GetCultureInfo("es-MX"), out v)) return v;
            return def;
        }

        private static decimal? DecN(object r, string col)
        {
            var s = Celda(r, col);
            if (string.IsNullOrEmpty(s)) return null;
            return Dec(r, col);
        }

        private static string NormalizarEsEmisionPersonaMoral(string valor)
        {
            var s = (valor ?? "").Trim().ToUpper();
            if (s.Length == 0) return "";
            if (s.StartsWith("1") || s == "TRUE" || s == "SI" || s == "SÍ"
                || s.IndexOf("PERSONA MORAL", StringComparison.Ordinal) >= 0)
                return "1";
            if (s.StartsWith("0") || s == "FALSE" || s == "NO"
                || s.IndexOf("FÍSICA", StringComparison.Ordinal) >= 0
                || s.IndexOf("FISICA", StringComparison.Ordinal) >= 0)
                return "0";
            return "";
        }

        private static bool Bool(object r, string col, bool def = false)
        {
            var n = NormalizarEsEmisionPersonaMoral(Celda(r, col));
            if (n == "1") return true;
            if (n == "0") return false;
            return def;
        }

        private static bool FechaO(object src, string col, out DateTime fecha)
        {
            fecha = default;
            if (src is DataRow r && r.Table.Columns.Contains(col) && r[col] is DateTime dt)
            {
                fecha = dt;
                return true;
            }
            var valor = Celda(src, col);
            if (string.IsNullOrWhiteSpace(valor)) return false;
            if (DateTime.TryParse(valor, CultureInfo.GetCultureInfo("es-MX"), DateTimeStyles.None, out fecha)) return true;
            if (DateTime.TryParse(valor, CultureInfo.InvariantCulture, DateTimeStyles.None, out fecha)) return true;
            if (double.TryParse(valor, NumberStyles.Any, CultureInfo.InvariantCulture, out var oa))
            {
                try { fecha = DateTime.FromOADate(oa); return true; }
                catch { return false; }
            }
            return false;
        }
    }
}
