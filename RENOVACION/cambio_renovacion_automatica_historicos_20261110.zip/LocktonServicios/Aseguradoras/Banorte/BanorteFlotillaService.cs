﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.Banorte.Catalogo;
using LocktonModel.Services.Banorte.Cotizacion;
using LocktonModel.Services.Banorte.Emision;
using LocktonModel.Services.Banorte.Token;
using LocktonModel.Services.Banorte.Vehiculo;
using LocktonModel.VModels;
using LocktonModel.xmls.AXA;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.Utilidades;
using log4net;
using Newtonsoft.Json;
using static LocktonServicios.Aseguradoras.Chubb.ChubbService;

namespace LocktonServicios.Aseguradoras.Banorte
{
    public class BanorteFlotillaService : IOperacionesAseguradoras
    {

        private static readonly ILog log = LogManager.GetLogger(typeof(BanorteFlotillaService));

        ApplicationDbContext db = null;
        private BanorteFlotillaProxy proxy = null;
        bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;

        public BanorteFlotillaService(string user, string pass)
        {
            var baseUrl = string.Empty;
            var catalogUrl = string.Empty;

            db = new ApplicationDbContext();

            if (!esProduccion)
            {
                baseUrl = $"{Utilidades.Utilidades.ObtienerValorParametro("BanorteFlotillaAPI_Test")}";
                catalogUrl = $"{Utilidades.Utilidades.ObtienerValorParametro("BanorteFlotillaAPICatalogos_Test")}";

            }
            else
            {
                baseUrl = $"{Utilidades.Utilidades.ObtienerValorParametro("BanorteFlotillaAPI")}";
                catalogUrl = $"{Utilidades.Utilidades.ObtienerValorParametro("BanorteFlotillaAPICatalogos")}";
            }

            var authorize = new Authorize
            {
                client_id = user,
                client_secret = pass,
                grant_type = "client_credentials",
                scope = "POL-EMPRE"
            };
            proxy = new BanorteFlotillaProxy(baseUrl, catalogUrl, authorize);

        }

        public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {
            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
            var error = "";
            try
            {
                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioCotiza.Id && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
                var paquete = "";
                int idTipoVehiculo = 0;

                var catperdioricidad = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == perioricidad.IdCatPeriodicidadFormaPago);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == catperdioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);
                var paqueteRamoConvenio = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == convenioId && x.IdCatRamoVehiculo == paqueteConvenio.IdCatRamoVehiculo).FirstOrDefault();
                var tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == convenioCotiza.IdAseguradora && x.IdCatTipoPaquete == IdTipoPaquete).FirstOrDefault();
                var coberturasOpcionales = db.PaqueteDetalleOpcional.Where(a => a.IdPaqueteConvenio == idPaqueteConvenio).ToList();

                string codigoPostal = ConveniosPaquetes.Empresa.Direccion.CodigoPostal;
                if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 2 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 6)//pooles
                {
                    codigoPostal = string.IsNullOrEmpty(CotizacionCompara.CodigoPostal) ? codigoPostal : CotizacionCompara.CodigoPostal;

                }

                //if (string.IsNullOrEmpty(CotizacionCompara.CodigoPostal))                

                var codigo = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == codigoPostal);

                if ((convenioCotiza.IdCatTipoContratante == 5))
                    codigoPostal = string.IsNullOrEmpty(CotizacionCompara.CodigoPostal) ? codigoPostal : CotizacionCompara.CodigoPostal;

                var request = new CotizacionRequest();
                var vehiculo = new vehiculo();
                var datosVehiculo = ObtenderDatosVehiculo(cot, convenioCotiza, paqueteConvenio.IdCatRamoVehiculo, CotizacionCompara.Año);

                request.vehiculos = new List<vehiculo>();

                vehiculo.plancobert = tipoPaquete.Clave;
                vehiculo.cuser = "LOCKTONONE";
                vehiculo.codprod = "A004";
                vehiculo.codplan = paqueteConvenio.ClavePlan;
                vehiculo.revplan = "000";

                vehiculo.tipovalor = "01";//VALOR COMERCIAL
                vehiculo.mtovalor = 0;

                if (CotizacionCompara.ValorFactura)
                {
                    vehiculo.tipovalor = "02";//VALOR FACTURA
                    //vehiculo.mtovalor = CotizacionCompara.MontoFactura;
                }

                vehiculo.codservicio = "01";
                vehiculo.sumasegeqesp = 0;
                vehiculo.indeven = "N";

                vehiculo.codestadocirc = codigo.IdEstadoCotizacion;// "23";
                vehiculo.codciudadcirc = codigo.IdCiudadCotizacion;// "005";               
                vehiculo.codformpago = perioricidad.FormaPago;

                vehiculo.tipoveh = datosVehiculo.IdTipoVehiculo;
                vehiculo.codmarca = datosVehiculo.IdMarca;
                vehiculo.codmodelo = datosVehiculo.IdModelo;
                vehiculo.treducido = datosVehiculo.IdVersion;
                vehiculo.anoveh = Convert.ToInt32(CotizacionCompara.Año);
                vehiculo.stscarga = "VAL";
                vehiculo.codtipcarga = "NAP";
                vehiculo.uso_veh = "01";

                vehiculo.fecha_carga = DateTime.Now;
                vehiculo.fecinivig = CotizacionCompara.FechaInicio;
                vehiculo.fecfinvig = CotizacionCompara.FechaFin;

                //COBERTURAS OPCIONALES

                if (coberturasOpcionales != null && coberturasOpcionales.Any())
                {
                    vehiculo.coberturas = new List<cobertura>();

                    foreach (var opcional in coberturasOpcionales)
                    {
                        var _reg = db.CoberturaOpcional.FirstOrDefault(a => a.Id == opcional.IdCobertura);

                        vehiculo.coberturas.Add(new cobertura { codcobert = _reg.Clave });
                    }


                }

                request.vehiculos.Add(vehiculo);

                var xmlEnvio = JsonConvert.SerializeObject(request);
                log.Info("Json Banorte Cotizacion " + xmlEnvio);
                var response = proxy.Cotizar(request);

                #region Validar Respuesta


                var xmlRespuesta = JsonConvert.SerializeObject(response);

                Comparar infoCompara = LeeXmlRespuesta(xmlRespuesta, xmlEnvio, convenioCotiza);

                infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();
                infoCompara.IdFormaPago = catperdioricidad.Id;
                infoCompara.IdMedioPago = mediopago.Id;
                CotizacionCompara.CodigoPostal = codigoPostal;

                //meses sin intereses
                if (catperdioricidad.Id == 1 && mediopago.Id == 1)
                {

                    Utilidades.Utilidades.AplicaMSICotizacion(convenioCotiza.IdEmpresa, convenioCotiza.Id, ref infoCompara);

                }

                CotizacionCompara.Comparar.Add(infoCompara);

                #endregion


            }
            catch (Exception ex)
            {

                Comparar infoCompara = new Comparar();
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.Aseguradora = "BANORTE";
                infoCompara.ErrorXML = string.Format("Tuvimos un inconveniente para realizar tu cotizacion: {0}", string.IsNullOrEmpty(error) ? ex.Message : error);
                CotizacionCompara.Comparar.Add(infoCompara);

                log.Info(infoCompara.ErrorXML);
                //throw;
            }

            return CotizacionCompara;
        }

        public Comparar LeeXmlRespuesta(string xmlRespuesta, string xmlEnvio, Convenio convenioCotiza)
        {

            var response = JsonConvert.DeserializeObject<CotizacionResponse>(xmlRespuesta);
            var request = JsonConvert.DeserializeObject<CotizacionRequest>(xmlEnvio);

            Comparar infoCompara = new Comparar();
            infoCompara.FechaCotizacion = request.vehiculos.FirstOrDefault().fecha_carga;
            infoCompara.XmlEmision = xmlEnvio;
            infoCompara.XmlRespuesta = xmlRespuesta;
            infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
            infoCompara.IdConvenio = convenioCotiza.Id;
            infoCompara.Aseguradora = "BANORTE";
            infoCompara.Año = request.vehiculos.FirstOrDefault().anoveh.ToString();
            infoCompara.FechaInicio = response.quote.fecinivigcot.ToString("dd/MM/yyyy");
            infoCompara.FechaFin = response.quote.fecfinvigcot.ToString("dd/MM/yyyy");
            //infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
            //infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
            //infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;

            if (response.status != 200)
            {
                infoCompara.ErrorXML = response.message;

                log.Error("cotizaVehiculo error BANORTE Request " + xmlEnvio.Replace("\n", "").Replace("\r", ""));
                log.Error("cotizaVehiculo error BANORTE Response " + xmlRespuesta.Replace("\n", "").Replace("\r", ""));

            }
            else
            {
                var vehiculoResponse = response.quote.vehiculos.FirstOrDefault();
                var coberturasResponse = vehiculoResponse.coberturas.ToList();
                var reciboResponse = vehiculoResponse.recibos.FirstOrDefault();

                infoCompara.Coberturas = new List<Coberturas>();

                foreach (var cobertura in coberturasResponse)
                {

                    Coberturas cotCob = new Coberturas();

                    cotCob.Cobertura = cobertura.mtoprimacob.ToString("N2");
                    cotCob.SumaAsegurada = cobertura.sumaasegurada.ToString("N2");
                    cotCob.Nombre = cobertura.cobertura.Trim();
                    cotCob.Deducible = cobertura.deducible.ToString();
                    cotCob.Codigo = cobertura.codcobert.ToString();

                    infoCompara.Coberturas.Add(cotCob);

                }

                infoCompara.PrimaNeta = reciboResponse.prima_neta_cesion.ToString("N2");
                infoCompara.PrimaTotal = reciboResponse.prima_total.ToString("N2");

                infoCompara.Impuesto = reciboResponse.iva.ToString("N2");
                infoCompara.Recargo = reciboResponse.recargo.ToString("N2");
                infoCompara.Derecho = reciboResponse.derecho.ToString("N2");
                //infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();
                infoCompara.PrimerPago = reciboResponse.primat_pr.ToString("N2");
                infoCompara.NumeroDePagos = reciboResponse.cant_recibos - 1;

                infoCompara.SegundoPago = "";

                if (reciboResponse.cant_recibos > 1)
                {
                    infoCompara.SegundoPago = reciboResponse.primat_sub.ToString("N2");

                }

            }

            return infoCompara;
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            EmisionPoliza result = new EmisionPoliza(true, string.Empty, string.Empty, new Poliza());
            var xmlEnvio = string.Empty;
            var xmlRespuesta = string.Empty;

            try
            {
                #region variables
                var request = new EmisionRequest();
                var vehiculo = new VehiculoEmision();
                var asegurado = new PersonaBanorte();
                var responsable = new PersonaBanorte();
                var conductor = new ConductorBanorte();

                var cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
                var cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacionDetalle.IdCotizacion);
                var cp = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == cotizacion.CodigoPostal);
                var colonia = cp.Asentamiento;

                if (InfoEmision.DatosUsuario.Direccion != null)
                    colonia = InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
                var colony = ObtenerColonia(cp.Codigo, colonia);
                var responseCotizacion = JsonConvert.DeserializeObject<CotizacionResponse>(cotizacionDetalle.XMLRecepcion);
                #endregion

                #region vahiculo
                vehiculo.consecutivo = 1;
                vehiculo.codservicio = "01";
                if (InfoEmision.Placas != "SNP")
                    vehiculo.numplaca = InfoEmision.Placas;
                else
                    vehiculo.numplaca = "";
                vehiculo.serialmotor = InfoEmision.NumeroMotor;
                vehiculo.serialcarroceria = InfoEmision.NumeroSerie.ToUpper();
                vehiculo.color = "0";
                vehiculo.codtipmercancia = "NAP";
                vehiculo.paisplaca = "052";
                vehiculo.cuser = "LOCKTONONE";
                vehiculo.origen = "API";
                #endregion

                #region cobranza
                vehiculo.cobranza = new Cobranza();

                if (!string.IsNullOrEmpty(InfoEmision.BeneficiarioPreferente))
                    vehiculo.nomben = InfoEmision.BeneficiarioPreferente;

                if (InfoEmision.CotizacionAutoGuardar.MediodePago == 0 || InfoEmision.CotizacionAutoGuardar.MediodePago == 1)
                {
                    vehiculo.cobranza.codviacobro = "04";

                    if (InfoEmision.CotizacionAutoGuardar.MediodePago == 1)
                        vehiculo.cobranza.codviacobro = "03";

                    vehiculo.cobranza.codtarjcred = InfoEmision.Tarjeta.TipoTarjeta.ToUpper();
                    vehiculo.cobranza.numdocref = InfoEmision.Tarjeta.NumeroTarjeta;
                    vehiculo.cobranza.codentfinan = InfoEmision.Tarjeta.Cvv;
                    vehiculo.cobranza.fecVenc = new DateTime(InfoEmision.IdAnio, Convert.ToInt32(InfoEmision.Tarjeta.MesVencimiento), 1);

                }
                else
                    vehiculo.cobranza.codviacobro = "05";

                vehiculo.cobranza.zonagestion = "000001";
                vehiculo.cobranza.codcobrador = "000001";
                vehiculo.cobranza.fecinicobro = DateTime.Now;
                #endregion

                #region responsable
                if ((InfoEmision.EsFlotilla && InfoEmision.Convenio.IdCatTipoContratante == 1) || ((InfoEmision.Convenio.IdCatTipoContratante == 5) && (cotizacionDetalle.IdMedioPago == 3 || cotizacionDetalle.IdMedioPago == 5))) //DESCUENTO POR NOMINA
                {
                    //RESPONSABLE EMPRESA
                    colony = ObtenerColonia(InfoEmision.Empresa.Direccion.CodigoPostal, InfoEmision.Empresa.Direccion.CatCodigoPostal.Asentamiento);
                    responsable.tipoper = "M";
                    responsable.razonsocial = InfoEmision.Empresa.RazonSocial;
                    responsable.nomter = InfoEmision.Empresa.RepresentanteLegal.Nombre;
                    responsable.apepater = InfoEmision.Empresa.RepresentanteLegal.ApellidoPaterno;
                    responsable.apetermater = InfoEmision.Empresa.RepresentanteLegal.ApellidoMaterno;
                    responsable.fecnac = InfoEmision.Empresa.FechaConstitucion.Value;
                    responsable.sexo = "N";
                    responsable.nacionalidad = "041";
                    responsable.numrfc = InfoEmision.Empresa.RFC;
                    responsable.email = "";
                    responsable.zip = cp.Codigo;
                    responsable.codpais = "052";
                    responsable.codestado = colony.codestado;
                    responsable.codciudad = colony.codciudad;
                    responsable.codmunicipio = colony.codmunicipio;
                    responsable.codbarrio = colony.codcolonia;
                    responsable.calle = InfoEmision.Empresa.Direccion.Calle;
                    responsable.numero = InfoEmision.Empresa.Direccion.NumeroExt;
                    responsable.fecnac = Convert.ToDateTime(InfoEmision.Empresa.FechaConstitucion);

                }
                else
                {
                    responsable.tipoper = "F";
                    responsable.nomter = InfoEmision.PrimerNombre + (string.IsNullOrEmpty(InfoEmision.SegundoNombre) ? "" : " " + InfoEmision.SegundoNombre);
                    responsable.apepater = InfoEmision.ApellidoPaterno;
                    responsable.apetermater = InfoEmision.ApellidoMaterno;
                    responsable.fecnac = InfoEmision.FechaNacimiento;
                    responsable.sexo = "N";
                    responsable.nacionalidad = "041";
                    responsable.numrfc = InfoEmision.DatosUsuario.RFC;
                    responsable.email = InfoEmision.Email;
                    responsable.zip = cp.Codigo;
                    responsable.codpais = "052";
                    responsable.codestado = colony.codestado;
                    responsable.codciudad = colony.codciudad;
                    responsable.codmunicipio = colony.codmunicipio;
                    responsable.codbarrio = colony.codcolonia;
                    responsable.calle = InfoEmision.DatosUsuario.Direccion.Calle;
                    responsable.numero = InfoEmision.DatosUsuario.Direccion.NumeroExt;

                }

                #endregion

                #region asegurado
                #region Flotilla Datos Fiscales Empresa
                if (InfoEmision.Convenio.IdCatTipoContratante == 1)
                {
                    asegurado.tipoper = "M";
                    asegurado.razonsocial = InfoEmision.Empresa.RazonSocial;
                    asegurado.numrfc = InfoEmision.Empresa.RFC;
                    asegurado.calle = InfoEmision.Empresa.Direccion.Calle;
                    asegurado.numero = InfoEmision.Empresa.Direccion.NumeroExt;
                    asegurado.fecnac = Convert.ToDateTime(InfoEmision.Empresa.FechaConstitucion);

                }
                else if ((InfoEmision.Convenio.IdCatTipoContratante == 5) && (cotizacionDetalle.IdMedioPago == 3 || cotizacionDetalle.IdMedioPago == 5))
                {
                    asegurado.tipoper = "M";
                    asegurado.razonsocial = InfoEmision.Empresa.RazonSocial;
                    asegurado.numrfc = InfoEmision.Empresa.RFC;
                    asegurado.calle = InfoEmision.Empresa.Direccion.Calle;
                    asegurado.numero = InfoEmision.Empresa.Direccion.NumeroExt;
                    asegurado.fecnac = Convert.ToDateTime(InfoEmision.Empresa.FechaConstitucion);
                }
                else
                {
                    asegurado.tipoper = "F";
                    asegurado.nomter = InfoEmision.PrimerNombre + (string.IsNullOrEmpty(InfoEmision.SegundoNombre) ? "" : " " + InfoEmision.SegundoNombre);
                    asegurado.apepater = InfoEmision.ApellidoPaterno;
                    asegurado.apetermater = InfoEmision.ApellidoMaterno;
                    asegurado.fecnac = InfoEmision.FechaNacimiento;
                    asegurado.sexo = "N";
                    asegurado.nacionalidad = "041";
                    asegurado.numrfc = InfoEmision.DatosUsuario.RFC;
                    asegurado.email = InfoEmision.Email;
                    asegurado.calle = InfoEmision.DatosUsuario.Direccion.Calle;
                    asegurado.numero = InfoEmision.DatosUsuario.Direccion.NumeroExt;
                }
                #endregion

                asegurado.zip = cp.Codigo;
                asegurado.codpais = "052";
                asegurado.codestado = colony.codestado;
                asegurado.codciudad = colony.codciudad;
                asegurado.codmunicipio = colony.codmunicipio;
                asegurado.codbarrio = colony.codcolonia;

                #endregion

                #region Emision
                if (InfoEmision.Convenio.IdCatTipoContratante == 1)
                {
                    conductor.tipoidcond = "A";
                    conductor.identificacion = "123456789";
                    conductor.anosexper = 0;
                    conductor.sexo = "N";
                    conductor.indcondpref = "S";
                    conductor.nomcondveh = InfoEmision.DetalleUsuario.Nombre + " " + InfoEmision.DetalleUsuario.NombreDos;
                    conductor.apecondveh = InfoEmision.DetalleUsuario.ApellidoPaterno + " " + InfoEmision.DetalleUsuario.ApellidoMaterno;
                    conductor.fecnaccondveh = InfoEmision.DetalleUsuario.FECHANACIMIENTO;
                }
                else
                {
                    conductor.tipoidcond = "A";
                    conductor.identificacion = "123456789";
                    conductor.anosexper = 0;
                    conductor.sexo = "N";
                    conductor.indcondpref = "S";
                    conductor.nomcondveh = InfoEmision.PrimerNombre + (string.IsNullOrEmpty(InfoEmision.SegundoNombre) ? "" : " " + InfoEmision.SegundoNombre);
                    conductor.apecondveh = InfoEmision.ApellidoPaterno + " " + InfoEmision.ApellidoMaterno;
                    conductor.fecnaccondveh = InfoEmision.FechaNacimiento;
                }

                vehiculo.asegurado = asegurado;

                vehiculo.responsable = responsable;

                vehiculo.conductor = conductor;

                request.vehiculos = new List<VehiculoEmision>() { vehiculo };
                xmlEnvio = JsonConvert.SerializeObject(request);
                log.Info(string.Format("Emisión BANORTE Request: {0}", xmlEnvio.Replace("\n", "").Replace("\r", "")));
                var response = proxy.Emitir(request, responseCotizacion.quote_id);
                xmlRespuesta = JsonConvert.SerializeObject(response);


                log.Info(string.Format("Emisión BANORTE Response: {0}", xmlRespuesta.Replace("\n", "").Replace("\r", "")));

                #endregion

                if (response.status != 200)
                {
                    var erroresCotizacion = string.Join(", ", response.log.Select(a => a.log_error).ToList());
                    result = new EmisionPoliza(false, xmlEnvio, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde. " + erroresCotizacion, null);
                }
                else
                {
                    #region Generacion Póliza

                    int IdPaquete = int.Parse(cotizacionDetalle.Paquete);
                    var tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == InfoEmision.Convenio.IdAseguradora && x.IdCatTipoPaquete == IdPaquete).FirstOrDefault();
                    var polizaBanorte = response.emision.polizas.FirstOrDefault();


                    Poliza poliza = new Poliza();
                    PolizaDetalle polizaDet = new PolizaDetalle();

                    Endoso endosoAlta = new Endoso();
                    endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                    endosoAlta.Fecha = DateTime.Now;
                    endosoAlta.ValorAnterior = "Alta";
                    endosoAlta.ValorActual = "Contratación";

                    poliza.NumeroPoliza = polizaBanorte.poliza + ((polizaBanorte.numcert > 0) ? "_" + polizaBanorte.numcert.ToString() : "");
                    poliza.FinVigencia = polizaBanorte.fecfinpol;
                    poliza.InicioVigencia = polizaBanorte.certificado.fechaInicioVigencia;

                    poliza.PrimaNeta = 0;
                    poliza.PrimaNetaAnualizada = 0;
                    poliza.PrimaTotal = 0;
                    poliza.PrimaTotalAnualizada = 0;

                    poliza.Motor = InfoEmision.NumeroMotor;
                    poliza.Serie = InfoEmision.NumeroSerie;
                    poliza.Placas = InfoEmision.Placas;
                    poliza.FechaEmision = DateTime.Now;
                    poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                    poliza.UrlPDFPoliza = "";
                    poliza.UrlPDFRecibos = "";
                    poliza.Estatus = 1;
                    poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                    poliza.IdConvenio = InfoEmision.Convenio.Id;
                    poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                    poliza.IdTipoCobertura = tipoPaquete.IdCatTipoPaquete;
                    poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
                    poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                    poliza.Acepto_DescuentoPoliza = true;

                    polizaDet.Inciso = "1";
                    polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para Banorte flotilla.
                    polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                    polizaDet.Deducible = 0;
                    polizaDet.Comision = 0;
                    polizaDet.Impuesto = 0;
                    polizaDet.Derechos = 0;
                    polizaDet.FactorIva = 16;
                    polizaDet.MigraOPERA = false;
                    polizaDet.UrlPDFPolizaOPERA = "";
                    polizaDet.PolizaOPERA = 0;
                    polizaDet.OTOpera = 0;
                    polizaDet.EndosoOPERA = 0;
                    polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                    polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;
                    polizaDet.IdCatRamoVehiculo = int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                    polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                    polizaDet.IdCatModalidadFormaPago = cotizacionDetalle.IdMedioPago ?? 0;
                    polizaDet.IdCatPeriodicidadFormaPago = cotizacionDetalle.IdFormaPago ?? 1;
                    polizaDet.XMLRecepcion = xmlRespuesta;
                    polizaDet.XMLSolicitud = xmlEnvio;
                    polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;

                    List<Recibo> recibosGenerados = new List<Recibo>();

                    foreach (var recibo in polizaBanorte.certificado.recibos)
                    {
                        Recibo reciboSave = new Recibo();
                        reciboSave.InicioVigencia = recibo.feinicio;
                        reciboSave.FinVigencia = recibo.fefin;
                        reciboSave.Numero = recibo.numdetacuerdo;
                        reciboSave.NoAsegurado = recibo.numrecibo.ToString();
                        reciboSave.PrimaNeta = recibo.prima;
                        reciboSave.Derecho = recibo.derecho;
                        reciboSave.Recargo = recibo.recargo;
                        reciboSave.Comision = recibo.comces;
                        reciboSave.Impuesto = recibo.iva;
                        reciboSave.PrimaTotal = reciboSave.PrimaNeta + reciboSave.Derecho + reciboSave.Recargo + reciboSave.Comision + reciboSave.Impuesto;
                        recibosGenerados.Add(reciboSave);

                    }

                    polizaDet.Derechos = polizaBanorte.certificado.tot_cpto.dcert;
                    polizaDet.Impuesto = polizaBanorte.certificado.tot_cpto.icert;
                    polizaDet.Comision = polizaBanorte.certificado.tot_cpto.cccert;
                    polizaDet.Recargos = polizaBanorte.certificado.tot_cpto.rcert;

                    poliza.PrimaNeta = polizaBanorte.certificado.tot_cpto.prima_neta_cesion;  //polizaBanorte.certificado.tot_cpto.pcert;
                    poliza.PrimaTotal = polizaDet.Derechos + polizaDet.Impuesto + polizaDet.Comision + polizaDet.Recargos;

                    poliza.PrimaNetaAnualizada = poliza.PrimaNeta;
                    poliza.PrimaTotalAnualizada = poliza.PrimaTotal;

                    endosoAlta.Recibo = recibosGenerados;
                    poliza.Endoso.Add(endosoAlta);
                    poliza.PolizaDetalle.Add(polizaDet);
                    db.Poliza.Add(poliza);
                    db.SaveChanges();


                    poliza.UrlPDFPoliza = ObtenerPoliza(poliza.NumeroPoliza);

                    #endregion

                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEnvio, xmlRespuesta, "", "Emisión");

                    Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                    result = new EmisionPoliza(true, xmlEnvio, xmlRespuesta, poliza);
                }

            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente para realizar tu emision {0} ", ex.Message));

                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEnvio, xmlRespuesta, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");

                //throw new Exception(string.Format("Tuvimos un inconveniente para realizar tu emision {0} ", ex.Message));
                result = new EmisionPoliza(false, xmlEnvio, ex.Message);
            }
            return result;

        }

        private LocktonModel.Services.Banorte.Vehiculo.DatosVehiculo ObtenderDatosVehiculo(mDetalles cot, Convenio convenio, int idCatRamoVehiculo, string year)
        {
            try
            {
                var datosVehiculo = new LocktonModel.Services.Banorte.Vehiculo.DatosVehiculo();

                datosVehiculo.Marca = cot.Catalogo.First().Marca.Trim();
                datosVehiculo.Modelo = cot.Catalogo.First().Modelo.Trim();
                datosVehiculo.Descripcion = cot.Catalogo.First().CatDescripciones.First().Descripcion;
                datosVehiculo.IdVersion = cot.Catalogo.First().CatDescripciones.First().clave;

                switch (idCatRamoVehiculo)
                {
                    case 1: datosVehiculo.TipoVehiculo = "AUTOMOVIL"; break;
                    case 2: datosVehiculo.TipoVehiculo = "PICK UP"; break;
                    case 3: datosVehiculo.TipoVehiculo = "MOTOCICLETA"; break;
                }
                log.Info("Banorte Obtener Datos Tipo Vehiculo Póliza:" + convenio.IdPoliza);
                var catalogoType = proxy.ObtenerCatalogoVehicule($"/type/{convenio.IdCotizacion}/{convenio.IdPoliza}");
                log.Info("Banorte Termina Obtener Datos Tipo Vehiculo");
                var tipoVehiculo = catalogoType.catalogo.FirstOrDefault(a => a.value.Contains(datosVehiculo.TipoVehiculo));

                datosVehiculo.IdTipoVehiculo = tipoVehiculo.key;

                log.Info("Banorte Obtener Datos Marca Vehiculo IdTipoVehiuclo: " + datosVehiculo.IdTipoVehiculo);
                var catalogoMarca = proxy.ObtenerCatalogoVehicule($"/brand/{convenio.IdCotizacion}/{convenio.IdPoliza}/{datosVehiculo.IdTipoVehiculo}");
                log.Info("Banorte Termina Obtener Datos Marca Vehiculo");
                var marca = catalogoMarca.catalogo.FirstOrDefault(a => a.value == datosVehiculo.Marca);
                datosVehiculo.IdMarca = marca.key;

                log.Info("Banorte Obtener Datos Modelo Vehiculo IdMarca: " + datosVehiculo.IdMarca);
                var catalogoModelo = proxy.ObtenerCatalogoVehicule($"/model/{convenio.IdCotizacion}/{convenio.IdPoliza}/{datosVehiculo.IdTipoVehiculo}/{datosVehiculo.IdMarca}");
                log.Info("Banorte Termina Obtener Datos Modelo Vehiculo");
                var modelo = catalogoModelo.catalogo.FirstOrDefault(a => a.value == datosVehiculo.Modelo);

                datosVehiculo.IdModelo = modelo.key;

                //var catalogoVersion = proxy.ObtenerCatalogoVehicule($"/version/{convenio.IdCotizacion}/{convenio.IdPoliza}/{datosVehiculo.IdTipoVehiculo}/{datosVehiculo.IdMarca}/{datosVehiculo.IdModelo}/{year}");
                //var version = catalogoModelo.catalogo.FirstOrDefault(a => a.value.Contains(datosVehiculo.Descripcion));



                return datosVehiculo;

            }
            catch (Exception ex)
            {
                log.Info(ex.ToString());
                throw new Exception("No se encontro vehiculo para cotizar.");
            }
        }

        private Colony ObtenerColonia(string cp, string colonia)
        {
            log.Info("Banorte ObtenerColonia Entra CP: " + cp);
            var colonies = proxy.ObtenerCatalogoAddress($"/colonies/{cp}");
            log.Info("Banorte Termina ObtenerColonia CP: " + cp);
            var colony = colonies.colonies.FirstOrDefault(a => a.desccolonia.ToUpper().Trim() == colonia.ToUpper().Trim());

            if (colony == null)
                colony = colonies.colonies.FirstOrDefault();

            return colony;
        }

        public byte[] ImprimirPoliza(string poliza)
        {
            try
            {

                var _poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == poliza);
                var _polizadetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == _poliza.Id);
                var responseEmision = JsonConvert.DeserializeObject<EmisionResponse>(_polizadetalle.XMLRecepcion);
                var polizaBanorte = responseEmision.emision.polizas.FirstOrDefault();

                var responsePDF = proxy.ObtenerDocumentosCertificado(polizaBanorte.cert_id);

                return System.Convert.FromBase64String(responsePDF.docs.FirstOrDefault().binary_b64);
            }
            catch (Exception ex)
            {
                log.Info(string.Format("BANORTE - ImprimirPoliza Tuvimos un inconveniente para imprimir la poliza {0} ", ex.InnerException != null ? ex.InnerException.Message : ex.Message));
                return null;
            }

        }

        public string ObtenerPoliza(string poliza)
        {
            try
            {
                var _documento = ImprimirPoliza(poliza);

                string RutaDescargaPDFsPolizas = HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/");
                string directorio = string.Format(@"{0}\{1}", RutaDescargaPDFsPolizas, "BANORTE");
                var rutaGuardadoPDFTemp = string.Concat(directorio, @"\", poliza, ".pdf");

                if (!Directory.Exists(directorio))
                {
                    Directory.CreateDirectory(directorio);
                }

                if (!File.Exists(rutaGuardadoPDFTemp))
                {
                    File.WriteAllBytes(rutaGuardadoPDFTemp, _documento);
                }

                return rutaGuardadoPDFTemp;
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Banorte - ObtenerPoliza Tuvimos un inconveniente para imprimir la poliza {0} ", ex.InnerException != null ? ex.InnerException.Message : ex.Message));
                return string.Empty;
            }
        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new NotImplementedException();
        }

        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
    }
}
