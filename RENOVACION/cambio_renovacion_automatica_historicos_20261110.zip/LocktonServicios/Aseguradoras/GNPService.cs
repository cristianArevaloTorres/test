﻿using com.lockton.xml.gnp.cotizacion.request;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonServicios.Catalogos;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace LocktonServicios.Aseguradoras
{
    public class GNPService : IGNPService
    {
        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger(typeof(GNPService));

        private Solicitud GeneraSoliciturFlotilla(CotizacionCompara CotizacionCompara,
                                                    int? convenioId,
                                                    mDetalles cot,
                                                    DetalleUsuario detalleUsuario,
                                                    VEmpConvPaq ConveniosPaquetes,
                                                    int IdTipoPaquete)
        {
            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
            CatModalidadFormaPago formaPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
            SolicitudGeneral general = new SolicitudGeneral();


            string InicioVigencia = convenioCotiza.InicioVigencia.ToString("dd/MM/yyyy");
            string FinVigencia = convenioCotiza.FinVigencia.ToString("dd/MM/yyyy");
            if (ConfigEmpresa.IdTipoDeNegocio == 2)
            {
                InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy") : DateTime.Now.ToString("dd/MM/yyyy");
                FinVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.AddYears(1).ToString("dd/MM/yyyy") : DateTime.Now.AddYears(1).ToString("dd/MM/yyyy");
            }
            else
            {
                if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, DateTime.Now))
                {
                    InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy") : DateTime.Now.ToString("dd/MM/yyyy");
                }
            }
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioId && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();

            general.Usuario = convenioCotiza.Usuario;
            general.Password = convenioCotiza.Contrasena;
            general.CodigoPromocion = convenioCotiza.CodigoPromocion;
            general.Tienda = "0";
            string caratula = "";
			//string caratula = db.Database.SqlQuery<string>(string.Format("Execute sp_CaratulasGNP_Obtener @IdConvenio={0}, @IdPaquete={1}, @IdPeriodicidad={2}, @IdFormaPago={3}, @Year={4}, @ClaveTipoVehiculo={5}", convenioId, IdTipoPaquete, CotizacionCompara.FormadePago, formaPago.Id, CotizacionCompara.Año, ObtieneIdRamoVehiculo(Convert.ToInt32(CotizacionCompara.TipoVehiculo)))).SingleOrDefault();
			if (!string.IsNullOrEmpty(caratula))
                general.OpcionesAContratar = caratula;
            else
                general.OpcionesAContratar = convenioCotiza.CaratulaPoliza;

            general.Paquete = caratula.ToUpper() == "AMPLIA GL" ? "Amplia gl" : ConveniosPaquetes.PaqueteAseguradoras.FirstOrDefault(x => x.IdAseguradora == convenioCotiza.IdAseguradora && x.IdCatTipoPaquete == IdTipoPaquete).Clave;
            general.FormaPago = perioricidad.FormaPago;
            general.MetodoPago = "R";
            general.InicioVig = InicioVigencia;//dd/MM/yyyy
            general.FinVig = FinVigencia; //dd/MM/yyyy
            general.Accion = "C";
            general.CodigoIntermediario = convenioCotiza.CodigoIntermediario;
            general.CodigoCliente = "";
            general.TipoPago = "";
            general.Cotizacion = "";
            general.descuentoGC = "";
            general.cesioncomision = "0";
            general.primerrecibo = "BC";
            general.recibosubsecuente = "BC";
            general.ValVehi = "0";
            general.PrimaTotal = "";

            SolicitudAutos autos = new SolicitudAutos();
            SolicitudAutosAuto auto = new SolicitudAutosAuto();

            auto.EstadoCirculacion = ConsultaPoblacionGNP(CotizacionCompara.CodigoPostal);
            auto.Uso = "01";

            descripciones _cotDesAuto = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault();
            catalogo _cotAuto = cot.Catalogo.FirstOrDefault();
            ConsultaCatalogoHomologado.ObjetoRespuestaBD _descripcion = new ConsultaCatalogoHomologado.ConsultaCatalogoHomologadoClient().NCHConsultaDetalleVehiculo("GNP", _cotDesAuto.clave);
            _Descripciones _resultado = JsonConvert.DeserializeObject<_Descripciones>(_descripcion.RespuestaJSON);

            auto.ClaveMarca = _cotDesAuto.clave;
            auto.Marca = _resultado.Descripciones[0].Marca;
            auto.Modelo = CotizacionCompara.Año;
            auto.Descripcion = _cotDesAuto.Descripcion;

            auto.FormaIndemnizacion = "";
            SolicitudPersonas personas = new SolicitudPersonas();
            SolicitudPersonasContratante contratante = new SolicitudPersonasContratante() { FecNac = "19840814", ContratanteIgualConductor = "N", Sexo = "Femenino" };
            personas.Contratante = new SolicitudPersonasContratante[] { contratante };

            SolicitudPersonasAsegurado asegurado = new SolicitudPersonasAsegurado();

            asegurado.CodigoCliente = "";
            asegurado.Tipo = "C";
            asegurado.Paterno = "PRUEBA";
            asegurado.Materno = "PRUEBA";
            asegurado.Nombre = "PRUEBA";
            asegurado.RFC = "PRPR900101";
            asegurado.Telefono = "5555555555";
            asegurado.Sexo = "Masculino";
            asegurado.FecNac = "1990-01-01";

            personas.Asegurado = new SolicitudPersonasAsegurado[] { asegurado };

            SolicitudCoberturas coberturas = new SolicitudCoberturas();
            List<SolicitudCoberturasCobertura> listaCoberturas = new List<SolicitudCoberturasCobertura>();

            List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete);
            foreach (Coberturas detalle in coberturasPaquete)
            {

                SolicitudCoberturasCobertura toAdd = new SolicitudCoberturasCobertura();

                toAdd.clave = detalle.Codigo;//.PadLeft(10, '0');
                toAdd.sumaasegurada = detalle.SumaAsegurada;
                toAdd.deducible = string.IsNullOrEmpty(detalle.Deducible) ? detalle.Deducible : string.Format("{0:N2}", Convert.ToDecimal(detalle.Deducible));
                toAdd.prima = "";

                if (detalle.Codigo.Contains("1289") || detalle.Codigo.Contains("1288") || detalle.Codigo.Contains("916"))
                {
                    auto.FormaIndemnizacion = detalle.Cobertura;
                    if (CotizacionCompara.ValorFactura)
                        toAdd.sumaasegurada = CotizacionCompara.MontoFactura.ToString();
                }

                listaCoberturas.Add(toAdd);

            }

            autos.Auto = new SolicitudAutosAuto[] { auto };
            coberturas.Cobertura = listaCoberturas.ToArray();

            List<Object> objList = new List<object>();
            objList.Add(general);
            objList.Add(autos);
            objList.Add(coberturas);
            objList.Add(personas);


            Solicitud solucitudCotiza = new Solicitud();

            solucitudCotiza.Items = objList.ToArray();
            return solucitudCotiza;
        }

        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("dd/MM/yyyy");

                XmlDocument xmlCotizacionSeleccionada = new XmlDocument();

                xmlCotizacionSeleccionada.LoadXml(xmlEmision);
                xmlCotizacionSeleccionada.SelectNodes("Solicitud/General/InicioVig")[0].InnerText =  date;
                      
                AutosCotizadorGNP.CotizadorGNPSoapClient cliente = new AutosCotizadorGNP.CotizadorGNPSoapClient();
                XmlNode node = cliente.Cotizar(xmlCotizacionSeleccionada.InnerXml);


                resultado.XMLSolicitud = xmlCotizacionSeleccionada.InnerXml;
                resultado.XMLRecepcion = node.OuterXml;                

                if (node.Name == "Errores")
                {
                    throw new Exception(node.OuterXml);                   
                }

                return resultado;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara,
                                                    int? convenioId,
                                                    mDetalles cot,
                                                    DetalleUsuario detalleUsuario,
                                                    ref List<LocktonModel.db.PaqueteDetalle> Coberturas,
                                                    VEmpConvPaq ConveniosPaquetes,
                                                    int IdTipoPaquete,
                                                    int idPaqueteConvenio)
        {

            try
            {
                Solicitud solucitudCotiza = new Solicitud();
                Comparar infoCompara = new Comparar();
                Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
                ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
                List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                var _perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == CotizacionCompara.FormadePago).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == _perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);

                string InicioVigencia = CotizacionCompara.FechaInicio.ToString("dd/MM/yyyy");
                string FinVigencia = CotizacionCompara.FechaFin.ToString("dd/MM/yyyy");

                infoCompara.FechaCotizacion = CotizacionCompara.FechaInicio;
                infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;

                //if (ConfigEmpresa.IdTipoDeNegocio == 2)
                //{
                //    InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy") : DateTime.Now.ToString("dd/MM/yyyy");
                //    FinVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.AddYears(1).ToString("dd/MM/yyyy") : DateTime.Now.AddYears(1).ToString("dd/MM/yyyy");

                //    infoCompara.FechaCotizacion = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion : DateTime.Now;
                //}
                //else
                //{
                //    if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, DateTime.Now))
                //    {
                //        InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy") : DateTime.Now.ToString("dd/MM/yyyy");
                //        infoCompara.FechaCotizacion = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion : DateTime.Now;
                //    }
                //}

                //if (ConfigEmpresa.IdTipoDeNegocio == 2)
                //{

                CatModalidadFormaPago formaPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                SolicitudGeneral general = new SolicitudGeneral();

                PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioId && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();

                general.Usuario = convenioCotiza.Usuario;
                general.Password = convenioCotiza.Contrasena;
                general.CodigoPromocion = convenioCotiza.CodigoPromocion;
                general.TipoCobranza = "";
                general.Tienda = "0";
                string caratula = string.Empty;// db.Database.SqlQuery<string>(string.Format("Execute sp_CaratulasGNP_Obtener @IdConvenio={0}, @IdPaquete={1}, @IdPeriodicidad={2}, @IdFormaPago={3}, @Year={4}, @ClaveTipoVehiculo={5}", convenioId, IdTipoPaquete, CotizacionCompara.FormadePago, formaPago.Id, CotizacionCompara.Año, ObtieneIdRamoVehiculo(Convert.ToInt32(CotizacionCompara.TipoVehiculo)))).SingleOrDefault();
                if (!string.IsNullOrEmpty(caratula))
                    general.OpcionesAContratar = caratula;
                else
                    general.OpcionesAContratar = convenioCotiza.CaratulaPoliza;

                general.Paquete = caratula.ToUpper() == "AMPLIA GL" ? "Amplia gl" : ConveniosPaquetes.PaqueteAseguradoras.FirstOrDefault(x => x.IdAseguradora == convenioCotiza.IdAseguradora && x.IdCatTipoPaquete == IdTipoPaquete).Clave;
                general.FormaPago = perioricidad.FormaPago;
                //Nomina es I tarjeta es R CotizacionCompara.MediodePago
                if (ConfigEmpresa.IdTipoDeNegocio != 2)
                {
                    if (CotizacionCompara.MediodePago == 0 || CotizacionCompara.MediodePago == 1)
                    {

                        if (CotizacionCompara.MediodePago == 0)
                        {
                            general.MetodoPago = "R";
                            general.primerrecibo = "BC";
                            general.recibosubsecuente = "BC";
                        }
                        else
                        {
                            general.MetodoPago = "D";
                            general.primerrecibo = "BC";
                            general.recibosubsecuente = "BC";
                        }
                    }
                    else
                    {

                        general.MetodoPago = "I";
                        general.primerrecibo = "IN";
                        general.recibosubsecuente = "IN";
                    }
                }
                else
                {
                    general.MetodoPago = "I";
                    general.primerrecibo = "IN";
                    general.recibosubsecuente = "IN";
                }


                general.InicioVig = InicioVigencia;//dd/MM/yyyy
                general.FinVig = FinVigencia; //dd/MM/yyyy
                general.Accion = "C";
                general.CodigoIntermediario = convenioCotiza.CodigoIntermediario;
                general.CodigoCliente = "";
                general.TipoPago = "";
                general.Cotizacion = "";
                general.descuentoGC = "0";
                general.cesioncomision = "0";
                general.SeguroPrevio = "no";
                general.ValVehi = "";
                general.PrimaTotal = "0";


                SolicitudAutos autos = new SolicitudAutos();
                SolicitudAutosAuto auto = new SolicitudAutosAuto();

                auto.EstadoCirculacion = ConsultaPoblacionGNP(string.IsNullOrEmpty(CotizacionCompara.CodigoPostal) ? ConveniosPaquetes.Empresa.Direccion.CodigoPostal : CotizacionCompara.CodigoPostal);
                //auto.EstadoCirculacion = ObtenerClaveEstado(CotizacionCompara.CodigoPostal);// detalleUsuario.Direccion.CatEstadosRepublica.Clave;
                auto.Uso = "01";

                descripciones _cotDesAuto = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault();
                catalogo _cotAuto = cot.Catalogo.FirstOrDefault();
                ConsultaCatalogoHomologado.ObjetoRespuestaBD _descripcion = new ConsultaCatalogoHomologado.ConsultaCatalogoHomologadoClient().NCHConsultaDetalleVehiculo("GNP", _cotDesAuto.clave);
                _Descripciones _resultado = JsonConvert.DeserializeObject<_Descripciones>(_descripcion.RespuestaJSON);

                auto.ClaveMarca = _cotDesAuto.clave;
                auto.Marca = _resultado.Descripciones[0].Marca;
                //auto.Modelo = _cotAuto.Modelo;
                auto.Modelo = CotizacionCompara.Año;
                auto.Descripcion = _cotDesAuto.Descripcion;
                auto.Motor = "";
                auto.Serie = "";
                auto.Placas = "";
                //auto.Marca = CotizacionCompara.Marca;
                //auto.Modelo = CotizacionCompara.Modelo;
                //auto.Descripcion = CotizacionCompara.Descripcion;

                auto.FormaIndemnizacion = "";

                SolicitudCoberturas coberturas = new SolicitudCoberturas();
                List<SolicitudCoberturasCobertura> listaCoberturas = new List<SolicitudCoberturasCobertura>();
                var coberturaUtils = new Utilidades.CoberturasUtils();

                if (ConfigEmpresa.IdTipoDeNegocio.Value != 2)
                {
                    foreach (Coberturas paquete in coberturasPaquete)
                    {
                        bool aplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(CotizacionCompara.IdConvenio, paquete.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                        bool EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, paquete.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);

                        if ((EsCondEspecial && aplicaCobertura) || !EsCondEspecial)
                        {
                            SolicitudCoberturasCobertura coberAdd = new SolicitudCoberturasCobertura();
                            coberAdd.clave = paquete.Codigo.PadLeft(10, '0'); ;
                            coberAdd.sumaasegurada = string.IsNullOrEmpty(paquete.SumaAsegurada) ? "0" : paquete.SumaAsegurada.Replace(",", "");
                            coberAdd.deducible = string.IsNullOrEmpty(paquete.Deducible) ? paquete.Deducible : string.Format("{0:N2}", Convert.ToDecimal(paquete.Deducible));
                            decimal deducible = !string.IsNullOrEmpty(paquete.Deducible) ? Convert.ToDecimal(paquete.Deducible) * 100 : 0;
                            coberAdd.impresiondeducible = deducible != 0 ? string.Format("{0:N0}", deducible) + "%" : "";

                            decimal sumaAsegurada = 0;
                            if (decimal.TryParse(paquete.SumaAsegurada, out sumaAsegurada))
                            {
                                string a = paquete.Cobertura;
                                if (sumaAsegurada == 0 && a.Contains("AMPARADA"))
                                {
                                    coberAdd.sumaasegurada = paquete.Cobertura.ToString().Trim();
                                    coberAdd.impresionsa = paquete.Cobertura.ToString().Trim();
                                }
                                else
                                {
                                    if (a.Contains("AMPARADA"))
                                    {
                                        coberAdd.impresionsa = paquete.Cobertura.ToString().Trim();
                                        coberAdd.deducible = "";
                                        coberAdd.impresiondeducible = "";
                                    }
                                    else
                                    {
                                        coberAdd.impresionsa = paquete.SumaAsegurada == "0" ? "" : string.Format("$" + Convert.ToDecimal(paquete.SumaAsegurada).ToString("#,##0.00"));
                                    }

                                }

                            }
                            listaCoberturas.Add(coberAdd);
                        }
                    }
                }
                else
                {
                    foreach (Coberturas detalle in coberturasPaquete)
                    {
                        bool aplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(CotizacionCompara.IdConvenio, detalle.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                        bool EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, detalle.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);

                        if ((EsCondEspecial && aplicaCobertura) || !EsCondEspecial)
                        {
                            SolicitudCoberturasCobertura toAdd = new SolicitudCoberturasCobertura();

                            if (ConfigEmpresa.IdTipoDeNegocio == 2)
                                toAdd.clave = detalle.Codigo.PadLeft(10, '0');
                            else
                                toAdd.clave = detalle.Codigo;
                            toAdd.sumaasegurada = detalle.SumaAsegurada;
                            toAdd.deducible = string.IsNullOrEmpty(detalle.Deducible) ? detalle.Deducible : string.Format("{0:N2}", Convert.ToDecimal(detalle.Deducible));
                            toAdd.prima = "";

                            if (detalle.Codigo.Contains("1289") || detalle.Codigo.Contains("1288") || detalle.Codigo.Contains("916"))
                            {
                                auto.FormaIndemnizacion = detalle.Cobertura;
                                if (CotizacionCompara.ValorFactura)
                                    toAdd.sumaasegurada = CotizacionCompara.MontoFactura.ToString();
                            }

                            listaCoberturas.Add(toAdd);
                        }
                    }
                }
                auto.ValorConvenido = "";
                autos.Auto = new SolicitudAutosAuto[] { auto };
                coberturas.Cobertura = listaCoberturas.ToArray();

                SolicitudPersonas personas = new SolicitudPersonas();
                SolicitudPersonasContratante contratante = new SolicitudPersonasContratante();
                int edad = string.IsNullOrEmpty(CotizacionCompara.Edad) ? Utilidades.Utilidades.CalculaEdad(detalleUsuario.FECHANACIMIENTO) : Convert.ToInt32(CotizacionCompara.Edad);
                contratante.CodigoCliente = "";
                contratante.Tipo = "C";
                contratante.FecNac = DateTime.Now.ToString("dd") + "/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.AddYears(-edad).Year.ToString();
                contratante.CP = CotizacionCompara.CodigoPostal;
                contratante.Numero = "0";
                contratante.Sexo = CotizacionCompara.Genero;
                contratante.Edad = CotizacionCompara.Edad;
                contratante.Paterno = "";
                contratante.Materno = "";
                contratante.Nombre = "";
                contratante.EdoCivil = "";
                contratante.RFC = "";
                contratante.Telefono = "";
                contratante.Lada = "";
                contratante.TelefonoOficina = "";
                contratante.LadaOficina = "";
                contratante.TelefonoMovil = "";
                contratante.LadaMovil = "";
                contratante.Extension = "";
                contratante.CorreoElectronico = "";
                contratante.Ocupacion = "";
                contratante.Nacionalidad = "";
                contratante.Estado = "";
                contratante.Poblacion = "";
                contratante.Calle = "";
                contratante.Colonia = "";
                contratante.Beneficiario = "";
                contratante.RazonSocial = "";
                contratante.Giro = "";
                contratante.fechaConstitucion = "";
                contratante.ContratanteIgualConductor = "";
                contratante.Interior = "";

                personas.Contratante = new SolicitudPersonasContratante[] { contratante };

                SolicitudPersonasAsegurado asegurado = new SolicitudPersonasAsegurado();
                asegurado.CodigoCliente = "";
                asegurado.Tipo = "";
                asegurado.Paterno = "";
                asegurado.Materno = "";
                asegurado.Nombre = "";
                asegurado.RFC = "";
                asegurado.Telefono = "";
                asegurado.FecNac = "";
                asegurado.Sexo = "";

                personas.Asegurado = new SolicitudPersonasAsegurado[] { asegurado };

                List<Object> objList = new List<object>();
                objList.Add(general);
                objList.Add(autos);
                objList.Add(personas);
                objList.Add(coberturas);
                solucitudCotiza.Items = objList.ToArray();
                //}
                //else
                //           solucitudCotiza = GeneraSoliciturFlotilla(CotizacionCompara, convenioId, cot, detalleUsuario, ConveniosPaquetes, IdTipoPaquete);



                string XmlizedString = new ABACHUBBService().ToXMLString<Solicitud>(solucitudCotiza);

                log.Info(string.Format("GNP Xml Cotizacion Solicitud: {0}", XmlizedString));

                AutosCotizadorGNP.CotizadorGNPSoapClient cliente = new AutosCotizadorGNP.CotizadorGNPSoapClient();
                XmlNode node = cliente.Cotizar(XmlizedString);




                infoCompara.XmlEmision = XmlizedString;
                infoCompara.XmlRespuesta = node.OuterXml;
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.Aseguradora = "GNP";
                infoCompara.Año = CotizacionCompara.Año;
                infoCompara.FechaInicio = InicioVigencia;
                infoCompara.FechaFin = FinVigencia;
                infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                log.Info(string.Format("GNP Xml Cotizacion Respuesta: {0}", node.OuterXml));

                if (node.Name == "Errores")
                {
                    infoCompara.ErrorXML = node.OuterXml;
                    log.Error("cotizaVehiculo error GNP " + node.OuterXml);

                    //return cotizacionDet;
                }
                else
                {


                    TextReader reader = new StringReader(node.OuterXml);
                    XmlSerializer xs = new XmlSerializer(typeof(com.lockton.xml.gnp.cotizacion.response.Emision));
                    com.lockton.xml.gnp.cotizacion.response.Emision movimientoResult = (com.lockton.xml.gnp.cotizacion.response.Emision)xs.Deserialize(reader);

                    infoCompara.CotizacionClave = movimientoResult.General.Cotizacion;

                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in movimientoResult.Paquetes)
                    {

                        infoCompara.Coberturas = new List<Coberturas>();
                        foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesCoberturas cobertura in paquete.Coberturas)
                        {
                            infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();

                            foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesCoberturasCobertura coberturaDet in cobertura.Cobertura)
                            {
                                Coberturas _coberturaPaquete = coberturasPaquete.FirstOrDefault(a => a.Nombre.ToUpper().Trim() == coberturaDet.Nombre.ToUpper().Trim());
                                if (_coberturaPaquete != null)
                                {
                                    Coberturas cotCob = new Coberturas();

                                    cotCob.Cobertura = QuitaCaracteres(coberturaDet.Prima);
                                    cotCob.SumaAsegurada = QuitaCaracteres(coberturaDet.Suma_Asegurada);
                                    cotCob.Nombre = coberturaDet.Nombre.Trim();
                                    if (ConfigEmpresa.IdTipoDeNegocio == 2)
                                        cotCob.Deducible = string.IsNullOrWhiteSpace(coberturaDet.Deducible) ? "" : (Convert.ToDouble(coberturaDet.Deducible) * 100).ToString();
                                    else
                                        cotCob.Deducible = coberturaDet.Deducible;
                                    cotCob.Codigo = _coberturaPaquete.Codigo;
                                    infoCompara.Coberturas.Add(cotCob);
                                }
                            }
                        }

                        foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                        {
                            infoCompara.PrimaNeta = QuitaCaracteres(primasResultado.Totales[0].PrimaNeta);
                            infoCompara.PrimaTotal = QuitaCaracteres(primasResultado.Totales[0].TotalPagar);
                            infoCompara.Impuesto = QuitaCaracteres(primasResultado.Totales[0].IVA);
                            infoCompara.Recargo = QuitaCaracteres(primasResultado.Totales[0].RecargoPagoFracc);
                            infoCompara.Derecho = QuitaCaracteres(primasResultado.Totales[0].DerechoPoliza);

                            infoCompara.PrimerPago = QuitaCaracteres(primasResultado.Totales[0].PrimerPago);
                            infoCompara.SegundoPago = QuitaCaracteres(primasResultado.Totales[0].PagosSubsecuentes);
                            infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;

                        }

                    }
                }
                CotizacionCompara.Comparar.Add(infoCompara);


            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente para realizar tu cotizacion {0}", ex.Message));
				Comparar infoCompara = new Comparar();
				infoCompara.ErrorXML = ex.Message;
				infoCompara.Aseguradora = "GNP";
				CotizacionCompara.Comparar.Add(infoCompara);
			}



            return CotizacionCompara;
        }
       
        public int GeneraPolizaNoEmitida(InformacionEmision InfoEmision)
        {
            SolicitudGeneral general = new SolicitudGeneral();
            bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.FormaPago).FirstOrDefault();
            CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Empresa.Id).FirstOrDefault();

            log.Info("Inicia emision GNP");

            general.Usuario = InfoEmision.Convenio.Usuario;
            general.Password = InfoEmision.Convenio.Contrasena;
            general.CodigoPromocion = InfoEmision.Convenio.CodigoPromocion;
            general.Tienda = "0";
            string caratula = string.Empty;// db.Database.SqlQuery<string>(string.Format("Execute sp_CaratulasGNP_Obtener @IdConvenio={0}, @IdPaquete={1}, @IdPeriodicidad={2}, @IdFormaPago={3}, @Year={4}, @ClaveTipoVehiculo={5}", InfoEmision.Convenio.Id, InfoEmision.CotizacionAutoGuardar.Cobertura, InfoEmision.CotizacionAutoGuardar.FormadePago, InfoEmision.CotizacionAutoGuardar.MediodePago, InfoEmision.CotizacionAutoGuardar.Agnio, ObtieneIdRamoVehiculo(Convert.ToInt32(InfoEmision.CotizacionAutoGuardar.TipoVehiculo)))).SingleOrDefault();
            if (!string.IsNullOrEmpty(caratula))
                general.OpcionesAContratar = caratula;
            else
                general.OpcionesAContratar = InfoEmision.Convenio.CaratulaPoliza;

            general.Paquete = caratula.ToUpper() == "AMPLIA GL" ? "Amplia gl" : InfoEmision.Paquete;
            general.FormaPago = perioricidad.FormaPago;
            //Nomina es I tarjeta es R CotizacionCompara.MediodePago
            if (InfoEmision.CotizacionAutoGuardar.MediodePago == 2)
            {
                general.MetodoPago = "I";
                general.primerrecibo = "IN";
                general.recibosubsecuente = "IN";
            }
            else
            {
                general.MetodoPago = "R";
                general.primerrecibo = "BC";
                general.recibosubsecuente = "BC";
            }

            string InicioVigencia = InfoEmision.Convenio.InicioVigencia.ToString("yyyy-MM-dd");
            string FinVigencia = InfoEmision.Convenio.FinVigencia.ToString("yyyy-MM-dd");
            if (ConfigEmpresa.IdTipoDeNegocio == 2)
            {
                InicioVigencia = DateTime.Now.ToString("yyyy-MM-dd");
                FinVigencia = DateTime.Now.AddYears(1).ToString("yyyy-MM-dd");
            }
            else
            {
                if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(InfoEmision.Convenio.IdEmpresa, DateTime.Now))
                {
                    InicioVigencia = DateTime.Now.ToString("yyyy-MM-dd");
                }
            }

            general.InicioVig = InicioVigencia;//dd/MM/yyyy
            general.FinVig = FinVigencia; //dd/MM/yyyy
            general.Accion = "E";
            general.Cotizacion = InfoEmision.NoCotizacion; // cotizacionDet.cotizacionClave;
            general.CodigoIntermediario = InfoEmision.Convenio.ClaveAgente.ToString();
            general.CodigoCliente = "";
            general.TipoPago = "";
            general.ValVehi = "0";
            general.PrimaTotal = "";

            SolicitudAutos autos = new SolicitudAutos();
            SolicitudAutosAuto auto = new SolicitudAutosAuto();

            auto.EstadoCirculacion = InfoEmision.Direccion.CatEstadosRepublica.Clave;
            auto.Uso = "01";
            auto.ClaveMarca = InfoEmision.CotizacionAutoGuardar.Amis;
            auto.Marca = InfoEmision.CotizacionAutoGuardar.Marca;
            auto.Modelo = InfoEmision.CotizacionAutoGuardar.Modelo;
            auto.Descripcion = InfoEmision.CotizacionAutoGuardar.ObtieneDescVehiculo();
            auto.Motor = InfoEmision.NumeroMotor;
            auto.Serie = InfoEmision.NumeroSerie;
            auto.Placas = InfoEmision.Placas;

            SolicitudPersonas personas = new SolicitudPersonas();
            SolicitudPersonasContratante contratante = new SolicitudPersonasContratante();

            contratante.Tipo = "C";
            contratante.CodigoCliente = "";
            contratante.EdoCivil = "";
            contratante.RFC = InfoEmision.DatosUsuario.RFC;
            contratante.Telefono = InfoEmision.TelefonoCel;
            contratante.Lada = "";
            contratante.TelefonoOficina = "";
            contratante.TelefonoMovil = "";
            contratante.LadaMovil = "";
            contratante.Extension = "";
            contratante.CorreoElectronico = InfoEmision.DetalleUsuario.Correo;
            contratante.Ocupacion = "ADMINISTRADOR";

            if (!string.IsNullOrEmpty(InfoEmision.Empresa.RazonSocial))
            {
                contratante.RazonSocial = InfoEmision.Empresa.RazonSocial + "PRUEBA";
                contratante.fechaConstitucion = InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yyyy");
            }
            else
            {
                contratante.Nombre = !EsProduccion ? "PRUEBA" : string.Format("{0} {1}", InfoEmision.DetalleUsuario.Nombre.Trim(), (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.NombreDos) ? "" : InfoEmision.DetalleUsuario.NombreDos.Trim()));
                contratante.Paterno = !EsProduccion ? "PRUEBA" : (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoPaterno) ? "" : InfoEmision.DetalleUsuario.ApellidoPaterno.Trim());
                contratante.Materno = !EsProduccion ? "PRUEBA" : (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoMaterno) ? "" : InfoEmision.DetalleUsuario.ApellidoMaterno.Trim());
                contratante.Sexo = "Masculino";
                contratante.FecNac = InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yyyy");
                contratante.Edad = Utilidades.Utilidades.CalculaEdad(InfoEmision.DetalleUsuario.FECHANACIMIENTO).ToString();

            }

            contratante.FecNac = InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yyyy");
            contratante.Nombre = !EsProduccion ? "PRUEBA" : string.Format("{0} {1}", InfoEmision.DetalleUsuario.Nombre.Trim(), (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.NombreDos) ? "" : InfoEmision.DetalleUsuario.NombreDos.Trim()));
            contratante.Paterno = !EsProduccion ? "PRUEBA" : (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoPaterno) ? "" : InfoEmision.DetalleUsuario.ApellidoPaterno.Trim());
            contratante.Materno = !EsProduccion ? "PRUEBA" : (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoMaterno) ? "" : InfoEmision.DetalleUsuario.ApellidoMaterno.Trim());
            contratante.Nacionalidad = "MEXICO";
            contratante.CP = InfoEmision.DetalleUsuario.Direccion.CodigoPostal;
            contratante.Estado = InfoEmision.DetalleUsuario.Direccion.CatEstadosRepublica.Clave;
            contratante.Poblacion = InfoEmision.DetalleUsuario.Direccion.CatCodigoPostal.IdMunicipioCotizacion;
            contratante.Calle = InfoEmision.DetalleUsuario.Direccion.DireccionCompleta;
            contratante.Numero = InfoEmision.DetalleUsuario.Direccion.NumeroExt;
            contratante.Interior = InfoEmision.DetalleUsuario.Direccion.NumeroInt;
            contratante.Colonia = InfoEmision.DetalleUsuario.Direccion.Colonia;
            contratante.Beneficiario = InfoEmision.BeneficiarioPreferente;
            contratante.Giro = "";
            contratante.ContratanteIgualConductor = "N";

            personas.Contratante = new SolicitudPersonasContratante[] { contratante };

            SolicitudPersonasAsegurado asegurado = new SolicitudPersonasAsegurado();

            asegurado.CodigoCliente = "";
            asegurado.Tipo = "";
            asegurado.Paterno = string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoPaterno) ? "" : InfoEmision.DetalleUsuario.ApellidoPaterno.Trim();
            asegurado.Materno = string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoMaterno) ? "" : InfoEmision.DetalleUsuario.ApellidoMaterno.Trim();
            asegurado.Nombre = string.Format("{0} {1}", InfoEmision.DetalleUsuario.Nombre.Trim(), (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.NombreDos) ? "" : InfoEmision.DetalleUsuario.NombreDos.Trim()));
            asegurado.RFC = InfoEmision.DatosUsuario.RFC;
            asegurado.Telefono = InfoEmision.TelefonoCel;
            asegurado.Sexo = "Masculino";
            asegurado.FecNac = InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yyyy");


            personas.Asegurado = new SolicitudPersonasAsegurado[] { asegurado };

            List<Coberturas> coberturasPaquete = ObtenerCoberturas(InfoEmision.Convenio.Id, Convert.ToInt32(cotizacionDetalle.Paquete));

            SolicitudCoberturas coberturas = new SolicitudCoberturas();
            List<SolicitudCoberturasCobertura> listaCoberturas = new List<SolicitudCoberturasCobertura>();

            string FormaIndemnizacion = "";

            foreach (Coberturas paquete in coberturasPaquete)
            {
                string deducible = "";
                string deducibleImpresion = "";
                string dedPorcen = "";
                if (string.IsNullOrEmpty(paquete.Deducible))
                {
                    double deduciblePorcentaje = double.Parse(paquete.Deducible);

                    if (deduciblePorcentaje > 0)
                    {
                        dedPorcen = deduciblePorcentaje.ToString();
                        deducible = (deduciblePorcentaje * 100).ToString();
                        deducibleImpresion = deducible + "%";
                    }
                }

                SolicitudCoberturasCobertura coberAdd = new SolicitudCoberturasCobertura();
                coberAdd.clave = paquete.Codigo;
                coberAdd.sumaasegurada = string.IsNullOrEmpty(paquete.SumaAsegurada) ? "0" : paquete.SumaAsegurada.Replace(",", "");
                coberAdd.deducible = dedPorcen;
                coberAdd.impresiondeducible = deducibleImpresion;
                coberAdd.impresionsa = string.IsNullOrEmpty(paquete.SumaAsegurada) ? "0" : paquete.SumaAsegurada.Replace(",", "");
                coberAdd.prima = "";

                if (paquete.Codigo.Contains("1289") || paquete.Codigo.Contains("1288") || paquete.Codigo.Contains("916"))
                {
                    coberAdd.sumaasegurada = InfoEmision.CotizacionAutoGuardar.MontoFactura.ToString();
                    if (string.IsNullOrEmpty(paquete.Cobertura))//descripcion
                        FormaIndemnizacion = paquete.Cobertura;

                }


                listaCoberturas.Add(coberAdd);


            }
            coberturas.Cobertura = listaCoberturas.ToArray();

            //                                          //HRZ 19Dic2018 (MODIFICACION) BANK OF AMERICA
            auto.FormaIndemnizacion = FormaIndemnizacion;
            autos.Auto = new SolicitudAutosAuto[] { auto };
            //                                          //HRZ 19Dic2018 (FIN MODIFICACION) BANK OF AMERICA
            List<Object> objList = new List<object>();

            objList.Add(general);
            objList.Add(autos);
            objList.Add(personas);
            objList.Add(coberturas);

            Solicitud solucitudCotiza = new Solicitud();
            solucitudCotiza.Items = objList.ToArray();

            string XmlizedString = new ABACHUBBService().ToXMLString<Solicitud>(solucitudCotiza);

            log.Info(string.Format("GNP Xml Emision Solicitud: {0}", XmlizedString.Replace("\n", "").Replace("\r", "")));

            Poliza poliza = new Poliza();
            PolizaDetalle polizaDet = new PolizaDetalle();

            poliza.FinVigencia = DateTime.Now;
            poliza.InicioVigencia = DateTime.Now;
            poliza.NumeroPoliza = "";
            poliza.PrimaNeta = 0;
            poliza.PrimaNetaAnualizada = 0;
            poliza.PrimaTotal = 0;
            poliza.PrimaTotalAnualizada = 0;
            poliza.Motor = InfoEmision.NumeroMotor;
            poliza.Serie = InfoEmision.NumeroSerie;
            poliza.Placas = InfoEmision.Placas;
            poliza.FechaEmision = DateTime.Now;
            poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
            poliza.UrlPDFPoliza = "";
            poliza.UrlPDFRecibos = "";
            poliza.Estatus = 20;
            poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
            poliza.IdConvenio = InfoEmision.Convenio.Id;
            poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
            poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
            poliza.Acepto_DescuentoPoliza = true;

            polizaDet.Inciso = "1";
            polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para GNP.
            polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
            polizaDet.Deducible = 0;
            polizaDet.Comision = 0;
            polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
            polizaDet.MigraOPERA = false;
            polizaDet.UrlPDFPolizaOPERA = "";
            polizaDet.PolizaOPERA = 0;
            polizaDet.OTOpera = 0;
            polizaDet.EndosoOPERA = 0;
            polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
            polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;
            polizaDet.IdCatRamoVehiculo = cotizacionDetalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
            polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
            polizaDet.IdCatModalidadFormaPago = InfoEmision.CotizacionAutoGuardar.MediodePago;
            polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
            polizaDet.XMLSolicitud = XmlizedString;
            polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;
            poliza.PolizaDetalle.Add(polizaDet);
            db.Poliza.Add(poliza);
            db.SaveChanges();


            return poliza.Id;
        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new System.NotImplementedException();
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            SolicitudGeneral general = new SolicitudGeneral();
            bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            CatPeriodicidadFormaPago catPeriodicidad = db.CatPeriodicidadFormaPago.FirstOrDefault(x => x.Id == InfoEmision.CotizacionAutoGuardar.FormadePago);
            CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
            Cotizacion cotizacion = db.Cotizacion.First(a => a.Id == cotizacionDetalle.IdCotizacion);
            int IdPaquete = int.Parse(cotizacionDetalle.Paquete);
            PaqueteAseguradora tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == InfoEmision.Convenio.IdAseguradora && x.IdCatTipoPaquete == IdPaquete).FirstOrDefault();
            CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
            string telefono = InfoEmision.TelefonoCel;

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            xmlCotizacionSeleccionada.LoadXml(cotizacionDetalle.XMLSolicitud);
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Empresa.Id).FirstOrDefault();

            var ramoVehiculo = db.CatRamoVehiculo.First(x => x.Clave == InfoEmision.CotizacionAutoGuardar.TipoVehiculo);
            var convenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatRamoVehiculo == ramoVehiculo.IdCatRamo);


            log.Info("Inicia emision GNP");
            if (!string.IsNullOrEmpty(telefono) && telefono.Length > 8)
            {
                telefono = telefono.Substring(telefono.Length - Math.Min(8, telefono.Length));
            }
            general.Usuario = InfoEmision.Convenio.Usuario;
            general.Password = InfoEmision.Convenio.Contrasena;
            general.CodigoPromocion = InfoEmision.Convenio.CodigoPromocion;
            general.Tienda = "0";
            string caratula = string.Empty;// db.Database.SqlQuery<string>(string.Format("Execute sp_CaratulasGNP_Obtener @IdConvenio={0}, @IdPaquete={1}, @IdPeriodicidad={2}, @IdFormaPago={3},@Year={4}, @ClaveTipoVehiculo={5}", InfoEmision.Convenio.Id, IdPaquete /*InfoEmision.CotizacionAutoGuardar.Cobertura*/, InfoEmision.CotizacionAutoGuardar.FormadePago, medioPago.Id, InfoEmision.CotizacionAutoGuardar.Agnio, ObtieneIdRamoVehiculo(Convert.ToInt32(InfoEmision.CotizacionAutoGuardar.TipoVehiculo)))).SingleOrDefault();

            if (!string.IsNullOrEmpty(caratula))
                general.OpcionesAContratar = caratula;
            else
                general.OpcionesAContratar = InfoEmision.Convenio.CaratulaPoliza;

            general.Paquete = caratula.ToUpper() == "AMPLIA GL" ? "Amplia gl" : tipoPaquete.Clave.ToString();
            general.FormaPago = perioricidad.FormaPago;
            //Nomina es I tarjeta es R CotizacionCompara.MediodePago
            if (ConfigEmpresa.IdTipoDeNegocio != 2)
            {

                if (InfoEmision.CotizacionAutoGuardar.MediodePago == 0 || InfoEmision.CotizacionAutoGuardar.MediodePago == 1)
                {
                    if (InfoEmision.CotizacionAutoGuardar.MediodePago == 0)
                    {
                        general.MetodoPago = "R";
                        general.primerrecibo = "BC";
                        general.recibosubsecuente = "BC";
                    }
                    else
                    {
                        general.MetodoPago = "D";
                        general.primerrecibo = "BC";
                        general.recibosubsecuente = "BC";
                    }

                }
                else
                {
                    general.MetodoPago = "I";
                    general.primerrecibo = "IN";
                    general.recibosubsecuente = "IN";


                }
            }
            else
            {
                general.MetodoPago = "I";
                general.primerrecibo = "IN";
                general.recibosubsecuente = "IN";


            }

            DateTime InicioVigencia = InfoEmision.Convenio.InicioVigencia;
            DateTime FinVigencia = InfoEmision.Convenio.FinVigencia;
            if (ConfigEmpresa.IdTipoDeNegocio == 2)
            {
                InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? cotizacion.FechaFactura : DateTime.Now;
                FinVigencia = ConfigEmpresa.AplicaFechaCotizacion ? cotizacion.FechaFactura.AddYears(1) : DateTime.Now.AddYears(1);
            }
            else
            {
                if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(InfoEmision.Convenio.IdEmpresa, DateTime.Now))
                {
                    InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? cotizacion.FechaFactura : DateTime.Now;
                }
            }

            general.InicioVig = InicioVigencia.ToString("dd/MM/yyyy");//dd/MM/yyyy
            general.FinVig = FinVigencia.ToString("dd/MM/yyyy");//dd/MM/yyyy
            general.Accion = InfoEmision.EsFlotilla ? "E" : "C";
            general.Cotizacion = InfoEmision.EsFlotilla ? InfoEmision.NoCotizacion : ""; // cotizacionDet.cotizacionClave;
            general.referencia = InfoEmision.DetalleUsuario.IdEmpleado;
            general.cesioncomision = db.Convenio.Where(x => x.Id == InfoEmision.Convenio.Id).FirstOrDefault().Comision.ToString();
            general.descuentoGC = db.Convenio.Where(x => x.Id == InfoEmision.Convenio.Id).FirstOrDefault().Descuento.ToString();
            general.CodigoIntermediario = InfoEmision.Convenio.CodigoIntermediario;
            general.CodigoCliente = "";
            general.TipoPago = "";
            general.ValVehi = "0";
            general.PrimaTotal = "0";

            SolicitudAutos autos = new SolicitudAutos();
            SolicitudAutosAuto auto = new SolicitudAutosAuto();
            string amis = xmlCotizacionSeleccionada.SelectNodes("Solicitud/Autos/Auto/ClaveMarca")[0].InnerText;
            ConsultaCatalogoHomologado.ObjetoRespuestaBD _descripcion = new ConsultaCatalogoHomologado.ConsultaCatalogoHomologadoClient().NCHConsultaDetalleVehiculo("GNP", amis);
            _Descripciones _resultado = JsonConvert.DeserializeObject<_Descripciones>(_descripcion.RespuestaJSON);
            string codigoPostal = "";

            if (InfoEmision.EsFlotilla)
                codigoPostal = InfoEmision.Empresa.Direccion.CodigoPostal;
            else
                codigoPostal = InfoEmision.DatosUsuario.Direccion.CodigoPostal;

            CodigoPostal catCodigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == codigoPostal);
            List<Coberturas> coberturasPaquete = ObtenerCoberturas(InfoEmision.Convenio.Id, Convert.ToInt32(cotizacionDetalle.Paquete));
            auto.EstadoCirculacion = ConsultaPoblacionGNP(codigoPostal);
            //auto.EstadoCirculacion = InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
            auto.Uso = "01";
            auto.ClaveMarca = amis;
            auto.Marca = _resultado.Descripciones[0].Marca;
            auto.Modelo = InfoEmision.CotizacionAutoGuardar.Agnio;
            auto.Descripcion = xmlCotizacionSeleccionada.SelectNodes("Solicitud/Autos/Auto/Descripcion")[0].InnerText;
            auto.Motor = InfoEmision.NumeroMotor;
            auto.Serie = InfoEmision.NumeroSerie;
            auto.Placas = InfoEmision.Placas;

            foreach (Coberturas paquete in coberturasPaquete)
            {

                if (paquete.Codigo.Contains("1289") || paquete.Codigo.Contains("1288") || paquete.Codigo.Contains("916"))
                {
                    auto.FormaIndemnizacion = paquete.Cobertura;
                }

            }
            auto.ValorConvenido = "";
            SolicitudPersonas personas = new SolicitudPersonas();
            SolicitudPersonasContratante contratante = new SolicitudPersonasContratante();

            contratante.Tipo = "C";
            contratante.CodigoCliente = "";
            contratante.EdoCivil = "";
            contratante.RFC = InfoEmision.EsFlotilla ? InfoEmision.DetalleUsuario.RFC != null ? InfoEmision.DetalleUsuario.RFC : LocktonServicios.Utilidades.Utilidades.CalcularRFC(InfoEmision.DetalleUsuario.Nombre + " " + InfoEmision.DetalleUsuario.NombreDos, InfoEmision.DetalleUsuario.ApellidoPaterno, InfoEmision.DetalleUsuario.ApellidoMaterno, InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yy")) : InfoEmision.DatosUsuario.RFC;
            contratante.Telefono = InfoEmision.TelefonoFijo.Substring(2);
            contratante.Lada = InfoEmision.TelefonoFijo.Substring(0, 2);
            contratante.TelefonoOficina = "";
            contratante.TelefonoMovil = InfoEmision.TelefonoCel;
            contratante.LadaMovil = "";
            contratante.Extension = "";
            contratante.CorreoElectronico = InfoEmision.ConfirmaEmail;
            contratante.Sexo = string.IsNullOrEmpty(xmlCotizacionSeleccionada.SelectNodes("Solicitud/Personas/Contratante/Sexo")[0].InnerText) ? InfoEmision.DetalleUsuario.GENERO : xmlCotizacionSeleccionada.SelectNodes("Solicitud/Personas/Contratante/Sexo")[0].InnerText;
            contratante.Ocupacion = "ADMINISTRADOR";

            if (!InfoEmision.EsFlotilla)
            {
                /*si se envia entonces debe de ir la fecha de constitucion de la empresa no del usuario*/
                contratante.RazonSocial = "";// InfoEmision.Empresa.RazonSocial ;
                //contratante.fechaConstitucion = InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy");
                contratante.fechaConstitucion = "";// DateTime.TryParse(InfoEmision.Empresa.FechaConstitucion.ToString(), out fechaConst) ? fechaConst.ToString("dd/MM/yyyy") : "01/01/2000";
                contratante.FecNac = InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy");
                contratante.Nombre = string.Format("{0} {1}", QuitarAcentos(InfoEmision.PrimerNombre.Trim()), (string.IsNullOrEmpty(InfoEmision.SegundoNombre) ? "" : QuitarAcentos(InfoEmision.SegundoNombre.Trim())));
                contratante.Paterno = string.IsNullOrEmpty(InfoEmision.ApellidoPaterno) ? "" : QuitarAcentos(InfoEmision.ApellidoPaterno.Trim());
                contratante.Materno = string.IsNullOrEmpty(InfoEmision.ApellidoMaterno) ? "" : QuitarAcentos(InfoEmision.ApellidoMaterno.Trim());
            }
            else
            {
                contratante.FecNac = InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yyyy");
                contratante.Nombre = string.Format("{0} {1}", InfoEmision.DetalleUsuario.Nombre.Trim(), (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.NombreDos) ? "" : QuitarAcentos(InfoEmision.DetalleUsuario.NombreDos.Trim())));
                contratante.Paterno = (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoPaterno) ? "" : QuitarAcentos(InfoEmision.DetalleUsuario.ApellidoPaterno.Trim()));
                contratante.Materno = (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoMaterno) ? "" : QuitarAcentos(InfoEmision.DetalleUsuario.ApellidoMaterno.Trim()));
                //contratante.Edad = Utilidades.Utilidades.CalculaEdad(InfoEmision.FechaNacimiento).ToString();
                contratante.Edad = InfoEmision.Edad == 0 ? Utilidades.Utilidades.CalculaEdad(InfoEmision.DetalleUsuario.FECHANACIMIENTO).ToString() : InfoEmision.Edad.ToString();

            }

            //contratante.FecNac = InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yyyy");

            contratante.Nacionalidad = "MEXICO";

            contratante.CP = codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
            contratante.Estado = catCodigoPostal.CatEstadosRepublica.Clave;// InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;

            contratante.Poblacion = QuitarAcentos(catCodigoPostal.CatEstadosRepublica.Estado);// InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Estado;
            contratante.Calle = InfoEmision.EsFlotilla ? QuitarAcentos(InfoEmision.Empresa.Direccion.Calle) : QuitarAcentos(InfoEmision.DatosUsuario.Direccion.Calle);
            contratante.Numero = InfoEmision.EsFlotilla ? InfoEmision.Empresa.Direccion.NumeroExt : InfoEmision.DatosUsuario.Direccion.NumeroExt;
            contratante.Interior = InfoEmision.EsFlotilla ? InfoEmision.Empresa.Direccion.NumeroInt : InfoEmision.DatosUsuario.Direccion.NumeroInt;
            contratante.Colonia = QuitarAcentos(catCodigoPostal.Asentamiento);// InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
            contratante.Beneficiario = InfoEmision.BeneficiarioPreferente;
            contratante.Giro = "";
            if (InfoEmision.ConductorHabitual)
            {
                contratante.ContratanteIgualConductor = "S";
            }
            else
            {
                contratante.ContratanteIgualConductor = "N";
            }

            ///*Representante Legal*/
            //RepLegal representanteLegal = new RepLegal();
            //representanteLegal.Correoelectronico = "";
            //representanteLegal.Paterno = "";
            //representanteLegal.Materno = "";
            //representanteLegal.RFC = "";
            //representanteLegal.Telefono = "";
            //representanteLegal.Lada = "";
            //representanteLegal.Ocupacion = "";
            //representanteLegal.FechaNacimiento = "";
            //representanteLegal.Nacionalidad = "MEXICO";
            //representanteLegal.CP = "";
            //representanteLegal.Estado = "";
            //representanteLegal.Poblacion = "";
            //representanteLegal.Calle = "";
            //representanteLegal.Numero = "";
            //representanteLegal.Interior = "";
            //representanteLegal.Colonia = "";
            //representanteLegal.Sexo = "";

            //personas.RepLegal = new RepLegal[] { representanteLegal };
            ///*Termina Representante legal*/

            //DateTime now = DateTime.Today;
            //int edad = DateTime.Today.Year - InfoEmision.FechaNacimiento.Year;
            //contratante.Edad = edad.ToString();
            contratante.Edad = InfoEmision.Edad == 0 ? Utilidades.Utilidades.CalculaEdad(InfoEmision.DetalleUsuario.FECHANACIMIENTO).ToString() : InfoEmision.Edad.ToString();

            personas.Contratante = new SolicitudPersonasContratante[] { contratante };

            SolicitudPersonasAsegurado asegurado = new SolicitudPersonasAsegurado();

            if (InfoEmision.ConductorHabitual && InfoEmision.EsFlotilla)
            {
                asegurado.CodigoCliente = "";
                asegurado.Tipo = "";
                asegurado.Paterno = string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoPaterno) ? "" : QuitarAcentos(InfoEmision.DetalleUsuario.ApellidoPaterno.Trim());
                asegurado.Materno = string.IsNullOrEmpty(InfoEmision.DetalleUsuario.ApellidoMaterno) ? "" : QuitarAcentos(InfoEmision.DetalleUsuario.ApellidoMaterno.Trim());
                asegurado.Nombre = string.Format("{0} {1}", QuitarAcentos(InfoEmision.DetalleUsuario.Nombre.Trim()), (string.IsNullOrEmpty(InfoEmision.DetalleUsuario.NombreDos) ? "" : QuitarAcentos(InfoEmision.DetalleUsuario.NombreDos.Trim())));
                //asegurado.RFC = InfoEmision.EsFlotilla ? LocktonServicios.Utilidades.Utilidades.CalcularRFC(InfoEmision.DetalleUsuario.Nombre + " " + InfoEmision.DetalleUsuario.NombreDos, InfoEmision.DetalleUsuario.ApellidoPaterno, InfoEmision.DetalleUsuario.ApellidoMaterno, InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yy")) : InfoEmision.DatosUsuario.RFC;
                asegurado.RFC = InfoEmision.DatosUsuario.RFC;
                asegurado.Telefono = telefono;
                asegurado.Sexo = string.IsNullOrEmpty(xmlCotizacionSeleccionada.SelectNodes("Solicitud/Personas/Contratante/Sexo")[0].InnerText) ? InfoEmision.DetalleUsuario.GENERO : xmlCotizacionSeleccionada.SelectNodes("Solicitud/Personas/Contratante/Sexo")[0].InnerText;
                string RFC = InfoEmision.DatosUsuario.RFC.Substring(4, 6);
                asegurado.FecNac = DateTime.ParseExact(RFC.ToString(), "yyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString("dd/MM/yyyy");
                //asegurado.FecNac =   InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy");


                personas.Asegurado = new SolicitudPersonasAsegurado[] { asegurado };

            }
            else
            {

                asegurado.CodigoCliente = "";
                asegurado.Tipo = "";
                asegurado.Paterno = string.IsNullOrEmpty(InfoEmision.ApellidoPaterno) ? "" : QuitarAcentos(InfoEmision.ApellidoPaterno.Trim());
                asegurado.Materno = string.IsNullOrEmpty(InfoEmision.ApellidoMaterno) ? "" : QuitarAcentos(InfoEmision.ApellidoMaterno.Trim());
                asegurado.Nombre = string.Format("{0} {1}", QuitarAcentos(InfoEmision.PrimerNombre.Trim()), (string.IsNullOrEmpty(InfoEmision.SegundoNombre) ? "" : QuitarAcentos(InfoEmision.SegundoNombre.Trim())));
                asegurado.RFC = InfoEmision.DatosUsuario.RFC;
                // asegurado.RFC = string.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC)? InfoEmision.EsFlotilla? LocktonServicios.Utilidades.Utilidades.CalcularRFC(InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno, InfoEmision.FechaNacimiento.ToString("dd/MM/yy")) : InfoEmision.DatosUsuario.RFC:InfoEmision.DatosUsuario.RFC;
                asegurado.Telefono = telefono;
                asegurado.Sexo = string.IsNullOrEmpty(xmlCotizacionSeleccionada.SelectNodes("Solicitud/Personas/Contratante/Sexo")[0].InnerText) ? InfoEmision.DetalleUsuario.GENERO : xmlCotizacionSeleccionada.SelectNodes("Solicitud/Personas/Contratante/Sexo")[0].InnerText;
                string RFC = InfoEmision.DatosUsuario.RFC.Substring(4, 6);
                asegurado.FecNac = DateTime.ParseExact(RFC.ToString(), "yyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString("dd/MM/yyyy");  //  InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy");


                personas.Asegurado = new SolicitudPersonasAsegurado[] { asegurado };
            }


            //var coberturasPaquete = ObtenerCoberturas(InfoEmision.Convenio.Id, Convert.ToInt32(cotizacionDetalle.Paquete));

            SolicitudCoberturas coberturas = new SolicitudCoberturas();
            List<SolicitudCoberturasCobertura> listaCoberturas = new List<SolicitudCoberturasCobertura>();

            //string FormaIndemnizacion = "";
            var coberturaUtils = new Utilidades.CoberturasUtils();
            foreach (Coberturas paquete in coberturasPaquete)
            {
                bool aplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(InfoEmision.Convenio.Id, paquete.IdCobertura.ToString(), InfoEmision.CotizacionAutoGuardar.Agnio, paquete.IdCatRamo);
                bool EsCondEspecial = coberturaUtils.EsCondicionEsp(InfoEmision.Convenio.Id, paquete.IdCobertura.ToString(), paquete.IdCatRamo);

                if ((EsCondEspecial && aplicaCobertura) || !EsCondEspecial)
                {
                    SolicitudCoberturasCobertura coberAdd = new SolicitudCoberturasCobertura();

                    decimal SumaAsegurada = 0;

                    coberAdd.clave = paquete.Codigo.PadLeft(10, '0'); ;
                    coberAdd.sumaasegurada = string.IsNullOrEmpty(paquete.SumaAsegurada) ? "0" : paquete.SumaAsegurada.Replace(",", "");
                    coberAdd.deducible = string.IsNullOrEmpty(paquete.Deducible) ? paquete.Deducible : string.Format("{0:N2}", Convert.ToDecimal(paquete.Deducible));
                    decimal deducible = !string.IsNullOrEmpty(paquete.Deducible) ? Convert.ToDecimal(paquete.Deducible) * 100 : 0;
                    coberAdd.impresiondeducible = deducible != 0 ? string.Format("{0:N0}", deducible) + "%" : "";


                    if (decimal.TryParse(paquete.SumaAsegurada, out SumaAsegurada))
                    {
                        string a = paquete.Cobertura;
                        if (SumaAsegurada == 0 && a.Contains("AMPARADA"))
                        {
                            coberAdd.sumaasegurada = paquete.Cobertura.ToString().Trim();
                            coberAdd.impresionsa = paquete.Cobertura.ToString().Trim();
                            coberAdd.deducible = "";
                            coberAdd.impresiondeducible = "";
                        }
                        else
                        {
                            if (a.Contains("AMPARADA"))
                            {
                                coberAdd.impresionsa = paquete.Cobertura.ToString().Trim();
                                coberAdd.deducible = "";
                                coberAdd.impresiondeducible = "";
                            }
                            else
                            {
                                coberAdd.impresionsa = paquete.SumaAsegurada == "0" ? "" : string.Format("$" + Convert.ToDecimal(paquete.SumaAsegurada).ToString("#,##0.00"));
                            }

                        }

                    }

                    //if (paquete.Codigo.Contains("1289") || paquete.Codigo.Contains("1288") || paquete.Codigo.Contains("916"))
                    //{
                    //    coberAdd.sumaasegurada = InfoEmision.CotizacionAutoGuardar.MontoFactura.ToString();
                    //    if (string.IsNullOrEmpty(paquete.Cobertura))//descripcion
                    //        FormaIndemnizacion = paquete.Cobertura;

                    //}

                    listaCoberturas.Add(coberAdd);
                }

            }
            coberturas.Cobertura = listaCoberturas.ToArray();

            //                                         
            //auto.FormaIndemnizacion = FormaIndemnizacion;
            autos.Auto = new SolicitudAutosAuto[] { auto };
            //                                       
            List<Object> objList = new List<object>();

            objList.Add(general);
            objList.Add(autos);
            objList.Add(personas);
            objList.Add(coberturas);
            SolicitudCobranza cobranza = new SolicitudCobranza();
            SolicitudCobranza cobranzaNew = new SolicitudCobranza();

            List<Object> objListNew = new List<object>();

            objListNew.Add(general);
            objListNew.Add(autos);
            objListNew.Add(personas);
            objListNew.Add(coberturas);

            if (InfoEmision.EsFlotilla)
            {
                cobranza.CodSeg = InfoEmision.Tarjeta.Cvv;
                cobranza.Cuenta = "";
                cobranza.Banco = InfoEmision.IdBanco.ToString().PadLeft(4, '0');
                cobranza.Mes = InfoEmision.Tarjeta.MesVencimiento;
                cobranza.Ano = InfoEmision.Tarjeta.AnioVencimiento.ToString() == "1900" ? InfoEmision.IdAnio.ToString() : InfoEmision.Tarjeta.AnioVencimiento.ToString();
                cobranza.Tipotarjeta = InfoEmision.Tarjeta.TipoTarjeta;
                cobranza.Numero = InfoEmision.Tarjeta.NumeroTarjeta;
                objList.Add(cobranza);


                string num = InfoEmision.Tarjeta.NumeroTarjeta.Substring(InfoEmision.Tarjeta.NumeroTarjeta.Length - Math.Min(4, InfoEmision.Tarjeta.NumeroTarjeta.Length));
                cobranzaNew.CodSeg = new string('*', InfoEmision.Tarjeta.Cvv.Length);
                cobranzaNew.Mes = new string('*', InfoEmision.Tarjeta.MesVencimiento.Length);
                cobranzaNew.Ano = new string('*', 4);
                cobranzaNew.Banco = InfoEmision.IdBanco.ToString().PadLeft(4, '0');
                cobranzaNew.Tipotarjeta = new string('*', 14);
                cobranzaNew.Numero = new string('*', 12) + num;
                objListNew.Add(cobranzaNew);

            }

            Solicitud solucitudCotizaNew = new Solicitud();
            solucitudCotizaNew.Items = objListNew.ToArray();

            string XmlizedStringNew = new ABACHUBBService().ToXMLString<Solicitud>(solucitudCotizaNew);

            Solicitud solucitudCotiza = new Solicitud();
            solucitudCotiza.Items = objList.ToArray();

            string XmlizedString = new ABACHUBBService().ToXMLString<Solicitud>(solucitudCotiza);

            log.Info(string.Format("GNP Xml Emision Solicitud: {0}", XmlizedStringNew.Replace("\n", "").Replace("\r", "")));

            AutosCotizadorGNP.CotizadorGNPSoapClient cliente = new AutosCotizadorGNP.CotizadorGNPSoapClient();

            XmlNode node;
            string resultado;
            /*Inicia emisión de polizas*/
            if (InfoEmision.EsFlotilla)
            {
                node = cliente.Emitir(XmlizedString);
                resultado = node.OuterXml;
                //resultado = "<Emision><Agente><Clave>0050496001</Clave><NumOficina>0042</NumOficina></Agente><Asegurado><Nombre>JOSE GUADALUPE</Nombre><ApPaterno>ROMERO</ApPaterno><ApMaterno>PINA</ApMaterno><FechaNacimiento>20010717</FechaNacimiento><NumeroIdentificacion>9999999999</NumeroIdentificacion></Asegurado><Poliza><FecFinVigencia>17/7/2020</FecFinVigencia><FecInicioVigencia>17/7/2019</FecInicioVigencia><Numero>00000339746216</Numero><Caratula>00000253132021</Caratula><Contrato>59733</Contrato><ClaveRamo>24</ClaveRamo><CodigoCliente>0066753598</CodigoCliente><FechaEmision>20190717</FechaEmision></Poliza><Tarifa><ClavePaquete>0000000079</ClavePaquete><Coberturas><Cobertura><Clave>0000001288</Clave><Descripcion>Daños Materiales Pérdida Total</Descripcion><Suma_Asegurada>Valor Comercial</Suma_Asegurada><Deducible>0.05</Deducible><Prima>2795.8785</Prima></Cobertura><Cobertura><Clave>0000001289</Clave><Descripcion>Daños Materiales Pérdida Parcial</Descripcion><Suma_Asegurada>Valor Comercial</Suma_Asegurada><Deducible>0.05</Deducible><Prima>4381.79484375</Prima></Cobertura><Cobertura><Clave>0000000916</Clave><Descripcion>Robo Total</Descripcion><Suma_Asegurada>Valor Comercial</Suma_Asegurada><Deducible>0.10</Deducible><Prima>1883.1564675</Prima></Cobertura><Cobertura><Clave>0000000891</Clave><Descripcion>Cristales</Descripcion><Suma_Asegurada>0</Suma_Asegurada><Deducible>20%</Deducible><Prima>Amparada</Prima></Cobertura><Cobertura><Clave>0000001273</Clave><Descripcion>Responsabilidad Civil por Daños a Terceros</Descripcion><Suma_Asegurada>2000000</Suma_Asegurada><Deducible></Deducible><Prima>2480.9</Prima></Cobertura><Cobertura><Clave>0000001285</Clave><Descripcion>Protección Legal</Descripcion><Suma_Asegurada>0</Suma_Asegurada><Deducible></Deducible><Prima>380</Prima></Cobertura><Cobertura><Clave>0000000906</Clave><Descripcion>Gastos Médicos Ocupantes</Descripcion><Suma_Asegurada>400000</Suma_Asegurada><Deducible></Deducible><Prima>267.94</Prima></Cobertura><Cobertura><Clave>0000000904</Clave><Descripcion>Extensión Cobertura Resp. Civil</Descripcion><Suma_Asegurada>0</Suma_Asegurada><Deducible></Deducible><Prima>310.1125</Prima></Cobertura><Cobertura><Clave>0000001268</Clave><Descripcion>Club GNP Autos</Descripcion><Suma_Asegurada>0</Suma_Asegurada><Deducible></Deducible><Prima>Amparada</Prima></Cobertura><Cobertura><Clave>0000001452</Clave><Descripcion>Responsabilidad Civil por Fallecimiento</Descripcion><Suma_Asegurada>3000000</Suma_Asegurada><Deducible></Deducible><Prima>309.62</Prima></Cobertura></Coberturas><DerechoPoliza>550</DerechoPoliza><DescripcionPaquete /><IVA>$2,983.93</IVA><PrimaNeta>$18,099.58</PrimaNeta><PrimaTotal>$21,633.51</PrimaTotal><RecargoPagoFraccionado>$0.00</RecargoPagoFraccionado><PrimerPago>$21,633.50</PrimerPago><PagosSubsecuentes>$0.00</PagosSubsecuentes></Tarifa><Vehiculo><Armadora>AC</Armadora><Carroceria>08</Carroceria><ClaveMarca>AC0805</ClaveMarca><DescripcionVehiculo>ACURA ILX A SPEC L4 2.4 AUT</DescripcionVehiculo><EdoCirculacion>25</EdoCirculacion><IndicadorAltoRiesgo>N</IndicadorAltoRiesgo><Modelo>2016</Modelo><NumeroMotor>DEW234123</NumeroMotor><NumeroSerie>DEWE1233123123412</NumeroSerie><Placas>DEA2345</Placas><TipoVehiculo>AUT</TipoVehiculo><VersionVehiculo>05</VersionVehiculo></Vehiculo></Emision>";
                log.Info("Parse respuesta Emitir GNP-Flotillas Resultado: " + resultado.Replace("\n", "").Replace("\r", ""));
            }
            else
            {
                node = cliente.Cotizar(XmlizedString);
                resultado = node.OuterXml;
                log.Info("Parse respuesta Emitir GNP-Pooles Resultado: " + resultado.Replace("\n", "").Replace("\r", ""));
            }
            /*Termina emisión de polizas*/
            Poliza poliza = new Poliza();
            PolizaDetalle polizaDet = new PolizaDetalle();

            if (node.Name == "Errores")
            {
                if (InfoEmision.EsFlotilla)
                {
                    log.Error("emiteVehiculo error GNP-Flotilla: " + resultado.Replace("\n", "").Replace("\r", ""));
                }
                else
                {
                    log.Error("emiteVehiculo error GNP-Individual: " + resultado.Replace("\n", "").Replace("\r", ""));
                }
                //return new EmisionPoliza(false, XmlizedString, node.InnerText, null);
                return new EmisionPoliza(false, XmlizedStringNew, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde." + node.InnerText, null);
            }

            com.lockton.xml.gnp.emision.response.Emision resultadoEmision = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.emision.response.Emision>(resultado);

            Endoso endosoAlta = new Endoso();
            endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
            endosoAlta.Fecha = DateTime.Now;
            endosoAlta.ValorAnterior = "Alta";
            endosoAlta.ValorActual = "Contratación";

            List<Recibo> recibosGenerados = new List<Recibo>();
            decimal primaNeta = decimal.Parse(ObtenerPrimaNeta(resultado));
            decimal primaTotal = decimal.Parse(ObtenerTotalPagar(resultado));
            decimal derechos = ObtenerDerechoPoliza(resultado);
            decimal impuestos = ObtenerIVA(resultado);
            decimal recargo = ObtenerRecargoPagoFracc(resultado);
            decimal primerPago = ObtenerPrimerPago(resultado);
            decimal pagoSubsecuente = ObtenerPagosSubsecuentes(resultado);

            //cambia el nUMERO DE COTIZACION POR EL NUMERO DE LA SEGUNDA COTIZACION solo si es pool
            if (!InfoEmision.EsFlotilla)
            {
                InfoEmision.NoCotizacion = ObtenerNoCotizacion(resultado);
            }
            if (InfoEmision.EsFlotilla)
            {
                derechos = decimal.Parse(QuitaCaracteres(resultadoEmision.Tarifa.DerechoPoliza), CultureInfo.InvariantCulture);
                recargo = decimal.Parse(QuitaCaracteres(resultadoEmision.Tarifa.RecargoPagoFraccionado), CultureInfo.InvariantCulture);
                impuestos = decimal.Parse(QuitaCaracteres(resultadoEmision.Tarifa.IVA), CultureInfo.InvariantCulture);
                List<string> format = new List<string>();
                format.Add("dd/MM/yyyy");
                format.Add("yyyyMMdd");
                try
                {
                    FinVigencia = DateTime.ParseExact(resultadoEmision.Poliza.FecFinVigencia, format.ToArray(), CultureInfo.InvariantCulture, DateTimeStyles.None);
                    InicioVigencia = DateTime.ParseExact(resultadoEmision.Poliza.FecInicioVigencia, format.ToArray(), CultureInfo.InvariantCulture, DateTimeStyles.None);
                    poliza.NumeroPoliza = resultadoEmision.Poliza.Numero.TrimStart(new Char[] { '0' });// Util.polizaGNP(resultadoEmision.Poliza.Numero);

                    primaNeta = decimal.Parse(QuitaCaracteres(resultadoEmision.Tarifa.PrimaNeta), CultureInfo.InvariantCulture);
                    primaTotal = decimal.Parse(QuitaCaracteres(resultadoEmision.Tarifa.PrimaTotal), CultureInfo.InvariantCulture);
                }
                catch (Exception) { }
            }

            poliza.FinVigencia = FinVigencia;
            poliza.InicioVigencia = InicioVigencia;

            poliza.PrimaNeta = primaNeta;
            poliza.PrimaNetaAnualizada = primaNeta;
            poliza.PrimaTotal = primaTotal;
            poliza.PrimaTotalAnualizada = primaTotal;

            poliza.Motor = InfoEmision.NumeroMotor;
            poliza.Serie = InfoEmision.NumeroSerie;
            poliza.Placas = InfoEmision.Placas;
            poliza.FechaEmision = DateTime.Now;
            poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
            poliza.UrlPDFPoliza = "";
            poliza.UrlPDFRecibos = "";
            poliza.Estatus = 1;
            poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
            poliza.IdConvenio = InfoEmision.Convenio.Id;
            poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
            poliza.IdTipoCobertura = tipoPaquete.IdCatTipoPaquete;
            poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
            poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
            poliza.Acepto_DescuentoPoliza = true;

            polizaDet.Inciso = "1";
            polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para el flujo alterno de GNP.
            polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
            polizaDet.Deducible = 0;
            polizaDet.Comision = 0;
            polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
            polizaDet.MigraOPERA = false;
            polizaDet.UrlPDFPolizaOPERA = "";
            polizaDet.PolizaOPERA = 0;
            polizaDet.OTOpera = 0;
            polizaDet.EndosoOPERA = 0;
            polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
            polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;
            polizaDet.IdCatRamoVehiculo = cotizacionDetalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
            polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
            polizaDet.IdCatModalidadFormaPago = medioPago.Id;// db.CatModalidadFormaPago.Where(x => x.Clave.Equals(medioPago)).FirstOrDefault().Id;
            polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;// db.CatPeriodicidadFormaPago.Where(x => x.Clave.Equals(formaPago)).FirstOrDefault().Id;
            polizaDet.XMLRecepcion = resultado;
            polizaDet.XMLSolicitud = XmlizedString;
            polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;

            if (InfoEmision.EsFlotilla)
            {

                polizaDet.XMLSolicitud = XmlizedStringNew;
                int numeroRecibo = 1;
                if (resultadoEmision.Tarifa.ConjuntoRecibos != null && resultadoEmision.Tarifa.ConjuntoRecibos.Any())
                    try
                    {
                        foreach (com.lockton.xml.gnp.emision.response.EmisionTarifaConjuntoRecibosRecibo recibo in resultadoEmision.Tarifa.ConjuntoRecibos)
                        {
                            if (recibo.fechaEfecto.Length > 1)
                            {
                                Recibo reciboBusqueda = new Recibo();
                                reciboBusqueda = recibosGenerados.Where(b => b.InicioVigencia == DateTime.ParseExact(recibo.fechaEfecto, "yyyyMMdd", CultureInfo.InvariantCulture)).FirstOrDefault();

                                if (reciboBusqueda == null)
                                {
                                    for (int nR = 0; nR <= recibo.detalleRecibo.Count() - 1; nR++)
                                    {
                                        Recibo reciboSave = new Recibo();
                                        reciboSave.InicioVigencia = DateTime.ParseExact(recibo.detalleRecibo[nR].fechaEfecto, "yyyyMMdd", CultureInfo.InvariantCulture);
                                        reciboSave.FinVigencia = DateTime.ParseExact(recibo.detalleRecibo[nR].fechaVencimiento, "yyyyMMdd", CultureInfo.InvariantCulture);
                                        reciboSave.Numero = numeroRecibo;
                                        reciboSave.NoAsegurado = "1";
                                        reciboSave.PrimaTotal = decimal.Parse(recibo.detalleRecibo[0].importe, CultureInfo.InvariantCulture);
                                        reciboSave.PrimaNeta = decimal.Parse(recibo.totalRecibos, CultureInfo.InvariantCulture);
                                        reciboSave.Comision = convenioRamoPaquete.Comision >0? decimal.Parse(recibo.detalleRecibo[nR].totalComisiones, CultureInfo.InvariantCulture):0;
                                        reciboSave.Impuesto = 0;

                                        recibosGenerados.Add(reciboSave);
                                        numeroRecibo++;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception) { }
                else
                {
                    Recibo reciboSave = new Recibo();
                    reciboSave.InicioVigencia = InicioVigencia;
                    reciboSave.FinVigencia = FinVigencia;
                    reciboSave.Numero = 1;
                    reciboSave.NoAsegurado = "1";
                    reciboSave.PrimaNeta = primaNeta;
                    reciboSave.PrimaTotal = primaTotal;
                    reciboSave.Derecho = derechos;
                    reciboSave.Recargo = recargo;
                    reciboSave.Comision = 0;
                    reciboSave.Impuesto = impuestos;
                    recibosGenerados.Add(reciboSave);
                }



            }
            else
            {
                if (catPeriodicidad.Id == 1)
                {
                    Recibo reciboSave = new Recibo();
                    reciboSave.InicioVigencia = InicioVigencia;
                    reciboSave.FinVigencia = FinVigencia;
                    reciboSave.Numero = 1;
                    reciboSave.NoAsegurado = "1";
                    reciboSave.PrimaNeta = primaNeta;
                    reciboSave.PrimaTotal = primaTotal;
                    reciboSave.Derecho = derechos;
                    reciboSave.Recargo = recargo;
                    reciboSave.Comision = 0;
                    reciboSave.Impuesto = impuestos;
                    recibosGenerados.Add(reciboSave);
                }
                else
                {
                    int numTotalRecibos = 0;
                    switch (catPeriodicidad.Id)
                    {
                        case 2:
                            numTotalRecibos = 2;
                            break;
                        case 3:
                            numTotalRecibos = 4;
                            break;
                        case 4:
                            numTotalRecibos = 12;
                            break;
                        case 5:
                            numTotalRecibos = 24;
                            break;
                        case 6:
                            numTotalRecibos = 24;
                            break;
                    }

                    int daysDiff = ((InicioVigencia - FinVigencia).Days / numTotalRecibos) * -1;
                    DateTime inicio = DateTime.Now;
                    DateTime fin = InicioVigencia;
                    decimal d = 1.16M;

                    for (int i = 1; i <= numTotalRecibos; i++)
                    {
                        inicio = fin;
                        fin = fin.AddDays(daysDiff);

                        Recibo reciboSave = new Recibo();
                        reciboSave.InicioVigencia = inicio;
                        reciboSave.FinVigencia = fin;
                        reciboSave.Numero = i;
                        reciboSave.NoAsegurado = i.ToString();
                        reciboSave.Comision = 0;
                        reciboSave.Recargo = recargo / numTotalRecibos;

                        if (i == 1)
                        {
                            reciboSave.PrimaNeta = primerPago / d;
                            reciboSave.PrimaTotal = primerPago;
                            reciboSave.Derecho = derechos;
                            reciboSave.Impuesto = (primerPago - (primerPago / d));
                        }
                        else
                        {
                            reciboSave.PrimaNeta = pagoSubsecuente / d;
                            reciboSave.PrimaTotal = pagoSubsecuente;
                            reciboSave.Derecho = 0;
                            reciboSave.Impuesto = (pagoSubsecuente - (pagoSubsecuente / d));
                        }
                        recibosGenerados.Add(reciboSave);
                    }
                }
            }


            endosoAlta.Recibo = recibosGenerados;

            poliza.Endoso.Add(endosoAlta);
            poliza.PolizaDetalle.Add(polizaDet);
            db.Poliza.Add(poliza);
            db.SaveChanges();

            if (InfoEmision.EsFlotilla)
            {
                List<string> pdf = ReimprimePoliza(poliza.NumeroPoliza, "", poliza.ClaveAgente);
                poliza.UrlPDFPoliza = pdf.FirstOrDefault();
                poliza.UrlPDFRecibos = pdf.LastOrDefault();
            }

            Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

            return new EmisionPoliza(true, XmlizedStringNew, resultado, poliza);
        }

        public Comparar LeeXmlRespuesta(string XmlResultado, List<LocktonModel.db.PaqueteDetalle> coberturas, int IdTipoPaquete, string xmlEnvio, Convenio convenioCotiza, int numeroRecibos, int tipoVehiculo = 0, int idPaquteConvenio = 0)
        {
            Comparar infoCompara = new Comparar();

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            xmlCotizacionSeleccionada.LoadXml(xmlEnvio);
            try
            {
                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(XmlResultado);
                infoCompara.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                infoCompara.Aseguradora = "GNP";
                infoCompara.Cobertura = IdTipoPaquete.ToString();
                infoCompara.XmlEmision = xmlEnvio;
                infoCompara.XmlRespuesta = XmlResultado;
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;

                List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete);
                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {

                    infoCompara.Coberturas = new List<Coberturas>();
                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesCoberturas cobertura in paquete.Coberturas)
                    {

                        foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesCoberturasCobertura coberturaDet in cobertura.Cobertura)
                        {
                            Coberturas _coberturaPaquete = coberturasPaquete.FirstOrDefault(a => a.Nombre.ToUpper().Trim() == coberturaDet.Nombre.ToUpper().Trim());
                            if (_coberturaPaquete != null)
                            {
                                Coberturas cotCob = new Coberturas();
                                double deducible = 0.0;
                                cotCob.Cobertura = QuitaCaracteres(coberturaDet.Prima);
                                cotCob.SumaAsegurada = QuitaCaracteres(coberturaDet.Suma_Asegurada);
                                cotCob.Nombre = coberturaDet.Nombre;
                                if (!string.IsNullOrWhiteSpace(coberturaDet.Deducible))
                                {
                                    if (double.TryParse(coberturaDet.Deducible, out deducible))
                                    {
                                        cotCob.Deducible = string.IsNullOrWhiteSpace(coberturaDet.Deducible) ? "" : (Convert.ToDouble(coberturaDet.Deducible) * 100).ToString();
                                    }
                                    else
                                    {
                                        cotCob.Deducible = coberturaDet.Deducible.ToString();
                                    }

                                }

                                cotCob.Codigo = _coberturaPaquete.Codigo;
                                infoCompara.Coberturas.Add(cotCob);
                            }
                        }
                    }

                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        infoCompara.PrimaNeta = QuitaCaracteres(primasResultado.Totales[0].PrimaNeta);
                        infoCompara.PrimaTotal = QuitaCaracteres(primasResultado.Totales[0].TotalPagar);
                        infoCompara.PrimaAnualizada = QuitaCaracteres(primasResultado.Totales[0].PrimaAnualizada);
                        decimal primaanualizada = 0;
                        if (decimal.TryParse(infoCompara.PrimaAnualizada, out primaanualizada))
                            infoCompara.PrimaAnualizada = primaanualizada.ToString();
                        else
                            infoCompara.PrimaAnualizada = infoCompara.PrimaTotal;

                        infoCompara.Impuesto = QuitaCaracteres(primasResultado.Totales[0].IVA);
                        infoCompara.Recargo = QuitaCaracteres(primasResultado.Totales[0].RecargoPagoFracc);
                        infoCompara.Derecho = QuitaCaracteres(primasResultado.Totales[0].DerechoPoliza);

                        infoCompara.PrimerPago = QuitaCaracteres(primasResultado.Totales[0].PrimerPago);
                        infoCompara.SegundoPago = QuitaCaracteres(primasResultado.Totales[0].PagosSubsecuentes);

                        infoCompara.NumeroDePagos = NumeroPagos(Convert.ToDecimal(infoCompara.PrimaTotal)
                                , Convert.ToDecimal(infoCompara.PrimerPago)
                                , Convert.ToDecimal(infoCompara.SegundoPago)
                                , numeroRecibos);

                        infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;

                    }

                }


                infoCompara.FechaInicio = xmlCotizacionSeleccionada.SelectNodes("Solicitud/General/InicioVig")[0].InnerText;
                infoCompara.FechaFin = xmlCotizacionSeleccionada.SelectNodes("Solicitud/General/FinVig")[0].InnerText;
                infoCompara.Año = xmlCotizacionSeleccionada.SelectNodes("Solicitud/Autos/Auto/Modelo")[0].InnerText;


            }
            catch (Exception)
            {
                throw;
            }
            return infoCompara;
        }



        public string QuitarAcentos(string cadenaAcentuada)
        {
            byte[] tempBytes;
            tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(cadenaAcentuada);
            string asciiStr = System.Text.Encoding.UTF8.GetString(tempBytes);
            return asciiStr.Trim();
        }
        public string ObtenerNoCotizacion(string xmlEnvio)
        {
            com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(xmlEnvio);
            return resultadoCotizacion.General.Cotizacion.ToString();
        }
        public decimal ObtenerPagosSubsecuentes(string xmlRespuesta)
        {
            decimal PagosSubsecuentes = 0;
            try
            {
                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(xmlRespuesta);

                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {
                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        PagosSubsecuentes = Convert.ToDecimal(QuitaCaracteres(primasResultado.Totales[0].PagosSubsecuentes));
                    }
                }
            }
            catch (Exception) { }
            return PagosSubsecuentes;
        }
        public decimal ObtenerPrimerPago(string xmlRespuesta)
        {
            decimal primerPago = 0;
            try
            {
                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(xmlRespuesta);

                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {
                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        primerPago = Convert.ToDecimal(QuitaCaracteres(primasResultado.Totales[0].PrimerPago));
                    }
                }
            }
            catch (Exception) { }
            return primerPago;
        }
        public string ObtenerPrimaNeta(string xmlRespuesta)
        {
            string primerPago = "0.0";
            try
            {

                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(xmlRespuesta);

                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {
                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        primerPago = QuitaCaracteres(primasResultado.Totales[0].PrimaNeta);
                    }
                }
            }
            catch (Exception) { }
            return primerPago;
        }

        public string ObtenerTotalPagar(string xmlRespuesta)
        {
            string primerPago = "0.0";
            try
            {
                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(xmlRespuesta);

                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {
                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        primerPago = QuitaCaracteres(primasResultado.Totales[0].TotalPagar);
                    }
                }
            }
            catch (Exception) { }
            return primerPago;
        }
        public decimal ObtenerDerechoPoliza(string xmlRespuesta)
        {
            decimal primerPago = 0;
            try
            {
                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(xmlRespuesta);

                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {
                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        primerPago = Convert.ToDecimal(QuitaCaracteres(primasResultado.Totales[0].DerechoPoliza));
                    }
                }
            }
            catch (Exception) { }
            return primerPago;
        }
        public decimal ObtenerRecargoPagoFracc(string xmlRespuesta)
        {
            decimal primerPago = 0;
            try
            {

                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(xmlRespuesta);

                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {
                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        primerPago = Convert.ToDecimal(QuitaCaracteres(primasResultado.Totales[0].RecargoPagoFracc));
                    }
                }
            }
            catch (Exception) { }
            return primerPago;
        }
        public decimal ObtenerIVA(string xmlRespuesta)
        {
            decimal primerPago = 0;
            try
            {
                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion = Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(xmlRespuesta);

                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {
                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        primerPago = Convert.ToDecimal(QuitaCaracteres(primasResultado.Totales[0].IVA));
                    }
                }
            }
            catch (Exception) { }
            return primerPago;
        }
        public Comparar LeeXmlInformacion(string XmlResultado, string xmlEnvio, int numeroRecibos)
        {
            Comparar infoCompara = new Comparar();

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            xmlCotizacionSeleccionada.LoadXml(xmlEnvio);
            try
            {
                com.lockton.xml.gnp.cotizacion.response.Emision resultadoCotizacion =Utilidades.Utilidades.ToObject<com.lockton.xml.gnp.cotizacion.response.Emision>(XmlResultado);

                foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetes paquete in resultadoCotizacion.Paquetes)
                {

                    foreach (com.lockton.xml.gnp.cotizacion.response.EmisionPaquetesTotalesPaquetes primasResultado in paquete.TotalesPaquetes)
                    {
                        infoCompara.PrimaNeta = QuitaCaracteres(primasResultado.Totales[0].PrimaNeta);
                        infoCompara.PrimaTotal = QuitaCaracteres(primasResultado.Totales[0].TotalPagar);
                        infoCompara.Impuesto = QuitaCaracteres(primasResultado.Totales[0].IVA);
                        infoCompara.Recargo = QuitaCaracteres(primasResultado.Totales[0].RecargoPagoFracc);
                        infoCompara.Derecho = QuitaCaracteres(primasResultado.Totales[0].DerechoPoliza);

                        infoCompara.PrimerPago = QuitaCaracteres(primasResultado.Totales[0].PrimerPago);
                        infoCompara.SegundoPago = QuitaCaracteres(primasResultado.Totales[0].PagosSubsecuentes);

                        infoCompara.NumeroDePagos = NumeroPagos(Convert.ToDecimal(infoCompara.PrimaTotal)
                            , Convert.ToDecimal(infoCompara.PrimerPago)
                            , Convert.ToDecimal(infoCompara.SegundoPago)
                            , numeroRecibos);

                        infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;
                    }

                }


                infoCompara.FechaInicio = xmlCotizacionSeleccionada.SelectNodes("Solicitud/General/InicioVig")[0].InnerText;
                infoCompara.FechaFin = xmlCotizacionSeleccionada.SelectNodes("Solicitud/General/FinVig")[0].InnerText;
                infoCompara.Año = xmlCotizacionSeleccionada.SelectNodes("Solicitud/Autos/Auto/Modelo")[0].InnerText;


            }
            catch (Exception)
            {
                throw;
            }
            return infoCompara;
        }

        private int NumeroPagos(decimal primaTotal, decimal primerPago, decimal segundoPago, int mesesMaximos)
        {
            var numeropagos = 0;
            if (segundoPago == 0)
                numeropagos = 1;
            else
            {
                decimal faltante = primaTotal - primerPago;
                decimal pagos = 0;
                for (int i = 1; i <= mesesMaximos; i++)
                {
                    pagos += segundoPago;
                    if (Math.Round(pagos, 0) == Math.Round(faltante, 0))
                    {
                        numeropagos = i + 1;
                        break;
                    }
                }
            }

            return numeropagos;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="toDeserialize"></param>
        /// <returns></returns>
       

      

        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            bool UrlDisponible = false;
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"Repositorio\Documentos\GNP\" + NumeroPoliza + ".pdf";
            bool Exists = File.Exists(filePath);
            if (!Exists)
            {
                StringBuilder xmlImpresionInfo = new StringBuilder();
                ImpresionGNP.RenovacionesSoapClient Impresion = new ImpresionGNP.RenovacionesSoapClient();
                Poliza poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == NumeroPoliza);
                string User = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("UsrGNP")).Valor;
                string Password = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("PwdGNP")).Valor;
                string userAgente = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_UsuarioAgente_Reimpresion")).Valor;
                string claveAgente = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_ClaveAgente_Reimpresion")).Valor;
                string userRecibos = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_Usuario_Recibos")).Valor;
                string passRecibos = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_Password_Reimpresion")).Valor;

                xmlImpresionInfo.Append("<ImpresionINFO>");
                xmlImpresionInfo.Append(string.Format("<Usuario>{0}</Usuario>", User));
                xmlImpresionInfo.Append(string.Format("<Password>{0}</Password>", Password));
                xmlImpresionInfo.Append(string.Format("<UsuarioAgente>{0}</UsuarioAgente>", userAgente));
                xmlImpresionInfo.Append(string.Format("<ClaveAgente>{0}</ClaveAgente>", passRecibos));
                xmlImpresionInfo.Append(string.Format("<Intermediario>{0}</Intermediario>", ClaveAgente));
                xmlImpresionInfo.Append(string.Format("<numeroPoliza>00000{0}</numeroPoliza>", NumeroPoliza));
                xmlImpresionInfo.Append("<versionPoliza>0</versionPoliza>");
                xmlImpresionInfo.Append("</ImpresionINFO>");

                XmlNode renovacion = Impresion.ImpresionINFO(xmlImpresionInfo.ToString());

                XElement polizas = XElement.Parse(string.Format("<recibos>{0}</recibos>", renovacion.InnerXml));
                if (poliza == null)
                {
                    List<string> resultCore = new List<string>();
                    string urlPoliza = "";
                    foreach (XElement pol in polizas.Descendants("URLArchivo"))
                    {

                        urlPoliza = pol.Value;// Replace("http://gnpventamasiva.com.mx", "http://web1.gnpventamasiva.com.mx").ToString();
                    }

                    UrlDisponible = Utilidades.Utilidades.VerificarUrlRemotas(urlPoliza);
                    if (UrlDisponible)
                    {
                        using (WebClient client = new WebClient())
                        {
                            client.DownloadFile(urlPoliza, filePath);
                        }
                    }
                    Exists = File.Exists(filePath);

                    resultCore.Add((!Exists) ? "" : filePath);

                    return resultCore;

                }
                else
                {

                    //Invocamos el WS que libera la poliza emitida del lado de GNP sin importar que genere una excepción
                    RecibosGNP.WSImpresionRecibosImplClient Recibos = new RecibosGNP.WSImpresionRecibosImplClient();
                    foreach (XElement pol in polizas.Descendants("URLArchivo"))
                    {

                        poliza.UrlPDFPoliza = pol.Value; //Replace("http://gnpventamasiva.com.mx", "http://web1.gnpventamasiva.com.mx").ToString();
                    }
                    UrlDisponible = Utilidades.Utilidades.VerificarUrlRemotas(poliza.UrlPDFPoliza);
                    if (UrlDisponible)
                    {
                        using (WebClient client = new WebClient())
                        {
                            client.DownloadFile(poliza.UrlPDFPoliza, filePath);
                        }
                    }
                    Exists = File.Exists(filePath);

                    RecibosGNP.ReqConsultaRecibosPol polizaEmitida = new RecibosGNP.ReqConsultaRecibosPol()

                    {
                        usr = userRecibos,
                        pwd = passRecibos,
                        verPol = "0",
                        tipoAttch = "MIME",
                        incPDF = "S",
                        cdInterm = ClaveAgente,
                        numPol = string.Format("00000{0}", NumeroPoliza)
                    };

                    try
                    {
                        RecibosGNP.RespConsultaRecibosPol res = Recibos.consultarRecibos(polizaEmitida);
                    }
                    catch (Exception) { }
                    StringBuilder xmlComerciales = new StringBuilder();
                    xmlComerciales.Append("<ConsultaRecibos>");
                    xmlComerciales.Append(string.Format("<Usuario>{0}</Usuario>", User));
                    xmlComerciales.Append(string.Format("<Password>{0}</Password>", Password));
                    xmlComerciales.Append(string.Format("<usuarioAgente>{0}</usuarioAgente>", userRecibos));
                    xmlComerciales.Append(string.Format("<claveAgente>{0}</claveAgente>", passRecibos));
                    xmlComerciales.Append(string.Format("<intermediario>{0}</intermediario>", ClaveAgente));
                    xmlComerciales.Append(string.Format("<numeroPoliza>00000{0}</numeroPoliza>", NumeroPoliza));
                    xmlComerciales.Append("<versionPoliza>0</versionPoliza>");
                    xmlComerciales.Append("</ConsultaRecibos>");

                    ComercialesGNP.WSComercialesSoapClient wsComerciales = new ComercialesGNP.WSComercialesSoapClient();
                    XmlNode xmlUrlRecibo = wsComerciales.impresionRecibos(xmlComerciales.ToString());
                    XElement recibos = XElement.Parse(string.Format("<recibos>{0}</recibos>", xmlUrlRecibo.InnerXml));

                    foreach (XElement recibo in recibos.Descendants("URLArchivo"))
                    {
                        poliza.UrlPDFRecibos = string.IsNullOrEmpty(recibo.Value) ? "" : recibo.Value;
                    }
                    db.SaveChanges();

                    List<string> result = new List<string>();
                    //result.Add(string.IsNullOrEmpty(poliza.UrlPDFPoliza) ? "" : poliza.UrlPDFPoliza);
                    result.Add((!Exists) ? "" : filePath);
                    result.Add(string.IsNullOrEmpty(poliza.UrlPDFRecibos) ? "" : poliza.UrlPDFRecibos);
                    return result;
                }

            }
            else
            {
                List<string> result = new List<string>();
                result.Add(filePath);
                return result;
            }
        }

        public List<string> ReimprimePoliza(string NumeroPoliza, int IdPoliza, string ClaveAgente, int Endoso = 0, int Inciso = 0)
        {
            StringBuilder xmlImpresionInfo = new StringBuilder();
            ImpresionGNP.RenovacionesSoapClient Impresion = new ImpresionGNP.RenovacionesSoapClient();
            Poliza poliza = db.Poliza.FirstOrDefault(a => a.Id == IdPoliza);
            string User = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("UsrGNP")).Valor;
            string Password = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("PwdGNP")).Valor;
            string userAgente = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_UsuarioAgente_Reimpresion")).Valor;
            string claveAgente = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_ClaveAgente_Reimpresion")).Valor;
            string userRecibos = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_Usuario_Recibos")).Valor;
            string passRecibos = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_Password_Reimpresion")).Valor;

            xmlImpresionInfo.Append("<ImpresionINFO>");
            xmlImpresionInfo.Append(string.Format("<Usuario>{0}</Usuario>", User));
            xmlImpresionInfo.Append(string.Format("<Password>{0}</Password>", Password));
            xmlImpresionInfo.Append(string.Format("<UsuarioAgente>{0}</UsuarioAgente>", userAgente));
            xmlImpresionInfo.Append(string.Format("<ClaveAgente>{0}</ClaveAgente>", claveAgente));
            xmlImpresionInfo.Append(string.Format("<Intermediario>{0}</Intermediario>", ClaveAgente));
            xmlImpresionInfo.Append(string.Format("<numeroPoliza>00000{0}</numeroPoliza>", NumeroPoliza));
            xmlImpresionInfo.Append("<versionPoliza>0</versionPoliza>");
            xmlImpresionInfo.Append("</ImpresionINFO>");

            XmlNode renovacion = Impresion.ImpresionINFO(xmlImpresionInfo.ToString());

            XElement polizas = XElement.Parse(string.Format("<recibos>{0}</recibos>", renovacion.InnerXml));

            foreach (XElement pol in polizas.Descendants("URLArchivo"))
            {
                poliza.UrlPDFPoliza = pol.Value;//.Replace("http://gnpventamasiva.com.mx", "http://web1.gnpventamasiva.com.mx");
            }

            //Invocamos el WS que libera la poliza emitida del lado de GNP sin importar que genere una excepción
            RecibosGNP.WSImpresionRecibosImplClient Recibos = new RecibosGNP.WSImpresionRecibosImplClient();

            RecibosGNP.ReqConsultaRecibosPol polizaEmitida = new RecibosGNP.ReqConsultaRecibosPol()

            {
                usr = userRecibos,
                pwd = passRecibos,
                verPol = "0",
                tipoAttch = "MIME",
                incPDF = "S",
                cdInterm = ClaveAgente,
                numPol = string.Format("00000{0}", NumeroPoliza)
            };

            try
            {
                RecibosGNP.RespConsultaRecibosPol res = Recibos.consultarRecibos(polizaEmitida);
            }
            catch (Exception) { }
            StringBuilder xmlComerciales = new StringBuilder();
            xmlComerciales.Append("<ConsultaRecibos>");
            xmlComerciales.Append(string.Format("<Usuario>{0}</Usuario>", User));
            xmlComerciales.Append(string.Format("<Password>{0}</Password>", Password));
            xmlComerciales.Append(string.Format("<usuarioAgente>{0}</usuarioAgente>", userRecibos));
            xmlComerciales.Append(string.Format("<claveAgente>{0}</claveAgente>", passRecibos));
            xmlComerciales.Append(string.Format("<intermediario>{0}</intermediario>", ClaveAgente));
            xmlComerciales.Append(string.Format("<numeroPoliza>00000{0}</numeroPoliza>", NumeroPoliza));
            xmlComerciales.Append("<versionPoliza>0</versionPoliza>");
            xmlComerciales.Append("</ConsultaRecibos>");

            ComercialesGNP.WSComercialesSoapClient wsComerciales = new ComercialesGNP.WSComercialesSoapClient();
            XmlNode xmlUrlRecibo = wsComerciales.impresionRecibos(xmlComerciales.ToString());
            XElement recibos = XElement.Parse(string.Format("<recibos>{0}</recibos>", xmlUrlRecibo.InnerXml));

            foreach (XElement recibo in recibos.Descendants("URLArchivo"))
            {
                poliza.UrlPDFRecibos = string.IsNullOrEmpty(recibo.Value) ? "" : recibo.Value;
            }
            db.SaveChanges();
            return new List<string>();
        }

        private string ObtenerCodigoCobertura(string nombre)
        {
            string clave = "";
            Cobertura cobertura = db.Cobertura.FirstOrDefault(a => a.Descripcion.Replace("\r\n", "").ToUpper().Trim() == nombre.ToUpper().Trim());
            if (cobertura != null)
                clave = cobertura.Clave.Replace("\r\n", "");
            return clave;
        }

        public List<Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete)
        {
            //List<SolicitudCoberturasCobertura> coberturas = new List<SolicitudCoberturasCobertura>();

            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio && a.IdCatTipoPaquete == idPaquete
                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible / 100).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", ""),
                                               IdCatRamo = c.IdCatRamoVehiculo,
                                               IdCobertura = b.Id,
                                               IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1

                                           }).ToList();
            return coberturas;
        }

        private string QuitaCaracteres(string numero)
        {
            return numero.Replace(",", "").Replace("$", "");
        }

        private string ObtenerClaveEstado(string codigoPosta)
        {
            CodigoPostal cp = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == codigoPosta);
            CatEstadosRepublica estado = db.CatEstadosRepublica.FirstOrDefault(a => a.Id == cp.IdEstado);
            return estado == null ? string.Empty : estado.Clave;
        }
        private string ConsultaPoblacionGNP(string CPostal)
        {
            string Poblacion = "";
            string User = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("UsrGNP")).Valor;
            string Password = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("PwdGNP")).Valor;

            try
            {

                ComercialesGNP.WSComercialesSoapClient comerciales = new ComercialesGNP.WSComercialesSoapClient();
                AutosCotizadorGNP.CotizadorGNPSoapClient cotizador = new AutosCotizadorGNP.CotizadorGNPSoapClient();
                XmlNode Municipio = cotizador.ObtenerCatalogo(("<SolicitudCatalogo><Catalogo><Usuario>" + User + "</Usuario><Password>" + Password + "</Password><Tipo>codigop" + "ostal</Tipo><Parametro1>" + (CPostal + "</Parametro1><Parametro2>estado</Parametro2></Catalogo></SolicitudCatalogo>")));
                string Municipios = Municipio.OuterXml;
                XmlDocument objXmlDocumentMun = new XmlDocument();
                XmlNodeList colElmentosMun;
                objXmlDocumentMun.LoadXml(Municipios);
                colElmentosMun = objXmlDocumentMun.GetElementsByTagName("Elemento");
                foreach (XmlNode Mun in colElmentosMun)
                {
                    Poblacion = Mun["Valor"].InnerText;
                }

                CatEstadosGNP estado = db.CatEstadosGNP.FirstOrDefault(a => a.Edo == Poblacion);
                Poblacion = estado.Id;

            }
            catch (Exception)
            {
            }
            return Poblacion;

        }

     

        private int ObtieneIdRamoVehiculo(int idCatRamoVehiculo)
        {
            int iDCatUsoVehiculo = db.CatUsoVehiculo.FirstOrDefault(cuv => cuv.Clave == idCatRamoVehiculo.ToString() && cuv.Estatus == 1).Id == 0 ? 1 : db.CatUsoVehiculo.FirstOrDefault(cuv => cuv.Clave == idCatRamoVehiculo.ToString() && cuv.Estatus == 1).Id;
            return iDCatUsoVehiculo;
        }

       

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
    }



}
