﻿using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonModel.xmls.AXA;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.Utilidades;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml;

namespace LocktonServicios.Aseguradoras
{
    public class MAPFRE : IOperacionesAseguradoras
    {
        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger("MAPFRE");
       

        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("dd/MM/yyyy");
                string MAPFRE_TOKEN = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_TOKEN")).FirstOrDefault().Valor;
                XmlDocument xmlCotizacionSeleccionada = new XmlDocument();

                xmlCotizacionSeleccionada.LoadXml(xmlEmision);
                xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_POLIZA")[0].Attributes["FEC_EFEC_POLIZA"].Value = date;

                var service = new wsMapfre.CatalogosAutosSoapClient();
                var response = service.WS_TW_ACotiza(xmlCotizacionSeleccionada.InnerXml, MAPFRE_TOKEN);
                Mapfre.Entidades.CotizacionResponse cotizacionResponse = MapCotizacion(response.OuterXml);


                resultado.XMLSolicitud = xmlCotizacionSeleccionada.InnerXml;
                resultado.XMLRecepcion = response.OuterXml;

                if (!cotizacionResponse.xml.param.result)
                {
                    throw new Exception(cotizacionResponse.xml.param.error);
                }

                return resultado;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<LocktonModel.db.PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {
            Mapfre.Entidades.CotizacionRequest cotizacion = new Mapfre.Entidades.CotizacionRequest();
            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
            var error = "";
            string Cp = "";
            try
            {

                ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();

                error = "No se encontró la clave en la aseguradora unica";
                string Ramo_Vehiculo = string.Empty;
                if (CotizacionCompara.TipoVehiculo == "1")
                    Ramo_Vehiculo = "401";
                if (CotizacionCompara.TipoVehiculo == "2")
                    Ramo_Vehiculo = "405";
                if (CotizacionCompara.TipoVehiculo == "3")
                    Ramo_Vehiculo = "403";
                var datosVehiculo = ObtenerDatosVehiculo(cot.Catalogo[0].CatDescripciones[0].clave);
                error = "";
                Cp = ConveniosPaquetes.Empresa.Direccion.CodigoPostal;
                if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 2 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 6 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5)
                {
                    Cp = CotizacionCompara.CodigoPostal;
                }
                if (convenioCotiza.ZonaCirculacion == 2)
                    Cp = convenioCotiza.CodigoPostal.ToString();
                CotizacionCompara.CodigoPostal = Cp.PadLeft(5, '0');

                var coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, cot.Catalogo[0].CatDescripciones[0].clave, Convert.ToInt32(CotizacionCompara.Año), ConfigEmpresa.IdEmpresa, Convert.ToInt32(CotizacionCompara.TipoVehiculo), EsMoto: CotizacionCompara.TipoVehiculo == "3" ? true : false);
                var idEstado = ObtenerCodigoEstado(CotizacionCompara.CodigoPostal);
                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioCotiza.Id && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
                var codigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == CotizacionCompara.CodigoPostal);
                if (string.IsNullOrEmpty(CotizacionCompara.NombreTipoVehiculo))
                    CotizacionCompara.NombreTipoVehiculo = CotizacionCompara.TipoVehiculo == "1" ? "AUTO (PARTICULAR)" : CotizacionCompara.TipoVehiculo == "2" ? "PICK UP (PARTICULAR)" : CotizacionCompara.TipoVehiculo == "3" ? "MOTO (PARTICULAR)" : "AUTO (PARTICULAR)";
                var _COD_PROV = ObtenerCodigoProvincia(idEstado, codigoPostal.Municipio, CotizacionCompara.NombreTipoVehiculo);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                var valorComercial10 = coberturasPaquete.Exists(a => a.Item1.Cobertura.Trim() == "VALOR COMERCIAL + 10%");
                var descuento = ConveniosPaquetes.ConvenioRamoPaquetes.FirstOrDefault(x => x.IdConvenio == paqueteConvenio.IdConvenio && x.IdCatRamoVehiculo == Convert.ToInt32(CotizacionCompara.TipoVehiculo)).Descuento;
                var _perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == CotizacionCompara.FormadePago).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == _perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);

                string MAPFRE_TOKEN = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_TOKEN")).FirstOrDefault().Valor;// "d0c95921-186d-4ae5-a563-deab50d1f158";//
                string MAPFRE_ID_NEGOCIO = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_ID_NEGOCIO")).FirstOrDefault().Valor;
                //string MAPFRE_NUM_POLIZA_GRUPO = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_NUM_POLIZA_GRUPO")).FirstOrDefault().Valor;
                string MAPFRE_COD_USR = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_COD_USR")).FirstOrDefault().Valor;

                //para si es flotilla verificar fechas
                DateTime FechaInicio = DateTime.Now;
                DateTime FechaTermino = DateTime.Now.AddYears(1);

                if (ConveniosPaquetes.configuracionEmpresa.AplicaFechaCotizacion)
                {
                    FechaInicio = CotizacionCompara.FechaCotizacion;
                    FechaTermino = CotizacionCompara.FechaCotizacion.AddYears(1);
                }
                //obtener la fecha de inicio y fin de la configuracion
                if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 1
                    || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 4
                    || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5)//flotilla
                {
                    //verifica las fechas de inicio
                    if (Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, FechaInicio))
                    {//busca si existe fecha de enrollment
                        FechaInicio = ConveniosPaquetes.Convenios[0].InicioVigencia;
                    }
                    FechaTermino = ConveniosPaquetes.Convenios[0].FinVigencia;

                }

                //prueba
                //var _COD_PROV =  ObtenerCodigoProvincia("9", "COYOACAN");

                if (ConveniosPaquetes.configuracionEmpresa.AplicaMultiAnual)
                {
                    //LocktonModel.db.CatPeriodicidadFormaPago catperdioricidad = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == perioricidad.IdCatPeriodicidadFormaPago);
                    //if (catperdioricidad != null)
                    //    FechaTermino = FechaInicio.AddYears(catperdioricidad.ValorMultiAnual);


                    if (CotizacionCompara.IdCatPeriodicidadMultianual > 0)
                    {
                        var idCatPeriodicidadMultianual = CotizacionCompara.IdCatPeriodicidadMultianual;
                        var multianual = db.PeriodicidadMultianual.FirstOrDefault(a => a.IdCatPeriodicidadMultianual == idCatPeriodicidadMultianual && a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago);
                        //if (multianual != null)
                        //    datosGenerales.FP = multianual.FormaPago;
                    }

                }

                string InicioVigencia = FechaInicio.ToString("dd/MM/yyyy");
                string FinVigencia = FechaTermino.ToString("dd/MM/yyyy");

                //if (ConfigEmpresa.IdTipoDeNegocio == 2)
                //{
                //    InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy") : DateTime.Now.ToString("dd/MM/yyyy");
                //    FinVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.AddYears(1).ToString("dd/MM/yyyy") : DateTime.Now.AddYears(1).ToString("dd/MM/yyyy");
                //}
                //else
                //{
                //    if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, DateTime.Now))
                //    {
                //        InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy") : DateTime.Now.ToString("dd/MM/yyyy");
                //    }
                //}

                cotizacion.User = convenioCotiza.Usuario;
                cotizacion.PWD = convenioCotiza.Contrasena;
                cotizacion.DATOS_POLIZA.ID_NEGOCIO = convenioCotiza.NumeroNegocio;// MAPFRE_ID_NEGOCIO;
                cotizacion.DATOS_POLIZA.NUM_POLIZA_GRUPO = convenioCotiza.NumeroPolizaGrupo;// MAPFRE_NUM_POLIZA_GRUPO;
                cotizacion.DATOS_POLIZA.NUM_CONTRATO = convenioCotiza.CodigoPromocion;
                cotizacion.DATOS_POLIZA.COD_SECTOR = "4";
                cotizacion.DATOS_POLIZA.COD_RAMO = Ramo_Vehiculo;
                cotizacion.DATOS_POLIZA.FEC_EFEC_POLIZA = InicioVigencia;
                cotizacion.DATOS_POLIZA.FEC_VCTO_POLIZA = FinVigencia;
                cotizacion.DATOS_POLIZA.COD_FRACC_PAGO = perioricidad.FormaPago;
                cotizacion.DATOS_POLIZA.COD_CUADRO_COM = convenioCotiza.CuadroComision;
                cotizacion.DATOS_POLIZA.COD_AGT = convenioCotiza.UsuarioAgente.Trim();
                cotizacion.DATOS_POLIZA.COD_USR = MAPFRE_COD_USR;
                cotizacion.DATOS_POLIZA.COD_NIVEL3_CAPTURA = "0";
                cotizacion.DATOS_POLIZA.TIP_DOCUM = "RFC";
                cotizacion.DATOS_POLIZA.COD_DOCUM = "PRUEBA";
                cotizacion.DATOS_POLIZA.COD_ESTADO = idEstado;
                cotizacion.DATOS_POLIZA.COD_PROV = _COD_PROV;
                cotizacion.DATOS_POLIZA.PCT_AGT = "100";
                cotizacion.DATOS_POLIZA.COD_GESTOR = convenioCotiza.UsuarioAgente.Trim();
                cotizacion.DATOS_POLIZA.TIP_GESTOR = "AG";

                cotizacion.DATOS_VARIABLES.NUM_RIESGO = "1";
                cotizacion.DATOS_VARIABLES.TIP_NIVEL = "3";
                cotizacion.DATOS_VARIABLES.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { COD_CAMPO = "COD_MATERIA", VAL_CAMPO = "1" });

                cotizacion.DATOS_VARIABLES19.NUM_RIESGO = "1";
                cotizacion.DATOS_VARIABLES19.TIP_NIVEL = "2";
                cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "9", COD_CAMPO = "COD_MODALIDAD", VAL_CAMPO = "40999" });
                cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "11", COD_CAMPO = "ANIO_FABRICA", VAL_CAMPO = CotizacionCompara.Año });
                cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "12", COD_CAMPO = "COD_MARCA", VAL_CAMPO = datosVehiculo.IdMarca });
                cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "13", COD_CAMPO = "COD_MODELO", VAL_CAMPO = datosVehiculo.IdModelo });
                cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "14", COD_CAMPO = "COD_TIP_VEHI", VAL_CAMPO = datosVehiculo.IdTipoVehiculo });
                cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "15", COD_CAMPO = "COD_USO_VEHI", VAL_CAMPO = "401" });
                if (CotizacionCompara.ValorFactura)
                {
                    var montoFactura = CotizacionCompara.MontoFactura.ToString();
                    if (montoFactura.Contains('.'))
                        montoFactura = montoFactura.Substring(0, montoFactura.IndexOf('.'));

                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "16", COD_CAMPO = "MCA_FACTURA", VAL_CAMPO = "S" });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "17", COD_CAMPO = "MCA_ACTUAL", VAL_CAMPO = "N" });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "18", COD_CAMPO = "MCA_COMERCIAL", VAL_CAMPO = "N" });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "45", COD_CAMPO = "FEC_FACTURA", VAL_CAMPO = CotizacionCompara.FechaFactura.ToString("ddMMyyyy") });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "46", COD_CAMPO = "NUM_FACTURA", VAL_CAMPO = CotizacionCompara.NumeroFactura });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "47", COD_CAMPO = "VAL_FACTURA", VAL_CAMPO = montoFactura });
                }
                else
                {
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "16", COD_CAMPO = "MCA_FACTURA", VAL_CAMPO = "N" });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "17", COD_CAMPO = "MCA_ACTUAL", VAL_CAMPO = "N" });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "18", COD_CAMPO = "MCA_COMERCIAL", VAL_CAMPO = valorComercial10 ? "N" : "S" });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "45", COD_CAMPO = "FEC_FACTURA", VAL_CAMPO = "" });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "46", COD_CAMPO = "NUM_FACTURA", VAL_CAMPO = "" });
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "47", COD_CAMPO = "VAL_FACTURA", VAL_CAMPO = "" });
                }
                if (valorComercial10)
                    cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "56", COD_CAMPO = "MCA_COMERCIAL10", VAL_CAMPO = CotizacionCompara.ValorFactura ? "N" : "S" });

                cotizacion.DATOS_VARIABLES19.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "68", COD_CAMPO = "NUM_SERIE", VAL_CAMPO = "XXXX" });

                cotizacion.DATOS_VARIABLES22.NUM_RIESGO = "0";
                cotizacion.DATOS_VARIABLES22.TIP_NIVEL = "1";
                cotizacion.DATOS_VARIABLES22.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "19", COD_CAMPO = "COD_BONI_RECA", VAL_CAMPO = "999" });
                cotizacion.DATOS_VARIABLES22.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "21", COD_CAMPO = "PCT_COD_REC_ESP", VAL_CAMPO = descuento.ToString("N0") == "0" ? "0" : "-" + descuento.ToString() });

                CoberturasUtils utils = new CoberturasUtils();
                foreach (var item in coberturasPaquete)
                {
                    bool EsCondEspecial = utils.EsCondicionEsp(convenioCotiza.Id, item.Item1.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                    var aplicaCondicionEspecial = utils.AplicaCoberturaEspecial(convenioCotiza.Id, item.Item1.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);

                    if (EsCondEspecial && !aplicaCondicionEspecial && item.Item1.Codigo == "4022")
                    {
                        aplicaCondicionEspecial = true;
                        item.Item1.SumaAsegurada = "0";
                    }

                    if ((EsCondEspecial && aplicaCondicionEspecial) || !EsCondEspecial)
                        switch (item.Item1.Cobertura.Trim())
                        {
                            case "VALOR COMERCIAL + 10%":
                                {
                                    if ((item.Item1.Codigo == "4000" || item.Item1.Codigo == "4001") && CotizacionCompara.ValorFactura)
                                        cotizacion.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = "F", COD_FRANQUICIA = Convert.ToInt32(Convert.ToDouble(item.Item1.Deducible) * 100).ToString() });
                                    else
                                        cotizacion.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = "C10", COD_FRANQUICIA = Convert.ToInt32(Convert.ToDouble(item.Item1.Deducible) * 100).ToString() });
                                }
                                break;
                            case "VALOR COMERCIAL":
                                {
                                    if ((item.Item1.Codigo == "4000" || item.Item1.Codigo == "4001") && CotizacionCompara.ValorFactura)
                                        cotizacion.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = "F", COD_FRANQUICIA = Convert.ToInt32(Convert.ToDouble(item.Item1.Deducible) * 100).ToString() });
                                    else
                                        cotizacion.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = "C", COD_FRANQUICIA = Convert.ToInt32(Convert.ToDouble(item.Item1.Deducible) * 100).ToString() });
                                }
                                break;
                            case "":
                                if (item.Item1.Codigo == "4000" || item.Item1.Codigo == "4001")
                                    cotizacion.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = item.Item1.SumaAsegurada, COD_FRANQUICIA = "0" });
                                else
                                    cotizacion.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = item.Item1.SumaAsegurada });
                                break;
                            case "VALOR CONVENIDO":
                            case "AMPARADA":
                            case "POR EVENTO":
                                {
                                    cotizacion.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = item.Item1.SumaAsegurada });
                                }
                                break;
                        }

                }

                #region DATOS_CH_TMV57

                var _aplicaDatos = db.MAPFRE_Nodo_Empresa.FirstOrDefault(a => a.IdEmpresa == convenioCotiza.IdEmpresa && a.Clave == "DATOS_CH_TMV");
                cotizacion.Nodo_DATOS_CH_TMV57 = _aplicaDatos != null;

                if (cotizacion.Nodo_DATOS_CH_TMV57)
                {

                    cotizacion.DATOS_CH_TMV57.Add(Campo("58", "MCA_SEXO", CotizacionCompara.Genero.ToLower().Trim() == "masculino" ? "1" : "0"));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("59", "COD_ESTADO", idEstado));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("60", "COD_PROV", _COD_PROV));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("61", "FEC_NACIMIENTO", string.IsNullOrEmpty(Convert.ToString(CotizacionCompara.FechaNacimiento)) ? detalleUsuario.FECHANACIMIENTO.ToString("ddMMyyyy") : Convert.ToDateTime(CotizacionCompara.FechaNacimiento).ToString("ddMMyyyy")));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("62", "COD_POSTAL", CotizacionCompara.CodigoPostal));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("63", "RFC", ""));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("64", "NOM_TERCERO", ""));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("65", "APE1_TERCERO", ""));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("66", "APE2_TERCERO", ""));
                    cotizacion.DATOS_CH_TMV57.Add(Campo("69", "MCA_FISICA", "S"));
                }
                #endregion

                var service = new wsMapfre.CatalogosAutosSoapClient();
                string xmlRequest = cotizacion.ToString();
                var response = service.WS_TW_ACotiza(xmlRequest, MAPFRE_TOKEN);
                Mapfre.Entidades.CotizacionResponse cotizacionResponse = MapCotizacion(response.OuterXml);

                Comparar infoCompara = new Comparar();
                infoCompara.FechaCotizacion = FechaInicio;
                infoCompara.XmlEmision = xmlRequest;
                infoCompara.XmlRespuesta = response.OuterXml;
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.Aseguradora = "MAPFRE";
                infoCompara.Año = CotizacionCompara.Año;
                infoCompara.FechaInicio = InicioVigencia;
                infoCompara.FechaFin = FinVigencia;
                infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                if (!cotizacionResponse.xml.param.result)
                {
                    infoCompara.ErrorXML = cotizacionResponse.xml.param.error;

                    log.Error("cotizaVehiculo error MAPFRE Request " + xmlRequest.Replace("\n", "").Replace("\r", ""));
                    log.Error("cotizaVehiculo error MAPFRE Response " + response.OuterXml.Replace("\n", "").Replace("\r", ""));
                }
                else
                {
                    infoCompara.CotizacionClave = cotizacionResponse.xml.data.cotizacion.NUM_POLIZA;
                    infoCompara.Coberturas = new List<Coberturas>();
                    foreach (var cobertura in cotizacionResponse.xml.data.cotizacion.coberturas)
                    {
                        Coberturas cotCob = new Coberturas();

                        cotCob.Cobertura = QuitaCaracteres(cobertura.PRIMAS);
                        cotCob.SumaAsegurada = cobertura.LIMMAXRESP;
                        cotCob.Nombre = cobertura.COBERTURA.Trim();
                        if (ConfigEmpresa.IdTipoDeNegocio == 2)
                            cotCob.Deducible = string.IsNullOrWhiteSpace(cobertura.DEDUCIBLE) ? "" : cobertura.DEDUCIBLE;
                        else
                            cotCob.Deducible = cobertura.DEDUCIBLE;

                        cotCob.Codigo = cobertura.COD_COB;
                        infoCompara.Coberturas.Add(cotCob);
                    }
                    infoCompara.PrimaNeta = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_prima_neta);
                    infoCompara.PrimaTotal = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.prima_total);
                    infoCompara.Impuesto = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_iva);
                    infoCompara.Recargo = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_recargos);
                    infoCompara.Derecho = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_derechos);
                    infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();
                    //infoCompara.PrimerPago = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Recibos[0].PrimaTotal);
                    //infoCompara.SegundoPago = cotizacionResponse.xml.data.cotizacion.Recibos.Count > 1 ? QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Recibos[1].PrimaTotal) : "0.00";
                    //infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;
                    infoCompara.PrimerPago = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().PrimaTotalPrimerRecibo);
                    infoCompara.NumeroDePagos = Convert.ToInt32(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().RecibosAdicionales) + 1;
                    infoCompara.SegundoPago = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().PrimaTotalXReciboAdicional);
                    infoCompara.SegundoPago = infoCompara.SegundoPago == "0" ? "" : infoCompara.SegundoPago;
                }
                CotizacionCompara.Comparar.Add(infoCompara);
            }
            catch (Exception ex)
            {

                Comparar infoCompara = new Comparar();
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.Aseguradora = "MAPFRE";
                infoCompara.ErrorXML = string.Format("Tuvimos un inconveniente para realizar tu cotizacion: {0}", string.IsNullOrEmpty(error) ? ex.Message : error);
                CotizacionCompara.Comparar.Add(infoCompara);

                log.Info(infoCompara.ErrorXML);
                //throw;
            }

            return CotizacionCompara;
        }

        private Mapfre.Entidades.Comunes.Request.Campo Campo(string cod, string nom, string val)
        {
            var campo = new Mapfre.Entidades.Comunes.Request.Campo();
            campo.COD_CAMPO = nom;
            campo.ID = cod;
            campo.VAL_CAMPO = val;

            return campo;
        }

        public Comparar LeeXmlRespuesta(string XmlResultado, List<LocktonModel.db.PaqueteDetalle> coberturas, int IdTipoPaquete, string xmlEnvio, Convenio convenioCotiza)
        {
            Mapfre.Entidades.CotizacionResponse cotizacionResponse = MapCotizacion(XmlResultado);

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            xmlCotizacionSeleccionada.LoadXml(xmlEnvio);

            Comparar infoCompara = new Comparar();
            infoCompara.XmlEmision = xmlEnvio;
            infoCompara.XmlRespuesta = XmlResultado;
            infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
            infoCompara.IdConvenio = convenioCotiza.Id;
            infoCompara.Aseguradora = "MAPFRE";

            infoCompara.FechaInicio = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_POLIZA")[0].Attributes["FEC_EFEC_POLIZA"].Value;
            infoCompara.FechaFin = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_POLIZA")[0].Attributes["FEC_VCTO_POLIZA"].Value;
            infoCompara.Año = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_VARIABLES19/CAMPO11")[0].Attributes["VAL_CAMPO"].Value;

            infoCompara.CotizacionClave = cotizacionResponse.xml.data.cotizacion.NUM_POLIZA;
            infoCompara.Coberturas = new List<Coberturas>();
            foreach (var cobertura in cotizacionResponse.xml.data.cotizacion.coberturas)
            {
                Coberturas cotCob = new Coberturas();

                cotCob.Cobertura = QuitaCaracteres(cobertura.PRIMAS);
                cotCob.SumaAsegurada = cobertura.LIMMAXRESP;
                cotCob.Nombre = cobertura.COBERTURA.Trim();
                //if (ConfigEmpresa.IdTipoDeNegocio == 2)
                //	cotCob.Deducible = string.IsNullOrWhiteSpace(cobertura.DEDUCIBLE) ? "" : cobertura.DEDUCIBLE;
                //else
                cotCob.Deducible = cobertura.DEDUCIBLE;

                cotCob.Codigo = cobertura.COD_COB;
                infoCompara.Coberturas.Add(cotCob);
            }
            infoCompara.PrimaNeta = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_prima_neta);
            infoCompara.PrimaTotal = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.prima_total);
            infoCompara.Impuesto = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_iva);
            infoCompara.Recargo = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_recargos);
            infoCompara.Derecho = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_derechos);
            //infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();
            //infoCompara.PrimerPago = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Recibos[0].PrimaTotal);
            //infoCompara.SegundoPago = cotizacionResponse.xml.data.cotizacion.Recibos.Count > 1 ? QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Recibos[1].PrimaTotal) : "0.00";
            //infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;
            infoCompara.PrimerPago = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().PrimaTotalPrimerRecibo);
            infoCompara.NumeroDePagos = Convert.ToInt32(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().RecibosAdicionales);
            infoCompara.SegundoPago = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().PrimaTotalXReciboAdicional);
            infoCompara.SegundoPago = infoCompara.SegundoPago == "0" ? "" : infoCompara.SegundoPago;

            return infoCompara;
        }

        public Comparar LeeXmlInformacion(string XmlResultado, string xmlEnvio)
        {
            Mapfre.Entidades.CotizacionResponse cotizacionResponse = MapCotizacion(XmlResultado);

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            xmlCotizacionSeleccionada.LoadXml(xmlEnvio);

            Comparar infoCompara = new Comparar();
            infoCompara.XmlEmision = xmlEnvio;
            infoCompara.XmlRespuesta = XmlResultado;
            infoCompara.Aseguradora = "MAPFRE";

            infoCompara.FechaInicio = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_POLIZA")[0].Attributes["FEC_EFEC_POLIZA"].Value;
            infoCompara.FechaFin = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_POLIZA")[0].Attributes["FEC_VCTO_POLIZA"].Value;
            infoCompara.Año = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_VARIABLES19/CAMPO11")[0].Attributes["VAL_CAMPO"].Value;

            infoCompara.CotizacionClave = cotizacionResponse.xml.data.cotizacion.NUM_POLIZA;
            infoCompara.Coberturas = new List<Coberturas>();
            foreach (var cobertura in cotizacionResponse.xml.data.cotizacion.coberturas)
            {
                Coberturas cotCob = new Coberturas();

                cotCob.Cobertura = QuitaCaracteres(cobertura.PRIMAS);
                cotCob.SumaAsegurada = cobertura.LIMMAXRESP;
                cotCob.Nombre = cobertura.COBERTURA.Trim();
                //if (ConfigEmpresa.IdTipoDeNegocio == 2)
                //	cotCob.Deducible = string.IsNullOrWhiteSpace(cobertura.DEDUCIBLE) ? "" : cobertura.DEDUCIBLE;
                //else
                cotCob.Deducible = cobertura.DEDUCIBLE;

                cotCob.Codigo = cobertura.COD_COB;
                infoCompara.Coberturas.Add(cotCob);
            }
            infoCompara.PrimaNeta = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_prima_neta);
            infoCompara.PrimaTotal = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.prima_total);
            infoCompara.Impuesto = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_iva);
            infoCompara.Recargo = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_recargos);
            infoCompara.Derecho = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.Totales.total_derechos);

            infoCompara.PrimerPago = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().PrimaTotalPrimerRecibo);
            infoCompara.NumeroDePagos = Convert.ToInt32(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().RecibosAdicionales);
            infoCompara.SegundoPago = QuitaCaracteres(cotizacionResponse.xml.data.cotizacion.FormaPago.Recibos.FirstOrDefault().PrimaTotalXReciboAdicional);
            infoCompara.SegundoPago = infoCompara.SegundoPago == "0" ? "" : infoCompara.SegundoPago;

            return infoCompara;
        }

        private Mapfre.Entidades.CotizacionResponse MapCotizacion(string strxml)
        {
            Mapfre.Entidades.CotizacionResponse response = new Mapfre.Entidades.CotizacionResponse();
            try
            {
                response.xml = Deserialize<Mapfre.Entidades.Comunes.Response.Cotizacion.xml>(strxml);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strxml);

                if (response.xml == null || response.xml.param == null)
                {
                    response.xml = new Mapfre.Entidades.Comunes.Response.Cotizacion.xml();
                    response.xml.param = new Mapfre.Entidades.Comunes.Response.ResponseBase();
                    response.xml.param.error = "";
                    response.xml.param.result = false;
                }

                if (response.xml.param.result)
                {
                    #region Obtener Numero Poliza
                    foreach (var element in doc.GetElementsByTagName("cotizacion"))
                    {
                        response.xml.data.cotizacion.NUM_POLIZA = (element as XmlNode).Attributes["NUM_POLIZA"].InnerText;
                    }
                    #endregion
                    #region Obtener Recibos Forma de Pago
                    response.xml.data.cotizacion.FormaPago = new Mapfre.Entidades.Comunes.Response.Cotizacion.FormaPago();
                    foreach (var element in doc.SelectNodes(@"//FormaPago/Recibos"))
                    {
                        var obj = (element as XmlNode);
                        response.xml.data.cotizacion.FormaPago.Recibos.Add(new Mapfre.Entidades.Comunes.Response.Cotizacion.Recibos
                        {
                            Periodo = obj.SelectNodes("Periodo").Item(0).InnerText,
                            PrimaTotalPrimerRecibo = obj.SelectNodes("PrimaTotalPrimerRecibo").Item(0).InnerText,
                            RecibosAdicionales = obj.SelectNodes("RecibosAdicionales").Item(0).InnerText,
                            PrimaTotalXReciboAdicional = obj.SelectNodes("PrimaTotalXReciboAdicional").Item(0).InnerText
                        });
                    }
                    #endregion
                    #region Obtener Recibos numeros de pagos
                    //response.xml.data.cotizacion.Recibos = new List<Mapfre.Entidades.Comunes.Response.Recibo>();
                    //foreach (var element in doc.GetElementsByTagName("Recibo"))
                    //{
                    //    var obj = (element as XmlNode);
                    //    response.xml.data.cotizacion.Recibos.Add(new Mapfre.Entidades.Comunes.Response.Recibo
                    //    {
                    //        Poliza = obj.SelectNodes("Periodo").Item(0).InnerText,
                    //        Inciso = obj.SelectNodes("PrimaTotalPrimerRecibo").Item(0).InnerText,
                    //        Endoso = obj.SelectNodes("RecibosAdicionales").Item(0).InnerText,
                    //        FechaInicio = obj.SelectNodes("FechaInicio").Item(0).InnerText,
                    //        FechaTermino = obj.SelectNodes("FechaTermino").Item(0).InnerText,
                    //        PrimaNeta = obj.SelectNodes("PrimaNeta").Item(0).InnerText,
                    //        Derecho = obj.SelectNodes("Derecho").Item(0).InnerText,
                    //        Recargo = obj.SelectNodes("Recargo").Item(0).InnerText,
                    //        PorcentajeIVA = obj.SelectNodes("PorcentajeIVA").Item(0).InnerText,
                    //        IVA = obj.SelectNodes("IVA").Item(0).InnerText,
                    //        PrimaTotal = obj.SelectNodes("PrimaTotal").Item(0).InnerText,
                    //        Serie = obj.SelectNodes("Serie").Item(0).InnerText,
                    //        Comision = obj.SelectNodes("Comision").Item(0).InnerText,
                    //        PorcentajeUDI = obj.SelectNodes("PorcentajeUDI").Item(0).InnerText,
                    //        UDI = obj.SelectNodes("UDI").Item(0).InnerText,
                    //        EstatusID = obj.SelectNodes("EstatusID").Item(0).InnerText
                    //    });
                    //}
                    #endregion
                    #region Obtener Coberturas
                    response.xml.data.cotizacion.coberturas = new List<Mapfre.Entidades.Comunes.Response.Cotizacion.coberturas>();
                    foreach (var element in doc.GetElementsByTagName("coberturas"))
                    {
                        var obj = (element as XmlNode);
                        response.xml.data.cotizacion.coberturas.Add(new Mapfre.Entidades.Comunes.Response.Cotizacion.coberturas
                        {
                            COD_COB = obj.SelectNodes("COD_COB").Item(0).InnerText,
                            COBERTURA = obj.SelectNodes("COBERTURA").Item(0).InnerText,
                            DEDUCIBLE = obj.SelectNodes("DEDUCIBLE").Item(0).InnerText,
                            LIMMAXRESP = obj.SelectNodes("LIMMAXRESP").Item(0).InnerText,
                            PRIMAS = obj.SelectNodes("PRIMAS").Item(0).InnerText,
                        });
                    }

                    #endregion
                }
                else
                {
                    var aditionalError = "";
                    try
                    {
                        aditionalError = doc.SelectSingleNode("xml/data").InnerText;

                    }
                    catch (Exception ex)
                    {
                        aditionalError = "";
                    }
                    response.xml.param.error = response.xml.param.error.Replace("\n", "") + "  " + aditionalError.Replace("\n", "");
                }
            }
            catch (Exception ex)
            {
                response.xml = new Mapfre.Entidades.Comunes.Response.Cotizacion.xml();
                response.xml.param = new Mapfre.Entidades.Comunes.Response.ResponseBase();
                response.xml.param.error = string.Format("ERROR: {0}", strxml);
                response.xml.param.result = false;
            }

            return response;
        }
        private T Deserialize<T>(string input) where T : class
        {
            System.Xml.Serialization.XmlSerializer ser = new System.Xml.Serialization.XmlSerializer(typeof(T));

            using (StringReader sr = new StringReader(input))
                return (T)ser.Deserialize(sr);
        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new System.NotImplementedException();
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            EmisionPoliza result = new EmisionPoliza(true, string.Empty, string.Empty, new Poliza());

            Mapfre.Entidades.EmisionRequest emision = new Mapfre.Entidades.EmisionRequest();
            log.Error("Entrando a Emitir MAPFRE");
            var rastreo = "";
            string xmlRequestToSave = string.Empty;
            string responseXMl =  string.Empty;

			try
            {

                CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
                int? idcatGenero = null;
                InfoEmision.Cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacionDetalle.IdCotizacion);
                var cotizacionauto = db.CotizacionAuto.FirstOrDefault(a => a.IdCotizacion == cotizacionDetalle.IdCotizacion);
                rastreo = "COTIZACIONES";

                int IdPaquete = int.Parse(cotizacionDetalle.Paquete);
                PaqueteAseguradora tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == InfoEmision.Convenio.IdAseguradora && x.IdCatTipoPaquete == IdPaquete).FirstOrDefault();
                CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
                PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
                CatPeriodicidadFormaPago catPeriodicidad = db.CatPeriodicidadFormaPago.FirstOrDefault(x => x.Id == InfoEmision.CotizacionAutoGuardar.FormadePago);

                rastreo = "FORMAS DE PAGO";

                var coberturasPaquete = ObtenerCoberturas(InfoEmision.Convenio.Id, IdPaquete, cotizacionDetalle.AMIS, Convert.ToInt32(InfoEmision.Vehiculo.Año), InfoEmision.Convenio.IdEmpresa, Convert.ToInt32(InfoEmision.CotizacionAutoGuardar.TipoVehiculo), false, EsMoto: InfoEmision.CotizacionAutoGuardar.TipoVehiculo == "3" ? true : false);
                var valorComercial10 = coberturasPaquete.Exists(a => a.Item1.Cobertura.Trim() == "VALOR COMERCIAL + 10%");
                int IDCatRamoVehiculo = Convert.ToInt32(InfoEmision.CotizacionAutoGuardar.TipoVehiculo);
                var convenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(a => a.IdConvenio == InfoEmision.Convenio.Id && a.IdCatRamoVehiculo == IDCatRamoVehiculo);
                var descuento = convenioRamoPaquete.Descuento;

                rastreo = "COBERTURAS";

                string MAPFRE_TOKEN = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_TOKEN")).FirstOrDefault().Valor;//"d0c95921-186d-4ae5-a563-deab50d1f158"; 
                string MAPFRE_ID_NEGOCIO = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_ID_NEGOCIO")).FirstOrDefault().Valor;
                //string MAPFRE_NUM_POLIZA_GRUPO = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_NUM_POLIZA_GRUPO")).FirstOrDefault().Valor;
                string MAPFRE_COD_USR = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_COD_USR")).FirstOrDefault().Valor;
                //string MAPFRE_URL_POLIZA = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_URL_POLIZA")).FirstOrDefault().Valor;

                rastreo = "PARAMETROS";

                if (InfoEmision.Cotizacion.IdCatGenero.HasValue)
                {
                    idcatGenero = InfoEmision.Cotizacion.IdCatGenero == 1 ? 1 : 0;
                }


                XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
                xmlCotizacionSeleccionada.LoadXml(cotizacionDetalle.XMLSolicitud);

                rastreo = "COTIZACION XML DETALLE";

                var idEstado = ObtenerCodigoEstado(InfoEmision.Empresa.Direccion.CodigoPostal);
                string InicioVigencia = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_POLIZA")[0].Attributes["FEC_EFEC_POLIZA"].Value;
                string FinVigencia = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_POLIZA")[0].Attributes["FEC_VCTO_POLIZA"].Value;
                var _COD_ESTADO = "";
                var _NOM_DOMICILIO1 = "";
                var _NOM_DOMICILIO3 = "";
                var _COD_PROV = "";
                var _COD_POSTAL = "";
                var _NOMBRE = "";
                var _APELLIDO_P = "";
                var _APELLIDO_M = "";
                var _COD_DOCUMContraTante = "";

                _COD_ESTADO = ObtenerCodigoEstado(InfoEmision.Empresa.Direccion.CodigoPostal);
                _COD_PROV = InfoEmision.Empresa.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(_COD_ESTADO, InfoEmision.Empresa.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo);

                rastreo = "PROVINCIA";

                #region Datos Poliza
                emision.User = InfoEmision.Convenio.Usuario;
                emision.PWD = InfoEmision.Convenio.Contrasena;
                emision.DATOS_POLIZA.ID_NEGOCIO = InfoEmision.Convenio.NumeroNegocio;// MAPFRE_ID_NEGOCIO;
                emision.DATOS_POLIZA.NUM_POLIZA_GRUPO = InfoEmision.Convenio.NumeroPolizaGrupo;// MAPFRE_NUM_POLIZA_GRUPO;
                emision.DATOS_POLIZA.NUM_CONTRATO = InfoEmision.Convenio.CodigoPromocion;
                emision.DATOS_POLIZA.COD_SECTOR = "4";
                emision.DATOS_POLIZA.COD_RAMO = InfoEmision.CotizacionAutoGuardar.TipoVehiculo == "1" ? "401" : InfoEmision.CotizacionAutoGuardar.TipoVehiculo == "2" ? "405" : "403";
                emision.DATOS_POLIZA.FEC_EFEC_POLIZA = InicioVigencia;
                emision.DATOS_POLIZA.FEC_VCTO_POLIZA = FinVigencia;
                emision.DATOS_POLIZA.COD_FRACC_PAGO = perioricidad.FormaPago;
                emision.DATOS_POLIZA.COD_CUADRO_COM = InfoEmision.Convenio.CuadroComision;
                emision.DATOS_POLIZA.COD_AGT = InfoEmision.Convenio.UsuarioAgente.Trim();
                emision.DATOS_POLIZA.COD_USR = MAPFRE_COD_USR;
                emision.DATOS_POLIZA.COD_NIVEL3_CAPTURA = "0";
                emision.DATOS_POLIZA.TIP_DOCUM = "RFC";
                emision.DATOS_POLIZA.COD_DOCUM = InfoEmision.Empresa.RFC;
                emision.DATOS_POLIZA.COD_ESTADO = idEstado;
                emision.DATOS_POLIZA.COD_PROV = _COD_PROV;
                emision.DATOS_POLIZA.PCT_AGT = "100";
                emision.DATOS_POLIZA.COD_GESTOR = InfoEmision.Convenio.UsuarioAgente.Trim();
                emision.DATOS_POLIZA.TIP_GESTOR = "AG";
                #endregion

                rastreo = "DATOS POLIZA";

                #region informacion Bancaria
                if (InfoEmision.CotizacionAutoGuardar.MediodePago == 0 || InfoEmision.CotizacionAutoGuardar.MediodePago == 1)
                {
                    rastreo = "INICIO INFORMACION BANCARIA";

                    var _fechacorte = InicioVigencia;
                    var _inicio = DateTime.ParseExact(InicioVigencia, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    var fechaCobro = db.FechaCobroMAPFRE.Where(a => a.IdConvenio == InfoEmision.Convenio.Id
                                        && a.IdPeriodicidad == catPeriodicidad.Id
                                        && a.Fecha >= _inicio).OrderBy(a => a.Fecha).FirstOrDefault();
                    if (fechaCobro != null)
                        _fechacorte = fechaCobro.Fecha.ToString("dd/MM/yyyy");

                    emision.DATOS_POLIZA.COD_GESTOR = InfoEmision.IdBanco.ToString().PadLeft(4, '0') + InfoEmision.IdBanco.ToString().PadLeft(4, '0');
                    emision.DATOS_POLIZA.TIP_GESTOR = (InfoEmision.CotizacionAutoGuardar.MediodePago == 0) ? "TA" : "BA";
                    emision.DATOS_POLIZA.FEC_CORTE = _fechacorte;
                    emision.DATOS_POLIZA.COD_ENTIDAD = InfoEmision.IdBanco.ToString().PadLeft(4, '0');
                    emision.DATOS_POLIZA.COD_OFICINA = InfoEmision.IdBanco.ToString().PadLeft(4, '0');
                    //TODO:Descomentar
                    emision.DATOS_POLIZA.NOM_TERCERO = InfoEmision.Tarjeta.NombreTitularTarjeta;
                    emision.DATOS_POLIZA.APE1_TERCERO = InfoEmision.Tarjeta.ApellidoPTitularTarjeta;
                    emision.DATOS_POLIZA.APE2_TERCERO = InfoEmision.Tarjeta.ApellidoMTitularTarjeta;
                    emision.DATOS_POLIZA.EMAIL = InfoEmision.Tarjeta.Email;

                    if (InfoEmision.Tarjeta.TipoTarjeta == "VISA")
                    {
                        emision.DATOS_POLIZA.TIP_TARJETA = "1";
                    }
                    else if (InfoEmision.Tarjeta.TipoTarjeta.Contains("MASTER"))
                    {
                        emision.DATOS_POLIZA.TIP_TARJETA = "2";
                    }
                    else
                    {
                        emision.DATOS_POLIZA.TIP_TARJETA = "3";
                    }
                    emision.DATOS_POLIZA.COD_TARJETA = "";
                    emision.DATOS_POLIZA.FEC_VCTO_TARJETA = "00/00/0000";
                    emision.DATOS_POLIZA.NUM_TARJETA = InfoEmision.Tarjeta.NumeroTarjeta;

                    rastreo = "INFORMACION BANCARIA";
                }
                #endregion

                #region Terceros

                var _regCapital = "";
                var _regFiscal = "";
                var _usoCFDI = "";

                if (InfoEmision.RequiereFactura)
                {
                    try
                    {
                        if (InfoEmision.EsFlotilla || InfoEmision.EmisionPersonaMoral)
                        {
                            if (InfoEmision.Empresa.IdRegimenFiscal.HasValue)
                            {
                                _regFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal).Clave;
                                _regCapital = db.CatRegimenCapital.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenCapital).ClaveMAPFRE;
                                _usoCFDI = db.CatUsoCFDI.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdUsoCFDI).Abreviatura;
                            }
                        }
                        else
                        {
                            _regFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.IdRegimenFiscal).Clave;
                            _usoCFDI = db.CatUsoCFDI.FirstOrDefault(a => a.Id == InfoEmision.IdUsoCFDI).Abreviatura;

                        }
                    }
                    catch (Exception ex)
                    {
                        _regCapital = "";
                        _regFiscal = "";
                        _usoCFDI = "";

                    }
                }

                if (InfoEmision.EmisionPersonaMoral)
                {
                    rastreo = "INICIO PERSONA MORAL";

                    InfoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoral.Id);
                    InfoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoralRepresentanteLegal.Id);

                    _COD_ESTADO = ObtenerCodigoEstado(InfoEmision.PersonaMoral.Direccion.CodigoPostal);
                    _NOM_DOMICILIO1 = string.Format("{0} {1} {2}", InfoEmision.PersonaMoral.Direccion.Calle, InfoEmision.PersonaMoral.Direccion.NumeroExt, string.IsNullOrEmpty(InfoEmision.PersonaMoral.Direccion.NumeroInt) ? "" : "int " + InfoEmision.PersonaMoral.Direccion.NumeroInt).Trim();
                    _NOM_DOMICILIO3 = InfoEmision.PersonaMoral.Direccion.Colonia;
                    _COD_PROV = InfoEmision.PersonaMoral.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(_COD_ESTADO, InfoEmision.PersonaMoral.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo);
                    _COD_POSTAL = InfoEmision.PersonaMoral.Direccion.CodigoPostal;

                    rastreo = "PERSONA MORAL PROVINCIAS";

                    Mapfre.Entidades.Comunes.Request.Tercero contratante = new Mapfre.Entidades.Comunes.Request.Tercero();
                    contratante.Tipo = Mapfre.Entidades.Comunes.Request.EnumTipoTercero.Contratante;
                    contratante.COD_DOCUM = InfoEmision.PersonaMoral.RFC;
                    contratante.MCA_FISICO = "N";
                    contratante.APE1_TERCERO = "";
                    contratante.APE2_TERCERO = "";
                    contratante.NOM_TERCERO = InfoEmision.PersonaMoral.NombreComercial;
                    contratante.NOM_DOMICILIO1 = _NOM_DOMICILIO1;
                    contratante.NOM_DOMICILIO3 = _NOM_DOMICILIO3;
                    contratante.COD_ESTADO = _COD_ESTADO;
                    contratante.COD_PROV = _COD_PROV;
                    contratante.COD_LOCALIDAD = contratante.COD_PROV;
                    contratante.MCA_SEXO = idcatGenero == null ? "1" : idcatGenero.ToString();
                    contratante.FEC_NACIMIENTO = InfoEmision.PersonaMoral.FechaConstitucion == null ? string.Empty : InfoEmision.PersonaMoral.FechaConstitucion.Value.ToString("dd/MM/yyyy");
                    contratante.COD_POSTAL = _COD_POSTAL;
                    contratante.TLF_NUMERO = InfoEmision.PersonaMoralRepresentanteLegal.Telefono;
                    contratante.EMAIL = InfoEmision.PersonaMoralRepresentanteLegal.Correo;
                    contratante.TLF_MOVIL = InfoEmision.PersonaMoralRepresentanteLegal.Telefono;
                    contratante.MODIFICADO = "N";
                    contratante.REG_SOC = _regCapital;
                    contratante.COD_REG_FIS = _regFiscal;
                    contratante.COD_POSTAL_FIS = string.IsNullOrEmpty(_regFiscal) ? "" : _COD_POSTAL;
                    contratante.USO_CFDI = _usoCFDI;
                    emision.TERCEROS.Add(contratante);

                    rastreo = "PERSONA MORAL";

                }
                else if (InfoEmision.EsFlotilla)
                {

                    rastreo = "INICIO FLOTILLA";

                    _COD_ESTADO = ObtenerCodigoEstado(InfoEmision.Empresa.Direccion.CodigoPostal);
                    _NOM_DOMICILIO1 = string.Format("{0} {1} {2}", InfoEmision.Empresa.Direccion.Calle, InfoEmision.Empresa.Direccion.NumeroExt, string.IsNullOrEmpty(InfoEmision.Empresa.Direccion.NumeroInt) ? "" : "int " + InfoEmision.Empresa.Direccion.NumeroInt).Trim();
                    _NOM_DOMICILIO3 = InfoEmision.Empresa.Direccion.Colonia;
                    _COD_PROV = InfoEmision.Empresa.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(_COD_ESTADO, InfoEmision.Empresa.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo);
                    _COD_POSTAL = InfoEmision.Empresa.Direccion.CodigoPostal;

                    rastreo = "FLOTILLA PROVINCIAS";

                    Mapfre.Entidades.Comunes.Request.Tercero contratante = new Mapfre.Entidades.Comunes.Request.Tercero();
                    contratante.Tipo = Mapfre.Entidades.Comunes.Request.EnumTipoTercero.Contratante;
                    contratante.COD_DOCUM = InfoEmision.Empresa.RFC;
                    contratante.MCA_FISICO = "N";
                    contratante.APE1_TERCERO = "";
                    contratante.APE2_TERCERO = "";
                    contratante.NOM_TERCERO = InfoEmision.Empresa.RazonSocial;
                    contratante.NOM_DOMICILIO1 = _NOM_DOMICILIO1;
                    contratante.NOM_DOMICILIO3 = _NOM_DOMICILIO3;
                    contratante.COD_ESTADO = _COD_ESTADO;
                    contratante.COD_PROV = _COD_PROV;
                    contratante.COD_LOCALIDAD = contratante.COD_PROV;
                    contratante.MCA_SEXO = idcatGenero == null ? "1" : idcatGenero.ToString();
                    contratante.FEC_NACIMIENTO = InfoEmision.Empresa.FechaConstitucion == null ? string.Empty : InfoEmision.Empresa.FechaConstitucion.Value.ToString("dd/MM/yyyy");
                    contratante.COD_POSTAL = _COD_POSTAL;
                    contratante.TLF_NUMERO = InfoEmision.Empresa.TelefonoGral;
                    contratante.EMAIL = "";
                    contratante.TLF_MOVIL = InfoEmision.Empresa.TelefonoGral;
                    contratante.MODIFICADO = "N";
                    contratante.REG_SOC = _regCapital;
                    contratante.COD_REG_FIS = _regFiscal;
                    contratante.COD_POSTAL_FIS = string.IsNullOrEmpty(_regFiscal) ? "" : _COD_POSTAL;
                    contratante.USO_CFDI = _usoCFDI;
                    emision.TERCEROS.Add(contratante);

                    rastreo = "FLOTILLA";
                }
                else
                {
                    if (InfoEmision.DetalleUsuario.Direccion != null)
                    {
                        log.Info("Entra a InfoEmision.DetalleUsuario.Direccion != null ");
                        rastreo = "INICIO DETALLEUSUARIO";

                        _COD_ESTADO = ObtenerCodigoEstado(InfoEmision.DetalleUsuario.Direccion.CodigoPostal);
                        _NOM_DOMICILIO1 = string.Format("{0} {1} {2}", InfoEmision.DetalleUsuario.Direccion.Calle, InfoEmision.DetalleUsuario.Direccion.NumeroExt, string.IsNullOrEmpty(InfoEmision.DetalleUsuario.Direccion.NumeroInt) ? "" : "int " + InfoEmision.DetalleUsuario.Direccion.NumeroInt).Trim();
                        _NOM_DOMICILIO3 = InfoEmision.DetalleUsuario.Direccion.Colonia;
                        _COD_PROV = InfoEmision.DetalleUsuario.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(_COD_ESTADO, InfoEmision.DetalleUsuario.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo);
                        _COD_POSTAL = InfoEmision.Direccion.CodigoPostal;

                        _NOMBRE = InfoEmision.DetalleUsuario.Nombre + " " + InfoEmision.DetalleUsuario.NombreDos;
                        _APELLIDO_P = InfoEmision.DetalleUsuario.ApellidoPaterno;
                        _APELLIDO_M = InfoEmision.DetalleUsuario.ApellidoMaterno;

                        rastreo = "DETALLE USUARIO PROVINCIAS";
                        _COD_DOCUMContraTante = InfoEmision.DetalleUsuario.RFC;
                        log.Info("_COD_DOCUMContraTante " + _COD_DOCUMContraTante);

                    }

                    if (InfoEmision.DatosUsuario.Direccion != null)
                    {
                        log.Info("Entra a InfoEmision.DatosUsuario.Direccion != null");
                        rastreo = "INICIO DATOS USUARIO";

                        _COD_ESTADO = ObtenerCodigoEstado(InfoEmision.DatosUsuario.Direccion.CodigoPostal);
                        _NOM_DOMICILIO1 = string.Format("{0} {1} {2}", InfoEmision.DatosUsuario.Direccion.Calle, InfoEmision.DatosUsuario.Direccion.NumeroExt, string.IsNullOrEmpty(InfoEmision.DatosUsuario.Direccion.NumeroInt) ? "" : "int " + InfoEmision.DatosUsuario.Direccion.NumeroInt).Trim();
                        _NOM_DOMICILIO3 = InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
                        _COD_PROV = InfoEmision.DatosUsuario.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(_COD_ESTADO, InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo);
                        _COD_POSTAL = InfoEmision.DatosUsuario.Direccion.CodigoPostal;

                        _NOMBRE = InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre;
                        _APELLIDO_P = InfoEmision.ApellidoPaterno;
                        _APELLIDO_M = InfoEmision.ApellidoMaterno;
                        _COD_DOCUMContraTante = InfoEmision.DatosUsuario.RFC;
                        log.Info("_COD_DOCUMContraTante " + _COD_DOCUMContraTante);

                        rastreo = "DATOS USUARIO PROVINCIA";
                    }

                    Mapfre.Entidades.Comunes.Request.Tercero contratante = new Mapfre.Entidades.Comunes.Request.Tercero();
                    contratante.Tipo = Mapfre.Entidades.Comunes.Request.EnumTipoTercero.Contratante;
                    log.Info("contratante cod_docum + " + _COD_DOCUMContraTante + " RF detalleusuario " + InfoEmision.DatosUsuario.RFC);
                    contratante.COD_DOCUM = _COD_DOCUMContraTante == null ? InfoEmision.DatosUsuario.RFC : _COD_DOCUMContraTante;
                    contratante.MCA_SEXO = idcatGenero == null ? InfoEmision.DetalleUsuario.GENERO.ToLower() == "masculino" ? "1" : "0" : idcatGenero.ToString();
                    contratante.MCA_FISICO = "S";
                    contratante.APE1_TERCERO = _APELLIDO_P;
                    contratante.APE2_TERCERO = _APELLIDO_M;
                    contratante.NOM_TERCERO = _NOMBRE;
                    contratante.NOM_DOMICILIO1 = _NOM_DOMICILIO1;
                    contratante.NOM_DOMICILIO3 = _NOM_DOMICILIO3;

                    contratante.COD_ESTADO = _COD_ESTADO;
                    contratante.COD_PROV = _COD_PROV;
                    contratante.COD_LOCALIDAD = contratante.COD_PROV;
                    contratante.FEC_NACIMIENTO = InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy");
                    contratante.COD_POSTAL = _COD_POSTAL;
                    contratante.TLF_NUMERO = InfoEmision.TelefonoFijo;
                    contratante.EMAIL = InfoEmision.Email;
                    contratante.TLF_MOVIL = InfoEmision.TelefonoCel;
                    contratante.MODIFICADO = "N";
                    contratante.REG_SOC = _regCapital;
                    contratante.COD_REG_FIS = _regFiscal;
                    contratante.COD_POSTAL_FIS = string.IsNullOrEmpty(_regFiscal) ? "" : _COD_POSTAL;
                    contratante.USO_CFDI = _usoCFDI;
                    emision.TERCEROS.Add(contratante);

                    rastreo = "TERCEROS";
                }



                if (InfoEmision.DatosUsuario.Direccion != null)
                {
                    rastreo = "INICIO DATOS USUARIO DIRECCION";

                    _COD_ESTADO = ObtenerCodigoEstado(InfoEmision.DatosUsuario.Direccion.CodigoPostal);
                    _NOM_DOMICILIO1 = string.Format("{0} {1} {2}", InfoEmision.DatosUsuario.Direccion.Calle, InfoEmision.DatosUsuario.Direccion.NumeroExt, string.IsNullOrEmpty(InfoEmision.DatosUsuario.Direccion.NumeroInt) ? "" : "int " + InfoEmision.DatosUsuario.Direccion.NumeroInt).Trim();
                    _NOM_DOMICILIO3 = InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
                    _COD_PROV = InfoEmision.DatosUsuario.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(_COD_ESTADO, InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo);
                    _COD_POSTAL = InfoEmision.DatosUsuario.Direccion.CodigoPostal;

                    rastreo = "DATOS USUARIO DIRECCION";
                }

                Mapfre.Entidades.Comunes.Request.Tercero conductor = new Mapfre.Entidades.Comunes.Request.Tercero();
                conductor.Tipo = Mapfre.Entidades.Comunes.Request.EnumTipoTercero.Conductor;
                if(InfoEmision.EmisionPersonaMoral && string.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC))
                {
                    InfoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoral.Id);
                    InfoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoralRepresentanteLegal.Id);

                    _COD_ESTADO = ObtenerCodigoEstado(InfoEmision.PersonaMoral.Direccion.CodigoPostal);
                    _NOM_DOMICILIO1 = string.Format("{0} {1} {2}", InfoEmision.PersonaMoral.Direccion.Calle, InfoEmision.PersonaMoral.Direccion.NumeroExt, string.IsNullOrEmpty(InfoEmision.PersonaMoral.Direccion.NumeroInt) ? "" : "int " + InfoEmision.PersonaMoral.Direccion.NumeroInt).Trim();
                    _NOM_DOMICILIO3 = InfoEmision.PersonaMoral.Direccion.Colonia;
                    _COD_PROV = InfoEmision.PersonaMoral.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(_COD_ESTADO, InfoEmision.PersonaMoral.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo);
                    _COD_POSTAL = InfoEmision.PersonaMoral.Direccion.CodigoPostal;

                    conductor.COD_DOCUM = InfoEmision.PersonaMoral.RFC;
                    conductor.MCA_SEXO = idcatGenero == null ? "1" : idcatGenero.ToString();
                    conductor.MCA_FISICO = "N";
                    conductor.APE1_TERCERO = "";
                    conductor.APE2_TERCERO = "";
                    conductor.NOM_TERCERO = InfoEmision.PersonaMoral.NombreComercial;
                    conductor.NOM_DOMICILIO1 = _NOM_DOMICILIO1;
                    conductor.NOM_DOMICILIO3 = _NOM_DOMICILIO3;
                    conductor.COD_ESTADO = _COD_ESTADO;
                    conductor.COD_PROV = _COD_PROV;
                    conductor.COD_LOCALIDAD = conductor.COD_PROV;
                    conductor.FEC_NACIMIENTO = InfoEmision.PersonaMoral.FechaConstitucion == null ? string.Empty : InfoEmision.PersonaMoral.FechaConstitucion.Value.ToString("dd/MM/yyyy");
                    conductor.COD_POSTAL = _COD_POSTAL;
                    conductor.TLF_NUMERO = InfoEmision.PersonaMoralRepresentanteLegal.Telefono;
                    conductor.EMAIL = InfoEmision.PersonaMoralRepresentanteLegal.Correo;
                    conductor.TLF_MOVIL = InfoEmision.PersonaMoralRepresentanteLegal.Telefono;
                    conductor.MODIFICADO = "N";
                }
                else
                {
                    conductor.COD_DOCUM = InfoEmision.DatosUsuario.RFC;
                    conductor.MCA_SEXO = idcatGenero == null ? InfoEmision.DetalleUsuario.GENERO.ToLower() == "masculino" ? "1" : "0" : idcatGenero.ToString();
                    conductor.MCA_FISICO = "S";
                    conductor.APE1_TERCERO = InfoEmision.ApellidoPaterno;
                    conductor.APE2_TERCERO = InfoEmision.ApellidoMaterno;
                    conductor.NOM_TERCERO = InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre;
                    conductor.NOM_DOMICILIO1 = _NOM_DOMICILIO1;
                    conductor.NOM_DOMICILIO3 = _NOM_DOMICILIO3;
                    conductor.COD_ESTADO = _COD_ESTADO;
                    conductor.COD_PROV = _COD_PROV;
                    conductor.COD_LOCALIDAD = conductor.COD_PROV;
                    conductor.FEC_NACIMIENTO = InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy");
                    conductor.COD_POSTAL = _COD_POSTAL;
                    conductor.TLF_NUMERO = InfoEmision.TelefonoFijo;
                    conductor.EMAIL = InfoEmision.Email;
                    conductor.TLF_MOVIL = InfoEmision.TelefonoCel;
                    conductor.MODIFICADO = "N";
                }                          
                emision.TERCEROS.Add(conductor);

                rastreo = "TERCEROS CONDUCTOR";

                if (InfoEmision.DetalleUsuario.Direccion != null)
                {
                    rastreo = "INICIO BENEFICIARIO";

                    Mapfre.Entidades.Comunes.Request.Tercero beneficiario = new Mapfre.Entidades.Comunes.Request.Tercero();
                    beneficiario.Tipo = Mapfre.Entidades.Comunes.Request.EnumTipoTercero.Beneficiario;
                    beneficiario.COD_DOCUM = InfoEmision.DatosUsuario.RFC;
                    beneficiario.MCA_SEXO = InfoEmision.DetalleUsuario.GENERO.ToLower() == "masculino" ? "1" : "0";
                    beneficiario.MCA_FISICO = "S";
                    beneficiario.APE1_TERCERO = InfoEmision.DetalleUsuario.ApellidoPaterno;
                    beneficiario.APE2_TERCERO = InfoEmision.DetalleUsuario.ApellidoMaterno;
                    beneficiario.NOM_TERCERO = InfoEmision.DetalleUsuario.Nombre + " " + InfoEmision.DetalleUsuario.NombreDos;
                    beneficiario.NOM_DOMICILIO1 = string.Format("{0} {1} {2}", InfoEmision.DetalleUsuario.Direccion.Calle, InfoEmision.DetalleUsuario.Direccion.NumeroExt, string.IsNullOrEmpty(InfoEmision.DetalleUsuario.Direccion.NumeroInt) ? "" : "int " + InfoEmision.DetalleUsuario.Direccion.NumeroInt).Trim();
                    beneficiario.NOM_DOMICILIO3 = InfoEmision.DetalleUsuario.Direccion.Colonia;
                    beneficiario.COD_ESTADO = ObtenerCodigoEstado(InfoEmision.DetalleUsuario.Direccion == null ? InfoEmision.Direccion.CodigoPostal : InfoEmision.DetalleUsuario.Direccion.CodigoPostal);
                    beneficiario.COD_PROV = InfoEmision.DetalleUsuario.Direccion == null ? "0" : (InfoEmision.DetalleUsuario.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(conductor.COD_ESTADO, InfoEmision.DetalleUsuario.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo));
                    beneficiario.COD_LOCALIDAD = beneficiario.COD_PROV;
                    beneficiario.FEC_NACIMIENTO = InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yyyy");
                    beneficiario.COD_POSTAL = InfoEmision.DetalleUsuario.Direccion == null ? InfoEmision.Direccion.CodigoPostal : InfoEmision.DetalleUsuario.Direccion.CodigoPostal;
                    beneficiario.TLF_NUMERO = InfoEmision.TelefonoFijo;
                    beneficiario.EMAIL = InfoEmision.Email;
                    beneficiario.TLF_MOVIL = InfoEmision.TelefonoCel;
                    beneficiario.MODIFICADO = "N";
                    emision.TERCEROS.Add(beneficiario);

                    rastreo = "BENEFICIARIO";


                    Mapfre.Entidades.Comunes.Request.Tercero yo = new Mapfre.Entidades.Comunes.Request.Tercero();
                    yo.Tipo = Mapfre.Entidades.Comunes.Request.EnumTipoTercero.Yo;
                    yo.COD_DOCUM = InfoEmision.DatosUsuario.RFC;
                    yo.MCA_SEXO = idcatGenero == null ? InfoEmision.DetalleUsuario.GENERO.ToLower() == "masculino" ? "1" : "0" : idcatGenero.ToString();
                    yo.MCA_FISICO = "S";
                    yo.APE1_TERCERO = InfoEmision.DetalleUsuario.ApellidoPaterno;
                    yo.APE2_TERCERO = InfoEmision.DetalleUsuario.ApellidoMaterno;
                    yo.NOM_TERCERO = InfoEmision.DetalleUsuario.Nombre + " " + InfoEmision.DetalleUsuario.NombreDos;
                    yo.NOM_DOMICILIO1 = string.Format("{0} {1} {2}", InfoEmision.DetalleUsuario.Direccion.Calle, InfoEmision.DetalleUsuario.Direccion.NumeroExt, string.IsNullOrEmpty(InfoEmision.DetalleUsuario.Direccion.NumeroInt) ? "" : "int " + InfoEmision.DetalleUsuario.Direccion.NumeroInt).Trim();
                    yo.NOM_DOMICILIO3 = InfoEmision.DetalleUsuario.Direccion.Colonia;
                    yo.COD_ESTADO = ObtenerCodigoEstado(InfoEmision.DetalleUsuario.Direccion == null ? InfoEmision.Direccion.CodigoPostal : InfoEmision.DetalleUsuario.Direccion.CodigoPostal);
                    yo.COD_PROV = InfoEmision.DetalleUsuario.Direccion == null ? "0" : (InfoEmision.DetalleUsuario.Direccion.CatCodigoPostal == null ? "0" : ObtenerCodigoProvincia(conductor.COD_ESTADO, InfoEmision.DetalleUsuario.Direccion.CatCodigoPostal.Municipio, InfoEmision.NombreTipoVehiculo));
                    yo.COD_LOCALIDAD = yo.COD_PROV;
                    yo.FEC_NACIMIENTO = InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yyyy");
                    yo.COD_POSTAL = InfoEmision.DetalleUsuario.Direccion == null ? InfoEmision.Direccion.CodigoPostal : InfoEmision.DetalleUsuario.Direccion.CodigoPostal;
                    yo.TLF_NUMERO = InfoEmision.TelefonoFijo;
                    yo.EMAIL = InfoEmision.Email;
                    yo.TLF_MOVIL = InfoEmision.TelefonoCel;
                    yo.MODIFICADO = "N";
                    emision.TERCEROS.Add(yo);

                    rastreo = "TERCEROS YO";
                }

                if (InfoEmision.EsBeneficiarioPreferente)
                {
                    rastreo = "INICIO BENEFICIARIO PREFERENTE";

                    int idBeneficiario = 0;
                    if (int.TryParse(InfoEmision.IdBeneficiarioPreferente, out idBeneficiario))
                    {
                        rastreo = "ID BENEFICIARIO " + idBeneficiario.ToString();

                        var _beneficiario = db.CatBeneficiarioPreferente.FirstOrDefault(a => a.Id == idBeneficiario);
                        if (_beneficiario != null)
                        {
                            var _localidad = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == _beneficiario.CodigoPostal);

                            _COD_ESTADO = ObtenerCodigoEstado(_beneficiario.CodigoPostal);
                            _COD_PROV = _localidad == null ? "0" : ObtenerCodigoProvincia(_COD_ESTADO, _localidad.Municipio, InfoEmision.NombreTipoVehiculo);

                            rastreo = "BENEFICIARIO PROVINCIA";

                            Mapfre.Entidades.Comunes.Request.Tercero beneficiario = new Mapfre.Entidades.Comunes.Request.Tercero();
                            beneficiario.Tipo = Mapfre.Entidades.Comunes.Request.EnumTipoTercero.Beneficiario;
                            beneficiario.COD_DOCUM = _beneficiario.RFC;
                            beneficiario.MCA_SEXO = _beneficiario.Genero.ToLower() == "masculino" ? "1" : "0";
                            beneficiario.MCA_FISICO = _beneficiario.PersonaMoral ? "N" : "S";
                            beneficiario.APE1_TERCERO = "";
                            beneficiario.APE2_TERCERO = "";
                            beneficiario.NOM_TERCERO = _beneficiario.Nombre;
                            beneficiario.NOM_DOMICILIO1 = _beneficiario.Direccion;
                            beneficiario.NOM_DOMICILIO3 = "";
                            beneficiario.COD_ESTADO = _COD_ESTADO;
                            beneficiario.COD_PROV = _COD_PROV;
                            beneficiario.COD_LOCALIDAD = _COD_PROV;
                            beneficiario.FEC_NACIMIENTO = _beneficiario.FechaNacimiento.HasValue ? _beneficiario.FechaNacimiento.Value.ToString("dd/MM/yyyy") : "";
                            beneficiario.COD_POSTAL = _beneficiario.CodigoPostal;
                            beneficiario.TLF_NUMERO = _beneficiario.NumeroTelefono;
                            beneficiario.TLF_MOVIL = _beneficiario.NumeroCelular;
                            beneficiario.EMAIL = _beneficiario.Email;
                            beneficiario.MODIFICADO = "N";
                            emision.TERCEROS.Add(beneficiario);

                            rastreo = "TERCEROS BENEFICIARIO";
                        }

                    }
                }

                #endregion

                #region Datos variables
                var valorFactura = "";
                rastreo = "VALOR FACTURA VALIDACION";
                if (cotizacionauto.ValorFactura)
                {
                    valorFactura = cotizacionauto.MontoFactura.ToString();
                    if (valorFactura.Contains('.'))
                        valorFactura = valorFactura.Substring(0, valorFactura.IndexOf('.'));
                }

                rastreo = "VALOR FACTURA";

                emision.DATOS_VARIABLES.NUM_RIESGO = "1";
                emision.DATOS_VARIABLES.TIP_NIVEL = "3";
                emision.DATOS_VARIABLES.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { COD_CAMPO = "COD_MATERIA", VAL_CAMPO = "1" });

                emision.DATOS_VARIABLES44.NUM_RIESGO = "1";
                emision.DATOS_VARIABLES44.TIP_NIVEL = "2";

                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "9", COD_CAMPO = "NUM_SERIE", VAL_CAMPO = InfoEmision.Vehiculo.Serie });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "11", COD_CAMPO = "COD_MODALIDAD", VAL_CAMPO = "40999" });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "12", COD_CAMPO = "ANIO_FABRICA", VAL_CAMPO = InfoEmision.Vehiculo.Año });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "13", COD_CAMPO = "COD_MARCA", VAL_CAMPO = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_VARIABLES19/CAMPO12")[0].Attributes["VAL_CAMPO"].Value });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "14", COD_CAMPO = "COD_MODELO", VAL_CAMPO = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_VARIABLES19/CAMPO13")[0].Attributes["VAL_CAMPO"].Value });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "15", COD_CAMPO = "COD_TIP_VEHI", VAL_CAMPO = xmlCotizacionSeleccionada.SelectNodes("XML/DATA/COTIZACION/DATOS_VARIABLES19/CAMPO14")[0].Attributes["VAL_CAMPO"].Value });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "16", COD_CAMPO = "COD_USO_VEHI", VAL_CAMPO = "401" });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "17", COD_CAMPO = "MCA_FACTURA", VAL_CAMPO = cotizacionauto.ValorFactura ? "S" : "N" });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "18", COD_CAMPO = "MCA_ACTUAL", VAL_CAMPO = "N" });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "19", COD_CAMPO = "MCA_COMERCIAL", VAL_CAMPO = valorComercial10 || cotizacionauto.ValorFactura ? "N" : "S" });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "23", COD_CAMPO = "NUM_MATRICULA", VAL_CAMPO = InfoEmision.Vehiculo.Placas });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "24", COD_CAMPO = "NUM_MOTOR", VAL_CAMPO = InfoEmision.Vehiculo.Motor });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "26", COD_CAMPO = "NUM_PASAJEROS", VAL_CAMPO = "5" });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "27", COD_CAMPO = "VAL_FACTURA", VAL_CAMPO = valorFactura });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "28", COD_CAMPO = "NUM_FACTURA", VAL_CAMPO = cotizacionauto.ValorFactura ? InfoEmision.Cotizacion.NumeroFactura : "" });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "29", COD_CAMPO = "FEC_FACTURA", VAL_CAMPO = cotizacionauto.ValorFactura ? InfoEmision.Cotizacion.FechaFactura.ToString("ddMMyyyy") : "" });
                emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "30", COD_CAMPO = "VAL_ACTUAL", VAL_CAMPO = InfoEmision.Vehiculo.MontoFactura.ToString() });

                rastreo = "DATOS VARIABLES";

                if (valorComercial10)
                    emision.DATOS_VARIABLES44.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "60", COD_CAMPO = "MCA_COMERCIAL10", VAL_CAMPO = cotizacionauto.ValorFactura ? "N" : "S" });


                emision.DATOS_VARIABLES49.NUM_RIESGO = "0";
                emision.DATOS_VARIABLES49.TIP_NIVEL = "1";
                emision.DATOS_VARIABLES49.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "44", COD_CAMPO = "COD_BONI_RECA", VAL_CAMPO = "999" });
                emision.DATOS_VARIABLES49.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "46", COD_CAMPO = "PCT_COD_REC_ESP", VAL_CAMPO = descuento.ToString("N0") == "0" ? "0" : "-" + descuento.ToString() });
                emision.DATOS_VARIABLES49.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "47", COD_CAMPO = "PCT_CESION_COM_AGT", VAL_CAMPO = "100" });
                emision.DATOS_VARIABLES49.Campos.Add(new Mapfre.Entidades.Comunes.Request.Campo { ID = "48", COD_CAMPO = "MEDIO_CAPTACION", VAL_CAMPO = "1" });


                rastreo = "DATOS VARIABLES FINAL";
                #endregion

                #region Coberturas
                CoberturasUtils utils = new CoberturasUtils();

                rastreo = "COBERTURAS";

                foreach (var item in coberturasPaquete)
                {
                    bool EsCondEspecial = utils.EsCondicionEsp(InfoEmision.Convenio.Id, item.Item1.IdCobertura.ToString(), convenioRamoPaquete.IdCatRamoVehiculo);
                    var aplicaCondicionEspecial = utils.AplicaCoberturaEspecial(InfoEmision.Convenio.Id, item.Item1.IdCobertura.ToString(), InfoEmision.Vehiculo.Año, convenioRamoPaquete.IdCatRamoVehiculo);

                    if (EsCondEspecial && !aplicaCondicionEspecial && item.Item1.Codigo == "4022")
                    {
                        aplicaCondicionEspecial = true;
                        item.Item1.SumaAsegurada = "0";
                    }

                    if ((EsCondEspecial && aplicaCondicionEspecial) || !EsCondEspecial)
                        switch (item.Item1.Cobertura.Trim())
                        {
                            case "VALOR COMERCIAL + 10%":
                                {
                                    if ((item.Item1.Codigo == "4000" || item.Item1.Codigo == "4001") && cotizacionauto.ValorFactura)
                                        emision.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = "F", COD_FRANQUICIA = Convert.ToInt32(Convert.ToDouble(item.Item1.Deducible) * 100).ToString() });
                                    else
                                        emision.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = "C10", COD_FRANQUICIA = Convert.ToInt32(Convert.ToDouble(item.Item1.Deducible) * 100).ToString() });
                                }
                                break;
                            case "VALOR COMERCIAL":
                                {
                                    if ((item.Item1.Codigo == "4000" || item.Item1.Codigo == "4001") && cotizacionauto.ValorFactura)
                                        emision.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = "F", COD_FRANQUICIA = Convert.ToInt32(Convert.ToDouble(item.Item1.Deducible) * 100).ToString() });
                                    else
                                        emision.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = "C", COD_FRANQUICIA = Convert.ToInt32(Convert.ToDouble(item.Item1.Deducible) * 100).ToString() });
                                }
                                break;
                            case "":
                                if (item.Item1.Codigo == "4000" || item.Item1.Codigo == "4001")
                                {

                                    emision.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = item.Item1.SumaAsegurada, COD_FRANQUICIA = "0" });
                                }
                                else
                                    emision.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = item.Item1.SumaAsegurada });
                                break;
                            case "VALOR CONVENIDO":
                            case "AMPARADA":
                            case "POR EVENTO":
                                {
                                    emision.COBERTURAS.Add(new Mapfre.Entidades.Comunes.Request.Cobertura { ID = item.Item2, COD_COB = item.Item1.Codigo, SUMA_ASEG = item.Item1.SumaAsegurada });
                                }
                                break;
                        }
                }

                rastreo = "FIN COBERTURAS";
                #endregion

                var service = new wsMapfre.CatalogosAutosSoapClient();
                string xmlRequest = emision.ToString();

                rastreo = "VALOR FACTURA";

                if (!string.IsNullOrEmpty(emision.DATOS_POLIZA.NUM_TARJETA))
                {
                    emision.DATOS_POLIZA.NUM_TARJETA = "***************";
                    emision.DATOS_POLIZA.TIP_TARJETA = "*";
                    emision.DATOS_POLIZA.COD_GESTOR = "****";
                    emision.DATOS_POLIZA.TIP_GESTOR = "**";
                    emision.DATOS_POLIZA.FEC_CORTE = "00/00/0000";
                    emision.DATOS_POLIZA.COD_ENTIDAD = "****";
                    emision.DATOS_POLIZA.COD_OFICINA = "****";

                }



                xmlRequestToSave = emision.ToString();
                rastreo = "XML SAVE " + xmlRequestToSave.Replace("\n", "").Replace("\r", "");
                log.Info("MAPFRE EMISIÓN REQUEST: " + xmlRequestToSave.Replace("\n", "").Replace("\r", ""));
                var response = service.WS_TW_AEmite(xmlRequest, MAPFRE_TOKEN);
                responseXMl = response.OuterXml;

				Mapfre.Entidades.EmisionResponse emisionResponse = MapEmision(response.OuterXml);

                #region Lecutura Respuesta
                if (emisionResponse.xml.param.result == false)
                {
                    rastreo = "ERROR EN LA EMISION";

                    log.Error("Error Mapfre-Flotilla Request: " + xmlRequestToSave.Replace("\n", "").Replace("\r", ""));
                    log.Error("Error Mapfre-Flotilla Response: " + response.OuterXml.Replace("\n", "").Replace("\r", ""));

					GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlRequestToSave, response.OuterXml, emisionResponse.xml.param.error, "Emisión");
					result = new EmisionPoliza(false, xmlRequestToSave, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde." + emisionResponse.xml.param.error, null);
                }
                else
                {
                    rastreo = "EMISION CORRECTA";
                    log.Error("Mapfre-Flotilla Response: " + response.OuterXml.Replace("\n", "").Replace("\r", ""));

                    Poliza poliza = new Poliza();
                    PolizaDetalle polizaDet = new PolizaDetalle();

                    Endoso endosoAlta = new Endoso();
                    endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                    endosoAlta.Fecha = DateTime.Now;
                    endosoAlta.ValorAnterior = "Alta";
                    endosoAlta.ValorActual = "Contratación";

                    rastreo = "ENDOSO";

                    decimal primaNeta = decimal.Parse(QuitaCaracteres(emisionResponse.xml.data.PrimasPoliza.PrimaNeta));
                    decimal primaTotal = decimal.Parse(QuitaCaracteres(emisionResponse.xml.data.PrimasPoliza.PrimaTotal));
                    decimal derechos = decimal.Parse(QuitaCaracteres(emisionResponse.xml.data.PrimasPoliza.Derecho));
                    decimal impuestos = decimal.Parse(QuitaCaracteres(emisionResponse.xml.data.PrimasPoliza.IVA));
                    decimal recargo = decimal.Parse(QuitaCaracteres(emisionResponse.xml.data.PrimasPoliza.Recargo));
                    decimal primerPago = decimal.Parse(QuitaCaracteres(emisionResponse.xml.data.Recibos[0].PrimaTotal));
                    decimal pagoSubsecuente = decimal.Parse(QuitaCaracteres(emisionResponse.xml.data.Recibos.Count > 1 ? emisionResponse.xml.data.Recibos[1].PrimaTotal : "0.0"));
                    if (InfoEmision.EmisionPersonaMoral)
                    {
                        poliza.IdPersonaMoral = InfoEmision.PersonaMoral.Id;
                        poliza.IdRepresentanteLegal = InfoEmision.PersonaMoralRepresentanteLegal.Id;

                    }

                    rastreo = "DECIMALES";

                    poliza.NumeroPoliza = emisionResponse.xml.data.PrimasPoliza.Poliza;
                    poliza.FinVigencia = DateTime.ParseExact(FinVigencia, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                    poliza.InicioVigencia = DateTime.ParseExact(InicioVigencia, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None);

                    poliza.PrimaNeta = primaNeta;
                    poliza.PrimaNetaAnualizada = primaNeta;
                    poliza.PrimaTotal = primaTotal;
                    poliza.PrimaTotalAnualizada = primaTotal;

                    poliza.Motor = InfoEmision.NumeroMotor;
                    poliza.Serie = InfoEmision.NumeroSerie;
                    poliza.Placas = InfoEmision.Placas;
                    poliza.FechaEmision = DateTime.Now;
                    poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                    poliza.UrlPDFPoliza = "";
                    poliza.UrlPDFRecibos = "";
                    poliza.Estatus = 1;
                    poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                    poliza.IdConvenio = InfoEmision.Convenio.Id;
                    poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                    poliza.IdTipoCobertura = tipoPaquete.IdCatTipoPaquete;
                    poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
                    poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                    poliza.Acepto_DescuentoPoliza = true;

                    rastreo = "POLIZA";

                    polizaDet.Inciso = "1";
                    polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para Mapfre.
                    polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                    polizaDet.Deducible = 0;
                    polizaDet.Comision = 0;
                    polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
                    polizaDet.MigraOPERA = false;
                    polizaDet.UrlPDFPolizaOPERA = "";
                    polizaDet.PolizaOPERA = 0;
                    polizaDet.OTOpera = 0;
                    polizaDet.EndosoOPERA = 0;
                    polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                    polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;
                    polizaDet.IdCatRamoVehiculo = Convert.ToInt32(InfoEmision.CotizacionAutoGuardar.TipoVehiculo);// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                    polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                    polizaDet.IdCatModalidadFormaPago = medioPago.Id;
                    polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
                    polizaDet.XMLRecepcion = response.OuterXml;
                    polizaDet.XMLSolicitud = xmlRequestToSave;
                    polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;
                    poliza.UrlPDFPoliza = ImprimePoliza(poliza.NumeroPoliza);

                    rastreo = "DETALLE";

                    List<Recibo> recibosGenerados = new List<Recibo>();
                    foreach (var recibo in emisionResponse.xml.data.Recibos)
                    {
                        Recibo reciboSave = new Recibo();
                        reciboSave.InicioVigencia = DateTime.ParseExact(recibo.FechaInicio.Substring(0, 10), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None); ;
                        reciboSave.FinVigencia = DateTime.ParseExact(recibo.FechaTermino.Substring(0, 10), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None); ;
                        reciboSave.Numero = Convert.ToInt32(recibo.Serie.Split('/')[0]);
                        reciboSave.NoAsegurado = "1";
                        reciboSave.PrimaNeta = decimal.Parse(QuitaCaracteres(recibo.PrimaNeta));
                        reciboSave.PrimaTotal = decimal.Parse(QuitaCaracteres(recibo.PrimaTotal));
                        reciboSave.Derecho = decimal.Parse(QuitaCaracteres(recibo.Derecho));
                        reciboSave.Recargo = decimal.Parse(QuitaCaracteres(recibo.Recargo));
                        reciboSave.Comision = decimal.Parse(QuitaCaracteres(recibo.Comision));
                        reciboSave.Impuesto = decimal.Parse(QuitaCaracteres(recibo.IVA));
                        recibosGenerados.Add(reciboSave);
                    }
                    rastreo = "RECIBOS";

                    endosoAlta.Recibo = recibosGenerados;
                    poliza.Endoso.Add(endosoAlta);
                    poliza.PolizaDetalle.Add(polizaDet);
                    db.Poliza.Add(poliza);
                    db.SaveChanges();

                    rastreo = "GUARDADO";

					GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlRequestToSave, response.OuterXml,"", "Emisión");

                    Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                    result = new EmisionPoliza(true, xmlRequestToSave, response.OuterXml, poliza);
                }
                #endregion
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente para realizar tu emision {0} -- {1}", rastreo, ex.Message));
				GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlRequestToSave, responseXMl, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");
				//throw new Exception(string.Format("Tuvimos un inconveniente para realizar tu emision {0} -- {1}", rastreo, ex.Message));
				result = new EmisionPoliza(false, xmlRequestToSave, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde." + ex.Message, null);
			}
            return result;
        }

        private Mapfre.Entidades.EmisionResponse MapEmision(string strxml)
        {
            Mapfre.Entidades.EmisionResponse response = new Mapfre.Entidades.EmisionResponse();

            response.xml = Deserialize<Mapfre.Entidades.Comunes.Response.Emision.xml>(strxml);
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(strxml);

            if (response.xml == null || response.xml.param == null)
            {
                response.xml = new Mapfre.Entidades.Comunes.Response.Emision.xml();
                response.xml.param = new Mapfre.Entidades.Comunes.Response.ResponseBase();
                response.xml.param.error = "";
                response.xml.param.result = false;
            }
            if (!response.xml.param.result)
            {
                var aditionalError = "";
                try
                {
                    aditionalError = doc.SelectSingleNode("xml/data").InnerText;

                }
                catch (Exception ex)
                {
                    aditionalError = "";
                }
                response.xml.param.error = response.xml.param.error.Replace("\n", "") + "  " + aditionalError.Replace("\n", "");
            }

            return response;
        }

        private string ObtenerCodigoProvincia(string idEstado, string Municipio, string TipoVhiculo)
        {
            string result = string.Empty;

            try
            {
                List<Mapfre.Entidades.Comunes.Response.Poblacion.Provincias> provincias = new List<Mapfre.Entidades.Comunes.Response.Poblacion.Provincias>();

                string MAPFRE_TOKEN = db.CatParametro.Where(x => x.Clave.Equals("MAPFRE_TOKEN")).FirstOrDefault().Valor;//"d0c95921-186d-4ae5-a563-deab50d1f158";//
                byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(Municipio.ToUpper());
                string cleanText = System.Text.Encoding.UTF8.GetString(bytes);
                var service = new wsMapfre.CatalogosAutosSoapClient();
                string CDO_RAMO = TipoVhiculo.Contains("AUTO (PARTICULAR)") ? "401" : TipoVhiculo.Contains("MOTO (PARTICULAR)") ? "403" : TipoVhiculo.Contains("PICK UP (PARTICULAR)") ? "405" : "401";
                //XElement root = new XElement("XML");
                //root.Add(new XElement("DATA", new XElement("VALOR", new XAttribute("COD_ESTADO", idEstado), new XAttribute("COD_RAMO", "401"))));
                string xmlRequest = string.Format("<XML><DATA><VALOR COD_ESTADO=\"{0}\" COD_RAMO=\"{1}\"/></DATA></XML>", idEstado, CDO_RAMO);
                log.Info("XML MAPFRE ObtenerCodigoProvincia Request  " + xmlRequest);
                var provinciasResponse = service.WS_TW_Poblaciones(xmlRequest, MAPFRE_TOKEN);
                log.Info("XML MAPFRE ObtenerCodigoProvincia Resposne  " + provinciasResponse.OuterXml);
                XmlDocument provinciasXML = new XmlDocument();
                provinciasXML.LoadXml(provinciasResponse.OuterXml);

                foreach (var element in provinciasXML.GetElementsByTagName("lista"))
                {
                    var obj = (element as XmlNode);
                    provincias.Add(new Mapfre.Entidades.Comunes.Response.Poblacion.Provincias
                    {
                        Codigo = obj.SelectNodes("COD_PROV").Item(0).InnerText,
                        Nombre = obj.SelectNodes("NOM_PROV").Item(0).InnerText
                    });
                }
                log.Info("ObtenerCodigoProvincia municipio " + cleanText);
                var provincia = provincias.Where(x => x.Nombre.ToUpper().Equals(cleanText)).FirstOrDefault();

                if (provincia == null)
                    provincia = provincias.FirstOrDefault();

                result = (provincia == null) ? "0": provincia.Codigo;
            }
            catch (Exception ex)
            {
                log.Info("se generó excepción ObtenerCodigoProvincia error: " + ex.ToString());
                throw new Exception("Hubo un error de intermitencia, favor de intentarlo mas tarde");
               
                //result = "0";
            }

            return result;
        }

       
        public string ImprimePoliza(string poliza)
        {

            var user = db.CatParametro.FirstOrDefault(a => a.Clave == "MAPFRE_TOKEN_VIPII_USR");
            var url = db.CatParametro.FirstOrDefault(a => a.Clave == "MAPFRE_URL_POLIZA");
            var token = GeneraTokenVIPII(user.Valor);
            return string.Format(url.Valor, poliza, token);

        }

        public string ImprimePolizaEndoso(string poliza)
        {

            var user = db.CatParametro.FirstOrDefault(a => a.Clave == "MAPFRE_TOKEN_VIPII_USR");
            var url = db.CatParametro.FirstOrDefault(a => a.Clave == "MAPFRE_URL_POLIZA_ENDOSO");
            var token = GeneraTokenVIPII(user.Valor);
            return string.Format(url.Valor, poliza, token);

        }

        private string GeneraTokenVIPII(string usuario)
        {
            try
            {
                var token = "";
                var service = new MapfreToken.AppTokenSoapClient();
                var response = service.ObtenToken_ws(usuario);
                if (response.Name == "TokenGenerado")
                {
                    token = response.InnerText;
                }
                else
                {
                    var generate = service.GeneraToken_ws(usuario);
                    token = generate.InnerText;
                }
                return token;
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente al generar Token GeneraTokenVIPII {0}", ex.Message));
                throw;
            }

        }
        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }
        private string QuitaCaracteres(string numero)
        {
            return numero.Replace(",", "").Replace("$", "");
        }

        private List<Tuple<Coberturas, string>> ObtenerCoberturas(int idConvenio, int idPaquete, string amis, int year, int idEmpresa, int IdCatRamoVehiculo, bool EsCotizacion = true, bool EsMoto = false)
        {
            List<Tuple<Coberturas, string>> result = new List<Tuple<Coberturas, string>>();

            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                var coberturas = (from a in db.PaqueteDetalle
                                  join b in db.Cobertura on a.IdCobertura equals b.Id
                                  join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                  where c.IdConvenio == idConvenio && a.IdCatTipoPaquete == idPaquete && c.IdCatRamoVehiculo == IdCatRamoVehiculo
                                  select new Coberturas()
                                  {
                                      Codigo = b.Clave.Replace("\r\n", ""),
                                      Deducible = a.Deducible > 0 ? (a.Deducible / 100).ToString() : string.Empty,
                                      Nombre = b.Descripcion.Replace("\r\n", ""),
                                      SumaAsegurada = a.SumaAsegurada,
                                      Cobertura = a.Descripcion.Replace("\r\n", ""),
                                      IdCatRamo = c.IdCatRamoVehiculo,
                                      IdCobertura = b.Id,
                                      IdTipoDatoDeducible = a.IdTipoDatoDeducible ??1

                                  }).ToList();

                #region map
                List<Tuple<string, string>> coberturasMapfre = new List<Tuple<string, string>>();
                if (!EsCotizacion)
                {
                    //EMISION
                    coberturasMapfre.Add(new Tuple<string, string>("4000", ""));
                    coberturasMapfre.Add(new Tuple<string, string>("4001", "51"));
                    coberturasMapfre.Add(new Tuple<string, string>("4010", "52"));
                    coberturasMapfre.Add(new Tuple<string, string>("4011", "53"));
                    coberturasMapfre.Add(new Tuple<string, string>("4006", "54"));
                    coberturasMapfre.Add(new Tuple<string, string>("4003", "55"));
                    coberturasMapfre.Add(new Tuple<string, string>("4004", "56"));
                    coberturasMapfre.Add(new Tuple<string, string>("4012", "57"));
                    coberturasMapfre.Add(new Tuple<string, string>("4015", "58"));
                    coberturasMapfre.Add(new Tuple<string, string>("4013", "59"));
                    coberturasMapfre.Add(new Tuple<string, string>("4022", "60"));
                    coberturasMapfre.Add(new Tuple<string, string>("4023", "61"));
                    coberturasMapfre.Add(new Tuple<string, string>("4024", "62"));
                    coberturasMapfre.Add(new Tuple<string, string>("4027", "63"));
                    coberturasMapfre.Add(new Tuple<string, string>("4028", "64"));
                    coberturasMapfre.Add(new Tuple<string, string>("4048", "65"));
                    coberturasMapfre.Add(new Tuple<string, string>("4007", "66"));
                    coberturasMapfre.Add(new Tuple<string, string>("4005", "67"));
                    coberturasMapfre.Add(new Tuple<string, string>("4014", "68"));
                    coberturasMapfre.Add(new Tuple<string, string>("4053", "69"));
                    coberturasMapfre.Add(new Tuple<string, string>("4054", "70"));
                    coberturasMapfre.Add(new Tuple<string, string>("4055", "71"));
                    coberturasMapfre.Add(new Tuple<string, string>("4056", "72"));
                    coberturasMapfre.Add(new Tuple<string, string>("4057", "73"));
                    coberturasMapfre.Add(new Tuple<string, string>("4065", "74"));
                    coberturasMapfre.Add(new Tuple<string, string>("4050", "75"));
                    coberturasMapfre.Add(new Tuple<string, string>("4068", "76"));

                    //
                    //coberturasMapfre.Add(new Tuple<string, string>("4054", "72"));
                    //coberturasMapfre.Add(new Tuple<string, string>("4049", "75"));
                }
                else
                {
                    //COTIZACION
                    coberturasMapfre.Add(new Tuple<string, string>("4000", ""));
                    coberturasMapfre.Add(new Tuple<string, string>("4001", "24"));
                    coberturasMapfre.Add(new Tuple<string, string>("4010", "25"));
                    coberturasMapfre.Add(new Tuple<string, string>("4011", "26"));
                    coberturasMapfre.Add(new Tuple<string, string>("4006", "27"));
                    coberturasMapfre.Add(new Tuple<string, string>("4003", "28"));
                    coberturasMapfre.Add(new Tuple<string, string>("4004", "29"));
                    coberturasMapfre.Add(new Tuple<string, string>("4012", "30"));
                    coberturasMapfre.Add(new Tuple<string, string>("4015", "31"));
                    coberturasMapfre.Add(new Tuple<string, string>("4013", "32"));
                    coberturasMapfre.Add(new Tuple<string, string>("4022", "33"));
                    coberturasMapfre.Add(new Tuple<string, string>("4023", "34"));
                    coberturasMapfre.Add(new Tuple<string, string>("4024", "35"));
                    coberturasMapfre.Add(new Tuple<string, string>("4027", "36"));
                    coberturasMapfre.Add(new Tuple<string, string>("4028", "37"));
                    coberturasMapfre.Add(new Tuple<string, string>("4048", "38"));
                    coberturasMapfre.Add(new Tuple<string, string>("4007", "39"));
                    coberturasMapfre.Add(new Tuple<string, string>("4068", "44"));
                    coberturasMapfre.Add(new Tuple<string, string>("4005", "48"));
                    coberturasMapfre.Add(new Tuple<string, string>("4014", "49"));
                    coberturasMapfre.Add(new Tuple<string, string>("4053", "50"));
                    coberturasMapfre.Add(new Tuple<string, string>("4054", "51"));
                    coberturasMapfre.Add(new Tuple<string, string>("4055", "52"));
                    coberturasMapfre.Add(new Tuple<string, string>("4056", "53"));
                    coberturasMapfre.Add(new Tuple<string, string>("4057", "54"));
                    coberturasMapfre.Add(new Tuple<string, string>("4065", "55"));
                    coberturasMapfre.Add(new Tuple<string, string>("4050", "57"));

                    //coberturasMapfre.Add(new Tuple<string, string>("4049", "51"));
                    //coberturasMapfre.Add(new Tuple<string, string>("4005", "48"));
                    //coberturasMapfre.Add(new Tuple<string, string>("4054", "51"));
                    //coberturasMapfre.Add(new Tuple<string, string>("4055", "52"));
                    //coberturasMapfre.Add(new Tuple<string, string>("4056", "53"));
                    //coberturasMapfre.Add(new Tuple<string, string>("4057", "54"));
                }

                foreach (var item in coberturasMapfre)
                {
                    var agregar = true;

                    var cobertura = coberturas.Where(x => x.Codigo.Equals(item.Item1)).FirstOrDefault();

                    if (idPaquete == 4 && item.Item1 == "4003")
                        agregar = false;

                    if (cobertura == null && item.Item1 == "4048")
                        agregar = false;

                    if (cobertura == null && item.Item1 == "4014")
                        agregar = false;

                    if (cobertura == null && item.Item1 == "4065")
                        agregar = false;

                    if (cobertura == null && item.Item1 == "4053")
                        agregar = false;
                    if (cobertura == null && item.Item1 == "4057")
                        if (EsMoto)
                            agregar = false;
                    if (cobertura == null && item.Item1 == "4050")
                        if (!EsMoto)
                            agregar = false;
                    if (agregar)
                    {
                        if (cobertura == null)
                            cobertura = new Coberturas { Codigo = item.Item1, SumaAsegurada = "0" };
                        else if (cobertura.Codigo == "4022")
                        {
                            var roboparcial = db.CoberturaMAPFRERoboParcial.FirstOrDefault(a => a.Amis == amis && a.IdEmpresa == idEmpresa && a.Year == year);
                            if (roboparcial != null)
                                cobertura.SumaAsegurada = roboparcial.SumaAsegurada.ToString();

                        }

                        if (cobertura.Codigo == "4003"
                                || cobertura.Codigo == "4004"
                                || cobertura.Codigo == "4014"
                                || cobertura.Codigo == "4065"
                                || cobertura.Codigo == "4053"
                            || cobertura.Codigo == "4048")
                            cobertura.SumaAsegurada = "1";

                        result.Add(new Tuple<Coberturas, string>(cobertura, item.Item2));
                    }

                }
                #endregion
            }

            return result;
        }

        private DatosVehiculo ObtenerDatosVehiculo(string clave)
        {
            DatosVehiculo result = new DatosVehiculo();

            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["CatalogoHomologado"].ToString()))
            {
                using (SqlCommand cmd = new SqlCommand("spConsultaMAPFRE", connection))
                {
                    SqlParameter amis = new SqlParameter("@IdMapfre", clave);

                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(amis);
                    connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            result.IdMarca = Convert.ToString(dr["IdMarca"]);
                            result.IdModelo = Convert.ToString(dr["IdModelo"]);
                            result.IdTipoVehiculo = Convert.ToString(dr["IdTipoVehiculo"]);
                        }
                    }

                    connection.Close();
                }
            }

            return result;
        }

        private string ObtenerCodigoEstado(string codigoPostal)
        {
            string result = string.Empty;

            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                var estado = db.CatCodigoPostal.Where(x => x.Codigo.Equals(codigoPostal.Trim())).FirstOrDefault();
                result = (estado == null) ? "999" : estado.IdEstado.ToString();
            }

            switch (result)
            {
                case "7": result = "5"; break;
                case "8": result = "6"; break;
                case "5": result = "7"; break;
                case "6": result = "8"; break;
                case "32": result = "9"; break;
                case "9": result = "10"; break;
                case "10": result = "11"; break;
                case "11": result = "12"; break;
                case "12": result = "13"; break;
                case "13": result = "14"; break;
                case "14": result = "15"; break;
                case "15": result = "16"; break;
                case "16": result = "17"; break;
                case "17": result = "18"; break;
                case "18": result = "19"; break;
                case "19": result = "20"; break;
                case "20": result = "21"; break;
                case "21": result = "22"; break;
                case "22": result = "23"; break;
                case "23": result = "24"; break;
                case "24": result = "25"; break;
                case "25": result = "26"; break;
                case "26": result = "27"; break;
                case "27": result = "28"; break;
                case "28": result = "29"; break;
                case "29": result = "30"; break;
                case "30": result = "31"; break;
                case "31": result = "32"; break;
            }

            return result;
        }

        #region LINK DE PAGO

        public EstatusOperacion LinkCobro(DatosLinkCobro datos, int? idRegistro)
        {
            var estatusOperacion = new EstatusOperacion();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
               
                var plantilla = db.LinkPagoPlantilla.First().Contenido;

                SqlParameter numeroPoloza = new SqlParameter("@Poliza", datos.NumeroPoliza);

                var datosPoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", numeroPoloza).FirstOrDefault();

                plantilla = plantilla.Replace("[Aseguradora]", "MAPFRE");
                plantilla = plantilla.Replace("[URLLinkPago]", "https://zonaliados.mapfre.com.mx/cobranzaii/Gestion/Linea/LineaCBPublic.aspx");
                plantilla = plantilla.Replace("[Negocio]", datosPoliza.Gerencia);
                plantilla = plantilla.Replace("[NumeroDePoliza]", datos.NumeroPoliza);
                plantilla = plantilla.Replace("[Vehiculo]", $"{datosPoliza.Marca} {datosPoliza.Modelo} {datosPoliza.Version}");


                var email = new LocktonServicios.Services.EnvioEmail.ServicioEmail();

                email.EnviarEmail(new List<string>() { datos.Email }, $"Link de Pago {datos.NumeroPoliza}", plantilla, null);

                urlMethod = "https://zonaliados.mapfre.com.mx/cobranzaii/Gestion/Linea/LineaCBPublic.aspx";
                jsonResponse = datos.Email;
                jsonRequest = plantilla;

                estatusOperacion.Exitoso = true;
                

            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado Link de Pago Mapfre: " + ex.Message, ex);

                estatusOperacion.Mensaje = ex.Message;
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                estatusOperacion.Exitoso = false;
                estatusOperacion.EsReintentable = false;
                estatusOperacion.MensajeCatalogo = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            if (idRegistro.HasValue)
            {
                var registro = db.LinkPagoMasivo_Poliza.FirstOrDefault(a => a.Id == idRegistro);

                registro.Error = estatusOperacion.MensajeCatalogo;
                registro.URL = urlMethod;
                registro.Response = jsonResponse;
                registro.Request = jsonRequest;

                db.SaveChanges();
            }

            RegistraOPL(datos.NumeroPoliza, jsonRequest, jsonResponse, "Link de Cobro", 5, estatusOperacion.Exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datos.NumeroPoliza) == true ? "Online" : "Tradicional");

            log.Info(string.Format("Termina proceso de generacion de link de pago de la poliza: {0}", datos.NumeroPoliza));

            return estatusOperacion;
        }


        private void RegistraOPL(string numeroPoliza, string xml, string respuesta, string tipo, int idTipo, bool exitoso, string TipoPoliza, int IdCatalogoError = 0)
        {
            try
            {
                using (var _db = new ApplicationDbContext())
                {
                    var oplRegistro = new PolizaRegistroCobranza();
                    oplRegistro.Exitoso = exitoso;
                    oplRegistro.Fecha = DateTime.Now;
                    oplRegistro.FechaResponse = DateTime.Now;
                    oplRegistro.IdTipoOPL = idTipo;
                    oplRegistro.NumeroPoliza = numeroPoliza;
                    oplRegistro.Response = respuesta;
                    oplRegistro.TipoOPL = tipo;
                    oplRegistro.Request = xml;
                    oplRegistro.TipoPoliza = TipoPoliza;
                    oplRegistro.IdCatalogoErrorInstalacionDatosBancarios = IdCatalogoError;
                    oplRegistro.IdAseguradora = 5;
                    _db.PolizaRegistroCobranza.Add(oplRegistro);
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado RegistraOPL Qualitas: " + ex.Message, ex);
            }
        }

        #endregion
        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }


    }

    public class DatosVehiculo
    {
        public string IdTipoVehiculo { get; set; }
        public string IdMarca { get; set; }
        public string IdModelo { get; set; }
    }
}
