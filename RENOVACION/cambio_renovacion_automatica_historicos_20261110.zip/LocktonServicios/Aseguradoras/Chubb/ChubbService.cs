﻿using com.lockton.xml.aba.cotizacion.request;
using com.lockton.xml.aba.cp.response;
using com.lockton.xml.aba.persona.request;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.Chubb.Cotizacion;
using LocktonModel.Services.Chubb.Emision;
using LocktonModel.Services.Chubb.Security;
using LocktonModel.VModels;
using LocktonModel.xmls.Qualitas.Solicitud;
using LocktonServicios.Catalogos;
using LocktonServicios.OTOperaService;
using LocktonServicios.Utilidades;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Poliza = LocktonModel.db.Poliza;
using Vehiculo = LocktonModel.Services.Chubb.Cotizacion.Vehiculo;
using System.Xml;
using com.lockton.xml.aba.consultadireccion.response;
using com.lockton.xml.aba.consultapersona.request;
using com.lockton.xml.aba.consultapersona.response;
using Endoso = LocktonModel.db.Endoso;
using Recibo = LocktonModel.db.Recibo;
using com.lockton.xml.aba.impresion.response;
using LocktonModel.xmls.AXA;

namespace LocktonServicios.Aseguradoras.Chubb
{
    public class ChubbService : IOperacionesAseguradoras
    {
        public enum Moneda
        {
            MXN = 1
        }

        public enum Periodicidad
        {
            [Description("Contado")]
            Contado = 1,
            [Description("Semestral")]
            Semestral = 2,
            [Description("Trimestral")]
            Trimestral = 3,
            [Description("Mensual")]
            Mensual = 4,
            [Description("Quincenal")]
            Quincenal = 5,
            [Description("Anual Extendida")]
            Anual = 8
        }

        private static readonly ILog log = LogManager.GetLogger(typeof(ChubbService));
        private const string aseguradora = "ABA";

        ApplicationDbContext db = null;
        private Proxy proxy = null;
        bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;

        public ChubbService(string userName = "", string password = "")
        {
            var version = string.Empty;
            var baseUrl = string.Empty;
            var baseUrlSecurity = string.Empty;

            if (string.IsNullOrEmpty(userName))
            {
                userName = Utilidades.Utilidades.ObtienerValorParametro("Proxu_ChubbService_Usuario");
                password = Utilidades.Utilidades.ObtienerValorParametro("Proxu_ChubbService_Password");
            }

            if (!esProduccion)
            {
                //version = ConfigurationManager.AppSettings["ChubbAPIVersion"].ToString();
                //baseUrl = $"{ConfigurationManager.AppSettings["ChubbAPI"].ToString()}{version}";
                //baseUrlSecurity = $"{ConfigurationManager.AppSettings["ChubbAPISecurity"].ToString()c;
                version = $"{Utilidades.Utilidades.ObtienerValorParametro("ChubbAPIVersionTest")}{version}";
                baseUrl = $"{Utilidades.Utilidades.ObtienerValorParametro("ChubbAPITest")}{version}";
                baseUrlSecurity = $"{Utilidades.Utilidades.ObtienerValorParametro("ChubbAPISecurityTest")}{version}";
            }
            else
            {
                version = $"{Utilidades.Utilidades.ObtienerValorParametro("ChubbAPIVersion")}{version}";
                baseUrl = $"{Utilidades.Utilidades.ObtienerValorParametro("ChubbAPI")}{version}";
                baseUrlSecurity = $"{Utilidades.Utilidades.ObtienerValorParametro("ChubbAPISecurity")}{version}";
            }

            db = new ApplicationDbContext();
            var authorize = new Authorize
            {
                client_id = userName,
                client_secret = password,
                grant_type = "client_credential",
                scope = "SEMI"
            };
            proxy = new Proxy(baseUrl, baseUrlSecurity, authorize);
        }


        public CotizacionCompara CotizaVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<LocktonModel.db.PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {
            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
            DateTime fechaCotizacionABA = CotizacionCompara.FechaCotizacion;
            try
            {
                var cotizacionRequest = new CotizacionRequest();
                var inciso = new IncisoRequest();
                var paquete = new PaqueteRequest();
                var coberturas = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, Convert.ToInt32(CotizacionCompara.TipoVehiculo), idPaqueteConvenio);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);

                cotizacionRequest.cotizacionId = 0;
                cotizacionRequest.versionId = 0;
                cotizacionRequest.datosGenerales.agenteId = convenioCotiza.ClaveAgente;
                cotizacionRequest.datosGenerales.negocioId = int.Parse(convenioCotiza.NumeroNegocio);
                cotizacionRequest.datosGenerales.conductoId = convenioCotiza.Conducto;
                cotizacionRequest.datosGenerales.tarifaId = int.Parse(convenioCotiza.Tarifa);
                cotizacionRequest.datosGenerales.agrupacionId = convenioCotiza.Agrupador;
                cotizacionRequest.datosGenerales.inicioVigencia = CotizacionCompara.FechaInicio.ToString("yyyy-MM-dd");
                cotizacionRequest.datosGenerales.finVigencia = CotizacionCompara.FechaFin.ToString("yyyy-MM-dd");
                cotizacionRequest.datosGenerales.monedaId = (int)Moneda.MXN;

                /*TODO:Preguntar Producto Id*/
                cotizacionRequest.datosGenerales.productoId = 1;
                /*TODO:Preguntar Tipo Calculo*/
                cotizacionRequest.datosGenerales.tipoCalculoId = 1;
                /*TODO:Preguntar Dias Gracia*/
                cotizacionRequest.datosGenerales.diasGracia = 30;

#if DEBUG
                /*Valores para pruebas*/
                cotizacionRequest.datosGenerales.agenteId = 93300;
                cotizacionRequest.datosGenerales.negocioId = 7190;
                cotizacionRequest.datosGenerales.agrupacionId = 208802;
#endif

                if (cot.Catalogo.Count() > 0)
                {
                    ConsultaCatalogoHomologado.ObjetoRespuestaBD _descripcion = new ConsultaCatalogoHomologado.ConsultaCatalogoHomologadoClient().NCHConsultaDetalleVehiculo("ABA", cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault().clave);
                    _Descripciones _resultado = JsonConvert.DeserializeObject<_Descripciones>(_descripcion.RespuestaJSON);
                    inciso.vehiculo.claveVehicular = _resultado.Descripciones[0].AMIS;
                }
                else
                {
                    log.Info("No se encontro vehiculo en el catalogo para cotizar.");
                    throw new Exception("No se encontro vehiculo para cotizar.");
                }

                var CodigoPostal = ConveniosPaquetes.Empresa.Direccion.CodigoPostal;
                if (convenioCotiza.IdCatTipoContratante == 4 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 6)//Si es contratante Individual se pone el CP ingresado en la cotizacion.
                {
                    CodigoPostal = CotizacionCompara.CodigoPostal;
                }
                var localizacion = proxy.ObtenerColonias(int.Parse(CodigoPostal)).responseData.FirstOrDefault();
                //var localizacion = db.CatCPCasa.Where(x => x.CP == CodigoPostal).FirstOrDefault();

                var tipoUsos = proxy.ObtenerTiposUso(cotizacionRequest.datosGenerales.agrupacionId, localizacion.estadoId, int.Parse(convenioCotiza.Tarifa));
                var paquetes = proxy.ObtenerPaquetes(cotizacionRequest.datosGenerales.agrupacionId, int.Parse(CotizacionCompara.Año));
                var formasPago = proxy.ObtenerFormasPago(cotizacionRequest.datosGenerales.agrupacionId, (int)Moneda.MXN);
                var tiposSuma = proxy.ObtenerTipoSumaAsegurada(cotizacionRequest.datosGenerales.agrupacionId, int.Parse(convenioCotiza.Tarifa), int.Parse(CotizacionCompara.Año));
                var tipoSumaAsegurada = "1"; //inicializacion 1

                if (CotizacionCompara.ValorFactura)
                    tipoSumaAsegurada = "3";
                else
                {
                    var coberturaRoboTotal = coberturas.FirstOrDefault(a => a.Codigo == "1");
                    if (coberturaRoboTotal != null)
                    {
                        tipoSumaAsegurada = db.CatTipoSumaAsegVehiculo.FirstOrDefault(x => x.Id == coberturaRoboTotal.TipoSumaAsegurada).Clave;
                    }
                }

                /*Preguntar Genero*/
                inciso.vehiculo.edad = int.Parse(CotizacionCompara.Edad);
                inciso.vehiculo.generoId = CotizacionCompara.Genero.Equals("masculino", StringComparison.InvariantCultureIgnoreCase) ? 1 : 0;
                inciso.vehiculo.estadoId = localizacion.estadoId;
                inciso.vehiculo.municipioId = localizacion.municipioId;
                inciso.vehiculo.codigoPostal = int.Parse(CodigoPostal);
                inciso.vehiculo.modelo = int.Parse(CotizacionCompara.Año);
                inciso.vehiculo.usoId = convenioCotiza.IdCatUsoVehiculo;
                inciso.vehiculo.tipoSumaAseguradaId = Convert.ToInt32(tipoSumaAsegurada); //tiposSuma.responseData.Where(x => x.typeAmountInsuredId.Equals(convenioCotiza.SumaAsegurada, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault().typeAmountInsuredId;


                //var ramo = int.Parse(convenioCotiza.RamoVehiculo);
                ConvenioRamoPaquete CRP = db.ConvenioRamoPaquete.Where(cr => cr.IdConvenio == convenioCotiza.Id && cr.IdCatRamoVehiculo == paqueteConvenio.IdCatRamoVehiculo).FirstOrDefault();
                inciso.porcentajeDescuento = CRP.Descuento;
                inciso.porcentajeBonificacion = 0;
                inciso.tipoRiesgoId = 2;
                var paq = ConveniosPaquetes.PaqueteAseguradoras.FirstOrDefault(x => x.IdAseguradora == convenioCotiza.IdAseguradora && x.IdCatTipoPaquete == IdTipoPaquete).Clave;
                //TODO:Revisar Datos                
                inciso.paquetes.Add(new PaqueteRequest { id = int.Parse(paq) });
                cotizacionRequest.incisos.Add(inciso);

                /*Formas de pago*/
                int formaPago = CotizacionCompara.FormadePago;
                PeriodicidadFormaPago perioricidadFP = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioCotiza.Id && x.IdCatPeriodicidadFormaPago == formaPago).FirstOrDefault();
                ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == convenioCotiza.IdEmpresa);

                if (configuracionEmpresa.AplicaMultiAnual)
                {
                    CatPeriodicidadFormaPago catperdioricidad = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == perioricidadFP.IdCatPeriodicidadFormaPago);
                    if (catperdioricidad != null)
                        cotizacionRequest.datosGenerales.finVigencia = CotizacionCompara.FechaInicio.AddYears(catperdioricidad.ValorMultiAnual).ToString("yyyy-MM-dd");
                }
                //TODO:Revisar datos
                int _formaPago = formasPago.responseData.Where(x => x.descripcion.Trim().Equals(GetEnumDescription(((Periodicidad)CotizacionCompara.FormadePago)), StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault().id;
                cotizacionRequest.datosGenerales.formasPago.Add(new FormaPagoRequest { id = _formaPago });
                /*End formas de pago*/

                var cotizacionResult = proxy.Cotizar(cotizacionRequest);

                var xmlEnvio = ObjectSerializer<CotizacionRequest>.Serialize(cotizacionRequest);
                var xmlRespuesta = ObjectSerializer<CotizacionResponse>.Serialize(cotizacionResult);

                var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == CotizacionCompara.FormadePago).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);

                var cotizacion = new Comparar();

                cotizacion = LeeXmlRespuesta(xmlRespuesta, xmlEnvio, convenioCotiza);
                cotizacion.IdPaqueteConvenio = idPaqueteConvenio;
                cotizacion.NombrePaqueteConvenio = $"{paqueteConvenio.NombrePaquete} - API";
                cotizacion.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                cotizacion.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                cotizacion.Cobertura = CotizacionCompara.Cobertura.ToString();

                CotizacionCompara.Comparar.Add(cotizacion);

            }
            catch (Exception ex)
            {
                log.Info(string.Format("Error en cotizacion: {0}", ex.Message));
                string mensaje = ex.Message;
                //CotizacionCompara.Comparar.Add(new Comparar() { ErrorXML = ex.Message, XmlEmision = xmlCotizacion, XmlRespuesta = string.IsNullOrEmpty(xmlResultadoCot) ? "<Error>" + ex.Message + "</Error>" : xmlResultadoCot });
            }

            return CotizacionCompara;
        }
        private string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes = fi.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];

            if (attributes != null && attributes.Any())
            {
                return attributes.First().Description;
            }

            return value.ToString();
        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new NotImplementedException();
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            var emisionPoliza = new EmisionPoliza(false, null, null);

            log.Info("Inicia emision ABA");
            EmisionABA.Token token = new EmisionABA.Token();
            token.usuario = InfoEmision.Convenio.Usuario;
            token.password = InfoEmision.Convenio.Contrasena;
            CotizacionDetalle _cotizacionDetalle = db.CotizacionDetalle.Find(InfoEmision.IdCotizacion);
            Poliza poliza = new Poliza();
            PolizaDetalle polizadetalle = new PolizaDetalle();
            EmisionRequest emisionRequest = new EmisionRequest();
            PersonaABA persona;
            CotizacionResponse cotizacion;
            string strCliente = string.Empty;
            string Rfc = string.Empty;
            string TipoPersona = "0";

            try
            {
                if ((InfoEmision.IdTipoDeNegocio == 5 || InfoEmision.IdTipoDeNegocio == 6))
                {
                    if (InfoEmision.EmisionPersonaMoral)
                    {
                        strCliente = InfoEmision.PersonaMoral.RazonSocial;
                        Rfc = InfoEmision.PersonaMoral.RFC;
                        TipoPersona = "1";
                    }
                    else
                    {

                        strCliente = string.Format("{0} {1} {2} {3}", InfoEmision.PrimerNombre, InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno);
                        Rfc = String.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC) ? LocktonServicios.Utilidades.Utilidades.CalcularRFC(InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno, InfoEmision.FechaNacimiento.ToString("dd/MM/yy")) : InfoEmision.DatosUsuario.RFC;
                        TipoPersona = "0";
                        if (!Utilidades.Utilidades.ValidaRFCHomoclave(Rfc))
                            return new EmisionPoliza(false, null, "Requerimos un RFC con homoclave para continuar con la emisión de tu auto.");

                    }
                }
                else if (InfoEmision.Convenio.IdCatTipoContratante.Equals(4) || InfoEmision.Convenio.IdCatTipoContratante.Equals(2))
                {

                    strCliente = string.Format("{0} {1} {2} {3}", InfoEmision.PrimerNombre, InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno);
                    Rfc = String.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC) ? LocktonServicios.Utilidades.Utilidades.CalcularRFC(InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno, InfoEmision.FechaNacimiento.ToString("dd/MM/yy")) : InfoEmision.DatosUsuario.RFC;
                    TipoPersona = "0";
                    if (!Utilidades.Utilidades.ValidaRFCHomoclave(Rfc))
                        return new EmisionPoliza(false, null, "Requerimos un RFC con homoclave para continuar con la emisión de tu auto.");

                }
                else
                {
                    strCliente = InfoEmision.Empresa.RazonSocial;
                    Rfc = InfoEmision.Empresa.RFC;
                    TipoPersona = "1";
                }

                cotizacion = ToObject<CotizacionResponse>(_cotizacionDetalle.XMLRecepcion);

                log.Info("alta persona  ABA");
                persona = AltaPersonaABA(InfoEmision, InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena, strCliente, Rfc, TipoPersona);
                log.Info("fin alta persona  ABA");

                LocktonModel.Services.Chubb.Emision.Inciso inciso = new LocktonModel.Services.Chubb.Emision.Inciso();
                emisionRequest.versionId = cotizacion.responseData.incisos.FirstOrDefault().paquetes.FirstOrDefault().versionId.Value;
                emisionRequest.cotizacionId = cotizacion.responseData.cotizacionId;
                emisionRequest.formaPagoId = cotizacion.responseData.paquetes.FirstOrDefault().formasPago.FirstOrDefault().id;
                inciso.numeroInciso = cotizacion.responseData.incisos.FirstOrDefault().numeroInciso.Value;
                inciso.paqueteId = cotizacion.responseData.incisos.FirstOrDefault().paquetes.FirstOrDefault().id.Value;
                inciso.vehiculo.referencia = "Emisión";
                inciso.vehiculo.serie = InfoEmision.NumeroSerie.ToUpper();
                inciso.vehiculo.motor = InfoEmision.NumeroMotor.ToUpper();
                inciso.vehiculo.placa = InfoEmision.Placas.ToUpper();
                emisionRequest.incisos.Add(inciso);
                emisionRequest.asegurado.aseguradoId = int.Parse(persona.personaId);
                emisionRequest.asegurado.direccionId = int.Parse(persona.direccionId);
                emisionRequest.asegurado.tranId = int.Parse(persona.transaccionId);

                if (InfoEmision.RequiereFactura)
                {
                    var _facturacion = new LocktonModel.db.Facturacion();

                    emisionRequest.facturacion = new LocktonModel.Services.Chubb.Emision.Facturacion();

                    emisionRequest.facturacion.personalidadJuridicaId = 0;
                    emisionRequest.facturacion.rfc = Rfc;
                    emisionRequest.facturacion.nombre = strCliente;
                    emisionRequest.facturacion.email = InfoEmision.Email;
                    emisionRequest.facturacion.emailComplementoPago = InfoEmision.Email;
                    emisionRequest.facturacion.comentarios = $"Serie {InfoEmision.NumeroSerie}";
                    emisionRequest.facturacion.ordenCompra = "OrdenCompra";


                    if (InfoEmision.EmisionPersonaMoral)
                    {
                        emisionRequest.facturacion.codigoPostal = InfoEmision.PersonaMoral.Direccion.CodigoPostal;

                    }
                    if (TipoPersona == "0" && !InfoEmision.EsFlotilla)
                    {
                        emisionRequest.facturacion.codigoPostal = InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                        emisionRequest.facturacion.regimenFiscalId = InfoEmision.IdRegimenFiscal;
                        emisionRequest.facturacion.usoCFDIId = InfoEmision.IdUsoCFDI;

                    }
                    else
                    {
                        emisionRequest.facturacion.codigoPostal = InfoEmision.Empresa.Direccion.CodigoPostal;
                        emisionRequest.facturacion.regimenFiscalId = InfoEmision.Empresa.IdRegimenFiscal ?? 1;
                        emisionRequest.facturacion.usoCFDIId = InfoEmision.Empresa.IdUsoCFDI ?? 1;
                    }

                    _facturacion.RFC = Rfc;
                    _facturacion.Nombre = strCliente;
                    _facturacion.CodigoPostal = emisionRequest.facturacion.codigoPostal;
                    _facturacion.IdRegimenFiscal = emisionRequest.facturacion.regimenFiscalId;
                    _facturacion.IdUsoCFDI = emisionRequest.facturacion.usoCFDIId;

                    Utilidades.Utilidades.GeneraRegistroFacturacion(_facturacion);

                }

                var emisionResponse = proxy.Emitir(emisionRequest);

                var xmlEnvio = ObjectSerializer<EmisionRequest>.Serialize(emisionRequest);
                var xmlRespuesta = ObjectSerializer<EmisionResponse>.Serialize(emisionResponse);


                poliza = GuardaPoliza(poliza, emisionResponse, InfoEmision, _cotizacionDetalle, polizadetalle, TipoPersona, xmlEnvio, xmlRespuesta);

                Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                return new EmisionPoliza(true, poliza.PolizaDetalle.First().XMLSolicitud, poliza.PolizaDetalle.First().XMLRecepcion, poliza);
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Error al emitir Chubb : {0}", ex.Message));
                Regex reg = new Regex("[*'\",_&#^@]");
                string mensaje = reg.Replace(ex.Message, string.Empty).Replace("\r\n", string.Empty);
                return new EmisionPoliza(false, null, mensaje);
            }
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }

        public Comparar LeeXmlRespuesta(string xmlRespuesta, string xmlEnvio, Convenio convenioCotiza)
        {

            var response = Utilidades.Utilidades.ToObject<CotizacionResponse>(xmlRespuesta);
            var request = Utilidades.Utilidades.ToObject<CotizacionRequest>(xmlEnvio);


            Comparar infoCompara = new Comparar();
            infoCompara.FechaCotizacion = DateTime.ParseExact(request.datosGenerales.inicioVigencia, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            infoCompara.XmlEmision = xmlEnvio;
            infoCompara.XmlRespuesta = xmlRespuesta;
            infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
            infoCompara.IdConvenio = convenioCotiza.Id;
            infoCompara.Aseguradora = "ABA";
            infoCompara.Año = request.incisos[0].vehiculo.modelo.ToString();
            infoCompara.FechaInicio = request.datosGenerales.inicioVigencia;
            infoCompara.FechaFin = request.datosGenerales.finVigencia;


            if (!response.isSuccess)
            {
                infoCompara.ErrorXML = string.Join(", ", response.messages.Select(a => a.message).ToList());

                log.Error("cotizaVehiculo error ABA Request " + xmlEnvio.Replace("\n", "").Replace("\r", ""));
                log.Error("cotizaVehiculo error ABA Response " + xmlRespuesta.Replace("\n", "").Replace("\r", ""));

            }
            else
            {

                var _formasPago = response.responseData.incisos.FirstOrDefault().paquetes.FirstOrDefault().formasPago.FirstOrDefault();
                var _paqueteRespuest = response.responseData.paquetes.FirstOrDefault().formasPago.FirstOrDefault();
                infoCompara.Coberturas = new List<Coberturas>();

                foreach (var cobertura in _formasPago.coberturas)
                {

                    Coberturas cotCob = new Coberturas();

                    cotCob.Cobertura = cobertura.primaNetaMonto.Value.ToString("N2");
                    cotCob.SumaAsegurada = cobertura.sumaAsegurada.Value.ToString("N2");
                    cotCob.Nombre = cobertura.descripcion.Trim();
                    cotCob.Deducible = cobertura.valorDeducible.ToString();
                    cotCob.Codigo = cobertura.id.ToString();

                    infoCompara.Coberturas.Add(cotCob);

                }

                infoCompara.PrimaNeta = _paqueteRespuest.primaNetaMonto.Value.ToString("N2");
                infoCompara.PrimaTotal = _paqueteRespuest.primaTotalMonto.Value.ToString("N2");
                infoCompara.Impuesto = _paqueteRespuest.ivaMonto.Value.ToString("N2");

                infoCompara.Derecho = _paqueteRespuest.derechoMonto.Value.ToString("N2");
                infoCompara.Recargo = _paqueteRespuest.recargoMonto.Value.ToString("N2");
                //infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();
                infoCompara.PrimerPago = _formasPago.recibos.FirstOrDefault(a => a.numero == 1).primaTotalMonto.Value.ToString("N2");
                infoCompara.NumeroDePagos = _formasPago.recibos.Count();
                infoCompara.SegundoPago = _formasPago.recibos.Count() > 1 ? _formasPago.recibos.FirstOrDefault(a => a.numero != 1).primaTotalMonto.Value.ToString("N2") : "";
                infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;

            }

            return infoCompara;
        }

        private List<Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete, int IdTipoVehiculo, int idPaqueteConvenio)
        {

            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio
                                           && a.IdCatTipoPaquete == idPaquete
                                           && c.IdCatRamoVehiculo == IdTipoVehiculo
                                           && a.IdPaqueteConvenio == idPaqueteConvenio
                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", ""),
                                               IdCatRamo = c.IdCatRamoVehiculo,
                                               IdCobertura = b.Id,
                                               TipoSumaAsegurada = a.TipoSumaAsegurada
                                           }).ToList();
            return coberturas;
        }

        private Poliza GuardaPoliza(Poliza poliza, EmisionResponse polizaEmitida, InformacionEmision InfoEmision, CotizacionDetalle _cotizacionDetalle, PolizaDetalle polizaDet, string tipoContribuyente, string xmlRequest, string xmlResponse)
        {
            log.Info("Comienza guardado de poliza Chubb");
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            Cotizacion Cotizacion = db.Cotizacion.Where(x => x.Id == InfoEmision.IdCotizacion).FirstOrDefault();

            int paquete = int.Parse(_cotizacionDetalle.Paquete);
            string medioPago = InfoEmision.CotizacionAutoGuardar.MediodePago.ToString();
            string formaPago = InfoEmision.CotizacionAutoGuardar.FormadePago.ToString();
            string Solicitud = _cotizacionDetalle.XMLSolicitud;
            string Recepcion = _cotizacionDetalle.XMLRecepcion;

            CotizacionRequest cot = ToObject<CotizacionRequest>(Solicitud);
            CotizacionResponse cotResult = ToObject<CotizacionResponse>(Recepcion);

            try
            {
                poliza.NumeroPoliza = String.Format("{0}{1}", polizaEmitida.responseData[0].clave, polizaEmitida.responseData[0].polizaId);
                poliza.PrimaNeta = Convert.ToDecimal(polizaEmitida.responseData[0].primaNetaMto);
                poliza.PrimaTotal = Convert.ToDecimal(polizaEmitida.responseData[0].primaTotalMto);
                poliza.Motor = InfoEmision.NumeroMotor;
                poliza.Serie = InfoEmision.NumeroSerie;
                poliza.Placas = InfoEmision.Placas;
                poliza.FinVigencia = Convert.ToDateTime(cot.datosGenerales.finVigencia);
                poliza.InicioVigencia = Convert.ToDateTime(cot.datosGenerales.inicioVigencia);
                poliza.FechaEmision = DateTime.Now;
                poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                poliza.UrlPDFPoliza = "";
                poliza.UrlPDFRecibos = "";
                poliza.Estatus = 20;
                poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                poliza.IdTipoCobertura = paquete;
                poliza.IdConvenio = InfoEmision.Convenio.Id;
                poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                poliza.Acepto_DescuentoPoliza = true;

                polizaDet.XMLSolicitud = xmlRequest;
                polizaDet.XMLRecepcion = xmlResponse;
                polizaDet.Inciso = "1";
                polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para Chubb.
                polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                polizaDet.Deducible = 0;
                polizaDet.Comision = 0;
                polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
                polizaDet.MigraOPERA = false;
                polizaDet.UrlPDFPolizaOPERA = "";
                polizaDet.PolizaOPERA = 0;
                polizaDet.OTOpera = 0;
                polizaDet.EndosoOPERA = 0;
                polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                polizaDet.IdCotizacionDetalle = _cotizacionDetalle.Id;
                polizaDet.IdCatRamoVehiculo = _cotizacionDetalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                polizaDet.IdCatModalidadFormaPago = db.CatModalidadFormaPago.Where(x => x.Clave.Equals(medioPago)).FirstOrDefault().Id;
                polizaDet.IdCatPeriodicidadFormaPago = db.CatPeriodicidadFormaPago.Where(x => x.Clave.Equals(formaPago)).FirstOrDefault().Id;
                if ((InfoEmision.IdTipoDeNegocio == 5 || InfoEmision.IdTipoDeNegocio == 6))
                {
                    if (InfoEmision.EmisionPersonaMoral)
                    {
                        poliza.IdPersonaMoral = InfoEmision.PersonaMoral.Id;
                        poliza.IdRepresentanteLegal = InfoEmision.PersonaMoralRepresentanteLegal.Id;
                        polizaDet.IdDireccion = InfoEmision.PersonaMoral.IdDireccion.Value;
                    }
                    else
                        polizaDet.IdDireccion = InfoEmision.Empresa.IdDireccion.Value;
                }
                else if (!InfoEmision.EsFlotilla)
                {
                    polizaDet.IdDireccion = ConstruyeDireccion(InfoEmision).Id;
                }
                else
                {
                    polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;
                }

                Endoso endosoAlta = new Endoso();
                endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                endosoAlta.Fecha = DateTime.Now;
                endosoAlta.ValorAnterior = "Alta";
                endosoAlta.ValorActual = "Contratación";

                foreach (var incisosResultado in cotResult.responseData.incisos)
                {
                    _cotizacionDetalle.ClaveIncisoCot = cotResult.responseData.cotizacionId.ToString();
                    _cotizacionDetalle.ClaveIncisoVer = cotResult.responseData.incisos.FirstOrDefault().paquetes.FirstOrDefault().versionId.ToString();
                    List<Recibo> recibosGenerados = new List<Recibo>();
                    int conteoRecibos = 1;
                    foreach (var reciboABA in incisosResultado.paquetes.FirstOrDefault().formasPago.FirstOrDefault().recibos)
                    {
                        Recibo reciboSave = new Recibo();
                        reciboSave.Numero = conteoRecibos;
                        reciboSave.NoAsegurado = reciboABA.numero.ToString();
                        reciboSave.PrimaNeta = Convert.ToDecimal(reciboABA.primaNetaMonto.Value);
                        reciboSave.PrimaTotal = Convert.ToDecimal(reciboABA.primaTotalMonto.Value);
                        reciboSave.Recargo = Convert.ToDecimal(reciboABA.recargoMonto.Value);
                        reciboSave.InicioVigencia = DateTime.ParseExact(reciboABA.inicioVigencia, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        reciboSave.FinVigencia = DateTime.ParseExact(reciboABA.finVigencia, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        reciboSave.Impuesto = Convert.ToDecimal(reciboABA.ivaMonto);
                        reciboSave.Comision = 0;
                        reciboSave.Derecho = Convert.ToDecimal(reciboABA.derechoMonto);
                        endosoAlta.Recibo.Add(reciboSave);
                        conteoRecibos++;
                    }
                }
                poliza.Endoso.Add(endosoAlta);
                poliza.PolizaDetalle.Add(polizaDet);
                db.Poliza.Add(poliza);
                db.SaveChanges();

                //Thread T1 = new Thread(delegate ()
                //{
                var modalidad = db.ModalidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidad == perioricidad.IdCatPeriodicidad && x.IdCatModalidadFormaPago == polizaDet.IdCatModalidadFormaPago).FirstOrDefault();
                var recibosPDF = modalidad.ImprimirRecibos;
                poliza.UrlPDFPoliza = ReimprimePoliza(poliza.NumeroPoliza, InfoEmision.Convenio.NumeroNegocio, perioricidad.ClaveAgente, InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena, tipoContribuyente, recibosPDF);
                if (poliza.UrlPDFPoliza != "")
                {
                    db.Entry(poliza).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                }
                //});
                //T1.Start();


                log.Info(string.Format("El numero de poliza {0} se guardo correctamente con el ID: {1}", poliza.NumeroPoliza, poliza.Id));
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un erro con el guardado de la poliza: {0}", ex.Message));
                throw;
            }
            return poliza;
        }

        public string ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string UsuarioWS, string PasswordWS, string tipoContribuyente, bool recibos)
        {
            string rutapolizaAba = "";
            log.Info(string.Format("Cominza la reimpresion de la poliza {0}", NumeroPoliza));
            try
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("<IM>");
                builder.AppendFormat("<CLAVE>{0}</CLAVE>", NumeroPoliza.Substring(0, 2));
                builder.AppendFormat("<POL>{0}</POL>", NumeroPoliza.Substring(2).Trim());
                builder.AppendFormat("<INCISO>{0}</INCISO>", 1);
                builder.AppendFormat("<RECIBO>{0}</RECIBO>", Convert.ToInt32(recibos));
                builder.AppendFormat("<RECIBO_TODOS>{0}</RECIBO_TODOS>", Convert.ToInt32(recibos));
                builder.Append("<FACTURA>0</FACTURA>");
                builder.Append("</IM>");

                string xmlImprimeAba = builder.ToString();
                ImpresionABA.Token tokenImp = new ImpresionABA.Token();

                tokenImp.usuario = UsuarioWS;
                tokenImp.password = PasswordWS;

                ImpresionABA.ACImpresionClient clienteImp = new ImpresionABA.ACImpresionClient();
                string resultadoImp = "";

                resultadoImp = clienteImp.ImpresionSegmentacion(tokenImp, xmlImprimeAba);
                StringReader reader = new StringReader(resultadoImp);

                XmlSerializer xs = new XmlSerializer(typeof(IM));
                IM impresionResult = (IM)xs.Deserialize(reader);

                if (impresionResult != null)
                {
                    rutapolizaAba = impresionResult.PATHPDF;
                }
                log.Info(string.Format("Resultado de la reimpresion de la poliza: {0}", rutapolizaAba));
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un problema al reimprimir la poliza {0}", ex.Message));
            }
            return rutapolizaAba;
        }

        private Direccion ConstruyeDireccion(InformacionEmision infoEmision)
        {
            Direccion direccion = new Direccion();
            try
            {
                log.Info("Inicia mapeo de datos para la dirección que ingresó el usuario.");
                direccion.Calle = infoEmision.DatosUsuario.Direccion.Calle;
                direccion.NumeroExt = infoEmision.DatosUsuario.Direccion.NumeroExt;
                direccion.NumeroInt = infoEmision.DatosUsuario.Direccion.NumeroInt;
                direccion.Colonia = infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
                direccion.Estado = infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Estado;
                direccion.Municipio = infoEmision.DatosUsuario.Direccion.Municipio;
                direccion.CodigoPostal = infoEmision.DatosUsuario.Direccion.CodigoPostal;
                direccion.IdEstado = null;
                direccion.IdMunicipio = null;
                direccion.IdColonia = null;
                direccion.IdCatEstadosRepublica = infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Id;
                direccion.IdCodigoPostal = infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Id;

                db.Direccion.Add(direccion);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("Se presentó el siguiente error: ", ex.Message));
            }
            return direccion;
        }

        private PersonaABA AltaPersonaABA(InformacionEmision InfoEmision, string UsuarioWS, string PasswordWS, string strCliente, string Rfc, string TipoPersona)
        {
            PersonaABA resultadoBuscaPersona = null;
            try
            {
                PersonaRegistroABA.PCRegistroClient cliente = new PersonaRegistroABA.PCRegistroClient();

                string codigoPostal = "";
                Direccion Dir = new Direccion();
                if (TipoPersona == "0")
                {
                    if (InfoEmision.EsFlotilla)
                    {
                        codigoPostal = InfoEmision.Empresa.Direccion.CodigoPostal;
                        Dir = InfoEmision.Empresa.Direccion;
                    }
                    else
                    {
                        codigoPostal = InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                        Dir = InfoEmision.DatosUsuario.Direccion;
                    }
                }
                else
                {
                    if (InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5)
                    {
                        codigoPostal = InfoEmision.PersonaMoral.Direccion.CodigoPostal;
                        Dir = InfoEmision.PersonaMoral.Direccion;
                    }
                    else
                    {
                        codigoPostal = InfoEmision.Empresa.Direccion.CodigoPostal;
                        Dir = InfoEmision.Empresa.Direccion;
                    }

                }



                resultadoBuscaPersona = buscaPersonaAbaCP(Rfc, TipoPersona, UsuarioWS, PasswordWS, strCliente, codigoPostal, Dir);
                if (resultadoBuscaPersona != null)
                {
                    return resultadoBuscaPersona;
                }


                PersonaRegistroABA.Token token = new PersonaRegistroABA.Token();
                token.usuario = UsuarioWS;
                token.password = PasswordWS;

                //Llena los datos del contratante
                DP dp = new DP();
                dp.TP = TipoPersona;
                //Persona fisica
                if (dp.TP == "0")
                {
                    dp.FISICA = new DPFISICA();
                    if (Rfc.Length > 10)
                    {
                        dp.FISICA.RFC = Rfc.Substring(0, Rfc.Length - 3);
                        dp.FISICA.HCVE = Rfc.Substring(Rfc.Length - 3, 3);
                    }
                    else
                    {
                        dp.FISICA.RFC = Rfc;
                        dp.FISICA.HCVE = "";
                    }
                    dp.FISICA.PNOM = InfoEmision.PrimerNombre;
                    dp.FISICA.SNOM = InfoEmision.SegundoNombre;
                    dp.FISICA.APP = InfoEmision.ApellidoPaterno;
                    dp.FISICA.APM = InfoEmision.ApellidoMaterno;
                    dp.FISICA.SEXO = "1";
                    dp.FISICA.EDOCIVIL = "2";

                    //dp.MORAL = new DPMORAL();
                    //dp.MORAL.RFC = "";
                    //dp.MORAL.HCVE = "";
                    //dp.MORAL.RS = "";
                    //dp.MORAL.NOMCOM = "";
                    //dp.MORAL.GIRO = "1";
                    //dp.MORAL.REGIMEN = "false";
                    //dp.MORAL.TS = "0";

                    if (InfoEmision.EsFlotilla)
                    {
                        dp.DOMICILIO = new DPDOMICILIO();
                        dp.DOMICILIO.TIPODIR = "1";

                        dp.DOMICILIO.CALLE = InfoEmision.Empresa.Direccion.Calle;
                        dp.DOMICILIO.NUMEXT = InfoEmision.Empresa.Direccion.NumeroExt ?? "0";
                        dp.DOMICILIO.NUMINT = InfoEmision.Empresa.Direccion.NumeroInt ?? "0";
                        dp.DOMICILIO.COL = InfoEmision.Empresa.Direccion.Colonia;
                        dp.DOMICILIO.CP = codigoPostal;
                        dp.DOMICILIO.POB = InfoEmision.Empresa.Direccion.Municipio;
                    }
                    else
                    {
                        dp.DOMICILIO = new DPDOMICILIO();
                        dp.DOMICILIO.TIPODIR = "1";
                        dp.DOMICILIO.CALLE = InfoEmision.DatosUsuario.Direccion.Calle;
                        dp.DOMICILIO.NUMEXT = InfoEmision.DatosUsuario.Direccion.NumeroExt ?? "0";
                        dp.DOMICILIO.NUMINT = InfoEmision.DatosUsuario.Direccion.NumeroInt ?? "0";
                        //dp.DOMICILIO.COL = InfoEmision.Direccion.Colonia;
                        dp.DOMICILIO.COL = db.CatCodigoPostal.Where(x => x.Id.Equals(InfoEmision.IdAsentamiento)).FirstOrDefault().Asentamiento.ToString();
                        dp.DOMICILIO.CP = codigoPostal;
                        dp.DOMICILIO.POB = InfoEmision.DatosUsuario.Direccion.Municipio;
                    }

                    dp.TELEFONO = new DPTELEFONO();
                    dp.TELEFONO.LADA = string.IsNullOrEmpty(InfoEmision.TelefonoFijo) ? "" : InfoEmision.TelefonoFijo.Substring(0, 2);
                    dp.TELEFONO.NUMERO = string.IsNullOrEmpty(InfoEmision.TelefonoFijo) ? "" : InfoEmision.TelefonoFijo.Substring(2, 8);
                    dp.CELULAR = new DPCELULAR();
                    dp.CELULAR.LADA = string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "" : InfoEmision.TelefonoCel.Substring(0, 2);
                    dp.CELULAR.NUMERO = string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "" : InfoEmision.TelefonoCel.Substring(2, 8);
                    dp.CORREO = InfoEmision.ConfirmaEmail;
                }
                else
                {
                    dp.MORAL = new DPMORAL();
                    if (InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5)
                    {
                        if (InfoEmision.PersonaMoral.RFC.Length > 10)
                        {
                            dp.MORAL.RFC = InfoEmision.PersonaMoral.RFC.Substring(0, InfoEmision.PersonaMoral.RFC.Length - 3);
                            dp.MORAL.HCVE = InfoEmision.PersonaMoral.RFC.Substring(InfoEmision.PersonaMoral.RFC.Length - 3, 3);
                        }
                        else
                        {
                            dp.MORAL.RFC = InfoEmision.PersonaMoral.RFC;
                            dp.MORAL.HCVE = "";
                        }

                        dp.MORAL.NOMCOM = InfoEmision.PersonaMoral.NombreComercial;
                        dp.MORAL.RS = InfoEmision.PersonaMoral.RazonSocial;

                        dp.MORAL.GIRO = "1";
                        dp.MORAL.REGIMEN = "false";
                        dp.MORAL.TS = "0";

                        dp.DOMICILIO = new DPDOMICILIO();
                        dp.DOMICILIO.TIPODIR = "1";

                        dp.DOMICILIO.CALLE = InfoEmision.PersonaMoral.Direccion.Calle;
                        dp.DOMICILIO.NUMEXT = InfoEmision.PersonaMoral.Direccion.NumeroExt ?? "0";
                        dp.DOMICILIO.NUMINT = InfoEmision.PersonaMoral.Direccion.NumeroInt ?? "0";
                        dp.DOMICILIO.COL = InfoEmision.PersonaMoral.Direccion.Colonia;
                        dp.DOMICILIO.CP = codigoPostal;
                        dp.DOMICILIO.POB = InfoEmision.PersonaMoral.Direccion.Municipio;

                        dp.TELEFONO = new DPTELEFONO();
                        dp.TELEFONO.LADA = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(0, 2);
                        dp.TELEFONO.NUMERO = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(2, 8);

                        dp.CELULAR = new DPCELULAR();
                        dp.CELULAR.LADA = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(0, 2);
                        dp.CELULAR.NUMERO = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(2, 8);

                        dp.CORREO = "";
                    }
                    else
                    {
                        if (InfoEmision.Empresa.RFC.Length > 10)
                        {
                            dp.MORAL.RFC = InfoEmision.Empresa.RFC.Substring(0, InfoEmision.Empresa.RFC.Length - 3);
                            dp.MORAL.HCVE = InfoEmision.Empresa.RFC.Substring(InfoEmision.Empresa.RFC.Length - 3, 3);
                        }
                        else
                        {
                            dp.MORAL.RFC = InfoEmision.Empresa.RFC;
                            dp.MORAL.HCVE = "";
                        }

                        dp.MORAL.NOMCOM = InfoEmision.Empresa.NombreComercial;
                        dp.MORAL.RS = InfoEmision.Empresa.RazonSocial;

                        dp.MORAL.GIRO = "1";
                        dp.MORAL.REGIMEN = "false";
                        dp.MORAL.TS = "0";

                        dp.DOMICILIO = new DPDOMICILIO();
                        dp.DOMICILIO.TIPODIR = "1";

                        dp.DOMICILIO.CALLE = InfoEmision.Empresa.Direccion.Calle;
                        dp.DOMICILIO.NUMEXT = InfoEmision.Empresa.Direccion.NumeroExt ?? "0";
                        dp.DOMICILIO.NUMINT = InfoEmision.Empresa.Direccion.NumeroInt ?? "0";
                        dp.DOMICILIO.COL = InfoEmision.Empresa.Direccion.Colonia;
                        dp.DOMICILIO.CP = codigoPostal;
                        dp.DOMICILIO.POB = InfoEmision.Empresa.Direccion.Municipio;

                        dp.TELEFONO = new DPTELEFONO();
                        dp.TELEFONO.LADA = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(0, 2);
                        dp.TELEFONO.NUMERO = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(2, 8);

                        dp.CELULAR = new DPCELULAR();
                        dp.CELULAR.LADA = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(0, 2);
                        dp.CELULAR.NUMERO = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(2, 8);

                        dp.CORREO = "";
                    }
                }


                string XmlizedString = ToXMLString<DP>(dp);
                log.Info("Envio RegistraPersona " + InfoEmision.Empresa.IdCatTipoPersona.ToString() + ": " + XmlizedString.Replace("\n", "").Replace("\r", ""));
                string respuesta = cliente.RegistraPersona(token, "<XML>" + XmlizedString + "</XML>");
                log.Info("respuesta dp xml" + respuesta.Replace("\n", "").Replace("\r", ""));
                resultadoBuscaPersona = new PersonaABA();
                com.lockton.xml.aba.persona.response.RESULTADO personaResult = ToObject<com.lockton.xml.aba.persona.response.RESULTADO>(respuesta);
                foreach (object item in personaResult.Items)
                {
                    if (item is com.lockton.xml.aba.persona.response.RESULTADOPERSONA)
                    {
                        resultadoBuscaPersona.personaId = ((com.lockton.xml.aba.persona.response.RESULTADOPERSONA)item).TPID;
                    }
                    if (item is com.lockton.xml.aba.persona.response.RESULTADOTRANSACCION)
                    {
                        resultadoBuscaPersona.transaccionId = ((com.lockton.xml.aba.persona.response.RESULTADOTRANSACCION)item).TRANID;
                    }
                    if (item is com.lockton.xml.aba.persona.response.RESULTADODIRECCION)
                    {
                        resultadoBuscaPersona.direccionId = ((com.lockton.xml.aba.persona.response.RESULTADODIRECCION)item).TDIRID;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error("Error altaPersonaABA " + ex.Message, ex);
                throw new Exception(ex.Message);
            }
            return resultadoBuscaPersona;
        }

        public PersonaABA buscaPersonaAbaCP(string rfc, string tipocontribuyenteClave, string UsuarioWS, string PasswordWS, string strBuscoNombre, string CP, Direccion direccionEmpleado)
        {
            PersonaRegistroABA.PCRegistroClient cliente = new PersonaRegistroABA.PCRegistroClient();
            try
            {
                XML xmlSend = new XML();
                xmlSend.Item = new XMLDP();

                if (rfc.Length > 10)
                {
                    log.Info("xmlSend.Item.RFC =>" + xmlSend.Item.RFC);
                    xmlSend.Item.RFC = rfc.Substring(0, rfc.Length - 3);
                    xmlSend.Item.HCVE = rfc.Substring(rfc.Length - 3, 3);
                }
                else
                {
                    xmlSend.Item.RFC = rfc;
                }
                xmlSend.Item.TP = tipocontribuyenteClave;
                string xmlBuscaPersona = ToXMLString<XML>(xmlSend);
                log.Info("Envio buscaPersonaAba dp xml: " + xmlBuscaPersona);

                ConsultasABA.PCConsultasClient clienteBuscaAsegurado = new ConsultasABA.PCConsultasClient();

                ConsultasABA.Token tokenConsulta = new ConsultasABA.Token();

                tokenConsulta.usuario = UsuarioWS;
                tokenConsulta.password = PasswordWS;

                string resultado = clienteBuscaAsegurado.ConsultaPersonas(tokenConsulta, xmlBuscaPersona);
                log.Info("Resultado WS buscaPersonaAba dp xmlABA: " + resultado);

                PERSONAS personas = ToObject<PERSONAS>(resultado);
                if (personas.Items != null)
                {
                    foreach (PERSONASPERSONA perResponse in personas.Items)
                    {
                        string rfcABA = perResponse.RFC.Trim().ToUpper() + perResponse.HCVE.Trim().ToUpper();
                        PersonaABA personaABA = new PersonaABA();
                        //if (strBuscoNombre == "" || perResponse.NOMBRE.Replace(" ", "").ToUpper().Contains(strBuscoNombre.Replace(" ", "").ToUpper()))
                        if (rfc.Trim().ToUpper() == rfcABA)
                        {
                            personaABA.personaId = perResponse.PID;
                            string buscaDireccion = String.Format("<XML><DP><TP>{0}</TP><PID>{1}</PID></DP></XML>", xmlSend.Item.TP, personaABA.personaId);
                            log.Info("buscaDireccion  ABA" + buscaDireccion);
                            string resultadoBuscaDireccion = clienteBuscaAsegurado.ConsultaDireccionesPersona(tokenConsulta, buscaDireccion);
                            log.Info("resultadoBuscaDireccion  ABA" + resultadoBuscaDireccion);
                            RESULTADO direccion = ToObject<RESULTADO>(resultadoBuscaDireccion);
                            string _codigoPostalABA = "";
                            foreach (object resObj in direccion.Items)
                            {
                                if (resObj is RESULTADODIRECCIONES)
                                {

                                    _codigoPostalABA = ((RESULTADODIRECCIONES)resObj).DIR.LastOrDefault().CP;
                                    _codigoPostalABA = _codigoPostalABA.PadLeft(5, '0');
                                    personaABA.direccionId = ((RESULTADODIRECCIONES)resObj).DIR.LastOrDefault().DIRID;
                                }

                                if (resObj is RESULTADOTRANSACCION)
                                {
                                    personaABA.transaccionId = ((RESULTADOTRANSACCION)resObj).TRANID.ToString();
                                }
                            }

                            if (_codigoPostalABA.Trim() == CP.Trim())
                                return personaABA;
                            else
                            {
                                //Si no existe esa direccion se da de alta.
                                if (personaABA.personaId != null)
                                {
                                    PersonaRegistroABA.Token token = new PersonaRegistroABA.Token();
                                    token.usuario = UsuarioWS;
                                    token.password = PasswordWS;

                                    string result = cliente.RegistraDireccionPersona(token, GeneraXmlRegistroDireccionPersona(direccionEmpleado, personaABA.personaId, tipocontribuyenteClave));

                                    com.lockton.xml.aba.registro.direcciones.RESULTADO direccionNueva = ToObject<com.lockton.xml.aba.registro.direcciones.RESULTADO>(result);
                                    personaABA.direccionId = direccionNueva.DIRECCION.TDIRID.ToString();
                                    personaABA.transaccionId = direccionNueva.TRANSACCION.TRANID.ToString();

                                    return personaABA;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error en buscaPersonaAba " + ex.Message, ex);
                throw new Exception(ex.Message);
            }
            return null;
        }

        public string GeneraXmlRegistroDireccionPersona(Direccion direccionAlta, string PersonaIDAba, string TipoPersona)
        {
            string xml = "";

            xml = string.Format("<XML><DP><TP>{7}</TP><PID>{0}</PID><DOMICILIO><TIPODIR>1</TIPODIR><CALLE>{1}</CALLE><NUMEXT>{2}</NUMEXT><NUMINT>{3}</NUMINT><COL>{4}</COL><CP>{5}</CP><POB>{6}</POB></DOMICILIO></DP></XML>",
                                                                   PersonaIDAba,
                                                                  string.IsNullOrEmpty(direccionAlta.Calle) ? "" : direccionAlta.Calle,
                                                                   string.IsNullOrEmpty(direccionAlta.NumeroExt) ? "1" : direccionAlta.NumeroExt,
                                                                   string.IsNullOrEmpty(direccionAlta.NumeroInt) ? "1" : direccionAlta.NumeroInt,
                                                                  string.IsNullOrEmpty(direccionAlta.Colonia) ? "1" : direccionAlta.Colonia,
                                                                  string.IsNullOrEmpty(direccionAlta.CodigoPostal) ? "05329" : direccionAlta.CodigoPostal,
                                                                   string.IsNullOrEmpty(direccionAlta.Municipio) ? "1" : direccionAlta.Municipio,
                                                                   TipoPersona);
            return xml;
        }

        public T ToObject<T>(string toDeserialize)
        {
            StringReader reader = new StringReader(toDeserialize);
            XmlSerializer xs = new XmlSerializer(typeof(T));
            T resultado = (T)xs.Deserialize(reader);
            reader.Close();
            return resultado;
        }

        public string ToXMLString<T>(T toSerialize)
        {
            MemoryStream memoryStream = new MemoryStream();
            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add(String.Empty, String.Empty);
            XmlSerializer xs = new XmlSerializer(typeof(T));
            XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Default);
            xs.Serialize(xmlTextWriter, toSerialize, ns);
            memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
            string XmlizedString = UTF8ByteArrayToString(memoryStream.ToArray());
            XmlizedString = XmlizedString.Replace("<?xml version=\"1.0\" encoding=\"Windows-1252\"?>", "");
            xmlTextWriter.Close();
            memoryStream.Close();
            return XmlizedString;
        }

        private String UTF8ByteArrayToString(Byte[] characters)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            String constructedString = encoding.GetString(characters);
            return (constructedString);
        }

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }


        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }

    }
}


