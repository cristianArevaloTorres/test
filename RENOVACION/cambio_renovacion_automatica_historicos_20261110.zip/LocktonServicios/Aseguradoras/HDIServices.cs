﻿using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.ANA;
using LocktonModel.VModels;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.Membresias;
using LocktonServicios.Services.Derivacion;
using LocktonServicios.Utilidades;
using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using static LocktonServicios.DerivacionOpera.DerivaOperaService;

namespace LocktonServicios.Aseguradoras
{
    public class HDIServices : IOperacionesAseguradoras
    {
        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger("HDI");

        private HDIAutos.PublicServicesAutosContractClient InitializeClient(string user, string pass)
        {
            HDIAutos.PublicServicesAutosContractClient servicio = new HDIAutos.PublicServicesAutosContractClient();
            System.ServiceModel.Description.ClientCredentials clientCredentials = new System.ServiceModel.Description.ClientCredentials();
            clientCredentials.UserName.UserName = user;
            clientCredentials.UserName.Password = pass;

            servicio.ChannelFactory.Endpoint.Behaviors.Remove<System.ServiceModel.Description.ClientCredentials>();
            servicio.ChannelFactory.Endpoint.Behaviors.Add(clientCredentials);

            return servicio;

        }

        public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {
            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
            var error = "";
            try
            {
                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioCotiza.Id && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
                var paquete = "";
                int idTipoVehiculo = 0;

                LocktonModel.db.CatPeriodicidadFormaPago catperdioricidad = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == perioricidad.IdCatPeriodicidadFormaPago);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == catperdioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);
                var paqueteRamoConvenio = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == convenioId && x.IdCatRamoVehiculo == paqueteConvenio.IdCatRamoVehiculo).FirstOrDefault();
                var servicio = InitializeClient(convenioCotiza.Usuario, convenioCotiza.Contrasena);
                var request = new HDIAutos.ObtenerPaquetesRequest();

                if (!int.TryParse(CotizacionCompara.TipoVehiculo, out idTipoVehiculo))
                    idTipoVehiculo = 1;

                //Tipo Suma Asegurada Valor factura
                if (CotizacionCompara.ValorFactura)
                {
                    request.IDTipoSumaAsegurada = 4454;
                    request.SumaAsegurada = CotizacionCompara.MontoFactura;
                }

                //Forma de pago
                request.idFormaPago = Convert.ToInt32(perioricidad.FormaPago);

                //Usuario
                request.usuario = convenioCotiza.Usuario;

                //Vigencia
                #region VIGENCIA

                request.Vigencia = new HDIAutos.Vigencia();

                DateTime FechaInicio = CotizacionCompara.FechaInicio;
                DateTime FechaTermino = CotizacionCompara.FechaFin;



                request.Vigencia.Inicial = FechaInicio;
                request.Vigencia.Final = FechaTermino;

                #endregion

                //Vehiculo
                #region DATOS DEL VEHICULO

                request.datosVehiculo = new HDIAutos.CaracteristicasVehiculo();

                var datosVehiculo = ObtenerDatosVehiculo(cot.Catalogo[0].CatDescripciones[0].clave);

                request.datosVehiculo.idVehiculo = cot.Catalogo[0].CatDescripciones[0].clave;
                request.datosVehiculo.idModelo = Convert.ToInt32(CotizacionCompara.Año);

                request.datosVehiculo.idMarca = datosVehiculo.IdMarca;
                request.datosVehiculo.idTransmision = datosVehiculo.IdTransmision;
                request.datosVehiculo.tipoVehiculo = datosVehiculo.IdTipoVehiculoHDI;
                request.datosVehiculo.idTipo = datosVehiculo.Tipo;
                request.datosVehiculo.idVersion = datosVehiculo.Version;

                if (idTipoVehiculo == 1)
                    request.datosVehiculo.idUso = 4581;
                else if (idTipoVehiculo == 2)
                    request.datosVehiculo.idUso = 4596;
                else if (idTipoVehiculo == 3)
                    request.datosVehiculo.idUso = 4594;

                request.datosVehiculo.pasajeros = 0;
                request.datosVehiculo.idZonaCirculacion = 0;
                request.datosVehiculo.idTonelaje = 0;
                request.datosVehiculo.idServicio = 4601;
                request.datosVehiculo.idRiesgoCarga = 0;



                string codigoPostal = ConveniosPaquetes.Empresa.Direccion.CodigoPostal;
                if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 2 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 6)//pooles
                {
                    codigoPostal = string.IsNullOrEmpty(CotizacionCompara.CodigoPostal) ? codigoPostal : CotizacionCompara.CodigoPostal;

                }

                request.datosVehiculo.DatosAdicionales = new HDIAutos.DatosAdicionalesGLM();
                request.datosVehiculo.DatosAdicionales.CPCirculacion = codigoPostal;

                request.datosVehiculo.AjusteAdicional = new HDIAutos.AjusteAdicional();

                if (CotizacionCompara.MediodePago == 0)
                    request.datosVehiculo.AjusteAdicional.IdConductoCobro = 4;
                else if (CotizacionCompara.MediodePago == 1)
                    request.datosVehiculo.AjusteAdicional.IdConductoCobro = 2;
                else
                    request.datosVehiculo.AjusteAdicional.IdConductoCobro = 1;



                #endregion

                //Estado y Ciudad
                var infoCP = ObtenerDatosCP(codigoPostal, servicio);
                request.estado = infoCP.IdEstado;
                request.ciudad = infoCP.IdCiudad;

                //Paquete
                if (paqueteConvenio.IdPlan == null)
                {
                    throw new Exception("No se encontró Clave del Paquete en la configuración");
                }

                paquete = paqueteConvenio.IdPlan.ToString();
                request.listaPaquetesACalcular = new HDIAutos.StringArrayContract();
                var _paqete = new List<string>();
                _paqete.Add(paquete);

                request.listaPaquetesACalcular.StringArray = _paqete.ToArray();
                request.obtenerTodosPaquetes = false;

                //Coberturas
                #region Coberturas

                var _paqueteCobertura = new HDIAutos.PaqueteCoberturas();
                var _obligatorias = new List<HDIAutos.Cobertura>();
                var _obligatoriasOpcionales = new List<HDIAutos.Cobertura>();
                var _opcionales = new List<HDIAutos.Cobertura>();

                var coberturas = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, datosVehiculo.IdTipoVehiculo, idPaqueteConvenio);
                var coberturasHDI = db.CoberturaHDI.Where(a => a.IdTipoVehiculo == idTipoVehiculo).OrderBy(a => a.IdTipoCobertura).ToList();

                _paqueteCobertura.Clave = Convert.ToInt32(paquete);

                foreach (var hdi in coberturasHDI)
                {
                    var cobertura = coberturas.FirstOrDefault(a => a.Codigo == hdi.Clave);
                    var item = new HDIAutos.Cobertura();
                    if (cobertura != null)
                    {
                        var dd = EsCoberturaConCondicionEspecial(convenioCotiza.Id, cobertura.IdCobertura.ToString(), CotizacionCompara.Año, datosVehiculo.IdTipoVehiculo);
                        if (!dd)
                            continue;
                    }                      
                    item.Regla = 0;
                    item.Clave = Convert.ToInt32(hdi.Clave);
                    item.Descripcion = hdi.Descripcion;
                    item.PrimaNeta = 0;
                    item.ProveedorAsistencia = hdi.IdProveedor;


                    if (cobertura == null)
                    {
                        item.Calculada = false;
                        item.Deducible = decimal.Truncate(hdi.Deducible);
                        item.SumaAsegurada = decimal.Truncate(hdi.SumaAsegurada);
                    }
                    else
                    {
                        item.Calculada = true;
                        if (item.Clave == 233 || item.Clave == 236)
                        {

                            item.Deducible = Convert.ToInt32(Convert.ToDouble(cobertura.Deducible) * 1);
                            item.SumaAsegurada = 0;

                            if (!CotizacionCompara.ValorFactura)
                            {
                                var _catSumaAsegurada = db.CatTipoSumaAsegVehiculo.FirstOrDefault(a => a.IdAseguradora == 20 && a.Nombre == cobertura.Cobertura);

                                if (_catSumaAsegurada != null)
                                    request.IDTipoSumaAsegurada = Convert.ToInt32(_catSumaAsegurada.Clave);
                            }
                        }
                        else
                        {
                            item.Deducible = 0;
                            item.SumaAsegurada = Convert.ToDecimal(cobertura.SumaAsegurada);

                        }
                    }


                    switch (hdi.IdTipoCobertura)
                    {
                        case 1:
                            _obligatorias.Add(item);
                            break;

                        case 2:
                            _obligatoriasOpcionales.Add(item);
                            break;

                        case 3:
                            _opcionales.Add(item);
                            break;

                    }


                }

                _paqueteCobertura.CoberturasObligatorias = new HDIAutos.Coberturas();
                _paqueteCobertura.CoberturasObligatorias.AddRange(_obligatorias);

                _paqueteCobertura.CoberturasObligatoriasOpcionales = new HDIAutos.Coberturas();
                _paqueteCobertura.CoberturasObligatoriasOpcionales.AddRange(_obligatoriasOpcionales);

                _paqueteCobertura.CoberturasOpcionales = new HDIAutos.Coberturas();
                _paqueteCobertura.CoberturasOpcionales.AddRange(_opcionales);

                _paqueteCobertura.Ajuste = new HDIAutos.Ajuste();
                _paqueteCobertura.Ajuste.TipoAjuste = 4612;
                _paqueteCobertura.Ajuste.PorcentajeAjuste = paqueteRamoConvenio.Descuento;

                request.paquetesConCambios = new HDIAutos.PaquetesCoberturas();
                request.paquetesConCambios.Add(_paqueteCobertura);

                #endregion               

                var response = servicio.ObtenerPaquetes(request);

                #region Validar Respuesta

                var xmlEnvio = ObjectSerializer<HDIAutos.ObtenerPaquetesRequest>.Serialize(request).Replace("\n", "").Replace("\r", "");
                var xmlRespuesta = ObjectSerializer<HDIAutos.InformacionPaquetes>.Serialize(response).Replace("\n", "").Replace("\r", "");

                Comparar infoCompara = LeeXmlRespuesta(xmlRespuesta, xmlEnvio, convenioCotiza);
                infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();


                //meses sin intereses
                if (catperdioricidad.Id == 1 && mediopago.Id == 1)
                {

                    Utilidades.Utilidades.AplicaMSICotizacion(convenioCotiza.IdEmpresa, convenioCotiza.Id, ref infoCompara);

                }


                CotizacionCompara.Comparar.Add(infoCompara);

                #endregion


            }
            catch (Exception ex)
            {

                Comparar infoCompara = new Comparar();
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.Aseguradora = "HDI";
                infoCompara.ErrorXML = string.Format("Tuvimos un inconveniente para realizar tu cotizacion: {0}", string.IsNullOrEmpty(error) ? ex.Message : error);
                CotizacionCompara.Comparar.Add(infoCompara);

                log.Info(infoCompara.ErrorXML);
                //throw;
            }

            return CotizacionCompara;
        }

        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision, Convenio convenio)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var request = Utilidades.Utilidades.ToObject<HDIAutos.ObtenerPaquetesRequest>(xmlEmision);

                var servicio = InitializeClient(convenio.Usuario, convenio.Contrasena);

                request.Vigencia.Inicial = DateTime.Now;

                var response = servicio.ObtenerPaquetes(request);
                var xmlEnvio = Utilidades.Utilidades.GetStringFromXML(request);
                var xmlRespuesta = Utilidades.Utilidades.GetStringFromXML(response);

                resultado.XMLSolicitud = xmlEnvio;
                resultado.XMLRecepcion = xmlRespuesta;

                if (response.errores.Any())
                {
                    var error = string.Join(", ", response.errores.Select(a => a.descripcion).ToList());

                    throw new Exception(error);

                }

                return resultado;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Comparar LeeXmlRespuesta(string xmlRespuesta, string xmlEnvio, Convenio convenioCotiza)
        {

            var response = Utilidades.Utilidades.ToObject<HDIAutos.InformacionPaquetes>(xmlRespuesta);
            var request = Utilidades.Utilidades.ToObject<HDIAutos.ObtenerPaquetesRequest>(xmlEnvio);


            Comparar infoCompara = new Comparar();
            infoCompara.FechaCotizacion = request.Vigencia.Inicial;
            infoCompara.XmlEmision = xmlEnvio;
            infoCompara.XmlRespuesta = xmlRespuesta;
            infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
            infoCompara.IdConvenio = convenioCotiza.Id;
            infoCompara.Aseguradora = "HDI";
            infoCompara.Año = request.datosVehiculo.idModelo.ToString();
            infoCompara.FechaInicio = request.Vigencia.Inicial.ToString("dd/MM/yyyy");
            infoCompara.FechaFin = request.Vigencia.Final.ToString("dd/MM/yyyy");
            //infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
            //infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
            //infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;

            if (response.errores.Any())
            {
                infoCompara.ErrorXML = string.Join(", ", response.errores.Select(a => a.descripcion).ToList());

                log.Error("cotizaVehiculo error HDI Request " + xmlEnvio.Replace("\n", "").Replace("\r", ""));
                log.Error("cotizaVehiculo error HDI Response " + xmlRespuesta.Replace("\n", "").Replace("\r", ""));

            }
            else
            {

                var _paqueteRespuest = response.ListaPaquetes.FirstOrDefault();
                infoCompara.Coberturas = new List<Coberturas>();

                foreach (var cobertura in _paqueteRespuest.CoberturasObligatorias)
                {
                    if (cobertura.Calculada)
                    {
                        Coberturas cotCob = new Coberturas();

                        cotCob.Cobertura = cobertura.PrimaNeta.ToString("N2");
                        cotCob.SumaAsegurada = cobertura.SumaAsegurada.ToString("N2");
                        cotCob.Nombre = cobertura.Descripcion.Trim();
                        cotCob.Deducible = cobertura.Deducible.ToString();
                        cotCob.Codigo = cobertura.Clave.ToString();

                        infoCompara.Coberturas.Add(cotCob);
                    }
                }

                foreach (var cobertura in _paqueteRespuest.CoberturasObligatoriasOpcionales)
                {
                    if (cobertura.Calculada)
                    {
                        Coberturas cotCob = new Coberturas();

                        cotCob.Cobertura = cobertura.PrimaNeta.ToString("N2");
                        cotCob.SumaAsegurada = cobertura.SumaAsegurada.ToString("N2");
                        cotCob.Nombre = cobertura.Descripcion.Trim();
                        cotCob.Deducible = cobertura.Deducible.ToString();
                        cotCob.Codigo = cobertura.Clave.ToString();

                        infoCompara.Coberturas.Add(cotCob);
                    }
                }

                foreach (var cobertura in _paqueteRespuest.CoberturasOpcionales)
                {
                    if (cobertura.Calculada)
                    {
                        Coberturas cotCob = new Coberturas();

                        cotCob.Cobertura = cobertura.PrimaNeta.ToString("N2");
                        cotCob.SumaAsegurada = cobertura.SumaAsegurada.ToString("N2");
                        cotCob.Nombre = cobertura.Descripcion.Trim();
                        cotCob.Deducible = cobertura.Deducible.ToString();
                        cotCob.Codigo = cobertura.Clave.ToString();

                        infoCompara.Coberturas.Add(cotCob);
                    }
                }

                infoCompara.PrimaNeta = _paqueteRespuest.Totales.PrimaNeta.ToString("N2");
                if (_paqueteRespuest.Totales.Descuento < 0)
                {
                    infoCompara.PrimaNeta = (_paqueteRespuest.Totales.PrimaNeta + _paqueteRespuest.Totales.Descuento).ToString("N2");

                }
                infoCompara.PrimaTotal = _paqueteRespuest.Totales.PrimaTotal.ToString("N2");
                infoCompara.Impuesto = _paqueteRespuest.Totales.IVA.ToString("N2");
                infoCompara.Recargo = _paqueteRespuest.Totales.Financiamiento.ToString("N2");
                infoCompara.Derecho = _paqueteRespuest.Totales.DerechoPoliza.ToString("N2");
                //infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();
                infoCompara.PrimerPago = _paqueteRespuest.Recibos.PrimeraExhibicion.ToString("N2");
                infoCompara.NumeroDePagos = _paqueteRespuest.Recibos.RecibosSubsecuentes + 1;
                infoCompara.SegundoPago = _paqueteRespuest.Recibos.Importe.ToString("N2");
                infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;

            }

            return infoCompara;
        }

        public void ObtenerFormaPago(int idConvenio)
        {
            var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
            var servicio = InitializeClient(convenio.Usuario, convenio.Contrasena);

            var forma = servicio.ObtenerFormasPago();
            var formas = servicio.ObtenerFormasPagoPorNegocio("00091");
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            EmisionPoliza result = new EmisionPoliza(true, string.Empty, string.Empty, new Poliza());

            var servicio = InitializeClient(InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena);

            log.Error("Entrando a Emitir HDI");
            var xmlEmisionEnvio = string.Empty;
            var xmlEmisionRespuesta = string.Empty;

            try
            {

                CotizacionDetalle _detalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
                var _detalleAuto = db.CotizacionAuto.FirstOrDefault(a => a.IdCotizacion == _detalle.IdCotizacion);
                var requestPaquetes = Utilidades.Utilidades.ToObject<HDIAutos.ObtenerPaquetesRequest>(_detalle.XMLSolicitud);
                var responsePaquetes = Utilidades.Utilidades.ToObject<HDIAutos.InformacionPaquetes>(_detalle.XMLRecepcion);
                var _coberturas = requestPaquetes.paquetesConCambios[0];
                var _paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == _detalle.IdPaqueteConvenio);
                var paqueteRamoConvenio = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatRamoVehiculo == _paqueteConvenio.IdCatRamoVehiculo).FirstOrDefault();

                InfoEmision.Cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == _detalle.IdCotizacion);

                var requestCotizacion = new HDIAutos.DatosCotizacion();

                requestCotizacion.PaqueteCoberturas = _coberturas;
                requestCotizacion.PaqueteCoberturas.Vigencia = requestPaquetes.Vigencia;

                requestCotizacion.PaqueteCoberturas.Ajuste = new HDIAutos.Ajuste();
                //requestCotizacion.PaqueteCoberturas.Ajuste = _coberturas.Ajuste;

                requestCotizacion.PaqueteCoberturas.Ajuste.PorcentajeAjuste = paqueteRamoConvenio.Descuento;
                requestCotizacion.PaqueteCoberturas.Ajuste.TipoAjuste = 4612;

                requestCotizacion.CaracteristicasVehiculo = requestPaquetes.datosVehiculo;
                requestCotizacion.CaracteristicasVehiculo.numeroMotor = InfoEmision.NumeroMotor;
                requestCotizacion.CaracteristicasVehiculo.numeroSerie = InfoEmision.NumeroSerie.ToUpper();
                requestCotizacion.CaracteristicasVehiculo.placas = InfoEmision.Placas;

                requestCotizacion.fechaInicioVigencia = requestPaquetes.Vigencia.Inicial;
                requestCotizacion.idFormaPago = requestPaquetes.idFormaPago;

                //Meses sin intereses
                if (InfoEmision.IdMSI.HasValue)
                {
                    int idFormaPagoMSI = 0;
                    var claveMSI = Utilidades.Utilidades.ObtenerClaveBancoMSI(InfoEmision.Convenio.IdAseguradora, InfoEmision.IdBanco, InfoEmision.IdConvenioMSI, InfoEmision.IdMSI);
                    if (!string.IsNullOrEmpty(claveMSI) && int.TryParse(claveMSI, out idFormaPagoMSI))
                        requestCotizacion.idFormaPago = idFormaPagoMSI;

                }



                if (InfoEmision.CotizacionAutoGuardar.MediodePago == 0 && InfoEmision.ConDatosBancarios)
                    requestCotizacion.idConductoCobro = 4;
                else if (InfoEmision.CotizacionAutoGuardar.MediodePago == 1 && InfoEmision.ConDatosBancarios)
                    requestCotizacion.idConductoCobro = 2;
                else
                    requestCotizacion.idConductoCobro = 1;

                #region CONDUCTOR

                var conductor = new HDIAutos.DatosConductor();

                conductor.ApellidoMaterno = InfoEmision.ApellidoMaterno;
                conductor.ApellidoPaterno = InfoEmision.ApellidoPaterno;
                conductor.Nombres = new HDIAutos.NombresConducor();
                conductor.Nombres.PrimerNombre = InfoEmision.PrimerNombre;
                conductor.Nombres.SegundoNombre = InfoEmision.SegundoNombre;
                conductor.FechaDeNacimiento = InfoEmision.FechaNacimiento;
                conductor.RFC = InfoEmision.DatosUsuario.RFC;
                conductor.Sexo = InfoEmision.Cotizacion.IdCatGenero.HasValue ? InfoEmision.Cotizacion.IdCatGenero.Value : 1;
                conductor.CuentaConCochera = false;
                conductor.Ocupacion = 112;
                conductor.EstadoCivil = "S";

                //conductor.FechaDeNacimiento = new DateTime(1983,11, 2);

                requestCotizacion.CaracteristicasVehiculo.Conductor = conductor;

                #endregion

                #region CLIENTE

                var cliente = new HDIAutos.Cliente();
                var infoCP = new InfoUbicacionHDI();

                cliente.Direccion = new HDIAutos.Direccion();

                cliente.actividadPolitica = false;
                cliente.FolioMercantil = "00";
                cliente.Direccion.nacionalidad = "002";//MEXICANO
                cliente.Direccion.pais = "00007";//MEXICO

                if (InfoEmision.EmisionPersonaMoral)
                {
                    var idGiroPM = "";
                    InfoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoralRepresentanteLegal.Id);
                    infoCP = ObtenerDatosCP(InfoEmision.PersonaMoral.Direccion.CodigoPostal, servicio);

                    if (!string.IsNullOrEmpty(InfoEmision.PersonaMoral.CatGiroBase.ClaveHDI))
                        idGiroPM = db.CatGiroBase.FirstOrDefault(a => !string.IsNullOrEmpty(a.ClaveHDI)).ClaveHDI;
                    else
                        idGiroPM = InfoEmision.PersonaMoral.CatGiroBase.ClaveHDI;

                    cliente.giroActividad = idGiroPM;
                    cliente.ocupacion = "0";//EMPLEADO
                    cliente.idTipoPersona = "02";

                    cliente.apellidoMaterno = "";
                    cliente.apellidoPaterno = "";
                    cliente.estadoCivil = "";
                    cliente.fechaNacimiento = InfoEmision.PersonaMoral.FechaConstitucion.HasValue ? InfoEmision.PersonaMoral.FechaConstitucion.Value : DateTime.Now;
                    cliente.primerNombre = InfoEmision.PersonaMoral.RazonSocial;
                    cliente.rfc = InfoEmision.PersonaMoral.RFC;
                    cliente.sexo = 0;

                    cliente.Direccion.calle = InfoEmision.PersonaMoral.Direccion.Calle;
                    cliente.Direccion.codigoPostal = InfoEmision.PersonaMoral.Direccion.CodigoPostal;
                    cliente.Direccion.colonia = InfoEmision.PersonaMoral.Direccion.Colonia;
                    cliente.Direccion.telefonoCasa = InfoEmision.PersonaMoralRepresentanteLegal.Telefono;
                    cliente.Direccion.telefonoOficina = InfoEmision.PersonaMoralRepresentanteLegal.Telefono;
                    cliente.Direccion.numeroExterior = InfoEmision.PersonaMoral.Direccion.NumeroExt;
                    cliente.Direccion.numeroInterior = InfoEmision.PersonaMoral.Direccion.NumeroInt;


                }
                else if (InfoEmision.EsFlotilla)
                {

                    infoCP = ObtenerDatosCP(InfoEmision.Empresa.Direccion.CodigoPostal, servicio);

                    cliente.giroActividad = InfoEmision.Empresa.CatGiroBase.ClaveHDI;
                    cliente.ocupacion = "0";//EMPLEADO
                    cliente.idTipoPersona = "02";

                    cliente.apellidoMaterno = "";
                    cliente.apellidoPaterno = "";
                    cliente.estadoCivil = "";
                    cliente.fechaNacimiento = InfoEmision.Empresa.FechaConstitucion.HasValue ? InfoEmision.Empresa.FechaConstitucion.Value : DateTime.Now;
                    cliente.primerNombre = InfoEmision.Empresa.RazonSocial;
                    cliente.segundoNombre = "";
                    cliente.rfc = InfoEmision.Empresa.RFC;
                    cliente.sexo = 0;

                    cliente.Direccion.calle = InfoEmision.Empresa.Direccion.Calle;
                    cliente.Direccion.codigoPostal = InfoEmision.Empresa.Direccion.CodigoPostal;
                    cliente.Direccion.colonia = InfoEmision.Empresa.Direccion.Colonia;
                    cliente.Direccion.telefonoCasa = InfoEmision.Empresa.TelefonoGral;
                    cliente.Direccion.telefonoOficina = InfoEmision.Empresa.TelefonoGral;
                    cliente.Direccion.numeroExterior = InfoEmision.Empresa.Direccion.NumeroExt;
                    cliente.Direccion.numeroInterior = InfoEmision.Empresa.Direccion.NumeroInt;

                    //infoCP = ObtenerDatosCP("37000");
                    //cliente.giroActividad = InfoEmision.Empresa.CatGiroBase.ClaveHDI;
                    //cliente.ocupacion = "0";
                    //cliente.idTipoPersona = "02";

                    //cliente.apellidoMaterno = "";
                    //cliente.apellidoPaterno = "";
                    //cliente.estadoCivil = "S";
                    //cliente.fechaNacimiento = new DateTime(1964, 08, 08);
                    //cliente.primerNombre = "PARADOR CHIHUAHUA S.A.DE C.V.";
                    //cliente.segundoNombre = "";
                    //cliente.rfc = "HAP640808CS5";
                    //cliente.sexo = 1;

                    //cliente.Direccion.calle = "LOCKTON PRUEBA";
                    //cliente.Direccion.codigoPostal = "37000";
                    //cliente.Direccion.colonia = "CENTRO";
                    //cliente.Direccion.telefonoCasa = "0000000000";
                    //cliente.Direccion.telefonoOficina = "0000000000";
                    //cliente.Direccion.numeroExterior = "861";
                    //cliente.Direccion.numeroInterior = "0";

                }
                else
                {

                    if (InfoEmision.DetalleUsuario.Direccion != null)
                    {
                        infoCP = ObtenerDatosCP(InfoEmision.DetalleUsuario.Direccion.CodigoPostal, servicio);

                        cliente.apellidoMaterno = InfoEmision.DetalleUsuario.ApellidoMaterno;
                        cliente.apellidoPaterno = InfoEmision.DetalleUsuario.ApellidoPaterno;
                        cliente.primerNombre = InfoEmision.DetalleUsuario.Nombre;
                        cliente.segundoNombre = InfoEmision.DetalleUsuario.NombreDos;


                        cliente.Direccion.calle = InfoEmision.DetalleUsuario.Direccion.Calle;
                        cliente.Direccion.codigoPostal = InfoEmision.DetalleUsuario.Direccion.CodigoPostal;
                        cliente.Direccion.colonia = InfoEmision.DetalleUsuario.Direccion.Colonia;
                        cliente.Direccion.numeroExterior = InfoEmision.DetalleUsuario.Direccion.NumeroExt;
                        cliente.Direccion.numeroInterior = InfoEmision.DetalleUsuario.Direccion.NumeroInt;

                    }

                    if (InfoEmision.DatosUsuario.Direccion != null)
                    {
                        infoCP = ObtenerDatosCP(InfoEmision.DatosUsuario.Direccion.CodigoPostal, servicio);

                        cliente.apellidoMaterno = InfoEmision.ApellidoMaterno;
                        cliente.apellidoPaterno = InfoEmision.ApellidoPaterno;
                        cliente.primerNombre = InfoEmision.PrimerNombre;
                        cliente.segundoNombre = InfoEmision.SegundoNombre;

                        cliente.Direccion.calle = InfoEmision.DatosUsuario.Direccion.Calle;
                        cliente.Direccion.codigoPostal = InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                        cliente.Direccion.colonia = InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
                        cliente.Direccion.numeroExterior = InfoEmision.DatosUsuario.Direccion.NumeroExt;
                        cliente.Direccion.numeroInterior = InfoEmision.DatosUsuario.Direccion.NumeroInt;


                    }

                    cliente.giroActividad = "0";
                    cliente.ocupacion = "9BJG";//EMPLEADO                        
                    cliente.idTipoPersona = "00";


                    cliente.estadoCivil = "S";
                    cliente.fechaNacimiento = InfoEmision.FechaNacimiento;
                    cliente.rfc = InfoEmision.DatosUsuario.RFC;
                    cliente.sexo = (short)conductor.Sexo;

                    cliente.Direccion.telefonoCasa = InfoEmision.TelefonoFijo;
                    cliente.Direccion.telefonoOficina = InfoEmision.TelefonoCel;

                }

                cliente.Direccion.ciudad = infoCP.IdCiudad;
                cliente.Direccion.estado = infoCP.IdEstado;

                requestCotizacion.Cliente = cliente;

                #endregion

                #region PAQUETE

                var _deducibleDM = 0;
                var _deducibleRT = 0;

                var _coberturaDM = _coberturas.CoberturasObligatorias.FirstOrDefault(a => a.Clave == 233);
                var _coberturaRM = _coberturas.CoberturasObligatorias.FirstOrDefault(a => a.Clave == 236);

                if (_coberturaDM != null)
                    _deducibleDM = Convert.ToInt32(_coberturaDM.Deducible);

                if (_coberturaRM != null)
                    _deducibleRT = Convert.ToInt32(_coberturaRM.Deducible);

                requestCotizacion.PaqueteEmitir = new HDIAutos.PaqueteTarificarExpress();
                requestCotizacion.PaqueteEmitir.IdPaquete = _coberturas.Clave;
                requestCotizacion.PaqueteEmitir.IdPromocion = 0;

                requestCotizacion.PaqueteEmitir.ListaCondiciones = new HDIAutos.ListaCondicionesTarificar();
                requestCotizacion.PaqueteEmitir.ListaCondiciones.Add(new HDIAutos.CondicionesTarificar()
                {
                    DeducibleDM = _deducibleDM,
                    DeducibleRT = _deducibleRT
                });

                requestCotizacion.PaqueteEmitir.ListaConfiguraciones = new HDIAutos.ListaConfiguracionesPaquete();
                requestCotizacion.PaqueteEmitir.ListaConfiguraciones.Add(new HDIAutos.ConfiguracionPaquete()
                {
                    UsuarioCotiza = requestPaquetes.usuario,
                    AgenteCotiza = requestPaquetes.usuario,
                    InicioVigencia = requestPaquetes.Vigencia.Inicial,
                    FinVigencia = requestPaquetes.Vigencia.Final,
                    EsCotizacionDiasPorMes = false,
                    Descuento = 0
                });

                #endregion


                requestCotizacion.idEstado = infoCP.IdEstado;
                requestCotizacion.idCiudad = infoCP.IdCiudad;
                requestCotizacion.IDTipoSumaAsegurada = requestPaquetes.IDTipoSumaAsegurada;

                if (!string.IsNullOrEmpty(InfoEmision.BeneficiarioPreferente))
                {
                    requestCotizacion.BeneficiarioPreferente = new HDIAutos.BeneficiarioPreferente();
                    requestCotizacion.BeneficiarioPreferente.tipoBeneficiario = "A:";
                    requestCotizacion.BeneficiarioPreferente.nombreCompleto = InfoEmision.BeneficiarioPreferente;
                }

                if (InfoEmision.RequiereFactura)
                {
                    var requimenFiscal = "0";
                    var regimenCapital = "0";
                    var _facturacion = new Facturacion();

                    if (InfoEmision.EsFlotilla || InfoEmision.EmisionPersonaMoral)
                    {
                        if (InfoEmision.Empresa.IdRegimenFiscal.HasValue)
                        {
                            _facturacion.IdRegimenFiscal = InfoEmision.Empresa.IdRegimenFiscal;
                            requimenFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal).ClaveHDI;
                        }
                        if (InfoEmision.Empresa.IdRegimenCapital.HasValue)
                            regimenCapital = db.CatRegimenCapital.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenCapital).ClaveHDI;
                    }
                    else
                    {
                        if (InfoEmision.IdRegimenFiscal > 0)
                        {
                            _facturacion.IdRegimenFiscal = InfoEmision.IdRegimenFiscal;
                            requimenFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.IdRegimenFiscal).ClaveHDI;
                        }
                    }

                    requestCotizacion.datosFiscales = new HDIAutos.DatosFiscales()
                    {
                        nombre = ($"{cliente.primerNombre} {cliente.segundoNombre} {cliente.apellidoPaterno} {cliente.apellidoMaterno}").Trim(),
                        rfc = cliente.rfc,
                        idRegimenFiscal = requimenFiscal,
                        idRegimenSocietario = regimenCapital,
                        CPFiscal = cliente.Direccion.codigoPostal,
                        idCIF = "0",
                        direccionFiscal = new HDIAutos.DireccionFiscal()
                        {
                            calle = cliente.Direccion.calle,
                            numeroExterior = cliente.Direccion.numeroExterior,
                            numeroInterior = string.IsNullOrEmpty(cliente.Direccion.numeroInterior) ? "0" : cliente.Direccion.numeroInterior,
                            colonia = cliente.Direccion.colonia,
                            ciudad = cliente.Direccion.ciudad,
                            estado = cliente.Direccion.estado
                        }
                    };

                    _facturacion.RFC = requestCotizacion.datosFiscales.rfc;
                    _facturacion.Nombre = requestCotizacion.datosFiscales.nombre;
                    _facturacion.CodigoPostal = requestCotizacion.datosFiscales.CPFiscal;

                    Utilidades.Utilidades.GeneraRegistroFacturacion(_facturacion);
                }

                requestCotizacion.SumaAsegurada = requestPaquetes.SumaAsegurada;
                requestPaquetes.usuario = requestPaquetes.usuario;
                var xmlCotizacionEnvio = ObjectSerializer<HDIAutos.DatosCotizacion>.Serialize(requestCotizacion);
                log.Info(string.Format("Emisión HDI Cotizacion-Request: {0}", xmlCotizacionEnvio.Replace("\n", "").Replace("\r", "")));
                var responseCotizacion = servicio.GuardarCotizacion(requestCotizacion, requestPaquetes.usuario);

                var xmlCotizacionRespuesta = ObjectSerializer<HDIAutos.InformacionCotizacion>.Serialize(responseCotizacion);


                log.Info(string.Format("Emisión HDI Cotizacion-Response: {0}", xmlCotizacionRespuesta.Replace("\n", "").Replace("\r", "")));

                if (responseCotizacion.errores.Any())
                {
                    var erroresCotizacion = string.Join(", ", responseCotizacion.errores.Select(a => a.descripcion).ToList());
                    result = new EmisionPoliza(false, xmlCotizacionEnvio, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde. " + erroresCotizacion, null);
                }
                else
                {
                    var requestEmision = new HDIAutos.EmiteCotGuardadaRequest();

                    requestEmision.IdAgencia = responseCotizacion.idOficina;
                    requestEmision.IdCotizacion = responseCotizacion.idCotizacion;
                    requestEmision.IdUsuario = requestPaquetes.usuario;

                    requestEmision.listaDatosCotizacion = new HDIAutos.ListaDatosCotizacion();
                    requestEmision.listaDatosCotizacion.Add(requestCotizacion);

                    var infoPago = new HDIAutos.InformacionPago();

                    infoPago.idBanco = 0;
                    infoPago.idTipoTarjeta = 0;
                    infoPago.numCuentaHabiente = "0";
                    infoPago.nombreTitularTarjeta = "0";
                    infoPago.numVencimientoTarjeta = "0";
                    infoPago.numCodigoSeguridad = "0";
                    infoPago.activarEmitirDespuesDePagar = false;  // false emsiones directas true: pago en linea

                    requestEmision.listaDatosCotizacion[0].PaqueteCoberturas = null;
                    requestEmision.listaDatosCotizacion[0].InformacionPago = null;
                    requestEmision.listaDatosCotizacion[0].InformacionAdicionalCorredor = new HDIAutos.InformacionAdicionalCorredor();
                    requestEmision.listaDatosCotizacion[0].InformacionAdicionalCorredor.FechaEmisionFactura = DateTime.Now;



                    xmlEmisionEnvio = ObjectSerializer<HDIAutos.EmiteCotGuardadaRequest>.Serialize(requestEmision);

                    #region Informacion pago

                    if ((InfoEmision.CotizacionAutoGuardar.MediodePago == 0 || InfoEmision.CotizacionAutoGuardar.MediodePago == 1) && InfoEmision.ConDatosBancarios)
                    {

                        infoPago.idBanco = InfoEmision.IdBanco;
                        if (InfoEmision.CotizacionAutoGuardar.MediodePago == 0)
                            infoPago.idTipoTarjeta = 4;
                        else
                            infoPago.idTipoTarjeta = 3;
                        infoPago.numCuentaHabiente = InfoEmision.Tarjeta.NumeroTarjeta;
                        infoPago.nombreTitularTarjeta = InfoEmision.Tarjeta.TitularTarjeta;
                        infoPago.numVencimientoTarjeta = $"{InfoEmision.Tarjeta.MesVencimiento}/{InfoEmision.IdAnio.ToString().Substring(2)}";
                        infoPago.numCodigoSeguridad = InfoEmision.Tarjeta.Cvv;

                        requestEmision.listaDatosCotizacion[0].InformacionPago = infoPago;

                    }

                    #endregion
                    log.Info(string.Format("Emisión HDI Emision-Request: {0}", xmlEmisionEnvio.Replace("\n", "").Replace("\r", "")));
                    var responseEmision = servicio.EmiteCotizacionGuardadaAsync(requestEmision).Result;

                    xmlEmisionRespuesta = ObjectSerializer<HDIAutos.EmiteCotGuardadaResponse>.Serialize(responseEmision);

                    log.Info(string.Format("Emisión HDI Emision-Response: {0}", xmlEmisionRespuesta.Replace("\n", "").Replace("\r", "")));

                    if (responseEmision.InfoEmision.errores.Any())
                    {
                        var erroresEmision = string.Join(", ", responseEmision.InfoEmision.errores.Select(a => a.descripcion).ToList());

                        GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEmisionEnvio, xmlEmisionRespuesta, erroresEmision.Replace("\r\n", ""), "Emisión");

                        result = new EmisionPoliza(false, xmlEmisionEnvio, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde. " + erroresEmision.Replace("\r\n", ""), null);
                    }
                    else
                    {
                        CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
                        int IdPaquete = int.Parse(cotizacionDetalle.Paquete);
                        PaqueteAseguradora tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == InfoEmision.Convenio.IdAseguradora && x.IdCatTipoPaquete == IdPaquete).FirstOrDefault();
                        CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
                        PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();

                        #region DATOS POLIZA

                        Poliza poliza = new Poliza();
                        PolizaDetalle polizaDet = new PolizaDetalle();

                        Endoso endosoAlta = new Endoso();
                        endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                        endosoAlta.Fecha = DateTime.Now;
                        endosoAlta.ValorAnterior = "Alta";
                        endosoAlta.ValorActual = "Contratación";

                        if (InfoEmision.EmisionPersonaMoral)
                        {
                            poliza.IdPersonaMoral = InfoEmision.PersonaMoral.Id;
                            poliza.IdRepresentanteLegal = InfoEmision.PersonaMoralRepresentanteLegal.Id;

                        }

                        poliza.NumeroPoliza = responseEmision.InfoEmision.idPoliza;
                        poliza.FinVigencia = requestEmision.listaDatosCotizacion[0].PaqueteEmitir.ListaConfiguraciones[0].FinVigencia;
                        poliza.InicioVigencia = requestEmision.listaDatosCotizacion[0].PaqueteEmitir.ListaConfiguraciones[0].InicioVigencia;

                        poliza.PrimaNeta = 0;
                        poliza.PrimaNetaAnualizada = 0;
                        poliza.PrimaTotal = 0;
                        poliza.PrimaTotalAnualizada = 0;

                        poliza.Motor = InfoEmision.NumeroMotor;
                        poliza.Serie = InfoEmision.NumeroSerie.ToUpper();
                        poliza.Placas = InfoEmision.Placas;
                        poliza.FechaEmision = DateTime.Now;
                        poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                        poliza.UrlPDFPoliza = "";
                        poliza.UrlPDFRecibos = "";
                        poliza.Estatus = 1;
                        poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                        poliza.IdConvenio = InfoEmision.Convenio.Id;
                        poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                        poliza.IdTipoCobertura = tipoPaquete.IdCatTipoPaquete;
                        poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
                        poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                        poliza.Acepto_DescuentoPoliza = true;

                        polizaDet.Inciso = "1";
                        polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para HDI.
                        polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                        polizaDet.Deducible = 0;
                        polizaDet.Comision = 0;
                        polizaDet.Impuesto = 0;
                        polizaDet.Derechos = 0;
                        polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
                        polizaDet.MigraOPERA = false;
                        polizaDet.UrlPDFPolizaOPERA = "";
                        polizaDet.PolizaOPERA = 0;
                        polizaDet.OTOpera = 0;
                        polizaDet.EndosoOPERA = 0;
                        polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                        polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;
                        polizaDet.IdCatRamoVehiculo = int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                        polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                        polizaDet.IdCatModalidadFormaPago = medioPago.Id;
                        polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
                        polizaDet.XMLRecepcion = xmlEmisionRespuesta;
                        polizaDet.XMLSolicitud = xmlEmisionEnvio;
                        polizaDet.RequestAdicional = xmlCotizacionEnvio;
                        polizaDet.ResponseAdicional = xmlCotizacionRespuesta;
                        polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;


                        List<Recibo> recibosGenerados = new List<Recibo>();
                        var mensajeRecibosPoliza = new HDIAutos.Mensajes();
                        var requestDatosPagoPoliza = new HDIAutos.ObtenerDatosRequest()
                        {
                            idPoliza = responseEmision.InfoEmision.idPoliza
                            ,
                            idCotizacion = responseCotizacion.idCotizacion
                            ,
                            idAgente = requestPaquetes.usuario
                            ,
                            idOficina = responseEmision.InfoEmision.idOficina
                        };
                        var xmlDatosPagoPoliza = ObjectSerializer<HDIAutos.ObtenerDatosRequest>.Serialize(requestDatosPagoPoliza);
                        log.Info(string.Format("Emisión HDI DatosPoliza-Request: {0}", xmlDatosPagoPoliza.Replace("\n", "").Replace("\r", "")));
                        var responseDatosPoliza = servicio.ObtenerDatosPagoPolizaAsync(requestDatosPagoPoliza).Result;

                        var xmlDatosPagoPolizaResponse = ObjectSerializer<HDIAutos.ObtenerDatosPolizaResponse>.Serialize(responseDatosPoliza);
                        log.Info(string.Format("Emisión HDI DatosPoliza-Response: {0}", xmlDatosPagoPolizaResponse.Replace("\n", "").Replace("\r", "")));

                        log.Info("Obtener Recibos Pólizas " + poliza.NumeroPoliza);



                        var resultRecibos = ObtenerRecibosPolizaEmision(InfoEmision.Convenio.Id, poliza.NumeroPoliza);
                        var reciboURL = resultRecibos.Recibos;

                        log.Info("Termina Obtener recibos poliza");

                        var responseRecibos = servicio.ObtenerRecibosDesglosados(new HDIAutos.SolicitudRecibosDesglosados()
                        {
                            IdAgencia = responseEmision.InfoEmision.idOficina,
                            IdCotizacion = responseCotizacion.idCotizacion,
                            Usuario = requestEmision.IdUsuario
                        });

                        foreach (var recibo in responseRecibos.ListaRecibosDesglosados)
                        {
                            Recibo reciboSave = new Recibo();
                            reciboSave.InicioVigencia = recibo.InicioVigencia;
                            reciboSave.FinVigencia = recibo.FinVigencia;
                            reciboSave.Numero = recibo.IdConsecutivo;
                            reciboSave.NoAsegurado = recibo.IdConsecutivo.ToString();
                            reciboSave.PrimaNeta = recibo.PrimaNeta;
                            reciboSave.PrimaTotal = recibo.PrimaTotal;
                            reciboSave.Derecho = recibo.DerechoPoliza;
                            reciboSave.Recargo = 0;
                            reciboSave.Comision = recibo.Financiamiento;
                            reciboSave.Impuesto = recibo.IVA;
                            recibosGenerados.Add(reciboSave);

                        }

                        poliza.PrimaTotal = responseDatosPoliza.InfoPoliza.totales.PrimaTotal;
                        poliza.PrimaNeta = responseDatosPoliza.InfoPoliza.totales.PrimaNeta;

                        polizaDet.Derechos = responseDatosPoliza.InfoPoliza.totales.DerechoPoliza;
                        polizaDet.Impuesto = responseDatosPoliza.InfoPoliza.totales.IVA;
                        polizaDet.Comision = responseDatosPoliza.InfoPoliza.totales.Comision;

                        poliza.PrimaNetaAnualizada = poliza.PrimaNeta;
                        poliza.PrimaTotalAnualizada = poliza.PrimaTotal;

                        endosoAlta.Recibo = recibosGenerados;
                        poliza.Endoso.Add(endosoAlta);
                        poliza.PolizaDetalle.Add(polizaDet);
                        db.Poliza.Add(poliza);
                        db.SaveChanges();

                        poliza.UrlPDFPoliza = ObtenerPoliza(poliza.NumeroPoliza);

                        #endregion

                        GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEmisionEnvio, xmlEmisionRespuesta, "", "Emisión");

                        Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                        result = new EmisionPoliza(true, xmlEmisionEnvio, xmlEmisionRespuesta, poliza);


                    }
                }

            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente para realizar tu emision {0} ", ex.Message));

                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEmisionEnvio, xmlEmisionRespuesta, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");

                //throw new Exception(string.Format("Tuvimos un inconveniente para realizar tu emision {0} ", ex.Message));
                result = new EmisionPoliza(false, xmlEmisionEnvio, ex.Message);
            }
            return result;
        }

        public byte[] ImprimirPoliza(string poliza)
        {
            try
            {

                var _poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == poliza);
                var _polizadetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == _poliza.Id);
                var responseEmision = Utilidades.Utilidades.ToObject<HDIAutos.EmiteCotGuardadaResponse>(_polizadetalle.XMLRecepcion);
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == _poliza.IdConvenio);
                var servicio = InitializeClient(convenio.Usuario, convenio.Contrasena);
                var requestPDF = new HDIAutos.PolizaAImprimir();

                requestPDF.Agencia = responseEmision.InfoEmision.idOficina;
                requestPDF.Cotizacion = responseEmision.InfoEmision.idCotizacion;
                requestPDF.NumeroDocumento = 0;
                requestPDF.NumeroPoliza = responseEmision.InfoEmision.idPoliza;
                requestPDF.usuario = convenio.Usuario;

                //var responsePDF = servicio.ObtenerPolizaSinRecibosPDF(requestPDF);
                var responsePDF = servicio.ObtenerPolizaPDF(requestPDF);

                return responsePDF.ByteArray;
            }
            catch (Exception ex)
            {
                log.Info(string.Format("HDI - ImprimirPoliza Tuvimos un inconveniente para imprimir la poliza {0} ", ex.InnerException != null ? ex.InnerException.Message : ex.Message));
                return null;
            }

        }

        public string ObtenerPoliza(string poliza)
        {
            try
            {
                var _documento = ImprimirPoliza(poliza);

                string RutaDescargaPDFsPolizas = HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/");
                string directorio = string.Format(@"{0}\{1}", RutaDescargaPDFsPolizas, "HDI");
                var rutaGuardadoPDFTemp = string.Concat(directorio, @"\", poliza, ".pdf");

                if (!Directory.Exists(directorio))
                {
                    Directory.CreateDirectory(directorio);
                }

                if (!File.Exists(rutaGuardadoPDFTemp))
                {
                    File.WriteAllBytes(rutaGuardadoPDFTemp, _documento);
                }

                return rutaGuardadoPDFTemp;
            }
            catch (Exception ex)
            {
                log.Info(string.Format("HDI - ObtenerPoliza Tuvimos un inconveniente para imprimir la poliza {0} ", ex.InnerException != null ? ex.InnerException.Message : ex.Message));
                return string.Empty;
            }
        }

        public void PRuebaDatosPoloza()
        {
            var servicio = new HDIAutos.PublicServicesAutosContractClient();
            var requestDatosPagoPoliza = new HDIAutos.ObtenerDatosRequest()
            {
                idPoliza = "0000000128"
                           ,
                idCotizacion = "0000001539"
                           ,
                idAgente = "0549400001"
                           ,
                idOficina = "00091"
            };

            var mensajes = new HDIAutos.Mensajes();
            var responseRecibosPoliza = servicio.ObtenerDatosPagoPoliza("0000000128", "0000001539", "0549400001", "00091", out mensajes);

            var xmlDatosPagoPoliza = ObjectSerializer<HDIAutos.ObtenerDatosRequest>.Serialize(requestDatosPagoPoliza);
            var xmlDatosPagoPolizaResponse = ObjectSerializer<HDIAutos.DatosPagosResult>.Serialize(responseRecibosPoliza);

        }

        public RecibosAseguradoraViewModel ObtenerRecibosPolizaEmision(int idConvenio, string numeroPoliza)
        {
            var resultado = new RecibosAseguradoraViewModel();
            var recibos = new List<sp_POLIZA_Recibos>();

            resultado.Exitoso = true;

            try
            {
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                var url = Utilidades.Utilidades.ObtienerValorParametro("URL_PAGOS_RECIBOS_HDI");

                var servicio = InitializeClient(convenio.Usuario, convenio.Contrasena);
                var request = new HDIAutos.SolicitudesPolizaInfo();

                request.Add(new HDIAutos.SolicitudPolizaInfo()
                {
                    IdAgencia = "00091",
                    IdCertificado = 1,
                    IdPoliza = numeroPoliza
                });

                log.Info("Entra a consultar los recibos HDI");

                var _recibosHDI = servicio.ObtenerPolizaRecibos(convenio.Usuario, request);
                var xmlEmisionEnvio = ObjectSerializer<HDIAutos.SolicitudesPolizaInfo>.Serialize(request);

                log.Info("XML envio: " + xmlEmisionEnvio);

                var xmlEmisionRespuesta = ObjectSerializer<HDIAutos.RecibosInfo>.Serialize(_recibosHDI);

                log.Info("XML respuesta: " + xmlEmisionRespuesta);



                if (_recibosHDI.Any())
                {
                    resultado.EstatusPoliza = "Activa";

                    if (_recibosHDI.Exists(a => a.EstatusRecibo.ToUpper() == "CANCELADO"))
                        resultado.EstatusPoliza = "Cancelada";

                    foreach (var _item in _recibosHDI)
                    {
                        var recibo = new sp_POLIZA_Recibos();
                        recibo.FDesde = _item.InicioVigencia;
                        recibo.FHasta = _item.FinVigencia;
                        recibo.PrimaTotal = Convert.ToDouble(_item.PrimaTotal);
                        recibo.IdRecibo = _item.IdRecibo;
                        recibo.Referencia = _item.ReferenciaInternet;
                        recibo.Periodo = _item.Consecutivo;
                        recibo.Estatus = _item.EstatusRecibo;
                        recibo.FechaPago = _item.FechaLimitePago;

                        if (!string.IsNullOrEmpty(recibo.Referencia))
                            recibo.URLPago = $"{url}{recibo.Referencia}";

                        recibos.Add(recibo);



                    }

                    resultado.Recibos = recibos;


                }
                else
                {
                    resultado.Exitoso = false;
                }



            }
            catch (Exception ex)
            {
                log.Info("HDI Ocurrio una excepción al ObtenerRecibosPoliza error: " + ex.ToString());

                resultado.Exitoso = false;
            }
            return resultado;

        }


        public RecibosAseguradoraViewModel ObtenerRecibosPoliza(int idConvenio, string numeroPoliza, string userName)
        {
            var resultado = new RecibosAseguradoraViewModel();
            var recibos = new List<sp_POLIZA_Recibos>();

            resultado.Exitoso = true;

            try
            {
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                var url = Utilidades.Utilidades.ObtienerValorParametro("URL_PAGOS_RECIBOS_HDI");

                var servicio = InitializeClient(convenio.Usuario, convenio.Contrasena);
                var request = new HDIAutos.SolicitudesPolizaInfo();

                request.Add(new HDIAutos.SolicitudPolizaInfo()
                {
                    IdAgencia = "00091",
                    IdCertificado = 1,
                    IdPoliza = numeroPoliza
                });

                log.Info("Entra a consultar los recibos HDI");

                var _recibosHDI = servicio.ObtenerPolizaRecibos(convenio.Usuario, request);
                var xmlEmisionEnvio = ObjectSerializer<HDIAutos.SolicitudesPolizaInfo>.Serialize(request);

                log.Info("XML envio: " + xmlEmisionEnvio);

                var xmlEmisionRespuesta = ObjectSerializer<HDIAutos.RecibosInfo>.Serialize(_recibosHDI);

                log.Info("XML respuesta: " + xmlEmisionRespuesta);

                var idReferencia = Utilidades.Utilidades.RegistroConsultaReciboAseguradora(20, numeroPoliza, xmlEmisionEnvio, xmlEmisionRespuesta, userName);

                resultado.IdReferencia = idReferencia;

                if (_recibosHDI.Any())
                {
                    #region ESTATUS ASEGURADORA
                    resultado.EstatusPoliza = "Activa";

                    if (_recibosHDI.Exists(a => a.EstatusRecibo.ToUpper() == "CANCELADO"))
                        resultado.EstatusPoliza = "Cancelada";



                    Utilidades.Utilidades.RegistroEstatusAseguradora(numeroPoliza, resultado.EstatusPoliza, idReferencia, userName);
                    #endregion

                    foreach (var _item in _recibosHDI)
                    {
                        var recibo = new sp_POLIZA_Recibos();
                        recibo.FDesde = _item.InicioVigencia;
                        recibo.FHasta = _item.FinVigencia;
                        recibo.PrimaTotal = Convert.ToDouble(_item.PrimaTotal);
                        recibo.IdRecibo = _item.IdRecibo;
                        recibo.Referencia = _item.ReferenciaInternet;
                        recibo.Periodo = _item.Consecutivo;
                        recibo.Estatus = _item.EstatusRecibo;
                        //recibo.FechaPago = _item.FechaLimitePago;

                        if (!string.IsNullOrEmpty(recibo.Referencia))
                            recibo.URLPago = $"{url}{recibo.Referencia}";

                        recibos.Add(recibo);

                        if (idReferencia > 0)
                            RegistroReciboAseguradora(idReferencia, _item);

                    }

                    resultado.Recibos = recibos;

                    ActualizacionRecibosLONE(idReferencia, userName);

                    var opera = new DerivacionOperaService();
                    opera.ActualizarRecibosOpera(idReferencia);


                }
                else
                {
                    resultado.Exitoso = false;
                }



            }
            catch (Exception ex)
            {
                log.Info("HDI Ocurrio una excepción al ObtenerRecibosPoliza error: " + ex.ToString());

                resultado.Exitoso = false;
            }
            return resultado;

        }



        public void ActualizacionRecibosLONE(int idReferencia, string userName)
        {
            var bitacora = db.ReciboAseguradora_Bitacora.FirstOrDefault(a => a.Id == idReferencia);
            try
            {
                var recibosAseguradora = db.ReciboAseguradora.Where(a => a.IdReferencia == idReferencia).ToList();
                var reciboAseguradoraFisrt = recibosAseguradora.First();
                var endosoOpera = 0;
                var totalPagos = recibosAseguradora.Max(a => a.Consecutivo);

                var poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == bitacora.NumeroPoliza);

                //var polizaDetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == poliza.Id);

                var numeroPoliza = new SqlParameter("@Poliza", bitacora.NumeroPoliza);
                var recibosLONE = db.sp_POLIZA_Recibos.SqlQuery("sp_POLIZA_Recibos @Poliza", numeroPoliza).ToList();

                if (poliza != null)
                {
                    var polizaDetalle = db.PolizaDetalle.FirstOrDefault(a => a.IdPoliza == poliza.Id);

                    endosoOpera = polizaDetalle.EndosoOPERA;

                }

                if (recibosLONE.Count == recibosAseguradora.Count)
                {

                    foreach (var reciboAseguradora in recibosAseguradora)
                    {
                        var recibo = recibosLONE.FirstOrDefault(a => a.Periodo == reciboAseguradora.Consecutivo);

                        if (recibo != null)
                        {
                            var _d = new ReciboAseguradora_Discrepancia();
                            var _registraDiscrepancia = false;

                            decimal _pt = 0;
                            var observaciones = new List<string>();
                            var relacionEstatus = db.ReciboAseguradora_Estatus.FirstOrDefault(a => a.IdAseguradora == 20 && a.EstatusAseguradora.ToUpper() == reciboAseguradora.EstatusRecibo.ToUpper());




                            _d.IdReferencia = idReferencia;
                            _d.IdRecibo = reciboAseguradora.IdRecibo;
                            _d.NumeroPoliza = bitacora.NumeroPoliza;
                            _d.PolizaEndoso = endosoOpera.ToString();
                            _d.Fecha = DateTime.Now;
                            _d.ActualizadoPor = userName;
                            _d.Recibo = reciboAseguradora.IdRecibo.ToString();
                            _d.NoRecibo = reciboAseguradora.Consecutivo.ToString();
                            _d.TotalPagos = totalPagos;

                            if (reciboAseguradora.EstatusRecibo.ToUpper() == "PAGADO"
                                && recibo.EstatusLONE.ToUpper() != reciboAseguradora.EstatusRecibo.ToUpper())
                            //&& reciboAseguradora.FechaPago.HasValue)
                            {
                                _registraDiscrepancia = true;
                                _d.EstatusRecibo = $"Estatus de la aseguradora se encuentra pagado, Aseguradora {reciboAseguradora.EstatusRecibo} -  LONE {recibo.EstatusLONE};";
                                observaciones.Add($"Estatus de la aseguradora se encuentra pagado, Aseguradora {reciboAseguradora.EstatusRecibo} -  LONE {recibo.EstatusLONE};");

                                //db.Database.ExecuteSqlCommand($"sp_POLIZA_Actualizar_Recibo @IdRecibo={recibo.IdRecibo}, @Fecha = '{reciboAseguradora.FechaPago.Value.ToString("yyyy-MM-dd")}'");
                                db.Database.ExecuteSqlCommand($"sp_POLIZA_Actualizar_Recibo @IdRecibo={recibo.IdRecibo}, @Fecha = '{DateTime.Now.ToString("yyyy-MM-dd")}'");
                            }


                            if (decimal.TryParse(recibo.PrimaTotal == null ? "" : recibo.PrimaTotal.ToString(), out _pt))
                            {
                                if (_pt != Math.Round(reciboAseguradora.PrimaTotal, 2))
                                {
                                    _registraDiscrepancia = true;
                                    _d.PrimaTotalRecibos = $"Diferencia en Prima Total Recibo, Aseguradora {reciboAseguradora.PrimaTotal} -  LONE {recibo.PrimaTotal};";
                                    observaciones.Add($"Diferencia en Prima Total Recibo, Aseguradora {reciboAseguradora.PrimaTotal} -  LONE {recibo.PrimaTotal};");
                                }
                            }
                            else
                            {
                                _registraDiscrepancia = true;
                                _d.PrimaTotalRecibos = $"Diferencia en Prima Total Recibo, Aseguradora {reciboAseguradora.PrimaTotal} -  LONE {recibo.PrimaTotal};";
                                observaciones.Add($"Diferencia en Prima Total Recibo, Aseguradora {reciboAseguradora.PrimaTotal} -  LONE {recibo.PrimaTotal};");
                            }

                            observaciones.Add($"Estatus de la asegurada - {reciboAseguradora.EstatusRecibo}, Estatus LONE - {relacionEstatus.EstatusAseguradora}");

                            if (relacionEstatus.EstatusLONE.ToUpper() != recibo.EstatusLONE.ToUpper())
                            {
                                var _estatus = db.ReciboAseguradora_Estatus.FirstOrDefault(a => a.IdAseguradora == 20 && a.EstatusAseguradora == reciboAseguradora.EstatusRecibo);

                                if (_estatus != null)
                                {
                                    _registraDiscrepancia = true;
                                    _d.EstatusRecibo = $"Diferencia en Estatus, Aseguradora {reciboAseguradora.EstatusRecibo} -  LONE {relacionEstatus.EstatusAseguradora};";

                                    db.Database.ExecuteSqlCommand($"sp_POLIZA_Actualizar_Recibo @IdRecibo={recibo.IdRecibo}, @Estatus = '{_estatus.EstatusLONE}'");

                                    var _ep = new ReciboAseguradora_CambioEstatusRecibo()
                                    {
                                        IdReferencia = idReferencia,
                                        ActualizadoPor = userName,
                                        EstatusAnterior = relacionEstatus.EstatusAseguradora,
                                        EstatusNuevo = reciboAseguradora.EstatusRecibo,
                                        Fecha = DateTime.Now,
                                        Motivo = "Diferencia Valores",
                                        NumeroPoliza = bitacora.NumeroPoliza,
                                        Origen = "LONE",
                                        IdReciboAseguradora = reciboAseguradora.IdRecibo,
                                        Consecutivo = reciboAseguradora.Consecutivo
                                    };

                                    db.ReciboAseguradora_CambioEstatusRecibo.Add(_ep);
                                    db.SaveChanges();
                                }

                            }

                            reciboAseguradora.Observacion = string.Join(" | ", observaciones);
                            db.SaveChanges();

                            if (_registraDiscrepancia)
                            {
                                db.ReciboAseguradora_Discrepancia.Add(_d);
                                db.SaveChanges();
                            }

                        }
                        else
                        {
                            var discrepancia = new ReciboAseguradora_Discrepancia()
                            {
                                IdReferencia = idReferencia,
                                ActualizadoPor = userName
                    ,
                                PolizaEndoso = endosoOpera.ToString(),
                                NumeroPoliza = bitacora.NumeroPoliza
                    ,
                                Fecha = DateTime.Now,
                                Recibo = $"Recibo no encontrado en LONE {reciboAseguradora.IdRecibo} - {reciboAseguradora.Consecutivo};"
                            };

                            db.ReciboAseguradora_Discrepancia.Add(discrepancia);

                            reciboAseguradora.Observacion = $"Recibo no encontrado en LONE {reciboAseguradora.IdRecibo} - {reciboAseguradora.Consecutivo};";
                            db.SaveChanges();
                        }
                    }

                }
                else
                {
                    var discrepancia = new ReciboAseguradora_Discrepancia()
                    {
                        IdReferencia = idReferencia,
                        ActualizadoPor = userName
                    ,
                        PolizaEndoso = endosoOpera.ToString(),
                        NumeroPoliza = bitacora.NumeroPoliza
                    ,
                        Fecha = DateTime.Now,
                        TotalPagos = reciboAseguradoraFisrt.TotalPagos
                    ,
                        NoRecibo = $"No Recibos Aseguradora {reciboAseguradoraFisrt.TotalPagos}, No Recibos LONE {recibosLONE.Count}, Diferencia en número de recibos"
                    };

                    db.ReciboAseguradora_Discrepancia.Add(discrepancia);

                    bitacora.Observaciones = $"No Recibos Aseguradora {reciboAseguradoraFisrt.TotalPagos}, No Recibos LONE {recibosLONE.Count}, Diferencia en número de recibos";
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                bitacora.Observaciones = "Error ACTUALIZAR RECIBOS HDI - " + ex.ToString();
                db.SaveChanges();
            }
        }


        public void RegistroReciboAseguradora(int idReferencia, HDIAutos.ReciboInfo recibo)
        {
            try
            {
                var item = new ReciboAseguradora();

                item.IdReferencia = idReferencia;
                item.IdAgencia = recibo.IdAgencia;
                item.IdRecibo = recibo.IdRecibo;
                item.NumeroPoliza = recibo.IdPoliza;
                item.IdCertificado = recibo.IdCertificado;
                item.Consecutivo = recibo.Consecutivo;
                item.EstatusRecibo = recibo.EstatusRecibo;
                item.InicioVigencia = recibo.InicioVigencia;
                item.FinVigencia = recibo.FinVigencia;
                item.FechaLimitePago = recibo.FechaLimitePago;
                item.Folio = recibo.Folio;
                item.PrimaTotal = recibo.PrimaTotal;
                item.Referencia = recibo.ReferenciaInternet;

                db.ReciboAseguradora.Add(item);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                log.Info("HDI Ocurrio una excepción al RegistroReciboAseguradora error: " + ex.InnerException.InnerException != null ? ex.InnerException.InnerException.Message : ex.Message);
            }

        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new NotImplementedException();
        }
        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
        private DatosVehiculoHDI ObtenerDatosVehiculo(string clave)
        {
            DatosVehiculoHDI result = new DatosVehiculoHDI();

            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["CatalogoHomologado"].ToString()))
            {
                using (SqlCommand cmd = new SqlCommand("spConsultaHDI", connection))
                {
                    SqlParameter amis = new SqlParameter("@IdHDI", clave);

                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(amis);
                    connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            result.IdTipoVehiculo = Convert.ToInt32(dr["IdTipoVehiculo"]);
                            result.IdTipoVehiculoHDI = Convert.ToInt32(dr["IdTipoVechiculoHDI"]);
                            result.IdMarca = Convert.ToInt32(dr["IdMarca"]);
                            result.IdTransmision = Convert.ToInt32(dr["IdTransmision"]);
                            result.Tipo = dr["Modelo"].ToString();
                            result.Version = dr["Version"].ToString();
                        }
                    }

                    connection.Close();
                }
            }

            return result;
        }

        private InfoUbicacionHDI ObtenerDatosCP(string codigoPostal, HDIAutos.PublicServicesAutosContractClient servicio)
        {

            var info = servicio.ObtenerInformacionPorCodigoPostal(codigoPostal);
            var result = new InfoUbicacionHDI();

            result.IdCiudad = info.FirstOrDefault().IdCiudad;
            result.IdEstado = info.FirstOrDefault().IdEstado;

            return result;


        }
        private string ObtenerTipoPaquete(int idTipoPaquete, int idTipoVehiculo)
        {
            var tipopaquete = db.HDI_TipoPaquete.FirstOrDefault(a => a.IdTipoVehiculo == idTipoVehiculo && a.IdTipoPaquete == idTipoPaquete);

            return tipopaquete == null ? "19" : tipopaquete.Paquete;
        }

        private List<Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete, int IdTipoVehiculo, int idPaqueteConvenio)
        {

            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio
                                           && a.IdCatTipoPaquete == idPaquete
                                           && c.IdCatRamoVehiculo == IdTipoVehiculo
                                           && a.IdPaqueteConvenio == idPaqueteConvenio
                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", ""),
                                               IdCatRamo = c.IdCatRamoVehiculo,
                                               IdCobertura = b.Id,
                                               IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1
                                           }).ToList();
            return coberturas;
        }
        public bool EsCoberturaConCondicionEspecial(int Idconvenio, string IdCobertura, string Anio, int idCatRamoVehiculo)
        {

            bool Aplica = true;
            int Clave = int.Parse(IdCobertura);

            LocktonModel.VModels.Coberturas cotCob = new LocktonModel.VModels.Coberturas();

            //Auto En agencia
            LocktonModel.db.CoberturasCondicionesEspeciales coberturasCondicionesEspeciales = db.CoberturasCondicionesEspeciales.FirstOrDefault(x => x.IdConvenio == Idconvenio && x.IdCobertura == Clave && x.CondicionEspecial.Estatus == true && x.IdCatRamoVehiculo == idCatRamoVehiculo);
            LocktonModel.db.CondicionEspecial condicionEspecial = new LocktonModel.db.CondicionEspecial();
            if (coberturasCondicionesEspeciales != null)
                condicionEspecial = db.CondicionEspecial.FirstOrDefault(x => x.Id == coberturasCondicionesEspeciales.IdCondicionEspecial && x.Estatus == true);

            ///Reparacion En agencia
            if (condicionEspecial.Valor1 != null && condicionEspecial.Valor2 != null)
            {
                if (int.Parse(condicionEspecial.Valor1) <= int.Parse(Anio) && int.Parse(Anio) <= int.Parse(condicionEspecial.Valor2))
                {
                    Aplica = true;
                }
                else
                    Aplica = false;
            }

            return Aplica;
        }

    }
    public class DatosVehiculoHDI
    {
        public int IdTipoVehiculo { get; set; }
        public int IdTipoVehiculoHDI { get; set; }
        public int IdMarca { get; set; }
        public int IdTransmision { get; set; }
        public string Tipo { get; set; }
        public string Version { get; set; }
    }

    public class InfoUbicacionHDI
    {
        public string IdEstado { get; set; }
        public string IdCiudad { get; set; }
    }
}
