﻿using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.CotizacionEmisionAtlas;
using LocktonServicios.ImpresionATLAS;
using log4net;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace LocktonServicios.Aseguradoras
{
    public class ATLASService : IOperacionesAseguradoras
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(ATLASService));
        ApplicationDbContext db = new ApplicationDbContext();


        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("yyyy-MM-dd");
                var cotiza_Atlas = ToObject<Cotiza_Atlas>(xmlEmision);

                cotiza_Atlas.DatosEndoso[0].FechaIni = date;

                WSSegAtlasImplClient cliente = new WSSegAtlasImplClient();
                Cotizador cotizador = cliente.WS_atlas_cotiza(cotiza_Atlas);
                string xmlRespuesta = XMLCotizacionResponse(cotizador);

                resultado.XMLRecepcion = xmlRespuesta;
                resultado.XMLSolicitud = XMLCotizacionRequest(cotiza_Atlas);

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CotizacionCompara CotizarVehiculo(CotizacionCompara cotizacionCompara, int? IdConvenio, mDetalles cot, int IdTipoPaquete, int idPaqueteConvenio)
        {
            Convenio convenio = db.Convenio.Where(x => x.Id == IdConvenio).FirstOrDefault();
            var _xmlEnvio = "";
            try
            {

                var configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == convenio.IdEmpresa);

                int? TipoNegocio = configuracionEmpresa.IdTipoDeNegocio;
                bool EsFlotilla = TipoNegocio == 1 || TipoNegocio == 4 || TipoNegocio == 5;

                bool peridoenrrollment = Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenio.IdEmpresa, DateTime.Now);

                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);

                int ItpoV = Convert.ToInt32(cotizacionCompara.TipoVehiculo);
                ConvenioRamoPaquete paqueteRamoConvenio = db.ConvenioRamoPaquete
                                           .Where(x => x.IdConvenio == convenio.Id && x.IdCatRamoVehiculo == ItpoV)
                                               .FirstOrDefault();

                WSSegAtlasImplClient cliente = new WSSegAtlasImplClient();
                Cotiza_Atlas cotiza_Atlas = new Cotiza_Atlas();
                var fechaCotizacionATLAS = cotizacionCompara.FechaInicio;
                //SECCIÓN DATOSENDOSO
                DatosEndoso datosEndoso = new DatosEndoso();
                datosEndoso.AEmision = 0;

                datosEndoso.FechaIni = cotizacionCompara.FechaInicio.ToString("yyyy-MM-dd");
                datosEndoso.FinVigenciaCot = cotizacionCompara.FechaFin.ToString("yyyy-MM-dd");

                //if (configuracionEmpresa.AplicaFechaCotizacion)
                //{
                //    fechaCotizacionATLAS = cotizacionCompara.FechaCotizacion;
                //    datosEndoso.FechaIni = cotizacionCompara.FechaCotizacion.ToString("yyyy-MM-dd");
                //    datosEndoso.FinVigenciaCot = cotizacionCompara.FechaCotizacion.AddYears(1).ToString("yyyy-MM-dd");
                //}
                ////obtener la fecha de inicio y fin de la configuracion
                //if (EsFlotilla)//flotilla
                //{
                //    //verifica las fechas de inicio
                //    if (peridoenrrollment)
                //    {//busca si existe fecha de enrollment
                //        fechaCotizacionATLAS = convenio.InicioVigencia;
                //        datosEndoso.FechaIni = convenio.InicioVigencia.ToString("yyyy-MM-dd");
                //    }
                //    datosEndoso.FinVigenciaCot = convenio.FinVigencia.ToString("yyyy-MM-dd");

                //}

                datosEndoso.NoReexp = 1;
                List<DatosEndoso> datosEndosoList = new List<DatosEndoso>();
                datosEndosoList.Add(datosEndoso);
                cotiza_Atlas.DatosEndoso = datosEndosoList.ToArray();
                //SECCION DATOSNUEVACOT
                List<DatosNuevaCot> datosNuevaCotList = new List<DatosNuevaCot>();
                DatosNuevaCot datosNuevaCot = new DatosNuevaCot();
                PeriodicidadFormaPago periodicidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == IdConvenio && x.IdCatPeriodicidadFormaPago == cotizacionCompara.FormadePago).FirstOrDefault();
                datosNuevaCot.Agente = Convert.ToInt32(periodicidad.ClaveAgente); // 851;

                List<Coberturas1> coberturas1 = new List<Coberturas1>();
                List<LocktonModel.VModels.Coberturas> cob = ObtenerCoberturas(convenio.Id, IdTipoPaquete, Convert.ToInt32(cotizacionCompara.TipoVehiculo), idPaqueteConvenio);
                foreach (LocktonModel.VModels.Coberturas c in cob)
                {
                    try
                    {
                        Coberturas1 cobertura = new Coberturas1();
                        cobertura.Cobertura = c.Codigo != null ? long.Parse(c.Codigo) : 0;
                        cobertura.Deducible = c.Deducible != null ? (long)double.Parse(c.Deducible) : 0;
                        cobertura.SumaAsegurada = c.SumaAsegurada != null ? long.Parse(c.SumaAsegurada) : 0;
                        //cobertura.SumaAsegurada = c.SumaAsegurada;
                        coberturas1.Add(cobertura);
                    }
                    catch (Exception)
                    {
                        log.Info("Cobertura sin código, se salta");
                    }

				}
				datosNuevaCot.Coberturas = coberturas1.ToArray();
				datosNuevaCot.CveCalculo = 1; // este esta pendiente, no se de donde agarrarlo
				datosNuevaCot.CveNegocio = 3;//Fijo 3
				//datosNuevaCot.CveUdi = 0;
				datosNuevaCot.CveUdi = paqueteRamoConvenio.UDIClave;
                if (cot.Catalogo.Count == 0)
				{
					try
					{
						foreach (string clave in cotizacionCompara.ClaveHomologadaSeleccionada.Split(','))
						{
							if (clave.Split('|')[0].ToUpper().Equals(convenio.Aseguradora.ClaveHomologado.ToUpper()))
							{
								datosNuevaCot.CveVehiculo = long.Parse(clave.Split('|')[1]);
								break;
							}
						}
					}
					catch (Exception)
					{
						datosNuevaCot.CveVehiculo = 0;
					}
					//datosNuevaCot.DescVehiculo = cotizacionCompara.Descripcion;
				}
				else
				{
					descripciones _cotDesAuto = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault();
					datosNuevaCot.CveVehiculo = long.Parse(_cotDesAuto.clave); //11668;
																			   //datosNuevaCot.DescVehiculo = _cotDesAuto.Descripcion;// "MAZDA CX - 3 I TRANSMISION AUTOMATICA";
				}

                datosNuevaCot.Descuento = convenio.Descuento;
                datosNuevaCot.DobleRem = "N";//No se si haya que agregar esta opcion para doble remolque
                                             //var EdoCircula = db.CatCodigoPostal.Where(x => x.Codigo == cotizacionCompara.CodigoPostal).Select(x => x.IdCiudadCotizacion).FirstOrDefault();

                var codigoPostal = cotizacionCompara.CodigoPostal;
                if (convenio.ZonaCirculacion == 2)
                    codigoPostal = convenio.CodigoPostal.ToString().PadLeft(5, '0');

                string EdoCircula = (
                    from CodigoPostal in db.CatCodigoPostal
                    join CatEstadosRepublica in db.CatEstadosRepublica on CodigoPostal.IdEstado equals CatEstadosRepublica.Id
                    where CodigoPostal.Codigo == codigoPostal
                    select CatEstadosRepublica.Clave
                    ).FirstOrDefault();

                if (EdoCircula != null && int.TryParse(EdoCircula, out int parsed))
                {
                    datosNuevaCot.EdoCircula = parsed;
                }
                else
                {
                    datosNuevaCot.EdoCircula = 9;
                }

                datosNuevaCot.FPago = long.Parse(periodicidad.FormaPago);
                datosNuevaCot.Modelo = long.Parse(cotizacionCompara.Año);
                datosNuevaCot.Moneda = 1;// este esta pendiente, creo que hay que agregarlo
                datosNuevaCot.No_pasajeros = 0;//Fijo 0
                datosNuevaCot.Plan = paqueteConvenio.IdPlan != null ? long.Parse(paqueteConvenio.IdPlan.ToString()) : long.Parse(db.PaqueteAseguradora.Where(x => x.IdAseguradora == convenio.IdAseguradora && x.IdCatTipoPaquete == paqueteConvenio.IdCatTipoPaquete).Select(x => x.Clave).FirstOrDefault());
                datosNuevaCot.Servicio = 1;//Fijo 1
                datosNuevaCot.TipCveVehi = 1;//Fijo 1
                datosNuevaCot.TipoCarga = cotizacionCompara.TipoVehiculo == "1" ? 0 : 1;
                datosNuevaCot.Tipo_Uso = 1;//Fijo 1
                datosNuevaCot.Uso = 1;//En el catálogo adicional solo esta el valor 1 para particular, por eso se deja fijo

                //Validamos si viaja a Valor Factura y si tiene un valor escrito.
                if (cotizacionCompara.ValorFactura && cotizacionCompara.MontoFactura > 0)
                {
                    datosNuevaCot.CveCalculo = 14;
                    datosNuevaCot.ValVehiculo = double.Parse(cotizacionCompara.MontoFactura.ToString());
                }
                //datosNuevaCot.ValVehiculo = 300000;
                datosNuevaCotList.Add(datosNuevaCot);
                if (EsFlotilla)
                {
                    //  string[] polizaMaestra = "D00-24-526032".Split('-');
                    long numeroPolizaMaestra = 0;
                    if (long.TryParse(periodicidad.NumeroPolizaMaestra, out numeroPolizaMaestra))
                    {
                        datosEndoso.NoPoliza = numeroPolizaMaestra; //32796;//hacer dinamica 526032 D00-24-526032
                        datosNuevaCot.Producto = Convert.ToInt32(paqueteRamoConvenio.Producto); //6;
                        datosNuevaCot.Sucursal = periodicidad.Sucursal; //"D00";//revisar si es dinamico
                    }
                }
                else
                {
                    datosEndoso.NoPoliza = 0;
                    datosNuevaCot.Producto = Convert.ToInt32(paqueteRamoConvenio.Producto);//1;
                    datosNuevaCot.Sucursal = periodicidad.Sucursal; //"E87";
                }

                if (convenio.IdCatTipoVigencia == 1)
                    datosNuevaCot.Tipo_Calculo = 2;
                else
                    datosNuevaCot.Tipo_Calculo = 1;

                cotiza_Atlas.DatosNuevaCot = datosNuevaCotList.ToArray();
                //SECCION DATOSSEGURIDAD
                List<DatosSeguridad> datosSeguridadList = new List<DatosSeguridad>();
                DatosSeguridad datosSeguridad = new DatosSeguridad();
                datosSeguridad.CveUsuario = convenio.Usuario;
                datosSeguridad.Password = convenio.Contrasena;
                datosSeguridadList.Add(datosSeguridad);
                cotiza_Atlas.DatosSeguridad = datosSeguridadList.ToArray();
               

                _xmlEnvio = XMLCotizacionRequest(cotiza_Atlas);
                log.Info($"Se consume WS para cotizacion ATLAS REQUEST: {_xmlEnvio}");

                Cotizador cotizador = cliente.WS_atlas_cotiza(cotiza_Atlas);
                
                string xmlRespuesta = XMLCotizacionResponse(cotizador);
                log.Info($"Se obtiene respuesta de cotizasión de WS de ATLAS RESPONSE: {xmlRespuesta}");

                Comparar infoCompara = LeeXmlRespuesta(xmlRespuesta, IdTipoPaquete, convenio.IdAseguradora, paqueteConvenio.IdPlan, paqueteConvenio.Id);
                var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == cotizacionCompara.FormadePago).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == cotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenio.Id && a.IdCatPeriodicidadFormaPago == perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);

                infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                infoCompara.FechaCotizacion = fechaCotizacionATLAS;
                infoCompara.XmlEmision = _xmlEnvio;
                infoCompara.XmlRespuesta = xmlRespuesta;
                infoCompara.IdAseguradora = convenio.IdAseguradora;
                infoCompara.IdConvenio = (int)IdConvenio;
                infoCompara.Aseguradora = "ATLAS";
                infoCompara.Año = DateTime.Now.Year.ToString();
                infoCompara.Cobertura = db.CatTipoPaquete.Where(x => x.Id == IdTipoPaquete).Select(x => x.Clave).FirstOrDefault();
                infoCompara.IdPaqueteConvenio = paqueteConvenio.Id;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                infoCompara.Descripcion = cotizacionCompara.Descripcion;
                infoCompara.FormaPagoEtiqueta = perioricidad.Nombre;
                infoCompara.MedioPagoEtiqueta = mediopago.Nombre;
                infoCompara.IdFormaPago = perioricidad.Id;
                infoCompara.IdMedioPago = mediopago.Id;
                if (paqueteConvenio.CoberturaAdicionalAIG)
                {
                    infoCompara.AplicaCoberturaAdicionalAIG = true;

                    infoCompara.DescargaCoberturaAIG = Utilidades.Utilidades.ContieneTipoDocumentoEmpresa(paqueteConvenio.IdConvenio, 2);
                }

                cotizacionCompara.Comparar.Add(infoCompara);
            }
            catch (Exception ex)
            {

                Comparar infoCompara = new Comparar();
                infoCompara.IdAseguradora = convenio.IdAseguradora;
                infoCompara.IdConvenio = convenio.Id;
                infoCompara.XmlRespuesta = ex.Message;
                infoCompara.XmlEmision = _xmlEnvio;
                infoCompara.Aseguradora = "ATLAS";
                infoCompara.ErrorXML = string.Format("Tuvimos un inconveniente para realizar tu cotizacion: {0}", ex.Message);
                cotizacionCompara.Comparar.Add(infoCompara);

                log.Info(infoCompara.ErrorXML);
                //throw;
            }
            return cotizacionCompara;
        }

        public string XMLCotizacionRequest(Cotiza_Atlas cotiza_Atlas)
        {
            log.Info("Generando XML Envio cotización Atlas");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Cotiza_Atlas));
            XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
            xmlWriterSettings.Indent = true;
            String result = "";
            using (Utf8StringWriter stringWriter = new Utf8StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
                {
                    xmlSerializer.Serialize(xmlWriter, cotiza_Atlas);
                }
                result = stringWriter.ToString();
            }
            return result;
        }

        public string XMLCotizacionResponse(Cotizador cotizador)
        {
            log.Info("Generando XML Respuesta cotización Atlas");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Cotizador));
            XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
            xmlWriterSettings.Indent = true;
            string result = "";
            using (Utf8StringWriter stringWriter = new Utf8StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
                {
                    xmlSerializer.Serialize(xmlWriter, cotizador);
                }
                result = stringWriter.ToString();
            }
            return result;
        }

        public string XMLSerializeToString<T>(T value)
        {
            XmlSerializerNamespaces emptyNamespaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            XmlSerializer serializer = new XmlSerializer(value.GetType());
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;

            using (StringWriter stream = new StringWriter())
            using (XmlWriter writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, value, emptyNamespaces);
                return stream.ToString();
            }
        }

        public Comparar LeeXmlRespuesta(string XmlRecepcion, int TipoPaquete, int IdAseguradora, int? idPlanConvenio, int idPaqueteConvenio)
        {
            List<Cobertura> coberturasPortal = db.Cobertura.Where(x => x.IdPaquete == 4).ToList();

            if (!idPlanConvenio.HasValue)
                idPlanConvenio = int.Parse(db.PaqueteAseguradora.FirstOrDefault(x => x.IdCatTipoPaquete == TipoPaquete && x.IdAseguradora == IdAseguradora).Clave);

            Comparar comparar = new Comparar();
            Cotizador cotizador = ToObject<Cotizador>(XmlRecepcion);
            comparar.FechaInicio = cotizador.FechaInicio;//"2019-09-24";
            comparar.FechaFin = cotizador.FechaTermino;//"2020-09-24";
            comparar.CotizacionClave = cotizador.NumCotiza + "";

            var detalles = db.PaqueteDetalle.Where(a => a.IdPaqueteConvenio == idPaqueteConvenio).ToList();
            var tipoDatos = db.CatTipoDatoDeducible.ToList();

            foreach (Planes p in cotizador.Planes.Where(x => x.Plan == idPlanConvenio))
            {
                comparar.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                foreach (CotizacionEmisionAtlas.Coberturas c in p.Coberturas)
                {
                    LocktonModel.VModels.Coberturas cotCob = new LocktonModel.VModels.Coberturas();
                    cotCob.Cobertura = c.Prima + "";
                    cotCob.SumaAsegurada = c.SumaAseg + "";
                    cotCob.Nombre = "";
                    cotCob.Deducible = c.Deducible + "";
                    cotCob.Codigo = c.Cobertura + "";

                    var coberturaPortal = coberturasPortal.FirstOrDefault(x => x.Clave.Equals(c.Cobertura.ToString()));

                    if (coberturaPortal != null)
                    {
                        cotCob.Nombre = coberturaPortal.Descripcion;

                        var detalle = detalles.FirstOrDefault(a => a.IdCobertura == coberturaPortal.Id);

                        if (detalle != null)
                        {
                            var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == detalle.IdTipoDatoDeducible);

                            if (tipoDato != null)
                            {
                                cotCob.IdTipoDatoDeducible = tipoDato.Id;
                                cotCob.TipoDato = tipoDato.Nombre;
                            }
                        }

                    }


                    comparar.Coberturas.Add(cotCob);
                }
                comparar.PrimaNeta = p.PPrima + "";
                comparar.PrimaTotal = p.PPrimaTot + "";
                comparar.Impuesto = p.PIva + "";
                comparar.Recargo = p.PRecargos + "";
                comparar.Derecho = p.PGastos + "";
                List<Recibos> recibos = p.Recibos.ToList();
                recibos = recibos.OrderBy(x => x.Recibo).ToList();
                p.Recibos = recibos.ToArray();
                comparar.PrimerPago = p.Recibos[0].RPrimaTot + "";
                comparar.NumeroDePagos = p.Recibos.Length;
                if (p.Recibos.Length < 2)
                {
                    comparar.SegundoPago = "";
                }
                else
                {
                    comparar.SegundoPago = p.Recibos[1].RPrimaTot + "";
                }
            }

            foreach (Errores e in cotizador.Errores)
            {
                if (e.CveError != 0)
                {
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(XmlRecepcion);
                    XmlNode errorNode = xml.SelectSingleNode("/Cotizador/Errores");
                    comparar.ErrorXML = errorNode.InnerXml;
                    comparar.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                    break;
                }
            }
            return comparar;
        }

        public Comparar LeeXmlRespuestaComparativo(string XmlRecepcion, int idConvenio, int TipoPaquete, int IdAseguradora, int idCatRamoVehiculo, int? idPlanConvenio, int idPaqueteConvenio, CotizacionDetalle cotDetalle)
        {
            //List<Cobertura> coberturasPortal = db.Cobertura.Where(x => x.IdPaquete == 4).ToList();
            var coberturasPortal = ObtenerCoberturasComparativo(idConvenio, TipoPaquete, idCatRamoVehiculo, idPaqueteConvenio);
            if (!idPlanConvenio.HasValue)
                idPlanConvenio = int.Parse(db.PaqueteAseguradora.FirstOrDefault(x => x.IdCatTipoPaquete == TipoPaquete && x.IdAseguradora == IdAseguradora).Clave);

            Comparar comparar = new Comparar();
            Cotizador cotizador = ToObject<Cotizador>(XmlRecepcion);
            comparar.FechaInicio = cotizador.FechaInicio;//"2019-09-24";
            comparar.FechaFin = cotizador.FechaTermino;//"2020-09-24";
            comparar.CotizacionClave = cotizador.NumCotiza + "";

            //var detalles = db.PaqueteDetalle.Where(a => a.IdPaqueteConvenio == idPaqueteConvenio).ToList();
            var tipoDatos = db.CatTipoDatoDeducible.ToList();

            foreach (Planes p in cotizador.Planes.Where(x => x.Plan == idPlanConvenio))
            {
                comparar.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                foreach (var c in coberturasPortal)
                {
                    var CotAut = db.CotizacionAuto.Where(x => x.IdCotizacion == cotDetalle.IdCotizacion).FirstOrDefault();
                    LocktonModel.VModels.Coberturas cotCob = new LocktonModel.VModels.Coberturas();

                    cotCob.Cobertura = c.PrimaNeta + "";
                    cotCob.SumaAsegurada = c.SumaAsegurada + "";
                    cotCob.Nombre = c.Nombre;
                    cotCob.Deducible = c.Deducible + "";
                    cotCob.Codigo = c.Codigo + "";
                    cotCob.IdTipoDatoDeducible = c.IdTipoDatoDeducible;

                    var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == c.IdTipoDatoDeducible);

                    cotCob.TipoDato = tipoDato.Nombre;

                    int idCoberturaAtlas = int.Parse(c.Codigo);

                    var coberturaAtlas = p.Coberturas.FirstOrDefault(x => x.Cobertura == idCoberturaAtlas);

                    if (coberturaAtlas != null)
                    {

                        cotCob.Cobertura = coberturaAtlas.Prima + "";
                        cotCob.SumaAsegurada = coberturaAtlas.SumaAseg + "";
                        cotCob.Deducible = coberturaAtlas.Deducible + "";
                        cotCob.Codigo = coberturaAtlas.Cobertura + "";

                    }

                    var dd = EsCoberturaConCondicionEspecial(idConvenio, c.IdCobertura.ToString(), CotAut.Agnio, idCatRamoVehiculo);
                    if (dd)
                        comparar.Coberturas.Add(cotCob);
                }
                comparar.PrimaNeta = p.PPrima + "";
                comparar.PrimaTotal = p.PPrimaTot + "";
                comparar.Impuesto = p.PIva + "";
                comparar.Recargo = p.PRecargos + "";
                comparar.Derecho = p.PGastos + "";
                List<Recibos> recibos = p.Recibos.ToList();
                recibos = recibos.OrderBy(x => x.Recibo).ToList();
                p.Recibos = recibos.ToArray();
                comparar.PrimerPago = p.Recibos[0].RPrimaTot + "";
                comparar.NumeroDePagos = p.Recibos.Length;
                if (p.Recibos.Length < 2)
                {
                    comparar.SegundoPago = "";
                }
                else
                {
                    comparar.SegundoPago = p.Recibos[1].RPrimaTot + "";
                }
            }

            foreach (Errores e in cotizador.Errores)
            {
                if (e.CveError != 0)
                {
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(XmlRecepcion);
                    XmlNode errorNode = xml.SelectSingleNode("/Cotizador/Errores");
                    comparar.ErrorXML = errorNode.InnerXml;
                    comparar.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                    break;
                }
            }
            return comparar;
        }

        public T ToObject<T>(string toDeserialize)
        {
            StringReader reader = new StringReader(toDeserialize);
            XmlSerializer xs = new XmlSerializer(typeof(T));
            T resultado = (T)xs.Deserialize(reader);
            reader.Close();
            return resultado;
        }
        public class Utf8StringWriter : StringWriter
        {
            public override Encoding Encoding
            {
                get
                {
                    return Encoding.UTF8;
                }
            }
        }

        public string GuardaDocumentoLocal(string name, bool colectividad)
        {
            var rutaGuardadoPDFTemp = "";
            try
            {
                var _complemento = colectividad ? "_Endoso.pdf" : "_Poliza.pdf";
                var pdf = ObtenerDocumentoSFTP($"{name}{_complemento}");

                string RutaDescargaPDFsPolizas = HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/");
                string directorio = string.Format(@"{0}\{1}", RutaDescargaPDFsPolizas, "ATLAS");

                rutaGuardadoPDFTemp = string.Concat(directorio, @"\", name, ".pdf");

                if (!Directory.Exists(directorio))
                {
                    Directory.CreateDirectory(directorio);
                }
                if (!File.Exists(rutaGuardadoPDFTemp))
                {
                    File.WriteAllBytes(rutaGuardadoPDFTemp, pdf);
                }
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un error no controlado en GuardaDocumentoLocal: {0}", ex.Message));
            }
            return rutaGuardadoPDFTemp;
        }

        public byte[] ObtenerDocumentoSFTP(string name)
        {
            byte[] bytes = null;

            try
            {
                string host = Utilidades.Utilidades.ObtienerValorParametro("ATLAS_SFTP");//  @"secureaccess.segurosatlas.com.mx";
                string username = Utilidades.Utilidades.ObtienerValorParametro("ATLAS_SFTP_Usuario");// "wslockton";
                string password = Utilidades.Utilidades.ObtienerValorParametro("ATLAS_SFTP_Password");//"Lxo.2c1t";
                string _p = Utilidades.Utilidades.ObtienerValorParametro("ATLAS_SFTP_Puerto");//
                int puerto = 0;

                int.TryParse(_p, out puerto);

                string remoteDirectory = Utilidades.Utilidades.ObtienerValorParametro("ATLAS_SFTP_RemoteDirectory");

                using (var sftp = new SftpClient(host, puerto, username, password))
                {
                    log.Info("Entra a conectar al servidor del sftp Atlas");
                    sftp.Connect();
                    log.Info("Realiza conexion al sftp Atlas");
                    sftp.OperationTimeout = TimeSpan.FromSeconds(300);
                    log.Info("Empieza a obtener el listado de los archivos del sftp Atlas");
                    var files = sftp.ListDirectory(remoteDirectory);
                    log.Info("obtene correctamente el listado de los archivos del sftp Atlas");
                    var file = files.FirstOrDefault(x => x.Name == name);
                    if (file != null)
                    {
                        log.Info("Empieza a escribir en bytes el archivo Atlas: " + name);
                        bytes = sftp.ReadAllBytes(file.FullName);
                        log.Info("Termina de escribir en bytes el archivo Atlas: " + name);
                    }
                    sftp.Disconnect();
                    log.Info("Se desconecta al servidor del sftp Atlas");
                }
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un error no controlado en ObtenerDocumentoSFTP: {0}", ex.Message));
            }
            return bytes;
        }


        public List<LocktonModel.VModels.Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete, int IdCatRamoVehiculo, int idPaqueteConvenio)
        {
            //List<SolicitudCoberturasCobertura> coberturas = new List<SolicitudCoberturasCobertura>();

            List<LocktonModel.VModels.Coberturas> coberturas = (from a in db.PaqueteDetalle
                                                                join b in db.Cobertura on a.IdCobertura equals b.Id
                                                                join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                                                where c.IdConvenio == idConvenio
                                                                    && a.IdCatTipoPaquete == idPaquete
                                                                    && c.IdCatRamoVehiculo == IdCatRamoVehiculo
                                                                    && a.IdPaqueteConvenio == idPaqueteConvenio
                                                                    && b.Clave != "0"
                                                                select new LocktonModel.VModels.Coberturas()
                                                                {
                                                                    Codigo = b.Clave.Replace("\r\n", ""),
                                                                    Deducible = a.Deducible.ToString(),
                                                                    Nombre = b.Descripcion.Replace("\r\n", ""),
                                                                    SumaAsegurada = a.SumaAsegurada,
                                                                    Cobertura = a.Descripcion.Replace("\r\n", ""),
                                                                    IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1
                                                                }).ToList();
            return coberturas;
        }

        public List<LocktonModel.VModels.Coberturas> ObtenerCoberturasComparativo(int idConvenio, int idPaquete, int IdCatRamoVehiculo, int idPaqueteConvenio)
        {
            //List<SolicitudCoberturasCobertura> coberturas = new List<SolicitudCoberturasCobertura>();

            List<LocktonModel.VModels.Coberturas> coberturas = (from a in db.PaqueteDetalle
                                                                join b in db.Cobertura on a.IdCobertura equals b.Id
                                                                join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                                                where c.IdConvenio == idConvenio
                                                                    && a.IdCatTipoPaquete == idPaquete
                                                                    && c.IdCatRamoVehiculo == IdCatRamoVehiculo
                                                                    && a.IdPaqueteConvenio == idPaqueteConvenio

                                                                select new LocktonModel.VModels.Coberturas()
                                                                {
                                                                    IdCobertura = b.Id,
                                                                    Codigo = b.Clave.Replace("\r\n", ""),
                                                                    Deducible = a.Deducible.ToString(),
                                                                    Nombre = b.Descripcion.Replace("\r\n", ""),
                                                                    SumaAsegurada = a.SumaAsegurada,
                                                                    Cobertura = a.Descripcion.Replace("\r\n", ""),
                                                                    IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1
                                                                }).ToList();
            return coberturas;
        }



        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new System.NotImplementedException();
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            WSSegAtlasImplClient cliente = new WSSegAtlasImplClient();
            Convenio convenio = db.Convenio.Where(x => x.Id == InfoEmision.Convenio.Id).FirstOrDefault();
            CotizacionDetalle cotizacion = db.CotizacionDetalle.Where(x => x.Id == InfoEmision.IdCotizacion).FirstOrDefault();
            Cotizador cotizador = ToObject<Cotizador>(cotizacion.XMLRecepcion);
            Cotiza_Atlas cotiza_Atlas = ToObject<Cotiza_Atlas>(cotizacion.XMLSolicitud);
            int? TipoNegocio = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == convenio.IdEmpresa).IdTipoDeNegocio;
            bool EsFlotilla = TipoNegocio == 1 || TipoNegocio == 4 || TipoNegocio == 5;

            CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
            int tipoPaquete = db.CatTipoPaquete.FirstOrDefault(a => a.Clave == cotizacionDetalle.Paquete).Id;
            int medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString()).Id;
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            Emision_Atlas emision_Atlas = new Emision_Atlas
            {
                AMConductor = InfoEmision.ApellidoMaterno,//Conductor
                APConductor = InfoEmision.ApellidoPaterno,//Conductor
                Agrupador = 0,//Fijo 0
                Alarma = 0//Fijo 0
            };
            List<Contrat> contratList = new List<Contrat>();

            Contrat contrat = new Contrat();
            string xmlEnvioEmisionAtlas = string.Empty;
            string xmlRespuestaEmisionAtlas = string.Empty;

            try
            {
                if (InfoEmision.EsBeneficiarioPreferente)
                {
                    contrat.BenefPrefer = InfoEmision.BeneficiarioPreferente;
                }

                if (EsFlotilla)
                {
                    if (convenio.IdCatTipoContratante == 2)
                    {
                        //contrat.AMaterno = InfoEmision.DetalleUsuario.ApellidoMaterno;
                        //contrat.APaterno = InfoEmision.DetalleUsuario.ApellidoPaterno;
                        //contrat.Nombre = InfoEmision.DetalleUsuario.Nombre;
                        contrat.AMaterno = InfoEmision.ApellidoMaterno;
                        contrat.APaterno = InfoEmision.ApellidoPaterno;
                        contrat.Nombre = InfoEmision.ObtieneNombres();
                        contrat.Colonia = InfoEmision.DatosUsuario.Direccion.Municipio;
                        contrat.Direccion = InfoEmision.DatosUsuario.Direccion.Calle;
                        contrat.no_exterior = InfoEmision.DatosUsuario.Direccion.NumeroExt;
                        contrat.no_interior = InfoEmision.DatosUsuario.Direccion.NumeroInt;
                        contrat.fec_constit = "1";//Fijo 1 para persona física
                        string EdoCircula = InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
                        if (EdoCircula != null && long.TryParse(EdoCircula, out long parsed))
                        {
                            contrat.Estado = parsed;
                        }
                        if (long.TryParse(InfoEmision.DatosUsuario.Direccion.CodigoPostal, out long parsedCP))
                        {
                            contrat.CP = parsedCP;
                        }
                        contrat.RFC = InfoEmision.DatosUsuario.RFC;
                        contrat.TipoPersona = 1;//1: Persona física
                        contrat.folio_mercantil = "1";//Fijo 1 para persona física
                        contrat.num_fea = "1";//Fijo 1 para persona física
                        emision_Atlas.Sucursal = perioricidad.Sucursal;//"E87";
                        emision_Atlas.NoPoliza = cotiza_Atlas.DatosEndoso[0].NoPoliza;

                        if (!Utilidades.Utilidades.ValidaRFCHomoclave(contrat.RFC))
                            return new EmisionPoliza(false, null, "Requerimos un RFC con homoclave para continuar con la emisión de tu auto.");
                    }
                    else
                    {
                        contrat.RazonSocial = InfoEmision.Empresa.RazonSocial;
                        contrat.fec_constit = InfoEmision.Empresa.FechaConstitucion.Value.ToString("yyyy-MM-dd");
                        if (long.TryParse(InfoEmision.Empresa.Direccion.CodigoPostal, out long parsed))
                        {
                            contrat.CP = parsed;
                        }
                        contrat.Colonia = InfoEmision.Empresa.Direccion.Colonia;
                        contrat.Direccion = InfoEmision.Empresa.Direccion.Calle;
                        contrat.no_exterior = InfoEmision.Empresa.Direccion.NumeroExt;
                        contrat.no_interior = InfoEmision.Empresa.Direccion.NumeroInt;
                        string EdoCircula = InfoEmision.Empresa.Direccion.CatEstadosRepublica.Clave;
                        if (EdoCircula != null && long.TryParse(EdoCircula, out parsed))
                        {
                            contrat.Estado = parsed;
                        }
                        contrat.RFC = InfoEmision.Empresa.RFC;
                        contrat.TipoPersona = 2;//1: Persona física, 2: persona moral
                        contrat.folio_mercantil = InfoEmision.Empresa.FolioMercantil;//Fijo 1 para persona física, en caso de ser Moral de la tabla Empresa
                        emision_Atlas.NoPoliza = cotiza_Atlas.DatosEndoso[0].NoPoliza;
                        emision_Atlas.Sucursal = perioricidad.Sucursal;// polizaMaestra[0];//"D00" ;
                    }
                }
                else if (InfoEmision.IdTipoDeNegocio == 6 && InfoEmision.EmisionPersonaMoral)
                {
                    InfoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoral.Id);
                    InfoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoralRepresentanteLegal.Id);
                    contrat.RazonSocial = InfoEmision.PersonaMoral.RazonSocial;
                    contrat.fec_constit = InfoEmision.PersonaMoral.FechaConstitucion.Value.ToString("yyyy-MM-dd");
                    if (long.TryParse(InfoEmision.PersonaMoral.Direccion.CodigoPostal, out long parsed))
                    {
                        contrat.CP = parsed;
                    }
                    contrat.Colonia = InfoEmision.PersonaMoral.Direccion.Colonia;
                    contrat.Direccion = InfoEmision.PersonaMoral.Direccion.Calle;
                    contrat.no_exterior = InfoEmision.PersonaMoral.Direccion.NumeroExt;
                    contrat.no_interior = InfoEmision.PersonaMoral.Direccion.NumeroInt;
                    string EdoCircula = InfoEmision.PersonaMoral.Direccion.CatEstadosRepublica.Clave;
                    if (EdoCircula != null && long.TryParse(EdoCircula, out parsed))
                    {
                        contrat.Estado = parsed;
                    }
                    contrat.RFC = InfoEmision.PersonaMoral.RFC;
                    contrat.TipoPersona = 2;//1: Persona física, 2: persona moral
                    contrat.folio_mercantil = InfoEmision.PersonaMoral.FolioMercantil;//Fijo 1 para persona física, en caso de ser Moral de la tabla Empresa
                    emision_Atlas.NoPoliza = cotiza_Atlas.DatosEndoso[0].NoPoliza;
                    emision_Atlas.Sucursal = perioricidad.Sucursal;// polizaMaestra[0];//"D00" ;
                }
                else
                {
                    //contrat.AMaterno = InfoEmision.DetalleUsuario.ApellidoMaterno;
                    //contrat.APaterno = InfoEmision.DetalleUsuario.ApellidoPaterno;
                    //contrat.Nombre = InfoEmision.DetalleUsuario.Nombre;
                    contrat.AMaterno = InfoEmision.ApellidoMaterno;
                    contrat.APaterno = InfoEmision.ApellidoPaterno;
                    contrat.Nombre = InfoEmision.ObtieneNombres();
                    contrat.Colonia = InfoEmision.DatosUsuario.Direccion.Municipio;
                    contrat.Direccion = InfoEmision.DatosUsuario.Direccion.Calle;
                    contrat.no_exterior = InfoEmision.DatosUsuario.Direccion.NumeroExt;
                    contrat.no_interior = InfoEmision.DatosUsuario.Direccion.NumeroInt;
                    contrat.fec_constit = "1";//Fijo 1 para persona física
                    string EdoCircula = InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
                    if (EdoCircula != null && long.TryParse(EdoCircula, out long parsed))
                    {
                        contrat.Estado = parsed;
                    }
                    if (long.TryParse(InfoEmision.DatosUsuario.Direccion.CodigoPostal, out long parsedCP))
                    {
                        contrat.CP = parsedCP;
                    }
                    contrat.RFC = InfoEmision.DatosUsuario.RFC;
                    contrat.TipoPersona = 1;//1: Persona física
                    contrat.folio_mercantil = "1";//Fijo 1 para persona física
                    contrat.num_fea = "1";//Fijo 1 para persona física
                    emision_Atlas.Sucursal = perioricidad.Sucursal;//"E87";
                    emision_Atlas.NoPoliza = cotiza_Atlas.DatosEndoso[0].NoPoliza;

                    if (!Utilidades.Utilidades.ValidaRFCHomoclave(contrat.RFC))
                        return new EmisionPoliza(false, null, "Requerimos un RFC con homoclave para continuar con la emisión de tu auto.");
                }
                contrat.Email = InfoEmision.Email;
                contrat.Telefono = InfoEmision.TelefonoCel;
                contrat.cve_giro = 0;//Este de dónde lo agarro?
                contrat.cve_ocupacion = 1;//Este de dónde lo agarro?
                contrat.nacionalidad = 1;//Fijo 1
                contrat.pais_nacimiento = 2013;//Fijo 2013 para nacionalidad mexicana

                contrat.t_anio_exp = 0;
                contrat.t_banco = 0;
                contrat.t_codigo = 0;
                contrat.t_instrumento = 0;
                contrat.t_mes_exp = 0;
                contrat.t_nm_e = 0;
                contrat.t_nombre = "0";
                contrat.t_num_tar = 0;
                contrat.tipo_exposicion = 0;

                if (InfoEmision.RequiereFactura)
                {


                    long _regimenFiscalId = 0;
                    var _claveRegimenFiscal = "";
                    var _facturacion = new Facturacion();

                    if (InfoEmision.EsFlotilla)
                    {
                        log.Info($"Emision Requiere Factura ATLAS FLOTILLA {InfoEmision.Empresa.Id}");

                        contrat.NombreConstanciaFiscal = contrat.RazonSocial;
                        if (InfoEmision.Empresa.IdRegimenFiscal.HasValue)
                        {
                            _claveRegimenFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal).Clave;
                            _facturacion.IdRegimenFiscal = InfoEmision.Empresa.IdRegimenFiscal;
                        }

                    }
                    else
                    {
                        log.Info($"Emision Requiere Factura ATLAS {InfoEmision.IdRegimenFiscal}");

                        contrat.NombreConstanciaFiscal = $"{contrat.Nombre} {contrat.APaterno} {contrat.AMaterno}";
                        if (InfoEmision.IdRegimenFiscal > 0)
                        {
                            _claveRegimenFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.IdRegimenFiscal).Clave;
                            _facturacion.IdRegimenFiscal = InfoEmision.IdRegimenFiscal;
                        }
                    }

                    log.Info($"Emision Requiere Factura ATLAS REGIMEN FISCAL {_claveRegimenFiscal}");

                    if (long.TryParse(_claveRegimenFiscal, out _regimenFiscalId))
                    {
                        contrat.RegimenFiscal = _regimenFiscalId;
                        contrat.CodPosDomicilioFiscal = contrat.CP;
                    }

                    _facturacion.RFC = contrat.RFC;
                    _facturacion.Nombre = contrat.NombreConstanciaFiscal;
                    _facturacion.CodigoPostal = contrat.CodPosDomicilioFiscal.ToString();

                    Utilidades.Utilidades.GeneraRegistroFacturacion(_facturacion);
                }

                contratList.Add(contrat);
                emision_Atlas.Contrat = contratList.ToArray();
                List<DatosSeguridad1> datosSeguridadList = new List<DatosSeguridad1>();
                DatosSeguridad1 datosSeguridad = new DatosSeguridad1();
                datosSeguridad.CveUsuario = convenio.Usuario;
                datosSeguridad.Password = convenio.Contrasena;
                datosSeguridadList.Add(datosSeguridad);
                emision_Atlas.DatosSeguridad = datosSeguridadList.ToArray();
                List<DetCoberEA> detCoberEAList = new List<DetCoberEA>();
                DetCoberEA detCoberEA = new DetCoberEA();
                detCoberEA.Cobertura = 0;//catálogo??0
                detCoberEA.DValor = 0;//catalogo??0
                detCoberEA.Descripcion = "";//catálogo??0
                detCoberEAList.Add(detCoberEA);
                emision_Atlas.DetCoberEA = detCoberEAList.ToArray();
                emision_Atlas.FechaCotiza = cotizador.FechaCotiza;

                emision_Atlas.FechaInicio = cotizador.FechaInicio;
                emision_Atlas.FechaTermino = cotizador.FechaTermino;


                emision_Atlas.IdControl = cotizador.IdControl;//este viene de la cotizacion
                emision_Atlas.Motor = InfoEmision.NumeroMotor;
                emision_Atlas.NomConductor = InfoEmision.ObtieneNombres();//Conductor
                emision_Atlas.NumContrato = "";//este de donde?? : este es opcional
                emision_Atlas.NumCotiza = cotizador.NumCotiza;
                emision_Atlas.NumEco = "";
                emision_Atlas.Placas = InfoEmision.Placas;
                emision_Atlas.Plan = cotiza_Atlas.DatosNuevaCot[0].Plan;//catálogo adicional
                emision_Atlas.RFV = "0";//Fijo 0
                emision_Atlas.RegresaRuta = 0;//Fijo 0
                emision_Atlas.Serie = InfoEmision.NumeroSerie;
                emision_Atlas.TipoIva = "1";//Fijo 1
                Emisor_Atlas emisor_Atlas = cliente.WS_atlas_emisor(emision_Atlas);
                #region ejemplo
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////simulacion respuesta de emisión
                //Emisor_Atlas emisor_Atlas = new Emisor_Atlas();
                //emisor_Atlas.NoEmision = 40;
                //emisor_Atlas.Sucursal = "Y12";
                //emisor_Atlas.Linea = 1;
                //emisor_Atlas.Producto = 1;
                //emisor_Atlas.Poliza = 41;
                //emisor_Atlas.Endoso = 0;
                //emisor_Atlas.AEmision = 0;
                //emisor_Atlas.NoReexp = 1;
                //emisor_Atlas.Estatus = 1;
                //emisor_Atlas.Inciso = 1;
                //emisor_Atlas.PrimaBruta = 8207.45;
                //emisor_Atlas.Descuento = 3123.95;
                //emisor_Atlas.Prima = 5083.50;
                //emisor_Atlas.Recargo = 419.39;
                //emisor_Atlas.Gastos = 580.00;
                //emisor_Atlas.IVA = 973.26;
                //emisor_Atlas.PrimaTotal = 7056.15;
                //emisor_Atlas.InicioVig = "2019-10-09";
                //emisor_Atlas.FinVig = "2020-10-09";
                //emisor_Atlas.FechaReg = "2019-10-09";
                //emisor_Atlas.DiasVig = 365;
                //emisor_Atlas.PolRenueva = 0;
                //emisor_Atlas.IdAseg = "PEDBARY12001";
                //emisor_Atlas.DigitoVerif = "";
                //emisor_Atlas.Plazo = 30;
                //emisor_Atlas.FecVenPlazo = "2019-10-09";
                //emisor_Atlas.OficioAmis = "CNSF-S0023-0447-2015 del";
                //List<Recibos1> recibos1List = new List<Recibos1>();
                //Recibos1 recibos1 = new Recibos1();
                //recibos1.Recibo = 1;
                //recibos1.RPrima = 423.68;
                //recibos1.RRecargos = 34.94;
                //recibos1.RGastos = 580.00;
                //recibos1.RIva = 166.18;
                //recibos1.RPrimaTot = 1204.80;
                //recibos1.IniVigRec = "2019-10-09";
                //recibos1.FinVigRec = "2020-10-09";
                //recibos1.EstatusRec = 3;
                //recibos1List.Add(recibos1);
                //emisor_Atlas.Recibos = recibos1List.ToArray();
                //List<Error_em> error_EmList = new List<Error_em>();
                //Error_em error_Em = new Error_em();
                //error_Em.Error = 0;
                //error_Em.CveError = 0;
                //error_Em.Concepto = "";
                //error_EmList.Add(error_Em);
                //emisor_Atlas.Error_em = error_EmList.ToArray();
                //List<T_resp_a> t_resp_aList = new List<T_resp_a>();
                //T_resp_a t_resp_a = new T_resp_a();
                //t_resp_a.t_estatus = 1213;
                //t_resp_a.t_d_stat_tar = "";
                //t_resp_aList.Add(t_resp_a);
                //emisor_Atlas.t_resp_a = t_resp_aList.ToArray();
                //List<RutaImp> rutaImpList = new List<RutaImp>();
                //RutaImp rutaImp = new RutaImp();
                //rutaImp.RutaPoliza = "";
                //rutaImp.RutaRecibo = "";
                //rutaImp.Codigo = "";
                //rutaImpList.Add(rutaImp);
                //emisor_Atlas.RutaImp = rutaImpList.ToArray();
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                ///
                #endregion

                xmlEnvioEmisionAtlas = EnmascaraDatosBancarios(emision_Atlas);
                xmlRespuestaEmisionAtlas = XMLSerializeToString<Emisor_Atlas>(emisor_Atlas);

                if (emisor_Atlas.Error_em.Length > 0)
                {
                    foreach (Error_em e in emisor_Atlas.Error_em)
                    {
                        if (e.Error != 0)
                        {
                            log.Info(string.Format("Ocurrio un error en la emision de la poliza se guarda xml de solicitud de emision --> {0}", xmlEnvioEmisionAtlas.Replace("\n", "").Replace("\r", "")));
                            log.Info(string.Format("Ocurrio un error en la emision de la poliza se guarda xml Emision respuesta --> {0} ", xmlRespuestaEmisionAtlas.Replace("\n", "").Replace("\r", "")));

                            GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEnvioEmisionAtlas, xmlRespuestaEmisionAtlas, e.Concepto, "Emisión");

                            return new EmisionPoliza(false, null, e.Concepto);
                        }
                    }

                }
                Poliza poliza = new Poliza();
                PolizaDetalle polizaDet = new PolizaDetalle();
                poliza.InicioVigencia = DateTime.ParseExact(emisor_Atlas.InicioVig, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
                poliza.FinVigencia = DateTime.ParseExact(emisor_Atlas.FinVig, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
                poliza.PrimaNeta = (decimal)emisor_Atlas.Prima;
                poliza.PrimaNetaAnualizada = (decimal)emisor_Atlas.Prima;
                poliza.PrimaTotal = (decimal)emisor_Atlas.PrimaTotal;
                poliza.PrimaTotalAnualizada = (decimal)emisor_Atlas.PrimaTotal;
                poliza.Motor = InfoEmision.NumeroMotor.ToUpper();
                poliza.Serie = InfoEmision.NumeroSerie.ToUpper();
                poliza.Placas = InfoEmision.Placas.ToUpper();
                poliza.FechaEmision = DateTime.Now;
                poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                poliza.NumeroPoliza = string.Format("{0}-{1}-{2}-{3}_{4}-{5}-{6}", emisor_Atlas.Sucursal, emisor_Atlas.Linea, emisor_Atlas.Producto, emisor_Atlas.Poliza.ToString().PadLeft(9, '0'), emisor_Atlas.Endoso.ToString().PadLeft(4, '0'), emisor_Atlas.AEmision, emisor_Atlas.NoReexp);
                //poliza.UrlPDFPoliza = "";//
                ReimprimePoliza(xmlRespuestaEmisionAtlas, convenio.Id, InfoEmision.Email, emision_Atlas.Sucursal, perioricidad.IdCatPeriodicidad, 1, emisor_Atlas.Producto.ToString()).FirstOrDefault();
                ReimprimePoliza(xmlRespuestaEmisionAtlas, convenio.Id, InfoEmision.Email, emision_Atlas.Sucursal, perioricidad.IdCatPeriodicidad, 98, emisor_Atlas.Producto.ToString()).FirstOrDefault();
                ReimprimePoliza(xmlRespuestaEmisionAtlas, convenio.Id, InfoEmision.Email, emision_Atlas.Sucursal, perioricidad.IdCatPeriodicidad, 89, emisor_Atlas.Producto.ToString()).FirstOrDefault();
                poliza.UrlPDFPoliza = GuardaDocumentoLocal(poliza.NumeroPoliza, convenio.Colectividad);

                var IVA = Convert.ToDecimal(db.CatParametro.Where(x => x.Clave.Contains("IVA")).FirstOrDefault().Valor);
                poliza.UrlPDFRecibos = "";
                poliza.Estatus = 1;
                poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                poliza.IdConvenio = InfoEmision.Convenio.Id;
                poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                poliza.IdTipoCobertura = tipoPaquete;
                poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                poliza.Acepto_DescuentoPoliza = true;

                var periodicidad = db.PeriodicidadFormaPago.Where(x => x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago && x.IdConvenio == InfoEmision.Convenio.Id).FirstOrDefault();
                poliza.ClaveAgente = periodicidad != null ? periodicidad.ClaveAgente : "0"; //InfoEmision.Convenio.CodigoIntermediario;
                polizaDet.Inciso = emisor_Atlas.Inciso + "";
                polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para Atlas.
                polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                polizaDet.Deducible = 0;
                polizaDet.Comision = 0;
                polizaDet.FactorIva = IVA;//16; //Ponerlo de manera dinamica
                polizaDet.MigraOPERA = false;
                polizaDet.UrlPDFPolizaOPERA = "";
                polizaDet.PolizaOPERA = 0;
                polizaDet.OTOpera = 0;
                polizaDet.EndosoOPERA = 0;
                polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;
                polizaDet.IdCatRamoVehiculo = cotizacionDetalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                polizaDet.IdCatModalidadFormaPago = medioPago;
                polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
                polizaDet.XMLSolicitud = xmlEnvioEmisionAtlas;
                polizaDet.XMLRecepcion = xmlRespuestaEmisionAtlas;
                polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;
                polizaDet.Impuesto = Convert.ToDecimal(emisor_Atlas.IVA); //recibo.Impuesto;    
                polizaDet.Derechos = Convert.ToDecimal(InfoEmision.Convenio.DerechosPoliza);
                polizaDet.Recargos = Convert.ToDecimal(emisor_Atlas.Recargo);
                List<Recibo> recibosGenerados = new List<Recibo>();
                foreach (Recibos1 r in emisor_Atlas.Recibos)
                {
                    Recibo recibo = new Recibo();
                    recibo.InicioVigencia = DateTime.ParseExact(r.IniVigRec, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
                    recibo.FinVigencia = DateTime.ParseExact(r.FinVigRec, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture); ;
                    recibo.Numero = (int)r.Recibo;
                    recibo.NoAsegurado = "1";
                    recibo.PrimaNeta = (decimal)r.RPrima;
                    recibo.PrimaTotal = (decimal)r.RPrimaTot;
                    //recibo.Derecho = derechos;
                    recibo.Recargo = (decimal)r.RRecargos;
                    recibo.Comision = 0;
                    recibo.Impuesto = (decimal)r.RIva;
                    recibosGenerados.Add(recibo);
                }

                Endoso endosoAlta = new Endoso
                {
                    IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id,
                    Fecha = DateTime.Now,
                    ValorAnterior = "Alta",
                    ValorActual = "Contratación",
                    Recibo = recibosGenerados
                };
                poliza.Endoso.Add(endosoAlta);
                poliza.PolizaDetalle.Add(polizaDet);

                db.Poliza.Add(poliza);
                db.SaveChanges();
                log.Info("Poliza de ATLAS guradada en BD: " + poliza.NumeroPoliza);


                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEnvioEmisionAtlas, xmlRespuestaEmisionAtlas, "", "Emisión");

                Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                return new EmisionPoliza(true, xmlEnvioEmisionAtlas, xmlRespuestaEmisionAtlas, poliza);
            }
            catch (Exception ex)
            {
                log.Info("Error Emision ATLAS : " + ex.InnerException != null ? ex.InnerException.Message : ex.Message);
                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEnvioEmisionAtlas, xmlRespuestaEmisionAtlas, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");
                return new EmisionPoliza(false, null, ex.Message);
            }
        }

        public string EnmascaraDatosBancarios(Emision_Atlas xml)
        {
            xml.Contrat.FirstOrDefault().t_codigo = 0;
            xml.Contrat.FirstOrDefault().t_mes_exp = 0;
            xml.Contrat.FirstOrDefault().t_num_tar = 0;
            string result = XMLSerializeToString<Emision_Atlas>(xml);

            return result;
        }



        public List<string> ReimprimePoliza(string xmlRecepcion, int IdConvenio, string correo, string sucursal, int idCatPeriodicidad, int TipoReimpresion, string Product = "0")
        {
            //TipoReimpresion = 1 Poliza
            //TipoReimpresion = 98 recibos
            //TipoReimpresion = 89 Certificado Individual
            List<string> responseList = new List<string>();
            try
            {
                Convenio convenio = db.Convenio.FirstOrDefault(x => x.Id == IdConvenio);
                Emisor_Atlas emisor_Atlas = ToObject<Emisor_Atlas>(xmlRecepcion);
                string Producto = string.IsNullOrEmpty(Product) ? "0" : Product; //db.PeriodicidadFormaPago.FirstOrDefault(x => x.IdConvenio == IdConvenio && x.IdCatPeriodicidad == idCatPeriodicidad).Producto;

                int? TipoNegocio = db.ConfiguracionEmpresa.FirstOrDefault(x => x.IdEmpresa == convenio.IdEmpresa).IdTipoDeNegocio;
                bool EsFlotilla = TipoNegocio == 1 || TipoNegocio == 4 || TipoNegocio == 5;

                WS_ImpresionesImplClient cliente = new WS_ImpresionesImplClient();
                List<Datimpres> datimpresList = new List<Datimpres>();
                Datimpres datimpres = new Datimpres();
                datimpres.Anio = 0;//Fijo 0
                datimpres.Bien = 0;//Fijo 0
                datimpres.Cola_impres = 0;//Fijo 0
                datimpres.Dependiente = 1;//Fijo 1
                List<DetImpres> detImpresList = new List<DetImpres>();
                DetImpres detImpres = new DetImpres();
                detImpres.Desc = "";//Vacío Fijo
                detImpres.ID_Impresion = TipoReimpresion; //1: Carátula
                detImpres.Imprime_sn = 1;//Fijo 1
                detImpres.Negocio = 0;//Fijo 0
                detImpresList.Add(detImpres);
                DetImpres[] detImpresArray = detImpresList.ToArray();
                datimpres.DetImpres = detImpresArray;
                datimpres.Email = "0";
                datimpres.EndSerie = emisor_Atlas.Endoso;
                datimpres.Id_Solcot = 0;//Fijo 0
                datimpres.Inciso = emisor_Atlas.Inciso;
                datimpres.Linea = 1;//Fijo 1
                datimpres.Num_rec = (TipoReimpresion == 98) ? 0 : 1;
                datimpres.Par2_alfa = "";//vacío fijo
                datimpres.Par_alfa = "";//vacío fijo
                datimpres.Par_num = 0;//Fijo 0
                datimpres.Password = convenio.Contrasena;
                datimpres.PolSolCot = emisor_Atlas.Poliza;//Numero de poliza proporcionada por atlas

                int producto = 6;
                bool esproducto = int.TryParse(Producto, out producto);
                if (EsFlotilla)
                {
                    datimpres.Producto = producto;// 6;
                    datimpres.Sucursal = sucursal; //"D00";
                }
                else
                {
                    datimpres.Producto = producto;// 1;
                    datimpres.Sucursal = sucursal; // "E87";
                }
                datimpres.Reexp = 1;
                datimpres.Seccion = 0;
                datimpres.Usuario = convenio.Usuario;
                datimpresList.Add(datimpres);
                Datimpres[] datimpresArray = datimpresList.ToArray();
                Datresp[] datrespArray = cliente.WS_Impres_atlas(datimpresArray);
                #region ejemplo
                ///////////////////////////////////////////////////////////////respuesta simulada
                //List<Datresp> datrespList = new List<Datresp>();
                //Datresp datresp = new Datresp();
                //datresp.Datos_sn = 1;
                //datresp.Errores = 0;
                //List<DetResp> detRespList = new List<DetResp>();
                //DetResp detResp = new DetResp();
                //detResp.ID_Impres = 1;
                //detResp.Error = 0;
                //detResp.Ruta_A = "ftp://Documentos:Docu$0213@148.233.128.212/D00-1-1-000500982_0000-0-1_Poliza.pdf";
                //D00-1-24-526032-14095647.pdf 
                //detRespList.Add(detResp);
                //datresp.DetResp = detRespList.ToArray();
                //datrespList.Add(datresp);
                //Datresp[] datrespArray = datrespList.ToArray();
                /////////////////////////////////////////////////////////////////////
                ///
                #endregion

                foreach (Datresp d in datrespArray)
                {
                    foreach (DetResp d1 in d.DetResp)
                    {
                        if (d1.Error != null && d1.Error == 0)
                        {
                            string ruta = db.CatParametro.FirstOrDefault(x => x.Clave.Contains("RutaReimpresion")).Valor;

                            responseList.Add(ruta + d1.Ruta_A);
                            log.Info("Se genero correctamente la url de reimpresion de atlas: " + ruta + d1.Ruta_A);
                        }
                        else
                            log.Info(string.Format("El servicio de reimpresion contesto con lo siguiente: {0}", d1.Error));
                    }
                }




            }
            catch (Exception ex)
            {

                responseList = new List<string>();
                log.Info(string.Format("Ocurrio un error no controlado en la reimpresion: {0}", ex.Message));
            }
            return responseList;
        }

        public List<string> ReimprimePolizaCore(string NumeroPoliza, int TipoReimpresion)
        {
            List<string> responseList = new List<string>();
            try
            {
                //consulta PolizaConInciso
                SqlParameter sqlpoliza = new SqlParameter("@poliza", NumeroPoliza);
                ConsultaPolizaInciso polizaInciso = db.ConsultaPolizaInciso.SqlQuery("sp_consulta_Poliza_Inciso  @poliza", sqlpoliza).FirstOrDefault();
                Poliza poliza = new Poliza();
                PolizaDetalle polizaDetalle = new PolizaDetalle();
                Convenio convenio = new Convenio();
                if (polizaInciso == null)
                {
                    poliza = db.Poliza.FirstOrDefault(x => x.NumeroPoliza == NumeroPoliza);
                    if (poliza != null)
                    {
                        polizaInciso = new ConsultaPolizaInciso();
                        polizaDetalle = db.PolizaDetalle.FirstOrDefault(x => x.IdPoliza == poliza.Id);
                        convenio = db.Convenio.FirstOrDefault(x => x.Id == poliza.IdConvenio);
                        Emisor_Atlas emisor_Atlas = ToObject<Emisor_Atlas>(polizaDetalle.XMLRecepcion);
                        polizaInciso.Inciso = emisor_Atlas.Inciso.ToString();
                        polizaInciso.Contrasena = convenio.Contrasena;
                        polizaInciso.Usuario = convenio.Usuario;
                        polizaInciso.Producto = emisor_Atlas.Producto.ToString();

                    }
                    else
                        return null;
                }
                string[] TokensPoliza = NumeroPoliza.Split('-');
                string[] TokenNumeroPoliza = TokensPoliza[3].Split('_');
                long NumeroP = 0;
                long Endoso = 0;
                long Inciso = 0;
                bool ConviertNumeroP = long.TryParse(TokenNumeroPoliza[0], out NumeroP);
                bool ConvierteNumeroE = long.TryParse(TokenNumeroPoliza[1], out Endoso);
                bool ConvierteInciso = long.TryParse(polizaInciso.Inciso, out Inciso);

                WS_ImpresionesImplClient cliente = new WS_ImpresionesImplClient();
                List<Datimpres> datimpresList = new List<Datimpres>();
                Datimpres datimpres = new Datimpres();
                datimpres.Anio = 0;//Fijo 0
                datimpres.Bien = 0;//Fijo 0
                datimpres.Cola_impres = 0;//Fijo 0
                datimpres.Dependiente = 1;//Fijo 1
                List<DetImpres> detImpresList = new List<DetImpres>();
                DetImpres detImpres = new DetImpres();
                detImpres.Desc = "";//Vacío Fijo
                detImpres.ID_Impresion = TipoReimpresion; //1: Carátula
                detImpres.Imprime_sn = 1;//Fijo 1
                detImpres.Negocio = 0;//Fijo 0
                detImpresList.Add(detImpres);
                DetImpres[] detImpresArray = detImpresList.ToArray();
                datimpres.DetImpres = detImpresArray;
                datimpres.Email = "0";//string.IsNullOrEmpty(polizaInciso.Email) ? "" : polizaInciso.Email;
                datimpres.EndSerie = Endoso;//emisor_Atlas.Endoso;
                datimpres.Id_Solcot = 0;//Fijo 0
                datimpres.Inciso = Inciso; //emisor_Atlas.Inciso;
                datimpres.Linea = 1;//Fijo 1
                datimpres.Num_rec = (TipoReimpresion == 98) ? 0 : 1;
                datimpres.Par2_alfa = "";//vacío fijo
                datimpres.Par_alfa = "";//vacío fijo
                datimpres.Par_num = 0;//Fijo 0
                datimpres.Password = polizaInciso.Contrasena;
                datimpres.PolSolCot = NumeroP;//emisor_Atlas.Poliza;//Numero de poliza proporcionada por atlas

                datimpres.Producto = long.Parse(polizaInciso.Producto) == 0 ? 6 : long.Parse(polizaInciso.Producto);// 6;
                datimpres.Sucursal = TokensPoliza[0].ToString(); //"D00";

                datimpres.Reexp = 1;
                datimpres.Seccion = 0;
                datimpres.Usuario = polizaInciso.Usuario;
                datimpresList.Add(datimpres);
                Datimpres[] datimpresArray = datimpresList.ToArray();
                Datresp[] datrespArray = cliente.WS_Impres_atlas(datimpresArray);

                #region ejemplo
                ///////////////////////////////////////////////////////////////respuesta simulada
                //List<Datresp> datrespList = new List<Datresp>();
                //Datresp datresp = new Datresp();
                //datresp.Datos_sn = 1;
                //datresp.Errores = 0;
                //List<DetResp> detRespList = new List<DetResp>();
                //DetResp detResp = new DetResp();
                //detResp.ID_Impres = 1;
                //detResp.Error = 0;
                //detResp.Ruta_A = "ftp://Documentos:Docu$0213@148.233.128.212/D00-1-1-000500982_0000-0-1_Poliza.pdf";
                //D00-1-24-526032-14095647.pdf 
                //detRespList.Add(detResp);
                //datresp.DetResp = detRespList.ToArray();
                //datrespList.Add(datresp);
                //Datresp[] datrespArray = datrespList.ToArray();
                /////////////////////////////////////////////////////////////////////
                ///
                #endregion

                foreach (Datresp d in datrespArray)
                {
                    foreach (DetResp d1 in d.DetResp)
                    {
                        if (d1.Error != null && d1.Error == 0)
                        {
                            string ruta = db.CatParametro.FirstOrDefault(x => x.Clave.Contains("RutaReimpresion")).Valor;
                            responseList.Add(ruta + d1.Ruta_A);
                            log.Info("Se genero correctamente la url de reimpresion de atlas: " + ruta + d1.Ruta_A);
                        }
                        else
                            log.Info(string.Format("El servicio de reimpresion contesto con lo siguiente: {0}", d1.Error));
                    }
                }

            }
            catch (Exception ex)
            {
                responseList = new List<string>();
                log.Info(string.Format("Ocurrio un error no controlado en la reimpresion: {0}", ex.Message));
            }

            if (responseList.Count == 0)
                responseList.Add("");

            return responseList;
        }
        public List<string> ReimprimeRecibosCore(string NumeroPoliza)
        {
            List<string> responseList = new List<string>();
            try
            {
                //consulta PolizaConInciso
                SqlParameter sqlpoliza = new SqlParameter("@poliza", NumeroPoliza);
                ConsultaPolizaInciso polizaInciso = db.ConsultaPolizaInciso.SqlQuery("sp_consulta_Poliza_Inciso  @poliza", sqlpoliza).FirstOrDefault();
                //'D00-1-24-000526032_0026-0-1'
                string[] TokensPoliza = NumeroPoliza.Split('-');
                string[] TokenNumeroPoliza = TokensPoliza[3].Split('_');
                long NumeroP = 0;
                long Endoso = 0;
                long Inciso = 0;
                bool ConviertNumeroP = long.TryParse(TokenNumeroPoliza[0], out NumeroP);
                bool ConvierteNumeroE = long.TryParse(TokenNumeroPoliza[1], out Endoso);
                bool ConvierteInciso = long.TryParse(polizaInciso.Inciso, out Inciso);

                WS_ImpresionesImplClient cliente = new WS_ImpresionesImplClient();
                List<Datimpres> datimpresList = new List<Datimpres>();
                Datimpres datimpres = new Datimpres();
                datimpres.Anio = 0;//Fijo 0
                datimpres.Bien = 0;//Fijo 0
                datimpres.Cola_impres = 0;//Fijo 0
                datimpres.Dependiente = 1;//Fijo 1
                List<DetImpres> detImpresList = new List<DetImpres>();
                DetImpres detImpres = new DetImpres();
                //detImpres.Desc = "";//Vacío Fijo
                detImpres.ID_Impresion = 98; //1: Carátula
                detImpres.Imprime_sn = 1;//Fijo 1
                detImpres.Negocio = 0;//Fijo 0
                detImpresList.Add(detImpres);
                DetImpres[] detImpresArray = detImpresList.ToArray();
                datimpres.DetImpres = detImpresArray;
                datimpres.Email = polizaInciso.Email;
                datimpres.EndSerie = Endoso;//emisor_Atlas.Endoso;
                datimpres.Id_Solcot = 0;//Fijo 0
                datimpres.Inciso = Inciso == 0 ? Inciso : Endoso; //emisor_Atlas.Inciso;
                datimpres.Linea = 1;//Fijo 1

                datimpres.Par_num = 0;//Fijo 0
                datimpres.Password = polizaInciso.Contrasena;
                datimpres.PolSolCot = NumeroP;//emisor_Atlas.Poliza;//Numero de poliza proporcionada por atlas

                int producto = 6;
                bool esproducto = int.TryParse(polizaInciso.Producto, out producto);

                datimpres.Producto = int.Parse(polizaInciso.Producto);// 6;
                datimpres.Sucursal = TokensPoliza[0].ToString(); //"D00";
                datimpres.Reexp = 1;
                datimpres.Seccion = 0;
                datimpres.Usuario = polizaInciso.Usuario;
                datimpresList.Add(datimpres);
                Datimpres[] datimpresArray = datimpresList.ToArray();
                Datresp[] datrespArray = cliente.WS_Impres_atlas(datimpresArray);

                #region ejemplo
                ///////////////////////////////////////////////////////////////respuesta simulada
                //List<Datresp> datrespList = new List<Datresp>();
                //Datresp datresp = new Datresp();
                //datresp.Datos_sn = 1;
                //datresp.Errores = 0;
                //List<DetResp> detRespList = new List<DetResp>();
                //DetResp detResp = new DetResp();
                //detResp.ID_Impres = 1;
                //detResp.Error = 0;
                //detResp.Ruta_A = "ftp://Documentos:Docu$0213@148.233.128.212/D00-1-1-000500982_0000-0-1_Poliza.pdf";
                //D00-1-24-526032-14095647.pdf 
                //detRespList.Add(detResp);
                //datresp.DetResp = detRespList.ToArray();
                //datrespList.Add(datresp);
                //Datresp[] datrespArray = datrespList.ToArray();
                /////////////////////////////////////////////////////////////////////
                ///
                #endregion

                foreach (Datresp d in datrespArray)
                {
                    foreach (DetResp d1 in d.DetResp)
                    {
                        if (d1.Error != null && d1.Error == 0)
                        {
                            CatParametro ruta = db.CatParametro.Where(x => x.Clave.Contains("RutaReimpresion")).FirstOrDefault();
                            responseList.Add(ruta.Valor + d1.Ruta_A);
                        }
                    }
                }




            }
            catch (Exception ex)
            {
                responseList = new List<string>();
            }

            if (responseList.Count == 0)
                responseList.Add("");

            return responseList;
        }

        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }
        public string GeneraInciso(string xmlRespuesta)
        {
            Emisor_Atlas emisor_Atlas = ToObject<Emisor_Atlas>(xmlRespuesta);
            if (emisor_Atlas.Inciso != null)
            {
                return emisor_Atlas.Inciso.ToString();
            }
            return "";
        }



        public ATLASPasarelaPagosResponse PasarelaDePagos(string NumeroPoliza)
        {
            ATLASPasarelaPagosResponse result = new ATLASPasarelaPagosResponse();
            try
            {
                bool Esproduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                string urlPasarelaPagos = "";
                if (Esproduccion)
                    urlPasarelaPagos = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("API_PROD_PAGO_ATLAS")).Valor;
                else
                    urlPasarelaPagos = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("API_DES_PAGO_ATLAS")).Valor;

                if (string.IsNullOrEmpty(NumeroPoliza))
                {
                    result.Url = "";
                    result.validacion = false;
                    result.errorDescripcion = "No se encontró el número de Póliza";

                    return result;
                }

                SqlParameter sqlpoliza = new SqlParameter("@poliza", NumeroPoliza);
                ConsultaPolizaInciso polizaInciso = db.ConsultaPolizaInciso.SqlQuery("sp_consulta_Poliza_Inciso  @poliza", sqlpoliza).FirstOrDefault();

                if (polizaInciso == null)
                {
                    result.Url = "";
                    result.validacion = false;
                    result.errorDescripcion = "No se encontró datos de la de Póliza";

                    return result;
                }

                string[] TokensPoliza = NumeroPoliza.Split('-');
                string[] TokenNumeroPoliza = TokensPoliza[3].Split('_');

                long NumeroP = long.Parse(TokenNumeroPoliza[0]);
                long AnoEmision = long.Parse(TokensPoliza[4]);
                long NumReexpedicion = long.Parse(TokensPoliza[5]);
                long Linea = long.Parse(TokensPoliza[1]);
                long Endoso = long.Parse(TokenNumeroPoliza[1]);

                string usuario = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("USR_PPAGO")).Valor;
                string password = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("PASS_PPAGO")).Valor;

                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(urlPasarelaPagos);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";

                using (StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = new JavaScriptSerializer().Serialize(new
                    {
                        usuario = usuario,
                        password = password,
                        sucursal = TokensPoliza[0].ToString(),
                        linea = Linea,
                        producto = Convert.ToInt32(polizaInciso.Producto),
                        poliza = NumeroP,
                        endoso = Endoso,
                        anoEmision = AnoEmision,
                        noReexpedicion = NumReexpedicion,
                        origen = "pagolinea"
                    });

                    streamWriter.Write(json);
                    log.Info(string.Format("Se manda la siguiente informacion a la API pasarela de pagos: {0}", json));
                }

                HttpWebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                using (StreamReader streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    result = new JavaScriptSerializer().Deserialize<ATLASPasarelaPagosResponse>(streamReader.ReadToEnd());
                }

                log.Info(string.Format("la respuesta para la pasarela de pagos: {0} y url = {1}", string.IsNullOrEmpty(result.errorDescripcion) ? "" : result.errorDescripcion, string.IsNullOrEmpty(result.Url) ? "No genero url" : result.Url));
            }
            catch (Exception ex)
            {

                result = new ATLASPasarelaPagosResponse() { Url = "", errorDescripcion = ex.Message, validacion = false };
                log.Info(string.Format("Ocurrio un error no controlado al generar la pasarela de pagos: {0}", ex.Message));
            }
            return result;
        }

        public ATLASEstatusReciboResponse EstatusRecibo(string NumeroRecibo)
        {
            ATLASEstatusReciboResponse result = new ATLASEstatusReciboResponse();
            try
            {
                bool Esproduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                string urlPasarelaPagos = "";
                if (Esproduccion)
                    urlPasarelaPagos = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("API_PROD_RECIBO_ATLAS")).Valor;
                else
                    urlPasarelaPagos = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("API_QA_RECIBO_ATLAS")).Valor;

                if (string.IsNullOrEmpty(NumeroRecibo))
                {
                    result.validacion = false;
                    result.errorDescripcion = "No se encontró el número de Póliza";

                    return result;
                }

                string usuario = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("USR_PPAGO")).Valor;
                string password = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("PASS_PPAGO")).Valor;

                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(urlPasarelaPagos);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";

                using (StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = new JavaScriptSerializer().Serialize(new
                    {
                        recibo = NumeroRecibo
                    });

                    streamWriter.Write(json);
                    log.Info(string.Format("Se manda la siguiente informacion a la API consulta Estatus recibo: {0}", json));
                }

                HttpWebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                using (StreamReader streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    result = new JavaScriptSerializer().Deserialize<ATLASEstatusReciboResponse>(streamReader.ReadToEnd());
                }

                log.Info(string.Format("la respuesta para la consulta de estatus de recibo: {0} ", string.IsNullOrEmpty(result.errorDescripcion) ? "" : result.errorDescripcion));
            }
            catch (Exception ex)
            {

                result = new ATLASEstatusReciboResponse() { errorDescripcion = ex.Message, validacion = false };
                log.Info(string.Format("Ocurrio un error no controlado al generar la consulta de recibo: {0}", ex.Message));
            }
            return result;
        }

        public bool EsCoberturaConCondicionEspecial(int Idconvenio, string IdCobertura, string Anio, int idCatRamoVehiculo)
        {

            bool Aplica = true;
            int Clave = int.Parse(IdCobertura);

            LocktonModel.VModels.Coberturas cotCob = new LocktonModel.VModels.Coberturas();


            if (Clave == 129 || Clave == 258)
            {
                //Auto En agencia
                LocktonModel.db.CoberturasCondicionesEspeciales coberturasCondicionesEspeciales = db.CoberturasCondicionesEspeciales.FirstOrDefault(x => x.IdConvenio == Idconvenio && x.IdCobertura == Clave && x.CondicionEspecial.Estatus == true && x.IdCatRamoVehiculo == idCatRamoVehiculo);
                LocktonModel.db.CondicionEspecial condicionEspecial = new LocktonModel.db.CondicionEspecial();
                if (coberturasCondicionesEspeciales != null)
                    condicionEspecial = db.CondicionEspecial.FirstOrDefault(x => x.Id == coberturasCondicionesEspeciales.IdCondicionEspecial && x.Estatus == true);

                ///Reparacion En agencia
                if (condicionEspecial.Valor1 != null && condicionEspecial.Valor2 != null)
                {
                    if (int.Parse(condicionEspecial.Valor1) <= int.Parse(Anio) && int.Parse(Anio) <= int.Parse(condicionEspecial.Valor2))
                    {
                        Aplica = true;
                    }
                    else
                        Aplica = false;
                }
            }

            return Aplica;
        }

        //public class RepuestaAPI
        //{
        //    public string Url { get; set; }
        //    public string errorDescripcion { get; set; }
        //    public bool validacion { get; set; }
        //}

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
    }
}
