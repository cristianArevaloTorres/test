﻿using com.lockton.xml.gnp.cotizacion.request;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonServicios.Catalogos;
using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using LocktonServicios.GNPInfoServiceCotizarEmitir;
using LocktonServicios.GNPInfoServiceImpresion;
using LocktonServicios.GNPInfoServiceConsultaRecibos;
using LocktonServicios.GNPInfoServiceImpresionRecibos;
using Newtonsoft.Json;
using Poliza = LocktonModel.db.Poliza;
using Recibo = LocktonModel.db.Recibo;
using System.Threading.Tasks;
using System.Net.Http;
using System.Web;
using System.Threading;
using LocktonServicios.XMLEntity.Cotizacion.GNPPreferente.Solicitudes;
using LocktonServicios.XMLEntity.Cotizacion.GNPPreferente.Respuestas;
using System.Net.Http.Headers;
using LocktonServicios.Utilidades;
using LocktonServicios.BitacoraPoliza;
using System.Data.SqlClient;
using LocktonServicios.SICASProcesaRecuperaInfo;
using RestSharp;
using System.Xml.XPath;
using Renci.SshNet;

namespace LocktonServicios.Aseguradoras
{
    public class GNPPreferenteService : IGNPService
    {
        #region Properties

        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger(typeof(GNPPreferenteService));

        #endregion



        #region Functional Methods


        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("yyyyMMdd");

                XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION solicitud = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION>(xmlEmision);

                solicitud.SOLICITUD.FCH_INICIO_VIGENCIA = date;

                //Enviar petición de cotización 
                string xmlSolicitud = Utilidades.Utilidades.GetStringFromXML(solicitud);
                var response = EnviaSolicitudCotizacion(solicitud);

                string result = response.Content.ReadAsStringAsync().Result.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");

                //Recupera el xml de respuesta de cotización
                XmlDocument node = new XmlDocument();
                node.LoadXml(result);
                XmlNode node2 = node.FirstChild;

                //Set de datos para el comparativo y guardado en db de la cotización  
                resultado.XMLSolicitud = xmlSolicitud;
                resultado.XMLRecepcion = node2.OuterXml;

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception(node2.OuterXml);
                }

                if (node.Name == "Errores")
                {
                    throw new Exception(node2.OuterXml);

                }

                return resultado;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {
            try
            {
                if (string.IsNullOrEmpty(CotizacionCompara.Edad))
                {
                    if (CotizacionCompara.FechaNacimiento == null)
                        CotizacionCompara.FechaNacimiento = DateTime.Now;
                    CotizacionCompara.Edad = Utilidades.Utilidades.CalculaEdad(Convert.ToDateTime(CotizacionCompara.FechaNacimiento)).ToString();

                }
                XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION reqCotAutos = new XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION();
                Comparar infoCompara = new Comparar();
                infoCompara.Aseguradora = "GNP";

                //Obtener datos de la db
                Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
                ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
                List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, string.IsNullOrEmpty(CotizacionCompara.TipoVehiculo) ? 1 : Convert.ToInt32(CotizacionCompara.TipoVehiculo));
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                int idFormaPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString()).Id;
                PeriodicidadFormaPago periodicidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioId && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
                var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == CotizacionCompara.FormadePago).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);


                if (cot.Catalogo.Count.Equals(0))
                {
                    string error = "El vehículo no está listado en el catálogo de GNP";
                    infoCompara.ErrorXML = error;
                    log.Error(string.Concat("cotizaVehiculo error GNP ", error));
                    log.Info(string.Format("GNP Xml Cotizacion Respuesta: {0}", "No es posible cotizar este vehículo", CotizacionCompara.DescripcionVehiculo));
                    CotizacionCompara.Comparar.Add(infoCompara);
                    return CotizacionCompara;
                }
                descripciones _cotDesAuto = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault();
                string InicioVigencia = CotizacionCompara.FechaInicio.ToString("dd/MM/yyyy");
                string FinVigencia = CotizacionCompara.FechaFin.ToString("dd/MM/yyyy");
                string prefijo = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("PrefijoGNPPreferente")).Valor;

                infoCompara.FechaCotizacion = CotizacionCompara.FechaInicio;

                // Datos principales para cotizar 
                reqCotAutos.SOLICITUD = new XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACIONSOLICITUD();
                reqCotAutos.SOLICITUD.USUARIO = convenioCotiza.Usuario;
                reqCotAutos.SOLICITUD.PASSWORD = convenioCotiza.Contrasena;
                reqCotAutos.SOLICITUD.ID_UNIDAD_OPERABLE = convenioCotiza.Tarifa;

                ColocaFormaDeCobro(reqCotAutos, CotizacionCompara.MediodePago);

                reqCotAutos.CONTRATANTE = new COTIZACIONCONTRATANTE();

                reqCotAutos.SOLICITUD.ELEMENTOS = new COTIZACIONSOLICITUDELEMENTOS();
                reqCotAutos.SOLICITUD.ELEMENTOS.ELEMENTO = new COTIZACIONSOLICITUDELEMENTOSELEMENTO();
                reqCotAutos.SOLICITUD.ELEMENTOS.ELEMENTO.NOMBRE = "CODIGO_PROMOCION";
                reqCotAutos.SOLICITUD.ELEMENTOS.ELEMENTO.CLAVE = convenioCotiza.CodigoPromocion;
                reqCotAutos.SOLICITUD.ELEMENTOS.ELEMENTO.VALOR = convenioCotiza.CodigoPromocion;

                //Set de inicio y fin de vigencia en el objeto de cotización
                reqCotAutos.SOLICITUD.FCH_INICIO_VIGENCIA = DateTime.Parse(InicioVigencia).ToString("yyyyMMdd");
                reqCotAutos.SOLICITUD.FCH_FIN_VIGENCIA = DateTime.Parse(FinVigencia).ToString("yyyyMMdd");
                reqCotAutos.SOLICITUD.PERIODICIDAD = periodicidad.FormaPago;// ObtenerFormaPago(periodicidad);

                //Se obtienen coberturas haciendo match con el Id de cobertura
                CoberturaIn[] listaCoberturas = ObtieneClavesCoberturas(coberturasPaquete, convenioCotiza.Id, CotizacionCompara.IdConvenio, CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);

                //Set de Coberturas en el paquete seleccionado; Set de paquete en objeto de cotización
                reqCotAutos.PAQUETES = new XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACIONPAQUETES();
                reqCotAutos.PAQUETES.PAQUETE = new XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACIONPAQUETESPAQUETE();
                reqCotAutos.PAQUETES.PAQUETE.DESC_PAQUETE = paqueteConvenio.NombrePaquete;
                reqCotAutos.PAQUETES.PAQUETE.CVE_PAQUETE = string.Concat(prefijo, CotizacionCompara.EmisionPersonaMoral ? paqueteConvenio.IdPlanPersonaMoral : paqueteConvenio.IdPlan);
                reqCotAutos.PAQUETES.PAQUETE.COBERTURAS = new XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACIONPAQUETESPAQUETECOBERTURAS();

                var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@IdConvenio",convenioId)
                    ,new SqlParameter("@IdCatRamoVehiculo",paqueteConvenio.IdCatRamoVehiculo)
                    ,new SqlParameter("@Year",CotizacionCompara.Año)
                };

                var coberturasEspeciales = db.ListaCombo.SqlQuery("sp_CoberturaEspecial_Convenio @IdConvenio,@IdCatRamoVehiculo,@Year ", parameters.ToArray()).ToList();

                if (coberturasEspeciales != null && coberturasEspeciales.Any())
                {
                    foreach (var coberturaEspecial in coberturasEspeciales)
                    {
                        if (coberturasPaquete.Exists(a => a.Codigo == coberturaEspecial.Nombre))
                        {
                            reqCotAutos.PAQUETES.PAQUETE.COBERTURAS.COBERTURA = new COTIZACIONPAQUETESPAQUETECOBERTURASCOBERTURA();
                            reqCotAutos.PAQUETES.PAQUETE.COBERTURAS.COBERTURA.CVE_COBERTURA = coberturaEspecial.Nombre;
                        }
                    }

                }


                //Consulta de catálogo homologado 
                _Descripciones _resultado = ConsultaCatalogoHomologado(_cotDesAuto.clave);

                //Set de objeto vehículo consultando el catálogo homologado
                //if (CotizacionCompara.TipoVehiculo.Equals("1"))
                //{
                COTIZACIONVEHICULO requestVehiculo =
                     ConstruyeObjetoVehiculoCotizacion(_resultado, _cotDesAuto, CotizacionCompara.Año, CotizacionCompara.CodigoPostal, ConveniosPaquetes.Empresa.Direccion.CodigoPostal, CotizacionCompara.ValorFactura, CotizacionCompara.MontoFactura.ToString(), false);
                reqCotAutos.VEHICULO = requestVehiculo;
                //}
                //if (CotizacionCompara.TipoVehiculo.Equals("2"))
                //{
                //    COTIZACIONVEHICULO requestVehiculo =
                //        ConstruyeObjetoVehiculoCotizacion(_resultado, _cotDesAuto, CotizacionCompara.Año, CotizacionCompara.CodigoPostal, ConveniosPaquetes.Empresa.Direccion.CodigoPostal, CotizacionCompara.ValorFactura, CotizacionCompara.MontoFactura.ToString(), false, false, true);
                //    reqCotAutos.VEHICULO = requestVehiculo;
                //}
                //if (CotizacionCompara.TipoVehiculo.Equals("3"))
                //{
                //    COTIZACIONVEHICULO requestVehiculo =
                //        ConstruyeObjetoVehiculoCotizacion(_resultado, _cotDesAuto, CotizacionCompara.Año, CotizacionCompara.CodigoPostal, ConveniosPaquetes.Empresa.Direccion.CodigoPostal, CotizacionCompara.ValorFactura, CotizacionCompara.MontoFactura.ToString(), false, true, false);
                //    reqCotAutos.VEHICULO = requestVehiculo;
                //}


                //Set de Conductor 
                COTIZACIONCONDUCTOR requestConductor = ConstruyeObjetoConductorCotizacion(detalleUsuario, CotizacionCompara.Genero, CotizacionCompara.Edad, Convert.ToDateTime(CotizacionCompara.FechaNacimiento), CotizacionCompara.CodigoPostal);
                reqCotAutos.CONDUCTOR = requestConductor;

                COTIZACIONCONTRATANTE requestContratante = ConstruyeObjetoContratanteCotizacion(CotizacionCompara.CodigoPostal, CotizacionCompara.EmisionPersonaMoral);
                reqCotAutos.CONTRATANTE = requestContratante;

                //Enviar petición de cotización  
                string solicitud = Utilidades.Utilidades.GetStringFromXML(reqCotAutos);
                log.Info(string.Format("GNP Xml Cotizacion Solicitud: {0}", solicitud));

                var response = EnviaSolicitudCotizacion(reqCotAutos);

                string result = response.Content.ReadAsStringAsync().Result.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");

                //Recupera el xml de respuesta de cotización
                XmlDocument node = new XmlDocument();
                node.LoadXml(result);
                XmlNode node2 = node.FirstChild;

                //Set de datos para el comparativo y guardado en db de la cotización  
                infoCompara.XmlEmision = solicitud;
                infoCompara.XmlRespuesta = node2.OuterXml;
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;

                infoCompara.Año = CotizacionCompara.Año;
                infoCompara.FechaInicio = InicioVigencia;
                infoCompara.FechaFin = FinVigencia;
                infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;

                if (!response.IsSuccessStatusCode)
                {
                    infoCompara.ErrorXML = node2.OuterXml;
                    log.Error("cotizaVehiculo error GNP " + node2.OuterXml);
                    log.Info(string.Format("GNP Xml Cotizacion Respuesta: {0}", node2.OuterXml));
                    CotizacionCompara.Comparar.Add(infoCompara);
                    return CotizacionCompara;
                }

                log.Info(string.Format("GNP Xml Cotizacion Respuesta: {0}", node2.OuterXml));

                //Obtiene el resultado de cotización y construye el objeto que se regresa con la info obtenida
                if (node.Name == "Errores")
                {
                    infoCompara.ErrorXML = node2.OuterXml;
                    log.Error("cotizaVehiculo error GNP " + node2.OuterXml);
                }
                else
                {
                    XMLEntity.Cotizacion.GNPPreferente.Respuestas.COTIZACION movimientoResult = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Respuestas.COTIZACION>(node2.OuterXml);

                    infoCompara.CotizacionClave = "";

                    foreach (var paquete in movimientoResult.PAQUETES)
                    {
                        infoCompara.Coberturas = ObtieneCoberturasCotizadas(paquete.COBERTURAS, infoCompara, CotizacionCompara.Cobertura, coberturasPaquete);
                        ColocaPrimasCotizadas(infoCompara, paquete.TOTALES);
                    }
                }

                CotizacionCompara.Comparar.Add(infoCompara);
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente para realizar tu cotizacion {0}", ex.Message));
                Comparar infoCompara = new Comparar();
                infoCompara.ErrorXML = ex.Message;
                infoCompara.Aseguradora = "GNP";
                CotizacionCompara.Comparar.Add(infoCompara);
                //throw;
            }

            return CotizacionCompara;
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            //Configuración
            bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
            PeriodicidadFormaPago periodicidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            CatPeriodicidadFormaPago catPeriodicidad = db.CatPeriodicidadFormaPago.FirstOrDefault(x => x.Id == InfoEmision.CotizacionAutoGuardar.FormadePago);
            CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
            Cotizacion cotizacion = db.Cotizacion.First(a => a.Id == cotizacionDetalle.IdCotizacion);
            int IdPaquete = int.Parse(cotizacionDetalle.Paquete);
            PaqueteAseguradora tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == InfoEmision.Convenio.IdAseguradora && x.IdCatTipoPaquete == IdPaquete).FirstOrDefault();
            CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
            string telefono = InfoEmision.TelefonoCel;
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Empresa.Id).FirstOrDefault();
            string codigoPostal = cotizacionDetalle.Cotizacion.CodigoPostal;//ObtieneCodigoPostalParaEmision(InfoEmision);
            LocktonModel.db.CodigoPostal catCodigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == codigoPostal);
            XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION xmlCotizacionSeleccionada = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION>(cotizacionDetalle.XMLSolicitud);
            var ramoVehiculo = db.CatRamoVehiculo.First(x => x.Clave == InfoEmision.CotizacionAutoGuardar.TipoVehiculo);
            var convenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatRamoVehiculo == ramoVehiculo.IdCatRamo);

            var recepcionCotizacion = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Respuestas.COTIZACION>(cotizacionDetalle.XMLRecepcion);
            string numeroCotizacion = recepcionCotizacion.SOLICITUD.NUM_COTIZACION;

            string XmlizedString = string.Empty;
            string xmlResponse = string.Empty;

            try
            {
                XMLEntity.Cotizacion.GNPPreferente.Solicitudes.EMISION reqEmiAuto = new XMLEntity.Cotizacion.GNPPreferente.Solicitudes.EMISION();

                reqEmiAuto.SOLICITUD = new XMLEntity.Cotizacion.GNPPreferente.Solicitudes.EMISIONSOLICITUD();
                reqEmiAuto.SOLICITUD.USUARIO = InfoEmision.Convenio.Usuario;
                reqEmiAuto.SOLICITUD.PASSWORD = InfoEmision.Convenio.Contrasena;
                reqEmiAuto.SOLICITUD.ID_UNIDAD_OPERABLE = InfoEmision.Convenio.Tarifa;

                reqEmiAuto.SOLICITUD.PERIODICIDAD = periodicidad.FormaPago;// ObtenerFormaPago(periodicidad);
                reqEmiAuto.SOLICITUD.NUM_COTIZACION = numeroCotizacion;

                log.Info("Inicia emision GNP");

                if (!string.IsNullOrEmpty(telefono) && telefono.Length > 8)
                {
                    telefono = telefono.Substring(telefono.Length - Math.Min(8, telefono.Length));
                }

                string caratula = ObtieneCaratulaPorSP(InfoEmision.Convenio.Id, IdPaquete, InfoEmision.CotizacionAutoGuardar.FormadePago, medioPago.Id, InfoEmision.CotizacionAutoGuardar.Agnio, Convert.ToInt32(InfoEmision.CotizacionAutoGuardar.TipoVehiculo));

                //Nomina es I tarjeta es R CotizacionCompara.MediodePago
                ColocaFormaDeCobro(reqEmiAuto, InfoEmision.CotizacionAutoGuardar.MediodePago);

                DateTime InicioVigencia = InfoEmision.Convenio.InicioVigencia;
                DateTime FinVigencia = InfoEmision.Convenio.FinVigencia;

                reqEmiAuto.SOLICITUD.FCH_INICIO_VIGENCIA = xmlCotizacionSeleccionada.SOLICITUD.FCH_INICIO_VIGENCIA.ToString();
                reqEmiAuto.SOLICITUD.FCH_FIN_VIGENCIA = xmlCotizacionSeleccionada.SOLICITUD.FCH_FIN_VIGENCIA.ToString();
                reqEmiAuto.SOLICITUD.FCH_EFECTO_MOVIMIENTO = xmlCotizacionSeleccionada.SOLICITUD.FCH_INICIO_VIGENCIA.ToString();
                reqEmiAuto.SOLICITUD.FCH_FIN_EFECTO_MOVIMIENTO = xmlCotizacionSeleccionada.SOLICITUD.FCH_INICIO_VIGENCIA.ToString();
                reqEmiAuto.SOLICITUD.CVE_MONEDA = "MXN";

                reqEmiAuto.SOLICITUD.BAN_RENOVACION_AUTOMATICA = "0";
                reqEmiAuto.SOLICITUD.BAN_URL_IMPRESION = "1";
                reqEmiAuto.SOLICITUD.CVE_FORMA_AJUSTE_IRREGULAR = "PR";
                reqEmiAuto.SOLICITUD.BAN_CONTRA_IGUAL_CONDUCTOR = InfoEmision.ConductorHabitual ? "1" : "0";
                reqEmiAuto.SOLICITUD.BAN_CONTRA_IGUAL_BENEFICIARIO = string.IsNullOrEmpty(InfoEmision.BeneficiarioPreferente) ? "1" : "0";
                reqEmiAuto.SOLICITUD.BAN_AFECTA_BONO = "1";

                reqEmiAuto.SOLICITUD.ELEMENTOS = new EMISIONSOLICITUDELEMENTOS();
                reqEmiAuto.SOLICITUD.ELEMENTOS.ELEMENTO = new EMISIONSOLICITUDELEMENTOSELEMENTO();
                reqEmiAuto.SOLICITUD.ELEMENTOS.ELEMENTO.CLAVE = xmlCotizacionSeleccionada.SOLICITUD.ELEMENTOS.ELEMENTO.CLAVE.ToString();
                reqEmiAuto.SOLICITUD.ELEMENTOS.ELEMENTO.NOMBRE = xmlCotizacionSeleccionada.SOLICITUD.ELEMENTOS.ELEMENTO.NOMBRE.ToString();
                reqEmiAuto.SOLICITUD.ELEMENTOS.ELEMENTO.VALOR = xmlCotizacionSeleccionada.SOLICITUD.ELEMENTOS.ELEMENTO.VALOR.ToString();


                _Descripciones _resultado = ConsultaCatalogoHomologado(string.Concat(xmlCotizacionSeleccionada.VEHICULO.TIPO_VEHICULO, xmlCotizacionSeleccionada.VEHICULO.ARMADORA, xmlCotizacionSeleccionada.VEHICULO.CARROCERIA, xmlCotizacionSeleccionada.VEHICULO.VERSION));

                List<Coberturas> coberturasPaquete = ObtenerCoberturas(InfoEmision.Convenio.Id, Convert.ToInt32(cotizacionDetalle.Paquete), string.IsNullOrEmpty(InfoEmision.Vehiculo.TipoVehiculo) ? 1 : Convert.ToInt32(InfoEmision.Vehiculo.TipoVehiculo));

                reqEmiAuto.VEHICULO = ConstruyeObjetoVehiculoEmision(InfoEmision, xmlCotizacionSeleccionada, coberturasPaquete);

                reqEmiAuto.CONTRATANTE = ConstruyeObjetoContratanteEmision(InfoEmision, xmlCotizacionSeleccionada, recepcionCotizacion, codigoPostal, catCodigoPostal);

                reqEmiAuto.CONDUCTOR = ConstruyeObjetoAseguradoEmision(xmlCotizacionSeleccionada, InfoEmision);

                if (InfoEmision.RequiereFactura)
                {
                    var catcodicoPostalContratante = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == reqEmiAuto.CONTRATANTE.DIRECCION.CODIGO_POSTAL);

                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES = new DATOS_FISCALES();

                    if (InfoEmision.EmisionPersonaMoral)
                    {
                        reqEmiAuto.CONTRATANTE.DATOS_FISCALES.RFC = reqEmiAuto.CONTRATANTE.RFC.ToString();
                        reqEmiAuto.CONTRATANTE.DATOS_FISCALES.NOMBRE_RAZON_SOCIAL = reqEmiAuto.CONTRATANTE.RAZON_SOCIAL;
                        reqEmiAuto.CONTRATANTE.DATOS_FISCALES.CVE_REGIMEN_FISCAL = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal).Clave;
                        reqEmiAuto.CONTRATANTE.DATOS_FISCALES.REGIMEN_CAPITAL = db.CatRegimenCapital.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenCapital).Abreviatura;
                    }
                    else
                    {
                        reqEmiAuto.CONTRATANTE.DATOS_FISCALES.RFC = reqEmiAuto.CONDUCTOR.RFC.ToString();
                        reqEmiAuto.CONTRATANTE.DATOS_FISCALES.NOMBRE_RAZON_SOCIAL = $"{reqEmiAuto.CONDUCTOR.NOMBRES} {reqEmiAuto.CONDUCTOR.APELLIDO_PATERNO} {reqEmiAuto.CONDUCTOR.APELLIDO_MATERNO}";
                        reqEmiAuto.CONTRATANTE.DATOS_FISCALES.CVE_REGIMEN_FISCAL = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.IdRegimenFiscal).Clave;
                    }

                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION = new DIRECCION_DATOS_FISCALES();
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.CALLE = QuitarAcentos(reqEmiAuto.CONTRATANTE.DIRECCION.CALLE.ToString());
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.NUMERO_EXTERIOR = reqEmiAuto.CONTRATANTE.DIRECCION.NUMERO_EXTERIOR.ToString();
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.NUMERO_INTERIOR = reqEmiAuto.CONTRATANTE.DIRECCION.NUMERO_INTERIOR == null ? "" : reqEmiAuto.CONTRATANTE.DIRECCION.NUMERO_INTERIOR.ToString();
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.COLONIA = QuitarAcentos(reqEmiAuto.CONTRATANTE.DIRECCION.COLONIA.ToString());
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.DELEGACION_MCPIO = QuitarAcentos(reqEmiAuto.CONTRATANTE.DIRECCION.DELEGACION_MCPIO.ToString());
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.ESTADO = QuitarAcentos(reqEmiAuto.CONTRATANTE.DIRECCION.ESTADO.ToString());
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.CODIGO_POSTAL = catcodicoPostalContratante.Codigo;
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.CVE_COLONIA = catcodicoPostalContratante.IdMunicipioCotizacion;
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.CVE_MUNICIPIO = catcodicoPostalContratante.IdCiudadCotizacion;
                    reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.CVE_ESTADO = catcodicoPostalContratante.IdEstadoCotizacion;

                    var _facturacion = new Facturacion();
                    _facturacion.RFC = reqEmiAuto.CONTRATANTE.DATOS_FISCALES.RFC;
                    _facturacion.Nombre = reqEmiAuto.CONTRATANTE.DATOS_FISCALES.NOMBRE_RAZON_SOCIAL;
                    _facturacion.CodigoPostal = reqEmiAuto.CONTRATANTE.DATOS_FISCALES.DIRECCION.CODIGO_POSTAL;
                    _facturacion.IdRegimenFiscal = InfoEmision.IdRegimenFiscal;

                    Utilidades.Utilidades.GeneraRegistroFacturacion(_facturacion);

                }


                reqEmiAuto.PAQUETE = new EMISIONPAQUETE();
                reqEmiAuto.PAQUETE.CVE_PAQUETE = xmlCotizacionSeleccionada.PAQUETES.PAQUETE.CVE_PAQUETE.ToString();

                //         if (InfoEmision.EmisionPersonaMoral)
                //         {
                //	string prefijo = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("PrefijoGNPPreferente")).Valor;
                //             var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == cotizacionDetalle.IdPaqueteConvenio);
                //	reqEmiAuto.PAQUETE.CVE_PAQUETE = string.Concat(prefijo, paqueteConvenio.IdPlanPersonaMoral );

                //}

                reqEmiAuto.IMPORTES = new EMISIONIMPORTES();
                reqEmiAuto.IMPORTES.IMP_IVA = recepcionCotizacion.PAQUETES.FirstOrDefault().TOTALES.TOTAL_PRIMA.CONCEPTO_ECONOMICO.Where(ce => ce.NOMBRE.Equals("IVA")).FirstOrDefault().MONTO;
                reqEmiAuto.IMPORTES.PRIMA_NETA = recepcionCotizacion.PAQUETES.FirstOrDefault().TOTALES.TOTAL_PRIMA.CONCEPTO_ECONOMICO.Where(ce => ce.NOMBRE.Equals("PRIMA_NETA")).FirstOrDefault().MONTO;
                reqEmiAuto.IMPORTES.PRIMA_TOTAL = recepcionCotizacion.PAQUETES.FirstOrDefault().TOTALES.TOTAL_PRIMA.CONCEPTO_ECONOMICO.Where(ce => ce.NOMBRE.Equals("TOTAL_PAGAR")).FirstOrDefault().MONTO;

                bool aplicaDatosBancarios = reqEmiAuto.SOLICITUD.VIA_PAGO.Equals("BC");

                List<string> listaDatosReemplazo = aplicaDatosBancarios ? ObtieneListaDatosAReemplazarXML(InfoEmision) : new List<string>();
                string datosAReemplazar = aplicaDatosBancarios ? ObtieneCadenaDatosAReemplazarXML(InfoEmision, new Banco()) : string.Empty;

                XmlizedString = Utilidades.Utilidades.ToXMLString<XMLEntity.Cotizacion.GNPPreferente.Solicitudes.EMISION>(reqEmiAuto);

                log.Info(string.Format("GNP Xml Emision Solicitud: {0}", XmlizedString.Replace("\n", "").Replace("\r", "")));

                if (aplicaDatosBancarios)
                    AgregaDatosBancariosContratante(reqEmiAuto.CONTRATANTE, InfoEmision);

                var response = EnviaSolicitudEmision(reqEmiAuto);

                xmlResponse = response.Content.ReadAsStringAsync().Result.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");

                XmlDocument node = new XmlDocument();

                if (!string.IsNullOrEmpty(datosAReemplazar) && listaDatosReemplazo.Count > 0)
                {
                    string datosOriginales = datosAReemplazar;
                    foreach (string dato in listaDatosReemplazo)
                    {
                        datosAReemplazar.Replace(dato, "*****");
                    }
                    xmlResponse = xmlResponse.Replace(datosOriginales, datosAReemplazar);
                }

                node.LoadXml(xmlResponse);

                log.Info("Obtiene respuesta Emitir GNP-Preferente Resultado: " + xmlResponse.Replace("\n", "").Replace("\r", ""));


                if (!response.IsSuccessStatusCode)
                {
                    // infoCompara.ErrorXML = node2.OuterXml;
                    log.Error("emiteVehiculo error GNP-Prefrente: " + xmlResponse);


                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, xmlResponse, node.InnerText, "Emisión");
                    return new EmisionPoliza(false, XmlizedString, node.InnerText);
                }


                /*Termina emisión de polizas*/
                Poliza poliza = new Poliza();
                PolizaDetalle polizaDet = new PolizaDetalle();

                if (node.Name == "Errores")
                {
                    if (InfoEmision.EsFlotilla)
                    {
                        log.Error("emiteVehiculo error GNP-Flotilla: " + xmlResponse.Replace("\n", "").Replace("\r", ""));
                    }
                    else
                    {
                        log.Error("emiteVehiculo error GNP-Individual: " + xmlResponse.Replace("\n", "").Replace("\r", ""));
                    }
                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, xmlResponse, node.InnerText, "Emisión");
                    return new EmisionPoliza(false, XmlizedString, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde." + node.InnerText, null);
                }

                var resultadoEmision = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Respuestas.EMISION>(xmlResponse);

                decimal primaNeta = 0.0M;
                decimal primaTotal = 0.0M;
                decimal primerPago = 0.0M;
                decimal pagoSubsecuente = 0.0M;
                decimal derechos = 0.0M;
                decimal recargo = 0.0M;
                decimal impuestos = 0.0M;
                int pagosSubsecuentes = 0;
                int numPagos = 0;
                decimal Recargo_Pago_Fracc = 0.0M;

                foreach (var primasResultado in resultadoEmision.CONCEPTOS_ECONOMICOS)
                {
                    switch (primasResultado.NOMBRE)
                    {
                        case "PRIMA_NETA":
                            primaNeta = decimal.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "TOTAL_PAGAR":
                            primaTotal = decimal.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "IVA":
                            impuestos = decimal.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "RECARGO_DESCUENTO":
                            recargo = decimal.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "DERECHOS_POLIZA":
                            derechos = decimal.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "IMP_PRIMER_RECIBO":
                            primerPago = decimal.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "IMP_RECIBO_SUBSECUENTE":
                            pagoSubsecuente = decimal.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "NUM_RECIBOS_SUB":
                            pagosSubsecuentes = int.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "NUM_PAGOS":
                            numPagos = int.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;
                        case "RECARGO_PAGO_FRACC":
                            Recargo_Pago_Fracc = decimal.Parse(QuitaCaracteres(primasResultado.MONTO.ToString()), CultureInfo.InvariantCulture);
                            break;

                    }
                }

                List<string> format = new List<string>();
                format.Add("dd/MM/yyyy");
                format.Add("yyyyMMdd");
                try
                {
                    FinVigencia = DateTime.ParseExact(reqEmiAuto.SOLICITUD.FCH_FIN_VIGENCIA, format.ToArray(), CultureInfo.InvariantCulture, DateTimeStyles.None);
                    InicioVigencia = DateTime.ParseExact(reqEmiAuto.SOLICITUD.FCH_INICIO_VIGENCIA, format.ToArray(), CultureInfo.InvariantCulture, DateTimeStyles.None);
                }
                catch (Exception) { }

                poliza = ConstruyeObjetoPoliza(
                    !string.IsNullOrEmpty(resultadoEmision.SOLICITUD.NUM_POLIZA) ? resultadoEmision.SOLICITUD.NUM_POLIZA.TrimStart(new Char[] { '0' }) : resultadoEmision.SOLICITUD.NUM_POLIZA,
                    FinVigencia, InicioVigencia, primaNeta, primaTotal, tipoPaquete.IdCatTipoPaquete, InfoEmision);

                polizaDet = ConstruyeObjetoPolizaDetalle(cotizacionDetalle,
                    medioPago.Id, periodicidad.IdCatPeriodicidadFormaPago, xmlResponse, XmlizedString, InfoEmision);

                List<Recibo> recibosGenerados = new List<Recibo>();

                if (!resultadoEmision.CONCEPTOS_ECONOMICOS.Where(ce => ce.NOMBRE.Equals("NUM_PAGOS")).FirstOrDefault().MONTO.Equals(1) && medioPago.Id == 3)
                    recibosGenerados = ObtieneObjetoRecibosEmision(resultadoEmision.RESULTADO_MONTO_PARCIALIDAD, InicioVigencia, FinVigencia, primaTotal, primaNeta, derechos, recargo, impuestos, convenioRamoPaquete.Comision > 0);
                else if (!resultadoEmision.CONCEPTOS_ECONOMICOS.Where(ce => ce.NOMBRE.Equals("NUM_PAGOS")).FirstOrDefault().MONTO.Equals(1) && medioPago.Id != 3)
                    recibosGenerados = ObtieneObjetoRecibosEmision(pagosSubsecuentes, numPagos, pagoSubsecuente, primerPago, primaTotal, InicioVigencia, FinVigencia, derechos, recargo, impuestos, primaNeta, InfoEmision.Convenio, Recargo_Pago_Fracc, convenioRamoPaquete.Comision > 0);
                else
                    recibosGenerados = ObtieneObjetoRecibosEmision(InicioVigencia, FinVigencia, primaTotal, primaNeta, derechos, recargo, impuestos, convenioRamoPaquete.Comision > 0);

                Endoso endosoAlta = ConstruyeObjetoEndosoAlta(recibosGenerados);

                InfoEmision.NoCotizacion = numeroCotizacion;

                poliza.Endoso.Add(endosoAlta);
                poliza.PolizaDetalle.Add(polizaDet);
                db.Poliza.Add(poliza);
                db.SaveChanges();

                List<string> pdf = ReimprimePoliza(poliza.NumeroPoliza, "", poliza.ClaveAgente,"",0);
                poliza.UrlPDFPoliza = pdf.FirstOrDefault();
                poliza.UrlPDFRecibos = pdf.LastOrDefault();
                db.SaveChanges();

                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, xmlResponse, "", "Emisión");

                Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                return new EmisionPoliza(true, XmlizedString, xmlResponse, poliza);
            }
            catch (Exception ex)
            {
                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, xmlResponse, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");
                return new EmisionPoliza(false, null, ex.Message);
            }
        }

        #endregion



        #region Utility Methods

        private int ObtieneIdRamoVehiculo(int idCatRamoVehiculo)
        {
            return db.CatUsoVehiculo.FirstOrDefault(cuv => cuv.Clave == idCatRamoVehiculo.ToString() && cuv.Estatus == 1).IdCatRamo ?? 1;
        }

        private string ObtenerClaveEstadoCivil(DetalleUsuario detalleUsuario)
        {
            throw new NotImplementedException();
        }

        //private string ObtenerClavePaquete(string paquete, string claveVehiculo)
        //{
        //    string respuesta = string.Empty;
        //    switch (paquete.ToLower())
        //    {
        //        case "amplia":
        //            switch (claveVehiculo.ToLower().Substring(0, 3))
        //            {
        //                case "aut":
        //                    respuesta = "PRS0036741";
        //                    break;
        //                case "ca1":
        //                    respuesta = "PRS0036738";
        //                    break;
        //                case "ca2":
        //                    respuesta = "PRS0036750";
        //                    break;
        //                case "mot":
        //                    respuesta = "PRS0036735";
        //                    break;
        //            }
        //            break;
        //        case "rc":
        //            switch (claveVehiculo.ToLower().Substring(0, 3))
        //            {
        //                case "aut":
        //                    respuesta = "PRS0036742";
        //                    break;
        //                case "ca1":
        //                    respuesta = "PRS0036739";
        //                    break;
        //                case "ca2":
        //                    respuesta = "PRS0036751";
        //                    break;
        //                case "mot":
        //                    respuesta = "PRS0036737";
        //                    break;
        //            }
        //            break;
        //        case "responsabilidad civil":
        //            switch (claveVehiculo.ToLower().Substring(0, 3))
        //            {
        //                case "aut":
        //                    respuesta = "PRS0036742";
        //                    break;
        //                case "ca1":
        //                    respuesta = "PRS0036739";
        //                    break;
        //                case "ca2":
        //                    respuesta = "PRS0036751";
        //                    break;
        //                case "mot":
        //                    respuesta = "PRS0036737";
        //                    break;
        //            }
        //            break;
        //        case "limitada":
        //            switch (claveVehiculo.ToLower().Substring(0, 3))
        //            {
        //                case "aut":
        //                    respuesta = "PRS0036743";
        //                    break;
        //                case "ca1":
        //                    respuesta = "PRS0036740";
        //                    break;
        //                case "ca2":
        //                    respuesta = "PRS0036752";
        //                    break;
        //                case "mot":
        //                    respuesta = "PRS0036736";
        //                    break;
        //            }
        //            break;
        //    }
        //    return respuesta;
        //}

        //private string ObtenerFormaPago(PeriodicidadFormaPago periodicidad)
        //{
        //    string formaPago = string.Empty;
        //    switch (periodicidad.FormaPago.ToLower())
        //    {
        //        case "anual":
        //            formaPago = "A";
        //            break;
        //        case "mensual":
        //            formaPago = "M";
        //            break;
        //        case "semestral":
        //            formaPago = "S";
        //            break;
        //    }
        //    return formaPago;
        //}

        private string QuitaCaracteres(string numero)
        {
            return numero.Replace(",", "").Replace("$", "").Replace(" ", "").Replace("%", "");
        }

        private string QuitaCaracteresCoberturas(string numero)
        {
            return numero.Replace(" ", "").Replace("%", "");
        }

        public List<Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete, int tipoVehiculo)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio && a.IdCatTipoPaquete == idPaquete && c.IdCatRamoVehiculo == tipoVehiculo
                                           && b.Clave != "0"
                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible / 100).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", ""),
                                               IdCatRamo = c.IdCatRamoVehiculo,
                                               IdCobertura = b.Id,
                                               IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1

                                           }).ToList();
            return coberturas;
        }

        private string ObtenerClaveEstado(string codigoPostal)
        {
            var estado = from s in db.CatCodigoPostal
                         join er in db.CatEstadosRepublica on s.IdEstado equals er.Id
                         join egnp in db.CatEstadosGNP on er.Estado.ToLower() equals egnp.Edo.ToLower()
                         where s.Codigo == codigoPostal
                         select egnp.Id;
            return estado?.FirstOrDefault() ?? "08";
            //LocktonModel.db.CodigoPostal cp = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == codigoPostal);
            //CatEstadosRepublica estado = db.CatEstadosRepublica.FirstOrDefault(a => a.Id == cp.IdEstado);
            //return estado == null ? string.Empty : estado.Clave;
        }

        public Comparar LeeXmlInformacion(string XmlResultado, string xmlEnvio, int numeroRecibos)
        {
            Comparar infoCompara = new Comparar();

            //XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            //xmlCotizacionSeleccionada.LoadXml(xmlEnvio);
            XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION xmlCotizacionSeleccionada = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION>(xmlEnvio);

            try
            {
                XMLEntity.Cotizacion.GNPPreferente.Respuestas.COTIZACION resultadoCotizacion = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Respuestas.COTIZACION>(XmlResultado);

                DateTime conversionFechaInicio = DateTime.Now;
                DateTime conversionFechaFin = DateTime.Now.AddYears(1);

                foreach (var paquete in resultadoCotizacion.PAQUETES)
                {
                    //infoCompara.Coberturas = ObtieneCoberturasCotizadas(paquete.COBERTURAS, infoCompara, CotizacionCompara.Cobertura, coberturasPaquete);
                    ColocaPrimasCotizadas(infoCompara, paquete.TOTALES);
                }

                infoCompara.FechaInicio = ConvertirFecha(resultadoCotizacion.SOLICITUD.FCH_INICIO_VIGENCIA).ToString("dd/MM/yyyy");
                infoCompara.FechaFin = ConvertirFecha(resultadoCotizacion.SOLICITUD.FCH_FIN_VIGENCIA).ToString("dd/MM/yyyy");

                //foreach (var paquete in resultadoCotizacion.PAQUETES)
                //{

                //foreach (var primasResultado in paquete.TOTALES)
                //{
                //    infoCompara.PrimaNeta = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.primaNeta);
                //    infoCompara.PrimaTotal = QuitaCaracteres(primasResultado.resultadoTotal.importeAcumuladoRecibos?.ToString());
                //    infoCompara.Impuesto = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.iva);
                //    infoCompara.Recargo = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.recargos);
                //    infoCompara.Derecho = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.derechosPol);
                //    string fechaInicio = resultadoCotizacion.poliza.fechaInicioVigencia;
                //    conversionFechaInicio = ConvertirFecha(fechaInicio);
                //    string fechaFin = resultadoCotizacion.poliza.fechaFinVigencia;
                //    conversionFechaFin = ConvertirFecha(fechaFin);
                //    infoCompara.PrimerPago = QuitaCaracteres(primasResultado.resultadoTotal.importePrimerRecibo.ToString());
                //    infoCompara.SegundoPago = QuitaCaracteres(primasResultado.resultadoTotal.importeSucesivos.ToString());

                //    infoCompara.NumeroDePagos = NumeroPagos(Convert.ToDecimal(infoCompara.PrimaTotal)
                //        , Convert.ToDecimal(infoCompara.PrimerPago)
                //        , Convert.ToDecimal(infoCompara.SegundoPago)
                //        , numeroRecibos);

                //    infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;
                //}
                //}
                //infoCompara.FechaInicio = conversionFechaInicio.ToString("dd/MM/yyyy");
                //infoCompara.FechaFin = conversionFechaFin.ToString("dd/MM/yyyy");
                infoCompara.Año = xmlCotizacionSeleccionada.VEHICULO.MODELO.ToString();
            }
            catch (Exception)
            {
                throw;
            }
            return infoCompara;
        }

        public Comparar LeeXmlRespuesta(string XmlResultado, List<LocktonModel.db.PaqueteDetalle> coberturas, int IdTipoPaquete, string xmlEnvio, Convenio convenioCotiza, int numeroRecibos, int tipoVehiculo, int idPaquteConvenio)
        {
            Comparar infoCompara = new Comparar();

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            xmlCotizacionSeleccionada.LoadXml(xmlEnvio);
            try
            {
                XMLEntity.Cotizacion.GNPPreferente.Respuestas.COTIZACION resultadoCotizacion = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Respuestas.COTIZACION>(XmlResultado);
                XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION solicitudCotizacion = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION>(xmlEnvio);

                infoCompara.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                infoCompara.Aseguradora = "GNP";
                infoCompara.Cobertura = IdTipoPaquete.ToString();
                infoCompara.XmlEmision = xmlEnvio;
                infoCompara.XmlRespuesta = XmlResultado;
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                DateTime conversionFechaInicio = DateTime.Now;
                DateTime conversionFechaFin = DateTime.Now;
                var tipoDatos = db.CatTipoDatoDeducible.ToList();
                List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, tipoVehiculo);
                foreach (var paquete in resultadoCotizacion.PAQUETES)
                {

                    infoCompara.Coberturas = new List<Coberturas>();
                    foreach (COTIZACIONPAQUETECOBERTURA cobertura in paquete.COBERTURAS)
                    {
                        Coberturas _coberturaPaquete = coberturasPaquete.FirstOrDefault(a => a.Codigo.Trim() == cobertura.CVE_COBERTURA.Trim());
                        if (_coberturaPaquete != null)
                        {
                            var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == _coberturaPaquete.IdTipoDatoDeducible);
                            Coberturas cotCob = new Coberturas();
                            cotCob.Cobertura = QuitaCaracteres(cobertura.NOMBRE.ToString());
                            cotCob.SumaAsegurada = QuitaCaracteres(cobertura.SUMA_ASEGURADA.ToString());
                            cotCob.Nombre = cobertura.NOMBRE.Trim();
                            bool tieneDeducible = !string.IsNullOrEmpty(cobertura.DEDUCIBLE) && !cobertura.DEDUCIBLE.ToLower().Equals("no aplica");
                            if (tieneDeducible)
                            {
                                cotCob.Deducible = QuitaCaracteresCoberturas(QuitaCaracteres(cobertura.DEDUCIBLE));
                                cotCob.IdTipoDatoDeducible = _coberturaPaquete.IdTipoDatoDeducible;
                                cotCob.TipoDato = tipoDato.Nombre;
                            }
                            else
                            { cotCob.Deducible = "0"; }
                            cotCob.Codigo = _coberturaPaquete.Codigo;
                            infoCompara.Coberturas.Add(cotCob);
                        }
                    }

                    ColocaPrimasCotizadas(infoCompara, paquete.TOTALES);

                    ///////infoCompara.CesionComision = Convert.ToDouble(QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.cesionComision));
                    string fechaInicio = resultadoCotizacion.SOLICITUD.FCH_INICIO_VIGENCIA;
                    conversionFechaInicio = ConvertirFecha(fechaInicio);
                    string fechaFin = resultadoCotizacion.SOLICITUD.FCH_FIN_VIGENCIA;
                    conversionFechaFin = ConvertirFecha(fechaFin);
                    infoCompara.PrimaAnualizada = QuitaCaracteres(Utilidades.Utilidades.CalculaPrimaAnualizada(conversionFechaInicio, conversionFechaFin, infoCompara.PrimaNeta, infoCompara.Derecho, infoCompara.CesionComision));

                    if (paquete.TOTALES.TOTAL_PRIMA.CVE_PERIODICIDAD != "A")
                    {
                        infoCompara.NumeroDePagos = NumeroPagos(Convert.ToDecimal(infoCompara.PrimaTotal)
                            , Convert.ToDecimal(infoCompara.PrimerPago)
                            , Convert.ToDecimal(string.IsNullOrEmpty(infoCompara.SegundoPago) ? "0" : infoCompara.SegundoPago)
                            , numeroRecibos);
                    }
                }
                infoCompara.FechaInicio = conversionFechaInicio.ToString("dd/MM/yyyy");
                infoCompara.FechaFin = conversionFechaFin.ToString("dd/MM/yyyy");
                infoCompara.Año = solicitudCotizacion.VEHICULO.MODELO.ToString();
            }
            catch (Exception)
            {
                throw;
            }
            return infoCompara;
        }

        private int NumeroPagos(decimal primaTotal, decimal primerPago, decimal segundoPago, int mesesMaximos)
        {
            var numeropagos = 0;
            if (segundoPago == 0)
                numeropagos = 1;
            else
            {
                decimal faltante = primaTotal - primerPago;
                decimal pagos = 0;
                for (int i = 1; i <= mesesMaximos; i++)
                {
                    pagos += segundoPago;
                    if (Math.Round(pagos, 0) == Math.Round(faltante, 0))
                    {
                        numeropagos = i + 1;
                        break;
                    }
                }
            }

            return numeropagos;
        }

        private DateTime ConvertirFecha(string fecha)
        {
            return new DateTime(Convert.ToInt32(fecha.Substring(0, 4)), Convert.ToInt32(fecha.Substring(4, 2)), Convert.ToInt32(fecha.Substring(6, 2)));
        }

        public string QuitarAcentos(string cadenaAcentuada)
        {
            byte[] tempBytes;
            tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(cadenaAcentuada);
            string asciiStr = System.Text.Encoding.UTF8.GetString(tempBytes);
            return asciiStr.Trim();
        }


        //public string GetStringFromXML<T>(T obj)
        //{
        //    return ToXMLString(obj);
        //}

        public string ReimprimeReciboPoliza(string NumeroPoliza)
        {




            SqlParameter sqlPoliza = new SqlParameter("@Poliza", NumeroPoliza);
            var detallePoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", sqlPoliza).FirstOrDefault();
            var idGerencia = detallePoliza.IDGerencia.ToString();
            Empresa empresa = db.Empresa.FirstOrDefault(x => x.IdGerenciaCORE == idGerencia && x.Estatus == 1);
            Convenio convenio = db.Convenio.FirstOrDefault(x => x.IdEmpresa.Equals(empresa.Id) && x.IdAseguradora.Equals(2) && x.Estatus.Equals(1));

            var url = "";

            ReimprimeReciboPolizaPreferente(NumeroPoliza, convenio.CodigoIntermediario, ref url);

            return url;


        }


        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            bool UrlDisponible = false;
            NumeroPoliza = NumeroPoliza.TrimStart('0');
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"Repositorio\Documentos\GNP\" + NumeroPoliza + ".pdf";
            bool Exists = false;
            if (!Exists)
            {
                Poliza poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == NumeroPoliza);
                //https://api.service.gnp.com.mx/autos/wsp/impresion/buscarPoliza
                var url = "";

                if (poliza == null)
                {
                    List<string> resultCore = new List<string>();

                    if (ReimprimePolizaPreferente(NumeroPoliza, ref url))
                    {

                        Exists = File.Exists(filePath);

                        resultCore.Add(url);

                        return resultCore;
                    }
                    else
                        return resultCore;

                }
                else
                {

                    List<string> result = new List<string>();

                    if (ReimprimePolizaPreferente(NumeroPoliza, ref url))
                    {
                        Exists = File.Exists(filePath);
                        result.Add(url);
                        result.Add(string.IsNullOrEmpty(poliza.UrlPDFRecibos) ? "" : poliza.UrlPDFRecibos);

                        return result;
                    }
                    else
                        return result;
                }

            }
            else
            {
                List<string> result = new List<string>();
                result.Add(filePath);
                return result;
            }
        }

        private bool ReimprimePolizaPreferente(string numeroPoliza, ref string url)
        {
            IMPRESION_POLIZA impresion = ConstruyeObjetoImpresionPoliza(numeroPoliza);

            var response = EnviaSolicitudImpresionPoliza(impresion);

            string xmlResponse = response.Content.ReadAsStringAsync().Result.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");

            if (!response.IsSuccessStatusCode)
            {
                log.Error("Re-impresión de póliza - error GNP: " + xmlResponse.Replace("\n", "").Replace("\r", ""));

                return false;
            }

            return ObtieneRutaGuardadoPDFPoliza(xmlResponse, numeroPoliza, ref url);
        }

        private bool ReimprimeReciboPolizaPreferente(string numeroPoliza, string intermediario, ref string url)
        {
            var success = false;
            try
            {
                var impresion = ConstruyeObjetoImpresionReciboPoliza(numeroPoliza, intermediario);

                var response = EnviaSolicitudImpresionRecibos(impresion);

                //var documentGNP = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Respuestas.DOCUMENTOS>(response);

                if (response.Contains("URL_PDF"))
                {
                    success = true;
                    url = response.Substring(response.LastIndexOf("<URL_PDF>"));

                    if (url.Contains("</DOCUMENTOS>"))
                        url = url.Replace("</DOCUMENTOS>", "");

                    if (url.Contains("</DOCUMENTO>"))
                        url = url.Replace("</DOCUMENTO>", "");

                    var doc =XDocument.Parse(url);

                    url = doc.XPathSelectElement("URL_PDF").Value;
                }
                else
                    success = false; 

                //var xd = XDocument.Parse(response);


                //url = documentGNP.Documento.URL_PDF;

               
            }
            catch(Exception ex)
            {
                url = "";
            }

            return success;
        }

        private bool ObtieneRutaGuardadoPDFPoliza(string xmlResponse, string numeroPoliza, ref string url)
        {
            try
            {
                LocktonServicios.XMLEntity.Cotizacion.GNPPreferente.Respuestas.RESULTADO pdfResponse = Utilidades.Utilidades.GetXmlFromString<RESULTADO>(xmlResponse.Replace("<BUSCADOCUMENTO>", "").Replace("</BUSCADOCUMENTO>", ""));
                var webClient = new WebClient();
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"Repositorio\Documentos\GNP\" + numeroPoliza + ".pdf";
                url = pdfResponse.URL_DOCUMENTO;
                byte[] fileData = webClient.DownloadData(pdfResponse.URL_DOCUMENTO);
                System.IO.File.WriteAllBytes(path, fileData);
            }
            catch (Exception ex)
            {
                log.Error("Re-impresión de póliza - error GNP: " + ex.Message);
                return false;
            }
            return true;
        }

        private IMPRESION_POLIZA ConstruyeObjetoImpresionPoliza(string numeroPoliza)
        {
            return new IMPRESION_POLIZA
            {
                USUARIO = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_Usuario_WSPreferente")).Valor,
                PASSWORD = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_Contrasena_WSPreferente")).Valor,
                NUM_POLIZA = string.Format("00000{0}", numeroPoliza),
                EXTENSION_ARCHIVO = "PDF",
                NUM_VERSION = "0"
            };
        }

        private ImpresionRecibo ConstruyeObjetoImpresionReciboPoliza(string numeroPoliza, string intermediario)
        {
            return new ImpresionRecibo
            {
                USUARIO = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_Usuario_WSPreferente")).Valor,
                PASSWORD = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_Contrasena_WSPreferente")).Valor,
                POLIZA = numeroPoliza.PadLeft(14, '0'),
                TIPO_DOCUMENTO = "R",
                FORMATO = "P",
                INTERMEDIARIO = intermediario
            };
        }

        public static string WebServiceImpresion(string url, string action, string numeroPoliza, string user, string pwd, string version, string tipoAttachment)
        {



            XmlDocument soapEnvelopeXml = CreateSoapEnvelope(user, pwd, numeroPoliza, version, tipoAttachment);
            HttpWebRequest webRequest = CreateWebRequest(url, action);
            InsertSoapEnvelopeIntoWebRequest(soapEnvelopeXml, webRequest);

            IAsyncResult asyncResult = webRequest.BeginGetResponse(null, null);

            // suspend this thread until call is complete. You might want to
            // do something usefull here like update your UI.
            asyncResult.AsyncWaitHandle.WaitOne();

            string soapResult;
            using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.EndGetResponse(asyncResult))
            {
                soapResult = readMultipart(webResponse, numeroPoliza).Result;
            }
            return soapResult;
        }

        async static Task<string> readMultipart(HttpWebResponse httpResponse, string numeroPoliza)
        {
            var content = new StreamContent(httpResponse.GetResponseStream());
            content.Headers.Add("Content-Type", httpResponse.ContentType);

            //byte[] fileData;

            //var stream = httpResponse.GetResponseStream();
            //using (var memoryStream = new MemoryStream())
            //{
            //    await stream.CopyToAsync(memoryStream);
            //    fileData= memoryStream.ToArray();
            //}

            MultipartMemoryStreamProvider multipart = new MultipartMemoryStreamProvider();
            Task.Factory.StartNew(() => multipart = content.ReadAsMultipartAsync().Result,
               CancellationToken.None,
               TaskCreationOptions.LongRunning, // guarantees separate thread
               TaskScheduler.Default)
               .Wait();

            string json = await multipart.Contents[0].ReadAsStringAsync();

            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"Repositorio\Documentos\GNP\" + numeroPoliza + ".pdf";
            byte[] fileData = multipart.Contents[1].ReadAsByteArrayAsync().Result;
            System.IO.File.WriteAllBytes(path, fileData);
            return path;
        }

        private static HttpWebRequest CreateWebRequest(string url, string action)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Headers.Add("SOAPAction", action);
            webRequest.ContentType = "text/xml;charset=\"utf-8\"";
            webRequest.Accept = "text/xml";
            webRequest.Method = "POST";
            return webRequest;
        }

        private static XmlDocument CreateSoapEnvelope(string user, string pwd, string numeroPoliza, string version, string tipoAttachment)
        {
            XmlDocument soapEnvelopeDocument = new XmlDocument();
            soapEnvelopeDocument.LoadXml(
            string.Format(@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:lay=""http://layout.ws.gnp.com.mx"">
                           <soapenv:Header/>
                           <soapenv:Body>
                              <lay:RequestImpresion>
                                 <usuario>{0}</usuario>
                                 <password>{1}</password>
                                 <poliza>{2}</poliza>
                                 <version>{3}</version>
                                 <tipoAttachment>{4}</tipoAttachment>
                              </lay:RequestImpresion>
                           </soapenv:Body>
                        </soapenv:Envelope>", user, pwd, string.Format("00000{0}", numeroPoliza), version, tipoAttachment));
            return soapEnvelopeDocument;
        }

        private static void InsertSoapEnvelopeIntoWebRequest(XmlDocument soapEnvelopeXml, HttpWebRequest webRequest)
        {
            using (Stream stream = webRequest.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }
        }

        //private string ToXMLString<T>(T toSerialize)
        //{
        //    MemoryStream memoryStream = new MemoryStream();
        //    XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
        //    ns.Add(String.Empty, String.Empty);
        //    XmlSerializer xs = new XmlSerializer(typeof(T));
        //    XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Default);
        //    xs.Serialize(xmlTextWriter, toSerialize, ns);
        //    memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //    string XmlizedString = UTF8ByteArrayToString(memoryStream.ToArray());
        //    XmlizedString = XmlizedString.Replace("<?xml version=\"1.0\" encoding=\"Windows-1252\"?>", "");
        //    xmlTextWriter.Close();
        //    memoryStream.Close();
        //    return XmlizedString;
        //}

        //private String UTF8ByteArrayToString(Byte[] characters)
        //{
        //    UTF8Encoding encoding = new UTF8Encoding();
        //    String constructedString = encoding.GetString(characters);
        //    return (constructedString);
        //}

        private HttpResponseMessage EnviaSolicitudImpresionPoliza(IMPRESION_POLIZA impPol)
        {
            Uri url = new Uri(db.CatParametro.FirstOrDefault(x => x.Clave.Equals("UrlGNPImpPDFPref")).Valor);
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Accept.Add(
             new MediaTypeWithQualityHeaderValue("application/xml"));

            HttpContent content = new StringContent(Utilidades.Utilidades.GetStringFromXML<IMPRESION_POLIZA>(impPol).Replace("Ó", "O"), UTF8Encoding.UTF8, "application/xml");
            return client.PostAsync(url, content).Result;

        }

        private string EnviaSolicitudImpresionRecibos(ImpresionRecibo impRecibo)
        {
            Uri url = new Uri(db.CatParametro.FirstOrDefault(x => x.Clave.Equals("GNP_URLRECIBOS_WSPreferente")).Valor);

            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            var body = Utilidades.Utilidades.GetStringFromXML<ImpresionRecibo>(impRecibo).Replace("Ó", "O");

            body = body.Replace("ImpresionRecibo", "SOLICITUD");
            request.AddHeader("Content-Type", "application/xml");
            request.AddParameter("application/xml", body, ParameterType.RequestBody);

            var response = client.Execute(request);

            log.Info($"GNP PREFERENTE - IMPRESION RECIBO - SOLICITUD: {body}");

            log.Info($"GNP PREFERENTE - IMPRESION RECIBO - RESPUETA: {response.Content}");

            return response.Content;

        }

        #endregion



        #region Metodos de Cotizacion
        private HttpResponseMessage EnviaSolicitudCotizacion(XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION reqCotAutos)
        {

            Uri url = new Uri(db.CatParametro.FirstOrDefault(x => x.Clave.Equals("UrlGNPCotizaPref")).Valor);
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Accept.Add(
             new MediaTypeWithQualityHeaderValue("application/xml"));

            HttpContent content = new StringContent(Utilidades.Utilidades.GetStringFromXML<XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION>(reqCotAutos), UTF8Encoding.UTF8, "application/xml");
            return client.PostAsync(url, content).Result;
        }

        private CoberturaIn[] ObtieneClavesCoberturas(List<Coberturas> coberturasPaquete, int id, int idConvenio, string anio, int idCatRamoVehiculo)
        {
            var listaCoberturas = new List<CoberturaIn>();
            var coberturaUtils = new Utilidades.CoberturasUtils();

            foreach (Coberturas paquete in coberturasPaquete)
            {
                bool aplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(idConvenio, paquete.IdCobertura.ToString(), anio, paquete.IdCatRamo);
                bool EsCondEspecial = coberturaUtils.EsCondicionEsp(id, paquete.IdCobertura.ToString(), idCatRamoVehiculo);

                if ((EsCondEspecial && aplicaCobertura) || !EsCondEspecial)
                {
                    CoberturaIn coberAdd = new CoberturaIn();
                    coberAdd.id = paquete.Codigo.PadLeft(10, '0'); ;
                    listaCoberturas.Add(coberAdd);
                }
            }
            return listaCoberturas.ToArray();
        }

        private _Descripciones ConsultaCatalogoHomologado(string clave)
        {
            ConsultaCatalogoHomologado.ObjetoRespuestaBD _descripcion = new ConsultaCatalogoHomologado.ConsultaCatalogoHomologadoClient().NCHConsultaDetalleVehiculo("GNP", clave);
            return JsonConvert.DeserializeObject<_Descripciones>(_descripcion.RespuestaJSON);
        }

        private string ObtieneCaratulaPorSP(int? convenioId, int idTipoPaquete, int formaDePago, int id, string anio, int tipoVehiculo)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@IdConvenio",convenioId)
                    ,new SqlParameter("@IdPaquete",idTipoPaquete)
                    ,new SqlParameter("@IdPeriodicidad",formaDePago)
                    ,new SqlParameter("@IdFormaPago",id)
                    ,new SqlParameter("@Year",anio)
                    ,new SqlParameter("@ClaveTipoVehiculo",tipoVehiculo)
                };

            return db.Database.SqlQuery<string>("Execute sp_CaratulasGNP_Obtener @IdConvenio, @IdPaquete, @IdPeriodicidad, @IdFormaPago, @Year, @ClaveTipoVehiculo", parameters.ToArray()).SingleOrDefault();
        }

        private COTIZACIONCONDUCTOR ConstruyeObjetoConductorCotizacion(DetalleUsuario detalleUsuario, string genero, string edad, DateTime FechaNac, string codigoPostal)
        {
            return new COTIZACIONCONDUCTOR()
            {

                //FCH_NACIMIENTO = detalleUsuario.FECHANACIMIENTO.ToString("yyyyMMdd"),
                FCH_NACIMIENTO = FechaNac.ToString("yyyyMMdd"),//DateTime.Now.AddYears(-int.Parse(edad)).ToString("yyyyMMdd"),
                CODIGO_POSTAL = codigoPostal ?? detalleUsuario.CodigoPostal,
                SEXO = genero.ToLower().Equals("masculino") ? "M" : "F",
                EDAD = edad
            };
        }

        private COTIZACIONCONTRATANTE ConstruyeObjetoContratanteCotizacion(string codigoPostal, bool emisionPersonaMoral)
        {
            return new COTIZACIONCONTRATANTE()
            {
                TIPO_PERSONA = emisionPersonaMoral ? "M" : "F",
                CODIGO_POSTAL = codigoPostal
            };
        }

        private COTIZACIONVEHICULO ConstruyeObjetoVehiculoCotizacion(_Descripciones descripciones, descripciones cotDesAuto, string modelo, string codigoPostal1, string codigoPostal2, bool aplicaValorFactura = false, string valorFactura = "", bool aplicaValorConvenido = false)
        {
            var vehiculo = new COTIZACIONVEHICULO()
            {
                SUB_RAMO = "01",
                USO = "01",
                //ALTO_RIESGO = "N",
                //ESTADO_CIRCULACION = ObtenerClaveEstado(string.IsNullOrEmpty(codigoPostal1) ? codigoPostal2 : codigoPostal1),
                TIPO_VEHICULO = cotDesAuto.clave.Substring(0, 3),
                MODELO = modelo,
                //DESCRIPCION_FACTURA_VEHICULO = cotDesAuto.Descripcion.Trim(),
                VALOR_CONVENIDO = aplicaValorFactura ? valorFactura : "0",
                FORMA_INDEMNIZACION = aplicaValorFactura ? "02" : "01",
                //TIPO_CARGA = "",
                //REGISTRO_FEDERAL = "",
                //SERIE = "",
                VALOR_FACTURA = aplicaValorFactura ? valorFactura : "",
                //MOTOR = "",
                //PLACAS = "",
                VALOR_REFERENCIA = ""
            };
            //if (esMoto)
            //{
            //    vehiculo.VALOR_CONVENIDO = valorFactura;
            //    vehiculo.VALOR_FACTURA = valorFactura;
            //    vehiculo.FORMA_INDEMNIZACION = "05";
            //}

            vehiculo.ARMADORA = cotDesAuto.clave.Substring(vehiculo.TIPO_VEHICULO.ToString().Length, 2);
            vehiculo.CARROCERIA = cotDesAuto.clave.Substring(vehiculo.TIPO_VEHICULO.ToString().Length + vehiculo.ARMADORA.ToString().Length, 2);
            vehiculo.VERSION = cotDesAuto.clave.Substring((vehiculo.TIPO_VEHICULO.ToString().Length + vehiculo.ARMADORA.ToString().Length + vehiculo.CARROCERIA.ToString().Length), 2);

            return vehiculo;

        }

        private void ColocaPrimasCotizadas(Comparar infoCompara, COTIZACIONPAQUETETOTALES resultadosFormaPago)
        {
            foreach (var primasResultado in resultadosFormaPago.TOTAL_PRIMA.CONCEPTO_ECONOMICO)
            {
                switch (primasResultado.NOMBRE)
                {
                    case "PRIMA_NETA":
                        infoCompara.PrimaNeta = QuitaCaracteres(primasResultado.MONTO.ToString());
                        break;
                    case "TOTAL_PAGAR":
                        infoCompara.PrimaTotal = QuitaCaracteres(primasResultado.MONTO.ToString());
                        break;
                    case "IVA":
                        infoCompara.Impuesto = QuitaCaracteres(primasResultado.MONTO.ToString());
                        break;
                    case "RECARGO_DESCUENTO":
                        infoCompara.Recargo = QuitaCaracteres(primasResultado.MONTO.ToString());
                        break;
                    case "RECARGO_FRACCIONAMIENTO":
                        infoCompara.Recargo = QuitaCaracteres(primasResultado.MONTO.ToString());
                        break;
                    case "DERECHOS_POLIZA":
                        infoCompara.Derecho = QuitaCaracteres(primasResultado.MONTO.ToString());
                        break;
                    case "PRIMER_RECIBO":
                        infoCompara.PrimerPago = QuitaCaracteres(primasResultado.MONTO.ToString());
                        break;
                    case "RECIBO_SUBSECUENTE":
                        if (resultadosFormaPago.TOTAL_PRIMA.CVE_PERIODICIDAD != "A")
                        {
                            infoCompara.SegundoPago = QuitaCaracteres(primasResultado.MONTO.ToString());
                            infoCompara.SegundoPago = infoCompara.SegundoPago == "0.0" ? "" : infoCompara.SegundoPago;
                        }
                        break;
                    case "NUM_RECIBOS_SUBS":
                        if (resultadosFormaPago.TOTAL_PRIMA.CVE_PERIODICIDAD != "A")
                        {
                            infoCompara.NumeroDePagos = Convert.ToInt32(primasResultado.MONTO);
                        }
                        break;

                }
            }
            infoCompara.PrimaNeta = !string.IsNullOrEmpty(infoCompara.Recargo) ? (Convert.ToDecimal(infoCompara.PrimaNeta) + Convert.ToDecimal(infoCompara.Recargo)).ToString() : infoCompara.PrimaNeta;
        }

        private List<Coberturas> ObtieneCoberturasCotizadas(COTIZACIONPAQUETECOBERTURA[] coberturas, Comparar infoCompara, int coberturaId, List<Coberturas> coberturasPaquete)
        {
            var listaCoberturas = new List<Coberturas>();
            var tipoDatos = db.CatTipoDatoDeducible.ToList();

            foreach (COTIZACIONPAQUETECOBERTURA cobertura in coberturas)
            {
                infoCompara.Cobertura = coberturaId.ToString();
                Coberturas _coberturaPaquete = coberturasPaquete.FirstOrDefault(a => a.Codigo.Trim() == cobertura.CVE_COBERTURA.Trim());
                if (_coberturaPaquete != null)
                {
                    var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == _coberturaPaquete.IdTipoDatoDeducible);

                    Coberturas cotCob = new Coberturas();

                    cotCob.Cobertura = QuitaCaracteres(cobertura.NOMBRE.ToString());
                    cotCob.SumaAsegurada = QuitaCaracteres(cobertura.SUMA_ASEGURADA.ToString());
                    cotCob.Nombre = _coberturaPaquete.Nombre.Trim();
                    bool tieneDeducible = !string.IsNullOrEmpty(cobertura.DEDUCIBLE);
                    if (tieneDeducible)
                    {
                        cotCob.Deducible = QuitaCaracteresCoberturas(QuitaCaracteres(cobertura.DEDUCIBLE));
                        cotCob.IdTipoDatoDeducible = _coberturaPaquete.IdTipoDatoDeducible;
                        cotCob.TipoDato = tipoDato.Nombre;
                    }
                    else
                    { cotCob.Deducible = "0"; }

                    cotCob.Codigo = _coberturaPaquete.Codigo;
                    listaCoberturas.Add(cotCob);
                }
            }
            return listaCoberturas;
        }
        #endregion



        #region Metodos de Emision
        private HttpResponseMessage EnviaSolicitudEmision(XMLEntity.Cotizacion.GNPPreferente.Solicitudes.EMISION reqEmiAuto)
        {
            Uri url = new Uri(db.CatParametro.FirstOrDefault(x => x.Clave.Equals("UrlGNPEmitePref")).Valor);
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Accept.Add(
             new MediaTypeWithQualityHeaderValue("application/xml"));

            HttpContent content = new StringContent(Utilidades.Utilidades.GetStringFromXML<XMLEntity.Cotizacion.GNPPreferente.Solicitudes.EMISION>(reqEmiAuto), UTF8Encoding.UTF8, "application/xml");
            return client.PostAsync(url, content).Result;
        }

        private PolizaDetalle ConstruyeObjetoPolizaDetalle(CotizacionDetalle cotizacionDetalle, int medioPagoId, int idCatPeriodicidadFormaPago, string xmlResponse, string xmlizedString, InformacionEmision infoEmision)
        {
            return new PolizaDetalle()
            {
                Inciso = "1",
                RenovacionAutomatica = infoEmision.RenovacionAutomatica, // CAT Renovación automática: persiste la elección del usuario para GNP Preferente.
                FechaDecisionRenovacionAutomaticaUtc = infoEmision.FechaDecisionRenovacionAutomaticaUtc, // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                Deducible = 0,
                Comision = 0,
                FactorIva = 16, //Ponerlo de manera dinamica
                MigraOPERA = false,
                UrlPDFPolizaOPERA = "",
                PolizaOPERA = 0,
                OTOpera = 0,
                EndosoOPERA = 0,
                IdCotizacionAuto = infoEmision.CotizacionAutoGuardar.Id,
                IdCotizacionDetalle = cotizacionDetalle.Id,
                IdCatRamoVehiculo = cotizacionDetalle.IdVehiculo,// int.Parse(infoEmision.Convenio.RamoVehiculo.Split(',')[0]),
                BeneficiarioPreferente = infoEmision.BeneficiarioPreferente,
                IdCatModalidadFormaPago = medioPagoId,// db.CatModalidadFormaPago.Where(x => x.Clave.Equals(medioPago)).FirstOrDefault().Id,
                IdCatPeriodicidadFormaPago = idCatPeriodicidadFormaPago,// db.CatPeriodicidadFormaPago.Where(x => x.Clave.Equals(formaPago)).FirstOrDefault().Id,
                XMLRecepcion = xmlResponse,
                XMLSolicitud = xmlizedString,
                IdDireccion = infoEmision.Empresa.Direccion.Id
            };
        }

        private Poliza ConstruyeObjetoPoliza(string numeroPoliza, DateTime finVigencia, DateTime inicioVigencia, decimal primaNeta, decimal primaTotal, int idCatTipoPaquete, InformacionEmision infoEmision)
        {
            return new Poliza()
            {
                NumeroPoliza = numeroPoliza,
                FinVigencia = finVigencia,
                InicioVigencia = inicioVigencia,

                PrimaNeta = primaNeta,
                PrimaNetaAnualizada = primaNeta,
                PrimaTotal = primaTotal,
                PrimaTotalAnualizada = primaTotal,

                Motor = infoEmision.NumeroMotor,
                Serie = infoEmision.NumeroSerie,
                Placas = infoEmision.Placas,
                FechaEmision = DateTime.Now,
                ConductorHabitual = infoEmision.ObtieneNombreCompleto(),
                UrlPDFPoliza = "",
                UrlPDFRecibos = "",
                Estatus = 1,
                IdUsuario = infoEmision.DetalleUsuario.Id,
                IdConvenio = infoEmision.Convenio.Id,
                IdParentesco = infoEmision.Parentesco == null ? 19 : infoEmision.Parentesco.Id,
                IdTipoCobertura = idCatTipoPaquete,
                ClaveAgente = infoEmision.Convenio.CodigoIntermediario,
                Acepto_AvisoPrivacidad_Aseguradora = true,
                Acepto_DescuentoPoliza = true
            };
        }

        private List<Recibo> ObtieneObjetoRecibosEmision(EMISIONRESULTADO_MONTO_PARCIALIDAD recibos, DateTime inicioVigencia, DateTime finVigencia, decimal primaTotal, decimal primaNeta, decimal derechos, decimal recargo, decimal impuestos, bool obtenerComision)
        {
            var recibosGenerados = new List<Recibo>();
            int recibosSubsecuentes = Convert.ToInt32(recibos.NUM_PARCIALIDADES);
            int numeroRecibo = 1;
            if (recibosSubsecuentes > 1)
            {
                try
                {
                    for (int i = 0; i < Convert.ToInt32(recibos.NUM_PARCIALIDADES); i++)
                    {

                        Recibo reciboBusqueda = new Recibo();

                        Recibo reciboSave = new Recibo();
                        reciboSave.InicioVigencia = DateTime.ParseExact(recibos.FCH_PROXIMO_PAGO, "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(i - 1);
                        reciboSave.FinVigencia = DateTime.ParseExact(recibos.FCH_PROXIMO_PAGO, "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(i);
                        reciboSave.Numero = numeroRecibo;
                        reciboSave.NoAsegurado = "1";
                        reciboSave.PrimaTotal = decimal.Parse(recibos.MTO_PARCIALIDADES.ToString(), CultureInfo.InvariantCulture);
                        reciboSave.PrimaNeta = decimal.Parse(recibos.MTO_PARCIALIDADES.ToString(), CultureInfo.InvariantCulture);
                        reciboSave.Comision = 0;
                        reciboSave.Impuesto = impuestos;

                        recibosGenerados.Add(reciboSave);
                        numeroRecibo++;


                    }
                }
                catch (Exception) { }
            }
            else
            {
                Recibo reciboSave = new Recibo();
                reciboSave.InicioVigencia = inicioVigencia;
                reciboSave.FinVigencia = finVigencia;
                reciboSave.Numero = 1;
                reciboSave.NoAsegurado = "1";
                reciboSave.PrimaNeta = primaNeta;
                reciboSave.PrimaTotal = primaTotal;
                reciboSave.Derecho = derechos;
                reciboSave.Recargo = recargo;
                reciboSave.Comision = 0;
                reciboSave.Impuesto = impuestos;
                recibosGenerados.Add(reciboSave);
            }
            return recibosGenerados;
        }
        private List<Recibo> ObtieneObjetoRecibosEmision(int NUM_RECIBOS_SUB, int NUM_PAGOS, decimal IMP_RECIBO_SUBSECUENTE, decimal IMP_PRIMER_RECIBO, decimal primaTotal, DateTime FechaInicioVigencia, DateTime FechaFinVigencia, decimal derechos, decimal recargo, decimal impuestos, decimal primaNeta, Convenio convenio, decimal Recargo_Pago_Fracc, bool obtenerComision)
        {
            var recibosGenerados = new List<Recibo>();
            int numeroRecibo = 1;
            impuestos = (impuestos == 0) ? 0 : impuestos / NUM_PAGOS;
            derechos = (convenio.DerechosPrimerRecibo) ? derechos : (derechos == 0) ? 0 : derechos / NUM_PAGOS;
            Recargo_Pago_Fracc = (Recargo_Pago_Fracc == 0) ? 0 : Recargo_Pago_Fracc / NUM_PAGOS;
            decimal SubTotal = Convert.ToDecimal(0.0);
            decimal IVA = Convert.ToDecimal(db.CatParametro.FirstOrDefault(x => x.Clave.Equals("IVA")).Valor);
            IVA = ((IVA / 100) + 1);
            if (NUM_RECIBOS_SUB > 1)
            {
                try
                {
                    for (int i = 0; i < Convert.ToInt32(NUM_PAGOS); i++)
                    {
                        Recibo reciboBusqueda = new Recibo();
                        Recibo reciboSave = new Recibo();
                        if (i == 0)
                        {
                            SubTotal = (IMP_RECIBO_SUBSECUENTE / IVA);
                            reciboSave.InicioVigencia = FechaInicioVigencia;
                            reciboSave.FinVigencia = FechaInicioVigencia;
                            reciboSave.Numero = numeroRecibo;
                            reciboSave.NoAsegurado = "1";
                            reciboSave.PrimaTotal = IMP_PRIMER_RECIBO;
                            reciboSave.PrimaNeta = SubTotal - derechos - Recargo_Pago_Fracc;
                            reciboSave.Derecho = derechos;
                            reciboSave.Comision = 0;
                            reciboSave.Recargo = Recargo_Pago_Fracc;
                            reciboSave.Impuesto = impuestos;
                        }
                        else
                        {
                            SubTotal = (IMP_RECIBO_SUBSECUENTE / IVA);
                            reciboSave.InicioVigencia = FechaInicioVigencia;
                            reciboSave.FinVigencia = FechaInicioVigencia;
                            reciboSave.Numero = numeroRecibo;
                            reciboSave.NoAsegurado = "1";
                            reciboSave.PrimaTotal = IMP_RECIBO_SUBSECUENTE;
                            reciboSave.PrimaNeta = (convenio.DerechosPrimerRecibo) ? SubTotal - Recargo_Pago_Fracc : SubTotal - derechos - Recargo_Pago_Fracc;
                            reciboSave.Derecho = (convenio.DerechosPrimerRecibo) ? 0 : derechos;
                            reciboSave.Recargo = Recargo_Pago_Fracc;
                            reciboSave.Comision = 0;
                            reciboSave.Impuesto = impuestos;
                        }

                        recibosGenerados.Add(reciboSave);
                        numeroRecibo++;


                    }
                }
                catch (Exception) { }
            }
            else
            {
                SubTotal = (IMP_RECIBO_SUBSECUENTE / IVA);
                Recibo reciboSave = new Recibo();
                reciboSave.InicioVigencia = FechaInicioVigencia;
                reciboSave.FinVigencia = FechaFinVigencia;
                reciboSave.Numero = 1;
                reciboSave.NoAsegurado = "1";
                reciboSave.PrimaNeta = SubTotal - derechos - Recargo_Pago_Fracc;
                reciboSave.PrimaTotal = primaTotal;
                reciboSave.Derecho = derechos;
                reciboSave.Recargo = Recargo_Pago_Fracc;
                reciboSave.Comision = 0;
                reciboSave.Impuesto = impuestos;
                recibosGenerados.Add(reciboSave);
            }
            return recibosGenerados;
        }
        private List<Recibo> ObtieneObjetoRecibosEmision(DateTime inicioVigencia, DateTime finVigencia, decimal primaTotal, decimal primaNeta, decimal derechos, decimal recargo, decimal impuestos, bool obtenerComision)
        {
            var recibosGenerados = new List<Recibo>();


            Recibo reciboSave = new Recibo();
            reciboSave.InicioVigencia = inicioVigencia;
            reciboSave.FinVigencia = finVigencia;
            reciboSave.Numero = 1;
            reciboSave.NoAsegurado = "1";
            reciboSave.PrimaNeta = primaNeta;
            reciboSave.PrimaTotal = primaTotal;
            reciboSave.Derecho = derechos;
            reciboSave.Recargo = recargo;
            reciboSave.Comision = 0;
            reciboSave.Impuesto = impuestos;
            recibosGenerados.Add(reciboSave);

            return recibosGenerados;
        }
        private Endoso ConstruyeObjetoEndosoAlta(List<Recibo> recibosGenerados)
        {
            return new Endoso()
            {
                IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id,
                Fecha = DateTime.Now,
                ValorAnterior = "Alta",
                ValorActual = "Contratación",
                Recibo = recibosGenerados
            };
        }

        private string ObtieneCadenaDatosAReemplazarXML(InformacionEmision infoEmision, Banco banco)
        {
            if (infoEmision.CotizacionAutoGuardar.MediodePago.Equals(0) || infoEmision.CotizacionAutoGuardar.MediodePago.Equals(1))
            {
                banco = new Banco();
                banco.codigoSegTarjeta = infoEmision.Tarjeta.Cvv;
                banco.tipo = "";
                banco.bancoEntidad = infoEmision.IdBanco.ToString().PadLeft(4, '0');
                banco.tipoCuentaTarjeta = infoEmision.Tarjeta.TipoTarjeta;
                banco.mes = infoEmision.Tarjeta.MesVencimiento;
                banco.anio = infoEmision.Tarjeta.AnioVencimiento.ToString() == "1900" ? infoEmision.IdAnio.ToString() : infoEmision.Tarjeta.AnioVencimiento.ToString();
                banco.numTarjeta = infoEmision.Tarjeta.NumeroTarjeta;
                banco.moneda = "MXP";
                banco.titular1 = infoEmision.Tarjeta.TitularTarjeta;
                banco.tipo = ObtieneClaveTipoCuentaBancaria(infoEmision.CotizacionAutoGuardar.MediodePago);
                banco.fechaCorte = "1";
            }
            return Utilidades.Utilidades.ToXMLString<Banco>(banco);
        }

        private List<string> ObtieneListaDatosAReemplazarXML(InformacionEmision infoEmision)
        {
            int medioPago = infoEmision.CotizacionAutoGuardar.MediodePago;
            var listaDatosReemplazo = new List<string>();
            if (medioPago.Equals(0) || medioPago.Equals(1))
            {
                listaDatosReemplazo.Add(infoEmision.Tarjeta.Cvv);
                listaDatosReemplazo.Add(infoEmision.IdBanco.ToString().PadLeft(4, '0'));
                listaDatosReemplazo.Add(infoEmision.Tarjeta.TipoTarjeta);
                listaDatosReemplazo.Add(infoEmision.Tarjeta.MesVencimiento);
                listaDatosReemplazo.Add(infoEmision.Tarjeta.AnioVencimiento.ToString() == "1900" ? infoEmision.IdAnio.ToString() : infoEmision.Tarjeta.AnioVencimiento.ToString());
                listaDatosReemplazo.Add(infoEmision.Tarjeta.NumeroTarjeta);
                listaDatosReemplazo.Add(infoEmision.Tarjeta.TitularTarjeta);
            }
            return listaDatosReemplazo;
        }

        private EMISIONCONDUCTOR ConstruyeObjetoAseguradoEmision(XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION xmlCotizacionSeleccionada, InformacionEmision infoEmision)
        {
            var asegurado = new EMISIONCONDUCTOR();

            //if (!string.IsNullOrEmpty(xmlCotizacionSeleccionada.SOLICITUD))
            //{
            //    asegurado.codigoCliente = xmlCotizacionSeleccionada.conductor.codigoCliente;
            //}
            //else
            //{
            //asegurado.codigoCliente = "";
            //asegurado.tipoDocumento = xmlCotizacionSeleccionada.conductor.tipoDocumento;
            //asegurado.numeroIdentificacion = xmlCotizacionSeleccionada.conductor.numeroIdentificacion;
            asegurado.EDAD_CONDUCTOR_HABITUAL = xmlCotizacionSeleccionada.CONDUCTOR.EDAD.ToString();
            asegurado.SEXO = string.IsNullOrEmpty(xmlCotizacionSeleccionada.CONDUCTOR.SEXO.ToString()) ? infoEmision.DetalleUsuario.GENERO.ToLower().Equals("masculino") ? "M" : "F" : xmlCotizacionSeleccionada.CONDUCTOR.SEXO.ToString();

            //asegurado.tipoPersona = "F";

            if (!infoEmision.ConductorHabitual && !string.IsNullOrEmpty(infoEmision.DatosUsuario.RFC))
            {
                asegurado.RFC = infoEmision.DatosUsuario.RFC;
                asegurado.APELLIDO_PATERNO = string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.ApellidoPaterno.Trim());
                asegurado.APELLIDO_MATERNO = string.IsNullOrEmpty(infoEmision.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.ApellidoMaterno.Trim());
                asegurado.NOMBRES = string.Format("{0} {1}", QuitarAcentos(infoEmision.PrimerNombre.Trim()), string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim()));
                string RFC = infoEmision.DatosUsuario.RFC.Substring(4, 6);
                asegurado.FCH_NACIMIENTO = DateTime.ParseExact(RFC.ToString(), "yyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString("yyyyMMdd");
            }
            else
            {

                asegurado.APELLIDO_PATERNO = string.IsNullOrEmpty(infoEmision.DetalleUsuario.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.ApellidoPaterno.Trim());
                asegurado.APELLIDO_MATERNO = string.IsNullOrEmpty(infoEmision.DetalleUsuario.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.ApellidoMaterno.Trim());
                asegurado.NOMBRES = string.Format("{0} {1}", QuitarAcentos(infoEmision.DetalleUsuario.Nombre.Trim()), (string.IsNullOrEmpty(infoEmision.DetalleUsuario.NombreDos) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.NombreDos.Trim())));
                asegurado.FCH_NACIMIENTO = infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("yyyyMMdd");
                asegurado.EDAD_CONDUCTOR_HABITUAL = Utilidades.Utilidades.CalculaEdad(infoEmision.DetalleUsuario.FECHANACIMIENTO);
                asegurado.RFC = infoEmision.DetalleUsuario.RFC == null ? Utilidades.Utilidades.CalcularRFC(asegurado.NOMBRES.ToString(), asegurado.APELLIDO_PATERNO.ToString(), asegurado.APELLIDO_MATERNO.ToString(), infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yy")) : infoEmision.DetalleUsuario.RFC;
            }
            //}
            return asegurado;
        }

        private EMISIONCONTRATANTE ConstruyeObjetoContratanteEmision(InformacionEmision infoEmision, XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION xmlCotizacionSeleccionada, XMLEntity.Cotizacion.GNPPreferente.Respuestas.COTIZACION xmlRespuestaCotizacion, string codigoPostal, LocktonModel.db.CodigoPostal catCodigoPostal)
        {
            var contratante = new EMISIONCONTRATANTE();
            List<Telefono> telefonos = new List<Telefono>();

            if (infoEmision.EmisionPersonaMoral)
            {

                infoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == infoEmision.PersonaMoral.Id);
                infoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == infoEmision.PersonaMoralRepresentanteLegal.Id);

                var catCodigoPostalPM = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == infoEmision.PersonaMoral.Direccion.CodigoPostal);

                contratante.TIPO_PERSONA = "M";
                contratante.RFC = infoEmision.PersonaMoral.RFC;
                contratante.RAZON_SOCIAL = infoEmision.PersonaMoral.RazonSocial;
                contratante.GIRO = ObtieneClaveGiroEmpresa(infoEmision.PersonaMoral.IdCatGiroBase);
                contratante.FCH_CONSTITUCION = infoEmision.PersonaMoral.FechaConstitucion?.ToString("yyyyMMdd");
                contratante.NACIONALIDAD = "MEX";
                contratante.PAIS_NACIMIENTO = "MEX";

                contratante.DIRECCION = new EMISIONCONTRATANTEDIRECCION();
                contratante.DIRECCION.CVE_TIPO_VIA = "CL";
                contratante.DIRECCION.CALLE = QuitarAcentos(infoEmision.PersonaMoral.Direccion.Calle);
                contratante.DIRECCION.NUMERO_EXTERIOR = infoEmision.PersonaMoral.Direccion.NumeroExt;
                contratante.DIRECCION.NUMERO_INTERIOR = infoEmision.PersonaMoral.Direccion.NumeroInt;
                contratante.DIRECCION.COLONIA = QuitarAcentos(catCodigoPostalPM.Asentamiento);
                contratante.DIRECCION.DELEGACION_MCPIO = catCodigoPostalPM.Ciudad;
                contratante.DIRECCION.ESTADO = catCodigoPostalPM.CatEstadosRepublica.Clave;
                contratante.DIRECCION.CODIGO_POSTAL = infoEmision.PersonaMoral.Direccion.CodigoPostal;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                contratante.DIRECCION.PAIS_DOMICILIO = "MEX";

                contratante.TELEFONOS = new EMISIONCONTRATANTETELEFONOS();
                contratante.TELEFONOS.TELEFONO = new EMISIONCONTRATANTETELEFONOSTELEFONO();
                contratante.TELEFONOS.TELEFONO.CVE_LADA = "52";
                contratante.TELEFONOS.TELEFONO.CVE_LADA_NACIONAL = infoEmision.PersonaMoralRepresentanteLegal.Telefono.Substring(0, 2);
                contratante.TELEFONOS.TELEFONO.NUMERO_TELEFONO = infoEmision.PersonaMoralRepresentanteLegal.Telefono.Substring(2);

                contratante.CORREOS = new EMISIONCONTRATANTECORREOS();
                contratante.CORREOS.CORREO = new EMISIONCONTRATANTECORREOSCORREO();
                contratante.CORREOS.CORREO.CORREO_ELECTRONICO = infoEmision.PersonaMoralRepresentanteLegal.Correo;


            }
            else
            {
                contratante.TIPO_PERSONA = "F"; //Fisica F - Moral M;
                                                //contratante.codigoCliente = xmlCotizacionSeleccionada.conductor.codigoCliente;
                contratante.ESTADO_CIVIL = "S";
                contratante.RFC =
                    string.IsNullOrEmpty(infoEmision.DatosUsuario.RFC) ?
                    Utilidades.Utilidades.CalcularRFC(
                        string.Format("{0} {1}", infoEmision.PrimerNombre.Trim(), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim()))),
                        infoEmision.ApellidoPaterno,
                        infoEmision.ApellidoMaterno,
                        infoEmision.FechaNacimiento.ToString("dd/MM/yy")
                        ) :
                        infoEmision.DatosUsuario.RFC;
                contratante.CORREOS = new EMISIONCONTRATANTECORREOS();
                contratante.CORREOS.CORREO = new EMISIONCONTRATANTECORREOSCORREO();
                contratante.CORREOS.CORREO.CORREO_ELECTRONICO = infoEmision.ConfirmaEmail;
                //contratante.email = infoEmision.ConfirmaEmail;
                contratante.SEXO = string.IsNullOrEmpty(xmlCotizacionSeleccionada.CONDUCTOR.SEXO?.ToString()) ? infoEmision.DetalleUsuario.GENERO.ToLower().Equals("masculino") ? "M" : "F" : xmlCotizacionSeleccionada.CONDUCTOR.SEXO;
                //contratante.numeroIdentificacion = xmlCotizacionSeleccionada.conductor.numeroIdentificacion;
                //contratante.tipoDocumento = xmlCotizacionSeleccionada.conductor.tipoDocumento;
                //contratante.OCUPACION = "1272";
                contratante.FCH_NACIMIENTO = infoEmision.FechaNacimiento.ToString("yyyyMMdd");
                contratante.NOMBRES = string.Format("{0} {1}", infoEmision.PrimerNombre.Trim(), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim())));
                contratante.APELLIDO_PATERNO = (string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.ApellidoPaterno.Trim()));
                contratante.APELLIDO_MATERNO = (string.IsNullOrEmpty(infoEmision.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.ApellidoMaterno.Trim()));
                contratante.NACIONALIDAD = "MEX";
                contratante.PAIS_NACIMIENTO = "MEX";
                contratante.DIRECCION = new EMISIONCONTRATANTEDIRECCION();
                //contratante.DIRECCION.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                contratante.DIRECCION.CODIGO_POSTAL = infoEmision.DatosUsuario.Direccion.CodigoPostal;
                contratante.DIRECCION.DELEGACION_MCPIO = string.IsNullOrEmpty(infoEmision.DatosUsuario.Direccion.Ciudad) ? infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Estado : infoEmision.DatosUsuario.Direccion.Ciudad;
                contratante.DIRECCION.ESTADO = infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
                contratante.DIRECCION.COLONIA = QuitarAcentos(infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento);
                contratante.DIRECCION.CVE_TIPO_VIA = "CL";

                if (infoEmision.DatosUsuario.Direccion != null)
                {
                    contratante.DIRECCION.CALLE = QuitarAcentos(infoEmision.DatosUsuario.Direccion.Calle);
                    contratante.DIRECCION.NUMERO_EXTERIOR = infoEmision.DatosUsuario.Direccion.NumeroExt;
                    contratante.DIRECCION.NUMERO_INTERIOR = infoEmision.DatosUsuario.Direccion.NumeroInt;
                }
                else
                {
                    contratante.DIRECCION.CALLE = QuitarAcentos(infoEmision.Empresa.Direccion.Calle);
                    contratante.DIRECCION.NUMERO_EXTERIOR = infoEmision.Empresa.Direccion.NumeroExt;
                    contratante.DIRECCION.NUMERO_INTERIOR = infoEmision.Empresa.Direccion.NumeroInt;
                }

                contratante.DIRECCION.PAIS_DOMICILIO = "MEX";
                contratante.TELEFONOS = new EMISIONCONTRATANTETELEFONOS();
                contratante.TELEFONOS.TELEFONO = new EMISIONCONTRATANTETELEFONOSTELEFONO();
                contratante.TELEFONOS.TELEFONO.CVE_LADA = "52";
                contratante.TELEFONOS.TELEFONO.CVE_LADA_NACIONAL = infoEmision.TelefonoCel.Substring(0, 2);
                contratante.TELEFONOS.TELEFONO.NUMERO_TELEFONO = infoEmision.TelefonoCel.Substring(2);
                //contratante.domicilio.telefonos = new Telefono[] { };
                //telefonos.Add(new Telefono { numero = infoEmision.TelefonoFijo.Substring(2), claveLada = infoEmision.TelefonoFijo.Substring(0, 2), pais = "52" });
                //telefonos.Add(new Telefono { numero = infoEmision.TelefonoCel.Substring(2), claveLada = infoEmision.TelefonoCel.Substring(0, 2), pais = "52" });
                //contratante.domicilio.telefonos = telefonos.ToArray();


                //switch (infoEmision.Convenio.IdCatTipoContratante)
                //{
                //    case 1:
                //    case 5:// Datos Fiscales Empresa
                //        contratante.TIPO_PERSONA = "M"; //Fisica F - Moral M;
                //                                        //contratante.codigoCliente = "";
                //        contratante.RFC = infoEmision.Empresa.RFC;
                //        contratante.CORREOS = new EMISIONCONTRATANTECORREOS();
                //        contratante.CORREOS.CORREO = new EMISIONCONTRATANTECORREOSCORREO();
                //        contratante.CORREOS.CORREO.CORREO_ELECTRONICO = infoEmision.Empresa.Ejecutivo.Correo;
                //        contratante.GIRO = ObtieneClaveGiroEmpresa(infoEmision.Empresa.IdCatGiroBase);
                //        contratante.FCH_CONSTITUCION = infoEmision.Empresa.FechaConstitucion?.ToString("yyyyMMdd");
                //        contratante.NACIONALIDAD = "MEX";
                //        contratante.PAIS_NACIMIENTO = "MEX";
                //        contratante.RAZON_SOCIAL = infoEmision.Empresa.RazonSocial;
                //        //contratante.tipoDocumento = "F";
                //        //contratante.numeroIdentificacion = infoEmision.Empresa.RFC;

                //        //contratante.representanteLegal = new GNPInfoServiceCotizarEmitir.RepresentanteLegal();
                //        //contratante.representanteLegal.nombre = infoEmision.Empresa.RepresentanteLegal.Nombre;
                //        //contratante.representanteLegal.amaterno = infoEmision.Empresa.RepresentanteLegal.ApellidoMaterno;
                //        //contratante.representanteLegal.apaterno = infoEmision.Empresa.RepresentanteLegal.ApellidoPaterno;
                //        //contratante.representanteLegal.rfc = Utilidades.Utilidades.CalcularRFC(contratante.representanteLegal.nombre, contratante.representanteLegal.apaterno, contratante.representanteLegal.amaterno, infoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yy"));
                //        //contratante.representanteLegal.fechaNacimiento = infoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("yyyyMMdd");
                //        //contratante.representanteLegal.tipoDocumento = "F";
                //        //contratante.representanteLegal.numeroIdentificacion = "9999999999";
                //        //contratante.representanteLegal.edoCivil = "S";
                //        //contratante.representanteLegal.sexo = "V";
                //        //contratante.representanteLegal.paisResidencia = "MEX";
                //        //contratante.representanteLegal.ocupacion = "1272";
                //        //contratante.representanteLegal.nacionalidad = "MEX";

                //        contratante.DIRECCION = new EMISIONCONTRATANTEDIRECCION();
                //        contratante.DIRECCION.CVE_TIPO_VIA = "CL";
                //        contratante.DIRECCION.CALLE = QuitarAcentos(infoEmision.Empresa.Direccion.Calle);
                //        contratante.DIRECCION.NUMERO_EXTERIOR = infoEmision.Empresa.Direccion.NumeroExt;
                //        contratante.DIRECCION.NUMERO_INTERIOR = infoEmision.Empresa.Direccion.NumeroInt;
                //        contratante.DIRECCION.PAIS_DOMICILIO = "MEX";
                //        //contratante.DIRECCION.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                //        contratante.DIRECCION.CODIGO_POSTAL = infoEmision.Empresa.Direccion.CodigoPostal;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                //        contratante.DIRECCION.DELEGACION_MCPIO = catCodigoPostal.Ciudad;
                //        contratante.DIRECCION.ESTADO = catCodigoPostal.CatEstadosRepublica.Clave;
                //        contratante.DIRECCION.COLONIA = QuitarAcentos(catCodigoPostal.Asentamiento);

                //        contratante.TELEFONOS = new EMISIONCONTRATANTETELEFONOS();
                //        contratante.TELEFONOS.TELEFONO = new EMISIONCONTRATANTETELEFONOSTELEFONO();
                //        contratante.TELEFONOS.TELEFONO.CVE_LADA = "52";
                //        contratante.TELEFONOS.TELEFONO.CVE_LADA_NACIONAL = infoEmision.Empresa.TelefonoGral.Substring(0, 2);
                //        contratante.TELEFONOS.TELEFONO.NUMERO_TELEFONO = infoEmision.Empresa.TelefonoGral.Substring(2);
                //        //new Telefono { numero = infoEmision.Empresa.TelefonoGral.Substring(2), claveLada = infoEmision.Empresa.TelefonoGral.Substring(0, 2), pais = "52" }
                //        //new Telefono { numero = infoEmision.Empresa.TelefonoGral.Substring(2), claveLada = infoEmision.Empresa.TelefonoGral.Substring(0, 2), pais = "52" }
                //        //contratante.domicilio.telefonos = telefonos.ToArray();

                //        break;
                //    case 4:
                //    case 2: // Datos Fiscales Empleado 
                //        contratante.TIPO_PERSONA = "F"; //Fisica F - Moral M;
                //                                        //contratante.codigoCliente = xmlCotizacionSeleccionada.conductor.codigoCliente;
                //        contratante.ESTADO_CIVIL = "S";
                //        contratante.RFC =
                //            string.IsNullOrEmpty(infoEmision.DatosUsuario.RFC) ?
                //            Utilidades.Utilidades.CalcularRFC(
                //                string.Format("{0} {1}", infoEmision.PrimerNombre.Trim(), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim()))),
                //                infoEmision.ApellidoPaterno,
                //                infoEmision.ApellidoMaterno,
                //                infoEmision.FechaNacimiento.ToString("dd/MM/yy")
                //                ) :
                //                infoEmision.DatosUsuario.RFC;
                //        contratante.CORREOS = new EMISIONCONTRATANTECORREOS();
                //        contratante.CORREOS.CORREO = new EMISIONCONTRATANTECORREOSCORREO();
                //        contratante.CORREOS.CORREO.CORREO_ELECTRONICO = infoEmision.ConfirmaEmail;
                //        //contratante.email = infoEmision.ConfirmaEmail;
                //        contratante.SEXO = string.IsNullOrEmpty(xmlCotizacionSeleccionada.CONDUCTOR.SEXO?.ToString()) ? infoEmision.DetalleUsuario.GENERO.ToLower().Equals("masculino") ? "M" : "F" : xmlCotizacionSeleccionada.CONDUCTOR.SEXO;
                //        //contratante.numeroIdentificacion = xmlCotizacionSeleccionada.conductor.numeroIdentificacion;
                //        //contratante.tipoDocumento = xmlCotizacionSeleccionada.conductor.tipoDocumento;
                //        //contratante.OCUPACION = "1272";
                //        contratante.FCH_NACIMIENTO = infoEmision.FechaNacimiento.ToString("yyyyMMdd");
                //        contratante.NOMBRES = string.Format("{0} {1}", infoEmision.PrimerNombre.Trim(), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim())));
                //        contratante.APELLIDO_PATERNO = (string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.ApellidoPaterno.Trim()));
                //        contratante.APELLIDO_MATERNO = (string.IsNullOrEmpty(infoEmision.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.ApellidoMaterno.Trim()));
                //        contratante.NACIONALIDAD = "MEX";
                //        contratante.PAIS_NACIMIENTO = "MEX";
                //        contratante.DIRECCION = new EMISIONCONTRATANTEDIRECCION();
                //        //contratante.DIRECCION.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                //        contratante.DIRECCION.CODIGO_POSTAL = infoEmision.DatosUsuario.Direccion.CodigoPostal;
                //        contratante.DIRECCION.DELEGACION_MCPIO = infoEmision.DatosUsuario.Direccion.Ciudad;
                //        contratante.DIRECCION.ESTADO = infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
                //        contratante.DIRECCION.COLONIA = QuitarAcentos(infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento);
                //        contratante.DIRECCION.CVE_TIPO_VIA = "CL";

                //        if (infoEmision.DatosUsuario.Direccion != null)
                //        {
                //            contratante.DIRECCION.CALLE = QuitarAcentos(infoEmision.DatosUsuario.Direccion.Calle);
                //            contratante.DIRECCION.NUMERO_EXTERIOR = infoEmision.DatosUsuario.Direccion.NumeroExt;
                //            contratante.DIRECCION.NUMERO_INTERIOR = infoEmision.DatosUsuario.Direccion.NumeroInt;
                //        }
                //        else
                //        {
                //            contratante.DIRECCION.CALLE = QuitarAcentos(infoEmision.Empresa.Direccion.Calle);
                //            contratante.DIRECCION.NUMERO_EXTERIOR = infoEmision.Empresa.Direccion.NumeroExt;
                //            contratante.DIRECCION.NUMERO_INTERIOR = infoEmision.Empresa.Direccion.NumeroInt;
                //        }

                //        contratante.DIRECCION.PAIS_DOMICILIO = "MEX";
                //        contratante.TELEFONOS = new EMISIONCONTRATANTETELEFONOS();
                //        contratante.TELEFONOS.TELEFONO = new EMISIONCONTRATANTETELEFONOSTELEFONO();
                //        contratante.TELEFONOS.TELEFONO.CVE_LADA = "52";
                //        contratante.TELEFONOS.TELEFONO.CVE_LADA_NACIONAL = infoEmision.TelefonoFijo.Substring(0, 2);
                //        contratante.TELEFONOS.TELEFONO.NUMERO_TELEFONO = infoEmision.TelefonoFijo.Substring(2);
                //        //contratante.domicilio.telefonos = new Telefono[] { };
                //        //telefonos.Add(new Telefono { numero = infoEmision.TelefonoFijo.Substring(2), claveLada = infoEmision.TelefonoFijo.Substring(0, 2), pais = "52" });
                //        //telefonos.Add(new Telefono { numero = infoEmision.TelefonoCel.Substring(2), claveLada = infoEmision.TelefonoCel.Substring(0, 2), pais = "52" });
                //        //contratante.domicilio.telefonos = telefonos.ToArray();
                //        break;
                //    default:
                //        contratante.TIPO_PERSONA = "F";
                //        //contratante.codigoCliente = "";
                //        contratante.ESTADO_CIVIL = "S";
                //        contratante.RFC = infoEmision.EsFlotilla ? LocktonServicios.Utilidades.Utilidades.CalcularRFC(infoEmision.DetalleUsuario.Nombre + " " + infoEmision.DetalleUsuario.NombreDos, infoEmision.DetalleUsuario.ApellidoPaterno, infoEmision.DetalleUsuario.ApellidoMaterno, infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yy")) : infoEmision.DatosUsuario.RFC;
                //        contratante.CORREOS = new EMISIONCONTRATANTECORREOS();
                //        contratante.CORREOS.CORREO = new EMISIONCONTRATANTECORREOSCORREO();
                //        contratante.CORREOS.CORREO.CORREO_ELECTRONICO = infoEmision.ConfirmaEmail;
                //        //contratante.email = infoEmision.ConfirmaEmail;
                //        contratante.SEXO = string.IsNullOrEmpty(xmlCotizacionSeleccionada.CONDUCTOR.SEXO.ToString()) ? infoEmision.DetalleUsuario.GENERO.ToLower().Equals("masculino") ? "M" : "F" : xmlCotizacionSeleccionada.CONDUCTOR.SEXO.ToString();
                //        //contratante.OCUPACION = "ADMINISTRADOR";
                //        //contratante.numeroIdentificacion = xmlCotizacionSeleccionada.conductor.numeroIdentificacion;
                //        //contratante.tipoDocumento = xmlCotizacionSeleccionada.conductor.tipoDocumento;
                //        contratante.OCUPACION = "OTRO";
                //        contratante.FCH_NACIMIENTO = infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("yyyyMMdd");
                //        contratante.NOMBRES = string.Format("{0} {1}", infoEmision.DetalleUsuario.Nombre.Trim(), (string.IsNullOrEmpty(infoEmision.DetalleUsuario.NombreDos) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.NombreDos.Trim())));
                //        contratante.APELLIDO_PATERNO = (string.IsNullOrEmpty(infoEmision.DetalleUsuario.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.ApellidoPaterno.Trim()));
                //        contratante.APELLIDO_MATERNO = (string.IsNullOrEmpty(infoEmision.DetalleUsuario.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.ApellidoMaterno.Trim()));
                //        contratante.PAIS_NACIMIENTO = "MEX";
                //        contratante.NACIONALIDAD = "MEX";
                //        contratante.DIRECCION = new EMISIONCONTRATANTEDIRECCION();
                //        //contratante.DIRECCION.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                //        contratante.DIRECCION.CODIGO_POSTAL = codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                //        contratante.DIRECCION.DELEGACION_MCPIO = catCodigoPostal.Ciudad;
                //        contratante.DIRECCION.ESTADO = catCodigoPostal.CatEstadosRepublica.Clave;
                //        contratante.DIRECCION.COLONIA = QuitarAcentos(catCodigoPostal.Asentamiento);
                //        contratante.DIRECCION.CVE_TIPO_VIA = "CL";// = catCodigoPostal.CatEstadosRepublica.Clave;// InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
                //        contratante.DIRECCION.CALLE = infoEmision.EsFlotilla ? QuitarAcentos(infoEmision.Empresa.Direccion.Calle) : QuitarAcentos(infoEmision.DatosUsuario.Direccion.Calle);
                //        contratante.DIRECCION.NUMERO_EXTERIOR = infoEmision.EsFlotilla ? infoEmision.Empresa.Direccion.NumeroExt : infoEmision.DatosUsuario.Direccion.NumeroExt;
                //        contratante.DIRECCION.NUMERO_INTERIOR = infoEmision.EsFlotilla ? infoEmision.Empresa.Direccion.NumeroInt : infoEmision.DatosUsuario.Direccion.NumeroInt;
                //        contratante.DIRECCION.PAIS_DOMICILIO = "MEX";
                //        contratante.TELEFONOS = new EMISIONCONTRATANTETELEFONOS();
                //        contratante.TELEFONOS.TELEFONO = new EMISIONCONTRATANTETELEFONOSTELEFONO();
                //        contratante.TELEFONOS.TELEFONO.CVE_LADA = "52";
                //        contratante.TELEFONOS.TELEFONO.CVE_LADA_NACIONAL = infoEmision.TelefonoFijo.Substring(0, 2);
                //        contratante.TELEFONOS.TELEFONO.NUMERO_TELEFONO = infoEmision.TelefonoFijo.Substring(2);
                //        break;
                //}

            }
            return contratante;
        }

        private string ObtieneClaveGiroEmpresa(int? idCatGiroBase)
        {


            string giro = "2";
            var catgiro = db.CatGiroBase.FirstOrDefault(a => a.Id == idCatGiroBase);

            if (catgiro != null && !string.IsNullOrEmpty(catgiro.ClaveGNPPreferente))

                giro = catgiro.ClaveGNPPreferente;

            return giro;
        }

        private void ColocaFormaDeCobro(XMLEntity.Cotizacion.GNPPreferente.Solicitudes.EMISION reqEmiAuto, int mediodePago)
        {
            if (mediodePago == 0 || mediodePago == 1)
            {
                reqEmiAuto.SOLICITUD.VIA_PAGO = "BC";
                reqEmiAuto.SOLICITUD.VIA_PAGO_SUCESIVOS = "BC";
                reqEmiAuto.SOLICITUD.OPERACION = "E";
            }
            else
            {
                reqEmiAuto.SOLICITUD.VIA_PAGO = "IN";
                reqEmiAuto.SOLICITUD.VIA_PAGO_SUCESIVOS = "IN";
                reqEmiAuto.SOLICITUD.OPERACION = "E";
            }
        }

        private void ColocaFormaDeCobro(XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION reqEmiAuto, int mediodePago)
        {
            if (mediodePago == 0 || mediodePago == 1)
            {
                reqEmiAuto.SOLICITUD.VIA_PAGO = "BC";
            }
            else
            {
                reqEmiAuto.SOLICITUD.VIA_PAGO = "IN";
            }
        }

        private EMISIONVEHICULO ConstruyeObjetoVehiculoEmision(InformacionEmision infoEmision, XMLEntity.Cotizacion.GNPPreferente.Solicitudes.COTIZACION xmlCotizacionSeleccionada, List<Coberturas> coberturasPaquete)
        {
            var nuevoVehiculo = new EMISIONVEHICULO()
            {
                SUB_RAMO = xmlCotizacionSeleccionada.VEHICULO.SUB_RAMO.ToString(),
                TIPO_VEHICULO = xmlCotizacionSeleccionada.VEHICULO.TIPO_VEHICULO.ToString(),
                MODELO = xmlCotizacionSeleccionada.VEHICULO.MODELO.ToString(),
                ARMADORA = xmlCotizacionSeleccionada.VEHICULO.ARMADORA.ToString(),
                CARROCERIA = xmlCotizacionSeleccionada.VEHICULO.CARROCERIA.ToString(),
                VERSION = xmlCotizacionSeleccionada.VEHICULO.VERSION.ToString(),
                USO = xmlCotizacionSeleccionada.VEHICULO.USO.ToString(),
                FORMA_INDEMNIZACION = xmlCotizacionSeleccionada.VEHICULO.FORMA_INDEMNIZACION.ToString(),
                VALOR_FACTURA = xmlCotizacionSeleccionada.VEHICULO.VALOR_FACTURA.ToString(),
                VALOR_REFERENCIA = xmlCotizacionSeleccionada.VEHICULO.VALOR_REFERENCIA.ToString(),
                VALOR_CONVENIDO = xmlCotizacionSeleccionada.VEHICULO.VALOR_CONVENIDO.ToString()
            };

            nuevoVehiculo.MOTOR = infoEmision.NumeroMotor;
            nuevoVehiculo.SERIE = infoEmision.NumeroSerie;
            nuevoVehiculo.PLACAS = infoEmision.Placas;

            if (nuevoVehiculo.FORMA_INDEMNIZACION != "02")
                foreach (Coberturas paquete in coberturasPaquete)
                {
                    if (paquete.Codigo.Contains("1289") || paquete.Codigo.Contains("1288") || paquete.Codigo.Contains("916"))
                    {
                        nuevoVehiculo.FORMA_INDEMNIZACION = ObtieneClaveTipoValorVehiculo(paquete.Cobertura);
                    }
                }
            nuevoVehiculo.VALOR_CONVENIDO = nuevoVehiculo.VALOR_REFERENCIA != null ? nuevoVehiculo.VALOR_REFERENCIA : nuevoVehiculo.VALOR_CONVENIDO;

            return nuevoVehiculo;
        }

        private string ObtieneClaveTipoValorVehiculo(string cobertura)
        {
            string clave = string.Empty;

            if (string.IsNullOrEmpty(cobertura))
                return string.Empty;

            switch (cobertura.ToLower())
            {
                case "valor comercial":
                    clave = "01";
                    break;
                case "valor convenido":
                    clave = "03";
                    break;
                case "valor declarado":
                    clave = "05";
                    break;
                default:
                    clave = "01";
                    break;
            }

            return clave;
        }

        private string ObtieneCodigoPostalParaEmision(InformacionEmision infoEmision)
        {
            string codigoPostal = string.Empty;
            if (!infoEmision.ConductorHabitual)
            {
                if (infoEmision.DatosUsuario.Direccion != null)
                {
                    codigoPostal = infoEmision.DatosUsuario.Direccion.CodigoPostal ?? infoEmision.Empresa.Direccion.CodigoPostal;
                }
                else if (infoEmision.DetalleUsuario.Direccion != null)
                {
                    codigoPostal = infoEmision.DetalleUsuario.Direccion.CodigoPostal ?? infoEmision.Empresa.Direccion.CodigoPostal;
                }
                else
                {
                    codigoPostal = infoEmision.Empresa.Direccion.CodigoPostal;
                }
            }
            else
            {
                codigoPostal = infoEmision.Empresa.Direccion.CodigoPostal;
            }
            return codigoPostal;
        }

        private void AgregaDatosBancariosContratante(EMISIONCONTRATANTE contratante, InformacionEmision infoEmision)
        {
            int medioPago = infoEmision.CotizacionAutoGuardar.MediodePago;

            if (medioPago.Equals(0) || medioPago.Equals(1))
            {
                contratante.MEDIO_COBRO = new EMISIONCONTRATANTEMEDIO_COBRO();
                contratante.MEDIO_COBRO.CVE_TIPO_BANCARIO = ObtieneClaveTipoCuentaBancaria(medioPago);
                contratante.MEDIO_COBRO.CVE_TIPO_CUENTA_TARJETA = ObtieneTipoCuentaTarjeta(infoEmision.Tarjeta.TipoTarjeta);
                contratante.MEDIO_COBRO.CVE_ENTIDAD_FINANCIERA = infoEmision.IdBanco.ToString().PadLeft(4, '0');
                contratante.MEDIO_COBRO.NUM_TARJETA = infoEmision.Tarjeta.NumeroTarjeta; ;
                contratante.MEDIO_COBRO.FCH_VENCIMIENTO = string.Concat(infoEmision.Tarjeta.MesVencimiento, infoEmision.Tarjeta.AnioVencimiento.ToString() == "1900" ? infoEmision.IdAnio.ToString() : infoEmision.Tarjeta.AnioVencimiento.ToString());
                contratante.MEDIO_COBRO.ID_CUENTA_FINANCIERA = "";
                contratante.MEDIO_COBRO.AUTORIZACION_PAGO = "";
                //////contratante.banco = new Banco();
                //////contratante.banco.codigoSegTarjeta = infoEmision.Tarjeta.Cvv;
                //////contratante.banco.tipo = "";
                //////contratante.banco.bancoEntidad = infoEmision.IdBanco.ToString().PadLeft(4, '0');
                //////contratante.banco.tipoCuentaTarjeta = "MC";//infoEmision.Tarjeta.TipoTarjeta;
                //////contratante.banco.mes = infoEmision.Tarjeta.MesVencimiento;
                //////contratante.banco.anio = infoEmision.Tarjeta.AnioVencimiento.ToString() == "1900" ? infoEmision.IdAnio.ToString() : infoEmision.Tarjeta.AnioVencimiento.ToString();
                //////contratante.banco.numTarjeta = infoEmision.Tarjeta.NumeroTarjeta;
                //////contratante.banco.moneda = "MXP";
                //////contratante.banco.titular1 = infoEmision.Tarjeta.TitularTarjeta;
                //////contratante.banco.tipo = ObtieneClaveTipoCuentaBancaria(medioPago);
                //////contratante.banco.fechaCorte = "1";
                //////contratante.banco.fechaVencimiento = String.Concat(contratante.banco.mes, contratante.banco.anio);

            }
        }

        private string ObtieneClaveTipoCuentaBancaria(int medioPago)
        {
            string clave = string.Empty;
            if (medioPago.Equals(0))
            {
                clave = "R";
            }
            if (medioPago.Equals(1))
            {
                clave = "D";
            }
            return clave;
        }

        private string ObtieneTipoCuentaTarjeta(string nombreTipoTarjeta)
        {
            string tipoTarjeta = string.Empty;
            switch (nombreTipoTarjeta.ToLower())
            {
                case "visa":
                    tipoTarjeta = "VI";
                    break;
                case "master card":
                    tipoTarjeta = "MC";
                    break;
                case "amex":
                    tipoTarjeta = "AM";
                    break;
            }
            return tipoTarjeta;
        }

        #endregion



        #region Not Implemented

        public struct FormaIndemnizacionInfoService
        {
            public string ValorConvenido => "03";
            public string ValorComercial => "01";
            public string ValorDeclarado => "05";
        }


        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new NotImplementedException();
        }



        public decimal ObtenerPrimerPago(string xMLRecepcion)
        {
            decimal primerPago = 0;
            try
            {
                XMLEntity.Cotizacion.GNPPreferente.Respuestas.EMISION resultadoCotizacion = Utilidades.Utilidades.GetXmlFromString<XMLEntity.Cotizacion.GNPPreferente.Respuestas.EMISION>(xMLRecepcion);

                foreach (var paquete in resultadoCotizacion.CONCEPTOS_ECONOMICOS)
                {
                    if (paquete.NOMBRE == "IMP_PRIMER_RECIBO")
                    {
                        primerPago = decimal.Parse(QuitaCaracteres(paquete.MONTO.ToString()), CultureInfo.InvariantCulture);
                        break;
                    }
                }
            }
            catch (Exception) { }
            return primerPago;

        }



        
        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
