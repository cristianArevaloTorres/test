﻿using com.lockton.xml.aba.consultadireccion.response;
using com.lockton.xml.aba.consultapersona.request;
using com.lockton.xml.aba.consultapersona.response;
using com.lockton.xml.aba.cotizacion.request;
using com.lockton.xml.aba.cp.response;
using com.lockton.xml.aba.emision.request;
using com.lockton.xml.aba.impresion.response;
using com.lockton.xml.aba.persona.request;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonModel.xmls.AXA;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.Catalogos;
using LocktonServicios.CodigoPostalABA;
using LocktonServicios.CotizacionABA;
using LocktonServicios.Utilidades;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;

namespace LocktonServicios.Aseguradoras
{
    public class ABACHUBBService : IOperacionesAseguradoras
    {



        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger(typeof(ABACHUBBService));
        private const string aseguradora = "ABA";


        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision, Convenio convenioCotiza)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("yyyy-MM-dd");
                XmlDocument xmlCotizacionSeleccionada = new XmlDocument();

                xmlCotizacionSeleccionada.LoadXml(xmlEmision);
                xmlCotizacionSeleccionada.SelectNodes("COT/DG/INIVIG")[0].InnerText = date;

                CotizacionABA.Token token = new CotizacionABA.Token();
                token.usuario = convenioCotiza.Usuario;
                token.password = convenioCotiza.Contrasena;

                using (ACCotizacionClient cliente = new ACCotizacionClient())
                {
                    var xmlResultadoCot = cliente.CotizaAuto(token, xmlCotizacionSeleccionada.InnerXml);

                    resultado.XMLSolicitud = xmlCotizacionSeleccionada.InnerXml;
                    resultado.XMLRecepcion = xmlResultadoCot;

                    return resultado;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Cotizacion
        public CotizacionCompara CotizaVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<LocktonModel.db.PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {
            string xmlResultadoCot = "";
            string xmlCotizacion = "";
            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
            try
            {
                DateTime fechaCotizacionABA = CotizacionCompara.FechaCotizacion;
                using (ACCotizacionClient cliente = new ACCotizacionClient())
                {
                    COT cotResult = new COT();

                    xmlCotizacion = ConstruyeXMLCotizacion(CotizacionCompara, convenioCotiza, cot, detalleUsuario, ref Coberturas, ConveniosPaquetes, IdTipoPaquete, ref fechaCotizacionABA, idPaqueteConvenio);
                    CotizacionABA.Token token = new CotizacionABA.Token();
                    token.usuario = convenioCotiza.Usuario;
                    token.password = convenioCotiza.Contrasena;
                    log.Info(string.Format("Xml Cotizacion Solicitud: {0}", xmlCotizacion.Replace("\n", "").Replace("\r", "")));

                    xmlResultadoCot = cliente.CotizaAuto(token, xmlCotizacion);

                    log.Info(string.Format("Xml Cotizacion Respuesta: {0}", xmlResultadoCot.Replace("\n", "").Replace("\r", "")));
                }
                var cotizacion = LeeXmlRespuesta(xmlResultadoCot, Coberturas, IdTipoPaquete, xmlCotizacion, convenioCotiza, idPaqueteConvenio);
                var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == CotizacionCompara.FormadePago).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);

                cotizacion.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                cotizacion.FechaCotizacion = fechaCotizacionABA;
                cotizacion.IdFormaPago = CotizacionCompara.FormadePago;
                cotizacion.IdMedioPago = mediopago.Id;

                //meses sin intereses
                if (perioricidad.Id == 1 && mediopago.Id == 1)
                {

                    Utilidades.Utilidades.AplicaMSICotizacion(convenioCotiza.IdEmpresa, convenioCotiza.Id, ref cotizacion);

                }

                CotizacionCompara.Comparar.Add(cotizacion);
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Error en cotizacion: {0}", ex.Message));
                string mensaje = ex.Message;

                if(mensaje.Contains("sobrepasa el limite configurado"))
                    mensaje = "Vehículo de Alta Gama. - El vehículo seleccionado no está autorizado, favor contactar a su ejecutivo";

                CotizacionCompara.Comparar.Add(new Comparar() { Aseguradora = "ABA", IdAseguradora = 3, ErrorXML = mensaje, XmlEmision = xmlCotizacion, XmlRespuesta = string.IsNullOrEmpty(xmlResultadoCot) ? "<Error>" + ex.Message + "</Error>" : xmlResultadoCot });
            }
            return CotizacionCompara;
        }

        public Coberturas ObtenerTipoDeducubleCobertura(string deducible, PaqueteDetalle detalle, List<CatTipoDatoDeducible> deducibles)
        {
            var coberturaDeducible = new Coberturas();

            decimal _d = 0;

            if (decimal.TryParse(deducible, out _d))
            {
                if (_d > 0 && detalle != null && detalle.IdTipoDatoDeducible > 1)
                {
                    var tipoDato = deducibles.FirstOrDefault(a => a.Id == detalle.IdTipoDatoDeducible);


                    coberturaDeducible.IdTipoDatoDeducible = tipoDato.Id;
                    coberturaDeducible.TipoDato = tipoDato.Nombre;
                }
            }

            return coberturaDeducible;
        }

        public Comparar LeeXmlRespuesta(string XmlResultado, List<LocktonModel.db.PaqueteDetalle> coberturas, int IdTipoPaquete, string xmlEnvio, Convenio convenioCotiza, int idPaqueteConvenio)
        {
            Comparar infoCompara = new Comparar();

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            CoberturasUtils utils = new CoberturasUtils();
            var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
            xmlCotizacionSeleccionada.LoadXml(xmlEnvio);


            try
            {
                LocktonServicios.aba.cotizacion.response.COT resultadoCotizacion = ToObject<LocktonServicios.aba.cotizacion.response.COT>(XmlResultado);
                infoCompara.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                infoCompara.PrimaTotal = resultadoCotizacion.PTOTAL;
                infoCompara.Recargo = resultadoCotizacion.REC;
                infoCompara.PrimaNeta = (double.Parse(resultadoCotizacion.PNETA, CultureInfo.InvariantCulture) - double.Parse(resultadoCotizacion.DTO, CultureInfo.InvariantCulture)).ToString();
                infoCompara.CotizacionClave = resultadoCotizacion.COTID;
                infoCompara.VersionClave = resultadoCotizacion.VERID;
                infoCompara.Aseguradora = "ABA";
                infoCompara.Cobertura = IdTipoPaquete.ToString();
                infoCompara.XmlEmision = xmlEnvio;
                infoCompara.XmlRespuesta = XmlResultado;
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.FechaInicio = xmlCotizacionSeleccionada.SelectNodes("COT/DG/INIVIG")[0].InnerText;
                infoCompara.FechaFin = xmlCotizacionSeleccionada.SelectNodes("COT/DG/FINVIG")[0].InnerText;
                infoCompara.Año = resultadoCotizacion.INCISOS.FirstOrDefault().MOD;
                infoCompara.Derecho = resultadoCotizacion.INCISOS.FirstOrDefault().DER;
                infoCompara.NumeroDePagos = resultadoCotizacion.INCISOS.FirstOrDefault().RECIBOS.Count() == 1 ? 1 : resultadoCotizacion.INCISOS.FirstOrDefault().RECIBOS.Count() - 1;

                if (paqueteConvenio.CoberturaAdicionalAIG)
                {
                    infoCompara.AplicaCoberturaAdicionalAIG = true;

                    infoCompara.DescargaCoberturaAIG = Utilidades.Utilidades.ContieneTipoDocumentoEmpresa(paqueteConvenio.IdConvenio, 2);
                }


                foreach (LocktonServicios.aba.cotizacion.response.COTINCISOSINCISO incisosResultado in resultadoCotizacion.INCISOS)
                {
                    infoCompara.IncisoCotizacionClave = incisosResultado.COTINCID;
                    infoCompara.IncisoVersionClave = incisosResultado.VERINCID;
                    infoCompara.PrimaNeta = incisosResultado.PNETA;
                    infoCompara.PrimaTotal = incisosResultado.PTOTAL;
                    infoCompara.Impuesto = incisosResultado.IVA;
                    infoCompara.Recargo = incisosResultado.REC;
                    infoCompara.Coberturas = new List<Coberturas>();
                    List<Cobertura> ListCoberturas = db.Cobertura.ToList();

                    var tipoDatosDeducibles = db.CatTipoDatoDeducible.ToList();

                    foreach (LocktonServicios.aba.cotizacion.response.COTINCISOSINCISOCOBSCOB coberturaABA in incisosResultado.COBS)
                    {
                        foreach (PaqueteDetalle paq in coberturas)
                        {
                            string ClaveCobertura = ListCoberturas.Where(x => x.Id.Equals(paq.IdCobertura)).FirstOrDefault().Clave;
                            var _deducible = ObtenerTipoDeducubleCobertura(coberturaABA.DEDESC, paq, tipoDatosDeducibles);

                            if (ListCoberturas != null)// idCobe == int.Parse(ClaveCobertura)))
                            {
                                if (coberturaABA.COBID == ClaveCobertura)
                                {
                                    if (ClaveCobertura == Cobertura.COBERTURA_CLAVE_ROBOTOTAL || ClaveCobertura == Cobertura.COBERTURA_CLAVE_DANOSMATERIALES)
                                    {
                                        coberturaABA.DEDESC = Convert.ToDouble(paq.Deducible).ToString();
                                    }
                                    string nombre = coberturaABA.DESC;

                                    bool EsCondEspecial = utils.EsCondicionEsp(convenioCotiza.Id, paq.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);

                                    if (EsCondEspecial)
                                    {
                                        var CondicionEspecialAno = utils.EsCoberturaEspecialano(convenioCotiza.Id
                                            , paq.IdCobertura.ToString()
                                            , infoCompara.Año
                                            , ""
                                            , ""
                                            , paq.SumaAsegurada
                                            , paq.Deducible
                                            , ""
                                            , ""
                                            , paqueteConvenio.IdCatRamoVehiculo);

                                        if (CondicionEspecialAno.Deducible != null)
                                        {
                                            infoCompara.Coberturas.Add(new LocktonModel.VModels.Coberturas() { IdTipoDatoDeducible = _deducible.IdTipoDatoDeducible, TipoDato = _deducible.TipoDato, Deducible = coberturaABA.DEDESC == "NO APLICA" ? "" : coberturaABA.DEDESC, Codigo = coberturaABA.COBID, SumaAsegurada = coberturaABA.SADESC, Tipo = "", Cobertura = coberturaABA.PNETA, Nombre = nombre });
                                        }
                                    }
                                    else
                                        infoCompara.Coberturas.Add(new LocktonModel.VModels.Coberturas() { IdTipoDatoDeducible = _deducible.IdTipoDatoDeducible, TipoDato = _deducible.TipoDato, Deducible = coberturaABA.DEDESC == "NO APLICA" ? "" : coberturaABA.DEDESC, Codigo = coberturaABA.COBID, SumaAsegurada = coberturaABA.SADESC, Tipo = "", Cobertura = coberturaABA.PNETA, Nombre = nombre });
                                }
                            }
                        }
                    }

                    if (incisosResultado.RECIBOS.Count() == 1)
                    {
                        infoCompara.PrimerPago = incisosResultado.RECIBOS[0].PTOTAL ?? "";
                    }

                    if (incisosResultado.RECIBOS.Count() > 1)
                    {
                        infoCompara.PrimerPago = incisosResultado.RECIBOS[0].PTOTAL ?? "";
                        infoCompara.SegundoPago = incisosResultado.RECIBOS[1].PTOTAL ?? "";
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return infoCompara;
        }


        public PersonaABA BuscaPersona(string rfc, string tipocontribuyente, string usuario, string password, string persona)
        {
            PersonaABA personaABA = new PersonaABA();
            return personaABA;
        }

        public LOCALIZACIONESLOCALIZACION ConsultarLocalizacionPorCP(CodigoPostalABA.Token token, string codigoPostal, Convenio conv)
        {
            string resultado = "";
            PCCatalogosClient client = new PCCatalogosClient();


            token.usuario = conv.Usuario;
            token.password = conv.Contrasena;


            resultado = client.ConsultarLocalizacionPorCP(token, String.Format("<XML><CP>{0}</CP></XML>", codigoPostal));


            TextReader reader = new StringReader(resultado);
            XmlSerializer xs = new XmlSerializer(typeof(LOCALIZACIONES));
            LOCALIZACIONES cotResult = (LOCALIZACIONES)xs.Deserialize(reader);
            LOCALIZACIONESLOCALIZACION localizacion = cotResult.Items.FirstOrDefault();


            return localizacion;


        }
        /// <summary>
        /// Metodo que construira el Nodo de COTDG para ABA en base al convenio.
        /// </summary>
        /// <returns></returns>
        public COTDG ConstruyeNodoDatosGenerales(Convenio convenio, ref CotizacionCompara CotCompara, ref DateTime fechaCotizacion)
        {


            COTDG datosGenerales = new COTDG();

            int formaPago = CotCompara.FormadePago;
            ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == convenio.IdEmpresa);
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenio.Id && x.IdCatPeriodicidadFormaPago == formaPago).FirstOrDefault();
            bool peridoenrrollment = Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenio.IdEmpresa, DateTime.Now);

            DateTime inicio = CotCompara.FechaInicio;
            string InicioVigencia = CotCompara.FechaInicio.ToString("yyyy-MM-dd");
            string FinVigencia = CotCompara.FechaFin.ToString("yyyy-MM-dd");
            fechaCotizacion = CotCompara.FechaCotizacion;

            string Agrupador = convenio.Agrupador.ToString();

            //if (configuracionEmpresa.AplicaFechaCotizacion )
            //{
            //	InicioVigencia = CotCompara.FechaCotizacion.ToString("yyyy-MM-dd");
            //	inicio = CotCompara.FechaCotizacion;
            //	fechaCotizacion = CotCompara.FechaCotizacion;
            //	FinVigencia = CotCompara.FechaCotizacion.AddYears(1).ToString("yyyy-MM-dd");
            //}

            //if (configuracionEmpresa.IdTipoDeNegocio == 1 || configuracionEmpresa.IdTipoDeNegocio == 4 || configuracionEmpresa.IdTipoDeNegocio == 5)//flotilla
            //{
            //	//verifica las fechas de inicio
            //	if (peridoenrrollment)
            //	{//busca si existe fecha de enrollment
            //		InicioVigencia = convenio.InicioVigencia.ToString("yyyy-MM-dd");
            //		fechaCotizacion = convenio.InicioVigencia;
            //	}
            //	FinVigencia = convenio.FinVigencia.ToString("yyyy-MM-dd");

            //}

            datosGenerales.NEG = convenio.NumeroNegocio;
            datosGenerales.AGE = perioricidad.ClaveAgente;
            datosGenerales.CON = convenio.Conducto.ToString();
            datosGenerales.TAR = convenio.Tarifa;

            //if (convenio.IdCatTipoContratante == 4)
            //{
            //	inicio = configuracionEmpresa.AplicaFechaCotizacion ? CotCompara.FechaCotizacion : DateTime.Now;
            //	InicioVigencia = configuracionEmpresa.AplicaFechaCotizacion ? CotCompara.FechaCotizacion.ToString("yyyy-MM-dd") : DateTime.Now.ToString("yyyy-MM-dd");
            //	FinVigencia = configuracionEmpresa.AplicaFechaCotizacion ? CotCompara.FechaCotizacion.AddYears(1).ToString("yyyy-MM-dd") : DateTime.Now.AddYears(1).ToString("yyyy-MM-dd");
            //}
            //else
            //{

            //	if (!peridoenrrollment && !configuracionEmpresa.AplicaFechaCotizacion)
            //	{
            //		InicioVigencia = DateTime.Now.ToString("yyyy-MM-dd");
            //		inicio = DateTime.Now;
            //		FinVigencia = convenio.FinVigencia.ToString("yyyy-MM-dd");
            //	}
            //}

            datosGenerales.FP = perioricidad.FormaPago; //forma de pago del convenio

            if (configuracionEmpresa.AplicaMultiAnual)
            {
                //CatPeriodicidadFormaPago catperdioricidad = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == perioricidad.IdCatPeriodicidadFormaPago);
                //if (catperdioricidad != null)
                //    FinVigencia = inicio.AddYears(catperdioricidad.ValorMultiAnual).ToString("yyyy-MM-dd");

                if(CotCompara.IdCatPeriodicidadMultianual > 0)
                {
                    var idCatPeriodicidadMultianual = CotCompara.IdCatPeriodicidadMultianual;
                    var multianual = db.PeriodicidadMultianual.FirstOrDefault(a => a.IdCatPeriodicidadMultianual == idCatPeriodicidadMultianual && a.IdConvenio == convenio.Id && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago);
                    if (multianual != null)
                        datosGenerales.FP = multianual.FormaPago;
                }
            }

            datosGenerales.INIVIG = InicioVigencia;
            datosGenerales.FINVIG = FinVigencia;        
            datosGenerales.TC = convenio.CodigoPromocion ?? ""; //Codigo de promocion configurado en el convenio.

            if (!string.IsNullOrEmpty(convenio.UsuarioAgente.ToString()))
            {
                datosGenerales.TS = "2";
                datosGenerales.AGRUPA = Agrupador; //Agrupador configurado en el convenio.
            }
            else
            {
                datosGenerales.TS = "1";
            }

            return datosGenerales;
        }


        private String UTF8ByteArrayToString(Byte[] characters)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            String constructedString = encoding.GetString(characters);
            return (constructedString);
        }


        public string ToXMLString<T>(T toSerialize)
        {
            MemoryStream memoryStream = new MemoryStream();
            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add(String.Empty, String.Empty);
            XmlSerializer xs = new XmlSerializer(typeof(T));
            XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Default);
            xs.Serialize(xmlTextWriter, toSerialize, ns);
            memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
            string XmlizedString = UTF8ByteArrayToString(memoryStream.ToArray());
            XmlizedString = XmlizedString.Replace("<?xml version=\"1.0\" encoding=\"Windows-1252\"?>", "");
            xmlTextWriter.Close();
            memoryStream.Close();
            return XmlizedString;
        }


        public string ConstruyeXMLCotizacion(CotizacionCompara cotDet, Convenio conv, mDetalles cot, DetalleUsuario detalleUsuario, ref List<PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, ref DateTime fechaCotizacion, int idPaqueteConvenio)
        {
            string XmlizedString = null;
            try
            {
                COT cotizacion = new COT();
                COTINCISOS cotizacionIncisos = new COTINCISOS();
                COTINCISOSINCISO datosVehiculo = new COTINCISOSINCISO();
                CodigoPostalABA.Token token = new CodigoPostalABA.Token();
                string CodigoPostal = "";
                token.usuario = conv.Usuario;
                token.password = conv.Contrasena;
                //int ramo = int.Parse(conv.RamoVehiculo);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                //ConvenioRamoPaquete CRP = db.ConvenioRamoPaquete.Where(cr => cr.IdConvenio == conv.Id && cr.IdCatRamoVehiculo == ramo).FirstOrDefault();
                ConvenioRamoPaquete CRP = db.ConvenioRamoPaquete.Where(cr => cr.IdConvenio == conv.Id && cr.IdCatRamoVehiculo == paqueteConvenio.IdCatRamoVehiculo).FirstOrDefault();
                //ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == conv.IdEmpresa).FirstOrDefault();
                int Ocupantes = 5;
                string ClaveVehicular = string.Empty;
                if (cot.Catalogo.Count() > 0)
                {
                    ConsultaCatalogoHomologado.ObjetoRespuestaBD _descripcion = new ConsultaCatalogoHomologado.ConsultaCatalogoHomologadoClient().NCHConsultaDetalleVehiculo("ABA", cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault().clave);
                    _Descripciones _resultado = JsonConvert.DeserializeObject<_Descripciones>(_descripcion.RespuestaJSON);

                    ClaveVehicular = _resultado.Descripciones[0].AMIS;
                    if (_resultado.Descripciones[0].Pasajeros.Length > 0)
                    {
                        Ocupantes = int.Parse(_resultado.Descripciones[0].Pasajeros);
                    }
                }
                else
                {
                    log.Info("No se encontro vehiculo en el catalogo para cotizar.");
                    throw new Exception("No se encontro vehiculo para cotizar.");
                }
                CodigoPostal = ConveniosPaquetes.Empresa.Direccion.CodigoPostal;
                //if (conv.IdCatTipoContratante == 4 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 6)//Si es contratante Individual se pone el CP ingresado en la cotizacion.
                if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 2 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 6 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5)
                {
                    CodigoPostal = cotDet.CodigoPostal;
                }

                if (conv.ZonaCirculacion == 2)
                    CodigoPostal = conv.CodigoPostal.ToString();


                COTDG DatosGenerales = ConstruyeNodoDatosGenerales(conv, ref cotDet, ref fechaCotizacion);

                LOCALIZACIONESLOCALIZACION localizacion = ConsultarLocalizacionPorCP(token, CodigoPostal, conv);

                datosVehiculo.CVEVEH = ClaveVehicular; //Clave vehicular que nos regresa la aseguradora para cotizar
                datosVehiculo.MOD = cotDet.Año; //Modelo a cotizar
                datosVehiculo.PAQ = ConveniosPaquetes.PaqueteAseguradoras.FirstOrDefault(x => x.IdAseguradora == conv.IdAseguradora && x.IdCatTipoPaquete == IdTipoPaquete).Clave;
                datosVehiculo.EDO = localizacion.EDO;
                datosVehiculo.MUN = localizacion.MPO;
                datosVehiculo.SERV = "1";
                datosVehiculo.USO = "1";
                datosVehiculo.TDED = "1";
                datosVehiculo.PD = Math.Round(CRP.Descuento, 2).ToString(); //Porcentaje de descuento configurado en el convenio
                datosVehiculo.PB = "0";

                string tipoSumaAsegurada = "1";

                List<COTINCISOSINCISOCOBSCOB> listaCoberturas = new List<COTINCISOSINCISOCOBSCOB>();

                bool aplicaFactura = conv.optAplicarVF != null ? Convert.ToBoolean(conv.optAplicarVF) : false;

                if (aplicaFactura && cotDet.MontoFactura == 0)
                {
                    aplicaFactura = false;
                }

                List<ConvenioRamoPaquete> paquetes = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == conv.Id && x.IdCatRamoVehiculo == CRP.IdCatRamoVehiculo).ToList();
                List<Cobertura> lstcoberturas = db.Cobertura.ToList();
                string cve = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault().clave;

                CoberturasUtils utils = new CoberturasUtils();
                //List<string> extras = ConfigurationManager.AppSettings[aseguradora + "_Cobertura"].ToString().Split(',').ToList();
                List<string> extras = db.CatParametro.Where(x => x.Clave.Equals(aseguradora + "_Cobertura")).FirstOrDefault().Valor.Split(',').ToList();

                foreach (ConvenioRamoPaquete ConvenioRamo in paquetes)
                {
                    List<PaqueteDetalle> paquetesDetalles = db.PaqueteDetalle.Where(x => x.IdConvenioRamoPaquete == ConvenioRamo.Id && x.IdCatTipoPaquete == IdTipoPaquete && x.IdPaqueteConvenio == idPaqueteConvenio).ToList();
                    Coberturas = paquetesDetalles;
                    foreach (PaqueteDetalle paqDet in paquetesDetalles)
                    {
                        COTINCISOSINCISOCOBSCOB cobadd = new COTINCISOSINCISOCOBSCOB();
                        cobadd.COBID = lstcoberturas.Where(x => x.Id == paqDet.IdCobertura).FirstOrDefault().Clave;
                        // cobadd.COBID = db.Cobertura.Where(x => x.Id == paqDet.IdCobertura).Select(y => y.Clave).First();
                        cobadd.SUMAASEG = paqDet.SumaAsegurada;
                        cobadd.DPCT = paqDet.Deducible == 0 ? "0" : Math.Round((paqDet.Deducible / 100), 2).ToString();

                        if (cobadd.COBID.Equals(Cobertura.COBERTURA_CLAVE_GMOCUPANTES))
                        {
                            if (paqDet.SumaAsegurada.Length > 0)
                            {
                                if (paqDet.TipoSumaAsegurada > 0 && db.PaqueteDetalle.Where(x => x.Id == paqDet.Id).Select(y => y.TipoSumaAsegurada).First() == 19)
                                {
                                    cobadd.SUMAASEG = paqDet.SumaAsegurada.ToString();
                                }
                                else
                                {
                                    decimal val = decimal.Parse(paqDet.SumaAsegurada) * Ocupantes;
                                    cobadd.SUMAASEG = val.ToString();
                                }
                            }
                        }
                        else
                        {
                            if (cobadd.COBID.Equals(Cobertura.COBERTURA_CLAVE_ROBOTOTAL) || cobadd.COBID.Equals(Cobertura.COBERTURA_CLAVE_DANOSMATERIALES))
                            {
                                if (conv.optAplicarVF == 1 && cotDet.ValorFactura && cotDet.MontoFactura > 1)
                                {
                                    cobadd.SUMAASEG = cotDet.MontoFactura.ToString();
                                }
                            }
                        }
                        if (aplicaFactura && cobadd.COBID == "47")
                        {
                            cobadd.SUMAASEG = "0";
                            cobadd.DPCT = "0";
                        }

                        CatTipoSumaAsegVehiculo TipoSumAseg = db.CatTipoSumaAsegVehiculo.Where(x => x.Id == paqDet.TipoSumaAsegurada).FirstOrDefault();

                        //Extras

                        string existe = extras.Where(x => x.ToLowerInvariant().Contains(cobadd.COBID.ToLowerInvariant())).FirstOrDefault();

                        if (!string.IsNullOrEmpty(existe))
                        {
                            bool EsCondEspecial = utils.EsCondicionEsp(conv.Id, paqDet.IdCobertura.ToString(), ConvenioRamo.IdCatRamoVehiculo);

                            if (EsCondEspecial)
                            {
                                LocktonModel.xmls.Qualitas.Solicitud.NCoberturas CondicionEspecialAno = utils.EsCoberturaEspecialano(conv.Id, paqDet.IdCobertura.ToString(), cotDet.Año, cotDet.Marca, cotDet.Modelo,
                                paqDet.SumaAsegurada, paqDet.Deducible, TipoSumAseg.Clave, cve, ConvenioRamo.IdCatRamoVehiculo);

                                if (CondicionEspecialAno.Deducible != null)
                                {
                                    cobadd.SUMAASEG = CondicionEspecialAno.SumaAsegurada;
                                    cobadd.DPCT = CondicionEspecialAno.Deducible;
                                    listaCoberturas.Add(cobadd);
                                    continue;
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }

                        listaCoberturas.Add(cobadd);

                        if (cobadd.COBID.Equals(Cobertura.COBERTURA_CLAVE_ROBOTOTAL))
                        {
                            tipoSumaAsegurada = db.CatTipoSumaAsegVehiculo.FirstOrDefault(x => x.Id == paqDet.TipoSumaAsegurada).Clave;
                        }
                    }
                }

                if (aplicaFactura)
                {
                    datosVehiculo.TSA = "3";
                }
                else
                {
                    datosVehiculo.TSA = tipoSumaAsegurada;
                }

                datosVehiculo.COBS = listaCoberturas.ToArray();

                cotizacionIncisos.INCISO = new COTINCISOSINCISO[] { datosVehiculo };

                cotizacion.Items = new object[] { DatosGenerales, cotizacionIncisos };

                XmlizedString = ToXMLString<COT>(cotizacion);
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente para realizar tu cotizacion {0}", ex.Message));
                throw;
            }

            return XmlizedString;
        }


        public T ToObject<T>(string toDeserialize)
        {
            StringReader reader = new StringReader(toDeserialize);
            XmlSerializer xs = new XmlSerializer(typeof(T));
            T resultado = (T)xs.Deserialize(reader);
            reader.Close();
            return resultado;
        }
        #endregion


        #region Emision

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new System.NotImplementedException();
        }
        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
            string XmlizedString = string.Empty;
            string XmlizedRecepcion = string.Empty;
            log.Info("Inicia emision ABA");
            EmisionABA.Token token = new EmisionABA.Token();
            token.usuario = InfoEmision.Convenio.Usuario;
            token.password = InfoEmision.Convenio.Contrasena;
            CotizacionDetalle _cotizacionDetalle = db.CotizacionDetalle.Find(InfoEmision.IdCotizacion);
            Poliza poliza = new Poliza();
            PolizaDetalle polizadetalle = new PolizaDetalle();
            EmisionABA.ACEmisionClient Cliente = new EmisionABA.ACEmisionClient();
            var configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == InfoEmision.Empresa.Id);

            string strCliente = "";
            string Rfc = "";
            string TipoPersona = "";
            //4 --> Individual - 2 --> Flota Empleados (Datos fiscales Empleado)
            if (InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5)
            {
                if (InfoEmision.EmisionPersonaMoral)
                {
                    InfoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoral.Id);
                    InfoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoralRepresentanteLegal.Id);

                    strCliente = InfoEmision.PersonaMoral.RazonSocial;
                    Rfc = InfoEmision.PersonaMoral.RFC;
                    TipoPersona = "1";
                }
                else
                {
                    strCliente = string.Format("{0} {1} {2} {3}", InfoEmision.PrimerNombre, InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno);
                    Rfc = String.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC) ? LocktonServicios.Utilidades.Utilidades.CalcularRFC(InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno, InfoEmision.FechaNacimiento.ToString("dd/MM/yy")) : InfoEmision.DatosUsuario.RFC;
                    TipoPersona = "0";
                    if (!Utilidades.Utilidades.ValidaRFCHomoclave(Rfc))
                        return new EmisionPoliza(false, null, "Requerimos un RFC con homoclave para continuar con la emisión de tu auto.");

                }
            }
            //else if (InfoEmision.Convenio.IdCatTipoContratante.Equals(4) || InfoEmision.Convenio.IdCatTipoContratante.Equals(2))
            else if (configuracionEmpresa.IdTipoDeNegocio == 2)
            {
                strCliente = string.Format("{0} {1} {2} {3}", InfoEmision.PrimerNombre, InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno);
                Rfc = String.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC) ? LocktonServicios.Utilidades.Utilidades.CalcularRFC(InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno, InfoEmision.FechaNacimiento.ToString("dd/MM/yy")) : InfoEmision.DatosUsuario.RFC;
                TipoPersona = "0";
                if (!Utilidades.Utilidades.ValidaRFCHomoclave(Rfc))
                    return new EmisionPoliza(false, null, "Requerimos un RFC con homoclave para continuar con la emisión de tu auto.");

            }
            else
            {
                strCliente = InfoEmision.Empresa.RazonSocial;
                Rfc = InfoEmision.Empresa.RFC;
                TipoPersona = "1";
            }

            PersonaABA persona;
            PersonaABA personaProp;

            try
            {
                log.Info("alta persona  ABA");

                persona = AltaPersonaABA(InfoEmision, InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena, strCliente, Rfc, TipoPersona);
                log.Info("fin alta persona  ABA");

                EMI emision = new EMI();
                emision.COTID = _cotizacionDetalle.ClaveCotizacion;
                emision.VERID = _cotizacionDetalle.ClaveVersion;

                EMIINCISOSINCISO inciso = new EMIINCISOSINCISO();
                inciso.COTINCID = _cotizacionDetalle.ClaveIncisoCot;
                inciso.VERINCID = _cotizacionDetalle.ClaveIncisoVer;
                EMIINCISOSINCISODE detalle = new EMIINCISOSINCISODE();

                if (InfoEmision.EmisionPersonaMoral)
                {
                    if (InfoEmision.ConductorHabitual || string.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC))
                    {
                        detalle.ASEGID = persona.personaId;
                        detalle.ASEGDIRID = persona.direccionId;
                        detalle.ASEGTRANID = persona.transaccionId;
                        detalle.PROPID = persona.personaId;
                        detalle.PROPDIRID = persona.direccionId;
                        detalle.PROPTRANID = persona.transaccionId;
                    }
                    else
                    {
                        if (!Utilidades.Utilidades.ValidaRFCHomoclave(InfoEmision.DatosUsuario.RFC))
                            return new EmisionPoliza(false, null, "Requerimos un RFC con homoclave para continuar con la emisión de tu auto.");

                        personaProp = altaPropietarioContratanteABA(InfoEmision, InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena, "0");

                        detalle.ASEGID = persona.personaId;
                        detalle.ASEGDIRID = persona.direccionId;
                        detalle.ASEGTRANID = persona.transaccionId;
                        detalle.PROPID = personaProp.personaId;
                        detalle.PROPDIRID = personaProp.direccionId;
                        detalle.PROPTRANID = personaProp.transaccionId;
                    }
                }
                else
                {
                    //if (InfoEmision.Convenio.IdCatTipoContratante.Equals(4)
                    //  || InfoEmision.Convenio.IdCatTipoContratante.Equals(2))
                    if (configuracionEmpresa.IdTipoDeNegocio == 2)
                    {
                        detalle.ASEGID = persona.personaId;
                        detalle.ASEGDIRID = persona.direccionId;
                        detalle.ASEGTRANID = persona.transaccionId;
                        detalle.PROPID = persona.personaId;
                        detalle.PROPDIRID = persona.direccionId;
                        detalle.PROPTRANID = persona.transaccionId;
                    }
                    else
                    {
                        if(string.IsNullOrEmpty(InfoEmision.DatosUsuario.RFC))
                        {
                            detalle.ASEGID = persona.personaId;
                            detalle.ASEGDIRID = persona.direccionId;
                            detalle.ASEGTRANID = persona.transaccionId;
                            detalle.PROPID = persona.personaId;
                            detalle.PROPDIRID = persona.direccionId;
                            detalle.PROPTRANID = persona.transaccionId;
                        }
                        else
                        {
                            if (!Utilidades.Utilidades.ValidaRFCHomoclave(InfoEmision.DatosUsuario.RFC))
                                return new EmisionPoliza(false, null, "Requerimos un RFC con homoclave para continuar con la emisión de tu auto.");

                            personaProp = altaPropietarioContratanteABA(InfoEmision, InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena, "0");

                            detalle.ASEGID = persona.personaId;
                            detalle.ASEGDIRID = persona.direccionId;
                            detalle.ASEGTRANID = persona.transaccionId;
                            detalle.PROPID = personaProp.personaId;
                            detalle.PROPDIRID = personaProp.direccionId;
                            detalle.PROPTRANID = personaProp.transaccionId;
                        }                      
                    }
                }

                inciso.REF = string.IsNullOrEmpty(InfoEmision.Convenio.Referencia1)? string.IsNullOrEmpty(InfoEmision.DetalleUsuario.IdEmpleado) ? "0" : InfoEmision.DetalleUsuario.IdEmpleado:InfoEmision.Convenio.Referencia1;

                inciso.DE = new EMIINCISOSINCISODE[] { detalle };

                inciso.SERIE = InfoEmision.NumeroSerie.ToUpper();
                inciso.MOTOR = InfoEmision.NumeroMotor.ToUpper();
                inciso.PLACAS = InfoEmision.Placas.ToUpper();

                emision.INCISOS = new EMIINCISOSINCISO[] { inciso };

                if (InfoEmision.RequiereFactura)
                {
                    FACTURANTE facturante = new FACTURANTE();
                    FACTURACION facturacion = new FACTURACION();
                    var _facturacion = new Facturacion();
                    //facturante.PERSONAID = persona.personaId;
                    //facturante.PERSONATRANID = persona.transaccionId;
                    //facturante.DIRECCIONID = persona.direccionId;
                    facturante.PERSONAID = "0";
                    facturante.PERSONATRANID = "0";
                    facturante.DIRECCIONID = "0";
                    facturante.DIRECCIONTRANID = "0";
                    facturante.EMAILCOMPLEMENTOPAGO = InfoEmision.Email;
                    facturante.COMENTARIOS = $"Serie {InfoEmision.NumeroSerie}";
                    facturante.ORDENCOMPRA = "Alta inicial";
                    facturacion.TIPOFACTURACIONID = "1";

                    if (TipoPersona == "1")
                    {
                        facturante.REGIMENFISCALSATID = InfoEmision.Empresa.IdRegimenFiscal ?? 1;
                        facturante.USOCFDI = InfoEmision.Empresa.IdUsoCFDI ?? 1;
                        facturante.CP = InfoEmision.Empresa.Direccion.CodigoPostal;

                        //facturacion.TIPOFACTURACIONID = "2";
                    }
                    else
                    {
                        facturante.REGIMENFISCALSATID = InfoEmision.IdRegimenFiscal;
                        facturante.USOCFDI = InfoEmision.IdUsoCFDI;
                        facturante.CP = InfoEmision.DatosUsuario.Direccion.CodigoPostal;


                    }

                    facturacion.FACTURANTES = new FACTURANTE[] { facturante };

                    emision.FACTURACION = facturacion;

                    _facturacion.RFC = Rfc;
                    _facturacion.Nombre = strCliente;
                    _facturacion.CodigoPostal = facturante.CP;
                    _facturacion.IdRegimenFiscal = facturante.REGIMENFISCALSATID;
                    _facturacion.IdUsoCFDI = facturante.USOCFDI;

                    Utilidades.Utilidades.GeneraRegistroFacturacion(_facturacion);

                }

                XmlizedString = ToXMLString<EMI>(emision);
                //XmlizedString = "<EMI><COTID>75230274</COTID><VERID>75596245</VERID><INCISOS><INCISO><COTINCID>121922624</COTINCID><VERINCID>75596245</VERINCID><DE><ASEGID>2018297304</ASEGID><ASEGDIRID>2018391545</ASEGDIRID><ASEGTRANID>55870171</ASEGTRANID><PROPID>2018297304</PROPID><PROPDIRID>2018391545</PROPDIRID><PROPTRANID>55870171</PROPTRANID></DE><SERIE>MNNBVCASDFG234567</SERIE><REF>16140</REF><MOTOR>heCHO PARA PRUEBAS</MOTOR><PLACAS>PERMISO</PLACAS></INCISO></INCISOS></EMI>";
                string resultado = "";
                log.Info(string.Format("Xml emision Envio: {0}", XmlizedString.Replace("\n", "").Replace("\r", "")));
                polizadetalle.XMLSolicitud = XmlizedString;
                resultado = Cliente.EmitePoliza(token, XmlizedString);
                log.Info(string.Format("Xml emision Respuesta: {0}", resultado.Replace("\n", "").Replace("\r", "")));
                polizadetalle.XMLRecepcion = resultado.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                XmlizedRecepcion = polizadetalle.XMLRecepcion;
                com.lockton.xml.aba.emision.response.EMI emisionResultado = ToObject<com.lockton.xml.aba.emision.response.EMI>(resultado);
                com.lockton.xml.aba.emision.response.POL polizaEmitidaABA = emisionResultado.Poliza;
                com.lockton.xml.aba.emision.response.POLPRIMA polizaPrmasABA = polizaEmitidaABA.PRIMA;

                polizadetalle.Derechos = decimal.Parse(polizaPrmasABA.DER, CultureInfo.InvariantCulture);
                polizadetalle.Recargos = decimal.Parse(polizaPrmasABA.REC, CultureInfo.InvariantCulture);
                polizadetalle.Impuesto = decimal.Parse(polizaPrmasABA.IVA, CultureInfo.InvariantCulture);

                poliza = GuardaPoliza(poliza, polizaEmitidaABA, polizaPrmasABA, InfoEmision, _cotizacionDetalle, polizadetalle, TipoPersona);

                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, XmlizedRecepcion, "", "Emisión");

                Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                return new EmisionPoliza(true, poliza.PolizaDetalle.First().XMLSolicitud, poliza.PolizaDetalle.First().XMLRecepcion, poliza);
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Error al emitir Chubb : {0}", ex.Message));
                Regex reg = new Regex("[*'\",_&#^@]");
                string mensaje = reg.Replace(ex.Message, string.Empty).Replace("\r\n", string.Empty);

                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, XmlizedRecepcion, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");

                return new EmisionPoliza(false, null, mensaje);
            }
        }


        private Poliza GuardaPoliza(Poliza poliza, com.lockton.xml.aba.emision.response.POL polizaEmitidaABA, com.lockton.xml.aba.emision.response.POLPRIMA polizaPrmasABA, InformacionEmision InfoEmision, CotizacionDetalle _cotizacionDetalle, PolizaDetalle polizaDet, string tipoContribuyente)
        {
            log.Info("Comienza guardado de poliza Chubb");


            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            Cotizacion Cotizacion = db.Cotizacion.Where(x => x.Id == InfoEmision.IdCotizacion).FirstOrDefault();
            int paquete = int.Parse(_cotizacionDetalle.Paquete);
            string medioPago = InfoEmision.CotizacionAutoGuardar.MediodePago.ToString();
            string formaPago = InfoEmision.CotizacionAutoGuardar.FormadePago.ToString();
            string Solicitud = _cotizacionDetalle.XMLSolicitud;
            com.lockton.xml.aba.cotizacion.request.COT cotSol = ToObject<com.lockton.xml.aba.cotizacion.request.COT>(Solicitud);
            com.lockton.xml.aba.cotizacion.request.COTDG cot = (COTDG)cotSol.Items[0];
            string Recepcion = _cotizacionDetalle.XMLRecepcion;
            LocktonServicios.aba.cotizacion.response.COT cotResult = ToObject<LocktonServicios.aba.cotizacion.response.COT>(Recepcion);

            try
            {
                poliza.NumeroPoliza = String.Format("{0}{1}", polizaEmitidaABA.CVE, polizaEmitidaABA.POL1);
                poliza.PrimaNeta = decimal.Parse(polizaPrmasABA.PNETA, CultureInfo.InvariantCulture);
                poliza.PrimaTotal = decimal.Parse(polizaPrmasABA.PTOTAL, CultureInfo.InvariantCulture);
                poliza.Motor = InfoEmision.NumeroMotor;
                poliza.Serie = InfoEmision.NumeroSerie;
                poliza.Placas = InfoEmision.Placas;
                poliza.FinVigencia = Convert.ToDateTime(cot.FINVIG);
                poliza.InicioVigencia = Convert.ToDateTime(cot.INIVIG);
                poliza.FechaEmision = DateTime.Now;
                poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                poliza.UrlPDFPoliza = "";
                poliza.UrlPDFRecibos = "";
                poliza.Estatus = 20;
                poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                poliza.IdTipoCobertura = paquete;
                poliza.IdConvenio = InfoEmision.Convenio.Id;
                poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                poliza.Acepto_DescuentoPoliza = true;

                polizaDet.Inciso = "1";
                polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para ABA Chubb.
                polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                polizaDet.Deducible = 0;
                polizaDet.Comision = 0;
                polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
                polizaDet.MigraOPERA = false;
                polizaDet.UrlPDFPolizaOPERA = "";
                polizaDet.PolizaOPERA = 0;
                polizaDet.OTOpera = 0;
                polizaDet.EndosoOPERA = 0;
                polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                polizaDet.IdCotizacionDetalle = _cotizacionDetalle.Id;
                polizaDet.IdCatRamoVehiculo = _cotizacionDetalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                polizaDet.IdCatModalidadFormaPago = db.CatModalidadFormaPago.Where(x => x.Clave.Equals(medioPago)).FirstOrDefault().Id;
                polizaDet.IdCatPeriodicidadFormaPago = db.CatPeriodicidadFormaPago.Where(x => x.Clave.Equals(formaPago)).FirstOrDefault().Id;
                if (InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5)
                {
                    if (InfoEmision.EmisionPersonaMoral)
                    {
                        poliza.IdPersonaMoral = InfoEmision.PersonaMoral.Id;
                        poliza.IdRepresentanteLegal = InfoEmision.PersonaMoralRepresentanteLegal.Id;
                        polizaDet.IdDireccion = InfoEmision.PersonaMoral.IdDireccion.Value;
                    }
                    else
                        polizaDet.IdDireccion = InfoEmision.Empresa.IdDireccion.Value;
                }
                else if (!InfoEmision.EsFlotilla)
                {
                    polizaDet.IdDireccion = ConstruyeDireccion(InfoEmision).Id;
                }
                else
                {
                    polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;
                }

                Endoso endosoAlta = new Endoso();
                endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                endosoAlta.Fecha = DateTime.Now;
                endosoAlta.ValorAnterior = "Alta";
                endosoAlta.ValorActual = "Contratación";

                foreach (LocktonServicios.aba.cotizacion.response.COTINCISOSINCISO incisosResultado in cotResult.INCISOS)
                {
                    _cotizacionDetalle.ClaveIncisoCot = incisosResultado.COTINCID;
                    _cotizacionDetalle.ClaveIncisoVer = incisosResultado.VERINCID;
                    List<Recibo> recibosGenerados = new List<Recibo>();
                    int conteoRecibos = 1;
                    foreach (LocktonServicios.aba.cotizacion.response.COTINCISOSINCISORECIBOSRECIBO reciboABA in incisosResultado.RECIBOS)
                    {
                        Recibo reciboSave = new Recibo();
                        reciboSave.Numero = conteoRecibos;
                        reciboSave.NoAsegurado = reciboABA.NUM;
                        reciboSave.PrimaNeta = decimal.Parse(reciboABA.PNETA, CultureInfo.InvariantCulture);
                        reciboSave.PrimaTotal = decimal.Parse(reciboABA.PTOTAL, CultureInfo.InvariantCulture);
                        reciboSave.Recargo = decimal.Parse(reciboABA.REC, CultureInfo.InvariantCulture);
                        reciboSave.InicioVigencia = DateTime.ParseExact(reciboABA.INIVIG, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        reciboSave.FinVigencia = DateTime.ParseExact(reciboABA.FINVIG, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                        reciboSave.Impuesto = decimal.Parse(reciboABA.IVA, CultureInfo.InvariantCulture);
                        reciboSave.Comision = 0;
                        reciboSave.Derecho = decimal.Parse(reciboABA.DER, CultureInfo.InvariantCulture);
                        endosoAlta.Recibo.Add(reciboSave);
                        conteoRecibos++;
                    }
                }

                if (InfoEmision.IdMSI.HasValue)
                    polizaDet.IdMSI = InfoEmision.IdMSI;

                poliza.Endoso.Add(endosoAlta);
                poliza.PolizaDetalle.Add(polizaDet);
                db.Poliza.Add(poliza);
                db.SaveChanges();

                //Thread T1 = new Thread(delegate ()
                //{
                var modalidad = db.ModalidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidad == perioricidad.IdCatPeriodicidad && x.IdCatModalidadFormaPago == polizaDet.IdCatModalidadFormaPago).FirstOrDefault();
                var recibosPDF = modalidad.ImprimirRecibos;
                poliza.UrlPDFPoliza = ReimprimePoliza(poliza.NumeroPoliza, InfoEmision.Convenio.NumeroNegocio, perioricidad.ClaveAgente, InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena, tipoContribuyente, recibosPDF);
                if (poliza.UrlPDFPoliza != "")
                {
                    db.Entry(poliza).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                }
                //});
                //T1.Start();


                log.Info(string.Format("El numero de poliza {0} se guardo correctamente con el ID: {1}", poliza.NumeroPoliza, poliza.Id));
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un erro con el guardado de la poliza: {0}", ex.Message));
                throw;
            }
            return poliza;
        }


        private Direccion ConstruyeDireccion(InformacionEmision infoEmision)
        {
            Direccion direccion = new Direccion();
            try
            {
                log.Info("Inicia mapeo de datos para la dirección que ingresó el usuario.");
                direccion.Calle = infoEmision.DatosUsuario.Direccion.Calle;
                direccion.NumeroExt = infoEmision.DatosUsuario.Direccion.NumeroExt;
                direccion.NumeroInt = infoEmision.DatosUsuario.Direccion.NumeroInt;
                direccion.Colonia = infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
                direccion.Estado = infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Estado;
                direccion.Municipio = infoEmision.DatosUsuario.Direccion.Municipio;
                direccion.CodigoPostal = infoEmision.DatosUsuario.Direccion.CodigoPostal;
                direccion.IdEstado = null;
                direccion.IdMunicipio = null;
                direccion.IdColonia = null;
                direccion.IdCatEstadosRepublica = infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Id;
                direccion.IdCodigoPostal = infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Id;

                db.Direccion.Add(direccion);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                log.Info(string.Concat("Se presentó el siguiente error: ", ex.Message));
            }
            return direccion;
        }
        private PersonaABA AltaPersonaABA(InformacionEmision InfoEmision, string UsuarioWS, string PasswordWS, string strCliente, string Rfc, string TipoPersona)
        {
            PersonaABA resultadoBuscaPersona = null;
            try
            {
                PersonaRegistroABA.PCRegistroClient cliente = new PersonaRegistroABA.PCRegistroClient();

                string codigoPostal = "";
                string PersonaIdEmpresa = string.IsNullOrEmpty(InfoEmision.Convenio.PersonaNoEmpresa) ? "" : InfoEmision.Convenio.PersonaNoEmpresa;
                Direccion Dir = new Direccion();
                if (TipoPersona == "0")
                {
                    if (InfoEmision.EsFlotilla)
                    {
                        codigoPostal = InfoEmision.Empresa.Direccion.CodigoPostal;
                        Dir = InfoEmision.Empresa.Direccion;
                    }
                    else
                    {
                        codigoPostal = InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                        Dir = InfoEmision.DatosUsuario.Direccion;
                    }
                }
                else
                {
                    if (InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5)
                    {
                        codigoPostal = InfoEmision.PersonaMoral.Direccion.CodigoPostal;
                        Dir = InfoEmision.PersonaMoral.Direccion;
                    }
                    else
                    {
                        codigoPostal = InfoEmision.Empresa.Direccion.CodigoPostal;
                        Dir = InfoEmision.Empresa.Direccion;
                    }

                }



                resultadoBuscaPersona = buscaPersonaAbaCP(Rfc, TipoPersona, UsuarioWS, PasswordWS, strCliente, codigoPostal, Dir, PersonaIdEmpresa);
                if (resultadoBuscaPersona != null)
                {
                    return resultadoBuscaPersona;
                }


                PersonaRegistroABA.Token token = new PersonaRegistroABA.Token();
                token.usuario = UsuarioWS;
                token.password = PasswordWS;

                //Llena los datos del contratante
                DP dp = new DP();
                dp.TP = TipoPersona;
                //Persona fisica
                if (dp.TP == "0")
                {
                    dp.FISICA = new DPFISICA();
                    if (Rfc.Length > 10)
                    {
                        dp.FISICA.RFC = Rfc.Substring(0, Rfc.Length - 3);
                        dp.FISICA.HCVE = Rfc.Substring(Rfc.Length - 3, 3);
                    }
                    else
                    {
                        dp.FISICA.RFC = Rfc;
                        dp.FISICA.HCVE = "";
                    }
                    dp.FISICA.PNOM = InfoEmision.PrimerNombre;
                    dp.FISICA.SNOM = InfoEmision.SegundoNombre;
                    dp.FISICA.APP = InfoEmision.ApellidoPaterno;
                    dp.FISICA.APM = InfoEmision.ApellidoMaterno;
                    dp.FISICA.SEXO = "1";
                    dp.FISICA.EDOCIVIL = "2";

                    //dp.MORAL = new DPMORAL();
                    //dp.MORAL.RFC = "";
                    //dp.MORAL.HCVE = "";
                    //dp.MORAL.RS = "";
                    //dp.MORAL.NOMCOM = "";
                    //dp.MORAL.GIRO = "1";
                    //dp.MORAL.REGIMEN = "false";
                    //dp.MORAL.TS = "0";

                    if (InfoEmision.EsFlotilla)
                    {
                        dp.DOMICILIO = new DPDOMICILIO();
                        dp.DOMICILIO.TIPODIR = "1";

                        dp.DOMICILIO.CALLE = InfoEmision.Empresa.Direccion.Calle;
                        dp.DOMICILIO.NUMEXT = InfoEmision.Empresa.Direccion.NumeroExt ?? "0";
                        dp.DOMICILIO.NUMINT = InfoEmision.Empresa.Direccion.NumeroInt ?? "0";
                        dp.DOMICILIO.COL = InfoEmision.Empresa.Direccion.Colonia;
                        dp.DOMICILIO.CP = codigoPostal;
                        dp.DOMICILIO.POB = InfoEmision.Empresa.Direccion.Municipio;
                    }
                    else
                    {
                        dp.DOMICILIO = new DPDOMICILIO();
                        dp.DOMICILIO.TIPODIR = "1";
                        dp.DOMICILIO.CALLE = InfoEmision.DatosUsuario.Direccion.Calle;
                        dp.DOMICILIO.NUMEXT = InfoEmision.DatosUsuario.Direccion.NumeroExt ?? "0";
                        dp.DOMICILIO.NUMINT = InfoEmision.DatosUsuario.Direccion.NumeroInt ?? "0";
                        //dp.DOMICILIO.COL = InfoEmision.Direccion.Colonia;
                        dp.DOMICILIO.COL = db.CatCodigoPostal.Where(x => x.Id.Equals(InfoEmision.IdAsentamiento)).FirstOrDefault().Asentamiento.ToString();
                        dp.DOMICILIO.CP = codigoPostal;
                        dp.DOMICILIO.POB = InfoEmision.DatosUsuario.Direccion.Municipio;
                    }

                    dp.TELEFONO = new DPTELEFONO();
                    dp.TELEFONO.LADA = string.IsNullOrEmpty(InfoEmision.TelefonoFijo) ? string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "" : InfoEmision.TelefonoCel.Substring(0, 2) : InfoEmision.TelefonoFijo.Substring(0, 2);
                    dp.TELEFONO.NUMERO = string.IsNullOrEmpty(InfoEmision.TelefonoFijo) ? string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "" : InfoEmision.TelefonoCel.Substring(2, 8) : InfoEmision.TelefonoFijo.Substring(2, 8);
                    dp.CELULAR = new DPCELULAR();
                    dp.CELULAR.LADA = string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "" : InfoEmision.TelefonoCel.Substring(0, 2);
                    dp.CELULAR.NUMERO = string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "" : InfoEmision.TelefonoCel.Substring(2, 8);
                    dp.CORREO = InfoEmision.ConfirmaEmail;
                }
                else
                {
                    dp.MORAL = new DPMORAL();
                    if (InfoEmision.IdTipoDeNegocio == 6 || InfoEmision.IdTipoDeNegocio == 5)
                    {
                        if (InfoEmision.PersonaMoral.RFC.Length > 10)
                        {
                            dp.MORAL.RFC = InfoEmision.PersonaMoral.RFC.Substring(0, InfoEmision.PersonaMoral.RFC.Length - 3);
                            dp.MORAL.HCVE = InfoEmision.PersonaMoral.RFC.Substring(InfoEmision.PersonaMoral.RFC.Length - 3, 3);
                        }
                        else
                        {
                            dp.MORAL.RFC = InfoEmision.PersonaMoral.RFC;
                            dp.MORAL.HCVE = "";
                        }

                        dp.MORAL.NOMCOM = InfoEmision.PersonaMoral.NombreComercial;
                        dp.MORAL.RS = InfoEmision.PersonaMoral.RazonSocial;

                        dp.MORAL.GIRO = "1";
                        dp.MORAL.REGIMEN = "false";
                        dp.MORAL.TS = "0";

                        dp.DOMICILIO = new DPDOMICILIO();
                        dp.DOMICILIO.TIPODIR = "1";

                        dp.DOMICILIO.CALLE = InfoEmision.PersonaMoral.Direccion.Calle;
                        dp.DOMICILIO.NUMEXT = InfoEmision.PersonaMoral.Direccion.NumeroExt ?? "0";
                        dp.DOMICILIO.NUMINT = InfoEmision.PersonaMoral.Direccion.NumeroInt ?? "0";
                        dp.DOMICILIO.COL = InfoEmision.PersonaMoral.Direccion.Colonia;
                        dp.DOMICILIO.CP = codigoPostal;
                        dp.DOMICILIO.POB = InfoEmision.PersonaMoral.Direccion.Municipio;

                        dp.TELEFONO = new DPTELEFONO();
                        dp.TELEFONO.LADA = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(0, 2);
                        dp.TELEFONO.NUMERO = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(2, 8);

                        dp.CELULAR = new DPCELULAR();
                        dp.CELULAR.LADA = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(0, 2);
                        dp.CELULAR.NUMERO = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(2, 8);

                        dp.CORREO = "";
                    }
                    else
                    {
                        if (InfoEmision.Empresa.RFC.Length > 10)
                        {
                            dp.MORAL.RFC = InfoEmision.Empresa.RFC.Substring(0, InfoEmision.Empresa.RFC.Length - 3);
                            dp.MORAL.HCVE = InfoEmision.Empresa.RFC.Substring(InfoEmision.Empresa.RFC.Length - 3, 3);
                        }
                        else
                        {
                            dp.MORAL.RFC = InfoEmision.Empresa.RFC;
                            dp.MORAL.HCVE = "";
                        }

                        dp.MORAL.NOMCOM = InfoEmision.Empresa.NombreComercial;
                        dp.MORAL.RS = InfoEmision.Empresa.RazonSocial;

                        dp.MORAL.GIRO = "1";
                        dp.MORAL.REGIMEN = "false";
                        dp.MORAL.TS = "0";

                        dp.DOMICILIO = new DPDOMICILIO();
                        dp.DOMICILIO.TIPODIR = "1";

                        dp.DOMICILIO.CALLE = InfoEmision.Empresa.Direccion.Calle;
                        dp.DOMICILIO.NUMEXT = InfoEmision.Empresa.Direccion.NumeroExt ?? "0";
                        dp.DOMICILIO.NUMINT = InfoEmision.Empresa.Direccion.NumeroInt ?? "0";
                        dp.DOMICILIO.COL = InfoEmision.Empresa.Direccion.Colonia;
                        dp.DOMICILIO.CP = codigoPostal;
                        dp.DOMICILIO.POB = InfoEmision.Empresa.Direccion.Municipio;

                        dp.TELEFONO = new DPTELEFONO();
                        dp.TELEFONO.LADA = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(0, 2);
                        dp.TELEFONO.NUMERO = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(2, 8);

                        dp.CELULAR = new DPCELULAR();
                        dp.CELULAR.LADA = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(0, 2);
                        dp.CELULAR.NUMERO = string.IsNullOrEmpty(InfoEmision.Empresa.TelefonoGral) ? "" : InfoEmision.Empresa.TelefonoGral.Substring(2, 8);

                        dp.CORREO = "";
                    }
                }


                string XmlizedString = ToXMLString<DP>(dp);
                log.Info("Envio RegistraPersona " + InfoEmision.Empresa.IdCatTipoPersona.ToString() + ": " + XmlizedString.Replace("\n", "").Replace("\r", ""));
                string respuesta = cliente.RegistraPersona(token, "<XML>" + XmlizedString + "</XML>");
                log.Info("respuesta dp xml" + respuesta.Replace("\n", "").Replace("\r", ""));
                resultadoBuscaPersona = new PersonaABA();
                com.lockton.xml.aba.persona.response.RESULTADO personaResult = ToObject<com.lockton.xml.aba.persona.response.RESULTADO>(respuesta);
                foreach (object item in personaResult.Items)
                {
                    if (item is com.lockton.xml.aba.persona.response.RESULTADOPERSONA)
                    {
                        resultadoBuscaPersona.personaId = ((com.lockton.xml.aba.persona.response.RESULTADOPERSONA)item).TPID;
                    }
                    if (item is com.lockton.xml.aba.persona.response.RESULTADOTRANSACCION)
                    {
                        resultadoBuscaPersona.transaccionId = ((com.lockton.xml.aba.persona.response.RESULTADOTRANSACCION)item).TRANID;
                    }
                    if (item is com.lockton.xml.aba.persona.response.RESULTADODIRECCION)
                    {
                        resultadoBuscaPersona.direccionId = ((com.lockton.xml.aba.persona.response.RESULTADODIRECCION)item).TDIRID;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error("Error altaPersonaABA " + ex.Message, ex);
                throw new Exception(ex.Message);
            }
            return resultadoBuscaPersona;
        }


        /// <summary>
        /// busca a una persona por el RFC
        /// TODO: hacer pruebas con y sin homoclave
        /// </summary>
        /// <param name="rfc"></param>
        /// <param name="tipocontribuyenteClave"></param>
        /// <param name="paqueteConvenio"></param>
        /// <returns></returns>
        public PersonaABA buscaPersonaAba(string rfc, string tipocontribuyenteClave, string UsuarioWS, string PasswordWS, string strBuscoNombre)
        {
            try
            {
                XML xmlSend = new XML();
                xmlSend.Item = new XMLDP();

                if (rfc.Length > 10)
                {
                    log.Info("xmlSend.Item.RFC =>" + xmlSend.Item.RFC);
                    xmlSend.Item.RFC = rfc.Substring(0, rfc.Length - 3);
                    xmlSend.Item.HCVE = rfc.Substring(rfc.Length - 3, 3);
                }
                else
                {
                    xmlSend.Item.RFC = rfc;
                }
                xmlSend.Item.TP = tipocontribuyenteClave;
                string xmlBuscaPersona = ToXMLString<XML>(xmlSend);
                log.Info("Envio buscaPersonaAba dp xml: " + xmlBuscaPersona);

                ConsultasABA.PCConsultasClient clienteBuscaAsegurado = new ConsultasABA.PCConsultasClient();

                ConsultasABA.Token tokenConsulta = new ConsultasABA.Token();

                tokenConsulta.usuario = UsuarioWS;
                tokenConsulta.password = PasswordWS;

                string resultado = clienteBuscaAsegurado.ConsultaPersonas(tokenConsulta, xmlBuscaPersona);
                log.Info("Resultado WS buscaPersonaAba dp xmlABA: " + resultado);

                PERSONAS personas = ToObject<PERSONAS>(resultado);
                if (personas.Items != null)
                {
                    foreach (PERSONASPERSONA perResponse in personas.Items)
                    {
                        string rfcABA = perResponse.RFC.Trim().ToUpper() + perResponse.HCVE.Trim().ToUpper();
                        PersonaABA personaABA = new PersonaABA();
                        //if (strBuscoNombre == "" || perResponse.NOMBRE.Replace(" ", "").ToUpper().Contains(strBuscoNombre.Replace(" ", "").ToUpper()))
                        if (rfc.Trim().ToUpper() == rfcABA)
                        {
                            personaABA.personaId = perResponse.PID;
                            string buscaDireccion = String.Format("<XML><DP><TP>{0}</TP><PID>{1}</PID></DP></XML>", xmlSend.Item.TP, personaABA.personaId);
                            log.Info("buscaDireccion  ABA" + buscaDireccion);
                            string resultadoBuscaDireccion = clienteBuscaAsegurado.ConsultaDireccionesPersona(tokenConsulta, buscaDireccion);
                            log.Info("resultadoBuscaDireccion  ABA" + resultadoBuscaDireccion);
                            RESULTADO direccion = ToObject<RESULTADO>(resultadoBuscaDireccion);
                            foreach (object resObj in direccion.Items)
                            {
                                if (resObj is RESULTADODIRECCIONES)
                                {
                                    personaABA.direccionId = ((RESULTADODIRECCIONES)resObj).DIR.LastOrDefault().DIRID;
                                }
                            }
                            return personaABA;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error en buscaPersonaAba " + ex.Message, ex);
                //throw new Exception(ex.Message);
            }
            return null;
        }

        /// <summary>
        /// busca a una persona por el RFC
        /// TODO: hacer pruebas con y sin homoclave
        /// </summary>
        /// <param name="rfc"></param>
        /// <param name="tipocontribuyenteClave"></param>
        /// <param name="paqueteConvenio"></param>
        /// <returns></returns>
        public PersonaABA buscaPersonaAbaCP(string rfc, string tipocontribuyenteClave, string UsuarioWS, string PasswordWS, string strBuscoNombre, string CP, Direccion direccionEmpleado, string PersonaIdEmpresa)
        {
            PersonaRegistroABA.PCRegistroClient cliente = new PersonaRegistroABA.PCRegistroClient();
            try
            {
                XML xmlSend = new XML();
                xmlSend.Item = new XMLDP();

                if (rfc.Length > 10)
                {
                    log.Info("xmlSend.Item.RFC =>" + xmlSend.Item.RFC);
                    xmlSend.Item.RFC = rfc.Substring(0, rfc.Length - 3);
                    xmlSend.Item.HCVE = rfc.Substring(rfc.Length - 3, 3);
                }
                else
                {
                    xmlSend.Item.RFC = rfc;
                }
                xmlSend.Item.TP = tipocontribuyenteClave;
                ConsultasABA.PCConsultasClient clienteBuscaAsegurado = new ConsultasABA.PCConsultasClient();
                ConsultasABA.Token tokenConsulta = new ConsultasABA.Token();

                tokenConsulta.usuario = UsuarioWS;
                tokenConsulta.password = PasswordWS;

                if (!string.IsNullOrEmpty(PersonaIdEmpresa) && tipocontribuyenteClave == "1")
                {
                    PersonaABA personaABA = new PersonaABA();
                    personaABA.personaId = PersonaIdEmpresa;
                    string buscaDireccion = String.Format("<XML><DP><TP>{0}</TP><PID>{1}</PID></DP></XML>", xmlSend.Item.TP, personaABA.personaId);
                    log.Info("buscaDireccion  ABA" + buscaDireccion);
                    string resultadoBuscaDireccion = clienteBuscaAsegurado.ConsultaDireccionesPersona(tokenConsulta, buscaDireccion);
                    log.Info("resultadoBuscaDireccion  ABA" + resultadoBuscaDireccion);
                    RESULTADO direccion = ToObject<RESULTADO>(resultadoBuscaDireccion);
                    string _codigoPostalABA = "";
                    foreach (object resObj in direccion.Items)
                    {
                        if (resObj is RESULTADODIRECCIONES)
                        {

                            _codigoPostalABA = ((RESULTADODIRECCIONES)resObj).DIR.LastOrDefault().CP;
                            _codigoPostalABA = _codigoPostalABA.PadLeft(5, '0');
                            personaABA.direccionId = ((RESULTADODIRECCIONES)resObj).DIR.LastOrDefault().DIRID;
                        }
                        if (resObj is RESULTADOTRANSACCION)
                        {
                            personaABA.transaccionId = ((RESULTADOTRANSACCION)resObj).TRANID;
                        }
                    }
                    if (_codigoPostalABA.Trim() == CP.Trim())
                        return personaABA;
                    else
                    {
                        //Si no existe esa direccion se da de alta.
                        if (personaABA.personaId != null)
                        {
                            PersonaRegistroABA.Token token = new PersonaRegistroABA.Token();
                            token.usuario = UsuarioWS;
                            token.password = PasswordWS;

                            string result = cliente.RegistraDireccionPersona(token, GeneraXmlRegistroDireccionPersona(direccionEmpleado, personaABA.personaId, tipocontribuyenteClave));

                            com.lockton.xml.aba.registro.direcciones.RESULTADO direccionNueva = ToObject<com.lockton.xml.aba.registro.direcciones.RESULTADO>(result);
                            personaABA.direccionId = direccionNueva.DIRECCION.TDIRID.ToString();
                            personaABA.transaccionId = direccionNueva.TRANSACCION.TRANID.ToString();

                            return personaABA;
                        }
                    }

                }
                else
                {
                    string xmlBuscaPersona = ToXMLString<XML>(xmlSend);
                    log.Info("Envio buscaPersonaAba dp xml: " + xmlBuscaPersona);
                    string resultado = clienteBuscaAsegurado.ConsultaPersonas(tokenConsulta, xmlBuscaPersona);
                    log.Info("Resultado WS buscaPersonaAba dp xmlABA: " + resultado);

                    PERSONAS personas = ToObject<PERSONAS>(resultado);
                    if (personas.Items != null)
                    {
                        foreach (PERSONASPERSONA perResponse in personas.Items)
                        {
                            string rfcABA = perResponse.RFC.Trim().ToUpper() + perResponse.HCVE.Trim().ToUpper();
                            PersonaABA personaABA = new PersonaABA();
                            //if (strBuscoNombre == "" || perResponse.NOMBRE.Replace(" ", "").ToUpper().Contains(strBuscoNombre.Replace(" ", "").ToUpper()))
                            if (rfc.Trim().ToUpper() == rfcABA)
                            {
                                personaABA.personaId = perResponse.PID;

                                string buscaDireccion = String.Format("<XML><DP><TP>{0}</TP><PID>{1}</PID></DP></XML>", xmlSend.Item.TP, personaABA.personaId);
                                log.Info("buscaDireccion  ABA" + buscaDireccion);
                                string resultadoBuscaDireccion = clienteBuscaAsegurado.ConsultaDireccionesPersona(tokenConsulta, buscaDireccion);
                                log.Info("resultadoBuscaDireccion  ABA" + resultadoBuscaDireccion);
                                RESULTADO direccion = ToObject<RESULTADO>(resultadoBuscaDireccion);
                                string _codigoPostalABA = "";
                                foreach (object resObj in direccion.Items)
                                {
                                    if (resObj is RESULTADODIRECCIONES)
                                    {

                                        _codigoPostalABA = ((RESULTADODIRECCIONES)resObj).DIR != null ? ((RESULTADODIRECCIONES)resObj).DIR.LastOrDefault().CP : "";
                                        _codigoPostalABA = string.IsNullOrEmpty(_codigoPostalABA) ? "" : _codigoPostalABA.PadLeft(5, '0');
                                        personaABA.direccionId = ((RESULTADODIRECCIONES)resObj).DIR != null ? ((RESULTADODIRECCIONES)resObj).DIR.LastOrDefault().DIRID : "";
                                    }
                                    if (resObj is RESULTADOTRANSACCION)
                                    {
                                        personaABA.transaccionId = ((RESULTADOTRANSACCION)resObj).TRANID;
                                    }
                                }
                                if (_codigoPostalABA.Trim() == CP.Trim())
                                    return personaABA;
                                else
                                {
                                    //Si no existe esa direccion se da de alta.
                                    if (personaABA.personaId != null)
                                    {
                                        PersonaRegistroABA.Token token = new PersonaRegistroABA.Token();
                                        token.usuario = UsuarioWS;
                                        token.password = PasswordWS;

                                        string result = cliente.RegistraDireccionPersona(token, GeneraXmlRegistroDireccionPersona(direccionEmpleado, personaABA.personaId, tipocontribuyenteClave));

                                        com.lockton.xml.aba.registro.direcciones.RESULTADO direccionNueva = ToObject<com.lockton.xml.aba.registro.direcciones.RESULTADO>(result);
                                        personaABA.direccionId = direccionNueva.DIRECCION.TDIRID.ToString();
                                        personaABA.transaccionId = direccionNueva.TRANSACCION.TRANID.ToString();

                                        return personaABA;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error en buscaPersonaAba " + ex.Message, ex);
                //throw new Exception(ex.Message);
            }
            return null;
        }

        public string GeneraXmlRegistroDireccionPersona(Direccion direccionAlta, string PersonaIDAba, string TipoPersona)
        {
            string xml = "";

            xml = string.Format("<XML><DP><TP>{7}</TP><PID>{0}</PID><DOMICILIO><TIPODIR>1</TIPODIR><CALLE>{1}</CALLE><NUMEXT>{2}</NUMEXT><NUMINT>{3}</NUMINT><COL>{4}</COL><CP>{5}</CP><POB>{6}</POB></DOMICILIO></DP></XML>",
                                                                   PersonaIDAba,
                                                                  string.IsNullOrEmpty(direccionAlta.Calle) ? "" : direccionAlta.Calle,
                                                                   string.IsNullOrEmpty(direccionAlta.NumeroExt) ? "1" : direccionAlta.NumeroExt,
                                                                   string.IsNullOrEmpty(direccionAlta.NumeroInt) ? "1" : direccionAlta.NumeroInt,
                                                                  string.IsNullOrEmpty(direccionAlta.Colonia) ? "1" : direccionAlta.Colonia,
                                                                  string.IsNullOrEmpty(direccionAlta.CodigoPostal) ? "05329" : direccionAlta.CodigoPostal,
                                                                   string.IsNullOrEmpty(direccionAlta.Municipio) ? "1" : direccionAlta.Municipio,
                                                                   TipoPersona);
            return xml;
        }



        /// <summary>
        /// TODO:revizar si funciona para personas morales
        /// </summary>
        /// <param name="titular"></param>
        /// <param name="paqueteConvenio"></param>
        /// <returns></returns>
        private PersonaABA altaPropietarioContratanteABA(InformacionEmision InfoEmision, string UsuarioWS, string PasswordWS, string TipoContratante)
        {
            PersonaABA resultadoBuscaPersona;
            try
            {
                //string rfcCliente = LocktonServicios.Utilidades.Utilidades.CalcularRFC(InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre, InfoEmision.ApellidoPaterno, InfoEmision.ApellidoMaterno, InfoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yy"));
                string rfcCliente = InfoEmision.DatosUsuario.RFC;

                resultadoBuscaPersona = buscaPersonaAba(rfcCliente, TipoContratante, UsuarioWS, PasswordWS, InfoEmision.ObtieneNombreCompleto());
                if (resultadoBuscaPersona != null)
                {
                    return resultadoBuscaPersona;
                }

                PersonaRegistroABA.PCRegistroClient cliente = new PersonaRegistroABA.PCRegistroClient();
                PersonaRegistroABA.Token token = new PersonaRegistroABA.Token();
                token.usuario = UsuarioWS;
                token.password = PasswordWS;

                //Llena los datos del contratante
                DP dp = new com.lockton.xml.aba.persona.request.DP();
                dp.TP = "0";
                //Persona fisica
                if (dp.TP == "0")
                {
                    dp.FISICA = new DPFISICA();
                    if (rfcCliente.Length > 10)
                    {
                        dp.FISICA.RFC = rfcCliente.Substring(0, rfcCliente.Length - 3);
                        dp.FISICA.HCVE = rfcCliente.Substring(rfcCliente.Length - 3, 3);
                    }
                    else
                    {
                        dp.FISICA.RFC = rfcCliente;
                        dp.FISICA.HCVE = "";
                    }
                    //dp.FISICA.PNOM = InfoEmision.DetalleUsuario.Nombre;
                    //dp.FISICA.SNOM = InfoEmision.DetalleUsuario.NombreDos;
                    //dp.FISICA.APP = InfoEmision.DetalleUsuario.ApellidoPaterno;
                    //dp.FISICA.APM = InfoEmision.DetalleUsuario.ApellidoMaterno;
                    dp.FISICA.PNOM = InfoEmision.PrimerNombre;
                    dp.FISICA.SNOM = InfoEmision.SegundoNombre;
                    dp.FISICA.APP = InfoEmision.ApellidoPaterno;
                    dp.FISICA.APM = InfoEmision.ApellidoMaterno;
                    dp.FISICA.SEXO = "1";
                    dp.FISICA.EDOCIVIL = "2";
                    //dp.MORAL = new DPMORAL();
                    //dp.MORAL.RFC = "";
                    //dp.MORAL.HCVE = "";
                    //dp.MORAL.RS = "";
                    //dp.MORAL.NOMCOM = "";
                    //dp.MORAL.GIRO = "1";
                    //dp.MORAL.REGIMEN = "false";
                    //dp.MORAL.TS = "0";
                }
                if (!string.IsNullOrEmpty(InfoEmision.Direccion.CodigoPostal))
                {
                    dp.DOMICILIO = new DPDOMICILIO();
                    dp.DOMICILIO.TIPODIR = "1";
                    dp.DOMICILIO.CALLE = InfoEmision.Direccion.Calle ?? "0";
                    dp.DOMICILIO.NUMEXT = InfoEmision.Direccion.NumeroExt ?? "0";
                    dp.DOMICILIO.NUMINT = InfoEmision.Direccion.NumeroInt ?? "0";
                    dp.DOMICILIO.COL = InfoEmision.Direccion.Colonia ?? "0";
                    dp.DOMICILIO.CP = InfoEmision.Direccion.CodigoPostal ?? "0";
                    dp.DOMICILIO.POB = InfoEmision.Direccion.Municipio ?? "0";
                    dp.TELEFONO = new DPTELEFONO();
                    dp.TELEFONO.LADA = string.IsNullOrEmpty(InfoEmision.TelefonoFijo) ? string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "55" : InfoEmision.TelefonoCel.Substring(0, 2) : InfoEmision.TelefonoFijo.Substring(0, 2);
                    dp.TELEFONO.NUMERO = string.IsNullOrEmpty(InfoEmision.TelefonoFijo) ? string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "55" : InfoEmision.TelefonoCel.Substring(2, 8) : InfoEmision.TelefonoFijo.Substring(2, 8);
                    dp.CELULAR = new DPCELULAR();
                    dp.CELULAR.LADA = string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "55" : InfoEmision.TelefonoCel.Substring(0, 2);
                    dp.CELULAR.NUMERO = string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "55" : InfoEmision.TelefonoCel.Substring(2, 8);
                    dp.CORREO = InfoEmision.Email;
                }
                else
                {
                    dp.DOMICILIO = new DPDOMICILIO();
                    dp.DOMICILIO.TIPODIR = "1";
                    dp.DOMICILIO.CALLE = InfoEmision.Empresa.Direccion.Calle;
                    dp.DOMICILIO.NUMEXT = InfoEmision.Empresa.Direccion.NumeroExt ?? "0";
                    dp.DOMICILIO.NUMINT = InfoEmision.Empresa.Direccion.NumeroInt ?? "0";
                    dp.DOMICILIO.COL = InfoEmision.Empresa.Direccion.Colonia ?? "0";
                    dp.DOMICILIO.CP = InfoEmision.Empresa.Direccion.CodigoPostal ?? "0";
                    dp.DOMICILIO.POB = InfoEmision.Empresa.Direccion.Municipio ?? "0";
                    dp.TELEFONO = new DPTELEFONO();
                    dp.TELEFONO.LADA = string.IsNullOrEmpty(InfoEmision.TelefonoFijo) ? string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "55" : InfoEmision.TelefonoCel.Substring(0, 2) : InfoEmision.TelefonoFijo.Substring(0, 2);
                    dp.TELEFONO.NUMERO = string.IsNullOrEmpty(InfoEmision.TelefonoFijo) ? string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "55" : InfoEmision.TelefonoCel.Substring(2, 8) : InfoEmision.TelefonoFijo.Substring(2, 8);
                    dp.CELULAR = new DPCELULAR();
                    dp.CELULAR.LADA = string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "55" : InfoEmision.TelefonoCel.Substring(0, 2);
                    dp.CELULAR.NUMERO = string.IsNullOrEmpty(InfoEmision.TelefonoCel) ? "55" : InfoEmision.TelefonoCel.Substring(2, 8);
                    dp.CORREO = InfoEmision.Email;
                }


                MemoryStream memoryStream = new MemoryStream();
                XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                ns.Add(String.Empty, String.Empty);
                XmlSerializer xs = new XmlSerializer(typeof(com.lockton.xml.aba.persona.request.DP));
                XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Default);
                xs.Serialize(xmlTextWriter, dp, ns);
                memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
                string XmlizedString = UTF8ByteArrayToString(memoryStream.ToArray());
                XmlizedString = XmlizedString.Replace("<?xml version=\"1.0\" encoding=\"Windows-1252\"?>", "");

                string respuesta = cliente.RegistraPersona(token, "<XML>" + XmlizedString + "</XML>");
                log.Info("respuesta altaPersonaPropietarioABA" + respuesta);
                resultadoBuscaPersona = new PersonaABA();
                com.lockton.xml.aba.persona.response.RESULTADO personaResult = ToObject<com.lockton.xml.aba.persona.response.RESULTADO>(respuesta);
                foreach (object item in personaResult.Items)
                {
                    if (item is com.lockton.xml.aba.persona.response.RESULTADOPERSONA)
                    {
                        resultadoBuscaPersona.personaId = ((com.lockton.xml.aba.persona.response.RESULTADOPERSONA)item).TPID;
                    }
                    if (item is com.lockton.xml.aba.persona.response.RESULTADOTRANSACCION)
                    {
                        resultadoBuscaPersona.transaccionId = ((com.lockton.xml.aba.persona.response.RESULTADOTRANSACCION)item).TRANID;
                    }
                    if (item is com.lockton.xml.aba.persona.response.RESULTADODIRECCION)
                    {
                        resultadoBuscaPersona.direccionId = ((com.lockton.xml.aba.persona.response.RESULTADODIRECCION)item).TDIRID;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info("altaPersonaPropietarioABA " + ex.Message, ex);
                throw new Exception(ex.Message);
            }
            return resultadoBuscaPersona;
        }
        #endregion


        #region ReimpresionPolizas


        public string ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string UsuarioWS, string PasswordWS, string tipoContribuyente, bool recibos)
        {
            string rutapolizaAba = "";
            log.Info(string.Format("Cominza la reimpresion de la poliza {0}", NumeroPoliza));
            try
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("<IM>");
                builder.AppendFormat("<CLAVE>{0}</CLAVE>", NumeroPoliza.Substring(0, 2));
                builder.AppendFormat("<POL>{0}</POL>", NumeroPoliza.Substring(2).Trim());
                builder.AppendFormat("<INCISO>{0}</INCISO>", 1);
                builder.AppendFormat("<RECIBO>{0}</RECIBO>", Convert.ToInt32(recibos));
                builder.AppendFormat("<RECIBO_TODOS>{0}</RECIBO_TODOS>", Convert.ToInt32(recibos));
                builder.Append("<FACTURA>0</FACTURA>");
                builder.Append("</IM>");

                string xmlImprimeAba = builder.ToString();
                ImpresionABA.Token tokenImp = new ImpresionABA.Token();

                tokenImp.usuario = UsuarioWS;
                tokenImp.password = PasswordWS;

                ////if (tipoContribuyente == "0")
                //{
                //    tokenImp.usuario = "WSUNICCO";
                //    tokenImp.password = "VIRTUAL1$";
                //}

                ImpresionABA.ACImpresionClient clienteImp = new ImpresionABA.ACImpresionClient();
                string resultadoImp = "";

                resultadoImp = clienteImp.ImpresionSegmentacion(tokenImp, xmlImprimeAba);
                StringReader reader = new StringReader(resultadoImp);

                XmlSerializer xs = new XmlSerializer(typeof(IM));
                IM impresionResult = (IM)xs.Deserialize(reader);

                if (impresionResult != null)
                {
                    rutapolizaAba = impresionResult.PATHPDF;
                }
                log.Info(string.Format("Resultado de la reimpresion de la poliza: {0}", rutapolizaAba));
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Ocurrio un problema al reimprimir la poliza {0}", ex.Message));
            }
            return rutapolizaAba;
        }

        public CotizacionCompara CotizarVehiculo()
        {
            throw new NotImplementedException();
        }

        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }

        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }
        #endregion

        public string EndpointABA()
        {
            bool esProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
            string destino = null;
            if (esProduccion)
            {
                destino = db.CatParametro.Where(x => x.Clave.Contains("PRODUCCION COBRANZA CHUBB")).Select(x => x.Valor).FirstOrDefault();
            }
            else
            {
                destino = db.CatParametro.Where(x => x.Clave.Contains("QA COBRANZA CHUBB")).Select(x => x.Valor).FirstOrDefault();
            }
            return destino;
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public EstatusOperacion LinkCobro(DatosLinkCobro datos, int? idRegistro)
        {
            var estatusOperacion = new EstatusOperacion();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
                SqlParameter numeroPoloza = new SqlParameter("@Poliza", datos.NumeroPoliza);

                var datosPoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", numeroPoloza).FirstOrDefault();


                var convenio = db.Convenio.FirstOrDefault(a => a.Id == datos.IdConvenio);
                string destino = EndpointABA();

                #region URL ABA

                StringBuilder sb = new StringBuilder();

                // Obtenemos la URL (completa) de retorno, que va a utilizar la pagina de cobranza de ABA
                string url = "";

                // Clave de la Poliza ( punto de venta)
                sb.AppendFormat("veI={0}+", datos.NumeroPoliza.Substring(0, 2)); //poliza.convenio.codidoPromocion);
                                                                          // Numero de poliza
                sb.AppendFormat("za={0}+", datos.NumeroPoliza.Substring(2));
                // Numero de inciso
                sb.AppendFormat("cis={0}+", 1);
                // Moneda de la Póliza
                sb.AppendFormat("bab={0}+", 1); //1 - Moneda Nacional
                                                // Oficina donde se emitió la póliza
                sb.AppendFormat("kgb={0}+", convenio.ZonaCotizacion); // 1 - Monterrey / 2 - México / 3 - Guadalajara
                                                                      // URL a donde hará redirect después de terminar el cobro.(si esta variable queda vacía, el sistema cerrará la ventana del explorador al presionar el botón Finalizar para los navegadores Explorer y Chrome, para Firefox, redireccionará a la web www.abaseguros.com)
                sb.AppendFormat("kli={0}+", url);
                // Consumidor, dato constante proporcionado por Aba para cada negocio (“que subsistema consume el sistema”)
                // WSDEMO / wsventa / wspag /  wsprog / wspyp
                sb.AppendFormat("trc={0}+", convenio.TRC);//ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                          //sb.AppendFormat("trc={0}+", "WSVENTASPYP");//ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2K_ABA));
                                                          // ID del usuario utilizado, dato constante proporcionado por Aba para cada negocio (“que usuario consume el sistema”)
                                                          // (sera un valor diferente dependiendo del ambiente enque se este trabajando)
                sb.AppendFormat("cnzd={0}+", convenio.CNZD); //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente
                                                             //sb.AppendFormat("cnzd={0}+", "109227"); //ParametroService.obtieneValorParametro(Parametro.PARAMETRO_V2B_ABA)); //, poliza.convenio.usuario_agente

                // ID del negocio de cobranza, dato constante proporcionado por Aba (“que negocio se utilizara el contiene las reglas de negocio como calendarización de pagos, avisos Etc…”) (opcional para cuando la programación es especial)
                //PA. Se activa solo para Principal con el valor 225

                // 2016-07-26 AGF Cambio para considerar valores correctos en cliente KANSAS
                if (convenio.IntentosCobro != null && !string.IsNullOrEmpty(convenio.NEI))
                {
                    sb.AppendFormat("NeI={0}+", convenio.NEI);
                }

                // RamoId de acuerdo al Ramo de la póliza.
                sb.AppendFormat("aId={0}+", 3); //Autos
                                                //  Requerir correo electrónico, si se requiere que la interfaz de Cargos en línea, requiera de manera obligatoria el correo electrónico del titular de la tarjeta enviar en “1”, en caso contrario “0” o no enviar.
                sb.AppendFormat("vcr={0}+", 1);
                //  Dirección de correo electrónico, para que aparezca como sugerencia en la interfaz de cargos en línea. Éste parámetro es opcional.
                sb.AppendFormat("vce={0}+", datos.Email);
                //sb.AppendFormat("vce={0}+", "vguzman@mx.lockton.com");
                //  Varieable para configura los medios de pago a mostrar, se tiene que enviar un string con las siguientes iniciales y el orden que desean que se despliegue en el combo,
                // a = Para AMEX
                // v = Para VISA / MasterCard
                // d = Para Debito y Clabe
                // Ejemplos:
                // av = Amex y Visa / Mastercard
                // va = Visa / MasterCard y Amex
                //sb.AppendFormat("NsP={0}+", "");
                //  Nombre del Tarjetahabiente, asegurado o propietario
                sb.AppendFormat("NmA={0}", datosPoliza.ConductorHabitual);

                if (convenio.EnvioFormaPagoABA)
                    sb.AppendFormat("+NsP={0}", "vda");
                //sb.AppendFormat("NmA={0}", "Victor Guzman");

                ASCIIEncoding ByteConverter = new ASCIIEncoding();
                string textoEncriptado = Convert.ToBase64String(ByteConverter.GetBytes(sb.ToString()));

                //*****FIN ENCRIPTAR VARIABLES******//
                //
                //string tipoAPP = "0";
                string CadURL = "";
                //*****FORMAR URL PARA LLAMAR INTERFACE ****// 
                CadURL += destino;

                CadURL += "alt=";
                CadURL += textoEncriptado;

                #endregion

                var plantilla = db.LinkPagoPlantilla.First().Contenido;

               
                plantilla = plantilla.Replace("[Aseguradora]", "CHUBB");
                plantilla = plantilla.Replace("[URLLinkPago]", CadURL);
                plantilla = plantilla.Replace("[Negocio]", datosPoliza.Gerencia);
                plantilla = plantilla.Replace("[NumeroDePoliza]", datos.NumeroPoliza);
                plantilla = plantilla.Replace("[Vehiculo]", $"{datosPoliza.Marca} {datosPoliza.Modelo} {datosPoliza.Version}");


                var email = new LocktonServicios.Services.EnvioEmail.ServicioEmail();

                email.EnviarEmail(new List<string>() { datos.Email }, $"Link de Pago {datos.NumeroPoliza}", plantilla, null);

                urlMethod = CadURL;
                jsonResponse = datos.Email;
                jsonRequest = plantilla;

                estatusOperacion.Exitoso = true;


            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado Link de Pago CHUBB: " + ex.Message, ex);

                estatusOperacion.Mensaje = ex.Message;
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                estatusOperacion.Exitoso = false;
                estatusOperacion.EsReintentable = false;
                estatusOperacion.MensajeCatalogo = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            if (idRegistro.HasValue)
            {
                var registro = db.LinkPagoMasivo_Poliza.FirstOrDefault(a => a.Id == idRegistro);

                registro.Error = estatusOperacion.MensajeCatalogo;
                registro.URL = urlMethod;
                registro.Response = jsonResponse;
                registro.Request = jsonRequest;

                db.SaveChanges();
            }

            RegistraOPL(datos.NumeroPoliza, jsonRequest, jsonResponse, "Link de Cobro", 5, estatusOperacion.Exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datos.NumeroPoliza) == true ? "Online" : "Tradicional");

            log.Info(string.Format("Termina proceso de generacion de link de pago de la poliza: {0}", datos.NumeroPoliza));

            return estatusOperacion;
        }

        private void RegistraOPL(string numeroPoliza, string xml, string respuesta, string tipo, int idTipo, bool exitoso, string TipoPoliza, int IdCatalogoError = 0)
        {
            try
            {
                using (var _db = new ApplicationDbContext())
                {
                    var oplRegistro = new PolizaRegistroCobranza();
                    oplRegistro.Exitoso = exitoso;
                    oplRegistro.Fecha = DateTime.Now;
                    oplRegistro.FechaResponse = DateTime.Now;
                    oplRegistro.IdTipoOPL = idTipo;
                    oplRegistro.NumeroPoliza = numeroPoliza;
                    oplRegistro.Response = respuesta;
                    oplRegistro.TipoOPL = tipo;
                    oplRegistro.Request = xml;
                    oplRegistro.TipoPoliza = TipoPoliza;
                    oplRegistro.IdCatalogoErrorInstalacionDatosBancarios = IdCatalogoError;
                    oplRegistro.IdAseguradora = 3;
                    _db.PolizaRegistroCobranza.Add(oplRegistro);
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado RegistraOPL Qualitas: " + ex.Message, ex);
            }
        }
    }

}
public class PersonaABA
{
    public string personaId { get; set; }
    public string direccionId { get; set; }
    public string transaccionId { get; set; }
}
