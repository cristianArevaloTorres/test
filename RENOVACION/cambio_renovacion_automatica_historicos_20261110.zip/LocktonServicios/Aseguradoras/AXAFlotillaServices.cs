﻿using com.lockton.xml.aba.consultapersona.request;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonModel.xmls.AXA;
using LocktonServicios.BitacoraPoliza;
using log4net;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace LocktonServicios.Aseguradoras
{
    public class AXAFlotillaServices : IOperacionesAseguradoras
    {
        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger("AXAFlotillaServices");

       

        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision, Convenio convenioCotiza)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("dd/MM/yyyy");
                var cotizacion = ToObject<AXAFlotillasCotizacion.DatosSolicitud>(xmlEmision);

                cotizacion.datosPoliza.vigenciaDesde = date;

                var service = new AXAFlotillasCotizacion.WSFlotillasClient();
                resultado.XMLSolicitud = Serialize(cotizacion);
                
             
                AXAFlotillasCotizacion.DatosCotizacion response = null;

                service.ClientCredentials.UserName.UserName = convenioCotiza.Usuario;
                service.ClientCredentials.UserName.Password = convenioCotiza.Contrasena;

                try
                {
                    response = service.CotizarInciso(cotizacion);
                }
                catch (Exception ex)
                {
                    throw ex;

                }

                resultado.XMLRecepcion = Serialize(response);
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private string ObtenerCaratulaAXA(DateTime inico, int idConvenio,int idPeriodicidad, int idMedioPago, int idEmpresa, string idUsuario, string vehiculo, int idPerfil)
        {
            string caratula = "";
			var empresasDeloitte = db.CatDeloitte.Select(a => a.IdEmpresa).ToList();

            if (empresasDeloitte.Contains(idEmpresa))
            {

                var registro = db.CaratulaINBURSA.FirstOrDefault(a =>
                    a.Estatus == 1 &&
                    a.Activo &&
                    a.TipoUnidad == vehiculo);
                if (registro != null)
                    caratula = registro.Poliza;

			}
            else
            {
                var parameters = new List<SqlParameter>
                {
                    new SqlParameter("@IdConvenio", idConvenio),
                    new SqlParameter("@IdPeriodicidad",idPeriodicidad),
                    new SqlParameter("@IdFormaPago",idMedioPago),
                    new SqlParameter("@Fecha", inico.ToString("yyyy-MM-dd"))
                };

                caratula = db.Database.SqlQuery<string>("Execute sp_CaratulasAXA_Obtener @IdConvenio, @IdPeriodicidad,@IdFormaPago, @Fecha", parameters.ToArray()).SingleOrDefault();
            }

            return caratula;

		}

		public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<LocktonModel.db.PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {
            AXAFlotillasCotizacion.DatosSolicitud cotizacion = new AXAFlotillasCotizacion.DatosSolicitud();
            try
            {

                Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
                ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
                var coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete);
                var empresa = db.Empresa.FirstOrDefault(a => a.Id == convenioCotiza.IdEmpresa);
                var estado = db.CatEstadosAXA.FirstOrDefault(a => a.Clave == empresa.Direccion.CatEstadosRepublica.Clave);
                if (convenioCotiza.ZonaCirculacion == 1)
                {
                    var codigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == CotizacionCompara.CodigoPostal);
                    estado = db.CatEstadosAXA.FirstOrDefault(a => a.Clave == codigoPostal.CatEstadosRepublica.Clave);
                }else if(convenioCotiza.ZonaCirculacion == 2)
                {
                    var _cpConvenio = convenioCotiza.CodigoPostal.ToString().PadLeft(5, '0');
                    var _codigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == _cpConvenio);
                    estado = db.CatEstadosAXA.FirstOrDefault(a => a.Clave == _codigoPostal.CatEstadosRepublica.Clave);
                }
                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioCotiza.Id && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
                var claveAmis = getMarcaTipoVehiculo(cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault().clave);
                CatRamoVehiculo vehiculo = db.CatRamoVehiculo.Where(x => x.Clave == CotizacionCompara.TipoVehiculo).FirstOrDefault();
                ConvenioRamoPaquete paqueteRamoConvenio = db.ConvenioRamoPaquete
                                            .Where(x => x.IdConvenio == convenioCotiza.Id && x.IdCatRamoVehiculo == vehiculo.IdCatRamo)
                                                .FirstOrDefault();
                CatModalidadFormaPago formaPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                //para si es flotilla verificar fechas
                DateTime FechaInicio = CotizacionCompara.FechaInicio;// DateTime.Now;
                DateTime FechaTermino = CotizacionCompara.FechaFin;
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
				var catperiodicidadformapago = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == CotizacionCompara.FormadePago);
				

				//if (ConveniosPaquetes.configuracionEmpresa.AplicaFechaCotizacion)
				//{
				//    FechaInicio = CotizacionCompara.FechaCotizacion;
				//    FechaTermino = CotizacionCompara.FechaCotizacion.AddYears(1);
				//}
				////obtener la fecha de inicio y fin de la configuracion
				//if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 1
				//    || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 4
				//    || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5)//flotilla
				//{
				//    //verifica las fechas de inicio
				//    if (Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, FechaInicio))
				//    {//busca si existe fecha de enrollment
				//        FechaInicio = ConveniosPaquetes.Convenios[0].InicioVigencia;
				//    }
				//    FechaTermino = ConveniosPaquetes.Convenios[0].FinVigencia;

				//}

				//if (ConveniosPaquetes.configuracionEmpresa.AplicaMultiAnual)
				//{
				//    LocktonModel.db.CatPeriodicidadFormaPago catperdioricidad = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == perioricidad.IdCatPeriodicidadFormaPago);
				//    if (catperdioricidad != null)
				//        FechaTermino = FechaInicio.AddYears(catperdioricidad.ValorMultiAnual);

				//}

				string InicioVigencia = FechaInicio.ToString("dd/MM/yyyy");
                string FinVigencia = FechaTermino.ToString("dd/MM/yyyy");
				
                string caratula = ObtenerCaratulaAXA(FechaInicio, convenioCotiza.Id, CotizacionCompara.FormadePago, formaPago.Id, convenioCotiza.IdEmpresa, detalleUsuario.IdUsuario, vehiculo.Nombre.ToUpper(), detalleUsuario.IdPerfil);

				if (string.IsNullOrEmpty(caratula))
                {
                    Comparar _infoCompara = new Comparar();

                    _infoCompara.XmlEmision = "";
                    _infoCompara.XmlRespuesta = "";
                    _infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                    _infoCompara.IdConvenio = convenioCotiza.Id;
                    _infoCompara.Aseguradora = "AXA";
                    _infoCompara.Año = CotizacionCompara.Año;

                    _infoCompara.ErrorXML = "No se encontró una Póliza configurada para AXA con la Forma de pago ni en las Fechas de Cotización";
                    CotizacionCompara.Comparar.Add(_infoCompara);
                    return CotizacionCompara;
                }
                cotizacion.datosPoliza = new AXAFlotillasCotizacion.PolizaMaestra();
                cotizacion.datosVehiculo = new AXAFlotillasCotizacion.Vehiculo();
                cotizacion.datosCoberturas = new AXAFlotillasCotizacion.DatosCoberturas();

                //DatoPoliza

                cotizacion.datosPoliza.miembroDesdeSpecified = true;
                cotizacion.datosPoliza.porcentajeDescuentoSpecified = true;
                cotizacion.datosPoliza.numeroPoliza = caratula;
                cotizacion.datosPoliza.vigenciaDesde = InicioVigencia;
                cotizacion.datosPoliza.porcentajeDescuento = Convert.ToDouble(paqueteRamoConvenio.Descuento);
                cotizacion.datosPoliza.tipoNegocio = AXAFlotillasCotizacion.TipoNegocio.Normal;
                if (CotizacionCompara.MediodePago == 0 || CotizacionCompara.MediodePago == 1)
                    cotizacion.datosPoliza.modoPago = AXAFlotillasCotizacion.ModoPago.Tarjeta;
                else if (CotizacionCompara.MediodePago == 2)
                    cotizacion.datosPoliza.modoPago = AXAFlotillasCotizacion.ModoPago.DxN;
                else
                    cotizacion.datosPoliza.modoPago = AXAFlotillasCotizacion.ModoPago.Efectivo;
                cotizacion.datosPoliza.miembroDesde = 0;

                //DatosVehiculo
                cotizacion.datosVehiculo.modelo = Convert.ToInt32(CotizacionCompara.Año);
                cotizacion.datosVehiculo.marca = claveAmis[0];
                cotizacion.datosVehiculo.tipo = claveAmis[1];
                cotizacion.datosVehiculo.clase = 1;
                cotizacion.datosVehiculo.descripcionVehiculo = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault().Descripcion;
                cotizacion.datosVehiculo.estadoPlacas = estado.Valor;

                //DatosCoberturas
                cotizacion.datosCoberturas.afianzadora = 6;
                cotizacion.datosCoberturas.servidora = 5;
                if (CotizacionCompara.ValorFactura)
                {
                    cotizacion.datosCoberturas.tipoValor = AXAFlotillasCotizacion.TipoValor.Convenido;
                    cotizacion.datosCoberturas.porcentajeValor = 100;
                    cotizacion.datosCoberturas.valorUnidad = Convert.ToInt32(CotizacionCompara.MontoFactura);
                    cotizacion.datosCoberturas.valorUnidadSpecified = true;
                    cotizacion.datosCoberturas.tipoDeducible = AXAFlotillasCotizacion.TipoDeducible.Fijo;
                }
                else
                {
                    cotizacion.datosCoberturas.tipoValor = AXAFlotillasCotizacion.TipoValor.Comercial;
                    cotizacion.datosCoberturas.porcentajeValor = 100;
                    cotizacion.datosCoberturas.valorUnidad = 0;
                    cotizacion.datosCoberturas.valorUnidadSpecified = true;
                    cotizacion.datosCoberturas.tipoDeducible = AXAFlotillasCotizacion.TipoDeducible.Variable;
                }

                cotizacion.datosCoberturas.servicio = AXAFlotillasCotizacion.Servicio.Particular;
                cotizacion.datosCoberturas.tipoCarga = AXAFlotillasCotizacion.TipoCarga.Normal;
                cotizacion.datosCoberturas.benefAccidentes = AXAFlotillasCotizacion.Respuesta.NO;
                cotizacion.datosCoberturas.uso = AXAFlotillasCotizacion.Uso.Normal;
                cotizacion.datosCoberturas.viajeros = 0;
                cotizacion.datosCoberturas.suva = AXAFlotillasCotizacion.Respuesta.NO;
                cotizacion.datosCoberturas.dobleRemolque = AXAFlotillasCotizacion.Respuesta.NO;
                cotizacion.datosCoberturas.arrastre = AXAFlotillasCotizacion.Respuesta.NO;

                //cotizacion.datosSolicitud.datosCoberturas.coberturasAmparar = new AXAFlotillasCotizacion.Coberturas
                var coberturas = new List<AXAFlotillasCotizacion.Coberturas>();
                var coberturaUtils = new Utilidades.CoberturasUtils();
                foreach (var item in coberturasPaquete)
                {
                    var cobertura = new AXAFlotillasCotizacion.Coberturas();
                    cobertura.claveCoberturaSpecified = true;

                    var agregarCobertura = true;
                    bool AplicaCobertura = false;
                    bool EsCondEspecial = false;
                    switch (item.Codigo)
                    {
                        case "DM":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if (!(AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.DM;
                                cobertura.deducible = item.Deducible.Substring(0, item.Deducible.LastIndexOf("."));
                                if (item.Cobertura == "VALOR COMERCIAL + 10%")
                                    cotizacion.datosCoberturas.porcentajeValor = 110;
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "PRIX":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.PRIX;
                            else
                                agregarCobertura = false;
                            break;
                        case "RT":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.RT;
                                cobertura.deducible = item.Deducible.Substring(0, item.Deducible.LastIndexOf("."));
                                if (item.Cobertura == "VALOR COMERCIAL + 10%")
                                    cotizacion.datosCoberturas.porcentajeValor = 110;
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "RC":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.RC;
                                cobertura.deducible = "0";
                                cobertura.sumaAseguradaSpecified = true;
                                cobertura.sumaAsegurada = Convert.ToInt32(item.SumaAsegurada) / 1000;
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "SRV":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.SRV;
                            else
                                agregarCobertura = false;
                            break;
                        case "EXRC":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.EXRC;
                            else
                                agregarCobertura = false;
                            break;
                        case "RCP":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.RCP;
                                cobertura.sumaAseguradaSpecified = true;
                                cobertura.sumaAsegurada = Convert.ToInt32(item.SumaAsegurada) / 1000;
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "DL":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.DL;
                                cobertura.sumaAseguradaSpecified = true;
                                cobertura.sumaAsegurada = Convert.ToInt32(item.SumaAsegurada) / 1000;
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "ACC":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.ACC;
                                cobertura.sumaAseguradaSpecified = true;
                                cobertura.sumaAsegurada = Convert.ToInt32(item.SumaAsegurada);
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "GMO":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.GMO;
                                cobertura.sumaAseguradaSpecified = true;
                                cobertura.sumaAsegurada = Convert.ToInt32(item.SumaAsegurada);
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "AS":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.AS;
                                cobertura.sumaAseguradaSpecified = true;
                                cobertura.sumaAsegurada = Convert.ToInt32(item.SumaAsegurada);
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "SCA":
                            AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            {
                                cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.SCA;
                                if (cotizacion.datosVehiculo.modelo < 2010)
                                    agregarCobertura = false;
                            }
                            else
                                agregarCobertura = false;
                            break;
                        case "RCEXTR":
                            //AplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(convenioCotiza.Id, item.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            //EsCondEspecial = coberturaUtils.EsCondicionEsp(convenioCotiza.Id, item.IdCobertura.ToString(), paqueteConvenio.IdCatRamoVehiculo);
                            //if ((AplicaCobertura && EsCondEspecial) || !EsCondEspecial)
                            //    cobertura.claveCobertura = AXAFlotillasCotizacion.ClaveCobertura.RCEXTR;
                            //else
                                agregarCobertura = false;
                            break;
                    }
                    if (agregarCobertura)
                    {


                        coberturas.Add(cobertura);
                    }

                }
                cotizacion.datosCoberturas.coberturasAmparar = coberturas.ToArray();

                var service = new AXAFlotillasCotizacion.WSFlotillasClient();
                var xmlEnvio = Serialize(cotizacion);
                log.Info("XML Envio Cotizacion AXA Flotilla: " + xmlEnvio.Replace("\n", "").Replace("\r", ""));
                var errorServicio = false;
                var errorMensaje = "";
                AXAFlotillasCotizacion.DatosCotizacion response = null;

                service.ClientCredentials.UserName.UserName = convenioCotiza.Usuario;
                service.ClientCredentials.UserName.Password = convenioCotiza.Contrasena;

                try
                {
                    response = service.CotizarInciso(cotizacion);
                    log.Info("AXA Flotilla Respuesta Cotizacion");
                }
                catch (Exception ex)
                {
                    errorServicio = true;
                    errorMensaje = ex.Message;
                    log.Error("Error Cotizacion AXA FLOTILLAS " + ex.ToString());

                }

                var tipoDatos = db.CatTipoDatoDeducible.ToList();
                var xmlRecepcion = Serialize(response);
                Comparar infoCompara = new Comparar();

                infoCompara.XmlEmision = xmlEnvio;
                infoCompara.XmlRespuesta = xmlRecepcion;
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.Aseguradora = "AXA";
                infoCompara.Año = CotizacionCompara.Año;
                infoCompara.IdPaqueteConvenio = paqueteConvenio.Id;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                infoCompara.FechaCotizacion = FechaInicio;
                infoCompara.CaratulaCotizacion = cotizacion.datosPoliza.numeroPoliza;

                if (errorServicio)
                {
                    infoCompara.ErrorXML = "Error Cotizacion AXA " + errorMensaje;

                }
                else
                {
                    infoCompara.FechaInicio = response.datosGenerales.FirstOrDefault().vigenciaDesde;
                    infoCompara.FechaFin = response.datosGenerales.FirstOrDefault().vigenciaHasta;
                    infoCompara.CotizacionClave = response.datosGenerales.FirstOrDefault().solicitud;
                    infoCompara.Coberturas = new List<Coberturas>();
                    foreach (var cobertura in response.primasCoberturas)
                    {
                        Coberturas cotCob = new Coberturas();
                        var coberturaConfigurada = coberturasPaquete.FirstOrDefault(a => a.Codigo == cobertura.claveCobertura.ToString());
                        if (coberturaConfigurada != null)
                        {
                            cotCob.Cobertura = cobertura.prima.ToString();
                            cotCob.SumaAsegurada = cobertura.sumaAsegurada.ToString();
                            cotCob.Nombre = cobertura.nombreCobertura.Trim();
                            cotCob.Deducible = cobertura.deducible.ToString();
                            cotCob.Codigo = cobertura.claveCobertura.ToString();
                            cotCob.PrimaNeta = cobertura.prima.ToString();

                            var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == coberturaConfigurada.IdTipoDatoDeducible);

                            cotCob.IdTipoDatoDeducible = tipoDato.Id;
                            cotCob.TipoDato = tipoDato.Nombre;

                            infoCompara.Coberturas.Add(cotCob);
                        }
                    }

                    if (coberturasPaquete.Exists(a => a.Codigo == "RCEXTR"))
                    {
                        var rcext = coberturasPaquete.FirstOrDefault(a => a.Codigo == "RCEXTR");
                        Coberturas cotCob = new Coberturas();

                        cotCob.Cobertura = "0";
                        cotCob.SumaAsegurada = "0";
                        cotCob.Nombre = rcext.Nombre.Trim();
                        cotCob.Deducible = "";
                        cotCob.Codigo = rcext.Codigo.ToString();
                        cotCob.PrimaNeta = "0";
                        infoCompara.Coberturas.Add(cotCob);
                    }

                    infoCompara.PrimaNeta = response.reciboPoliza.primaNeta.ToString();
                    infoCompara.PrimaTotal = response.reciboPoliza.primaTotal.ToString();
                    infoCompara.Impuesto = response.reciboPoliza.impuestos.ToString();
                    infoCompara.Recargo = response.reciboPoliza.recargos.ToString();
                    infoCompara.Derecho = response.reciboPoliza.derechos.ToString();
                    infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();

					infoCompara.FormaPagoEtiqueta = catperiodicidadformapago.Nombre;
					infoCompara.MedioPagoEtiqueta = formaPago.Nombre;
					infoCompara.IdFormaPago = catperiodicidadformapago.Id;
					infoCompara.IdMedioPago = formaPago.Id;

					infoCompara.PrimerPago = response.primerRecibo.primaTotal.ToString();
                    infoCompara.NumeroDePagos = string.IsNullOrEmpty(response.reciboSubsecuentes.numeroRecibos) ? 1 : Convert.ToInt32(response.reciboSubsecuentes.numeroRecibos);
                    infoCompara.SegundoPago = infoCompara.NumeroDePagos > 1 ? response.reciboSubsecuentes.primaTotal.ToString() : "";
                    infoCompara.PrimaAnualizada = Utilidades.Utilidades.CalculaPrimaAnualizada(FechaInicio, FechaTermino, infoCompara.PrimaNeta, infoCompara.Derecho, infoCompara.CesionComision);
					var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago && a.IdCatModalidadFormaPago == formaPago.Id);

                    if(modalidadFormaPago != null)
                        infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                }
                CotizacionCompara.Comparar.Add(infoCompara);

            }
            catch (Exception ex)
            {
                //log.Info(string.Format("Tuvimos un inconveniente para realizar tu cotizacion {0}", ex.Message));
                //throw;
                CotizacionCompara.Comparar.Add(new Comparar() { ErrorXML = "No se encontró la clave en la aseguradora unica", Aseguradora="AXA" });
            }

            return CotizacionCompara;
        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new System.NotImplementedException();
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
           EmisionPoliza result = new EmisionPoliza(true, string.Empty, string.Empty, new Poliza());
			XElement root = new XElement("SOLICITUDEMISION");
            var content = "";
			try
            {
                CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
                AXAFlotillasCotizacion.DatosCotizacion response = ToObject<AXAFlotillasCotizacion.DatosCotizacion>(cotizacionDetalle.XMLRecepcion);
                AXAFlotillasCotizacion.DatosSolicitud cotizacion = ToObject<AXAFlotillasCotizacion.DatosSolicitud>(cotizacionDetalle.XMLSolicitud);
                int IdPaquete = int.Parse(cotizacionDetalle.Paquete);
                PaqueteAseguradora tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == InfoEmision.Convenio.IdAseguradora && x.IdCatTipoPaquete == IdPaquete).FirstOrDefault();
                CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
                PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
                var befeniciario = InfoEmision.BeneficiarioPreferente;
				var empresasDeloitte = db.CatDeloitte.Select(a => a.IdEmpresa).ToList();

				var api = Utilidades.Utilidades.ObtienerValorParametro("API_EMISION_AXA_FLOTILLAS");
                var key = Utilidades.Utilidades.ObtienerValorParametro("API_EMISION_AXA_FLOTILLAS_KEY");
                var b = Utilidades.Utilidades.ObtienerValorParametro("API_EMISION_AXA_FLOTILLAS_B");
                var clientews = InfoEmision.Convenio.CodigoPromocion; //Utilidades.Utilidades.ObtienerValorParametro("API_EMISION_AXA_FLOTILLAS_CLIENTEWS");


				if (string.IsNullOrEmpty(InfoEmision.BeneficiarioPreferente))
                {
                    befeniciario = InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre + " " + InfoEmision.ApellidoPaterno + " " + InfoEmision.ApellidoMaterno;
                }
                byte[] tempBytes;
                tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(InfoEmision.Empresa.Direccion.Estado);
                string estadoSinAcentos = System.Text.Encoding.UTF8.GetString(tempBytes);
                string direccion = InfoEmision.Empresa.Direccion.Calle;

                if (!string.IsNullOrEmpty(InfoEmision.Empresa.Direccion.NumeroExt))
                    direccion += string.Format(" {0}", InfoEmision.Empresa.Direccion.NumeroExt);

                if (!string.IsNullOrEmpty(InfoEmision.Empresa.Direccion.NumeroInt))
                    direccion += string.Format(" Int {0}", InfoEmision.Empresa.Direccion.NumeroInt);

                string cp = InfoEmision.Empresa.Direccion.CodigoPostal;
                string colonia = InfoEmision.Empresa.Direccion.Colonia;
                string municipio = InfoEmision.Empresa.Direccion.Municipio;

                if (!InfoEmision.EsFlotilla)
                {
                    tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Estado);
                    estadoSinAcentos = System.Text.Encoding.UTF8.GetString(tempBytes);
                    direccion = InfoEmision.DatosUsuario.Direccion.Calle;

                    if (!string.IsNullOrEmpty(InfoEmision.DatosUsuario.Direccion.NumeroExt))
                        direccion += string.Format(" {0}", InfoEmision.DatosUsuario.Direccion.NumeroExt);

                    if (!string.IsNullOrEmpty(InfoEmision.DatosUsuario.Direccion.NumeroInt))
                        direccion += string.Format(" Int {0}", InfoEmision.DatosUsuario.Direccion.NumeroInt);

                    cp = InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                    colonia = InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento;
                    municipio = InfoEmision.DatosUsuario.Direccion.CatCodigoPostal.Municipio;
                }
                 if (empresasDeloitte.Contains(InfoEmision.Convenio.IdEmpresa))
                {
					var detalleUsuarioBeflex = db.DetalleUsuarioBeFlex.FirstOrDefault(a => a.IdUsuario == InfoEmision.DetalleUsuario.IdUsuario);
					var sociedad = detalleUsuarioBeflex.Sociedad.Trim() == "S008" ? "S001" : detalleUsuarioBeflex.Sociedad.Trim();
					var empresaDeloitte = db.EmpresaDeloitte.FirstOrDefault(a => a.Sociedad.Trim() == sociedad);					
					var tipoIdentificacionEmpresa = db.CatTipoIdentificacions.FirstOrDefault(a => a.Id == empresaDeloitte.IdCatTipoIdentificacion);					
					var catEsado = db.CatEstadosRepublica.FirstOrDefault(a => a.Id == empresaDeloitte.IdCatEstadosRepublica_Nacimiento);

					tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(catEsado.Estado);
					estadoSinAcentos = System.Text.Encoding.UTF8.GetString(tempBytes);
					direccion = empresaDeloitte.Direccion.Calle;

					if (!string.IsNullOrEmpty(empresaDeloitte.Direccion.NumeroExt))
						direccion += string.Format(" {0}", empresaDeloitte.Direccion.NumeroExt);

					if (!string.IsNullOrEmpty(empresaDeloitte.Direccion.NumeroInt))
						direccion += string.Format(" Int {0}", empresaDeloitte.Direccion.NumeroInt);

					cp = empresaDeloitte.Direccion.CodigoPostal;
					colonia = empresaDeloitte.Direccion.CatCodigoPostal.Asentamiento;
					municipio = empresaDeloitte.Direccion.CatCodigoPostal.Municipio;
				}

                //if(InfoEmision.Convenio.ZonaCirculacion == 2)
                //{
                //    var _cpConvenio = InfoEmision.Convenio.CodigoPostal.ToString().PadLeft(5, '0');
                //    var _catCodigo = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == _cpConvenio);

                //    cp = _catCodigo.Codigo;
                //    colonia = _catCodigo.Asentamiento;
                //    municipio = _catCodigo.Municipio;
                //}

                if (estadoSinAcentos.ToUpper() == "ESTADO DE MEXICO")
                    estadoSinAcentos = "Mexico";

                var necesitaTokenTarjeta = InfoEmision.FormaPago == 0 || InfoEmision.FormaPago == 1;
                var regimenCapital = "";
                var regimenFiscal = "";
                var usoCFDI = "";
                var tipoFactura = "";

                if (InfoEmision.RequiereFactura)
                {
                    if (InfoEmision.EsFlotilla)
                    {
                        if (InfoEmision.Empresa.IdRegimenFiscal.HasValue)
                            regimenFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal).Clave;
                        if (InfoEmision.Empresa.IdRegimenCapital.HasValue)
                            regimenCapital = db.CatRegimenCapital.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenCapital).Abreviatura;
                        if (InfoEmision.Empresa.IdUsoCFDI.HasValue)
                            usoCFDI = db.CatUsoCFDI.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdUsoCFDI).Abreviatura;

                        tipoFactura = "2";
                    }
					else
					{
                        if (InfoEmision.IdRegimenFiscal>0)
                            regimenFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.IdRegimenFiscal).Clave;                       
                        if (InfoEmision.IdUsoCFDI > 0)
                            usoCFDI = db.CatUsoCFDI.FirstOrDefault(a => a.Id == InfoEmision.IdUsoCFDI).Abreviatura;

                        tipoFactura = "1";
                    }
                }
                var documentResponse = XDocument.Parse(cotizacionDetalle.XMLRecepcion);
                documentResponse.Element("DatosCotizacion").RemoveAttributes();
                documentResponse.Element("DatosCotizacion").Name = "datosCotizacion";

               
                XNamespace ns = @"http://www.w3.org/2001/XMLSchema";
                XNamespace xsi = @"http://www.w3.org/2001/XMLSchema-instance";

                root.Add(new XElement("clientews", clientews));

                root.Add(new XElement("CotizaAutoRespuesta"
                    , new XElement("CotizarIncisoResponse"
                    //, new XAttribute(XNamespace.Xmlns + "xsd", ns.NamespaceName)
                    //, new XAttribute(XNamespace.Xmlns + "xsi", xsi.NamespaceName)
                    , documentResponse.Elements())));

                root.Add(new XElement("datosEmision"
                    , new XElement("datosContratante"
                        , new XElement("numeroPoliza", cotizacion.datosPoliza.numeroPoliza)
                        , new XElement("tipoValor", cotizacion.datosCoberturas.tipoValor.ToString())
                        , new XElement("porcentajeValor", cotizacion.datosCoberturas.porcentajeValor)
                        , new XElement("direccion", direccion)
                        , new XElement("colonia", colonia)
                        , new XElement("cp", cp)
                        , new XElement("edo", estadoSinAcentos)
                        , new XElement("mun", municipio)
                        , new XElement("nombreConductor", InfoEmision.PrimerNombre + " " + InfoEmision.SegundoNombre)
                        , new XElement("paterno", InfoEmision.ApellidoPaterno)
                        , new XElement("materno", InfoEmision.ApellidoMaterno)
                        , new XElement("nomina", InfoEmision.DetalleUsuario.IdEmpleado == null ? "0" : InfoEmision.DetalleUsuario.IdEmpleado)
                        , new XElement("identificador", InfoEmision.DetalleUsuario.IdEmpleado == null ? "0" : InfoEmision.DetalleUsuario.IdEmpleado)
                        , new XElement("rfc", InfoEmision.DatosUsuario.RFC)
                         , new XElement("tel", InfoEmision.TelefonoCel)
                        , new XElement("beneficiario", befeniciario)
                        , new XElement("clabe", "0")
                        , new XElement("vendedor", "")
                        , new XElement("datosFiscales"
                            , new XElement("enviar", InfoEmision.RequiereFactura ? "1" : "0")
                            , new XElement("tipo", InfoEmision.RequiereFactura ? tipoFactura : "")
                            , new XElement("regCapital", InfoEmision.RequiereFactura ? regimenCapital : "")
                            , new XElement("regFiscal", InfoEmision.RequiereFactura ? regimenFiscal : "")
                            , new XElement("usoCFDI", InfoEmision.RequiereFactura ? usoCFDI : ""))
                       )

                   

                    , new XElement("datosVehiculo"
                        , new XElement("noEconomico", "0")                        
                        , new XElement("edoCircula", "")
                        , new XElement("munCircula", "")
                        , new XElement("serie", InfoEmision.NumeroSerie)
                        , new XElement("placas", InfoEmision.Placas)
                        , new XElement("estadoPlacas", estadoSinAcentos)
                        , new XElement("motor", InfoEmision.NumeroMotor)
                        , new XElement("valorUnidad", cotizacion.datosVehiculo.valorUnidad == null ? "0" : cotizacion.datosVehiculo.valorUnidad)
                        , new XElement("remolque", "")
                        , new XElement("dobleRemolque", "")
                          , new XElement("equipoEspecial"
                            , new XElement("descEquipo", "")
                            , new XElement("sumaAseg", ""))
                        )));

                var tokenTarjeta = "";
                if (necesitaTokenTarjeta)
                {
                    tokenTarjeta = TokenizarTarjeta(InfoEmision, cotizacion.datosPoliza.numeroPoliza);
                    root.Element("datosEmision").Element("datosContratante").Add(new XElement("tarjeta", tokenTarjeta));
                }
                else
                {
                    root.Element("datosEmision").Element("datosContratante").Add(new XElement("tarjeta", ""));
                }

                //var servicio = new AXAFlotillasEmisionServices.EmisionIncisoSoapClient();
                //var responseEmision = servicio.EmiteAxa(root.ToString());

                //var respuesta = Deserialize<LocktonServicios.XMLEntity.AXA.RESPUESTA>(responseEmision);
                //API
                RestSharp.RestClient client = new RestSharp.RestClient(api);
                var postRequest = new RestSharp.RestRequest(RestSharp.Method.POST);
                var request = new RequestAPI();
                request.s4_key = key;
                request.b = b;
                request.v1 = root.ToString().Replace("\r\n", "");
                log.Info(string.Format("Emisión AXA-Flotilla Request: {0}", root.ToString()));
                postRequest.AddJsonBody(JsonConvert.SerializeObject(request));

                var resultAPI = client.Execute(postRequest);
                log.Info(string.Format("Emisión AXA-Flotilla Response: {0}", resultAPI.Content));
                if (resultAPI.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    log.Error("Error AXA-Flotilla: " + resultAPI.Content);
					GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, root.ToString(), content, resultAPI.Content, "Emisión");

					result = new EmisionPoliza(false, resultAPI.Content, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde. ", null);
                }
                else
                {
                    var i = resultAPI.Content.IndexOf("<RESPUESTA>");
                    var e = resultAPI.Content.LastIndexOf("</RESPUESTA>") + 12;
                    content = System.Net.WebUtility.HtmlDecode(resultAPI.Content.Substring(i, e - i));

                    var respuesta = Deserialize<LocktonServicios.XMLEntity.AXA.RESPUESTA>(content);

                    if (!string.IsNullOrEmpty(respuesta.error))
                    {
                        log.Error("Error AXA-Flotilla: " + respuesta.error);
                        result = new EmisionPoliza(false, respuesta.error, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde. " + respuesta.error, null);
                    }
                    else if (string.IsNullOrEmpty(respuesta.inciso))
                    {
                        log.Error("Error AXA-Flotilla: No hubo una respuesta valida por parte del servicio");
                        result = new EmisionPoliza(false, respuesta.error, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde. ", null);
                    }
                    else
                    {
                        Poliza poliza = new Poliza();
                        PolizaDetalle polizaDet = new PolizaDetalle();

                        Endoso endosoAlta = new Endoso();
                        endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                        endosoAlta.Fecha = DateTime.Now;
                        endosoAlta.ValorAnterior = "Alta";
                        endosoAlta.ValorActual = "Contratación";

                        decimal primaNeta = Convert.ToDecimal(response.reciboPoliza.primaNeta);
                        decimal primaTotal = Convert.ToDecimal(response.reciboPoliza.primaTotal);
                        decimal derechos = Convert.ToDecimal(response.reciboPoliza.derechos);
                        decimal impuestos = Convert.ToDecimal(response.reciboPoliza.impuestos);
                        decimal recargo = Convert.ToDecimal(response.reciboPoliza.recargos);
                        decimal primerPago = Convert.ToDecimal(response.primerRecibo.primaTotal);
                        decimal pagoSubsecuente = Convert.ToDecimal(response.reciboSubsecuentes.primaTotal);

                        poliza.NumeroPoliza = string.Format("{0}_{1}", cotizacion.datosPoliza.numeroPoliza, respuesta.inciso);
                        poliza.FinVigencia = DateTime.ParseExact(response.datosGenerales[0].vigenciaHasta, "dd/MM/yy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                        poliza.InicioVigencia = DateTime.ParseExact(response.datosGenerales[0].vigenciaDesde, "dd/MM/yy", CultureInfo.InvariantCulture, DateTimeStyles.None);

                        poliza.PrimaNeta = primaNeta;
                        poliza.PrimaNetaAnualizada = primaNeta;
                        poliza.PrimaTotal = primaTotal;
                        poliza.PrimaTotalAnualizada = primaTotal;

                        poliza.Motor = InfoEmision.NumeroMotor;
                        poliza.Serie = InfoEmision.NumeroSerie;
                        poliza.Placas = InfoEmision.Placas;
                        poliza.FechaEmision = DateTime.Now;
                        poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                        poliza.UrlPDFPoliza = respuesta.url;
                        poliza.UrlPDFRecibos = "";
                        poliza.Estatus = 1;
                        poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                        poliza.IdConvenio = InfoEmision.Convenio.Id;
                        poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                        poliza.IdTipoCobertura = tipoPaquete.IdCatTipoPaquete;
                        poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
                        poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                        poliza.Acepto_DescuentoPoliza = true;

                        polizaDet.Inciso = "1";
                        polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para AXA flotilla.
                        polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                        polizaDet.Deducible = 0;
                        polizaDet.Comision = 0;
                        polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
                        polizaDet.MigraOPERA = false;
                        polizaDet.UrlPDFPolizaOPERA = "";
                        polizaDet.PolizaOPERA = 0;
                        polizaDet.OTOpera = 0;
                        polizaDet.EndosoOPERA = 0;
                        polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                        polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;
                        polizaDet.IdCatRamoVehiculo = cotizacionDetalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                        polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                        polizaDet.IdCatModalidadFormaPago = medioPago.Id;
                        polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
                        polizaDet.XMLRecepcion = content;
                        polizaDet.XMLSolicitud = root.ToString();
                        polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;
                        poliza.UrlPDFPoliza = respuesta.url;

                        List<Recibo> recibosGenerados = new List<Recibo>();

                        Recibo reciboSave = new Recibo();
                        reciboSave.InicioVigencia = poliza.InicioVigencia;
                        reciboSave.FinVigencia = poliza.FinVigencia;
                        reciboSave.Numero = 1;
                        reciboSave.NoAsegurado = "1";
                        reciboSave.PrimaNeta = Convert.ToDecimal(response.primerRecibo.primaNeta);
                        reciboSave.PrimaTotal = Convert.ToDecimal(response.primerRecibo.primaTotal);
                        reciboSave.Derecho = Convert.ToDecimal(response.primerRecibo.derechos);
                        reciboSave.Recargo = Convert.ToDecimal(response.primerRecibo.recargos);
                        reciboSave.Comision = Convert.ToDecimal(response.primerRecibo.cesionComision);
                        reciboSave.Impuesto = Convert.ToDecimal(response.primerRecibo.impuestos);
                        recibosGenerados.Add(reciboSave);

                        if(response.reciboSubsecuentes != null)
                        {
                            int numRecibosSubsecuentes = 0;
                            if (int.TryParse(response.reciboSubsecuentes.numeroRecibos, out numRecibosSubsecuentes)) {
                                for (int r = 1; r <= numRecibosSubsecuentes; r++)
                                {
                                    Recibo reciboSub = new Recibo();
                                    reciboSub.InicioVigencia = poliza.InicioVigencia;
                                    reciboSub.FinVigencia = poliza.FinVigencia;
                                    reciboSub.Numero = r+1;
                                    reciboSub.NoAsegurado = "1";
                                    reciboSub.PrimaNeta = Convert.ToDecimal(response.reciboSubsecuentes.primaNeta / numRecibosSubsecuentes);
                                    reciboSub.PrimaTotal = Convert.ToDecimal(response.reciboSubsecuentes.primaTotal / numRecibosSubsecuentes);
                                    reciboSub.Derecho = Convert.ToDecimal(response.reciboSubsecuentes.derechos);
                                    reciboSub.Recargo = Convert.ToDecimal(response.reciboSubsecuentes.recargos);
                                    reciboSub.Comision = Convert.ToDecimal(response.reciboSubsecuentes.cesionComision);
                                    reciboSub.Impuesto = Convert.ToDecimal(response.reciboSubsecuentes.impuestos / numRecibosSubsecuentes);
                                    recibosGenerados.Add(reciboSub);
                                }
                            }

                        }

                        endosoAlta.Recibo = recibosGenerados;
                        poliza.Endoso.Add(endosoAlta);
                        poliza.PolizaDetalle.Add(polizaDet);
                        db.Poliza.Add(poliza);
                        db.SaveChanges();

						GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, root.ToString(), content,"", "Emisión");

                        Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                        result = new EmisionPoliza(true, root.ToString(), content, poliza);

                    }
                }


            }
            catch (Exception ex)
            {
				GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, root.ToString(), content, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");

				log.Info(string.Format("Tuvimos un inconveniente para realizar tu cotizacion {0}", ex.Message));
				result = new EmisionPoliza(false, ex.Message, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde. ", null);

			}




            return result;
        }

       

        private string TokenizarTarjeta(InformacionEmision ObjData, string numeroPoliza)
        {
            log.Info($"Inicia proceso para tokenizar tarjeta");
            #region Tokeniza tarjeta									

            string tokenTarjeta = string.Empty;
            if (!string.IsNullOrEmpty(ObjData.Tarjeta.NumeroTarjeta))
            {
                TokenOauthRequest tkn = new TokenOauthRequest();
                TokenRequest tokenTar = new TokenRequest();
                string varUrlrOauth, varUsrOauth, varPswOauth, varUrlTokeniza = string.Empty;

                tkn.claims.scope = "/pci/tokenizaTarjeta";
                tkn.config.expiresIn = 300;

                //CredentialCache myCache = new CredentialCache();
                if (ConfigurationManager.AppSettings["TipoConexion"].Equals("1") ? false : true)
                {
                    varUrlrOauth = "oauthTokenProd";//Prod 
                    varUsrOauth = "usrOauthAXAProd";
                    varPswOauth = "pswOauthAXAProd";
                    varUrlTokeniza = "TokenizaProd";

                }
                else
                {
                    varUrlrOauth = "oauthTokenTest";//QA
                    varUsrOauth = "usrOauthAXATest";
                    varPswOauth = "pswOauthAXATest";
                    varUrlTokeniza = "TokenizaTest";
                }

                varUrlrOauth = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varUrlrOauth);
                varUsrOauth = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varUsrOauth);
                varPswOauth = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varPswOauth);
                varUrlTokeniza = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varUrlTokeniza);

                string tokenBearer = LocktonServicios.Utilidades.Utilidades.GetToken(varUrlrOauth, varUsrOauth, varPswOauth, tkn);

                Guid g;
                // Create and display the value of two GUIDs.
                g = Guid.NewGuid();

                tokenTar.AXAHeaderReq.ramo = "COL";
                tokenTar.AXAHeaderReq.medio = "WEB";
                tokenTar.AXAHeaderReq.transaccion = "";
                tokenTar.AXAHeaderReq.evento = "";
                tokenTar.AXAHeaderReq.segmento = "";
                tokenTar.AXAHeaderReq.rol = "Agente";
                tokenTar.AXAHeaderReq.usuario = "MXS02009708A";
                tokenTar.AXAHeaderReq.sistemaId = "SRV007";
                tokenTar.AXAHeaderReq.version = "1.0";
                tokenTar.AXAHeaderReq.UUID = g.ToString();
                tokenTar.AXAHeaderReq.fechaHora = DateTime.UtcNow.ToString("s");

                //tokenTar.data.referencia = "SRV007+" + numeroPoliza + "+0";
                tokenTar.data.referencia = $"SRV007+{ObjData.IdCotizacion}{DateTime.Now.ToString("yyyyMMddHHmmss")}+0";
                tokenTar.data.datosTarjeta.PAN = ObjData.Tarjeta.NumeroTarjeta;
                tokenTar.data.nombre = ObjData.Tarjeta.NombreTitularTarjeta;
                tokenTar.data.apellidoPaterno = ObjData.Tarjeta.ApellidoPTitularTarjeta;
                tokenTar.data.apellidoMaterno = ObjData.Tarjeta.ApellidoMTitularTarjeta;
                tokenTar.data.MSI = 0;
                tokenTar.data.fechaVencimiento = ObjData.Tarjeta.MesVencimiento + "/" + ObjData.Tarjeta.AnioVencimiento.ToString().Substring(2);
                tokenTar.data.email = ObjData.Tarjeta.Email;

                var respuesta = Tokenizar(varUrlTokeniza, tokenBearer, tokenTar);
                //REGISTRO OPL
                JavaScriptSerializer serializador = new JavaScriptSerializer();
                tokenTar.data.datosTarjeta.PAN = "****************";
                tokenTar.data.fechaVencimiento = "**/**";
                string jsonReqst = serializador.Serialize(tokenTar);


                if (respuesta.AXAHeaderRes.resultado.codigo == 0)
                {
                    tokenTarjeta = respuesta.data.tokenClabe;
                    RegistraOPL(numeroPoliza, jsonReqst, tokenTarjeta, "Pago Con Tarjeta", 1, true);
                }
                else
                {
                    RegistraOPL(numeroPoliza, jsonReqst, respuesta.AXAHeaderRes.resultado.mensaje, "Pago Con Tarjeta", 1, false);
                    throw new Exception(respuesta.AXAHeaderRes.resultado.mensaje);
                }
            }

            #endregion Tokeniza tarjeta
            log.Info($"Finaliza proceso para tokenizar tarjeta");
            return tokenTarjeta;
        }

        private void RegistraOPL(string numeroPoliza, string xml, string respuesta, string tipo, int idTipo, bool exitoso)
        {
            try
            {
                using (var _db = new ApplicationDbContext())
                {
                    var oplRegistro = new PolizaRegistroCobranza();
                    oplRegistro.Exitoso = exitoso;
                    oplRegistro.Fecha = DateTime.Now;
                    oplRegistro.FechaResponse = DateTime.Now;
                    oplRegistro.IdTipoOPL = idTipo;
                    oplRegistro.NumeroPoliza = numeroPoliza;
                    oplRegistro.Response = respuesta;
                    oplRegistro.TipoOPL = tipo;
                    oplRegistro.Request = xml;
                    oplRegistro.IdAseguradora = 10;

                    _db.PolizaRegistroCobranza.Add(oplRegistro);
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado RegistraOPL Qualitas: " + ex.Message, ex);
            }
        }

        public TokenResponse Tokenizar(string url, string tkn, TokenRequest ccrequest)
        {


            JavaScriptSerializer serializador = new JavaScriptSerializer();
            RestClient client = new RestSharp.RestClient(url);
            RestRequest request = new RestSharp.RestRequest(Method.POST);
            client.AddDefaultHeader("Authorization", "Bearer " + tkn);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            string jsonReqst = serializador.Serialize(ccrequest);
            request.AddJsonBody(ccrequest);

            RestSharp.IRestResponse response = client.Execute(request);
            string content = response.Content; // raw content as string

            TokenResponse resp = serializador.Deserialize<TokenResponse>(content);
            return resp;



        }

        public Comparar LeeXmlRespuesta(string XmlResultado, int IdTipoPaquete, string xmlEnvio, Convenio convenioCotiza)
        {
            Comparar infoCompara = new Comparar();

            try
            {
                AXAFlotillasCotizacion.DatosCotizacion response = ToObject<AXAFlotillasCotizacion.DatosCotizacion>(XmlResultado);
                AXAFlotillasCotizacion.DatosSolicitud cotizacion = ToObject<AXAFlotillasCotizacion.DatosSolicitud>(xmlEnvio);
                infoCompara.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                infoCompara.Aseguradora = "AXA";
                infoCompara.Cobertura = IdTipoPaquete.ToString();
                infoCompara.XmlEmision = xmlEnvio;
                infoCompara.XmlRespuesta = XmlResultado;
                infoCompara.CaratulaCotizacion = cotizacion.datosPoliza.numeroPoliza;
                if (convenioCotiza != null)
                {
                    infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                    infoCompara.IdConvenio = convenioCotiza.Id;
                }

                infoCompara.CotizacionClave = response.datosGenerales.FirstOrDefault().solicitud;
                infoCompara.Coberturas = new List<Coberturas>();
                var coberturasConvenio = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete);
                var tipoDatos = db.CatTipoDatoDeducible.ToList();

                foreach (var cobertura in response.primasCoberturas)
                {
                    Coberturas cotCob = new Coberturas();

                    cotCob.Cobertura = cobertura.prima.ToString();
                    cotCob.SumaAsegurada = cobertura.sumaAsegurada.ToString();
                    cotCob.Nombre = cobertura.nombreCobertura.Trim();
                    cotCob.Deducible = cobertura.deducible.ToString();
                    cotCob.Codigo = cobertura.claveCobertura.ToString();
                    cotCob.PrimaNeta = cobertura.prima.ToString();

                    var coberturaConfigurada = coberturasConvenio.FirstOrDefault(a => a.Codigo == cobertura.claveCobertura.ToString());
                    if (coberturaConfigurada != null)
                    {                       
                        var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == coberturaConfigurada.IdTipoDatoDeducible);

                        cotCob.IdTipoDatoDeducible = tipoDato.Id;
                        cotCob.TipoDato = tipoDato.Nombre;                       
                    }

                    infoCompara.Coberturas.Add(cotCob);
                }

                if (convenioCotiza != null)
                {
                   
                    if (coberturasConvenio.Exists(a => a.Codigo == "RCEXTR"))
                    {
                        var rcext = coberturasConvenio.FirstOrDefault(a => a.Codigo == "RCEXTR");
                        Coberturas cotCob = new Coberturas();

                        cotCob.Cobertura = "0";
                        cotCob.SumaAsegurada = "0";
                        cotCob.Nombre = rcext.Nombre.Trim();
                        cotCob.Deducible = "";
                        cotCob.Codigo = rcext.Codigo.ToString();
                        cotCob.PrimaNeta = "0";
                        infoCompara.Coberturas.Add(cotCob);
                    }
                }

                infoCompara.PrimaNeta = response.reciboPoliza.primaNeta.ToString();
                infoCompara.PrimaTotal = response.reciboPoliza.primaTotal.ToString();
                infoCompara.Impuesto = response.reciboPoliza.impuestos.ToString();
                infoCompara.Recargo = response.reciboPoliza.recargos.ToString();
                infoCompara.Derecho = response.reciboPoliza.derechos.ToString();

                infoCompara.PrimerPago = response.primerRecibo.primaTotal.ToString();
                infoCompara.NumeroDePagos = string.IsNullOrEmpty(response.reciboSubsecuentes.numeroRecibos) ? 1 : Convert.ToInt32(response.reciboSubsecuentes.numeroRecibos);
                infoCompara.SegundoPago = infoCompara.NumeroDePagos > 1 ? (response.reciboSubsecuentes.primaTotal / infoCompara.NumeroDePagos).ToString() : "";


                infoCompara.FechaInicio = response.datosGenerales.FirstOrDefault().vigenciaDesde;
                infoCompara.FechaFin = response.datosGenerales.FirstOrDefault().vigenciaHasta;
                infoCompara.Año = response.datosGenerales[0].modelo;


            }
            catch (Exception)
            {
                throw;
            }
            return infoCompara;
        }

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }

        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }

        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }


        public ReimprimirPolizaEstatus ReimprimePoliza(string numeroPoliza, string usuario, string pass)
        {
            var result = new ReimprimirPolizaEstatus();
			var service = new AXAFlotillasCotizacion.WSFlotillasClient();
			
			service.ClientCredentials.UserName.UserName = usuario;
			service.ClientCredentials.UserName.Password = pass;
            service.InnerChannel.OperationTimeout = new TimeSpan(1, 0, 0, 0);

            
            try
            {
                var request = new AXAFlotillasCotizacion.SolicitudImpresion();
                int inciso = 0;
                var _numeroPoliza = numeroPoliza.Split('_')[0];
                var _inciso = numeroPoliza.Split('_')[1];

                if (int.TryParse(_inciso, out inciso)) {

                    request.obtenerPDF = true;
                    request.obtenerPDFSpecified = true;                   
                    request.caratulaPoliza = false;
                    request.numeroPoliza = _numeroPoliza;
                    request.numeroInciso =inciso;

                    var response = service.ImprimirInciso(request).FirstOrDefault();
                    

                    result.Exitoso = true;
                    result.Documento = response.archivoPDF;
                    result.ContentType = "application/pdf";
                }
                else
                {
					result.Mensaje = "Documento no encontrado";
					result.Exitoso = false;
				}

			}
			catch (Exception ex)
			{
                result.Mensaje = ex.Message;
                result.Exitoso = false;
				
				log.Error("Error ReimprimePoliza AXA FLOTILLAS " + ex.ToString());

			}

            return result;
		}

		private static int[] getMarcaTipoVehiculo(string amis)
        {
            int[] datosVehiculo = new int[2];
            int sizeAmis = amis.Length;
            try
            {
                switch (sizeAmis)
                {
                    case 1:
                    case 2:
                        datosVehiculo[0] = 0;//Marca
                        datosVehiculo[1] = Convert.ToInt32(amis);//Tipo
                        break;
                    case 3:
                        datosVehiculo[0] = Convert.ToInt32(amis.Substring(0, 1));
                        datosVehiculo[1] = Convert.ToInt32(amis.Substring(1, 2));
                        break;
                    case 4:
                        datosVehiculo[0] = Convert.ToInt32(amis.Substring(0, 2));
                        datosVehiculo[1] = Convert.ToInt32(amis.Substring(2, 2));
                        break;
                    case 5:
                        datosVehiculo[0] = Convert.ToInt32(amis.Substring(0, 3));
                        datosVehiculo[1] = Convert.ToInt32(amis.Substring(3, 2));
                        break;
                }
            }
            catch (Exception)
            {

            }
            return datosVehiculo;
        }

        private List<Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete)
        {
            //List<SolicitudCoberturasCobertura> coberturas = new List<SolicitudCoberturasCobertura>();

            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio && a.IdCatTipoPaquete == idPaquete
                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", ""),
                                               IdCatRamo = c.IdCatRamoVehiculo,
                                               IdCobertura = b.Id,
                                               IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1
                                           }).ToList();
            return coberturas;
        }

        private static string Serialize(object dataToSerialize)
        {
            if (dataToSerialize == null) return null;

            using (StringWriter stringwriter = new System.IO.StringWriter())
            {
                var serializer = new XmlSerializer(dataToSerialize.GetType());
                serializer.Serialize(stringwriter, dataToSerialize);
                return stringwriter.ToString();
            }
        }

        private T Deserialize<T>(string input) where T : class
        {
            System.Xml.Serialization.XmlSerializer ser = new System.Xml.Serialization.XmlSerializer(typeof(T));

            using (StringReader sr = new StringReader(input))
                return (T)ser.Deserialize(sr);
        }


        private XElement XmlCoberturas(AXAFlotillasCotizacion.DatosSolicitud cotizacion)
        {
            XElement root = new XElement("datosCoberturas");
            root.Add(new XElement("afianzadora", cotizacion.datosCoberturas.afianzadora));
            root.Add(new XElement("servidora", cotizacion.datosCoberturas.servidora));
            root.Add(new XElement("tipoValor", cotizacion.datosCoberturas.tipoValor));
            root.Add(new XElement("porcentajeValor", cotizacion.datosCoberturas.porcentajeValor));
            root.Add(new XElement("valorUnidad", cotizacion.datosCoberturas.valorUnidad));
            root.Add(new XElement("servicio", cotizacion.datosCoberturas.servicio));
            root.Add(new XElement("tipoCarga", cotizacion.datosCoberturas.tipoCarga));
            root.Add(new XElement("benefAccidentes", cotizacion.datosCoberturas.benefAccidentes));
            root.Add(new XElement("uso", cotizacion.datosCoberturas.uso));
            root.Add(new XElement("viajeros", cotizacion.datosCoberturas.viajeros));
            root.Add(new XElement("suva", cotizacion.datosCoberturas.suva));
            root.Add(new XElement("dobleRemolque", cotizacion.datosCoberturas.dobleRemolque));
            root.Add(new XElement("arrastre", cotizacion.datosCoberturas.arrastre));
            root.Add(new XElement("tipoDeducible", cotizacion.datosCoberturas.tipoDeducible));
            var e = 1;
            foreach (var item in cotizacion.datosCoberturas.coberturasAmparar.ToList())
            {
                if (string.IsNullOrEmpty(item.deducible))
                {
                    root.Add(new XElement("coberturasAmparar"
                        , new XElement("claveCobertura", item.claveCobertura.ToString())
                        , new XElement("sumaAsegurada", item.sumaAsegurada)));
                }
                else
                {
                    root.Add(new XElement("coberturasAmparar"
                        , new XElement("claveCobertura", item.claveCobertura.ToString())
                        , new XElement("deducible", item.deducible ?? " ")
                        , new XElement("sumaAsegurada", item.sumaAsegurada)));
                }

                e++;
            }
            return root;
        }

        public T ToObject<T>(string toDeserialize)
        {
            StringReader reader = new StringReader(toDeserialize);
            XmlSerializer xs = new XmlSerializer(typeof(T));
            T resultado = (T)xs.Deserialize(reader);
            reader.Close();
            return resultado;
        }
        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

    }
}
public class EmiteAxaResponse
{
    public string EmiteAxaResult { get; set; }
}
public class RequestAPI
{
    public string s4_key { get; set; }
    public string b { get; set; }
    public string v1 { get; set; }
}
