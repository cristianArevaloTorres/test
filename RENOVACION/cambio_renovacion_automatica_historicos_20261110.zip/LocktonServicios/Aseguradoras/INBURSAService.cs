﻿using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonServicios.Catalogos;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace LocktonServicios.Aseguradoras
{
    public class INBURSAService : IOperacionesAseguradoras
    {
        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger(typeof(INBURSAService));
      
        public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara,
                                                    int? convenioId,
                                                    mDetalles cot,
                                                    DetalleUsuario detalleUsuario,
                                                    VEmpConvPaq ConveniosPaquetes,
                                                    int IdTipoPaquete,
                                                    int idPaqueteConvenio)
        {
            if (cot == null || cot.Catalogo.Count() == 0)
            {
                CotizacionCompara.Comparar.Add(new Comparar() { ErrorXML = "No se encontró el vehiculo dentro del catalogo" });
            }
            else
            {
                Tarificador.TarificadorClient tarificador = new Tarificador.TarificadorClient();
                ConsultaHomologacion consultaHomologacion = new ConsultaHomologacion();
                Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
                ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
                descripciones _cotDesAuto = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault();
                CatTipoPaquete tipoPaquete = db.CatTipoPaquete.FirstOrDefault(a => a.Id == IdTipoPaquete);
                PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioId && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
                var paqueteconvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                var catperiodicidadformapago = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == CotizacionCompara.FormadePago);
                CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                //Obtencion de costo para el TipoPaquete
                CostosInbursa bloques = consultaHomologacion.ConsultarCostosInbursa(_cotDesAuto.clave, Convert.ToInt32(CotizacionCompara.Año), Convert.ToInt32(tipoPaquete.Clave), convenioCotiza.IdTarifa ??0);
                //var costoRenovacion = 0d;

                //if (!string.IsNullOrEmpty(CotizacionCompara.NumeroDePoliza))//RENOVACION
                //{
                //	var otRenovacion = db.OTRenovacion.FirstOrDefault(a => a.NumeroDePoliza == CotizacionCompara.NumeroDePoliza && a.Estatus == 1);
                //	if (otRenovacion != null && otRenovacion.PrimaTotal.HasValue)
                //		costoRenovacion = Convert.ToDouble(otRenovacion.PrimaTotal.Value);
                //}

                if (bloques != null && bloques.Costos != null)
                {

                    foreach (CostoINBURSA bloque in bloques.Costos)
                    {
                        Comparar infoCompara = new Comparar();
                        //if (costoRenovacion > 0)
                        //	bloque.Costo = costoRenovacion;

                     
                        List<Tarificador.ListaDeCobro> recibos = new List<Tarificador.ListaDeCobro>();

                        //if(CotizacionCompara.ComparativoAnual)
                        //	recibos = tarificador.GetRecibosContadoOffline(convenioId.Value, flotilla, bloque.Costo, CotizacionCompara.FechaCotizacion).ToList();
                        //else


                        infoCompara.FechaCotizacion = CotizacionCompara.FechaInicio;
                       string InicioVigencia = CotizacionCompara.FechaInicio.ToString("dd/MM/yyyy");
                        string FinVigencia = CotizacionCompara.FechaFin.ToString("dd/MM/yyyy");
                        List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, Convert.ToInt32(CotizacionCompara.Año), bloque.IdBloque, CotizacionCompara.TipoVehiculo);
                        //if (ConfigEmpresa.IdTipoDeNegocio == 2)
                        //{
                        //	InicioVigencia = DateTime.Now.ToString("dd/MM/yyyy");
                        //	FinVigencia = DateTime.Now.AddYears(1).ToString("dd/MM/yyyy");
                        //}
                        //else
                        //{
                        //	if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, DateTime.Now))
                        //	{
                        //		InicioVigencia = DateTime.Now.ToString("dd/MM/yyyy");
                        //	}
                        //}
                        //if (Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, DateTime.Now))
                        //{
                        //	CotizacionCompara.FechaCotizacion = convenioCotiza.InicioVigencia;
                        //	InicioVigencia = convenioCotiza.InicioVigencia.ToString("dd/MM/yyyy");
                        //}
                        log.Info( string.Format("INBURSA Cotización Envio tarificador IDconvenio = {0},  IdCatTipoVigencia = {1}, FormaPago = {2}, Costo = {3}, FechaInicio = {4}", convenioId.Value, convenioCotiza.IdCatTipoVigencia == 1, perioricidad.FormaPago, bloque.Costo, CotizacionCompara.FechaInicio.Date));
                        recibos = tarificador.GetRecibos(convenioId.Value, convenioCotiza.IdCatTipoVigencia==1, perioricidad.FormaPago, bloque.Costo, CotizacionCompara.FechaInicio.Date).ToList();
                        string objetcts = string.Empty;
                        objetcts = JsonConvert.SerializeObject(recibos);
                        log.Info("INBURSA Cotización Request tarificador " + objetcts);
                        if (recibos.Any())
                        {
                            Tarificador.ListaDeCobro primerRecibo = recibos.Find(a => a.Index == 0);
                            if (string.IsNullOrEmpty(primerRecibo.MensajeError))
                            {

                                if (bloque.IdTipoCobertura == 3)
                                    bloque.Bloque = bloque.Bloque.Substring(bloque.Bloque.LastIndexOf("RT"));
                                infoCompara.XmlEmision = "";
                                infoCompara.XmlRespuesta = GeneraDatosGenericos(bloque, string.Format("{0} {1}", tipoPaquete.Nombre, bloque.Bloque));
                                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                                infoCompara.IdConvenio = convenioCotiza.Id;
                                infoCompara.Aseguradora = "INBURSA";
                                infoCompara.Año = CotizacionCompara.Año;
                                infoCompara.FechaInicio = InicioVigencia;
                                infoCompara.FechaFin = FinVigencia;
                                infoCompara.Coberturas = coberturasPaquete;
                                infoCompara.Bloque = bloque.Bloque;
								infoCompara.Cobertura = IdTipoPaquete.ToString();

								infoCompara.IdPaqueteConvenio = paqueteconvenio.Id;
                                infoCompara.NombrePaqueteConvenio = paqueteconvenio.NombrePaquete;
                                infoCompara.IdCatTipoPaquete = paqueteconvenio.IdCatTipoPaquete;
                                infoCompara.FormaPagoEtiqueta = catperiodicidadformapago.Nombre;
                                infoCompara.MedioPagoEtiqueta = medioPago.Nombre;
                                infoCompara.IdFormaPago = catperiodicidadformapago.Id;
                                infoCompara.IdMedioPago = medioPago.Id;
                                CotizacionCompara.FechaFactura = CotizacionCompara.FechaInicio;

                                infoCompara.PrimaNeta = primerRecibo.PrimaNeta.ToString();
                                infoCompara.PrimaTotal = primerRecibo.PrimaTotal.ToString();
                                infoCompara.CostoTotal = primerRecibo.PrimaAnualizada.ToString();
                                infoCompara.Impuesto = primerRecibo.Impuesto.ToString();
                                infoCompara.Recargo = primerRecibo.Comision.ToString();
                                infoCompara.Derecho = primerRecibo.DerechoDePolizaTotal.ToString();

                                infoCompara.PrimaAnualizada = Utilidades.Utilidades.CalculaPrimaAnualizada(DateTime.Parse(InicioVigencia), DateTime.Parse(FinVigencia), infoCompara.PrimaNeta, infoCompara.Derecho, infoCompara.CesionComision);

                                infoCompara.PrimerPago = primerRecibo.CobroCorte.ToString();
                                if (recibos.Count == 1)
                                    infoCompara.SegundoPago = "";
                                else if (recibos.Find(a => a.Index == 1) != null)
                                    infoCompara.SegundoPago = recibos.Find(a => a.Index == 1).CobroCorte.ToString();
                                else
                                    infoCompara.SegundoPago = "";

                                CotizacionCompara.Comparar.Add(infoCompara);
                            }
                            else
                                CotizacionCompara.Comparar.Add(new Comparar() { ErrorXML = primerRecibo.MensajeError });
                        }
                        else
                        {
                            CotizacionCompara.Comparar.Add(new Comparar() { ErrorXML = "No se encontró un calendario configurado" });
                        }


                    }
                }
            }

            return CotizacionCompara;
        }

        public CotizacionCompara CotizarVehiculoCeroComision(CotizacionCompara CotizacionCompara,
                                                    int? convenioId,
                                                    DetalleUsuario detalleUsuario,
                                                    VEmpConvPaq ConveniosPaquetes,
                                                    int IdTipoPaquete)
        {
            ConsultaHomologacion consultaHomologacion = new ConsultaHomologacion();
            Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
            CatTipoPaquete tipoPaquete = db.CatTipoPaquete.FirstOrDefault(a => a.Id == IdTipoPaquete);
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioId && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
            var catperiodicidadformapago = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == CotizacionCompara.FormadePago);
            CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
            //Obtencion de costo para el TipoPaquete
            CostosInbursa bloques = consultaHomologacion.ConsultarCostosInbursa("", Convert.ToInt32(CotizacionCompara.Año), Convert.ToInt32(tipoPaquete.Clave), convenioCotiza.IdTarifa??0);

            if (bloques != null && bloques.Costos != null)
            {
                bloques.Costos = bloques.Costos.Where(a => a.IdBloque == CotizacionCompara.Bloque).ToList();
                foreach (CostoINBURSA bloque in bloques.Costos)
                {
                    bool flotilla = ConfigEmpresa.IdTipoDeNegocio == 1 || ConfigEmpresa.IdTipoDeNegocio == 4;
                    string InicioVigencia = CotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy");
                    string FinVigencia = convenioCotiza.FinVigencia.ToString("dd/MM/yyyy");
                    List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, Convert.ToInt32(CotizacionCompara.Año), bloque.IdBloque, CotizacionCompara.TipoVehiculo);


                    Comparar infoCompara = new Comparar();
                    if (bloque.IdTipoCobertura == 3)
                        bloque.Bloque = bloque.Bloque.Substring(bloque.Bloque.LastIndexOf("RT"));
                    infoCompara.XmlEmision = "";
                    infoCompara.XmlRespuesta = GeneraDatosGenericos(bloque, string.Format("{0} {1}", tipoPaquete.Nombre, bloque.Bloque));
                    infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                    infoCompara.IdConvenio = convenioCotiza.Id;
                    infoCompara.Aseguradora = "INBURSA";
                    infoCompara.Año = CotizacionCompara.Año;
                    infoCompara.FechaInicio = InicioVigencia;
                    infoCompara.FechaFin = FinVigencia;
                    infoCompara.Coberturas = coberturasPaquete;
                    infoCompara.Bloque = bloque.Bloque;
                    infoCompara.Cobertura = IdTipoPaquete.ToString();
                    CotizacionCompara.FechaFactura = CotizacionCompara.FechaCotizacion;
                    infoCompara.FechaCotizacion = CotizacionCompara.FechaCotizacion;
                    infoCompara.IdFormaPago = catperiodicidadformapago.Id;
                    infoCompara.IdMedioPago = medioPago.Id;

                    infoCompara.PrimaNeta = "0.00";
                    infoCompara.PrimaTotal = "0.00";
                    infoCompara.CostoTotal = "0.00";
                    infoCompara.Impuesto = "0.00";
                    infoCompara.Recargo = "0.00";
                    infoCompara.Derecho = "0.00";

                    infoCompara.PrimerPago = "0.00";
                    infoCompara.SegundoPago = "";

                    CotizacionCompara.Comparar.Add(infoCompara);

                }
            }

            return CotizacionCompara;
        }
        public Comparar LeeXmlRespuesta(string XmlResultado, int IdTipoPaquete, int year, Cotizacion cotizacion, CotizacionDetalle detalle, Convenio convenioCotiza, string tipoVehiculo)
        {
            Comparar infoCompara = new Comparar();
            double costo = 0;
            Tarificador.TarificadorClient tarificador = new Tarificador.TarificadorClient();
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioCotiza.Id && x.IdCatPeriodicidadFormaPago == cotizacion.IdPeriodicidadPago).FirstOrDefault();
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
            string InicioVigencia = cotizacion.FechaFactura.ToString("dd/MM/yyyy");
            string FinVigencia = convenioCotiza.FinVigencia.ToString("dd/MM/yyyy");

            XmlDocument xmlDetalle = new XmlDocument();
            xmlDetalle.LoadXml(XmlResultado);

            string costoCotizacion = xmlDetalle.SelectNodes("INBURSA/CostoTotal")[0].InnerText;
            double.TryParse(costoCotizacion, out costo);
           
            List<Tarificador.ListaDeCobro> recibos = new List<Tarificador.ListaDeCobro>();
            if (perioricidad == null)
                recibos = tarificador.GetRecibosContadoOffline(convenioCotiza.Id, convenioCotiza.IdCatTipoVigencia == 1, costo, cotizacion.FechaFactura.Date).ToList();
            else
                recibos = tarificador.GetRecibos(convenioCotiza.Id, convenioCotiza.IdCatTipoVigencia == 1, perioricidad.FormaPago, costo, cotizacion.FechaFactura.Date).ToList();

            //if (ConfigEmpresa.IdTipoDeNegocio == 2)
            //{
            //	InicioVigencia = DateTime.Now.ToString("dd/MM/yyyy");
            //	FinVigencia = DateTime.Now.AddYears(1).ToString("dd/MM/yyyy");
            //}
            //else
            //{
            //	if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, DateTime.Now))
            //	{
            //		InicioVigencia = DateTime.Now.ToString("dd/MM/yyyy");
            //	}
            //}
            int idBloque = Convert.ToInt32(xmlDetalle.SelectNodes("INBURSA/IdBloque")[0].InnerText);
            List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, year, idBloque, tipoVehiculo);

            infoCompara.XmlEmision = "";
            infoCompara.XmlRespuesta = XmlResultado;
            infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
            infoCompara.IdConvenio = convenioCotiza.Id;
            infoCompara.Aseguradora = "INBURSA";
            infoCompara.Año = year.ToString();
            infoCompara.FechaInicio = InicioVigencia;
            infoCompara.FechaFin = FinVigencia;
            infoCompara.Coberturas = coberturasPaquete;
            infoCompara.Bloque = xmlDetalle.SelectNodes("INBURSA/Bloque")[0].InnerText;
            infoCompara.Cobertura = IdTipoPaquete.ToString();
            infoCompara.NumeroDePagos = recibos.Count() - 1;

            Tarificador.ListaDeCobro primerRecibo = recibos.Find(a => a.Index == 0);
            infoCompara.PrimaNeta = primerRecibo.PrimaNeta.ToString();
            infoCompara.PrimaTotal = primerRecibo.PrimaTotal.ToString();
            infoCompara.CostoTotal = primerRecibo.PrimaAnualizada.ToString();
            infoCompara.Impuesto = primerRecibo.Impuesto.ToString();
            infoCompara.Recargo = primerRecibo.Comision.ToString();
            infoCompara.Derecho = primerRecibo.DerechoDePolizaTotal.ToString();
            infoCompara.PrimaAnualizada = Utilidades.Utilidades.CalculaPrimaAnualizada(convenioCotiza.InicioVigencia, convenioCotiza.FinVigencia, infoCompara.PrimaNeta, infoCompara.Derecho, infoCompara.CesionComision);
            infoCompara.PrimerPago = primerRecibo.CobroCorte.ToString();
            if (recibos.Count == 1)
                infoCompara.SegundoPago = "";
            else if (recibos.Find(a => a.Index == 1) != null)
                infoCompara.SegundoPago = recibos.Find(a => a.Index == 1).CobroCorte.ToString();
            else
                infoCompara.SegundoPago = "";

            //infoCompara.SegundoPago = recibos.Count == 1 ? "" : recibos.Find(a => a.Index == 1).CobroCorte.ToString();

            return infoCompara;
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            Tarificador.TarificadorClient tarificador = new Tarificador.TarificadorClient();
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            CotizacionDetalle detalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
            Cotizacion cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == detalle.IdCotizacion);
            double costo = 0;
            CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Convenio.IdEmpresa).FirstOrDefault();

            DateTime InicioVigencia = cotizacion.FechaFactura;
            DateTime FinVigencia = InfoEmision.Convenio.FinVigencia;

            XmlDocument xmlDetalle = new XmlDocument();
            xmlDetalle.LoadXml(detalle.XMLRecepcion);

            string costoCotizacion = xmlDetalle.SelectNodes("INBURSA/CostoTotal")[0].InnerText;
            string paquete = xmlDetalle.SelectNodes("INBURSA/Paquete")[0].InnerText;
            double.TryParse(costoCotizacion, out costo);
            List<Tarificador.ListaDeCobro> recibos = tarificador.GetRecibos(InfoEmision.Convenio.Id, InfoEmision.Convenio.IdCatTipoVigencia == 1, perioricidad.FormaPago, costo, cotizacion.FechaFactura.Date).ToList();
            Tarificador.ListaDeCobro primerRecibo = recibos.Find(a => a.Index == 0);
            string tipoPropietario = InfoEmision.EsBeneficiarioPreferente ? "PLAN" : "PERSONAL";
            CatRamoVehiculo vehiculo = db.CatRamoVehiculo.Where(x => x.Clave == InfoEmision.CotizacionAutoGuardar.TipoVehiculo).FirstOrDefault();
            var parameters = new List<SqlParameter>()
            {
                new SqlParameter("@IdUsuario", InfoEmision.DetalleUsuario.IdUsuario),
                new SqlParameter("@TipoPropietario", tipoPropietario),
                new SqlParameter("@TipoAuto",vehiculo.Nombre.ToUpper()),
                new SqlParameter("@Paquete",paquete)
            };

            string caratula = db.Database.SqlQuery<string>("sp_CaratulasINBURSA_Obtener @IdUsuario, @TipoPropietario, @TipoAuto, @Paquete", parameters.ToArray()).SingleOrDefault();

            InfoEmision.CaratulaInbursa = caratula;
            //if (ConfigEmpresa.IdTipoDeNegocio == 2)
            //{
            //	InicioVigencia = DateTime.Now;
            //	FinVigencia = DateTime.Now.AddYears(1);
            //}
            //else
            //{
            //	if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(InfoEmision.Convenio.IdEmpresa, DateTime.Now))
            //	{
            //		InicioVigencia = DateTime.Now;
            //	}
            //}

            Poliza poliza = new Poliza();
            PolizaDetalle polizaDet = new PolizaDetalle();

            Endoso endosoAlta = new Endoso();
            endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
            endosoAlta.Fecha = DateTime.Now;
            endosoAlta.ValorAnterior = "Alta";
            endosoAlta.ValorActual = "Contratación";

            poliza.FinVigencia = FinVigencia;
            poliza.InicioVigencia = InicioVigencia;

            poliza.PrimaNeta = (decimal)primerRecibo.PrimaNeta;
            poliza.PrimaNetaAnualizada = (decimal)primerRecibo.PrimaNeta;
            poliza.PrimaTotal = (decimal)primerRecibo.PrimaTotal;
            poliza.PrimaTotalAnualizada = (decimal)primerRecibo.PrimaTotal;

            poliza.Motor = InfoEmision.NumeroMotor;
            poliza.Serie = InfoEmision.NumeroSerie;
            poliza.Placas = InfoEmision.Placas;
            poliza.FechaEmision = DateTime.Now;
            poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
            poliza.UrlPDFPoliza = "";
            poliza.UrlPDFRecibos = "";
            poliza.Estatus = 21;
            poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
            poliza.IdConvenio = InfoEmision.Convenio.Id;
            poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
            poliza.IdTipoCobertura = Convert.ToInt32(detalle.Paquete);
            poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
            poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
            poliza.Acepto_DescuentoPoliza = true;

            polizaDet.Inciso = "1";
            polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para Inbursa.
            polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
            polizaDet.Deducible = 0;
            polizaDet.Comision = 0;
            polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
            polizaDet.MigraOPERA = false;
            polizaDet.UrlPDFPolizaOPERA = "";
            polizaDet.PolizaOPERA = 0;
            polizaDet.OTOpera = 0;
            polizaDet.EndosoOPERA = 0;
            polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
            polizaDet.IdCotizacionDetalle = detalle.Id;
            //VALIDAR
            polizaDet.IdCatRamoVehiculo = detalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
                                                             //polizaDet.IdCatRamoVehiculo = 4;
            polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
            polizaDet.IdCatModalidadFormaPago = medioPago.Id;
            polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
            polizaDet.XMLRecepcion = GeneraDatosPoliza(InfoEmision, paquete);
            polizaDet.XMLSolicitud = "";
            polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;

            List<Recibo> recibosGenerados = new List<Recibo>();
            foreach (Tarificador.ListaDeCobro recibo in recibos)
            {
                Recibo reciboSave = new Recibo();
                reciboSave.InicioVigencia = recibo.FechaInicio;
                reciboSave.FinVigencia = recibo.FechaFin;
                reciboSave.Numero = recibo.Index + 1;
                reciboSave.NoAsegurado = "1";
                reciboSave.PrimaTotal = Convert.ToDecimal(recibo.CobroCorte);
                reciboSave.PrimaNeta = Convert.ToDecimal(recibo.PrimaNetaRecibo);
                reciboSave.Comision = Convert.ToDecimal(recibo.Comision);
                reciboSave.Impuesto = Convert.ToDecimal(recibo.ImpuestoRecibo);

                recibosGenerados.Add(reciboSave);
            }
            endosoAlta.Recibo = recibosGenerados;

            poliza.Endoso.Add(endosoAlta);
            poliza.PolizaDetalle.Add(polizaDet);
            db.Poliza.Add(poliza);
            db.SaveChanges();

            return new EmisionPoliza(true, "", "", poliza);

        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            Tarificador.TarificadorClient tarificador = new Tarificador.TarificadorClient();
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            CotizacionDetalle detalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
            Cotizacion cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == detalle.IdCotizacion);
            double costo = 0;
            CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Convenio.IdEmpresa).FirstOrDefault();

            DateTime InicioVigencia = cotizacion.FechaFactura;
            DateTime FinVigencia = InfoEmision.Convenio.FinVigencia;

            XmlDocument xmlDetalle = new XmlDocument();
            xmlDetalle.LoadXml(detalle.XMLRecepcion);

            string costoCotizacion = xmlDetalle.SelectNodes("INBURSA/CostoTotal")[0].InnerText;
            string paquete = xmlDetalle.SelectNodes("INBURSA/Paquete")[0].InnerText;
            double.TryParse(costoCotizacion, out costo);
            List<Tarificador.ListaDeCobro> recibos = tarificador.GetRecibos(InfoEmision.Convenio.Id, InfoEmision.Convenio.IdCatTipoVigencia == 1, perioricidad.FormaPago, costo, cotizacion.FechaFactura.Date).ToList();
            Tarificador.ListaDeCobro primerRecibo = recibos.Find(a => a.Index == 0);
            string tipoPropietario = InfoEmision.EsBeneficiarioPreferente ? "PLAN" : "PERSONAL";
            CatRamoVehiculo vehiculo = db.CatRamoVehiculo.Where(x => x.Clave == InfoEmision.CotizacionAutoGuardar.TipoVehiculo).FirstOrDefault();
            var parameters = new List<SqlParameter>()
				{
					new SqlParameter("@IdUsuario",InfoEmision.DetalleUsuario.IdUsuario)
					,new SqlParameter("@TipoPropietario",tipoPropietario)
					,new SqlParameter("@TipoAuto",vehiculo.Nombre.ToUpper())
                    ,new SqlParameter("@Paquete",paquete)
                };

			string caratula = db.Database.SqlQuery<string>("Execute sp_CaratulasINBURSA_Obtener @IdUsuario, @TipoPropietario, @TipoAuto, @Paquete", parameters.ToArray()).SingleOrDefault();

            InfoEmision.CaratulaInbursa = caratula;
            //if (ConfigEmpresa.IdTipoDeNegocio == 2)
            //{
            //	InicioVigencia = DateTime.Now;
            //	FinVigencia = DateTime.Now.AddYears(1);
            //}
            //else
            //{
            //	if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(InfoEmision.Convenio.IdEmpresa, DateTime.Now))
            //	{
            //		InicioVigencia = DateTime.Now;
            //	}
            //}

            Poliza poliza = new Poliza();
            PolizaDetalle polizaDet = new PolizaDetalle();

            Endoso endosoAlta = new Endoso();
            endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
            endosoAlta.Fecha = DateTime.Now;
            endosoAlta.ValorAnterior = "Alta";
            endosoAlta.ValorActual = "Contratación";

            poliza.FinVigencia = FinVigencia;
            poliza.InicioVigencia = InicioVigencia;

            poliza.PrimaNeta = (decimal)primerRecibo.PrimaNeta;
            poliza.PrimaNetaAnualizada = (decimal)primerRecibo.PrimaNeta;
            poliza.PrimaTotal = (decimal)primerRecibo.PrimaTotal;
            poliza.PrimaTotalAnualizada = (decimal)primerRecibo.PrimaTotal;

            poliza.Motor = InfoEmision.NumeroMotor;
            poliza.Serie = InfoEmision.NumeroSerie;
            poliza.Placas = InfoEmision.Placas;
            poliza.FechaEmision = DateTime.Now;
            poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
            poliza.UrlPDFPoliza = "";
            poliza.UrlPDFRecibos = "";
            poliza.Estatus = 21;
            poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
            poliza.IdConvenio = InfoEmision.Convenio.Id;
            poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
            poliza.IdTipoCobertura = Convert.ToInt32(detalle.Paquete);
            poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
            poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
            poliza.Acepto_DescuentoPoliza = true;

            polizaDet.Inciso = "1";
            polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para el flujo alterno de Inbursa.
            polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
            polizaDet.Deducible = 0;
            polizaDet.Comision = 0;
            polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
            polizaDet.MigraOPERA = false;
            polizaDet.UrlPDFPolizaOPERA = "";
            polizaDet.PolizaOPERA = 0;
            polizaDet.OTOpera = 0;
            polizaDet.EndosoOPERA = 0;
            polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
            polizaDet.IdCotizacionDetalle = detalle.Id;
            polizaDet.IdCatRamoVehiculo = detalle.IdVehiculo;// int.Parse(InfoEmision.Convenio.RamoVehiculo.Split(',')[0]);
            polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
            polizaDet.IdCatModalidadFormaPago = medioPago.Id;
            polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
            polizaDet.XMLRecepcion = GeneraDatosPoliza(InfoEmision, paquete);
            polizaDet.XMLSolicitud = "";
            polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;

            List<Recibo> recibosGenerados = new List<Recibo>();
            foreach (Tarificador.ListaDeCobro recibo in recibos)
            {
                Recibo reciboSave = new Recibo();
                reciboSave.InicioVigencia = recibo.FechaInicio;
                reciboSave.FinVigencia = recibo.FechaFin;
                reciboSave.Numero = recibo.Index + 1;
                reciboSave.NoAsegurado = "1";
                reciboSave.PrimaTotal = Convert.ToDecimal(recibo.CobroCorte);
                reciboSave.PrimaNeta = Convert.ToDecimal(recibo.PrimaNetaRecibo);
                reciboSave.Comision = Convert.ToDecimal(recibo.Comision);
                reciboSave.Impuesto = Convert.ToDecimal(recibo.ImpuestoRecibo);

                recibosGenerados.Add(reciboSave);
            }
            endosoAlta.Recibo = recibosGenerados;

            poliza.Endoso.Add(endosoAlta);
            poliza.PolizaDetalle.Add(polizaDet);
            db.Poliza.Add(poliza);
            db.SaveChanges();

            return new EmisionPoliza(true, "", "", poliza);

        }

        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }

        private List<Coberturas> ObtenerCoberturas(int idConvenio, int idTipoPaquete, int year, int bloque, string tipoVehiculo)
        {
            List<Coberturas> coberturasPaquete = new GNPService().ObtenerCoberturas(idConvenio, idTipoPaquete);
            CatUsoVehiculo catUsoVehiculo = db.CatUsoVehiculo.First(a => a.Clave == tipoVehiculo);
            CatTipoPaquete tipoPaquete = db.CatTipoPaquete.FirstOrDefault(a => a.Id == idTipoPaquete);
            List<CoberturaINBURSAEspecial> cobertrasEspeciales = ObtenerCoberturasEspeciales(Convert.ToInt32(catUsoVehiculo.Clave), Convert.ToInt32(tipoPaquete.Clave), bloque);
            List<Coberturas> resultado = new List<Coberturas>();

            foreach (Coberturas cobertura in coberturasPaquete.Where(a => a.IdCatRamo == catUsoVehiculo.IdCatRamo))
            {
                Coberturas cotCob = new Coberturas();
                CoberturaINBURSAEspecial especial = cobertrasEspeciales.Where(a => a.ClaveCobertura == cobertura.Codigo).FirstOrDefault();

                cotCob.Cobertura = cobertura.Cobertura;
                cotCob.SumaAsegurada = cobertura.SumaAsegurada;
                cotCob.Nombre = cobertura.Nombre.Trim();
                cotCob.Deducible = cobertura.Deducible;
                cotCob.Codigo = cobertura.Codigo;

                if (especial != null)
                {
                    cotCob.SumaAsegurada = especial.SumaAsegurada;
                    cotCob.Deducible = especial.Deducible.ToString();
                }
                resultado.Add(cotCob);
            }
            return resultado;
        }

        private List<CoberturaINBURSAEspecial> ObtenerCoberturasEspeciales(int claveVehiculo, int clavePaquete, int claveBloque)
        {
            List<CoberturaINBURSAEspecial> list = db.CoberturaINBURSAEspecial.Where(a => a.ClaveTipoVehiculo == claveVehiculo && a.ClaveTipoCobertura == clavePaquete && a.ClaveBloque == claveBloque).ToList();
            return list;
        }
        private string GeneraDatosGenericos(CostoINBURSA item, string paquete)
        {
            XElement root = new XElement("INBURSA");
            root.Add(new XElement("IdBloque", item.IdBloque));
            root.Add(new XElement("Bloque", item.Bloque));
            root.Add(new XElement("CostoTotal", item.Costo));
            root.Add(new XElement("Paquete", paquete));
            return root.ToString();
        }
        private string GeneraDatosPoliza(InformacionEmision item, string paquete)
        {
            XElement root = new XElement("INBURSA");
            root.Add(new XElement("Sociedad", item.SociedadBeFlex));
            root.Add(new XElement("Contratante", item.ContratanteBeFlex));
            root.Add(new XElement("Localidad", item.LocalidadBeFlex));
            root.Add(new XElement("Caratula", item.CaratulaInbursa));
            root.Add(new XElement("Paquete", paquete));
            return root.ToString();
        }
       
        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        

    }
}
