﻿using com.lockton.xml.gnp.cotizacion.request;
using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.Banorte.Cotizacion;
using LocktonModel.VModels;
using LocktonModel.xmls.AXA;
using LocktonModel.xmls.AXA.Consultas;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.Catalogos;
using log4net;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using static LocktonModel.xmls.AXA.Request;
using static LocktonModel.xmls.AXA.Response;


namespace LocktonServicios.Aseguradoras
{
    public class AXAService : IAXAService
    {
        #region: Global variables

        //Variable to record the movements inside the AXA web service methods.
        private static readonly ILog log = LogManager.GetLogger(typeof(AXAService));
        //Data base context.
        ApplicationDbContext db = new ApplicationDbContext();

        #endregion

        #region: Methods

        /// <summary>
        /// Method to get car quote AXA across their web service.
        /// </summary>
        /// <param name="cot">mDetalles class</param>
        /// <param name="cotizacionCompara">CotizacionCompara class</param>
        /// <param name="convenioId">Agreement Id</param>
        /// <param name="detalleUsuario">DetalleUsuario class</param>       
        /// <param name="conveniosPaquetes">VEmpConvPaq class</param>
        /// <param name="idTipoPaquete">Pack Type Id</param>
        /// <returns>Car quote AXA</returns>
        /// 
        //public XmlDocument CarQuoteCompare(mDetalles cot, CotizacionCompara cotizacionCompara, int? Idconvenio, LocktonModel.db.DetalleUsuario detalleUsuarios, ref List<LocktonModel.db.Cobertura> coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete)
        //{
        //	var regre = "";
        //	return regre;
        //}
        public Comparar CarQuoteCompare(CotizacionCompara cotizacionCompara, int? convenioId, mDetalles cot,
                                                    DetalleUsuario detalleUsuario, VEmpConvPaq conveniosPaquetes,
                                                            int idTipoPaquete, int idPaqueteConvenio)
        {
            //Declare variables & instance class.
            Comparar CarQuoteCompare = new Comparar();

            try
            {
                //Method to connect to web service AXA, Create XML document request &fill Comparar class with data from web service AXA
                CarQuoteCompare = GetCarQuoteData(cotizacionCompara, convenioId, cot, detalleUsuario,
                                                         conveniosPaquetes, idTipoPaquete, idPaqueteConvenio);

            }
            catch (Exception ex)
            {
                //Record an error movement in the log.
                log.Info($"Information: Error at car quotation process, Method: CarQuoteCompare(), Message: {ex.Message}");
                //Throw a message when an exception ocurred.
                //throw new ApplicationException(ex.Message);
                CarQuoteCompare = new Comparar() { ErrorXML = ex.Message, Aseguradora = "AXA" };
            }

            //Returns comparar class with the car quote information.
            return CarQuoteCompare;
        }

        /// <summary>
        /// Method to connect to web service AXA, Create XML document request & fill Comparar class with data from web service AXA
        /// </summary>
        /// <param name="cot">mDetalles class</param>
        /// <param name="cotizacionCompara">CotizacionCompara class</param>
        /// <param name="convenioId">Agreement Id</param>
        /// <param name="detalleUsuario">DetalleUsuario class</param>       
        /// <param name="conveniosPaquetes">VEmpConvPaq class</param>
        /// <param name="idTipoPaquete">Pack Type Id</param>
        /// <returns>Comparar class with car quote information</returns>
        public Comparar GetCarQuoteData(CotizacionCompara cotizacionCompara, int? convenioId, mDetalles cot,
                                                    DetalleUsuario detalleUsuario, VEmpConvPaq conveniosPaquetes,
                                                            int idTipoPaquete, int idPaqueteConvenio)
        {
            //Declare variables
            string carQuoteResponse = string.Empty;
            XmlDocument xmlCarQuoteResponse = new XmlDocument();
            Comparar CarQuoteCompare = new Comparar();
            CredentialCache myCache = new CredentialCache();
            string xmlrequests = string.Empty;
            try
            {
                log.Info("Inicia Cotización AXA pool GetCarQuoteData");
                //Get Credentials from LocktOne_DB database
                Convenio agreement = db.Convenio.Find(convenioId);  //agreement.Usuario, agreement.Contrasena

                //============= Temporal Becton Flotilla Credentials ==============

                Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == convenioId); string user = convenio.Usuario;
                string password = convenio.Contrasena;


                //Get xml document AXA.
                XmlDocument xmlRequest = CreateXMLCarQuoteRequest(cot, cotizacionCompara, convenioId, detalleUsuario,
                                                                       conveniosPaquetes, idTipoPaquete);
                log.Info("CreateXMLCarQuoteRequest XML AXA Pool Envío Cotización: " + xmlRequest.InnerText);
                xmlrequests = xmlRequest.InnerXml;
                var service = new CotizacionEmisionAXAService.SolicitudPolizasWSFacadeClient();
                service.ClientCredentials.UserName.UserName = user;
                service.ClientCredentials.UserName.Password = password;

                carQuoteResponse = service.createSolicitudPolizasInmediata(xmlRequest.InnerText);


                xmlCarQuoteResponse.LoadXml(carQuoteResponse);
                log.Info("GetCarQuoteData XML AXA pool Respuesta Cotización" + xmlCarQuoteResponse.InnerXml);

                CarQuoteCompare = ReadCarQuoteResponse(xmlCarQuoteResponse, convenioId, xmlRequest, idTipoPaquete, idPaqueteConvenio);
                var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == cotizacionCompara.FormadePago).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == cotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenio.Id && a.IdCatPeriodicidadFormaPago == perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);

                if (string.IsNullOrEmpty(CarQuoteCompare.ErrorXML))
                {
                    CarQuoteCompare.IdMedioPago = cotizacionCompara.MediodePago;
                    CarQuoteCompare.IdFormaPago = cotizacionCompara.FormadePago;
                    CarQuoteCompare.FechaCotizacion = cotizacionCompara.FechaCotizacion;


                    CarQuoteCompare.FormaPagoEtiqueta = perioricidad.Nombre;
                    CarQuoteCompare.MedioPagoEtiqueta = mediopago.Nombre;
                    CarQuoteCompare.IdMedioPago = mediopago.Id;
                    CarQuoteCompare.IdFormaPago = perioricidad.Id;
                    CarQuoteCompare.PrimaAnualizada = Utilidades.Utilidades.CalculaPrimaAnualizada(cotizacionCompara.FechaInicio, cotizacionCompara.FechaFin, CarQuoteCompare.PrimaNeta, CarQuoteCompare.Derecho, CarQuoteCompare.CesionComision);
                    CarQuoteCompare.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                }
            }
            catch (Exception ex)
            {
                //Record an error movement in the log.
                log.Info($"Information: Error at car quotation process, Method: GetCarQuoteData(), Message: {ex.Message}");
                //Throw a message when an exception ocurred.
                CarQuoteCompare.XmlEmision = xmlrequests;
                CarQuoteCompare.ErrorXML = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                CarQuoteCompare.Aseguradora = "AXA";
                return CarQuoteCompare;
            }

            //Returns comparar class with the car quote data.
            CarQuoteCompare.XmlEmision = xmlrequests;
            return CarQuoteCompare;
        }

        /// <summary>
        /// Method to buil a XML Document and send a request to web service of AXA.
        /// </summary>
        /// <param name="cot">mDetalles class</param>
        /// <param name="cotizacionCompara">CotizacionCompara class</param>
        /// <param name="idconvenio">Agreement Id</param>
        /// <param name="detalleUsuarios">DetalleUsuario class</param>      
        /// <param name="conveniosPaquetes">VEmpConvPaq class</param>
        /// <param name="idTipoPaquete">Pack Type Id</param>
        /// <returns>A XML Document Request</returns>
        public XmlDocument CreateXMLCarQuoteRequest(mDetalles cot, CotizacionCompara cotizacionCompara, int? idconvenio,
                                                        DetalleUsuario detalleUsuarios, VEmpConvPaq conveniosPaquetes,
                                                            int idTipoPaquete)
        {
            //================== Declare variables & create class instances =====================//
            int? idEmpresa = null;
            string descripcionVehiculo, claveEstado, codigoPostal, result, xmlBody = string.Empty;
            LocktonModel.db.Aseguradora aseguradora = null;
            LocktonModel.db.DetalleUsuario detalleUsuario;
            LocktonModel.db.Convenio convenio = new LocktonModel.db.Convenio();
            XmlDocument XmlCarQuoteRequestAXA = new XmlDocument();
            //===================================================================================//

            try
            {
                //Record a quotation car in the log.
                log.Info("CreateXMLCarQuoteRequest: Inica a crear xml para cotización AXA pool");

                //========================== Init get information required for XML Document AXA Request ==========================//
                //Validate idConvenio for get information about the client or company.
                if (idconvenio == null)
                {
                    //User details
                    detalleUsuario = db.DetalleUsuario.Include("Direccion").Include("DetalleUsuarioEmpresa")
                                        .Where(x => x.IdUsuario == detalleUsuarios.IdUsuario)
                                            .FirstOrDefault() ?? new LocktonModel.db.DetalleUsuario();
                    //Insurance company
                    aseguradora = db.Aseguradora.Where(x => x.Nombre.Contains("AXA")).FirstOrDefault();

                    //Company Id
                    idEmpresa = detalleUsuario.DetalleUsuarioEmpresa.FirstOrDefault().IdEmpresa;

                    //Agreement
                    convenio = db.Convenio
                                    .Where(x => x.IdEmpresa == idEmpresa && x.IdAseguradora == aseguradora.Id)
                                        .FirstOrDefault();
                }
                else
                {
                    //User details
                    detalleUsuario = db.DetalleUsuario.Include("Direccion").Include("DetalleUsuarioEmpresa")
                                        .Where(x => x.IdUsuario == detalleUsuarios.IdUsuario)
                                            .FirstOrDefault() ?? new LocktonModel.db.DetalleUsuario();
                    //Agreement
                    convenio = db.Convenio.Where(x => x.Id == idconvenio).FirstOrDefault();

                    //Company Id
                    idEmpresa = convenio.IdEmpresa;

                    //Company address
                    Empresa direccionEmpresa = db.Empresa.Include("Direccion").Where(x => x.Id == idEmpresa).FirstOrDefault();

                    //Set company address
                    detalleUsuario.Direccion = direccionEmpresa.Direccion;

                    //Insurance company
                    aseguradora = db.Aseguradora.Where(x => x.Id == convenio.IdAseguradora).FirstOrDefault();
                }

                double? CesionComision = db.Empresa.Where(x => x.Id == idEmpresa).Select(s => s.CesionComision).FirstOrDefault();

                //periodicity
                PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago
                                    .Where(x => x.IdConvenio == convenio.Id
                                        && x.IdCatPeriodicidadFormaPago == cotizacionCompara.FormadePago).FirstOrDefault();
                //Car
                CatRamoVehiculo vehiculo = db.CatRamoVehiculo.Where(x => x.Clave == cotizacionCompara.TipoVehiculo).FirstOrDefault();

                //Pack branch agreement
                ConvenioRamoPaquete paqueteRamoConvenio = db.ConvenioRamoPaquete
                                            .Where(x => x.IdConvenio == convenio.Id && x.IdCatRamoVehiculo == vehiculo.IdCatRamo)
                                                .FirstOrDefault();
                //Pack detail
                IOrderedQueryable<PaqueteDetalle> paqueteDetalle = db.PaqueteDetalle
                                        .Where(x => x.IdConvenioRamoPaquete == paqueteRamoConvenio.Id &&
                                                x.IdCatTipoPaquete == idTipoPaquete).OrderBy(x => x.IdCobertura);

                ConfiguracionEmpresa configuracionEmpresa = db.ConfiguracionEmpresa.FirstOrDefault(a => a.IdEmpresa == idEmpresa);
                ////State key
                //claveEstado = (db.CatEstadosRepublica
                //                        .Where(x => x.Estado == (detalleUsuario.Direccion.Estado ?? ""))
                //                            .FirstOrDefault() ?? new LocktonModel.db.CatEstadosRepublica()).Clave;
                ////Postal Code
                //codigoPostal = detalleUsuario.Direccion.CodigoPostal;

                //Car description
                descripcionVehiculo = ($"{cotizacionCompara.Marca}, {cotizacionCompara.Modelo}, {cotizacionCompara.Version}, {cotizacionCompara.Descripcion}");

                //============== Flotilla (Colective) verify dates =================//
                //Init Date
                DateTime fechaInicio = cotizacionCompara.FechaInicio;//  DateTime.Now;
                                                                     //End Date
                DateTime fechaTermino = cotizacionCompara.FechaFin;// DateTime.Now.AddYears(1);

                //======================= Init business Rules ======================//
                //if (convenio.IdCatTipoVigencia == 1)
                //{
                //    fechaInicio = cotizacionCompara.FechaCotizacion;
                //    string fechaRe = convenio.FinVigencia.ToString();
                //    string[] datosFecha = fechaRe.Split(' ');
                //    DateTime ffVig = DateTime.Parse(datosFecha[0]);
                //    fechaTermino = ffVig;
                //}
                //else if (convenio.IdCatTipoVigencia == 2)
                //{
                //    fechaInicio = cotizacionCompara.FechaCotizacion;
                //    fechaTermino = cotizacionCompara.FechaCotizacion.AddYears(1);
                //}
                //// 1.Flotilla Case
                //if (conveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 1) // 1 ==> Flotilla
                //{
                //    //Verify Init date.
                //    if (LocktonServicios.Utilidades.Utilidades.EstaEnPeriodoDeEnrollment((int)idEmpresa, fechaInicio))
                //    {
                //        //Search if exists an enrollment date.
                //        fechaInicio = conveniosPaquetes.Convenios[0].InicioVigencia;
                //    }

                //    //Returns a end validity date based on the agreement Id company.
                //    fechaTermino = conveniosPaquetes.Convenios[0].FinVigencia;

                //}


                codigoPostal = cotizacionCompara.CodigoPostal;

                if (string.IsNullOrEmpty(codigoPostal) && convenio.CodigoPostal > 0)
                    codigoPostal = convenio.CodigoPostal.ToString();

                if (string.IsNullOrEmpty(codigoPostal) && detalleUsuario != null && detalleUsuario.Direccion != null)
                    codigoPostal = detalleUsuario.Direccion.CodigoPostal;

                claveEstado = db.CatCodigoPostal
                                .FirstOrDefault(cp => cp.Codigo == codigoPostal)
                                    .IdEstadoCotizacion.ToString().PadLeft(2, '0');

                string sexo = cotizacionCompara.Genero;

                if (string.IsNullOrEmpty(sexo))
                    sexo = detalleUsuario.GENERO;

                string edad = cotizacionCompara.Edad;

                if (string.IsNullOrEmpty(edad))
                    edad = Utilidades.Utilidades.CalculaEdad(detalleUsuario.FECHANACIMIENTO).ToString();
                //========================== End get information required for XML Document AXA Request ==========================//

                //========================= Init build XML Document AXA Request based on NodeSolicitud class ====================//

                CatCaratulaPaquete _paqete = db.CatCaratulaPaquete.FirstOrDefault(a => a.IdConvenio == idconvenio && a.IdTipoPaquete == idTipoPaquete && a.IdCatRamoVehiculo == vehiculo.IdCatRamo);
                string _iva = db.CatParametro.Where(w => w.Clave == "IVA").Select(s => s.Valor).FirstOrDefault();
                //Record when start the XML build.
                log.Info($"Information: start build xml document, Method: XMLRequest()");
                string[] resVehiculo = new List<string>().ToArray();

                string valorParametro = Utilidades.Utilidades.ObtienerValorParametro("AXAHomologadoBOGO");

                descripciones _cotDesAuto = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault();
                catalogo _cotAuto = cot.Catalogo.FirstOrDefault();

                string TipoPersona = "FISICA";
                if ((configuracionEmpresa.IdTipoDeNegocio == 1 || configuracionEmpresa.IdTipoDeNegocio == 4) && convenio.IdCatTipoContratante == 1)//negocio tipo flotilla con datos del negocio
                {
                    TipoPersona = "MORAL";
                }
                else if ((configuracionEmpresa.IdTipoDeNegocio == 6 || configuracionEmpresa.IdTipoDeNegocio == 5) && cotizacionCompara.EmisionPersonaMoral)//Cotizar con persona moral
                {
                    TipoPersona = "MORAL";
                }
                resVehiculo = getMarcaTipoVehiculo(_cotDesAuto.clave);
                descripcionVehiculo = _cotDesAuto.Descripcion;
                var datosVehiculo = ObtenerDatosVehiculo(_cotDesAuto.clave, _cotAuto.Aseguradora);
                claveEstado = db.CatEstadosAXA.FirstOrDefault(x => x.Clave == claveEstado).Valor.ToString();
                NodeSolicitud Solicitud = new NodeSolicitud()
                {
                    Poliza = new Request.NodePoliza()
                    {
                        NombreProducto = convenio.ProductoAXA,
                        Generales = new Request.NodeGenerales()
                        {
                            TipoPoliza = "COLECTIVA",
                            TipoMovimiento = "COTIZACION",
                            SeriePoliza = convenio.SerieAXA,
                            TipoVigencia = "ANUAL",
                            FechaDesde = fechaInicio.ToString("dd/MM/yyyy"),
                            FechaHasta = fechaTermino.ToString("dd/MM/yyyy"),
                            Titular = new Request.NodeTitular()
                            {
                                TipoPersona = TipoPersona,
                                Nombre = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "YANET" : ((detalleUsuario.Nombre.Length) >= 20 ? detalleUsuario.Nombre.Split(' ')[0].ToString() : detalleUsuario.Nombre),
                                ApPaterno = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "RAMIREZ" : detalleUsuario.ApellidoPaterno,
                                ApMaterno = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "GUERRERO" : detalleUsuario.ApellidoMaterno,
                                RFC = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "RAGY8108071W8" : detalleUsuario.RFC,
                                Telefono = "55555555",
                                Direccion = new NodeDireccion()
                                {
                                    CalleNumero = conveniosPaquetes.Empresa.Direccion.Calle,
                                    Colonia = conveniosPaquetes.Empresa.Direccion.Colonia,
                                    Poblacion = conveniosPaquetes.Empresa.Direccion.Municipio,
                                    ClaveEstado = claveEstado,
                                    ClavePoblacion = "1",
                                    CodigoPostal = codigoPostal
                                },
                                Sexo = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "Femenino" : sexo,
                                Edad = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "18" : edad
                            },
                            ClienteYO = new NodeClienteYO()
                            {
                                Nombre = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "YANET" : detalleUsuario.Nombre,
                                ApMaterno = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "GUERRERO" : detalleUsuario.ApellidoMaterno,
                                ApPaterno = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "RAMIREZ" : detalleUsuario.ApellidoPaterno,
                                TipoPersonaYO = TipoPersona,
                            },
                            Sector = "PUBLICO",
                            FormaPago = perioricidad.FormaPago,
                            Moneda = "NACIONAL",
                            IVA = string.IsNullOrEmpty(_iva) ? "16" : _iva,
                            TipoNegocio = "NORMAL",
                            Subramo = (vehiculo.Clave == 1.ToString()) ? "AUTOS" : (vehiculo.Clave == 2.ToString()) ? "CAMIONES" : "CAMIONES",
                            TipoVehiculo = (vehiculo.Clave == 1.ToString()) ? "RESIDENTES" : (vehiculo.Clave == 2.ToString()) ? "PICK-UP" : "PICK-UP",
                            Agente = perioricidad.ClaveAgente,
                            PorcentajeCesion = string.IsNullOrEmpty(CesionComision.ToString()) ? "0" : CesionComision.ToString(),
                            OTAgente = "66",
                            ReporteTelefonico = "65",

                            Vehiculo = new Request.NodeVehiculo()
                            {
                                Descripcion = descripcionVehiculo,
                                Modelo = cotizacionCompara.Año,
                                Serie = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("SerieVahiculoAxa")).Valor,
                                Placas = "PERMISO",
                                EdoPlacas = claveEstado,
                                Ocupantes = "0",//_cotDesAuto.Pasajeros,
                                Tonelaje = "0",
                                Uso = "NORMAL",
                                Valor = (cotizacionCompara.ValorFactura) ? cotizacionCompara.MontoFactura.ToString() : "0",
                                Servicio = "PARTICULAR",
                                Catalogo = new NodeCatalogo()
                                {
                                    Propio = new NodePropio()
                                    {
                                        Marca = resVehiculo[0],
                                        Tipo = resVehiculo[1],
                                        Clase = datosVehiculo.IdClase, /*"1"*/
                                    }
                                }
                            },
                            PorcentajeValor = getPorcentajeValor(convenio.Id, idTipoPaquete).ToString(),
                            EsValorComercial = cotizacionCompara.ValorFactura ? "NO" : "SI",
                            CondicionesEmision = new Request.NodeCondicionesEmision()
                            {
                                Tarifa = paqueteRamoConvenio.Tarifa,
                                DescuentoPorVolumen = paqueteRamoConvenio.Descuento.ToString("n2"),
                                PorcentajeCoaseguro = "0",
                                Afianzadora = "AUSA",
                                Servidora = "AXA 2005",
                                ProrratearDerechos = convenio.DerechosPrimerRecibo ? "NO" : "SI",
                                Paquete = _paqete.Clave,
                            }
                        },
                        ConductorHabitual = new NodeConductorHabitual()
                        {
                            Nombre = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "YANET" : detalleUsuario.Nombre,
                            ApPaterno = string.IsNullOrEmpty(detalleUsuario.ApellidoPaterno) ? "RAMIREZ" : detalleUsuario.ApellidoPaterno,
                            ApMaterno = string.IsNullOrEmpty(detalleUsuario.ApellidoMaterno) ? "GUERRERO" : detalleUsuario.ApellidoMaterno,
                            Sexo = string.IsNullOrEmpty(sexo) ? "Femenino" : sexo,
                            Edad = string.IsNullOrEmpty(edad) ? "18" : edad,
                            CodigoPostal = codigoPostal
                        }
                    }
                };
                //========================= End build XML Document AXA Request based on NodeSolicitud class ====================//

                //Start the serialization of NodeSolicitud class.
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(NodeSolicitud));
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;

                //Serialize xml information
                using (Utf8StringWriter stringWriter = new Utf8StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
                    {
                        xmlSerializer.Serialize(xmlWriter, Solicitud);
                    }

                    result = stringWriter.ToString();
                }
                //Build xml document with headers 
                xmlBody = @"<soapenv:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' 
                                        xmlns:xsd='http://www.w3.org/2001/XMLSchema' 
                                                xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/'
                                                        xmlns:wsf='http://wsfacade.emisionpolizas.autos.seguros.mx.ia3.ing.com'>
                            <soapenv:Header/>
                                <soapenv:Body>
                                    <wsf:createSolicitudPolizasInmediata 
                                        soapenv:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'>
                                            <xml xsi:type='xsd:string'><![CDATA[" + result + @"]]></xml>
                                    </wsf:createSolicitudPolizasInmediata>
                                </soapenv:Body>
                           </soapenv:Envelope>";


                //Load information into a xml format
                XmlCarQuoteRequestAXA.LoadXml(xmlBody);
            }
            catch (Exception ex)
            {
                //Record an error movement of xml build in the log.
                log.Info($"Information: Error in the xml build process, Method: XMLRequest(), Message: {ex.Message}");
                //Record when the exception ocurred while xml document was builded.
                throw new ApplicationException(ex.Message);
            }

            //Return a xml document request. This information got by the user/client configuration 
            //& some fields information was typed from form of principal page.
            return XmlCarQuoteRequestAXA;
        }


        /// <summary>
        /// Method to read the data response based on the information from web service AXA.
        /// </summary>
        /// <param name="cotizacionCompara">CotizacionCompara class</param>
        /// <param name="coberturas">List<Cobertura> coverage List</param>
        /// <param name="xmlRequest">XML Request string</param>
        /// <param name="convenioId">Agreement Id</param>
        /// <returns>Comparar class</returns>
        public Comparar ReadCarQuoteResponse(XmlDocument responseXML, int? convenioId, XmlDocument requestXML, int idTipoPaquete, int idPaqueteConvenio)
        {
            //Declare variables & class instance.        
            int i = 0;
            XmlDocument xmlRequestResponse = new XmlDocument();
            NodeEmision response;
            Comparar carQuoteResponse = new Comparar();
            carQuoteResponse.XmlEmision = requestXML.InnerXml;
            //Get data agreement
            Convenio agreement = db.Convenio.Include("Aseguradora")
                                .Where(a => a.Id == convenioId).FirstOrDefault();

            try
            {
                //Record when start the build XML Response process.
                log.Info($"Information: start to create XML Response process, Method: XMLReadResponse()");
                //Load xml response
                //xmlRequestResponse.LoadXml(requestResponse);
                xmlRequestResponse.LoadXml(responseXML.InnerXml);

                //Validate xml nodes
                if (xmlRequestResponse.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                    xmlRequestResponse.RemoveChild(xmlRequestResponse.FirstChild);

                //Reading, serialize and deserialize xml information.
                using (TextReader sr = new StringReader(xmlRequestResponse.InnerXml))
                {
                    XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(NodeEmision));
                    response = (NodeEmision)serializer.Deserialize(sr);
                }

                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                //Recover the information from the web service response and fill the Comparar class.
                string policyNumber = response.Poliza.Generales.NumeroPoliza;
                carQuoteResponse.Año = response.Poliza.Vehiculo.Modelo;
                carQuoteResponse.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                carQuoteResponse.IdConvenio = agreement.Id;
                carQuoteResponse.IdAseguradora = agreement.IdAseguradora;
                carQuoteResponse.Aseguradora = "AXA";
                //carQuoteResponse.XmlEmision = requestResponse;

                //carQuoteResponse.XmlRespuesta = response.ToString();
                carQuoteResponse.XmlRespuesta = responseXML.InnerXml;
                carQuoteResponse.FechaInicio = response.Poliza.Generales.FechaDesde;
                carQuoteResponse.FechaFin = response.Poliza.Generales.FechaHasta;
                carQuoteResponse.IdPaqueteConvenio = idPaqueteConvenio;
                carQuoteResponse.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                carQuoteResponse.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                carQuoteResponse.NumeroDePagos = string.IsNullOrEmpty(response.Poliza.CondicionesEmision.RecibosSubsecuentes) ? 0 : Convert.ToInt32(response.Poliza.CondicionesEmision.RecibosSubsecuentes);
                //carQuoteResponse.IdFormaPago = Convert.ToInt32(response.Poliza.Generales.FormaPago);
                //carQuoteResponse.IdMedioPago = response.Poliza.Generales.medio
                //Record when start to get all coverages
                log.Info($"Information: start to get coverages process, Method: XMLReadResponse()");

                List<Coberturas> coberturas = new GNPService().ObtenerCoberturas(agreement.Id, idTipoPaquete);
                //Start the routine to get the coverages.
                foreach (NodeCobertura coverage in response.Poliza.CondicionesEmision.Coberturas.Cobertura)
                {
                    //Get sum Assured
                    string sumAssured = coverage.SumaAsegurada;
                    int result;
                    bool isNumeric = int.TryParse(sumAssured, out result);

                    //Validate if a coverage is RC or Proliber type to get the correct sum assured.
                    if (isNumeric)
                    {
                        if (coverage.Nombre.Contains("RC") || coverage.Nombre.Contains("Proliber"))
                        {
                            decimal sa = Convert.ToDecimal(sumAssured);
                            sumAssured = (sa * 1000).ToString();
                        }

                        sumAssured = Convert.ToSingle(sumAssured).ToString("C0");
                        int position = sumAssured.IndexOf(".");
                        sumAssured = (position != -1 ? sumAssured : sumAssured + ".00");
                    }

                    //Add coverages.
                    Coberturas coberturaExistente = coberturas.FirstOrDefault(a => a.Nombre.ToUpper().Trim() == coverage.Nombre.ToUpper().Trim());
                    carQuoteResponse.Coberturas.Add(new LocktonModel.VModels.Coberturas()
                    {
                        Nombre = coverage.Nombre,
                        Deducible = coverage.Deducible,
                        SumaAsegurada = sumAssured,
                        PrimaNeta = coverage.PrimaNeta,
                        Cobertura = coverage.PrimaNeta,
                        Codigo = coberturaExistente == null ? "" : coberturaExistente.Codigo
                    });
                }

                //Record when start to get all receipt
                log.Info($"Information: start to get receipt process, Method: XMLReadResponse()");

                //Start routine to get receipt
                foreach (NodeDetalleImporte importDetail in response.Poliza.CondicionesEmision.ImportesRecibos.DetalleImporte)
                {
                    i = i + 1;          //Counter

                    if (i == 1)         //First Node response
                    {
                        carQuoteResponse.PrimaNeta = importDetail.PrimaNeta;
                        carQuoteResponse.Comision = importDetail.CesionComision;
                        carQuoteResponse.Recargo = importDetail.Recargos;
                        carQuoteResponse.Derecho = importDetail.Derechos;
                        carQuoteResponse.Impuesto = importDetail.Impuesto;
                        carQuoteResponse.PrimaTotal = importDetail.PrimaTotal;
                    }
                    else if (i == 2)    //Second Node response
                    {
                        carQuoteResponse.PrimerPago = importDetail.PrimaTotal;
                    }
                    else if (i == 3)    //Third Node Response
                    {
                        //
                        if (carQuoteResponse.NumeroDePagos > 0 && Convert.ToDecimal(importDetail.PrimaTotal) > 0)
                        {
                            //Total Receipt
                            int totalReceipt = carQuoteResponse.NumeroDePagos;

                            //Get total prime subsequent
                            decimal totalPrimeSubsequent = Convert.ToDecimal(importDetail.PrimaTotal);
                            //Get subsequent pay
                            decimal subsequentPay = (totalPrimeSubsequent / totalReceipt);
                            //Get second pay
                            carQuoteResponse.SegundoPago = Math.Round(subsequentPay, 2).ToString();
                        }


                    }
                }
            }
            catch (Exception ex)
            {
                //Record when an error ocurred at moment to get all receipt
                log.Info($"Information: Error at get xml response process, Method: XMLReadResponse(), Message: {ex.Message}");
                //Throw an message when an exception ocurred.
                //throw new ApplicationException(ex.Message);
                carQuoteResponse.XmlEmision = requestXML.InnerXml;
                carQuoteResponse.ErrorXML = responseXML.InnerText;
                carQuoteResponse.XmlRespuesta = responseXML.InnerXml;
                return carQuoteResponse;
            }

            //Returns the Comparar class filled with the information from the web service AXA.
            return carQuoteResponse;
        }

        public string fakeXML()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<?xml version=\"1.0\"?>");
            sb.Append("<Emision>");
            sb.Append("<SolicitudID>747655487305393212</SolicitudID>");
            sb.Append("<Poliza>");
            sb.Append("<Generales>");
            sb.Append("<Solicitud>DHR0</Solicitud>");
            sb.Append("<Consecutivo>1</Consecutivo>");
            sb.Append("<Numero-Poliza>CO08235510</Numero-Poliza>");
            sb.Append("<FormaPago>CONTADO</FormaPago>");
            sb.Append("<FechaDesde>01/12/2018</FechaDesde>");
            sb.Append("<FechaHasta>30/09/2019</FechaHasta>");
            sb.Append("<Tarifa>TB7030</Tarifa>");
            sb.Append("<IndiceTarifa>885201</IndiceTarifa>");
            sb.Append("<FechaTrabajo>01/12/2018</FechaTrabajo>");
            sb.Append("</Generales>");
            sb.Append("<Titular>");
            sb.Append("<Nombre>NOMBREAPATERNOAMATERNO</Nombre>");
            sb.Append("<NumeroCliente>");
            sb.Append("</NumeroCliente>");
            sb.Append("<RFC>NOPA010101</RFC>");
            sb.Append("<Sexo>FEMENINO</Sexo>");
            sb.Append("<Edad>25</Edad>");
            sb.Append("</Titular>");
            sb.Append("<Vehiculo>");
            sb.Append("<Descripcion>FIESTATRENDCOMFORTSTDA/ACV/VELOURC</Descripcion>");
            sb.Append("<Modelo>2005</Modelo>");
            sb.Append("<Placas>PERMISO</Placas>");
            sb.Append("<Motor>");
            sb.Append("</Motor>");
            sb.Append("<Serie>XXXXXXXXXX1</Serie>");
            sb.Append("<Valor>34760</Valor>");
            sb.Append("<EsValorComercial>SI</EsValorComercial>");
            sb.Append("<Uso>NORMAL</Uso>");
            sb.Append("<Servicio>PARTICULAR</Servicio>");
            sb.Append("<Ocupantes>5</Ocupantes>");
            sb.Append("<Tonelaje>0.0</Tonelaje>");
            sb.Append("</Vehiculo>");
            sb.Append("<CondicionesEmision>");
            sb.Append("<DescuentoPorNoSiniestro>0.0</DescuentoPorNoSiniestro>");
            sb.Append("<ExtensionRC>SI</ExtensionRC>");
            sb.Append("<AmpliarRC>NO</AmpliarRC>");
            sb.Append("<DobleRemolque>NO</DobleRemolque>");
            sb.Append("<RecibosSubsecuentes>0</RecibosSubsecuentes>");
            sb.Append("<Importes-Recibos>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>1472.38</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>330</Derechos>");
            sb.Append("<Impuesto>288.38</Impuesto>");
            sb.Append("<PrimaTotal>2090.76</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>1472.38</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>330</Derechos>");
            sb.Append("<Impuesto>288.38</Impuesto>");
            sb.Append("<PrimaTotal>2090.76</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("</Importes-Recibos>");
            sb.Append("<Coberturas>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>DañosMateriales</Nombre>");
            sb.Append("<Deducible>5</Deducible>");
            sb.Append("<SumaAsegurada>34760</SumaAsegurada>");
            sb.Append("<PrimaNeta>721.57</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>RoboTotal</Nombre>");
            sb.Append("<Deducible>5</Deducible>");
            sb.Append("<SumaAsegurada>34760</SumaAsegurada>");
            sb.Append("<PrimaNeta>127.54</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>RCBienes</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>1000</SumaAsegurada>");
            sb.Append("<PrimaNeta>385.47</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>ServiciodeAsistencia</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>Amparada</SumaAsegurada>");
            sb.Append("<PrimaNeta>63.7</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>RCPersonas</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>3000</SumaAsegurada>");
            sb.Append("<PrimaNeta>76.75</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>GastosMédicos</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>350000</SumaAsegurada>");
            sb.Append("<PrimaNeta>70.78</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>Proliber</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>1000</SumaAsegurada>");
            sb.Append("<PrimaNeta>14.26</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>Accidentes</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>100000</SumaAsegurada>");
            sb.Append("<PrimaNeta>12.3</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>");
            sb.Append("</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>");
            sb.Append("</SumaAsegurada>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("</Coberturas>");
            sb.Append("</CondicionesEmision>");
            sb.Append("</Poliza>");
            sb.Append("</Emision>");

            return sb.ToString();
        }

        /// <summary>
        /// Method to create a Http web request
        /// </summary>
        /// <returns>A Http web request</returns>
        public HttpWebRequest CreateHttpWebRequest()
        {
            //Create a HttpWebRequest instance.
            HttpWebRequest webRequest = (dynamic)null;

            try
            {
                //Record when start the http web request creation.
                log.Info($"Start create Http Web Request, Method: CreateHttpWebRequest()");

                //Create a Http Web Request.
                webRequest = ((HttpWebRequest)WebRequest.Create(GetUrlDevelopmentEnviroment()));
                //Web request content type
                webRequest.Accept = "text/xml";
                //Web request type
                webRequest.Method = "POST";

            }
            catch (Exception ex)
            {
                //Record an error in the log.
                log.Info($"Information: Error at create http web request process, Method: CreateHttpWebRequest(), Message: {ex.Message}");
                //Throw an message when an exception ocurred.
                throw new ApplicationException(ex.Message);
            }

            // Returns a web request.
            return webRequest;
        }

        /// <summary>
        /// Method to get a string url connection web service AXA; test or production.
        /// </summary>
        /// <returns>Url web service AXA</returns>
        public string GetUrlDevelopmentEnviroment()
        {
            //Record when start to get a url string connection.
            log.Info($"Start get the development enviroment url, Method: GetUrlDevelopmentEnviroment()");

            //Declare variable.
            string connectionDevelopment = string.Empty;

            try
            {
                // ========================== This is an information from Web.Config =============================
                // Type 1 = Test       ==> false
                // Type 2 = Production ==> true
                bool connectionType = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") ? true : false;

                // Get connection type from Web.Config
                if (connectionType)
                    connectionDevelopment = ConfigurationManager.AppSettings["UrlDevelopmentTest"].ToString();
                else
                    connectionDevelopment = ConfigurationManager.AppSettings["UrlDevelopmentProd"].ToString();
            }
            catch (Exception ex)
            {
                //Record information when an error ocurred.
                log.Info($"Information: Error at get the development enviroment url process, Method: GetUrlDevelopmentEnviroment(), Message: {ex.Message}");
                throw new ApplicationException(ex.Message);
            }

            // Returns url web service connection.
            return connectionDevelopment;
        }

        /// <summary>
        /// Method to get the user/client credentials to web service access AXA.
        /// </summary>
        /// <param name="user">User/Client Name</param>
        /// <param name="password">User/Client Password</param>
        /// <returns>User/client credentials</returns>
        public CredentialCache GetClientCredentials(string user, string password)
        {
            //Instance Credentials class
            CredentialCache credentials = new CredentialCache();

            try
            {
                //Record when start to get user/client credentials process.
                log.Info($"Start get credentials process");

                //Add user credentials for access to web service Quotation Car AXA.
                credentials.Add(new Uri(GetUrlDevelopmentEnviroment()), "Basic", new NetworkCredential(user, password));
            }
            catch (Exception ex)
            {
                //Record when an error ocurred in the to get user/client credentials process.
                log.Info($"Information: Error at get credentials process, Method: GetCredentials(), Message: {ex.Message}");
                //Throw an exception if an error ocurred.
                throw new ApplicationException(ex.Message);
            }

            //Returns User/Client credentials.
            return credentials;
        }

        /// <summary>
        /// Method to save a XML document request.
        /// </summary>
        /// <param name="xmlRequest">XML Document Request</param>
        /// <param name="webRequest">Http Web Request</param>
        public void SaveXmlRequestIntoWebRequest(XmlDocument xmlRequest, HttpWebRequest webRequest)
        {
            using (Stream stream = webRequest.GetRequestStream())
            {
                xmlRequest.Save(stream);
            }
        }

        public CotizacionCompara CotizarVehiculo()
        {
            throw new NotImplementedException();
        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new System.NotImplementedException();

        }
        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            EmisionPoliza emisionpoliza = null;
            XmlDocument soapEnvelopeXmlCot = null;
            string xmlRequest = string.Empty;
            string xmlRespuesta = string.Empty;

            try
            {
                CredentialCache myCache = new CredentialCache();
                string _url = GetUrlDevelopmentEnviroment();

                //Obtener Datos
                SolicitudGeneral general = new SolicitudGeneral();
                bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
                CatPeriodicidadFormaPago catPeriodicidad = db.CatPeriodicidadFormaPago.FirstOrDefault(x => x.Id == InfoEmision.CotizacionAutoGuardar.FormadePago);
                CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
                CatTipoPaquete tipoPaquete = db.CatTipoPaquete.FirstOrDefault(a => a.Clave == cotizacionDetalle.Paquete);
                CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());


                log.Info("Inicia emision AXA");



                DateTime InicioVigencia = InfoEmision.Convenio.InicioVigencia;
                DateTime FinVigencia = InfoEmision.Convenio.FinVigencia;


                SolicitudAutos autos = new SolicitudAutos();
                SolicitudAutosAuto auto = new SolicitudAutosAuto();
                //XmlDocument soapEnvelopeXmlCot = CreateSoapEnvelopeEmision(InfoEmision, idEstado, IdGerencia, InfoEmision.Convenio.Id, InfoEmision.Convenio.Agente);
                #region Obtener emision AXA
                soapEnvelopeXmlCot = CreateSoapEnvelopeEmision(InfoEmision, null, null, InfoEmision.Convenio.Id.ToString(), perioricidad.ClaveAgente, tipoPaquete.Id);
                //var m = soapenvelopexmlcot.innerxml.indexof("<poliza>");
                //var n = soapenvelopexmlcot.innerxml.lastindexof("</poliza>") + 9;
                //var contentEnvio = System.Net.WebUtility.HtmlDecode(soapEnvelopeXmlCot.InnerXml.Substring(m, n - m));
                log.Info("CreateSoapEnvelopeEmision XML Emision: " + soapEnvelopeXmlCot.InnerText);
                //HttpWebRequest webRequest3 = CreateWebRequest(_url, "");

                //============= Temporal Becton Flotilla Credentials ==============

                Convenio convenio = db.Convenio.FirstOrDefault(a => a.Id == InfoEmision.Convenio.Id);
                string user = convenio.Usuario;
                string password = convenio.Contrasena;

                var service = new CotizacionEmisionAXAService.SolicitudPolizasWSFacadeClient();
                service.ClientCredentials.UserName.UserName = user;
                service.ClientCredentials.UserName.Password = password;
                string soapResultCot;
                soapResultCot = service.createSolicitudPolizasInmediata(soapEnvelopeXmlCot.InnerText);


                //myCache.Add(new Uri(_url), "Basic", new NetworkCredential(user, password));
                //webRequest3.Headers.Add("SOAPAction", "");
                //webRequest3.PreAuthenticate = true;
                //webRequest3.Timeout = 100000;
                //webRequest3.Credentials = myCache;
                //InsertSoapEnvelopeIntoWebRequest(soapEnvelopeXmlCot, webRequest3);
                ////Guardado de xml Emision Envio
                ////ObjData.IDLog = ca.guardadoLogEmision(soapEnvelopeXmlCot.InnerXml.ToString(), "", urlSitio, "", "", "", 1, nombreCompletoLog, ObjData.Cliente.Direccion.CodPostal, ObjData.Aseguradora, 0);

                ////Global.LOG += "Proceso Obtener Emisión <br>";

                //IAsyncResult asyncResult3 = webRequest3.BeginGetResponse(null, null);
                //asyncResult3.AsyncWaitHandle.WaitOne();



                ////Global.LOG += "Comienza proceso emisión<br>";
                XmlDocument docCot = new XmlDocument();


                //using (WebResponse webResponse = webRequest3.EndGetResponse(asyncResult3))
                //{
                //    using (StreamReader rd = new StreamReader(webResponse.GetResponseStream()))
                //    {
                //        soapResultCot = rd.ReadToEnd();
                //    }

                docCot.LoadXml(soapResultCot);

                //}
                //docCot.LoadXml(FakeEmisionXML());
                log.Info("EmitirVehiculo XML AXA pool Respuesta Emisión: " + docCot.InnerXml);
                //Start the serialization of NodeSolicitud class.
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(NodeSolicitud));
                XmlSerializer xmlSerializer2 = new XmlSerializer(typeof(NodeEmision));
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                XmlWriterSettings xmlWriterSettings2 = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                xmlWriterSettings2.Indent = true;

                //Serialize xml information
                NodeSolicitud solicitud = LeerXMLRequest(soapEnvelopeXmlCot);
                using (Utf8StringWriter stringWriter = new Utf8StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
                    {
                        xmlSerializer.Serialize(xmlWriter, solicitud);
                    }

                    xmlRequest = stringWriter.ToString();
                }
                NodeEmision respuesta = LeerXMLResponse(docCot);
                using (Utf8StringWriter stringWriter2 = new Utf8StringWriter())
                {
                    using (XmlWriter xmlWriter2 = XmlWriter.Create(stringWriter2, xmlWriterSettings2))
                    {
                        xmlSerializer2.Serialize(xmlWriter2, respuesta);
                    }

                    xmlRespuesta = stringWriter2.ToString();
                }
                log.Info("Termina la emisión axa");
                xmlRequest = xmlRequest.Replace("\r\n", "").Replace("\n", "").Replace("\r", "");
                xmlRespuesta = xmlRespuesta.Replace("\r\n", "").Replace("\n", "").Replace("\r", "");
                if (respuesta.Poliza != null && respuesta.Poliza.Errores != null)
                {
                    if (respuesta.Poliza.Errores.Error.Count > 0)
                    {
                        string Errores = string.Empty;
                        int count = 0;
                        foreach (var item in respuesta.Poliza.Errores.Error)
                        {
                            if (count == 0)
                                Errores = "El servicio de Axa Respondió lo siguiente: " + item;
                            else
                                Errores = Errores + "; " + item;
                            count++;
                        }

                        GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlRequest, xmlRespuesta, Errores, "Emisión");

                        return emisionpoliza = new EmisionPoliza(false, xmlRequest, Errores);
                    }
                }
                var m = docCot.InnerXml.IndexOf("<Emision>");
                var n = docCot.InnerXml.LastIndexOf("</Emision>") + 10;
                var contentRespuesta = System.Net.WebUtility.HtmlDecode(docCot.InnerXml.Substring(m, n - m));

                #endregion

                if (respuesta.Poliza != null && respuesta.Poliza.Generales != null)
                {
                    LocktonModel.db.Poliza poliza = new LocktonModel.db.Poliza();
                    PolizaDetalle polizaDet = new PolizaDetalle();

                    LocktonModel.db.Endoso endosoAlta = new LocktonModel.db.Endoso();
                    endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                    endosoAlta.Fecha = DateTime.Now;
                    endosoAlta.ValorAnterior = "Alta";
                    endosoAlta.ValorActual = "Contratación";

                    List<LocktonModel.db.Recibo> recibosGenerados = new List<LocktonModel.db.Recibo>();
                    decimal primaNeta = 0.0M;
                    decimal primaTotal = 0.0M;
                    decimal derechos = 0.0M;
                    decimal impuestos = 0.0M;
                    decimal recargo = 0.0M;
                    decimal primerPago = 0.0M;
                    decimal pagoSubsecuente = 0.0M;
                    string NumeroPoliza = string.Empty;

                    NumeroPoliza = respuesta.Poliza.Generales.NumeroPoliza;
                    var servicer = new CotizacionEmisionAXAService.SolicitudPolizasWSFacadeClient();
                    servicer.ClientCredentials.UserName.UserName = user;
                    servicer.ClientCredentials.UserName.Password = password;
                    string soapResultR;
                    log.Info(string.Format("AXAService Entra a getPoliza Poliza = {0}, Endoso = {1}", NumeroPoliza, NumeroPoliza.Substring(0, 8)));
                    soapResultR = service.getPoliza(NumeroPoliza, NumeroPoliza.Substring(0, 8), null);

                    string xmlRaw = soapResultR;

                    // Convierte &lt; &gt; etc a XML normal
                    string xml = WebUtility.HtmlDecode(xmlRaw);
                    log.Info("AXAService Respuesta getPoliza: " + xml);
                    XDocument doc = XDocument.Parse(xml);



                    var GetPolizaAxa = new LocktonModel.xmls.AXA.Consultas.Poliza
                    {

                        // ========================
                        // GENERALES
                        // ========================
                        Generales = doc.Descendants("Generales")
        .Select(g => new LocktonModel.xmls.AXA.Consultas.Generales
        {
            NumeroPoliza = (string)g.Element("Numero-Poliza"),
            TipoPoliza = (string)g.Element("TipoPoliza"),
            FechaDesde = ParseFecha(g.Element("FechaDesde")),
            FechaHasta = ParseFecha(g.Element("FechaHasta")),
            FechaEmision = ParseFecha(g.Element("FechaEmision")),
            FechaCancelacion = ParseFecha(g.Element("FechaCancelacion")),
            EstadoPoliza = (string)g.Element("EstadoPoliza"),
            Subramo = (string)g.Element("Subramo"),
            FormaPago = (string)g.Element("FormaPago"),
            Moneda = (string)g.Element("Moneda"),
            Agente = (string)g.Element("Agente"),
            CentroCostos = (string)g.Element("CentroCostos"),
            PolizaAnterior = (string)g.Element("PolizaAnterior"),
            PolizaSiguiente = (string)g.Element("PolizaSiguiente"),
            PagoElectronico = (string)g.Element("PagoElectronico"),
            TarifaAlta = (string)g.Element("TarifaAlta"),
            Arrendador = ParseInt(g.Element("Arrendador")),
            Version = ParseInt(g.Element("Version")),
            DescuentoPorExperiencia = ParseDecimal(g.Element("DescuentoPorExperiencia")),
            DescuentoPorVolumen = ParseDecimal(g.Element("DescuentoPorVolumen")),
            Servidora = (string)g.Element("Servidora"),
            Afianzadora = (string)g.Element("Afianzadora"),
            IndiceTarifa = ParseLong(g.Element("IndiceTarifa")),
            Tarifa = (string)g.Element("Tarifa")
        })
        .FirstOrDefault(),

                        // ========================
                        // TITULAR
                        // ========================
                        Titular = doc.Descendants("Titular")
        .Select(t => new LocktonModel.xmls.AXA.Consultas.Titular
        {
            TipoPersona = (string)t.Element("TipoPersona"),
            Nombre = (string)t.Element("Nombre"),
            ApPaterno = (string)t.Element("ApPaterno"),
            ApMaterno = (string)t.Element("ApMaterno"),
            RFC = (string)t.Element("RFC"),
            Telefono = (string)t.Element("Telefono"),
            Direccion = t.Element("Direccion") == null ? null : new LocktonModel.xmls.AXA.Consultas.Direccion
            {
                CalleNumero = (string)t.Element("Direccion").Element("CalleNumero"),
                Colonia = (string)t.Element("Direccion").Element("Colonia"),
                CodigoPostal = (string)t.Element("Direccion").Element("CodigoPostal"),
                Estado = (string)t.Element("Direccion").Element("Estado"),
                Poblacion = (string)t.Element("Direccion").Element("Poblacion")
            }
        })
        .FirstOrDefault(),

                        // ========================
                        // CONDICIONES EMISION
                        // ========================
                        CondicionesEmision = doc.Descendants("CondicionesEmision")
        .Select(c => new LocktonModel.xmls.AXA.Consultas.CondicionesEmision
        {
            EsValorComercial = (string)c.Element("EsValorComercial"),
            DanosMateriales = ParseInt(c.Element("DanosMateriales")),
            RoboTotal = ParseInt(c.Element("RoboTotal")),
            ResponsabilidadCivil = ParseInt(c.Element("ResponsabilidadCivil")),
            RCBienes = ParseDecimal(c.Element("RCBienes")),
            RCPersonas = ParseDecimal(c.Element("RCPersonas")),
            Accidentes = ParseDecimal(c.Element("Accidentes")),
            AutoSustituto = ParseInt(c.Element("AutoSustituto")),
            GastosMedicos = ParseDecimal(c.Element("GastosMedicos")),
            ServicioAsistencia = (string)c.Element("ServicioAsistencia"),
            SigueConAuto = (string)c.Element("SigueConAuto"),
            Fianza = ParseDecimal(c.Element("Fianza")),
            EquipoEspecial = ParseInt(c.Element("EquipoEspecial")),
            Adaptaciones = ParseInt(c.Element("Adaptaciones")),
            RoboExt = ParseInt(c.Element("RoboExt")),
            RoboInt = ParseInt(c.Element("RoboInt")),
            Viajero = ParseInt(c.Element("Viajero")),
            DobleRemolque = (string)c.Element("DobleRemolque"),
            AmpliacionRC = (string)c.Element("AmpliacionRC"),
            ExencionDeducible = (string)c.Element("ExencionDeducible"),
            ExtensionRC = (string)c.Element("ExtensionRC"),
            SUVA = (string)c.Element("SUVA")
        })
        .FirstOrDefault(),

                        // ========================
                        // BENEFICIARIO PREFERENTE
                        // ========================
                        BeneficiarioPreferente = doc.Descendants("BeneficiarioPreferente")
        .Select(b => new LocktonModel.xmls.AXA.Consultas.BeneficiarioPreferente())
        .ToList(),

                        // ========================
                        // CLIENTE YO
                        // ========================
                        ClienteYO = doc.Descendants("ClienteYO")
        .Select(c => new LocktonModel.xmls.AXA.Consultas.ClienteYO
        {
            NumeroPoliza = (string)c.Element("Numero-Poliza"),
            TipoPersona = (string)c.Element("TipoPersona"),
            Nombre = (string)c.Element("Nombre"),
            ApPaterno = (string)c.Element("ApPaterno"),
            ApMaterno = (string)c.Element("ApMaterno")
        })
        .ToList(),

                        // ========================
                        // CONDUCTORES REGISTRADOS
                        // ========================
                        ConductoresRegistrados = doc.Descendants("ConductoresRegistrados")
        .Descendants("Conductor")
        .Select(c => new LocktonModel.xmls.AXA.Consultas.ConductoresRegistrados
        {
            Conductor = c.Value
        })
        .ToList(),

                        // ========================
                        // BENEFICIARIOS ACCIDENTES
                        // ========================
                        BeneficiariosAccidentes = doc.Descendants("BeneficiariosAccidentes")
        .Descendants("Beneficiario")
        .Select(b => new LocktonModel.xmls.AXA.Consultas.BeneficiariosAccidentes
        {
            Beneficiario = b.Value
        })
        .ToList(),

                        // ========================
                        // VEHICULO
                        // ========================
                        Vehiculo = doc.Descendants("Vehiculo")
        .Select(v => new LocktonModel.xmls.AXA.Consultas.Vehiculo
        {
            Modelo = ParseInt(v.Element("Modelo")),
            Paquete = (string)v.Element("Paquete"),
            Marca = (string)v.Element("Marca"),
            Descripcion = (string)v.Element("Descripcion"),
            Ocupantes = ParseInt(v.Element("Ocupantes")),
            Motor = (string)v.Element("Motor"),
            Serie = (string)v.Element("Serie"),
            Placas = (string)v.Element("Placas"),
            EdoPlacas = (string)v.Element("EdoPlacas"),
            ClaveUso = ParseInt(v.Element("ClaveUso")),
            Uso = (string)v.Element("Uso"),
            Servicio = (string)v.Element("Servicio"),
            TipoCarga = (string)v.Element("TipoCarga"),
            PorcentajeSuma = ParseDecimal(v.Element("PorcentajeSuma")),
            Valor = ParseDecimal(v.Element("Valor")),
            ClaveAmis = (string)v.Element("ClaveAmis")
        })
        .FirstOrDefault(),

                        // ========================
                        // ENDOSOS / COBERTURAS / RECIBOS
                        // ========================
                        Endosos = doc.Descendants("Endoso")
        .Select(e => new LocktonModel.xmls.AXA.Consultas.Endoso
        {
            NumeroPoliza = (string)e.Element("Numero-Poliza"),
            NumeroEndoso = (string)e.Element("NumeroEndoso"),
            Descripcion = (string)e.Element("Descripcion"),
            FechaTrabajo = ParseFecha(e.Element("FechaTrabajo")),
            FechaDesde = ParseFecha(e.Element("FechaDesde")),
            FechaHasta = ParseFecha(e.Element("FechaHasta")),
            PrimaNeta = ParseDecimal(e.Element("PrimaNeta")),
            Recargo = ParseDecimal(e.Element("Recargo")),
            Derecho = ParseDecimal(e.Element("Derecho")),
            Impuesto = ParseDecimal(e.Element("Impuesto")),
            PrimaTotal = ParseDecimal(e.Element("PrimaTotal")),
            Coberturas = e.Descendants("Cobertura")
                .Select(c => new LocktonModel.xmls.AXA.Consultas.Cobertura
                {
                    NumeroPoliza = (string)c.Element("Numero-Poliza"),
                    NumeroEndoso = (string)c.Element("NumeroEndoso"),
                    Descripcion = (string)c.Element("Descripcion"),
                    Suma = (string)c.Element("Suma"),
                    Deducible = (string)c.Element("Deducible"),
                    PrimaTotal = ParseDecimal(c.Element("PrimaTotal"))
                })
                .ToList(),
            Recibos = e.Descendants("Recibo")
                .Select(r => new LocktonModel.xmls.AXA.Consultas.Recibo
                {
                    NumeroPoliza = (string)r.Element("Numero-Poliza"),
                    NumeroEndoso = (string)r.Element("NumeroEndoso"),
                    FechaTrabajo = ParseFecha(r.Element("FechaTrabajo")),
                    FechaDesde = ParseFecha(r.Element("FechaDesde")),
                    FechaHasta = ParseFecha(r.Element("FechaHasta")),
                    ComprobantePago = (string)r.Element("ComprobantePago"),
                    MedioDePago = (string)r.Element("MedioDePago"),
                    FechaPago = ParseFecha(r.Element("FechaPago")),
                    FechaImpresion = ParseFecha(r.Element("FechaImpresion")),
                    SerieRecibo = ParseLong(r.Element("SerieRecibo")),
                    EstadoRecibo = (string)r.Element("EstadoRecibo"),
                    FolioRecibo = (string)r.Element("FolioRecibo"),
                    PrimaNeta = ParseDecimal(r.Element("PrimaNeta")),
                    Recargo = ParseDecimal(r.Element("Recargo")),
                    Derecho = ParseDecimal(r.Element("Derecho")),
                    Impuesto = ParseDecimal(r.Element("Impuesto")),
                    PrimaTotal = ParseDecimal(r.Element("PrimaTotal"))
                })
                .OrderBy(r => r.FechaDesde)
                .ToList()
        })
        .ToList()

                    };



                    DateTime? ParseFecha(XElement el)
                    {
                        if (el == null) return null;

                        var v = el.Value.Trim();
                        if (string.IsNullOrEmpty(v)) return null;

                        return DateTime.ParseExact(v, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }

                    decimal? ParseDecimal(XElement el)
                    {
                        if (el == null) return null;

                        var v = el.Value.Trim();
                        if (string.IsNullOrEmpty(v)) return null;

                        return decimal.Parse(v.Replace(",", ""), CultureInfo.InvariantCulture);
                    }

                    int? ParseInt(XElement el)
                    {
                        if (el == null) return null;

                        var v = el.Value.Trim();
                        if (string.IsNullOrEmpty(v)) return null;

                        return int.Parse(v);
                    }

                    long? ParseLong(XElement el)
                    {
                        if (el == null) return null;

                        var v = el.Value.Trim();
                        if (string.IsNullOrEmpty(v)) return null;

                        return long.Parse(v);
                    }
                    log.Info("AXAService entra a recorrer los recibos");
                    foreach (var item in GetPolizaAxa.Endosos)
                    {
                        primaNeta = item.PrimaNeta ?? 0m;
                        primaTotal = item.PrimaTotal ?? 0m;
                        derechos = item.Derecho ?? 0m;
                        recargo = item.Recargo ?? 0m;
                        impuestos = item.Impuesto ?? 0m;
                        int i = 1;
                        foreach (var recibo in item.Recibos)
                        {
                            LocktonModel.db.Recibo reciboSaves = new LocktonModel.db.Recibo();
                            reciboSaves.InicioVigencia = Convert.ToDateTime(recibo.FechaDesde);
                            reciboSaves.FinVigencia = Convert.ToDateTime(recibo.FechaHasta);
                            reciboSaves.Numero = i;
                            reciboSaves.NoAsegurado = i.ToString();
                            reciboSaves.PrimaNeta = recibo.PrimaNeta ?? 0m;
                            reciboSaves.PrimaTotal = recibo.PrimaTotal ?? 0m;
                            reciboSaves.Derecho = recibo.Derecho ?? 0m;
                            reciboSaves.Recargo = recibo.Recargo ?? 0m;
                            reciboSaves.Comision = 0;//(decimal.Parse(detalle.CesionComision) == 0) ? 0 : decimal.Parse(detalle.CesionComision) / RecibSub;
                            reciboSaves.Impuesto = recibo.Impuesto ?? 0m;
                            recibosGenerados.Add(reciboSaves);
                            i++;
                        }
                    }
                    log.Info("AXAService termina a recorrer los recibos");
                    poliza.NumeroPoliza = NumeroPoliza;
                    poliza.Motor = InfoEmision.NumeroMotor;
                    poliza.Serie = InfoEmision.NumeroSerie;
                    poliza.Placas = InfoEmision.Placas;
                    poliza.FinVigencia = Convert.ToDateTime(respuesta.Poliza.Generales.FechaHasta);
                    poliza.InicioVigencia = Convert.ToDateTime(respuesta.Poliza.Generales.FechaDesde);
                    poliza.FechaEmision = DateTime.Now;
                    poliza.PrimaNeta = primaNeta;
                    poliza.PrimaTotal = primaTotal;
                    poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                    poliza.Estatus = 20;
                    poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                    poliza.IdConvenio = InfoEmision.Convenio.Id;
                    poliza.IdTipoCobertura = tipoPaquete.Id;
                    poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                    poliza.PrimaNetaAnualizada = primaNeta;
                    poliza.PrimaTotalAnualizada = primaTotal;
                    poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                    poliza.Acepto_DescuentoPoliza = true;

                    poliza.UrlPDFPoliza = "";
                    poliza.UrlPDFRecibos = "";

                    polizaDet.XMLRecepcion = contentRespuesta;
                    polizaDet.XMLSolicitud = soapEnvelopeXmlCot.InnerText;
                    polizaDet.IdCatRamoVehiculo = cotizacionDetalle.IdVehiculo;// db.PaqueteConvenio.FirstOrDefault(x => x.IdCatTipoPaquete.Equals(tipoPaquete.Id) && x.IdConvenio.Equals(InfoEmision.Convenio.Id)).IdCatRamoVehiculo;
                    polizaDet.Derechos = derechos;
                    polizaDet.Inciso = "1";
                    polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para AXA.
                    polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                    polizaDet.Deducible = 0;
                    polizaDet.Comision = 0;
                    polizaDet.FactorIva = 16; //Ponerlo de manera dinamica
                    polizaDet.MigraOPERA = false;
                    polizaDet.UrlPDFPolizaOPERA = "";
                    polizaDet.PolizaOPERA = 0;
                    polizaDet.OTOpera = 0;
                    polizaDet.EndosoOPERA = 0;
                    polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                    polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;

                    polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                    polizaDet.IdCotizacionDetalle = InfoEmision.IdCotizacion;
                    polizaDet.IdCatModalidadFormaPago = medioPago.Id;
                    polizaDet.IdCatPeriodicidadFormaPago = perioricidad.IdCatPeriodicidadFormaPago;
                    polizaDet.IdCatModalidadFormaPago = db.CatModalidadFormaPago.FirstOrDefault(x => x.Clave.Equals(InfoEmision.CotizacionAutoGuardar.MediodePago.ToString())).Id;
                    polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;
                    polizaDet.BenefMuerteAccidental = InfoEmision.BenefMuerteAccidental ?? "";

                    //RECIBOS Request
                    endosoAlta.Recibo = recibosGenerados;
                    poliza.NumeroPoliza = NumeroPoliza;

                    poliza.Endoso.Add(endosoAlta);
                    poliza.PolizaDetalle.Add(polizaDet);
                    db.Poliza.Add(poliza);
                    db.SaveChanges();
                    log.Info("EmitirVehiculo se guardaron correctamente los datos Poliza: " + NumeroPoliza);

                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlRequest, xmlRespuesta, "", "Emisión");

                    Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                    emisionpoliza = new EmisionPoliza(true, xmlRequest, xmlRespuesta, poliza);
                }
                else
                {
                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlRequest, xmlRespuesta, contentRespuesta, "Emisión");
                    emisionpoliza = new EmisionPoliza(false, xmlRequest, xmlRespuesta);
                }
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente para realizar tu emision {0} ", ex.Message));
                //throw new Exception(string.Format("Tuvimos un inconveniente para realizar tu emision {0} ", ex.Message));
                //log.Info("EmitirVehiculo Error: " + ex.InnerException != null ? ex.InnerException.Message : ex.Message);
                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlRequest, xmlRespuesta, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");
                emisionpoliza = new EmisionPoliza(false, xmlRequest, xmlRespuesta);
            }
            return emisionpoliza;
        }

        private LocktonModel.db.Endoso ConstruirEndoso()
        {
            log.Info("Crea endoso de alta para la nueva póliza.");
            return new LocktonModel.db.Endoso()
            {
                IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id,
                Fecha = DateTime.Now,
                ValorAnterior = "Alta",
                ValorActual = "Contratación"
            };
        }

        public static string ObetenrURLPDFPoliza(string polizaID, CredentialCache myCache, string _url)
        {
            log.Info("ObetenrURLPDFPoliza entra a obeter la Reimpresión de la póliza ");
            string PolizaResponse = string.Empty;

            try
            {
                XmlDocument docImp = new XmlDocument();

                XmlDocument soapEnvelopeXmlImp = CreateSoapEnvelopeImpresion(polizaID);
                HttpWebRequest webRequest4 = CreateWebRequest(_url, "");
                webRequest4.PreAuthenticate = true;
                webRequest4.Credentials = myCache;
                webRequest4.Timeout = 100000;
                InsertSoapEnvelopeIntoWebRequest(soapEnvelopeXmlImp, webRequest4);

                IAsyncResult asyncResult4 = webRequest4.BeginGetResponse(null, null);
                asyncResult4.AsyncWaitHandle.WaitOne();

                dynamic soapResultImp;
                using (WebResponse webResponse = webRequest4.EndGetResponse(asyncResult4))
                {
                    using (StreamReader rd = new StreamReader(webResponse.GetResponseStream()))
                    {
                        soapResultImp = rd.ReadToEnd();
                    }

                    docImp.LoadXml(soapResultImp);
                }


                XmlNodeList colElementosImp = docImp.GetElementsByTagName("soapenv:Envelope");
                XmlNodeList colElementosImp2 = docImp.GetElementsByTagName("soapenv:Body");
                XmlNodeList colElementosImp3 = docImp.GetElementsByTagName("ns1:getPDFPolizaResponse");
                XmlNodeList colElementosImp4 = docImp.GetElementsByTagName("getPDFPolizaReturn");
                foreach (XmlNode objNodoPaquete in colElementosImp)
                {
                    foreach (XmlNode objNodoPaquete1 in colElementosImp2)
                    {
                        foreach (XmlNode objNodoPaquete2 in colElementosImp3)
                        {
                            PolizaResponse = objNodoPaquete2["getPDFPolizaReturn"].InnerText;
                            //dynamic arrayURL = objNodoPaquete2["getPDFPolizaReturn"].InnerText;
                            //Uri uri = HttpContext.Current.Request.Url;
                            //string pathQuery = uri.PathAndQuery;
                            //string hostName = uri.ToString().Replace(pathQuery, "");
                            //string rutaUrl = hostName + @"\axa\";
                            //string rutaLocal = System.Web.HttpContext.Current.Server.MapPath("~/axa/");
                            //dynamic arraybyte = Convert.FromBase64String(objNodoPaquete2["getPDFPolizaReturn"].InnerText);
                            //File.WriteAllBytes(rutaLocal + ObjData.Emision.Poliza + ".pdf", arraybyte);
                            //ObjData.Emision.Documento = rutaUrl + ObjData.Emision.Poliza + ".pdf";
                        }
                    }

                }
                log.Info("ObetenrURLPDFPoliza termina proceso Reimprimir póliza");

            }
            catch (Exception ex)
            {
                log.Info("ObetenrURLPDFPoliza se generó un error: " + ex.InnerException != null ? ex.InnerException.Message : ex.Message);
                return "";
            }
            return PolizaResponse;
        }

        private static string FakeEmisionXML()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<?xml version=\"1.0\"?>");
            sb.Append("<Emision>");
            sb.Append("<SolicitudID>4639562561942719180</SolicitudID>");
            sb.Append("<Poliza>");
            sb.Append("<Generales>");
            sb.Append("<Solicitud>DHR0</Solicitud>");
            sb.Append("<Consecutivo>1</Consecutivo>");
            sb.Append("<Numero-Poliza>DHR012340000</Numero-Poliza>");
            sb.Append("<FormaPago>CONTADO</FormaPago>");
            sb.Append("<FechaDesde>03/12/2018</FechaDesde>");
            sb.Append("<FechaHasta>30/09/2019</FechaHasta>");
            sb.Append("<Tarifa>TB7030</Tarifa>");
            sb.Append("<IndiceTarifa>389101</IndiceTarifa>");
            sb.Append("<FechaTrabajo>03/12/2018</FechaTrabajo>");
            sb.Append("</Generales>");
            sb.Append("<Titular>");
            sb.Append("<Nombre>MARIOALBERTORAMIREZPEREZ</Nombre>");
            sb.Append("<NumeroCliente>CL05372434</NumeroCliente>");
            sb.Append("<RFC>RAPM740301EH5</RFC>");
            sb.Append("<Sexo>");
            sb.Append("</Sexo>");
            sb.Append("<Edad>0</Edad>");
            sb.Append("</Titular>");
            sb.Append("<Vehiculo>");
            sb.Append("<Descripcion>LANCERESMT</Descripcion>");
            sb.Append("<Modelo>2010</Modelo>");
            sb.Append("<Placas>483WWY</Placas>");
            sb.Append("<Motor>DK0927</Motor>");
            sb.Append("<Serie>JE3AU26U4AU017001</Serie>");
            sb.Append("<Valor>112310</Valor>");
            sb.Append("<EsValorComercial>SI</EsValorComercial>");
            sb.Append("<Uso>NORMAL</Uso>");
            sb.Append("<Servicio>PARTICULAR</Servicio>");
            sb.Append("<Ocupantes>5</Ocupantes>");
            sb.Append("<Tonelaje>0.0</Tonelaje>");
            sb.Append("</Vehiculo>");
            sb.Append("<CondicionesEmision>");
            sb.Append("<DescuentoPorNoSiniestro>0.0</DescuentoPorNoSiniestro>");
            sb.Append("<ExtensionRC>SI</ExtensionRC>");
            sb.Append("<AmpliarRC>NO</AmpliarRC>");
            sb.Append("<DobleRemolque>NO</DobleRemolque>");
            sb.Append("<RecibosSubsecuentes>0</RecibosSubsecuentes>");
            sb.Append("<Importes-Recibos>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>2494.24</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>330</Derechos>");
            sb.Append("<Impuesto>451.88</Impuesto>");
            sb.Append("<PrimaTotal>3276.12</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>2494.24</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>330</Derechos>");
            sb.Append("<Impuesto>451.88</Impuesto>");
            sb.Append("<PrimaTotal>3276.12</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("<DetalleImporte>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("<CesionComision>0</CesionComision>");
            sb.Append("<Recargos>0</Recargos>");
            sb.Append("<Derechos>0</Derechos>");
            sb.Append("<Impuesto>0</Impuesto>");
            sb.Append("<PrimaTotal>0</PrimaTotal>");
            sb.Append("</DetalleImporte>");
            sb.Append("</Importes-Recibos>");
            sb.Append("<Coberturas>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>DañosMateriales</Nombre>");
            sb.Append("<Deducible>5</Deducible>");
            sb.Append("<SumaAsegurada>112310</SumaAsegurada>");
            sb.Append("<PrimaNeta>1473.44</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>RoboTotal</Nombre>");
            sb.Append("<Deducible>5</Deducible>");
            sb.Append("<SumaAsegurada>112310</SumaAsegurada>");
            sb.Append("<PrimaNeta>423.35</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>RCBienes</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>1000</SumaAsegurada>");
            sb.Append("<PrimaNeta>369.63</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>ServiciodeAsistencia</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>Amparada</SumaAsegurada>");
            sb.Append("<PrimaNeta>63.28</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>RCPersonas</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>3000</SumaAsegurada>");
            sb.Append("<PrimaNeta>76.24</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>GastosMédicos</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>350000</SumaAsegurada>");
            sb.Append("<PrimaNeta>61.92</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>Proliber</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>1000</SumaAsegurada>");
            sb.Append("<PrimaNeta>14.16</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>Accidentes</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>100000</SumaAsegurada>");
            sb.Append("<PrimaNeta>12.22</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("<Cobertura>");
            sb.Append("<Nombre>");
            sb.Append("</Nombre>");
            sb.Append("<Deducible>0</Deducible>");
            sb.Append("<SumaAsegurada>");
            sb.Append("</SumaAsegurada>");
            sb.Append("<PrimaNeta>0</PrimaNeta>");
            sb.Append("</Cobertura>");
            sb.Append("</Coberturas>");
            sb.Append("</CondicionesEmision>");
            sb.Append("</Poliza>");
            sb.Append("</Emision>");

            return sb.ToString();
        }



        private static HttpWebRequest CreateWebRequest(string url, string action)
        {
            HttpWebRequest webRequest__1 = ((HttpWebRequest)WebRequest.Create(url));
            webRequest__1.Accept = "text/xml";
            webRequest__1.Method = "POST";
            return webRequest__1;
        }

        private static void InsertSoapEnvelopeIntoWebRequest(XmlDocument soapEnvelopeXml, HttpWebRequest webRequest)
        {
            using (Stream stream = webRequest.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }
        }

        private static XmlDocument CreateSoapEnvelope(InformacionEmision ObjData)
        {
            XmlDocument soapEnvelop = new XmlDocument();
            string Finicio = DateTime.Now.ToString("yyyyMMdd");
            string FFin = DateTime.Now.AddYears(1).ToString("yyyyMMdd");
            soapEnvelop.LoadXml("<soapenv:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:wsf='http://wsfacade.emisionpolizas.autos.seguros.mx.ia3.ing.com'><soapenv:Header/><soapenv:Body><wsf:getCatalogosPorTarifaYNombre soapenv:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'> <tarifa xsi:type='xsd:string'>TB4127</tarifa><nombreCatalogo xsi:type='xsd:string'>Marca</nombreCatalogo></wsf:getCatalogosPorTarifaYNombre></soapenv:Body></soapenv:Envelope>");
            return soapEnvelop;
        }

        private XmlDocument CreateSoapEnvelopeEmision(InformacionEmision ObjData, string estado, string IdGeren, string IdConv, string agente, int idTipoPaquete)
        {
            XmlDocument soapEnvelop = new XmlDocument();
            //ClientesAdmin ca = new ClientesAdmin();
            AXAService wsaxa = new AXAService();
            int idConvenio = Int32.Parse(IdConv);

            NodeSolicitud datosRequest = LeerXMLRequest(ObjData.XmlsAseguradoras["CotizacionSolicitud"]);
            NodeEmision datosResponse = LeerXMLResponse(ObjData.XmlsAseguradoras["CotizacionRecepcion"]);
            //Verificamos que tipo de cotizacion esta configurada en el convenio
            Convenio datosConvenio = db.Convenio.Where(w => w.Id == idConvenio).FirstOrDefault();// ca.getDatosConvenioWS(Int32.Parse(idConvenio));
            string tipoVigencia = "ANUAL";
            string InicioVigencia = "";
            string FinVigencia = "";
            if (datosConvenio.IdCatTipoVigencia == 1)//if (datosConvenio.tipoVigencia == "Vigencia Prorrata")
            {
                InicioVigencia = datosResponse.Poliza.Generales.FechaDesde; //DateTime.Now.ToString("dd") + "/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.Year.ToString();

                string fechaRe = datosConvenio.FinVigencia.ToString();
                string[] datosFecha = fechaRe.Split(' ');
                DateTime ffVig = DateTime.Parse(datosFecha[0]);
                FinVigencia = ffVig.ToString("dd/MM/yyyy");
            }
            else if (datosConvenio.IdCatTipoVigencia == 2)//else if (datosConvenio.tipoVigencia == "Vigencia Anual")
            {
                tipoVigencia = "ANUAL";
                //Vigencia Anual
                InicioVigencia = datosResponse.Poliza.Generales.FechaDesde; //DateTime.Now.ToString("dd") + "/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.Year.ToString();
                FinVigencia = Convert.ToDateTime(datosResponse.Poliza.Generales.FechaDesde).AddYears(1).ToString("dd/MM/yyyy");//DateTime.Now.ToString("dd") + "/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.AddYears(1).Year.ToString();
            }

            //int IdGerencia = int.Parse(IdGeren);
            //Verificamos si el negocio y convenio se encuentran en enrollment
            var resEnrollment = db.Enrollment.Where(x => x.IdEmpresa == ObjData.Empresa.Id && x.IdEstatus == 1).FirstOrDefault();//int resEnrollment = ca.verificarEnrollmentNegocio(IdGerencia);
            if (resEnrollment != null)
            {
                //Si se encuentra en enrollment sustituimos las fechas por las configuradas en el convenio
                string fechaRe2 = datosConvenio.InicioVigencia.ToString();
                string[] datosFecha2 = fechaRe2.Split(' ');
                DateTime fiVig = DateTime.Parse(datosFecha2[0]);
                InicioVigencia = fiVig.ToString("dd/MM/yyyy");

                string fechaRe = datosConvenio.FinVigencia.ToString();
                string[] datosFecha = fechaRe.Split(' ');
                DateTime ffVig = DateTime.Parse(datosFecha[0]);
                FinVigencia = ffVig.ToString("dd/MM/yyyy");
            }

            ObjData.Poliza.InicioVigencia = DateTime.Parse(InicioVigencia);//ObjData.Emision.FInicio = InicioVigencia.ToString();
            ObjData.Poliza.FinVigencia = DateTime.Parse(FinVigencia);//ObjData.Emision.FTermino = FinVigencia.ToString();

            //Obtenemos el tipo de vehículo y número de pasajeros
            dynamic Lista = ObjData.Vehiculo.TipoVehiculo; //ca.getTipoAut(ObjData.Vehiculo.Clave);
                                                           //string tipoAut = Lista[0];
                                                           //string Pasajeros = Lista[1];

            string Serie = datosConvenio.SerieAXA;//datosConvenio.serie.ToString();
            string paquete = datosConvenio.NombreAXA;//datosConvenio.nombre.ToString(); ;
            string producto = datosConvenio.ProductoAXA;//datosConvenio.producto.ToString();
            string FormaPago = "";
            string FormaPagoCobranza = "";
            string formaPagoId = "";
            string fechaNac = (Convert.ToDateTime(ObjData.DetalleUsuario.FECHANACIMIENTO)).ToString("dd/MM/yyyy"); //(Convert.ToDateTime(ObjData.Cliente.FechaNacimiento)).ToString("dd/MM/yyyy");				
            PeriodicidadFormaPago perioricidad = db.PeriodicidadFormaPago
                                .Where(x => x.IdConvenio == datosConvenio.Id
                                    && x.IdCatPeriodicidadFormaPago == ObjData.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            if (perioricidad != null)
            {
                formaPagoId = perioricidad.IdCatPeriodicidad.ToString();
                FormaPago = perioricidad.FormaPago;
                FormaPagoCobranza = perioricidad.FormaPagoCobranza;

            }
            else
            {
                formaPagoId = "1";
                FormaPago = "CONTADO";
            }
            FormaPagoCobranza = String.IsNullOrEmpty(FormaPagoCobranza) ? "AUTOS" : FormaPagoCobranza;
            string tipoPersona = "";

            char separador = ' ';
            string nomTarjeta = "";
            string appTarjeta = "";
            string apmTarjeta = "";
            dynamic nombreTarjetaArray = ObjData.Tarjeta.TitularTarjeta.Split(separador);//ObjData.Pago.NombreTarjeta.Split(separador);

            for (int i = 0; i <= nombreTarjetaArray.Length - 3; i++)
            {
                nomTarjeta = nomTarjeta + nombreTarjetaArray[i];
            }
            nomTarjeta = ObjData.Tarjeta.NombreTitularTarjeta;
            appTarjeta = ObjData.Tarjeta.ApellidoPTitularTarjeta; /*nombreTarjetaArray[nombreTarjetaArray.Length - 2];*/
            apmTarjeta = ObjData.Tarjeta.ApellidoMTitularTarjeta;/*nombreTarjetaArray[nombreTarjetaArray.Length - 1];*/


            tipoPersona = (ObjData.EmisionPersonaMoral) ? "MORAL" : "FISICA";
            PersonaMoral personaMoral = new PersonaMoral();
            string numeroIntPM = "";
            if (ObjData.EmisionPersonaMoral)
            {
                personaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == ObjData.PersonaMoral.Id);
                numeroIntPM = string.IsNullOrEmpty(personaMoral.Direccion.NumeroInt) ? "" : " " + personaMoral.Direccion.NumeroInt;
            }

            log.Info($"Inicia proceso para tokenizar tarjeta");

            #region Tokeniza tarjeta									

            string tokenTarjeta = string.Empty;
            string IdBanco = string.Empty;
            if (ConfigurationManager.AppSettings["TipoConexion"].Equals("1") ? false : true)
            {
                if (!string.IsNullOrEmpty(ObjData.Tarjeta.NumeroTarjeta) && ObjData.CotizacionAutoGuardar.MediodePago == 0)
                {
                    var varUrlTokeniza = string.Empty;
                    var tokenBearer = GeneraTokenAXA(datosConvenio.Usuario, datosConvenio.Contrasena);
                    TokenRequest tokenTar = new TokenRequest();
                    if (ConfigurationManager.AppSettings["TipoConexion"].Equals("1") ? false : true)
                    {
                        varUrlTokeniza = "TokenizaProd";
                    }
                    else
                    {
                        varUrlTokeniza = "TokenizaTest";
                    }


                    varUrlTokeniza = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varUrlTokeniza);

                    Guid g;
                    // Create and display the value of two GUIDs.
                    g = Guid.NewGuid();

                    tokenTar.AXAHeaderReq.ramo = "COL";
                    tokenTar.AXAHeaderReq.medio = "WEB";
                    tokenTar.AXAHeaderReq.transaccion = "";
                    tokenTar.AXAHeaderReq.evento = "";
                    tokenTar.AXAHeaderReq.segmento = "";
                    tokenTar.AXAHeaderReq.rol = "Agente";
                    tokenTar.AXAHeaderReq.usuario = datosConvenio.Usuario;//"MXS00101422A";//"MXS02009708A";
                    tokenTar.AXAHeaderReq.sistemaId = "SRV007";
                    tokenTar.AXAHeaderReq.version = "1.0";
                    tokenTar.AXAHeaderReq.UUID = g.ToString();
                    tokenTar.AXAHeaderReq.fechaHora = DateTime.UtcNow.ToString("s");

                    tokenTar.data.referencia = $"SRV007+{ObjData.IdCotizacion}{DateTime.Now.ToString("yyyyMMddHHmmss")}+0";
                    tokenTar.data.datosTarjeta.PAN = ObjData.Tarjeta.NumeroTarjeta;
                    tokenTar.data.nombre = ObjData.Tarjeta.NombreTitularTarjeta;
                    tokenTar.data.apellidoPaterno = ObjData.Tarjeta.ApellidoPTitularTarjeta;
                    tokenTar.data.apellidoMaterno = ObjData.Tarjeta.ApellidoMTitularTarjeta;
                    tokenTar.data.MSI = 0;
                    tokenTar.data.fechaVencimiento = ObjData.Tarjeta.MesVencimiento + "/" + ObjData.IdAnio.ToString().Substring(2);
                    tokenTar.data.email = ObjData.Tarjeta.Email;


                    var tokenTarLog = new TokenRequest
                    {
                        AXAHeaderReq = new AXAHeaderReq
                        {
                            ramo = tokenTar.AXAHeaderReq.ramo,
                            medio = tokenTar.AXAHeaderReq.medio,
                            transaccion = tokenTar.AXAHeaderReq.transaccion,
                            evento = tokenTar.AXAHeaderReq.evento,
                            segmento = tokenTar.AXAHeaderReq.segmento,
                            rol = tokenTar.AXAHeaderReq.rol,
                            usuario = tokenTar.AXAHeaderReq.usuario,
                            sistemaId = tokenTar.AXAHeaderReq.sistemaId,
                            version = tokenTar.AXAHeaderReq.version,
                            UUID = tokenTar.AXAHeaderReq.UUID,
                            fechaHora = tokenTar.AXAHeaderReq.fechaHora
                        },
                        data = new DataContact
                        {
                            referencia = tokenTar.data.referencia,
                            datosTarjeta = new DatosTarjeta
                            {
                                PAN = "******" // <- enmascarado solo para log
                            },
                            nombre = tokenTar.data.nombre,
                            apellidoPaterno = tokenTar.data.apellidoPaterno,
                            apellidoMaterno = tokenTar.data.apellidoMaterno,
                            MSI = tokenTar.data.MSI,
                            fechaVencimiento = "**/**", // sugerido para log
                            email = tokenTar.data.email
                        }
                    };


                    string objetcts = string.Empty;

                    objetcts = JsonConvert.SerializeObject(tokenTarLog);
                    log.Info("AXA Colectividad  Datos Request Tokenizar " + objetcts);
                    var respuesta = LocktonServicios.Utilidades.Utilidades.Tokenizar(varUrlTokeniza, tokenBearer, tokenTar);


                    if (respuesta.AXAHeaderRes.resultado.codigo == 0)
                    {
                        tokenTarjeta = respuesta.data.tokenClabe;
                        IdBanco = respuesta.data.banco.ToString();
                    }
                    else
                    {
                        log.Info("Error al Tokenizar Tarjeta " + respuesta.AXAHeaderRes.resultado.mensaje);
                        throw new Exception(respuesta.AXAHeaderRes.resultado.mensaje);

                    }
                }

                if (ObjData.CotizacionAutoGuardar.MediodePago == 0 || ObjData.CotizacionAutoGuardar.MediodePago == 1)
                {
                    var validationRequest = new TokenValidationRequest();
                    validationRequest.AXAHeaderReq = new AXAHeaderReq();
                    validationRequest.AXAHeaderReq.ramo = "AU";
                    validationRequest.AXAHeaderReq.medio = "Internet";
                    validationRequest.AXAHeaderReq.transaccion = "IND";
                    validationRequest.AXAHeaderReq.evento = "E";
                    validationRequest.AXAHeaderReq.segmento = "O";
                    validationRequest.AXAHeaderReq.rol = "Agente";
                    validationRequest.AXAHeaderReq.usuario = datosConvenio.Usuario;//"MXS00102064A";//"MXS02009708A";
                    validationRequest.AXAHeaderReq.sistemaId = "SRV007";
                    validationRequest.AXAHeaderReq.version = "1.0";
                    validationRequest.AXAHeaderReq.UUID = Guid.NewGuid().ToString();
                    validationRequest.AXAHeaderReq.fechaHora = DateTime.UtcNow.ToString("s");

                    validationRequest.data = new DataValidation();
                    validationRequest.data.tokenClabe = ObjData.CotizacionAutoGuardar.MediodePago == 0 ? tokenTarjeta : ObjData.Tarjeta.ClaveInterbancaria;
                    validationRequest.data.nombreRazonSocial = ObjData.Tarjeta.NombreTitularTarjeta;
                    validationRequest.data.apellidoPaterno = ObjData.Tarjeta.ApellidoPTitularTarjeta;
                    validationRequest.data.apellidoMaterno = ObjData.Tarjeta.ApellidoMTitularTarjeta;
                    //validationRequest.data.fechaVencimiento = ObjData.CotizacionAutoGuardar.MediodePago == 0? ObjData.Tarjeta.MesVencimiento + "/" + ObjData.IdAnio.ToString().Substring(2): "";
                    validationRequest.data.email = ObjData.Tarjeta.Email;

                    var tokenValidacion = GeneraTokenAXA(datosConvenio.Usuario, datosConvenio.Contrasena);
                    var validationResponse = TokenValidation(tokenValidacion, validationRequest);

                    if (validationResponse.AXAHeaderRes.resultado.codigo == 0)
                    {
                        log.Info($"Validacion de Token correcta");
                    }
                    else
                    {
                        log.Info($"Validacion de token fallida {validationResponse.AXAHeaderRes.resultado.mensaje}");
                        throw new Exception(validationResponse.AXAHeaderRes.resultado.mensaje);
                    }

                }

            }

            #endregion Tokeniza tarjeta
            log.Info($"Finaliza proceso para tokenizar tarjeta");

            if (ObjData.DatosUsuario == null)
            {
                ObjData.DatosUsuario = new VDatosUsuario();
            }
            else
            {
                if (ObjData.DatosUsuario.Direccion == null)
                {
                    ObjData.DatosUsuario.Direccion = new LocktonModel.db.Direccion();
                }
            }

            string idPoblacion = ObjData.DatosUsuario.Direccion.IdEstado.ToString(); //ConsultaPoblacionAXA(estado, ObjData.Cliente.Direccion.Poblacion);
            /*string idBanco = ObjData.IdBanco.ToString();*///ConsultaBancoAXA(ObjData.Pago.Banco);
                                                            //string[] resVehiculo = ObjData.Vehiculo.Serie.Split('/');//getMarcaTipoVehiculo(ObjData.Vehiculo.Clave); TODO:Valor del campo resVehiuclo
                                                            //string colonia = (ObjData.DatosUsuario.Direccion.Colonia != null ? ObjData.DatosUsuario.Direccion.Colonia : "");//string colonia = (ObjData.Cliente.Direccion.Colonia != null ? ObjData.Cliente.Direccion.Colonia : "");

            //Validacion emision valor factura
            string nodoValor = "";
            string esValorComercial = "SI";
            if (ObjData.CotizacionAutoGuardar.ValorFactura)//if (ObjData.Vehiculo.ValorFactura == "1")
            {
                nodoValor = "<Valor>" + Convert.ToInt32(ObjData.CotizacionAutoGuardar.MontoFactura) + "</Valor>";//nodoValor = "<Valor>" + ObjData.Vehiculo.Valor + "</Valor>";
                esValorComercial = "NO";//Esto indica que es a valor Factura
            }
            string porcentajeValor = getPorcentajeValor(idConvenio, idTipoPaquete).ToString();
            string xsd = Request.GetXMLSchemaDefition();

            estado = "9";
            idPoblacion = "1";
            //estado = db.CatCodigoPostal
            //				.FirstOrDefault(cp => cp.Codigo == ObjData.Empresa.Direccion.CodigoPostal)
            //					.IdEstadoCotizacion.ToString().PadLeft(2, '0');

            if (ObjData.DetalleUsuario.Direccion == null)
                ObjData.DetalleUsuario.Direccion = new LocktonModel.db.Direccion();

            string _iva = db.CatParametro.Where(w => w.Clave == "IVA").Select(s => s.Valor).FirstOrDefault();
            //Car
            CatRamoVehiculo vehiculo = db.CatRamoVehiculo.Where(x => x.Clave == ObjData.CotizacionAutoGuardar.TipoVehiculo).FirstOrDefault();
            double? CesionComision = db.Empresa.Where(x => x.Id == ObjData.Convenio.IdEmpresa).Select(s => s.CesionComision).FirstOrDefault();
            ConfiguracionEmpresa configuracionempresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == ObjData.Convenio.IdEmpresa).FirstOrDefault();
            ConvenioRamoPaquete paqueteRamoConvenio = db.ConvenioRamoPaquete
                                        .Where(x => x.IdConvenio == ObjData.Convenio.Id && x.IdCatRamoVehiculo == vehiculo.IdCatRamo)
                                            .FirstOrDefault();
            CatCaratulaPaquete _paqete = db.CatCaratulaPaquete.FirstOrDefault(a => a.IdConvenio == ObjData.Convenio.Id && a.IdTipoPaquete == idTipoPaquete && a.IdCatRamoVehiculo == vehiculo.IdCatRamo);
            var idABancoAseguradora = (from CB in db.CatBanco
                                       join CBA in db.CatBancosAseguradoras on CB.Id equals CBA.IdBanco
                                       where CBA.IdAseguradora == 10 && CB.BancoId == ObjData.IdBanco
                                       select new
                                       {
                                           CB.BancoId
                                       }).FirstOrDefault();

            var regimenFiscal = "";
            var usoCFDI = "";

            if (ObjData.IdRegimenFiscal > 0)
            {
                var _reg = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == ObjData.IdRegimenFiscal);
                regimenFiscal = $"{_reg.Clave} - {_reg.Nombre}";
            }

            if (ObjData.IdUsoCFDI > 0)
            {
                var _uso = db.CatUsoCFDI.FirstOrDefault(a => a.Id == ObjData.IdUsoCFDI);
                usoCFDI = $"{_uso.Abreviatura} - {_uso.Nombre}";
            }

            #region XML
            string tarifa = paqueteRamoConvenio.Tarifa;//datosConvenio.tarifa.ToString();
            string xml = "<soapenv:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:wsf='http://wsfacade.emisionpolizas.autos.seguros.mx.ia3.ing.com'>" +
       "<soapenv:Header/>" +
       "<soapenv:Body>" +
          "<wsf:createSolicitudPolizasInmediata soapenv:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'>" +
             "<xml xsi:type='xsd:string'><![CDATA[<Solicitud xsi:noNamespaceSchemaLocation='" + xsd + "' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>" +
       "<Poliza>" +
            "<NombreProducto>" + producto + "</NombreProducto>" +
            "<Generales>" +
                "<TipoPoliza>COLECTIVA</TipoPoliza>" +
                "<TipoMovimiento>EMISION</TipoMovimiento>" +
                "<SeriePoliza>" + Serie + "</SeriePoliza>" +
                "<TipoVigencia>" + tipoVigencia + "</TipoVigencia>" +
                "<FechaDesde>" + InicioVigencia + "</FechaDesde>" +
                "<FechaHasta>" + FinVigencia + "</FechaHasta>";
            //Definimos que valores se enviarán en las consideraciones de acuerdo al tipo de contratante
            //dynamic resTC = ca.getDatosTipoContratanteConvenio(Int32.Parse(idConvenio));
            //string tipoContratante = resTC.nombre;
            //tipoContratante = tipoContratante.Trim();
            if (configuracionempresa.IdTipoDeNegocio == 2 || configuracionempresa.IdTipoDeNegocio == 3
                || (!ObjData.EmisionPersonaMoral && configuracionempresa.IdTipoDeNegocio == 6)// negocio de tipo individual con datos de usuario
                || (!ObjData.EmisionPersonaMoral && configuracionempresa.IdTipoDeNegocio == 5))
            {
                string idestado = db.CatEstadosAXA.FirstOrDefault(x => x.Clave == ObjData.DatosUsuario.Direccion.CatCodigoPostal.IdEstadoCotizacion).Valor.ToString();
                xml += "<Titular>" +
                "<TipoPersona>FISICA</TipoPersona>" +
                "<Nombre>" + ObjData.PrimerNombre + "</Nombre>" +
                "<ApPaterno>" + ObjData.ApellidoPaterno + "</ApPaterno>" +

                "<ApMaterno>" + ObjData.ApellidoMaterno + "</ApMaterno>" +
                "<RFC>" + ObjData.DatosUsuario.RFC + "</RFC>" +
                "<Telefono>" + ObjData.TelefonoCel + "</Telefono>" +
                "<Direccion>" +
                    "<CalleNumero>" + ObjData.DatosUsuario.Direccion.Calle + " " + ObjData.DatosUsuario.Direccion.NumeroExt + "</CalleNumero>" +
                    "<Colonia>" + ObjData.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento + "</Colonia>" +
                    "<Poblacion>" + ObjData.DatosUsuario.Direccion.Municipio + "</Poblacion>" +
                    "<ClaveEstado>" + idestado + "</ClaveEstado>" +
                    "<ClavePoblacion>" + 1/*+ ObjData.DatosUsuario.Direccion.CatCodigoPostal.IdEstadoCotizacion +*/ + "</ClavePoblacion>" +
                    "<CodigoPostal>" + ObjData.DatosUsuario.Direccion.CodigoPostal + "</CodigoPostal>" +
                "</Direccion>" +
                "<Sexo>" + datosResponse.Poliza.Titular.Sexo + "</Sexo>" +
                "<Edad>" + (ObjData.Edad == 0 ? Utilidades.Utilidades.CalculaEdad(ObjData.FechaNacimiento) : ObjData.Edad) + "</Edad>" +
            "</Titular>";
            }
            else if ((configuracionempresa.IdTipoDeNegocio == 1 || configuracionempresa.IdTipoDeNegocio == 4) && ObjData.Convenio.IdCatTipoContratante == 1)//negocio tipo flotilla con datos del negocio
            {
                string idestado = db.CatEstadosAXA.FirstOrDefault(x => x.Clave == ObjData.Empresa.Direccion.CatCodigoPostal.IdEstadoCotizacion).Valor.ToString();
                xml += "<Titular>" +
                "<TipoPersona>MORAL</TipoPersona>" +
                "<Nombre>" + ObjData.Empresa.RazonSocial + "</Nombre>" +
                "<RFC>" + ObjData.Empresa.RFC + "</RFC>" +
                "<Telefono>" + ObjData.TelefonoCel + "</Telefono>" +
                "<Direccion>" +
                    "<CalleNumero>" + ObjData.Empresa.Direccion.Calle + " " + ObjData.Empresa.Direccion.NumeroExt + "</CalleNumero>" +
                    "<Colonia>" + ObjData.Empresa.Direccion.Colonia + "</Colonia>" +
                    "<Poblacion>" + ObjData.Empresa.Direccion.Municipio + "</Poblacion>" +
                    "<ClaveEstado>" + idestado + "</ClaveEstado>" +
                    "<ClavePoblacion>1</ClavePoblacion>" +
                    "<CodigoPostal>" + ObjData.Empresa.Direccion.CodigoPostal + "</CodigoPostal>" +
                "</Direccion>" +
            "</Titular>";
            }
            else if ((configuracionempresa.IdTipoDeNegocio == 1 || configuracionempresa.IdTipoDeNegocio == 4) && ObjData.Convenio.IdCatTipoContratante == 2)//negocio tipo flotilla con datos de empleado
            {
                string idestado = db.CatEstadosAXA.FirstOrDefault(x => x.Clave == ObjData.DatosUsuario.Direccion.CatCodigoPostal.IdEstadoCotizacion).Valor.ToString();
                xml += "<Titular>" +
                "<TipoPersona>FISICA</TipoPersona>" +
                "<Nombre>" + ObjData.PrimerNombre + "</Nombre>" +
                "<ApPaterno>" + ObjData.ApellidoPaterno + "</ApPaterno>" +

                "<ApMaterno>" + ObjData.ApellidoMaterno + "</ApMaterno>" +
                "<RFC>" + ObjData.DatosUsuario.RFC + "</RFC>" +
                "<Telefono>" + ObjData.TelefonoCel + "</Telefono>" +
                "<Direccion>" +
                    "<CalleNumero>" + ObjData.DatosUsuario.Direccion.Calle + " " + ObjData.DatosUsuario.Direccion.NumeroExt + "</CalleNumero>" +
                    "<Colonia>" + ObjData.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento + "</Colonia>" +
                    "<Poblacion>" + ObjData.DatosUsuario.Direccion.Municipio + "</Poblacion>" +
                    "<ClaveEstado>" + idestado + "</ClaveEstado>" +
                    "<ClavePoblacion>1</ClavePoblacion>" +
                    "<CodigoPostal>" + ObjData.DatosUsuario.Direccion.CodigoPostal + "</CodigoPostal>" +
                "</Direccion>" +
                "<Sexo>" + datosResponse.Poliza.Titular.Sexo + "</Sexo>" +
                "<Edad>" + (ObjData.Edad == 0 ? Utilidades.Utilidades.CalculaEdad(ObjData.FechaNacimiento) : ObjData.Edad) + "</Edad>" +
            "</Titular>";
            }
            else if ((configuracionempresa.IdTipoDeNegocio == 5 || configuracionempresa.IdTipoDeNegocio == 6) && ObjData.EmisionPersonaMoral)//Emitir con persona moral
            {
                string idestado = db.CatEstadosAXA.FirstOrDefault(x => x.Clave == personaMoral.Direccion.CatCodigoPostal.IdEstadoCotizacion).Valor.ToString();
                xml += "<Titular>" +
                "<TipoPersona>MORAL</TipoPersona>" +
                "<Nombre>" + personaMoral.RazonSocial + "</Nombre>" +
                "<RFC>" + personaMoral.RFC + "</RFC>" +
                "<Telefono>" + ObjData.TelefonoCel + "</Telefono>" +
                "<Direccion>" +
                    "<CalleNumero>" + personaMoral.Direccion.Calle + " " + personaMoral.Direccion.NumeroExt + numeroIntPM + "</CalleNumero>" +
                    "<Colonia>" + personaMoral.Direccion.Colonia + "</Colonia>" +
                    "<Poblacion>" + personaMoral.Direccion.Municipio + "</Poblacion>" +
                    //"<Poblacion>" + datosRequest.Poliza.Generales.Titular.Direccion.Poblacion + "</Poblacion>" +
                    "<ClaveEstado>" + idestado + "</ClaveEstado>" +
                    "<ClavePoblacion>1</ClavePoblacion>" +
                    "<CodigoPostal>" + personaMoral.Direccion.CodigoPostal + "</CodigoPostal>" +
                "</Direccion>" +
                "<Sexo>" + datosResponse.Poliza.Titular.Sexo + "</Sexo>" +
                "<Edad>" + (ObjData.Edad == 0 ? Utilidades.Utilidades.CalculaEdad(ObjData.DetalleUsuario.FECHANACIMIENTO) : ObjData.Edad) + "</Edad>" +
            "</Titular>";
            }
            if ((configuracionempresa.IdTipoDeNegocio == 2 || configuracionempresa.IdTipoDeNegocio == 3) || (!ObjData.EmisionPersonaMoral && (configuracionempresa.IdTipoDeNegocio == 5 || configuracionempresa.IdTipoDeNegocio == 6)))// negocio de tipo individual con datos de usuario
            {
                xml += "<ClienteYO>" +
                    "<Nombre>" + ObjData.DetalleUsuario.Nombre + "</Nombre>" +
                    "<ApPaterno>" + ObjData.DetalleUsuario.ApellidoPaterno + "</ApPaterno>" +
                    "<ApMaterno>" + ObjData.DetalleUsuario.ApellidoMaterno + "</ApMaterno>" +
                    "<TipoPersonaYO>FISICA</TipoPersonaYO>" +
                "</ClienteYO>";
            }
            else if ((configuracionempresa.IdTipoDeNegocio == 1 || configuracionempresa.IdTipoDeNegocio == 4) && ObjData.Convenio.IdCatTipoContratante == 1)//negocio tipo flotilla con datos del negocio
            {
                xml += "<ClienteYO>" +
                    "<Nombre>" + ObjData.Empresa.RazonSocial + "</Nombre>" +
                    "<TipoPersonaYO>MORAL</TipoPersonaYO>" +
                "</ClienteYO>";
            }
            else if ((configuracionempresa.IdTipoDeNegocio == 1 || configuracionempresa.IdTipoDeNegocio == 4) && ObjData.Convenio.IdCatTipoContratante == 2)//negocio tipo flotilla con datos de empleado
            {
                xml += "<ClienteYO>" +
                    "<Nombre>" + ObjData.DetalleUsuario.Nombre + "</Nombre>" +
                    "<ApPaterno>" + ObjData.DetalleUsuario.ApellidoPaterno + "</ApPaterno>" +
                    "<ApMaterno>" + ObjData.DetalleUsuario.ApellidoMaterno + "</ApMaterno>" +
                    "<TipoPersonaYO>FISICA</TipoPersonaYO>" +
                "</ClienteYO>";
            }
            else if ((configuracionempresa.IdTipoDeNegocio == 5 || configuracionempresa.IdTipoDeNegocio == 6) && ObjData.EmisionPersonaMoral)//Emitir con persona moral
            {
                xml += "<ClienteYO>" +
                    "<Nombre>" + personaMoral.RazonSocial + "</Nombre>" +
                    "<TipoPersonaYO>MORAL</TipoPersonaYO>" +
                "</ClienteYO>";
            }

            if (!string.IsNullOrWhiteSpace(ObjData.BeneficiarioPreferente))
            {
                xml += "<BeneficiarioPreferente>" +
                            "<Nombre>" + datosRequest.Poliza.Generales.BeneficiarioPreferente.Nombre + "</Nombre>" +
                            "<EsCancelable>" + datosRequest.Poliza.Generales.BeneficiarioPreferente.EsCancelable + "</EsCancelable>" +
                        "</BeneficiarioPreferente>";
            }
            if (!string.IsNullOrEmpty(ObjData.Convenio.Contrato))
                xml += "<Contrato>" + ObjData.Convenio.Contrato + "</Contrato>";
            xml += "<Sector>PUBLICO</Sector>" +
                              "<FormaPago>" + FormaPago + "</FormaPago>" +
                              "<Moneda>NACIONAL</Moneda>" +
                              "<IVA>" + (string.IsNullOrEmpty(_iva) ? "16" : _iva) + "</IVA>" +
                              "<TipoNegocio>NORMAL</TipoNegocio>" +
                              "<Subramo>" + ((vehiculo.Clave == 1.ToString()) ? "AUTOS" : (vehiculo.Clave == 2.ToString()) ? "CAMIONES" : "CAMIONES") + "</Subramo>" +
                              "<TipoVehiculo>" + ((vehiculo.Clave == 1.ToString()) ? "RESIDENTES" : (vehiculo.Clave == 2.ToString()) ? "PICK-UP" : "PICK-UP") + "</TipoVehiculo>" +
                              "<Agente>" + agente + "</Agente>" +
                              "<PorcentajeCesion>" + (string.IsNullOrEmpty(CesionComision.ToString()) ? "0" : CesionComision.ToString()) + "</PorcentajeCesion>" +
                              "<OTAgente>66</OTAgente>" +
                              "<ReporteTelefonico>65</ReporteTelefonico>" +
                              "<Vehiculo>" +
                                  "<Descripcion>" + datosRequest.Poliza.Generales.Vehiculo.Descripcion + "</Descripcion>" +
                                  "<Modelo>" + datosRequest.Poliza.Generales.Vehiculo.Modelo + "</Modelo>" +
                                  "" + nodoValor + "" +
                                  "<Serie>" + ObjData.Vehiculo.Serie + "</Serie>" +
                                  "<Motor>" + ObjData.Vehiculo.Motor + "</Motor>" +
                                  "<Placas>" + ObjData.Vehiculo.Placas + "</Placas>" +
                                  "<EdoPlacas>" + datosRequest.Poliza.Generales.Vehiculo.EdoPlacas + "</EdoPlacas>" +
                                  "<Ocupantes>" + datosRequest.Poliza.Generales.Vehiculo.Ocupantes + "</Ocupantes>" +
                                  "<Tonelaje>" + datosRequest.Poliza.Generales.Vehiculo.Tonelaje + "</Tonelaje>" +
                                  "<Uso>" + datosRequest.Poliza.Generales.Vehiculo.Uso + "</Uso>" +
                                  "<Servicio>" + datosRequest.Poliza.Generales.Vehiculo.Servicio + "</Servicio>" +
                                  "<Catalogo>" +
                                      "<Propio>" +
                                          "<Marca>" + datosRequest.Poliza.Generales.Vehiculo.Catalogo.Propio.Marca + "</Marca>" +
                                          "<Tipo>" + datosRequest.Poliza.Generales.Vehiculo.Catalogo.Propio.Tipo + "</Tipo>" +
                                          "<Clase>" + datosRequest.Poliza.Generales.Vehiculo.Catalogo.Propio.Clase + "</Clase>" +
                                      "</Propio>" +
                                  "</Catalogo>" +
                              "</Vehiculo>" +
                              "<PorcentajeValor>" + porcentajeValor + "</PorcentajeValor>" +
                              "<EsValorComercial>" + esValorComercial + "</EsValorComercial>" +
                              "<CondicionesEmision>" +
                                  "<Tarifa>" + tarifa + @"</Tarifa>" +
                                  "<DescuentoPorVolumen>" + paqueteRamoConvenio.Descuento.ToString("n2") + "</DescuentoPorVolumen>" +//TODO Descuento
                                  "<PorcentajeCoaseguro>0</PorcentajeCoaseguro>" +
                                  "<Afianzadora>AUSA</Afianzadora>" +
                                  "<Servidora>AXA 2005</Servidora>" +
                                  "<ProrratearDerechos>" + (datosConvenio.DerechosPrimerRecibo ? "NO" : "SI") + "</ProrratearDerechos>" +
                                 "<Paquete>" + _paqete.Clave + "</Paquete>" +//"<Paquete>" + getNombrePaqueteAxa(ObjData.Paquete, Int32.Parse(idConvenio)) + @"</Paquete>" +
                              "</CondicionesEmision>" +
                          "</Generales>";
            if (!string.IsNullOrEmpty(ObjData.ApellidoPaterno))
            {
                xml += "<ConductorHabitual>" +
                             "<Nombre>" + ObjData.ObtieneNombres() + "</Nombre>" +
                             "<ApPaterno>" + ObjData.ApellidoPaterno + "</ApPaterno>" +
                             "<ApMaterno>" + ObjData.ApellidoMaterno + "</ApMaterno>" +
                             "<Sexo>" + datosResponse.Poliza.Titular.Sexo + "</Sexo>" +
                             "<Edad>" + (ObjData.Edad == 0 ? Utilidades.Utilidades.CalculaEdad(ObjData.FechaNacimiento) : ObjData.Edad) + "</Edad>" +
                             //"<Ocupacion>Empleado</Ocupacion>" +
                             //"<CalleNumero>" + ObjData.DatosUsuario.Direccion.Calle + " " + ObjData.DatosUsuario.Direccion.NumeroExt + "</CalleNumero>" +
                             //"<Colonia>" + ObjData.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento + "</Colonia>" +
                             //"<Poblacion>" + ObjData.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento + "</Poblacion>" +
                             //"<ClaveEstado>" + estado + "</ClaveEstado>" +
                             //"<ClavePoblacion>" + idPoblacion + "</ClavePoblacion>" +
                             "<CodigoPostal>" + ObjData.DatosUsuario.Direccion.CodigoPostal + "</CodigoPostal>" +
                         //"<Amparar>NO</Amparar>" +
                         "</ConductorHabitual>";
            }
            else
            {
                xml += "<ConductorHabitual>" +
                             "<Nombre>" + ObjData.DetalleUsuario.ObtieneNombreCompleto() + "</Nombre>" +
                             "<ApPaterno>" + ObjData.DetalleUsuario.ApellidoPaterno + "</ApPaterno>" +
                             "<ApMaterno>" + ObjData.DetalleUsuario.ApellidoMaterno + "</ApMaterno>" +
                             "<Sexo>" + datosResponse.Poliza.Titular.Sexo + "</Sexo>" +
                             "<Edad>" + (Utilidades.Utilidades.CalculaEdad(ObjData.DetalleUsuario.FECHANACIMIENTO)) + "</Edad>" +
                             //"<Ocupacion>Empleado</Ocupacion>" +
                             //"<CalleNumero>" + ObjData.DatosUsuario.Direccion.Calle + " " + ObjData.DatosUsuario.Direccion.NumeroExt + "</CalleNumero>" +
                             //"<Colonia>" + ObjData.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento + "</Colonia>" +
                             //"<Poblacion>" + ObjData.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento + "</Poblacion>" +
                             //"<ClaveEstado>" + estado + "</ClaveEstado>" +
                             //"<ClavePoblacion>" + idPoblacion + "</ClavePoblacion>" +
                             "<CodigoPostal>" + ObjData.DatosUsuario.Direccion.CodigoPostal + "</CodigoPostal>" +
                         //"<Amparar>NO</Amparar>" +
                         "</ConductorHabitual>";
            }

            if (ConfigurationManager.AppSettings["TipoConexion"].Equals("1") ? false : true)
            {
                xml += "<PagoElectronico>" +
                         "<RenovacionAutomatica>NO</RenovacionAutomatica>" +
                         "<TipoNegocioTC>AUTOS</TipoNegocioTC>" +
                         "<NombreTitular>" + nomTarjeta + "</NombreTitular>" +
                         "<PaternoTitular>" + appTarjeta + "</PaternoTitular>" +
                         "<MaternoTitular>" + apmTarjeta + "</MaternoTitular>" +
                         "<Tarjetas>" +
                           "<Tarjeta>";
                if (ObjData.CotizacionAutoGuardar.MediodePago == 0)
                {
                    xml += "<Credito>" +
                    "<Numero>" + tokenTarjeta + "</Numero>" +
                "</Credito>";
                }
                else if (ObjData.CotizacionAutoGuardar.MediodePago == 1)
                {
                    xml += "<Debito>" +
                               "<Cuenta>" + ObjData.Tarjeta.ClaveInterbancaria + "</Cuenta>" +
                               "<ClaveBanco>" + idABancoAseguradora.BancoId + "</ClaveBanco>" +
                               "<Plaza>0</Plaza>" +
                               "<Sucursal>0</Sucursal>" +
                           "</Debito>";
                }
                xml += "</Tarjeta>" +
               "</Tarjetas>" +
           "</PagoElectronico>";
            }

            xml += "<Facturacion>" +
                "<Facturar>" + (ObjData.RequiereFactura ? "SI" : "NO") + "</Facturar>" +
                "<RegimenFiscal>" + (ObjData.RequiereFactura ? regimenFiscal : "") + "</RegimenFiscal>" +
                "<usoCFDI>" + (ObjData.RequiereFactura ? usoCFDI : "") + "</usoCFDI>" +
                "</Facturacion>";

            xml += "</Poliza>" +
                  "</Solicitud>]]></xml>" +
               "</wsf:createSolicitudPolizasInmediata>" +
             "</soapenv:Body>" +
            "</soapenv:Envelope>";

            #endregion XML
            soapEnvelop.LoadXml(xml);


            return soapEnvelop;
        }

        public static TokenValidationResponse TokenValidation(string tkn, TokenValidationRequest ccrequest)
        {
            TokenValidationResponse resp = new TokenValidationResponse();
            try
            {
                bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;

                var url = EsProduccion ? Utilidades.Utilidades.ObtienerValorParametro("AXAValidaTokenProd") : Utilidades.Utilidades.ObtienerValorParametro("AXAValidaTokenQA");
                //@"https://www.serviciosaxa.mx/axaPgWeb/v1/mit/api/validaToken";

                JavaScriptSerializer serializador = new JavaScriptSerializer();
                RestClient client = new RestSharp.RestClient(url);
                RestRequest request = new RestSharp.RestRequest(Method.POST);
                client.AddDefaultHeader("Authorization", "Bearer " + tkn);
                request.AddHeader("Accept", "application/json");
                request.AddHeader("Content-Type", "application/json");
                string jsonReqst = serializador.Serialize(ccrequest);
                request.AddJsonBody(ccrequest);

                RestSharp.IRestResponse response = client.Execute(request);
                string content = response.Content; // raw content as string

                resp = serializador.Deserialize<TokenValidationResponse>(content);

                log.Info($"TokenValidation REQUEST {jsonReqst}");
                log.Info($"TokenValidation RESPONSE {content}");
            }
            catch (Exception)
            { }

            return resp;
        }

        public string GeneraTokenAXA(string usuario, string password )
        {
            TokenOauthRequest tkn = new TokenOauthRequest();
            TokenRequest tokenTar = new TokenRequest();
            string varUrlrOauth, varUsrOauth, varPswOauth, varUrlTokeniza = string.Empty;

            tkn.claims.scope = "/pci/tokenizaTarjeta";
            tkn.config.expiresIn = 300;

            //CredentialCache myCache = new CredentialCache();
            if (ConfigurationManager.AppSettings["TipoConexion"].Equals("1") ? false : true)
            {
                varUrlrOauth = "oauthTokenProd";//Prod 
                //varUsrOauth = "usrOauthAXAProd";
                //varPswOauth = "pswOauthAXAProd";
                varUrlTokeniza = "TokenizaProd";

            }
            else
            {
                varUrlrOauth = "oauthTokenTest";//QA
                //varUsrOauth = "usrOauthAXATest";
                //varPswOauth = "pswOauthAXATest";
                varUrlTokeniza = "TokenizaTest";
            }

            varUrlrOauth = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varUrlrOauth);
            varUsrOauth = usuario;//LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varUsrOauth);
            varPswOauth = password;//LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varPswOauth);
            varUrlTokeniza = LocktonServicios.Utilidades.Utilidades.ObtienerValorParametro(varUrlTokeniza);

            string tokenBearer = LocktonServicios.Utilidades.Utilidades.GetToken(varUrlrOauth, varUsrOauth, varPswOauth, tkn);

            return tokenBearer;
        }

        public List<Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete)
        {
            //List<SolicitudCoberturasCobertura> coberturas = new List<SolicitudCoberturasCobertura>();

            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio && a.IdCatTipoPaquete == idPaquete
                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible / 100).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", "")
                                           }).ToList();
            return coberturas;
        }


        public string ReimprimePolizaAXAPool(string NumeroPoliza, string user, string password)
        {
            log.Info("ReimprimePolizaAXAPool Reimprimir Poliza " + NumeroPoliza);
            string rutaGuardadoPDFTemp = string.Empty;
            CredentialCache myCache = new CredentialCache();
            string _url = GetUrlDevelopmentEnviroment();
            XmlDocument docImp = new XmlDocument();
            string RutaDescargaPDFsPolizas = HttpContext.Current.Server.MapPath("~/Repositorio/Documentos/");
            string directorio = string.Format(@"{0}\{1}", RutaDescargaPDFsPolizas, "AXA");
            rutaGuardadoPDFTemp = string.Concat(directorio, @"\", NumeroPoliza, ".pdf");
            if (!Directory.Exists(directorio))
            {
                Directory.CreateDirectory(directorio);
            }
            if (!File.Exists(rutaGuardadoPDFTemp))
            {
                log.Info("póliza no existe en el repositorio consulta al servidor de AXA pool póliza " + NumeroPoliza);
                for (int i = 0; i <= 3; i++)
                {
                    try
                    {
                        //myCache.Add(new Uri(_url), "Basic", new NetworkCredential(user, password));
                        XmlDocument soapEnvelopeXmlImp = CreateSoapEnvelopeImpresion(NumeroPoliza);
                        log.Info("ReimprimePolizaAXAPool xml Envío AXA Pool Reimpresion: " + NumeroPoliza);
                        var service = new CotizacionEmisionAXAService.SolicitudPolizasWSFacadeClient();
                        service.ClientCredentials.UserName.UserName = user;
                        service.ClientCredentials.UserName.Password = password;

                        dynamic soapResultImp;
                        soapResultImp = service.getPDFPoliza(NumeroPoliza);
                        //HttpWebRequest webRequest4 = CreateWebRequest(_url, "");
                        //webRequest4.Headers.Add("SOAPAction", "");
                        //webRequest4.PreAuthenticate = true;
                        //webRequest4.Credentials = myCache;
                        //webRequest4.Timeout = 100000;
                        //InsertSoapEnvelopeIntoWebRequest(soapEnvelopeXmlImp, webRequest4);

                        //IAsyncResult asyncResult4 = webRequest4.BeginGetResponse(null, null);
                        //asyncResult4.AsyncWaitHandle.WaitOne();


                        //using (WebResponse webResponse = webRequest4.EndGetResponse(asyncResult4))
                        //{
                        //    using (StreamReader rd = new StreamReader(webResponse.GetResponseStream()))
                        //    {
                        //        soapResultImp = rd.ReadToEnd();
                        //    }

                        //docImp.LoadXml(nn);

                        //    //Global.LOG += "Proceso Finalizado Emisión, Impresion <br>";
                        File.WriteAllBytes(rutaGuardadoPDFTemp, soapResultImp);
                        break;
                        //}


                    }
                    catch (Exception ex)
                    {
                        log.Info("ReimprimePolizaAXAPool se presentó un error: " + (ex.InnerException != null ? ex.InnerException.Message.ToString() : ex.Message.ToString()));
                        //Guardado Error general
                        //ca.guardadoLogEmision("", "", urlSitio, "", "", ex.ToString(), 5, nombreCompletoLog, ObjData.Cliente.Direccion.CodPostal, ObjData.Aseguradora, ObjData.IDLog);
                        //ObjData.Cotizacion.Resultado = ex.ToString();
                        //ObjData.CodigoError = ex.ToString();
                    }
                }
                //XmlNodeList colElementosImp = docImp.GetElementsByTagName("soapenv:Envelope");
                //XmlNodeList colElementosImp2 = docImp.GetElementsByTagName("soapenv:Body");
                //XmlNodeList colElementosImp3 = docImp.GetElementsByTagName("ns1:getPDFPolizaResponse");
                //XmlNodeList colElementosImp4 = docImp.GetElementsByTagName("faultstring");
                //if (colElementosImp4.Count > 0)
                //    log.Info("Error servicio AXA Pool al intentar reimprimir la póliza " + NumeroPoliza + ", Error " + colElementosImp4[0].InnerText);
                //string documento = string.Empty;
                //foreach (XmlNode objNodoPaquete in colElementosImp)
                //{
                //    foreach (XmlNode objNodoPaquete1 in colElementosImp2)
                //    {
                //        foreach (XmlNode objNodoPaquete2 in colElementosImp3)
                //        {
                //            log.Info("ReimprimePolizaAXAPool el servicio regresó correctamenta la póliza encryptada");

                //            byte[] arraybyte = Convert.FromBase64String(objNodoPaquete2["getPDFPolizaReturn"].InnerText);

                //           

                //        }
                //    }

                //}

            }

            return rutaGuardadoPDFTemp;

        }

        private static XmlDocument CreateSoapEnvelopeImpresion(string poliza)
        {
            XmlDocument soapEnvelop = new XmlDocument();
            soapEnvelop.LoadXml("<soapenv:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:wsf='http://wsfacade.emisionpolizas.autos.seguros.mx.ia3.ing.com'><soapenv:Header/><soapenv:Body><wsf:getPDFPoliza soapenv:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'><poliza xsi:type='xsd:string'>" + poliza + "</poliza></wsf:getPDFPoliza></soapenv:Body></soapenv:Envelope>");
            return soapEnvelop;
        }
        private catalogo BusquedaAutoBOGO(string marca, string año, string modelo, string descripcion)
        {
            ResultadoBuscar _homologadoBogo = new ConsultaHomologacion("LocktonOne", "LocktonOne2017").BusquedaBOGO(marca, año, modelo, "", descripcion);
            catalogo _axaBogo = _homologadoBogo.Catalogo.Where(a => a.Aseguradora == "AXA").FirstOrDefault();
            return _axaBogo;
        }

        public static string[] getMarcaTipoVehiculo(string amis)
        {
            string[] datosVehiculo = new string[2];
            int sizeAmis = amis.Length;
            try
            {
                switch (sizeAmis)
                {
                    case 1:
                    case 2:
                        datosVehiculo[0] = "0";//Marca
                        datosVehiculo[1] = amis;//Tipo
                        break;
                    case 3:
                        datosVehiculo[0] = amis.Substring(0, 1);
                        datosVehiculo[1] = amis.Substring(1, 2);
                        break;
                    case 4:
                        datosVehiculo[0] = amis.Substring(0, 2);
                        datosVehiculo[1] = amis.Substring(2, 2);
                        break;
                    case 5:
                        datosVehiculo[0] = amis.Substring(0, 3);
                        datosVehiculo[1] = amis.Substring(3, 2);
                        break;
                }
            }
            catch (Exception)
            {

            }
            return datosVehiculo;
        }

        private int getPorcentajeValor(int idConvenio, int idTipoPaquete)
        {
            int porcentajeValor = 100;
            List<Coberturas> coberturas = new GNPService().ObtenerCoberturas(idConvenio, idTipoPaquete);
            foreach (Coberturas cobertura in coberturas)
            {
                if (cobertura.Nombre.ToUpper() == "DAÑOS MATERIALES" || cobertura.Nombre.ToUpper() == "ROBO TOTAL")
                {
                    if ((cobertura.Cobertura == "VALOR COMERCIAL + 10%" || cobertura.Cobertura == "VALOR COMERCIAL 10%") /* modificado 26/11/2024 && (idTipoPaquete == 1 || idTipoPaquete == 3 || idTipoPaquete == 2)*/)
                        porcentajeValor = 110;
                }
            }
            return porcentajeValor;
        }

        private NodeEmision LeerXMLResponse(XmlDocument xmlResponse)
        {
            string idCotizacion = string.Empty;
            NodeEmision response;
            XmlDocument xmlResponceResponse = new XmlDocument();

            //xmlRequestResponse.LoadXml(requestResponse);
            xmlResponceResponse.LoadXml(xmlResponse.InnerXml);

            //Validate xml nodes
            if (xmlResponceResponse.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                xmlResponceResponse.RemoveChild(xmlResponceResponse.FirstChild);

            using (TextReader sr = new StringReader(xmlResponceResponse.InnerXml))
            {
                XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(NodeEmision));
                response = (NodeEmision)serializer.Deserialize(sr);
            }

            return response;
        }

        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision, Convenio convenioCotiza)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("dd/MM/yyyy");
                var documentRequest = new XmlDocument();
                string result = "";

                documentRequest.LoadXml(xmlEmision);

                var cotizacion = LeerXMLRequest(documentRequest);

                cotizacion.Poliza.Generales.FechaDesde = date;

                //Start the serialization of NodeSolicitud class.
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(NodeSolicitud));
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;

                //Serialize xml information
                using (Utf8StringWriter stringWriter = new Utf8StringWriter())
                {
                    using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
                    {
                        xmlSerializer.Serialize(xmlWriter, cotizacion);
                    }

                    result = stringWriter.ToString();
                }
                //Build xml document with headers 
                var xmlBody = @"<soapenv:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' 
                                        xmlns:xsd='http://www.w3.org/2001/XMLSchema' 
                                                xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/'
                                                        xmlns:wsf='http://wsfacade.emisionpolizas.autos.seguros.mx.ia3.ing.com'>
                            <soapenv:Header/>
                                <soapenv:Body>
                                    <wsf:createSolicitudPolizasInmediata 
                                        soapenv:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'>
                                            <xml xsi:type='xsd:string'><![CDATA[" + result + @"]]></xml>
                                    </wsf:createSolicitudPolizasInmediata>
                                </soapenv:Body>
                           </soapenv:Envelope>";

                XmlDocument XmlCarQuoteRequestAXA = new XmlDocument();
                //Load information into a xml format
                XmlCarQuoteRequestAXA.LoadXml(xmlBody);

                CredentialCache myCache = new CredentialCache();
                string _url = GetUrlDevelopmentEnviroment();
                string carQuoteResponse = string.Empty;
                XmlDocument xmlCarQuoteResponse = new XmlDocument();

                var service = new CotizacionEmisionAXAService.SolicitudPolizasWSFacadeClient();
                service.ClientCredentials.UserName.UserName = convenioCotiza.Usuario;
                service.ClientCredentials.UserName.Password = convenioCotiza.Contrasena;

                carQuoteResponse = service.createSolicitudPolizasInmediata(XmlCarQuoteRequestAXA.InnerText);

                //myCache.Add(new Uri(_url), "Basic", new NetworkCredential(convenioCotiza.Usuario, convenioCotiza.Contrasena));


                ////Create a web request with user credentials.
                //HttpWebRequest webRequest = CreateWebRequest(_url, "");
                //webRequest.Headers.Add("SOAPAction", "");
                //webRequest.PreAuthenticate = true;
                //webRequest.Timeout = 100000;
                //webRequest.Credentials = myCache;/*GetClientCredentials(user, password);*/
                ////Save xml document inside a web request.
                //InsertSoapEnvelopeIntoWebRequest(XmlCarQuoteRequestAXA, webRequest);

                ////Start a new async operation for the web request.
                ////IAsyncResult asyncStateRequest = webRequest.BeginGetResponse(FinishWebRequest, webRequest);
                //IAsyncResult asyncStateRequest = webRequest.BeginGetResponse(null, null);
                //asyncStateRequest.AsyncWaitHandle.WaitOne();

                ////Record when start to create response of car quote.
                //log.Info($"Start create xml response");
                ////Get response of car quote from web service AXA

                //using (WebResponse webResponse = webRequest.EndGetResponse(asyncStateRequest))
                //{
                //    using (StreamReader sr = new StreamReader(webResponse.GetResponseStream()))
                //    {
                //        carQuoteResponse = sr.ReadToEnd();
                //    }
                //}

                //Load car quote response data from web service AXA into a xml format.

                xmlCarQuoteResponse.LoadXml(carQuoteResponse);

                resultado.XMLSolicitud = XmlCarQuoteRequestAXA.InnerXml;
                resultado.XMLRecepcion = xmlCarQuoteResponse.InnerXml;

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        private NodeSolicitud LeerXMLRequest(XmlDocument xmlRequest)
        {
            NodeSolicitud response;
            XmlDocument xmlRequestResponse = new XmlDocument();

            //xmlRequestResponse.LoadXml(requestResponse);
            xmlRequestResponse.LoadXml(xmlRequest.InnerText);

            //Validate xml nodes
            if (xmlRequestResponse.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                xmlRequestResponse.RemoveChild(xmlRequestResponse.FirstChild);

            using (TextReader sr = new StringReader(xmlRequestResponse.InnerXml))
            {
                XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(NodeSolicitud));
                response = (NodeSolicitud)serializer.Deserialize(sr);
            }

            return response;
        }

        #endregion

        #region: Helpers

        /// <summary>
        /// Method to encoding a string in UTF-8.
        /// </summary>
        public class Utf8StringWriter : StringWriter
        {
            public override Encoding Encoding
            {
                get
                {
                    return Encoding.UTF8;
                }
            }
        }

        #endregion

        private void FinishWebRequest(IAsyncResult result)
        {
            HttpWebResponse response = (result.AsyncState as HttpWebRequest).EndGetResponse(result) as HttpWebResponse;
        }



        private DatosVehiculoAXA ObtenerDatosVehiculo(string clave, string aseguradora)
        {
            DatosVehiculoAXA result = new DatosVehiculoAXA();
            var sp = $"spConsulta{aseguradora}";

            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["CatalogoHomologado"].ToString()))
            {
                using (SqlCommand cmd = new SqlCommand(sp, connection))
                {
                    SqlParameter amis = new SqlParameter("@IdAXA", clave);

                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(amis);
                    connection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            result.IdClase = Convert.ToString(dr["IdClase"]);
                        }
                    }

                    connection.Close();
                }
            }

            return result;
        }


        private object Tokenizar(string varUrlTokeniza, string tokenBearer, TokenRequest tokenTar)
        {
            throw new NotImplementedException();
        }
        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }
        private static string Serialize(object dataToSerialize)
        {
            if (dataToSerialize == null) return null;

            using (StringWriter stringwriter = new System.IO.StringWriter())
            {
                var serializer = new XmlSerializer(dataToSerialize.GetType());
                serializer.Serialize(stringwriter, dataToSerialize);
                return stringwriter.ToString();
            }
        }

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public LocktonModel.db.Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public LocktonModel.db.Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
    }
    public class DatosVehiculoAXA
    {
        public string IdClase { get; set; }
    }
}

