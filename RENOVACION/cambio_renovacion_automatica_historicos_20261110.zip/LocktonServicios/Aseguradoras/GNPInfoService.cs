﻿using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.VModels;
using LocktonModel.xmls.AXA;
using LocktonOne.Proxy.GNP.Cancelaciones;
using LocktonOne.Proxy.GNP.Cancelaciones.Models.Request;
using LocktonOne.Proxy.GNP.Domiciliacion.Models.Request;
using LocktonServicios.Aseguradoras.GNP;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.Catalogos;
using LocktonServicios.GNPInfoServiceCotizarEmitir;
using LocktonServicios.GNPInfoServiceImpresion;
using LocktonServicios.Utilidades;
using LocktonServicios.XMLEntity.Cotizacion.GNPPreferente.Solicitudes;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Policy;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Serialization;
using Poliza = LocktonModel.db.Poliza;
using Recibo = LocktonModel.db.Recibo;

namespace LocktonServicios.Aseguradoras
{
    public class GNPInfoService : IGNPService
    {
        #region Properties

        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger(typeof(GNPInfoService));

        #endregion

        #region Functional Methods

        public EstatusCotizacion CotizaEmiteSolicitudAprobada(string xmlEmision)
        {
            try
            {
                var resultado = new EstatusCotizacion();
                var date = DateTime.Now.ToString("dd/MM/yyyy");

                RequestCotizacionAutos solicitud = GetXmlFromString<RequestCotizacionAutos>(xmlEmision);

                solicitud.fechaInicioVigencia = date;

                //Enviar petición de cotización 
                string xmlSolicitud = Utilidades.Utilidades.GetStringFromXML(solicitud);
                var response = EnviaSolicitudCotizacion(solicitud);

                //Recupera el xml de respuesta de cotización
                XmlDocument node = new XmlDocument();
                node.LoadXml(Utilidades.Utilidades.GetStringFromXML(response.response));
                XmlNode node2 = node.FirstChild;

                if (response.response == null && response.error != null)
                {
                    throw new Exception(response.error);
                }

                //Set de datos para el comparativo y guardado en db de la cotización
                resultado.XMLSolicitud = xmlSolicitud;
                resultado.XMLRecepcion = node2.OuterXml;

                //Obtiene el resultado de cotización y construye el objeto que se regresa con la info obtenida
                if (node.Name == "Errores")
                {
                    throw new Exception(node2.OuterXml);
                }

                return resultado;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {
            try
            {
                cotizarPolizaRequest cotRequest = new cotizarPolizaRequest();
                RequestCotizacionAutos reqCotAutos = new RequestCotizacionAutos();
                Comparar infoCompara = new Comparar();

                //Obtener datos de la db
                Convenio convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
                ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == convenioCotiza.IdEmpresa).FirstOrDefault();
                var empresa = db.Empresa.FirstOrDefault(a => a.Id == convenioCotiza.IdEmpresa);
                List<Coberturas> coberturasPaquete = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, string.IsNullOrEmpty(CotizacionCompara.TipoVehiculo) ? 1 : Convert.ToInt32(CotizacionCompara.TipoVehiculo), idPaqueteConvenio);
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                int idFormaPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString()).Id;
                PeriodicidadFormaPago periodicidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioId && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
                descripciones _cotDesAuto = cot.Catalogo.FirstOrDefault().CatDescripciones.FirstOrDefault();
                var convenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(x => x.IdConvenio == convenioId && x.IdCatRamoVehiculo == paqueteConvenio.IdCatRamoVehiculo);

                string InicioVigencia = CotizacionCompara.FechaInicio.ToString("dd/MM/yyyy");
                string FinVigencia = CotizacionCompara.FechaFin.ToString("dd/MM/yyyy");
                string prefijo = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("PrefijoGNPInfo")).Valor;

                var perioricidad = db.CatPeriodicidadFormaPago.Where(x => x.Id == CotizacionCompara.FormadePago).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == perioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);


                infoCompara.FechaCotizacion = CotizacionCompara.FechaInicio;

                // Datos principales para cotizar 
                reqCotAutos.usuario = convenioCotiza.Usuario;
                reqCotAutos.password = convenioCotiza.Contrasena;
                reqCotAutos.intermediario = convenioCotiza.CodigoIntermediario;
                reqCotAutos.contratante = new GNPInfoServiceCotizarEmitir.Contratante();
                reqCotAutos.representanteLegal = new GNPInfoServiceCotizarEmitir.RepresentanteLegal();
                reqCotAutos.elementosAdicionales = new List<ElementoAdicional>().ToArray();
                reqCotAutos.codigoCEC = "";

                //Verifica si hay que modificar la fecha de inicio dependiendo del enrollment
                //if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(convenioCotiza.IdEmpresa, DateTime.Now))
                //{
                //    InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion.ToString("dd/MM/yyyy") : DateTime.Now.ToString("dd/MM/yyyy");
                //    infoCompara.FechaCotizacion = ConfigEmpresa.AplicaFechaCotizacion ? CotizacionCompara.FechaCotizacion : DateTime.Now;
                //}

                //Set de inicio y fin de vigencia en el objeto de cotización
                reqCotAutos.fechaInicioVigencia = DateTime.Parse(InicioVigencia).ToString("yyyyMMdd");
                reqCotAutos.fechaFinVigencia = DateTime.Parse(FinVigencia).ToString("yyyyMMdd");
                reqCotAutos.formaPago = periodicidad.FormaPago;// ObtenerFormaPago(periodicidad);

                //Valida si seleccionó vehiculo disponible
                int? idVehiculoDisponible = null;
                bool checkActivo = convenioCotiza.CHKCARTYPE == "1";

                if (checkActivo) 
                { 
                    idVehiculoDisponible = CotizacionCompara.ValorFactura
                        ? 1  //"Nuevo"
                        : 2; //"Seminuevo" 
                }


                //Obtiene caratula
                string caratula = ObtieneCaratulaPorSP(convenioId, IdTipoPaquete, CotizacionCompara.FormadePago, idFormaPago, CotizacionCompara.Año, ObtieneIdRamoVehiculo(Convert.ToInt32(CotizacionCompara.TipoVehiculo)), idVehiculoDisponible);
                reqCotAutos.numeroCaratula = !string.IsNullOrEmpty(caratula) ? caratula : convenioCotiza.CaratulaPoliza;

                //Se obtienen coberturas haciendo match con el Id de cobertura
                CoberturaIn[] listaCoberturas = ObtieneClavesCoberturas(coberturasPaquete, convenioCotiza.Id, CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);

                //Set de Coberturas en el paquete seleccionado; Set de paquete en objeto de cotización
                var clavePaquete = string.Concat(prefijo, paqueteConvenio.IdPlan != null ? paqueteConvenio.IdPlan.Value.ToString() : db.PaqueteAseguradora.FirstOrDefault(pa => pa.IdCatTipoPaquete == IdTipoPaquete && pa.IdAseguradora == convenioCotiza.IdAseguradora).Clave);
                List<PaqueteIn> requestPaquetes = new List<PaqueteIn>();
                requestPaquetes.Add(
                    new PaqueteIn()
                    {
                        clavePaquete = clavePaquete,
                        coberturas = listaCoberturas,
                        coberturasOpcionales = null
                    });
                reqCotAutos.paquetes = requestPaquetes.ToArray();

                //Consulta de catálogo homologado 
                _Descripciones _resultado = ConsultaCatalogoHomologado(_cotDesAuto.clave);
                string CodigoPostal1 = CotizacionCompara.CodigoPostal;
                if (convenioCotiza.ZonaCirculacion == 2 && convenioCotiza.CodigoPostal > 0)
                    CodigoPostal1 = convenioCotiza.CodigoPostal.ToString().PadLeft(5, '0');
                //Set de objeto vehículo consultando el catálogo homologado
                if (CotizacionCompara.TipoVehiculo.Equals("1"))
                {
                    GNPInfoServiceCotizarEmitir.Vehiculo requestVehiculo =
                        ConstruyeObjetoVehiculoCotizacion(_resultado, _cotDesAuto, CotizacionCompara.Año, CodigoPostal1, ConveniosPaquetes.Empresa.Direccion.CodigoPostal, CotizacionCompara.ValorFactura, CotizacionCompara.MontoFactura.ToString(), paqueteConvenio.AplicaValorConvenido, false, false);               
                    reqCotAutos.vehiculo = requestVehiculo;
                }
                if (CotizacionCompara.TipoVehiculo.Equals("2"))
                {
                    GNPInfoServiceCotizarEmitir.Vehiculo requestVehiculo =
                        ConstruyeObjetoVehiculoCotizacion(_resultado, _cotDesAuto, CotizacionCompara.Año, CodigoPostal1, ConveniosPaquetes.Empresa.Direccion.CodigoPostal, CotizacionCompara.ValorFactura, CotizacionCompara.MontoFactura.ToString(), paqueteConvenio.AplicaValorConvenido, false, true);
                    reqCotAutos.vehiculo = requestVehiculo;
                }
                if (CotizacionCompara.TipoVehiculo.Equals("3"))
                {
                    if (CotizacionCompara.ValorFactura)
                    {
                        GNPInfoServiceCotizarEmitir.Vehiculo requestVehiculo =
                            ConstruyeObjetoVehiculoCotizacion(_resultado, _cotDesAuto, CotizacionCompara.Año, CodigoPostal1, ConveniosPaquetes.Empresa.Direccion.CodigoPostal, CotizacionCompara.ValorFactura, CotizacionCompara.MontoFactura.ToString(), false, true, false);
                        reqCotAutos.vehiculo = requestVehiculo;
                    }
                    else
                    {
                        GNPInfoServiceCotizarEmitir.Vehiculo requestVehiculo =
                        ConstruyeObjetoVehiculoCotizacion(_resultado, _cotDesAuto, CotizacionCompara.Año, CodigoPostal1, ConveniosPaquetes.Empresa.Direccion.CodigoPostal, CotizacionCompara.ValorFactura, CotizacionCompara.MontoDeclarado.ToString(), false, true, false);
                        reqCotAutos.vehiculo = requestVehiculo;
                    }

                }

                if (!string.IsNullOrEmpty(convenioRamoPaquete.TipoCarga))
                    reqCotAutos.vehiculo.tipoCarga = convenioRamoPaquete.TipoCarga;

                if (CotizacionCompara.IdUso > 0)
                {
                    var uso = db.CatUsos.FirstOrDefault(a => a.Id == CotizacionCompara.IdUso);
                    reqCotAutos.vehiculo.usoVehiculo = uso.ClaveGNP;

                    if (CotizacionCompara.TipoVehiculo.Equals("2"))
                    {
                        var _elementosAdicionales = new List<ElementoAdicional>();
                        _elementosAdicionales.Add(new ElementoAdicional()
                        {
                            elemento = "INCARPRO",
                            valor = "S"
                        });

                        _elementosAdicionales.Add(new ElementoAdicional()
                        {
                            elemento = "CDGIRAUT",
                            valor = "01"
                        });

                        reqCotAutos.elementosAdicionales = _elementosAdicionales.ToArray();
                    }
                }
                if (CotizacionCompara.EsFlotilla)
                    reqCotAutos.contratante = ConstruyeObjetoContratante(empresa, CotizacionCompara, CodigoPostal1, convenioCotiza.CodigoCliente, true);
                else
                    reqCotAutos.contratante = ConstruyeObjetoContratante(empresa, CotizacionCompara, CodigoPostal1, convenioCotiza.CodigoCliente, false);


                //Set de Conductor 
                Conductor requestConductor = ConstruyeObjetoConductorCotizacion(detalleUsuario, CotizacionCompara.Genero);
                reqCotAutos.conductor = requestConductor;
                //Enviar petición de cotización 
                var cml = Utilidades.ObjectSerializer<RequestCotizacionAutos>.Serialize(reqCotAutos);
                string solicitud = Utilidades.Utilidades.GetStringFromXML(reqCotAutos);
                log.Info(string.Format("GNP Xml Cotizacion Solicitud: {0}", solicitud));

                var response = EnviaSolicitudCotizacion(reqCotAutos);

                //Recupera el xml de respuesta de cotización
                XmlDocument node = new XmlDocument();
                node.LoadXml(Utilidades.Utilidades.GetStringFromXML(response.response));
                XmlNode node2 = node.FirstChild;

                infoCompara.XmlEmision = solicitud;
                infoCompara.XmlRespuesta = node2.OuterXml;

                if (response.response == null && response.error != null)
                {
                    infoCompara.ErrorXML = response.error;
                    log.Error("cotizaVehiculo error GNP " + response.error);
                    log.Info(string.Format("GNP Xml Cotizacion Respuesta: {0}", response.error));
                    infoCompara.XmlRespuesta = response.error;
                    CotizacionCompara.Comparar.Add(infoCompara);
                    return CotizacionCompara;
                }

                //Set de datos para el comparativo y guardado en db de la cotización

                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.Aseguradora = "GNP";
                infoCompara.Año = CotizacionCompara.Año;
                infoCompara.FechaInicio = InicioVigencia;
                infoCompara.FechaFin = FinVigencia;
                infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
                infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;

                log.Info(string.Format("GNP Xml Cotizacion Respuesta: {0}", node2.OuterXml));

                //Obtiene el resultado de cotización y construye el objeto que se regresa con la info obtenida
                if (node.Name == "Errores")
                {
                    infoCompara.ErrorXML = node2.OuterXml;
                    log.Error("cotizaVehiculo error GNP " + node2.OuterXml);
                }
                else
                {
                    ResponseCotizacionAutos movimientoResult = GetXmlFromString<ResponseCotizacionAutos>(node2.OuterXml);

                    infoCompara.CotizacionClave = "";

                    foreach (var paquete in movimientoResult.paquetes)
                    {

                        infoCompara.Coberturas = ObtieneCoberturasCotizadas(paquete.coberturas.Concat(paquete.coberturasOpcionales).ToArray(), infoCompara, CotizacionCompara.Cobertura, coberturasPaquete);
                        ColocaPrimasCotizadas(infoCompara, paquete.resultadosFormaPago);
                    }
                }

                CotizacionCompara.Comparar.Add(infoCompara);
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Tuvimos un inconveniente para realizar tu cotizacion {0}", ex.Message));
                throw;
            }

            return CotizacionCompara;
        }



        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            //Configuración
            bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
            PeriodicidadFormaPago periodicidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatPeriodicidadFormaPago == InfoEmision.CotizacionAutoGuardar.FormadePago).FirstOrDefault();
            CatPeriodicidadFormaPago catPeriodicidad = db.CatPeriodicidadFormaPago.FirstOrDefault(x => x.Id == InfoEmision.CotizacionAutoGuardar.FormadePago);
            CotizacionDetalle cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);
            Cotizacion cotizacion = db.Cotizacion.First(a => a.Id == cotizacionDetalle.IdCotizacion);
            int IdPaquete = int.Parse(cotizacionDetalle.Paquete);
            PaqueteAseguradora tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == InfoEmision.Convenio.IdAseguradora && x.IdCatTipoPaquete == IdPaquete).FirstOrDefault();
            CatModalidadFormaPago medioPago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == InfoEmision.CotizacionAutoGuardar.MediodePago.ToString());
            //CAT: La nueva ruta solo aplica a la emision web configurada y a medios de pago con tarjeta.
            bool aplicaDomiciliacionPostEmision = InfoEmision.Convenio.AplicaDomiciliacionPostEmision
                && (InfoEmision.CotizacionAutoGuardar.MediodePago == 0 || InfoEmision.CotizacionAutoGuardar.MediodePago == 1);
            string telefono = InfoEmision.TelefonoCel;
            ConfiguracionEmpresa ConfigEmpresa = db.ConfiguracionEmpresa.Where(x => x.IdEmpresa == InfoEmision.Empresa.Id).FirstOrDefault();
            string codigoPostal = cotizacionDetalle.Cotizacion.CodigoPostal; ObtieneCodigoPostalParaEmision(InfoEmision);
            LocktonModel.db.CodigoPostal catCodigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == codigoPostal);
            RequestCotizacionAutos xmlCotizacionSeleccionada = GetXmlFromString<RequestCotizacionAutos>(cotizacionDetalle.XMLSolicitud);
            var ramoVehiculo = db.CatRamoVehiculo.First(x => x.Clave == InfoEmision.CotizacionAutoGuardar.TipoVehiculo);
            var convenioRamoPaquete = db.ConvenioRamoPaquete.FirstOrDefault(x => x.IdConvenio == InfoEmision.Convenio.Id && x.IdCatRamoVehiculo == ramoVehiculo.IdCatRamo);
            var objConvenio = db.Convenio.Where(x => x.Id == convenioRamoPaquete.IdConvenio).FirstOrDefault();

            string XmlizedString = string.Empty;
            string xmlResponse = string.Empty;

            try
            {

                RequestEmisionAutosAPI reqEmiAuto = new RequestEmisionAutosAPI();
                reqEmiAuto.usuario = InfoEmision.Convenio.Usuario;
                reqEmiAuto.password = InfoEmision.Convenio.Contrasena;
                reqEmiAuto.intermediario = InfoEmision.Convenio.CodigoIntermediario;
                reqEmiAuto.intermediarioUDI = "";
                reqEmiAuto.intermediarioPromotor = "";
                reqEmiAuto.intermediarioCoordinador = "";

                reqEmiAuto.formaPago = periodicidad.FormaPago;// ObtenerFormaPago(periodicidad);
                reqEmiAuto.referencia1 = InfoEmision.DetalleUsuario.IdEmpleado;
                reqEmiAuto.referencia2 = "";
                reqEmiAuto.referencia2Valor = "";
                reqEmiAuto.folio = "";
                reqEmiAuto.codigoCEC = "";
                reqEmiAuto.beneficiario = InfoEmision.BeneficiarioPreferente;
                reqEmiAuto.incluirDocumentacion = "S";

                reqEmiAuto.elementosAdicionales = new ElementoAdicional[] { };
                reqEmiAuto.paquete = new PaqueteIn();
                reqEmiAuto.incluirCFD = "";
                reqEmiAuto.indContraConductor = "";

                log.Info("Inicia emision GNP");

                if (!string.IsNullOrEmpty(telefono) && telefono.Length > 8)
                {
                    telefono = telefono.Substring(telefono.Length - Math.Min(8, telefono.Length));
                }
                log.Info("Obtiene carátula");
                int? idVehiculoDisponible = null;

                bool checkActivo = InfoEmision.Convenio.CHKCARTYPE == "1";
                if (checkActivo)
                {
                    idVehiculoDisponible = InfoEmision.CotizacionAutoGuardar.ValorFactura
                        ? 1
                        :2; 
                }
                string caratula = ObtieneCaratulaPorSP(InfoEmision.Convenio.Id, IdPaquete, InfoEmision.CotizacionAutoGuardar.FormadePago, medioPago.Id, InfoEmision.CotizacionAutoGuardar.Agnio, ObtieneIdRamoVehiculo(Convert.ToInt32(InfoEmision.CotizacionAutoGuardar.TipoVehiculo)), idVehiculoDisponible);

                reqEmiAuto.numeroCaratula = !string.IsNullOrEmpty(caratula) ? caratula : InfoEmision.Convenio.CaratulaPoliza;
                reqEmiAuto.paquete.clavePaquete = xmlCotizacionSeleccionada.paquetes.FirstOrDefault().clavePaquete;

                //Nomina es I tarjeta es R CotizacionCompara.MediodePago
                ColocaFormaDeCobro(reqEmiAuto, InfoEmision.CotizacionAutoGuardar.MediodePago, aplicaDomiciliacionPostEmision);

                DateTime InicioVigencia = InfoEmision.Convenio.InicioVigencia;
                DateTime FinVigencia = InfoEmision.Convenio.FinVigencia;

                //if (!Utilidades.Utilidades.EstaEnPeriodoDeEnrollment(InfoEmision.Convenio.IdEmpresa, DateTime.Now))
                //{
                //    InicioVigencia = ConfigEmpresa.AplicaFechaCotizacion ? cotizacion.FechaFactura : DateTime.Now;
                //}
                //log.Info("Coloca fechas de vigencia");
                //reqEmiAuto.fechaInicioVigencia = InicioVigencia.ToString("yyyyMMdd");
                //reqEmiAuto.fechaFinVigencia = FinVigencia.ToString("yyyyMMdd");

                reqEmiAuto.fechaInicioVigencia = xmlCotizacionSeleccionada.fechaInicioVigencia;
                reqEmiAuto.fechaFinVigencia = xmlCotizacionSeleccionada.fechaFinVigencia;

                _Descripciones _resultado = ConsultaCatalogoHomologado(xmlCotizacionSeleccionada.vehiculo.claveMarca);

                log.Info("Obtiene coberturas y sus claves");
                List<Coberturas> coberturasPaquete = ObtenerCoberturas(InfoEmision.Convenio.Id, Convert.ToInt32(cotizacionDetalle.Paquete), cotizacionDetalle.IdVehiculo, cotizacionDetalle.IdPaqueteConvenio ?? 1);

                reqEmiAuto.paquete.coberturas = ObtieneClavesCoberturas(coberturasPaquete, InfoEmision.Convenio.Id, InfoEmision.CotizacionAutoGuardar.Agnio, cotizacionDetalle.IdVehiculo);

                log.Info("Coloca datos de Vehículo");
                reqEmiAuto.vehiculo = ConstruyeObjetoVehiculoEmision(InfoEmision, xmlCotizacionSeleccionada, coberturasPaquete);

                log.Info("Coloca datos de Contratante");
                reqEmiAuto.contratante = ConstruyeObjetoContratanteEmision(InfoEmision, xmlCotizacionSeleccionada, codigoPostal, catCodigoPostal, ConfigEmpresa, objConvenio.CodigoCliente);

                log.Info("Coloca datos de Asegurado");
                reqEmiAuto.asegurado = ConstruyeObjetoAseguradoEmision(xmlCotizacionSeleccionada, InfoEmision);

                //provisional 
                reqEmiAuto.asegurado.domicilio = reqEmiAuto.contratante.domicilio;

                if (InfoEmision.RequiereFactura)
                {
                    var datosFacturacion = new List<ElementoAdicional>();
                    var regimenFiscal = "";
                    var razonsocial = "";
                    var cp = reqEmiAuto.contratante.domicilio.codigoPostal.cp;
                    var _facturacion = new Facturacion();

                    if (reqEmiAuto.contratante.tipoPersona == "F")
                    {
                        if (InfoEmision.IdRegimenFiscal > 0)
                        {
                            _facturacion.IdRegimenFiscal = InfoEmision.IdRegimenFiscal;
                            regimenFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.IdRegimenFiscal).Clave;
                        }

                        razonsocial = $"{reqEmiAuto.asegurado.nombre} {reqEmiAuto.asegurado.apaterno} {reqEmiAuto.asegurado.amaterno}";

                    }
                    else
                    {
                        if (InfoEmision.Empresa.IdRegimenFiscal.HasValue)
                        {
                            _facturacion.IdRegimenFiscal = InfoEmision.Empresa.IdRegimenFiscal;
                            regimenFiscal = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal).Clave;
                        }

                        razonsocial = reqEmiAuto.contratante.razonSocial;

                    }

                    datosFacturacion.Add(new ElementoAdicional()
                    {
                        elemento = "REG_FISCAL",
                        valor = regimenFiscal
                    });

                    datosFacturacion.Add(new ElementoAdicional()
                    {
                        elemento = "RAZON_SOCIAL_CONSTANCIA",
                        valor = razonsocial
                    });

                    datosFacturacion.Add(new ElementoAdicional()
                    {
                        elemento = "CP_FISCAL",
                        valor = cp
                    });

                    reqEmiAuto.elementosAdicionales = datosFacturacion.ToArray();

                    _facturacion.RFC = reqEmiAuto.contratante.rfc;
                    _facturacion.Nombre = razonsocial;
                    _facturacion.CodigoPostal = cp;

                    Utilidades.Utilidades.GeneraRegistroFacturacion(_facturacion);

                }

                if (xmlCotizacionSeleccionada.elementosAdicionales != null && xmlCotizacionSeleccionada.elementosAdicionales.Length > 0)
                    reqEmiAuto.elementosAdicionales = xmlCotizacionSeleccionada.elementosAdicionales;

                //provisional           
                reqEmiAuto.asegurado.domicilio = reqEmiAuto.contratante.domicilio;
                //
                log.Info("Obtiene datos reemplazables del xml");
                List<string> listaDatosReemplazo = ObtieneListaDatosAReemplazarXML(InfoEmision);// new List<string>();
                string datosAReemplazar = ObtieneCadenaDatosAReemplazarXML(InfoEmision, new Banco());// string.Empty;

                XmlizedString = Utilidades.Utilidades.ToXMLString<RequestEmisionAutosAPI>(reqEmiAuto);

                log.Info(string.Format("GNP Xml Emision Solicitud: {0}", XmlizedString.Replace("\n", "").Replace("\r", "")));

                //CAT: Omite los nodos bancarios cuando GNP recibira los datos mediante el servicio posterior de domiciliacion.
                if (!aplicaDomiciliacionPostEmision)
                    AgregaDatosBancariosContratante(reqEmiAuto.contratante, InfoEmision);

                log.Info("Manda solicitud de emisión");
                WSAutosWSImplClient emitirClient = new WSAutosWSImplClient();
                emitirClient.Open();
                var responseEmitir = emitirClient.emitirPolizaWS(reqEmiAuto);
                emitirClient.Close();
                log.Info("Recibe solicitud de emisión");

                XmlDocument node = new XmlDocument();
                xmlResponse = Utilidades.Utilidades.ToXMLString<ResponseEmisionAutos>(responseEmitir.response);

                if (!string.IsNullOrEmpty(datosAReemplazar) && listaDatosReemplazo.Count > 0)
                {
                    string datosOriginales = datosAReemplazar;
                    foreach (string dato in listaDatosReemplazo)
                    {
                        datosAReemplazar.Replace(dato, "*****");
                    }
                    xmlResponse = xmlResponse.Replace(datosOriginales, datosAReemplazar);
                }

                node.LoadXml(xmlResponse);

                log.Info("Obtiene respuesta Emitir GNP-Flotillas Resultado: " + xmlResponse.Replace("\n", "").Replace("\r", ""));

                /*Termina emisión de polizas*/
                Poliza poliza = new Poliza();
                PolizaDetalle polizaDet = new PolizaDetalle();

                if (responseEmitir.response == null && responseEmitir.error != null)
                {
                    log.Error("Emision error GNP " + responseEmitir.error);
                    log.Info(string.Format("GNP Xml Emision Respuesta: {0}", responseEmitir.error));

                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, xmlResponse, responseEmitir.error, "Emisión");
                    return new EmisionPoliza(false, XmlizedString, string.Concat("Tuvimos inconveniente al generar tu póliza. ", responseEmitir.error), null);
                }

                if (node.Name == "Errores")
                {
                    if (InfoEmision.EsFlotilla)
                    {
                        log.Error("emiteVehiculo error GNP-Flotilla: " + xmlResponse.Replace("\n", "").Replace("\r", ""));
                    }
                    else
                    {
                        log.Error("emiteVehiculo error GNP-Individual: " + xmlResponse.Replace("\n", "").Replace("\r", ""));
                    }
                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, xmlResponse, node.InnerText, "Emisión");
                    return new EmisionPoliza(false, XmlizedString, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde." + node.InnerText, null);
                }

                //var resultadoEmision = GetXmlFromString<ResponseEmisionAutos>(xmlResponse);//responseEmitir.response;
                var resultadoEmision = responseEmitir.response;

                decimal primaNeta = decimal.Parse(resultadoEmision.tarifa.primaNeta.ToString());
                decimal primaTotal = decimal.Parse(resultadoEmision.tarifa.primaTotal.ToString());
                decimal primerPago = decimal.Parse(resultadoEmision.tarifa.recibos.Select(r => r.detalleRecibos.Max(dr => dr.importe)).FirstOrDefault().ToString());
                decimal pagoSubsecuente = decimal.Parse(resultadoEmision.tarifa.recibos.Select(r => r.detalleRecibos.Min(dr => dr.importe)).FirstOrDefault().ToString());
                decimal derechos = decimal.Parse(QuitaCaracteres(resultadoEmision.tarifa.derechoPoliza.ToString()), CultureInfo.InvariantCulture);
                decimal recargo = decimal.Parse(QuitaCaracteres(resultadoEmision.tarifa.recargoPagoFracc.ToString()), CultureInfo.InvariantCulture);
                decimal impuestos = decimal.Parse(QuitaCaracteres(resultadoEmision.tarifa.iva.ToString()), CultureInfo.InvariantCulture);
                List<string> format = new List<string>();
                format.Add("dd/MM/yyyy");
                format.Add("yyyyMMdd");
                try
                {
                    FinVigencia = DateTime.ParseExact(resultadoEmision.poliza.fechaFinVigencia, format.ToArray(), CultureInfo.InvariantCulture, DateTimeStyles.None);
                    InicioVigencia = DateTime.ParseExact(resultadoEmision.poliza.fechaInicioVigencia, format.ToArray(), CultureInfo.InvariantCulture, DateTimeStyles.None);
                    primaNeta = decimal.Parse(QuitaCaracteres(resultadoEmision.tarifa.primaNeta.ToString()), CultureInfo.InvariantCulture);
                    primaTotal = decimal.Parse(QuitaCaracteres(resultadoEmision.tarifa.primaTotal.ToString()), CultureInfo.InvariantCulture);
                }
                catch (Exception) { }

                poliza = ConstruyeObjetoPoliza(
                    !string.IsNullOrEmpty(resultadoEmision.poliza.numero) ? resultadoEmision.poliza.numero.TrimStart(new Char[] { '0' }) : resultadoEmision.poliza.numero,
                    FinVigencia, InicioVigencia, primaNeta, primaTotal, tipoPaquete.IdCatTipoPaquete, InfoEmision);

                polizaDet = ConstruyeObjetoPolizaDetalle(cotizacionDetalle,
                    medioPago.Id, periodicidad.IdCatPeriodicidadFormaPago, xmlResponse, XmlizedString, InfoEmision);

                //List<Recibo> recibosGenerados = ObtieneObjetoRecibosEmision(resultadoEmision.tarifa.recibos, InicioVigencia, FinVigencia, primaTotal, primaNeta, derechos, recargo, impuestos, convenioRamoPaquete.Comision > 0);
                List<Recibo> recibosGenerados = WebServiceImpresionReciboDetalle(poliza.NumeroPoliza, reqEmiAuto.usuario, reqEmiAuto.password, reqEmiAuto.intermediario, "0", "MIME", resultadoEmision.tarifa.recibos, InicioVigencia, FinVigencia, primaTotal, primaNeta, derechos, recargo, impuestos, convenioRamoPaquete.Comision > 0);

                Endoso endosoAlta = ConstruyeObjetoEndosoAlta(recibosGenerados);

                poliza.Endoso.Add(endosoAlta);
                poliza.PolizaDetalle.Add(polizaDet);
                db.Poliza.Add(poliza);
                db.SaveChanges();

                List<string> pdf = ReimprimePoliza(poliza.NumeroPoliza, "", poliza.ClaveAgente);

                poliza.UrlPDFPoliza = pdf.FirstOrDefault();
                poliza.UrlPDFRecibos = pdf.LastOrDefault();
                
                db.SaveChanges();

                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, xmlResponse, "", "Emisión");

                Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                EmisionPoliza resultado = new EmisionPoliza(true, XmlizedString, xmlResponse, poliza);

                //CAT: Ejecuta la domiciliacion solo despues de confirmar y guardar la poliza; cualquier falla se reporta sin reemitirla.
                if (aplicaDomiciliacionPostEmision)
                {
                    try
                    {
                        DatosCobranza datosCobranza = ConstruyeDatosCobranzaDomiciliacion(InfoEmision, poliza.NumeroPoliza);
                        resultado.EstatusDomiciliacion = PagoConTarjeta(datosCobranza);
                    }
                    catch (Exception ex)
                    {
                        log.Error(string.Format("La poliza GNP {0} fue emitida, pero ocurrio un error al registrar su domiciliacion.", poliza.NumeroPoliza), ex);
                        resultado.EstatusDomiciliacion = new EstatusOperacion
                        {
                            Exitoso = false,
                            EsReintentable = false,
                            Mensaje = "No fue posible registrar la domiciliación."
                        };
                    }
                }

                return resultado;
            }
            catch (Exception ex)
            {
                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, XmlizedString, xmlResponse, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");
                return new EmisionPoliza(false, null, ex.Message);
            }
        }

        #endregion



        #region Utility Methods

        private int ObtieneIdRamoVehiculo(int idCatRamoVehiculo)
        {
            return db.CatUsoVehiculo.FirstOrDefault(cuv => cuv.Clave == idCatRamoVehiculo.ToString() && cuv.Estatus == 1).Id;
        }

        //private string ObtenerClavePaquete(string paquete)
        //{
        //    string respuesta = string.Empty;
        //    switch (paquete.ToLower())
        //    {
        //        case "amplia":
        //            respuesta = "0000000332";
        //            break;
        //        case "rc":
        //            respuesta = "0000000335";
        //            break;
        //        case "responsabilidad civil":
        //            respuesta = "0000000335";
        //            break;
        //        case "limitada":
        //            respuesta = "0000000333";
        //            break;
        //        default:
        //            respuesta = "0000000332";
        //            break;
        //    }
        //    return respuesta;
        //}

        //private string ObtenerFormaPago(PeriodicidadFormaPago periodicidad)
        //{
        //    string formaPago = string.Empty;
        //    switch (periodicidad.FormaPago.ToLower())
        //    {
        //        case "anual":
        //            formaPago = "A";
        //            break;
        //        case "mensual":
        //            formaPago = "M";
        //            break;
        //        case "semestral":
        //            formaPago = "S";
        //            break;
        //    }
        //    return formaPago;
        //}

        private string QuitaCaracteres(string numero)
        {
            return numero.Replace(",", "").Replace("$", "");
        }

        public List<Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete, int tipoVehiculo, int idPaqueteConvenio)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio
                                           && a.IdCatTipoPaquete == idPaquete
                                           && c.IdCatRamoVehiculo == tipoVehiculo
                                              && a.IdPaqueteConvenio == idPaqueteConvenio
                                              && b.Clave != "0"
                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible / 100).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", ""),
                                               IdCatRamo = c.IdCatRamoVehiculo,
                                               IdCobertura = b.Id,
                                               IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1

                                           }).ToList();
            return coberturas;
        }

        public List<Coberturas> ObtenerCoberturasComparativo(int idConvenio, int idPaquete, int tipoVehiculo, int idPaqueteConvenio)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio
                                           && a.IdCatTipoPaquete == idPaquete
                                           && c.IdCatRamoVehiculo == tipoVehiculo
                                              && a.IdPaqueteConvenio == idPaqueteConvenio

                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible / 100).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", ""),
                                               IdCatRamo = c.IdCatRamoVehiculo,
                                               IdCobertura = b.Id,
                                               IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1

                                           }).ToList();
            return coberturas;
        }

        private string ObtenerClaveEstado(string codigoPostal)
        {
            var estado = from s in db.CatCodigoPostal
                         join er in db.CatEstadosRepublica on s.IdEstado equals er.Id
                         join egnp in db.CatEstadosGNP on er.Estado.ToLower() equals egnp.Edo.ToLower()
                         where s.Codigo == codigoPostal
                         select egnp.Id;
            return estado?.FirstOrDefault() ?? "08";
        }
        private string ObtenerColonia(string codigoPostal)
        {
            var Colonia = from s in db.CatCodigoPostal
                          where s.Codigo == codigoPostal
                          select s.Asentamiento;
            return Colonia?.FirstOrDefault() ?? "Prueba";
        }
        public Comparar LeeXmlInformacion(string XmlResultado, string xmlEnvio, int numeroRecibos, Convenio convenio)
        {
            Comparar infoCompara = new Comparar();

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            xmlCotizacionSeleccionada.LoadXml(xmlEnvio);

            try
            {
                ResponseCotizacionAutos resultadoCotizacion = GetXmlFromString<ResponseCotizacionAutos>(XmlResultado);

                DateTime conversionFechaInicio = DateTime.Now;
                DateTime conversionFechaFin = DateTime.Now;

                foreach (var paquete in resultadoCotizacion.paquetes)
                {

                    foreach (ResultadoFormaPago primasResultado in paquete.resultadosFormaPago)
                    {
                        infoCompara.PrimaNeta = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.primaNeta);
                        infoCompara.PrimaTotal = QuitaCaracteres(primasResultado.resultadoTotal.importeAcumuladoRecibos?.ToString());
                        infoCompara.Impuesto = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.iva);
                        infoCompara.Recargo = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.recargos);
                        infoCompara.Derecho = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.derechosPol);
                        string fechaInicio = resultadoCotizacion.poliza.fechaInicioVigencia;
                        conversionFechaInicio = ConvertirFecha(fechaInicio);
                        string fechaFin = convenio.FinVigencia.ToString("yyyyMMdd");//resultadoCotizacion.poliza.fechaFinVigencia;
                        conversionFechaFin = ConvertirFecha(fechaFin);
                        infoCompara.PrimerPago = QuitaCaracteres(primasResultado.resultadoTotal.importePrimerRecibo.ToString());
                        infoCompara.SegundoPago = QuitaCaracteres(primasResultado.resultadoTotal.importeSucesivos.ToString());

                        infoCompara.NumeroDePagos = NumeroPagos(Convert.ToDecimal(infoCompara.PrimaTotal)
                            , Convert.ToDecimal(infoCompara.PrimerPago)
                            , Convert.ToDecimal(string.IsNullOrEmpty(infoCompara.SegundoPago) ? "0" : infoCompara.SegundoPago)
                            , numeroRecibos);

                        infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;
                    }
                }
                infoCompara.FechaInicio = conversionFechaInicio.ToString("dd/MM/yyyy");
                infoCompara.FechaFin = conversionFechaFin.ToString("dd/MM/yyyy");
                infoCompara.Año = resultadoCotizacion.vehiculo.modelo;
            }
            catch (Exception)
            {
                throw;
            }
            return infoCompara;
        }

        public Comparar LeeXmlRespuesta(string XmlResultado, List<LocktonModel.db.PaqueteDetalle> coberturas, int IdTipoPaquete, string xmlEnvio, Convenio convenioCotiza, int numeroRecibos, int tipoVehiculo, int idPaquteConvenio)
        {
            Comparar infoCompara = new Comparar();

            XmlDocument xmlCotizacionSeleccionada = new XmlDocument();
            xmlCotizacionSeleccionada.LoadXml(xmlEnvio);
            try
            {
                ResponseCotizacionAutos resultadoCotizacion = GetXmlFromString<ResponseCotizacionAutos>(XmlResultado);

                infoCompara.Coberturas = new List<LocktonModel.VModels.Coberturas>();
                infoCompara.Aseguradora = "GNP";
                infoCompara.Cobertura = IdTipoPaquete.ToString();
                infoCompara.XmlEmision = xmlEnvio;
                infoCompara.XmlRespuesta = XmlResultado;
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                DateTime conversionFechaInicio = DateTime.Now;
                DateTime conversionFechaFin = DateTime.Now;

                List<Coberturas> coberturasPaquete = ObtenerCoberturasComparativo(convenioCotiza.Id, IdTipoPaquete, tipoVehiculo, idPaquteConvenio);
                var tipoDatos = db.CatTipoDatoDeducible.ToList();

                foreach (var paquete in resultadoCotizacion.paquetes)
                {

                    infoCompara.Coberturas = new List<Coberturas>();

                    foreach (var cobertura in coberturasPaquete)
                    {
                        var _coberturaPaquete = paquete.coberturas.Concat(paquete.coberturasOpcionales).ToList().FirstOrDefault(a => a.id.Trim() == cobertura.Codigo.Trim());
                        var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == cobertura.IdTipoDatoDeducible);

                        Coberturas cotCob = new Coberturas();

                        if (_coberturaPaquete != null)
                        {

                            cotCob.Cobertura = QuitaCaracteres(_coberturaPaquete.primaNeta.ToString());

                            cotCob.SumaAsegurada = QuitaCaracteres(_coberturaPaquete.sumaAsegurada.ToString());

                            cotCob.Nombre = _coberturaPaquete.descripcion.Trim();

                            bool tieneDeducible = _coberturaPaquete.elementosCobertura.Where(ec => ec.elemento.ToUpper().Contains("CDDEDUCI")).Any();

                            if (tieneDeducible)
                            {
                                cotCob.Deducible = _coberturaPaquete.elementosCobertura.Where(ec => ec.elemento.ToUpper().Equals("CDDEDUCI")).FirstOrDefault().valor;
                                cotCob.IdTipoDatoDeducible = cobertura.IdTipoDatoDeducible;
                                cotCob.TipoDato = tipoDato.Nombre;
                            }
                            else
                            {
                                cotCob.Deducible = "0";
                            }


                        }
                        else
                        {
                            cotCob.Cobertura = "0";

                            cotCob.SumaAsegurada = "0";

                            cotCob.Nombre = cobertura.Nombre.Trim();

                            cotCob.Deducible = "0";
                        }

                        cotCob.Codigo = cobertura.Codigo;

                        infoCompara.Coberturas.Add(cotCob);

                    }


                    //foreach (CoberturaCotizada cobertura in paquete.coberturas.Concat(paquete.coberturasOpcionales).ToArray())
                    //{
                    //    Coberturas _coberturaPaquete = coberturasPaquete.FirstOrDefault(a => a.Codigo.Trim() == cobertura.id.Trim());


                    //    if (_coberturaPaquete != null)
                    //    {
                    //        var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == _coberturaPaquete.IdTipoDatoDeducible);
                    //        Coberturas cotCob = new Coberturas();
                    //        cotCob.Cobertura = QuitaCaracteres(cobertura.primaNeta.ToString());
                    //        cotCob.SumaAsegurada = QuitaCaracteres(cobertura.sumaAsegurada.ToString());
                    //        cotCob.Nombre = cobertura.descripcion.Trim();
                    //        bool tieneDeducible = cobertura.elementosCobertura.Where(ec => ec.elemento.ToUpper().Contains("CDDEDUCI")).Any();
                    //        if (tieneDeducible)
                    //        {
                    //            cotCob.Deducible = cobertura.elementosCobertura.Where(ec => ec.elemento.ToUpper().Equals("CDDEDUCI")).FirstOrDefault().valor;
                    //            cotCob.IdTipoDatoDeducible = _coberturaPaquete.IdTipoDatoDeducible;
                    //            cotCob.TipoDato = tipoDato.Nombre;
                    //        }
                    //        else
                    //        { cotCob.Deducible = "0"; }
                    //        cotCob.Codigo = _coberturaPaquete.Codigo;
                    //        infoCompara.Coberturas.Add(cotCob);
                    //    }
                    //}

                    foreach (ResultadoFormaPago primasResultado in paquete.resultadosFormaPago)
                    {
                        ColocaPrimasCotizadas(infoCompara, paquete.resultadosFormaPago);
                        infoCompara.CesionComision = Convert.ToDouble(QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.cesionComision));
                        string fechaInicio = resultadoCotizacion.poliza.fechaInicioVigencia;
                        conversionFechaInicio = ConvertirFecha(fechaInicio);
                        string fechaFin = fechaFin = convenioCotiza.FinVigencia.ToString("yyyyMMdd");
                        if (convenioCotiza.IdCatTipoVigencia == 2)
                            fechaFin = conversionFechaInicio.AddYears(1).ToString("yyyyMMdd"); //resultadoCotizacion.poliza.fechaFinVigencia;
                        conversionFechaFin = ConvertirFecha(fechaFin);
                        infoCompara.PrimaAnualizada = QuitaCaracteres(Utilidades.Utilidades.CalculaPrimaAnualizada(conversionFechaInicio, conversionFechaFin, infoCompara.PrimaNeta, infoCompara.Derecho, infoCompara.CesionComision));

                        if (paquete.resultadosFormaPago.FirstOrDefault().resultadoTotal.formaPago != "A")
                        {
                            infoCompara.NumeroDePagos = NumeroPagos(Convert.ToDecimal(infoCompara.PrimaTotal)
                                    , Convert.ToDecimal(infoCompara.PrimerPago)
                                    , Convert.ToDecimal(string.IsNullOrEmpty(infoCompara.SegundoPago) ? "0" : infoCompara.SegundoPago)
                                    , numeroRecibos);
                        }

                        //infoCompara.SegundoPago = infoCompara.SegundoPago == "0.00" ? "" : infoCompara.SegundoPago;

                    }
                }
                infoCompara.FechaInicio = conversionFechaInicio.ToString("dd/MM/yyyy");
                infoCompara.FechaFin = conversionFechaFin.ToString("dd/MM/yyyy");
                infoCompara.Año = resultadoCotizacion.vehiculo.modelo;
            }
            catch (Exception)
            {
                throw;
            }
            return infoCompara;
        }

        private int NumeroPagos(decimal primaTotal, decimal primerPago, decimal segundoPago, int mesesMaximos)
        {
            var numeropagos = 0;
            if (segundoPago == 0)
                numeropagos = 1;
            else
            {
                decimal faltante = primaTotal - primerPago;
                decimal pagos = 0;
                for (int i = 1; i <= mesesMaximos; i++)
                {
                    pagos += segundoPago;
                    if (Math.Round(pagos, 0) == Math.Round(faltante, 0))
                    {
                        numeropagos = i + 1;
                        break;
                    }
                }
            }

            return numeropagos;
        }

        private DateTime ConvertirFecha(string fecha)
        {
            return new DateTime(Convert.ToInt32(fecha.Substring(0, 4)), Convert.ToInt32(fecha.Substring(4, 2)), Convert.ToInt32(fecha.Substring(6, 2)));
        }

        public string QuitarAcentos(string cadenaAcentuada)
        {
            byte[] tempBytes;
            tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(cadenaAcentuada);
            string asciiStr = System.Text.Encoding.UTF8.GetString(tempBytes);
            return asciiStr.Trim();
        }

        public T GetXmlFromString<T>(string xmlSerialized)
        {
            TextReader reader = new StringReader(xmlSerialized);
            XmlSerializer xs = new XmlSerializer(typeof(T));
            var result = (T)xs.Deserialize(reader);
            reader.Close();
            return result;
        }

        public static GNPInfoReimpresion ReimprimePolizaGNPInfo(string NumeroPoliza)
        {
            bool UrlDisponible = false;
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"Repositorio\Documentos\GNP\" + NumeroPoliza + ".pdf";
            bool Exists = false;


            if (!Exists)
            {
                ApplicationDbContext db = new ApplicationDbContext();

                Poliza poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == NumeroPoliza);
                RequestImpresion impresion = new RequestImpresion();

                string urlsServicioImp = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("UrlGNPImpPDFInfo")).Valor;

                if (poliza == null)
                {
                    SqlParameter sqlPoliza = new SqlParameter("@Poliza", NumeroPoliza);
                    var detallePoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", sqlPoliza).FirstOrDefault();
                    Empresa empresa = db.Empresa.FirstOrDefault(x => x.IdGerenciaCORE.Equals(detallePoliza.IDGerencia) && x.Estatus == 1);
                    Convenio convenio = db.Convenio.FirstOrDefault(x => x.IdEmpresa.Equals(empresa.Id) && x.IdAseguradora.Equals(2) && x.Estatus.Equals(1));
                    impresion = new GNPInfoService().ConstruyeObjetoImpresionPoliza(NumeroPoliza, convenio.Id);
                    List<string> resultCore = new List<string>();

                    return WebServiceImpresion(
                    urlsServicioImp.Split('?')[0],
                    urlsServicioImp,
                    impresion.poliza,
                    impresion.usuario,
                    impresion.password,
                    impresion.version,
                    impresion.tipoAttachment);

                    //Exists = File.Exists(filePath);

                    //resultCore.Add((!Exists) ? "" : filePath);

                    //return resultCore;


                }
                else
                {
                    impresion = new GNPInfoService().ConstruyeObjetoImpresionPoliza(NumeroPoliza, poliza.IdConvenio);
                    var result = WebServiceImpresion(
                        urlsServicioImp.Split('?')[0],
                        urlsServicioImp,
                        impresion.poliza,
                        impresion.usuario,
                        impresion.password,
                        impresion.version,
                        impresion.tipoAttachment);

                    String strPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;
                    String strUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(strPathAndQuery, "/");
                    strUrl += @"Repositorio/Documentos/GNP/" + NumeroPoliza + ".pdf";
                    result.Url = strUrl;

                    return result;
                }

            }
            else
            {
                var result = new GNPInfoReimpresion();
                result.Path = filePath;
                result.Bytes = null;
                String strPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;
                String strUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(strPathAndQuery, "/");
                strUrl += @"Repositorio/Documentos/GNP/" + NumeroPoliza + ".pdf";
                result.Url = strUrl;

                return result;
            }
        }


        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            bool UrlDisponible = false;
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"Repositorio\Documentos\GNP\" + NumeroPoliza + ".pdf";
            bool Exists = false;
            if (!Exists)
            {

                Poliza poliza = db.Poliza.FirstOrDefault(a => a.NumeroPoliza == NumeroPoliza);
                RequestImpresion impresion = new RequestImpresion();

                string urlsServicioImp = db.CatParametro.FirstOrDefault(x => x.Clave.Equals("UrlGNPImpPDFInfo")).Valor;

                if (poliza == null)
                {
                    SqlParameter sqlPoliza = new SqlParameter("@Poliza", NumeroPoliza);
                    var detallePoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", sqlPoliza).FirstOrDefault();
                    Empresa empresa = db.Empresa.FirstOrDefault(x => x.IdGerenciaCORE.Equals(detallePoliza.IDGerencia) && x.Estatus == 1);
                    Convenio convenio = db.Convenio.FirstOrDefault(x => x.IdEmpresa.Equals(empresa.Id) && x.IdAseguradora.Equals(2) && x.Estatus.Equals(1));
                    impresion = ConstruyeObjetoImpresionPoliza(NumeroPoliza, convenio.Id);
                    List<string> resultCore = new List<string>();
                    WebServiceImpresion(
                    urlsServicioImp.Split('?')[0],
                    urlsServicioImp,
                    impresion.poliza,
                    impresion.usuario,
                    impresion.password,
                    impresion.version,
                    impresion.tipoAttachment);

                    Exists = File.Exists(filePath);

                    resultCore.Add((!Exists) ? "" : filePath);

                    return resultCore;

                }
                else
                {
                    impresion = ConstruyeObjetoImpresionPoliza(NumeroPoliza, poliza.IdConvenio);
                    WebServiceImpresion(
                    urlsServicioImp.Split('?')[0],
                    urlsServicioImp,
                    impresion.poliza,
                    impresion.usuario,
                    impresion.password,
                    impresion.version,
                    impresion.tipoAttachment);

                    List<string> result = new List<string>();

                    String strPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;
                    String strUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(strPathAndQuery, "/");
                    strUrl += @"Repositorio/Documentos/GNP/" + NumeroPoliza + ".pdf";
                    result.Add(strUrl);
                    result.Add(string.IsNullOrEmpty(poliza.UrlPDFRecibos) ? "" : poliza.UrlPDFRecibos);
                    return result;
                }

            }
            else
            {
                List<string> result = new List<string>();
                result.Add(filePath);
                return result;
            }
        }

        private RequestImpresion ConstruyeObjetoImpresionPoliza(string numeroPoliza, int idconvenio)
        {
            Convenio convenio = db.Convenio.FirstOrDefault(x => x.Id.Equals(idconvenio));
            return new RequestImpresion()
            {
                usuario = convenio.Usuario,
                password = convenio.Contrasena,
                poliza = numeroPoliza,
                tipoAttachment = "MIME",
                version = "U"
            };
        }

        public static GNPInfoReimpresion WebServiceImpresion(string url, string action, string numeroPoliza, string user, string pwd, string version, string tipoAttachment)
        {
            var result = new GNPInfoReimpresion();
            result.Path = null;
            result.Bytes = null;

            try
            {
                XmlDocument soapEnvelopeXml = CreateSoapEnvelope(user, pwd, numeroPoliza, version, tipoAttachment);
                HttpWebRequest webRequest = CreateWebRequest(url, action);
                InsertSoapEnvelopeIntoWebRequest(soapEnvelopeXml, webRequest);

                IAsyncResult asyncResult = webRequest.BeginGetResponse(null, null);

                // suspend this thread until call is complete. You might want to
                // do something usefull here like update your UI.
                asyncResult.AsyncWaitHandle.WaitOne();

                using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.EndGetResponse(asyncResult))
                {
                    result = readMultipart(webResponse, numeroPoliza).Result;
                }
            }
            catch (Exception ex)
            {
                log.Info("Error Método WebServiceImpresion remimpresion GNP " + ex.InnerException != null ? ex.InnerException.Message : ex.Message);
                return result;
            }

            return result;
        }

        public static GNPInfoReimpresionRecibo WebServiceImpresionRecibo(string url, string numeroPoliza, string user, string pwd, string intermediario, string version, string tipoAttachment)
        {
            var result = new GNPInfoReimpresionRecibo();
            result.Path = null;
            result.Bytes = null;
            try
            {
                XmlDocument soapEnvelopeXml = CreateSoapReciboEnvelope(user, pwd, intermediario, numeroPoliza, version, tipoAttachment);
                HttpWebRequest webRequest = CreateWebRequest(url);
                InsertSoapEnvelopeIntoWebRequest(soapEnvelopeXml, webRequest);

                IAsyncResult asyncResult = webRequest.BeginGetResponse(null, null);

                // suspend this thread until call is complete. You might want to
                // do something usefull here like update your UI.
                asyncResult.AsyncWaitHandle.WaitOne();

                using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.EndGetResponse(asyncResult))
                {
                    result = readMultipartRecibo(webResponse).Result;
                }
            }
            catch (Exception ex)
            {
                log.Info("Error Método WebServiceImpresion remimpresion GNP " + ex.InnerException != null ? ex.InnerException.Message : ex.Message);
                return result;
            }

            return result;
        }
        public List<Recibo> WebServiceImpresionReciboDetalle(string numeroPoliza, string user, string pwd, string intermediario, string version, string tipoAttachment, ConjuntoRecibos[] recibos, DateTime inicioVigencia, DateTime finVigencia, decimal primaTotal, decimal primaNeta, decimal derechos, decimal recargo, decimal impuestos, bool obtenerComision)
        {
            List<Recibo> lisrecibos = new List<Recibo>();
            log.Info("Entrar al metodo WebServiceImpresionReciboDetalle");
            GNPInfoServiceImpresionRecibos.WSImpresionRecibosImplClient wSImpresionRecibosImplClient = new GNPInfoServiceImpresionRecibos.WSImpresionRecibosImplClient();

            try
            {
                GNPInfoServiceImpresionRecibos.ReqConsultaRecibosPol reqConsultaRecibosPol = new GNPInfoServiceImpresionRecibos.ReqConsultaRecibosPol();
                reqConsultaRecibosPol.usr = user;
                reqConsultaRecibosPol.pwd = pwd;
                reqConsultaRecibosPol.cdInterm = intermediario;
                reqConsultaRecibosPol.numPol = numeroPoliza;
                reqConsultaRecibosPol.verPol = version;
                reqConsultaRecibosPol.tipoAttch = tipoAttachment;
                reqConsultaRecibosPol.incPDF = "N";
                var RecibosGNP = wSImpresionRecibosImplClient.consultarRecibos(reqConsultaRecibosPol);
                int Numrecibo = 1;
                foreach (var r in RecibosGNP.recibos)
                {
                    if (r != null)
                    {
                        Recibo recibo = new Recibo();
                        recibo.InicioVigencia = Convert.ToDateTime(r.feEfeRec);
                        recibo.FinVigencia = Convert.ToDateTime(r.feVenRec);
                        recibo.Numero = Numrecibo;
                        recibo.NoAsegurado = "1";
                        recibo.PrimaTotal = Convert.ToDecimal(r.impTotRec);
                        recibo.PrimaNeta = Convert.ToDecimal(r.impPrimaNeta);
                        recibo.Impuesto = Convert.ToDecimal(r.impIVA);
                        recibo.Recargo = Convert.ToDecimal(r.impRecargoFrac);
                        recibo.Derecho = Convert.ToDecimal(r.impDerPol);
                        lisrecibos.Add(recibo);
                        Numrecibo++;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Info("Error Método WebServiceImpresionReciboDetalle remimpresion GNP " + ex.ToString());
                try
                {
                    lisrecibos = ObtieneObjetoRecibosEmision(recibos, inicioVigencia, finVigencia, primaTotal, primaNeta, derechos, recargo, impuestos, obtenerComision);
                }
                catch (Exception error)
                {
                    log.Info("Error Método ObtieneObjetoRecibosEmision remimpresion GNP " + error.ToString());

                }
                return lisrecibos;
            }

            return lisrecibos;
        }
        public List<byte[]> ImpresionRecibo(string numeroPoliza)
        {

            try
            {

                SqlParameter sqlPoliza = new SqlParameter("@Poliza", numeroPoliza);
                var detallePoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", sqlPoliza).FirstOrDefault();
                var idGerencia = detallePoliza.IDGerencia.ToString();
                Empresa empresa = db.Empresa.FirstOrDefault(x => x.IdGerenciaCORE == idGerencia && x.Estatus == 1);
                Convenio convenio = db.Convenio.FirstOrDefault(x => x.IdEmpresa.Equals(empresa.Id) && x.IdAseguradora.Equals(2) && x.Estatus.Equals(1));

                var urlRecibosGNP = Utilidades.Utilidades.ObtienerValorParametro("UrlGNPImpReciboPDFInfo");

                var result = WebServiceImpresionRecibo(urlRecibosGNP, numeroPoliza, convenio.Usuario, convenio.Contrasena, convenio.CodigoIntermediario, "0", "MIME");

                return result.Bytes;


            }
            catch (Exception ex)
            {



            }

            return null;
        }

        async static Task<GNPInfoReimpresion> readMultipart(HttpWebResponse httpResponse, string numeroPoliza)
        {
            var result = new GNPInfoReimpresion();
            result.Path = null;
            result.Bytes = null;

            try
            {
                var content = new StreamContent(httpResponse.GetResponseStream());
                content.Headers.Add("Content-Type", httpResponse.ContentType);


                //byte[] fileData;

                //var stream = httpResponse.GetResponseStream();
                //using (var memoryStream = new MemoryStream())
                //{
                //    await stream.CopyToAsync(memoryStream);
                //    fileData = memoryStream.ToArray();
                //}

                MultipartMemoryStreamProvider multipart = new MultipartMemoryStreamProvider();
                Task.Factory.StartNew(() => multipart = content.ReadAsMultipartAsync().Result,
                   CancellationToken.None,
                   TaskCreationOptions.LongRunning, // guarantees separate thread
                   TaskScheduler.Default)
                   .Wait();

                string json = await multipart.Contents[0].ReadAsStringAsync();

                result.Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"Repositorio\Documentos\GNP\" + numeroPoliza + ".pdf";
                result.Bytes = multipart.Contents[1].ReadAsByteArrayAsync().Result;
                System.IO.File.WriteAllBytes(result.Path, result.Bytes);
                return result;
            }
            catch (Exception ex)
            {
                log.Info("Error método readMultipart Reimprimir Poliza GNP" + ex.InnerException != null ? ex.InnerException.Message : ex.Message);
                return result;
            }
        }

        async static Task<GNPInfoReimpresionRecibo> readMultipartRecibo(HttpWebResponse httpResponse)
        {
            var result = new GNPInfoReimpresionRecibo();
            result.Path = null;
            result.Bytes = new List<byte[]>();

            try
            {
                var content = new StreamContent(httpResponse.GetResponseStream());
                content.Headers.Add("Content-Type", httpResponse.ContentType);

                MultipartMemoryStreamProvider multipart = new MultipartMemoryStreamProvider();
                Task.Factory.StartNew(() => multipart = content.ReadAsMultipartAsync().Result,
                   CancellationToken.None,
                   TaskCreationOptions.LongRunning, // guarantees separate thread
                   TaskScheduler.Default)
                   .Wait();

                string json = await multipart.Contents[0].ReadAsStringAsync();

                //result.Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"Repositorio\Documentos\GNP\" + numeroPoliza + ".pdf";
                for (int i = 1; i < multipart.Contents.Count; i++)
                {
                    result.Bytes.Add(multipart.Contents[i].ReadAsByteArrayAsync().Result);
                }
                //result.Bytes = multipart.Contents[1].ReadAsByteArrayAsync().Result;
                //System.IO.File.WriteAllBytes(result.Path, result.Bytes);
                return result;
            }
            catch (Exception ex)
            {
                log.Info("Error método readMultipart Reimprimir Poliza GNP" + ex.InnerException != null ? ex.InnerException.Message : ex.Message);
                return result;
            }
        }

        private static HttpWebRequest CreateWebRequest(string url, string action)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Headers.Add("SOAPAction", action);
            webRequest.ContentType = "text/xml;charset=\"utf-8\"";
            webRequest.Accept = "text/xml";
            webRequest.Method = "POST";
            return webRequest;
        }

        private static HttpWebRequest CreateWebRequest(string url)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Headers.Add("SOAPAction", "consultarRecibos");
            webRequest.ContentType = "text/xml;charset=\"utf-8\"";
            webRequest.Accept = "text/xml";
            webRequest.Method = "POST";
            return webRequest;
        }

        private static XmlDocument CreateSoapEnvelope(string user, string pwd, string numeroPoliza, string version, string tipoAttachment)
        {
            XmlDocument soapEnvelopeDocument = new XmlDocument();
            soapEnvelopeDocument.LoadXml(
            string.Format(@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:lay=""http://layout.ws.gnp.com.mx"">
                           <soapenv:Header/>
                           <soapenv:Body>
                              <lay:RequestImpresion>
                                 <usuario>{0}</usuario>
                                 <password>{1}</password>
                                 <poliza>{2}</poliza>
                                 <version>{3}</version>
                                 <tipoAttachment>{4}</tipoAttachment>
                              </lay:RequestImpresion>
                           </soapenv:Body>
                        </soapenv:Envelope>", user, pwd, string.Format("00000{0}", numeroPoliza), version, tipoAttachment));
            return soapEnvelopeDocument;
        }

        private static XmlDocument CreateSoapReciboEnvelope(string user, string pwd, string intermediario, string numeroPoliza, string version, string tipoAttachment)
        {
            XmlDocument soapEnvelopeDocument = new XmlDocument();
            soapEnvelopeDocument.LoadXml(
            string.Format(@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:web=""http://webservice.layout.ws.gnp.com.mx"">
                               <soapenv:Header/>
                               <soapenv:Body>
                                  <web:ReqConsultaRecibosPol>
                                     <usr>{0}</usr>
                                     <pwd>{1}</pwd>
                                     <cdInterm>{2}</cdInterm>
                                     <numPol>{3}</numPol>
                                     <verPol>{4}</verPol>
                                     <tipoAttch>{5}</tipoAttch>
                                     <incPDF>S</incPDF>
                                  </web:ReqConsultaRecibosPol>
                               </soapenv:Body>
                            </soapenv:Envelope>", user, pwd, intermediario, numeroPoliza, version, tipoAttachment));
            return soapEnvelopeDocument;
        }

        private static void InsertSoapEnvelopeIntoWebRequest(XmlDocument soapEnvelopeXml, HttpWebRequest webRequest)
        {
            using (Stream stream = webRequest.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }
        }




        #endregion



        #region Metodos de Cotizacion
        private ResponseCotizacionAutosWrapper EnviaSolicitudCotizacion(RequestCotizacionAutos reqCotAutos)
        {
            WSAutosWSImplClient serviceCotizacion = new WSAutosWSImplClient();
            serviceCotizacion.Open();
            ResponseCotizacionAutosWrapper response = serviceCotizacion.cotizarPoliza(reqCotAutos);
            serviceCotizacion.Close();
            return response;
        }

        private CoberturaIn[] ObtieneClavesCoberturas(List<Coberturas> coberturasPaquete, int idConvenio, string anio, int idCatRamoVehiculo)
        {
            var listaCoberturas = new List<CoberturaIn>();
            var coberturaUtils = new Utilidades.CoberturasUtils();

            foreach (Coberturas paquete in coberturasPaquete.Where(a => a.Codigo != "0"))
            {
                bool aplicaCobertura = coberturaUtils.AplicaCoberturaEspecial(idConvenio, paquete.IdCobertura.ToString(), anio, paquete.IdCatRamo);
                bool EsCondEspecial = coberturaUtils.EsCondicionEsp(idConvenio, paquete.IdCobertura.ToString(), idCatRamoVehiculo);

                if ((EsCondEspecial && aplicaCobertura) || !EsCondEspecial)
                {
                    CoberturaIn coberAdd = new CoberturaIn();
                    coberAdd.id = paquete.Codigo.PadLeft(10, '0'); ;
                    listaCoberturas.Add(coberAdd);
                }
            }
            return listaCoberturas.ToArray();
        }

        private _Descripciones ConsultaCatalogoHomologado(string clave)
        {
            ConsultaCatalogoHomologado.ObjetoRespuestaBD _descripcion = new ConsultaCatalogoHomologado.ConsultaCatalogoHomologadoClient().NCHConsultaDetalleVehiculo("GNP", clave);
            return JsonConvert.DeserializeObject<_Descripciones>(_descripcion.RespuestaJSON);
        }

        private string ObtieneCaratulaPorSP(int? convenioId, int idTipoPaquete, int formaDePago, int id, string anio, int tipoVehiculo, int? idVehiculoDisponible = null)
        {
            var parameters = new List<SqlParameter>()
                {
                    new SqlParameter("@IdConvenio",convenioId)
                    ,new SqlParameter("@IdPaquete",idTipoPaquete)
                    ,new SqlParameter("@IdPeriodicidad",formaDePago)
                    ,new SqlParameter("@IdFormaPago",id)
                    ,new SqlParameter("@Year",anio)
                    ,new SqlParameter("@ClaveTipoVehiculo",tipoVehiculo)
                    ,new SqlParameter("@idVehiculoDisponible", (object)idVehiculoDisponible ?? DBNull.Value)
                };

            return db.Database.SqlQuery<string>("Execute sp_CaratulasGNP_Obtener @IdConvenio, @IdPaquete, @IdPeriodicidad, @IdFormaPago, @Year, @ClaveTipoVehiculo, @idVehiculoDisponible", parameters.ToArray()).SingleOrDefault();
        }

        private GNPInfoServiceCotizarEmitir.Contratante ConstruyeObjetoContratante(Empresa empresa, CotizacionCompara cotizacionCompara, string CodigoPostal, string convenioCodigoCliente, bool Flotilla = true)
        {
            var contratante = new GNPInfoServiceCotizarEmitir.Contratante();
            List<Telefono> telefonos = new List<Telefono>();

            if (!Flotilla)
            {
                log.Info("Entra a llenar objeto de conratante cotización No es flotilla GNP");
                contratante.nombre = "PRUEBA";
                contratante.apaterno = "PRUEBA";
                contratante.amaterno = "PRUEBA";
                if (cotizacionCompara.FechaNacimiento != null)
                    contratante.rfc = "PUPP" + (cotizacionCompara.FechaNacimiento?.ToString("yyyyMMdd").Substring(2));
                contratante.tipoPersona = "F";
                if (cotizacionCompara.FechaNacimiento != null)
                    contratante.fechaNacimiento = cotizacionCompara.FechaNacimiento?.ToString("yyyyMMdd");
                contratante.tipoDocumento = "F";
                contratante.numeroIdentificacion = "9999999999";
                contratante.codigoCliente = convenioCodigoCliente ?? "";
                contratante.edoCivil = "S";
                contratante.sexo = (cotizacionCompara.Genero.ToLower() == "masculino") ? "V" : "M";
                contratante.nacionalidad = "MEX";
                contratante.paisResidencia = "MEX";
                contratante.ocupacion = "1510";
                contratante.email = "prueba@lockton.com";
                contratante.domicilio = new Domicilio();
                contratante.domicilio.numero = "1";
                contratante.domicilio.ubicacion = "Prueba";
                contratante.domicilio.tipoUbicacion = "CL";
                contratante.domicilio.paisResidencia = "MEX";
                contratante.domicilio.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                contratante.domicilio.codigoPostal.cp = CodigoPostal;
                contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(CodigoPostal);
                //contratante.domicilio.codigoPostal.colonia = ObtenerColonia(cotizacionCompara.CodigoPostal);
                contratante.domicilio.telefonos = new Telefono[] { };
                telefonos.Add(new Telefono { numero = "55555555", claveLada = "55", pais = "52" });
                telefonos.Add(new Telefono { numero = "55555555", claveLada = "55", pais = "52" });
                contratante.domicilio.telefonos = telefonos.ToArray();
                log.Info("termina a llenar objeto de conratante cotización No es flotilla GNP");
                return contratante;
            }
            contratante.tipoPersona = "J"; //Fisica F - Moral J;
            contratante.codigoCliente = convenioCodigoCliente ?? "";
            contratante.rfc = empresa.RFC;
            contratante.email = empresa.Ejecutivo.Correo;
            contratante.giro = ObtieneClaveGiroEmpresa(empresa.IdCatGiroBase);
            contratante.fechaConstitucion = empresa.FechaConstitucion?.ToString("yyyyMMdd");
            contratante.nacionalidad = "MEX";
            contratante.paisResidencia = "MEX";
            contratante.razonSocial = empresa.RazonSocial;
            contratante.tipoDocumento = "F";
            contratante.numeroIdentificacion = empresa.RFC;

            //contratante.representanteLegal = new GNPInfoServiceCotizarEmitir.RepresentanteLegal();
            //contratante.representanteLegal.nombre = empresa.RepresentanteLegal.Nombre;
            //contratante.representanteLegal.amaterno = empresa.RepresentanteLegal.ApellidoMaterno;
            //contratante.representanteLegal.apaterno = empresa.RepresentanteLegal.ApellidoPaterno;
            //contratante.representanteLegal.rfc = Utilidades.Utilidades.CalcularRFC(contratante.representanteLegal.nombre, contratante.representanteLegal.apaterno, contratante.representanteLegal.amaterno, empresa.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yy"));
            //contratante.representanteLegal.fechaNacimiento = empresa.RepresentanteLegal.FechaNacimiento.ToString("yyyyMMdd");
            //contratante.representanteLegal.tipoDocumento = "F";
            //contratante.representanteLegal.numeroIdentificacion = "9999999999";
            //contratante.representanteLegal.edoCivil = "S";
            //contratante.representanteLegal.sexo = "V";
            //contratante.representanteLegal.paisResidencia = "MEX";
            //contratante.representanteLegal.ocupacion = "1272";
            //contratante.representanteLegal.nacionalidad = "MEX";

            contratante.domicilio = new Domicilio();
            contratante.domicilio.tipoUbicacion = "CL";
            contratante.domicilio.ubicacion = QuitarAcentos(empresa.Direccion.Calle);
            contratante.domicilio.numero = empresa.Direccion.NumeroExt;
            contratante.domicilio.numeroInterior = empresa.Direccion.NumeroInt;
            contratante.domicilio.paisResidencia = "MEX";

            contratante.domicilio.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
            contratante.domicilio.codigoPostal.cp = empresa.Direccion.CodigoPostal;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
            contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(empresa.Direccion.CodigoPostal);//empresa.Direccion.CatCodigoPostal.CatEstadosRepublica.Clave;			

            contratante.domicilio.codigoPostal.colonia = QuitarAcentos(empresa.Direccion.CatCodigoPostal.Asentamiento);

            contratante.domicilio.telefonos = new Telefono[] { };
            telefonos.Add(new Telefono { numero = empresa.TelefonoGral.Substring(2), claveLada = empresa.TelefonoGral.Substring(0, 2), pais = "52" });
            telefonos.Add(new Telefono { numero = empresa.TelefonoGral.Substring(2), claveLada = empresa.TelefonoGral.Substring(0, 2), pais = "52" });
            contratante.domicilio.telefonos = telefonos.ToArray();

            return contratante;
        }


        private Conductor ConstruyeObjetoConductorCotizacion(DetalleUsuario detalleUsuario, string genero)
        {
            return new Conductor()
            {
                nombre = string.IsNullOrEmpty(detalleUsuario.NombreDos) ? detalleUsuario.Nombre : $"{detalleUsuario.Nombre} {detalleUsuario.NombreDos}",
                apaterno = detalleUsuario.ApellidoPaterno,
                amaterno = detalleUsuario.ApellidoMaterno,
                fechaNacimiento = detalleUsuario.FECHANACIMIENTO.ToString("yyyyMMdd"),
                numeroIdentificacion = "9999999999",
                tipoDocumento = "F",
                codigoCliente = "",
                edoCivil = "S",//ObtenerClaveEstadoCivil(detalleUsuario),
                sexo = genero.ToLower().Equals("masculino") ? "V" : "M",
                descuentoSiniestralidad = "0"
            };
        }

        private GNPInfoServiceCotizarEmitir.Vehiculo ConstruyeObjetoVehiculoCotizacion(_Descripciones descripciones, descripciones cotDesAuto, string modelo, string codigoPostal1, string codigoPostal2, bool aplicaValorFactura = false, string valorFactura = "", bool aplicaValorConvenido = false, bool esMoto = false, bool esPickup = false)
        {
            var vehiculo =
                new GNPInfoServiceCotizarEmitir.Vehiculo()
                {
                    usoVehiculo = "01",
                    indicadorAltoRiesgo = "N",
                    estadoCirculacion = ObtenerClaveEstado(string.IsNullOrEmpty(codigoPostal1) ? codigoPostal2 : codigoPostal1),
                    tipoVehiculo = cotDesAuto.clave.Substring(0, 3),
                    modelo = modelo,
                    descripcionVehiculo = cotDesAuto.Descripcion.Trim(),
                    claveMarca = cotDesAuto.clave,
                    valorConvenidoVehiculo = aplicaValorFactura ? valorFactura : "0",
                    tipoValorVehiculo = aplicaValorFactura ? "02" : aplicaValorConvenido ? "03" : "01",
                    tipoCarga = "",
                    registroFederal = "",
                    numeroSerie = "",
                    valorFactura = aplicaValorFactura ? valorFactura : "",
                    numeroMotor = "",
                    placas = "",
                    capacidad = "",
                    valorReferencia = aplicaValorFactura ? valorFactura : "",
                };
            if (esMoto)
            {
                vehiculo.valorConvenidoVehiculo = valorFactura;
                vehiculo.valorFactura = valorFactura;
                vehiculo.tipoValorVehiculo = "05";
            }
            if (esPickup)
            {
                vehiculo.tipoCarga = "A";
            }

            vehiculo.armadora = cotDesAuto.clave.Substring(vehiculo.tipoVehiculo.Length, 2);
            vehiculo.carroceria = cotDesAuto.clave.Substring(vehiculo.tipoVehiculo.Length + vehiculo.armadora.Length, 2);
            vehiculo.versionVehiculo = cotDesAuto.clave.Substring((vehiculo.tipoVehiculo.Length + vehiculo.armadora.Length + vehiculo.carroceria.Length), 2);

            return vehiculo;

        }

        private void ColocaPrimasCotizadas(Comparar infoCompara, ResultadoFormaPago[] resultadosFormaPago)
        {
            foreach (ResultadoFormaPago primasResultado in resultadosFormaPago)
            {
                infoCompara.PrimaNeta = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.primaNeta);
                infoCompara.PrimaTotal = QuitaCaracteres(primasResultado.resultadoTotal.importeAcumuladoRecibos?.ToString());
                infoCompara.Impuesto = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.iva);
                infoCompara.Recargo = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.recargos);
                infoCompara.Derecho = QuitaCaracteres(primasResultado.resultadoTotal.cotizacion.derechosPol);
                infoCompara.PrimerPago = QuitaCaracteres(primasResultado.resultadoTotal.importePrimerRecibo.ToString());
                if (primasResultado.resultadoTotal.formaPago != "A")
                {
                    infoCompara.SegundoPago = QuitaCaracteres(primasResultado.resultadoTotal.importeSucesivos.ToString());
                    infoCompara.SegundoPago = infoCompara.SegundoPago == "0" ? "" : infoCompara.SegundoPago;
                }
            }
        }

        private List<Coberturas> ObtieneCoberturasCotizadas(CoberturaCotizada[] coberturas, Comparar infoCompara, int coberturaId, List<Coberturas> coberturasPaquete)
        {
            var listaCoberturas = new List<Coberturas>();
            var tipoDatos = db.CatTipoDatoDeducible.ToList();

            foreach (CoberturaCotizada cobertura in coberturas)
            {
                infoCompara.Cobertura = coberturaId.ToString();
                Coberturas _coberturaPaquete = coberturasPaquete.FirstOrDefault(a => a.Codigo.Trim() == cobertura.id.Trim());



                if (_coberturaPaquete != null)
                {

                    var tipoDato = tipoDatos.FirstOrDefault(a => a.Id == _coberturaPaquete.IdTipoDatoDeducible);
                    Coberturas cotCob = new Coberturas();

                    cotCob.Cobertura = QuitaCaracteres(cobertura.primaNeta.ToString());
                    cotCob.SumaAsegurada = QuitaCaracteres(cobertura.sumaAsegurada.ToString());
                    cotCob.Nombre = _coberturaPaquete.Nombre.Trim();
                    bool tieneDeducible = cobertura.elementosCobertura.Where(ec => ec.elemento.ToUpper().Contains("CDDEDUCI")).Any();
                    if (tieneDeducible)
                    {
                        cotCob.Deducible = cobertura.elementosCobertura.Where(ec => ec.elemento.ToUpper().Equals("CDDEDUCI")).FirstOrDefault().valor;
                        cotCob.IdTipoDatoDeducible = _coberturaPaquete.IdTipoDatoDeducible;
                        cotCob.TipoDato = tipoDato.Nombre;

                    }
                    else
                    { cotCob.Deducible = "0"; }

                    cotCob.Codigo = _coberturaPaquete.Codigo;
                    listaCoberturas.Add(cotCob);
                }
            }
            return listaCoberturas;
        }
        #endregion



        #region Metodos de Emision
        private PolizaDetalle ConstruyeObjetoPolizaDetalle(CotizacionDetalle cotizacionDetalle, int medioPagoId, int idCatPeriodicidadFormaPago, string xmlResponse, string xmlizedString, InformacionEmision infoEmision)
        {
            return new PolizaDetalle()
            {
                Inciso = "1",
                RenovacionAutomatica = infoEmision.RenovacionAutomatica, // CAT Renovación automática: persiste la elección del usuario para GNP Info.
                FechaDecisionRenovacionAutomaticaUtc = infoEmision.FechaDecisionRenovacionAutomaticaUtc, // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                Deducible = 0,
                Comision = 0,
                FactorIva = 16, //Ponerlo de manera dinamica
                MigraOPERA = false,
                UrlPDFPolizaOPERA = "",
                PolizaOPERA = 0,
                OTOpera = 0,
                EndosoOPERA = 0,
                IdCotizacionAuto = infoEmision.CotizacionAutoGuardar.Id,
                IdCotizacionDetalle = cotizacionDetalle.Id,
                IdCatRamoVehiculo = cotizacionDetalle.IdVehiculo,// int.Parse(infoEmision.Convenio.RamoVehiculo.Split(',')[0]),
                BeneficiarioPreferente = infoEmision.BeneficiarioPreferente,
                IdCatModalidadFormaPago = medioPagoId,// db.CatModalidadFormaPago.Where(x => x.Clave.Equals(medioPago)).FirstOrDefault().Id,
                IdCatPeriodicidadFormaPago = idCatPeriodicidadFormaPago,// db.CatPeriodicidadFormaPago.Where(x => x.Clave.Equals(formaPago)).FirstOrDefault().Id,
                XMLRecepcion = xmlResponse,
                XMLSolicitud = xmlizedString,
                IdDireccion = infoEmision.Empresa.Direccion.Id
            };
        }

        private Poliza ConstruyeObjetoPoliza(string numeroPoliza, DateTime finVigencia, DateTime inicioVigencia, decimal primaNeta, decimal primaTotal, int idCatTipoPaquete, InformacionEmision infoEmision)
        {
            return new Poliza()
            {
                NumeroPoliza = numeroPoliza,
                FinVigencia = finVigencia,
                InicioVigencia = inicioVigencia,

                PrimaNeta = primaNeta,
                PrimaNetaAnualizada = primaNeta,
                PrimaTotal = primaTotal,
                PrimaTotalAnualizada = primaTotal,

                Motor = infoEmision.NumeroMotor,
                Serie = infoEmision.NumeroSerie,
                Placas = infoEmision.Placas,
                FechaEmision = DateTime.Now,
                ConductorHabitual = infoEmision.ObtieneNombreCompleto(),
                UrlPDFPoliza = "",
                UrlPDFRecibos = "",
                Estatus = 1,
                IdUsuario = infoEmision.DetalleUsuario.Id,
                IdConvenio = infoEmision.Convenio.Id,
                IdParentesco = infoEmision.Parentesco == null ? 19 : infoEmision.Parentesco.Id,
                IdTipoCobertura = idCatTipoPaquete,
                ClaveAgente = infoEmision.Convenio.CodigoIntermediario,
                Acepto_AvisoPrivacidad_Aseguradora = true,
                Acepto_DescuentoPoliza = true
            };
        }

        private List<Recibo> ObtieneObjetoRecibosEmision(ConjuntoRecibos[] recibos, DateTime inicioVigencia, DateTime finVigencia, decimal primaTotal, decimal primaNeta, decimal derechos, decimal recargo, decimal impuestos, bool obtenerComision)
        {
            log.Info("comienza a obtener los recibos desde el xml de la emisión");
            var recibosGenerados = new List<Recibo>();
            int numeroRecibo = 1;
            if (recibos != null && recibos.Any())
            {
                try
                {
                    foreach (ConjuntoRecibos recibo in recibos)
                    {
                        if (recibo.fechaEfecto.Length > 1)
                        {
                            Recibo reciboBusqueda = new Recibo();
                            reciboBusqueda = recibosGenerados.Where(b => b.InicioVigencia == DateTime.ParseExact(recibo.fechaEfecto, "yyyyMMdd", CultureInfo.InvariantCulture)).FirstOrDefault();

                            if (reciboBusqueda == null)
                            {
                                for (int nR = 0; nR <= recibo.detalleRecibos.Count() - 1; nR++)
                                {
                                    Recibo reciboSave = new Recibo();
                                    reciboSave.InicioVigencia = DateTime.ParseExact(recibo.detalleRecibos[nR].fechaEfecto, "yyyyMMdd", CultureInfo.InvariantCulture);
                                    reciboSave.FinVigencia = DateTime.ParseExact(recibo.detalleRecibos[nR].fechaVencimiento, "yyyyMMdd", CultureInfo.InvariantCulture);
                                    reciboSave.Numero = numeroRecibo;
                                    reciboSave.NoAsegurado = "1";
                                    reciboSave.PrimaTotal = decimal.Parse(recibo.totalRecibos.ToString(), CultureInfo.InvariantCulture);
                                    reciboSave.PrimaNeta = decimal.Parse(recibo.detalleRecibos[0].importe.ToString(), CultureInfo.InvariantCulture);
                                    reciboSave.Comision = obtenerComision ? decimal.Parse(recibo.detalleRecibos[nR].totalComisiones.ToString(), CultureInfo.InvariantCulture) : 0;
                                    reciboSave.Impuesto = 0;

                                    recibosGenerados.Add(reciboSave);
                                    numeroRecibo++;
                                }
                            }
                        }
                    }
                }
                catch (Exception) { }
            }
            else
            {
                Recibo reciboSave = new Recibo();
                reciboSave.InicioVigencia = inicioVigencia;
                reciboSave.FinVigencia = finVigencia;
                reciboSave.Numero = 1;
                reciboSave.NoAsegurado = "1";
                reciboSave.PrimaNeta = primaNeta;
                reciboSave.PrimaTotal = primaTotal;
                reciboSave.Derecho = derechos;
                reciboSave.Recargo = recargo;
                reciboSave.Comision = 0;
                reciboSave.Impuesto = impuestos;
                recibosGenerados.Add(reciboSave);
            }
            log.Info("termina obtener recibos");
            return recibosGenerados;
        }

        private Endoso ConstruyeObjetoEndosoAlta(List<Recibo> recibosGenerados)
        {
            return new Endoso()
            {
                IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id,
                Fecha = DateTime.Now,
                ValorAnterior = "Alta",
                ValorActual = "Contratación",
                Recibo = recibosGenerados
            };
        }

        private string ObtieneCadenaDatosAReemplazarXML(InformacionEmision infoEmision, Banco banco)
        {
            if (infoEmision.CotizacionAutoGuardar.MediodePago.Equals(0) || infoEmision.CotizacionAutoGuardar.MediodePago.Equals(1))
            {
                banco = new Banco();
                banco.codigoSegTarjeta = infoEmision.Tarjeta.Cvv;
                banco.tipo = "";
                banco.bancoEntidad = infoEmision.IdBanco.ToString().PadLeft(4, '0');
                banco.tipoCuentaTarjeta = infoEmision.Tarjeta.TipoTarjeta;
                banco.mes = infoEmision.Tarjeta.MesVencimiento;
                banco.anio = infoEmision.Tarjeta.AnioVencimiento.ToString() == "1900" ? infoEmision.IdAnio.ToString() : infoEmision.Tarjeta.AnioVencimiento.ToString();
                banco.numTarjeta = infoEmision.Tarjeta.NumeroTarjeta;
                banco.moneda = "MXP";
                banco.titular1 = infoEmision.Tarjeta.TitularTarjeta;
                banco.tipo = ObtieneClaveTipoCuentaBancaria(infoEmision.CotizacionAutoGuardar.MediodePago);
                banco.fechaCorte = "1";
            }
            return Utilidades.Utilidades.ToXMLString<Banco>(banco);
        }

        private List<string> ObtieneListaDatosAReemplazarXML(InformacionEmision infoEmision)
        {
            int medioPago = infoEmision.CotizacionAutoGuardar.MediodePago;
            var listaDatosReemplazo = new List<string>();
            if (medioPago.Equals(0) || medioPago.Equals(1))
            {
                listaDatosReemplazo.Add(infoEmision.Tarjeta.Cvv);
                listaDatosReemplazo.Add(infoEmision.IdBanco.ToString().PadLeft(4, '0'));
                listaDatosReemplazo.Add(infoEmision.Tarjeta.TipoTarjeta);
                listaDatosReemplazo.Add(infoEmision.Tarjeta.MesVencimiento);
                listaDatosReemplazo.Add(infoEmision.Tarjeta.AnioVencimiento.ToString() == "1900" ? infoEmision.IdAnio.ToString() : infoEmision.Tarjeta.AnioVencimiento.ToString());
                listaDatosReemplazo.Add(infoEmision.Tarjeta.NumeroTarjeta);
                listaDatosReemplazo.Add(infoEmision.Tarjeta.TitularTarjeta);
            }
            return listaDatosReemplazo;
        }

        private AseguradoContacto ConstruyeObjetoAseguradoEmision(RequestCotizacionAutos xmlCotizacionSeleccionada, InformacionEmision infoEmision)
        {
            var asegurado = new AseguradoContacto();
            if (infoEmision.EmisionPersonaMoral)
            {
                if (!string.IsNullOrEmpty(xmlCotizacionSeleccionada.conductor.codigoCliente))
                {
                    asegurado.codigoCliente = xmlCotizacionSeleccionada.conductor.codigoCliente;
                }
                else
                    asegurado.codigoCliente = "";
                //asegurado.fechaNacimiento = DateTime.ParseExact(asegurado.rfc.Substring(4, 6), "yyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString("yyyyMMdd");

                infoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == infoEmision.PersonaMoral.Id);
                infoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == infoEmision.PersonaMoralRepresentanteLegal.Id);
                asegurado.nombre = string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "SIN" : string.Format("{0} {1}", QuitarAcentos(infoEmision.PrimerNombre.Trim()), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim()))); //QuitarAcentos(Utilidades.Utilidades.GetNombrePersonaMoral(infoEmision.PersonaMoral.NombreComercial, 1));
                asegurado.apaterno = string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "CONDUCTOR" : QuitarAcentos(infoEmision.ApellidoPaterno);
                asegurado.amaterno = string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "HABITUAL" : QuitarAcentos(infoEmision.ApellidoMaterno);
                asegurado.fechaNacimiento = infoEmision.PersonaMoralRepresentanteLegal.FechaNacimiento.ToString("yyyyMMdd");
                //asegurado.rfc = Utilidades.Utilidades.CalcularRFC(asegurado.nombre, asegurado.apaterno, asegurado.amaterno, infoEmision.PersonaMoralRepresentanteLegal.FechaNacimiento.ToString("dd/MM/yy"));
                asegurado.tipoDocumento = "F";
                asegurado.numeroIdentificacion = string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? infoEmision.PersonaMoralRepresentanteLegal.NumeroIdentificacion : infoEmision.FechaNacimiento.ToString("yyyyMMdd");
                asegurado.tipoPersona = "F";
                asegurado.sexo = "V";
                asegurado.edoCivil = "S";
                asegurado.nacionalidad = "MEX";
                asegurado.paisResidencia = "MEX";
                asegurado.email = infoEmision.PersonaMoralRepresentanteLegal.Correo;
            }
            else
            {
                switch (infoEmision.Convenio.IdCatTipoContratante)
                {
                    case 1:
                        if (!string.IsNullOrEmpty(xmlCotizacionSeleccionada.conductor.codigoCliente))
                        {
                            asegurado.codigoCliente = xmlCotizacionSeleccionada.conductor.codigoCliente;
                        }
                        else
                            asegurado.codigoCliente = "";
                        //asegurado.fechaNacimiento = DateTime.ParseExact(asegurado.rfc.Substring(4, 6), "yyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString("yyyyMMdd");
                        asegurado.nombre = "SIN"; //QuitarAcentos(Utilidades.Utilidades.GetNombrePersonaMoral(infoEmision.Empresa.NombreComercial, 1));
                        asegurado.apaterno = "CONDUCTOR";
                        asegurado.amaterno = "HABITUAL";/*QuitarAcentos(Utilidades.Utilidades.GetNombrePersonaMoral(infoEmision.Empresa.NombreComercial, 3));*/
                        asegurado.fechaNacimiento = infoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("yyyyMMdd");
                        //asegurado.rfc = Utilidades.Utilidades.CalcularRFC(asegurado.nombre, asegurado.apaterno, asegurado.amaterno, infoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yy"));
                        //asegurado.nacionalidad = "MEX";
                        //asegurado.paisResidencia = "MEX";
                        asegurado.tipoDocumento = "F";
                        asegurado.numeroIdentificacion = infoEmision.Empresa.RepresentanteLegal.NumeroIdentificacion;
                        //asegurado.giro = ObtieneClaveGiroEmpresa(infoEmision.PersonaMoral.IdCatGiroBase);
                        asegurado.tipoPersona = "F";
                        asegurado.codigoCliente = "";
                        asegurado.sexo = "V";
                        asegurado.edoCivil = "S";
                        asegurado.nacionalidad = "MEX";
                        asegurado.paisResidencia = "MEX";
                        asegurado.email = infoEmision.Empresa.RepresentanteLegal.Correo;
                        break;
                    default:
                        if (!string.IsNullOrEmpty(xmlCotizacionSeleccionada.conductor.codigoCliente))
                        {
                            asegurado.codigoCliente = xmlCotizacionSeleccionada.conductor.codigoCliente;
                        }
                        else
                        {
                            asegurado.codigoCliente = "";
                            asegurado.tipoDocumento = xmlCotizacionSeleccionada.conductor.tipoDocumento;
                            asegurado.numeroIdentificacion = xmlCotizacionSeleccionada.conductor.numeroIdentificacion;
                            asegurado.edoCivil = xmlCotizacionSeleccionada.conductor.edoCivil;
                            asegurado.sexo = string.IsNullOrEmpty(xmlCotizacionSeleccionada.conductor.sexo) ? infoEmision.DetalleUsuario.GENERO.ToLower().Equals("masculino") ? "V" : "M" : xmlCotizacionSeleccionada.conductor.sexo;
                            asegurado.rfc = infoEmision.DatosUsuario.RFC;
                            asegurado.tipoPersona = "F";

                            //if (!infoEmision.ConductorHabitual)
                            //{
                            //    asegurado.apaterno = string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.ApellidoPaterno.Trim());
                            //    asegurado.amaterno = string.IsNullOrEmpty(infoEmision.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.ApellidoMaterno.Trim());
                            //    asegurado.nombre = string.Format("{0} {1}", QuitarAcentos(infoEmision.PrimerNombre.Trim()), string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim()));
                            //    asegurado.fechaNacimiento = DateTime.ParseExact(infoEmision.FechaNacimiento.ToString(), "yyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString("yyyyMMdd");
                            //}
                            //else
                            //{ 
                            if (infoEmision.Convenio.IdCatTipoContratante.Equals(1) || infoEmision.Convenio.IdCatTipoContratante.Equals(5))
                            {
                                asegurado.fechaNacimiento = DateTime.ParseExact(asegurado.rfc.Substring(4, 6), "yyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString("yyyyMMdd");
                            }

                            else
                            {
                                //var fechanacimiento = infoEmision.FechaNacimiento.ToString("yyMMdd");
                                //fechanacimiento = fechanacimiento != asegurado.rfc.Substring(4, 6) ? infoEmision.DetalleUsuario.FECHANACIMIENTO != null ? infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("yyyyMMdd") : DateTime.ParseExact(fechanacimiento, "yyyyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString() : DateTime.ParseExact(fechanacimiento, "yyyyMMdd", CultureInfo.GetCultureInfo("en-US")).ToString();
                                asegurado.fechaNacimiento = infoEmision.FechaNacimiento.ToString("yyyyMMdd");
                            }

                            asegurado.apaterno = string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.ApellidoPaterno.Trim());
                            asegurado.amaterno = string.IsNullOrEmpty(infoEmision.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.ApellidoMaterno.Trim());
                            asegurado.nombre = string.Format("{0} {1}", QuitarAcentos(infoEmision.PrimerNombre.Trim()), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim())));
                            //}
                        }
                        break;
                }
            }

            return asegurado;
        }

        private GNPInfoServiceCotizarEmitir.Contratante ConstruyeObjetoContratanteEmision(InformacionEmision infoEmision, RequestCotizacionAutos xmlCotizacionSeleccionada, string codigoPostal, LocktonModel.db.CodigoPostal catCodigoPostal, ConfiguracionEmpresa ConfigEmpresa, string convenioCodigoCliente)
        {
            var contratante = new GNPInfoServiceCotizarEmitir.Contratante();
            List<Telefono> telefonos = new List<Telefono>();

            if (infoEmision.EmisionPersonaMoral)
            {

                infoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == infoEmision.PersonaMoral.Id);
                infoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == infoEmision.PersonaMoralRepresentanteLegal.Id);

                var catCodigoPostalPM = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == infoEmision.PersonaMoral.Direccion.CodigoPostal);

                contratante.tipoPersona = "J"; //Fisica F - Moral J;
                contratante.codigoCliente = convenioCodigoCliente ?? "";
                contratante.rfc = infoEmision.PersonaMoral.RFC;
                contratante.email = infoEmision.PersonaMoralRepresentanteLegal.Correo;
                contratante.giro = ObtieneClaveGiroEmpresa(infoEmision.PersonaMoral.IdCatGiroBase);
                contratante.fechaConstitucion = infoEmision.PersonaMoral.FechaConstitucion?.ToString("yyyyMMdd");
                contratante.nacionalidad = "MEX";
                contratante.paisResidencia = "MEX";
                contratante.razonSocial = infoEmision.PersonaMoral.RazonSocial;
                contratante.tipoDocumento = "F";
                contratante.numeroIdentificacion = infoEmision.PersonaMoral.RFC;

                contratante.representanteLegal = new GNPInfoServiceCotizarEmitir.RepresentanteLegal();
                contratante.representanteLegal.nombre = infoEmision.PersonaMoralRepresentanteLegal.Nombre;
                contratante.representanteLegal.amaterno = infoEmision.PersonaMoralRepresentanteLegal.ApellidoMaterno;
                contratante.representanteLegal.apaterno = infoEmision.PersonaMoralRepresentanteLegal.ApellidoPaterno;
                contratante.representanteLegal.rfc = Utilidades.Utilidades.CalcularRFC(contratante.representanteLegal.nombre, contratante.representanteLegal.apaterno, contratante.representanteLegal.amaterno, infoEmision.PersonaMoralRepresentanteLegal.FechaNacimiento.ToString("dd/MM/yy"));
                contratante.representanteLegal.fechaNacimiento = infoEmision.PersonaMoralRepresentanteLegal.FechaNacimiento.ToString("yyyyMMdd");
                contratante.representanteLegal.tipoDocumento = "F";
                contratante.representanteLegal.numeroIdentificacion = "9999999999";
                contratante.representanteLegal.edoCivil = "S";
                contratante.representanteLegal.sexo = "V";
                contratante.representanteLegal.paisResidencia = "MEX";
                contratante.representanteLegal.ocupacion = "1272";
                contratante.representanteLegal.nacionalidad = "MEX";

                contratante.domicilio = new Domicilio();
                contratante.domicilio.tipoUbicacion = "CL";
                contratante.domicilio.ubicacion = QuitarAcentos(infoEmision.PersonaMoral.Direccion.Calle);
                contratante.domicilio.numero = infoEmision.PersonaMoral.Direccion.NumeroExt;
                contratante.domicilio.numeroInterior = infoEmision.PersonaMoral.Direccion.NumeroInt;
                contratante.domicilio.paisResidencia = "MEX";

                contratante.domicilio.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                if (infoEmision.Convenio.ZonaCirculacion == 2)
                {
                    var _cpConvenio = infoEmision.Convenio.CodigoPostal.ToString().PadLeft(5, '0');
                    var _catCodigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == _cpConvenio);

                    contratante.domicilio.codigoPostal.cp = _cpConvenio;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                    contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(_cpConvenio);// _catCodigoPostal.CatEstadosRepublica.Clave;
                    contratante.domicilio.codigoPostal.colonia = QuitarAcentos(_catCodigoPostal.Asentamiento);
                }
                else
                {
                    contratante.domicilio.codigoPostal.cp = infoEmision.PersonaMoral.Direccion.CodigoPostal;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                    contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(infoEmision.PersonaMoral.Direccion.CodigoPostal);
                    contratante.domicilio.codigoPostal.colonia = QuitarAcentos(infoEmision.PersonaMoral.Direccion.CatCodigoPostal.Asentamiento);
                }
                contratante.domicilio.telefonos = new Telefono[] { };
                telefonos.Add(new Telefono { numero = infoEmision.PersonaMoralRepresentanteLegal.Telefono.Substring(2), claveLada = infoEmision.PersonaMoralRepresentanteLegal.Telefono.Substring(0, 2), pais = "52" });
                telefonos.Add(new Telefono { numero = infoEmision.PersonaMoralRepresentanteLegal.Telefono.Substring(2), claveLada = infoEmision.PersonaMoralRepresentanteLegal.Telefono.Substring(0, 2), pais = "52" });
                contratante.domicilio.telefonos = telefonos.ToArray();

            }else if (ConfigEmpresa.IdTipoDeNegocio == 4)
            {
                switch (infoEmision.Convenio.IdCatTipoContratante)
                {
                    case 1:
                    case 5:// Datos Fiscales Empresa
                        contratante.tipoPersona = "J"; //Fisica F - Moral J;
                        contratante.codigoCliente = convenioCodigoCliente ?? "";
                        contratante.rfc = infoEmision.Empresa.RFC;
                        contratante.email = infoEmision.Empresa.Ejecutivo.Correo;
                        contratante.giro = ObtieneClaveGiroEmpresa(infoEmision.Empresa.IdCatGiroBase);
                        contratante.fechaConstitucion = infoEmision.Empresa.FechaConstitucion?.ToString("yyyyMMdd");
                        contratante.nacionalidad = "MEX";
                        contratante.paisResidencia = "MEX";
                        contratante.razonSocial = infoEmision.Empresa.RazonSocial;
                        contratante.tipoDocumento = "R";
                        contratante.numeroIdentificacion = infoEmision.Empresa.RFC;

                        contratante.representanteLegal = new GNPInfoServiceCotizarEmitir.RepresentanteLegal();
                        contratante.representanteLegal.nombre = infoEmision.Empresa.RepresentanteLegal.Nombre;
                        contratante.representanteLegal.amaterno = infoEmision.Empresa.RepresentanteLegal.ApellidoMaterno;
                        contratante.representanteLegal.apaterno = infoEmision.Empresa.RepresentanteLegal.ApellidoPaterno;
                        contratante.representanteLegal.rfc = Utilidades.Utilidades.CalcularRFC(contratante.representanteLegal.nombre, contratante.representanteLegal.apaterno, contratante.representanteLegal.amaterno, infoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yy"));
                        contratante.representanteLegal.fechaNacimiento = infoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("yyyyMMdd");
                        contratante.representanteLegal.tipoDocumento = "F";
                        contratante.representanteLegal.numeroIdentificacion = "9999999999";
                        contratante.representanteLegal.edoCivil = "S";
                        contratante.representanteLegal.sexo = "V";
                        contratante.representanteLegal.paisResidencia = "MEX";
                        contratante.representanteLegal.ocupacion = "1272";
                        contratante.representanteLegal.nacionalidad = "MEX";

                        contratante.domicilio = new Domicilio();
                        contratante.domicilio.tipoUbicacion = "CL";
                        contratante.domicilio.ubicacion = QuitarAcentos(infoEmision.Empresa.Direccion.Calle);
                        contratante.domicilio.numero = infoEmision.Empresa.Direccion.NumeroExt;
                        contratante.domicilio.numeroInterior = infoEmision.Empresa.Direccion.NumeroInt;
                        contratante.domicilio.paisResidencia = "MEX";

                        contratante.domicilio.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                        if (infoEmision.Convenio.ZonaCirculacion == 2)
                        {
                            var _cpConvenio = infoEmision.Convenio.CodigoPostal.ToString().PadLeft(5, '0');
                            var _catCodigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == _cpConvenio);

                            contratante.domicilio.codigoPostal.cp = _cpConvenio;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                            contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(_cpConvenio);//_catCodigoPostal.CatEstadosRepublica.Clave;
                            contratante.domicilio.codigoPostal.colonia = QuitarAcentos(_catCodigoPostal.Asentamiento);
                        }
                        else
                        {
                            contratante.domicilio.codigoPostal.cp = infoEmision.Empresa.Direccion.CodigoPostal;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                            contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(infoEmision.Empresa.Direccion.CodigoPostal);
                            contratante.domicilio.codigoPostal.colonia = QuitarAcentos(infoEmision.Empresa.Direccion.CatCodigoPostal.Asentamiento);
                        }
                        contratante.domicilio.telefonos = new Telefono[] { };
                        telefonos.Add(new Telefono { numero = infoEmision.Empresa.TelefonoGral.Substring(2), claveLada = infoEmision.Empresa.TelefonoGral.Substring(0, 2), pais = "52" });
                        telefonos.Add(new Telefono { numero = infoEmision.Empresa.TelefonoGral.Substring(2), claveLada = infoEmision.Empresa.TelefonoGral.Substring(0, 2), pais = "52" });
                        contratante.domicilio.telefonos = telefonos.ToArray();

                        break;
                    default: // Datos Fiscales Empleado con donmicilio empresa
                        contratante.tipoPersona = "F"; //Fisica F - Moral J;
                        contratante.codigoCliente = xmlCotizacionSeleccionada.conductor.codigoCliente;
                        contratante.edoCivil = xmlCotizacionSeleccionada.conductor.edoCivil;
                        contratante.rfc =
                            string.IsNullOrEmpty(infoEmision.DatosUsuario.RFC) ?
                            Utilidades.Utilidades.CalcularRFC(
                                string.Format("{0} {1}", infoEmision.PrimerNombre.Trim(), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim()))),
                                infoEmision.ApellidoPaterno,
                                infoEmision.ApellidoMaterno,
                                infoEmision.FechaNacimiento.ToString("dd/MM/yy")
                                ) :
                                infoEmision.DatosUsuario.RFC;
                        contratante.email = infoEmision.ConfirmaEmail;
                        contratante.sexo = string.IsNullOrEmpty(xmlCotizacionSeleccionada.conductor.sexo) ? infoEmision.DetalleUsuario.GENERO.ToLower().Equals("masculino") ? "V" : "M" : xmlCotizacionSeleccionada.conductor.sexo;
                        contratante.numeroIdentificacion = xmlCotizacionSeleccionada.conductor.numeroIdentificacion;
                        contratante.tipoDocumento = xmlCotizacionSeleccionada.conductor.tipoDocumento;
                        contratante.ocupacion = "1272";
                        contratante.fechaNacimiento = infoEmision.FechaNacimiento.ToString("yyyyMMdd");
                        contratante.nombre = string.Format("{0} {1}", infoEmision.PrimerNombre.Trim(), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim())));
                        contratante.apaterno = (string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.ApellidoPaterno.Trim()));
                        contratante.amaterno = (string.IsNullOrEmpty(infoEmision.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.ApellidoMaterno.Trim()));
                        contratante.nacionalidad = "MEX";
                        contratante.paisResidencia = "MEX";
                        contratante.domicilio = new Domicilio();
                        contratante.domicilio.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();

                        if (infoEmision.Convenio.ZonaCirculacion == 2)
                        {
                            var _cpConvenio = infoEmision.Convenio.CodigoPostal.ToString().PadLeft(5, '0');
                            var _catCodigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == _cpConvenio);

                            contratante.domicilio.codigoPostal.cp = _cpConvenio;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                            contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(_cpConvenio);//_catCodigoPostal.CatEstadosRepublica.Clave;
                            contratante.domicilio.codigoPostal.colonia = QuitarAcentos(_catCodigoPostal.Asentamiento);
                        }
                        else
                        {
                            contratante.domicilio.codigoPostal.cp = infoEmision.Empresa.Direccion.CodigoPostal;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                            contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(infoEmision.Empresa.Direccion.CodigoPostal);
                            contratante.domicilio.codigoPostal.colonia = QuitarAcentos(infoEmision.Empresa.Direccion.CatCodigoPostal.Asentamiento);
                        }                      
                      

                        contratante.domicilio.paisResidencia = "MEX";
                        contratante.domicilio.telefonos = new Telefono[] { };
                        telefonos.Add(new Telefono { numero = infoEmision.TelefonoCel.Substring(2), claveLada = infoEmision.TelefonoCel.Substring(0, 2), pais = "52" });
                        telefonos.Add(new Telefono { numero = infoEmision.TelefonoCel.Substring(2), claveLada = infoEmision.TelefonoCel.Substring(0, 2), pais = "52" });
                        contratante.domicilio.telefonos = telefonos.ToArray();
                        break;                   
                }
            }
            else
            {
                switch (infoEmision.Convenio.IdCatTipoContratante)
                {
                    case 1:
                    case 5:// Datos Fiscales Empresa
                        contratante.tipoPersona = "J"; //Fisica F - Moral J;
                        contratante.codigoCliente = convenioCodigoCliente ?? "";
                        contratante.rfc = infoEmision.Empresa.RFC;
                        contratante.email = infoEmision.Empresa.Ejecutivo.Correo;
                        contratante.giro = ObtieneClaveGiroEmpresa(infoEmision.Empresa.IdCatGiroBase);
                        contratante.fechaConstitucion = infoEmision.Empresa.FechaConstitucion?.ToString("yyyyMMdd");
                        contratante.nacionalidad = "MEX";
                        contratante.paisResidencia = "MEX";
                        contratante.razonSocial = infoEmision.Empresa.RazonSocial;
                        contratante.tipoDocumento = "R";
                        contratante.numeroIdentificacion = infoEmision.Empresa.RFC;

                        contratante.representanteLegal = new GNPInfoServiceCotizarEmitir.RepresentanteLegal();
                        contratante.representanteLegal.nombre = infoEmision.Empresa.RepresentanteLegal.Nombre;
                        contratante.representanteLegal.amaterno = infoEmision.Empresa.RepresentanteLegal.ApellidoMaterno;
                        contratante.representanteLegal.apaterno = infoEmision.Empresa.RepresentanteLegal.ApellidoPaterno;
                        contratante.representanteLegal.rfc = Utilidades.Utilidades.CalcularRFC(contratante.representanteLegal.nombre, contratante.representanteLegal.apaterno, contratante.representanteLegal.amaterno, infoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("dd/MM/yy"));
                        contratante.representanteLegal.fechaNacimiento = infoEmision.Empresa.RepresentanteLegal.FechaNacimiento.ToString("yyyyMMdd");
                        contratante.representanteLegal.tipoDocumento = "F";
                        contratante.representanteLegal.numeroIdentificacion = "9999999999";
                        contratante.representanteLegal.edoCivil = "S";
                        contratante.representanteLegal.sexo = "V";
                        contratante.representanteLegal.paisResidencia = "MEX";
                        contratante.representanteLegal.ocupacion = "1272";
                        contratante.representanteLegal.nacionalidad = "MEX";

                        contratante.domicilio = new Domicilio();
                        contratante.domicilio.tipoUbicacion = "CL";
                        contratante.domicilio.ubicacion = QuitarAcentos(infoEmision.Empresa.Direccion.Calle);
                        contratante.domicilio.numero = infoEmision.Empresa.Direccion.NumeroExt;
                        contratante.domicilio.numeroInterior = infoEmision.Empresa.Direccion.NumeroInt;
                        contratante.domicilio.paisResidencia = "MEX";

                        contratante.domicilio.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                        if (infoEmision.Convenio.ZonaCirculacion == 2)
                        {
                            var _cpConvenio = infoEmision.Convenio.CodigoPostal.ToString().PadLeft(5, '0');
                            var _catCodigoPostal = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == _cpConvenio);

                            contratante.domicilio.codigoPostal.cp = _cpConvenio;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                            contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(_cpConvenio);//_catCodigoPostal.CatEstadosRepublica.Clave;
                            contratante.domicilio.codigoPostal.colonia = QuitarAcentos(_catCodigoPostal.Asentamiento);
                        }
                        else
                        {
                            contratante.domicilio.codigoPostal.cp = infoEmision.Empresa.Direccion.CodigoPostal;//codigoPostal; //InfoEmision.DatosUsuario.Direccion.CodigoPostal;
                            contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(infoEmision.Empresa.Direccion.CodigoPostal);
                            contratante.domicilio.codigoPostal.colonia = QuitarAcentos(infoEmision.Empresa.Direccion.CatCodigoPostal.Asentamiento);
                        }
                        contratante.domicilio.telefonos = new Telefono[] { };
                        telefonos.Add(new Telefono { numero = infoEmision.Empresa.TelefonoGral.Substring(2), claveLada = infoEmision.Empresa.TelefonoGral.Substring(0, 2), pais = "52" });
                        telefonos.Add(new Telefono { numero = infoEmision.Empresa.TelefonoGral.Substring(2), claveLada = infoEmision.Empresa.TelefonoGral.Substring(0, 2), pais = "52" });
                        contratante.domicilio.telefonos = telefonos.ToArray();

                        break;
                    case 2: // Datos Fiscales Empleado 
                        contratante.tipoPersona = "F"; //Fisica F - Moral J;
                        contratante.codigoCliente = xmlCotizacionSeleccionada.conductor.codigoCliente;
                        contratante.edoCivil = xmlCotizacionSeleccionada.conductor.edoCivil;
                        contratante.rfc =
                            string.IsNullOrEmpty(infoEmision.DatosUsuario.RFC) ?
                            Utilidades.Utilidades.CalcularRFC(
                                string.Format("{0} {1}", infoEmision.PrimerNombre.Trim(), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim()))),
                                infoEmision.ApellidoPaterno,
                                infoEmision.ApellidoMaterno,
                                infoEmision.FechaNacimiento.ToString("dd/MM/yy")
                                ) :
                                infoEmision.DatosUsuario.RFC;
                        contratante.email = infoEmision.ConfirmaEmail;
                        contratante.sexo = string.IsNullOrEmpty(xmlCotizacionSeleccionada.conductor.sexo) ? infoEmision.DetalleUsuario.GENERO.ToLower().Equals("masculino") ? "V" : "M" : xmlCotizacionSeleccionada.conductor.sexo;
                        contratante.numeroIdentificacion = xmlCotizacionSeleccionada.conductor.numeroIdentificacion;
                        contratante.tipoDocumento = xmlCotizacionSeleccionada.conductor.tipoDocumento;
                        contratante.ocupacion = "1272";
                        contratante.fechaNacimiento = infoEmision.FechaNacimiento.ToString("yyyyMMdd");
                        contratante.nombre = string.Format("{0} {1}", infoEmision.PrimerNombre.Trim(), (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim())));
                        contratante.apaterno = (string.IsNullOrEmpty(infoEmision.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.ApellidoPaterno.Trim()));
                        contratante.amaterno = (string.IsNullOrEmpty(infoEmision.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.ApellidoMaterno.Trim()));
                        contratante.nacionalidad = "MEX";
                        contratante.paisResidencia = "MEX";
                        contratante.domicilio = new Domicilio();
                        contratante.domicilio.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                        contratante.domicilio.codigoPostal.cp = infoEmision.DatosUsuario.Direccion.CodigoPostal;
                        contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(infoEmision.DatosUsuario.Direccion.CodigoPostal);// infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
                        contratante.domicilio.codigoPostal.colonia = QuitarAcentos(infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento);
                        contratante.domicilio.tipoUbicacion = "CL";

                        //if (infoEmision.DetalleUsuario.Direccion != null)
                        //{
                        //    contratante.domicilio.ubicacion = QuitarAcentos(infoEmision.DetalleUsuario.Direccion.Calle);
                        //    contratante.domicilio.numero = infoEmision.DetalleUsuario.Direccion.NumeroExt;
                        //    contratante.domicilio.numeroInterior = infoEmision.DetalleUsuario.Direccion.NumeroInt;
                        //}
                        //else
                        //{
                        contratante.domicilio.ubicacion = QuitarAcentos(infoEmision.DatosUsuario.Direccion.Calle);
                        contratante.domicilio.numero = infoEmision.DatosUsuario.Direccion.NumeroExt;
                        contratante.domicilio.numeroInterior = infoEmision.DatosUsuario.Direccion.NumeroInt;
                        //}

                        contratante.domicilio.paisResidencia = "MEX";
                        contratante.domicilio.telefonos = new Telefono[] { };
                        telefonos.Add(new Telefono { numero = infoEmision.TelefonoCel.Substring(2), claveLada = infoEmision.TelefonoCel.Substring(0, 2), pais = "52" });
                        telefonos.Add(new Telefono { numero = infoEmision.TelefonoCel.Substring(2), claveLada = infoEmision.TelefonoCel.Substring(0, 2), pais = "52" });
                        contratante.domicilio.telefonos = telefonos.ToArray();
                        break;
                    default:
                        contratante.tipoPersona = "F";
                        contratante.codigoCliente = convenioCodigoCliente ?? "";
                        contratante.edoCivil = xmlCotizacionSeleccionada.conductor.edoCivil;
                        contratante.rfc = infoEmision.EsFlotilla ? LocktonServicios.Utilidades.Utilidades.CalcularRFC(infoEmision.DetalleUsuario.Nombre + " " + infoEmision.DetalleUsuario.NombreDos, infoEmision.DetalleUsuario.ApellidoPaterno, infoEmision.DetalleUsuario.ApellidoMaterno, infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("dd/MM/yy")) : infoEmision.DatosUsuario.RFC;
                        contratante.email = infoEmision.ConfirmaEmail;
                        contratante.sexo = string.IsNullOrEmpty(xmlCotizacionSeleccionada.conductor.sexo) ? infoEmision.DetalleUsuario.GENERO.ToLower().Equals("masculino") ? "V" : "M" : xmlCotizacionSeleccionada.conductor.sexo;
                        contratante.ocupacion = "ADMINISTRADOR";
                        contratante.numeroIdentificacion = xmlCotizacionSeleccionada.conductor.numeroIdentificacion;
                        contratante.tipoDocumento = xmlCotizacionSeleccionada.conductor.tipoDocumento;
                        contratante.ocupacion = "1272";

                        contratante.fechaNacimiento = infoEmision.FechaNacimiento.ToString("yyyyMMdd");// infoEmision.DetalleUsuario.FECHANACIMIENTO.ToString("yyyyMMdd");
                        contratante.nombre = infoEmision.EsFlotilla ? string.Format("{0} {1}", infoEmision.DetalleUsuario.Nombre.Trim(), (string.IsNullOrEmpty(infoEmision.DetalleUsuario.NombreDos) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.NombreDos.Trim()))) : string.Format("{0} {1}", infoEmision.PrimerNombre, (string.IsNullOrEmpty(infoEmision.SegundoNombre) ? "" : QuitarAcentos(infoEmision.SegundoNombre.Trim())));
                        contratante.apaterno = infoEmision.EsFlotilla ? (string.IsNullOrEmpty(infoEmision.DetalleUsuario.ApellidoPaterno) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.ApellidoPaterno.Trim())) : QuitarAcentos(infoEmision.ApellidoPaterno);
                        contratante.amaterno = infoEmision.EsFlotilla ? (string.IsNullOrEmpty(infoEmision.DetalleUsuario.ApellidoMaterno) ? "" : QuitarAcentos(infoEmision.DetalleUsuario.ApellidoMaterno.Trim())) : QuitarAcentos(infoEmision.ApellidoMaterno);
                        contratante.nacionalidad = "MEX";
                        contratante.paisResidencia = "MEX";
                        contratante.domicilio = new Domicilio();
                        contratante.domicilio.codigoPostal = new GNPInfoServiceCotizarEmitir.CodigoPostal();
                        contratante.domicilio.codigoPostal.cp = infoEmision.DatosUsuario.Direccion.CodigoPostal;
                        contratante.domicilio.codigoPostal.estado = ObtenerClaveEstado(infoEmision.DatosUsuario.Direccion.CodigoPostal);// infoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
                        contratante.domicilio.codigoPostal.colonia = QuitarAcentos(infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento);
                        contratante.domicilio.tipoUbicacion = "CL";// = catCodigoPostal.CatEstadosRepublica.Clave;// InfoEmision.DatosUsuario.Direccion.CatEstadosRepublica.Clave;
                        contratante.domicilio.ubicacion = infoEmision.EsFlotilla ? QuitarAcentos(infoEmision.Empresa.Direccion.Calle) : QuitarAcentos(infoEmision.DatosUsuario.Direccion.Calle);
                        contratante.domicilio.numero = infoEmision.EsFlotilla ? infoEmision.Empresa.Direccion.NumeroExt : infoEmision.DatosUsuario.Direccion.NumeroExt;
                        contratante.domicilio.numeroInterior = infoEmision.EsFlotilla ? infoEmision.Empresa.Direccion.NumeroInt : infoEmision.DatosUsuario.Direccion.NumeroInt;
                        contratante.domicilio.paisResidencia = "MEX";
                        contratante.domicilio.telefonos = new Telefono[] { };
                        telefonos.Add(new Telefono { numero = infoEmision.TelefonoCel.Substring(2), claveLada = infoEmision.TelefonoCel.Substring(0, 2), pais = "52" });
                        telefonos.Add(new Telefono { numero = infoEmision.TelefonoCel.Substring(2), claveLada = infoEmision.TelefonoCel.Substring(0, 2), pais = "52" });
                        contratante.domicilio.telefonos = telefonos.ToArray();
                        break;
                }

            }
            return contratante;
        }

        private string ObtieneClaveGiroEmpresa(int? idCatGiroBase)
        {
            //-------------Catálogo GNP------------
            //100100  Agricultura, ganadería, aprovechamiento forestal, pesca y caza
            //100101  Minería y extracción de petróleo
            //100102  Electricidad, agua y suministro de gas
            //100103  Construcción
            //100104  Industria manufacturera
            //100105  Comercio al mayoreo
            //100106  Comercio al menudeo
            //100107  Transportes, comunicaciones, correo y almacenamientox
            //100108  Información en medios masivos
            //100109  Servicios financieros y de seguros
            //100110  Servicios inmobiliarios y de alquiler de bienes, muebles e intangibles
            //100111  Servicios profesionales, científicos y técnicos
            //100112  Dirección de corporativos y empresas
            //100113  Servicios de apoyo a los negocios(Administración, Outsourcing)
            //100114  Servicios educativos
            //100115  Servicios de salud y de asistencia social
            //100116  Servicios culturales, deportivos y otros servicios recreativos
            //100117  Asociaciones religiosas
            //100118  Servicios de hospedaje y de preparación de alimentos y bebidas
            //100119  Otros servicios(excepto actividades del gobierno)
            //100120  Asociaciones militares
            //100121  Actividades del gobierno y de organismos internacionales y extraterritoriales
            //100122  Cámaras y asociaciones empresariales
            //100123  Otro

            string giro = string.Empty;

            if (idCatGiroBase != null && idCatGiroBase > 0)
            {
                switch (idCatGiroBase)
                {

                    //Industrial
                    case 2:
                        giro = "100104";
                        break;
                    //Comercial
                    case 3:
                        giro = "100105";
                        break;
                    //Servicios
                    case 4:
                        giro = "100111";
                        break;
                    //Servicios Públicos
                    case 6:
                        giro = "100121";
                        break;
                    //Servicios Privados
                    case 7:
                        giro = "100113";
                        break;
                    //Transporte
                    case 8:
                        giro = "100107";
                        break;
                    //Turismo
                    case 9:
                        giro = "100118";
                        break;
                    //Instituciones Financieras
                    case 10:
                        giro = "100109";
                        break;
                    //Educacion
                    case 11:
                        giro = "100114";
                        break;
                    //Salubridad
                    case 13:
                        giro = "100115";
                        break;
                    //Fianzas y Seguros
                    case 14:
                        giro = "100109";
                        break;
                    default:
                        giro = "100119";
                        break;
                }
            }
            else
            {
                giro = "100123"; //otro
            }
            ;

            return giro;
        }

        private void ColocaFormaDeCobro(RequestEmisionAutosAPI reqEmiAuto, int mediodePago, bool emitirComoIntermediario = false)
        {
            //CAT: Fuerza el canal intermediario cuando los datos bancarios se instalaran despues de la emision.
            if (!emitirComoIntermediario && (mediodePago == 0 || mediodePago == 1))
            {
                reqEmiAuto.canalCobro = "BC";
                reqEmiAuto.canalCobroSubsecuentes = "BC";
            }
            else
            {
                reqEmiAuto.canalCobro = "IN";
                reqEmiAuto.canalCobroSubsecuentes = "IN";
            }
        }

        private GNPInfoServiceCotizarEmitir.Vehiculo ConstruyeObjetoVehiculoEmision(InformacionEmision infoEmision, RequestCotizacionAutos xmlCotizacionSeleccionada, List<Coberturas> coberturasPaquete)
        {
            var nuevoVehiculo = new GNPInfoServiceCotizarEmitir.Vehiculo();
            nuevoVehiculo = xmlCotizacionSeleccionada.vehiculo;

            nuevoVehiculo.numeroMotor = infoEmision.NumeroMotor;
            nuevoVehiculo.numeroSerie = infoEmision.NumeroSerie;
            nuevoVehiculo.placas = infoEmision.Placas;
            foreach (Coberturas paquete in coberturasPaquete)
            {
                if (paquete.Codigo.Contains("1289") || paquete.Codigo.Contains("1288") || paquete.Codigo.Contains("916"))
                {
                    nuevoVehiculo.tipoValorVehiculo = ObtieneClaveTipoValorVehiculo(paquete.Cobertura);
                }
            }
            nuevoVehiculo.valorConvenidoVehiculo = !string.IsNullOrEmpty(nuevoVehiculo.valorReferencia) ? nuevoVehiculo.valorReferencia : nuevoVehiculo.valorConvenidoVehiculo;

            if (!string.IsNullOrEmpty(xmlCotizacionSeleccionada.vehiculo.valorFactura) && infoEmision.CotizacionAutoGuardar.TipoVehiculo == "1")
                nuevoVehiculo.tipoValorVehiculo = "02";

            return nuevoVehiculo;
        }

        private string ObtieneClaveTipoValorVehiculo(string cobertura)
        {
            string clave = string.Empty;

            if (string.IsNullOrEmpty(cobertura))
                return string.Empty;

            switch (cobertura.ToLower())
            {
                case "valor comercial":
                    clave = "01";
                    break;
                case "valor convenido":
                    clave = "03";
                    break;
                case "valor declarado":
                    clave = "05";
                    break;
                default:
                    clave = "01";
                    break;
            }

            return clave;
        }

        private string ObtieneCodigoPostalParaEmision(InformacionEmision infoEmision)
        {
            string codigoPostal = string.Empty;
            if (!infoEmision.ConductorHabitual)
            {
                if (infoEmision.DatosUsuario.Direccion != null)
                {
                    codigoPostal = infoEmision.DatosUsuario.Direccion.CodigoPostal ?? infoEmision.Empresa.Direccion.CodigoPostal;
                }
                else if (infoEmision.DetalleUsuario.Direccion != null)
                {
                    codigoPostal = infoEmision.DetalleUsuario.Direccion.CodigoPostal ?? infoEmision.Empresa.Direccion.CodigoPostal;
                }
                else
                {
                    codigoPostal = infoEmision.Empresa.Direccion.CodigoPostal;
                }
            }
            else
            {
                codigoPostal = infoEmision.Empresa.Direccion.CodigoPostal;
            }
            return codigoPostal;
        }

        private void AgregaDatosBancariosContratante(GNPInfoServiceCotizarEmitir.Contratante contratante, InformacionEmision infoEmision)
        {
            int medioPago = infoEmision.CotizacionAutoGuardar.MediodePago;

            if (medioPago.Equals(0) || medioPago.Equals(1))
            {
                contratante.banco = new Banco();
                contratante.banco.codigoSegTarjeta = infoEmision.Tarjeta.Cvv;
                contratante.banco.tipo = "";
                contratante.banco.bancoEntidad = infoEmision.IdBanco.ToString().PadLeft(4, '0');
                contratante.banco.tipoCuentaTarjeta = ObtieneTipoCuentaTarjeta(infoEmision.Tarjeta.TipoTarjeta);
                contratante.banco.mes = infoEmision.Tarjeta.MesVencimiento;
                contratante.banco.anio = infoEmision.Tarjeta.AnioVencimiento.ToString() == "1900" ? infoEmision.IdAnio.ToString() : infoEmision.Tarjeta.AnioVencimiento.ToString();
                contratante.banco.numTarjeta = infoEmision.Tarjeta.NumeroTarjeta;
                contratante.banco.moneda = "MXP";
                contratante.banco.titular1 = infoEmision.Tarjeta.TitularTarjeta;
                contratante.banco.tipo = ObtieneClaveTipoCuentaBancaria(medioPago);
                contratante.banco.fechaCorte = "1";

                if (medioPago.Equals(0))
                    contratante.banco.fechaVencimiento = String.Concat(contratante.banco.mes, contratante.banco.anio);
                else
                    contratante.banco.fechaVencimiento = String.Concat("01", contratante.banco.mes, contratante.banco.anio);
            }
        }

        //CAT: Construye exclusivamente los datos que requiere el servicio existente de domiciliacion GNP.
        private DatosCobranza ConstruyeDatosCobranzaDomiciliacion(InformacionEmision infoEmision, string numeroPoliza)
        {
            int anioVencimiento = infoEmision.IdAnio > 0
                ? infoEmision.IdAnio
                : infoEmision.Tarjeta.AnioVencimiento;
            string anio = anioVencimiento.ToString();

            if (anio.Length > 2)
                anio = anio.Substring(anio.Length - 2);

            return new DatosCobranza
            {
                NumeroPoliza = numeroPoliza,
                NumeroTarjeta = infoEmision.Tarjeta.NumeroTarjeta,
                MesVencimiento = infoEmision.Tarjeta.MesVencimiento.PadLeft(2, '0'),
                AnoVencimiento = anio,
                NombreCompleto = infoEmision.Tarjeta.TitularTarjeta,
                TipoTarjeta = infoEmision.CotizacionAutoGuardar.MediodePago == 0 ? "credito" : "debito",
                CodigoSeguridad = infoEmision.Tarjeta.Cvv,
                IdConvenio = infoEmision.Convenio.Id,
                NumeroReintentos = 3
            };
        }

        private string ObtieneClaveTipoCuentaBancaria(int medioPago)
        {
            string clave = string.Empty;
            if (medioPago.Equals(0))
            {
                clave = "R";
            }
            if (medioPago.Equals(1))
            {
                clave = "D";
            }
            return clave;
        }

        private string ObtieneTipoCuentaTarjeta(string nombreTipoTarjeta)
        {
            string tipoTarjeta = string.Empty;
            switch (nombreTipoTarjeta.ToLower())
            {
                case "visa":
                    tipoTarjeta = "VI";
                    break;
                case "master card":
                    tipoTarjeta = "MC";
                    break;
                case "amex":
                    tipoTarjeta = "AM";
                    break;
            }
            return tipoTarjeta;
        }

        #endregion



        #region Not Implemented

        public struct FormaIndemnizacionInfoService
        {
            public string ValorConvenido => "03";
            public string ValorComercial => "01";
            public string ValorDeclarado => "05";
        }


        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new NotImplementedException();
        }

        public LocktonModel.db.Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }

        public LocktonModel.db.Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }

        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            var estatusOperacion = new EstatusOperacion();
            var error = new CatalogoErrorInstalacionDatosBancarios();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
                var endpoint = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_URL");
                var user = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_USER");
                var pass = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_PASS");
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == datosCobranza.IdConvenio);

                var proxy = new DomiciliacionProxy(endpoint, user, pass, convenio.CodigoIntermediario);
                var request = new AgregarDomiciliacionRequest();

                request.numTarjeta = datosCobranza.NumeroTarjeta;
                request.vencimiento = $"{datosCobranza.MesVencimiento}/{datosCobranza.AnoVencimiento}";
                request.nombre = datosCobranza.NombreCompleto;
                request.intermediario = convenio.CodigoIntermediario;
                request.tipo = datosCobranza.TipoTarjeta;
                request.cvv = datosCobranza.CodigoSeguridad;
                request.NumeroPoliza = datosCobranza.NumeroPoliza.PadLeft(14, '0');

                var response = proxy.AgregarDomiciliacion(request);

                request.numTarjeta = "**********";
                request.vencimiento = "**/**";
                request.cvv = "***";

                jsonRequest = JsonConvert.SerializeObject(request);
                jsonResponse = response.JsonData.ResponseContent;
                urlMethod = response.Url;

                if (response.Response.SuccessCode == "200" && response.Response.ErrorCode == "0")
                {
                    estatusOperacion.Exitoso = true;

                    error = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(x => x.DescripcionError.Equals("Exitoso"));

                    log.Info(string.Format("XML PAGO TDC Pago exitoso, intento({0}/{1})", 1, datosCobranza.NumeroReintentos));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al pagar la poliza: {0} Error: {1})", datosCobranza.NumeroPoliza, response.ErrorMessage ?? ""));

                    estatusOperacion.Mensaje = "Algo salió mal en la instalación de tus datos bancarios, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    estatusOperacion.MensajeCatalogo = response.ErrorMessage;
                }

            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado pago Con Tarjeta GNP: " + ex.Message, ex);
                estatusOperacion.Mensaje = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(x => x.DescripcionError.Contains("exepcion") && x.IdAseguradora == 2).MensajeMostrarUsaurio;
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                estatusOperacion.Exitoso = false;
                estatusOperacion.EsReintentable = false;
                estatusOperacion.MensajeCatalogo = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                error = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(y => y.DescripcionError.Contains("exepcion") && y.IdAseguradora == 2);
            }

            RegistraOPL(datosCobranza.NumeroPoliza, jsonRequest, jsonResponse, "Pago Con Tarjeta", 1, estatusOperacion.Exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datosCobranza.NumeroPoliza) == true ? "Online" : "Tradicional", urlMethod, error != null ? error.Id : 0);

            log.Info(string.Format("Termina proceso de intalacion a OPL TDC de la poliza: {0}", datosCobranza.NumeroPoliza));

            return estatusOperacion;
        }

        public EstatusOperacion EdicionTarjeta(DatosCobranza datosCobranza)
        {
            var estatusOperacion = new EstatusOperacion();
            var error = new CatalogoErrorInstalacionDatosBancarios();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
                var endpoint = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_URL");
                var user = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_USER");
                var pass = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_PASS");
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == datosCobranza.IdConvenio);

                var proxy = new DomiciliacionProxy(endpoint, user, pass, convenio.CodigoIntermediario);
                var request = new ActualizarDomiciliacionRequest();

                request.numTarjeta = datosCobranza.NumeroTarjeta;
                request.vencimiento = $"{datosCobranza.MesVencimiento}/{datosCobranza.AnoVencimiento}";
                request.nombre = datosCobranza.NombreCompleto;
                request.intermediario = convenio.CodigoIntermediario;
                request.tipo = datosCobranza.TipoTarjeta;
                request.cvv = datosCobranza.CodigoSeguridad;
                request.NumeroPoliza = datosCobranza.NumeroPoliza.PadLeft(14, '0');

                var response = proxy.ActualizarDomiciliacion(request);

                request.numTarjeta = "**********";
                request.vencimiento = "**/**";
                request.cvv = "***";

                jsonRequest = JsonConvert.SerializeObject(request);
                jsonResponse = response.JsonData.ResponseContent;
                urlMethod = response.Url;

                if (response.Response.SuccessCode == "200" && response.Response.ErrorCode == "0")
                {
                    estatusOperacion.Exitoso = true;

                    error = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(x => x.DescripcionError.Equals("Exitoso"));

                    log.Info(string.Format("XML PAGO TDC Pago exitoso, intento({0}/{1})", 1, datosCobranza.NumeroReintentos));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al pagar la poliza: {0} Error: {1})", datosCobranza.NumeroPoliza, response.ErrorMessage ?? ""));

                    estatusOperacion.Mensaje = "Algo salió mal en la instalación de tus datos bancarios, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    estatusOperacion.MensajeCatalogo = response.ErrorMessage;
                }

            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado pago Con Tarjeta GNP: " + ex.Message, ex);
                estatusOperacion.Mensaje = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(x => x.DescripcionError.Contains("exepcion") && x.IdAseguradora == 2).MensajeMostrarUsaurio;
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                estatusOperacion.Exitoso = false;
                estatusOperacion.EsReintentable = false;
                estatusOperacion.MensajeCatalogo = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                error = db.CatalogoErrorInstalacionDatosBancarios.FirstOrDefault(y => y.DescripcionError.Contains("exepcion") && y.IdAseguradora == 2);
            }

            RegistraOPL(datosCobranza.NumeroPoliza, jsonRequest, jsonResponse, "Edición Tarjeta", 4, estatusOperacion.Exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datosCobranza.NumeroPoliza) == true ? "Online" : "Tradicional", urlMethod, error != null ? error.Id : 0);

            log.Info(string.Format("Termina proceso de intalacion a OPL TDC de la poliza: {0}", datosCobranza.NumeroPoliza));

            return estatusOperacion;
        }

        public EstatusOperacion LinkCobro(DatosLinkCobro datos)
        {
            var estatusOperacion = new EstatusOperacion();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
                var endpoint = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_URL");
                var user = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_USER");
                var pass = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_PASS");
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == datos.IdConvenio);

                var proxy = new DomiciliacionProxy(endpoint, user, pass, convenio.CodigoIntermediario);
                var request = new EnvioCobroLinkRequest();

                request.nombre = datos.Nombre;
                request.correo = datos.Email;
                request.NumeroPoliza = datos.NumeroPoliza.PadLeft(14, '0');

                var response = proxy.EnvioCobroLink(request);

                jsonResponse = response.JsonData.ResponseContent;
                jsonRequest = response.JsonData.RequestBody;
                urlMethod = response.Url;

                if (response.Code == 200)
                {
                    estatusOperacion.Exitoso = true;

                    log.Info(string.Format("GNP Link de Pago exitoso)"));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al enviar el link de pago de la poliza: {0} Error: {1})", datos.NumeroPoliza, response.ErrorMessage ?? ""));

                    estatusOperacion.Mensaje = "Algo salió mal en él envió del link de pago, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    estatusOperacion.MensajeCatalogo = response.ErrorMessage;
                }

            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado pago Con Tarjeta GNP: " + ex.Message, ex);

                estatusOperacion.Mensaje = ex.Message;
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
                estatusOperacion.Exitoso = false;
                estatusOperacion.EsReintentable = false;
                estatusOperacion.MensajeCatalogo = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            RegistraOPL(datos.NumeroPoliza, jsonRequest, jsonResponse, "Link de Cobro", 5, estatusOperacion.Exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datos.NumeroPoliza) == true ? "Online" : "Tradicional", urlMethod, 0);

            log.Info(string.Format("Termina proceso de intalacion a OPL TDC de la poliza: {0}", datos.NumeroPoliza));

            return estatusOperacion;
        }

        public EstatusOperacion CancelacionPoliza(string numeroPoliza, int idConvenio)
        {
            var estatusOperacion = new EstatusOperacion();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
                bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                var endpoint = "";
                var user = "";
                var pass = "";

                if (EsProduccion)
                {
                    endpoint = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_URL");
                    user = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_USER");
                    pass = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_PASS");
                }
                else
                {
                    endpoint = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_QA_URL");
                    user = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_QA_USER");
                    pass = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_QA_PASS");
                }

                var proxy = new CancelacionesProxy(endpoint, user, pass, convenio.CodigoIntermediario);

                var response = proxy.CancelarPoliza(numeroPoliza.PadLeft(14, '0'));

                jsonRequest = response.JsonData.RequestBody;
                jsonResponse = response.JsonData.ResponseContent;
                urlMethod = response.Url;

                if (response.success)
                {
                    estatusOperacion.Exitoso = true;

                    log.Info(string.Format("Cancelación de póliza exitosa)"));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al enviar el link de pago de la poliza: {0} Error: {1})", numeroPoliza, response.JsonData.ResponseContent ?? ""));

                    estatusOperacion.Mensaje = "Algo salió mal en él envió del link de pago, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    estatusOperacion.MensajeCatalogo = response.mensajeError;
                }


            }
            catch (Exception ex)
            {
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            Utilidades.Utilidades.RegistroEndosoBitacora(4, urlMethod, numeroPoliza, estatusOperacion.MensajeCatalogo ?? "", jsonRequest, jsonResponse);

            return estatusOperacion;

        }

        public EstatusOperacion CorreccionObjetoPoliza(string numeroPoliza, int idConvenio, Modificacion modificacion)
        {
            var estatusOperacion = new EstatusOperacion();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
                bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                var endpoint = "";
                var user = "";
                var pass = "";

                if (EsProduccion)
                {
                    endpoint = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_URL");
                    user = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_USER");
                    pass = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_PASS");
                }
                else
                {
                    endpoint = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_QA_URL");
                    user = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_QA_USER");
                    pass = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_ENDOSOSB_QA_PASS");
                }

                var proxy = new CancelacionesProxy(endpoint, user, pass, convenio.CodigoIntermediario);
                var request = new CambioDatosRequest();

                request.intermediario = convenio.CodigoIntermediario;
                request.NumeroPoliza = numeroPoliza.PadLeft(14, '0');

                switch (modificacion.IdTipoModificacion)
                {
                    case 3: request.numPlaca = modificacion.DebeDecir; break;
                    case 4: request.numSerie = modificacion.DebeDecir; break;
                    case 5:
                        request.conductor = new CambioDatosConductor();
                        request.conductor.nombre = modificacion.Nombre;
                        request.conductor.apellidoPaterno = modificacion.ApellidoPaterno;
                        request.conductor.apellidoMaterno = modificacion.ApellidoMaterno;
                        break;

                }

                var response = proxy.CambiarDatos(request);

                jsonRequest = response.JsonData.RequestBody;
                jsonResponse = response.JsonData.ResponseContent;
                urlMethod = response.Url;

                if (response.success)
                {
                    estatusOperacion.Exitoso = true;

                    log.Info(string.Format("Corrección de objeto de póliza exitosa)"));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al enviar la correción de objetos de la poliza: {0} Error: {1})", numeroPoliza, response.JsonData.ResponseContent ?? ""));

                    estatusOperacion.Mensaje = "Algo salió mal en él envió de la correción de la póliza, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    estatusOperacion.MensajeCatalogo = response.mensajeError;
                }


            }
            catch (Exception ex)
            {
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            Utilidades.Utilidades.RegistroEndosoBitacora(2, urlMethod, numeroPoliza, estatusOperacion.MensajeCatalogo ?? "", jsonRequest, jsonResponse);

            return estatusOperacion;

        }

        public void LinkCobroProcesoMasivo(DatosLinkCobro datos, int idRegistro)
        {

            string jsonRequest = "";
            string jsonResponse = "";
            string mensaje = "";
            var exitoso = false;
            var urlMethod = "";

            try
            {
                var endpoint = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_URL");
                var user = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_USER");
                var pass = Utilidades.Utilidades.ObtienerValorParametro("GNP_API_COBRANZA_PASS");
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == datos.IdConvenio);

                var proxy = new DomiciliacionProxy(endpoint, user, pass, convenio.CodigoIntermediario);
                var request = new EnvioCobroLinkRequest();

                request.nombre = datos.Nombre;
                request.correo = datos.Email;
                request.NumeroPoliza = datos.NumeroPoliza.PadLeft(14, '0');

                var response = proxy.EnvioCobroLink(request);

                jsonResponse = response.JsonData.ResponseContent;
                jsonRequest = response.JsonData.RequestBody;
                urlMethod = response.Url;

                if (response.Code == 200)
                {
                    exitoso = true;

                    log.Info(string.Format("GNP Link de Pago exitoso)"));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al enviar el link de pago de la poliza: {0} Error: {1})", datos.NumeroPoliza, response.ErrorMessage ?? ""));


                    exitoso = false;

                    mensaje = response.ErrorMessage;
                }

            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado pago Con Tarjeta GNP: " + ex.Message, ex);

                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;

            }

            var registro = db.LinkPagoMasivo_Poliza.FirstOrDefault(a => a.Id == idRegistro);

            registro.Error = mensaje;
            registro.URL = urlMethod;
            registro.Response = jsonResponse;
            registro.Request = jsonRequest;

            db.SaveChanges();

            RegistraOPL(datos.NumeroPoliza, jsonRequest, jsonResponse, "Link de Cobro", 5, exitoso, Utilidades.Utilidades.ValidaPolizaOnline(datos.NumeroPoliza) == true ? "Online" : "Tradicional", urlMethod, 0);

            log.Info(string.Format("Termina proceso de intalacion a OPL TDC de la poliza: {0}", datos.NumeroPoliza));


        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public decimal ObtenerPrimerPago(string xMLRecepcion)
        {
            decimal primerPago = 0;
            try
            {
                ResponseCotizacionAutos resultadoCotizacion = GetXmlFromString<ResponseCotizacionAutos>(xMLRecepcion);

                foreach (var paquete in resultadoCotizacion.paquetes)
                {
                    foreach (var primasResultado in paquete.resultadosFormaPago)
                    {
                        primerPago = Convert.ToDecimal(QuitaCaracteres(primasResultado.resultadoTotal.importePrimerRecibo.ToString()));
                    }
                }
            }
            catch (Exception) { }
            return primerPago;

        }

        #endregion

        private void RegistraOPL(string numeroPoliza, string request, string response, string tipo, int idTipo, bool exitoso, string TipoPoliza, string url, int IdCatalogoError = 0)
        {
            try
            {
                using (var _db = new ApplicationDbContext())
                {
                    var oplRegistro = new PolizaRegistroCobranza();
                    oplRegistro.Exitoso = exitoso;
                    oplRegistro.Fecha = DateTime.Now;
                    oplRegistro.FechaResponse = DateTime.Now;
                    oplRegistro.IdTipoOPL = idTipo;
                    oplRegistro.NumeroPoliza = numeroPoliza;
                    oplRegistro.Response = response;
                    oplRegistro.TipoOPL = tipo;
                    oplRegistro.Request = request;
                    oplRegistro.TipoPoliza = TipoPoliza;
                    oplRegistro.IdCatalogoErrorInstalacionDatosBancarios = IdCatalogoError;
                    oplRegistro.IdAseguradora = 2;
                    oplRegistro.UrlMethod = url;
                    _db.PolizaRegistroCobranza.Add(oplRegistro);
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                log.Info("Ocurrio un error no controlado RegistraOPL GNP: " + ex.Message, ex);
            }
        }



    }
    public class GNPInfoReimpresion
    {
        public string Path { get; set; }
        public byte[] Bytes { get; set; }
        public string Url { get; set; }
    }
    public class GNPInfoReimpresionRecibo
    {
        public string Path { get; set; }
        public List<byte[]> Bytes { get; set; }
        public string Url { get; set; }
    }
}
