﻿using LocktonModel.Consulta;
using LocktonModel.db;
using LocktonModel.Models;
using LocktonModel.Services.ANA;
using LocktonModel.Services.Banorte.Cotizacion;
using LocktonModel.Services.Banorte.Vehiculo;
using LocktonModel.VModels;
using LocktonServicios.BitacoraPoliza;
using LocktonServicios.Utilidades;
using LocktonServicios.XMLEntity.ANA;
using log4net;
using Newtonsoft.Json;
using Quartz.Xml;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LocktonServicios.Aseguradoras.ANA
{
    public class ANAServices : IOperacionesAseguradoras
    {
        ApplicationDbContext db = new ApplicationDbContext();
        private static readonly ILog log = LogManager.GetLogger("ANAServices");

        public CotizacionCompara CotizarVehiculo(CotizacionCompara CotizacionCompara, int? convenioId, mDetalles cot, DetalleUsuario detalleUsuario, ref List<LocktonModel.db.PaqueteDetalle> Coberturas, VEmpConvPaq ConveniosPaquetes, int IdTipoPaquete, int idPaqueteConvenio)
        {

            var convenioCotiza = db.Convenio.Where(x => x.Id == convenioId).FirstOrDefault();
            var error = "";

            try
            {

                var tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == convenioCotiza.IdAseguradora && x.IdCatTipoPaquete == IdTipoPaquete).FirstOrDefault();
                var codigoPostal = ConveniosPaquetes.Empresa.Direccion.CodigoPostal;
                var paqueteConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == idPaqueteConvenio);
                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenioCotiza.Id && x.IdCatPeriodicidadFormaPago == CotizacionCompara.FormadePago).FirstOrDefault();
                var catperdioricidad = db.CatPeriodicidadFormaPago.FirstOrDefault(a => a.Id == perioricidad.IdCatPeriodicidadFormaPago);
                var paqueteRamoConvenio = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == convenioId && x.IdCatRamoVehiculo == paqueteConvenio.IdCatRamoVehiculo).FirstOrDefault();
                var mediopago = db.CatModalidadFormaPago.FirstOrDefault(a => a.Clave == CotizacionCompara.MediodePago.ToString());
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenioCotiza.Id && a.IdCatPeriodicidadFormaPago == catperdioricidad.Id && a.IdCatModalidadFormaPago == mediopago.Id);

                var claveAgente = Convert.ToInt32(modalidadFormaPago.ClaveAgenteModalidadFormaPago ?? "0");
                //ARGUMENTOS ADICIONALES
                var argumentos = db.ANA_Argumento.Where(a => a.IdConvenio == CotizacionCompara.IdConvenio).ToList();
                if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 2 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5 || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 6)//pooles
                {
                    codigoPostal = string.IsNullOrEmpty(CotizacionCompara.CodigoPostal) ? codigoPostal : CotizacionCompara.CodigoPostal;

                }

                var codigo = db.CatCodigoPostal.FirstOrDefault(a => a.Codigo == codigoPostal);

                if (codigo == null)
                {
                    Comparar infoCompara_error = new Comparar();
                    infoCompara_error.IdAseguradora = convenioCotiza.IdAseguradora;
                    infoCompara_error.IdConvenio = convenioCotiza.Id;
                    infoCompara_error.Aseguradora = "ANA";
                    infoCompara_error.ErrorXML = string.Format("Tuvimos un inconveniente para realizar tu cotización: no se encotró información del Código Postal");
                    CotizacionCompara.Comparar.Add(infoCompara_error);
                }
                else
                {

                    var coberturas = ObtenerCoberturas(convenioCotiza.Id, IdTipoPaquete, paqueteConvenio.IdCatRamoVehiculo, idPaqueteConvenio);

                    var tipoPersona = 1;

                    var estadoANA = ObtenerEstadoANA(codigo.Codigo, convenioCotiza.Id, claveAgente);

                    if (CotizacionCompara.EmisionPersonaMoral)
                        tipoPersona = 2;
                    else if (ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 1
                        || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 4
                        || ConveniosPaquetes.configuracionEmpresa.IdTipoDeNegocio == 5)
                        tipoPersona = 2;

                    XElement xRequest = new XElement("transacciones");
                    var _T = XmlTransaccion("C", claveAgente, "");
                    var _V = XmlVehiculo(cot, estadoANA, tipoPaquete.Clave, CotizacionCompara.Año);
                    var coberturasOpcionales = db.PaqueteDetalleOpcional.Where(a => a.IdPaqueteConvenio == idPaqueteConvenio).ToList();
                    foreach (var cobertura in coberturas)
                    {
                        var tipo = "";
                        var id = cobertura.Codigo;
                        decimal? sa = null;
                        decimal? ded = null;

                        if (id == "02" || id == "04")
                        {
                            if (!CotizacionCompara.ValorFactura)
                            {
                                var _catSumaAsegurada = db.CatTipoSumaAsegVehiculo.FirstOrDefault(a => a.IdAseguradora == convenioCotiza.IdAseguradora && a.Nombre == cobertura.Cobertura);

                                if (_catSumaAsegurada != null)
                                    tipo = _catSumaAsegurada.Clave;
                            }
                            else
                            {
                                tipo = "4";
                                sa = CotizacionCompara.MontoFactura;
                            }
                        }

                        if (id.Contains("|"))
                        {
                            var _l = id.Split('|');
                            id = _l[0];
                            tipo = _l[1];
                        }

                        if (!string.IsNullOrEmpty(cobertura.Deducible))
                            ded = decimal.Parse(cobertura.Deducible);

                        if (!string.IsNullOrEmpty(cobertura.SumaAsegurada))
                            sa = decimal.Parse(cobertura.SumaAsegurada);
                        //Coberturas Condición especial
                        if (cobertura != null)
                        {
                            var dd = EsCoberturaConCondicionEspecial(convenioCotiza.Id, cobertura.IdCobertura.ToString(), CotizacionCompara.Año, paqueteConvenio.IdCatRamoVehiculo);
                            if (!dd)
                                continue;
                        }

                        _V.Add(XmlCobertura(id, "", sa, tipo, ded, null));
                    }

                    _T.Add(_V);

                    _T.Add(XmlAsegurado(tipoPersona, codigo, estadoANA));
                    _T.Add(XmlPoliza(CotizacionCompara, convenioCotiza, perioricidad.FormaPago, paqueteRamoConvenio.Descuento, argumentos));
                    _T.Add(XmlRecibo());
                    _T.Add(XmlPrima());
                    _T.Add(new XElement("error"));

                    xRequest.Add(_T);

                    log.Info("ANA XML Cotizacion Request-  " + xRequest.ToString());

                    var servicio = new ANA_Consultas.ServiceSoapClient();



                    var xmlRespuesta = servicio.Transaccion(xRequest, ANA_Consultas.TipoTransaccion.Cotizacion, convenioCotiza.Usuario, convenioCotiza.Contrasena);

                    #region Validar Respuesta

                    var xmlEnvio = xRequest.ToString();

                    log.Info("ANA XML Cotizacion Response-  " + xmlEnvio.ToString());

                    var resultadoEmision = Utilidades.Utilidades.GetXmlFromString<Transacciones>(xmlRespuesta);


                    Comparar infoCompara = LeeXmlRespuesta(xmlRespuesta, xmlEnvio, convenioCotiza);
                    infoCompara.IdPaqueteConvenio = idPaqueteConvenio;
                    infoCompara.NombrePaqueteConvenio = paqueteConvenio.NombrePaquete;
                    infoCompara.IdCatTipoPaquete = paqueteConvenio.IdCatTipoPaquete;
                    infoCompara.RequiereAprobacion = modalidadFormaPago.RequiereAprobacion;
                    infoCompara.Cobertura = CotizacionCompara.Cobertura.ToString();
                    infoCompara.IdFormaPago = catperdioricidad.Id;
                    infoCompara.IdMedioPago = mediopago.Id;
                    CotizacionCompara.CodigoPostal = codigoPostal;

                    //meses sin intereses
                    if (catperdioricidad.Id == 1 && mediopago.Id == 1)
                    {

                        if (resultadoEmision.Transaccion.Msi != null && !string.IsNullOrEmpty(resultadoEmision.Transaccion.Msi.Aplica) && resultadoEmision.Transaccion.Msi.Aplica == "SI")
                            Utilidades.Utilidades.AplicaMSICotizacion(convenioCotiza.IdEmpresa, convenioCotiza.Id, ref infoCompara);


                    }


                    CotizacionCompara.Comparar.Add(infoCompara);

                    #endregion
                }

            }
            catch (Exception ex)
            {

                Comparar infoCompara = new Comparar();
                infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
                infoCompara.IdConvenio = convenioCotiza.Id;
                infoCompara.Aseguradora = "ANA";
                infoCompara.ErrorXML = string.Format("Tuvimos un inconveniente para realizar tu cotización: {0}", string.IsNullOrEmpty(error) ? ex.Message : error);
                CotizacionCompara.Comparar.Add(infoCompara);

                log.Info(infoCompara.ErrorXML);
                //throw;
            }

            return CotizacionCompara;
        }

        public Comparar LeeXmlRespuesta(string xmlRespuesta, string xmlEnvio, Convenio convenioCotiza)
        {

            var response = Utilidades.Utilidades.GetXmlFromString<Transacciones>(xmlRespuesta);
            var request = Utilidades.Utilidades.GetXmlFromString<Transacciones>(xmlEnvio);


            Comparar infoCompara = new Comparar();
            infoCompara.FechaCotizacion = DateTime.Parse(request.Transaccion.Poliza.Feciniciovig);
            infoCompara.XmlEmision = xmlEnvio;
            infoCompara.XmlRespuesta = xmlRespuesta;
            infoCompara.IdAseguradora = convenioCotiza.IdAseguradora;
            infoCompara.IdConvenio = convenioCotiza.Id;
            infoCompara.Aseguradora = "ANA";
            infoCompara.Año = request.Transaccion.Vehiculo.Modelo.ToString();
            infoCompara.FechaInicio = request.Transaccion.Poliza.Feciniciovig;
            infoCompara.FechaFin = request.Transaccion.Poliza.Fecterminovig;


            if (!string.IsNullOrWhiteSpace(response.Transaccion.Error))
            {
                infoCompara.ErrorXML = response.Transaccion.Error;

                log.Error("cotizaVehiculo error ANA Request " + xmlEnvio.Replace("\n", "").Replace("\r", ""));
                log.Error("cotizaVehiculo error ANA Response " + xmlRespuesta.Replace("\n", "").Replace("\r", ""));

            }
            else
            {


                infoCompara.Coberturas = new List<Coberturas>();

                foreach (var cobertura in response.Transaccion.Vehiculo.Cobertura)
                {

                    Coberturas cotCob = new Coberturas();

                    cotCob.Cobertura = cobertura.Pma;
                    cotCob.SumaAsegurada = cobertura.Sa;
                    cotCob.Nombre = cobertura.Desc.Trim();
                    cotCob.Deducible = cobertura.Ded.ToString();
                    cotCob.Codigo = cobertura.Id.ToString();

                    infoCompara.Coberturas.Add(cotCob);

                }



                infoCompara.PrimaNeta = response.Transaccion.Prima._Primaneta.ToString("N2");
                infoCompara.PrimaTotal = response.Transaccion.Prima._Primatotal.ToString("N2");
                infoCompara.Impuesto = response.Transaccion.Prima._Impuesto.ToString("N2");
                infoCompara.Recargo = response.Transaccion.Prima._Recargo.ToString("N2");
                infoCompara.Derecho = response.Transaccion.Prima._Derecho.ToString("N2");
                infoCompara.PrimerPago = response.Transaccion.Prima._Primatotal.ToString("N2");
                infoCompara.NumeroDePagos = response.Transaccion.Recibo.Count;
                infoCompara.SegundoPago = "";

                if (infoCompara.NumeroDePagos > 1)
                {
                    infoCompara.PrimerPago = response.Transaccion.Recibo.FirstOrDefault().Primatotal;
                    infoCompara.SegundoPago = response.Transaccion.Recibo.LastOrDefault().Primatotal;
                }

            }

            return infoCompara;
        }

        public List<int> ObtenerMeses(string vin, int idCotizacionDetalle)
        {
            var meses = new List<int>();
            try
            {
                var cotiacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == idCotizacionDetalle);
                var paqConvenio = db.PaqueteConvenio.FirstOrDefault(a => a.Id == cotiacionDetalle.IdPaqueteConvenio);
                var paq = db.ConvenioRamoPaquete.Where(x => x.IdConvenio == cotiacionDetalle.IdConvenio && x.IdCatRamoVehiculo == paqConvenio.IdCatRamoVehiculo).FirstOrDefault();
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == cotiacionDetalle.IdConvenio);
                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == convenio.Id && x.IdCatPeriodicidadFormaPago == cotiacionDetalle.IdFormaPago).FirstOrDefault();
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == convenio.Id && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago && a.IdCatModalidadFormaPago == cotiacionDetalle.IdMedioPago);

                var claveAgente = Convert.ToInt32(modalidadFormaPago.ClaveAgenteModalidadFormaPago);

                var servicio = new ANA_Consultas.ServiceSoapClient();

                var response = servicio.CalculaMSI(claveAgente, convenio.Usuario, convenio.Contrasena, vin, paq.Descuento.ToString(), convenio.Usuario);

                log.Info($"ANA ObtenerMeses - Resultado de obtener meses del vin {vin} - {response}");

                var transaccion = Utilidades.Utilidades.GetXmlFromString<Transacciones>(response);


                if (transaccion != null && transaccion.Transaccion != null && transaccion.Transaccion.MSI != null && string.IsNullOrEmpty(transaccion.Transaccion.Error))
                {
                    foreach (var mes in transaccion.Transaccion.MSI)
                        if (mes._Meses > 0)
                            meses.Add(mes._Meses);
                }

                return meses;

            }
            catch (Exception ex)
            {
                log.Info($"ANA ObtenerMeses - Error al calcular los meses del vin {vin} - {ex.Message}");
                return meses;
            }
        }

        public EmisionPoliza EmitirVehiculo(InformacionEmision InfoEmision, string username)
        {
            EmisionPoliza result = new EmisionPoliza(true, string.Empty, string.Empty, new Poliza());
            var xmlEnvio = string.Empty;
            var xmlRespuesta = string.Empty;

            try
            {
                var cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == InfoEmision.IdCotizacion);

                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == cotizacionDetalle.IdConvenio && x.IdCatPeriodicidadFormaPago == cotizacionDetalle.IdFormaPago).FirstOrDefault();
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == cotizacionDetalle.IdConvenio && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago && a.IdCatModalidadFormaPago == cotizacionDetalle.IdMedioPago);

                var claveAgente = Convert.ToInt32(modalidadFormaPago.ClaveAgenteModalidadFormaPago);

                InfoEmision.Cotizacion = db.Cotizacion.FirstOrDefault(a => a.Id == cotizacionDetalle.IdCotizacion);

                var xcRequest = XElement.Parse(cotizacionDetalle.XMLSolicitud);
                var xcResponse = XElement.Parse(cotizacionDetalle.XMLRecepcion);

                XElement xRequest = new XElement("transacciones");
                XElement xRequest_log = new XElement("transacciones");

                var _T = XmlTransaccion("E", claveAgente, xcResponse.Element("transaccion").Attribute("cotizacion").Value);
                var _T_log = XmlTransaccion("E", claveAgente, xcResponse.Element("transaccion").Attribute("cotizacion").Value);
                var _A = xcRequest.Element("transaccion").Element("asegurado");

                #region Vehiculo

                var _V = xcRequest.Element("transaccion").Element("vehiculo");

                _V.Attribute("motor").Value = InfoEmision.NumeroMotor;
                _V.Attribute("serie").Value = InfoEmision.NumeroSerie;
                _V.Attribute("placas").Value = InfoEmision.Placas;

                #endregion

                #region Poliza ANA

                var _P = xcRequest.Element("transaccion").Element("poliza");

                if (!string.IsNullOrEmpty(InfoEmision.BeneficiarioPreferente))
                    _P.Attribute("beneficiario").Value = InfoEmision.BeneficiarioPreferente;

                if (InfoEmision.IdMSI.HasValue)
                    _P.Add(XmlArgumento(48, "1", "", InfoEmision.IdMSI.ToString()));

                //ARGUMENTOS ADICIONALES
                var argumentos = db.ANA_Argumento.Where(a => a.IdConvenio == cotizacionDetalle.IdConvenio);
                if (argumentos != null)
                {
                    foreach (var argumento in argumentos)
                    {
                        _P.Add(XmlArgumento(argumento.IdArgumento, argumento.Tipo ?? "", argumento.Campo ?? "", argumento.Valor ?? ""));
                    }
                }

                #endregion

                #region Persona Moral
                //Asegurado la persona moral 
                if ((InfoEmision.IdTipoDeNegocio == 6 && InfoEmision.EmisionPersonaMoral)
                    || (InfoEmision.IdTipoDeNegocio == 5 && InfoEmision.EmisionPersonaMoral)) //Emision Persona Moral
                {
                    var _regimenEmpresa = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal);

                    InfoEmision.PersonaMoral = db.PersonaMoral.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoral.Id);
                    InfoEmision.PersonaMoralRepresentanteLegal = db.PersonaMoralRepresentanteLegal.FirstOrDefault(a => a.Id == InfoEmision.PersonaMoralRepresentanteLegal.Id);

                    _V.Attribute("poblacion").Value = InfoEmision.PersonaMoral.Direccion.Municipio;

                    _A = XmlAsegurado(InfoEmision.PersonaMoral, InfoEmision.Convenio.Id, claveAgente);

                    _A.Add(XmlArgumento(2, "", "", InfoEmision.PersonaMoralRepresentanteLegal.Correo));
                    _A.Add(XmlArgumento(3, "", "", InfoEmision.PersonaMoralRepresentanteLegal.Telefono));
                    _A.Add(XmlArgumento(4, "", "", InfoEmision.PersonaMoral.RFC));
                    _A.Add(XmlArgumento(10, "", "", InfoEmision.PersonaMoral.CatGiroBase.ClaveANA));
                    _A.Add(XmlArgumento(11, "", "", $"{InfoEmision.PersonaMoralRepresentanteLegal.ObtieneNombreCompleto()}"));
                    _A.Add(XmlArgumento(12, "", "", "M1"));
                    _A.Add(XmlArgumento(13, "", "", $"{InfoEmision.PersonaMoralRepresentanteLegal.ObtieneNombreCompleto()}"));
                    _A.Add(XmlArgumento(14, "", "", "M1"));
                    _A.Add(XmlArgumento(27, "", "", $"{_regimenEmpresa.Clave}"));
                    _A.Add(XmlArgumento(28, "", "", InfoEmision.Empresa.RazonSocial));
                    _A.Add(XmlArgumento(29, "", "", InfoEmision.Empresa.RFC));
                    _A.Add(XmlArgumento(30, "", "", InfoEmision.Empresa.Direccion.CodigoPostal));
                    _A.Add(XmlArgumento(31, "", "", InfoEmision.Empresa.RepresentanteLegal.Correo));

                }
                #endregion

                #region Flotilla Datos Fiscales Empresa
                //Asegurado Empresa (Persona Moral) / Sin Contratante
                else if (InfoEmision.Convenio.IdCatTipoContratante == 1 || InfoEmision.EsFlotilla)
                {

                    var _regimenEmpresa = db.CatRegimenFiscal.FirstOrDefault(a => a.Id == InfoEmision.Empresa.IdRegimenFiscal);

                    _V.Attribute("poblacion").Value = InfoEmision.Empresa.Direccion.Municipio;

                    _A = XmlAsegurado(2, InfoEmision, claveAgente);

                    _A.Add(XmlArgumento(2, "", "", InfoEmision.Empresa.RepresentanteLegal.Correo ?? ""));
                    _A.Add(XmlArgumento(3, "", "", InfoEmision.Empresa.RepresentanteLegal.Telefono ?? ""));
                    _A.Add(XmlArgumento(4, "", "", InfoEmision.Empresa.RFC));
                    _A.Add(XmlArgumento(10, "", "", InfoEmision.Empresa.CatGiroBase.ClaveANA));
                    _A.Add(XmlArgumento(11, "", "", $"{InfoEmision.Empresa.RepresentanteLegal.ObtieneNombreCompleto()}"));
                    _A.Add(XmlArgumento(12, "", "", "M1"));
                    _A.Add(XmlArgumento(13, "", "", $"{InfoEmision.Empresa.RepresentanteLegal.ObtieneNombreCompleto()}"));
                    _A.Add(XmlArgumento(14, "", "", "M1"));

                    if (_regimenEmpresa != null)
                        _A.Add(XmlArgumento(27, "", "", $"{_regimenEmpresa.Clave}"));

                    _A.Add(XmlArgumento(28, "", "", InfoEmision.Empresa.RazonSocial));
                    _A.Add(XmlArgumento(29, "", "", InfoEmision.Empresa.RFC));
                    _A.Add(XmlArgumento(30, "", "", InfoEmision.Empresa.Direccion.CodigoPostal));
                    _A.Add(XmlArgumento(31, "", "", InfoEmision.Empresa.RepresentanteLegal.Correo));

                }
                #endregion

                //#region Flotilla Datos Fiscales Empresa y Empleado
                ////Asegurado es persona moral la empresa, contratante empleado (Persona Fisica)
                //else if (esUsuarioFlotilla)
                //{

                //}
                //#endregion

                #region Individuales - Persona Fisica
                //Asegurado Empleado - Conductor (Persona Fisica) / Sin Contratante
                else
                {

                    _V.Attribute("poblacion").Value = InfoEmision.DatosUsuario.Direccion.Municipio;

                    _A = XmlAsegurado(1, InfoEmision, claveAgente);

                    _A.Add(XmlArgumento(2, "", "", InfoEmision.Email));
                    _A.Add(XmlArgumento(3, "", "", InfoEmision.TelefonoCel));
                    _A.Add(XmlArgumento(4, "", "", InfoEmision.DatosUsuario.RFC));
                    _A.Add(XmlArgumento(6, "", "", "M1"));
                    _A.Add(XmlArgumento(7, "", "", "C2"));
                    _A.Add(XmlArgumento(8, "", "", InfoEmision.DatosUsuario.NumeroIdentificacion ?? "9999999999"));
                    _A.Add(XmlArgumento(9, "", "", "O1"));
                    _A.Add(XmlArgumento(17, "", "", (InfoEmision.Cotizacion.IdCatGenero ?? 1).ToString()));
                    _A.Add(XmlArgumento(19, "", "", InfoEmision.FechaNacimiento.ToString("dd/MM/yyyy")));

                }

                #endregion

                _T.Add(_V);
                _T.Add(_A);
                _T.Add(_P);
                _T.Add(XmlPrima());
                _T.Add(XmlRecibo());

                _T_log.Add(_V);
                _T_log.Add(_A);
                _T_log.Add(_P);
                _T_log.Add(XmlPrima());
                _T_log.Add(XmlRecibo());

                if (InfoEmision.CotizacionAutoGuardar.MediodePago == 0 || InfoEmision.CotizacionAutoGuardar.MediodePago == 1)
                {
                    if (!string.IsNullOrEmpty(InfoEmision.Tarjeta.TitularTarjeta))
                    {
                        _T.Add(XmlTC(InfoEmision, false));
                        _T.Add(XmlDomiciliacion(InfoEmision));

                        _T_log.Add(XmlTC(InfoEmision, true));
                        _T_log.Add(XmlDomiciliacion(InfoEmision));
                    }
                }
                _T.Add(new XElement("error"));
                _T_log.Add(new XElement("error"));

                xRequest.Add(_T);
                //xmlEnvio = xRequest.ToString().Replace("\n", "").Replace("\r", "");

                xRequest_log.Add(_T_log);
                xmlEnvio = xRequest_log.ToString().Replace("\n", "").Replace("\r", "");

                log.Info("ANA XML Emision Request -  " + xmlEnvio);

                var servicio = new ANA_Consultas.ServiceSoapClient();

                xmlRespuesta = servicio.Transaccion(xRequest, ANA_Consultas.TipoTransaccion.Emision, InfoEmision.Convenio.Usuario, InfoEmision.Convenio.Contrasena);

                log.Info("ANA XML Emision Response -  " + xmlRespuesta);

                xmlRespuesta = xmlRespuesta.Substring(xmlRespuesta.IndexOf("<transacciones"));

                var resultadoEmision = Utilidades.Utilidades.GetXmlFromString<Transacciones>(xmlRespuesta);


                if (!string.IsNullOrWhiteSpace(resultadoEmision.Transaccion.Error))
                {

                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEnvio, xmlRespuesta, resultadoEmision.Transaccion.Error, "Emisión");

                    result = new EmisionPoliza(false, xmlEnvio, "Tuvimos inconveniente al generar tu póliza, por favor intentalo más tarde. " + resultadoEmision.Transaccion.Error, null);
                }
                else
                {
                    #region Generacion Póliza

                    int IdPaquete = int.Parse(cotizacionDetalle.Paquete);
                    var tipoPaquete = db.PaqueteAseguradora.Where(x => x.IdAseguradora == InfoEmision.Convenio.IdAseguradora && x.IdCatTipoPaquete == IdPaquete).FirstOrDefault();
                    var polizaANA = resultadoEmision.Transaccion.Poliza;


                    Poliza poliza = new Poliza();
                    PolizaDetalle polizaDet = new PolizaDetalle();

                    Endoso endosoAlta = new Endoso();
                    endosoAlta.IdTipoEndoso = db.TipoEndoso.FirstOrDefault(x => x.Clave.Equals("A")).Id;
                    endosoAlta.Fecha = DateTime.Now;
                    endosoAlta.ValorAnterior = "Alta";
                    endosoAlta.ValorActual = "Contratación";

                    poliza.NumeroPoliza = polizaANA.Id;
                    poliza.InicioVigencia = Convert.ToDateTime(polizaANA.Feciniciovig);
                    poliza.FinVigencia = Convert.ToDateTime(polizaANA.Fecterminovig);

                    poliza.PrimaNeta = 0;
                    poliza.PrimaNetaAnualizada = 0;
                    poliza.PrimaTotal = 0;
                    poliza.PrimaTotalAnualizada = 0;

                    poliza.Motor = InfoEmision.NumeroMotor;
                    poliza.Serie = InfoEmision.NumeroSerie;
                    poliza.Placas = InfoEmision.Placas;
                    poliza.FechaEmision = DateTime.Now;
                    poliza.ConductorHabitual = InfoEmision.ObtieneNombreCompleto();
                    poliza.UrlPDFPoliza = "";
                    poliza.UrlPDFRecibos = "";
                    poliza.Estatus = 1;
                    poliza.IdUsuario = InfoEmision.DetalleUsuario.Id;
                    poliza.IdConvenio = InfoEmision.Convenio.Id;
                    poliza.IdParentesco = InfoEmision.Parentesco == null ? 19 : InfoEmision.Parentesco.Id;
                    poliza.IdTipoCobertura = tipoPaquete.IdCatTipoPaquete;
                    poliza.ClaveAgente = InfoEmision.Convenio.CodigoIntermediario;
                    poliza.Acepto_AvisoPrivacidad_Aseguradora = true;
                    poliza.Acepto_DescuentoPoliza = true;

                    polizaDet.Inciso = "1";
                    polizaDet.RenovacionAutomatica = InfoEmision.RenovacionAutomatica; // CAT Renovación automática: persiste la elección del usuario para ANA.
                    polizaDet.FechaDecisionRenovacionAutomaticaUtc = InfoEmision.FechaDecisionRenovacionAutomaticaUtc; // CAT Renovación automática: conserva la evidencia UTC de que la decisión fue capturada.
                    polizaDet.Deducible = 0;
                    polizaDet.Comision = 0;
                    polizaDet.Impuesto = 0;
                    polizaDet.Derechos = 0;
                    polizaDet.FactorIva = 16;
                    polizaDet.MigraOPERA = false;
                    polizaDet.UrlPDFPolizaOPERA = "";
                    polizaDet.PolizaOPERA = 0;
                    polizaDet.OTOpera = 0;
                    polizaDet.EndosoOPERA = 0;
                    polizaDet.IdCotizacionAuto = InfoEmision.CotizacionAutoGuardar.Id;
                    polizaDet.IdCotizacionDetalle = cotizacionDetalle.Id;
                    polizaDet.IdCatRamoVehiculo = cotizacionDetalle.IdVehiculo;
                    polizaDet.BeneficiarioPreferente = InfoEmision.BeneficiarioPreferente;
                    polizaDet.IdCatModalidadFormaPago = cotizacionDetalle.IdMedioPago ?? 0;
                    polizaDet.IdCatPeriodicidadFormaPago = cotizacionDetalle.IdFormaPago ?? 1;
                    polizaDet.XMLRecepcion = xmlRespuesta;
                    polizaDet.XMLSolicitud = xmlEnvio;
                    polizaDet.IdDireccion = InfoEmision.Empresa.Direccion.Id;

                    if (InfoEmision.IdMSI.HasValue)
                        polizaDet.IdMSI = InfoEmision.IdMSI;

                    List<Recibo> recibosGenerados = new List<Recibo>();
                    int numRecConsec = 1;
                    foreach (var recibo in resultadoEmision.Transaccion.Recibo.OrderBy(x => Convert.ToDateTime(x.Fecterminovig)))
                    {
                        Recibo reciboSave = new Recibo();
                        reciboSave.InicioVigencia = Convert.ToDateTime(recibo.Feciniciovig);
                        reciboSave.FinVigencia = Convert.ToDateTime(recibo.Fecterminovig);
                        reciboSave.Numero = numRecConsec;//recibo._Id;
                        reciboSave.NoAsegurado = recibo.Id;
                        reciboSave.PrimaNeta = recibo._Primaneta;
                        reciboSave.Derecho = recibo._Derecho;
                        reciboSave.Recargo = recibo._Recargo;
                        reciboSave.Comision = recibo._Comision;
                        reciboSave.Impuesto = recibo._Impuesto;
                        reciboSave.PrimaTotal = recibo._Primatotal;
                        recibosGenerados.Add(reciboSave);
                        numRecConsec++;


                    }

                    polizaDet.Derechos = Convert.ToDecimal(resultadoEmision.Transaccion.Prima._Derecho);
                    polizaDet.Impuesto = Convert.ToDecimal(resultadoEmision.Transaccion.Prima._Impuesto);
                    polizaDet.Comision = Convert.ToDecimal(resultadoEmision.Transaccion.Prima._Comision);
                    polizaDet.Recargos = Convert.ToDecimal(resultadoEmision.Transaccion.Prima._Recargo);

                    poliza.PrimaNeta = Convert.ToDecimal(resultadoEmision.Transaccion.Prima._Primaneta); //polizaBanorte.certificado.tot_cpto.pcert;
                    poliza.PrimaTotal = Convert.ToDecimal(resultadoEmision.Transaccion.Prima._Primatotal);

                    poliza.PrimaNetaAnualizada = poliza.PrimaNeta;
                    poliza.PrimaTotalAnualizada = poliza.PrimaTotal;

                    endosoAlta.Recibo = recibosGenerados;
                    poliza.Endoso.Add(endosoAlta);
                    poliza.PolizaDetalle.Add(polizaDet);
                    db.Poliza.Add(poliza);
                    db.SaveChanges();

                    poliza.UrlPDFPoliza = ImprimirPoliza(poliza.NumeroPoliza, InfoEmision.Convenio.Id);

                    #endregion

                    Utilidades.Utilidades.RegistroPolizaProcesoDerivacion(poliza.NumeroPoliza);

                    GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEnvio, xmlRespuesta, "", "Emisión");

                    result = new EmisionPoliza(true, xmlEnvio, xmlRespuesta, poliza);

                }

            }
            catch (Exception ex)
            {
                log.Info(string.Format("ANA - Tuvimos un inconveniente para realizar tu emision {0} ", ex.Message));

                GeneraBitacoraPoliza.GenerarBitacoraPoliza(InfoEmision, username, xmlEnvio, xmlRespuesta, ex.InnerException != null ? ex.InnerException.Message : ex.Message, "Emisión");

                //throw new Exception(string.Format("Tuvimos un inconveniente para realizar tu emision {0} ", ex.Message));
                result = new EmisionPoliza(false, xmlEnvio, ex.Message);
            }
            return result;

        }

        public string ImprimirPoliza(string poliza, int idConvenio, string endoso = "")
        {
            var urlPoliza = "";
            try
            {
                SqlParameter _numeroPoliza = new SqlParameter("@Poliza", poliza);
                var datosPoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", _numeroPoliza).FirstOrDefault();

                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);

                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == idConvenio && x.IdCatPeriodicidadFormaPago == datosPoliza.IdFormaPago).FirstOrDefault();
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == idConvenio && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago && a.IdCatModalidadFormaPago == datosPoliza.IdMedioPago);

                var claveAgente = Convert.ToInt32(modalidadFormaPago.ClaveAgenteModalidadFormaPago);


                var _T = XmlTransaccion("I", claveAgente, "");

                if (string.IsNullOrEmpty(endoso) || endoso.Length < 6)
                    endoso = endoso.PadLeft(6, '0');
                else
                {
                    endoso = endoso.Substring(endoso.Length - 6);
                }

                XElement xRequest = new XElement("transacciones");
                _T.Add(XmlPoliza_Impresion(poliza, endoso));
                _T.Add(new XElement("error"));
                xRequest.Add(_T);

                log.Info("ANA XML Impresion Request -  " + xRequest.ToString());

                var servicio = new ANA_Consultas.ServiceSoapClient();

                var resultado = servicio.Transaccion(xRequest, ANA_Consultas.TipoTransaccion.Impresion, convenio.Usuario, convenio.Contrasena);

                log.Info("ANA XML Impresion Response -  " + resultado);

                resultado = resultado.Substring(resultado.IndexOf("<transacciones"));

                var resultadoImpresion = Utilidades.Utilidades.GetXmlFromString<Transacciones>(resultado);

                if (string.IsNullOrWhiteSpace(resultadoImpresion.Transaccion.Error))
                {
                    urlPoliza = resultadoImpresion.Transaccion.Poliza.Link;
                }

            }
            catch (Exception ex)
            {
                log.Info(string.Format("ANA - ImprimirPoliza Tuvimos un inconveniente para imprimir la poliza {0} ", ex.InnerException != null ? ex.InnerException.Message : ex.Message));

            }

            return urlPoliza;

        }

        public EstatusOperacion CancelacionPoliza(string numeroPoliza, int idConvenio, int idMotivoCancelacion)
        {
            var estatusOperacion = new EstatusOperacion();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
                bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                var catMotivo = db.CatMotivoCancelacion.FirstOrDefault(a => a.Id == idMotivoCancelacion);

                SqlParameter _numeroPoliza = new SqlParameter("@Poliza", numeroPoliza);

                var datosPoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", _numeroPoliza).FirstOrDefault();

                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == idConvenio && x.IdCatPeriodicidadFormaPago == datosPoliza.IdFormaPago).FirstOrDefault();
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == idConvenio && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago && a.IdCatModalidadFormaPago == datosPoliza.IdMedioPago);

                var claveAgente = Convert.ToInt32(modalidadFormaPago.ClaveAgenteModalidadFormaPago);

                var idMotivoANA = 29;

                if (catMotivo != null && catMotivo.IdANA != null)
                    idMotivoANA = catMotivo.IdANA.Value;

                var endpoint = "";


                if (EsProduccion)
                {
                    endpoint = Utilidades.Utilidades.ObtienerValorParametro("ANA_API_Opeaciones_URL");

                }
                else
                {
                    endpoint = Utilidades.Utilidades.ObtienerValorParametro("ANA_API_Opeaciones_QA_URL");

                }

                var proxy = new ANAOperacionesProxy(endpoint, convenio.Usuario, convenio.Contrasena, claveAgente);

                var numeroPolizaANA = numeroPoliza.Substring(2, 9);

                var response = proxy.CancelarPoliza(numeroPolizaANA, idMotivoANA);

                jsonRequest = response.JsonData.RequestBody;
                jsonResponse = response.JsonData.ResponseContent;
                urlMethod = response.Url;

                if (response.success)
                {
                    estatusOperacion.Exitoso = true;

                    log.Info(string.Format("Cancelación de póliza exitosa)"));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al cancelar la poliza: {0} Error: {1})", numeroPoliza, response.JsonData.ResponseContent ?? ""));

                    estatusOperacion.Mensaje = "Algo salió mal en en la cancelacion de poliza, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    estatusOperacion.MensajeCatalogo = response.mensajeError;
                }


            }
            catch (Exception ex)
            {
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            Utilidades.Utilidades.RegistroEndosoBitacora(4, urlMethod, numeroPoliza, estatusOperacion.MensajeCatalogo ?? "", jsonRequest, jsonResponse);

            return estatusOperacion;

        }

        public EstatusOperacion EndosoVehiculo(string numeroPoliza, int idConvenio, Modificacion modificacion)
        {
            var estatusOperacion = new EstatusOperacion();

            string jsonRequest = "";
            string jsonResponse = "";
            var urlMethod = "";

            try
            {
                bool EsProduccion = ConfigurationManager.AppSettings["TipoConexion"].Equals("1") || ConfigurationManager.AppSettings["TipoConexion"] == null ? false : true;
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);
                var endpoint = "";

                SqlParameter _numeroPoliza = new SqlParameter("@Poliza", numeroPoliza);

                var datosPoliza = db.sp_POLIZA_DatosPoliza.SqlQuery("sp_POLIZA_DatosPoliza @Poliza", _numeroPoliza).FirstOrDefault();

                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == idConvenio && x.IdCatPeriodicidadFormaPago == datosPoliza.IdFormaPago).FirstOrDefault();
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == idConvenio && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago && a.IdCatModalidadFormaPago == datosPoliza.IdMedioPago);

                var claveAgente = Convert.ToInt32(modalidadFormaPago.ClaveAgenteModalidadFormaPago);


                if (EsProduccion)
                {
                    endpoint = Utilidades.Utilidades.ObtienerValorParametro("ANA_API_Opeaciones_URL");

                }
                else
                {
                    endpoint = Utilidades.Utilidades.ObtienerValorParametro("ANA_API_Opeaciones_QA_URL");

                }

                var proxy = new ANAOperacionesProxy(endpoint, convenio.Usuario, convenio.Contrasena, claveAgente);
                var request = new EndosoVehiculoRequest();

                request.Item = new ItemEndosoVehiculo();

                var numeroPolizaANA = numeroPoliza.Substring(2, 9);

                request.Item.Poliza = numeroPolizaANA;

                switch (modificacion.IdTipoModificacion)
                {
                    case 2: request.Item.Motor = modificacion.DebeDecir; break;
                    case 3: request.Item.Placas = modificacion.DebeDecir; break;
                    case 4: request.Item.Serie = modificacion.DebeDecir.Substring(0, 11); break;
                    case 5:
                        request.Item.Conductor = ($"{modificacion.Nombre} {modificacion.ApellidoPaterno} {modificacion.ApellidoMaterno}").Trim();
                        break;

                }

                var response = proxy.EndosoVehiculo(request);

                jsonRequest = response.JsonData.RequestBody;
                jsonResponse = response.JsonData.ResponseContent;
                urlMethod = response.Url;

                if (response.success)
                {
                    estatusOperacion.Exitoso = true;
                    estatusOperacion.IdEndosoB = response.Identificador;

                    log.Info(string.Format("Corrección de objeto de póliza exitosa)"));

                }
                else
                {
                    log.Info(string.Format("Ocurrio un error al enviar la correción de objetos de la poliza: {0} Error: {1})", numeroPoliza, response.JsonData.ResponseContent ?? ""));

                    estatusOperacion.Mensaje = "Algo salió mal en él envió de la correción de la póliza, acércate con tu asesor de servicio";
                    estatusOperacion.Exitoso = false;
                    estatusOperacion.EsReintentable = false;
                    estatusOperacion.MensajeCatalogo = response.mensajeError;
                }


            }
            catch (Exception ex)
            {
                jsonResponse += ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }

            Utilidades.Utilidades.RegistroEndosoBitacora(2, urlMethod, numeroPoliza, estatusOperacion.MensajeCatalogo ?? "", jsonRequest, jsonResponse);

            return estatusOperacion;

        }

        public List<CatBanco> ObtenerBancos(int idConvenio, int idCotizacionDetalle)
        {
            var bancos = new List<CatBanco>();
            try
            {
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);

                var cotizacionDetalle = db.CotizacionDetalle.FirstOrDefault(a => a.Id == idCotizacionDetalle);

                var perioricidad = db.PeriodicidadFormaPago.Where(x => x.IdConvenio == cotizacionDetalle.IdConvenio && x.IdCatPeriodicidadFormaPago == cotizacionDetalle.IdFormaPago).FirstOrDefault();
                var modalidadFormaPago = db.ModalidadFormaPago.FirstOrDefault(a => a.IdConvenio == cotizacionDetalle.IdConvenio && a.IdCatPeriodicidadFormaPago == perioricidad.IdCatPeriodicidadFormaPago && a.IdCatModalidadFormaPago == cotizacionDetalle.IdMedioPago);

                var claveAgente = Convert.ToInt32(modalidadFormaPago.ClaveAgenteModalidadFormaPago);

                log.Info("ANA Obtencion de bancos -  " + idConvenio.ToString());

                var servicio = new ANA_Consultas.ServiceSoapClient();

                var resultado = servicio.Bancos(claveAgente, convenio.Usuario, convenio.Contrasena);

                log.Info("ANA Obtencion de bancos Response -  " + resultado);

                resultado = resultado.Substring(resultado.IndexOf("<transacciones"));

                var resultadoBancos = Utilidades.Utilidades.GetXmlFromString<Transacciones>(resultado);

                if (resultadoBancos.Bancos != null)
                {
                    foreach (var banco in resultadoBancos.Bancos)
                    {
                        var item = new CatBanco();
                        item.Id = banco._Id;
                        item.BancoId = banco._Id;
                        item.Nombre = banco.Text;
                        item.Abreviacion = banco.Text;

                        bancos.Add(item);
                    }
                }

            }
            catch (Exception ex)
            {
                log.Info(string.Format("ANA - ImprimirPoliza Tuvimos un inconveniente para imprimir la poliza {0} ", ex.InnerException != null ? ex.InnerException.Message : ex.Message));

            }

            return bancos;

        }

        public string ObtenerEstadoANA(string codigoPostal, int idConvenio, int claveAgente)
        {
            var estadoANA = "";
            try
            {
                var convenio = db.Convenio.FirstOrDefault(a => a.Id == idConvenio);

                log.Info("ANA Obtencion de colonias del CP -  " + codigoPostal);

                var servicio = new ANA_Consultas.ServiceSoapClient();

                var resultado = servicio.ColxCP(claveAgente, codigoPostal, convenio.Usuario, convenio.Contrasena);

                log.Info("ANA Obtencion de colonias del CP Response: -  " + resultado);

                resultado = resultado.Substring(resultado.IndexOf("<transacciones"));

                var resultadoColonias = Utilidades.Utilidades.GetXmlFromString<Transacciones>(resultado);

                if (resultadoColonias.Colonias != null && resultadoColonias.Colonias.Any())
                {
                    var colonia = resultadoColonias.Colonias.First();
                    estadoANA = $"{colonia.IdEstado.PadLeft(2, '0')}{colonia.IdDelMun.PadLeft(3, '0')}";
                }

            }
            catch (Exception ex)
            {
                log.Info(string.Format("ANA - ImprimirPoliza Tuvimos un inconveniente para imprimir la poliza {0} ", ex.InnerException != null ? ex.InnerException.Message : ex.Message));

            }

            return estadoANA;

        }

        public EmisionPoliza EmitirCeroVehiculo(InformacionEmision InfoEmision)
        {
            throw new System.NotImplementedException();
        }
        public Poliza GeneraDocumentoPoliza()
        {
            throw new NotImplementedException();
        }
        public EstatusOperacion PagoConTarjeta(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoDescuentoNomina(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }

        public string PagoReferenciado(DatosCobranza datosCobranza)
        {
            throw new NotImplementedException();
        }
        public Poliza GeneraReciboPoliza()
        {
            throw new NotImplementedException();
        }
        public List<string> ReimprimePoliza(string NumeroPoliza, string NumeroNegocio, string ClaveAgente, string Endoso = "", int Inciso = 0)
        {
            throw new NotImplementedException();
        }
        private List<Coberturas> ObtenerCoberturas(int idConvenio, int idPaquete, int IdTipoVehiculo, int idPaqueteConvenio)
        {

            ApplicationDbContext db = new ApplicationDbContext();
            List<Coberturas> coberturas = (from a in db.PaqueteDetalle
                                           join b in db.Cobertura on a.IdCobertura equals b.Id
                                           join c in db.ConvenioRamoPaquete on a.IdConvenioRamoPaquete equals c.Id
                                           where c.IdConvenio == idConvenio
                                           && a.IdCatTipoPaquete == idPaquete
                                           && c.IdCatRamoVehiculo == IdTipoVehiculo
                                           && a.IdPaqueteConvenio == idPaqueteConvenio
                                           select new Coberturas()
                                           {
                                               Codigo = b.Clave.Replace("\r\n", ""),
                                               Deducible = a.Deducible > 0 ? (a.Deducible).ToString() : string.Empty,
                                               Nombre = b.Descripcion.Replace("\r\n", ""),
                                               SumaAsegurada = a.SumaAsegurada == "0" ? string.Empty : a.SumaAsegurada,
                                               Cobertura = a.Descripcion.Replace("\r\n", ""),
                                               IdCatRamo = c.IdCatRamoVehiculo,
                                               IdCobertura = b.Id,
                                               IdTipoDatoDeducible = a.IdTipoDatoDeducible ?? 1
                                           }).ToList();
            return coberturas;
        }

        private XElement XmlTransaccion(string tipo, int claveAgente, string cotizacionANA)
        {
            XElement root = new XElement("transaccion");

            root.Add(new XAttribute("version", "1"),
                     new XAttribute("tipotransaccion", tipo),
                     new XAttribute("cotizacion", cotizacionANA),
                     new XAttribute("negocio", claveAgente),
                     new XAttribute("tiponegocio", ""));

            return root;
        }

        private XElement XmlVehiculo(mDetalles cot, string estadoANA, string plan, string modelo)
        {
            XElement root = new XElement("vehiculo");


            root.Add(new XAttribute("id", "1"),
                     new XAttribute("amis", cot.Catalogo[0].CatDescripciones[0].clave),
                     new XAttribute("modelo", modelo),
                     new XAttribute("descripcion", ""),
                     new XAttribute("uso", "1"),
                     new XAttribute("servicio", "1"),
                     new XAttribute("plan", plan),
                     new XAttribute("motor", ""),
                     new XAttribute("serie", ""),
                     new XAttribute("repuve", ""),
                     new XAttribute("placas", ""),
                     new XAttribute("conductor", ""),
                     new XAttribute("conductorliciencia", ""),
                     new XAttribute("conductorfecnac", ""),
                     new XAttribute("conductorocupacion", ""),
                     new XAttribute("estado", estadoANA),
                     new XAttribute("poblacion", ""),
                     new XAttribute("color", ""),
                     new XAttribute("dispositivo", ""),
                     new XAttribute("fecdispositivo", ""),
                     new XAttribute("tipocarga", ""),
                     new XAttribute("tipocargadescripcion", ""));

            return root;
        }

        private XElement XmlCobertura(string id, string dec, decimal? sa, string tipo, decimal? ded, decimal? pma)
        {

            XElement root = new XElement("cobertura");

            root.Add(new XAttribute("id", id),
                     new XAttribute("desc", ""),
                     new XAttribute("sa", sa.HasValue ? sa.Value.ToString() : ""),
                     new XAttribute("tipo", tipo),
                     new XAttribute("ded", ded.HasValue ? ded.Value.ToString() : ""),
                      new XAttribute("pma", pma.HasValue ? pma.Value.ToString() : ""));

            return root;
        }

        private XElement XmlAsegurado(int tipoPersona, CodigoPostal codigo, string estadoANA)
        {
            XElement root = new XElement("asegurado");

            root.Add(new XAttribute("id", ""),
                     new XAttribute("nombre", ""),
                     new XAttribute("paterno", ""),
                     new XAttribute("materno", ""),
                     new XAttribute("calle", "1"),
                     new XAttribute("numerointerior", ""),
                     new XAttribute("numeroexterior", ""),
                     new XAttribute("colonia", ""),
                     new XAttribute("poblacion", ""),
                     new XAttribute("estado", $"{estadoANA}"),
                     new XAttribute("cp", codigo.Codigo),
                     new XAttribute("pais", ""),
                     new XAttribute("tipopersona", tipoPersona));

            return root;
        }

        private XElement XmlAsegurado(int tipoPersona, InformacionEmision infoEmision, int claveAgente)
        {
            XElement root = new XElement("asegurado");

            if (tipoPersona == 1)
            {
                var estadoANAUsuario = ObtenerEstadoANA(infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Codigo, infoEmision.Convenio.Id, claveAgente);

                root.Add(new XAttribute("id", ""),
                         new XAttribute("nombre", ($"{infoEmision.PrimerNombre} {infoEmision.SegundoNombre ?? ""}").Trim()),
                         new XAttribute("paterno", infoEmision.ApellidoPaterno),
                         new XAttribute("materno", infoEmision.ApellidoMaterno ?? ""),
                         new XAttribute("calle", infoEmision.DatosUsuario.Direccion.Calle),
                         new XAttribute("numerointerior", infoEmision.DatosUsuario.Direccion.NumeroInt ?? ""),
                         new XAttribute("numeroexterior", infoEmision.DatosUsuario.Direccion.NumeroExt),
                         new XAttribute("colonia", infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Asentamiento),
                         new XAttribute("poblacion", infoEmision.DatosUsuario.Direccion.Municipio),
                         new XAttribute("estado", $"{estadoANAUsuario}"),
                         new XAttribute("cp", infoEmision.DatosUsuario.Direccion.CatCodigoPostal.Codigo),
                         new XAttribute("pais", "MEXICO"),
                         new XAttribute("tipopersona", tipoPersona));
            }
            else
            {
                var estadoANAEmpresa = ObtenerEstadoANA(infoEmision.Empresa.Direccion.CatCodigoPostal.Codigo, infoEmision.Convenio.Id, claveAgente);

                root.Add(new XAttribute("id", ""),
                         new XAttribute("nombre", ($"{infoEmision.Empresa.RazonSocial}").Trim()),
                         new XAttribute("paterno", ""),
                         new XAttribute("materno", ""),
                         new XAttribute("calle", infoEmision.Empresa.Direccion.Calle),
                         new XAttribute("numerointerior", infoEmision.Empresa.Direccion.NumeroInt ?? ""),
                         new XAttribute("numeroexterior", infoEmision.Empresa.Direccion.NumeroExt),
                         new XAttribute("colonia", infoEmision.Empresa.Direccion.CatCodigoPostal.Asentamiento),
                         new XAttribute("poblacion", infoEmision.Empresa.Direccion.Municipio),
                         new XAttribute("estado", $"{estadoANAEmpresa}"),
                         new XAttribute("cp", infoEmision.Empresa.Direccion.CatCodigoPostal.Codigo),
                         new XAttribute("pais", "MEXICO"),
                         new XAttribute("tipopersona", tipoPersona));
            }

            return root;
        }

        private XElement XmlAsegurado(PersonaMoral personaMoral, int idConvenio, int claveAgente)
        {
            XElement root = new XElement("asegurado");

            var estadoANAEmpresa = ObtenerEstadoANA(personaMoral.Direccion.CatCodigoPostal.Codigo, idConvenio, claveAgente);

            root.Add(new XAttribute("id", ""),
                     new XAttribute("nombre", ($"{personaMoral.RazonSocial}").Trim()),
                     new XAttribute("paterno", ""),
                     new XAttribute("materno", ""),
                     new XAttribute("calle", personaMoral.Direccion.Calle),
                     new XAttribute("numerointerior", personaMoral.Direccion.NumeroInt ?? ""),
                     new XAttribute("numeroexterior", personaMoral.Direccion.NumeroExt),
                     new XAttribute("colonia", personaMoral.Direccion.CatCodigoPostal.Asentamiento),
                     new XAttribute("poblacion", personaMoral.Direccion.Municipio),
                     new XAttribute("estado", $"{estadoANAEmpresa}"),
                     new XAttribute("cp", personaMoral.Direccion.CatCodigoPostal.Codigo),
                     new XAttribute("pais", "MEXICO"),
                     new XAttribute("tipopersona", 2));

            return root;
        }

        private XElement XmlPoliza(CotizacionCompara compara, Convenio convenio, string formaPago, decimal descuento, List<ANA_Argumento> argumentos)
        {
            XElement root = new XElement("poliza");

            root.Add(new XAttribute("id", ""),
                     new XAttribute("tipo", "A"),
                     new XAttribute("endoso", ""),
                     new XAttribute("fecemision", compara.FechaInicio.ToString("dd/MM/yyyy")),
                     new XAttribute("feciniciovig", compara.FechaInicio.ToString("dd/MM/yyyy")),
                     new XAttribute("fecterminovig", compara.FechaFin.ToString("dd/MM/yyyy")),
                     new XAttribute("moneda", "00"),
                     new XAttribute("bonificacion", descuento),
                     new XAttribute("formapago", formaPago),
                     new XAttribute("agente", convenio.Usuario),
                     new XAttribute("tarifacuotas", ""),
                     new XAttribute("tarifavalores", ""),
                     new XAttribute("tarifaderechos", ""),
                     new XAttribute("beneficiario", ""),
                     new XAttribute("politicacancelacion", "1"));


            if (argumentos != null)
            {
                foreach (var argumento in argumentos)
                {
                    root.Add(XmlArgumento(argumento.IdArgumento, argumento.Tipo ?? "", argumento.Campo ?? "", argumento.Valor ?? ""));
                }
            }
            return root;
        }

        private XElement XmlPoliza_Impresion(string numeroPoliza, string endoso)
        {
            XElement root = new XElement("poliza");

            root.Add(new XAttribute("id", numeroPoliza),
                     new XAttribute("endoso", endoso),
                     new XAttribute("inciso", "1"),
                     new XAttribute("link", ""));

            return root;
        }

        private XElement XmlPrima()
        {
            XElement root = new XElement("prima");

            root.Add(new XAttribute("primaneta", ""),
                     new XAttribute("derecho", ""),
                     new XAttribute("recargo", ""),
                     new XAttribute("impuesto", ""),
                     new XAttribute("primatotal", ""),
                     new XAttribute("comision", ""));

            return root;
        }

        private XElement XmlRecibo()
        {
            XElement root = new XElement("recibo");

            root.Add(new XAttribute("id", ""),
                     new XAttribute("feciniciovig", ""),
                     new XAttribute("fecterminovig", ""),
                     new XAttribute("primaneta", ""),
                     new XAttribute("derecho", ""),
                     new XAttribute("recargo", ""),
                     new XAttribute("impuesto", ""),
                     new XAttribute("primatotal", ""),
                     new XAttribute("comision", ""),
                     new XAttribute("cadenaoriginal", ""),
                     new XAttribute("sellodigital", ""),
                     new XAttribute("fecemision", ""),
                     new XAttribute("serie", ""),
                     new XAttribute("folio", ""),
                     new XAttribute("horaemision", ""),
                     new XAttribute("numeroaprobacion", ""),
                     new XAttribute("anoaprobacion", ""),
                     new XAttribute("numseriecertificado", ""));

            return root;
        }

        private XElement XmlArgumento(int id, string tipo, string campo, string valor)
        {
            XElement root = new XElement("argumento");

            root.Add(new XAttribute("id", id),
                     new XAttribute("tipo", tipo),
                     new XAttribute("campo", campo),
                     new XAttribute("valor", valor));

            return root;
        }

        private XElement XmlTC(InformacionEmision infoEmision, bool log)
        {
            XElement root = new XElement("tarjetacredito");

            if (log)
            {
                root.Add(new XAttribute("cliente", $"{infoEmision.Tarjeta.TitularTarjeta}"),
                         new XAttribute("numero", infoEmision.Tarjeta.NumeroTarjeta.Substring(infoEmision.Tarjeta.NumeroTarjeta.Length - 4).PadLeft(16, '*')),
                         new XAttribute("vencimiento", "**/**"),
                         new XAttribute("codigoseguridad", "****"));
            }
            else
            {
                root.Add(new XAttribute("cliente", $"{infoEmision.Tarjeta.TitularTarjeta}"),
                         new XAttribute("numero", infoEmision.Tarjeta.NumeroTarjeta),
                         new XAttribute("vencimiento", $"{infoEmision.Tarjeta.MesVencimiento}/{infoEmision.IdAnio.ToString().Substring(2)}"),
                         new XAttribute("codigoseguridad", infoEmision.Tarjeta.Cvv));
            }
            return root;
        }

        private XElement XmlDomiciliacion(InformacionEmision infoEmision)
        {
            XElement root = new XElement("domiciliacion");

            root.Add(new XAttribute("banco", infoEmision.IdBanco),
                     new XAttribute("direcciontarjetahabiente", $"{infoEmision.DatosUsuario.Direccion.Calle} {infoEmision.DatosUsuario.Direccion.NumeroExt}"),
                     new XAttribute("envio", $"N"),
                     new XAttribute("rfc", $"{infoEmision.DatosUsuario.RFC}"),
                     new XAttribute("fiscal", "N"));

            return root;
        }

        private bool EsCoberturaConCondicionEspecial(int Idconvenio, string IdCobertura, string Anio, int idCatRamoVehiculo)
        {

            bool Aplica = true;
            int Clave = int.Parse(IdCobertura);

            LocktonModel.VModels.Coberturas cotCob = new LocktonModel.VModels.Coberturas();

            //Auto En agencia
            LocktonModel.db.CoberturasCondicionesEspeciales coberturasCondicionesEspeciales = db.CoberturasCondicionesEspeciales.FirstOrDefault(x => x.IdConvenio == Idconvenio && x.IdCobertura == Clave && x.CondicionEspecial.Estatus == true && x.IdCatRamoVehiculo == idCatRamoVehiculo);
            LocktonModel.db.CondicionEspecial condicionEspecial = new LocktonModel.db.CondicionEspecial();
            if (coberturasCondicionesEspeciales != null)
                condicionEspecial = db.CondicionEspecial.FirstOrDefault(x => x.Id == coberturasCondicionesEspeciales.IdCondicionEspecial && x.Estatus == true);

            ///Reparacion En agencia
            if (condicionEspecial.Valor1 != null && condicionEspecial.Valor2 != null)
            {
                if (int.Parse(condicionEspecial.Valor1) <= int.Parse(Anio) && int.Parse(Anio) <= int.Parse(condicionEspecial.Valor2))
                {
                    Aplica = true;
                }
                else
                    Aplica = false;
            }

            return Aplica;
        }

    }
}

