USE [LocktonOne_DB];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* CAT Renovación automática: agrega por convenio el interruptor y el aviso que se mostrarán durante la emisión. */
IF COL_LENGTH(N'dbo.Convenio', N'MostrarAvisoRenovacionAutomatica') IS NULL
BEGIN
    ALTER TABLE dbo.Convenio
        ADD MostrarAvisoRenovacionAutomatica BIT NOT NULL
            CONSTRAINT DF_Convenio_MostrarAvisoRenovacionAutomatica DEFAULT (0) WITH VALUES;
END;
GO

/* CAT Renovación automática: corrige instalaciones previas que hubieran creado el indicador como nullable o sin default. */
UPDATE dbo.Convenio
   SET MostrarAvisoRenovacionAutomatica = 0
 WHERE MostrarAvisoRenovacionAutomatica IS NULL;

ALTER TABLE dbo.Convenio
    ALTER COLUMN MostrarAvisoRenovacionAutomatica BIT NOT NULL;

IF NOT EXISTS
(
    SELECT 1
      FROM sys.default_constraints dc
      INNER JOIN sys.columns c
              ON c.object_id = dc.parent_object_id
             AND c.column_id = dc.parent_column_id
     WHERE dc.parent_object_id = OBJECT_ID(N'dbo.Convenio')
       AND c.name = N'MostrarAvisoRenovacionAutomatica'
)
BEGIN
    ALTER TABLE dbo.Convenio
        ADD CONSTRAINT DF_Convenio_MostrarAvisoRenovacionAutomatica
            DEFAULT (0) FOR MostrarAvisoRenovacionAutomatica;
END;
GO

IF COL_LENGTH(N'dbo.Convenio', N'MensajeRenovacionAutomatica') IS NULL
BEGIN
    ALTER TABLE dbo.Convenio
        ADD MensajeRenovacionAutomatica NVARCHAR(MAX) NULL;
END;
GO

/* CAT Renovación automática: la fecha nullable separa decisiones nuevas de valores históricos que antes se guardaban en true. */
IF COL_LENGTH(N'dbo.PolizaDetalle', N'FechaDecisionRenovacionAutomaticaUtc') IS NULL
BEGIN
    ALTER TABLE dbo.PolizaDetalle
        ADD FechaDecisionRenovacionAutomaticaUtc DATETIME2(3) NULL;
END;
GO

/* CAT Renovación automática: crea una base mínima solo si el procedimiento aún no existe, para que el despliegue sea repetible. */
IF OBJECT_ID(N'dbo.sp_reporte_polizas_gerencia', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.sp_reporte_polizas_gerencia AS BEGIN SET NOCOUNT ON; END;');
END;
GO

ALTER PROCEDURE [dbo].[sp_reporte_polizas_gerencia]
    @gerencia NVARCHAR(MAX),
    @FechaInicio DATETIME,
    @FechaFin DATETIME,
    @soloCorporativo BIT = 0,
    @IdCorporativo INT = 0
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        doc.IDDocto [Identificador],
        ger.Nombre [Gerencia],
        doc.Documento [NumeroPoliza],
        cr.Nombre [Producto],
        csr.Nombre [SubProducto],
        fp.Nombre [Forma_pago],
        tp.Descripcion [Medio_pago],
        concia.NombreCompleto [Aseguradora],
        [fecha_inicio] = doc.FDesde,
        [fecha_fin] = doc.FHasta,
        doc.FCaptura [FechaCaptura],
        doc.PrimaNeta,
        doc.Impuesto1 [IVA],
        doc.Derechos,
        doc.PrimaTotal,
        [TipoVenta] =
            CASE
                WHEN doc.TVenta = 8 THEN 'Opera Tradicional'
                WHEN doc.TVenta = 6 THEN 'Tradicional'
                WHEN doc.TVenta = 5 THEN 'On-Line'
                WHEN doc.TVenta = 4 THEN 'Telemarketing'
                WHEN doc.TVenta = 3 THEN 'Ejecutivo'
                WHEN doc.TVenta = 2 THEN 'Agente'
                WHEN doc.TVenta = 1 THEN 'Vendedor'
                WHEN doc.TVenta = -1 OR doc.TVenta = NULL THEN ''
            END,
        det.Clave [ClaveVehicular],
        det.Marca,
        det.Tipo [Version],
        det.Modelo,
        det.Motor,
        det.Serie,
        det.Placas,
        cont.NombreCompleto [NombreEmpleado],
        [Numero_empleado] = ISNULL(cont.NEmpleado, ''),
        [Correo] = ISNULL(cont.EMail1, ''),
        ctr.NombreCompleto [Conductor_Habitual],
        CASE
            WHEN C.EstatusCobranza = 1 AND doc.StatusUser = 26 THEN 'Cancelado por Cobranza'
            WHEN C.EstatusCobranza = 1 AND doc.StatusUser = 27 THEN 'Rechazo por cobro en aclaración'
            ELSE st.Descripcion
        END [Estatus],
        ISNULL
        (
            (
                SELECT B.Nombre
                  FROM [1786_SistemaSICAS]..CfgProductosSCR A,
                       [1786_SistemaSICAS]..CatProductosS B
                 WHERE A.IDProductoS = B.IDProductoS
                   AND A.IDProdCR = det.IDProdCR
            ),
            ''
        ) [Paquete],
        [OTCancelacion] = '',
        [UserNameEmite] = ISNULL
        (
            (SELECT TOP 1 UserNameEmite FROM Poliza WHERE NumeroPoliza = doc.Documento),
            ''
        ),
        ISNULL(doc.Referencia1, '') [Referencia1],
        ISNULL(doc.Referencia2, '') [Referencia2],
        ISNULL(doc.Referencia3, '') [Referencia3],
        ISNULL(doc.Referencia4, '') [Referencia4],
        /* CAT Renovación automática: solo interpreta Referencia5 cuando existe evidencia de una decisión nueva. */
        CASE
            WHEN PD.FechaDecisionRenovacionAutomaticaUtc IS NULL THEN N'Sin registro'
            WHEN UPPER(LTRIM(RTRIM(ISNULL(doc.Referencia5, '')))) IN (N'SI', N'SÍ', N'1', N'TRUE') THEN N'Sí'
            WHEN UPPER(LTRIM(RTRIM(ISNULL(doc.Referencia5, '')))) IN (N'NO', N'0', N'FALSE') THEN N'No'
            WHEN PD.RenovacionAutomatica = 1 THEN N'Sí'
            ELSE N'No'
        END [Renovacion_Automatica],
        ISNULL(doc.Notas, '') [Notas],
        CASE WHEN doc.StatusUser = 30 THEN 'EMISION SIN TARJETA' ELSE '' END [EstatusUsuario],
        [MSI] = ISNULL(MSI.Descripcion, ''),
        [Estado] = ISNULL(CP.ESTADO, ''),
        [Ciudad] = ISNULL(CP.Ciudad, ''),
        [CodigoPostalCotizacion] = ISNULL(CO.CodigoPostal, ''),
        [CodigoPostalEmision] = ISNULL(dir.CodigoPostal, ''),
        [PaqueteRenombrado] = ISNULL(PC.NombrePaquete, ''),
        [CoberturaAdicional] = CASE
                                  WHEN P.NumeroPolizaAdicional IS NULL THEN CONVERT(BIT, 0)
                                  ELSE CONVERT(BIT, 1)
                              END,
        [BeneficiarioPreferente] = ISNULL(PD.BeneficiarioPreferente, ''),
        det.Tipo,
        [TipoSumaAsegurada] = CASE WHEN CO.ValorFactura > 0 THEN 'Factura' ELSE 'Comercial' END,
        [FechaFactura] = CASE WHEN CO.ValorFactura > 0 THEN CO.FechaFactura ELSE NULL END,
        [ValorVehiculo] = CO.ValorFactura,
        [NoFactura] = CO.NumeroFactura,
        det.Servicio
    FROM [1786_SistemaSICAS]..DatDocumentos doc WITH (NOLOCK)
    INNER JOIN [1786_SistemaSICAS]..DatDoctoDetail det WITH (NOLOCK)
            ON doc.IDDocto = det.IDDocto
    INNER JOIN [1786_SistemaSICAS]..CatGerencia ger WITH (NOLOCK)
            ON ger.IDGerencia = doc.IDGerencia
    INNER JOIN [1786_SistemaSICAS]..CatClientes cli WITH (NOLOCK)
            ON doc.IDCli = cli.IDCli
    INNER JOIN [1786_SistemaSICAS]..CatContactos cont WITH (NOLOCK)
            ON cont.IDCont = cli.IDCont
    INNER JOIN [1786_SistemaSICAS]..CatFPagos fp WITH (NOLOCK)
            ON fp.IDFPago = doc.IDFPago
    INNER JOIN [1786_SistemaSICAS]..CCatDoctoTipoPago tp WITH (NOLOCK)
            ON tp.IDCatGral = doc.TPago
    INNER JOIN [1786_SistemaSICAS]..CatContactos ctr WITH (NOLOCK)
            ON ctr.IDCont =
               CASE
                   WHEN det.IDAseg = 0 THEN cli.IDCont
                   WHEN det.IDAseg <> 0 AND det.IDAseg <> cli.IDCont THEN det.IDAseg
                   WHEN det.IDAseg <> 0 AND det.IDAseg = cli.IDCont THEN cli.IDCont
               END
    INNER JOIN [1786_SistemaSICAS]..CCatStatusDocto st WITH (NOLOCK)
            ON st.iValue = doc.Status
    INNER JOIN [1786_SistemaSICAS]..CatAgentes ag WITH (NOLOCK)
            ON doc.IDAgente = ag.IDAgente
    INNER JOIN [1786_SistemaSICAS]..CatCias cia WITH (NOLOCK)
            ON ag.IDCia = cia.IDCia
    INNER JOIN [1786_SistemaSICAS]..CatContactos concia WITH (NOLOCK)
            ON cia.IDCont = concia.IDCont
    INNER JOIN Empresa E WITH (NOLOCK)
            ON E.IdGerenciaCORE = doc.IDGerencia
           AND E.Estatus = 1
    INNER JOIN Corporativo CORP WITH (NOLOCK)
            ON CORP.Id = E.IdCorporativo
    INNER JOIN ConfiguracionEmpresa C WITH (NOLOCK)
            ON C.IdEmpresa = E.Id
    INNER JOIN [1786_SistemaSICAS]..CatSRamos csr WITH (NOLOCK)
            ON csr.IDSRamo = doc.IDSRamo
    INNER JOIN [1786_SistemaSICAS]..CatRamos cr WITH (NOLOCK)
            ON cr.IDRamo = csr.IDRamo
    LEFT JOIN Poliza P WITH (NOLOCK)
           ON doc.Documento = P.NumeroPoliza
    LEFT JOIN PolizaDetalle PD WITH (NOLOCK)
           ON P.Id = PD.IdPoliza
    LEFT JOIN CotizacionDetalle CD WITH (NOLOCK)
           ON PD.IdCotizacionDetalle = CD.Id
    LEFT JOIN Cotizacion CO WITH (NOLOCK)
           ON CD.IdCotizacion = CO.Id
    LEFT JOIN Direccion dir WITH (NOLOCK)
           ON PD.IdDireccion = dir.Id
    LEFT JOIN
    (
        SELECT DISTINCT CP.Codigo, ER.Estado, CP.Ciudad
          FROM CodigoPostal CP WITH (NOLOCK)
          INNER JOIN CatEstadosRepublica ER WITH (NOLOCK)
                  ON CP.IdEstado = ER.Id
    ) CP
           ON CO.CodigoPostal = CP.Codigo
    LEFT JOIN CatMesesSinIntereses MSI WITH (NOLOCK)
           ON PD.IdMSI = MSI.Id
    LEFT JOIN PaqueteConvenio PC WITH (NOLOCK)
           ON PC.Id = CD.IdPaqueteConvenio
    WHERE cr.IDRamo IN (2, 1)
      AND doc.TipoDocto = 1
      AND CONVERT(DATE, doc.FCaptura) >= CONVERT(DATE, @FechaInicio)
      AND CONVERT(DATE, doc.FCaptura) <= CONVERT(DATE, @FechaFin)
      AND
      (
          (@soloCorporativo = 1 AND CORP.Id = @IdCorporativo)
          OR
          (@soloCorporativo = 0 AND doc.IDGerencia IN
              (SELECT Item FROM dbo.SplitStrings_XML(@gerencia, ';')))
      )

    UNION ALL

    SELECT
        doc.IDDocto [Identificador],
        ger.Nombre [Gerencia],
        doc.Documento [NumeroPoliza],
        cr.Nombre [Producto],
        csr.Nombre [SubProducto],
        fp.Nombre [Forma_pago],
        tp.Descripcion [Medio_pago],
        concia.NombreCompleto [Aseguradora],
        [fecha_inicio] = doc.FDesde,
        [fecha_fin] = doc.FHasta,
        doc.FCaptura [FechaCaptura],
        doc.PrimaNeta,
        doc.Impuesto1 [IVA],
        doc.Derechos,
        doc.PrimaTotal,
        [TipoVenta] =
            CASE
                WHEN doc.TVenta = 8 THEN 'Opera Tradicional'
                WHEN doc.TVenta = 6 THEN 'Tradicional'
                WHEN doc.TVenta = 5 THEN 'On-Line'
                WHEN doc.TVenta = 4 THEN 'Telemarketing'
                WHEN doc.TVenta = 3 THEN 'Ejecutivo'
                WHEN doc.TVenta = 2 THEN 'Agente'
                WHEN doc.TVenta = 1 THEN 'Vendedor'
                WHEN doc.TVenta = -1 OR doc.TVenta = NULL THEN ''
            END,
        det.Clave [ClaveVehicular],
        det.Marca,
        det.Tipo [Version],
        det.Modelo,
        det.Motor,
        det.Serie,
        det.Placas,
        cont.NombreCompleto [NombreEmpleado],
        [Numero_empleado] = ISNULL(cont.NEmpleado, ''),
        [Correo] = ISNULL(cont.EMail1, ''),
        ctr.NombreCompleto [Conductor_Habitual],
        CASE
            WHEN C.EstatusCobranza = 1 AND doc.StatusUser = 26 THEN 'Cancelado por Cobranza'
            WHEN C.EstatusCobranza = 1 AND doc.StatusUser = 27 THEN 'Rechazo por cobro en aclaración'
            ELSE st.Descripcion
        END [Estatus],
        ISNULL
        (
            (
                SELECT B.Nombre
                  FROM [1786_SistemaSICAS]..CfgProductosSCR A,
                       [1786_SistemaSICAS]..CatProductosS B
                 WHERE A.IDProductoS = B.IDProductoS
                   AND A.IDProdCR = det.IDProdCR
            ),
            ''
        ) [Paquete],
        [OTCancelacion] = '',
        [UserNameEmite] = ISNULL
        (
            (SELECT TOP 1 UserNameEmite FROM Poliza WHERE NumeroPoliza = doc.Documento),
            ''
        ),
        ISNULL(doc.Referencia1, '') [Referencia1],
        ISNULL(doc.Referencia2, '') [Referencia2],
        ISNULL(doc.Referencia3, '') [Referencia3],
        ISNULL(doc.Referencia4, '') [Referencia4],
        /* CAT Renovación automática: los productos fuera del alcance de autos no tienen una decisión capturada. */
        N'Sin registro' [Renovacion_Automatica],
        ISNULL(doc.Notas, '') [Notas],
        CASE WHEN doc.StatusUser = 30 THEN 'EMISION SIN TARJETA' ELSE '' END [EstatusUsuario],
        [MSI] = ISNULL(MSI.Descripcion, ''),
        [Estado] = ISNULL(CP.ESTADO, ''),
        [Ciudad] = ISNULL(CP.Ciudad, ''),
        '' [CodigoPostalCotizacion],
        '' [CodigoPostalEmision],
        [PaqueteRenombrado] = ISNULL(PC.NombrePaquete, ''),
        CONVERT(BIT, 0) [CoberturaAdicional],
        '' [BeneficiarioPreferente],
        det.Tipo,
        '' [TipoSumaAsegurada],
        NULL [FechaFactura],
        NULL [ValorVehiculo],
        '' [NoFactura],
        det.Servicio
    FROM [1786_SistemaSICAS]..DatDocumentos doc WITH (NOLOCK)
    INNER JOIN [1786_SistemaSICAS]..DatDoctoDetail det WITH (NOLOCK)
            ON doc.IDDocto = det.IDDocto
    INNER JOIN [1786_SistemaSICAS]..CatGerencia ger WITH (NOLOCK)
            ON ger.IDGerencia = doc.IDGerencia
    INNER JOIN [1786_SistemaSICAS]..CatClientes cli WITH (NOLOCK)
            ON doc.IDCli = cli.IDCli
    INNER JOIN [1786_SistemaSICAS]..CatContactos cont WITH (NOLOCK)
            ON cont.IDCont = cli.IDCont
    INNER JOIN [1786_SistemaSICAS]..CatFPagos fp WITH (NOLOCK)
            ON fp.IDFPago = doc.IDFPago
    INNER JOIN [1786_SistemaSICAS]..CCatDoctoTipoPago tp WITH (NOLOCK)
            ON tp.IDCatGral = doc.TPago
    INNER JOIN [1786_SistemaSICAS]..CatContactos ctr WITH (NOLOCK)
            ON ctr.IDCont =
               CASE
                   WHEN det.IDAseg = 0 THEN cli.IDCont
                   WHEN det.IDAseg <> 0 AND det.IDAseg <> cli.IDCont THEN det.IDAseg
                   WHEN det.IDAseg <> 0 AND det.IDAseg = cli.IDCont THEN cli.IDCont
               END
    INNER JOIN [1786_SistemaSICAS]..CCatStatusDocto st WITH (NOLOCK)
            ON st.iValue = doc.Status
    INNER JOIN [1786_SistemaSICAS]..CatAgentes ag WITH (NOLOCK)
            ON doc.IDAgente = ag.IDAgente
    INNER JOIN [1786_SistemaSICAS]..CatCias cia WITH (NOLOCK)
            ON ag.IDCia = cia.IDCia
    INNER JOIN [1786_SistemaSICAS]..CatContactos concia WITH (NOLOCK)
            ON cia.IDCont = concia.IDCont
    INNER JOIN Empresa E WITH (NOLOCK)
            ON E.IdGerenciaCORE = doc.IDGerencia
           AND E.Estatus = 1
    INNER JOIN Corporativo CORP WITH (NOLOCK)
            ON CORP.Id = E.IdCorporativo
    INNER JOIN ConfiguracionEmpresa C WITH (NOLOCK)
            ON C.IdEmpresa = E.Id
    INNER JOIN [1786_SistemaSICAS]..CatSRamos csr WITH (NOLOCK)
            ON csr.IDSRamo = doc.IDSRamo
    INNER JOIN [1786_SistemaSICAS]..CatRamos cr WITH (NOLOCK)
            ON cr.IDRamo = csr.IDRamo
    LEFT JOIN PolizaProducto P WITH (NOLOCK)
           ON doc.Documento = P.NumeroPoliza
    LEFT JOIN PolizaProductoDetalle PD WITH (NOLOCK)
           ON P.Id = PD.IdPoliza
    LEFT JOIN CotizacionProductoDetalle CD WITH (NOLOCK)
           ON PD.IdCotizacionDetalle = CD.Id
    LEFT JOIN CotizacionProducto CO WITH (NOLOCK)
           ON CD.IdCotizacion = CO.Id
    LEFT JOIN
    (
        SELECT DISTINCT CP.Codigo, ER.Estado, CP.Ciudad
          FROM CodigoPostal CP WITH (NOLOCK)
          INNER JOIN CatEstadosRepublica ER WITH (NOLOCK)
                  ON CP.IdEstado = ER.Id
    ) CP
           ON P.CodigoPostal = CP.Codigo
    LEFT JOIN CatMesesSinIntereses MSI WITH (NOLOCK)
           ON PD.IdMSI = MSI.Id
    LEFT JOIN PaqueteConvenioProducto PC WITH (NOLOCK)
           ON PC.IdPlan = CD.IdPlan
          AND PC.IdConvenioProductos = CD.IdConvenio
    WHERE cr.IDRamo IN (9)
      AND doc.TipoDocto = 1
      AND CONVERT(DATE, doc.FCaptura) >= CONVERT(DATE, @FechaInicio)
      AND CONVERT(DATE, doc.FCaptura) <= CONVERT(DATE, @FechaFin)
      AND
      (
          (@soloCorporativo = 1 AND CORP.Id = @IdCorporativo)
          OR
          (@soloCorporativo = 0 AND doc.IDGerencia IN
              (SELECT Item FROM dbo.SplitStrings_XML(@gerencia, ';')))
      )
    ORDER BY FechaCaptura DESC;
END;
GO

/* CAT Renovación automática: crea una base mínima solo si el procedimiento aún no existe, para que el despliegue sea repetible. */
IF OBJECT_ID(N'dbo.sp_reporte_polizas_Emitidas_Linea_gerencia', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.sp_reporte_polizas_Emitidas_Linea_gerencia AS BEGIN SET NOCOUNT ON; END;');
END;
GO

ALTER PROCEDURE [dbo].[sp_reporte_polizas_Emitidas_Linea_gerencia]
    @gerencia INT,
    @FechaInicio DATETIME,
    @FechaFin DATETIME
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        P.Id [Identificador],
        CG.Nombre [Gerencia],
        P.NumeroPoliza [NumeroPoliza],
        A.Nombre [Aseguradora],
        P.FechaEmision [FechaCaptura],
        CON.Email [Correo_Enviado_A],
        [UserNameEmite] = ISNULL(P.UserNameEmite, ''),
        [Telefono1] = CON.telefonoCel,
        [Telefono2] = CON.telefonoFijo,
        [EmpresaUSR] = csr.nombreEmpresaUSR,
        [NombreUSRQueCotizo] = CONCAT(csr.Nombre, ' ', csr.Nombre2, ' ', csr.ApPaterno, ' ', csr.ApMaterno),
        /* CAT Renovación automática: evita presentar como aceptación los true históricos que no fueron elegidos. */
        [Renovacion_Automatica] = CASE
                                     WHEN PDTL.FechaDecisionRenovacionAutomaticaUtc IS NULL THEN N'Sin registro'
                                     WHEN PDTL.RenovacionAutomatica = 1 THEN N'Sí'
                                     ELSE N'No'
                                 END
    FROM LocktonOne_DB..Poliza P WITH (NOLOCK)
    INNER JOIN LocktonOne_DB..PolizaDetalle PDTL WITH (NOLOCK)
            ON P.Id = PDTL.IdPoliza
    INNER JOIN LocktonOne_DB..Convenio C WITH (NOLOCK)
            ON P.IdConvenio = C.Id
    INNER JOIN LocktonOne_DB..Empresa E WITH (NOLOCK)
            ON C.IdEmpresa = E.Id
    INNER JOIN [1786_SistemaSICAS]..CatGerencia CG WITH (NOLOCK)
            ON CG.IDGerencia = E.IdGerenciaCORE
    INNER JOIN LocktonOne_DB..Contratante CON WITH (NOLOCK)
            ON PDTL.IdContratante = CON.Id
    INNER JOIN LocktonOne_DB..Aseguradora A WITH (NOLOCK)
            ON C.IdAseguradora = A.Id
    INNER JOIN LocktonOne_DB..CotizacionDetalle CD WITH (NOLOCK)
            ON PDTL.IdCotizacionDetalle = CD.Id
    LEFT JOIN LocktonOne_DB..CotizacionSinRegistro csr WITH (NOLOCK)
           ON csr.IdCotizacion = CD.IdCotizacion
    WHERE P.Estatus IN (1, 23, 24, 20, 19, 18, 13)
      AND E.IdGerenciaCORE = @gerencia
      AND CONVERT(DATE, P.FechaEmision) >= CONVERT(DATE, @FechaInicio)
      AND CONVERT(DATE, P.FechaEmision) <= CONVERT(DATE, @FechaFin)
    ORDER BY P.FechaEmision DESC;
END;
GO

