﻿namespace LocktonModel.VModels
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Xml;
	using LocktonModel.db;
	using Newtonsoft.Json;

	public class InformacionEmision
    {
        private int idLugarNacimiento;
        private DateTime fechaNacimiento;
        private int idNacionalidad;
        private bool esFlotilla;
        private int formaPago;
        private db.Poliza poliza;
        private db.PolizaCasa polizaCasa;
        private db.PolizaDetalleCasa polizaCasaDetalle;
        private bool conductorHabitual;
        private int idParentesco;
        private string primerNombre;
        private string segundoNombre;
        private string apellidoPaterno;
        private string apellidoMaterno;
        private string primerNombreEmpleado;
        private string segundoNombreEmpleado;
        private string apellidoPaternoEmpledo;
        private string apellidoMaternoEmpleado;
        private string rfcEmpleado;
        private bool esPersonaPoliticamenteExpuesta;
        private bool esBeneficiarioPreferente;
        private string idBeneficiarioPreferente;
        private string numeroMotor;
        private string numeroSerie;
        private string placas;
        private int idCotizacion;
        private string email;
        private string confirmaEmail;
        private db.Direccion direccion;
        private string telefonoCel;
        private string telefonoFijo;
        private string tipoMovimiento;
        private string noPoliza;
        private string noCotizacion;
        private string noEndoso;
        private string tipoEndoso;
        private string noOTra;
        private string noNegocio;
        private string amis;
        private string noAsegurado;
        private string noInciso;
        private string paquete;
        private string moneda;
        private string noEmpleado;
        private Dictionary<string, XmlDocument> xmlsAseguradoras;
        private Vehiculo vehiculo;
        private Tarjeta tarjeta;
	
		private db.Empresa empresa;
		
		private db.DetalleUsuario detalleUsuario;
        private db.Convenio convenio;
        private db.ConvenioProductos convenioProducto;
        private string beneficiarioPreferente;
        private db.CatParentesco parentesco;
        private string aseguradora;
        private int idAnio;
        private int idBanco;
        private string rutaDescargaPDFsPolizas;
        private string benefMuerteAccidental;
        private bool esRenovacion;
        private db.CotizacionAuto cotizacionAuto;
        private VDatosUsuario datosUsuario;
        private int idEstado;
        private int idAsentamiento;
        private bool aplicaSucursales;
        private int idSucursal;
        private int edad;
        private string IdArrendado;
        private int? idBenefCore;
        private string urlReimpresionEncriptada;
        private bool esPromotor;
        private string inciso;
        public InformacionEmision()
        {
            this.aplicaSucursales = false;
            this.idSucursal = 0;
            this.idAsentamiento = 0;
            this.IdEstado = 0;
            this.datosUsuario = new VDatosUsuario();
            this.idLugarNacimiento = 0;
            this.fechaNacimiento = DateTime.Now.AddYears(-18);
            this.idNacionalidad = 0;
            this.esFlotilla = false;
            this.rutaDescargaPDFsPolizas = "";
            this.formaPago = 0;
            this.poliza = new db.Poliza();
            this.polizaCasa = new db.PolizaCasa();
            this.polizaCasaDetalle = new db.PolizaDetalleCasa();
            this.idBanco = 0;
            this.idAnio = 0;
            this.conductorHabitual = false;
            this.aseguradora = "";
            this.idParentesco = 0;
            this.primerNombre = "";
            this.segundoNombre = "";
            this.apellidoPaterno = "";
            this.apellidoMaterno = "";
            this.primerNombreEmpleado = "";
            this.segundoNombreEmpleado = "";
            this.apellidoPaternoEmpledo = "";
            this.apellidoMaternoEmpleado = "";
            this.rfcEmpleado = "";
            this.esPersonaPoliticamenteExpuesta = false;
            this.esBeneficiarioPreferente = false;
            this.idBeneficiarioPreferente = "";
            this.numeroMotor = "";
            this.numeroSerie = "";
            this.placas = "";
            this.idCotizacion = 0;
            this.email = "";
            this.confirmaEmail = "";
            this.direccion = new db.Direccion();
            this.telefonoCel = "";
            this.telefonoFijo = "";
            this.tipoMovimiento = "";
            this.noPoliza = "";
            this.noCotizacion = "";
            this.noEndoso = "";
            this.tipoEndoso = "";
            this.noOTra = "";
            this.noNegocio = "";
            this.amis = "";
            this.noAsegurado = "";
            this.noInciso = "";
            this.paquete = "";
            this.moneda = "";
            this.noEmpleado = "";
            this.xmlsAseguradoras = new Dictionary<string, XmlDocument>();
            this.vehiculo = new Vehiculo();
            this.tarjeta = new Tarjeta();
         
            this.empresa = new db.Empresa();
            this.detalleUsuario = new db.DetalleUsuario();
            this.convenio = new db.Convenio();
            this.convenioProducto = new db.ConvenioProductos();
            this.beneficiarioPreferente = "";
            this.parentesco = new db.CatParentesco();
            this.esRenovacion = false;
            this.CotizacionAutoGuardar = new db.CotizacionAuto();
            this.edad = 0;
            this.IdArrendado = "";
            this.idBenefCore=0;
            this.urlReimpresionEncriptada = "";
			this.PersonaMoral = new PersonaMoral();
			this.PersonaMoralRepresentanteLegal = new PersonaMoralRepresentanteLegal();
            this.Contratante = new Contratante();
            this.esPromotor = false;
            this.inciso = "";           
    }


        public bool ConductorHabitual { get => conductorHabitual; set => conductorHabitual = value; }
        public int IdParentesco { get => idParentesco; set => idParentesco = value; }
        public string Aseguradora { get => aseguradora; set => aseguradora = value; }
        public string PrimerNombre { get => primerNombre; set => primerNombre = value; }
        public string SegundoNombre { get => segundoNombre; set => segundoNombre = value; }
        public string ApellidoPaterno { get => apellidoPaterno; set => apellidoPaterno = value; }
        public string ApellidoMaterno { get => apellidoMaterno; set => apellidoMaterno = value; }
        public string PrimerNombreEmpleado { get => primerNombreEmpleado; set => primerNombreEmpleado = value; }
        public string SegundoNombreEmpleado { get => segundoNombreEmpleado; set => segundoNombreEmpleado = value; }
        public string ApellidoPaternoEmpleado { get => apellidoPaternoEmpledo; set => apellidoPaternoEmpledo = value; }
        public string ApellidoMaternoEmpleado { get => apellidoMaternoEmpleado; set => apellidoMaternoEmpleado = value; }
        public string RFCEmpleado { get => rfcEmpleado; set => rfcEmpleado = value; }
        public bool EsPersonaPoliticamenteExpuesta { get => esPersonaPoliticamenteExpuesta; set => esPersonaPoliticamenteExpuesta = value; }
        public bool EsBeneficiarioPreferente { get => esBeneficiarioPreferente; set => esBeneficiarioPreferente = value; }
        public string IdBeneficiarioPreferente { get => idBeneficiarioPreferente; set => idBeneficiarioPreferente = value; }
        public string NumeroMotor { get => numeroMotor; set => numeroMotor = value; }
		public string NumeroEconomico { get; set; }
		public string NumeroSegmento { get; set; }
        public string NumeroEmpleado { get; set; }
        public string NumeroSerie { get => numeroSerie; set => numeroSerie = value; }
        public string Placas { get => placas; set => placas = value; }
        public int IdCotizacion { get => idCotizacion; set => idCotizacion = value; }
        [Required, StringLength(50)]
        public string Email { get => email; set => email = value; }
        [Required, StringLength(50)]
        public string ConfirmaEmail { get => confirmaEmail; set => confirmaEmail = value; }
        public db.Direccion Direccion { get => direccion; set => direccion = value; }
        [Required, StringLength(10, MinimumLength = 10)]
        public string TelefonoCel { get => telefonoCel; set => telefonoCel = value; }
        [Required, StringLength(10, MinimumLength = 10)]
        public string TelefonoFijo { get => telefonoFijo; set => telefonoFijo = value; }
        public string TipoMovimiento { get => tipoMovimiento; set => tipoMovimiento = value; }
        public string NoPoliza { get => noPoliza; set => noPoliza = value; }
        public string NoCotizacion { get => noCotizacion; set => noCotizacion = value; }
        public string NoEndoso { get => noEndoso; set => noEndoso = value; }
        public string TipoEndoso { get => tipoEndoso; set => tipoEndoso = value; }
        public string NoOTra { get => noOTra; set => noOTra = value; }
        public string NoNegocio { get => noNegocio; set => noNegocio = value; }
        public string Amis { get => amis; set => amis = value; }
        public string NoAsegurado { get => noAsegurado; set => noAsegurado = value; }
        public string NoInciso { get => noInciso; set => noInciso = value; }
        public string Paquete { get => paquete; set => paquete = value; }
        public string Moneda { get => moneda; set => moneda = value; }
        public string NoEmpleado { get => noEmpleado; set => noEmpleado = value; }
        public Dictionary<string, XmlDocument> XmlsAseguradoras { get => xmlsAseguradoras; set => xmlsAseguradoras = value; }
        public Vehiculo Vehiculo { get => vehiculo; set => vehiculo = value; }
        public Tarjeta Tarjeta { get => tarjeta; set => tarjeta = value; }
	
		public db.Empresa Empresa { get => empresa; set => empresa = value; }
	
		public db.DetalleUsuario DetalleUsuario { get => detalleUsuario; set => detalleUsuario = value; }
        public db.Convenio Convenio { get => convenio; set => convenio = value; }
        public db.ConvenioProductos ConvenioProducto { get => convenioProducto; set => convenioProducto = value; }
        public string BeneficiarioPreferente { get => beneficiarioPreferente; set => beneficiarioPreferente = value; }
        public db.CatParentesco Parentesco { get => parentesco; set => parentesco = value; }
        public int IdAnio { get => idAnio; set => idAnio = value; }
        public int IdBanco { get => idBanco; set => idBanco = value; }
        public int FormaPago { get => formaPago; set => formaPago = value; }
        public int IdMedioPago { get; set; }
        public db.Poliza Poliza { get => poliza; set => poliza = value; }
        public db.PolizaCasa PolizaCasa { get => polizaCasa; set => polizaCasa = value; }
        public db.PolizaDetalleCasa PolizaCasaDetalle { get => polizaCasaDetalle; set => polizaCasaDetalle = value; }
        public db.CotizacionAuto CotizacionAutoGuardar { get => cotizacionAuto; set => cotizacionAuto = value; }
        public string RutaDescargaPDFsPolizas { get => rutaDescargaPDFsPolizas; set => rutaDescargaPDFsPolizas = value; }
        public string BenefMuerteAccidental { get => benefMuerteAccidental; set => benefMuerteAccidental = value; }
        public bool EsRenovacion { get => esRenovacion; set => esRenovacion = value; }
        public bool EsFlotilla { get => esFlotilla; set => esFlotilla = value; }
        public int IdugarNacimiento { get => idLugarNacimiento; set => idLugarNacimiento = value; }
        public DateTime FechaNacimiento { get => fechaNacimiento; set => fechaNacimiento = value; }
        public int IdNacionalidad { get => idNacionalidad; set => idNacionalidad = value; }
        public VDatosUsuario DatosUsuario { get => datosUsuario; set => datosUsuario = value; }
        public int IdEstado { get => idEstado; set => idEstado = value; }
        public int IdAsentamiento { get => idAsentamiento; set => idAsentamiento = value; }

        public int IdAsentamientoSelected { get; set; }
        public int IdSucursal { get => idSucursal; set => idSucursal = value; }
        public bool AplicaSucursales { get => aplicaSucursales; set => aplicaSucursales = value; }
        public int Edad { get => edad; set => edad = value; }
       
        public  string Arrendado { get => IdArrendado; set => IdArrendado = value; }
        public int? IdBenefCore { get => idBenefCore; set => idBenefCore = value; }
		public string NombreTipoVehiculo { get; set; }
       
		public string SociedadBeFlex { get; set; }
		public string ContratanteBeFlex { get; set; }
		public string LocalidadBeFlex { get; set; }
		public string CaratulaInbursa { get; set; }
		public int IdTipoDeNegocio { get; set; }
        public int IdTipoContratante { get; set; }
        public bool EmisionPersonaMoral { get; set; }
		public PersonaMoral PersonaMoral { get; set; }
		public PersonaMoralRepresentanteLegal PersonaMoralRepresentanteLegal { get; set; }				
        public string UrlReimpresionEncriptada { get => urlReimpresionEncriptada; set => urlReimpresionEncriptada = value; }
        public Contratante Contratante { get; set; }
        public bool EsPromotor { get => esPromotor; set => esPromotor = value; }
        public string Inciso { get => inciso; set=>inciso=value; }		
		public bool CotizacionCero { get; set; }
		public bool RenovacionAutomatica { get; set; } // CAT Renovación automática: transporta la elección del usuario desde la emisión hasta el detalle de póliza.
		public DateTime? FechaDecisionRenovacionAutomaticaUtc { get; set; } // CAT Renovación automática: transporta la fecha UTC que confirma que la decisión fue capturada.
		public bool AplicaNumeroContrato { get; set; }
		public bool AplicaNumeroSegmento { get; set; }
        public bool AplicaNumeroEmpleado { get; set; }
		public bool AplicaSelectAdicional { get; set; }
        public string SelectAdicionalEtiqueta { get; set; }
        public int IdSelectOpcion { get; set; }
        public int IdSelectOpcionAdicional { get; set; }
        public string SelectOpcionConcatenada { get; set; }
		public Cotizacion Cotizacion { get; set; }
		public bool BloqueoNumeroTarjeta { get; set; }
		public string MensajeDatosBancarios { get; set; }
        public bool EmpresaDeloitte { get; set; }
        public bool RequiereFactura { get; set; }
        public bool EsFacturable { get; set; }
        public bool EmisionConDatosBancarios { get; set; }
        public bool ConDatosBancarios { get; set; }
        public int IdRegimenFiscal { get; set; }
        public int IdRegimenCapital { get; set; }
        public int IdUsoCFDI { get; set; }
        public int? IdMSI { get; set; }
        public int IdConvenioMSI { get; set; }
        public bool AplicaMSI { get; set; }
        public bool PermisoSoloRenovacion { get; set; }
        public bool ValidaMembresia {  get; set; }

        public int ZonaCirculacion { get; set; }

        public bool MismosDatosBancariosEnrollment { get; set; }

        public string ObtieneNombres()
		{
            return ($"{this.primerNombre ?? ""} {this.segundoNombre ?? ""}").Trim();
		}

        public PolizaProducto PolizaProducto { get; set; }
        public PolizaProductoDetalle PolizaProductoDetalle { get; set; }

        /// <summary>
        /// DATOS PARA DERIVAR MASCOTAS
        /// </summary>
        /// <returns></returns>
        public string ColorOjo { get; set; }
        public string ColorNariz { get; set; }
        public string Enfermedades {  get; set; }
        public string Chip {  get; set; }
		public string ObtieneNombreCompleto()
        {
            //string conductor = this.ConductorHabitual ?
            //                    string.Concat(
            //                        this.DetalleUsuario.Nombre,
            //                        " ",
            //                        !string.IsNullOrWhiteSpace(this.DetalleUsuario.NombreDos) ?
            //                            string.Concat(" ", this.DetalleUsuario.NombreDos, " ") :
            //                            " ",
            //                            this.DetalleUsuario.ApellidoPaterno,
            //                            " ",
            //                            this.DetalleUsuario.ApellidoMaterno) :
            //                    string.Concat(this.PrimerNombre,
            //                        !string.IsNullOrWhiteSpace(this.SegundoNombre) ?
            //                            string.Concat(" ", this.SegundoNombre, " ") :
            //                            " ",
            //                            this.ApellidoPaterno,
            //                            " ",
            //                            this.ApellidoMaterno);
            //return conductor;
		
				string conductor = string.IsNullOrEmpty(this.PrimerNombre) ?
								string.Concat(
									this.DetalleUsuario.Nombre,
									" ",
									!string.IsNullOrWhiteSpace(this.DetalleUsuario.NombreDos) ?
										string.Concat(" ", this.DetalleUsuario.NombreDos, " ") :
										" ",
										this.DetalleUsuario.ApellidoPaterno,
										" ",
										this.DetalleUsuario.ApellidoMaterno) :
								string.Concat(this.PrimerNombre,
									!string.IsNullOrWhiteSpace(this.SegundoNombre) ?
										string.Concat(" ", this.SegundoNombre, " ") :
										" ",
										this.ApellidoPaterno,
										" ",
										this.ApellidoMaterno);
			return conductor;
		}

    }
}
