﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LocktonModel.db
{
    public class ReportePolizas
    {
        [Key]
        public int Identificador { get; set; }

        public string Gerencia { get; set; }

        public string NumeroPoliza { get; set; }
       //public string TipoVehiculo { get; set; }
        public string TipoSumaAsegurada {  get; set; }
        public DateTime? FechaFactura { get; set; }
        [NotMapped]
        public string FechaFactura1_ { get { return FechaFactura==null ?"": FechaFactura.Value.ToString("dd/MM/yyyy"); } }
        public  decimal? ValorVehiculo { get; set; }
        public string NoFactura { get; set; }
        public string BeneficiarioPreferente { get; set; }
     
      
        
        public string Servicio {  get; set; }
        
        public string Producto { get; set; }
        public string SubProducto { get; set; }
        public string Forma_pago { get; set; }

        public string Medio_pago { get; set; }
        public string Aseguradora { get; set; }

        public string TipoVenta { get; set; }

        public DateTime fecha_inicio { get; set; }
        [NotMapped]
        public string fecha_inicio1_ { get { return fecha_inicio.ToString("dd/MM/yyyy"); } }

        public DateTime fecha_fin { get; set; }
        [NotMapped]
        public string fecha_fin1_ { get { return fecha_fin.ToString("dd/MM/yyyy"); } }
        public DateTime FechaCaptura { get; set; }
        [NotMapped]
        public string FechaCaptura1_ { get { return FechaCaptura.ToString("dd/MM/yyyy"); } }

        public double PrimaNeta { get; set; }
        public double Derechos { get; set; }

        public double IVA { get; set; }
        public double PrimaTotal { get; set; }
        public string ClaveVehicular { get; set; }
        public string Marca { get; set; }

        public string Version { get; set; }

        public string Modelo { get; set; }

        public string Motor { get; set; }

        public string Serie { get; set; }

        public string Placas { get; set; }

        public string NombreEmpleado { get; set; }

        public string Numero_empleado { get; set; }

        public string Correo { get; set; }

        public string Conductor_Habitual { get; set; }

        public string Estatus { get; set; }
        public string Paquete { get; set; }
        public string PaqueteRenombrado { get; set; }
        public string OTCancelacion { get; set; }
        public string UserNameEmite { get; set; }
        public string Referencia1 { get; set; }
        public string Referencia2 { get; set; }
        public string Referencia3 { get; set; }
        public string Referencia4 { get; set; }
        // CAT Renovación automática: expone Sí, No o Sin registro según exista una decisión confiable.
        public string Renovacion_Automatica { get; set; }
        public string Notas { get; set; }
        public string EstatusUsuario { get; set; }
        public string MSI { get; set; }
        public string Estado { get; set; }
        public string Ciudad { get; set; }
        public string CodigoPostalCotizacion { get; set; }
        public string CodigoPostalEmision { get; set; }
        public bool CoberturaAdicional { get;set; }
        public string Tipo { get; set; }

    }
}
