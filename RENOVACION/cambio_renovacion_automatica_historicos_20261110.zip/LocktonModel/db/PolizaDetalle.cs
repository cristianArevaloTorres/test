﻿namespace LocktonModel.db
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("PolizaDetalle")]
    public class PolizaDetalle
    {
        public int Id { get; set; }
        public string XMLSolicitud { get; set; }
        public string XMLRecepcion { get; set; }
        public decimal Derechos { get; set; }
        [StringLength(20)]
        public string Inciso { get; set; }
        public bool RenovacionAutomatica { get; set; }
        public DateTime? FechaDecisionRenovacionAutomaticaUtc { get; set; } // CAT Renovación automática: identifica cuándo se capturó la decisión sin asumirla para pólizas anteriores.
        public decimal Deducible { get; set; }
        public decimal Recargos { get; set; }
        public decimal Impuesto { get; set; }
        public decimal Comision { get; set; }
        public decimal FactorIva { get; set; }
        public bool MigraOPERA { get; set; }
        [StringLength(1000)]
        public string UrlPDFPolizaOPERA { get; set; }
        public int PolizaOPERA { get; set; }
        public int OTOpera { get; set; }
        public int EndosoOPERA { get; set; }
        public string BenefMuerteAccidental { get; set; }
        public int IdPoliza { get; set; }
        public int IdCatRamoVehiculo { get; set; }
        public int IdCotizacionAuto { get; set; }
        public int IdCotizacionDetalle { get; set; }
        [StringLength(100)]
        public string BeneficiarioPreferente { get; set; }
        public int IdCatModalidadFormaPago { get; set; }
        public int IdCatPeriodicidadFormaPago { get; set; }
        public int IdDireccion { get; set; }
        [NotMapped]
        public int IdCatBeneficiarioPreferente { get; set; }

        public bool MigraCORE { get; set; }
        public string IdPolizaCORE { get; set; }

        public int? TicketOpera { get; set; }
        public  int? IdContratante       {get;set;}
        public  bool? MigraBemobile       {get;set;}
        public string MensajeBemobile { get; set; }
        public string RefProg { get; set; }
        public string MensajeOpera { get; set; }
        public string MensajeCore { get; set; }

		public string CorreoEnvio { get; set; }

		public string CorreoMensajeError { get; set; }

		public bool CorreoExitoso { get; set; }

        public string RequestAdicional { get; set; }
        public string ResponseAdicional { get; set; }
		public int? IdMSI { get; set; }
		[ForeignKey("IdPoliza")]
        public virtual Poliza Poliza { get; set; }
        [ForeignKey("IdCatRamoVehiculo")]
        public virtual CatRamoVehiculo CatRamoVehiculo { get; set; }
        [ForeignKey("IdCotizacionAuto")]
        public virtual CotizacionAuto CotizacionAuto { get; set; }
        [ForeignKey("IdCotizacionDetalle")]
        public virtual CotizacionDetalle CotizacionDetalle { get; set; }
        [ForeignKey("IdCatModalidadFormaPago")]
        public virtual CatModalidadFormaPago CatModalidadFormaPago { get; set; }
        [ForeignKey("IdCatPeriodicidadFormaPago")]
        public virtual CatPeriodicidadFormaPago CatPeriodicidadFormaPago { get; set; }
        [ForeignKey("IdDireccion")]
        public virtual Direccion Direccion { get; set; }
    }
}
