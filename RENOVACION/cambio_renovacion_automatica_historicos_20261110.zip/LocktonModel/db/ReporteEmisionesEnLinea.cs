﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocktonModel.db
{
    public class ReporteEmisionesEnLinea
    {
        [Key]
        public int Identificador { get; set; }

        public string Gerencia { get; set; }

        public string NumeroPoliza { get; set; }

        public string Aseguradora { get; set; }

        public DateTime FechaCaptura { get; set; }
        [NotMapped]
        public string FechaCaptura1_ { get { return FechaCaptura.ToString("dd/MM/yyyy"); } }
        public string Correo_Enviado_A { get; set; }
        public string UserNameEmite { get; set; }
        public string Telefono1 { get; set; }
        public string Telefono2 { get; set; }
        public string EmpresaUSR { get; set; }
        public string NombreUSRQueCotizo { get; set; }
        // CAT Renovación automática: agrega al Excel la decisión o identifica que no existe registro confiable.
        public string Renovacion_Automatica { get; set; }

    }
}
