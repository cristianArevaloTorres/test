USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

/*
  CAT 2026-11-10: smoke transaccional de los wrappers que consumen los dos
  motores PlanEspejo. Ejecuta flujo normal, def1, def2 y def3 en vigencia
  actual y multivigencia. Los result sets son los propios de cada wrapper;
  la prueba valida que cada EXEC termine sin error y conserve la transaccion.

  No realiza COMMIT. Cualquier dato generado por los wrappers se revierte.
*/

IF OBJECT_ID('dbo.ff_CBuscaPlanesPerfil_V31Test', 'P') IS NULL
    THROW 51000, 'No existe el wrapper dbo.ff_CBuscaPlanesPerfil_V31Test.', 1;

IF OBJECT_ID('dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3', 'P') IS NULL
    THROW 51000, 'No existe el wrapper dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3.', 1;

IF OBJECT_ID('dbo.ff_CBuscaPlanEspejoTest', 'P') IS NULL
    THROW 51000, 'No existe dbo.ff_CBuscaPlanEspejoTest.', 1;

IF OBJECT_ID('dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3', 'P') IS NULL
    THROW 51000, 'No existe dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Empleado
    WHERE ID = 7314560
      AND EMNumeroEmpleado = 'QADEF3D-186'
      AND EMIdEmpresa = 186
      AND EMIdTitular = 1
      AND EMIdEstatus = 1
)
    THROW 51000, 'No existe el fixture QADEF3D-186.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanesPerfilScript
    WHERE EMIdEmpresa = 186
      AND Activo = 1
)
    THROW 51000, 'La empresa 186 usa el motor V3.2; este smoke ya no ejercitaria los SP en alcance.', 1;

DECLARE
    @ResultadoBloqueo INT,
    @Modo VARCHAR(6),
    @Etiqueta VARCHAR(10),
    @Ejecuciones INT = 0,
    @TmpAntes INT,
    @TmpDespues INT,
    @Mensaje NVARCHAR(2048),
    @JsonActual NVARCHAR(MAX) =
        N'{"costo":null,"idempleado":-1,"nuevo":null,"tcidtarifacosto":-1}',
    @JsonAnterior NVARCHAR(MAX) =
        N'{"costoOld":null,"idempleadoOld":-1,"nuevoOld":null,"tcidtarifacostoOld":-1}';

SELECT @TmpAntes = COUNT(*)
FROM dbo.ff_PlanOpcionSeleccionTmp
WHERE PONumeroEmpleado = 'QADEF3D-186'
  AND POIdEmpresa = 186;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @ResultadoBloqueo = sys.sp_getapplock
        @Resource = N'CAT_DEF3_HISTORICOS_QADEF3D_186',
        @LockMode = 'Exclusive',
        @LockOwner = 'Transaction',
        @LockTimeout = 15000;

    IF @ResultadoBloqueo < 0
        THROW 51000, 'No fue posible obtener el bloqueo exclusivo del smoke.', 1;

    /* Aisla el flujo normal de cualquier staging previo del fixture. */
    DELETE FROM dbo.ff_PlanOpcionSeleccionTmp
    WHERE PONumeroEmpleado = 'QADEF3D-186'
      AND POIdEmpresa = 186;

    DECLARE Modos CURSOR LOCAL FAST_FORWARD FOR
        SELECT Modo
        FROM
        (
            VALUES
                (CAST(NULL AS VARCHAR(6))),
                (CAST('def1' AS VARCHAR(6))),
                (CAST('def2' AS VARCHAR(6))),
                (CAST('def3' AS VARCHAR(6)))
        ) M(Modo);

    OPEN Modos;
    FETCH NEXT FROM Modos INTO @Modo;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Etiqueta = ISNULL(@Modo, 'NORMAL');

        EXEC dbo.ff_CBuscaPlanesPerfil_V31Test
            @idempresa = 186,
            @idempleado = 7314560,
            @tmpplanesseleccionados = @JsonActual,
            @tmpplanesseleccionadosold = @JsonAnterior,
            @transfer = @Modo,
            @idVigenciaDestino = 438;

        IF XACT_STATE() <> 1 OR @@TRANCOUNT <> 1
        BEGIN
            SET @Mensaje = CONCAT(
                'El wrapper de vigencia actual altero la transaccion en modo ',
                @Etiqueta, '.');
            THROW 51001, @Mensaje, 1;
        END;

        SET @Ejecuciones += 1;

        EXEC dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3
            @idempresa = 186,
            @idempleado = 7314560,
            @tmpplanesseleccionados = @JsonActual,
            @tmpplanesseleccionadosold = @JsonAnterior,
            @transfer = @Modo,
            @idVigenciaD = 438,
            @idVigenciaDestino = 481;

        IF XACT_STATE() <> 1 OR @@TRANCOUNT <> 1
        BEGIN
            SET @Mensaje = CONCAT(
                'El wrapper multivigencia altero la transaccion en modo ',
                @Etiqueta, '.');
            THROW 51002, @Mensaje, 1;
        END;

        SET @Ejecuciones += 1;

        SELECT
            'SMOKE_OK' AS resultado,
            @Etiqueta AS modo,
            'VIGENCIA_ACTUAL_Y_MULTIVIGENCIA' AS wrappers;

        FETCH NEXT FROM Modos INTO @Modo;
    END;

    CLOSE Modos;
    DEALLOCATE Modos;

    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF CURSOR_STATUS('local', 'Modos') >= -1
    BEGIN
        IF CURSOR_STATUS('local', 'Modos') > -1 CLOSE Modos;
        DEALLOCATE Modos;
    END;

    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;

IF @@TRANCOUNT <> 0
    THROW 51000, 'El smoke termino con una transaccion abierta.', 1;

SELECT @TmpDespues = COUNT(*)
FROM dbo.ff_PlanOpcionSeleccionTmp
WHERE PONumeroEmpleado = 'QADEF3D-186'
  AND POIdEmpresa = 186;

IF @TmpAntes <> @TmpDespues
    THROW 51000, 'El ROLLBACK no restauro el staging previo del fixture.', 1;

IF @Ejecuciones <> 8
    THROW 51000, 'No se ejecutaron las ocho combinaciones de wrapper y modo.', 1;

SELECT
    'SMOKE_WRAPPERS_OK_SIN_CAMBIOS_PERMANENTES' AS resultado,
    @Ejecuciones AS ejecucionesValidadas,
    @@TRANCOUNT AS transaccionesAbiertas;
GO
