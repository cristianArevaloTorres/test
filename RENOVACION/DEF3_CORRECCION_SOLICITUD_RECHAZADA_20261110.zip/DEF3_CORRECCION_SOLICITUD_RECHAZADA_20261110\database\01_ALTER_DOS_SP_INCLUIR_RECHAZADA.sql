USE [FlexiForbesv2];
GO

/*
  Guarda de version: esta entrega parte de la correccion del 2026-10-30 o de
  una reinstalacion idempotente de la version 2026-11-10. Si el ambiente tiene
  otra definicion, se detiene para evitar sobrescribir cambios no revisados.
*/
IF OBJECT_ID(N'dbo.ff_CBuscaPlanEspejoTest', N'P') IS NULL
   OR OBJECT_ID(N'dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3', N'P') IS NULL
    THROW 51000, 'No existen los dos motores PlanEspejo requeridos.', 1;

IF
(
    OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_CBuscaPlanEspejoTest'))
        NOT LIKE '%CAT 2026-10-30%'
    AND OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_CBuscaPlanEspejoTest'))
        NOT LIKE '%CAT 2026-11-10%'
)
OR
(
    OBJECT_DEFINITION
    (
        OBJECT_ID(N'dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3')
    ) NOT LIKE '%CAT 2026-10-30%'
    AND OBJECT_DEFINITION
    (
        OBJECT_ID(N'dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3')
    ) NOT LIKE '%CAT 2026-11-10%'
)
    THROW 51000, 'Version de motores no reconocida; respaldar y revisar antes de instalar.', 1;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/*
  CAT 2026-11-10: conserva en def3 las elecciones de la solicitud
  inmediatamente anterior, aunque el administrador la haya rechazado para
  poder modificar el grupo familiar. Se reutilizan estados de seleccion
  1 (Activo), 4 (Cancelada por actualizacion), 5 (Rechazada) y 10 (Renovada).
  La regla del 29/10 se mantiene:
  los opcionales individuales pertenecen al mismo integrante, mientras las
  opciones grupales y forzosas se recalculan con la familia vigente.
  No cambia firmas ni requiere Java.
*/

/*
  CAT 2026-10-27: implementa la regla def3 para conservar la ultima solicitud
  de la vigencia destino y recalcularla con la composicion familiar activa.
  El backend compatible con def3 ya existe; el ajuste del 29/10/2026 es solo BD.
*/

/* ALTER dbo.ff_CBuscaPlanEspejoTest */
/*******************************************************************************
********************************************************************************
*  Nombre StoreProcedure: ff_GetParametroValor                                 *
*  DescripciÃ³n: SE MANDA LLAMAR DEL SP dbo.ff_CBuscaRegresaEmpleadoPlanes	   *
*  Autor: PROG BENJAMIN ACOSTA TORRES 										   *
*  Fecha CreaciÃ³n: 11072007 
*  drop procedure dbo.ff_CBuscaPlanEspejo    								   *
*************************CONTROL DE CAMBIOS*************************************
*  Nombre	        Fecha      DescripciÃ³n Cambio                              * 
*                                                                              *
*                                                                              *
********************************************************************************
*******************************************************************************/
ALTER PROCEDURE [dbo].[ff_CBuscaPlanEspejoTest]
(
	@NUMEROEMPLEADO VARCHAR(20),
	@idEmpleado INT,
	@idEmpresa INT,
	@idPerfil INT,
	@GpoTitular INT,
	@NUCLEOFAMILIAR CHAR(1),
	@transfer varchar(6) = null,
	@idVigenciaDestino INT = NULL
)
AS 
DECLARE @TmpSelecciON INT,
	@GRUPOPANT INT,
	@GRUPOP INT,
	@Bandera INT
BEGIN

   

	print '****************'
	print 'idEmpleado'
	print @idEmpleado
	print 'idEmpresa'
	print @idEmpresa
	print 'idPerfil'
	print @idPerfil
	print 'GpoTitular'
	print @GpoTitular
	print 'NUCLEOFAMILIAR'
	print @NUCLEOFAMILIAR
	print 'variable transfer'
	print @transfer

    
    IF (SELECT COUNT(CPIdCondicionPlan) 
		FROM dbo.ff_CondicionPlan  WITH (NOLOCK,READUNCOMMITTED) 
		WHERE CPIdPerfil=@idPerfil 
		AND CPIdTipoCondicion=21 
		AND CPIdEstatus=1) > 0
    BEGIN
		SET @NUCLEOFAMILIAR =1
    END
	
	PRINT @NUCLEOFAMILIAR

    SET @Bandera=0

	/*VALIDAR SI ES PROCESO DE DEFAULTEO SELECCCIONES ANTERIORES*/
	IF (@Transfer = 'def1' or @Transfer = 'def2' or @Transfer = 'def3' )  
	BEGIN  
		print 'se hizo el borrado de los planes seleccionados en tmp para el empleado:'
		print @numeroempleado
		delete ff_planopcionselecciontmp where PONumeroEmpleado = @numeroempleado and POidEmpresa = @idEmpresa
	END
	/*VALIDAR SI ES PROCESO DE DEFAULTEO SELECCCIONES ANTERIORES*/	 

	SELECT @TmpSelecciON=ISNULL(COUNT(POIdPlanOpciONSelecciON),0) 
	FROM dbo.ff_PlanOpciONSelecciONTmp WITH (NOLOCK,READUNCOMMITTED) 
	WHERE	PONumeroEmpleado = @numeroempleado 
		AND POidEmpresa = @idempresa 
		AND poidestatus = 1
	
	SET @TmpSelecciON= ISNULL(@TmpSelecciON,0)




	IF @TmpSelecciON > 0   
	BEGIN
	print 'CARLOS**************HAY SELECCIONES'
		SELECT @Bandera = ISNULL(COUNT(POIdPlanOpciONSelecciON),0) 
		FROM dbo.ff_PlanOpciONSelecciONTmp tmp WITH (NOLOCK,READUNCOMMITTED) 
		WHERE tmp.PONumeroEmpleado = @numeroempleado 
			AND tmp.POidEmpresa = @idempresa 
			AND tmp.POidEstatus = 1  
			AND tmp.poidgrupoparentesco IS NOT NULL 
			AND CAST(tmp.poidplanopciON AS VARCHAR(10))
				+'-'
				+CAST(tmp.poidgrupoparentesco AS VARCHAR(10)) IN   
																(SELECT CAST(TCidPlanOpciON AS NVARCHAR(10))
																	+'-'
																	+CAST(tcidgrupoparentesco AS NVARCHAR(10)) 
																	FROM #tmpPlanesFlexibles) 
		HAVING COUNT(*) = ( SELECT  COUNT(*) 
							FROM dbo.ff_PlanOpciONSelecciONTmp tmp WITH (NOLOCK,READUNCOMMITTED) 
							WHERE	tmp.PONumeroEmpleado = @numeroempleado 
								AND tmp.POidEmpresa = @idempresa 
								AND tmp.poidgrupoparentesco IS NOT NULL 
								AND tmp.POidEstatus = 1 )

		IF @Bandera<=0
		BEGIN  
			print 'BANDERA ES MENOS O IGUAL A 0'
			SELECT DISTINCT  @GRUPOPANT = poidgrupoparentesco 
			FROM dbo.ff_PlanOpciONSelecciONTmp tmp WITH (NOLOCK,READUNCOMMITTED)  
			WHERE	PONumeroEmpleado = @NumeroEmpleado 
				AND POidEmpresa = @idEmpresa 
				AND POidEstatus = 1   	
				AND poidgrupoparentesco IS NOT NULL  
				AND	poidgrupoparentesco NOT IN 
											(SELECT DISTINCT tcidgrupoparentesco 
												FROM #tmpPlanesFlexibles 
												WHERE	tcidtipotarIFa = 2 
												AND TCidPlanOpciON = tmp.poidplanopciON)  
			GROUP BY poidplanopciON, poidgrupoparentesco  
			OPTION (KEEP PLAN)

			--PASO 2  
			--OBTENGO EL PARENTESCO QUE REEMPLAZA  

			SELECT TOP 1 @GRUPOP = tcidgrupoparentesco   
			FROM #tmpPlanesFlexibles tmp  
			WHERE tcidtipotarIFa = 2 
			AND tcidgrupoparentesco NOT IN 
										(SELECT DISTINCT poidgrupoparentesco 
											FROM dbo.ff_PlanOpciONSelecciONTmp WITH (NOLOCK,READUNCOMMITTED) 
											WHERE	TCidPlanOpciON = tmp.poidplanopciON 
											AND pONumeroEmpleado = @NumeroEmpleado 
											AND POidEmpresa = @idEmpresa
											AND poidgrupoparentesco IS NOT NULL 
											AND POidEstatus = 1)    
			GROUP BY tcidplanopciON, tcidgrupoparentesco 
			OPTION (KEEP PLAN)
       
			--PASO 3  
			--ACTUALIZO   

			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true', 
					vISible='true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_PlanOpciONSelecciONTmp POST  WITH (NOLOCK,READUNCOMMITTED) 
					ON PF.POidPlanoPCION = POST.POidPlanOpciON
					AND tcidgrupoparentesco = @GRUPOP
				WHERE	pf.id = POST.poidempleado  
					AND POST.PONumeroEmpleado = @NUMEROEMPLEADO 	
					AND POST.POidEmpresa = @idEmpresa 
					AND POST.POidEstatus = 1  
				OPTION (KEEP PLAN)

			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true', 
					vISible='true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_PlanOpciONSelecciONTmp POST  WITH (NOLOCK,READUNCOMMITTED) 
					ON PF.POidPlanoPCION = POST.POidPlanOpciON
				WHERE	pf.id = POST.poidempleado 
					AND POST.PONumeroEmpleado = @NUMEROEMPLEADO
					AND POST.POidEmpresa = @idEmpresa	 
					AND PF.IDPARENTESCO = POST.POidParentesco   
					AND POST.POidEstatus = 1   
				OPTION (KEEP PLAN)
		END  
		ELSE  
		BEGIN
			print 'BANDERA ES MAYOR A 0'
			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true', 
					vISible = 'true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_PlanOpciONSelecciONTmp POST  WITH (NOLOCK,READUNCOMMITTED) 
					ON PF.POidPlanoPCION = POST.POidPlanOpciON  
				WHERE	pf.id = POST.poidempleado  
					AND PF.IDPARENTESCO = ISNULL(POST.POidGrupoParentesco,POST.POidParentesco) 	
					AND POST.POidEmpresa = @idEmpresa 
					AND POST.PONumeroEmpleado = @NUMEROEMPLEADO 
					AND POST.POidEstatus = 1  	 	
				OPTION (KEEP PLAN)
		END  
	END   
	ELSE  
	BEGIN
			/*****************************obtener una vigencia anterior de una empresa***************************/
					DECLARE @idVigenciaAnterior INT
					DECLARE @idSolicitudAnterior INT
					DECLARE @haySeleccionesAnteriores INT

										select @idVigenciaAnterior = V.VIidVigencia from ff_Empresa E
					inner join ff_Configuracion C ON E.EMidConfiguracion = C.COidConfiguracion
					inner join ff_Vigencia V ON V.VIidConfiguracion = C.COidConfiguracion
					where E.EMidEmpresa = @idEmpresa and V.VIidEstatus <> 6
					--398065
					--501651 solicitud
					print 'defaulteo vigencia anterior'
					print @idVigenciaAnterior

					-- CAT: def3 toma la ultima solicitud de la vigencia destino aunque
					-- la actualizacion familiar ya la haya cancelado. Si aun no existe,
					-- conserva como respaldo la autorizada de la vigencia anterior.
					IF @Transfer = 'def3'
					BEGIN
						SELECT TOP (1) @idSolicitudAnterior = S.SOIdSolicitud
						FROM dbo.ff_Solicitud S WITH (NOLOCK, READUNCOMMITTED)
						WHERE S.SOIdEmpleado = @idEmpleado
						  AND S.SOIdEmpresa = @idEmpresa
						  AND S.SOIdVigencia = @idVigenciaDestino
						  AND S.SOEstatusSolicitud IN (1, 3, 4, 5)
						  AND EXISTS
						      (SELECT 1 FROM dbo.ff_PlanOpcionSeleccion PS WITH (NOLOCK, READUNCOMMITTED)
						       WHERE PS.POIdSolicitud = S.SOIdSolicitud
						         AND PS.POIdEstatus IN (1, 4, 5, 10))
						ORDER BY S.SOIdSolicitud DESC;

						IF ISNULL(@idSolicitudAnterior, 0) = 0
						BEGIN
							SELECT TOP (1) @idSolicitudAnterior = S.SOIdSolicitud
							FROM dbo.ff_Solicitud S WITH (NOLOCK, READUNCOMMITTED)
							WHERE S.SOIdEmpleado = @idEmpleado
							  AND S.SOIdEmpresa = @idEmpresa
							  AND S.SOIdVigencia = @idVigenciaAnterior
							  AND S.SOEstatusSolicitud IN (1, 3, 4, 5)
							  AND EXISTS
							      (SELECT 1 FROM dbo.ff_PlanOpcionSeleccion PS WITH (NOLOCK, READUNCOMMITTED)
							       WHERE PS.POIdSolicitud = S.SOIdSolicitud
							         AND PS.POIdEstatus IN (1, 4, 5, 10))
							ORDER BY S.SOIdSolicitud DESC;
						END
					END
					ELSE
					BEGIN
						select @idSolicitudAnterior=SOIdSolicitud from ff_solicitud where
						SOIdEmpleado = @idEmpleado
						and
						SOIdVigencia = @idVigenciaAnterior
						and
						SOEstatusSolicitud = 1
					END

					print 'defaulteo id solicitud origen'
					print @idSolicitudAnterior
					SET @haySeleccionesAnteriores = ISNULL(@idSolicitudAnterior, 0)

					DECLARE @haySeleccionesAplicables INT = 0
					IF @Transfer = 'def3' AND @haySeleccionesAnteriores <> 0
					BEGIN
						-- CAT 2026-10-29: una opcion anterior solo es aplicable al familiar
						-- que la contrato. Se extiende a la familia actual unicamente cuando
						-- la tarifa es grupal o la opcion esta configurada como forzosa.
						SELECT @haySeleccionesAplicables = COUNT(*)
						FROM #tmpPlanesFlexibles PF
						INNER JOIN dbo.ff_PlanOpcionSeleccion PO WITH (NOLOCK, READUNCOMMITTED)
							ON PF.POidPlanoPCION = PO.POidPlanOpcion
						WHERE PO.POidSolicitud = @idSolicitudAnterior
						  AND PO.POIdEstatus IN (1, 4, 5, 10)
						  AND
						  (
							PF.TCidTipoTarifa = 2
							OR
							PF.Id = PO.POIdEmpleado
							OR EXISTS
							(
								SELECT 1
								FROM dbo.ff_PlanOpcion POO WITH (NOLOCK, READUNCOMMITTED)
								WHERE POO.POIdPlanOpcion = PF.POidPlanoPCION
								  AND POO.POOpcionForzosa = '1'
							)
						  );
					END

					

					/*****************************obtener una vigencia anterior de una empresa***************************/


	IF ((@Transfer = 'def1' AND @haySeleccionesAnteriores <> 0)
	OR (@Transfer = 'def3' AND @haySeleccionesAplicables > 0))  
		BEGIN  
		print 'se metio en planes selecciones anteriores'
		
			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true'  
				FROM #tmpPlanesFlexibles PF  
				
				INNER JOIN dbo.ff_PlanOpcionSeleccion PO  WITH (NOLOCK,READUNCOMMITTED) 
	
				ON PF.POidPlanoPCION = PO.POidPlanOpcion

				where  PO.POidSolicitud = @idSolicitudAnterior
				  AND
				  (
					@Transfer = 'def1'
					OR
					(
						@Transfer = 'def3'
						AND PO.POIdEstatus IN (1, 4, 5, 10)
						AND
						(
							PF.TCidTipoTarifa = 2
							OR
							PF.Id = PO.POIdEmpleado
							OR EXISTS
							(
								SELECT 1
								FROM dbo.ff_PlanOpcion POO WITH (NOLOCK, READUNCOMMITTED)
								WHERE POO.POIdPlanOpcion = PF.POidPlanoPCION
								  AND POO.POOpcionForzosa = '1'
							)
						)
					)
				  )
				/*
				--prueba 
				print 'prueba'
				
					 select DISTINCT  PF.POidPlanOpcion,PO2.PODescripcion
				FROM #tmpPlanesFlexibles PF  
				
				INNER JOIN dbo.ff_PlanOpcionSeleccion PO  WITH (NOLOCK,READUNCOMMITTED)
				
				INNER JOIN ff_planopcion PO2 ON  PO.POidplanopcion = PO2.poidplanopcion 
	
				ON PF.POidPlanoPCION = PO.POidPlanOpcion

				where  PO.POidSolicitud = @idSolicitudAnterior
				
			

				print 'prueba'
				--prueba
				*/

			-- CAT 2026-10-29: si el integrante no existia en la solicitud
			-- anterior, asigna sus planes basicos individuales. Solo toma una
			-- opcion por plan y no reemplaza una opcion ya seleccionada/forzosa.
			IF @Transfer = 'def3'
			BEGIN
				;WITH BasicosIndividualesCandidatos AS
				(
					SELECT DISTINCT
						PF.Id,
						PF.POIdPlan,
						PF.POIdPlanOpcion,
						PB.PBIdPlanBasico,
						PB.PBFlexible
					FROM #tmpPlanesFlexibles PF
					INNER JOIN dbo.ff_PlanBasico PB WITH (NOLOCK, READUNCOMMITTED)
						ON PB.PBIdPlanOpcion = PF.POIdPlanOpcion
					INNER JOIN dbo.ff_PlanBasicoDetalle PBD WITH (NOLOCK, READUNCOMMITTED)
						ON PBD.PBIdPlanBasico = PB.PBIdPlanBasico
					   AND PBD.PBIdParentesco = PF.IDPARENTESCO
					WHERE PF.TCIdTipoTarifa = 1
					  AND PB.PBIdPerfil = @idPerfil
					  AND PB.PBFormaCredito NOT IN ('4', '8')
					  AND PB.PBIdEstatus = 1
					  AND PBD.PBIdEstatus = 1
					  AND NOT (PB.PBParentescoDefaulteo = 2 AND PF.IDPARENTESCO <> 1)
					  AND NOT EXISTS
					  (
						SELECT 1
						FROM dbo.ff_PlanOpcionSeleccion Anterior WITH (NOLOCK, READUNCOMMITTED)
						WHERE Anterior.POIdSolicitud = @idSolicitudAnterior
						  AND Anterior.POIdEmpleado = PF.Id
						  AND Anterior.POIdEstatus IN (1, 4, 5, 10)
					  )
					  AND NOT EXISTS
					  (
						SELECT 1
						FROM #tmpPlanesFlexibles Seleccionado
						WHERE Seleccionado.Id = PF.Id
						  AND Seleccionado.POIdPlan = PF.POIdPlan
						  AND Seleccionado.Checked = 'true'
					  )
				),
				BasicosIndividualesElegidos AS
				(
					SELECT *,
						ROW_NUMBER() OVER
						(
							PARTITION BY Id, POIdPlan
							ORDER BY PBIdPlanBasico, POIdPlanOpcion
						) AS orden
					FROM BasicosIndividualesCandidatos
				)
				UPDATE PF
				SET PF.Checked = 'true',
					PF.Enabled = CASE Elegido.PBFlexible WHEN '0' THEN 'false' ELSE 'true' END
				FROM #tmpPlanesFlexibles PF
				INNER JOIN BasicosIndividualesElegidos Elegido
					ON Elegido.Id = PF.Id
				   AND Elegido.POIdPlan = PF.POIdPlan
				   AND Elegido.POIdPlanOpcion = PF.POIdPlanOpcion
				   AND Elegido.orden = 1
				WHERE PF.TCIdTipoTarifa = 1;

				-- Si la composicion familiar genero una tarifa grupal nueva y el
				-- plan aun no tiene seleccion, aplica un solo basico para ese plan.
				;WITH BasicosGrupalesBase AS
				(
					SELECT
						PF.POIdPlan,
						PF.POIdPlanOpcion,
						PF.IDPARENTESCO,
						PB.PBIdPlanBasico,
						PB.PBParentescoDefaulteo,
						COUNT(*) OVER
						(
							PARTITION BY PF.POIdPlanOpcion, PF.IDPARENTESCO
						) AS integrantes
					FROM #tmpPlanesFlexibles PF
					INNER JOIN dbo.ff_PlanBasico PB WITH (NOLOCK, READUNCOMMITTED)
						ON PB.PBIdPlanOpcion = PF.POIdPlanOpcion
					WHERE PF.TCIdTipoTarifa = 2
					  AND PB.PBIdPerfil = @idPerfil
					  AND PB.PBFormaCredito NOT IN ('4', '8')
					  AND PB.PBIdEstatus = 1
					  AND NOT EXISTS
					  (
						SELECT 1
						FROM #tmpPlanesFlexibles Seleccionado
						WHERE Seleccionado.POIdPlan = PF.POIdPlan
						  AND Seleccionado.Checked = 'true'
					  )
				),
				BasicosGrupalesDistintos AS
				(
					SELECT DISTINCT
						POIdPlan, POIdPlanOpcion, IDPARENTESCO,
						PBIdPlanBasico, PBParentescoDefaulteo, integrantes
					FROM BasicosGrupalesBase
				),
				BasicosGrupalesElegidos AS
				(
					SELECT *,
						ROW_NUMBER() OVER
						(
							PARTITION BY POIdPlan
							ORDER BY
								CASE WHEN PBParentescoDefaulteo = 1 THEN integrantes END DESC,
								CASE WHEN PBParentescoDefaulteo = 2 THEN integrantes END ASC,
								PBIdPlanBasico, POIdPlanOpcion, IDPARENTESCO
						) AS orden
					FROM BasicosGrupalesDistintos
				)
				UPDATE PF
				SET PF.Checked = 'true'
				FROM #tmpPlanesFlexibles PF
				INNER JOIN BasicosGrupalesElegidos Elegido
					ON Elegido.POIdPlan = PF.POIdPlan
				   AND Elegido.POIdPlanOpcion = PF.POIdPlanOpcion
				   AND Elegido.IDPARENTESCO = PF.IDPARENTESCO
				   AND Elegido.orden = 1
				WHERE PF.TCIdTipoTarifa = 2;
			END
		END
	ELSE
		BEGIN  
			/***************************pruba**********************************/

			print 'se metio en planes basicos defaulteo'
					UPDATE #tmpPlanesFlexibles  
				SET checked = 'true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_planbASico PB  WITH (NOLOCK,READUNCOMMITTED) ON POidPlanoPCION = PBidPlanOpciON
				WHERE PF.IDPARENTESCO IN(CASE PBParentescoDefaulteo   
									WHEN 1 THEN (SELECT IDPARENTESCO  
													FROM dbo.#tmpPlanesFlexibles  
													WHERE POidPlanoPCION = PBidPlanOpciON  
													GROUP BY POidPlanoPCION, IDPARENTESCO  
													HAVING COUNT(*) = (SELECT TOP 1 COUNT(*) 
																	FROM #tmpPlanesFlexibles 
																	WHERE POidPlanoPCION = PBidPlanOpciON 
																	GROUP BY POidPlanoPCION, IDPARENTESCO 
																	ORDER BY 1 DESC))   
									WHEN 2 THEN (SELECT IDPARENTESCO  
													FROM #tmpPlanesFlexibles   
													WHERE POidPlanoPCION = PBidPlanOpciON  
													GROUP BY POidPlanoPCION, IDPARENTESCO  
													HAVING COUNT(POidPlanoPCION) = (SELECT TOP 1 COUNT(*) 
																					FROM #tmpPlanesFlexibles 
																					WHERE POidPlanoPCION = PBidPlanOpciON 
																					GROUP BY POidPlanoPCION, IDPARENTESCO 
																					ORDER BY 1 ASC))   
									END)  
				AND PBidPerfil = @idPerfil  
				AND PBFormaCredito <> 4 
				AND PBFormaCredito <> 8
				AND TCidTipoTarIFa = 2  
				AND PBidEstatus = 1
     
		UPDATE #tmpPlanesFlexibles  
			SET checked = CASE 
							WHEN PBParentescoDefaulteo=2 AND PF.IDPARENTESCO<>1 THEN 'false' 
							ELSE 'true' 
							END,
				ENABLED = CASE PB.PBFLEXIBLE 
							WHEN 0 THEN 'false' 
							ELSE 'true' 
							END 
			FROM #tmpPlanesFlexibles PF  
			INNER JOIN dbo.ff_planbASico PB WITH (NOLOCK,READUNCOMMITTED) 
				ON POidPlanoPCION = PBidPlanOpciON
			INNER JOIN dbo.ff_PlanBASicoDetalle PBD WITH (NOLOCK,READUNCOMMITTED) 
				ON PB.PBidPlanBASico = PBD.PBidPlanBASico   
			WHERE	PBidPerfil = @idPerfil 
				AND PBD.PBidParentesco = PF.IDPARENTESCO  
				AND TCidTipoTarIFa = 1  
				AND PBFormaCredito NOT IN (4,8)
				AND Pb.PBidEstatus = 1 
				AND Pbd.PBidEstatus = 1
	END  

			/***************************pruba**********************************/
		END

	
	
		--planes Basicos

		/*antes*******************************************/
		/*
			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_planbASico PB  WITH (NOLOCK,READUNCOMMITTED) ON POidPlanoPCION = PBidPlanOpciON
				WHERE PF.IDPARENTESCO IN(CASE PBParentescoDefaulteo   
									WHEN 1 THEN (SELECT IDPARENTESCO  
													FROM dbo.#tmpPlanesFlexibles  
													WHERE POidPlanoPCION = PBidPlanOpciON  
													GROUP BY POidPlanoPCION, IDPARENTESCO  
													HAVING COUNT(*) = (SELECT TOP 1 COUNT(*) 
																	FROM #tmpPlanesFlexibles 
																	WHERE POidPlanoPCION = PBidPlanOpciON 
																	GROUP BY POidPlanoPCION, IDPARENTESCO 
																	ORDER BY 1 DESC))   
									WHEN 2 THEN (SELECT IDPARENTESCO  
													FROM #tmpPlanesFlexibles   
													WHERE POidPlanoPCION = PBidPlanOpciON  
													GROUP BY POidPlanoPCION, IDPARENTESCO  
													HAVING COUNT(POidPlanoPCION) = (SELECT TOP 1 COUNT(*) 
																					FROM #tmpPlanesFlexibles 
																					WHERE POidPlanoPCION = PBidPlanOpciON 
																					GROUP BY POidPlanoPCION, IDPARENTESCO 
																					ORDER BY 1 ASC))   
									END)  
				AND PBidPerfil = @idPerfil  
				AND PBFormaCredito <> 4 
				AND PBFormaCredito <> 8
				AND TCidTipoTarIFa = 2  
				AND PBidEstatus = 1
     
		UPDATE #tmpPlanesFlexibles  
			SET checked = CASE 
							WHEN PBParentescoDefaulteo=2 AND PF.IDPARENTESCO<>1 THEN 'false' 
							ELSE 'true' 
							END,
				ENABLED = CASE PB.PBFLEXIBLE 
							WHEN 0 THEN 'false' 
							ELSE 'true' 
							END 
			FROM #tmpPlanesFlexibles PF  
			INNER JOIN dbo.ff_planbASico PB WITH (NOLOCK,READUNCOMMITTED) 
				ON POidPlanoPCION = PBidPlanOpciON
			INNER JOIN dbo.ff_PlanBASicoDetalle PBD WITH (NOLOCK,READUNCOMMITTED) 
				ON PB.PBidPlanBASico = PBD.PBidPlanBASico   
			WHERE	PBidPerfil = @idPerfil 
				AND PBD.PBidParentesco = PF.IDPARENTESCO  
				AND TCidTipoTarIFa = 1  
				AND PBFormaCredito NOT IN (4,8)
				AND Pb.PBidEstatus = 1 
				AND Pbd.PBidEstatus = 1
	END  

	*/
	/*antes fin***********************************************************/
	PRINT 'EVALUA SI LOS PLANES REQUIEREN DE LA SELECCION DEL TITULAR  '
 
 
	UPDATE #tmpPlanesFlexibles  
		 SET VISIBLE = 'FALSE', 
			 ENABLED = 'FALSE', 
			 CHECKED = 'FALSE'  
		 WHERE   IDPARENTESCO = 1 
			 AND POIDPLANOPCION IN
								(SELECT POIDPLANOPCION  
								 FROM #tmpPlanesFlexibles  
								 WHERE	PLCoberturaForzosaTitular = '1' 
									AND EMIDPARENTESCO = 1  
								 GROUP BY POIDPLANOPCION  
								 HAVING COUNT(*) > 1)
		AND tcidgrupoparentesco = @GpoTitular
		AND @NUCLEOFAMILIAR = '1' 
 

--	select count(*) from #tmpPlanesFlexibles where checked = 'true'  


	UPDATE #tmpPlanesFlexibles  
		SET checked = 'true', 
			vISible = 'true', 
			enabled = 'false'   
		FROM	#tmpPlanesFlexibles  
		WHERE	idparentesco = 1 
			AND checked='false' 
			AND plcoberturaforzosatitular = '1' 
			AND poidplanopciON IN 
								(SELECT poidplanopciON  
								 FROM	#tmpPlanesFlexibles tmp  
								 WHERE	plcoberturaforzosatitular = '1' 
									AND checked = 'true'  
								 GROUP BY poidplanopciON  
								 HAVING COUNT(*)=(SELECT COUNT(*) 
												  FROM	#tmpPlanesFlexibles  
												  WHERE	plcoberturaforzosatitular = '1' 
													AND checked = 'true' 
													AND emidparentesco NOT IN (1) 
													AND tmp.poidplanopciON = poidplanopciON))


--		select count(*) from #tmpPlanesFlexibles where checked = 'true' 


	 /************************************************************************************/  
	 /************ ACTUALIZA A NO VISIBLES LOS PLANES QUE REQUIEREN DEL TITULAR Y ESTE NO 
	 SE ENCUENTRA EN EL PLAN, APOYANDOSE EN LA TABLA FF_PLANRELACION *********************/  
	 /************************************************************************************/  
 
	UPDATE #tmpPlanesFlexibles   
		SET vISible = 'false', 
			checked = 'false', 
			enabled = 'false'  
		WHERE poidplan IN
				(SELECT DISTINCT pridplan  
				FROM dbo.ff_planrelaciON WITH (NOLOCK,READUNCOMMITTED) 
				WHERE pridplanrelaciON NOT IN (
									SELECT  pridplanrelaciON  
									FROM #tmpPlanesFlexibles  
									INNER JOIN dbo.ff_planrelaciON pr WITH (NOLOCK,READUNCOMMITTED) 
										ON poidplan = pr.pridplan
									WHERE pridplanrelaciON IN (
										SELECT pridplanrelaciON  
										FROM dbo.ff_planrelaciON  WITH (NOLOCK,READUNCOMMITTED)  
										INNER JOIN dbo.ff_plan WITH (NOLOCK,READUNCOMMITTED)  ON pridplan = plidplan  
										WHERE	plcoberturaforzosatitular = '1') 
									AND emidparentesco = 1))
									AND plcoberturaforzosatitular = '1'

	/******************************************************************************************/  
	/***************************************  EVALUA LOS CANDADOS  ****************************/  
	-- PRINT 'entran cANDados1'  
	-- EXECUTE dbo.ff_CevaluacANDados @idEmpleado, @idEmpresa, @NumeroEmpleado  
	/************************************ NEW*********************************/  

 END
GO

/* ALTER dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3 */
/*
  CAT 2026-11-10: el motor multivigencia reutiliza en def3 las elecciones de
  la solicitud inmediatamente anterior, incluidos los estados rechazados por
  la actualizacion familiar. La asignacion de basicos permanece limitada al
  integrante realmente nuevo.
*/
/*******************************************************************************
********************************************************************************
*  Nombre StoreProcedure: ff_GetParametroValor                                 *
*  DescripciÃ³n: SE MANDA LLAMAR DEL SP dbo.ff_CBuscaRegresaEmpleadoPlanes	   *
*  Autor: PROG BENJAMIN ACOSTA TORRES 										   *
*  Fecha CreaciÃ³n: 11072007 
*  drop procedure dbo.ff_CBuscaPlanEspejo    								   *
*************************CONTROL DE CAMBIOS*************************************
*  Nombre	        Fecha      DescripciÃ³n Cambio                              * 
*                                                                              *
*                                                                              *
********************************************************************************
*******************************************************************************/
ALTER PROCEDURE [dbo].[ff_CBuscaPlanEspejoTestMultivigenciaBF3]
(
	@NUMEROEMPLEADO VARCHAR(20),
	@idEmpleado INT,
	@idEmpresa INT,
	@idPerfil INT,
	@GpoTitular INT,
	@NUCLEOFAMILIAR CHAR(1),
	@transfer varchar(6) = null,
	@idVigencia INT,
	@idVigenciaDestino INT = NULL
)
AS 
DECLARE @TmpSelecciON INT,
	@GRUPOPANT INT,
	@GRUPOP INT,
	@Bandera INT
BEGIN

   

	print '****************'
	print 'idEmpleado'
	print @idEmpleado
	print 'idEmpresa'
	print @idEmpresa
	print 'idPerfil'
	print @idPerfil
	print 'GpoTitular'
	print @GpoTitular
	print 'NUCLEOFAMILIAR'
	print @NUCLEOFAMILIAR
	print 'variable transfer'
	print @transfer
	print 'vigencia'
	print @idVigencia

    
    IF (SELECT COUNT(CPIdCondicionPlan) 
		FROM dbo.ff_CondicionPlan  WITH (NOLOCK,READUNCOMMITTED) 
		WHERE CPIdPerfil=@idPerfil 
		AND CPIdTipoCondicion=21 
		AND CPIdEstatus=1) > 0
    BEGIN
		SET @NUCLEOFAMILIAR =1
    END
	
	PRINT @NUCLEOFAMILIAR

    SET @Bandera=0

	/*VALIDAR SI ES PROCESO DE DEFAULTEO SELECCCIONES ANTERIORES*/
	IF (@Transfer = 'def1' or @Transfer = 'def2' or @Transfer = 'def3' )  
	BEGIN  
		print 'se hizo el borrado de los planes seleccionados en tmp para el empleado:'
		print @numeroempleado
		delete ff_planopcionselecciontmp where PONumeroEmpleado = @numeroempleado and POidEmpresa = @idEmpresa
	END
	/*VALIDAR SI ES PROCESO DE DEFAULTEO SELECCCIONES ANTERIORES*/	 

	SELECT @TmpSelecciON=ISNULL(COUNT(POIdPlanOpciONSelecciON),0) 
	FROM dbo.ff_PlanOpciONSelecciONTmp WITH (NOLOCK,READUNCOMMITTED) 
	WHERE	PONumeroEmpleado = @numeroempleado 
		AND POidEmpresa = @idempresa 
		AND poidestatus = 1
	
	SET @TmpSelecciON= ISNULL(@TmpSelecciON,0)




	IF @TmpSelecciON > 0   
	BEGIN
	
		SELECT @Bandera = ISNULL(COUNT(POIdPlanOpciONSelecciON),0) 
		FROM dbo.ff_PlanOpciONSelecciONTmp tmp WITH (NOLOCK,READUNCOMMITTED) 
		WHERE tmp.PONumeroEmpleado = @numeroempleado 
			AND tmp.POidEmpresa = @idempresa 
			AND tmp.POidEstatus = 1  
			AND tmp.poidgrupoparentesco IS NOT NULL 
			AND CAST(tmp.poidplanopciON AS VARCHAR(10))
				+'-'
				+CAST(tmp.poidgrupoparentesco AS VARCHAR(10)) IN   
																(SELECT CAST(TCidPlanOpciON AS NVARCHAR(10))
																	+'-'
																	+CAST(tcidgrupoparentesco AS NVARCHAR(10)) 
																	FROM #tmpPlanesFlexibles) 
		HAVING COUNT(*) = ( SELECT  COUNT(*) 
							FROM dbo.ff_PlanOpciONSelecciONTmp tmp WITH (NOLOCK,READUNCOMMITTED) 
							WHERE	tmp.PONumeroEmpleado = @numeroempleado 
								AND tmp.POidEmpresa = @idempresa 
								AND tmp.poidgrupoparentesco IS NOT NULL 
								AND tmp.POidEstatus = 1 )

		IF @Bandera<=0
		BEGIN  
			print 'BANDERA ES MENOS O IGUAL A 0'
			SELECT DISTINCT  @GRUPOPANT = poidgrupoparentesco 
			FROM dbo.ff_PlanOpciONSelecciONTmp tmp WITH (NOLOCK,READUNCOMMITTED)  
			WHERE	PONumeroEmpleado = @NumeroEmpleado 
				AND POidEmpresa = @idEmpresa 
				AND POidEstatus = 1   	
				AND poidgrupoparentesco IS NOT NULL  
				AND	poidgrupoparentesco NOT IN 
											(SELECT DISTINCT tcidgrupoparentesco 
												FROM #tmpPlanesFlexibles 
												WHERE	tcidtipotarIFa = 2 
												AND TCidPlanOpciON = tmp.poidplanopciON)  
			GROUP BY poidplanopciON, poidgrupoparentesco  
			OPTION (KEEP PLAN)

			--PASO 2  
			--OBTENGO EL PARENTESCO QUE REEMPLAZA  

			SELECT TOP 1 @GRUPOP = tcidgrupoparentesco   
			FROM #tmpPlanesFlexibles tmp  
			WHERE tcidtipotarIFa = 2 
			AND tcidgrupoparentesco NOT IN 
										(SELECT DISTINCT poidgrupoparentesco 
											FROM dbo.ff_PlanOpciONSelecciONTmp WITH (NOLOCK,READUNCOMMITTED) 
											WHERE	TCidPlanOpciON = tmp.poidplanopciON 
											AND pONumeroEmpleado = @NumeroEmpleado 
											AND POidEmpresa = @idEmpresa
											AND poidgrupoparentesco IS NOT NULL 
											AND POidEstatus = 1)    
			GROUP BY tcidplanopciON, tcidgrupoparentesco 
			OPTION (KEEP PLAN)
       
			--PASO 3  
			--ACTUALIZO   

			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true', 
					vISible='true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_PlanOpciONSelecciONTmp POST  WITH (NOLOCK,READUNCOMMITTED) 
					ON PF.POidPlanoPCION = POST.POidPlanOpciON
					AND tcidgrupoparentesco = @GRUPOP
				WHERE	pf.id = POST.poidempleado  
					AND POST.PONumeroEmpleado = @NUMEROEMPLEADO 	
					AND POST.POidEmpresa = @idEmpresa 
					AND POST.POidEstatus = 1  
				OPTION (KEEP PLAN)

			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true', 
					vISible='true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_PlanOpciONSelecciONTmp POST  WITH (NOLOCK,READUNCOMMITTED) 
					ON PF.POidPlanoPCION = POST.POidPlanOpciON
				WHERE	pf.id = POST.poidempleado 
					AND POST.PONumeroEmpleado = @NUMEROEMPLEADO
					AND POST.POidEmpresa = @idEmpresa	 
					AND PF.IDPARENTESCO = POST.POidParentesco   
					AND POST.POidEstatus = 1   
				OPTION (KEEP PLAN)
		END  
		ELSE  
		BEGIN
			print 'BANDERA ES MAYOR A 0'
			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true', 
					vISible = 'true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_PlanOpciONSelecciONTmp POST  WITH (NOLOCK,READUNCOMMITTED) 
					ON PF.POidPlanoPCION = POST.POidPlanOpciON  
				WHERE	pf.id = POST.poidempleado  
					AND PF.IDPARENTESCO = ISNULL(POST.POidGrupoParentesco,POST.POidParentesco) 	
					AND POST.POidEmpresa = @idEmpresa 
					AND POST.PONumeroEmpleado = @NUMEROEMPLEADO 
					AND POST.POidEstatus = 1  	 	
				OPTION (KEEP PLAN)
		END  
	END   
	ELSE  
	BEGIN
			/*****************************obtener una vigencia anterior de una empresa***************************/
					DECLARE @idSolicitudAnterior INT
					DECLARE @haySeleccionesAnteriores INT
										DECLARE @haySeleccionesAplicables INT = 0

					-- CAT: def3 usa la solicitud inmediatamente anterior de la vigencia
					-- destino, sin exigir que siga autorizada despues del cambio familiar.
					IF @Transfer = 'def3'
					BEGIN
						SELECT TOP (1) @idSolicitudAnterior = S.SOIdSolicitud
						FROM dbo.ff_Solicitud S WITH (NOLOCK, READUNCOMMITTED)
						WHERE S.SOIdEmpleado = @idEmpleado
						  AND S.SOIdEmpresa = @idEmpresa
						  AND S.SOIdVigencia = @idVigenciaDestino
						  AND S.SOEstatusSolicitud IN (1, 3, 4, 5)
						  AND EXISTS
						      (SELECT 1 FROM dbo.ff_PlanOpcionSeleccion PS WITH (NOLOCK, READUNCOMMITTED)
						       WHERE PS.POIdSolicitud = S.SOIdSolicitud
						         AND PS.POIdEstatus IN (1, 4, 5, 10))
						ORDER BY S.SOIdSolicitud DESC;

						IF ISNULL(@idSolicitudAnterior, 0) = 0
						BEGIN
							SELECT TOP (1) @idSolicitudAnterior = S.SOIdSolicitud
							FROM dbo.ff_Solicitud S WITH (NOLOCK, READUNCOMMITTED)
							WHERE S.SOIdEmpleado = @idEmpleado
							  AND S.SOIdEmpresa = @idEmpresa
							  AND S.SOIdVigencia = @idVigencia
							  AND S.SOEstatusSolicitud IN (1, 3, 4, 5)
							  AND EXISTS
							      (SELECT 1 FROM dbo.ff_PlanOpcionSeleccion PS WITH (NOLOCK, READUNCOMMITTED)
							       WHERE PS.POIdSolicitud = S.SOIdSolicitud
							         AND PS.POIdEstatus IN (1, 4, 5, 10))
							ORDER BY S.SOIdSolicitud DESC;
						END
					END
					ELSE
					BEGIN
						select @idSolicitudAnterior=SOIdSolicitud from ff_solicitud where
						SOIdEmpleado = @idEmpleado
						and
						SOIdVigencia = @idVigencia
						and
						SOEstatusSolicitud = 1
					END

					print 'defaulteo id solicitud origen'
					print @idSolicitudAnterior
					SET @haySeleccionesAnteriores = ISNULL(@idSolicitudAnterior, 0)

					IF @Transfer = 'def3' AND @haySeleccionesAnteriores <> 0
					BEGIN
						-- CAT 2026-10-29: misma regla del flujo de vigencia actual.
						-- Los servicios individuales opcionales no se heredan; los planes
						-- grupales y las opciones forzosas se recalculan con la familia actual.
						SELECT @haySeleccionesAplicables = COUNT(*)
						FROM #tmpPlanesFlexibles PF
						INNER JOIN dbo.ff_PlanOpcionSeleccion PO WITH (NOLOCK, READUNCOMMITTED)
							ON PF.POidPlanoPCION = PO.POidPlanOpcion
						WHERE PO.POidSolicitud = @idSolicitudAnterior
						  AND PO.POIdEstatus IN (1, 4, 5, 10)
						  AND
						  (
							PF.TCidTipoTarifa = 2
							OR
							PF.Id = PO.POIdEmpleado
							OR EXISTS
							(
								SELECT 1
								FROM dbo.ff_PlanOpcion POO WITH (NOLOCK, READUNCOMMITTED)
								WHERE POO.POIdPlanOpcion = PF.POidPlanoPCION
								  AND POO.POOpcionForzosa = '1'
							)
						  );
					END

					

					/*****************************obtener una vigencia anterior de una empresa***************************/


	IF ((@Transfer = 'def1' AND @haySeleccionesAnteriores <> 0)
	OR (@Transfer = 'def3' AND @haySeleccionesAplicables > 0))  
		BEGIN  
		print 'se metio en planes selecciones anteriores'
		
			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true'  
				FROM #tmpPlanesFlexibles PF  
				
				INNER JOIN dbo.ff_PlanOpcionSeleccion PO  WITH (NOLOCK,READUNCOMMITTED) 
	
				ON PF.POidPlanoPCION = PO.POidPlanOpcion

				where  PO.POidSolicitud = @idSolicitudAnterior
				  AND
				  (
					@Transfer = 'def1'
					OR
					(
						@Transfer = 'def3'
						AND PO.POIdEstatus IN (1, 4, 5, 10)
						AND
						(
							PF.TCidTipoTarifa = 2
							OR
							PF.Id = PO.POIdEmpleado
							OR EXISTS
							(
								SELECT 1
								FROM dbo.ff_PlanOpcion POO WITH (NOLOCK, READUNCOMMITTED)
								WHERE POO.POIdPlanOpcion = PF.POidPlanoPCION
								  AND POO.POOpcionForzosa = '1'
							)
						)
					)
				  )
			-- CAT 2026-10-29: si el integrante no existia en la solicitud
			-- anterior, asigna sus planes basicos individuales. Solo toma una
			-- opcion por plan y no reemplaza una opcion ya seleccionada/forzosa.
			IF @Transfer = 'def3'
			BEGIN
				;WITH BasicosIndividualesCandidatos AS
				(
					SELECT DISTINCT
						PF.Id,
						PF.POIdPlan,
						PF.POIdPlanOpcion,
						PB.PBIdPlanBasico,
						PB.PBFlexible
					FROM #tmpPlanesFlexibles PF
					INNER JOIN dbo.ff_PlanBasico PB WITH (NOLOCK, READUNCOMMITTED)
						ON PB.PBIdPlanOpcion = PF.POIdPlanOpcion
					INNER JOIN dbo.ff_PlanBasicoDetalle PBD WITH (NOLOCK, READUNCOMMITTED)
						ON PBD.PBIdPlanBasico = PB.PBIdPlanBasico
					   AND PBD.PBIdParentesco = PF.IDPARENTESCO
					WHERE PF.TCIdTipoTarifa = 1
					  AND PB.PBIdPerfil = @idPerfil
					  AND PB.PBFormaCredito NOT IN ('4', '8')
					  AND PB.PBIdEstatus = 1
					  AND PBD.PBIdEstatus = 1
					  AND NOT (PB.PBParentescoDefaulteo = 2 AND PF.IDPARENTESCO <> 1)
					  AND NOT EXISTS
					  (
						SELECT 1
						FROM dbo.ff_PlanOpcionSeleccion Anterior WITH (NOLOCK, READUNCOMMITTED)
						WHERE Anterior.POIdSolicitud = @idSolicitudAnterior
						  AND Anterior.POIdEmpleado = PF.Id
						  AND Anterior.POIdEstatus IN (1, 4, 5, 10)
					  )
					  AND NOT EXISTS
					  (
						SELECT 1
						FROM #tmpPlanesFlexibles Seleccionado
						WHERE Seleccionado.Id = PF.Id
						  AND Seleccionado.POIdPlan = PF.POIdPlan
						  AND Seleccionado.Checked = 'true'
					  )
				),
				BasicosIndividualesElegidos AS
				(
					SELECT *,
						ROW_NUMBER() OVER
						(
							PARTITION BY Id, POIdPlan
							ORDER BY PBIdPlanBasico, POIdPlanOpcion
						) AS orden
					FROM BasicosIndividualesCandidatos
				)
				UPDATE PF
				SET PF.Checked = 'true',
					PF.Enabled = CASE Elegido.PBFlexible WHEN '0' THEN 'false' ELSE 'true' END
				FROM #tmpPlanesFlexibles PF
				INNER JOIN BasicosIndividualesElegidos Elegido
					ON Elegido.Id = PF.Id
				   AND Elegido.POIdPlan = PF.POIdPlan
				   AND Elegido.POIdPlanOpcion = PF.POIdPlanOpcion
				   AND Elegido.orden = 1
				WHERE PF.TCIdTipoTarifa = 1;

				-- Si la composicion familiar genero una tarifa grupal nueva y el
				-- plan aun no tiene seleccion, aplica un solo basico para ese plan.
				;WITH BasicosGrupalesBase AS
				(
					SELECT
						PF.POIdPlan,
						PF.POIdPlanOpcion,
						PF.IDPARENTESCO,
						PB.PBIdPlanBasico,
						PB.PBParentescoDefaulteo,
						COUNT(*) OVER
						(
							PARTITION BY PF.POIdPlanOpcion, PF.IDPARENTESCO
						) AS integrantes
					FROM #tmpPlanesFlexibles PF
					INNER JOIN dbo.ff_PlanBasico PB WITH (NOLOCK, READUNCOMMITTED)
						ON PB.PBIdPlanOpcion = PF.POIdPlanOpcion
					WHERE PF.TCIdTipoTarifa = 2
					  AND PB.PBIdPerfil = @idPerfil
					  AND PB.PBFormaCredito NOT IN ('4', '8')
					  AND PB.PBIdEstatus = 1
					  AND NOT EXISTS
					  (
						SELECT 1
						FROM #tmpPlanesFlexibles Seleccionado
						WHERE Seleccionado.POIdPlan = PF.POIdPlan
						  AND Seleccionado.Checked = 'true'
					  )
				),
				BasicosGrupalesDistintos AS
				(
					SELECT DISTINCT
						POIdPlan, POIdPlanOpcion, IDPARENTESCO,
						PBIdPlanBasico, PBParentescoDefaulteo, integrantes
					FROM BasicosGrupalesBase
				),
				BasicosGrupalesElegidos AS
				(
					SELECT *,
						ROW_NUMBER() OVER
						(
							PARTITION BY POIdPlan
							ORDER BY
								CASE WHEN PBParentescoDefaulteo = 1 THEN integrantes END DESC,
								CASE WHEN PBParentescoDefaulteo = 2 THEN integrantes END ASC,
								PBIdPlanBasico, POIdPlanOpcion, IDPARENTESCO
						) AS orden
					FROM BasicosGrupalesDistintos
				)
				UPDATE PF
				SET PF.Checked = 'true'
				FROM #tmpPlanesFlexibles PF
				INNER JOIN BasicosGrupalesElegidos Elegido
					ON Elegido.POIdPlan = PF.POIdPlan
				   AND Elegido.POIdPlanOpcion = PF.POIdPlanOpcion
				   AND Elegido.IDPARENTESCO = PF.IDPARENTESCO
				   AND Elegido.orden = 1
				WHERE PF.TCIdTipoTarifa = 2;
			END
		END
	ELSE
		BEGIN  
			/***************************pruba**********************************/

			print 'se metio en planes basicos defaulteo'
					UPDATE #tmpPlanesFlexibles  
				SET checked = 'true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_planbASico PB  WITH (NOLOCK,READUNCOMMITTED) ON POidPlanoPCION = PBidPlanOpciON
				WHERE PF.IDPARENTESCO IN(CASE PBParentescoDefaulteo   
									WHEN 1 THEN (SELECT IDPARENTESCO  
													FROM dbo.#tmpPlanesFlexibles  
													WHERE POidPlanoPCION = PBidPlanOpciON  
													GROUP BY POidPlanoPCION, IDPARENTESCO  
													HAVING COUNT(*) = (SELECT TOP 1 COUNT(*) 
																	FROM #tmpPlanesFlexibles 
																	WHERE POidPlanoPCION = PBidPlanOpciON 
																	GROUP BY POidPlanoPCION, IDPARENTESCO 
																	ORDER BY 1 DESC))   
									WHEN 2 THEN (SELECT IDPARENTESCO  
													FROM #tmpPlanesFlexibles   
													WHERE POidPlanoPCION = PBidPlanOpciON  
													GROUP BY POidPlanoPCION, IDPARENTESCO  
													HAVING COUNT(POidPlanoPCION) = (SELECT TOP 1 COUNT(*) 
																					FROM #tmpPlanesFlexibles 
																					WHERE POidPlanoPCION = PBidPlanOpciON 
																					GROUP BY POidPlanoPCION, IDPARENTESCO 
																					ORDER BY 1 ASC))   
									END)  
				AND PBidPerfil = @idPerfil  
				AND PBFormaCredito <> 4 
				AND PBFormaCredito <> 8
				AND TCidTipoTarIFa = 2  
				AND PBidEstatus = 1
     
		UPDATE #tmpPlanesFlexibles  
			SET checked = CASE 
							WHEN PBParentescoDefaulteo=2 AND PF.IDPARENTESCO<>1 THEN 'false' 
							ELSE 'true' 
							END,
				ENABLED = CASE PB.PBFLEXIBLE 
							WHEN 0 THEN 'false' 
							ELSE 'true' 
							END 
			FROM #tmpPlanesFlexibles PF  
			INNER JOIN dbo.ff_planbASico PB WITH (NOLOCK,READUNCOMMITTED) 
				ON POidPlanoPCION = PBidPlanOpciON
			INNER JOIN dbo.ff_PlanBASicoDetalle PBD WITH (NOLOCK,READUNCOMMITTED) 
				ON PB.PBidPlanBASico = PBD.PBidPlanBASico   
			WHERE	PBidPerfil = @idPerfil 
				AND PBD.PBidParentesco = PF.IDPARENTESCO  
				AND TCidTipoTarIFa = 1  
				AND PBFormaCredito NOT IN (4,8)
				AND Pb.PBidEstatus = 1 
				AND Pbd.PBidEstatus = 1
	      END  

			/***************************pruba**********************************/
		END

	
	
		--planes Basicos

		/*antes*******************************************/
		/*
			UPDATE #tmpPlanesFlexibles  
				SET checked = 'true'  
				FROM #tmpPlanesFlexibles PF  
				INNER JOIN dbo.ff_planbASico PB  WITH (NOLOCK,READUNCOMMITTED) ON POidPlanoPCION = PBidPlanOpciON
				WHERE PF.IDPARENTESCO IN(CASE PBParentescoDefaulteo   
									WHEN 1 THEN (SELECT IDPARENTESCO  
													FROM dbo.#tmpPlanesFlexibles  
													WHERE POidPlanoPCION = PBidPlanOpciON  
													GROUP BY POidPlanoPCION, IDPARENTESCO  
													HAVING COUNT(*) = (SELECT TOP 1 COUNT(*) 
																	FROM #tmpPlanesFlexibles 
																	WHERE POidPlanoPCION = PBidPlanOpciON 
																	GROUP BY POidPlanoPCION, IDPARENTESCO 
																	ORDER BY 1 DESC))   
									WHEN 2 THEN (SELECT IDPARENTESCO  
													FROM #tmpPlanesFlexibles   
													WHERE POidPlanoPCION = PBidPlanOpciON  
													GROUP BY POidPlanoPCION, IDPARENTESCO  
													HAVING COUNT(POidPlanoPCION) = (SELECT TOP 1 COUNT(*) 
																					FROM #tmpPlanesFlexibles 
																					WHERE POidPlanoPCION = PBidPlanOpciON 
																					GROUP BY POidPlanoPCION, IDPARENTESCO 
																					ORDER BY 1 ASC))   
									END)  
				AND PBidPerfil = @idPerfil  
				AND PBFormaCredito <> 4 
				AND PBFormaCredito <> 8
				AND TCidTipoTarIFa = 2  
				AND PBidEstatus = 1
     
		UPDATE #tmpPlanesFlexibles  
			SET checked = CASE 
							WHEN PBParentescoDefaulteo=2 AND PF.IDPARENTESCO<>1 THEN 'false' 
							ELSE 'true' 
							END,
				ENABLED = CASE PB.PBFLEXIBLE 
							WHEN 0 THEN 'false' 
							ELSE 'true' 
							END 
			FROM #tmpPlanesFlexibles PF  
			INNER JOIN dbo.ff_planbASico PB WITH (NOLOCK,READUNCOMMITTED) 
				ON POidPlanoPCION = PBidPlanOpciON
			INNER JOIN dbo.ff_PlanBASicoDetalle PBD WITH (NOLOCK,READUNCOMMITTED) 
				ON PB.PBidPlanBASico = PBD.PBidPlanBASico   
			WHERE	PBidPerfil = @idPerfil 
				AND PBD.PBidParentesco = PF.IDPARENTESCO  
				AND TCidTipoTarIFa = 1  
				AND PBFormaCredito NOT IN (4,8)
				AND Pb.PBidEstatus = 1 
				AND Pbd.PBidEstatus = 1
	END  

	*/
	/*antes fin***********************************************************/
	PRINT 'EVALUA SI LOS PLANES REQUIEREN DE LA SELECCION DEL TITULAR  '
 
 
	UPDATE #tmpPlanesFlexibles  
		 SET VISIBLE = 'FALSE', 
			 ENABLED = 'FALSE', 
			 CHECKED = 'FALSE'  
		 WHERE   IDPARENTESCO = 1 
			 AND POIDPLANOPCION IN
								(SELECT POIDPLANOPCION  
								 FROM #tmpPlanesFlexibles  
								 WHERE	PLCoberturaForzosaTitular = '1' 
									AND EMIDPARENTESCO = 1  
								 GROUP BY POIDPLANOPCION  
								 HAVING COUNT(*) > 1)
		AND tcidgrupoparentesco = @GpoTitular
		AND @NUCLEOFAMILIAR = '1' 
 

--	select count(*) from #tmpPlanesFlexibles where checked = 'true'  


	UPDATE #tmpPlanesFlexibles  
		SET checked = 'true', 
			vISible = 'true', 
			enabled = 'false'   
		FROM	#tmpPlanesFlexibles  
		WHERE	idparentesco = 1 
			AND checked='false' 
			AND plcoberturaforzosatitular = '1' 
			AND poidplanopciON IN 
								(SELECT poidplanopciON  
								 FROM	#tmpPlanesFlexibles tmp  
								 WHERE	plcoberturaforzosatitular = '1' 
									AND checked = 'true'  
								 GROUP BY poidplanopciON  
								 HAVING COUNT(*)=(SELECT COUNT(*) 
												  FROM	#tmpPlanesFlexibles  
												  WHERE	plcoberturaforzosatitular = '1' 
													AND checked = 'true' 
													AND emidparentesco NOT IN (1) 
													AND tmp.poidplanopciON = poidplanopciON))


--		select count(*) from #tmpPlanesFlexibles where checked = 'true' 


	 /************************************************************************************/  
	 /************ ACTUALIZA A NO VISIBLES LOS PLANES QUE REQUIEREN DEL TITULAR Y ESTE NO 
	 SE ENCUENTRA EN EL PLAN, APOYANDOSE EN LA TABLA FF_PLANRELACION *********************/  
	 /************************************************************************************/  
 
	UPDATE #tmpPlanesFlexibles   
		SET vISible = 'false', 
			checked = 'false', 
			enabled = 'false'  
		WHERE poidplan IN
				(SELECT DISTINCT pridplan  
				FROM dbo.ff_planrelaciON WITH (NOLOCK,READUNCOMMITTED) 
				WHERE pridplanrelaciON NOT IN (
									SELECT  pridplanrelaciON  
									FROM #tmpPlanesFlexibles  
									INNER JOIN dbo.ff_planrelaciON pr WITH (NOLOCK,READUNCOMMITTED) 
										ON poidplan = pr.pridplan
									WHERE pridplanrelaciON IN (
										SELECT pridplanrelaciON  
										FROM dbo.ff_planrelaciON  WITH (NOLOCK,READUNCOMMITTED)  
										INNER JOIN dbo.ff_plan WITH (NOLOCK,READUNCOMMITTED)  ON pridplan = plidplan  
										WHERE	plcoberturaforzosatitular = '1') 
									AND emidparentesco = 1))
									AND plcoberturaforzosatitular = '1'

	/******************************************************************************************/  
	/***************************************  EVALUA LOS CANDADOS  ****************************/  
	-- PRINT 'entran cANDados1'  
	-- EXECUTE dbo.ff_CevaluacANDados @idEmpleado, @idEmpresa, @NumeroEmpleado  
	/************************************ NEW*********************************/  

 END
GO


