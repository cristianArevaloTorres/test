# Corrección Def3: solicitud anterior rechazada

Fecha: 2026-11-10

## Resultado funcional

`Actualización de dependientes solicitud anterior` conserva las elecciones de
la solicitud inmediatamente anterior aunque ésta esté en estado 5 (Rechazada).
Después reconcilia esas elecciones con la familia vigente mediante las reglas
ya configuradas de perfil, opción, parentesco, edad, tarifa grupal y opción
forzosa.

El cambio evita que Def3 pierda la historia y caiga en los planes básicos sólo
porque el administrador tuvo que rechazar la solicitud antes de dar de alta o
de baja a un dependiente.

## Causa raíz

Los dos motores buscaban solicitudes únicamente en estados 1, 3 y 4, y leían
selecciones en estados 1, 4 y 10. El flujo funcional exige rechazar primero la
solicitud para permitir cambios en la familia, por lo que la solicitud y sus
selecciones quedan en estado 5. Al excluirlas, `@idSolicitudAnterior` quedaba
sin una fuente aplicable y el procedimiento ejecutaba el fallback de básicos.

## Alcance técnico

Se modifican sólo las ramas `@Transfer = 'def3'` de:

- `dbo.ff_CBuscaPlanEspejoTest`;
- `dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3`.

Def3 admite ahora:

- solicitudes en estados `(1, 3, 4, 5)`;
- selecciones en estados `(1, 4, 5, 10)`.

La consulta sigue escogiendo `TOP (1) ... ORDER BY SOIdSolicitud DESC`, es
decir, la solicitud inmediatamente anterior con elecciones. No se mezclan
elecciones de solicitudes rechazadas más antiguas. Las reglas de asignación no
cambian: una opción individual sólo se conserva para el mismo integrante; las
opciones grupales y forzosas se recalculan con la familia actual; un integrante
nuevo recibe únicamente los básicos/configuraciones que le correspondan.

No se cambian firmas, Java, Angular, wrappers, candados ni los comportamientos
de def1, def2 o flujo normal.

## Decisión de alcance

La entrega del 2026-10-30 excluía de forma intencional cualquier solicitud
rechazada. La evidencia funcional nueva reemplaza esa regla **únicamente para
Def3**: el administrador debe rechazar la solicitud para desbloquear la edición
de dependientes y luego elige explícitamente `Actualización de dependientes
solicitud anterior`.

El modelo actual no guarda la causa del rechazo ni recibe un id de solicitud
origen en Casos Especiales. Por eso el contrato aplicado es el que sí puede
representar el sistema actual: al invocar Def3 se toma la solicitud más reciente
del mismo empleado, empresa y vigencia que tenga elecciones utilizables, aunque
esté rechazada. El `TOP (1)` evita mezclar historiales y el estado 5 no se admite
fuera de las ramas Def3.

Si en el futuro se necesita distinguir un rechazo hecho para actualizar la
familia de cualquier otro rechazo administrativo, deberá persistirse y
propagarse un `idSolicitudOrigenDef3` (o un marcador equivalente). Esa
correlación no existe hoy y agregarla sería un cambio de contrato de UI,
servicio, wrappers y base de datos distinto al requerimiento corregido aquí.

## Orden de instalación

1. Respaldar la definición vigente de los dos motores.
2. Ejecutar `database/01_ALTER_DOS_SP_INCLUIR_RECHAZADA.sql`.
3. Ejecutar `database/04_VALIDAR_INSTALACION_Y_QA.sql`.
4. Ejecutar `database/02_PRUEBA_MOTORES_TRANSACCIONAL.sql`.
5. Ejecutar `database/03_PRUEBA_WRAPPERS_SMOKE.sql`.
6. En QA, reproducir alta y baja de dependiente y comparar el resultado contra
   `Generación de Cambios Calificados` para la misma familia.

Para inspeccionar específicamente los casos de referencia, ejecutar
`database/06_DIAGNOSTICO_QA_3296357_3296358.sql` en QA.

Las pruebas 02 y 03 hacen `ROLLBACK`; no dejan datos sintéticos.

## Criterios de aceptación

- Alta: conserva todos los planes anteriores del titular; agrega al nuevo
  dependiente sólo donde la configuración lo hace elegible/obligatorio.
- Baja: elimina al dependiente inactivo y conserva los mismos planes para los
  familiares restantes, recalculando grupo y costo.
- El resultado funcional debe coincidir con Cambios Calificados para la misma
  solicitud anterior y la misma familia actual.
- Def1, def2 y flujo normal mantienen su comportamiento.

## Rollback

Ejecutar `database/05_ROLLBACK_DOS_SP_VERSION_20261030.sql`.

El rollback fue ejecutado en LocalDB y restauró los hashes previos; después se
reinstaló y validó nuevamente la corrección.

## Limitación del dataset local

`dateset1.csv` no contiene las solicitudes 3296357/3296358 ni un candidato
completo y ejecutable con vigencia activa, solicitud rechazada con elecciones y
familia apta. Por eso la regresión exacta se cubrió con fixture transaccional.
La aceptación final de esos dos casos debe realizarse con sus datos de QA.
