USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @SolicitudOrigen INT = 3296357;
DECLARE @SolicitudDef3 INT = 3296358;
DECLARE @IdEmpleado INT;
DECLARE @IdEmpresa INT;
DECLARE @IdVigencia INT;

SELECT
    @IdEmpleado = COALESCE(N.SOIdEmpleado, O.SOIdEmpleado),
    @IdEmpresa = COALESCE(N.SOIdEmpresa, O.SOIdEmpresa),
    @IdVigencia = COALESCE(N.SOIdVigencia, O.SOIdVigencia)
FROM (SELECT 1 AS X) D
LEFT JOIN dbo.ff_Solicitud O
    ON O.SOIdSolicitud = @SolicitudOrigen
LEFT JOIN dbo.ff_Solicitud N
    ON N.SOIdSolicitud = @SolicitudDef3;

SELECT
    'SOLICITUDES' AS bloque,
    S.SOIdSolicitud,
    S.SOSolicitudEmpleado,
    S.SOAnexoSolicitud,
    S.SOIdEmpleado,
    S.SOIdEmpresa,
    S.SOIdVigencia,
    S.SOEstatusSolicitud,
    S.SOIdCambioCalificado,
    S.SOFechaAdd,
    S.SOFechaUMod,
    COUNT(PS.PlanOpcionSeleccion_Id) AS selecciones,
    SUM(CASE WHEN PS.POIdEstatus IN (1, 4, 5, 10) THEN 1 ELSE 0 END)
        AS seleccionesUtilizablesDef3
FROM dbo.ff_Solicitud S
LEFT JOIN dbo.ff_PlanOpcionSeleccion PS
    ON PS.POIdSolicitud = S.SOIdSolicitud
WHERE S.SOIdSolicitud IN (@SolicitudOrigen, @SolicitudDef3)
GROUP BY
    S.SOIdSolicitud,
    S.SOSolicitudEmpleado,
    S.SOAnexoSolicitud,
    S.SOIdEmpleado,
    S.SOIdEmpresa,
    S.SOIdVigencia,
    S.SOEstatusSolicitud,
    S.SOIdCambioCalificado,
    S.SOFechaAdd,
    S.SOFechaUMod
ORDER BY S.SOIdSolicitud;

/* Debe devolver 3296357 para el caso reportado. */
SELECT TOP (1)
    'FUENTE_QUE_ELEGIRIA_DEF3' AS bloque,
    S.SOIdSolicitud,
    S.SOEstatusSolicitud,
    S.SOIdVigencia,
    S.SOFechaAdd
FROM dbo.ff_Solicitud S
WHERE S.SOIdEmpleado = @IdEmpleado
  AND S.SOIdEmpresa = @IdEmpresa
  AND S.SOIdVigencia = @IdVigencia
  AND S.SOEstatusSolicitud IN (1, 3, 4, 5)
  AND EXISTS
      (
          SELECT 1
          FROM dbo.ff_PlanOpcionSeleccion PS
          WHERE PS.POIdSolicitud = S.SOIdSolicitud
            AND PS.POIdEstatus IN (1, 4, 5, 10)
      )
  AND S.SOIdSolicitud < @SolicitudDef3
ORDER BY S.SOIdSolicitud DESC;

SELECT
    'DETALLE_ELECCIONES' AS bloque,
    PS.POIdSolicitud,
    PS.POIdEmpleado,
    E.EMIdParentesco,
    E.EMIdEstatus AS estatusEmpleado,
    PS.POIdPlanOpcion,
    P.PODescripcion,
    P.POIdPlan,
    PL.PLNombre,
    PS.POIdEstatus AS estatusSeleccion,
    PS.PODefaulteo,
    PS.POTarifaNeta
FROM dbo.ff_PlanOpcionSeleccion PS
LEFT JOIN dbo.ff_Empleado E
    ON E.Id = PS.POIdEmpleado
LEFT JOIN dbo.ff_PlanOpcion P
    ON P.POIdPlanOpcion = PS.POIdPlanOpcion
LEFT JOIN dbo.ff_Plan PL
    ON PL.PLIdPlan = P.POIdPlan
WHERE PS.POIdSolicitud IN (@SolicitudOrigen, @SolicitudDef3)
ORDER BY
    PS.POIdSolicitud,
    PS.POIdPlanOpcion,
    PS.POIdEmpleado;

DROP TABLE IF EXISTS #Origen;
DROP TABLE IF EXISTS #Nueva;

CREATE TABLE #Origen
(
    POIdPlanOpcion INT NOT NULL,
    POIdEmpleado INT NOT NULL,
    filas INT NOT NULL,
    PRIMARY KEY (POIdPlanOpcion, POIdEmpleado)
);

CREATE TABLE #Nueva
(
    POIdPlanOpcion INT NOT NULL,
    POIdEmpleado INT NOT NULL,
    filas INT NOT NULL,
    PRIMARY KEY (POIdPlanOpcion, POIdEmpleado)
);

INSERT INTO #Origen (POIdPlanOpcion, POIdEmpleado, filas)
SELECT
    PS.POIdPlanOpcion,
    PS.POIdEmpleado,
    COUNT(*)
FROM dbo.ff_PlanOpcionSeleccion PS
WHERE PS.POIdSolicitud = @SolicitudOrigen
  AND PS.POIdEstatus IN (1, 4, 5, 10)
GROUP BY PS.POIdPlanOpcion, PS.POIdEmpleado
OPTION (MAXDOP 1);

INSERT INTO #Nueva (POIdPlanOpcion, POIdEmpleado, filas)
SELECT
    PS.POIdPlanOpcion,
    PS.POIdEmpleado,
    COUNT(*)
FROM dbo.ff_PlanOpcionSeleccion PS
WHERE PS.POIdSolicitud = @SolicitudDef3
  AND PS.POIdEstatus IN (1, 4, 5, 10)
GROUP BY PS.POIdPlanOpcion, PS.POIdEmpleado
OPTION (MAXDOP 1);

SELECT
    'DIFERENCIAS_ORIGEN_VS_DEF3' AS bloque,
    COALESCE(O.POIdPlanOpcion, N.POIdPlanOpcion) AS POIdPlanOpcion,
    P.PODescripcion,
    COALESCE(O.POIdEmpleado, N.POIdEmpleado) AS POIdEmpleado,
    E.EMIdParentesco,
    E.EMIdEstatus AS estatusEmpleado,
    ISNULL(O.filas, 0) AS filasOrigen,
    ISNULL(N.filas, 0) AS filasDef3,
    CASE
        WHEN O.POIdPlanOpcion IS NULL THEN 'AGREGADA_EN_DEF3'
        WHEN N.POIdPlanOpcion IS NULL THEN 'ELIMINADA_EN_DEF3'
        ELSE 'CAMBIO_CANTIDAD'
    END AS diferencia
FROM #Origen O
FULL OUTER JOIN #Nueva N
    ON N.POIdPlanOpcion = O.POIdPlanOpcion
   AND N.POIdEmpleado = O.POIdEmpleado
LEFT JOIN dbo.ff_PlanOpcion P
    ON P.POIdPlanOpcion = COALESCE(O.POIdPlanOpcion, N.POIdPlanOpcion)
LEFT JOIN dbo.ff_Empleado E
    ON E.Id = COALESCE(O.POIdEmpleado, N.POIdEmpleado)
WHERE ISNULL(O.filas, 0) <> ISNULL(N.filas, 0)
ORDER BY POIdPlanOpcion, POIdEmpleado
OPTION (MAXDOP 1);

IF @IdEmpleado IS NULL
    THROW 51000, 'No se encontraron 3296357/3296358 en este ambiente.', 1;
GO
