# Resultados de pruebas LocalDB

Fecha: 2026-11-10  
Servidor: `(localdb)\\MSSQLLocalDB`  
Base: `FlexiForbesv2`

## Población del dataset

- Lote: `D61CA60A-A03E-C1F7-1866-437740ADCC50`.
- Estado: `APLICADO`.
- 65 tablas funcionales.
- 690,990 filas de datos: 688,473 insertadas y 2,517 actualizadas.
- 0 JSON inválidos y 0 tablas con error de carga.
- 148 relaciones FK auditadas; 11 relaciones conservan 1,816 referencias
  ausentes que ya venían así en el CSV.
- Se crearon únicamente tres roles mínimos requeridos por FKs habilitadas de
  `ff_Empleado`.

## Instalación

`database/04_VALIDAR_INSTALACION_Y_QA.sql`:

- `ff_CBuscaPlanEspejoTest`: `CORRECCION_INSTALADA`.
- `ff_CBuscaPlanEspejoTestMultivigenciaBF3`: `CORRECCION_INSTALADA`.
- Resultado final: `VALIDACION_OK`.

Hashes instalados:

- `ff_CBuscaPlanEspejoTest`:
  `3F59B6D7494BA853633723B047BE14F58228B4393D836D4D9CAB88F7B98BD9EC`.
- `ff_CBuscaPlanEspejoTestMultivigenciaBF3`:
  `291DE76CF5C6945B5D90BB6A83EE7C7654BED76B1B5E13BFAAE281B81DFA8605`.

## Regresión de motores

`database/02_PRUEBA_MOTORES_TRANSACCIONAL.sql`:

- Resultado: `PRUEBA_OK_SIN_CAMBIOS_PERMANENTES`.
- 28 ejecuciones validadas.
- `@@TRANCOUNT = 0`.
- Cubre estados 1, 4, 5 y 10; solicitud inmediatamente anterior rechazada;
  alta y baja de dependientes; mismo integrante; cambio de parentesco; opción
  individual, básica, forzosa y grupal; def1, def2, def3 y flujo normal; motor
  actual y multivigencia.

## Regresión de wrappers

`database/03_PRUEBA_WRAPPERS_SMOKE.sql`:

- Resultado: `SMOKE_WRAPPERS_OK_SIN_CAMBIOS_PERMANENTES`.
- 8 ejecuciones validadas.
- `@@TRANCOUNT = 0`.
- Cubre flujo normal, def1, def2 y def3 en los wrappers de vigencia actual y
  multivigencia.

## Rollback probado

El rollback se ejecutó sin error y restauró los hashes de 2026-10-30:

- `8A5577893FAB9B23566644940C8E3790C0B310DF4C2CC71A3A3CBA86B2293E9F`.
- `5D57248AC2B9F39D094C684DC4B6E8B66173B199C9955CEA5A0D5DA975D92693`.

Después se reinstaló la corrección y `04_VALIDAR_INSTALACION_Y_QA.sql` volvió a
terminar con `VALIDACION_OK`.

## Pendiente de aceptación QA

El CSV no contiene 3296357/3296358. Falta ejecutar en QA los escenarios reales
de alta y baja y comparar la nueva solicitud contra Cambios Calificados.

`database/06_DIAGNOSTICO_QA_3296357_3296358.sql` se ejecutó correctamente en
LocalDB y terminó con el error controlado esperado: esos dos ids no existen en
el dataset. El diagnóstico quedó optimizado para comparar ambos conjuntos sin
solicitar una concesión de memoria grande.
