USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

/*
  CAT 2026-11-10: regresion transaccional de los dos motores PlanEspejo.

  Alcance determinista sobre el fixture local QADEF3D-186:
    - def3 reutiliza selecciones historicas 1, 4, 5 y 10;
    - la solicitud rechazada inmediatamente anterior es la fuente de def3;
    - alta: conserva lo propio del titular y no lo hereda al nuevo dependiente;
    - alta: conserva/recalcula seleccion forzosa y grupal;
    - alta: asigna el basico aplicable al nuevo dependiente;
    - sin cambio: conserva la seleccion del mismo integrante;
    - baja/ultimo dependiente: no crea filas para un integrante ausente;
    - cambio de parentesco: no reutiliza una seleccion individual incompatible;
    - sin historia y def2: aplica basicos, no opciones historicas;
    - flujo normal: respeta el staging vigente;
    - ambos motores: vigencia actual y multivigencia.

  Todos los cambios de datos se realizan dentro de BEGIN TRAN/ROLLBACK.
  El script falla con THROW ante cualquier resultado distinto al esperado.
*/

IF OBJECT_ID('dbo.ff_CBuscaPlanEspejoTest', 'P') IS NULL
    THROW 51000, 'No existe dbo.ff_CBuscaPlanEspejoTest.', 1;

IF OBJECT_ID('dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3', 'P') IS NULL
    THROW 51000, 'No existe dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Empleado
    WHERE ID = 7314560
      AND EMNumeroEmpleado = 'QADEF3D-186'
      AND EMIdEmpresa = 186
      AND EMIdPerfil = 18966
      AND EMIdTitular = 1
      AND EMIdEstatus = 1
)
    THROW 51000, 'No existe el titular del fixture QADEF3D-186.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Empleado
    WHERE ID = 7314561
      AND EMNumeroEmpleado = 'QADEF3D-186'
      AND EMIdTitular = 7314560
      AND EMIdParentesco = 2
      AND EMIdEstatus = 1
)
    THROW 51000, 'No existe el dependiente del fixture QADEF3D-186.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Solicitud
    WHERE SOIdSolicitud = 3279087
      AND SOIdEmpleado = 7314560
      AND SOIdEmpresa = 186
      AND SOIdVigencia = 438
)
    THROW 51000, 'No existe la solicitud 3279087 del fixture.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_Solicitud
    WHERE SOIdSolicitud = 3279092
      AND SOIdEmpleado = 7314560
      AND SOIdEmpresa = 186
      AND SOIdVigencia = 481
)
    THROW 51000, 'No existe la solicitud 3279092 del fixture.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanOpcionSeleccion
    WHERE POIdPlanOpcionSeleccion = 900000004
      AND POIdSolicitud = 3279087
      AND POIdEmpleado = 7314560
      AND POIdPlanOpcion = 1769
)
    THROW 51000, 'No existe la seleccion opcional 900000004 del fixture.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanOpcion
    WHERE POIdPlanOpcion = 12959
      AND POOpcionForzosa = '1'
)
    THROW 51000, 'La opcion 12959 ya no esta configurada como forzosa.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanOpcionSeleccion
    WHERE POIdPlanOpcionSeleccion IN (-910000001, -910000002, -910000003)
)
    THROW 51000, 'Los IDs negativos reservados para la prueba ya existen.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanBasico
    WHERE PBIdPlanBasico = -910000010
)
    THROW 51000, 'El ID negativo reservado para ff_PlanBasico ya existe.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanBasicoDetalle
    WHERE PBIdPlanBasicoDetalle IN (-910000011, -910000012, -910000013)
)
    THROW 51000, 'Los IDs negativos reservados para ff_PlanBasicoDetalle ya existen.', 1;

DECLARE
    @IdPlanBasicoPrueba INT = -910000010,
    @ResultadoBloqueo INT,
    @PruebasEjecutadas INT = 0,
    @Mensaje NVARCHAR(2048),
    @Motor VARCHAR(20),
    @EstadoSeleccion INT,
    @EstadoSolicitud INT,
    @Esperado BIT,
    @IdVigenciaFallback INT,
    @IdentityPlanBasicoOn BIT = 0,
    @IdentityPlanBasicoDetalleOn BIT = 0;

BEGIN TRY
    BEGIN TRANSACTION;

    EXEC @ResultadoBloqueo = sys.sp_getapplock
        @Resource = N'CAT_DEF3_HISTORICOS_QADEF3D_186',
        @LockMode = 'Exclusive',
        @LockOwner = 'Transaction',
        @LockTimeout = 15000;

    IF @ResultadoBloqueo < 0
        THROW 51000, 'No fue posible obtener el bloqueo exclusivo de la prueba.', 1;

    /* Basico sintetico para titular, conyuge y parentesco alterno. */
    SET IDENTITY_INSERT dbo.ff_PlanBasico ON;
    SET @IdentityPlanBasicoOn = 1;

    INSERT INTO dbo.ff_PlanBasico
    (
        PBidPlanBasico,
        PBidVigencia, PBidPerfil, PBidPlanOpcion, PBFlexible,
        PBParentescoDefaulteo, PBFormaCredito, PBidEstatus,
        PBUsuarioAdd, PBFechaAdd, PBUsuarioUMod, PBFechaUMod,
        PBIdPlan, PBSoloCotizacion
    )
    VALUES
    (
        @IdPlanBasicoPrueba,
        438, 18966, 1775, '0',
        1, '0', 1,
        0, GETDATE(), 0, GETDATE(),
        2050, 0
    );

    SET IDENTITY_INSERT dbo.ff_PlanBasico OFF;
    SET @IdentityPlanBasicoOn = 0;

    SET IDENTITY_INSERT dbo.ff_PlanBasicoDetalle ON;
    SET @IdentityPlanBasicoDetalleOn = 1;

    INSERT INTO dbo.ff_PlanBasicoDetalle
    (
        PBidPlanBasicoDetalle,
        PBidPlanBasico, PBConsecutivo, PBidParentesco,
        PBidEstatus, PBUsuarioAdd, PBFechaAdd, PBUsuarioUMod, PBFechaUMod
    )
    VALUES
        (-910000011, @IdPlanBasicoPrueba, 1, 1, 1, 0, GETDATE(), 0, GETDATE()),
        (-910000012, @IdPlanBasicoPrueba, 2, 2, 1, 0, GETDATE(), 0, GETDATE()),
        (-910000013, @IdPlanBasicoPrueba, 3, 3, 1, 0, GETDATE(), 0, GETDATE());

    SET IDENTITY_INSERT dbo.ff_PlanBasicoDetalle OFF;
    SET @IdentityPlanBasicoDetalleOn = 0;

    /* Historicos sinteticos: forzoso y grupal contratados por el titular. */
    INSERT INTO dbo.ff_PlanOpcionSeleccion
    (
        POIdPlanOpcionSeleccion,
        POIdEmpresaFlexiForbes,
        POIdEmpresa,
        PONumeroEmpleado,
        POIdEmpleado,
        POIdParentesco,
        POEdad,
        POIdGrupoParentesco,
        POIdPlanOpcion,
        POTarifaNeta,
        POIdSolicitud,
        POAnexo,
        POCostoRestante,
        POIdPeriodicidadPago,
        PORequiereAutorizacion,
        POIdVigencia,
        PODefaulteo,
        POIdEstatus,
        POUsuarioAdd,
        POFechaAdd,
        POAutorizado
    )
    VALUES
        (-910000001, 'S001', 186, 'QADEF3D-186', 7314560, 1, 41, NULL,
         12959, 0, 3279087, 0, 0, 8, '0', 438, 0, 1, 0, GETDATE(), 1),
        (-910000002, 'S001', 186, 'QADEF3D-186', 7314560, NULL, 41, 11,
         12955, 0, 3279087, 0, 0, 8, '0', 438, 0, 1, 0, GETDATE(), 1);

    CREATE TABLE #tmpPlanesFlexibles
    (
        id INT NULL,
        EMApellidoMaterno VARCHAR(50) NULL,
        EMApellidoPaterno VARCHAR(50) NULL,
        EMNombre1 VARCHAR(50) NULL,
        EMNombre2 VARCHAR(50) NULL,
        EMIdParentesco INT NULL,
        TCIdTarifaCosto INT NULL,
        TCIdTarifa INT NULL,
        TCIdPlanOpcion INT NULL,
        TCIdTipoTarifa INT NULL,
        TCIdGrupoParentesco INT NULL,
        TCIdParentesco INT NULL,
        TCIdSexo INT NULL,
        TCEdad INT NULL,
        TCIdTipoFumador INT NULL,
        TCPrimaNeta MONEY NULL,
        TCPrimaTotal MONEY NULL,
        POIdPlanOpcion INT NULL,
        POIdPlan INT NULL,
        PONombre VARCHAR(50) NULL,
        PODescripcion VARCHAR(150) NULL,
        POCaptura CHAR(1) NULL,
        PLNombre VARCHAR(50) NULL,
        PLDescripcion VARCHAR(150) NULL,
        PLIdRamo INT NULL,
        PLCoberturaForzosaTitular VARCHAR(1) NULL,
        RANombre VARCHAR(50) NULL,
        RADescripcion VARCHAR(150) NULL,
        ParentescosDescripcion VARCHAR(150) NULL,
        IDPARENTESCO INT NULL,
        PADescripcion VARCHAR(150) NULL,
        Checked VARCHAR(10) NULL,
        Visible VARCHAR(10) NULL,
        Enabled VARCHAR(10) NULL,
        HTMLControl VARCHAR(500) NULL,
        Cantidad INT NULL,
        Archivo VARCHAR(200) NULL,
        RAImg VARCHAR(200) NULL,
        PLImg VARCHAR(200) NULL,
        POImg VARCHAR(200) NULL,
        RAOrden INT NULL,
        PLOrden INT NULL,
        POOrden INT NULL,
        ArchivoPlan VARCHAR(200) NULL,
        PLAyuda VARCHAR(MAX) NULL
    );

    /*
      1769 = opcional individual; 1775 = basico individual;
      12959 = forzoso; 12955 = grupal tipo 2.
    */
    INSERT INTO #tmpPlanesFlexibles
    (
        id, EMIdParentesco, TCIdPlanOpcion, TCIdTipoTarifa,
        TCIdGrupoParentesco, TCIdParentesco, POIdPlanOpcion,
        POIdPlan, IDPARENTESCO, Checked, Visible, Enabled
    )
    VALUES
        (7314560, 1, 1769, 1, NULL, 1, 1769, 549, 1, 'false', 'true', 'true'),
        (7314561, 2, 1769, 1, NULL, 2, 1769, 549, 2, 'false', 'true', 'true'),
        (7314560, 1, 1775, 1, NULL, 1, 1775, 2050, 1, 'false', 'true', 'true'),
        (7314561, 2, 1775, 1, NULL, 2, 1775, 2050, 2, 'false', 'true', 'true'),
        (7314560, 1, 12959, 1, NULL, 1, 12959, 3521, 1, 'false', 'true', 'true'),
        (7314561, 2, 12959, 1, NULL, 2, 12959, 3521, 2, 'false', 'true', 'true'),
        (7314560, 1, 12955, 2, 12, NULL, 12955, 3518, 12, 'false', 'true', 'true'),
        (7314561, 2, 12955, 2, 12, NULL, 12955, 3518, 12, 'false', 'true', 'true');

    /* Matriz de estados historicos: 1, 4, 5 y 10 se reutilizan en def3. */
    DECLARE Estados CURSOR LOCAL FAST_FORWARD FOR
        SELECT EstadoSeleccion,
               CASE WHEN EstadoSeleccion = 10 THEN 4 ELSE EstadoSeleccion END AS EstadoSolicitud,
               1 AS Esperado
        FROM (VALUES (1), (4), (10), (5)) E(EstadoSeleccion);

    OPEN Estados;
    FETCH NEXT FROM Estados INTO @EstadoSeleccion, @EstadoSolicitud, @Esperado;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE dbo.ff_Solicitud
        SET SOEstatusSolicitud = @EstadoSolicitud
        WHERE SOIdSolicitud = 3279087;

        UPDATE dbo.ff_Solicitud
        SET SOIdVigencia = 481,
            SOEstatusSolicitud = 1
        WHERE SOIdSolicitud = 3279092;

        UPDATE dbo.ff_PlanOpcionSeleccion
        SET POIdEstatus = @EstadoSeleccion
        WHERE POIdSolicitud = 3279087;

        DECLARE MotoresEstado CURSOR LOCAL FAST_FORWARD FOR
            SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

        OPEN MotoresEstado;
        FETCH NEXT FROM MotoresEstado INTO @Motor;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            UPDATE #tmpPlanesFlexibles
            SET Checked = 'false', Visible = 'true', Enabled = 'true';

            IF @Motor = 'ACTUAL'
            BEGIN
                EXEC dbo.ff_CBuscaPlanEspejoTest
                    @NUMEROEMPLEADO = 'QADEF3D-186',
                    @idEmpleado = 7314560,
                    @idEmpresa = 186,
                    @idPerfil = 18966,
                    @GpoTitular = 1,
                    @NUCLEOFAMILIAR = '0',
                    @transfer = 'def3',
                    @idVigenciaDestino = 438;
            END
            ELSE
            BEGIN
                EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                    @NUMEROEMPLEADO = 'QADEF3D-186',
                    @idEmpleado = 7314560,
                    @idEmpresa = 186,
                    @idPerfil = 18966,
                    @GpoTitular = 1,
                    @NUCLEOFAMILIAR = '0',
                    @transfer = 'def3',
                    @idVigencia = 438,
                    @idVigenciaDestino = 438;
            END;

            IF ISNULL
               (
                   (SELECT MAX(CASE WHEN Checked = 'true' THEN 1 ELSE 0 END)
                    FROM #tmpPlanesFlexibles
                    WHERE id = 7314560
                      AND POIdPlanOpcion = 1769),
                   0
               ) <> @Esperado
            BEGIN
                SET @Mensaje = CONCAT(
                    'Estado historico ', @EstadoSeleccion,
                    ' incorrecto en motor ', @Motor,
                    '. Esperado=', @Esperado, '.');
                THROW 51001, @Mensaje, 1;
            END;

            SET @PruebasEjecutadas += 1;
            FETCH NEXT FROM MotoresEstado INTO @Motor;
        END;

        CLOSE MotoresEstado;
        DEALLOCATE MotoresEstado;

        FETCH NEXT FROM Estados INTO @EstadoSeleccion, @EstadoSolicitud, @Esperado;
    END;

    CLOSE Estados;
    DEALLOCATE Estados;

    /*
      Fallback real: una solicitud cancelada de la vigencia anterior conserva
      elecciones 4. Se obtiene la misma vigencia legada que consulta el motor
      actual para reproducir exactamente su ruta de respaldo.
    */
    SELECT @IdVigenciaFallback = V.VIIdVigencia
    FROM dbo.ff_Empresa E
    INNER JOIN dbo.ff_Configuracion C
        ON E.EMIdConfiguracion = C.COIdConfiguracion
    INNER JOIN dbo.ff_Vigencia V
        ON V.VIIdConfiguracion = C.COIdConfiguracion
    WHERE E.EMIdEmpresa = 186
      AND V.VIIdEstatus <> 6;

    UPDATE dbo.ff_Solicitud
    SET SOIdVigencia = @IdVigenciaFallback,
        SOEstatusSolicitud = 4
    WHERE SOIdSolicitud = 3279087;

    UPDATE dbo.ff_PlanOpcionSeleccion
    SET POIdVigencia = @IdVigenciaFallback,
        POIdEstatus = 4
    WHERE POIdSolicitud = 3279087;

    DECLARE MotoresFallback CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresFallback;
    FETCH NEXT FROM MotoresFallback INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3',
                @IdVigenciaFallback, 438;

        IF NOT EXISTS
        (
            SELECT 1
            FROM #tmpPlanesFlexibles
            WHERE id = 7314560
              AND POIdPlanOpcion = 1769
              AND Checked = 'true'
        )
        BEGIN
            SET @Mensaje = CONCAT(
                'El fallback no reutilizo el estado 4 en ', @Motor, '.');
            THROW 51010, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresFallback INTO @Motor;
    END;

    CLOSE MotoresFallback;
    DEALLOCATE MotoresFallback;

    UPDATE dbo.ff_Solicitud
    SET SOIdVigencia = 438
    WHERE SOIdSolicitud = 3279087;

    UPDATE dbo.ff_PlanOpcionSeleccion
    SET POIdVigencia = 438
    WHERE POIdSolicitud = 3279087;

    /* Def3 debe tomar la solicitud inmediatamente anterior aunque este rechazada. */
    UPDATE dbo.ff_Solicitud
    SET SOEstatusSolicitud = 4
    WHERE SOIdSolicitud = 3279087;

    UPDATE dbo.ff_PlanOpcionSeleccion
    SET POIdEstatus = 10
    WHERE POIdSolicitud = 3279087;

    UPDATE dbo.ff_Solicitud
    SET SOIdVigencia = 438,
        SOEstatusSolicitud = 5
    WHERE SOIdSolicitud = 3279092;

    UPDATE dbo.ff_PlanOpcionSeleccion
    SET POIdEstatus = 5
    WHERE POIdSolicitud = 3279092;

    DECLARE MotoresRechazo CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresRechazo;
    FETCH NEXT FROM MotoresRechazo INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438, 438;

        IF EXISTS
        (
            SELECT 1 FROM #tmpPlanesFlexibles
            WHERE id = 7314560
              AND POIdPlanOpcion = 1769
              AND Checked = 'true'
        )
        OR NOT EXISTS
        (
            SELECT 1 FROM #tmpPlanesFlexibles
            WHERE id = 7314560
              AND POIdPlanOpcion = 1775
              AND Checked = 'true'
        )
        BEGIN
            SET @Mensaje = CONCAT(
                'Def3 no tomo la solicitud rechazada inmediatamente anterior en ', @Motor, '.');
            THROW 51002, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresRechazo INTO @Motor;
    END;

    CLOSE MotoresRechazo;
    DEALLOCATE MotoresRechazo;

    /* Restaura la segunda solicitud a su vigencia para las pruebas familiares. */
    UPDATE dbo.ff_Solicitud
    SET SOIdVigencia = 481,
        SOEstatusSolicitud = 1
    WHERE SOIdSolicitud = 3279092;

    UPDATE dbo.ff_PlanOpcionSeleccion
    SET POIdEstatus = 1
    WHERE POIdSolicitud = 3279092;

    /* Alta: nuevo dependiente no hereda opcional; recibe forzoso, grupal y basico. */
    DECLARE MotoresAlta CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresAlta;
    FETCH NEXT FROM MotoresAlta INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438, 438;

        IF NOT
        (
            EXISTS (SELECT 1 FROM #tmpPlanesFlexibles WHERE id = 7314560 AND POIdPlanOpcion = 1769 AND Checked = 'true')
            AND NOT EXISTS (SELECT 1 FROM #tmpPlanesFlexibles WHERE id = 7314561 AND POIdPlanOpcion = 1769 AND Checked = 'true')
            AND EXISTS (SELECT 1 FROM #tmpPlanesFlexibles WHERE id = 7314560 AND POIdPlanOpcion = 12959 AND Checked = 'true')
            AND EXISTS (SELECT 1 FROM #tmpPlanesFlexibles WHERE id = 7314561 AND POIdPlanOpcion = 12959 AND Checked = 'true')
            AND EXISTS (SELECT 1 FROM #tmpPlanesFlexibles WHERE id = 7314560 AND POIdPlanOpcion = 12955 AND Checked = 'true')
            AND EXISTS (SELECT 1 FROM #tmpPlanesFlexibles WHERE id = 7314561 AND POIdPlanOpcion = 12955 AND Checked = 'true')
            AND EXISTS (SELECT 1 FROM #tmpPlanesFlexibles WHERE id = 7314561 AND POIdPlanOpcion = 1775 AND Checked = 'true')
        )
        BEGIN
            SET @Mensaje = CONCAT('Fallo el escenario de alta en motor ', @Motor, '.');
            THROW 51003, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresAlta INTO @Motor;
    END;

    CLOSE MotoresAlta;
    DEALLOCATE MotoresAlta;

    /* Sin cambio: el dependiente conserva su propia opcion individual. */
    INSERT INTO dbo.ff_PlanOpcionSeleccion
    (
        POIdPlanOpcionSeleccion,
        POIdEmpresaFlexiForbes,
        POIdEmpresa,
        PONumeroEmpleado,
        POIdEmpleado,
        POIdParentesco,
        POEdad,
        POIdGrupoParentesco,
        POIdPlanOpcion,
        POTarifaNeta,
        POIdSolicitud,
        POAnexo,
        POCostoRestante,
        POIdPeriodicidadPago,
        PORequiereAutorizacion,
        POIdVigencia,
        PODefaulteo,
        POIdEstatus,
        POUsuarioAdd,
        POFechaAdd,
        POAutorizado
    )
    VALUES
    (
        -910000003, 'S001', 186, 'QADEF3D-186', 7314561, 2, 20, NULL,
        1769, 0, 3279087, 0, 0, 8, '0', 438, 0, 10, 0, GETDATE(), 1
    );

    DECLARE MotoresSinCambio CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresSinCambio;
    FETCH NEXT FROM MotoresSinCambio INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET EMIdParentesco = CASE WHEN id = 7314561 THEN 2 ELSE EMIdParentesco END,
            TCIdParentesco = CASE WHEN id = 7314561 AND TCIdTipoTarifa = 1 THEN 2 ELSE TCIdParentesco END,
            IDPARENTESCO = CASE WHEN id = 7314561 AND TCIdTipoTarifa = 1 THEN 2 ELSE IDPARENTESCO END,
            Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438, 438;

        IF NOT EXISTS
        (
            SELECT 1 FROM #tmpPlanesFlexibles
            WHERE id = 7314561
              AND POIdPlanOpcion = 1769
              AND Checked = 'true'
        )
        BEGIN
            SET @Mensaje = CONCAT('No se conservo la seleccion propia del dependiente en ', @Motor, '.');
            THROW 51004, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresSinCambio INTO @Motor;
    END;

    CLOSE MotoresSinCambio;
    DEALLOCATE MotoresSinCambio;

    /* Cambio de parentesco: el mismo integrante conserva la opcion si sigue disponible. */
    DECLARE MotoresParentesco CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresParentesco;
    FETCH NEXT FROM MotoresParentesco INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET EMIdParentesco = CASE WHEN id = 7314561 THEN 3 ELSE EMIdParentesco END,
            TCIdParentesco = CASE WHEN id = 7314561 AND TCIdTipoTarifa = 1 THEN 3 ELSE TCIdParentesco END,
            IDPARENTESCO = CASE WHEN id = 7314561 AND TCIdTipoTarifa = 1 THEN 3 ELSE IDPARENTESCO END,
            Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438, 438;

        IF NOT EXISTS
        (
            SELECT 1 FROM #tmpPlanesFlexibles
            WHERE id = 7314561
              AND POIdPlanOpcion = 1769
              AND Checked = 'true'
        )
        BEGIN
            SET @Mensaje = CONCAT('El mismo integrante perdio su opcion disponible al cambiar parentesco en ', @Motor, '.');
            THROW 51005, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresParentesco INTO @Motor;
    END;

    CLOSE MotoresParentesco;
    DEALLOCATE MotoresParentesco;

    /* Baja y eliminacion del ultimo dependiente: el motor no debe recrear filas. */
    DELETE FROM #tmpPlanesFlexibles WHERE id = 7314561;

    DECLARE MotoresBaja CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresBaja;
    FETCH NEXT FROM MotoresBaja INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438, 438;

        IF EXISTS (SELECT 1 FROM #tmpPlanesFlexibles WHERE id = 7314561)
           OR NOT EXISTS
              (
                  SELECT 1 FROM #tmpPlanesFlexibles
                  WHERE id = 7314560
                    AND POIdPlanOpcion = 1769
                    AND Checked = 'true'
              )
        BEGIN
            SET @Mensaje = CONCAT('Fallo el escenario de baja/ultimo dependiente en ', @Motor, '.');
            THROW 51006, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresBaja INTO @Motor;
    END;

    CLOSE MotoresBaja;
    DEALLOCATE MotoresBaja;

    /* Repone candidato dependiente para def2, sin historia y flujo normal. */
    INSERT INTO #tmpPlanesFlexibles
    (
        id, EMIdParentesco, TCIdPlanOpcion, TCIdTipoTarifa,
        TCIdGrupoParentesco, TCIdParentesco, POIdPlanOpcion,
        POIdPlan, IDPARENTESCO, Checked, Visible, Enabled
    )
    VALUES
        (7314561, 2, 1769, 1, NULL, 2, 1769, 549, 2, 'false', 'true', 'true'),
        (7314561, 2, 1775, 1, NULL, 2, 1775, 2050, 2, 'false', 'true', 'true'),
        (7314561, 2, 12959, 1, NULL, 2, 12959, 3521, 2, 'false', 'true', 'true'),
        (7314561, 2, 12955, 2, 12, NULL, 12955, 3518, 12, 'false', 'true', 'true');

    /* Def3 conserva las elecciones rechazadas de los integrantes ya existentes. */
    UPDATE dbo.ff_Solicitud
    SET SOEstatusSolicitud = 5
    WHERE SOIdSolicitud IN (3279087, 3279092);

    UPDATE dbo.ff_PlanOpcionSeleccion
    SET POIdEstatus = 5
    WHERE POIdSolicitud IN (3279087, 3279092);

    DECLARE MotoresSinHistoria CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresSinHistoria;
    FETCH NEXT FROM MotoresSinHistoria INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def3', 438, 438;

        IF NOT EXISTS
           (
               SELECT 1 FROM #tmpPlanesFlexibles
               WHERE id = 7314560
                 AND POIdPlanOpcion = 1769
                 AND Checked = 'true'
           )
           OR NOT EXISTS
              (
                  SELECT 1 FROM #tmpPlanesFlexibles
                  WHERE id = 7314561
                    AND POIdPlanOpcion = 1769
                    AND Checked = 'true'
              )
        BEGIN
            SELECT
                @Motor AS Motor,
                id,
                POIdPlanOpcion,
                Checked,
                Visible,
                Enabled
            FROM #tmpPlanesFlexibles
            WHERE POIdPlanOpcion IN (1769, 1775)
            ORDER BY id, POIdPlanOpcion;

            SET @Mensaje = CONCAT('Fallo la seleccion de la ultima solicitud rechazada en ', @Motor, '.');
            THROW 51007, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresSinHistoria INTO @Motor;
    END;

    CLOSE MotoresSinHistoria;
    DEALLOCATE MotoresSinHistoria;

    /* def2 conserva su comportamiento de basicos en los dos motores. */
    DECLARE MotoresDef2 CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresDef2;
    FETCH NEXT FROM MotoresDef2 INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def2', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def2', 438, 438;

        IF NOT EXISTS
        (
            SELECT 1 FROM #tmpPlanesFlexibles
            WHERE id = 7314561
              AND POIdPlanOpcion = 1775
              AND Checked = 'true'
        )
        BEGIN
            SET @Mensaje = CONCAT('def2 dejo de aplicar el basico en ', @Motor, '.');
            THROW 51008, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresDef2 INTO @Motor;
    END;

    CLOSE MotoresDef2;
    DEALLOCATE MotoresDef2;

    /*
      def1 depende de la vigencia que devuelve una consulta legada sin ORDER BY.
      En este fixture existen 438 y 481; se valida ejecucion, no una opcion fija.
    */
    UPDATE dbo.ff_Solicitud
    SET SOEstatusSolicitud = 1
    WHERE SOIdSolicitud IN (3279087, 3279092);

    UPDATE dbo.ff_PlanOpcionSeleccion
    SET POIdEstatus = 1
    WHERE POIdSolicitud IN (3279087, 3279092);

    DECLARE MotoresDef1 CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresDef1;
    FETCH NEXT FROM MotoresDef1 INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def1', 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', 'def1', 438, 438;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresDef1 INTO @Motor;
    END;

    CLOSE MotoresDef1;
    DEALLOCATE MotoresDef1;

    SELECT
        'ADVERTENCIA_CONTROLADA' AS resultado,
        'def1 se ejecuto en ambos motores. No se fija una opcion esperada porque la consulta legada de vigencia anterior no define ORDER BY y el fixture tiene dos vigencias.' AS detalle;

    /* Flujo normal: staging activo conserva la seleccion propia del titular. */
    INSERT INTO dbo.ff_PlanOpcionSeleccionTmp
    (
        POIdPlanOpcionSeleccion,
        POIdEmpresaFlexiForbes,
        POIdEmpresa,
        PONumeroEmpleado,
        POIdEmpleado,
        POIdParentesco,
        POEdad,
        POIdGrupoParentesco,
        POIdPlanOpcion,
        POTarifaTotal,
        POCostoRestante,
        POIdPeriodicidadPago,
        PORequiereAutorizacion,
        POIdVigencia,
        PODefaulteo,
        POIdEstatus,
        POUsuarioAdd,
        POFechaAdd
    )
    VALUES
    (
        -910000001, 'S001', 186, 'QADEF3D-186', 7314560, 1, 41, NULL,
        1769, 0, 0, 8, '0', 438, 0, 1, 0, GETDATE()
    );

    DECLARE MotoresNormal CURSOR LOCAL FAST_FORWARD FOR
        SELECT Motor FROM (VALUES ('ACTUAL'), ('MULTIVIGENCIA')) M(Motor);

    OPEN MotoresNormal;
    FETCH NEXT FROM MotoresNormal INTO @Motor;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE #tmpPlanesFlexibles
        SET Checked = 'false', Visible = 'true', Enabled = 'true';

        IF @Motor = 'ACTUAL'
            EXEC dbo.ff_CBuscaPlanEspejoTest
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', NULL, 438;
        ELSE
            EXEC dbo.ff_CBuscaPlanEspejoTestMultivigenciaBF3
                'QADEF3D-186', 7314560, 186, 18966, 1, '0', NULL, 438, 438;

        IF NOT EXISTS
           (
               SELECT 1 FROM #tmpPlanesFlexibles
               WHERE id = 7314560
                 AND POIdPlanOpcion = 1769
                 AND Checked = 'true'
           )
           OR EXISTS
              (
                  SELECT 1 FROM #tmpPlanesFlexibles
                  WHERE id = 7314561
                    AND POIdPlanOpcion = 1769
                    AND Checked = 'true'
              )
        BEGIN
            SET @Mensaje = CONCAT('El flujo normal no respeto el staging individual en ', @Motor, '.');
            THROW 51009, @Mensaje, 1;
        END;

        SET @PruebasEjecutadas += 1;
        FETCH NEXT FROM MotoresNormal INTO @Motor;
    END;

    CLOSE MotoresNormal;
    DEALLOCATE MotoresNormal;

    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF @IdentityPlanBasicoDetalleOn = 1
    BEGIN
        SET IDENTITY_INSERT dbo.ff_PlanBasicoDetalle OFF;
        SET @IdentityPlanBasicoDetalleOn = 0;
    END;

    IF @IdentityPlanBasicoOn = 1
    BEGIN
        SET IDENTITY_INSERT dbo.ff_PlanBasico OFF;
        SET @IdentityPlanBasicoOn = 0;
    END;

    IF CURSOR_STATUS('local', 'Estados') >= -1
    BEGIN
        IF CURSOR_STATUS('local', 'Estados') > -1 CLOSE Estados;
        DEALLOCATE Estados;
    END;

    IF CURSOR_STATUS('local', 'MotoresFallback') >= -1
    BEGIN
        IF CURSOR_STATUS('local', 'MotoresFallback') > -1 CLOSE MotoresFallback;
        DEALLOCATE MotoresFallback;
    END;

    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;

IF @@TRANCOUNT <> 0
    THROW 51000, 'La prueba termino con una transaccion abierta.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanOpcionSeleccion
    WHERE POIdPlanOpcionSeleccion IN (-910000001, -910000002, -910000003)
)
    THROW 51000, 'El ROLLBACK no retiro las selecciones sinteticas.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanOpcionSeleccionTmp
    WHERE POIdPlanOpcionSeleccion = -910000001
)
    THROW 51000, 'El ROLLBACK no retiro el staging sintetico.', 1;

IF @IdPlanBasicoPrueba IS NOT NULL
   AND EXISTS
       (
           SELECT 1
           FROM dbo.ff_PlanBasico
           WHERE PBIdPlanBasico = @IdPlanBasicoPrueba
       )
    THROW 51000, 'El ROLLBACK no retiro el plan basico sintetico.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.ff_PlanBasicoDetalle
    WHERE PBIdPlanBasicoDetalle IN (-910000011, -910000012, -910000013)
)
    THROW 51000, 'El ROLLBACK no retiro los detalles sinteticos.', 1;

SELECT
    'PRUEBA_OK_SIN_CAMBIOS_PERMANENTES' AS resultado,
    @PruebasEjecutadas AS ejecucionesValidadas,
    @@TRANCOUNT AS transaccionesAbiertas;
GO
