# Análisis y justificación de la corrección Def3

Fecha: 2026-11-10

## Qué debe ocurrir

Para modificar el grupo familiar, el administrador primero rechaza la solicitud
vigente. Después ejecuta en Casos Especiales la opción `Actualización de
dependientes solicitud anterior` (Def3). El resultado debe partir de las
elecciones de esa solicitud y reconciliarlas con la familia activa:

- en un alta, conserva la cobertura anterior y agrega al nuevo dependiente sólo
  donde las reglas lo permiten u obligan;
- en una baja, retira al dependiente inactivo y conserva las coberturas de los
  integrantes restantes;
- en ambos casos recalcula opciones grupales, forzosas, elegibilidad y costo.

## Por qué fallaba

El rechazo cambia a 5 tanto `ff_Solicitud.SOEstatusSolicitud` como
`ff_PlanOpcionSeleccion.POIdEstatus`. Sin embargo, los dos motores PlanEspejo
de Def3 sólo aceptaban solicitudes `(1,3,4)` y selecciones `(1,4,10)`.

En consecuencia, el motor no encontraba una fuente histórica aplicable. La
rama de respaldo entregaba planes básicos, aunque la pantalla todavía pudiera
mostrar las elecciones anteriores. Eso explica la diferencia observada entre
la solicitud correcta y la generada por Def3.

## Corrección aplicada

Sólo dentro de Def3, en ambos motores, se agregó el estado 5 a:

1. la búsqueda de la solicitud anterior;
2. la validación de que esa solicitud tenga elecciones;
3. el conjunto de elecciones aplicables;
4. el marcado de elecciones conservadas;
5. la detección de integrantes que ya existían en la solicitud origen.

No se reescribió el algoritmo familiar. Una vez recuperada la historia, el
motor existente continúa aplicando las reglas de parentesco, edad, perfil,
opción individual, grupo y obligatoriedad. Esa es la razón por la que el cambio
es pequeño pero corrige tanto altas como bajas.

## Por qué esta solución corresponde al flujo actual

Casos Especiales no recibe un id de solicitud origen ni la base guarda la causa
del rechazo. La señal funcional disponible es que el administrador eligió
Def3. Dentro de esa operación, el motor toma `TOP (1)` por empleado, empresa y
vigencia, ordenado por el id de solicitud descendente. Así reutiliza una sola
solicitud reciente y no mezcla historiales.

La regla anterior que ignoraba rechazos queda reemplazada sólo en Def3. Los
flujos normal, Def1 y Def2 siguen sin reutilizar estado 5. Si negocio necesitara
distinguir causas de rechazo, sería necesario un cambio posterior para
correlacionar explícitamente la solicitud desde la UI hasta los motores.

## Evidencia de verificación

- 28 ejecuciones transaccionales de motores, incluyendo alta, baja, estado 5,
  opciones individuales, básicas, forzosas y grupales.
- 8 pruebas de humo sobre ambos wrappers y sus cuatro modos de operación.
- instalación, validación, rollback y reinstalación ejecutados en LocalDB.
- ninguna prueba dejó datos sintéticos porque todas terminan con `ROLLBACK`.

La aceptación con 3296357 y 3296358 debe ejecutarse en QA porque el CSV local no
contiene esas solicitudes. El script `database/06_DIAGNOSTICO_QA_3296357_3296358.sql`
deja preparada esa comparación.
