# Publica exclusivamente el ajuste de notificacion de Cobranza.
# Antes de ejecutarlo, copiar la carpeta src del ZIP sobre la raiz de APIREPORTS.

$RepoApi = 'C:\repo\reportes\APIREPORTS'
$Rama = 'ReporteSabanaHomologacionOK-clean'

Set-Location -LiteralPath $RepoApi

if (-not (Test-Path -LiteralPath '.git')) {
    throw "Esta carpeta no es un clon Git: $RepoApi"
}

git switch $Rama
if ($LASTEXITCODE -ne 0) { throw "No se pudo cambiar a $Rama." }

$YaPreparados = @(git diff --cached --name-only)
if ($YaPreparados.Count -gt 0) {
    $YaPreparados
    throw 'Ya existen archivos en staging. Quitalos de staging y vuelve a ejecutar.'
}

git pull --rebase --autostash origin $Rama
if ($LASTEXITCODE -ne 0) {
    throw 'El pull encontro un conflicto. Ejecuta git status antes de continuar.'
}

$Archivos = @(
    'src/main/java/com/lockton/rpt/controllers/WSCobranzaController.java',
    'src/main/java/com/lockton/rpt/services/CobranzaService.java',
    'src/main/java/com/lockton/rpt/services/impl/CobranzaServiceImpl.java'
)

foreach ($Archivo in $Archivos) {
    if (-not (Test-Path -LiteralPath $Archivo)) {
        throw "No se encontro el archivo requerido: $Archivo"
    }
}

git add -- $Archivos
if ($LASTEXITCODE -ne 0) { throw 'No se pudieron agregar los archivos.' }

Write-Host 'Unicos archivos que entraran al commit:'
git diff --cached --name-status

git diff --cached --check
if ($LASTEXITCODE -ne 0) { throw 'Git encontro errores en los archivos preparados.' }

git commit -m 'Corrige notificacion de Cobranza en flujo sincrono'
if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear el commit.' }

git push origin $Rama
if ($LASTEXITCODE -ne 0) { throw 'El push fue rechazado.' }

Write-Host 'Push terminado. Solo se publicaron las tres clases de Cobranza.'
