USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

/*
  Complemento para reparar el filtro agregado por
  01_CORREGIR_BAJAS_ACTIVAS_SABANA_B3.sql.

  Ese script reemplazo una cadena presente tanto en Altas como en Bajas
  de ff_SabanaGMM_BF3. Aqui se quita EMIdEstatus = 2 SOLO de Altas.
  Bajas conserva el filtro. No toca B2, Vida, Opcionales, datos ni formato.

  Es idempotente y falla sin modificar el procedimiento si la definicion
  instalada no coincide con la estructura esperada.
*/

DECLARE @Definicion nvarchar(max) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaGMM_BF3'));
DECLARE @InicioAltas int;
DECLARE @InicioBajas int;
DECLARE @BloqueAltas nvarchar(max);
DECLARE @BloqueBajas nvarchar(max);
DECLARE @FiltroIncorrecto nvarchar(250) =
    N'WHERE CS.CSidTipoSabana = 1 AND CS.CSPestana = 1 AND EM.EMIdEstatus = 2 AND POS.POidempresa = ';
DECLARE @FiltroCorrecto nvarchar(250) =
    N'WHERE CS.CSidTipoSabana = 1 AND CS.CSPestana = 1 AND POS.POidempresa = ';
DECLARE @PosCrear int;
DECLARE @PosAlterar int;
DECLARE @DefinicionNueva nvarchar(max);
DECLARE @Aplicado bit = 0;
DECLARE @TransaccionIniciada bit = 0;

BEGIN TRY
    IF @Definicion IS NULL
        THROW 52110, 'No existe o no es legible dbo.ff_SabanaGMM_BF3.', 1;

    SET @InicioAltas = CHARINDEX(N'IF @IDESTATUS = 1', UPPER(@Definicion));
    SET @InicioBajas = CHARINDEX(N'ELSE IF @IDESTATUS=2', UPPER(@Definicion), @InicioAltas);

    IF @InicioAltas = 0 OR @InicioBajas <= @InicioAltas
        THROW 52111, 'No se pudieron delimitar las ramas de Altas y Bajas de GMM BF3.', 1;

    SET @BloqueAltas = SUBSTRING(@Definicion, @InicioAltas, @InicioBajas - @InicioAltas);
    SET @BloqueBajas = SUBSTRING(@Definicion, @InicioBajas, LEN(@Definicion));

    IF (LEN(@BloqueBajas) - LEN(REPLACE(@BloqueBajas, @FiltroIncorrecto, N''))) / LEN(@FiltroIncorrecto) <> 1
        THROW 52112, 'Bajas GMM no tiene exactamente una vez el filtro EMIdEstatus = 2 esperado.', 1;

    IF CHARINDEX(@FiltroIncorrecto, @BloqueAltas) > 0
    BEGIN
        IF (LEN(@BloqueAltas) - LEN(REPLACE(@BloqueAltas, @FiltroIncorrecto, N''))) / LEN(@FiltroIncorrecto) <> 1
            THROW 52113, 'Altas GMM tiene un numero inesperado de filtros que reparar.', 1;

        SET @BloqueAltas = REPLACE(@BloqueAltas, @FiltroIncorrecto, @FiltroCorrecto);
        SET @Definicion = STUFF(@Definicion, @InicioAltas, @InicioBajas - @InicioAltas, @BloqueAltas);

        -- ALTER PROCEDURE debe ser la primera instruccion del lote dinamico.
        SET @PosCrear = CHARINDEX(N'CREATE OR ALTER PROCEDURE', UPPER(@Definicion));
        IF @PosCrear > 0 AND @PosCrear < @InicioAltas
            SET @Definicion = STUFF(@Definicion, @PosCrear,
                LEN(N'CREATE OR ALTER PROCEDURE'), N'ALTER PROCEDURE');
        ELSE
        BEGIN
            SET @PosCrear = CHARINDEX(N'CREATE PROCEDURE', UPPER(@Definicion));
            IF @PosCrear > 0 AND @PosCrear < @InicioAltas
                SET @Definicion = STUFF(@Definicion, @PosCrear,
                    LEN(N'CREATE PROCEDURE'), N'ALTER PROCEDURE');
            ELSE
            BEGIN
                SET @PosAlterar = CHARINDEX(N'ALTER PROCEDURE', UPPER(@Definicion));
                IF @PosAlterar = 0 OR @PosAlterar >= @InicioAltas
                    THROW 52114, 'No se encontro un encabezado valido de ff_SabanaGMM_BF3.', 1;
            END;
        END;

        BEGIN TRANSACTION;
        SET @TransaccionIniciada = 1;
        EXEC sys.sp_executesql @Definicion;
        SET @Aplicado = 1;
    END
    ELSE IF CHARINDEX(@FiltroCorrecto, @BloqueAltas) = 0
        THROW 52115, 'Altas GMM no contiene ni el filtro anterior ni el esperado; no se modifico.', 1;

    SET @DefinicionNueva = OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaGMM_BF3'));
    SET @InicioAltas = CHARINDEX(N'IF @IDESTATUS = 1', UPPER(@DefinicionNueva));
    SET @InicioBajas = CHARINDEX(N'ELSE IF @IDESTATUS=2', UPPER(@DefinicionNueva), @InicioAltas);

    IF @InicioAltas = 0 OR @InicioBajas <= @InicioAltas
        THROW 52116, 'La definicion final no contiene ambas ramas de GMM.', 1;

    SET @BloqueAltas = SUBSTRING(@DefinicionNueva, @InicioAltas, @InicioBajas - @InicioAltas);
    SET @BloqueBajas = SUBSTRING(@DefinicionNueva, @InicioBajas, LEN(@DefinicionNueva));

    IF CHARINDEX(@FiltroIncorrecto, @BloqueAltas) > 0
       OR CHARINDEX(@FiltroCorrecto, @BloqueAltas) = 0
       OR CHARINDEX(@FiltroIncorrecto, @BloqueBajas) = 0
        THROW 52117, 'La validacion final de Altas/Bajas GMM no coincidio; se revierte.', 1;

    IF @TransaccionIniciada = 1 AND XACT_STATE() = 1 COMMIT TRANSACTION;

    SELECT N'OK' AS Estado,
           @Aplicado AS ProcedimientoModificado,
           N'Altas GMM sin EMIdEstatus=2; Bajas GMM conserva EMIdEstatus=2.' AS Resultado;
END TRY
BEGIN CATCH
    IF @TransaccionIniciada = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
