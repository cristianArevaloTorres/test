USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*
    DIAGNOSTICO DE SOLO LECTURA - SABANA B3 - UN SOLO RESULTSET

    Empresa:       2185 - Zurich
    Vigencia:      4067
    Periodo:       2025-10-13 a 2026-09-30
    Tipo:          altas (@IdEstatus = 1)

    USO
    1. Generar un reporte NUEVO desde el sitio.
    2. Ejecutar este archivo inmediatamente en la misma base de APIREPORTS.
    3. Exportar el unico resultset a CSV y compartirlo completo.

    No crea, modifica ni elimina informacion persistente y no ejecuta los SP
    del reporte. #Resultado y #DatosOpcionales existen solamente durante esta
    conexion y se eliminan automaticamente al terminar.
*/

DECLARE @IdEmpresa    int  = 2185,
        @IdVigencia   int  = 4067,
        @FechaIni     date = '20251013',
        @FechaFin     date = '20260930',
        @IdEstatus    int  = 1,
        @Confidencial int  = 1;

CREATE TABLE #Resultado
(
    Orden    int            NOT NULL,
    Seccion  varchar(50)    NOT NULL,
    Estado   varchar(10)    NOT NULL,
    Clave    nvarchar(250)  NOT NULL,
    Valor    nvarchar(max)  NULL,
    Detalle  nvarchar(max)  NULL
);

/* =====================================================================
   01. SERVIDOR, BASE Y PARAMETROS
   ===================================================================== */
INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
VALUES
(100,'01_CONTEXTO','INFO','Servidor',CONVERT(nvarchar(128),SERVERPROPERTY('ServerName')),
 N'Debe ser el mismo servidor configurado en APIREPORTS.'),
(101,'01_CONTEXTO','INFO','Maquina',CONVERT(nvarchar(128),SERVERPROPERTY('MachineName')),NULL),
(102,'01_CONTEXTO','INFO','Instancia',ISNULL(CONVERT(nvarchar(128),SERVERPROPERTY('InstanceName')),N'(predeterminada)'),NULL),
(103,'01_CONTEXTO','INFO','BaseDatos',DB_NAME(),N'Debe ser la misma base configurada en APIREPORTS.'),
(104,'01_CONTEXTO','INFO','Login',SUSER_SNAME(),NULL),
(105,'01_CONTEXTO','INFO','Parametros',
 CONCAT(N'Empresa=',@IdEmpresa,N'; Vigencia=',@IdVigencia,N'; Inicio=',CONVERT(char(10),@FechaIni,120),
        N'; Fin=',CONVERT(char(10),@FechaFin,120),N'; Estatus=',@IdEstatus,N'; Confidencial=',@Confidencial),NULL);

INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
SELECT 110,'01_CONTEXTO',
       CASE WHEN EXISTS(SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa=@IdEmpresa) THEN 'OK' ELSE 'ALERTA' END,
       'EmpresaExiste',
       CASE WHEN EXISTS(SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa=@IdEmpresa) THEN '1' ELSE '0' END,
       N'Debe ser 1.';

INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
SELECT 111,'01_CONTEXTO',
       CASE WHEN EXISTS(SELECT 1 FROM dbo.ff_Vigencia WHERE VIIdVigencia=@IdVigencia) THEN 'OK' ELSE 'ALERTA' END,
       'VigenciaExiste',
       CASE WHEN EXISTS(SELECT 1 FROM dbo.ff_Vigencia WHERE VIIdVigencia=@IdVigencia) THEN '1' ELSE '0' END,
       N'Debe ser 1.';

/* =====================================================================
   02. OBJETOS INSTALADOS
   ===================================================================== */
DECLARE @ObjetosEsperados TABLE
(
    Orden  int           NOT NULL,
    Objeto nvarchar(128) NOT NULL
);

INSERT @ObjetosEsperados(Orden,Objeto)
VALUES (201,N'ff_Sabana_BF3'),
       (202,N'ff_SabanaGMM_BF3'),
       (203,N'ff_SabanaVIDA_BF3'),
       (204,N'ff_SabanaOPC_BF3'),
       (205,N'ff_SabanaMascotas_BF3'),
       (206,N'ff_orquestadorReportes');

INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
SELECT E.Orden,
       '02_OBJETOS_SQL',
       CASE WHEN O.object_id IS NOT NULL THEN 'OK' ELSE 'ALERTA' END,
       E.Objeto,
       CASE WHEN O.object_id IS NULL THEN N'NO EXISTE'
            ELSE CONCAT(N'EXISTE; modificado=',CONVERT(char(19),O.modify_date,120),
                        N'; bytes=',DATALENGTH(M.definition)) END,
       N'Objeto requerido por la ruta BF3 corregida.'
FROM @ObjetosEsperados AS E
LEFT JOIN sys.objects AS O
       ON O.name=E.Objeto
      AND O.schema_id=SCHEMA_ID(N'dbo')
LEFT JOIN sys.sql_modules AS M ON M.object_id=O.object_id;

/* =====================================================================
   03. LOGICA INSTALADA EN LOS PROCEDIMIENTOS BF3
   ===================================================================== */
DECLARE @DefinicionOPC nvarchar(max)=
(
    SELECT definition
    FROM sys.sql_modules
    WHERE object_id=OBJECT_ID(N'dbo.ff_SabanaOPC_BF3')
);

DECLARE @DefNorm nvarchar(max)=UPPER(
    REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(@DefinicionOPC,N''),
        N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N''),N'[',N''));
SET @DefNorm=REPLACE(@DefNorm,N']',N'');

DECLARE @ValidaEmpresa bit=CASE WHEN @DefNorm LIKE N'%SO.SOIDEMPRESA=POS.POIDEMPRESA%' THEN 1 ELSE 0 END,
        @ValidaEstatus bit=CASE WHEN @DefNorm LIKE N'%SO.SOESTATUSSOLICITUDIN(1,3)%' THEN 1 ELSE 0 END,
        @ValidaFiltroEmpresa bit=CASE WHEN @DefNorm LIKE N'%CS.CSIDTIPOSABANA=3ANDPOIDEMPRESA=@IDEMPRESA%' THEN 1 ELSE 0 END,
        @ValidaVigencia bit=CASE WHEN @DefNorm LIKE N'%POS.POIDVIGENCIA=@IDVIGENCIA%' THEN 1 ELSE 0 END;

INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
VALUES
(301,'03_LOGICA_OPC',CASE WHEN @ValidaEmpresa=1 THEN 'OK' ELSE 'ALERTA' END,
 'UneSolicitudConEmpresa',CONVERT(varchar(1),@ValidaEmpresa),N'Debe ser 1.'),
(302,'03_LOGICA_OPC',CASE WHEN @ValidaEstatus=1 THEN 'OK' ELSE 'ALERTA' END,
 'FiltraSolicitudActiva',CONVERT(varchar(1),@ValidaEstatus),N'Debe ser 1.'),
(303,'03_LOGICA_OPC',CASE WHEN @ValidaFiltroEmpresa=1 THEN 'OK' ELSE 'ALERTA' END,
 'FiltraEmpresa',CONVERT(varchar(1),@ValidaFiltroEmpresa),N'Debe ser 1.'),
(304,'03_LOGICA_OPC',CASE WHEN @ValidaVigencia=1 THEN 'OK' ELSE 'ALERTA' END,
 'FiltraVigencia',CONVERT(varchar(1),@ValidaVigencia),N'Debe ser 1.');

DECLARE @DefinicionWrapper nvarchar(max)=
(
    SELECT definition
    FROM sys.sql_modules
    WHERE object_id=OBJECT_ID(N'dbo.ff_Sabana_BF3')
);

DECLARE @WrapperNorm nvarchar(max)=UPPER(
    REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(@DefinicionWrapper,N''),
        N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N''),N'[',N''));
SET @WrapperNorm=REPLACE(@WrapperNorm,N']',N'');

DECLARE @WrapperSoloBF3 bit=CASE
    WHEN @WrapperNorm LIKE N'%EXECDBO.FF_SABANAGMM_BF3%'
     AND @WrapperNorm LIKE N'%EXECDBO.FF_SABANAVIDA_BF3%'
     AND @WrapperNorm LIKE N'%EXECDBO.FF_SABANAOPC_BF3%'
     AND @WrapperNorm LIKE N'%EXECDBO.FF_SABANAMASCOTAS_BF3%'
     AND CHARINDEX(N'EXECDBO.FF_SABANAGMM_V2',@WrapperNorm)=0
     AND CHARINDEX(N'EXECDBO.FF_SABANAVIDA_V2',@WrapperNorm)=0
     AND CHARINDEX(N'EXECDBO.FF_SABANAOPC_V2',@WrapperNorm)=0
     AND CHARINDEX(N'EXECDBO.FF_SABANA_V2',@WrapperNorm)=0
    THEN 1 ELSE 0 END,
        @WrapperNoOcultaErrores bit=CASE
    WHEN @WrapperNorm NOT LIKE N'%BEGINCATCHENDCATCH%' THEN 1 ELSE 0 END;

INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
VALUES
(305,'03_LOGICA_OPC',CASE WHEN @WrapperSoloBF3=1 THEN 'OK' ELSE 'ALERTA' END,
 'WrapperSoloBF3',CONVERT(varchar(1),@WrapperSoloBF3),
 N'Debe llamar GMM, Vida, Opcionales y Mascotas BF3, sin dependencias _v2.'),
(306,'03_LOGICA_OPC',CASE WHEN @WrapperNoOcultaErrores=1 THEN 'OK' ELSE 'ALERTA' END,
 'WrapperNoOcultaErrores',CONVERT(varchar(1),@WrapperNoOcultaErrores),
 N'Debe ser 1; un resultset parcial no debe marcarse como exitoso.');

/* =====================================================================
   04. RUTA QUE EJECUTA EL REPORTE 3
   ===================================================================== */
INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
SELECT 400+ROW_NUMBER() OVER(ORDER BY SP.catReportesSPOrden,SP.catReportesSPId),
       '04_RUTA_REPORTE',
       CASE WHEN SP.catReportesSPNombre='ff_Sabana_BF3' AND ISNULL(SP.ESid,1)=1
            THEN 'OK'
            WHEN ISNULL(SP.ESid,1)=1 THEN 'ALERTA'
            ELSE 'INFO' END,
       CONCAT(N'catReportesSPId=',SP.catReportesSPId),
       CONCAT(N'nombre=',SP.catReportesSPNombre,N'; orden=',SP.catReportesSPOrden,N'; ESId=',SP.ESid),
       CASE WHEN SP.catReportesSPNombre='ff_Sabana_BF3' AND ISNULL(SP.ESid,1)=1
            THEN N'Ruta activa esperada.'
            WHEN ISNULL(SP.ESid,1)=1 THEN N'Ruta activa incorrecta.'
            ELSE N'Ruta inactiva.' END
FROM dbo.bf_CatReportesSP AS SP
WHERE SP.catReportesId=3;

DECLARE @RutasActivas int=(SELECT COUNT(*) FROM dbo.bf_CatReportesSP WHERE catReportesId=3 AND ISNULL(ESid,1)=1),
        @RutasCorrectas int=(SELECT COUNT(*) FROM dbo.bf_CatReportesSP WHERE catReportesId=3 AND ISNULL(ESid,1)=1 AND catReportesSPNombre='ff_Sabana_BF3');

INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
VALUES
(450,'04_RUTA_REPORTE',CASE WHEN @RutasActivas=1 AND @RutasCorrectas=1 THEN 'OK' ELSE 'ALERTA' END,
 'ResumenRuta',CONCAT(N'Activas=',@RutasActivas,N'; correctas=',@RutasCorrectas),
 N'Debe existir una sola ruta activa y debe llamarse ff_Sabana_BF3.');

/* =====================================================================
   05. PARAMETROS QUE TERMINA LEYENDO EL ORQUESTADOR
   ===================================================================== */
INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
SELECT 500+ROW_NUMBER() OVER(ORDER BY SP.catReportesSPOrden,SP.catReportesSPId,P.catReportesParamsOrden,P.catReportesParamsId),
       '05_PARAMETROS','INFO',
       CONCAT(N'SP=',SP.catReportesSPId,N'; Param=',ISNULL(P.catReportesParamsNombre,N'(sin parametro)')),
       CONCAT(N'SPActivo=',SP.ESid,N'; OrdenSP=',SP.catReportesSPOrden,
              N'; OrdenParam=',P.catReportesParamsOrden,N'; ParamActivo=',P.ESid),
       SP.catReportesSPNombre
FROM dbo.bf_CatReportesSP AS SP
LEFT JOIN dbo.bf_CatReportesParams AS P ON P.catReportesSPId=SP.catReportesSPId
WHERE SP.catReportesId=3;

;WITH RutaActiva AS
(
    SELECT TOP(1) catReportesSPOrden
    FROM dbo.bf_CatReportesSP
    WHERE catReportesId=3 AND ISNULL(ESid,1)=1
    ORDER BY catReportesSPOrden,catReportesSPId
),
ParametrosEfectivos AS
(
    /* Replica la seleccion de parametros de ff_orquestadorReportes. */
    SELECT UPPER(LTRIM(RTRIM(P.catReportesParamsNombre))) AS Parametro
    FROM dbo.bf_CatReportesParams AS P
    INNER JOIN dbo.bf_CatReportesSP AS SP ON SP.catReportesSPId=P.catReportesSPId
    INNER JOIN RutaActiva AS R ON R.catReportesSPOrden=SP.catReportesSPOrden
    WHERE SP.catReportesId=3
),
Duplicados AS
(
    SELECT Parametro,COUNT(*) AS Cantidad
    FROM ParametrosEfectivos
    GROUP BY Parametro
    HAVING COUNT(*)>1
)
INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
SELECT 590+ROW_NUMBER() OVER(ORDER BY Parametro),
       '05_PARAMETROS','ALERTA',Parametro,CONVERT(varchar(20),Cantidad),
       N'El orquestador enviaria este argumento mas de una vez.'
FROM Duplicados;

IF NOT EXISTS(SELECT 1 FROM #Resultado WHERE Seccion='05_PARAMETROS' AND Estado='ALERTA')
    INSERT #Resultado VALUES(599,'05_PARAMETROS','OK','ParametrosDuplicados','0',N'Debe ser 0.');

/* =====================================================================
   06 Y 07. CONTEOS Y FILAS RECHAZADAS EN LOS DATOS FUENTE
   ===================================================================== */
SELECT DISTINCT
       CS.CSAlias AS Hoja,
       POS.POIdSolicitud,
       POS.POIdEmpleado,
       POS.POIdPlanOpcion,
       POS.POIdGrupoParentesco,
       POS.POIdEstatus,
       SO.SONumeroSolicitud,
       SO.SOIdEmpresa,
       SO.SOIdEstatus,
       SO.SOEstatusSolicitud,
       EM.EMIdSalarioConfidencial,
       EM.EMNumeroEmpleado,
       EM.EMNombre1,
       EM.EMNombre2,
       EM.EMApellidoPaterno,
       EM.EMApellidoMaterno
INTO #DatosOpcionales
FROM dbo.ff_PlanOpcionSeleccion AS POS
INNER JOIN dbo.ff_PlanOpcion AS PO
        ON PO.POIdPlanOpcion=POS.POIdPlanOpcion
       AND POS.POIdEstatus IN(1,3,10)
INNER JOIN dbo.ff_Empleado AS EM ON EM.Id=POS.POIdEmpleado
INNER JOIN dbo.ff_ConfiguracionSabana AS CS ON CS.CSIdPlanOpcion=POS.POIdPlanOpcion
INNER JOIN dbo.ff_Solicitud AS SO
        ON SO.SOIdSolicitud=POS.POIdSolicitud
       AND SO.SOIdEmpresa=POS.POIdEmpresa
       AND SO.SOIdEstatus IN(1,3,10)
WHERE CS.CSIdEstatus=1
  AND CS.CSIdTipoSabana=3
  AND POS.POIdEmpresa=@IdEmpresa
  AND POS.POIdVigencia=@IdVigencia
  AND ISNULL(SO.SOFechaAprovacion,@FechaFin)>=@FechaIni
  AND ISNULL(SO.SOFechaAprovacion,@FechaFin)<=@FechaFin
  AND EM.EMNumeroEmpleado NOT LIKE 'test%';

;WITH Conteos AS
(
    SELECT Hoja,
           COUNT(*) AS AnteriorB3,
           SUM(CASE WHEN SOEstatusSolicitud IN(1,3) THEN 1 ELSE 0 END) AS CorregidoTodos,
           SUM(CASE WHEN SOEstatusSolicitud IN(1,3)
                         AND (@Confidencial=1 OR ISNULL(EMIdSalarioConfidencial,0)=0)
                    THEN 1 ELSE 0 END) AS CorregidoSegunConfidencial,
           SUM(CASE WHEN SOEstatusSolicitud NOT IN(1,3) OR SOEstatusSolicitud IS NULL
                    THEN 1 ELSE 0 END) AS Excluidos
    FROM #DatosOpcionales
    WHERE UPPER(Hoja) LIKE N'%GASTOS FUNER%'
       OR UPPER(Hoja) LIKE N'%PLAN DE PENSI%'
    GROUP BY Hoja
)
INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
SELECT 600+ROW_NUMBER() OVER(ORDER BY Hoja),
       '06_CONTEOS_FUENTE',
       CASE WHEN (UPPER(Hoja) LIKE N'%GASTOS FUNER%' AND CorregidoTodos=215)
                  OR (UPPER(Hoja) LIKE N'%PLAN DE PENSI%' AND CorregidoTodos=255)
            THEN 'OK' ELSE 'ALERTA' END,
       Hoja,
       CONCAT(N'AnteriorB3=',AnteriorB3,N'; CorregidoTodos=',CorregidoTodos,
              N'; CorregidoSegunConfidencial=',CorregidoSegunConfidencial,N'; Excluidos=',Excluidos),
       N'Con la extraccion recibida se esperan 215 en Gastos Funerarios y 255 en Plan de Pension.'
FROM Conteos;

INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
SELECT 700+ROW_NUMBER() OVER(ORDER BY Hoja,POIdSolicitud,POIdEmpleado),
       '07_FILAS_RECHAZADAS','INFO',
       CONCAT(Hoja,N'; Solicitud=',POIdSolicitud,N'; Empleado=',POIdEmpleado),
       CONCAT(N'NumeroSolicitud=',SONumeroSolicitud,N'; SOEstatusSolicitud=',SOEstatusSolicitud,
              N'; PlanOpcion=',POIdPlanOpcion,N'; NumeroEmpleado=',EMNumeroEmpleado),
       LTRIM(RTRIM(CONCAT(ISNULL(EMNombre1,N''),N' ',ISNULL(EMNombre2,N''),N' ',
                          ISNULL(EMApellidoPaterno,N''),N' ',ISNULL(EMApellidoMaterno,N''))))
FROM #DatosOpcionales
WHERE (UPPER(Hoja) LIKE N'%GASTOS FUNER%' OR UPPER(Hoja) LIKE N'%PLAN DE PENSI%')
  AND (SOEstatusSolicitud NOT IN(1,3) OR SOEstatusSolicitud IS NULL);

DECLARE @FilasRechazadas int=
(
    SELECT COUNT(*)
    FROM #DatosOpcionales
    WHERE (UPPER(Hoja) LIKE N'%GASTOS FUNER%' OR UPPER(Hoja) LIKE N'%PLAN DE PENSI%')
      AND (SOEstatusSolicitud NOT IN(1,3) OR SOEstatusSolicitud IS NULL)
);

INSERT #Resultado VALUES
(750,'07_FILAS_RECHAZADAS',CASE WHEN @FilasRechazadas=3 THEN 'OK' ELSE 'ALERTA' END,
 'TotalFilasQueNoDebenSalir',CONVERT(varchar(20),@FilasRechazadas),
 N'Con la extraccion recibida se esperan tres: dos de Gastos Funerarios y una de Pension.');

/* =====================================================================
   08. ULTIMA EJECUCION OBSERVABLE EN LA CACHE DE SQL SERVER
   ===================================================================== */
IF HAS_PERMS_BY_NAME(NULL,NULL,'VIEW SERVER STATE')=1
BEGIN
    INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
    SELECT 800+ROW_NUMBER() OVER(ORDER BY P.name),
           '08_ULTIMA_EJECUCION','INFO',P.name,
           ISNULL(CONVERT(char(23),PS.last_execution_time,121),N'(sin dato en cache)'),
           CASE WHEN PS.execution_count IS NULL THEN N'La cache puede haberse limpiado.'
                ELSE CONCAT(N'EjecucionesEnCache=',PS.execution_count,
                            N'; UltimaDuracionMicrosegundos=',PS.last_elapsed_time) END
    FROM sys.procedures AS P
    LEFT JOIN sys.dm_exec_procedure_stats AS PS
           ON PS.object_id=P.object_id AND PS.database_id=DB_ID()
    WHERE P.schema_id=SCHEMA_ID(N'dbo')
      AND P.name IN(N'ff_orquestadorReportes',N'ff_Sabana_BF3',N'ff_SabanaGMM_BF3',
                    N'ff_SabanaVIDA_BF3',N'ff_SabanaOPC_BF3',N'ff_SabanaMascotas_BF3');
END
ELSE
    INSERT #Resultado VALUES
    (899,'08_ULTIMA_EJECUCION','INFO','Permiso','SIN VIEW SERVER STATE',
     N'La falta de este permiso no invalida las demas secciones.');

/* =====================================================================
   09. INICIOS RECIENTES DE ff_SabanaOPC_BF3 PARA LA EMPRESA
   Si no hay una fila posterior al reporte nuevo, el sitio uso otro SP/base.
   ===================================================================== */
IF OBJECT_ID(N'dbo.bf_RepConf_Debug',N'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        INSERT #Resultado(Orden,Seccion,Estado,Clave,Valor,Detalle)
        SELECT 900+ROW_NUMBER() OVER(ORDER BY id DESC),
               ''09_TRAZA_SITIO'',''INFO'',CONCAT(''opc_bf3_inicio id='',id),
               CONVERT(char(23),fecha,121),detalle
        FROM
        (
            SELECT TOP(20) id,fecha,detalle
            FROM dbo.bf_RepConf_Debug WITH(NOLOCK)
            WHERE etapa=''opc_bf3_inicio''
              AND detalle LIKE ''idEmpresa=''+CONVERT(varchar(20),@Empresa)+'' %''
            ORDER BY id DESC
        ) AS T;',
        N'@Empresa int',@Empresa=@IdEmpresa;

    IF NOT EXISTS(SELECT 1 FROM #Resultado WHERE Seccion='09_TRAZA_SITIO')
        INSERT #Resultado VALUES
        (999,'09_TRAZA_SITIO','ALERTA','SinEjecucionOPCBF3','0',
         N'Si ya se genero el reporte, el sitio no llamo ff_SabanaOPC_BF3 o usa otra base.');
END
ELSE
    INSERT #Resultado VALUES
    (999,'09_TRAZA_SITIO','ALERTA','TablaDebug','NO EXISTE',
     N'No se puede confirmar desde esta base si el sitio ejecuto ff_SabanaOPC_BF3.');

/* =====================================================================
   10. UNICO RESULTSET: EXPORTAR ESTA TABLA COMPLETA A UN SOLO CSV
   ===================================================================== */
INSERT #Resultado VALUES
(1000,'10_LECTURA','INFO','Instruccion',N'Exportar este unico resultset completo.',
 N'Una ALERTA identifica la seccion que explica por que el sitio sigue diferente.');

SELECT Seccion,
       Estado,
       Clave,
       Valor,
       Detalle
FROM #Resultado
ORDER BY Orden,Seccion,Clave;
GO
