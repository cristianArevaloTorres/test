USE [FlexiForbesv2]
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
    Homologacion B3 con B2 (B2 es solo referencia y no se modifica):
    - Este instalador solo crea o altera procedimientos con sufijo _BF3.
      Los procedimientos _v2 pertenecen a la ruta legacy y quedan intactos.
    - Vida entrega una fila por empleado, aun cuando tenga cobertura adicional.
    - Opcionales descarta solicitudes rechazadas/canceladas.
    - Mascotas vuelve a emitirse como cuarto resultset y acepta que idPlan
      contenga tanto el plan como la opcion de plan, segun el ambiente.
    - La configuracion global de la hoja Mascotas queda instalada de forma
      idempotente para no depender del estado previo de cada base.
*/

-- =============================================================================
-- SCRIPT 1: ff_SabanaGMM_BF3
-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_SabanaGMM_BF3] (
@idEmpresa int,
@FechaIni varchar(20),
@FechaFin varchar(20),
@idEstatus int,
@idVigencia int,
@Confidencial INT = 0)
AS
BEGIN

DECLARE @IDConfiguracion INT
SET @IDConfiguracion = ISNULL((Select EMidConfiguracion FROM ff_Empresa where EMidEmpresa = @idEmpresa),0)

DECLARE @Kueri as Varchar(max)
DECLARE @KueriII as Varchar(max)

SET @FechaFin = @FechaFin

DECLARE @SOIdEstatus int

SELECT @SOIdEstatus= CASE WHEN EXISTS (select 'k' from ff_Vigencia v2 where v2.VIRenovada= v1.VIidVigencia) THEN 10
        WHEN VIidEstatus not in (1,6) THEN 10  ELSE 1 END
  FROM  ff_Vigencia v1 INNER JOIN ff_Empresa WITH (NOLOCK) ON VIidConfiguracion=EMidConfiguracion
  WHERE EMidEmpresa = @idEmpresa
    AND VIidVigencia = @idVigencia
    AND VITipoNegocio = 1


IF @idEstatus = 1
BEGIN

SET @Kueri = 'SELECT   ''GMM'' as grupo, CS.CSAlias AS NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, EM.EMidParentesco, PA.PADescripcion ,PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre,
RTRIM(EM.EMNumeroEmpleado) as EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
ISNULL(EM.EMNombre1,'+ char(39) + ' '+ char(39) + ') + SPACE(1) + ISNULL(EM.EMNombre2,'+ char(39) + ' '+ char(39) + ') as Nombres ,
convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,  convert(char(10),EM.EMFechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
convert(char(10),ISNULL(EM.EMFechaAlta,EM.EMFechaIngresoEmpresa), 103) AS EMFechaAlta,
SO.SONumeroSolicitud, SE.SEDescripcion, ISNULL(GPDescripcion, PA.PADescripcion) AS GPDescripcion, EMedad, EM.EMIdParentesco AS EMIdParentesco1, EMOFicina,
(Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='+ CHAR(39)+'EMOFICINA'+CHAR(39)
+ 'AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as '+CHAR(39)+'Oficina' + CHAR(39)+',RTRIM(EMRFC) as RFC,
Perfil=(select pedescripcion from ff_perfil where peidperfil=em.emidperfil),
isnull(emCalleFiscal,'''') as Calle,isnull(EMColoniaFisico,'''') as NumExt,isnull(EMCalleFisico,'''') as NumInt,isnull(emColoniaFiscal,'''') as Colonia,
 isnull(EMMunicipioDelegacionFiscal,'''') as Del_Municipio,
 EstadoFiscal = (Select esDescripcion from ff_Estado where esidEstado = emEstadofiscal),
 isnull(''''+emcodigoPostalFiscal,'''') as CP,
GMM_ANT= ISNULL((select TOP 1 RTRIM(CDPlanOpcion) from ff_cobranzaDetallada col WHERE CDMES=9 and CDA'+CHAR(241)+'o=2015 AND col.cdidplan in(140,141,162,170,51,52)
and col.CDNumeroEmpleado=POS.PONumeroEmpleado AND POS.poIDEmpresa=col.cdIdEmpresa and col.cdidempleado=POS.Poidempleado),''NUEVO''),
Exceso_ante= ISNULL((select TOP 1 RTRIM(CDPlanOpcion) from ff_cobranzaDetallada col WHERE CDMES=9 and CDA'+CHAR(241)+'o=2015 AND col.cdidplan in(146,163,168,169,54,53)
and col.CDNumeroEmpleado=POS.PONumeroEmpleado AND POS.poIDEmpresa=col.cdIdEmpresa  and col.cdidempleado=POS.Poidempleado),''NUEVO'' ),
PrimeNeta=
CASE WHEN  EMIdParentesco= 1 AND POS.POIDGrupoParentesco IS NOT NULL  THEN
  ( SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103) from ff_TarifaCosto ppp WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion )
  WHEN  POS.POIDGrupoParentesco IS NULL  THEN
  ISNULL((SELECT CONVERT(CHAR(20),TPPrimaNeta,103) FROM ff_tarifaCostoPerfil WHERE TPidplanopcion=POS.POIDPlanOpcion and TPIdPerfil=em.emidperfil AND TPIdEstatus=1 ),
     (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103) from '+(case when @SOIdEstatus=1 then 'ff_TarifaCosto' else 'ff_TarifaCosto_hist'end)+' ppp
      WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion ) ) ELSE '+CHAR(39)+CHAR(39)+' END,
Costo=
CASE WHEN  EMIdParentesco= 1 AND POS.POIDGrupoParentesco IS NOT NULL THEN
  (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103) from ff_PlanOpcionSeleccion ppp WHERE ppp.PONumeroEmpleado=EM.EMNumeroEmpleado and ppp.POIdPlanOpcion=POS.POIdPlanOpcion
  and ppp.POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID )
  WHEN  POS.POIDGrupoParentesco IS NULL  THEN
  (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103) from ff_PlanOpcionSeleccion ppp WHERE ppp.PONumeroEmpleado=EM.EMNumeroEmpleado and ppp.POIdPlanOpcion=POS.POIdPlanOpcion
  and ppp.POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID )
  ELSE '+CHAR(39)+CHAR(39)+' END'

-- flujo aislado: sin csidvigencia=@idVigencia en el loop de columnas
SELECT @Kueri = @Kueri + ', (SELECT case count(*) when 1 then CONVERT(CHAR(20),SUM(POCostoRestante),103) else '+ char(39) + 'NO'+ char(39) + ' end
from ff_PlanOpcionSeleccion WHERE POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID and POidplanopcion= ' +  cast(CSidplanopcion as varchar(5))  + ' ) as ' + char(39) +  CSalias + char(39) + char(13)
FROM dbo.ff_ConfiguracionSabana  WITH (NOLOCK,READUNCOMMITTED)
where CSidConfiguracion = @IDConfiguracion AND CSIDTiposabana = 1 AND CSPestana = 0 AND CSIDESTATUS = 1
AND CSIdPlanOpcion in (
    SELECT ppidplanOpcion FROM ff_Perfil INNER JOIN ff_PlanOpcionPerfil ON PPidPErfil=PEIdPerfil AND PEAdministrador=0
    WHERE PEIdestatus=1 and PPidestatus=1 AND PEIdEmpresa=@idEmpresa
)
order by CSidplan

SELECT @KueriII = ' , EM.ID as IDEmp,INFO=RTRIM(ISNULL(Desarrollo,'''')),EMArea,EMIdCentroCostos,EMArchivoInformacion as Ubicacion
FROM dbo.ff_PlanOpcionSeleccion POS  WITH (NOLOCK)
INNER JOIN dbo.ff_PlanOpcion PO WITH (NOLOCK) ON POS.poidplanopcion =  PO.POidplanopcion
INNER JOIN dbo.ff_Plan PL WITH (NOLOCK) ON PL.plidplan =  PO.POidplan
INNER JOIN dbo.ff_Empleado EM WITH (NOLOCK) ON EM.ID = POS.poidempleado AND EM.EMNumeroEmpleado not like ''Test%''
INNER JOIN dbo.ff_Parentesco PA WITH (NOLOCK) ON PA.PAidparentesco = EM.EMidparentesco
LEFT OUTER JOIN dbo.ff_GrupoParentesco GP WITH (NOLOCK) ON GP.gpidgrupoparentesco = POS.poidgrupoparentesco
INNER JOIN dbo.ff_ConfiguracionSabana CS WITH (NOLOCK) ON CS.CSidPlanOpcion = POS.POidplanopcion AND CS.CSIdConfiguracion='
+LTRIM(CAST(@IDConfiguracion as varchar(10))) +'
INNER JOIN dbo.ff_Solicitud SO WITH (NOLOCK) ON SO.SOidSolicitud = POS.POidSolicitud
INNER JOIN dbo.ff_Sexo SE WITH (NOLOCK) ON EM.EMidsexo = SE.SEidSexo
WHERE CS.CSidTipoSabana = 1 AND CS.CSPestana = 1 AND POS.POidempresa = '+ cast(@idEmpresa as varchar(30))
+ ' AND POS.POidEstatus in (1, 3, 10) '
+ ' AND SO.SOEstatusSolicitud in (1,3) '
+ 'AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date) ) >= '''+@FechaIni+''' AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= '''+@FechaFin+'''
AND POS.POidvigencia = '+ cast(@idVigencia as varchar(30))
+ ' AND (1=' + cast(@Confidencial as varchar(1)) + ' OR EM.EMidSalarioConfidencial=0)'
+ ' ORDER BY CS.CSidPlan, PO.POOrden, CS.CSidPlanOpcion, EM.EMOFicina,EM.EMNumeroEmpleado, EM.EmidParentesco'

print @Kueri + @KueriII
execute(@Kueri + @KueriII)
END

ELSE IF @idEstatus=2
BEGIN

SET @Kueri = 'SELECT ''GMM'' as grupo, CS.CSAlias AS NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, PA.PADescripcion ,PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre,
RTRIM(EM.EMNumeroEmpleado) as EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
ISNULL(EM.EMNombre1,'+ char(39) + ' '+ char(39) + ') + SPACE(1) + ISNULL(EM.EMNombre2,'+ char(39) + ' '+ char(39) + ') as Nombres ,EM.EMIdParentesco,
convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
convert(char(10),EM.EMFechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
convert(char(10),ISNULL(EM.EMFechaBaja,GETDATE()), 103) AS EMFechaAlta,
 SO.SONumeroSolicitud, SE.SEDescripcion, ISNULL(GPDescripcion, PA.PADescripcion) AS GPDescripcion, EMedad, EM.EMIdParentesco AS EMIdParentesco1, EMOFicina,
(Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
 AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='+ CHAR(39)+'EMOFICINA'+CHAR(39)+ 'AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa))
  as '+CHAR(39)+'Oficina' + CHAR(39)+',RTRIM(EMRFC) as RFC,
 Perfil=(select pedescripcion from ff_perfil where peidperfil=em.emidperfil),
 isnull(emCalleFiscal,'''') as Calle,isnull(EMColoniaFisico,'''') as NumExt,isnull(EMCalleFisico,'''') as NumInt,isnull(emColoniaFiscal,'''') as Colonia,
 isnull(EMMunicipioDelegacionFiscal,'''') as Del_Municipio,
 EstadoFiscal = (Select esDescripcion from ff_Estado where esidEstado = emEstadofiscal),
 isnull(''''+emcodigoPostalFiscal,'''') as CP,
CONVERT(char(10),EMFechaBaja,103) as FechaBaja,
PrimeNeta=
CASE WHEN  EMIdParentesco= 1 AND POS.POIDGrupoParentesco IS NOT NULL  THEN
  (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103)  from '+(case when @SOIdEstatus=1 then 'ff_TarifaCosto' else 'ff_TarifaCosto_hist'end)+' ppp
  WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion )
 WHEN  POS.POIDGrupoParentesco IS NULL  THEN
  (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103)  from '+(case when @SOIdEstatus=1 then 'ff_TarifaCosto' else 'ff_TarifaCosto_hist'end)+' ppp WHERE
  ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion )
 ELSE '+CHAR(39)+CHAR(39)+' END,
Costo=
CASE WHEN  EMIdParentesco= 1 AND POS.POIDGrupoParentesco IS NOT NULL
 THEN (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103)  from ff_PlanOpcionSeleccion ppp WHERE ppp.PONumeroEmpleado=EM.EMNumeroEmpleado and ppp.POIdPlanOpcion=POS.POIdPlanOpcion
   and ppp.POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID )
 WHEN  POS.POIDGrupoParentesco IS NULL
 THEN (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103)  from ff_PlanOpcionSeleccion ppp WHERE ppp.PONumeroEmpleado=EM.EMNumeroEmpleado and ppp.POIdPlanOpcion=POS.POIdPlanOpcion
 and ppp.POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID )
 ELSE '+CHAR(39)+CHAR(39)+' END'

SELECT @Kueri = @Kueri + ', (SELECT case count(*) when 1 then CONVERT(CHAR(20),SUM(POCostoRestante),103) else '+ char(39) + 'NO'+ char(39) + ' end
 from ff_PlanOpcionSeleccion WHERE POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID and POidplanopcion= ' +  cast(CSidplanopcion as varchar(5))  + ' )
  as ' + char(39) + CSalias + char(39) + char(13) from (
    select distinct CSalias, CSidplanopcion, CSidplan
    FROM dbo.ff_ConfiguracionSabana  WITH (NOLOCK,READUNCOMMITTED)
    where CSidConfiguracion = @IDConfiguracion AND CSIDTiposabana = 1 AND CSPestana = 0 AND CSIDESTATUS = 1
    AND CSIdPlanOpcion in(SELECT ppidplanOpcion FROM ff_Perfil INNER JOIN ff_PlanOpcionPerfil ON PPidPErfil=PEIdPerfil AND PEAdministrador=0 WHERE PEIdestatus=1 and PPidestatus=1 AND PEIdEmpresa=@idEmpresa)
) info order by CSidplan

SELECT @KueriII = ' , EM.ID as IDEmp,INFO=RTRIM(ISNULL(Desarrollo,'''')),EMArea,EMIdCentroCostos,EMArchivoInformacion as Ubicacion
INTO #Registros FROM dbo.ff_PlanOpcionSeleccion POS  WITH (NOLOCK)
INNER JOIN dbo.ff_PlanOpcion PO WITH (NOLOCK) ON POS.poidplanopcion =  PO.POidplanopcion
INNER JOIN dbo.ff_Plan PL WITH (NOLOCK) ON PL.plidplan =  PO.POidplan
INNER JOIN dbo.ff_Empleado EM WITH (NOLOCK) ON EM.ID = POS.poidempleado AND EM.EMNumeroEmpleado not like ''Test%''
INNER JOIN dbo.ff_Parentesco PA WITH (NOLOCK) ON PA.PAidparentesco = EM.EMidparentesco
LEFT OUTER JOIN dbo.ff_GrupoParentesco GP WITH (NOLOCK) ON GP.gpidgrupoparentesco = POS.poidgrupoparentesco
INNER JOIN dbo.ff_ConfiguracionSabana CS WITH (NOLOCK) ON CS.CSidPlanOpcion = POS.POidplanopcion AND CS.CSIdConfiguracion='
+LTRIM(CAST(@IDConfiguracion as varchar(10))) +'
INNER JOIN dbo.ff_Solicitud SO WITH (NOLOCK) ON SO.SOidSolicitud = POS.POidSolicitud
INNER JOIN dbo.ff_Sexo SE WITH (NOLOCK) ON EM.EMidsexo = SE.SEidSexo
WHERE CS.CSidTipoSabana = 1 AND CS.CSPestana = 1 AND POS.POidempresa = '+ cast(@idEmpresa as varchar(30)) + '
AND POS.POidEstatus in(4,5) AND SO.SOEstatusSolicitud in(4,5) AND POS.POidvigencia = '+ cast(@idVigencia as varchar(30))
+ ' AND (SOFechaEstatus >= '+ char(39) + cast(@FechaIni as varchar(10)) + char(39) +' OR EM.EMFechaDel >= '+ char(39) + cast(@FechaIni as varchar(10))+ char(39) +') '
+ ' AND (SOFechaEstatus <= '+ char(39) + cast(@FechaFin as varchar(10)) + char(39) +' OR EM.EMFechaDel <= '+ char(39) + cast(@FechaFin as varchar(10))+ char(39) +') '
+ ' AND Convert(varchar(10),POS.poidempleado,103)+''-''+convert(varchar(10),POS.PoidplanOpcion,103) not in (Select Convert(varchar(10),poidempleado,103)+''-''+convert(varchar(10),PoidplanOpcion,103) from ff_Planopcionseleccion WHERE POIdEstatus=1 AND POidVigencia ='+ cast(@idVigencia as varchar(30))
+ ' AND PONumeroempleado = EM.EMNumeroEmpleado )'
+ ' ORDER BY CS.CSidPlan, PO.POOrden, CS.CSidPlanOpcion, EM.EMOFicina,EM.EMNumeroEmpleado, EM.EmidParentesco
SELECT DISTINCT * FROM #Registros '

print @Kueri + @KueriII
execute(@Kueri + @KueriII)

END
END
GO

-- =============================================================================
-- SCRIPT 2: ff_SabanaVIDA_BF3
-- Logica B2 homologada dentro de la ruta propia de B3.
-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_SabanaVIDA_BF3](
@idEmpresa int,
@FechaIni varchar(20),
@FechaFin varchar(20),
@idEstatus int,
@idVigencia int,
@Confidencial INT = 0)
AS
BEGIN
DECLARE @KueriI  Varchar(MAX)
DECLARE @KueriII  Varchar(MAX)
DECLARE @KueriIII  Varchar(MAX)
declare @Registros int, @i int

SET @FechaFin = @FechaFin

DECLARE @SOIdEstatus int
SELECT @SOIdEstatus= CASE WHEN EXISTS (select 'k' from ff_Vigencia v2 where v2.VIRenovada= v1.VIidVigencia) THEN 10
        WHEN VIidEstatus not in (1,6) THEN 10  ELSE 1 END
  FROM  ff_Vigencia v1 INNER JOIN ff_Empresa WITH (NOLOCK) ON VIidConfiguracion=EMidConfiguracion
  WHERE EMidEmpresa = @idEmpresa AND VIidVigencia = @idVigencia AND VITipoNegocio = 1

SELECT DISTINCT top 0 cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion , PLNombre,
 RTRIM(EM.EMNumeroEmpleado) as EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
 RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
 ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres ,EM.EMIdParentesco,
 convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
 convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa ,
 case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM( coalesce(TCPrimaNeta,0)),103) from  ff_TarifaCosto ppp
          WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else
        (SELECT CONVERT(CHAR(20),SUM( coalesce(TCPrimaNeta,0)),103) from  ff_TarifaCosto_hist ppp
         WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
         and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
 CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
 SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad,EMOficina,EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
 (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
  AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
 EMArea,EMIdCentroCostos,EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC,POS.POIDVigencia,SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
 isnull(emCalleFiscal,'') as Calle,isnull(EMColoniaFisico,'') as NumExt,isnull(EMCalleFisico,'') as NumInt,isnull(emColoniaFiscal,'') as Colonia,
 isnull(EMMunicipioDelegacionFiscal,'') as Del_Municipio,
 EstadoFiscal = (Select esDescripcion from ff_Estado where esidEstado = emEstadofiscal),
 isnull(''+emcodigoPostalFiscal,'') as CP
 INTO dbo.#PlanesSabanaVida
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion = PO.POidplanopcion AND POS.POIdEstatus in(1, 3, 10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan = PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID = POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco = EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion = POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud = POS.POidSolicitud
    and case when @idEstatus=1 and SOIDEstatus in(1, 3, 10) then 1
             when @idEstatus=2 and SOIDEstatus in(0,1,4,5)  then 1 else 0 end = 1
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo = SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana = 2 and CSPestana=0 AND poidempresa = @idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= @FechaFin
 AND case when @idEstatus=1 and POS.POidEstatus in (1, 3, 10) then 1
          when @idEstatus=2 and POS.POidEstatus in (4, 5)     then 1 else 0 end = 1
 AND POS.POidvigencia = @idVigencia AND EM.EMNumeroEmpleado not like 'test%'


IF @idEstatus = 1
BEGIN
 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,PADescripcion,PLNombre,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  Nombres,EMIdParentesco,EMFechaNacimiento,EMFechaIngresoEmpresa,PrimaNeta,Costo,
  SONumeroSolicitud,EMSalarioBase,SEDescripcion,EMEdad,EMOficina,ID,INFO,Oficina,EMArea,EMIdCentroCostos,Ubicacion,RFC,POIDVigencia,POIdSolicitud,Perfil,
  Calle,NumExt,NumInt,Colonia,Del_Municipio,EstadoFiscal,CP)
 SELECT DISTINCT cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion, PLNombre,
  RTRIM(EM.EMNumeroEmpleado), EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
  RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
  ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres, EM.EMIdParentesco,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
  SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad, EMOficina, EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
  (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  EMArea, EMIdCentroCostos, EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC, POS.POIDVigencia, SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(EMMunicipioDelegacionFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus in (1,3,10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud
  AND SO.SOIdEmpresa=POS.POidEmpresa and SOIDEstatus in(1,3,10)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana=2 and CSPestana=0 AND poidempresa=@idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidEstatus in (1,3,10)
 AND SO.SOEstatusSolicitud in (1,3)
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 AND (@Confidencial = 1 OR EM.EMidSalarioConfidencial = 0)
 AND 1=0 -- Flujo redundante: la segunda insercion consolida Vida como legacy.

 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,PADescripcion,PLNombre,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  Nombres,EMIdParentesco,EMFechaNacimiento,EMFechaIngresoEmpresa,PrimaNeta,Costo,
  SONumeroSolicitud,EMSalarioBase,SEDescripcion,EMEdad,EMOficina,ID,INFO,Oficina,EMArea,EMIdCentroCostos,Ubicacion,RFC,POIDVigencia,POIdSolicitud,Perfil,
  Calle,NumExt,NumInt,Colonia,Del_Municipio,EstadoFiscal,CP)
 SELECT DISTINCT 'VIDA' as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion, PLNombre,
  RTRIM(EM.EMNumeroEmpleado), EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
  RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
  ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres, EM.EMIdParentesco,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
  SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad, EMOficina, EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
  (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  EMArea, EMIdCentroCostos, EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC, POS.POIDVigencia, SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(EMMunicipioDelegacionFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus in (1,3,10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud
  AND SO.SOIdEmpresa=POS.POidEmpresa and SOIDEstatus in(1,3,10)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana=2 and CSPestana=0 AND poidempresa=@idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidEstatus in (1,3,10)
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 AND (@Confidencial = 1 OR EM.EMidSalarioConfidencial = 0)

END
ELSE IF @idEstatus=2
BEGIN
 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,PADescripcion,PLNombre,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  Nombres,EMIdParentesco,EMFechaNacimiento,EMFechaIngresoEmpresa,PrimaNeta,Costo,
  SONumeroSolicitud,EMSalarioBase,SEDescripcion,EMEdad,EMOficina,ID,INFO,Oficina,EMArea,EMIdCentroCostos,Ubicacion,RFC,POIDVigencia,POIdSolicitud,Perfil,
  Calle,NumExt,NumInt,Colonia,Del_Municipio,EstadoFiscal,CP)
 SELECT DISTINCT cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion, PLNombre,
  RTRIM(EM.EMNumeroEmpleado), EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
  RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
  ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres, EM.EMIdParentesco,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
  SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad, EMOficina, EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
  (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  EMArea, EMIdCentroCostos, EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC, POS.POIDVigencia, SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(EMMunicipioDelegacionFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus IN(4,5,0)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(0,1,4,5)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND CS.CSidTipoSabana=2 AND poidempresa=@idEmpresa
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 AND 1=0 -- Flujo redundante: la segunda insercion consolida Vida como legacy.

 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,PADescripcion,PLNombre,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  Nombres,EMIdParentesco,EMFechaNacimiento,EMFechaIngresoEmpresa,PrimaNeta,Costo,
  SONumeroSolicitud,EMSalarioBase,SEDescripcion,EMEdad,EMOficina,ID,INFO,Oficina,EMArea,EMIdCentroCostos,Ubicacion,RFC,POIDVigencia,POIdSolicitud,Perfil,
  Calle,NumExt,NumInt,Colonia,Del_Municipio,EstadoFiscal,CP)
 SELECT DISTINCT 'VIDA' as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion, PLNombre,
  RTRIM(EM.EMNumeroEmpleado), EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
  RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
  ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres, EM.EMIdParentesco,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
  SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad, EMOficina, EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
  (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  EMArea, EMIdCentroCostos, EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC, POS.POIDVigencia, SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(EMMunicipioDelegacionFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus IN(4,5,0)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(0,1,4,5)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND CS.CSidTipoSabana=2 AND poidempresa=@idEmpresa
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
END

-- B2 consolida todas las coberturas de Vida en una fila por beneficiario.
-- PLNombre es constante y los costos base no forman parte de este resultset;
-- incluirlos hacia que DISTINCT conservara una fila por cobertura (1271 en
-- lugar de 1115 para Zurich).
SELECT @KueriI = 'SELECT DISTINCT ''Vida'' as grupo, ''VIDA'' as NombrePestana, P.TipoSabana, P.PADescripcion, ''Vida'' as PLNombre,
P.EMNumeroEmpleado, P.EMCertificado, P.EMApellidoPaterno, P.EMApellidoMaterno, P.EMNombre1, P.EMNombre2, P.Nombres, P.EMIdParentesco, P.EMFechaNacimiento, Perfil,
P.EMFechaIngresoEmpresa, P.SONumeroSolicitud, P.EMSalarioBase, P.SEDescripcion, P.EMEdad, P.EMOficina, P.Oficina, P.Ubicacion, P.RFC, Id as Idemp, INFO '

-- flujo aislado: sin csidvigencia=@idVigencia en #Configuracion
SELECT 0 as Consecutivo, 0 as AliasConsecutivo,*
INTO #Configuracion
FROM dbo.ff_ConfiguracionSabana WITH (READUNCOMMITTED,NOLOCK)
where CSIdEstatus=1
  AND CSidConfiguracion = (Select EMidConfiguracion FROM ff_Empresa where EMidEmpresa = @idEmpresa)
  and CSIDTiposabana = 2 AND CSPestana = 0
order by CSidplan

SET @Registros = (SELECT COUNT(consecutivo) from #Configuracion)
SET @i=1
While @i<=@Registros
BEGIN
    Declare @Registro INT
    SET @Registro=(SELECT Min(CsIdConfiguracionSabana) FROM #Configuracion WHERE Consecutivo=0)
    Update #Configuracion SET Consecutivo=@i WHERE CsIdConfiguracionSabana=@Registro
    SET @i=@i+1
END

;WITH AliasDuplicado AS (
    SELECT AliasConsecutivo,
           ROW_NUMBER() OVER (
               PARTITION BY CSAlias, DATALENGTH(CSAlias)
               ORDER BY CSidplan, CsIdConfiguracionSabana) AS NumeroAlias
    FROM #Configuracion
)
UPDATE AliasDuplicado SET AliasConsecutivo = NumeroAlias

SELECT @KueriII=
 CASE WHEN Consecutivo <=30 AND CSidplanopcion IN(3200) AND @idEmpresa NOT IN(288,169,168) THEN
  isnull(@KueriII,'')+ ',VERDE_12M=ISNULL((SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA INNER JOIN FF_PlanOpcionseleccion ON VSIdEmpleado=P.Id AND POidplanOpcion=VSIdPlanOpcion AND VSIdVigencia=P.POIdVigencia WHERE VSIdPlanOpcion in(3200) AND POIDplanOpcion in(3200) and POIdSolicitud=P.POidSolicitud and POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + '),(SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3200) and s.VSIdEstatus=1))+' + ''',Costo_''' + '+RTRIM(cast(Consecutivo as char(3)))+' + '''=(SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3200) and s.VSIdEstatus=1) '''
 WHEN Consecutivo <=30 AND CSidplanopcion IN(3201) AND @idEmpresa IN(288,169,168) THEN
  isnull(@KueriII,'')+ ',VERDE_12M=ISNULL((SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA INNER JOIN FF_PlanOpcionseleccion ON VSIdEmpleado=P.Id AND POidplanOpcion=VSIdPlanOpcion AND VSIdVigencia=P.POIdVigencia WHERE VSIdPlanOpcion in(3201) AND POIDplanOpcion in(3201) and POIdSolicitud=P.POidSolicitud and POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + '),(SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3201) and s.VSIdEstatus=1))+' + ''',Costo_''' + '+RTRIM(cast(Consecutivo as char(3)))+' + '''=(SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3201) and s.VSIdEstatus=1) '''
 WHEN Consecutivo <=30 AND CSidplanopcion NOT IN(3200,3201) AND CSIdConfiguracion=26 THEN
  isnull(@KueriII,'')+ ',(SELECT CASE WHEN COUNT(*)>0 THEN (SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA WHERE VSIdEmpleado=P.Id AND VSIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' AND VSIdVigencia=P.POIdVigencia) else ' + char(39) + 'N' + char(39) + ' end from ff_PlanOpcionSeleccion s where s.POidEmpleado=P.ID and POIdSolicitud=P.POidSolicitud and s.POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + ') as ' + char(39) + CSalias + CASE WHEN AliasConsecutivo=1 THEN '' ELSE RTRIM(CAST(AliasConsecutivo-1 AS VARCHAR(10))) END + char(39) + char(13) + ',Costo_' + RTRIM(cast(Consecutivo as char(3))) + '=CASE WHEN EMIdParentesco in(1,2) THEN (SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_PlanOpcionSeleccion s INNER JOIN FF_ValidaSavida v ON v.vsidempleado=s.poidempleado and v.vsidvigencia=s.poidvigencia and v.vsidestatus=1 and v.vsidplanopcion=s.poidplanopcion WHERE s.PONumeroEmpleado=P.EMNumeroEmpleado and s.POIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' and s.POIdSolicitud=P.POidSolicitud AND s.POidEmpleado=P.ID) ELSE ' + CHAR(39)+CHAR(39) + ' END '
 WHEN Consecutivo <=30 AND CSIdConfiguracion<>26 THEN
  isnull(@KueriII,'')+ ',(SELECT CASE WHEN COUNT(*)>0 THEN (SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA WHERE VSIdEmpleado=P.Id AND VSIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' AND VSIdVigencia=P.POIdVigencia) else ' + char(39) + 'N' + char(39) + ' end from ff_PlanOpcionSeleccion s where s.POidEmpleado=P.ID and POIdSolicitud=P.POidSolicitud and s.POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + ') as ' + char(39) + CSalias + CASE WHEN AliasConsecutivo=1 THEN '' ELSE RTRIM(CAST(AliasConsecutivo-1 AS VARCHAR(10))) END + char(39) + char(13) + ',Costo_' + RTRIM(cast(Consecutivo as char(3))) + '=CASE WHEN EMIdParentesco in(1,2) THEN (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103) from ff_PlanOpcionSeleccion s WHERE s.PONumeroEmpleado=P.EMNumeroEmpleado and s.POIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' and s.POIdSolicitud=P.POidSolicitud AND s.POidEmpleado=P.ID) ELSE ' + CHAR(39)+CHAR(39) + ' END '
 ELSE @KueriII END
FROM #Configuracion
order by CSidplan

SELECT @KueriIII = ' FROM dbo.#PlanesSabanaVida P ORDER BY OFICINA,EMNUMEROEMPLEADO,EMIDPARENTESCO'

execute (@KueriI + @KueriII + @KueriIII)

end
GO

-- =============================================================================
-- SCRIPT 3: ff_SabanaOPC_BF3 (Option B)
-- Logica B2 homologada dentro de la ruta propia de B3.
-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_SabanaOPC_BF3] (
@idEmpresa int,
@FechaIni varchar(20),
@FechaFin varchar(20),
@idEstatus int,
@idVigencia int,
@Confidencial INT = 0)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @KueriI  Varchar(MAX)
DECLARE @KueriII  Varchar(MAX)
DECLARE @KueriIII  Varchar(MAX)
declare @Registros int, @i int

SET @FechaFin = @FechaFin

DECLARE @SOIdEstatus int
SELECT @SOIdEstatus= CASE WHEN EXISTS (select 'k' from ff_Vigencia v2 where v2.VIRenovada= v1.VIidVigencia) THEN 10
        WHEN VIidEstatus not in (1,6) THEN 10  ELSE 1 END
  FROM  ff_Vigencia v1 INNER JOIN ff_Empresa WITH (NOLOCK) ON VIidConfiguracion=EMidConfiguracion
  WHERE EMidEmpresa = @idEmpresa AND VIidVigencia = @idVigencia AND VITipoNegocio = 1

/* La traza ayuda a confirmar la ruta del sitio, pero no es requisito del SP. */
IF OBJECT_ID(N'dbo.bf_RepConf_Debug',N'U') IS NOT NULL
BEGIN
    DECLARE @DetalleInicio varchar(max)=
        'idEmpresa='+CAST(@idEmpresa AS varchar(20))
        +' idVigencia='+CAST(@idVigencia AS varchar(20))
        +' FechaIni='+@FechaIni+' FechaFin='+@FechaFin
        +' idEstatus='+CAST(@idEstatus AS varchar(20))
        +' SOIdEstatus='+ISNULL(CAST(@SOIdEstatus AS varchar(20)),'NULL');

    EXEC sys.sp_executesql
        N'INSERT dbo.bf_RepConf_Debug(etapa,detalle)
          VALUES (''opc_bf3_inicio'',@Detalle);',
        N'@Detalle varchar(max)',
        @Detalle=@DetalleInicio;
END

-- estructura vacia; CSPestana=1 aqui no importa (top 0 = 0 filas)
SELECT top 0 cast('' as varchar(100)) as NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, EM.EMidParentesco,
 PA.PADescripcion, PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre, PO.PONombre, EM.EMEdad,
 EM.EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
 SO.SONumeroSolicitud, ISNULL(EM.EMNombre1,' ') + SPACE(1) + ISNULL(EM.EMNombre2,' ') as Nombres,
 convert(char(10),EM.emfechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
 case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),coalesce(TCPrimaNeta,0),103) from ff_TarifaCosto ppp
          WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
 CONVERT(CHAR(20),(coalesce(POCostoRestante,0)),103) as Costo, EMOFicina,
 (Select top 1 RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
  AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
 rtrim(emRFC) as RFC, RTRIM(pe.PEDescripcion) AS Perfil,
 isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
 isnull(EMMunicipioDelegacionFiscal,'') as Del_Municipio,
 EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
 isnull(''+emcodigoPostalFiscal,'') as CP, rtrim(emarchivoinformacion) as local_number,
 EMArea, EMArchivoInformacion Ubicacion, EMIdCentroCostos, 0 as EmSalariobase,
 (Select top 1 RTRIM(teDatoAdicional2) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
  AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Categoria,
 convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
 SE.SEDescripcion, em.id, INFO=RTRIM(ISNULL(Desarrollo,'')), pos.POidSolicitud, pos.POidVigencia,
 cast('' as varchar(50)) as Folio
 INTO dbo.#PlanesSabanaVida
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus in(1,3,10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud
  AND SO.SOIdEmpresa=POS.POidEmpresa and SOIDEstatus in(1,3,10)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana=3 and CSPestana=1 AND poidempresa=@idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidEstatus in (1,3,10)
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 ORDER BY Oficina,EMNumeroEmpleado, EM.EmidParentesco

IF @idEstatus = 1
BEGIN
 -- opcion B: todos los CSAlias de tipo 3 generan pestana (sin filtro CSPestana=1)
 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,POidPlan,EMidParentesco,PADescripcion,poidplanopcion,POidGrupoParentesco,
  PLNombre,PONombre,EMEdad,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  SONumeroSolicitud,Nombres,EMFechaIngresoEmpresa,PrimaNeta,Costo,EMOFicina,Oficina,RFC,Perfil,Calle,NumExt,NumInt,Colonia,
  Del_Municipio,EstadoFiscal,CP,local_number,EMArea,Ubicacion,EMIdCentroCostos,EmSalariobase,Categoria,EMFechaNacimiento,SEDescripcion,id,INFO,POidSolicitud,POidVigencia,Folio)
 SELECT DISTINCT cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, EM.EMidParentesco,
  PA.PADescripcion, PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre, PO.PONombre, EM.EMEdad,
  EM.EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
  SO.SONumeroSolicitud, ISNULL(EM.EMNombre1,' ') + SPACE(1) + ISNULL(EM.EMNombre2,' ') as Nombres,
  convert(char(10),EM.emfechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),COALESCE(SUM(TCPrimaNeta),0),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),COALESCE(SUM(TCPrimaNeta),0),103) from ff_TarifaCosto_hist ppp with(nolock)
             WHERE ppp.TCidParentesco is not null and ppp.TCEdad is not null and ppp.TCIdSexo is not null
             and ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo, EMOFicina,
  (Select top 1 RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  rtrim(emRFC) as RFC, RTRIM(pe.PEDescripcion) AS Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(EMMunicipioDelegacionFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP, rtrim(emarchivoinformacion) as local_number,
  EMArea, rtrim(emarchivoinformacion) as Ubicacion, EMIdCentroCostos, 0 as EmSalariobase,
  (Select top 1 RTRIM(teDatoAdicional2) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Categoria,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  SE.SEDescripcion, em.id, INFO=RTRIM(ISNULL(Desarrollo,'')), pos.POidSolicitud, pos.POidVigencia, '' as Folio
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus in (1,3,10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud
  AND SO.SOIdEmpresa=POS.POidEmpresa and SOIDEstatus in(1,3,10)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 -- opcion B: sin CSPestana=1 → todos los planes de tipo 3 generan pestaña
 -- fix fecha: ISNULL usa @FechaFin (no getdate) para incluir solicitudes sin fecha aprobacion
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana=3 AND poidempresa=@idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,CONVERT(date,@FechaFin)) >= CONVERT(date,@FechaIni)
 AND ISNULL(SO.SOFechaAprovacion,CONVERT(date,@FechaFin)) <= CONVERT(date,@FechaFin)
 AND POS.POidEstatus in (1,3,10)
 AND SO.SOEstatusSolicitud in (1,3)
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 AND (@Confidencial = 1 OR EM.EMidSalarioConfidencial = 0)

END
ELSE IF @idEstatus=2
BEGIN
 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,POidPlan,EMidParentesco,PADescripcion,poidplanopcion,POidGrupoParentesco,
  PLNombre,PONombre,EMEdad,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  SONumeroSolicitud,Nombres,EMFechaIngresoEmpresa,PrimaNeta,Costo,EMOFicina,Oficina,RFC,Perfil,Calle,NumExt,NumInt,Colonia,
  Del_Municipio,EstadoFiscal,CP,local_number,EMArea,Ubicacion,EMIdCentroCostos,EmSalariobase,Categoria,EMFechaNacimiento,SEDescripcion,id,INFO,POidSolicitud,POidVigencia,Folio)
 SELECT DISTINCT cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, EM.EMidParentesco,
  PA.PADescripcion, PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre, PO.PONombre, EM.EMEdad,
  EM.EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
  SO.SONumeroSolicitud, ISNULL(EM.EMNombre1,' ') + SPACE(1) + ISNULL(EM.EMNombre2,' ') as Nombres,
  convert(char(10),EM.emfechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),COALESCE(SUM(TCPrimaNeta),0),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),COALESCE(SUM(TCPrimaNeta),0),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo, EMOFicina,
  (Select top 1 RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  rtrim(emRFC) as RFC, RTRIM(pe.PEDescripcion) AS Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(EMMunicipioDelegacionFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP, rtrim(emarchivoinformacion) as local_number,
  EMArea, EMArchivoInformacion Ubicacion, EMIdCentroCostos, 0 as EmSalariobase,
  (Select top 1 RTRIM(teDatoAdicional2) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Categoria,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  SE.SEDescripcion, em.id, INFO=RTRIM(ISNULL(Desarrollo,'')), pos.POidSolicitud, pos.POidVigencia, '' as Folio
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus IN(4,5,0)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(0,1,4,5)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND CS.CSidTipoSabana=3 AND poidempresa=@idEmpresa
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'

END

SELECT @KueriI = 'SELECT DISTINCT ''OPC'' as grupo, NombrePestana, P.TipoSabana, P.PADescripcion, P.PONombre, PLNombre,
P.EMNumeroEmpleado, P.EMCertificado, P.EMApellidoPaterno, P.EMApellidoMaterno, P.EMNombre1, P.EMNombre2, P.Nombres, P.PrimaNeta, P.costo as Costo,
P.EMIdParentesco, P.EMFechaNacimiento, Perfil, P.EMFechaIngresoEmpresa, P.SONumeroSolicitud, P.EMSalarioBase,
P.SEDescripcion, P.EMEdad, P.EMOficina, P.Oficina, P.Ubicacion, P.RFC, Id, INFO, Calle, NumExt, NumInt, Colonia, Del_Municipio, EstadoFiscal, CP,
P.local_number, P.EMArea, P.EMIdCentroCostos, P.Categoria, P.Folio '

-- flujo aislado: sin csidvigencia=@idVigencia en #Configuracion
SELECT 0 as Consecutivo, 0 as AliasConsecutivo,CSConfig.*
INTO #Configuracion
FROM dbo.ff_ConfiguracionSabana CSConfig WITH (READUNCOMMITTED,NOLOCK)
where CSConfig.CSIdEstatus=1
  AND CSConfig.CSidConfiguracion=ISNULL((Select EMidConfiguracion FROM ff_Empresa where EMidEmpresa=@idEmpresa),0)
  and CSConfig.CSIDTiposabana=3 AND CSConfig.CSPestana=0
  -- Si la vigencia actual ya tiene configuracion, no mezclar coberturas
  -- historicas ni filas NULL que consuman el limite de 30 coberturas.
  -- Cuando aun no se ha clonado la configuracion (ATT, Zurich y otros),
  -- conservar el fallback legacy a todas las filas disponibles.
  AND (
      CSConfig.CSidVigencia=@idVigencia
      OR NOT EXISTS (
          SELECT 1
          FROM dbo.ff_ConfiguracionSabana CSActual WITH (READUNCOMMITTED,NOLOCK)
          WHERE CSActual.CSIdEstatus=1
            AND CSActual.CSidConfiguracion=CSConfig.CSidConfiguracion
            AND CSActual.CSIDTiposabana=3
            AND CSActual.CSPestana=0
            AND CSActual.CSidVigencia=@idVigencia
      )
  )
order by CSidplan

SET @Registros = (SELECT COUNT(consecutivo) from #Configuracion)

SET @i=1
While @i<=@Registros
BEGIN
    Declare @Registro2 INT
    SET @Registro2=(SELECT Min(CsIdConfiguracionSabana) FROM #Configuracion WHERE Consecutivo=0)
    Update #Configuracion SET Consecutivo=@i WHERE CsIdConfiguracionSabana=@Registro2
    SET @i=@i+1
END

;WITH AliasDuplicado AS (
    SELECT AliasConsecutivo,
           ROW_NUMBER() OVER (
               PARTITION BY CSAlias, DATALENGTH(CSAlias)
               ORDER BY CSidplan, CsIdConfiguracionSabana) AS NumeroAlias
    FROM #Configuracion
)
UPDATE AliasDuplicado SET AliasConsecutivo = NumeroAlias

SELECT @KueriII=
 CASE WHEN Consecutivo <=30 AND CSidplanopcion IN(3200) AND @idEmpresa NOT IN(288,169,168) THEN
  isnull(@KueriII,'')+ ',VERDE_12M=ISNULL((SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA INNER JOIN FF_PlanOpcionseleccion ON VSIdEmpleado=P.Id AND POidplanOpcion=VSIdPlanOpcion AND VSIdVigencia=P.POIdVigencia WHERE VSIdPlanOpcion in(3200) AND POIDplanOpcion in(3200) and POIdSolicitud=P.POidSolicitud and POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + '),(SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3200) and s.VSIdEstatus=1))+' + ''',Costo_''' + '+RTRIM(cast(Consecutivo as char(3)))+' + '''=(SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3200) and s.VSIdEstatus=1) '''
 WHEN Consecutivo <=30 AND CSidplanopcion IN(3201) AND @idEmpresa IN(288,169,168) THEN
  isnull(@KueriII,'')+ ',VERDE_12M=ISNULL((SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA INNER JOIN FF_PlanOpcionseleccion ON VSIdEmpleado=P.Id AND POidplanOpcion=VSIdPlanOpcion AND VSIdVigencia=P.POIdVigencia WHERE VSIdPlanOpcion in(3201) AND POIDplanOpcion in(3201) and POIdSolicitud=P.POidSolicitud and POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + '),(SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3201) and s.VSIdEstatus=1))+' + ''',Costo_''' + '+RTRIM(cast(Consecutivo as char(3)))+' + '''=(SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3201) and s.VSIdEstatus=1) '''
 WHEN Consecutivo <=30 AND CSidplanopcion NOT IN(3200,3201) AND CSIdConfiguracion=26 THEN
  isnull(@KueriII,'')+ ',(SELECT CASE WHEN COUNT(*)>0 THEN (SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) FROM FF_VALIDASAVIDA WHERE VSIdEmpleado=P.Id AND VSIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' AND VSIdVigencia=P.POIdVigencia) else ' + char(39) + 'N' + char(39) + ' end from ff_PlanOpcionSeleccion s where s.POidEmpleado=P.ID and POIdSolicitud=P.POidSolicitud and s.POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + ') as ' + char(39) + CSalias + CASE WHEN AliasConsecutivo=1 THEN '' ELSE RTRIM(CAST(AliasConsecutivo-1 AS VARCHAR(10))) END + char(39) + char(13) + ',Costo_' + RTRIM(cast(Consecutivo as char(3))) + '=CASE WHEN EMIdParentesco in(1,2) THEN (SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_PlanOpcionSeleccion s INNER JOIN FF_ValidaSavida v ON v.vsidempleado=s.poidempleado and v.vsidvigencia=s.poidvigencia and v.vsidestatus=1 and v.vsidplanopcion=s.poidplanopcion WHERE s.PONumeroEmpleado=P.EMNumeroEmpleado and s.POIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' and s.POIdSolicitud=P.POidSolicitud AND s.POidEmpleado=P.ID) ELSE ' + CHAR(39)+CHAR(39) + ' END '
 WHEN Consecutivo <=30 AND CSIdConfiguracion<>26 THEN
  isnull(@KueriII,'')+ ',(SELECT CASE WHEN COUNT(*)>0 THEN (SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) FROM FF_VALIDASAVIDA WHERE VSIdEmpleado=P.Id AND VSIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' AND VSIdVigencia=P.POIdVigencia) else ' + char(39) + 'N' + char(39) + ' end from ff_PlanOpcionSeleccion s where s.POidEmpleado=P.ID and POIdSolicitud=P.POidSolicitud and s.POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + ') as ' + char(39) + CSalias + CASE WHEN AliasConsecutivo=1 THEN '' ELSE RTRIM(CAST(AliasConsecutivo-1 AS VARCHAR(10))) END + char(39) + char(13) + ',Costo_' + RTRIM(cast(Consecutivo as char(3))) + '=CASE WHEN EMIdParentesco in(1,2) THEN (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103) from ff_PlanOpcionSeleccion s WHERE s.PONumeroEmpleado=P.EMNumeroEmpleado and s.POIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' and s.POIdSolicitud=P.POidSolicitud AND s.POidEmpleado=P.ID) ELSE ' + CHAR(39)+CHAR(39) + ' END '
 ELSE @KueriII END
FROM #Configuracion
order by CSidplan

SELECT @KueriIII = ' FROM dbo.#PlanesSabanaVida P ORDER BY OFICINA,EMNUMEROEMPLEADO,EMIDPARENTESCO'

-- sin columnas dinamicas cuando #Configuracion esta vacio (evita execute(NULL) = sin resultset)
IF @KueriII IS NULL SET @KueriII = ''

execute (@KueriI + @KueriII + @KueriIII)
drop table #PlanesSabanaVida;

end
GO

-- =============================================================================
-- SCRIPT 4: ff_SabanaMascotas_BF3
-- Restaura la hoja dedicada y relaciona cada mascota con su cobertura real.
-- InfoPlanMascota.idPlan se ha usado como plan o como plan-opcion segun la
-- version del ambiente; se soportan ambas convenciones sin duplicar filas.
-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_SabanaMascotas_BF3]
    @idEmpresa  INT,
    @FechaIni   VARCHAR(20),
    @FechaFin   VARCHAR(20),
    @idVigencia INT,
    @idEstatus  INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @idEstatus <> 1
        RETURN;

    SELECT DISTINCT
        'MASCOTAS' AS NombrePestana,
        'Mascotas' AS grupo,
        1 AS IdBeflex,
        ISNULL(ESA.EMNombre, '') AS Empresa,
        ADO.EMNumeroEmpleado AS Empleado,
        LTRIM(RTRIM(ISNULL(ADO.EMApellidoPaterno, '') + ' '
            + ISNULL(ADO.EMApellidoMaterno, '') + ' '
            + ISNULL(ADO.EMNombre1, '') + ' '
            + ISNULL(ADO.EMNombre2, ''))) AS [Nombre titular],
        PL.PLIdPlan AS IdPlan,
        PL.PLNombre AS [Plan],
        POS.POIdPlanOpcion AS idCobertura,
        PO.PONombre AS Cobertura,
        POS.POIdEmpleado AS IdDependiente,
        PA.PADescripcion AS Parentesco,
        MAS.Nombre,
        MAS.Edad,
        MAS.Sexo,
        MAS.Raza,
        CASE MAS.Pedigree WHEN 0 THEN 'No' WHEN 1 THEN 'Si' END AS Pedigree,
        MAS.ColorNariz AS [Color Nariz],
        MAS.ColorMascota AS [Color Mascota],
        MAS.CaracteristicasMascota AS [Caracteristicas Mascota],
        MAS.Enfermedades,
        POS.POIdSolicitud AS Solicitud
    FROM dbo.ff_Solicitud AS SO WITH (NOLOCK)
    INNER JOIN dbo.ff_Empleado AS ADO WITH (NOLOCK)
        ON ADO.Id = SO.SOIdEmpleado
       AND ADO.EMIdEmpresa = SO.SOIdEmpresa
    INNER JOIN dbo.ff_Empresa AS ESA WITH (NOLOCK)
        ON ESA.EMIdEmpresa = SO.SOIdEmpresa
       AND ESA.EMIdEstatus = 1
    INNER JOIN dbo.ff_PlanOpcionSeleccion AS POS WITH (NOLOCK)
        ON POS.POIdSolicitud = SO.SOIdSolicitud
       AND POS.POIdEmpresa = SO.SOIdEmpresa
       AND POS.POIdParentesco = 23
       AND POS.POIdEstatus IN (1,3,10)
    INNER JOIN dbo.ff_PlanOpcion AS PO WITH (NOLOCK)
        ON PO.POIdPlanOpcion = POS.POIdPlanOpcion
    INNER JOIN dbo.ff_Plan AS PL WITH (NOLOCK)
        ON PL.PLIdPlan = PO.POIdPlan
    INNER JOIN dbo.ff_Parentesco AS PA WITH (NOLOCK)
        ON PA.PAIdParentesco = POS.POIdParentesco
    INNER JOIN dbo.ff_InfoPlanMascota AS MAS WITH (NOLOCK)
        ON MAS.idSolicitud = SO.SOIdSolicitud
       AND MAS.idBeneficiario = POS.POIdEmpleado
       AND (MAS.idPlan = POS.POIdPlanOpcion OR MAS.idPlan = PL.PLIdPlan)
       AND MAS.status = 1
    WHERE SO.SOIdEmpresa = @idEmpresa
      AND SO.SOIdVigencia = @idVigencia
      AND SO.SOEstatusSolicitud IN (1,3)
      AND ISNULL(SO.SOFechaAprovacion, CONVERT(date,@FechaFin))
            >= CONVERT(date,@FechaIni)
      AND ISNULL(SO.SOFechaAprovacion, CONVERT(date,@FechaFin))
            <= CONVERT(date,@FechaFin)
    ORDER BY ADO.EMNumeroEmpleado, POS.POIdSolicitud,
             POS.POIdEmpleado, MAS.Nombre;
END
GO

-- =============================================================================
-- SCRIPT 5: ff_Sabana_BF3
-- Unico punto de entrada del reporte B3. No llama ni modifica objetos _v2.
-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_Sabana_BF3]
    @idEmpresa    INT,
    @FechaIni     VARCHAR(50),
    @FechaFin     VARCHAR(50),
    @idEstatus    INT,
    @idVigencia   INT,
    @Confidencial INT = 0
AS
BEGIN
    SET NOCOUNT ON;

    -- No ocultar errores: un Excel parcial no debe marcarse como exitoso.
    EXEC dbo.ff_SabanaGMM_BF3
        @idEmpresa    = @idEmpresa,
        @FechaIni     = @FechaIni,
        @FechaFin     = @FechaFin,
        @idEstatus    = @idEstatus,
        @idVigencia   = @idVigencia,
        @Confidencial = @Confidencial;

    EXEC dbo.ff_SabanaVIDA_BF3
        @idEmpresa    = @idEmpresa,
        @FechaIni     = @FechaIni,
        @FechaFin     = @FechaFin,
        @idEstatus    = @idEstatus,
        @idVigencia   = @idVigencia,
        @Confidencial = @Confidencial;

    EXEC dbo.ff_SabanaOPC_BF3
        @idEmpresa    = @idEmpresa,
        @FechaIni     = @FechaIni,
        @FechaFin     = @FechaFin,
        @idEstatus    = @idEstatus,
        @idVigencia   = @idVigencia,
        @Confidencial = @Confidencial;

    IF @idEstatus = 1
    BEGIN
        EXEC dbo.ff_SabanaMascotas_BF3
            @idEmpresa  = @idEmpresa,
            @FechaIni   = @FechaIni,
            @FechaFin   = @FechaFin,
            @idVigencia = @idVigencia,
            @idEstatus  = @idEstatus;
    END
END
GO

-- =============================================================================
-- SCRIPT 6: asegurar configuracion de la hoja Mascotas
-- Se reemplaza exclusivamente la configuracion global de este grupo. No se
-- modifican configuraciones particulares de ninguna empresa.
-- =============================================================================
BEGIN TRY
BEGIN TRANSACTION;

IF EXISTS
(
    SELECT 1
    FROM dbo.bf_RepConf_Tabla
    WHERE idEmpresa = 0
      AND catReportesId = 3
      AND grupo = N'Mascotas'
)
BEGIN
    UPDATE dbo.bf_RepConf_Tabla
    SET columnaGrupo = N'NombrePestana',
        agruparPorColumna = 0,
        indexTable = 3,
        alineacion = N'Derecha',
        colorFondo = N'#0D6EFD',
        colorLetra = N'White',
        activo = 1,
        repConfTablaUsuarioMod = 0,
        repConfTablaFechaMod = GETDATE()
    WHERE idEmpresa = 0
      AND catReportesId = 3
      AND grupo = N'Mascotas';
END
ELSE
BEGIN
    INSERT dbo.bf_RepConf_Tabla
    (
        idEmpresa, catReportesId, grupo, columnaGrupo,
        agruparPorColumna, indexTable, tituloTabla,
        espacioIzquierda, espacioDerecha, alineacion,
        colorFondo, colorLetra, activo,
        repConfTablaUsuarioAdd, repConfTablaFechaAdd
    )
    VALUES
    (
        0, 3, N'Mascotas', N'NombrePestana',
        0, 3, NULL,
        NULL, NULL, N'Derecha',
        N'#0D6EFD', N'White', 1,
        0, GETDATE()
    );
END;

DELETE dbo.bf_RepConf_Columna
WHERE idEmpresa = 0
  AND catReportesId = 3
  AND grupo = N'Mascotas';

INSERT dbo.bf_RepConf_Columna
(
    idEmpresa, catReportesId, grupo, orden,
    campoOrigen, encabezado, visible, ancho,
    formato, alinear, tipoDato,
    repConfColumnaUsuarioAdd, repConfColumnaFechaAdd
)
VALUES
    (0,3,N'Mascotas', 2,N'Empresa',N'Empresa',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas', 3,N'Empleado',N'Número Empleado',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas', 4,N'Nombre titular',N'Nombre titular',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas', 5,N'IdPlan',N'IdPlan',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas', 6,N'Plan',N'Plan',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas', 7,N'idCobertura',N'idCobertura',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas', 8,N'Cobertura',N'Cobertura',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas', 9,N'IdDependiente',N'IdDependiente',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',10,N'Parentesco',N'Parentesco',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',11,N'Nombre',N'Nombre',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',12,N'Sexo',N'Sexo',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',13,N'Raza',N'Raza',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',14,N'Edad',N'Edad',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',15,N'Pedigree',N'Pedigree',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',16,N'Color Nariz',N'Color Nariz',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',17,N'Color Mascota',N'Color Mascota',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',18,N'Caracteristicas Mascota',N'Caracteristicas Mascota',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',19,N'Enfermedades',N'Enfermedades',1,NULL,NULL,NULL,NULL,0,GETDATE()),
    (0,3,N'Mascotas',20,N'Solicitud',N'Solicitud',1,NULL,NULL,NULL,NULL,0,GETDATE());

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

-- =============================================================================
-- SCRIPT 7: apuntar reporteId=3 a ff_Sabana_BF3
--
-- No se usa un catReportesSPId fijo: es identity y cambia entre ambientes.
-- El orquestador debe encontrar una sola ruta activa para el reporte Sabana.
-- =============================================================================
DECLARE @SabanaReporteId int = 3,
        @SabanaSPId      int,
        @OrdenConf       int;

SELECT TOP (1)
       @SabanaSPId = SP.catReportesSPId
FROM dbo.bf_CatReportesSP AS SP
WHERE SP.catReportesId = @SabanaReporteId
ORDER BY CASE
             WHEN ISNULL(SP.ESid, 1) = 1
              AND SP.catReportesSPNombre = 'ff_Sabana_BF3' THEN 0
             WHEN ISNULL(SP.ESid, 1) = 1 THEN 1
             WHEN SP.catReportesSPNombre = 'ff_Sabana_BF3' THEN 2
             ELSE 3
         END,
         SP.catReportesSPOrden,
         SP.catReportesSPId;

IF @SabanaSPId IS NULL
    THROW 55210, 'El reporte 3 (Sabana) no tiene configuracion en dbo.bf_CatReportesSP.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    UPDATE dbo.bf_CatReportesSP
    SET catReportesSPNombre = 'ff_Sabana_BF3',
        ESid = 1
    WHERE catReportesSPId = @SabanaSPId;

    /* Evita que el sitio ejecute tambien una ruta legacy del mismo reporte. */
    UPDATE dbo.bf_CatReportesSP
    SET ESid = 0
    WHERE catReportesId = @SabanaReporteId
      AND catReportesSPId <> @SabanaSPId
      AND ISNULL(ESid, 1) = 1;

    /*
       Una reinstalacion previa podia duplicar parametros y hacer que el
       orquestador enviara dos veces el mismo argumento al procedimiento.
    */
    ;WITH ParametrosDuplicados AS
    (
        SELECT P.catReportesParamsId,
               ROW_NUMBER() OVER
               (
                   PARTITION BY UPPER(LTRIM(RTRIM(P.catReportesParamsNombre)))
                   ORDER BY CASE WHEN ISNULL(P.ESid, 1) = 1 THEN 0 ELSE 1 END,
                            P.catReportesParamsId
               ) AS NumeroFila
        FROM dbo.bf_CatReportesParams AS P
        WHERE P.catReportesSPId = @SabanaSPId
    )
    DELETE P
    FROM dbo.bf_CatReportesParams AS P
    INNER JOIN ParametrosDuplicados AS D
            ON D.catReportesParamsId = P.catReportesParamsId
    WHERE D.NumeroFila > 1;

    /* El parametro es opcional en SQL, pero el sitio lo envia cuando aplica. */
    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.bf_CatReportesParams AS P
        WHERE P.catReportesSPId = @SabanaSPId
          AND UPPER(LTRIM(RTRIM(P.catReportesParamsNombre))) = '@CONFIDENCIAL'
    )
    BEGIN
        SELECT @OrdenConf = CASE
                                WHEN NOT EXISTS
                                     (
                                         SELECT 1
                                         FROM dbo.bf_CatReportesParams
                                         WHERE catReportesSPId = @SabanaSPId
                                           AND catReportesParamsOrden = 6
                                     ) THEN 6
                                ELSE ISNULL(MAX(catReportesParamsOrden), 5) + 1
                            END
        FROM dbo.bf_CatReportesParams
        WHERE catReportesSPId = @SabanaSPId;

        INSERT dbo.bf_CatReportesParams
        (
            catReportesSPId,
            catReportesTipoDatoId,
            catReportesParamsLongitud,
            catReportesParamsOrden,
            catReportesParamsNombre,
            catReportesParamsDesc,
            ESid,
            catReportesParamsUsuarioAdd,
            catReportesParamsFechaAdd
        )
        VALUES
        (
            @SabanaSPId,
            1,
            '1',
            @OrdenConf,
            '@confidencial',
            'Filtro confidencialidad salarial (0=solo no-confidenciales, 1=todos)',
            1,
            0,
            GETDATE()
        );
    END;

    IF
    (
        SELECT COUNT(*)
        FROM dbo.bf_CatReportesSP
        WHERE catReportesId = @SabanaReporteId
          AND ISNULL(ESid, 1) = 1
    ) <> 1
        THROW 55211, 'El reporte 3 debe tener una sola configuracion de SP activa.', 1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.bf_CatReportesSP
        WHERE catReportesSPId = @SabanaSPId
          AND catReportesSPNombre = 'ff_Sabana_BF3'
          AND ISNULL(ESid, 1) = 1
    )
        THROW 55212, 'No fue posible activar dbo.ff_Sabana_BF3 para el reporte 3.', 1;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT SP.catReportesSPId,
       SP.catReportesId,
       SP.catReportesSPNombre,
       SP.catReportesSPOrden,
       SP.ESid
FROM dbo.bf_CatReportesSP AS SP
WHERE SP.catReportesId = @SabanaReporteId
ORDER BY SP.catReportesSPOrden, SP.catReportesSPId;
GO

-- Encabezados globales tal como los expone el Excel legacy. Las empresas con
-- configuracion especifica (por ejemplo ATT: Cobertura) conservan su valor.
UPDATE dbo.bf_RepConf_Columna
SET encabezado = CASE campoOrigen
    WHEN 'PONombre' THEN 'PONombre'
    WHEN 'NumExt' THEN 'NumExt'
    WHEN 'NumInt' THEN 'NumInt'
    WHEN 'Id' THEN 'id'
    ELSE encabezado
END
WHERE catReportesId = 3
  AND idEmpresa = 0
  AND UPPER(LTRIM(RTRIM(grupo))) IN ('OPC', 'OPCIONALES')
  AND campoOrigen IN ('PONombre', 'NumExt', 'NumInt', 'Id');

-- Ajustes exactos observados contra los Excel legacy de Corteva.
UPDATE dbo.bf_RepConf_Columna
SET encabezado = CASE campoOrigen
    WHEN 'PONombre' THEN 'PONombre'
    WHEN 'NumExt' THEN 'NumExt'
    WHEN 'NumInt' THEN 'NumInt'
    ELSE encabezado
END
WHERE catReportesId = 3
  AND idEmpresa = 856
  AND UPPER(LTRIM(RTRIM(grupo))) IN ('OPC', 'OPCIONALES')
  AND campoOrigen IN ('PONombre', 'NumExt', 'NumInt');

UPDATE dbo.bf_RepConf_Columna
SET encabezado = 'EMOficina'
WHERE catReportesId = 3
  AND idEmpresa = 856
  AND UPPER(LTRIM(RTRIM(grupo))) = 'VIDA'
  AND UPPER(LTRIM(RTRIM(campoOrigen))) = 'EMOFICINA';

-- El XML legacy usa estos nombres de pestana; la configuracion migrada
-- contenia la variante completa y producia un nombre distinto en B3.
UPDATE dbo.ff_ConfiguracionSabana
SET CSAlias = 'GRAVES ENFERMEDADE'
WHERE CSidConfiguracion = 25
  AND CSAlias = 'GRAVES ENFERMEDADES';

UPDATE dbo.ff_ConfiguracionSabana
SET CSAlias = 'HOSPITAL INDIVIDUA'
WHERE CSidConfiguracion = 35
  AND CSAlias = 'HOSPITAL INDIVIDUAL';
GO
