# Homologacion Sabana y Cobranza B3

Fecha de cierre: 8 de septiembre de 2026.

Este paquete contiene exclusivamente el instalador SQL de B3, los archivos
Java modificados y sus pruebas. B2 se utilizo como patron y no fue modificado.
Angular tampoco requiere cambios para estas incidencias.

Es una entrega incremental sobre la instalacion de cache/homologacion de
Cobranza realizada previamente. No vuelve a incluir ni reinstalar los SP del
cache de Cobranza; el unico SQL nuevo requerido por estas incidencias es el de
Sabana incluido aqui.

## Instalacion

1. Respaldar la base y ejecutar `01_BASE_DATOS/01_INSTALAR_SABANA_B3.sql` con
   una cuenta que pueda alterar procedimientos y actualizar las tablas de
   configuracion del reporte.
2. Copiar el contenido de `02_API_REPORTES` sobre la raiz del clon de
   APIREPORTS, conservando la estructura `src/main` y `src/test`.
3. En el clon de APIREPORTS ejecutar
   `03_COMANDOS_GIT/COMANDOS_API_REPORTES.ps1`.
4. Desplegar o reiniciar API Reportes. Los cambios Java no se activan solo con
   el push; necesitan pasar por el despliegue del ambiente.

Si el Excel del sitio conserva diferencias, generar primero un reporte nuevo
y ejecutar `01_BASE_DATOS/02_VALIDAR_SABANA_B3_EMPRESA_2185.sql` en la misma
base utilizada por APIREPORTS. Es un diagnostico de solo lectura y devuelve un
unico resultset con servidor/base, ruta activa, parametros, version instalada,
conteos fuente, filas rechazadas y la traza reciente del SP. Exportar esa unica
tabla como CSV para compartir toda la evidencia en un solo archivo.

El SQL es idempotente: se probo ejecutandolo varias veces. La configuracion
global de Mascotas queda en una sola fila con 19 columnas. El reporte 3 queda
con una sola ruta activa a `ff_Sabana_BF3`; la seleccion se hace por reporte y
no por un `catReportesSPId` identity que puede ser distinto en cada ambiente.
Tambien se eliminan parametros duplicados del paso seleccionado.

La homologacion se instala exclusivamente en `ff_Sabana_BF3`,
`ff_SabanaGMM_BF3`, `ff_SabanaVIDA_BF3`, `ff_SabanaOPC_BF3` y
`ff_SabanaMascotas_BF3`. Los procedimientos terminados en `_v2` pertenecen a
la ruta legacy de B2 y este instalador no los crea, altera ni ejecuta.

## Incidencias corregidas

| Incidencia anterior | Resultado nuevo | Causa y correccion |
| --- | --- | --- |
| Vida: B3 entregaba 1,271 registros contra 1,115 de B2. | B3 entrega 1,115; la comparacion de columnas y filas contra el resultset B2 dio cero diferencias. | Las coberturas adicionales multiplicaban al empleado. La salida B3 ahora proyecta el mismo nivel de detalle que B2 y elimina esa multiplicacion. |
| Gastos Funerarios: 217 contra 215. | 215, igual que B2. | Se excluyen solicitudes rechazadas/canceladas y se conserva la union solicitud-empresa. |
| Plan de Pension: 256 contra 255. | 255, igual que B2. | Se aplica el mismo filtro de estatus de solicitud de B2. |
| El SP corregido daba 215/255 al ejecutarse manualmente, pero el archivo del sitio podia conservar 217/256. | El reporte 3 ejecuta exclusivamente `ff_Sabana_BF3`. | El instalador localiza la configuracion por `catReportesId=3`, desactiva rutas anteriores y depura parametros repetidos. |
| No aparecia la hoja de Mascotas. | El wrapper entrega un cuarto resultset con 34 registros y el generador crea `MASCOTAS`. | Se agrego el SP de Mascotas, se admite que `ff_InfoPlanMascota.idPlan` guarde plan u opcion de plan y se asegura su configuracion global. |
| Cobranza colocaba el total de Concentrada al principio. | Las filas TOTAL se colocan al final. | El orden ya no depende de que la primera fila sea el total. |
| Empresa, ID, Edad y Numero Oficina se mostraban como moneda. | Claves como texto y campos enteros como numero sin moneda. | El formato se resuelve por nombre del campo, no por el valor nulo de la fila TOTAL. |
| Los bloques y conceptos de Total por coberturas tenian otro orden. | Se conserva el orden del SP/B2 y los conceptos siguen `ImpPer`: Prima Neta, Derecho, IVA y Prima Total. | Se retiro la reubicacion artificial de resultsets y se agrego el ordinal SQL a la ordenacion. |
| La cobranza terminaba y se podia descargar, pero no notificaba. | Tanto el endpoint anterior `/cobranza/consultar` como el asincrono `/cobranza/solicitar` solicitan una notificacion en exito o error. | El sitio desplegado podia conservar la llamada sincrona, donde no se habia conectado el correo. Ambos caminos ahora transmiten el token y usan la misma llamada y plantillas de notificacion. La consulta del historial se excluye para no enviar correos falsos. |

La observacion sobre la suma de `Costo Empleado` y `Costo Empresa` no se
modifico: el documento indica que el mismo comportamiento existe en B2 y B2
es el origen funcional que no debe alterarse.

## Evidencia local

- Base: `(localdb)\MSSQLLocalDB`, `FlexiForbesv2`.
- Empresa 2185, vigencia 4067, periodo 2025-10-13 a 2026-09-30.
- Wrapper B3: GMM 1,674; Vida 1,115; opcionales 1,723; Mascotas 34.
- La comparacion integral entre la referencia local `_v2` y la nueva familia
  `_BF3` dio el mismo esquema y los mismos datos en los cuatro resultsets.
- Las fechas de modificacion y los hashes SHA-256 de los cuatro procedimientos
  `_v2` permanecieron sin cambios antes y despues de dos instalaciones BF3.
- Gastos Funerarios 215 y Plan de Pension 255.
- La prueba a traves de `ff_orquestadorReportes` (el mismo punto de entrada del
  sitio) confirmo los cinco resultsets: metadatos, GMM, Vida, opcionales y
  Mascotas, con los mismos conteos.
- La diferencia anterior se identifico en la solicitud 436
  (`POIdSolicitud=3242191`, `SOEstatusSolicitud=5`): agregaba dos personas a
  Gastos Funerarios y una a Plan de Pension. Las tres quedan excluidas.
- Se conservaron los trece conteos GMM informados, que suman 1,674.
- La suite Maven termino con 44 pruebas, cero fallas y cero errores; cinco
  inspectores que requieren rutas externas se omiten en la corrida general.
- Los inspectores se ejecutaron por separado sobre los XLSX entregados de B2 y
  B3 para establecer el estado anterior.

Nota de evidencia: los dos XLSX historicos de Sabana suministrados contienen
28 hojas y ninguno contiene Mascotas. El documento de incidencias pide
expresamente restaurarla; con la informacion fuente local el resultado nuevo
tiene 29 hojas, incluyendo `MASCOTAS`. Este punto queda comprobado contra los
datos y la configuracion, no contra una hoja Mascotas B2 incluida en esos XLSX.

El envio SMTP real no puede ejecutarse en LocalDB. Las regresiones automatizadas
comprueban que tanto la ruta sincrona como la asincrona invocan una vez el
cliente de correo con destinatario, plantillas y token correctos. La confirmacion
final del correo requiere el despliegue y conectividad del ambiente.

El detalle reproducible de la instalacion BF3, las huellas que demuestran que
`_v2` no cambio y los conteos del orquestador se encuentra en
`04_EVIDENCIAS/VALIDACION_SABANA_BF3_LOCAL_2185.md`.
