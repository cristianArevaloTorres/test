# Validacion local de Sabana BF3

Fecha: 8 de septiembre de 2026.

Ambiente utilizado: `(localdb)\MSSQLLocalDB`, base `FlexiForbesv2`.
Empresa 2185, vigencia 4067, periodo 2025-10-13 a 2026-09-30,
estatus 1 y confidencial 1.

## Instalacion y aislamiento de B2

`01_INSTALAR_SABANA_B3.sql` se ejecuto dos veces sin errores. El archivo crea
o altera exclusivamente estos procedimientos:

- `ff_Sabana_BF3`
- `ff_SabanaGMM_BF3`
- `ff_SabanaVIDA_BF3`
- `ff_SabanaOPC_BF3`
- `ff_SabanaMascotas_BF3`

La busqueda estatica del instalador no encontro instrucciones `CREATE`,
`ALTER` o `EXEC` dirigidas a procedimientos `_v2`.

Las fechas y huellas de los procedimientos `_v2` fueron iguales antes y
despues de ambas instalaciones:

| Procedimiento | Fecha de modificacion | SHA-256 de la definicion |
| --- | --- | --- |
| `ff_Sabana_v2` | 2026-09-07 20:48:47 | `BAE576661027BBEBCFE8EF0B4655FE68FAACDEA12BFD3D364E5449229898E7FA` |
| `ff_SabanaGMM_v2` | 2026-09-07 20:48:44 | `DD5F8FDEFE5A4CFA6F57E6248840E7886590A56B78172722ACA2805ACB72DAB1` |
| `ff_SabanaOPC_v2` | 2026-09-07 20:48:46 | `7EAEA84B0084F5257622A8FCB4FB5B16AD43787E0B0E09C545BB4FCB78B7E178` |
| `ff_SabanaVIDA_v2` | 2026-09-07 20:48:46 | `B41EAECDEA3A5E740E84B69D6925C2DD2406FF0219AC5FE62322EE859A53ACCD` |

Estas huellas prueban que el instalador BF3 no modifico la referencia local
`_v2`. No se establecio conexion ni se ejecuto ningun cambio en B2.

## Comparacion de resultados

Se ejecutaron `ff_Sabana_v2` como referencia local y `ff_Sabana_BF3` como
nueva ruta. Cada resultset se comparo mediante el esquema completo y una
huella SHA-256 independiente del orden de las filas.

| Resultset | Filas `_v2` | Filas `_BF3` | Columnas | Esquema igual | Datos iguales |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 - GMM | 1,674 | 1,674 | 44 | Si | Si |
| 2 - Vida | 1,115 | 1,115 | 36 | Si | Si |
| 3 - Opcionales | 1,723 | 1,723 | 41 | Si | Si |
| 4 - Mascotas | 34 | 34 | 22 | Si | Si |

Resultado integral: `OK`, sin diferencias de esquema ni datos.

## Ruta del sitio y diagnostico

El reporte 3 quedo con una sola ruta activa: `ff_Sabana_BF3`. La ejecucion
mediante `ff_orquestadorReportes`, el mismo punto de entrada que consume API
Reportes, devolvio:

| Resultset | Filas | Columnas |
| ---: | ---: | ---: |
| Metadatos | 1 | 4 |
| GMM | 1,674 | 44 |
| Vida | 1,115 | 36 |
| Opcionales | 1,723 | 41 |
| Mascotas | 34 | 22 |

El diagnostico `02_VALIDAR_SABANA_B3_EMPRESA_2185.sql` finalizo con cero
filas en estado `ALERTA`. Confirmo ademas:

- wrapper compuesto solamente por procedimientos BF3;
- errores de generacion no ocultos;
- una sola ruta activa y seis parametros sin duplicados;
- Gastos Funerarios en 215 filas;
- Plan de Pension en 255 filas;
- tres filas rechazadas/canceladas correctamente excluidas.
