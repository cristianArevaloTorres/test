# Publica solamente los archivos Java incluidos en esta entrega.
# No crea otra rama y no agrega SQL ni cambios locales ajenos.

$RepoApi = 'C:\repo\reportes\APIREPORTS'
$Rama = 'ReporteSabanaHomologacionOK-clean'

Set-Location -LiteralPath $RepoApi

if (-not (Test-Path -LiteralPath '.git')) {
    throw "Esta carpeta no es un clon Git: $RepoApi"
}

git switch $Rama
if ($LASTEXITCODE -ne 0) { throw "No se pudo cambiar a $Rama." }

# Para evitar mezclar un commit anterior, no debe haber archivos ya preparados.
$YaPreparados = @(git diff --cached --name-only)
if ($YaPreparados.Count -gt 0) {
    $YaPreparados
    throw 'Ya hay archivos en staging. Quitalos de staging y vuelve a ejecutar.'
}

# Baja los cambios remotos y conserva automaticamente los cambios locales.
git pull --rebase --autostash origin $Rama
if ($LASTEXITCODE -ne 0) {
    throw 'El pull encontro un conflicto. Ejecuta git status antes de continuar.'
}

$Archivos = @(
    'src/main/java/com/lockton/rpt/controllers/WSCobranzaController.java',
    'src/main/java/com/lockton/rpt/dao/JDBCCobranza.java',
    'src/main/java/com/lockton/rpt/services/CobranzaService.java',
    'src/main/java/com/lockton/rpt/services/impl/CobranzaServiceImpl.java',
    'src/test/java/com/lockton/rpt/dao/CobranzaWorkbookInspectorTest.java',
    'src/test/java/com/lockton/rpt/dao/JDBCCobranzaTest.java',
    'src/test/java/com/lockton/rpt/services/impl/CobranzaServiceImplTest.java',
    'src/test/java/com/lockton/rpt/util/ExcelHojaMultipleHomologacionTest.java',
    'src/test/java/com/lockton/rpt/util/SabanaWorkbookInspectorTest.java'
)

git add -- $Archivos
if ($LASTEXITCODE -ne 0) { throw 'No se pudieron preparar los archivos.' }

Write-Host 'Archivos que se incluiran en el commit:'
git diff --cached --name-status
git diff --cached --check
if ($LASTEXITCODE -ne 0) { throw 'Git encontro errores en el contenido preparado.' }

git commit -m 'Homologa incidencias de Sabana y Cobranza B3'
if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear el commit.' }

git push origin $Rama
if ($LASTEXITCODE -ne 0) { throw 'El push fue rechazado.' }

Write-Host "Push terminado en la misma rama: $Rama"
Write-Host 'No se agregaron SQL, binarios ni otros cambios locales.'
