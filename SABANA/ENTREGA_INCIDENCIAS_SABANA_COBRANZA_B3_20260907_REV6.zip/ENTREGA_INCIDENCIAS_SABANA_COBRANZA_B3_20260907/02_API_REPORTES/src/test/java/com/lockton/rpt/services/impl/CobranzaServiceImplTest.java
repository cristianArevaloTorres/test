package com.lockton.rpt.services.impl;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.lockton.rpt.dao.JDBCCobranza;
import com.lockton.rpt.repositories.CfgRptGenRepository;
import com.lockton.rpt.util.Correo;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

public class CobranzaServiceImplTest {

    @Test
    public void reconoceSolamenteLaRespuestaFuncionalSinDatos() {
        List<Object> respuesta = error(
                "No se encontraron coincidencias para los rangos o filtros seleccionados.",
                true);

        assertTrue(CobranzaServiceImpl.esRespuestaError(respuesta));
        assertTrue(CobranzaServiceImpl.esRespuestaSinDatos(respuesta));
    }

    @Test
    public void unaFallaDeExcelSeRegistraComoError() {
        List<Object> respuesta = error(
                "No fue posible escribir el archivo Excel.", false);

        assertTrue(CobranzaServiceImpl.esRespuestaError(respuesta));
        assertFalse(CobranzaServiceImpl.esRespuestaSinDatos(respuesta));
    }

    @Test
    public void consultaDeHistorialNoEsSolicitudDeGeneracion() {
        assertTrue(CobranzaServiceImpl.esConsultaListaArchivos(
                -1, "null", "null", -1, new ArrayList<>(),
                "null", "null", "null", "null", "null"));

        assertFalse(CobranzaServiceImpl.esConsultaListaArchivos(
                1, "2026-09-01", "2026-09-30", 1,
                java.util.Arrays.asList(3056), "Empresa 917",
                "Corporativo", "Administrador", "Empresa", "correo@qa.mx"));
    }

    @Test
    public void emptyNoSeInterpretaComoArchivoGenerado() {
        assertFalse(CobranzaServiceImpl.esNombreArchivoGenerado("empty"));
        assertFalse(CobranzaServiceImpl.esNombreArchivoGenerado(" null "));
        assertTrue(CobranzaServiceImpl.esNombreArchivoGenerado(
                "Cobranza20260904135200000.xlsx"));
    }

    @Test
    public void recuperaElNombreDelArchivoGenerado() {
        assertEquals("Cobranza20260907120000000.xlsx",
                CobranzaServiceImpl.nombreArchivoRespuesta(Arrays.asList(
                        "Cobranza20260907120000000.xlsx")));
        assertEquals("Cobranza",
                CobranzaServiceImpl.nombreArchivoRespuesta(error(
                        "Sin datos", true)));
    }

    @Test
    public void consultaSincronaTambienSolicitaNotificacion() {
        CobranzaServiceImpl service = new CobranzaServiceImpl();
        JDBCCobranza jdbc = mock(JDBCCobranza.class);
        CfgRptGenRepository config = mock(CfgRptGenRepository.class);
        Correo correo = mock(Correo.class);
        ReflectionTestUtils.setField(service, "jdbcCobranza", jdbc);
        ReflectionTestUtils.setField(service, "cfgRptGenRepository", config);
        ReflectionTestUtils.setField(service, "correoServ", correo);
        ReflectionTestUtils.setField(service, "rutaBase", "C:/reportes/");

        List<Integer> perfiles = Arrays.asList(3056);
        List<Object> result = Arrays.asList(
                "Cobranza20260908120000000.xlsx");
        when(jdbc.consultaCobranza(
                eq(2185), eq(1), eq("2026-09-01"), eq("2026-09-30"), eq(1),
                eq(perfiles), eq("Zurich"), eq(25), eq("Corporativo"),
                eq("Administrador"), eq("Zurich"), eq("qa@ejemplo.mx"),
                eq(4067), eq(0), eq("C:/reportes/")))
                .thenReturn(result);
        when(config.findCfgRptValorByCfgRptClave("asunto_correo"))
                .thenReturn(Optional.of("Reporte {0}"));
        when(config.findCfgRptValorByCfgRptClave("cuerpo_correo"))
                .thenReturn(Optional.of("{1} {2} {3} {5}"));

        service.consultaCobranza(
                2185, 1, "2026-09-01", "2026-09-30", 1,
                perfiles, "Zurich", 25, "Corporativo", "Administrador",
                "Zurich", "qa@ejemplo.mx", 4067, 0, 77,
                "Bearer token-prueba");

        verify(correo).EnviarCorreo(
                eq(77), eq(2185), eq("Administrador"), eq("Zurich"),
                eq("qa@ejemplo.mx"), eq(true),
                eq("Cobranza20260908120000000.xlsx"),
                eq("{1} {2} {3} {5}"), eq("Reporte {0}"), eq(""),
                eq("Bearer token-prueba"), isNull());
    }

    @Test
    public void solicitaNotificacionAlTerminarLaGeneracionAsincrona() {
        CobranzaServiceImpl service = new CobranzaServiceImpl();
        CfgRptGenRepository config = mock(CfgRptGenRepository.class);
        Correo correo = mock(Correo.class);
        ReflectionTestUtils.setField(service, "cfgRptGenRepository", config);
        ReflectionTestUtils.setField(service, "correoServ", correo);

        when(config.findCfgRptValorByCfgRptClave("asunto_correo"))
                .thenReturn(Optional.of("Reporte {0}"));
        when(config.findCfgRptValorByCfgRptClave("cuerpo_correo"))
                .thenReturn(Optional.of("{1} {2} {3} {5}"));

        List<Object> result = Arrays.asList(
                "Cobranza20260907120000000.xlsx");
        service.notificarResultado(77, 2185, "Administrador", "Zurich",
                "qa@ejemplo.mx", result,
                "C:/reportes/2185/Cobranza/Cobranza20260907120000000.xlsx",
                "", "Bearer token-prueba");

        verify(correo).EnviarCorreo(
                eq(77), eq(2185), eq("Administrador"), eq("Zurich"),
                eq("qa@ejemplo.mx"), eq(true),
                eq("Cobranza20260907120000000.xlsx"),
                eq("{1} {2} {3} {5}"), eq("Reporte {0}"), eq(""),
                eq("Bearer token-prueba"), isNull());
    }

    private static List<Object> error(String mensaje, boolean sinDatos) {
        Map<String, Object> detalle = new HashMap<>();
        detalle.put("error", true);
        detalle.put("sinDatos", sinDatos);
        detalle.put("mssError", mensaje);
        List<Object> result = new ArrayList<>();
        result.add(detalle);
        return result;
    }
}
