package com.lockton.rpt.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.util.LinkedCaseInsensitiveMap;

public class JDBCCobranzaTest {

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void normalizaCacheAlContratoDeConsultaDirecta() {
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                new ArrayList<>();

        ArrayList<LinkedCaseInsensitiveMap> informacion = new ArrayList<>();
        informacion.add(row(
                "NombrePestana", "Información",
                "grupo", "Informacion",
                "Empresa", "Empresa QA"));
        resultsets.add(informacion);

        ArrayList<LinkedCaseInsensitiveMap> concentrada = new ArrayList<>();
        concentrada.add(row(
                "NombrePestana", "Concentrada",
                "grupo", "Concentrada",
                "empresa", "Empresa QA",
                "NumEMpleado", "100"));
        resultsets.add(concentrada);

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> normalizados =
                JDBCCobranza.normalizarContratoCobranza(resultsets);

        assertEquals(1, normalizados.size());
        assertEquals(2, normalizados.get(0).get(0).size());
        assertEquals("Empresa QA", normalizados.get(0).get(0).get("empresa"));
        assertEquals("100", normalizados.get(0).get(0).get("NumEMpleado"));
        assertFalse(normalizados.get(0).get(0).containsKey("NombrePestana"));
        assertFalse(normalizados.get(0).get(0).containsKey("grupo"));
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void conservaSinCambiosElContratoDeConsultaDirecta() {
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                new ArrayList<>();
        ArrayList<LinkedCaseInsensitiveMap> desglosada = new ArrayList<>();
        desglosada.add(row("EMPRESA", 186, "NUMEMPLEADO", "100", "CVEP", "GMM"));
        resultsets.add(desglosada);

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> normalizados =
                JDBCCobranza.normalizarContratoCobranza(resultsets);

        assertEquals(resultsets, normalizados);
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void aceptaResultsetsQueNoSonArrayList() {
        LinkedCaseInsensitiveMap row = row(
                "empresa", "Empresa QA", "NumEMpleado", "100");
        Map<String, Object> resultado = new LinkedHashMap<>();
        resultado.put("#result-set-1", new LinkedList<>(Arrays.asList(row)));

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                JDBCCobranza.extraerResultsets(resultado);

        assertEquals(1, resultsets.size());
        assertEquals("100", resultsets.get(0).get(0).get("NumEMpleado"));
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void convierteMapGenericoAlContratoCaseInsensitive() {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("EMPRESA", "Empresa QA");
        row.put("NUMEMPLEADO", "200");
        Map<String, Object> resultado = new LinkedHashMap<>();
        resultado.put("#result-set-1", Arrays.asList(row));

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                JDBCCobranza.extraerResultsets(resultado);

        assertEquals("200", resultsets.get(0).get(0).get("numempleado"));
    }

    @Test
    public void ignoraConfiguracionAnclaQueNoCubreTodoElResultset() {
        Map<String, String> parcial = new LinkedHashMap<>();
        parcial.put("numempleado", "Número empleado");

        assertFalse(JDBCCobranza.configuracionColumnasCompleta(
                parcial, Arrays.asList("NumEMpleado", "MontoGMM")));
    }

    @Test
    public void aceptaConfiguracionCompletaSinImportarMayusculas() {
        Map<String, String> completa = new LinkedHashMap<>();
        completa.put("numempleado", "Número empleado");
        completa.put("montogmm", "Monto GMM");

        assertEquals(true, JDBCCobranza.configuracionColumnasCompleta(
                completa, Arrays.asList("NumEMpleado", "MontoGMM")));
    }

    @Test
    public void compactaFechaComoLaPortadaB2() {
        assertEquals("20260831", JDBCCobranza.fechaCompacta("2026-08-31 13:19"));
        assertEquals("20260831", JDBCCobranza.fechaCompacta("20260831"));
        assertEquals("", JDBCCobranza.fechaCompacta(null));
    }

    @Test
    public void portadaUsaElRangoRecibidoEnLosFiltros() {
        assertEquals("15/07/2026 al 21/08/2026",
                JDBCCobranza.rangoFechasPortada(
                        "2026-07-15 00:00", "2026-08-21 23:59"));
        assertEquals("01/09/2025 al 01/09/2026",
                JDBCCobranza.rangoFechasPortada(
                        "2025-09-01", "2026-09-01"));
    }

    @Test
    public void distingueConceptoDelNombreDelPlanEnTotalesB2() {
        String[] base = {"Clave de plan", "Clave de cobertura",
                "Nombre del plan", "Importe", "Prima", "Empresa",
                "Empleado", "Excedentes", "Real", "Sobrante"};

        String[] concepto = JDBCCobranza.ajustarCabeceraTotal(
                "Total por coberturas", base,
                Arrays.asList("CVEP", "CVEPO", "Concepto", "Importe",
                        "Prima", "Empresa", "Empleado", "Excedentes",
                        "Real", "Sobrante"), false);

        assertEquals("Concepto", concepto[2]);
        assertEquals("Nombre del plan", base[2]);
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void detectaElBloqueRealDeConceptosPorSuOrdinal() {
        ArrayList<LinkedCaseInsensitiveMap> filas = new ArrayList<>();
        filas.add(row("CVEP", 10002, "CVEPO", 9,
                "PlanD", "Prima Neta Vida", "ImpPer", 1));

        assertTrue(JDBCCobranza.esBloqueConceptos((List) filas));
    }

    @Test
    public void convierteBitsDeSqlServerSinCastearBooleanANumber() {
        assertEquals(1, JDBCCobranza.toInt(Boolean.TRUE));
        assertEquals(0, JDBCCobranza.toInt(Boolean.FALSE));
        assertEquals(1, JDBCCobranza.toInt(Integer.valueOf(1)));
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void colocaElTotalDeConcentradaDespuesDeLosEmpleados() {
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                new ArrayList<>();
        ArrayList<LinkedCaseInsensitiveMap> concentrada = new ArrayList<>();
        concentrada.add(row("empresa", null, "NumEMpleado", "TOTALES: "));
        concentrada.add(row("empresa", "ZURICH", "NumEMpleado", "70175141"));
        resultsets.add(concentrada);

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> normalizados =
                JDBCCobranza.normalizarContratoCobranza(resultsets);

        assertEquals("70175141",
                normalizados.get(0).get(0).get("NumEMpleado"));
        assertEquals("TOTALES: ",
                normalizados.get(0).get(1).get("NumEMpleado"));
    }

    @Test
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void respetaElOrdenNumericoDeLosConceptosB2() {
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> resultsets =
                new ArrayList<>();
        ArrayList<LinkedCaseInsensitiveMap> conceptos = new ArrayList<>();
        conceptos.add(row("CVEP", 10002, "CVEPO", 99,
                "PlanD", "IVA", "ImpPer", 3));
        conceptos.add(row("CVEP", 10002, "CVEPO", 99,
                "PlanD", "Derecho de póliza", "ImpPer", 2));
        conceptos.add(row("CVEP", 10002, "CVEPO", 99,
                "PlanD", "Prima Total", "ImpPer", 4));
        conceptos.add(row("CVEP", 10002, "CVEPO", 99,
                "PlanD", "Prima Neta", "ImpPer", 1));
        resultsets.add(conceptos);

        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> normalizados =
                JDBCCobranza.normalizarContratoCobranza(resultsets);

        assertEquals("Prima Neta", normalizados.get(0).get(0).get("PlanD"));
        assertEquals("Derecho de póliza", normalizados.get(0).get(1).get("PlanD"));
        assertEquals("IVA", normalizados.get(0).get(2).get("PlanD"));
        assertEquals("Prima Total", normalizados.get(0).get(3).get("PlanD"));
    }

    @Test
    public void identificadoresNoRecibenFormatoMoneda() {
        assertEquals(0, JDBCCobranza.resolverFormatoCobranza(
                "empresa", "Empresa", null));
        assertEquals(0, JDBCCobranza.resolverFormatoCobranza(
                "NumEMpleado", "Número empleado", "00123"));
        assertEquals(1, JDBCCobranza.resolverFormatoCobranza(
                "CveEmpl", "Id", null));
        assertEquals(1, JDBCCobranza.resolverFormatoCobranza(
                "Edad", "Edad", null));
        assertEquals(1, JDBCCobranza.resolverFormatoCobranza(
                "NumOficina", "Número Oficina", null));
        assertEquals(2, JDBCCobranza.resolverFormatoCobranza(
                "CostoEmpresa", "Costo empresa", new java.math.BigDecimal("1.00")));
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static LinkedCaseInsensitiveMap row(Object... values) {
        LinkedCaseInsensitiveMap row = new LinkedCaseInsensitiveMap();
        for (int i = 0; i < values.length; i += 2) {
            row.put(String.valueOf(values[i]), values[i + 1]);
        }
        return row;
    }
}
