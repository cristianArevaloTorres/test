/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lockton.WSBeFlex.DAO;

import com.lockton.WSBeFlex.Constantes;
import com.lockton.WSBeFlex.POJO.Especiales.DispersionBanwire;
import com.lockton.WSBeFlex.POJO.Especiales.EnvioCorreoUnificadoRequest;
import com.lockton.WSBeFlex.POJO.Especiales.LiquidacionesBanwire;
import com.lockton.WSBeFlex.POJO.Especiales.TransaccionesBanwire;
import com.lockton.WSBeFlex.Services.EnvioCorreoUnificadoService;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections4.ListUtils;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.crypt.EncryptionMode;
import org.apache.poi.poifs.crypt.Encryptor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.SheetUtil;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;



/**
 *
 * @author Moises Flores
 */
@Repository

public class JDBCFfCobranza implements FfCobranzaDAO {

    private static final String PROCEDIMIENTO_COBRANZA = "ReporteCobranzaConcentrada_BF3_Cache";

    
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    EnvioCorreoUnificadoService envioCorreoUnificadoService;

    @SuppressWarnings("unchecked")

    @Override
    public List<Object> consultaCobranza(int idEmpresa, int idSolTipo, String FecIni, String FecFin, int idVencida, int[] IdsPerfil, String empresa, int idCorporativo, 
        String nomCorp, String nomAdm, String nomEmp, String email, int idVigencia, int bandera) {

        String pathLog = Constantes.DOCUMENTO_EMPRESA + idEmpresa + "/Cobranza/";
        Date today = new Date();
        SimpleDateFormat formatoArchivo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String fechaIniProceso = formatoArchivo.format(today);
        try {
            if (idSolTipo == -1 && "null".equals(FecIni) && "null".equals(FecFin) && idVencida == -1 && IdsPerfil.length == 0 && "null".equals(empresa)
                    && "null".equals(nomCorp) && "null".equals(nomAdm) && "null".equals(nomEmp) && "null".equals(email)) {
                return getListArchivosVigenciaActivaRenovada(idEmpresa, pathLog, idVigencia);
            }
            escribirArchivo("Inicia cobranza ....................................................................................................................", pathLog);
            if ("null".equals(FecIni)) {
                FecIni = getFechaInicioVigencia(idVigencia);
                escribirArchivo("El parametro fecha_Inicio es tomada de la vigencia activa. fecha_Inicio = " + FecIni, pathLog);
            }
            if ("null".equals(FecFin)) {
                FecFin = getFechaFinalVigencia(idVigencia);
                escribirArchivo("El parametro fecha_Final es tomada de la vigencia activa. fecha_Final = " + FecFin, pathLog);
            }

            SQLServerDataTable dtIdsPerfil = new SQLServerDataTable();
            dtIdsPerfil.addColumnMetadata("IdTipoNotificacionCorreo", java.sql.Types.INTEGER);
            String paramsIdsPerfil = "[";
            for (int i = 0; i < IdsPerfil.length; i++) {
                int idPerfil = IdsPerfil[i];
                dtIdsPerfil.addRow(idPerfil);
                if (i == IdsPerfil.length - 1) {
                    paramsIdsPerfil += idPerfil;
                } else {
                    paramsIdsPerfil += idPerfil + ",";
                }
            }
            paramsIdsPerfil += "]";

            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(PROCEDIMIENTO_COBRANZA);
            Map<String, Object> inParamMap = new HashMap<>();
            inParamMap.put("idEmpresa", idEmpresa);
            inParamMap.put("idSolTipo", idSolTipo);
            inParamMap.put("FecIni", FecIni);
            inParamMap.put("FecFin", FecFin);
            inParamMap.put("idVencida", idVencida);
            inParamMap.put("IdPerfil", dtIdsPerfil);
            inParamMap.put("idVIgencia", idVigencia);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            String strParamentros = idEmpresa + ", " + idSolTipo + ", " + FecIni + ", " + FecFin + ", " + idVencida + ", " + paramsIdsPerfil;
            escribirArchivo("Se invoca el stored " + PROCEDIMIENTO_COBRANZA + " con los parametros (" + strParamentros + ")", pathLog);
            Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
            List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
            ArrayList<ArrayList<LinkedCaseInsensitiveMap>> lista = new ArrayList<>();
            listSP.stream().filter((object) -> (object instanceof ArrayList)).forEachOrdered((object) -> {
                ArrayList listObject = (ArrayList) object;
                if (listObject.size() > 0) {
                    lista.add((ArrayList) object);
                }
            });

            boolean resul = false;
            for (int i = 0; i < lista.size(); ++i) {
                if (lista.get(i).size() > 1) {
                    resul = true;
                    break;
                }
            }

            if (resul == true) {
                resul = false;
                escribirArchivo("Termina la ejecucion del stored con un total de " + lista.size() + " tablas", pathLog);
                
                return generarExcel(lista, empresa, idEmpresa, pathLog, FecIni, FecFin, idCorporativo, nomCorp, nomAdm, nomEmp, email, fechaIniProceso, idVigencia, bandera);

            } else {
                enviarCorreo(idEmpresa, 0, nomCorp, nomAdm, nomEmp, email, "No se encontraron coincidencias para los rangos o filtros seleccionados.", fechaIniProceso, pathLog);
                escribirArchivo("Se presenta este error al momento de generar la cobranza: No se encontraron coincidencias para los rangos o filtros seleccionados.", pathLog);
                List<Object> arrayError = new ArrayList<>();
                Map<String, Object> json = new HashMap<>();
                json.put("error", true);
                json.put("mssError", getCausa("No se encontraron coincidencias para los rangos o filtros seleccionados.", 1));
                arrayError.add(json);
                
                return arrayError;
            }
        } catch (Exception e) {
            enviarCorreo(idEmpresa, 0, nomCorp, nomAdm, nomEmp, email, getCausa(e.getMessage(), 1), fechaIniProceso, pathLog);
            escribirArchivo("Se presenta este error al momento de generar la cobranza: " + getCausa(e.getMessage(), 1) + "\n\r" + e.getStackTrace(), pathLog);
            List<Object> arrayError = new ArrayList<>();
            Map<String, Object> json = new HashMap<>();
            json.put("error", true);
            json.put("mssError", getCausa(e.getMessage(), 1));
            arrayError.add(json);
            
            
            return arrayError;
        }
    }

    public int getCadidadDePagos(int idCorporativo, int idEmpresa) {
        int periodiciad = getPeriocidad(idCorporativo);
        int vigencia = getVigenciaActiva(idEmpresa);
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetVigenciaCalendarioXVigenciaPeriodicidad");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("IdVigencia", vigencia);
        inParamMap.put("Periodiciad", periodiciad);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        ArrayList<ArrayList<LinkedCaseInsensitiveMap>> listLinksLinks = new ArrayList<>();
        listSP.stream().filter((object) -> (object instanceof ArrayList)).forEachOrdered((object) -> {
            listLinksLinks.add((ArrayList) object);
        });
        ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listLinksLinks.get(0);
        LinkedCaseInsensitiveMap instanciaDeQuery = listLinks.get(0);
        Object[] v = instanciaDeQuery.values().toArray();
        try {
            int cantidad = Integer.parseInt(v[0].toString());
            
            return cantidad;
        } catch (Exception e) {
            
            return 0;
        }
    }

    @Override
    public int getPeriocidad(int idCorporativo) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_ObtenerConfiguracionEnvio");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("IdCorporativo", idCorporativo);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        try {
            List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
            ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            LinkedCaseInsensitiveMap instanciaDeQuery = listLinks.get(0);
            Object[] v = instanciaDeQuery.values().toArray();
            int periocidad = Integer.parseInt(v[v.length - 2].toString());
            
            return periocidad;
        } catch (Exception e) {
            
            return -1;
        }
    }

    public String getStringPeriocidad(int index) {
        String[] periodos = new String[]{"NoEspecificado", "Semanal", "Quincenal", "Mensual", "Trimestral", "Semestral"};
        return periodos[index].toUpperCase();
    }

    public List<Object> getListArchivosVigenciaActivaRenovada(int idEmpresa, String pathLog, int idVigencia) {
        try {
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("getFilesVigenciaActivaRenovadaXEmpresa");
            Map<String, Object> inParamMap = new HashMap<>();
            inParamMap.put("idEmpresa", idEmpresa);
            inParamMap.put("idVigencia", idVigencia);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
            List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
            ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            ArrayList<String> aux = new ArrayList();
            for (LinkedCaseInsensitiveMap l : listLinks) {
                String value = (String) l.values().toArray()[0];
                aux.add(value);
            }
            List<Object> list = new ArrayList<>(aux);
            
            return list;
        } catch (Exception e) {
            escribirArchivo("Se presenta este error al momento de generar la cobranza: " + getCausa(e.getMessage(), 1) + "\n\r" + e.getStackTrace(), pathLog);
            List<Object> arrayError = new ArrayList<>();
            Map<String, Object> json = new HashMap<>();
            json.put("error", true);
            json.put("mssError", getCausa(e.getMessage(), 1));
            arrayError.add(json);
            
            return arrayError;
        }
    }

    public String getRazonSocial(int idEmpresa, String empresa, int idVigencia) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("getFilesVigenciaActivaRenovadaXEmpresa");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("idEmpresa", idEmpresa);
        inParamMap.put("idVigencia", idVigencia);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
        try {
            String razon = (String) listLinks.get(0).values().toArray()[2];
            
            return razon;
        } catch (Exception e) {
            
            return empresa;
        }
    }

    class Periodicidad {

        String periodicidad;
        int catidadPagos;

        public Periodicidad() {
            periodicidad = "";
            catidadPagos = 0;
        }
    }

    private Periodicidad getPeriodicidadPagos(int idVigencia) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("getPeriodicidadPagos");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("IdVigencia", idVigencia);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        Periodicidad periodicidad = new Periodicidad();
        try {
            ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            periodicidad.periodicidad = listLinks.get(0).get("PPNombre").toString();
            periodicidad.catidadPagos = Integer.parseInt(listLinks.get(0).get("PPCantidadPagos").toString());
            
            
            return periodicidad;
        } catch (Exception e) {
            
            return periodicidad;
        }
    }

    @Override
    public List<Object> getPeriodicidadDePagos(int idVigencia) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("getPeriodicidadPagos");

        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("IdVigencia", idVigencia);

        SqlParameterSource in = new MapSqlParameterSource(inParamMap);

        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        return listSP;
    }

    @Override
    public int getVigenciaActiva(int idEmpresa) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_get2VigenciasPorCorporativo");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("IdEmpresa", idEmpresa);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        try {
            List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
            ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            LinkedCaseInsensitiveMap instanciaDeQuery = listLinks.get(0);
            Object[] v = instanciaDeQuery.values().toArray();
            int vigencia = Integer.parseInt(v[0].toString());
            
            return vigencia;
        } catch (Exception e) {
            
            return -1;
        }
    }

    @Override
    public String getFechaInicioVigencia(int vigencia) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetVigenciaXId");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("IdVigencia", vigencia);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
        LinkedCaseInsensitiveMap out = listLinks.get(0);
        Timestamp outFechaIni = (Timestamp) out.get("VIVigenciaIni");
        Date date = new Date(outFechaIni.getTime());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String fechaIni = format.format(date);
        return fechaIni;
    }

    @Override
    public String getFechaFinalVigencia(int vigencia) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetVigenciaXId");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("IdVigencia", vigencia);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
        LinkedCaseInsensitiveMap out = listLinks.get(0);
        Timestamp outFechaFin = (Timestamp) out.get("VIVigenciaFin");
        Date date = new Date(outFechaFin.getTime());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String fechaFin = format.format(date);
        return fechaFin;
    }

    @Override
    public String getFechaInicioEnrollment(int vigencia) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetVigenciaXId");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("IdVigencia", vigencia);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
        LinkedCaseInsensitiveMap out = listLinks.get(0);
        Timestamp outFechaEnroll = (Timestamp) out.get("VIEnrollmentIni");
        Date date = new Date(outFechaEnroll.getTime());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String fechaEnroll = format.format(date);
        return fechaEnroll;
    }

    public int insertArchivoCobranza(int idEmpresa, String FecIni, String FecFin, int vigencia, String nombreArch, Date today, String pathLog) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyy-MM-dd HH:mm:ss:SSS");
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("ff_IInsertaCobranzaEncabezado");
        Map<String, Object> inParamMap = new HashMap<String, Object>();

        inParamMap.put("COIdEmpresa", idEmpresa);
        inParamMap.put("COIdVigencia", vigencia);
        inParamMap.put("COFechaIni", FecIni);
        inParamMap.put("COFechaFin", FecFin);
        inParamMap.put("CONombreRep", nombreArch);
        inParamMap.put("COFecHoraGen", formatoFecha.format(today));
        inParamMap.put("Usuario", null);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);

        escribirArchivo("Se invoca el stored ff_IInsertaCobranzaEncabezado con los parametros (" + idEmpresa + ", " + vigencia + ", " + FecIni + ", " + FecFin + ", " + nombreArch + ", " + formatoFecha.format(today) + ", " + null + ")", pathLog);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());

        if (!listSP.isEmpty()) {
            return 1;
        }
        return 0;
    }

    public List<Integer> OrdenarLista(ArrayList<ArrayList<LinkedCaseInsensitiveMap>> lista) {
        List<Integer> posiciones = new ArrayList<Integer>();
        int cont = 0;
        int cont2 = 0;

        for (List<LinkedCaseInsensitiveMap> arrayList : lista) {
            Set setKeys = arrayList.get(0).keySet();
            ArrayList<String> keys = new ArrayList(setKeys);
            String key = keys.get(0);
            if (null == key) {
                cont++;
            } else {
                switch (key) {
                    case "empresa":
                    case "NumEMpleado":
                        cont++;
                        break;
                    case "EMPRESA":
                    case "NUMEMPLEADO":
                        cont++;
                        break;
                    case "CVEP":
                    case "CVEPO":
                        posiciones.add(cont2);//insertar al principio el último valor
                        cont++;
                        break;
                    case "cvep":
                    case "cvepo":
                        cont++;
                        break;
                    default:
                        cont++;
                        break;
                }
            }
            cont2++;
        }
        return posiciones;
    }


    public static Map<String, List<Map<String, Object>>> filtrarTransacciones(List<Object> lista) {
        Map<String, List<Map<String, Object>>> arreglosPorProveedor = new HashMap<>();
    
        for (Object obj : lista) {
            if (obj instanceof Map) {
                Map<String, Object> mapa = (Map<String, Object>) obj;
                if (mapa.containsKey("ProveedorTransaccion")) {
                    String nombreProveedor = (String) mapa.get("ProveedorTransaccion");
                    if (nombreProveedor != null && !nombreProveedor.isEmpty()) {
                        List<Map<String, Object>> arregloPorProveedor = arreglosPorProveedor.computeIfAbsent(nombreProveedor, k -> new ArrayList<>());
                        arregloPorProveedor.add(mapa);
                    }
                }
            }
        }
        return arreglosPorProveedor;
    }

    public static Map<String, List<Map<String, Object>>> filtrarLiquidaciones(List<Object> lista) {
        Map<String, List<Map<String, Object>>> arreglosPorProveedor = new HashMap<>();
    
        for (Object obj : lista) {
            if (obj instanceof Map) {
                Map<String, Object> mapa = (Map<String, Object>) obj;
                if (mapa.containsKey("ProveedorLiquidacion")) {
                    String nombreProveedor = (String) mapa.get("ProveedorLiquidacion");
                    if (nombreProveedor != null && !nombreProveedor.isEmpty()) {
                        List<Map<String, Object>> arregloPorProveedor = arreglosPorProveedor.computeIfAbsent(nombreProveedor, k -> new ArrayList<>());
                        arregloPorProveedor.add(mapa);
                    }
                }
            }
        }
        return arreglosPorProveedor;
    }
    


    public static Map<String, List<Map<String, Object>>> filtrarDispersiones(List<Object> lista) {
        Map<String, List<Map<String, Object>>> arreglosPorProveedor = new HashMap<>();
    
        for (Object obj : lista) {
            if (obj instanceof Map) {
                Map<String, Object> mapa = (Map<String, Object>) obj;
                if (mapa.containsKey("ProveedorDispersion")) {
                    String nombreProveedor = (String) mapa.get("ProveedorDispersion");
                    if (nombreProveedor != null && !nombreProveedor.isEmpty()) {
                        List<Map<String, Object>> arregloPorProveedor = arreglosPorProveedor.computeIfAbsent(nombreProveedor, k -> new ArrayList<>());
                        arregloPorProveedor.add(mapa);
                    }
                }
            }
        }
    
        return arreglosPorProveedor;
    }

    private Map<String, Object> mapearTransacciones(LinkedCaseInsensitiveMap columna) {
        Map<String, Object> rowData = new HashMap<>();
    
        // Acceder a los valores por el nombre de las columnas
        Object idTransaccion = columna.get("idtrans");
        Object fechaPago = columna.get("fechadepago");
        Object montoProcesado = columna.get("montoprocesado");
        Object comisionBanwire = columna.get("comisionbanwire");
        Object iva = columna.get("iva");
        Object comisionFijaSinIva = columna.get("comisionfijasiniva");
        Object ivaComisionFija = columna.get("ivacomisionfija");
        Object comisionMsi = columna.get("comisionmsi");
        Object ivaMsi = columna.get("ivsmsi");
        Object totalComision = columna.get("totalcomision");
        Object tasa = columna.get("tasa");
        Object civa = columna.get("civa");
        Object liquidacion = columna.get("liquidacion");
        Object terminal = columna.get("terminal");
        Object codigoAut = columna.get("codigoaut");
        Object referencia = columna.get("referencia");
        Object extRefCliente = columna.get("extrefcliente");
        Object card = columna.get("card");
        Object telefono = columna.get("telefono");
        Object mail = columna.get("mail");
        Object comercio = columna.get("comercio");
        Object mesesFinanciados = columna.get("mesesfinanciados");
        Object proveedorTransaccion = columna.get("ProveedorTransaccion");
    
        // Agregar los valores mapeados al mapa de datos
        rowData.put("idtrans", idTransaccion);
        rowData.put("fechadepago", fechaPago);
        rowData.put("montoprocesado", montoProcesado);
        rowData.put("comisionbanwire", comisionBanwire);
        rowData.put("iva", iva);
        rowData.put("comisionfijasiniva", comisionFijaSinIva);
        rowData.put("ivacomisionfija", ivaComisionFija);
        rowData.put("comisionmsi", comisionMsi);
        rowData.put("ivsmsi", ivaMsi);
        rowData.put("totalcomision", totalComision);
        rowData.put("tasa", tasa);
        rowData.put("civa", civa);
        rowData.put("liquidacion", liquidacion);
        rowData.put("terminal", terminal);
        rowData.put("codigoAut", codigoAut);
        rowData.put("referencia", referencia);
        rowData.put("extrefcliente", extRefCliente);
        rowData.put("card", card);
        rowData.put("telefono", telefono);
        rowData.put("mail", mail);
        rowData.put("comercio", comercio);
        rowData.put("mesesfinanciados", mesesFinanciados);
        rowData.put("ProveedorTransaccion", proveedorTransaccion);
    
        return rowData;
    }
    private Map<String, Object> mapearLiquidaciones(LinkedCaseInsensitiveMap columna) {
        Map<String, Object> rowData = new HashMap<>();
    
        Object idTransaccion = columna.get("idTransaccion");
        Object montoTransaccion = columna.get("MontoTransaccion");
        Object num = columna.get("#");
        Object estatus = columna.get("Estatus");
        Object clave = columna.get("Clave");
        Object nombreBeneficiario = columna.get("NombreBeneficiario");
        Object monto = columna.get("Monto");
        Object conceptoPago = columna.get("ConceptoPago");
        Object proveedorLiquidacion = columna.get("ProveedorLiquidacion");
    
        rowData.put("idTransaccion", idTransaccion);
        rowData.put("MontoTransaccion", montoTransaccion);
        rowData.put("#", num);
        rowData.put("Estatus", estatus);
        rowData.put("Clave", clave);
        rowData.put("NombreBeneficiario", nombreBeneficiario);
        rowData.put("Monto", monto);
        rowData.put("ConceptoPago", conceptoPago);
        rowData.put("ProveedorLiquidacion", proveedorLiquidacion);
    
        return rowData;
    }
        
    private Map<String, Object> mapearDispersiones(LinkedCaseInsensitiveMap columna) {
        Map<String, Object> rowData = new HashMap<>();

        Object numEmpleado = columna.get("numEmpleado");
        Object conceptoDispersion = columna.get("ConceptoDispersion");
        Object monto = columna.get("monto");
        Object cuenta = columna.get("cuenta");
        Object proveedorDispersion = columna.get("ProveedorDispersion");
    
        rowData.put("numEmpleado", numEmpleado);
        rowData.put("ConceptoDispersion", conceptoDispersion);
        rowData.put("monto", monto);
        rowData.put("cuenta", cuenta);
        rowData.put("ProveedorDispersion", proveedorDispersion);
    
        return rowData;
    }
    

    @SuppressWarnings("unchecked")
    public List<Object> generarExcel(ArrayList<ArrayList<LinkedCaseInsensitiveMap>> lista, String empresa, int idEmpresa, String ruta, String FecIni, String FecFin, int idCorporativo, String nomCorp, String nomAdm, 
        String nomEmp, String email, String fechaIniProc, int idVigencia, int bandera) {
        
        String pathLog = ruta;
        try {
            Date today = new Date();
            SimpleDateFormat formatoArchivo = new SimpleDateFormat("yyyyMMddHHmm");
            String strFecha = formatoArchivo.format(today);
            String nomArch = "Cobranza" + strFecha + ".xlsx";

            Workbook libro = new SXSSFWorkbook();
            getHojaInfo(libro, idEmpresa, empresa, FecIni, FecFin, idVigencia);

            escribirArchivo("Se establece formato para las celdas", pathLog);

           
            List<Object> datosLiquidaciones = new ArrayList<>();
            List<Object> datosTransaccion = new ArrayList<>();
            List<Object> datosDispersion = new ArrayList<>();

            //Liquidaciones
            for (ArrayList<LinkedCaseInsensitiveMap> fila : lista) {
                for (LinkedCaseInsensitiveMap mapa : fila) {
                    Map<String, Object> rowData = mapearLiquidaciones(mapa);
                    datosLiquidaciones.add(rowData);
                }
            }

            //Transacciones
            for (ArrayList<LinkedCaseInsensitiveMap> fila : lista) {
                for (LinkedCaseInsensitiveMap mapa : fila) {
                    Map<String, Object> rowData = mapearTransacciones(mapa);
                    datosTransaccion.add(rowData);
                }
            }
            //Dispersiones
            for (ArrayList<LinkedCaseInsensitiveMap> fila : lista) {
                for (LinkedCaseInsensitiveMap mapa : fila) {
                    Map<String, Object> rowData = mapearDispersiones(mapa);
                    datosDispersion.add(rowData);
                }
            }

            Map<String, List<Map<String, Object>>> liquidaciones_filtradas = filtrarLiquidaciones(datosLiquidaciones);
            Map<String, List<Map<String, Object>>> transacciones_filtradas = filtrarTransacciones(datosTransaccion);
            Map<String, List<Map<String, Object>>> dispersiones_filtradas = filtrarDispersiones(datosDispersion);

            System.out.println("\n\n\n\n datosDispersion: \n"+datosDispersion+"\n\n\n\n");
            System.out.println("\n\n\n\n dispersiones_filtradas: \n"+dispersiones_filtradas+"\n\n\n\n");
            

            Sheet hojaConcentrada = libro.createSheet("Concentrada");
            Sheet hojaDesglosada = libro.createSheet("Desglosada");
            Sheet hojaTotalPorCoberturas = libro.createSheet("Total por coberturas");
            Sheet hojaPlanesParentesco = libro.createSheet("Planes_Parentesco");
            
            int ic = 0;
            int id = 0;
            int it = 0;
            int ip = 0;
            int iex = 1;

            CellStyle styleCabezera = libro.createCellStyle();
            CellStyle styleContenido = libro.createCellStyle();
            CellStyle styleDinero = libro.createCellStyle();
            CellStyle styleFecha = libro.createCellStyle();
            CellStyle styleEntero = libro.createCellStyle();
            CellStyle styleTexto = libro.createCellStyle();

            Font fontCabezera = libro.createFont();
            Font fontContenido = libro.createFont();
            Font fontDinero = libro.createFont();

            fontCabezera.setFontName("Calibri");
            fontCabezera.setBold(true);
            fontCabezera.setColor(IndexedColors.WHITE.getIndex());
            fontCabezera.setFontHeightInPoints((short) 11);
            styleCabezera.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            styleCabezera.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.index);
            styleCabezera.setFont(fontCabezera);
            styleCabezera.setVerticalAlignment(VerticalAlignment.CENTER);
            styleCabezera.setAlignment(HorizontalAlignment.CENTER);

            fontContenido.setFontName("Calibri");
            fontContenido.setColor(IndexedColors.BLACK.getIndex());
            fontContenido.setFontHeightInPoints((short) 11);
            styleContenido.setFont(fontContenido);
            styleContenido.setVerticalAlignment(VerticalAlignment.CENTER);
            styleContenido.setAlignment(HorizontalAlignment.LEFT);

            fontDinero.setFontName("Calibri");
            fontDinero.setColor(IndexedColors.BLACK.getIndex());
            fontDinero.setFontHeightInPoints((short) 11);
            styleDinero.setFont(fontDinero);
            styleDinero.setVerticalAlignment(VerticalAlignment.CENTER);
            styleDinero.setAlignment(HorizontalAlignment.LEFT);
            styleDinero.setDataFormat((short) 8);

            CellStyle estiloMoneda = libro.createCellStyle();
            DataFormat formato = libro.createDataFormat();
            estiloMoneda.setDataFormat(formato.getFormat("\"$\"#,##0.00"));

            if(bandera == 1){
                hojas_transacciones(libro, bandera, estiloMoneda, styleCabezera, transacciones_filtradas);
                hojas_liquidaciones(libro, bandera, estiloMoneda, styleCabezera, liquidaciones_filtradas);
                hojas_dispersion(libro, bandera, estiloMoneda, styleCabezera, dispersiones_filtradas);                
            }

            CreationHelper createHelper = libro.getCreationHelper();
            styleFecha.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy"));
            styleFecha.setAlignment(CellStyle.ALIGN_RIGHT);

            styleEntero.setDataFormat(createHelper.createDataFormat().getFormat("0"));
            styleEntero.setAlignment(CellStyle.ALIGN_RIGHT);
            
            styleTexto.setDataFormat(createHelper.createDataFormat().getFormat("@"));

            escribirArchivo("Se separan las tablas del DataSet", pathLog);
            int sizePartition = 100;

            List<Integer> posiciones = OrdenarLista(lista);

            int pos = posiciones.size();//Obttenemos la longitud del array
            int inicio = posiciones.get(0);
            int fin = posiciones.get(pos - 1);
            ArrayList<LinkedCaseInsensitiveMap> aux = lista.get(fin); //Almacenamos el ultimo valor en una variable
            lista.add(inicio, aux);//insertar al principio el último valor
            lista.remove(fin + 1);//removemos el ultimo valor

            for (List<LinkedCaseInsensitiveMap> arrayList : lista) {
                Set setKeys = arrayList.get(0).keySet();
                ArrayList<String> keys = new ArrayList(setKeys);
                String key = keys.get(0);
                if (null == key) {
                    Sheet hojaExtra = libro.createSheet("Hoja " + (iex++));

                    setHoja(arrayList, hojaExtra, 0, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "", true, bandera);

                } else {
                    switch (key) {
                        case "empresa":
                        case "NumEMpleado":
                            escribirArchivo("Procesando datos de Hoja Concentrada, total = " + arrayList.size(), pathLog);
                            if (arrayList.size() > sizePartition) {
                                boolean saltoL = true;
                                List<List<LinkedCaseInsensitiveMap>> partitions = ListUtils.partition((List<LinkedCaseInsensitiveMap>) arrayList, sizePartition);
                                for (List<LinkedCaseInsensitiveMap> partition : partitions) {

                                    ic = setHoja(partition, hojaConcentrada, ic, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Concentrada", saltoL, bandera);

                                    saltoL = false;
                                }
                            } else {

                                ic = setHoja(arrayList, hojaConcentrada, ic, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Concentrada", true, bandera);

                            }
                            break;
                        case "EMPRESA":
                        case "NUMEMPLEADO":
                            escribirArchivo("Procesando datos de Hoja Desglosada, total = " + arrayList.size(), pathLog);
                            if (arrayList.size() > sizePartition) {
                                boolean saltoL = true;
                                List<List<LinkedCaseInsensitiveMap>> partitions = ListUtils.partition((List<LinkedCaseInsensitiveMap>) arrayList, sizePartition);
                                for (List<LinkedCaseInsensitiveMap> partition : partitions) {
                                    
                                    id = setHoja(partition, hojaDesglosada, id, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Desglosada", saltoL, bandera);
                                    saltoL = false;

                                }
                            } else {

                                id = setHoja(arrayList, hojaDesglosada, id, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Desglosada", true, bandera);

                            }
                            break;
                        case "CVEP":
                        case "CVEPO":
                            escribirArchivo("Procesando datos de Hoja Total por coberturas, total = " + arrayList.size(), pathLog);
                            if (arrayList.size() > sizePartition) {
                                boolean saltoL = true;
                                List<List<LinkedCaseInsensitiveMap>> partitions = ListUtils.partition((List<LinkedCaseInsensitiveMap>) arrayList, sizePartition);
                                for (List<LinkedCaseInsensitiveMap> partition : partitions) {

                                    it = setHoja(partition, hojaTotalPorCoberturas, it, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Total por coberturas", saltoL, bandera);
                                    saltoL = false;

                                }
                            } else {

                                it = setHoja(arrayList, hojaTotalPorCoberturas, it, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Total por coberturas", true, bandera);

                            }
                            break;
                        case "cvep":
                        case "cvepo":
                            escribirArchivo("Procesando datos de Hoja Planes_Parentesco, total = " + arrayList.size(), pathLog);
                            if (arrayList.size() > sizePartition) {
                                boolean saltoL = true;
                                List<List<LinkedCaseInsensitiveMap>> partitions = ListUtils.partition((List<LinkedCaseInsensitiveMap>) arrayList, sizePartition);
                                for (List<LinkedCaseInsensitiveMap> partition : partitions) {

                                    ip = setHoja(partition, hojaPlanesParentesco, ip, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Planes_Parentesco", saltoL, bandera);
                                    saltoL = false;

                                }
                            } else {

                                ip = setHoja(arrayList, hojaPlanesParentesco, ip, styleCabezera, styleContenido, styleDinero, styleFecha, styleEntero, styleTexto, "Planes_Parentesco", true, bandera);

                            }
                            break;
                            default:
                            break;

                    }
                }
            }

            escribirArchivo("Se agregan las tablas al EXCEL", pathLog);
            escribirArchivo("Se verifica la integridad del archivo", pathLog);

            File file = new File(ruta + nomArch);
            File dir = new File(ruta);

            if (!dir.exists()) {
                dir.mkdirs();
            }
            if (file.exists()) {
                file.delete();
            }
            FileOutputStream fileOuS;
            fileOuS = new FileOutputStream(file);

            String cPassword = "";
            cPassword = getParametro(idEmpresa, 12);
            escribirArchivo("Se consulta parametro 12 para saber si se asignara password al documento", pathLog);
            escribirArchivo("El valor del parametro 12 es: " + cPassword.trim(), pathLog);
            if (!cPassword.trim().equals("")) {
                try {
                    POIFSFileSystem fs = new POIFSFileSystem();
                    EncryptionInfo info = new EncryptionInfo(EncryptionMode.standard);

                    Encryptor enc = info.getEncryptor();
                    enc.confirmPassword(cPassword.trim());

                    OutputStream os = enc.getDataStream(fs);

                    libro.write(os);

                    fs.writeFilesystem(fileOuS);
                    escribirArchivo("Se guarda el archivo", pathLog);
                    enviarCorreo(idEmpresa, 1, nomCorp, nomAdm, nomEmp, email, nomArch, fechaIniProc, pathLog);
                    fileOuS.flush();
                    fileOuS.close();

                    escribirArchivo("Contraseña colocada con exito", pathLog);

                    escribirArchivo("Se arma el arreglo de parametros para el stored ff_IInsertaCobranzaEncabezado", pathLog);
                    insertArchivoCobranza(idEmpresa, FecIni, FecFin, idVigencia, nomArch, today, pathLog);
                    escribirArchivo("Liberamos el documento", pathLog);
                } catch (Exception exx) {
                    enviarCorreo(idEmpresa, 0, nomCorp, nomAdm, nomEmp, email, "(Contraseña / Guardar) " + exx.getMessage(), fechaIniProc, pathLog);
                    escribirArchivo("Se presenta este error al momento de generar la cobranza: (Contraseña / Guardar) " + exx.getMessage() + "\n\r" + exx.getStackTrace(), pathLog);
                    List<Object> arrayError = new ArrayList<>();
                    Map<String, Object> json = new HashMap<>();
                    json.put("error", true);
                    json.put("mssError", "(Contraseña / Guardar) " + getCausa(exx.getMessage(), 1));
                    arrayError.add(json);
                    return arrayError;
                }
            }else{
                fileOuS = new FileOutputStream(file);
                libro.write(fileOuS);
                fileOuS.flush();
                fileOuS.close();
                escribirArchivo("Se arma el arreglo de parametros para el stored ff_IInsertaCobranzaEncabezado", pathLog);
                insertArchivoCobranza(idEmpresa, FecIni, FecFin, idVigencia, nomArch, today, pathLog);
                escribirArchivo("Liberamos el documento", pathLog);
            }
            escribirArchivo("Finaliza la cobranza ...........................................................................................................\n", pathLog);
            return getListArchivosVigenciaActivaRenovada(idEmpresa, pathLog, idVigencia);
        } catch (IOException e) {
            enviarCorreo(idEmpresa, 0, nomCorp, nomAdm, nomEmp, email, e.getMessage(), fechaIniProc, pathLog);
            escribirArchivo("Se presenta este error al momento de generar la cobranza: " + e.getMessage() + "\n\r" + e.getStackTrace(), pathLog);
            List<Object> arrayError = new ArrayList<>();
            Map<String, Object> json = new HashMap<>();
            json.put("error", true);
            json.put("mssError", getCausa(e.getMessage(), 1));
            arrayError.add(json);
            return arrayError;
        }
    }


    private void hojas_transacciones(Workbook libro, int bandera, CellStyle estiloMoneda, CellStyle styleCabezera, Map<String, List<Map<String, Object>>> transacciones_filtradas){

        for(String clave : transacciones_filtradas.keySet()){

            Sheet transacciones = libro.createSheet("Transacciones " + clave);
            hojas_banwire(styleCabezera, transacciones, "Transacciones", bandera);

            List<Map<String, Object>> valor = transacciones_filtradas.get(clave);

            List<TransaccionesBanwire> l_transacciones = new ArrayList<>();

            for(Map<String, Object> map : valor){

                TransaccionesBanwire banwire = new TransaccionesBanwire();

                banwire.setComisionbanwire(0.0);
                banwire.setComisionfijasiniva(2.50);
                banwire.setIvacomisionfija(0.40);
                banwire.setComisionmsi(0.0);
                banwire.setIvsmsi(0.0);

                Double total = Double.parseDouble(banwire.getComisionbanwire() + "") + Double.parseDouble(banwire.getComisionfijasiniva() + "") 
                    + Double.parseDouble(banwire.getIvacomisionfija() + "");

                banwire.setTotalcomision(total);
                banwire.setTasa(2.90);
                banwire.setCiva(3.364);
                banwire.setTerminal("V/MC");
                banwire.setMesesfinanciados("");

                if(map.containsKey("idtrans")){

                    banwire.setIdtrans(map.get("idtrans") + "");

                }
                
                if(map.containsKey("fechadepago")){

                    banwire.setFechadepago(map.get("fechadepago") + "");

                }

                if(map.containsKey("montoprocesado")){

                    banwire.setMontoprocesado(Double.parseDouble(map.get("montoprocesado") + ""));

                    Double monto = Double.parseDouble(map.get("montoprocesado") + "") * 0.16;

                    banwire.setIva(monto);
                    banwire.setLiquidacion(Double.parseDouble(map.get("montoprocesado") + ""));

                }

                if(map.containsKey("codigoaut")){

                    banwire.setCodigoaut(map.get("codigoaut") + "");

                }

                if(map.containsKey("referencia")){

                    banwire.setReferencia(map.get("referencia") + "");

                }

                if(map.containsKey("extrefcliente")){

                    banwire.setExtrefcliente(map.get("extrefcliente") + "");

                }


                if(map.containsKey("card")){

                    banwire.setCard(map.get("card") + "");

                }

                if(map.containsKey("telefono")){

                    banwire.setCard(map.get("telefono") + "");

                }

                if(map.containsKey("mail")){

                    banwire.setMail(map.get("mail") + "");

                }

                if(map.containsKey("comercio")){

                    banwire.setComercio(map.get("comercio") + "");

                }

                l_transacciones.add(banwire);
            }

            for(int i = 0; i < l_transacciones.size(); i++){

                TransaccionesBanwire banwire = l_transacciones.get(i);

                int num = i + 1;
                    
                Row row = transacciones.createRow(num);
                    
                row.createCell(0).setCellValue(banwire.getIdtrans());

                row.createCell(1).setCellValue(banwire.getFechadepago());

                Cell monto = row.createCell(2);
                monto.setCellValue(banwire.getMontoprocesado());
                monto.setCellStyle(estiloMoneda);
                    
                Cell comisionbanwire = row.createCell(3);
                comisionbanwire.setCellValue(banwire.getComisionbanwire());
                comisionbanwire.setCellStyle(estiloMoneda);

                Cell iva = row.createCell(4);
                iva.setCellValue(banwire.getIva());
                iva.setCellStyle(estiloMoneda);

                Cell comisionfijasiniva = row.createCell(5);
                comisionfijasiniva.setCellValue(banwire.getComisionfijasiniva());
                comisionfijasiniva.setCellStyle(estiloMoneda);

                Cell ivacomisionfija = row.createCell(6);
                ivacomisionfija.setCellValue(banwire.getIvacomisionfija());
                ivacomisionfija.setCellStyle(estiloMoneda);

                Cell comisionmsi = row.createCell(7);
                comisionmsi.setCellValue(banwire.getComisionmsi());
                comisionmsi.setCellStyle(estiloMoneda);

                Cell ivsmsi = row.createCell(8);
                ivsmsi.setCellValue(banwire.getIvsmsi());
                ivsmsi.setCellStyle(estiloMoneda);

                Cell totalcomision = row.createCell(9);
                totalcomision.setCellValue(banwire.getTotalcomision());
                totalcomision.setCellStyle(estiloMoneda);

                Cell tasa = row.createCell(10);
                tasa.setCellValue(banwire.getTasa());
                tasa.setCellStyle(estiloMoneda);

                Cell civa = row.createCell(11);
                civa.setCellValue(banwire.getCiva());
                civa.setCellStyle(estiloMoneda);

                Cell liquidacion = row.createCell(12);
                liquidacion.setCellValue(banwire.getLiquidacion());
                liquidacion.setCellStyle(estiloMoneda);


                row.createCell(13).setCellValue(banwire.getTerminal());

                row.createCell(14).setCellValue(banwire.getCodigoaut());

                row.createCell(15).setCellValue(banwire.getReferencia());

                row.createCell(16).setCellValue(banwire.getExtrefcliente());

                row.createCell(17).setCellValue(banwire.getCard());

                row.createCell(18).setCellValue(banwire.getTelefono());

                row.createCell(19).setCellValue(banwire.getMail());

                row.createCell(20).setCellValue(banwire.getComercio());

                row.createCell(21).setCellValue(banwire.getMesesfinanciados());

            }

        }

    }


    private void hojas_liquidaciones(Workbook libro, int bandera, CellStyle estiloMoneda, CellStyle styleCabezera, Map<String, List<Map<String, Object>>> liquidaciones_filtradas){

        for(String clave : liquidaciones_filtradas.keySet()){

            Sheet liquidaciones = libro.createSheet("Liquidaciones " + clave);
            hojas_banwire(styleCabezera, liquidaciones, "Liquidaciones", bandera);

            List<Map<String, Object>> valor = liquidaciones_filtradas.get(clave);

            List<LiquidacionesBanwire> l_liquidacion = new ArrayList<>();

            for(Map<String, Object> objeto : valor){

                LiquidacionesBanwire liquiacion = new LiquidacionesBanwire();

                if(objeto.containsKey("idTransaccion")){

                    liquiacion.setIdtrans(objeto.get("idTransaccion") + "");

                }
                 
                if(objeto.containsKey("MontoTransaccion")){

                    liquiacion.setMontotransaccion(Double.parseDouble(objeto.get("MontoTransaccion") + ""));
                    liquiacion.setNumero(Double.parseDouble(objeto.get("MontoTransaccion") + ""));
                    liquiacion.setMonto(Double.parseDouble(objeto.get("MontoTransaccion") + ""));

                }

                if(objeto.containsKey("Clave")){

                    liquiacion.setClave(objeto.get("Clave") + "");

                }

                if(objeto.containsKey("NombreBeneficiario")){

                    liquiacion.setNombrebeneficiario(objeto.get("NombreBeneficiario") + "");

                }

                if(objeto.containsKey("ConceptoPago")){

                    liquiacion.setConceptopago(objeto.get("ConceptoPago") + "");

                }

                liquiacion.setEstatus("Correcto");
                liquiacion.setEmailbeneficiario("");

                l_liquidacion.add(liquiacion);

            }

            for(int i = 0; i < l_liquidacion.size(); i++){

                LiquidacionesBanwire banwire = l_liquidacion.get(i);

                int num = i + 1;
                    
                Row row = liquidaciones.createRow(num);
                    
                row.createCell(0).setCellValue(banwire.getIdtrans());

                Cell montotransaccion = row.createCell(1);
                montotransaccion.setCellValue(banwire.getMontotransaccion());
                montotransaccion.setCellStyle(estiloMoneda);

                Cell numero = row.createCell(2);
                numero.setCellValue(banwire.getNumero());
                numero.setCellStyle(estiloMoneda);

                row.createCell(3).setCellValue(banwire.getEstatus());

                row.createCell(4).setCellValue(banwire.getClave());

                row.createCell(5).setCellValue(banwire.getNombrebeneficiario());
                    
                Cell monto = row.createCell(6);
                monto.setCellValue(banwire.getMonto());
                monto.setCellStyle(estiloMoneda);

                row.createCell(7).setCellValue(banwire.getConceptopago());

                row.createCell(8).setCellValue(banwire.getEmailbeneficiario());
                    
            }

        }

    }

    private void hojas_dispersion(Workbook libro, int bandera, CellStyle estiloMoneda, CellStyle styleCabezera, Map<String, List<Map<String, Object>>> dispersiones_filtradas){

        for(String clave : dispersiones_filtradas.keySet()){
    
            Sheet dispersionesSheet = libro.createSheet("Dispersiones " + clave);
            hojas_banwire(styleCabezera, dispersionesSheet, "Dispersiones", bandera);
    
            List<Map<String, Object>> valores = dispersiones_filtradas.get(clave);
    
            List<DispersionBanwire> dispersionesList = new ArrayList<>();
    
            for(Map<String, Object> objeto : valores){
    
                DispersionBanwire dispersion = new DispersionBanwire();
    
                // Beneficiario
                if(objeto.containsKey("ConceptoDispersion")){
                    dispersion.setBeneficiaro(objeto.get("ConceptoDispersion").toString());
                }
    
                // Monto
                if(objeto.containsKey("monto")){
                    dispersion.setMonto(Double.parseDouble(objeto.get("monto").toString()));
                }
    
                // Cuenta
                if(objeto.containsKey("cuenta")){
                    dispersion.setCuenta(objeto.get("cuenta").toString());
                }
    
                dispersionesList.add(dispersion);
            }
    
            for(int i = 0; i < dispersionesList.size(); i++){
    
                DispersionBanwire dispersion = dispersionesList.get(i);
    
                int num = i + 1;
                    
                Row row = dispersionesSheet.createRow(num);
                    
                row.createCell(0).setCellValue(dispersion.getBeneficiaro());
    
                Cell montoCell = row.createCell(1);
                montoCell.setCellValue(dispersion.getMonto());
                montoCell.setCellStyle(estiloMoneda);
    
                row.createCell(2).setCellValue(dispersion.getCuenta());
            }
        }
    }
    
    


    private static void hojas_banwire(CellStyle styleCabezera, Sheet hoja, String tipo, int bandera){

        Cell cell;
        Row row = hoja.createRow(0);
        String[] cabecera = null;

        switch (tipo) {
            case "Transacciones":
                cabecera = getCabecera("Transacciones", 0, bandera);
                break;

            case "Liquidaciones":
                cabecera = getCabecera("Liquidaciones", 0, bandera);
                break;

            case "Dispersiones":
                cabecera = getCabecera("Dispersiones", 0, bandera);
                break;

        }

        for (int i = 0; i < cabecera.length; i++) {

            cell = row.createCell(i);
            cell.setCellStyle(styleCabezera);
            cell.setCellValue(cabecera[i]);

            autoSizeColumn(hoja, i, 1);

        }

    }
    

    private static boolean isNumeric(String cadena) {
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }

    /**
     * Obtiene un valor representativo de la columna dentro de la particion.
     *
     * Las hojas se escriben en bloques de 100 registros. Antes se tomaba
     * siempre el valor de la primera fila para decidir el tipo de toda la
     * columna; si esa celda venia como cadena vacia, los importes restantes
     * del bloque se exportaban como texto. Se ignoran nulos y cadenas vacias
     * para conservar el tipo numerico informado por JDBC.
     */
    private static Object getReferenceValue(List<LinkedCaseInsensitiveMap> rows, int columnIndex) {
        for (LinkedCaseInsensitiveMap rowData : rows) {
            ArrayList rowValues = new ArrayList(rowData.values());
            if (columnIndex >= rowValues.size()) {
                continue;
            }

            Object value = rowValues.get(columnIndex);
            if (value == null) {
                continue;
            }
            if (value instanceof String && ((String) value).trim().isEmpty()) {
                continue;
            }
            return value;
        }
        return null;
    }

    /**
     * Conserva el orden utilizado por Cobranza B2 para el resumen por tipo
     * de plan. El procedimiento entrega los mismos valores, pero SQL Server
     * no garantiza su orden cuando el resultset no incluye un ORDER BY.
     */
    private static void sortPlanTypeTotalsLikeB2(List<LinkedCaseInsensitiveMap> rows, String sheetName) {
        if (!"Total por coberturas".equals(sheetName)) {
            return;
        }

        boolean hasGmm = false;
        boolean hasOptional = false;
        boolean hasLife = false;

        for (LinkedCaseInsensitiveMap rowData : rows) {
            int order = getPlanTypeTotalOrder(rowData.get("PlanD"));
            if (order > 3) {
                return;
            }
            hasGmm |= order == 0;
            hasOptional |= order == 1;
            hasLife |= order == 2;
        }

        if (hasGmm && hasOptional && hasLife) {
            rows.sort((left, right) -> Integer.compare(
                    getPlanTypeTotalOrder(left.get("PlanD")),
                    getPlanTypeTotalOrder(right.get("PlanD"))));
        }
    }

    private static int getPlanTypeTotalOrder(Object value) {
        String plan = value == null ? "" : value.toString().trim();
        if ("Total GMM".equalsIgnoreCase(plan)) {
            return 0;
        }
        if ("Total Opcionales".equalsIgnoreCase(plan)) {
            return 1;
        }
        if ("Total Vida".equalsIgnoreCase(plan)) {
            return 2;
        }
        if ("TOTALES:".equalsIgnoreCase(plan)) {
            return 3;
        }
        return Integer.MAX_VALUE;
    }


    private int setHoja(List<LinkedCaseInsensitiveMap> arrayList, Sheet hoja, int index, CellStyle sc, CellStyle sd, CellStyle sdi, 
        CellStyle styleFecha, CellStyle styleEntero, CellStyle texto, String tipo, boolean saltoL, int bandera) {

        sortPlanTypeTotalsLikeB2(arrayList, tipo);

        Set setKeys = arrayList.get(0).keySet();
        ArrayList<String> keys = new ArrayList(setKeys);

        String[] cabecera = getCabecera(tipo, keys.size(), bandera);

        int[] formatosDeCeldas = new int[cabecera.length];
        index = (saltoL && (index != 0)) ? index + 5 : index;
        Row rowC;
        if (saltoL) {
            rowC = hoja.createRow(index++);
        } else {
            rowC = hoja.createRow(index);
        }

        Cell cell;
        Row row;
        BigDecimal bd;
        Integer num;
        ArrayList celdas;
        String[][] tbDatos = new String[0][0];

        if (cabecera.length == 0) {
            for (int i = 0; i < keys.size(); i++) {
                if (saltoL) {
                    cell = rowC.createCell(i);
                    cell.setCellStyle(sc);
                    cell.setCellValue(keys.get(i));
                }
            }
        } else {
            for (int i = 0; i < cabecera.length; i++) {
                if (saltoL) {
                    cell = rowC.createCell(i);
                    cell.setCellStyle(sc);
                    cell.setCellValue(cabecera[i]);
                }
                Object referenceValue = getReferenceValue(arrayList, i);
                if (referenceValue instanceof String) {
                    formatosDeCeldas[i] = 0;
                } else if (referenceValue instanceof Integer) {
                    if((tipo == "Concentrada" && cabecera[i] == "Transacción") || (tipo == "Concentrada" && cabecera[i] == "Código de autorización")){

                        formatosDeCeldas[i] = 1;

                    }else{

                        formatosDeCeldas[i] = 1;

                    }
                    
                } else if (referenceValue instanceof BigDecimal) {

                    if((tipo == "Concentrada" && cabecera[i] == "Transacción") || (tipo == "Concentrada" && cabecera[i] == "Código de autorización")){

                        formatosDeCeldas[i] = 1;

                    }else{

                        formatosDeCeldas[i] = 2;

                    }
                    
                } else {
                    
                    if((tipo == "Concentrada" && cabecera[i] == "Transacción") || (tipo == "Concentrada" && cabecera[i] == "Código de autorización")){

                        formatosDeCeldas[i] = 1;

                    }else{

                        formatosDeCeldas[i] = 2;

                    }
                    
                }
            }
        }

        tbDatos = new String[arrayList.size()][cabecera.length];
        if (cabecera.length > 0) {
            for (int r = 0; r < arrayList.size(); r++) {
                celdas = new ArrayList(arrayList.get(r).values());
                for (int c = 0; c < celdas.size(); c++) {
                    tbDatos[r][c] = celdas.get(c) != null ? celdas.get(c).toString() : "";
                }
            }
        }

        for (String[] tbDato : tbDatos) {
            row = hoja.createRow(index++);
            for (int c = 0; c < tbDato.length; c++) {
                cell = row.createCell(c);
                switch (formatosDeCeldas[c]) {
                    case 0:
                        int resultado = tbDato[c].indexOf("/");
                        if (resultado == 2) {
                            try{
                                cell.setCellValue(new SimpleDateFormat("dd/MM/yyyy").parse(tbDato[c]));
                                cell.setCellStyle(styleFecha);
                            } catch (ParseException dateEx) {
                                cell.setCellValue(new Date(tbDato[c]));
                                cell.setCellStyle(styleFecha);
                            }
                        } 
                        else if (isNumeric(tbDato[c])) {
                            cell.setCellValue(tbDato[c]);
                            cell.setCellType(Cell.CELL_TYPE_STRING);
                            cell.setCellStyle(texto);
                        } else {
                            cell.setCellValue(tbDato[c]);
                            cell.setCellStyle(sd);
                        }
                        break;
                    case 1:
                        try {
                        num = new Integer(tbDato[c]);
                        cell.setCellValue(num);
                        cell.setCellType(Cell.CELL_TYPE_NUMERIC);
                        cell.setCellStyle(styleEntero);
                    } catch (Exception exBig) {
                        cell.setCellValue(tbDato[c]);
                        cell.setCellStyle(sd);
                    }
                    break;
                    case 2:
                        if (tbDato[c] != null) {
                            try {
                                bd = new BigDecimal(tbDato[c]);
                                cell.setCellStyle(sdi);
                                cell.setCellValue(bd.doubleValue());
                            } catch (Exception exBig) {
                                cell.setCellStyle(sd);
                                cell.setCellValue(tbDato[c]);
                            }
                        }
                        break;
                }
            }
        }
        if(tbDatos.length>0)
        for ( int j=0; j<=tbDatos[0].length; j++ ) {
            autoSizeColumn(hoja, j, 1);
        }
        
        return index;
    }


    private static String[] getCabecera(String nomHoja, int size, int bandera) {
        String[] cabecera = new String[]{};

        if(bandera == 1){

            switch (nomHoja) {
                case "Concentrada":
                    if (size == 69) {
                        cabecera = new String[]{
                            "Empresa", "Número Empleado", "Id", "Paterno", "Materno", "Primer nombre", "Segundo nombre", "Sexo",
                            "Fecha nacimiento", "Edad", "Sueldo confidencial", "Sueldo mensual", "Sueldo mensual anterior",
                            "Diferencia Sueldo mensual", "Transferido", "Número solicitud", "Perfil", "Fecha autorización",
                            "Grupo Parentesco", "Monto GMM periodo descuento", "Monto vida periodo descuento", "Monto otros periodo descuento", "Créditos GMM periodo descuento",
                            "Créditos vida periodo descuento", "Monto total créditos periodo descuento", "Monto total créditos periodo descuento Anterior",
                            "Diferencia Créditos", "Monto total selecciones periodo descuento", "Monto total selecciones anteriores periodo descuento",
                            "Diferencia selecciones periodo descuento", "Sobrante créditos periodo descuento", "Monto pagado con créditos periodo descuento",
                            "Descuento empleado periodo descuento", "Descuento empleado periodo descuento Anterior", "Diferencia descuento empleado",
                            "Q1", "Q2", "Diferencia", "Excedentes periodo descuento", "Excedentes anteriores periodo descuento", "Diferencia Excedentes",
                            "Monto fondo ahorro periodo descuento", "Monto fondo ahorro periodo descuento Anterior", "Diferencia Monto fondo ahorro",
                            "Sobrante de excedentes periodo descuento", "Aplicación de excedentes periodo descuento", "Descuento empleado de fondo ahorro",
                            "Descuento empleado final periodo descuento", "Costo empleado nómina seguros periodo descuento", "Sobrante de excedentes final periodo descuento",
                            "Cobertura regalos periodo descuento", "Número Oficina", "Nombre Oficina", "Plan Fondo de Ahorro", "Observaciones",
                            "Costo Empresa", "Costo Empleado", "Costo Planes Tarjeta", "Cobro Tarjeta", "Diferencia Tarjeta", "Transacción", "Fecha de cobro", "Código de autorización", "Referencia", "Extensión de referencia del cliente",
                            "Card", "Teléfono", "Mail", "Comercio"
                        };
                    }
                    break;
                case "Desglosada":
                    if (size == 58) {
                        cabecera = new String[]{
                            "Empresa", "Número empleado", "Id", "Paterno", "Materno", "Primer nombre", "Segundo nombre",
                            "Sexo", "Fecha nacimiento", "Edad", "Perfil", "CveParentesco", "Parentesco", "Transferido",
                            "Sueldo mensual", "Número solicitud", "Plan", "Cobertura", "Grupo parentesco", "CVEPO",
                            "CVEP", "Tipo S.A.", "Valor S.A.", "Orden cobranza", "Importe de costos hasta fin de vigencia",
                            "Prima neta hasta fin de vigencia", "Importe de costos por periodo", "Prima neta por periodo",
                            "Monto de créditos al fin de vigencia", "Monto de créditos por periodo", "Costo empresa por periodo",
                            "Costo empresa cashflow por periodo", "Costo empresa 1er. exceso por periodo",
                            "Costo empresa Stoploss por periodo", "Costo empleado por periodo", "Costo empleado cashflow por periodo",
                            "Costo empleado 1er. exceso por periodo", "Costo empleado stoploss por periodo",
                            "Costo empleado excedentes por periodo", "Costo empleado real por periodo",
                            "Sobrante excedentes por periodo", "Costo Empresa", "Costo Empleado", 
                            "Tipo", "Monto Pago", "Derecho Pol", "Recargo", "IVA", "Total", "Monto Pago Tarjeta", "Derecho Pol Tarjeta", "Recargo Tarjeta", "IVA Tarjeta", "Total Tarjeta", "Diferencia", "Transacción", "Liquidación Concepto", "Proveedor"
                        };
                    }
                    break;
                case "Total por coberturas":
                    if (size == 10) {
                        cabecera = new String[]{
                            "Clave de plan", "Clave de cobertura", "Nombre del plan", "Importe por periodo",
                            "Prima neta por periodo", "Costo empresa por periodo", "Costo empleado por periodo",
                            "Costo empleado excedentes", "Costo empleado real", "Sobrante de excedentes"
                        };
                    } else if (size == 5) {
                        cabecera = new String[]{
                            "Clave de plan", "Clave de cobertura", "Nombre Cobertura", "Clave Parentesco", "Cantidad"
                        };
                    }
                    break;
                case "Planes_Parentesco":
                    if (size == 12) {
                        cabecera = new String[]{
                            "Clave Plan", "Clave Plan Opcion", "Plan", "Plan Opcion", "TITULAR", "HIJO(A)",
                            "CONYUGE", "PADRE_MADRE", "HERMANO(A)", "SUEGRO(A)", "OTRO", "CONCUBINO(A)",};
                    }
                    break;

                case "Transacciones":

                    cabecera = new String[]{
                        "ID Trans", "Fecha de Pago", "Monto procesado", "Comisión BanWire", "IVA Comisión Fija", "IVA", "Comisión Fija Sin IVA",
                        "Comisión MSI", "IVS MSI", "Total Comisión", "Tasa", "C/IVA", "Liquidación", "Terminal", "codigo_aut", "referencia",
                        "ext_ref_cliente", "Card", "telefóno", "mail", "Comercio", "Meses Financiados"
                    };

                    break;
                
                case "Liquidaciones":

                    cabecera = new String[]{
                        "ID TRANSACCION", "Monto transaccion", "#", "Estatus", "Clave", "NOMBRE_BENEFICIARIO",
                        "MONTO", "CONCEPTO_PAGO", "EMAIL_BENEFICIARIO"
                    };

                    break;
                
                case "Dispersiones":

                    cabecera = new String[]{
                        "NOMBRE_BENEFICIARIO", "MONTO", "CUENTA_BENEFICIARIO"
                    };

                    break;
            }

        }else{

            switch (nomHoja) {
                case "Concentrada":
                    if (size == 57) {
                        cabecera = new String[]{
                            "Empresa", "Número Empleado", "Id", "Paterno", "Materno", "Primer nombre", "Segundo nombre", "Sexo",
                            "Fecha nacimiento", "Edad", "Sueldo confidencial", "Sueldo mensual", "Sueldo mensual anterior",
                            "Diferencia Sueldo mensual", "Transferido", "Número solicitud", "Perfil", "Fecha autorización",
                            "Grupo Parentesco", "Monto GMM periodo descuento", "Monto vida periodo descuento", "Monto otros periodo descuento", "Créditos GMM periodo descuento",
                            "Créditos vida periodo descuento", "Monto total créditos periodo descuento", "Monto total créditos periodo descuento Anterior",
                            "Diferencia Créditos", "Monto total selecciones periodo descuento", "Monto total selecciones anteriores periodo descuento",
                            "Diferencia selecciones periodo descuento", "Sobrante créditos periodo descuento", "Monto pagado con créditos periodo descuento",
                            "Descuento empleado periodo descuento", "Descuento empleado periodo descuento Anterior", "Diferencia descuento empleado",
                            "Q1", "Q2", "Diferencia", "Excedentes periodo descuento", "Excedentes anteriores periodo descuento", "Diferencia Excedentes",
                            "Monto fondo ahorro periodo descuento", "Monto fondo ahorro periodo descuento Anterior", "Diferencia Monto fondo ahorro",
                            "Sobrante de excedentes periodo descuento", "Aplicación de excedentes periodo descuento", "Descuento empleado de fondo ahorro",
                            "Descuento empleado final periodo descuento", "Costo empleado nómina seguros periodo descuento", "Sobrante de excedentes final periodo descuento",
                            "Cobertura regalos periodo descuento", "Número Oficina", "Nombre Oficina", "Plan Fondo de Ahorro", "Observaciones",
                            "Costo Empresa", "Costo Empleado"
                        };
                    }
                    break;
                case "Desglosada":
                    if (size == 43) {
                        cabecera = new String[]{
                            "Empresa", "Número empleado", "Id", "Paterno", "Materno", "Primer nombre", "Segundo nombre",
                            "Sexo", "Fecha nacimiento", "Edad", "Perfil", "CveParentesco", "Parentesco", "Transferido",
                            "Sueldo mensual", "Número solicitud", "Plan", "Cobertura", "Grupo parentesco", "CVEPO",
                            "CVEP", "Tipo S.A.", "Valor S.A.", "Orden cobranza", "Importe de costos hasta fin de vigencia",
                            "Prima neta hasta fin de vigencia", "Importe de costos por periodo", "Prima neta por periodo",
                            "Monto de créditos al fin de vigencia", "Monto de créditos por periodo", "Costo empresa por periodo",
                            "Costo empresa cashflow por periodo", "Costo empresa 1er. exceso por periodo",
                            "Costo empresa Stoploss por periodo", "Costo empleado por periodo", "Costo empleado cashflow por periodo",
                            "Costo empleado 1er. exceso por periodo", "Costo empleado stoploss por periodo",
                            "Costo empleado excedentes por periodo", "Costo empleado real por periodo",
                            "Sobrante excedentes por periodo", "Costo Empresa", "Costo Empleado"
                        };
                    }
                    break;
                case "Total por coberturas":
                    if (size == 10) {
                        cabecera = new String[]{
                            "Clave de plan", "Clave de cobertura", "Nombre del plan", "Importe por periodo",
                            "Prima neta por periodo", "Costo empresa por periodo", "Costo empleado por periodo",
                            "Costo empleado excedentes", "Costo empleado real", "Sobrante de excedentes"
                        };
                    } else if (size == 5) {
                        cabecera = new String[]{
                            "Clave de plan", "Clave de cobertura", "Nombre Cobertura", "Clave Parentesco", "Cantidad"
                        };
                    }
                    break;
                case "Planes_Parentesco":
                    if (size == 12) {
                        cabecera = new String[]{
                            "Clave Plan", "Clave Plan Opcion", "Plan", "Plan Opcion", "TITULAR", "HIJO(A)",
                            "CONYUGE", "PADRE_MADRE", "HERMANO(A)", "SUEGRO(A)", "OTRO", "CONCUBINO(A)",};
                    }
                    break;
            }

        }
        
        return cabecera;

    }
    

    private void getHojaInfo(Workbook libro, int idEmpresa, String empresa, String FecIni, String FecFin, int idVigencia) {
        Sheet hojaInfo = libro.createSheet("Información");

        SimpleDateFormat formatoIngles = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat formatoMex = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaIni = new Date();
        Date fechaFin = new Date();
        try {
            fechaIni = formatoIngles.parse(FecIni);
            fechaFin = formatoIngles.parse(FecFin);
        } catch (ParseException ex) {
            
        }

        Periodicidad periodicidad = getPeriodicidadPagos(idVigencia);

        CellStyle style1 = libro.createCellStyle();
        Font font1 = libro.createFont();
        CellStyle style2 = libro.createCellStyle();
        Font font2 = libro.createFont();
        CellStyle style3 = libro.createCellStyle();
        Font font3 = libro.createFont();
        CellStyle style4 = libro.createCellStyle();
        Font font4 = libro.createFont();
        CellStyle style5 = libro.createCellStyle();
        Font font5 = libro.createFont();

        font1.setBold(true);
        font1.setColor(IndexedColors.WHITE.getIndex());
        font1.setFontName("Calibri");
        font1.setFontHeightInPoints((short) 16);
        style1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style1.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.index);
        style1.setFont(font1);
        style1.setVerticalAlignment(VerticalAlignment.BOTTOM);
        style1.setAlignment(HorizontalAlignment.LEFT);

        font2.setBold(true);
        font2.setColor(IndexedColors.WHITE.getIndex());
        font2.setFontName("Calibri");
        font2.setFontHeightInPoints((short) 11);
        style2.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style2.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.index);
        style2.setFont(font2);
        style2.setVerticalAlignment(VerticalAlignment.CENTER);
        style2.setAlignment(HorizontalAlignment.LEFT);

        font3.setColor(IndexedColors.BLACK.getIndex());
        font3.setFontHeightInPoints((short) 11);
        font3.setFontName("Calibri");
        style3.setFont(font3);
        style3.setVerticalAlignment(VerticalAlignment.CENTER);
        style3.setAlignment(HorizontalAlignment.RIGHT);

        font4.setColor(IndexedColors.BLACK.getIndex());
        font4.setFontHeightInPoints((short) 11);
        font4.setFontName("Calibri");
        style4.setFont(font4);
        style4.setVerticalAlignment(VerticalAlignment.CENTER);
        style4.setAlignment(HorizontalAlignment.LEFT);

        font5.setColor(IndexedColors.BLACK.getIndex());
        font5.setFontHeightInPoints((short) 11);
        font5.setFontName("Calibri");
        style5.setFont(font5);
        style5.setVerticalAlignment(VerticalAlignment.JUSTIFY);
        style5.setAlignment(HorizontalAlignment.JUSTIFY);

        Row row = hojaInfo.createRow((short) 0);
        Cell cell = row.createCell((short) 0);
        cell.setCellValue("Empresa: " + getRazonSocial(idEmpresa, empresa, idVigencia));
        cell.setCellStyle(style1);
        hojaInfo.addMergedRegion(new CellRangeAddress(0, 5, 0, 8));

        row = hojaInfo.createRow((short) 6);
        cell = row.createCell((short) 0);
        cell.setCellValue("INFORMACIÓN AL:");
        cell.setCellStyle(style2);
        hojaInfo.addMergedRegion(new CellRangeAddress(6, 6, 0, 3));

        cell = row.createCell((short) 4);
        cell.setCellValue(formatoMex.format(fechaIni) + " al " + formatoMex.format(fechaFin));
        cell.setCellStyle(style3);
        hojaInfo.addMergedRegion(new CellRangeAddress(6, 6, 4, 8));

        row = hojaInfo.createRow((short) 7);
        cell = row.createCell((short) 0);
        cell.setCellValue("PERIODICIDAD DE PAGO");
        cell.setCellStyle(style2);
        hojaInfo.addMergedRegion(new CellRangeAddress(7, 7, 0, 3));

        cell = row.createCell((short) 4);
        cell.setCellValue(periodicidad.periodicidad);
        cell.setCellStyle(style4);
        hojaInfo.addMergedRegion(new CellRangeAddress(7, 7, 4, 8));

        row = hojaInfo.createRow((short) 8);
        cell = row.createCell((short) 0);
        cell.setCellValue("CANTIDAD DE PAGOS");
        cell.setCellStyle(style2);
        hojaInfo.addMergedRegion(new CellRangeAddress(8, 8, 0, 3));

        cell = row.createCell((short) 4);
        cell.setCellValue(periodicidad.catidadPagos);
        cell.setCellStyle(style4);
        hojaInfo.addMergedRegion(new CellRangeAddress(8, 8, 4, 8));
    }

    public static void autoSizeColumn(Sheet hoja, int column, int plusMinusChars) {
        try {
            double width = SheetUtil.getColumnWidth(hoja, column, false);
            if (width != -1) {
                width += plusMinusChars;
                width *= 256;
                int maxColumnWidth = 255 * 256;
                if (width > maxColumnWidth) {
                    width = maxColumnWidth;
                }
                hoja.setColumnWidth(column, (int) (width));
            }
        } catch (Exception e) {
            
        }
    }

    @Override
    public int setEncabezado(int COIdEmpresa, int COIdVigencia, String COFechaIni, String COFechaFin, String CONombreRep, String COFecHoraGen, int Usuario) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("ff_IInsertaCobranzaEncabezado");
        Map<String, Object> inParamMap = new HashMap<String, Object>();

        inParamMap.put("COIdEmpresa", COIdEmpresa);
        inParamMap.put("COIdVigencia", COIdVigencia);
        inParamMap.put("COFechaIni", COFechaIni);
        inParamMap.put("COFechaFin", COFechaFin);
        inParamMap.put("CONombreRep", CONombreRep);
        inParamMap.put("COFecHoraGen", COFecHoraGen);
        inParamMap.put("Usuario", Usuario);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);

        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());

        if (!listSP.isEmpty()) {
            return 1;
        }
        return 0;
    }

    private void escribirArchivo(String contenido, String ruta) {
        File dir = new File(ruta);
        File file = new File(ruta + "Log.txt");

        try {
            if (!dir.exists()) {
                dir.mkdirs();
            }
            BufferedWriter bw;
            Date today = new Date();
            SimpleDateFormat formatoArchivo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss - ");
            String fecha = formatoArchivo.format(today);
            if (file.exists()) {
                bw = new BufferedWriter(new FileWriter(file, true));
                bw.write(fecha + contenido + "\n");
            } else {
                bw = new BufferedWriter(new FileWriter(file));
                bw.write(fecha + contenido + "\n");
            }
            bw.close();
        } catch (Exception e) {
            
        }
    }

    public String getCorreoAdmin(int idEmpresa) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(
                "ff_GetCorreoEmpresa");

        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("idEmpresa", idEmpresa);

        SqlParameterSource in = new MapSqlParameterSource(inParamMap);

        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        String param = "BeFlex@mx.lockton.com";
        try {
            ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            param = listLinks.get(0).get("correo").toString();
            
            return param;
        } catch (Exception e) {
            
            return param;
        }
    }

    public void enviarCorreo(int idEmpresa, int tipo, String nomCorp, String nomAdm, String nomEmp, String email, String nomArchivo, String fechaIniProceso, String pathLog) {
        String subject = nomCorp + " - Generación de reportes (Archivo Reporte Cobranza)";
        String logStr = "Notificación de archivo generado. Correo: " + email;
        String html = "<DIV ALIGN=\"CENTER\">"
                + "<FONT COLOR=\"black\" SIZE=\"3\" FACE=\"COSMOS\"><B>Notificación de archivo generado.</B></FONT><BR /><BR />"
                + "<FONT COLOR=\"black\" SIZE=\"2\" FACE=\"COSMOS\">Administrador, " + nomAdm + "</FONT><BR /><BR />"
                + "<FONT COLOR=\"black\" SIZE=\"2\" FACE=\"COSMOS\">Se generó el archivo de " + nomArchivo + " de la empresa " + nomEmp
                + " con fecha inicio de proceso del " + fechaIniProceso + ".</FONT><BR />"
                + "<HR NOSHADE WIDTH=\"50%\" COLOR=\"#ADA990\"><BR>"
                + "</DIV>";
        if (tipo == 0) {
            logStr = "Notificación de archivo no generado. Correo: " + email;
            html = "<DIV ALIGN=\"CENTER\">"
                    + "<FONT COLOR=\"black\" SIZE=\"3\" FACE=\"COSMOS\"><B>Notificación de archivo no generado.</B></FONT><BR /><BR />"
                    + "<FONT COLOR=\"black\" SIZE=\"2\" FACE=\"COSMOS\">Administrador, " + nomAdm + "</FONT><BR /><BR />"
                    + "<FONT COLOR=\"black\" SIZE=\"2\" FACE=\"COSMOS\">No fue posible generar el reporte de cobranza para la empresa " + nomEmp
                    + " con fecha inicio de proceso del " + fechaIniProceso + ".</FONT><BR />";
            if (!getCausa(nomArchivo, 0).equals("")) {
                html = html + "<FONT COLOR=\"black\" SIZE=\"2\" FACE=\"COSMOS\">Causa: " + getCausa(nomArchivo, 0) + "</FONT><BR />";
            }
            html = html + "<FONT COLOR=\"black\" SIZE=\"2\" FACE=\"COSMOS\">Mensaje de error: " + nomArchivo + "</FONT><BR />"
                    + "<HR NOSHADE WIDTH=\"50%\" COLOR=\"#ADA990\"><BR>"
                    + "</DIV>";
        }
        String cc = "";
        List<String> correos = getCorreosAdmin(idEmpresa);
        for (String correo : correos) {
            cc += correo + ",";
        }
        EnvioCorreoUnificadoRequest request = new EnvioCorreoUnificadoRequest();
        request.setIdEmpresa(idEmpresa);
        request.setOrigen(EnvioCorreoUnificadoService.ORIGEN_BACK_COBRANZA);
        request.setTo(email);
        request.setCc(cc.endsWith(",") ? cc.substring(0, cc.length() - 1) : cc);
        request.setAsunto(subject);
        request.setCuerpoHtml(html);
        boolean enviado = envioCorreoUnificadoService.enviarYRegistrar(request);
        if (enviado) {
            escribirArchivo("Se envio Correo de: " + logStr, pathLog);
        }
    }

    private String getCausa(String error, int tipo) {
        if (error != null && !error.equals("")) {
            String causa = "";
            if (tipo == 1) {
                causa = error;
            }
            if (error.toLowerCase().contains("socket closed")) {
                causa = "Se cerro la conexión a base de datos. " + error;
            }
            if (error.toLowerCase().contains("network is unreachable")) {
                causa = "Conexión de Red inestable. No se puede acceder a la red. " + error;
            }
            if (error.toLowerCase().contains("connection reset")) {
                causa = "Restablecimiento de la conexión, por tiempo de respuesta excedido. " + error;
            }
            if (error.toLowerCase().contains("timeout")) {
                causa = "Tiempo el tiempo de espera ha expirado. " + error;
            }
            if (error.toLowerCase().contains("timeout")) {
                causa = "Tiempo el tiempo de espera ha expirado. " + error;
            }
            if (error.toLowerCase().contains("timed out")) {
                causa = "Tiempo el tiempo de espera ha expirado. " + error;
            }
            if (error.toLowerCase().contains("nullpointerexception")) {
                causa = "Tiempo el tiempo de espera ha expirado. " + error;
            }
            if (error.toLowerCase().contains("sqlexception")) {
                if (error.toLowerCase().contains("subquery returned more than 1 value")) {
                    causa = "Ocurrio un error dentro de la ejecución del procedimiento almacenado.";
                } else {
                    causa = "Ocurrio un error en la base de datos. Intente nuevamente.";
                }
            }
            
            return causa;
        } else if (error == null) {
            
            return "NullPointerException. Objeto NULL encontrado";
        } else {
            
            return error;
        }
    }

    public String getParametro(int idEmpresa, int parametro) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetParametro");

        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("Empresa", idEmpresa);
        inParamMap.put("Parametro", parametro);

        SqlParameterSource in = new MapSqlParameterSource(inParamMap);

        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        String param = "";
        try {
            ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            param = listLinks.get(0).get("paValor").toString();
            
            return param;
        } catch (Exception e) {
            
            return param;
        }
    }

    public List<String> getCorreosAdmin(int idEmpresa) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(
                "ff_getCorreosAdminPorEmpresa");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("idEmpresa", idEmpresa);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<>(simpleJdbcCallResult.values());
        List<String> correos = new ArrayList<>();
        try {
            ArrayList<LinkedCaseInsensitiveMap> listLinks = (ArrayList<LinkedCaseInsensitiveMap>) listSP.get(0);
            for (LinkedCaseInsensitiveMap correo: listLinks) {
                String value = (String) correo.values().toArray()[0];
                if (!value.trim().isEmpty()) {
                    correos.add(value.trim());
                }
            }
            
            return correos;
        } catch (Exception e) {
            
            return correos;
        }
    }

}
