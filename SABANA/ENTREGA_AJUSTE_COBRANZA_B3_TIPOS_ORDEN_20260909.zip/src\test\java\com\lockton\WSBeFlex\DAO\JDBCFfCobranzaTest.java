package com.lockton.WSBeFlex.DAO;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.springframework.util.LinkedCaseInsensitiveMap;

import static org.junit.jupiter.api.Assertions.assertEquals;

class JDBCFfCobranzaTest {

    @Test
    void writesMoneyAsNumericWhenPartitionStartsWithEmptyValues() throws Exception {
        List<LinkedCaseInsensitiveMap> rows = new ArrayList<>();
        rows.add(desglosadaRow("", ""));
        rows.add(desglosadaRow(new BigDecimal("1250.50"), new BigDecimal("875.25")));

        SXSSFWorkbook workbook = new SXSSFWorkbook();
        try {
            Sheet sheet = workbook.createSheet("Desglosada");
            CellStyle header = workbook.createCellStyle();
            CellStyle content = workbook.createCellStyle();
            CellStyle money = workbook.createCellStyle();
            CellStyle date = workbook.createCellStyle();
            CellStyle integer = workbook.createCellStyle();
            CellStyle text = workbook.createCellStyle();

            Method setSheet = JDBCFfCobranza.class.getDeclaredMethod(
                    "setHoja", List.class, Sheet.class, int.class,
                    CellStyle.class, CellStyle.class, CellStyle.class,
                    CellStyle.class, CellStyle.class, CellStyle.class,
                    String.class, boolean.class, int.class);
            setSheet.setAccessible(true);
            setSheet.invoke(new JDBCFfCobranza(), rows, sheet, 0,
                    header, content, money, date, integer, text,
                    "Desglosada", true, 0);

            Cell valueSa = sheet.getRow(2).getCell(22);
            Cell netPremium = sheet.getRow(2).getCell(25);
            assertEquals(Cell.CELL_TYPE_NUMERIC, valueSa.getCellType());
            assertEquals(Cell.CELL_TYPE_NUMERIC, netPremium.getCellType());
            assertEquals(1250.50d, valueSa.getNumericCellValue(), 0.001d);
            assertEquals(875.25d, netPremium.getNumericCellValue(), 0.001d);
        } finally {
            workbook.dispose();
            workbook.close();
        }
    }

    @Test
    void ordersPlanTypeTotalsLikeB2() throws Exception {
        List<LinkedCaseInsensitiveMap> rows = new ArrayList<>(Arrays.asList(
                planTotalRow("Total Vida"),
                planTotalRow("Total GMM"),
                planTotalRow("Total Opcionales"),
                planTotalRow("TOTALES:")));

        Method sort = JDBCFfCobranza.class.getDeclaredMethod(
                "sortPlanTypeTotalsLikeB2", List.class, String.class);
        sort.setAccessible(true);
        sort.invoke(null, rows, "Total por coberturas");

        assertEquals(Arrays.asList("Total GMM", "Total Opcionales", "Total Vida", "TOTALES:"),
                rows.stream().map(row -> row.get("PlanD").toString()).collect(Collectors.toList()));
    }

    private static LinkedCaseInsensitiveMap<Object> desglosadaRow(Object valueSa, Object netPremium) {
        LinkedCaseInsensitiveMap<Object> row = new LinkedCaseInsensitiveMap<>();
        for (int column = 0; column < 43; column++) {
            Object value = "texto";
            if (column == 22) {
                value = valueSa;
            } else if (column == 25) {
                value = netPremium;
            }
            row.put("column" + column, value);
        }
        return row;
    }

    private static LinkedCaseInsensitiveMap<Object> planTotalRow(String plan) {
        LinkedCaseInsensitiveMap<Object> row = new LinkedCaseInsensitiveMap<>();
        row.put("PlanD", plan);
        return row;
    }
}
