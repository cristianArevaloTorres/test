USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

/*
    SOLO COLOR DE ENCABEZADOS - SABANA B3 (catReportesId = 3)

    Comparacion de archivos:
      B3 20260921131013.xlsx:           #0D6EFD
      B2 20260818115023 CORTEVA B2.xlsx: #6699CC

    No cambia columnas, datos, fuentes, tipografia, filtros ni Cobranza.
    Cambia todas las configuraciones B3 que aun usan el azul anterior,
    incluidas las especificas por empresa. Se puede ejecutar de nuevo.
    Generar una sabana NUEVA para observar el resultado; los XLSX ya
    generados no se modifican.
*/

DECLARE @FilasActualizadas int = 0;

BEGIN TRY
    IF OBJECT_ID(N'dbo.bf_RepConf_Tabla', N'U') IS NULL
        THROW 52101, 'No existe dbo.bf_RepConf_Tabla en FlexiForbesv2.', 1;

    BEGIN TRANSACTION;

    UPDATE dbo.bf_RepConf_Tabla
       SET colorFondo = N'#6699CC'
     WHERE catReportesId = 3
       AND colorFondo COLLATE Latin1_General_100_BIN2 = N'#0D6EFD';

    SET @FilasActualizadas = @@ROWCOUNT;

    -- Las cuatro configuraciones globales que utiliza BF3 deben quedar
    -- presentes y con el color B2. Si no, no confirmar un ajuste parcial.
    IF (
        SELECT COUNT(*)
          FROM dbo.bf_RepConf_Tabla
         WHERE idEmpresa = 0
           AND catReportesId = 3
           AND grupo IN (N'GMM', N'Vida', N'OPC', N'Mascotas')
           AND colorFondo COLLATE Latin1_General_100_BIN2 = N'#6699CC'
    ) <> 4
        THROW 52102, 'No se encontraron las cuatro configuraciones globales de Sabana B3 con el azul esperado.', 1;

    IF EXISTS (
        SELECT 1
          FROM dbo.bf_RepConf_Tabla
         WHERE catReportesId = 3
           AND colorFondo COLLATE Latin1_General_100_BIN2 = N'#0D6EFD'
    )
        THROW 52103, 'Aun existen configuraciones de Sabana B3 con el azul anterior.', 1;

    COMMIT TRANSACTION;

    SELECT @FilasActualizadas AS FilasActualizadas,
           N'#0D6EFD' AS ColorAnterior,
           N'#6699CC' AS ColorNuevo,
           N'Generar un archivo nuevo para comprobar el encabezado.' AS SiguientePaso;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
