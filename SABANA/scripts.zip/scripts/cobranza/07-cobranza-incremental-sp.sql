-- ============================================================
-- PASO 7: SPs para cache incremental de cobranza
-- Ejecutar en BD FlexiForbesv2 DESPUÉS de PASO 6.
--
-- Qué hace:
--   - ff_Cobranza_v2: acepta @fechaUltimoCalculo (DATETIME, default NULL).
--     Cuando se provee, crea #FiltroIncrementalEmps con solo los empleados
--     que tienen registro en ff_empleado_historico posterior a esa fecha.
--     El sub-SP ff_ObtenEmpleadosCob_v2_bf3 detecta esa tabla y aplica el filtro.
--
--   - ff_ObtenEmpleadosCob_v2_bf3: sin parámetros nuevos. Detecta si existe
--     #FiltroIncrementalEmps (creada por ff_Cobranza_v2) y solo procesa
--     los empleados en ella, reduciendo el WHILE loop de 10k a ~N modificados.
--
-- En Java (JDBCCobranza.precalcularCobranzaEmpresa):
--   - Primera corrida (sin cache): pasa NULL → SP procesa todos.
--   - Corridas siguientes: pasa la fecha del último cache → SP procesa solo delta.
--   - Los 3 result-sets de totales (TotCoberturas, TotCoberturasP, PlanesParentesco)
--     son ignorados del SP incremental; Java los recalcula con GROUP BY directo
--     sobre bf_CobranzaCache_Desglosada (que ya tiene todos los empleados).
-- ============================================================

-- ── 7.1  ff_Cobranza_v2  (agregar @fechaUltimoCalculo) ─────────────────────
CREATE OR ALTER PROCEDURE dbo.ff_Cobranza_v2
    @idEmpresa          INT,
    @idSolTipo          INT,
    @FecIni             VARCHAR(20),
    @FecFin             VARCHAR(20),
    @idVencida          INT,
    @IdPerfil           VARCHAR(MAX),
    @idVIgencia         INT,
    @fechaUltimoCalculo DATETIME = NULL   -- NULL = rebuild completo
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
    VALUES ('cobranza_sp_parametros',
        'idEmpresa='   + CAST(@idEmpresa  AS VARCHAR) +
        ' idSolTipo='  + CAST(@idSolTipo  AS VARCHAR) +
        ' FecIni='     + ISNULL(@FecIni,  'NULL')     +
        ' FecFin='     + ISNULL(@FecFin,  'NULL')     +
        ' idVencida='  + CAST(@idVencida  AS VARCHAR) +
        ' idVIgencia=' + CAST(@idVIgencia AS VARCHAR) +
        ' IdPerfil='   + ISNULL(@IdPerfil,'NULL')     +
        ' incremental='+ CASE WHEN @fechaUltimoCalculo IS NULL THEN 'NO'
                              ELSE CONVERT(VARCHAR(20), @fechaUltimoCalculo, 120) END);

    DECLARE @tblIdPerfil dbo.ListInt;

    INSERT INTO @tblIdPerfil (IdTipoNotificacionCorreo)
    SELECT CAST(LTRIM(RTRIM(value)) AS INT)
    FROM STRING_SPLIT(@IdPerfil, ',')
    WHERE LTRIM(RTRIM(value)) <> '';

    INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
    VALUES ('cobranza_sp_perfiles_parseados',
        'count=' + CAST((SELECT COUNT(1) FROM @tblIdPerfil) AS VARCHAR));

    -- Crea filtro incremental: solo empleados con historial posterior al último cálculo
    IF @fechaUltimoCalculo IS NOT NULL
    BEGIN
        CREATE TABLE #FiltroIncrementalEmps (EMId INT NOT NULL PRIMARY KEY);
        INSERT INTO #FiltroIncrementalEmps (EMId)
        SELECT DISTINCT EMId
        FROM   dbo.ff_empleado_historico WITH (NOLOCK)
        WHERE  emidempresa = @idEmpresa
          AND  EMFechaCambio > @fechaUltimoCalculo;

        INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
        VALUES ('cobranza_incremental_filtro',
            'desde='   + CONVERT(VARCHAR(20), @fechaUltimoCalculo, 120) +
            ' empsCambio=' + CAST((SELECT COUNT(1) FROM #FiltroIncrementalEmps) AS VARCHAR));
    END

    BEGIN TRY
        EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3
            @idEmpresa  = @idEmpresa,
            @idSolTipo  = @idSolTipo,
            @FecIni     = @FecIni,
            @FecFin     = @FecFin,
            @idVencida  = @idVencida,
            @IdPerfil   = @tblIdPerfil,
            @idVIgencia = @idVIgencia;

        INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
        VALUES ('cobranza_sp_delegacion_ok', 'ObtenCobranzaConcentrada_otro_V2_BF3 completado');
    END TRY
    BEGIN CATCH
        INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
        VALUES ('cobranza_sp_delegacion_error',
            'ERROR ' + CAST(ERROR_NUMBER() AS VARCHAR) + ': ' + ERROR_MESSAGE());
        THROW;
    END CATCH
END
GO

-- ── 7.2  ff_ObtenEmpleadosCob_v2_bf3  (detectar filtro incremental) ─────────
-- Cambios respecto a la versión anterior:
--   Se agrega en los branches @idCobActual=1/10 (con y sin #IdPerfilV2) el AND:
--     AND (OBJECT_ID('tempdb..#FiltroIncrementalEmps') IS NULL
--          OR Id IN (SELECT EMId FROM #FiltroIncrementalEmps))
--   Cuando #FiltroIncrementalEmps no existe (rebuild completo) la condición
--   siempre es TRUE y el comportamiento es idéntico al original.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR ALTER PROCEDURE [dbo].[ff_ObtenEmpleadosCob_v2_bf3]
    (@idEmpresa INT, @FecIni VARCHAR(16), @FecFin VARCHAR(16),
     @idCobActual INT, @IdPerfil AS dbo.ListInt READONLY)
AS
BEGIN

DECLARE @dFecIni AS DATETIME = CONVERT(datetime, @FecIni),
        @dFecFin AS DATETIME = CONVERT(datetime, @FecFin);

IF NOT EXISTS (SELECT TOP 1 IdTipoNotificacionCorreo FROM #IdPerfilV2)
BEGIN
    IF @idCobActual = 1 OR @idCobActual = 10
    BEGIN
        INSERT DBO.#ff_Empleadotemp (
          EMId,EMIdEmpresa,EMIdTitular,EMIdPerfil,EMIdParentesco,EMIdSexo,EMIdEstatus,EMFechaEstatus,EMIdTransferido,EMNumeroEmpleado,
          EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMEdad,EMFechaIngresoEmpresa,
          EMFechaBaja,EMFechaAntiguedadGMM,EMAntiguedadGMM,EMPuesto,EMArea,EMOficina,EMrfc,EMIdTipoSalario,EMIdSalarioConfidencial,
          EMSalarioBase,EMSalarioIntegrado,EMSalarioBruto,EMSalarioNeto,EMDeduccionesM,EMDeduccionesP,EMPrestacionesM,EMPrestacionesP,
          EMFondoAhorroM,EMFondoAhorroP,EMFondoAhorroAcumulado,EMValesM,EMValesP,EMExcedente,EMBeneficioMaximoM,EMBeneficioMaximoP,
          EMBeneFicioOtorgadoM,EMBeneFicioOtorgadoP,EMVIP,EMIdRol,EMidCentroCostos,EMNetForbes,EMDiasVacacionesporGozar,EMMesFechaUmod,
          EMAnioFechaUmod,EMModificaciones,EMAplicacion,EMMismaEmpresa,EMIdEmpresaAnt,EMIdAnt
        )
        SELECT Id, EMIdEmpresa, EMIdTitular, EMIdPerfil, EMIdParentesco, EMIdSexo, EMIdEstatus, EMFechaEstatus, EMIdTransferido,
          EMNumeroEmpleado, EMCertificado, EMApellidoPaterno, EMApellidoMaterno, EMNombre1, EMNombre2, EMFechaNacimiento,
          EMEdad, EMFechaIngresoEmpresa, EMFechaBaja, EMFechaAntiguedadGMM, EMAntiguedadGMM, EMPuesto, EMArea, EMOficina,
          EMrfc, EMIdTipoSalario, EMIdSalarioConfidencial, EMSalarioBase, EMSalarioIntegrado, EMSalarioBruto, EMSalarioNeto,
          EMDeduccionesM, EMDeduccionesP, EMPrestacionesM, EMPrestacionesP, EMFondoAhorroM, EMFondoAhorroP,
          EMFondoAhorroAcumulado, EMValesM, EMValesP, EMExcedente, EMBeneficioMaximoM, EMBeneficioMaximoP, EMBeneFicioOtorgadoM,
          EMBeneFicioOtorgadoP, EMVIP, EMIdRol, EMidCentroCostos, EMNetForbes, EMDiasVacacionesporGozar,
          0 AS EMMesFechaUmod, 0 AS EMAnioFechaUmod, 0 AS EMModificaciones, 0 AS EMAplicacion,
          1 AS EMMismaEmpresa, EMIdEmpresa AS EMIdEmpresaAnt, Id AS EMIdAnt
        FROM DBO.ff_empleado WITH (NOLOCK)
        WHERE EMIDESTATUS = 1
          AND emidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
          AND EMNumeroEmpleado NOT LIKE 'TEST%'
          -- filtro incremental: si existe #FiltroIncrementalEmps, solo esos empleados
          AND (OBJECT_ID('tempdb..#FiltroIncrementalEmps') IS NULL
               OR Id IN (SELECT EMId FROM #FiltroIncrementalEmps))
        ORDER BY emnumeroempleado, emidparentesco
    END

    IF @idCobActual = 4
    BEGIN
        INSERT DBO.#ff_Empleadotemp (
          EMId,EMIdEmpresa,EMIdTitular,EMIdPerfil,EMIdParentesco,EMIdSexo,EMIdEstatus,EMFechaEstatus,EMIdTransferido,EMNumeroEmpleado,
          EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMEdad,EMFechaIngresoEmpresa,
          EMFechaBaja,EMFechaAntiguedadGMM,EMAntiguedadGMM,EMPuesto,EMArea,EMOficina,EMrfc,EMIdTipoSalario,EMIdSalarioConfidencial,
          EMSalarioBase,EMSalarioIntegrado,EMSalarioBruto,EMSalarioNeto,EMDeduccionesM,EMDeduccionesP,EMPrestacionesM,EMPrestacionesP,
          EMFondoAhorroM,EMFondoAhorroP,EMFondoAhorroAcumulado,EMValesM,EMValesP,EMExcedente,EMBeneficioMaximoM,EMBeneficioMaximoP,
          EMBeneFicioOtorgadoM,EMBeneFicioOtorgadoP,EMVIP,EMIdRol,EMidCentroCostos,EMNetForbes,EMDiasVacacionesporGozar,EMMesFechaUmod,
          EMAnioFechaUmod,EMModificaciones,EMAplicacion,EMMismaEmpresa,EMIdEmpresaAnt,EMIdAnt
        )
        SELECT Id, EMIdEmpresa, EMIdTitular, EMIdPerfil, EMIdParentesco, EMIdSexo, EMIdEstatus, EMFechaEstatus, EMIdTransferido,
          EMNumeroEmpleado, EMCertificado, EMApellidoPaterno, EMApellidoMaterno, EMNombre1, EMNombre2, EMFechaNacimiento,
          EMEdad, EMFechaIngresoEmpresa, EMFechaBaja, EMFechaAntiguedadGMM, EMAntiguedadGMM, EMPuesto, EMArea, EMOficina,
          EMrfc, EMIdTipoSalario, EMIdSalarioConfidencial, EMSalarioBase, EMSalarioIntegrado, EMSalarioBruto, EMSalarioNeto,
          EMDeduccionesM, EMDeduccionesP, EMPrestacionesM, EMPrestacionesP, EMFondoAhorroM, EMFondoAhorroP,
          EMFondoAhorroAcumulado, EMValesM, EMValesP, EMExcedente, EMBeneficioMaximoM, EMBeneficioMaximoP, EMBeneFicioOtorgadoM,
          EMBeneFicioOtorgadoP, EMVIP, EMIdRol, EMidCentroCostos, EMNetForbes, EMDiasVacacionesporGozar,
          0 AS EMMesFechaUmod, 0 AS EMAnioFechaUmod, 0 AS EMModificaciones, 0 AS EMAplicacion,
          1 AS EMMismaEmpresa, EMIdEmpresa AS EMIdEmpresaAnt, Id AS EMIdAnt
        FROM DBO.ff_empleado A WITH (NOLOCK)
        INNER JOIN ff_solicitud B WITH (NOLOCK) ON A.emnumeroempleado = B.SONumEmpleado
        WHERE EMIDESTATUS = 1
          AND emidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
          AND EMNumeroEmpleado NOT LIKE 'TEST%'
          AND soidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
          AND soidestatus = 1
          AND soestatussolicitud = 1
          AND sonumempleado NOT LIKE '%TEST%'
          AND SOFechaAprovacion >= @FecIni
          AND SOFechaAprovacion <= @FecFin
        ORDER BY emnumeroempleado, emidparentesco
    END
END

IF @idCobActual = 0
BEGIN
    SELECT MAX(EMHIdHist) AS idhist, EMId AS idempl
      INTO #TablaHist
      FROM ff_empleado_historico WITH (NOLOCK)
      WHERE emidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
        AND ((EMFechaCambio >= @dFecIni) AND (EMFechaCambio <= (DATEADD(day, 1, @dFecFin))))
        AND (emModificaciones NOT LIKE '%EMContraseña%')
      GROUP BY EMId
      ORDER BY Emid

    INSERT INTO DBO.#ff_Empleadotemp (
      EMId,EMIdEmpresa,EMIdTitular,EMIdPerfil,EMIdParentesco,EMIdSexo,EMIdEstatus,EMFechaEstatus,EMIdTransferido,EMNumeroEmpleado,
      EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMEdad,EMFechaIngresoEmpresa,
      EMFechaBaja,EMFechaAntiguedadGMM,EMAntiguedadGMM,EMPuesto,EMArea,EMOficina,EMrfc,EMIdTipoSalario,EMIdSalarioConfidencial,
      EMSalarioBase,EMSalarioIntegrado,EMSalarioBruto,EMSalarioNeto,EMDeduccionesM,EMDeduccionesP,EMPrestacionesM,EMPrestacionesP,
      EMFondoAhorroM,EMFondoAhorroP,EMFondoAhorroAcumulado,EMValesM,EMValesP,EMExcedente,EMBeneficioMaximoM,EMBeneficioMaximoP,
      EMBeneFicioOtorgadoM,EMBeneFicioOtorgadoP,EMVIP,EMIdRol,EMidCentroCostos,EMNetForbes,EMDiasVacacionesporGozar,EMMesFechaUmod,
      EMAnioFechaUmod,EMModificaciones,EMAplicacion,EMMismaEmpresa,EMIdEmpresaAnt,EMIdAnt
    )
    SELECT Id, EMIdEmpresa, EMIdTitular, EMIdPerfil, EMIdParentesco, EMIdSexo, EMIdEstatus, EMFechaEstatus, EMIdTransferido,
      EMNumeroEmpleado, EMCertificado, EMApellidoPaterno, EMApellidoMaterno, EMNombre1, EMNombre2, EMFechaNacimiento,
      EMEdad, EMFechaIngresoEmpresa, EMFechaBaja, EMFechaAntiguedadGMM, EMAntiguedadGMM, EMPuesto, EMArea, EMOficina,
      EMrfc, EMIdTipoSalario, EMIdSalarioConfidencial, EMSalarioBase, EMSalarioIntegrado, EMSalarioBruto, EMSalarioNeto,
      EMDeduccionesM, EMDeduccionesP, EMPrestacionesM, EMPrestacionesP, EMFondoAhorroM, EMFondoAhorroP,
      EMFondoAhorroAcumulado, EMValesM, EMValesP, EMExcedente, EMBeneficioMaximoM, EMBeneficioMaximoP, EMBeneFicioOtorgadoM,
      EMBeneFicioOtorgadoP, EMVIP, EMIdRol, EMidCentroCostos, EMNetForbes, EMDiasVacacionesporGozar, '','','','',
      1, EMIdEmpresa, Id
    FROM DBO.ff_empleado WITH (NOLOCK)
    WHERE EMIDESTATUS = 1
      AND emidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
      AND EMFechaIngresoEmpresa <= @dFecFin
      AND id NOT IN (SELECT idempl FROM #TablaHist WITH (NOLOCK))
      AND id NOT IN (SELECT id FROM ff_empleado WITH (NOLOCK), ff_transferencia
          WHERE emidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
            AND ((TRFechaTransferencia >= @dFecIni) AND (TRFechaTransferencia <= @dFecFin))
            AND EMidempresa = TRidempresadestino
            AND EMnumeroempleado = TRNumeroempleadoDestino)

    INSERT INTO DBO.#ff_Empleadotemp (
      EMId,EMIdEmpresa,EMIdTitular,EMIdPerfil,EMIdParentesco,EMIdSexo,EMIdEstatus,EMFechaEstatus,EMIdTransferido,EMNumeroEmpleado,
      EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMEdad,EMFechaIngresoEmpresa,
      EMFechaBaja,EMFechaAntiguedadGMM,EMAntiguedadGMM,EMPuesto,EMArea,EMOficina,EMrfc,EMIdTipoSalario,EMIdSalarioConfidencial,
      EMSalarioBase,EMSalarioIntegrado,EMSalarioBruto,EMSalarioNeto,EMDeduccionesM,EMDeduccionesP,EMPrestacionesM,EMPrestacionesP,
      EMFondoAhorroM,EMFondoAhorroP,EMFondoAhorroAcumulado,EMValesM,EMValesP,EMExcedente,EMBeneficioMaximoM,EMBeneficioMaximoP,
      EMBeneFicioOtorgadoM,EMBeneFicioOtorgadoP,EMVIP,EMIdRol,EMidCentroCostos,EMNetForbes,EMDiasVacacionesporGozar,EMMesFechaUmod,
      EMAnioFechaUmod,EMModificaciones,EMAplicacion,EMMismaEmpresa,EMIdEmpresaAnt,EMIdAnt
    )
    SELECT EMId, EMIdEmpresa, EMIdTitular, EMIdPerfil, EMIdParentesco, EMIdSexo, EMIdEstatus, EMFechaEstatus, EMIdTransferido,
      EMNumeroEmpleado, EMCertificado, EMApellidoPaterno, EMApellidoMaterno, EMNombre1, EMNombre2, EMFechaNacimiento,
      EMEdad, EMFechaIngresoEmpresa, EMFechaBaja, EMFechaAntiguedadGMM, EMAntiguedadGMM, EMPuesto, EMArea, EMOficina,
      EMrfc, EMIdTipoSalario, EMIdSalarioConfidencial, EMSalarioBase, EMSalarioIntegrado, EMSalarioBruto, EMSalarioNeto,
      EMDeduccionesM, EMDeduccionesP, EMPrestacionesM, EMPrestacionesP, EMFondoAhorroM, EMFondoAhorroP,
      EMFondoAhorroAcumulado, EMValesM, EMValesP, EMExcedente, EMBeneficioMaximoM, EMBeneficioMaximoP, EMBeneFicioOtorgadoM,
      EMBeneFicioOtorgadoP, EMVIP, EMIdRol, EMidCentroCostos, EMNetForbes, EMDiasVacacionesporGozar,
      EMMesFechaUmod, EMAnioFechaUmod, EMModificaciones, EMAplicacion, 1, EMIdEmpresa, EMId
    FROM ff_empleado_historico EH WITH (NOLOCK)
    INNER JOIN #TablaHist TH WITH (NOLOCK) ON EH.EMHIdHist = TH.idhist
    WHERE emidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)

    INSERT INTO DBO.#ff_Empleadotemp (
      EMId,EMIdEmpresa,EMIdTitular,EMIdPerfil,EMIdParentesco,EMIdSexo,EMIdEstatus,EMFechaEstatus,EMIdTransferido,EMNumeroEmpleado,
      EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMEdad,EMFechaIngresoEmpresa,
      EMFechaBaja,EMFechaAntiguedadGMM,EMAntiguedadGMM,EMPuesto,EMArea,EMOficina,EMrfc,EMIdTipoSalario,EMIdSalarioConfidencial,
      EMSalarioBase,EMSalarioIntegrado,EMSalarioBruto,EMSalarioNeto,EMDeduccionesM,EMDeduccionesP,EMPrestacionesM,EMPrestacionesP,
      EMFondoAhorroM,EMFondoAhorroP,EMFondoAhorroAcumulado,EMValesM,EMValesP,EMExcedente,EMBeneficioMaximoM,EMBeneficioMaximoP,
      EMBeneFicioOtorgadoM,EMBeneFicioOtorgadoP,EMVIP,EMIdRol,EMidCentroCostos,EMNetForbes,EMDiasVacacionesporGozar,EMMesFechaUmod,
      EMAnioFechaUmod,EMModificaciones,EMAplicacion,EMMismaEmpresa,EMIdEmpresaAnt,EMIdAnt
    )
    SELECT Id, EMIdEmpresa, EMIdTitular, EMIdPerfil, EMIdParentesco, EMIdSexo, EMIdEstatus, EMFechaEstatus, EMIdTransferido,
      EMNumeroEmpleado, EMCertificado, EMApellidoPaterno, EMApellidoMaterno, EMNombre1, EMNombre2, EMFechaNacimiento,
      EMEdad, EMFechaIngresoEmpresa, EMFechaBaja, EMFechaAntiguedadGMM, EMAntiguedadGMM, EMPuesto, EMArea, EMOficina,
      EMrfc, EMIdTipoSalario, EMIdSalarioConfidencial, EMSalarioBase, EMSalarioIntegrado, EMSalarioBruto, EMSalarioNeto,
      EMDeduccionesM, EMDeduccionesP, EMPrestacionesM, EMPrestacionesP, EMFondoAhorroM, EMFondoAhorroP,
      EMFondoAhorroAcumulado, EMValesM, EMValesP, EMExcedente, EMBeneficioMaximoM, EMBeneficioMaximoP, EMBeneFicioOtorgadoM,
      EMBeneFicioOtorgadoP, EMVIP, EMIdRol, EMidCentroCostos, EMNetForbes, EMDiasVacacionesporGozar, '','','','',
      0, TRidEmpresaOrigen, TRidEmpleado
    FROM DBO.ff_empleado WITH (NOLOCK)
    INNER JOIN ff_transferencia WITH (NOLOCK) ON EMidempresa = TRidempresadestino
      AND EMnumeroempleado = TRNumeroempleadoDestino
    WHERE emidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
      AND ((TRFechaTransferencia >= @dFecIni) AND (TRFechaTransferencia <= @dFecFin))
    ORDER BY emnumeroempleado, emidparentesco
END

IF @idCobActual = 1 AND EXISTS (SELECT TOP 1 IdTipoNotificacionCorreo FROM #IdPerfilV2)
BEGIN
    INSERT DBO.#ff_Empleadotemp (
      EMId,EMIdEmpresa,EMIdTitular,EMIdPerfil,EMIdParentesco,EMIdSexo,EMIdEstatus,EMFechaEstatus,EMIdTransferido,EMNumeroEmpleado,
      EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMEdad,EMFechaIngresoEmpresa,
      EMFechaBaja,EMFechaAntiguedadGMM,EMAntiguedadGMM,EMPuesto,EMArea,EMOficina,EMrfc,EMIdTipoSalario,EMIdSalarioConfidencial,
      EMSalarioBase,EMSalarioIntegrado,EMSalarioBruto,EMSalarioNeto,EMDeduccionesM,EMDeduccionesP,EMPrestacionesM,EMPrestacionesP,
      EMFondoAhorroM,EMFondoAhorroP,EMFondoAhorroAcumulado,EMValesM,EMValesP,EMExcedente,EMBeneficioMaximoM,EMBeneficioMaximoP,
      EMBeneFicioOtorgadoM,EMBeneFicioOtorgadoP,EMVIP,EMIdRol,EMidCentroCostos,EMNetForbes,EMDiasVacacionesporGozar,EMMesFechaUmod,
      EMAnioFechaUmod,EMModificaciones,EMAplicacion,EMMismaEmpresa,EMIdEmpresaAnt,EMIdAnt
    )
    SELECT Id, EMIdEmpresa, EMIdTitular, EMIdPerfil, EMIdParentesco, EMIdSexo, EMIdEstatus, EMFechaEstatus, EMIdTransferido,
      EMNumeroEmpleado, EMCertificado, EMApellidoPaterno, EMApellidoMaterno, EMNombre1, EMNombre2, EMFechaNacimiento,
      EMEdad, EMFechaIngresoEmpresa, EMFechaBaja, EMFechaAntiguedadGMM, EMAntiguedadGMM, EMPuesto, EMArea, EMOficina,
      EMrfc, EMIdTipoSalario, EMIdSalarioConfidencial, EMSalarioBase, EMSalarioIntegrado, EMSalarioBruto, EMSalarioNeto,
      EMDeduccionesM, EMDeduccionesP, EMPrestacionesM, EMPrestacionesP, EMFondoAhorroM, EMFondoAhorroP,
      EMFondoAhorroAcumulado, EMValesM, EMValesP, EMExcedente, EMBeneficioMaximoM, EMBeneficioMaximoP, EMBeneFicioOtorgadoM,
      EMBeneFicioOtorgadoP, EMVIP, EMIdRol, EMidCentroCostos, EMNetForbes, EMDiasVacacionesporGozar,
      0 AS EMMesFechaUmod, 0 AS EMAnioFechaUmod, 0 AS EMModificaciones, 0 AS EMAplicacion,
      1 AS EMMismaEmpresa, EMIdEmpresa AS EMIdEmpresaAnt, Id AS EMIdAnt
    FROM DBO.ff_empleado WITH (NOLOCK)
    WHERE EMIDESTATUS = 1
      AND emidempresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
      AND EMNumeroEmpleado NOT LIKE 'TEST%'
      AND EMIdPerfil IN (SELECT IdTipoNotificacionCorreo FROM #IdPerfilV2)
      -- filtro incremental: si existe #FiltroIncrementalEmps, solo esos empleados
      AND (OBJECT_ID('tempdb..#FiltroIncrementalEmps') IS NULL
           OR Id IN (SELECT EMId FROM #FiltroIncrementalEmps))
    ORDER BY emnumeroempleado, emidparentesco
END

END
GO

-- ── Verificación post-deploy ────────────────────────────────────────────────
-- Prueba rebuild completo (igual que antes):
--   EXEC dbo.ff_Cobranza_v2 @idEmpresa=186, @idSolTipo=0,
--        @FecIni='20260101', @FecFin='20261231', @idVencida=0, @IdPerfil='', @idVIgencia=4235
--
-- Prueba incremental (solo empleados con cambios en los últimos 7 días):
--   EXEC dbo.ff_Cobranza_v2 @idEmpresa=186, @idSolTipo=0,
--        @FecIni='20260101', @FecFin='20261231', @idVencida=0, @IdPerfil='', @idVIgencia=4235,
--        @fechaUltimoCalculo = DATEADD(DAY, -7, GETDATE())
--
-- Monitorear:
--   SELECT etapa, detalle, fecha FROM dbo.bf_RepConf_Debug
--   WHERE etapa LIKE 'cobranza_%' AND fecha >= DATEADD(MINUTE,-30,GETDATE()) ORDER BY id;
