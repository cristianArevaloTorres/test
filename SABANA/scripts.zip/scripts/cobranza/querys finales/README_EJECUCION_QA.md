# Querys finales de Cobranza

Esta carpeta contiene la secuencia consolidada para instalar el cache de
Cobranza en una base limpia que ya tenga el esquema funcional de FlexiForbes.
No deben mezclarse con los scripts antiguos de la carpeta padre.

## Requisitos

- Respaldar la base antes de la instalación.
- Desplegar la versión actualizada de APIREPORTES junto con estos scripts.
- La base debe contener los procedimientos legacy de Cobranza y `dbo.ListInt`.
- Ejecutar con un usuario autorizado para crear y alterar objetos.

## Orden de ejecución

1. `01_instalacion-completa-cache-cobranza.sql`
   Instala objetos V2, integración del reporte, configuración de hojas y
   corrige la fuente Desglosada para usar
   `ff_PlanOpcionSeleccionCobranza2`.

2. `02_configuracion-empresa-worker.sql`
   Revisar `@IdEmpresa` y `@HoraWorker`. Habilita el cache para la empresa y
   configura el horario diario del worker.

3. `03_configuracion-passwords-excel-opcional.sql`
   Revisar passwords y banderas. Por seguridad, ambos quedan deshabilitados
   inicialmente. Puede omitirse si no se usarán passwords.

4. `04_carga-inicial-ultimas-4-vigencias.sql`
   Revisar `@IdEmpresa`. Ejecutar fuera del horario de mayor uso; fuerza la
   carga completa de las cuatro vigencias más recientes.

5. `05_validacion-final-qa.sql`
   No modifica información. Debe terminar con estado `OK`.

## Pruebas funcionales QA

- Generar Cobranza para cada una de las cuatro vigencias.
- Comprobar que el Excel contiene `Información`, `Concentrada`, `Desglosada`
  y los resúmenes configurados.
- En vigencias con selecciones activas en `Cobranza2`, `Desglosada` debe tener
  filas reales además de la fila de totales.
- Generar dos reportes dentro del mismo minuto y comprobar que las rutas son
  diferentes.
- Probar password habilitado y deshabilitado con solicitudes nuevas.
- Confirmar que `bf_RepConf_Debug` continúa disponible para otros reportes.

## Rollback operativo

Para evitar usar el cache sin borrar objetos:

```sql
UPDATE dbo.ff_Parametro
SET paValor='0',paFechaUmod=GETDATE()
WHERE paIdEmpresa=186
  AND UPPER(LTRIM(RTRIM(paClase)))='COBRANZA_CACHE';
```

La API regresará al flujo legacy. No ejecutar scripts antiguos de eliminación
ni borrar tablas mientras existan reportes en proceso.

