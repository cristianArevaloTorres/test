

CREATE OR ALTER PROCEDURE ff_Cobranza_v2
    @idEmpresa   INT,
    @idSolTipo   INT,
    @FecIni      VARCHAR(20),
    @FecFin      VARCHAR(20),
    @idVencida   INT,
    @IdPerfil    VARCHAR(MAX),   -- ej. '1,2,3' en lugar de TVP
    @idVIgencia  INT
AS
BEGIN
    SET NOCOUNT ON;

    -- ── Log inicio ──────────────────────────────────────────────
    INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
    VALUES ('cobranza_sp_parametros',
        'idEmpresa='   + CAST(@idEmpresa  AS VARCHAR) +
        ' idSolTipo='  + CAST(@idSolTipo  AS VARCHAR) +
        ' FecIni='     + ISNULL(@FecIni,  'NULL')     +
        ' FecFin='     + ISNULL(@FecFin,  'NULL')     +
        ' idVencida='  + CAST(@idVencida  AS VARCHAR) +
        ' idVIgencia=' + CAST(@idVIgencia AS VARCHAR) +
        ' IdPerfil='   + ISNULL(@IdPerfil,'NULL'));

    DECLARE @tblIdPerfil ListInt;

    INSERT INTO @tblIdPerfil (IdTipoNotificacionCorreo)
    SELECT CAST(LTRIM(RTRIM(value)) AS INT)
    FROM STRING_SPLIT(@IdPerfil, ',')
    WHERE LTRIM(RTRIM(value)) <> '';

    INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
    VALUES ('cobranza_sp_perfiles_parseados',
        'count=' + CAST((SELECT COUNT(1) FROM @tblIdPerfil) AS VARCHAR));

    BEGIN TRY
        EXEC ObtenCobranzaConcentrada_otro_V2_BF3
            @idEmpresa  = @idEmpresa,
            @idSolTipo  = @idSolTipo,
            @FecIni     = @FecIni,
            @FecFin     = @FecFin,
            @idVencida  = @idVencida,
            @IdPerfil   = @tblIdPerfil,
            @idVIgencia = @idVIgencia;

        INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
        VALUES ('cobranza_sp_delegacion_ok', 'ObtenCobranzaConcentrada_otro_V2_BF3 completado');
    END TRY
    BEGIN CATCH
        INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle)
        VALUES ('cobranza_sp_delegacion_error',
            'ERROR ' + CAST(ERROR_NUMBER() AS VARCHAR) + ': ' + ERROR_MESSAGE());
        THROW;
    END CATCH
END
GO



IF NOT EXISTS (SELECT 1 FROM bf_CatReportesSP WHERE catReportesSPId = 11)
BEGIN
    DECLARE @newCatId  INT           = (SELECT MAX(catReportesId)      + 1 FROM bf_CatReportesSP);
    DECLARE @newOrden  INT           = (SELECT MAX(catReportesSPOrden) + 1 FROM bf_CatReportesSP);
    DECLARE @cols      NVARCHAR(MAX) = N'';
    DECLARE @sel       NVARCHAR(MAX) = N'';

    SELECT
        @cols += N',' + QUOTENAME(c.name),
        @sel  += N',' + CASE c.name
                    WHEN 'catReportesSPId'     THEN N'11'
                    WHEN 'catReportesSPNombre' THEN N'''ff_Cobranza_v2'''
                    WHEN 'catReportesId'        THEN CAST(@newCatId AS NVARCHAR)
                    WHEN 'catReportesSPOrden'   THEN CAST(@newOrden  AS NVARCHAR)
                    ELSE QUOTENAME(c.name)
                END
    FROM sys.columns c
    WHERE c.object_id = OBJECT_ID(N'bf_CatReportesSP')
    ORDER BY c.column_id;

    DECLARE @sql NVARCHAR(MAX) =
        N'SET IDENTITY_INSERT bf_CatReportesSP ON; ' +
        N'INSERT INTO bf_CatReportesSP (' + STUFF(@cols,1,1,N'') + N') ' +
        N'SELECT ' + STUFF(@sel,1,1,N'') + N' FROM bf_CatReportesSP WHERE catReportesSPId = 10; ' +
        N'SET IDENTITY_INSERT bf_CatReportesSP OFF;';

    EXEC sp_executesql @sql;
    PRINT N'bf_CatReportesSP id=11 insertado correctamente.';
END
ELSE
    PRINT N'bf_CatReportesSP id=11 ya existe, se omite.';
GO

-- ── Verificación post-deploy ─────────────────────────────────

SELECT catReportesSPId, catReportesSPNombre
FROM bf_CatReportesSP
ORDER BY catReportesSPId;

SELECT name, create_date, modify_date
FROM sys.objects
WHERE name = 'ff_Cobranza_v2' AND type = 'P';
GO



IF NOT EXISTS (SELECT 1 FROM dbo.bf_RepConf_Tabla WHERE catReportesId = 11 AND idEmpresa = 0)
BEGIN
    INSERT INTO dbo.bf_RepConf_Tabla
        (idEmpresa, catReportesId, grupo, columnaGrupo, agruparPorColumna, indexTable,
         tituloTabla, espacioIzquierda, espacioDerecha, alineacion, colorFondo, colorLetra,
         activo, repConfTablaUsuarioAdd, repConfTablaFechaAdd)
    VALUES
        (0,11,'Concentrada',                   NULL,0, 0,NULL,0,0,'Derecha','Blue',NULL,1,0,GETDATE()),
        (0,11,'Desglosada',                    NULL,0, 1,NULL,0,0,'Derecha','Blue',NULL,1,0,GETDATE()),
        (0,11,'Total por coberturas',          NULL,0, 2,NULL,0,0,'Derecha','Blue',NULL,1,0,GETDATE()),
        (0,11,'Total por coberturas Parentesco',NULL,0,6,NULL,0,0,'Derecha','Blue',NULL,1,0,GETDATE()),
        (0,11,'Planes_Parentesco',             NULL,0, 7,NULL,0,0,'Derecha','Blue',NULL,1,0,GETDATE()),
        (0,11,'Transacciones',                 NULL,0, 8,NULL,0,0,'Derecha',NULL,  NULL,1,0,GETDATE()),
        (0,11,'Liquidaciones',                 NULL,0, 9,NULL,0,0,'Derecha',NULL,  NULL,1,0,GETDATE()),
        (0,11,'Dispersiones',                  NULL,0,10,NULL,0,0,'Derecha',NULL,  NULL,1,0,GETDATE());
    PRINT N'bf_RepConf_Tabla: 8 hojas de Cobranza registradas.';
END
ELSE
    PRINT N'bf_RepConf_Tabla catReportesId=11 ya existe, se omite BD-3.';
GO

-- ── BD-4: Registrar columnas en bf_RepConf_Columna ──────────

IF NOT EXISTS (SELECT 1 FROM dbo.bf_RepConf_Columna WHERE catReportesId = 11 AND idEmpresa = 0)
BEGIN
    INSERT INTO dbo.bf_RepConf_Columna
        (idEmpresa, catReportesId, grupo, orden, campoOrigen, encabezado, visible,
         repConfColumnaUsuarioAdd, repConfColumnaFechaAdd)
    VALUES
    -- ─── Concentrada (57 columnas) ──────────────────────────────────────────
    (0,11,'Concentrada', 1,'empresa',               'Empresa',                                      1,0,GETDATE()),
    (0,11,'Concentrada', 2,'NumEMpleado',            'Número Empleado',                              1,0,GETDATE()),
    (0,11,'Concentrada', 3,'CveEmpl',                'Id',                                           1,0,GETDATE()),
    (0,11,'Concentrada', 4,'Paterno',                'Paterno',                                      1,0,GETDATE()),
    (0,11,'Concentrada', 5,'MAterno',                'Materno',                                      1,0,GETDATE()),
    (0,11,'Concentrada', 6,'Nombre1',                'Primer nombre',                                1,0,GETDATE()),
    (0,11,'Concentrada', 7,'Nombre2',                'Segundo nombre',                               1,0,GETDATE()),
    (0,11,'Concentrada', 8,'Sexo',                   'Sexo',                                         1,0,GETDATE()),
    (0,11,'Concentrada', 9,'FechaNac',               'Fecha nacimiento',                             1,0,GETDATE()),
    (0,11,'Concentrada',10,'Edad',                   'Edad',                                         1,0,GETDATE()),
    (0,11,'Concentrada',11,'Confidencial',           'Sueldo confidencial',                          1,0,GETDATE()),
    (0,11,'Concentrada',12,'SueldoMensual',          'Sueldo mensual',                               1,0,GETDATE()),
    (0,11,'Concentrada',13,'SueldoMensualAnt',       'Sueldo mensual anterior',                      1,0,GETDATE()),
    (0,11,'Concentrada',14,'SueldoMensualDif',       'Diferencia Sueldo mensual',                    1,0,GETDATE()),
    (0,11,'Concentrada',15,'TRANSFERIDO',            'Transferido',                                  1,0,GETDATE()),
    (0,11,'Concentrada',16,'NumSolicitud',           'Número solicitud',                             1,0,GETDATE()),
    (0,11,'Concentrada',17,'Perfil',                 'Perfil',                                       1,0,GETDATE()),
    (0,11,'Concentrada',18,'FechaAutorizacion',      'Fecha autorización',                           1,0,GETDATE()),
    (0,11,'Concentrada',19,'GrupoParentescoGMM',    'Grupo Parentesco',                             1,0,GETDATE()),
    (0,11,'Concentrada',20,'MontoGMM',               'Monto GMM mensual',                            1,0,GETDATE()),
    (0,11,'Concentrada',21,'MontoVIDA',              'Monto vida mensual',                           1,0,GETDATE()),
    (0,11,'Concentrada',22,'MontoOTROSPLANES',      'Monto otros mensual',                          1,0,GETDATE()),
    (0,11,'Concentrada',23,'CreditosGMM',            'Créditos GMM mensual',                         1,0,GETDATE()),
    (0,11,'Concentrada',24,'CreditosViDA',           'Créditos vida mensual',                        1,0,GETDATE()),
    (0,11,'Concentrada',25,'MontoTotalCreditos',     'Monto total créditos mensual',                 1,0,GETDATE()),
    (0,11,'Concentrada',26,'MontoTotalCreditosAnt',  'Monto total créditos mensual Anterior',        1,0,GETDATE()),
    (0,11,'Concentrada',27,'DiferenciaCreditos',     'Diferencia Créditos',                          1,0,GETDATE()),
    (0,11,'Concentrada',28,'MontoTotalSelecciones',  'Monto total selecciones mensual',              1,0,GETDATE()),
    (0,11,'Concentrada',29,'MontoTotalSeleccionesAnt','Monto total selecciones anteriores mensual',  1,0,GETDATE()),
    (0,11,'Concentrada',30,'DiferenciaSelecciones',  'Diferencia Selecciones Mensual',               1,0,GETDATE()),
    (0,11,'Concentrada',31,'SobranteCreditos',       'Sobrante créditos mensual',                    1,0,GETDATE()),
    (0,11,'Concentrada',32,'MontoPagCred',           'Monto pagado con créditos mensual',            1,0,GETDATE()),
    (0,11,'Concentrada',33,'MontoDescMensual',       'Descuento empleado mensual',                   1,0,GETDATE()),
    (0,11,'Concentrada',34,'MontoDescMensualAnt',    'Descuento empleado mensual Anterior',          1,0,GETDATE()),
    (0,11,'Concentrada',35,'DiferenciaMonto',        'Diferencia descuento empleado',                1,0,GETDATE()),
    (0,11,'Concentrada',36,'Q1',                     'Q1',                                           1,0,GETDATE()),
    (0,11,'Concentrada',37,'Q2',                     'Q2',                                           1,0,GETDATE()),
    (0,11,'Concentrada',38,'Diferencia',             'Diferencia',                                   1,0,GETDATE()),
    (0,11,'Concentrada',39,'Excedentes',             'Excedentes mensuales',                         1,0,GETDATE()),
    (0,11,'Concentrada',40,'ExcedentesAnt',          'Excedentes anteriores mensuales',              1,0,GETDATE()),
    (0,11,'Concentrada',41,'DiferenciaExcedentes',   'Diferencia Excedentes',                        1,0,GETDATE()),
    (0,11,'Concentrada',42,'MontoFondoAhorroMensual','Monto fondo ahorro mensual',                   1,0,GETDATE()),
    (0,11,'Concentrada',43,'MontoFondoAhorroMensualAnt','Monto fondo ahorro mensual Anterior',       1,0,GETDATE()),
    (0,11,'Concentrada',44,'DiferenciaFH',           'Diferencia Monto fondo ahorro',                1,0,GETDATE()),
    (0,11,'Concentrada',45,'SobranteExcedentes',     'Sobrante de excedentes mensuales',             1,0,GETDATE()),
    (0,11,'Concentrada',46,'AplicExcedentes',        'Aplicación de excedentes mensuales',           1,0,GETDATE()),
    (0,11,'Concentrada',47,'DescuentoEmpleadoFH',    'Descuento empleado de fondo ahorro',           1,0,GETDATE()),
    (0,11,'Concentrada',48,'DescuentoEmpleadoFinal', 'Descuento empleado final mensual',             1,0,GETDATE()),
    (0,11,'Concentrada',49,'CtoEmpleadoNomSeg',      'Costo empleado nómina seguros mensual',        1,0,GETDATE()),
    (0,11,'Concentrada',50,'SobranteExceFinal',      'Sobrante de excedentes final mensual',         1,0,GETDATE()),
    (0,11,'Concentrada',51,'CoberturaDesc',          'Cobertura regalos mensual',                    1,0,GETDATE()),
    (0,11,'Concentrada',52,'NumOficina',             'Número Oficina',                               1,0,GETDATE()),
    (0,11,'Concentrada',53,'NomOficina',             'Nombre Oficina',                               1,0,GETDATE()),
    (0,11,'Concentrada',54,'POFH',                   'Plan Fondo de Ahorro',                         1,0,GETDATE()),
    (0,11,'Concentrada',55,'LocalNumber',            'Observaciones',                                1,0,GETDATE()),
    (0,11,'Concentrada',56,'PagoEmpresa',            'Costo Empresa',                                1,0,GETDATE()),
    (0,11,'Concentrada',57,'PagoEmpleado',           'Costo Empleado',                               1,0,GETDATE()),
    -- ─── Desglosada (43 columnas) ───────────────────────────────────────────
    (0,11,'Desglosada', 1,'EMPRESA',                'Empresa',                                       1,0,GETDATE()),
    (0,11,'Desglosada', 2,'NUMEMPLEADO',             'Número empleado',                              1,0,GETDATE()),
    (0,11,'Desglosada', 3,'idemp',                   'Id',                                           1,0,GETDATE()),
    (0,11,'Desglosada', 4,'Paterno',                 'Paterno',                                      1,0,GETDATE()),
    (0,11,'Desglosada', 5,'Materno',                 'Materno',                                      1,0,GETDATE()),
    (0,11,'Desglosada', 6,'Nombre1',                 'Primer nombre',                                1,0,GETDATE()),
    (0,11,'Desglosada', 7,'Nombre2',                 'Segundo nombre',                               1,0,GETDATE()),
    (0,11,'Desglosada', 8,'Sexo',                    'Sexo',                                         1,0,GETDATE()),
    (0,11,'Desglosada', 9,'FechaNac',                'Fecha nacimiento',                             1,0,GETDATE()),
    (0,11,'Desglosada',10,'Edad',                    'Edad',                                         1,0,GETDATE()),
    (0,11,'Desglosada',11,'Perfil',                  'Perfil',                                       1,0,GETDATE()),
    (0,11,'Desglosada',12,'CVEParentesco',           'CveParentesco',                                1,0,GETDATE()),
    (0,11,'Desglosada',13,'NombreParentesco',        'Parentesco',                                   1,0,GETDATE()),
    (0,11,'Desglosada',14,'TRANSFERIDO',             'Transferido',                                  1,0,GETDATE()),
    (0,11,'Desglosada',15,'SueldoMensual',           'Sueldo mensual',                               1,0,GETDATE()),
    (0,11,'Desglosada',16,'NumSolicitud',            'Número solicitud',                             1,0,GETDATE()),
    (0,11,'Desglosada',17,'PlanD',                   'Plan',                                         1,0,GETDATE()),
    (0,11,'Desglosada',18,'PlanOpcion',              'Cobertura',                                    1,0,GETDATE()),
    (0,11,'Desglosada',19,'GRUPOPARENTESCO',         'Grupo parentesco',                             1,0,GETDATE()),
    (0,11,'Desglosada',20,'CVEPO',                   'CVEPO',                                        1,0,GETDATE()),
    (0,11,'Desglosada',21,'CVEP',                    'CVEP',                                         1,0,GETDATE()),
    (0,11,'Desglosada',22,'TIPOSUMASEG',             'Tipo S.A.',                                    1,0,GETDATE()),
    (0,11,'Desglosada',23,'VALSUMA',                 'Valor S.A.',                                   1,0,GETDATE()),
    (0,11,'Desglosada',24,'PLOrdenCobranza',         'Orden cobranza',                               1,0,GETDATE()),
    (0,11,'Desglosada',25,'ImporteAnual',            'Importe de costos hasta fin de vigencia',      1,0,GETDATE()),
    (0,11,'Desglosada',26,'PrimaNetaAnual',          'Prima neta hasta fin de vigencia',             1,0,GETDATE()),
    (0,11,'Desglosada',27,'ImportexPeriodo',         'Importe de costos por periodo',                1,0,GETDATE()),
    (0,11,'Desglosada',28,'PrimaNetaxPer',           'Prima neta por periodo',                       1,0,GETDATE()),
    (0,11,'Desglosada',29,'MontoTotalCreditos',      'Monto de créditos al fin de vigencia',         1,0,GETDATE()),
    (0,11,'Desglosada',30,'MontoPeridoCreditos',     'Monto de créditos por periodo',                1,0,GETDATE()),
    (0,11,'Desglosada',31,'CostoEmpresa',            'Costo empresa por periodo',                    1,0,GETDATE()),
    (0,11,'Desglosada',32,'CtoEmpresaCash',          'Costo empresa cashflow por periodo',           1,0,GETDATE()),
    (0,11,'Desglosada',33,'CtoEmpresa1erexc',        'Costo empresa 1er. exceso por periodo',        1,0,GETDATE()),
    (0,11,'Desglosada',34,'CtoEmpresaStoploss',      'Costo empresa Stoploss por periodo',           1,0,GETDATE()),
    (0,11,'Desglosada',35,'CostoEmpleado',           'Costo empleado por periodo',                   1,0,GETDATE()),
    (0,11,'Desglosada',36,'CtoEmpleadoCash',         'Costo empleado cashflow por periodo',          1,0,GETDATE()),
    (0,11,'Desglosada',37,'CtoEmpleado1erexc',       'Costo empleado 1er. exceso por periodo',       1,0,GETDATE()),
    (0,11,'Desglosada',38,'CtoEmpleadoStoploss',     'Costo empleado stoploss por periodo',          1,0,GETDATE()),
    (0,11,'Desglosada',39,'CostoEmpleadoExcedente',  'Costo empleado excedentes por periodo',        1,0,GETDATE()),
    (0,11,'Desglosada',40,'CostoEmpleadoReal',       'Costo empleado real por periodo',              1,0,GETDATE()),
    (0,11,'Desglosada',41,'SobranteExcedentes',      'Sobrante excedentes por periodo',              1,0,GETDATE()),
    (0,11,'Desglosada',42,'COSTOEMPRESACRED',        'Costo Empresa',                                1,0,GETDATE()),
    (0,11,'Desglosada',43,'COSTOEMPLEADOCRED',       'Costo Empleado',                               1,0,GETDATE()),
    -- ─── Total por coberturas (10 cols, indexTable 2-5) ─────────────────────
    (0,11,'Total por coberturas', 1,'CVEP',          'Clave de plan',                                1,0,GETDATE()),
    (0,11,'Total por coberturas', 2,'CVEPO',         'Clave de cobertura',                           1,0,GETDATE()),
    (0,11,'Total por coberturas', 3,'PlanD',         'Nombre del plan',                              1,0,GETDATE()),
    (0,11,'Total por coberturas', 4,'ImpPer',        'Importe por periodo',                          1,0,GETDATE()),
    (0,11,'Total por coberturas', 5,'ImpPN',         'Prima neta por periodo',                       1,0,GETDATE()),
    (0,11,'Total por coberturas', 6,'ImpEmpresa',    'Costo empresa por periodo',                    1,0,GETDATE()),
    (0,11,'Total por coberturas', 7,'ImpEmpleado',   'Costo empleado por periodo',                   1,0,GETDATE()),
    (0,11,'Total por coberturas', 8,'ImpEmpExced',   'Costo empleado excedentes',                    1,0,GETDATE()),
    (0,11,'Total por coberturas', 9,'ImpEmpReal',    'Costo empleado real',                          1,0,GETDATE()),
    (0,11,'Total por coberturas',10,'ImpExced',      'Sobrante de excedentes',                       1,0,GETDATE()),
    -- ─── Total por coberturas Parentesco (5 cols, indexTable 6) ─────────────
    (0,11,'Total por coberturas Parentesco',1,'CVEP',        'Clave de plan',                        1,0,GETDATE()),
    (0,11,'Total por coberturas Parentesco',2,'CVEPO',       'Clave de cobertura',                   1,0,GETDATE()),
    (0,11,'Total por coberturas Parentesco',3,'PlanD',       'Nombre Cobertura',                     1,0,GETDATE()),
    (0,11,'Total por coberturas Parentesco',4,'CVEParentesco','Clave Parentesco',                    1,0,GETDATE()),
    (0,11,'Total por coberturas Parentesco',5,'total',       'Cantidad',                             1,0,GETDATE()),
    -- ─── Planes_Parentesco (12 cols, indexTable 7) ──────────────────────────
    (0,11,'Planes_Parentesco', 1,'cvep',             'Clave Plan',                                   1,0,GETDATE()),
    (0,11,'Planes_Parentesco', 2,'cvepo',            'Clave Plan Opcion',                            1,0,GETDATE()),
    (0,11,'Planes_Parentesco', 3,'planD',            'Plan',                                         1,0,GETDATE()),
    (0,11,'Planes_Parentesco', 4,'planopcion',       'Plan Opcion',                                  1,0,GETDATE()),
    (0,11,'Planes_Parentesco', 5,'Parentesco_1',     'TITULAR',                                      1,0,GETDATE()),
    (0,11,'Planes_Parentesco', 6,'Parentesco_2',     'CONYUGE',                                      1,0,GETDATE()),
    (0,11,'Planes_Parentesco', 7,'Parentesco_3',     'HIJO(A)',                                      1,0,GETDATE()),
    (0,11,'Planes_Parentesco', 8,'Parentesco_4',     'PADRE_MADRE',                                  1,0,GETDATE()),
    (0,11,'Planes_Parentesco', 9,'Parentesco_5',     'HERMANO(A)',                                   1,0,GETDATE()),
    (0,11,'Planes_Parentesco',10,'Parentesco_11',    'SUEGRO(A)',                                    1,0,GETDATE()),
    (0,11,'Planes_Parentesco',11,'Parentesco_17',    'OTRO',                                         1,0,GETDATE()),
    (0,11,'Planes_Parentesco',12,'Parentesco_18',    'CONCUBINO(A)',                                 1,0,GETDATE()),
    -- ─── Transacciones Banwire (22 cols) ────────────────────────────────────
    (0,11,'Transacciones', 1,'idtrans',              'ID Trans',                                     1,0,GETDATE()),
    (0,11,'Transacciones', 2,'fechadepago',          'Fecha de Pago',                                1,0,GETDATE()),
    (0,11,'Transacciones', 3,'montoprocesado',       'Monto procesado',                              1,0,GETDATE()),
    (0,11,'Transacciones', 4,'comision_banwire',     'Comisión BanWire',                             1,0,GETDATE()),
    (0,11,'Transacciones', 5,'iva_comision_fija',    'IVA Comisión Fija',                            1,0,GETDATE()),
    (0,11,'Transacciones', 6,'iva',                  'IVA',                                          1,0,GETDATE()),
    (0,11,'Transacciones', 7,'comision_sin_iva',     'Comisión Fija Sin IVA',                        1,0,GETDATE()),
    (0,11,'Transacciones', 8,'comision_msi',         'Comisión MSI',                                 1,0,GETDATE()),
    (0,11,'Transacciones', 9,'ivs_msi',              'IVS MSI',                                      1,0,GETDATE()),
    (0,11,'Transacciones',10,'total_comision',       'Total Comisión',                               1,0,GETDATE()),
    (0,11,'Transacciones',11,'tasa',                 'Tasa',                                         1,0,GETDATE()),
    (0,11,'Transacciones',12,'c_iva',                'C/IVA',                                        1,0,GETDATE()),
    (0,11,'Transacciones',13,'liquidacion',          'Liquidación',                                  1,0,GETDATE()),
    (0,11,'Transacciones',14,'terminal',             'Terminal',                                     1,0,GETDATE()),
    (0,11,'Transacciones',15,'codigoaut',            'codigo_aut',                                   1,0,GETDATE()),
    (0,11,'Transacciones',16,'referencia',           'referencia',                                   1,0,GETDATE()),
    (0,11,'Transacciones',17,'extrefcliente',        'ext_ref_cliente',                              1,0,GETDATE()),
    (0,11,'Transacciones',18,'card',                 'Card',                                         1,0,GETDATE()),
    (0,11,'Transacciones',19,'telefono',             'teléfono',                                     1,0,GETDATE()),
    (0,11,'Transacciones',20,'mail',                 'mail',                                         1,0,GETDATE()),
    (0,11,'Transacciones',21,'comercio',             'Comercio',                                     1,0,GETDATE()),
    (0,11,'Transacciones',22,'meses_financiados',    'Meses Financiados',                            1,0,GETDATE()),
    -- ─── Liquidaciones Banwire (9 cols) ─────────────────────────────────────
    (0,11,'Liquidaciones', 1,'idTransaccion',        'ID TRANSACCION',                               1,0,GETDATE()),
    (0,11,'Liquidaciones', 2,'MontoTransaccion',     'Monto transaccion',                            1,0,GETDATE()),
    (0,11,'Liquidaciones', 3,'num',                  '#',                                            1,0,GETDATE()),
    (0,11,'Liquidaciones', 4,'estatus',              'Estatus',                                      1,0,GETDATE()),
    (0,11,'Liquidaciones', 5,'Clave',                'Clave',                                        1,0,GETDATE()),
    (0,11,'Liquidaciones', 6,'NombreBeneficiario',   'NOMBRE_BENEFICIARIO',                          1,0,GETDATE()),
    (0,11,'Liquidaciones', 7,'monto',                'MONTO',                                        1,0,GETDATE()),
    (0,11,'Liquidaciones', 8,'ConceptoPago',         'CONCEPTO_PAGO',                                1,0,GETDATE()),
    (0,11,'Liquidaciones', 9,'email_benef',          'EMAIL_BENEFICIARIO',                           1,0,GETDATE()),
    -- ─── Dispersiones Banwire (3 cols) ──────────────────────────────────────
    (0,11,'Dispersiones', 1,'ConceptoDispersion',    'NOMBRE_BENEFICIARIO',                          1,0,GETDATE()),
    (0,11,'Dispersiones', 2,'monto',                 'MONTO',                                        1,0,GETDATE()),
    (0,11,'Dispersiones', 3,'cuenta',                'CUENTA_BENEFICIARIO',                          1,0,GETDATE());

    PRINT N'bf_RepConf_Columna: columnas de Cobranza registradas (Default + Banwire).';
END
ELSE
    PRINT N'bf_RepConf_Columna catReportesId=11 ya existe, se omite BD-4.';
GO


SELECT grupo, indexTable, activo
FROM dbo.bf_RepConf_Tabla
WHERE catReportesId = 11
ORDER BY indexTable;

SELECT grupo, orden, campoOrigen, encabezado
FROM dbo.bf_RepConf_Columna
WHERE catReportesId = 11 AND idEmpresa = 0
ORDER BY grupo, orden;
GO


IF NOT EXISTS (SELECT 1 FROM bf_CatalogoReporteGen WHERE CatRptId = 11)
BEGIN
    SET IDENTITY_INSERT bf_CatalogoReporteGen ON;

    INSERT INTO bf_CatalogoReporteGen
        (CatRptId, CatRptNombre, CatRptProgramado, CatRptActivo,
         CatRptUsuarioAdd, CatRptFechaAdd, CatRptUsuarioMod, CatRptFechaMod,
         CatRptUsuarioDel, CatRptFechaDel)
    VALUES
        (11, 'Cobranza', 0, 1,
         1, GETDATE(), 1, GETDATE(),
         1, GETDATE());

    SET IDENTITY_INSERT bf_CatalogoReporteGen OFF;

    PRINT 'bf_CatalogoReporteGen: Cobranza (id=11) registrada.';
END
ELSE
    PRINT 'bf_CatalogoReporteGen id=11 ya existe, se omite BD-5.';
GO


SELECT CatRptId, CatRptNombre, CatRptActivo
FROM bf_CatalogoReporteGen
ORDER BY CatRptId;
GO


GO
