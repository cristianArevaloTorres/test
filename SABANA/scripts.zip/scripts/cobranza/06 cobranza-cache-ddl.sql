
IF NOT EXISTS (
    SELECT 1 FROM sys.tables WHERE name = 'bf_CobranzaCache_Ctrl' AND schema_id = SCHEMA_ID('dbo')
)
BEGIN
    CREATE TABLE dbo.bf_CobranzaCache_Ctrl (
        ccIdEmpresa     INT            NOT NULL,
        ccIdVigencia    INT            NOT NULL,
        ccMes           TINYINT        NOT NULL,
        ccAnio          SMALLINT       NOT NULL,
        ccIdVencida     TINYINT        NOT NULL,
        ccFecIni        VARCHAR(16)    NOT NULL,
        ccFecFin        VARCHAR(16)    NOT NULL,
        ccRutaArchivo   VARCHAR(500)   NOT NULL CONSTRAINT DF_CCC_Ruta DEFAULT '',
        ccFecCalculo    DATETIME2      NOT NULL CONSTRAINT DF_CCC_Fec  DEFAULT SYSUTCDATETIME(),
        ccEstado        VARCHAR(20)    NOT NULL CONSTRAINT DF_CCC_Est  DEFAULT 'PENDIENTE',
        CONSTRAINT PK_bf_CobranzaCache_Ctrl
            PRIMARY KEY CLUSTERED (ccIdEmpresa, ccIdVigencia, ccMes, ccAnio, ccIdVencida)
    );
    PRINT '>> bf_CobranzaCache_Ctrl creada OK';
END
ELSE
    PRINT '>> bf_CobranzaCache_Ctrl ya existe, omitido';
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes WHERE name = 'IX_CCC_FecCalculo' AND object_id = OBJECT_ID('dbo.bf_CobranzaCache_Ctrl')
)
BEGIN
    CREATE NONCLUSTERED INDEX IX_CCC_FecCalculo
        ON dbo.bf_CobranzaCache_Ctrl (ccEstado, ccFecCalculo)
        INCLUDE (ccIdEmpresa, ccIdVigencia, ccIdVencida, ccRutaArchivo);
    PRINT '>> IX_CCC_FecCalculo creado OK';
END
ELSE
    PRINT '>> IX_CCC_FecCalculo ya existe, omitido';
GO

-- ── PASO 3: Registros en ff_Parametro (paId=200) ────────────
-- Mismo patrón que la contraseña (paId=12, paIdEmpresa=186).
-- paId=200 es el identificador del parámetro "cache nocturno cobranza".
-- Verificar primero que 200 no esté usado: SELECT * FROM ff_Parametro WHERE paId=200;

-- Default global: todas las empresas sin fila propia tienen cache OFF
IF EXISTS (SELECT 1 FROM dbo.ff_Parametro WHERE paId=200 AND paIdEmpresa=0 AND paidEstatus=1)
BEGIN
    PRINT 'Registro paId=200 empresa=0 encontrado — actualizando a OFF...';
    UPDATE dbo.ff_Parametro
    SET    paValor = '0'
    WHERE  paId=200 AND paIdEmpresa=0 AND paidEstatus=1;
END
ELSE
BEGIN
    PRINT 'Registro paId=200 empresa=0 no existe — insertando...';
    INSERT INTO dbo.ff_Parametro
        (paId, paIdEmpresa, paClase, paValor, paDescripcion,                              paidEstatus, paUsuarioAdd, paFechaAdd)
    VALUES
        (200,  0,           '',      '0',     'Cache nocturno cobranza (0=off, 1=on)',    1,           1,            GETDATE());
END
GO

-- Empresa 186: cache ON explícito
IF EXISTS (SELECT 1 FROM dbo.ff_Parametro WHERE paId=200 AND paIdEmpresa=186 AND paidEstatus=1)
BEGIN
    PRINT 'Registro paId=200 empresa=186 encontrado — actualizando a ON...';
    UPDATE dbo.ff_Parametro
    SET    paValor = '1'
    WHERE  paId=200 AND paIdEmpresa=186 AND paidEstatus=1;
END
ELSE
BEGIN
    PRINT 'Registro paId=200 empresa=186 no existe — insertando...';
    INSERT INTO dbo.ff_Parametro
        (paId, paIdEmpresa, paClase, paValor, paDescripcion,                              paidEstatus, paUsuarioAdd, paFechaAdd)
    VALUES
        (200,  186,         '',      '1',     'Cache nocturno cobranza (0=off, 1=on)',    1,           1,            GETDATE());
END
GO

-- ── PASO 4: Verificación ────────────────────────────────────
-- Confirma los registros y qué vigencias procesará el job esta noche
SELECT paId, paIdEmpresa, paValor, paDescripcion
FROM   dbo.ff_Parametro
WHERE  paId = 200;

-- Vigencias que el job va a procesar (empresa configurada + sin cache de hoy)
SELECT E.EMidEmpresa, E.EMNombre, V.VIidVigencia,
       CASE
           WHEN EXISTS (SELECT 1 FROM ff_Parametro
                        WHERE paId=200 AND paIdEmpresa=E.EMidEmpresa AND paidEstatus=1 AND paValor='1')
           THEN 'fila propia ON'
           ELSE 'hereda global ON'
       END AS origen_config
FROM   ff_Empresa E
       INNER JOIN ff_Vigencia V ON V.VIidConfiguracion = E.EMidConfiguracion
WHERE  E.EMidEstatus = 1
  AND  V.VIidEstatus IN (1, 3)
  AND  NOT EXISTS (
           SELECT 1 FROM dbo.bf_CobranzaCache_Ctrl C
           WHERE  C.ccIdEmpresa=E.EMidEmpresa AND C.ccIdVigencia=V.VIidVigencia
             AND  C.ccEstado='VIGENTE' AND CAST(C.ccFecCalculo AS DATE)=CAST(GETDATE() AS DATE)
       )
  AND  (
           EXISTS (SELECT 1 FROM dbo.ff_Parametro
                   WHERE paId=200 AND paIdEmpresa=E.EMidEmpresa AND paidEstatus=1 AND paValor='1')
        OR (    NOT EXISTS (SELECT 1 FROM dbo.ff_Parametro
                            WHERE paId=200 AND paIdEmpresa=E.EMidEmpresa AND paidEstatus=1)
            AND EXISTS (SELECT 1 FROM dbo.ff_Parametro
                        WHERE paId=200 AND paIdEmpresa=0 AND paidEstatus=1 AND paValor='1'))
       );
GO

-- ── PASO 5: Agregar columna ccDatos (no usada, mantenida por compatibilidad) ──
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE  object_id = OBJECT_ID('dbo.bf_CobranzaCache_Ctrl') AND name = 'ccDatos'
)
BEGIN
    ALTER TABLE dbo.bf_CobranzaCache_Ctrl ADD ccDatos NVARCHAR(MAX) NULL;
    PRINT '>> columna ccDatos agregada OK (compatibilidad)';
END
ELSE
    PRINT '>> columna ccDatos ya existe, omitido';
GO

-- ── PASO 6: Tablas de cache — una por cada result-set del SP ─────────────────
-- Cada tabla tiene las mismas columnas que devuelve el SP (NVARCHAR para portabilidad)
-- más columnas meta ccd* para lookup. Si existe la tabla bf_CobranzaCache_Datos
-- anterior (JSON o EAV), se elimina primero.
IF OBJECT_ID('dbo.bf_CobranzaCache_Datos','U') IS NOT NULL
BEGIN
    DROP TABLE dbo.bf_CobranzaCache_Datos;
    PRINT '>> bf_CobranzaCache_Datos (anterior) eliminada';
END
GO

-- ── 6.1 Concentrada (57 columnas del SP) ─────────────────────────────────────
IF OBJECT_ID('dbo.bf_CobranzaCache_Concentrada','U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_CobranzaCache_Concentrada (
        ccdId                      BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT PK_CCCONC PRIMARY KEY CLUSTERED,
        ccdIdEmpresa               INT           NOT NULL,
        ccdIdVigencia              INT           NOT NULL,
        ccdIdVencida               TINYINT       NOT NULL,
        ccdFecCalculo              DATETIME2(3)  NOT NULL CONSTRAINT DF_CCCONC_Fec DEFAULT SYSUTCDATETIME(),
        empresa                    NVARCHAR(500) NULL,
        NumEMpleado                NVARCHAR(100) NULL,
        CveEmpl                    NVARCHAR(100) NULL,
        Paterno                    NVARCHAR(200) NULL,
        MAterno                    NVARCHAR(200) NULL,
        Nombre1                    NVARCHAR(200) NULL,
        Nombre2                    NVARCHAR(200) NULL,
        Sexo                       NVARCHAR(10)  NULL,
        FechaNac                   NVARCHAR(50)  NULL,
        Edad                       NVARCHAR(10)  NULL,
        Confidencial               NVARCHAR(100) NULL,
        SueldoMensual              NVARCHAR(100) NULL,
        SueldoMensualAnt           NVARCHAR(100) NULL,
        SueldoMensualDif           NVARCHAR(100) NULL,
        TRANSFERIDO                NVARCHAR(50)  NULL,
        NumSolicitud               NVARCHAR(100) NULL,
        Perfil                     NVARCHAR(200) NULL,
        FechaAutorizacion          NVARCHAR(50)  NULL,
        GrupoParentescoGMM         NVARCHAR(200) NULL,
        MontoGMM                   NVARCHAR(100) NULL,
        MontoVIDA                  NVARCHAR(100) NULL,
        MontoOTROSPLANES           NVARCHAR(100) NULL,
        CreditosGMM                NVARCHAR(100) NULL,
        CreditosViDA               NVARCHAR(100) NULL,
        MontoTotalCreditos         NVARCHAR(100) NULL,
        MontoTotalCreditosAnt      NVARCHAR(100) NULL,
        DiferenciaCreditos         NVARCHAR(100) NULL,
        MontoTotalSelecciones      NVARCHAR(100) NULL,
        MontoTotalSeleccionesAnt   NVARCHAR(100) NULL,
        DiferenciaSelecciones      NVARCHAR(100) NULL,
        SobranteCreditos           NVARCHAR(100) NULL,
        MontoPagCred               NVARCHAR(100) NULL,
        MontoDescMensual           NVARCHAR(100) NULL,
        MontoDescMensualAnt        NVARCHAR(100) NULL,
        DiferenciaMonto            NVARCHAR(100) NULL,
        Q1                         NVARCHAR(100) NULL,
        Q2                         NVARCHAR(100) NULL,
        Diferencia                 NVARCHAR(100) NULL,
        Excedentes                 NVARCHAR(100) NULL,
        ExcedentesAnt              NVARCHAR(100) NULL,
        DiferenciaExcedentes       NVARCHAR(100) NULL,
        MontoFondoAhorroMensual    NVARCHAR(100) NULL,
        MontoFondoAhorroMensualAnt NVARCHAR(100) NULL,
        DiferenciaFH               NVARCHAR(100) NULL,
        SobranteExcedentes         NVARCHAR(100) NULL,
        AplicExcedentes            NVARCHAR(100) NULL,
        DescuentoEmpleadoFH        NVARCHAR(100) NULL,
        DescuentoEmpleadoFinal     NVARCHAR(100) NULL,
        CtoEmpleadoNomSeg          NVARCHAR(100) NULL,
        SobranteExceFinal          NVARCHAR(100) NULL,
        CoberturaDesc              NVARCHAR(100) NULL,
        NumOficina                 NVARCHAR(100) NULL,
        NomOficina                 NVARCHAR(200) NULL,
        POFH                       NVARCHAR(200) NULL,
        LocalNumber                NVARCHAR(200) NULL,
        PagoEmpresa                NVARCHAR(100) NULL,
        PagoEmpleado               NVARCHAR(100) NULL
    );
    CREATE NONCLUSTERED INDEX IX_CCCONC_Lookup
        ON dbo.bf_CobranzaCache_Concentrada (ccdIdEmpresa, ccdIdVigencia, ccdIdVencida);
    PRINT '>> bf_CobranzaCache_Concentrada creada OK';
END
ELSE PRINT '>> bf_CobranzaCache_Concentrada ya existe, omitido';
GO

-- ── 6.2 Desglosada (43 columnas del SP) ──────────────────────────────────────
IF OBJECT_ID('dbo.bf_CobranzaCache_Desglosada','U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_CobranzaCache_Desglosada (
        ccdId                  BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT PK_CCDEG PRIMARY KEY CLUSTERED,
        ccdIdEmpresa           INT           NOT NULL,
        ccdIdVigencia          INT           NOT NULL,
        ccdIdVencida           TINYINT       NOT NULL,
        ccdFecCalculo          DATETIME2(3)  NOT NULL CONSTRAINT DF_CCDEG_Fec DEFAULT SYSUTCDATETIME(),
        EMPRESA                NVARCHAR(500) NULL,
        NUMEMPLEADO            NVARCHAR(100) NULL,
        idemp                  NVARCHAR(100) NULL,
        Paterno                NVARCHAR(200) NULL,
        Materno                NVARCHAR(200) NULL,
        Nombre1                NVARCHAR(200) NULL,
        Nombre2                NVARCHAR(200) NULL,
        Sexo                   NVARCHAR(10)  NULL,
        FechaNac               NVARCHAR(50)  NULL,
        Edad                   NVARCHAR(10)  NULL,
        Perfil                 NVARCHAR(200) NULL,
        CVEParentesco          NVARCHAR(100) NULL,
        NombreParentesco       NVARCHAR(200) NULL,
        TRANSFERIDO            NVARCHAR(50)  NULL,
        SueldoMensual          NVARCHAR(100) NULL,
        NumSolicitud           NVARCHAR(100) NULL,
        PlanD                  NVARCHAR(200) NULL,
        PlanOpcion             NVARCHAR(200) NULL,
        GRUPOPARENTESCO        NVARCHAR(200) NULL,
        CVEPO                  NVARCHAR(100) NULL,
        CVEP                   NVARCHAR(100) NULL,
        TIPOSUMASEG            NVARCHAR(100) NULL,
        VALSUMA                NVARCHAR(100) NULL,
        PLOrdenCobranza        NVARCHAR(100) NULL,
        ImporteAnual           NVARCHAR(100) NULL,
        PrimaNetaAnual         NVARCHAR(100) NULL,
        ImportexPeriodo        NVARCHAR(100) NULL,
        PrimaNetaxPer          NVARCHAR(100) NULL,
        MontoTotalCreditos     NVARCHAR(100) NULL,
        MontoPeridoCreditos    NVARCHAR(100) NULL,
        CostoEmpresa           NVARCHAR(100) NULL,
        CtoEmpresaCash         NVARCHAR(100) NULL,
        CtoEmpresa1erexc       NVARCHAR(100) NULL,
        CtoEmpresaStoploss     NVARCHAR(100) NULL,
        CostoEmpleado          NVARCHAR(100) NULL,
        CtoEmpleadoCash        NVARCHAR(100) NULL,
        CtoEmpleado1erexc      NVARCHAR(100) NULL,
        CtoEmpleadoStoploss    NVARCHAR(100) NULL,
        CostoEmpleadoExcedente NVARCHAR(100) NULL,
        CostoEmpleadoReal      NVARCHAR(100) NULL,
        SobranteExcedentes     NVARCHAR(100) NULL,
        COSTOEMPRESACRED       NVARCHAR(100) NULL,
        COSTOEMPLEADOCRED      NVARCHAR(100) NULL
    );
    CREATE NONCLUSTERED INDEX IX_CCDEG_Lookup
        ON dbo.bf_CobranzaCache_Desglosada (ccdIdEmpresa, ccdIdVigencia, ccdIdVencida);
    PRINT '>> bf_CobranzaCache_Desglosada creada OK';
END
ELSE PRINT '>> bf_CobranzaCache_Desglosada ya existe, omitido';
GO

-- ── 6.3 Total por coberturas (10 columnas) ───────────────────────────────────
IF OBJECT_ID('dbo.bf_CobranzaCache_TotCoberturas','U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_CobranzaCache_TotCoberturas (
        ccdId         BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT PK_CCTC PRIMARY KEY CLUSTERED,
        ccdIdEmpresa  INT           NOT NULL,
        ccdIdVigencia INT           NOT NULL,
        ccdIdVencida  TINYINT       NOT NULL,
        ccdFecCalculo DATETIME2(3)  NOT NULL CONSTRAINT DF_CCTC_Fec DEFAULT SYSUTCDATETIME(),
        CVEP          NVARCHAR(100) NULL,
        CVEPO         NVARCHAR(100) NULL,
        PlanD         NVARCHAR(200) NULL,
        ImpPer        NVARCHAR(100) NULL,
        ImpPN         NVARCHAR(100) NULL,
        ImpEmpresa    NVARCHAR(100) NULL,
        ImpEmpleado   NVARCHAR(100) NULL,
        ImpEmpExced   NVARCHAR(100) NULL,
        ImpEmpReal    NVARCHAR(100) NULL,
        ImpExced      NVARCHAR(100) NULL
    );
    CREATE NONCLUSTERED INDEX IX_CCTC_Lookup
        ON dbo.bf_CobranzaCache_TotCoberturas (ccdIdEmpresa, ccdIdVigencia, ccdIdVencida);
    PRINT '>> bf_CobranzaCache_TotCoberturas creada OK';
END
ELSE PRINT '>> bf_CobranzaCache_TotCoberturas ya existe, omitido';
GO

-- ── 6.4 Total por coberturas Parentesco (5 columnas) ─────────────────────────
IF OBJECT_ID('dbo.bf_CobranzaCache_TotCoberturasP','U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_CobranzaCache_TotCoberturasP (
        ccdId         BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT PK_CCTP PRIMARY KEY CLUSTERED,
        ccdIdEmpresa  INT           NOT NULL,
        ccdIdVigencia INT           NOT NULL,
        ccdIdVencida  TINYINT       NOT NULL,
        ccdFecCalculo DATETIME2(3)  NOT NULL CONSTRAINT DF_CCTP_Fec DEFAULT SYSUTCDATETIME(),
        CVEP          NVARCHAR(100) NULL,
        CVEPO         NVARCHAR(100) NULL,
        PlanD         NVARCHAR(200) NULL,
        CVEParentesco NVARCHAR(100) NULL,
        total         NVARCHAR(100) NULL
    );
    CREATE NONCLUSTERED INDEX IX_CCTP_Lookup
        ON dbo.bf_CobranzaCache_TotCoberturasP (ccdIdEmpresa, ccdIdVigencia, ccdIdVencida);
    PRINT '>> bf_CobranzaCache_TotCoberturasP creada OK';
END
ELSE PRINT '>> bf_CobranzaCache_TotCoberturasP ya existe, omitido';
GO

-- ── 6.5 Planes Parentesco (12 columnas) ──────────────────────────────────────
IF OBJECT_ID('dbo.bf_CobranzaCache_PlanesParentesco','U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_CobranzaCache_PlanesParentesco (
        ccdId         BIGINT        IDENTITY(1,1) NOT NULL CONSTRAINT PK_CCPP PRIMARY KEY CLUSTERED,
        ccdIdEmpresa  INT           NOT NULL,
        ccdIdVigencia INT           NOT NULL,
        ccdIdVencida  TINYINT       NOT NULL,
        ccdFecCalculo DATETIME2(3)  NOT NULL CONSTRAINT DF_CCPP_Fec DEFAULT SYSUTCDATETIME(),
        cvep          NVARCHAR(100) NULL,
        cvepo         NVARCHAR(100) NULL,
        planD         NVARCHAR(200) NULL,
        planopcion    NVARCHAR(200) NULL,
        Parentesco_1  NVARCHAR(100) NULL,
        Parentesco_2  NVARCHAR(100) NULL,
        Parentesco_3  NVARCHAR(100) NULL,
        Parentesco_4  NVARCHAR(100) NULL,
        Parentesco_5  NVARCHAR(100) NULL,
        Parentesco_11 NVARCHAR(100) NULL,
        Parentesco_17 NVARCHAR(100) NULL,
        Parentesco_18 NVARCHAR(100) NULL
    );
    CREATE NONCLUSTERED INDEX IX_CCPP_Lookup
        ON dbo.bf_CobranzaCache_PlanesParentesco (ccdIdEmpresa, ccdIdVigencia, ccdIdVencida);
    PRINT '>> bf_CobranzaCache_PlanesParentesco creada OK';
END
ELSE PRINT '>> bf_CobranzaCache_PlanesParentesco ya existe, omitido';
GO

-- Consultas útiles para validar el cache de empresa 186:
-- SELECT empresa, NumEMpleado, PagoEmpresa, PagoEmpleado FROM dbo.bf_CobranzaCache_Concentrada    WHERE ccdIdEmpresa=186;
-- SELECT EMPRESA, NUMEMPLEADO, CostoEmpresa, CostoEmpleado FROM dbo.bf_CobranzaCache_Desglosada  WHERE ccdIdEmpresa=186;
-- SELECT CVEP, CVEPO, PlanD, ImpPer, ImpEmpresa FROM dbo.bf_CobranzaCache_TotCoberturas          WHERE ccdIdEmpresa=186;
-- SELECT cvep, cvepo, planD, Parentesco_1 FROM dbo.bf_CobranzaCache_PlanesParentesco              WHERE ccdIdEmpresa=186;
GO

-- ── CÓMO SE LLENA bf_CobranzaCache_Ctrl ─────────────────────────────────────
-- El job (CobranzaCacheJob) corre a las 23:59, invoca el SP ff_Cobranza_v2,
-- serializa el resultado como JSON y lo guarda en ccDatos (sin generar archivo).
-- Cuando el usuario solicita cobranza, el servicio lee ccDatos, deserializa y
-- genera el Excel en el momento (sólo la generación, no el SP de 3 minutos).
--
-- Para forzar re-cómputo urgente de una empresa:
-- UPDATE dbo.bf_CobranzaCache_Ctrl SET ccEstado='ERROR'
-- WHERE  ccIdEmpresa=186 AND CAST(ccFecCalculo AS DATE)=CAST(GETDATE() AS DATE);
GO

