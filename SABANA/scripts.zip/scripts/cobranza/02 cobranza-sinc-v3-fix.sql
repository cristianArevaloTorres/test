

CREATE OR ALTER PROCEDURE [dbo].[ff_CobranzaSincronizacion_V3_bf3]
    (@idEmpresa INT, @idVigencia INT)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @created_list BIT = 0;
    IF OBJECT_ID('tempdb..#ListEmpresas') IS NULL
    BEGIN
        CREATE TABLE #ListEmpresas (EMidEmpresa INT);
        INSERT INTO #ListEmpresas SELECT @idEmpresa;
        SET @created_list = 1;
    END

    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_inicio', 'idEmpresa=' + CAST(@idEmpresa AS VARCHAR)
            + ' idVigencia=' + CAST(@idVigencia AS VARCHAR)
            + ' created_list=' + CAST(@created_list AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    -- Carga solicitudes ya presentes en las tablas cobranza (evita duplicados)
    CREATE TABLE #TMPSOLICITUDCOBRANZAPO (SOIDSOLICITUD INT PRIMARY KEY);
    CREATE TABLE #TMPSOLICITUDCOBRANZAEC (SOIDSOLICITUD INT PRIMARY KEY);

    INSERT #TMPSOLICITUDCOBRANZAPO
    SELECT DISTINCT POIdSolicitud
    FROM   ff_PlanOpcionSeleccionCobranza2 WITH (NOLOCK)
    WHERE  POidEmpresa  IN (SELECT EMidEmpresa FROM #ListEmpresas)
    AND    POidVigencia = @idVigencia
    AND    POidEstatus  <> 10
    AND    POIdSOLICITUD IS NOT NULL;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_step1_tmpc2po', 'rows=' + CAST(@@ROWCOUNT AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    INSERT #TMPSOLICITUDCOBRANZAEC
    SELECT DISTINCT ECIdSolicitud
    FROM   ff_EdoCuentaCobranza2 WITH (NOLOCK)
    WHERE  ECidEmpresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
    AND    ECIdEstatus  <> 10
    AND    ECIdSOLICITUD IS NOT NULL;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_step2_tmpc2ec', 'rows=' + CAST(@@ROWCOUNT AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    -- Copia nuevas selecciones de plan al snapshot de cobranza
    INSERT INTO ff_PlanOpcionSeleccionCobranza2
    SELECT POidPlanOpcionSeleccion,POidEmpresaFlexiForbes,POidEmpresa,PONumeroEmpleado,POidEmpleado,
           POidParentesco,POEdad,POidGrupoParentesco,POidPlanOpcion,POTarifaNeta,POidSolicitud,POAnexo,
           POCostoRestante,POidPeriodicidadPago,PORequiereAutorizacion,POidVigencia,PODefaulteo,POidEstatus,
           POUsuarioAdd,POFechaAdd,POUsuarioUMod,POFechaUMod,POUsuarioDel,POFechaDel,POAutorizado,POFechaAutorizacion
    FROM   ff_PlanOpcionSeleccion WITH (NOLOCK)
    WHERE  POidEmpresa  IN (SELECT EMidEmpresa FROM #ListEmpresas)
    AND    POidVigencia = @idVigencia
    AND    POIdEstatus <> 10
    AND    POIdSolicitud NOT IN (SELECT SOIDSOLICITUD FROM #TMPSOLICITUDCOBRANZAPO);
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_step3_insert_po', 'rows_nuevos=' + CAST(@@ROWCOUNT AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    -- Copia nuevos movimientos de edo cuenta al snapshot de cobranza
    -- NOLOCK evita lock wait de ~17s cuando la tabla origen es grande
    INSERT INTO ff_EdoCuentaCobranza2
    SELECT ECidEstadoCuenta,ECidPlanOpcionSeleccion,ECidConcepto,ECidEmpleado,ECNumeroEmpleado,
           ECidEmpresa,ECTipoMovto,ECCantidad,ECDescripcion,ECidSolicitud,ECAnexo,ECidPlanOpcion,
           ECidCompensacion,ECidEstatus,ECUsuarioAdd,ECFechaAdd,ECUsuarioUMod,ECFechaUMod,
           ECUsuarioDel,ECFechaDel,ECTipoConcepto
    FROM   ff_EdoCuenta WITH (NOLOCK)
    WHERE  ECidEmpresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
    AND    ECIdSolicitud NOT IN (SELECT SOIDSOLICITUD FROM #TMPSOLICITUDCOBRANZAEC)
    AND    ECIdEstatus <> 10;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_step4_insert_ec', 'rows_nuevos=' + CAST(@@ROWCOUNT AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    -- Sincroniza cambios de estatus: canceladas (5)
    UPDATE ff_EdoCuentaCobranza2 SET ECidEstatus=5, ECFechaUMod=GETDATE()
    FROM   ff_EdoCuentaCobranza2 A
    INNER JOIN ff_Solicitud B ON B.SOIdSolicitud=A.ECidSolicitud
                             AND B.SOidEmpresa=A.ECidEmpresa
                             AND B.SOEstatusSolicitud=5
                             AND B.SOIdVigencia=@idVigencia
    WHERE  A.ECidEmpresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
    AND    A.ECidEstatus=1;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_step5_upd_ec_5', 'rows=' + CAST(@@ROWCOUNT AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    UPDATE ff_PlanOpcionSeleccionCobranza2 SET POidEstatus=5, POFechaUMod=GETDATE()
    FROM   ff_PlanOpcionSeleccionCobranza2 A
    INNER JOIN ff_Solicitud B ON B.SOIdSolicitud=A.POidSolicitud
                             AND B.SOidEmpresa=A.POidEmpresa
                             AND B.SOEstatusSolicitud=5
    WHERE  A.POidEmpresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
    AND    A.POidVigencia=@idVigencia
    AND    A.POidEstatus=1;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_step6_upd_po_5', 'rows=' + CAST(@@ROWCOUNT AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    -- Sincroniza cambios de estatus: defaulteadas (4)
    UPDATE ff_EdoCuentaCobranza2 SET ECidEstatus=4, ECFechaUMod=GETDATE()
    FROM   ff_EdoCuentaCobranza2 A
    INNER JOIN ff_Solicitud B ON B.SOIdSolicitud=A.ECidSolicitud
                             AND B.SOidEmpresa=A.ECidEmpresa
                             AND B.SOEstatusSolicitud=4
                             AND B.SOIdVigencia=@idVigencia
    WHERE  A.ECidEmpresa=@idEmpresa
    AND    A.ECidEstatus=1;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_step7_upd_ec_4', 'rows=' + CAST(@@ROWCOUNT AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    UPDATE ff_PlanOpcionSeleccionCobranza2 SET PoidEstatus=4, POFechaUMod=GETDATE()
    FROM   ff_PlanOpcionSeleccionCobranza2 A
    INNER JOIN ff_Solicitud B ON B.SOIdSolicitud=A.POIdSolicitud
                             AND B.SOidEmpresa=A.POidEmpresa
                             AND B.SOEstatusSolicitud=4
    WHERE  A.POidEmpresa IN (SELECT EMidEmpresa FROM #ListEmpresas)
    AND    A.POidVigencia=@idVigencia
    AND    A.PoidEstatus=1;
    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_step8_upd_po_4', 'rows=' + CAST(@@ROWCOUNT AS VARCHAR));
    END TRY BEGIN CATCH END CATCH;

    DROP TABLE #TMPSOLICITUDCOBRANZAPO;
    DROP TABLE #TMPSOLICITUDCOBRANZAEC;

    IF @created_list = 1
        DROP TABLE #ListEmpresas;

    BEGIN TRY INSERT INTO dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES('cobranza_sinc_fin', 'completado');
    END TRY BEGIN CATCH END CATCH;
END
GO
