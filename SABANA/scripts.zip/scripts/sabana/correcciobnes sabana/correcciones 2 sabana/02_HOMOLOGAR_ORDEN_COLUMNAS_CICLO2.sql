
BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.bf_RepConf_Tabla', N'U') IS NULL
        THROW 50110, 'No existe dbo.bf_RepConf_Tabla.', 1;
    IF OBJECT_ID(N'dbo.bf_RepConf_Columna', N'U') IS NULL
        THROW 50111, 'No existe dbo.bf_RepConf_Columna.', 1;

    DECLARE @Target TABLE (
        idEmpresa INT NOT NULL,
        perfil NVARCHAR(20) NOT NULL,
        grupo NVARCHAR(100) NOT NULL,
        PRIMARY KEY (idEmpresa, grupo)
    );

    INSERT @Target (idEmpresa, perfil, grupo) VALUES
        (856,  N'CORTEVA', N'GMM'),
        (856,  N'CORTEVA', N'Vida'),
        (856,  N'CORTEVA', N'Opcionales'),
        (166,  N'ATT',     N'Opcionales'),
        (116,  N'SSGT',    N'OPC'),
        (117,  N'SSGT',    N'OPC'),
        (1038, N'BH',      N'GMM'),
        (1038, N'BH',      N'Vida'),
        (1038, N'BH',      N'OPC');

    /* Una tabla especifica es necesaria para que Java prefiera las columnas
       de la empresa sobre el fallback idEmpresa=0. */
    MERGE dbo.bf_RepConf_Tabla AS dst
    USING (
        SELECT x.idEmpresa, t.catReportesId, x.grupo,
               t.columnaGrupo, t.agruparPorColumna, t.indexTable,
               t.tituloTabla, t.espacioIzquierda, t.espacioDerecha,
               t.alineacion, t.colorFondo, t.colorLetra, CAST(1 AS BIT) activo
        FROM @Target x
        JOIN dbo.bf_RepConf_Tabla t
          ON t.idEmpresa = 0
         AND t.catReportesId = 3
         AND UPPER(LTRIM(RTRIM(t.grupo))) = UPPER(LTRIM(RTRIM(x.grupo)))
    ) AS src
      ON dst.idEmpresa = src.idEmpresa
     AND dst.catReportesId = src.catReportesId
     AND dst.grupo = src.grupo
    WHEN MATCHED THEN UPDATE SET
        columnaGrupo = src.columnaGrupo,
        agruparPorColumna = src.agruparPorColumna,
        indexTable = src.indexTable,
        tituloTabla = src.tituloTabla,
        espacioIzquierda = src.espacioIzquierda,
        espacioDerecha = src.espacioDerecha,
        alineacion = src.alineacion,
        colorFondo = src.colorFondo,
        colorLetra = src.colorLetra,
        activo = 1,
        repConfTablaFechaMod = GETDATE()
    WHEN NOT MATCHED THEN INSERT (
        idEmpresa, catReportesId, grupo, columnaGrupo,
        agruparPorColumna, indexTable, tituloTabla,
        espacioIzquierda, espacioDerecha, alineacion,
        colorFondo, colorLetra, activo, repConfTablaUsuarioAdd)
    VALUES (
        src.idEmpresa, src.catReportesId, src.grupo, src.columnaGrupo,
        src.agruparPorColumna, src.indexTable, src.tituloTabla,
        src.espacioIzquierda, src.espacioDerecha, src.alineacion,
        src.colorFondo, src.colorLetra, src.activo, 0);

    DECLARE @Layout TABLE (
        perfil NVARCHAR(20) NOT NULL,
        grupo NVARCHAR(100) NOT NULL,
        orden INT NOT NULL,
        campoOrigen NVARCHAR(200) NOT NULL,
        encabezado NVARCHAR(200) NOT NULL,
        PRIMARY KEY (perfil, grupo, orden),
        UNIQUE (perfil, grupo, campoOrigen)
    );

    /* CORTEVA - GMM */
    INSERT @Layout VALUES
      (N'CORTEVA',N'GMM',1,N'EMNumeroEmpleado',N'No. Empleado'),
      (N'CORTEVA',N'GMM',2,N'EMCertificado',N'Número Certificado'),
      (N'CORTEVA',N'GMM',3,N'EMApellidoPaterno',N'Paterno'),
      (N'CORTEVA',N'GMM',4,N'EMApellidoMaterno',N'Materno'),
      (N'CORTEVA',N'GMM',5,N'EMNombre1',N'Primer Nombre'),
      (N'CORTEVA',N'GMM',6,N'EMNombre2',N'Segundo Nombre'),
      (N'CORTEVA',N'GMM',7,N'SEDescripcion',N'Sexo'),
      (N'CORTEVA',N'GMM',8,N'PADescripcion',N'Parentesco'),
      (N'CORTEVA',N'GMM',9,N'EMFechaNacimiento',N'Fecha de Nacimiento'),
      (N'CORTEVA',N'GMM',10,N'RFC',N'RFC'),
      (N'CORTEVA',N'GMM',11,N'EMEdad',N'Edad'),
      (N'CORTEVA',N'GMM',12,N'EMFechaIngresoEmpresa',N'Fecha Antigüedad'),
      (N'CORTEVA',N'GMM',13,N'PrimeNeta',N'Prima Neta'),
      (N'CORTEVA',N'GMM',14,N'Costo',N'Costo'),
      (N'CORTEVA',N'GMM',15,N'EMOFicina',N'IdOficina'),
      (N'CORTEVA',N'GMM',16,N'Oficina',N'Oficina'),
      (N'CORTEVA',N'GMM',17,N'Exceso_ante',N'Exceso_ante'),
      (N'CORTEVA',N'GMM',18,N'GMM_ANT',N'GMM_ANT'),
      (N'CORTEVA',N'GMM',19,N'Perfil',N'Perfil'),
      (N'CORTEVA',N'GMM',20,N'Folio',N'Folio');

    /* CORTEVA - VIDA */
    INSERT @Layout VALUES
      (N'CORTEVA',N'Vida',1,N'EMNumeroEmpleado',N'No. Empleado'),
      (N'CORTEVA',N'Vida',2,N'EMCertificado',N'Certificado'),
      (N'CORTEVA',N'Vida',3,N'EMApellidoPaterno',N'Paterno'),
      (N'CORTEVA',N'Vida',4,N'EMApellidoMaterno',N'Materno'),
      (N'CORTEVA',N'Vida',5,N'Nombres',N'Nombres'),
      (N'CORTEVA',N'Vida',6,N'SEDescripcion',N'Sexo'),
      (N'CORTEVA',N'Vida',7,N'PADescripcion',N'Parentesco'),
      (N'CORTEVA',N'Vida',8,N'RFC',N'RFC'),
      (N'CORTEVA',N'Vida',9,N'EMFechaNacimiento',N'Fecha de Nacimiento'),
      (N'CORTEVA',N'Vida',10,N'EMEdad',N'Edad'),
      (N'CORTEVA',N'Vida',11,N'EMFechaIngresoEmpresa',N'Fecha Antigüedad'),
      (N'CORTEVA',N'Vida',12,N'EMSalarioBase',N'Sueldo'),
      (N'CORTEVA',N'Vida',13,N'EMOficina',N'EMOficina'),
      (N'CORTEVA',N'Vida',14,N'Oficina',N'Oficina'),
      (N'CORTEVA',N'Vida',15,N'Idemp',N'Idemp'),
      (N'CORTEVA',N'Vida',16,N'INFO',N'INFO'),
      (N'CORTEVA',N'Vida',17,N'30 MESES FALL',N'30 MESES FALL'),
      (N'CORTEVA',N'Vida',18,N'Costo_1',N'Costo_1'),
      (N'CORTEVA',N'Vida',19,N'36 MESES FALL',N'36 MESES FALL'),
      (N'CORTEVA',N'Vida',20,N'Costo_2',N'Costo_2'),
      (N'CORTEVA',N'Vida',21,N'3,250,000 FALL',N'3,250,000 FALL'),
      (N'CORTEVA',N'Vida',22,N'Costo_3',N'Costo_3'),
      (N'CORTEVA',N'Vida',23,N'6,500,000  FALL',N'6,500,000  FALL'),
      (N'CORTEVA',N'Vida',24,N'Costo_4',N'Costo_4'),
      (N'CORTEVA',N'Vida',25,N'7,150,000 FALL',N'7,150,000 FALL'),
      (N'CORTEVA',N'Vida',26,N'Costo_5',N'Costo_5'),
      (N'CORTEVA',N'Vida',27,N'Perfil',N'Perfil'),
      (N'CORTEVA',N'Vida',28,N'30 MESES INVAL',N'30 MESES INVAL'),
      (N'CORTEVA',N'Vida',29,N'Costo_6',N'Costo_6'),
      (N'CORTEVA',N'Vida',30,N'36 MESES INVAL',N'36 MESES INVAL'),
      (N'CORTEVA',N'Vida',31,N'Costo_7',N'Costo_7'),
      (N'CORTEVA',N'Vida',32,N'3,250,000 INVAL',N'3,250,000 INVAL'),
      (N'CORTEVA',N'Vida',33,N'Costo_8',N'Costo_8'),
      (N'CORTEVA',N'Vida',34,N'6,500,000 INVAL',N'6,500,000 INVAL'),
      (N'CORTEVA',N'Vida',35,N'Costo_9',N'Costo_9'),
      (N'CORTEVA',N'Vida',36,N'7,150,000 INVAL',N'7,150,000 INVAL'),
      (N'CORTEVA',N'Vida',37,N'Costo_10',N'Costo_10'),
      (N'CORTEVA',N'Vida',38,N'VIDA EMPLEADO FALLECIMIENTO',N'VIDA EMPLEADO FALLECIMIENTO'),
      (N'CORTEVA',N'Vida',39,N'Costo_11',N'Costo_11'),
      (N'CORTEVA',N'Vida',40,N'VIDA EMPLEADO FALLECIMIENTO1',N'VIDA EMPLEADO FALLECIMIENTO1'),
      (N'CORTEVA',N'Vida',41,N'Costo_12',N'Costo_12'),
      (N'CORTEVA',N'Vida',42,N'VIDA EMPLEADO FALLECIMIENTO2',N'VIDA EMPLEADO FALLECIMIENTO2'),
      (N'CORTEVA',N'Vida',43,N'Costo_13',N'Costo_13'),
      (N'CORTEVA',N'Vida',44,N'VIDA EMPLEADO FALLECIMIENTO3',N'VIDA EMPLEADO FALLECIMIENTO3'),
      (N'CORTEVA',N'Vida',45,N'Costo_14',N'Costo_14'),
      (N'CORTEVA',N'Vida',46,N'VIDA EMPLEADO FALLECIMIENTO4',N'VIDA EMPLEADO FALLECIMIENTO4'),
      (N'CORTEVA',N'Vida',47,N'Costo_15',N'Costo_15'),
      (N'CORTEVA',N'Vida',48,N'VIDA EMPLEADO INVALIDEZ',N'VIDA EMPLEADO INVALIDEZ'),
      (N'CORTEVA',N'Vida',49,N'Costo_16',N'Costo_16'),
      (N'CORTEVA',N'Vida',50,N'VIDA EMPLEADO INVALIDEZ1',N'VIDA EMPLEADO INVALIDEZ1'),
      (N'CORTEVA',N'Vida',51,N'Costo_17',N'Costo_17'),
      (N'CORTEVA',N'Vida',52,N'VIDA EMPLEADO INVALIDEZ2',N'VIDA EMPLEADO INVALIDEZ2'),
      (N'CORTEVA',N'Vida',53,N'Costo_18',N'Costo_18'),
      (N'CORTEVA',N'Vida',54,N'VIDA EMPLEADO INVALIDEZ3',N'VIDA EMPLEADO INVALIDEZ3'),
      (N'CORTEVA',N'Vida',55,N'Costo_19',N'Costo_19'),
      (N'CORTEVA',N'Vida',56,N'VIDA EMPLEADO INVALIDEZ4',N'VIDA EMPLEADO INVALIDEZ4'),
      (N'CORTEVA',N'Vida',57,N'Costo_20',N'Costo_20');

    /* CORTEVA - OPCIONALES */
    INSERT @Layout VALUES
      (N'CORTEVA',N'Opcionales',1,N'EMNumeroEmpleado',N'No. Empleado'),
      (N'CORTEVA',N'Opcionales',2,N'EMApellidoPaterno',N'Paterno'),
      (N'CORTEVA',N'Opcionales',3,N'EMApellidoMaterno',N'Materno'),
      (N'CORTEVA',N'Opcionales',4,N'EMNombre1',N'Primer Nombre'),
      (N'CORTEVA',N'Opcionales',5,N'EMNombre2',N'Segundo Nombre'),
      (N'CORTEVA',N'Opcionales',6,N'SEDescripcion',N'Sexo'),
      (N'CORTEVA',N'Opcionales',7,N'PADescripcion',N'Parentesco'),
      (N'CORTEVA',N'Opcionales',8,N'EMEdad',N'Edad'),
      (N'CORTEVA',N'Opcionales',9,N'EMFechaNacimiento',N'Fecha de Nacimiento'),
      (N'CORTEVA',N'Opcionales',10,N'EMFechaIngresoEmpresa',N'EMFechaIngresoEmpresa'),
      (N'CORTEVA',N'Opcionales',11,N'RFC',N'RFC'),
      (N'CORTEVA',N'Opcionales',12,N'PrimaNeta',N'PrimaNeta'),
      (N'CORTEVA',N'Opcionales',13,N'Costo',N'Costo'),
      (N'CORTEVA',N'Opcionales',14,N'EMOFicina',N'EMOFICINA'),
      (N'CORTEVA',N'Opcionales',15,N'NumExt',N'NumExt'),
      (N'CORTEVA',N'Opcionales',16,N'Oficina',N'Oficina'),
      (N'CORTEVA',N'Opcionales',17,N'NumInt',N'NumInt'),
      (N'CORTEVA',N'Opcionales',18,N'PONombre',N'PONombre'),
      (N'CORTEVA',N'Opcionales',19,N'Perfil',N'Perfil'),
      (N'CORTEVA',N'Opcionales',20,N'Id',N'id'),
      (N'CORTEVA',N'Opcionales',21,N'Folio',N'Folio');

    /* AT&T - OPCIONALES */
    INSERT @Layout VALUES
      (N'ATT',N'Opcionales',1,N'EMNumeroEmpleado',N'No. Empleado'),
      (N'ATT',N'Opcionales',2,N'EMApellidoPaterno',N'Paterno'),
      (N'ATT',N'Opcionales',3,N'EMApellidoMaterno',N'Materno'),
      (N'ATT',N'Opcionales',4,N'EMNombre1',N'Primer Nombre'),
      (N'ATT',N'Opcionales',5,N'PADescripcion',N'Parentesco'),
      (N'ATT',N'Opcionales',6,N'EMNombre2',N'Segundo Nombre'),
      (N'ATT',N'Opcionales',7,N'SEDescripcion',N'Sexo'),
      (N'ATT',N'Opcionales',8,N'EMEdad',N'Edad'),
      (N'ATT',N'Opcionales',9,N'EMFechaIngresoEmpresa',N'EMFechaIngresoEmpresa'),
      (N'ATT',N'Opcionales',10,N'EMFechaNacimiento',N'Fecha de Nacimiento'),
      (N'ATT',N'Opcionales',11,N'PONombre',N'Cobertura'),
      (N'ATT',N'Opcionales',12,N'RFC',N'RFC'),
      (N'ATT',N'Opcionales',13,N'PrimaNeta',N'PrimaNeta'),
      (N'ATT',N'Opcionales',14,N'Costo',N'Costo'),
      (N'ATT',N'Opcionales',15,N'EMOFicina',N'EMOFICINA'),
      (N'ATT',N'Opcionales',16,N'Oficina',N'Oficina'),
      (N'ATT',N'Opcionales',17,N'Perfil',N'Perfil'),
      (N'ATT',N'Opcionales',18,N'Calle',N'Calle'),
      (N'ATT',N'Opcionales',19,N'NumExt',N'Num Ext'),
      (N'ATT',N'Opcionales',20,N'NumInt',N'Num Int'),
      (N'ATT',N'Opcionales',21,N'Colonia',N'Colonia'),
      (N'ATT',N'Opcionales',22,N'Del_Municipio',N'Del o Municipio'),
      (N'ATT',N'Opcionales',23,N'EstadoFiscal',N'Estado'),
      (N'ATT',N'Opcionales',24,N'CP',N'CP'),
      (N'ATT',N'Opcionales',25,N'Folio',N'Folio'),
      (N'ATT',N'Opcionales',26,N'Id',N'id');

    /* SSGT y OPCIONALES de BH */
    INSERT @Layout VALUES
      (N'SSGT',N'OPC',1,N'EMNumeroEmpleado',N'No. Empleado'),
      (N'SSGT',N'OPC',2,N'EMApellidoPaterno',N'Paterno'),
      (N'SSGT',N'OPC',3,N'EMApellidoMaterno',N'Materno'),
      (N'SSGT',N'OPC',4,N'Nombres',N'Nombres'),
      (N'SSGT',N'OPC',5,N'SEDescripcion',N'Sexo'),
      (N'SSGT',N'OPC',6,N'PADescripcion',N'Parentesco'),
      (N'SSGT',N'OPC',7,N'EMFechaNacimiento',N'Fecha de Nacimiento'),
      (N'SSGT',N'OPC',8,N'EMEdad',N'Edad'),
      (N'SSGT',N'OPC',9,N'SONumeroSolicitud',N'Solicitud'),
      (N'SSGT',N'OPC',10,N'EMFechaIngresoEmpresa',N'EMFechaIngresoEmpresa'),
      (N'SSGT',N'OPC',11,N'NumExt',N'NumExt'),
      (N'SSGT',N'OPC',12,N'NumInt',N'NumInt'),
      (N'SSGT',N'OPC',13,N'PrimaNeta',N'PrimaNeta'),
      (N'SSGT',N'OPC',14,N'EmSalariobase',N'EMSalarioBase'),
      (N'SSGT',N'OPC',15,N'Costo',N'Costo'),
      (N'SSGT',N'OPC',16,N'EMOFicina',N'EMOFICINA'),
      (N'SSGT',N'OPC',17,N'Oficina',N'Oficina'),
      (N'SSGT',N'OPC',18,N'EMArea',N'EMArea'),
      (N'SSGT',N'OPC',19,N'RFC',N'RFC'),
      (N'SSGT',N'OPC',20,N'EMIdCentroCostos',N'EMIdCentroCostos'),
      (N'SSGT',N'OPC',21,N'Id',N'id'),
      (N'SSGT',N'OPC',22,N'local_number',N'local_number'),
      (N'SSGT',N'OPC',23,N'Folio',N'Folio'),
      (N'SSGT',N'OPC',24,N'PONombre',N'PONombre');

    INSERT @Layout
    SELECT N'BH', grupo, orden, campoOrigen, encabezado
    FROM @Layout WHERE perfil=N'SSGT' AND grupo=N'OPC';

    /* BH - GMM */
    INSERT @Layout VALUES
      (N'BH',N'GMM',1,N'EMNumeroEmpleado',N'No. Empleado'),
      (N'BH',N'GMM',2,N'EMCertificado',N'Número Certificado'),
      (N'BH',N'GMM',3,N'EMApellidoPaterno',N'Paterno'),
      (N'BH',N'GMM',4,N'EMApellidoMaterno',N'Materno'),
      (N'BH',N'GMM',5,N'Nombres',N'Nombres'),
      (N'BH',N'GMM',6,N'PADescripcion',N'Parentesco'),
      (N'BH',N'GMM',7,N'SEDescripcion',N'Sexo'),
      (N'BH',N'GMM',8,N'EMIdParentesco1',N'EMIdParentesco1'),
      (N'BH',N'GMM',9,N'EMEdad',N'Edad'),
      (N'BH',N'GMM',10,N'EMFechaNacimiento',N'Fecha de Nacimiento'),
      (N'BH',N'GMM',11,N'EMFechaIngresoEmpresa',N'Fecha Antigüedad'),
      (N'BH',N'GMM',12,N'GPDescripcion',N'GMM'),
      (N'BH',N'GMM',13,N'EMOFicina',N'EMOFICINA'),
      (N'BH',N'GMM',14,N'Oficina',N'Oficina'),
      (N'BH',N'GMM',15,N'EMArea',N'EMArea'),
      (N'BH',N'GMM',16,N'EMIdCentroCostos',N'EMIdCentroCostos'),
      (N'BH',N'GMM',17,N'SONumeroSolicitud',N'Solicitud'),
      (N'BH',N'GMM',18,N'GMM_ANT',N'GMM_ANT'),
      (N'BH',N'GMM',19,N'Perfil',N'Perfil'),
      (N'BH',N'GMM',20,N'PrimeNeta',N'PrimeNeta'),
      (N'BH',N'GMM',21,N'Costo',N'Costo'),
      (N'BH',N'GMM',22,N'Exceso_ante',N'Exceso_ante'),
      (N'BH',N'GMM',23,N'IDEmp',N'IDEmp'),
      (N'BH',N'GMM',24,N'INFO',N'INFO'),
      (N'BH',N'GMM',25,N'Ubicacion',N'Ubicacion'),
      (N'BH',N'GMM',26,N'Folio',N'Folio');

    /* BH - VIDA */
    INSERT @Layout VALUES
      (N'BH',N'Vida',1,N'EMNumeroEmpleado',N'No. Empleado'),
      (N'BH',N'Vida',2,N'EMCertificado',N'Número Certificado'),
      (N'BH',N'Vida',3,N'EMApellidoPaterno',N'Paterno'),
      (N'BH',N'Vida',4,N'EMApellidoMaterno',N'Materno'),
      (N'BH',N'Vida',5,N'Nombres',N'Nombres'),
      (N'BH',N'Vida',6,N'EMNombre1',N'EMNombre1'),
      (N'BH',N'Vida',7,N'SEDescripcion',N'Sexo'),
      (N'BH',N'Vida',8,N'PADescripcion',N'Parentesco'),
      (N'BH',N'Vida',9,N'EMEdad',N'Edad'),
      (N'BH',N'Vida',10,N'EMFechaNacimiento',N'Fecha de Nacimiento'),
      (N'BH',N'Vida',11,N'EMNombre2',N'EMNombre2'),
      (N'BH',N'Vida',12,N'EMFechaIngresoEmpresa',N'Fecha Antigüedad'),
      (N'BH',N'Vida',13,N'RFC',N'RFC'),
      (N'BH',N'Vida',14,N'SONumeroSolicitud',N'Solicitud'),
      (N'BH',N'Vida',15,N'EMSalarioBase',N'Sueldo'),
      (N'BH',N'Vida',16,N'Perfil',N'Perfil'),
      (N'BH',N'Vida',17,N'Idemp',N'Idemp'),
      (N'BH',N'Vida',18,N'INFO',N'INFO'),
      (N'BH',N'Vida',19,N'Vida 36 MESES',N'Vida 36 MESES'),
      (N'BH',N'Vida',20,N'Costo_2',N'Costo_2'),
      (N'BH',N'Vida',21,N'Vida 72 MESES',N'Vida 72 MESES'),
      (N'BH',N'Vida',22,N'Costo_3',N'Costo_3'),
      (N'BH',N'Vida',23,N'Vida 24 MESES',N'Vida 24 MESES'),
      (N'BH',N'Vida',24,N'Costo_1',N'Costo_1');

    DELETE c
    FROM dbo.bf_RepConf_Columna c
    JOIN @Target t
      ON t.idEmpresa=c.idEmpresa
     AND t.grupo=c.grupo
    WHERE c.catReportesId=3;

    INSERT dbo.bf_RepConf_Columna (
        idEmpresa, catReportesId, grupo, orden, campoOrigen,
        encabezado, visible, ancho, formato, alinear, tipoDato,
        repConfColumnaUsuarioAdd)
    SELECT t.idEmpresa, 3, t.grupo, l.orden, l.campoOrigen,
           l.encabezado, 1, NULL, NULL, NULL, NULL, 0
    FROM @Target t
    JOIN @Layout l
      ON l.perfil=t.perfil AND l.grupo=t.grupo;

    IF EXISTS (
        SELECT 1
        FROM @Target t
        CROSS APPLY (
            SELECT COUNT(*) cantidad,
                   MIN(orden) minOrden,
                   MAX(orden) maxOrden
            FROM dbo.bf_RepConf_Columna c
            WHERE c.idEmpresa=t.idEmpresa
              AND c.catReportesId=3
              AND c.grupo=t.grupo
              AND c.visible=1
        ) x
        WHERE x.cantidad<>x.maxOrden OR x.minOrden<>1
    )
        THROW 50112, 'La configuracion final contiene huecos o duplicados.', 1;

    COMMIT TRANSACTION;

    /* FOR XML PATH mantiene compatibilidad con motores anteriores a SQL Server 2017. */
    SELECT c.idEmpresa, c.grupo, COUNT(*) columnas,
           STUFF((
               SELECT N' | ' + CONVERT(NVARCHAR(MAX),c2.encabezado)
               FROM dbo.bf_RepConf_Columna c2
               WHERE c2.idEmpresa=c.idEmpresa
                 AND c2.catReportesId=3
                 AND c2.grupo=c.grupo
                 AND c2.visible=1
               ORDER BY c2.orden
               FOR XML PATH(''),TYPE
           ).value('.', 'NVARCHAR(MAX)'),1,3,N'') AS encabezados
    FROM dbo.bf_RepConf_Columna c
    JOIN @Target t ON t.idEmpresa=c.idEmpresa AND t.grupo=c.grupo
    WHERE c.catReportesId=3 AND c.visible=1
    GROUP BY c.idEmpresa,c.grupo
    ORDER BY c.idEmpresa,c.grupo;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH
GO
