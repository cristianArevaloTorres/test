
USE FlexiForbesv2
GO

DECLARE @sp NVARCHAR(MAX)

SELECT @sp = CAST(definition AS NVARCHAR(MAX))
FROM sys.sql_modules WHERE object_id = OBJECT_ID('dbo.ff_SabanaVIDA_v2')

IF @sp IS NULL BEGIN RAISERROR('ff_SabanaVIDA_v2 no existe', 16, 1) RETURN END

DECLARE @lenAntes INT = LEN(@sp)
PRINT 'len_antes=' + CAST(@lenAntes AS VARCHAR(10))

-- Fix 1: muestra los primeros 100 chars para diagnostico, luego DROP+CREATE
PRINT 'inicio: [' + LEFT(@sp, 100) + ']'
PRINT 'pos_CREATE=' + CAST(CHARINDEX('CREATE', @sp) AS VARCHAR(10))

-- DROP + CREATE es mas confiable que intentar parchear CREATE->ALTER
IF OBJECT_ID('dbo.ff_SabanaVIDA_v2', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ff_SabanaVIDA_v2

-- Fix 2: diagnostico del texto exacto alrededor de CSalias
DECLARE @pc INT = CHARINDEX('CSalias', @sp)
PRINT 'pos_CSalias=' + CAST(@pc AS VARCHAR(10))
IF @pc > 0
    PRINT 'contexto: [' + SUBSTRING(@sp, @pc - 15, 80) + ']'

-- Fix 3: reemplazo del alias (patron corto, robusto ante variaciones de espacio)
SET @sp = REPLACE(@sp,
    'CSalias + char(39) + char(13)',
    'CSalias + CASE WHEN Consecutivo=1 THEN '''' ELSE RTRIM(CAST(Consecutivo-1 AS CHAR(2))) END + char(39) + char(13)')

DECLARE @lenDespues INT = LEN(@sp)
PRINT 'len_despues=' + CAST(@lenDespues AS VARCHAR(10))
PRINT 'chars_agregados=' + CAST(@lenDespues - @lenAntes AS VARCHAR(10)) + ' (esperado ~162 para 2 reemplazos)'

IF @lenDespues = @lenAntes
BEGIN
    PRINT 'ADVERTENCIA: patron no encontrado. Mostrando mas contexto:'
    SET @pc = CHARINDEX('CSalias', @sp)
    IF @pc > 0 PRINT SUBSTRING(@sp, @pc - 30, 150)
    RAISERROR('Patron no reemplazado - ver contexto arriba', 16, 1)
    RETURN
END

EXEC sp_executesql @sp
PRINT 'ff_SabanaVIDA_v2 actualizado OK'
GO
