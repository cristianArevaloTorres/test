

-- =============================================================================
-- SCRIPT 1: ff_SabanaGMM_v2
-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_SabanaGMM_v2] (
@idEmpresa int,
@FechaIni varchar(20),
@FechaFin varchar(20),
@idEstatus int,
@idVigencia int,
@Confidencial INT = 0)
AS
BEGIN

DECLARE @IDConfiguracion INT
SET @IDConfiguracion = ISNULL((Select EMidConfiguracion FROM ff_Empresa where EMidEmpresa = @idEmpresa),0)

DECLARE @Kueri as Varchar(max)
DECLARE @KueriII as Varchar(max)

SET @FechaFin = @FechaFin

DECLARE @SOIdEstatus int

SELECT @SOIdEstatus= CASE WHEN EXISTS (select 'k' from ff_Vigencia v2 where v2.VIRenovada= v1.VIidVigencia) THEN 10
        WHEN VIidEstatus not in (1,6) THEN 10  ELSE 1 END
  FROM  ff_Vigencia v1 INNER JOIN ff_Empresa WITH (NOLOCK) ON VIidConfiguracion=EMidConfiguracion
  WHERE EMidEmpresa = @idEmpresa
    AND VIidVigencia = @idVigencia
    AND VITipoNegocio = 1


IF @idEstatus = 1
BEGIN

SET @Kueri = 'SELECT   ''GMM'' as grupo, CS.CSAlias AS NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, EM.EMidParentesco, PA.PADescripcion ,PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre,
RTRIM(EM.EMNumeroEmpleado) as EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
ISNULL(EM.EMNombre1,'+ char(39) + ' '+ char(39) + ') + SPACE(1) + ISNULL(EM.EMNombre2,'+ char(39) + ' '+ char(39) + ') as Nombres ,
convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,  convert(char(10),EM.EMFechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
convert(char(10),ISNULL(EM.EMFechaAlta,EM.EMFechaIngresoEmpresa), 103) AS EMFechaAlta,
SO.SONumeroSolicitud, SE.SEDescripcion, ISNULL(GPDescripcion, PA.PADescripcion) AS GPDescripcion, EMedad,EMOFicina,
(Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='+ CHAR(39)+'EMOFICINA'+CHAR(39)
+ 'AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as '+CHAR(39)+'Oficina' + CHAR(39)+',RTRIM(EMRFC) as RFC,
Perfil=(select pedescripcion from ff_perfil where peidperfil=em.emidperfil),
isnull(emCalleFiscal,'''') as Calle,isnull(EMColoniaFisico,'''') as NumExt,isnull(EMCalleFisico,'''') as NumInt,isnull(emColoniaFiscal,'''') as Colonia,
 isnull(emMunicipioDelegaciónFiscal,'''') as Del_Municipio,
 EstadoFiscal = (Select esDescripcion from ff_Estado where esidEstado = emEstadofiscal),
 isnull(''''+emcodigoPostalFiscal,'''') as CP,
GMM_ANT= ISNULL((select TOP 1 RTRIM(CDPlanOpcion) from ff_cobranzaDetallada col WHERE CDMES=9 and CDAño=2015 AND col.cdidplan in(140,141,162,170,51,52)
and col.CDNumeroEmpleado=POS.PONumeroEmpleado AND POS.poIDEmpresa=col.cdIdEmpresa and col.cdidempleado=POS.Poidempleado),''NUEVO''),
Exceso_ante= ISNULL((select TOP 1 RTRIM(CDPlanOpcion) from ff_cobranzaDetallada col WHERE CDMES=9 and CDAño=2015 AND col.cdidplan in(146,163,168,169,54,53)
and col.CDNumeroEmpleado=POS.PONumeroEmpleado AND POS.poIDEmpresa=col.cdIdEmpresa  and col.cdidempleado=POS.Poidempleado),''NUEVO'' ),
PrimeNeta=
CASE WHEN  EMIdParentesco= 1 AND POS.POIDGrupoParentesco IS NOT NULL  THEN
  ( SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103) from ff_TarifaCosto ppp WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion )
  WHEN  POS.POIDGrupoParentesco IS NULL  THEN
  ISNULL((SELECT CONVERT(CHAR(20),TPPrimaNeta,103) FROM ff_tarifaCostoPerfil WHERE TPidplanopcion=POS.POIDPlanOpcion and TPIdPerfil=em.emidperfil AND TPIdEstatus=1 ),
     (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103) from '+(case when @SOIdEstatus=1 then 'ff_TarifaCosto' else 'ff_TarifaCosto_hist'end)+' ppp
      WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion ) ) ELSE '+CHAR(39)+CHAR(39)+' END,
Costo=
CASE WHEN  EMIdParentesco= 1 AND POS.POIDGrupoParentesco IS NOT NULL THEN
  (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103) from ff_PlanOpcionSeleccion ppp WHERE ppp.PONumeroEmpleado=EM.EMNumeroEmpleado and ppp.POIdPlanOpcion=POS.POIdPlanOpcion
  and ppp.POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID )
  WHEN  POS.POIDGrupoParentesco IS NULL  THEN
  (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103) from ff_PlanOpcionSeleccion ppp WHERE ppp.PONumeroEmpleado=EM.EMNumeroEmpleado and ppp.POIdPlanOpcion=POS.POIdPlanOpcion
  and ppp.POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID )
  ELSE '+CHAR(39)+CHAR(39)+' END'

-- flujo aislado: sin csidvigencia=@idVigencia en el loop de columnas
SELECT @Kueri = @Kueri + ', (SELECT case count(*) when 1 then CONVERT(CHAR(20),SUM(POCostoRestante),103) else '+ char(39) + 'NO'+ char(39) + ' end
from ff_PlanOpcionSeleccion WHERE POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID and POidplanopcion= ' +  cast(CSidplanopcion as varchar(5))  + ' ) as ' + char(39) +  CSalias + char(39) + char(13)
FROM dbo.ff_ConfiguracionSabana  WITH (NOLOCK,READUNCOMMITTED)
where CSidConfiguracion = @IDConfiguracion AND CSIDTiposabana = 1 AND CSPestana = 0 AND CSIDESTATUS = 1
AND CSIdPlanOpcion in (
    SELECT ppidplanOpcion FROM ff_Perfil INNER JOIN ff_PlanOpcionPerfil ON PPidPErfil=PEIdPerfil AND PEAdministrador=0
    WHERE PEIdestatus=1 and PPidestatus=1 AND PEIdEmpresa=@idEmpresa
)
order by CSidplan

SELECT @KueriII = ' , EM.ID as IDEmp,INFO=RTRIM(ISNULL(Desarrollo,'''')),EMArea,EMIdCentroCostos,EMArchivoInformacion as Ubicacion
FROM dbo.ff_PlanOpcionSeleccion POS  WITH (NOLOCK)
INNER JOIN dbo.ff_PlanOpcion PO WITH (NOLOCK) ON POS.poidplanopcion =  PO.POidplanopcion
INNER JOIN dbo.ff_Plan PL WITH (NOLOCK) ON PL.plidplan =  PO.POidplan
INNER JOIN dbo.ff_Empleado EM WITH (NOLOCK) ON EM.ID = POS.poidempleado AND EM.EMNumeroEmpleado not like ''Test%''
INNER JOIN dbo.ff_Parentesco PA WITH (NOLOCK) ON PA.PAidparentesco = EM.EMidparentesco
LEFT OUTER JOIN dbo.ff_GrupoParentesco GP WITH (NOLOCK) ON GP.gpidgrupoparentesco = POS.poidgrupoparentesco
INNER JOIN dbo.ff_ConfiguracionSabana CS WITH (NOLOCK) ON CS.CSidPlanOpcion = POS.POidplanopcion AND CS.CSIdConfiguracion='
+LTRIM(CAST(@IDConfiguracion as varchar(10))) +'
INNER JOIN dbo.ff_Solicitud SO WITH (NOLOCK) ON SO.SOidSolicitud = POS.POidSolicitud
INNER JOIN dbo.ff_Sexo SE WITH (NOLOCK) ON EM.EMidsexo = SE.SEidSexo
WHERE CS.CSidTipoSabana = 1 AND CS.CSPestana = 1 AND POS.POidempresa = '+ cast(@idEmpresa as varchar(30))
+ ' AND POS.POidEstatus in (1, 3, 10) '
+ ' AND SO.SOEstatusSolicitud in (1,3) '
+ 'AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date) ) >= '''+@FechaIni+''' AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= '''+@FechaFin+'''
AND POS.POidvigencia = '+ cast(@idVigencia as varchar(30))
+ ' AND (1=' + cast(@Confidencial as varchar(1)) + ' OR EM.EMidSalarioConfidencial=0)'
+ ' ORDER BY CS.CSidPlan, PO.POOrden, CS.CSidPlanOpcion, EM.EMOFicina,EM.EMNumeroEmpleado, EM.EmidParentesco'

print @Kueri + @KueriII
execute(@Kueri + @KueriII)
END

ELSE IF @idEstatus=2
BEGIN

SET @Kueri = 'SELECT ''GMM'' as grupo, CS.CSAlias AS NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, PA.PADescripcion ,PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre,
RTRIM(EM.EMNumeroEmpleado) as EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
ISNULL(EM.EMNombre1,'+ char(39) + ' '+ char(39) + ') + SPACE(1) + ISNULL(EM.EMNombre2,'+ char(39) + ' '+ char(39) + ') as Nombres ,EM.EMIdParentesco,
convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
convert(char(10),EM.EMFechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
convert(char(10),ISNULL(EM.EMFechaBaja,GETDATE()), 103) AS EMFechaAlta,
SO.SONumeroSolicitud, SE.SEDescripcion, ISNULL(GPDescripcion, PA.PADescripcion) AS GPDescripcion, EMedad,EMOFicina,
(Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
 AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='+ CHAR(39)+'EMOFICINA'+CHAR(39)+ 'AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa))
  as '+CHAR(39)+'Oficina' + CHAR(39)+',RTRIM(EMRFC) as RFC,
 Perfil=(select pedescripcion from ff_perfil where peidperfil=em.emidperfil),
 isnull(emCalleFiscal,'''') as Calle,isnull(EMColoniaFisico,'''') as NumExt,isnull(EMCalleFisico,'''') as NumInt,isnull(emColoniaFiscal,'''') as Colonia,
 isnull(emMunicipioDelegaciónFiscal,'''') as Del_Municipio,
 EstadoFiscal = (Select esDescripcion from ff_Estado where esidEstado = emEstadofiscal),
 isnull(''''+emcodigoPostalFiscal,'''') as CP,
CONVERT(char(10),EMFechaBaja,103) as FechaBaja,
PrimeNeta=
CASE WHEN  EMIdParentesco= 1 AND POS.POIDGrupoParentesco IS NOT NULL  THEN
  (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103)  from '+(case when @SOIdEstatus=1 then 'ff_TarifaCosto' else 'ff_TarifaCosto_hist'end)+' ppp
  WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion )
 WHEN  POS.POIDGrupoParentesco IS NULL  THEN
  (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103)  from '+(case when @SOIdEstatus=1 then 'ff_TarifaCosto' else 'ff_TarifaCosto_hist'end)+' ppp WHERE
  ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion )
 ELSE '+CHAR(39)+CHAR(39)+' END,
Costo=
CASE WHEN  EMIdParentesco= 1 AND POS.POIDGrupoParentesco IS NOT NULL
 THEN (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103)  from ff_PlanOpcionSeleccion ppp WHERE ppp.PONumeroEmpleado=EM.EMNumeroEmpleado and ppp.POIdPlanOpcion=POS.POIdPlanOpcion
   and ppp.POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID )
 WHEN  POS.POIDGrupoParentesco IS NULL
 THEN (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103)  from ff_PlanOpcionSeleccion ppp WHERE ppp.PONumeroEmpleado=EM.EMNumeroEmpleado and ppp.POIdPlanOpcion=POS.POIdPlanOpcion
 and ppp.POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID )
 ELSE '+CHAR(39)+CHAR(39)+' END'

SELECT @Kueri = @Kueri + ', (SELECT case count(*) when 1 then CONVERT(CHAR(20),SUM(POCostoRestante),103) else '+ char(39) + 'NO'+ char(39) + ' end
 from ff_PlanOpcionSeleccion WHERE POIdSolicitud=POS.POidSolicitud AND POidEmpleado = EM.ID and POidplanopcion= ' +  cast(CSidplanopcion as varchar(5))  + ' )
  as ' + char(39) + CSalias + char(39) + char(13) from (
    select distinct CSalias, CSidplanopcion, CSidplan
    FROM dbo.ff_ConfiguracionSabana  WITH (NOLOCK,READUNCOMMITTED)
    where CSidConfiguracion = @IDConfiguracion AND CSIDTiposabana = 1 AND CSPestana = 0 AND CSIDESTATUS = 1
    AND CSIdPlanOpcion in(SELECT ppidplanOpcion FROM ff_Perfil INNER JOIN ff_PlanOpcionPerfil ON PPidPErfil=PEIdPerfil AND PEAdministrador=0 WHERE PEIdestatus=1 and PPidestatus=1 AND PEIdEmpresa=@idEmpresa)
) info order by CSidplan

SELECT @KueriII = ' , EM.ID as IDEmp,INFO=RTRIM(ISNULL(Desarrollo,'''')),EMArea,EMIdCentroCostos,EMArchivoInformacion as Ubicacion
INTO #Registros FROM dbo.ff_PlanOpcionSeleccion POS  WITH (NOLOCK)
INNER JOIN dbo.ff_PlanOpcion PO WITH (NOLOCK) ON POS.poidplanopcion =  PO.POidplanopcion
INNER JOIN dbo.ff_Plan PL WITH (NOLOCK) ON PL.plidplan =  PO.POidplan
INNER JOIN dbo.ff_Empleado EM WITH (NOLOCK) ON EM.ID = POS.poidempleado AND EM.EMNumeroEmpleado not like ''Test%''
INNER JOIN dbo.ff_Parentesco PA WITH (NOLOCK) ON PA.PAidparentesco = EM.EMidparentesco
LEFT OUTER JOIN dbo.ff_GrupoParentesco GP WITH (NOLOCK) ON GP.gpidgrupoparentesco = POS.poidgrupoparentesco
INNER JOIN dbo.ff_ConfiguracionSabana CS WITH (NOLOCK) ON CS.CSidPlanOpcion = POS.POidplanopcion AND CS.CSIdConfiguracion='
+LTRIM(CAST(@IDConfiguracion as varchar(10))) +'
INNER JOIN dbo.ff_Solicitud SO WITH (NOLOCK) ON SO.SOidSolicitud = POS.POidSolicitud
INNER JOIN dbo.ff_Sexo SE WITH (NOLOCK) ON EM.EMidsexo = SE.SEidSexo
WHERE CS.CSidTipoSabana = 1 AND CS.CSPestana = 1 AND POS.POidempresa = '+ cast(@idEmpresa as varchar(30)) + '
AND POS.POidEstatus in(4,5) AND SO.SOEstatusSolicitud in(4,5) AND POS.POidvigencia = '+ cast(@idVigencia as varchar(30))
+ ' AND (SOFechaEstatus >= '+ char(39) + cast(@FechaIni as varchar(10)) + char(39) +' OR EM.EMFechaDel >= '+ char(39) + cast(@FechaIni as varchar(10))+ char(39) +') '
+ ' AND (SOFechaEstatus <= '+ char(39) + cast(@FechaFin as varchar(10)) + char(39) +' OR EM.EMFechaDel <= '+ char(39) + cast(@FechaFin as varchar(10))+ char(39) +') '
+ ' AND Convert(varchar(10),POS.poidempleado,103)+''-''+convert(varchar(10),POS.PoidplanOpcion,103) not in (Select Convert(varchar(10),poidempleado,103)+''-''+convert(varchar(10),PoidplanOpcion,103) from ff_Planopcionseleccion WHERE POIdEstatus=1 AND POidVigencia ='+ cast(@idVigencia as varchar(30))
+ ' AND PONumeroempleado = EM.EMNumeroEmpleado )'
+ ' ORDER BY CS.CSidPlan, PO.POOrden, CS.CSidPlanOpcion, EM.EMOFicina,EM.EMNumeroEmpleado, EM.EmidParentesco
SELECT DISTINCT * FROM #Registros '

print @Kueri + @KueriII
execute(@Kueri + @KueriII)

END
END
GO

-- =============================================================================
-- SCRIPT 2: ff_SabanaVIDA_v2

-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_SabanaVIDA_v2](
@idEmpresa int,
@FechaIni varchar(20),
@FechaFin varchar(20),
@idEstatus int,
@idVigencia int,
@Confidencial INT = 0)
AS
BEGIN
DECLARE @KueriI  Varchar(MAX)
DECLARE @KueriII  Varchar(MAX)
DECLARE @KueriIII  Varchar(MAX)
declare @Registros int, @i int

SET @FechaFin = @FechaFin

DECLARE @SOIdEstatus int
SELECT @SOIdEstatus= CASE WHEN EXISTS (select 'k' from ff_Vigencia v2 where v2.VIRenovada= v1.VIidVigencia) THEN 10
        WHEN VIidEstatus not in (1,6) THEN 10  ELSE 1 END
  FROM  ff_Vigencia v1 INNER JOIN ff_Empresa WITH (NOLOCK) ON VIidConfiguracion=EMidConfiguracion
  WHERE EMidEmpresa = @idEmpresa AND VIidVigencia = @idVigencia AND VITipoNegocio = 1

SELECT DISTINCT top 0 cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion , PLNombre,
 RTRIM(EM.EMNumeroEmpleado) as EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
 RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
 ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres ,EM.EMIdParentesco,
 convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
 convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa ,
 case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM( coalesce(TCPrimaNeta,0)),103) from  ff_TarifaCosto ppp
          WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else
        (SELECT CONVERT(CHAR(20),SUM( coalesce(TCPrimaNeta,0)),103) from  ff_TarifaCosto_hist ppp
         WHERE ppp.TCidParentesco =EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
         and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
 CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
 SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad,EMOficina,EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
 (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
  AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
 EMArea,EMIdCentroCostos,EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC,POS.POIDVigencia,SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
 isnull(emCalleFiscal,'') as Calle,isnull(EMColoniaFisico,'') as NumExt,isnull(EMCalleFisico,'') as NumInt,isnull(emColoniaFiscal,'') as Colonia,
 isnull(emMunicipioDelegaciónFiscal,'') as Del_Municipio,
 EstadoFiscal = (Select esDescripcion from ff_Estado where esidEstado = emEstadofiscal),
 isnull(''+emcodigoPostalFiscal,'') as CP
 INTO dbo.#PlanesSabanaVida
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion = PO.POidplanopcion AND POS.POIdEstatus in(1, 3, 10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan = PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID = POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco = EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion = POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud = POS.POidSolicitud
    and case when @idEstatus=1 and SOIDEstatus in(1, 3, 10) then 1
             when @idEstatus=2 and SOIDEstatus in(0,1,4,5)  then 1 else 0 end = 1
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo = SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana = 2 and CSPestana=0 AND poidempresa = @idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= @FechaFin
 AND case when @idEstatus=1 and POS.POidEstatus in (1, 3, 10) then 1
          when @idEstatus=2 and POS.POidEstatus in (4, 5)     then 1 else 0 end = 1
 AND POS.POidvigencia = @idVigencia AND EM.EMNumeroEmpleado not like 'test%'


IF @idEstatus = 1
BEGIN
 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,PADescripcion,PLNombre,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  Nombres,EMIdParentesco,EMFechaNacimiento,EMFechaIngresoEmpresa,PrimaNeta,Costo,
  SONumeroSolicitud,EMSalarioBase,SEDescripcion,EMEdad,EMOficina,ID,INFO,Oficina,EMArea,EMIdCentroCostos,Ubicacion,RFC,POIDVigencia,POIdSolicitud,Perfil,
  Calle,NumExt,NumInt,Colonia,Del_Municipio,EstadoFiscal,CP)
 SELECT DISTINCT cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion, PLNombre,
  RTRIM(EM.EMNumeroEmpleado), EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
  RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
  ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres, EM.EMIdParentesco,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
  SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad, EMOficina, EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
  (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  EMArea, EMIdCentroCostos, EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC, POS.POIDVigencia, SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(emMunicipioDelegaciónFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus in (1,3,10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(1,3,10)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana=2 and CSPestana=0 AND poidempresa=@idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidEstatus in (1,3,10)
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 AND (@Confidencial = 1 OR EM.EMidSalarioConfidencial = 0)

 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,PADescripcion,PLNombre,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  Nombres,EMIdParentesco,EMFechaNacimiento,EMFechaIngresoEmpresa,PrimaNeta,Costo,
  SONumeroSolicitud,EMSalarioBase,SEDescripcion,EMEdad,EMOficina,ID,INFO,Oficina,EMArea,EMIdCentroCostos,Ubicacion,RFC,POIDVigencia,POIdSolicitud,Perfil,
  Calle,NumExt,NumInt,Colonia,Del_Municipio,EstadoFiscal,CP)
 SELECT DISTINCT 'VIDA' as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion, PLNombre,
  RTRIM(EM.EMNumeroEmpleado), EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
  RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
  ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres, EM.EMIdParentesco,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
  SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad, EMOficina, EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
  (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  EMArea, EMIdCentroCostos, EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC, POS.POIDVigencia, SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(emMunicipioDelegaciónFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus in (1,3,10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(1,3,10)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana=2 and CSPestana=0 AND poidempresa=@idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidEstatus in (1,3,10)
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 AND (@Confidencial = 1 OR EM.EMidSalarioConfidencial = 0)

END
ELSE IF @idEstatus=2
BEGIN
 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,PADescripcion,PLNombre,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  Nombres,EMIdParentesco,EMFechaNacimiento,EMFechaIngresoEmpresa,PrimaNeta,Costo,
  SONumeroSolicitud,EMSalarioBase,SEDescripcion,EMEdad,EMOficina,ID,INFO,Oficina,EMArea,EMIdCentroCostos,Ubicacion,RFC,POIDVigencia,POIdSolicitud,Perfil,
  Calle,NumExt,NumInt,Colonia,Del_Municipio,EstadoFiscal,CP)
 SELECT DISTINCT cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion, PLNombre,
  RTRIM(EM.EMNumeroEmpleado), EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
  RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
  ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres, EM.EMIdParentesco,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
  SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad, EMOficina, EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
  (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  EMArea, EMIdCentroCostos, EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC, POS.POIDVigencia, SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(emMunicipioDelegaciónFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus IN(4,5,0)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(0,1,4,5)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND CS.CSidTipoSabana=2 AND poidempresa=@idEmpresa
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'

 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,PADescripcion,PLNombre,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  Nombres,EMIdParentesco,EMFechaNacimiento,EMFechaIngresoEmpresa,PrimaNeta,Costo,
  SONumeroSolicitud,EMSalarioBase,SEDescripcion,EMEdad,EMOficina,ID,INFO,Oficina,EMArea,EMIdCentroCostos,Ubicacion,RFC,POIDVigencia,POIdSolicitud,Perfil,
  Calle,NumExt,NumInt,Colonia,Del_Municipio,EstadoFiscal,CP)
 SELECT DISTINCT 'VIDA' as NombrePestana, CS.CSidTipoSabana as TipoSabana, PA.PADescripcion, PLNombre,
  RTRIM(EM.EMNumeroEmpleado), EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno,
  RTRIM(ISNULL(EM.EMNombre1,'')) As EMNombre1, RTRIM(ISNULL(EM.EMNombre2,'')) as EMNombre2,
  ISNULL(EM.EMNombre1,'')+ SPACE(1)+ ISNULL(EM.EMNombre2,'') as Nombres, EM.EMIdParentesco,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  convert(char(10),EM.EMFechaAntiguedadGMM, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo,
  SO.SONumeroSolicitud, EM.EMSalarioBase, SE.SEDescripcion, EM.EMEdad, EMOficina, EM.Id as ID, INFO=ISNULL(em.Desarrollo,''),
  (Select RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOficina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  EMArea, EMIdCentroCostos, EMArchivoInformacion as Ubicacion, RTRIM(emrfc) as RFC, POS.POIDVigencia, SOIdSolicitud as POIdSolicitud, PENombre as Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(emMunicipioDelegaciónFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus IN(4,5,0)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(0,1,4,5)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND CS.CSidTipoSabana=2 AND poidempresa=@idEmpresa
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
END

-- NombrePestana desde #PlanesSabanaVida: genera una pestana por CSAlias (Vida 30MSB, VIDA, etc.)
SELECT @KueriI = 'SELECT DISTINCT ''Vida'' as grupo, NombrePestana, P.TipoSabana, P.PADescripcion, PLNombre,
P.EMNumeroEmpleado, P.EMCertificado, P.EMApellidoPaterno, P.EMApellidoMaterno, P.EMNombre1, P.EMNombre2, P.Nombres, P.PrimaNeta, P.costo as Costo, P.EMIdParentesco, P.EMFechaNacimiento, Perfil,
P.EMFechaIngresoEmpresa, P.SONumeroSolicitud, P.EMSalarioBase, P.SEDescripcion, P.EMEdad, P.EMOficina, P.Oficina, P.Ubicacion, P.RFC, Id, INFO, Calle, NumExt, NumInt, Colonia, Del_Municipio, EstadoFiscal, CP '

-- flujo aislado: sin csidvigencia=@idVigencia en #Configuracion
SELECT 0 as Consecutivo,*
INTO #Configuracion
FROM dbo.ff_ConfiguracionSabana WITH (READUNCOMMITTED,NOLOCK)
where CSIdEstatus=1
  AND CSidConfiguracion = (Select EMidConfiguracion FROM ff_Empresa where EMidEmpresa = @idEmpresa)
  and CSIDTiposabana = 2 AND CSPestana = 0
order by CSidplan

SET @Registros = (SELECT COUNT(consecutivo) from #Configuracion)
SET @i=1
While @i<=@Registros
BEGIN
    Declare @Registro INT
    SET @Registro=(SELECT Min(CsIdConfiguracionSabana) FROM #Configuracion WHERE Consecutivo=0)
    Update #Configuracion SET Consecutivo=@i WHERE CsIdConfiguracionSabana=@Registro
    SET @i=@i+1
END

SELECT @KueriII=
 CASE WHEN Consecutivo <=30 AND CSidplanopcion IN(3200) AND @idEmpresa NOT IN(288,169,168) THEN
  isnull(@KueriII,'')+ ',VERDE_12M=ISNULL((SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA INNER JOIN FF_PlanOpcionseleccion ON VSIdEmpleado=P.Id AND POidplanOpcion=VSIdPlanOpcion AND VSIdVigencia=P.POIdVigencia WHERE VSIdPlanOpcion in(3200) AND POIDplanOpcion in(3200) and POIdSolicitud=P.POidSolicitud and POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + '),(SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3200) and s.VSIdEstatus=1))+' + ''',Costo_''' + '+RTRIM(cast(Consecutivo as char(3)))+' + '''=(SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3200) and s.VSIdEstatus=1) '''
 WHEN Consecutivo <=30 AND CSidplanopcion IN(3201) AND @idEmpresa IN(288,169,168) THEN
  isnull(@KueriII,'')+ ',VERDE_12M=ISNULL((SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA INNER JOIN FF_PlanOpcionseleccion ON VSIdEmpleado=P.Id AND POidplanOpcion=VSIdPlanOpcion AND VSIdVigencia=P.POIdVigencia WHERE VSIdPlanOpcion in(3201) AND POIDplanOpcion in(3201) and POIdSolicitud=P.POidSolicitud and POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + '),(SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3201) and s.VSIdEstatus=1))+' + ''',Costo_''' + '+RTRIM(cast(Consecutivo as char(3)))+' + '''=(SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3201) and s.VSIdEstatus=1) '''
 WHEN Consecutivo <=30 AND CSidplanopcion NOT IN(3200,3201) AND CSIdConfiguracion=26 THEN
  isnull(@KueriII,'')+ ',(SELECT CASE WHEN COUNT(*)>0 THEN (SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA WHERE VSIdEmpleado=P.Id AND VSIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' AND VSIdVigencia=P.POIdVigencia) else ' + char(39) + 'N' + char(39) + ' end from ff_PlanOpcionSeleccion s where s.POidEmpleado=P.ID and POIdSolicitud=P.POidSolicitud and s.POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + ') as ' + char(39) + CSalias + char(39) + char(13) + ',Costo_' + RTRIM(cast(Consecutivo as char(3))) + '=CASE WHEN EMIdParentesco in(1,2) THEN (SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_PlanOpcionSeleccion s INNER JOIN FF_ValidaSavida v ON v.vsidempleado=s.poidempleado and v.vsidvigencia=s.poidvigencia and v.vsidestatus=1 and v.vsidplanopcion=s.poidplanopcion WHERE s.PONumeroEmpleado=P.EMNumeroEmpleado and s.POIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' and s.POIdSolicitud=P.POidSolicitud AND s.POidEmpleado=P.ID) ELSE ' + CHAR(39)+CHAR(39) + ' END '
 WHEN Consecutivo <=30 AND CSIdConfiguracion<>26 THEN
  isnull(@KueriII,'')+ ',(SELECT CASE WHEN COUNT(*)>0 THEN (SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA WHERE VSIdEmpleado=P.Id AND VSIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' AND VSIdVigencia=P.POIdVigencia) else ' + char(39) + 'N' + char(39) + ' end from ff_PlanOpcionSeleccion s where s.POidEmpleado=P.ID and POIdSolicitud=P.POidSolicitud and s.POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + ') as ' + char(39) + CSalias + char(39) + char(13) + ',Costo_' + RTRIM(cast(Consecutivo as char(3))) + '=CASE WHEN EMIdParentesco in(1,2) THEN (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103) from ff_PlanOpcionSeleccion s WHERE s.PONumeroEmpleado=P.EMNumeroEmpleado and s.POIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' and s.POIdSolicitud=P.POidSolicitud AND s.POidEmpleado=P.ID) ELSE ' + CHAR(39)+CHAR(39) + ' END '
 ELSE @KueriII END
FROM #Configuracion
order by CSidplan

SELECT @KueriIII = ' FROM dbo.#PlanesSabanaVida P ORDER BY OFICINA,EMNUMEROEMPLEADO,EMIDPARENTESCO'

execute (@KueriI + @KueriII + @KueriIII)

end
GO

-- =============================================================================
-- SCRIPT 3: ff_SabanaOPC_v2 (Option B)

-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_SabanaOPC_v2] (
@idEmpresa int,
@FechaIni varchar(20),
@FechaFin varchar(20),
@idEstatus int,
@idVigencia int,
@Confidencial INT = 0)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @KueriI  Varchar(MAX)
DECLARE @KueriII  Varchar(MAX)
DECLARE @KueriIII  Varchar(MAX)
declare @Registros int, @i int

SET @FechaFin = @FechaFin

DECLARE @SOIdEstatus int
SELECT @SOIdEstatus= CASE WHEN EXISTS (select 'k' from ff_Vigencia v2 where v2.VIRenovada= v1.VIidVigencia) THEN 10
        WHEN VIidEstatus not in (1,6) THEN 10  ELSE 1 END
  FROM  ff_Vigencia v1 INNER JOIN ff_Empresa WITH (NOLOCK) ON VIidConfiguracion=EMidConfiguracion
  WHERE EMidEmpresa = @idEmpresa AND VIidVigencia = @idVigencia AND VITipoNegocio = 1

INSERT INTO dbo.bf_RepConf_Debug (etapa,detalle) VALUES ('opc_inicio',
 'idEmpresa='+CAST(@idEmpresa AS VARCHAR)+' idVigencia='+CAST(@idVigencia AS VARCHAR)
 +' FechaIni='+@FechaIni+' FechaFin='+@FechaFin+' idEstatus='+CAST(@idEstatus AS VARCHAR)
 +' SOIdEstatus='+ISNULL(CAST(@SOIdEstatus AS VARCHAR),'NULL'))

-- estructura vacia; CSPestana=1 aqui no importa (top 0 = 0 filas)
SELECT top 0 cast('' as varchar(100)) as NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, EM.EMidParentesco,
 PA.PADescripcion, PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre, PO.PONombre, EM.EMEdad,
 EM.EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
 SO.SONumeroSolicitud, ISNULL(EM.EMNombre1,' ') + SPACE(1) + ISNULL(EM.EMNombre2,' ') as Nombres,
 convert(char(10),EM.emfechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
 case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),coalesce(TCPrimaNeta,0),103) from ff_TarifaCosto ppp
          WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
          and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(coalesce(TCPrimaNeta,0)),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
 CONVERT(CHAR(20),(coalesce(POCostoRestante,0)),103) as Costo, EMOFicina,
 (Select top 1 RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
  AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
 rtrim(emRFC) as RFC, RTRIM(pe.PEDescripcion) AS Perfil,
 isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
 isnull(emMunicipioDelegaciónFiscal,'') as Del_Municipio,
 EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
 isnull(''+emcodigoPostalFiscal,'') as CP, rtrim(emarchivoinformacion) as local_number,
 EMArea, EMArchivoInformacion Ubicacion, EMIdCentroCostos, 0 as EmSalariobase,
 (Select top 1 RTRIM(teDatoAdicional2) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
  AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Categoria,
 convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
 SE.SEDescripcion, em.id, INFO=RTRIM(ISNULL(Desarrollo,'')), pos.POidSolicitud, pos.POidVigencia,
 cast('' as varchar(50)) as Folio
 INTO dbo.#PlanesSabanaVida
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus in(1,3,10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(1,3,10)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana=3 and CSPestana=1 AND poidempresa=@idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(SO.SOFechaAprovacion,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidEstatus in (1,3,10)
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 ORDER BY Oficina,EMNumeroEmpleado, EM.EmidParentesco

IF @idEstatus = 1
BEGIN
 -- opcion B: todos los CSAlias de tipo 3 generan pestana (sin filtro CSPestana=1)
 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,POidPlan,EMidParentesco,PADescripcion,poidplanopcion,POidGrupoParentesco,
  PLNombre,PONombre,EMEdad,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  SONumeroSolicitud,Nombres,EMFechaIngresoEmpresa,PrimaNeta,Costo,EMOFicina,Oficina,RFC,Perfil,Calle,NumExt,NumInt,Colonia,
  Del_Municipio,EstadoFiscal,CP,local_number,EMArea,Ubicacion,EMIdCentroCostos,EmSalariobase,Categoria,EMFechaNacimiento,SEDescripcion,id,INFO,POidSolicitud,POidVigencia,Folio)
 SELECT DISTINCT cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, EM.EMidParentesco,
  PA.PADescripcion, PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre, PO.PONombre, EM.EMEdad,
  EM.EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
  SO.SONumeroSolicitud, ISNULL(EM.EMNombre1,' ') + SPACE(1) + ISNULL(EM.EMNombre2,' ') as Nombres,
  convert(char(10),EM.emfechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103) from ff_TarifaCosto_hist ppp with(nolock)
             WHERE ppp.TCidParentesco is not null and ppp.TCEdad is not null and ppp.TCIdSexo is not null
             and ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo, EMOFicina,
  (Select top 1 RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  rtrim(emRFC) as RFC, RTRIM(pe.PEDescripcion) AS Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(emMunicipioDelegaciónFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP, rtrim(emarchivoinformacion) as local_number,
  EMArea, rtrim(emarchivoinformacion) as Ubicacion, EMIdCentroCostos, 0 as EmSalariobase,
  (Select top 1 RTRIM(teDatoAdicional2) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Categoria,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  SE.SEDescripcion, em.id, INFO=RTRIM(ISNULL(Desarrollo,'')), pos.POidSolicitud, pos.POidVigencia, '' as Folio
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus in (1,3,10)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(1,3,10)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 -- opcion B: sin CSPestana=1 → todos los planes de tipo 3 generan pestaña
 -- fix fecha: ISNULL usa @FechaFin (no getdate) para incluir solicitudes sin fecha aprobacion
 WHERE CS.CSIdEstatus=1 AND CS.CSidTipoSabana=3 AND poidempresa=@idEmpresa
 AND ISNULL(SO.SOFechaAprovacion,CONVERT(date,@FechaFin)) >= CONVERT(date,@FechaIni)
 AND ISNULL(SO.SOFechaAprovacion,CONVERT(date,@FechaFin)) <= CONVERT(date,@FechaFin)
 AND POS.POidEstatus in (1,3,10)
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'
 AND (@Confidencial = 1 OR EM.EMidSalarioConfidencial = 0)

 INSERT INTO dbo.bf_RepConf_Debug (etapa,detalle) VALUES ('opc_insert_estatus1',
  'filas_insertadas='+CAST(@@ROWCOUNT AS VARCHAR))
END
ELSE IF @idEstatus=2
BEGIN
 INSERT INTO dbo.#PlanesSabanaVida (NombrePestana,TipoSabana,POidPlan,EMidParentesco,PADescripcion,poidplanopcion,POidGrupoParentesco,
  PLNombre,PONombre,EMEdad,EMNumeroEmpleado,EMCertificado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,
  SONumeroSolicitud,Nombres,EMFechaIngresoEmpresa,PrimaNeta,Costo,EMOFicina,Oficina,RFC,Perfil,Calle,NumExt,NumInt,Colonia,
  Del_Municipio,EstadoFiscal,CP,local_number,EMArea,Ubicacion,EMIdCentroCostos,EmSalariobase,Categoria,EMFechaNacimiento,SEDescripcion,id,INFO,POidSolicitud,POidVigencia,Folio)
 SELECT DISTINCT cs.CSAlias as NombrePestana, CS.CSidTipoSabana as TipoSabana, PO.POidPlan, EM.EMidParentesco,
  PA.PADescripcion, PO.poidplanopcion, POS.POidGrupoParentesco, PL.PLNombre, PO.PONombre, EM.EMEdad,
  EM.EMNumeroEmpleado, EM.EMCertificado, EM.EMApellidoPaterno, EM.EMApellidoMaterno, EM.EMNombre1, EM.EMNombre2,
  SO.SONumeroSolicitud, ISNULL(EM.EMNombre1,' ') + SPACE(1) + ISNULL(EM.EMNombre2,' ') as Nombres,
  convert(char(10),EM.emfechaantiguedadgmm, 103) AS EMFechaIngresoEmpresa,
  case when @SOIdEstatus=1 then (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103) from ff_TarifaCosto ppp
            WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
            and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion)
       else (SELECT CONVERT(CHAR(20),SUM(TCPrimaNeta),103) from ff_TarifaCosto_hist ppp
             WHERE ppp.TCidParentesco=EM.EMIdParentesco and ppp.TCEdad=POS.POEdad and TCidEstatus=1
             and ppp.TCIdSexo=EM.EMIdSexo AND ppp.TCIdPlanOpcion=POS.POIDPlanOpcion) end as PrimaNeta,
  CONVERT(CHAR(20),(POCostoRestante),103) as Costo, EMOFicina,
  (Select top 1 RTRIM(TEDescripcion) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Oficina,
  rtrim(emRFC) as RFC, RTRIM(pe.PEDescripcion) AS Perfil,
  isnull(emCalleFiscal,'') as Calle, isnull(EMColoniaFisico,'') as NumExt, isnull(EMCalleFisico,'') as NumInt, isnull(emColoniaFiscal,'') as Colonia,
  isnull(emMunicipioDelegaciónFiscal,'') as Del_Municipio,
  EstadoFiscal=(Select esDescripcion from ff_Estado where esidEstado=emEstadofiscal),
  isnull(''+emcodigoPostalFiscal,'') as CP, rtrim(emarchivoinformacion) as local_number,
  EMArea, EMArchivoInformacion Ubicacion, EMIdCentroCostos, 0 as EmSalariobase,
  (Select top 1 RTRIM(teDatoAdicional2) from ff_tablaencabezadoDetalle WHERE TEIDDetalle=EMOFicina
   AND TEEnClave=(Select ENClave from ff_tablaencabezado WHERE ENNombreCampo='EMOFICINA' AND ENIdEstatus=1 AND ENIdEmpresa=EM.EMIdEmpresa)) as Categoria,
  convert(char(10),EM.EMFechaNacimiento,103) AS EMFechaNacimiento,
  SE.SEDescripcion, em.id, INFO=RTRIM(ISNULL(Desarrollo,'')), pos.POidSolicitud, pos.POidVigencia, '' as Folio
 FROM dbo.ff_PlanOpcionSeleccion POS
 INNER JOIN dbo.ff_PlanOpcion PO ON POS.poidplanopcion=PO.POidplanopcion AND POS.POIdEstatus IN(4,5,0)
 INNER JOIN dbo.ff_Plan PL ON PL.plidplan=PO.POidplan
 INNER JOIN dbo.ff_Empleado EM ON EM.ID=POS.poidempleado
 INNER JOIN dbo.ff_Parentesco PA ON PA.PAidparentesco=EM.EMidparentesco
 INNER JOIN dbo.ff_ConfiguracionSabana CS ON CS.CSidPlanOpcion=POS.POidplanopcion
 INNER JOIN dbo.ff_Solicitud SO ON SO.SOidSolicitud=POS.POidSolicitud and SOIDEstatus in(0,1,4,5)
 INNER JOIN dbo.ff_Sexo SE ON EM.EMidsexo=SE.SEidSexo
 INNER JOIN dbo.ff_Perfil pe on EM.EMIdPerfil=PEIdPerfil
 WHERE CS.CSIdEstatus=1 AND POS.POIdEstatus in (4,5) AND CS.CSidTipoSabana=3 AND poidempresa=@idEmpresa
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) >= @FechaIni
 AND ISNULL(EM.EMFechaBaja,cast(getdate() As Date)) <= @FechaFin
 AND POS.POidvigencia=@idVigencia AND EM.EMNumeroEmpleado not like 'test%'

 INSERT INTO dbo.bf_RepConf_Debug (etapa,detalle) VALUES ('opc_insert_estatus2',
  'filas_insertadas='+CAST(@@ROWCOUNT AS VARCHAR))
END

SELECT @KueriI = 'SELECT DISTINCT ''OPC'' as grupo, NombrePestana, P.TipoSabana, P.PADescripcion, P.PONombre, PLNombre,
P.EMNumeroEmpleado, P.EMCertificado, P.EMApellidoPaterno, P.EMApellidoMaterno, P.EMNombre1, P.EMNombre2, P.Nombres, P.PrimaNeta, P.costo as Costo,
P.EMIdParentesco, P.EMFechaNacimiento, Perfil, P.EMFechaIngresoEmpresa, P.SONumeroSolicitud, P.EMSalarioBase,
P.SEDescripcion, P.EMEdad, P.EMOficina, P.Oficina, P.Ubicacion, P.RFC, Id, INFO, Calle, NumExt, NumInt, Colonia, Del_Municipio, EstadoFiscal, CP,
P.local_number, P.EMArea, P.EMIdCentroCostos, P.Categoria, P.Folio '

-- flujo aislado: sin csidvigencia=@idVigencia en #Configuracion
SELECT 0 as Consecutivo,*
INTO #Configuracion
FROM dbo.ff_ConfiguracionSabana WITH (READUNCOMMITTED,NOLOCK)
where CSIdEstatus=1
  AND CSidConfiguracion=ISNULL((Select EMidConfiguracion FROM ff_Empresa where EMidEmpresa=@idEmpresa),0)
  and CSIDTiposabana=3 AND CSPestana=0
order by CSidplan

SET @Registros = (SELECT COUNT(consecutivo) from #Configuracion)

DECLARE @TotalPSV INT = (SELECT COUNT(*) FROM #PlanesSabanaVida)
INSERT INTO dbo.bf_RepConf_Debug (etapa,detalle) VALUES ('opc_planesvida_total',
 'planesvida='+CAST(@TotalPSV AS VARCHAR)+' configuracion='+CAST(@Registros AS VARCHAR)
 +' FechaIni_conv='+ISNULL(CAST(TRY_CONVERT(date,@FechaIni) AS VARCHAR),'CONV-ERROR')
 +' FechaFin_conv='+ISNULL(CAST(TRY_CONVERT(date,@FechaFin) AS VARCHAR),'CONV-ERROR'))

SET @i=1
While @i<=@Registros
BEGIN
    Declare @Registro2 INT
    SET @Registro2=(SELECT Min(CsIdConfiguracionSabana) FROM #Configuracion WHERE Consecutivo=0)
    Update #Configuracion SET Consecutivo=@i WHERE CsIdConfiguracionSabana=@Registro2
    SET @i=@i+1
END

SELECT @KueriII=
 CASE WHEN Consecutivo <=30 AND CSidplanopcion IN(3200) AND @idEmpresa NOT IN(288,169,168) THEN
  isnull(@KueriII,'')+ ',VERDE_12M=ISNULL((SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA INNER JOIN FF_PlanOpcionseleccion ON VSIdEmpleado=P.Id AND POidplanOpcion=VSIdPlanOpcion AND VSIdVigencia=P.POIdVigencia WHERE VSIdPlanOpcion in(3200) AND POIDplanOpcion in(3200) and POIdSolicitud=P.POidSolicitud and POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + '),(SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3200) and s.VSIdEstatus=1))+' + ''',Costo_''' + '+RTRIM(cast(Consecutivo as char(3)))+' + '''=(SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3200) and s.VSIdEstatus=1) '''
 WHEN Consecutivo <=30 AND CSidplanopcion IN(3201) AND @idEmpresa IN(288,169,168) THEN
  isnull(@KueriII,'')+ ',VERDE_12M=ISNULL((SELECT CONVERT(CHAR(20),VSSumaAsegurada,103) FROM FF_VALIDASAVIDA INNER JOIN FF_PlanOpcionseleccion ON VSIdEmpleado=P.Id AND POidplanOpcion=VSIdPlanOpcion AND VSIdVigencia=P.POIdVigencia WHERE VSIdPlanOpcion in(3201) AND POIDplanOpcion in(3201) and POIdSolicitud=P.POidSolicitud and POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + '),(SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3201) and s.VSIdEstatus=1))+' + ''',Costo_''' + '+RTRIM(cast(Consecutivo as char(3)))+' + '''=(SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_ValidaSAvida s WHERE s.VSIdEMpleado=P.Id AND s.VSIdPlanOpcion in(3201) and s.VSIdEstatus=1) '''
 WHEN Consecutivo <=30 AND CSidplanopcion NOT IN(3200,3201) AND CSIdConfiguracion=26 THEN
  isnull(@KueriII,'')+ ',(SELECT CASE WHEN COUNT(*)>0 THEN (SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) FROM FF_VALIDASAVIDA WHERE VSIdEmpleado=P.Id AND VSIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' AND VSIdVigencia=P.POIdVigencia) else ' + char(39) + 'N' + char(39) + ' end from ff_PlanOpcionSeleccion s where s.POidEmpleado=P.ID and POIdSolicitud=P.POidSolicitud and s.POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + ') as ' + char(39) + CSalias + char(39) + char(13) + ',Costo_' + RTRIM(cast(Consecutivo as char(3))) + '=CASE WHEN EMIdParentesco in(1,2) THEN (SELECT CONVERT(CHAR(20),SUM(VSPrimaAnual),103) from ff_PlanOpcionSeleccion s INNER JOIN FF_ValidaSavida v ON v.vsidempleado=s.poidempleado and v.vsidvigencia=s.poidvigencia and v.vsidestatus=1 and v.vsidplanopcion=s.poidplanopcion WHERE s.PONumeroEmpleado=P.EMNumeroEmpleado and s.POIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' and s.POIdSolicitud=P.POidSolicitud AND s.POidEmpleado=P.ID) ELSE ' + CHAR(39)+CHAR(39) + ' END '
 WHEN Consecutivo <=30 AND CSIdConfiguracion<>26 THEN
  isnull(@KueriII,'')+ ',(SELECT CASE WHEN COUNT(*)>0 THEN (SELECT CONVERT(CHAR(20),SUM(VSSumaAsegurada),103) FROM FF_VALIDASAVIDA WHERE VSIdEmpleado=P.Id AND VSIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' AND VSIdVigencia=P.POIdVigencia) else ' + char(39) + 'N' + char(39) + ' end from ff_PlanOpcionSeleccion s where s.POidEmpleado=P.ID and POIdSolicitud=P.POidSolicitud and s.POidplanopcion=' + cast(CSidplanopcion as varchar(5)) + ') as ' + char(39) + CSalias + char(39) + char(13) + ',Costo_' + RTRIM(cast(Consecutivo as char(3))) + '=CASE WHEN EMIdParentesco in(1,2) THEN (SELECT CONVERT(CHAR(20),SUM(POCostoRestante),103) from ff_PlanOpcionSeleccion s WHERE s.PONumeroEmpleado=P.EMNumeroEmpleado and s.POIdPlanOpcion=' + cast(CSidplanopcion as varchar(5)) + ' and s.POIdSolicitud=P.POidSolicitud AND s.POidEmpleado=P.ID) ELSE ' + CHAR(39)+CHAR(39) + ' END '
 ELSE @KueriII END
FROM #Configuracion
order by CSidplan

INSERT INTO dbo.bf_RepConf_Debug (etapa,detalle) VALUES ('opc_kuerii_estado',
 'es_null='+CASE WHEN @KueriII IS NULL THEN '1' ELSE '0' END
 +' longitud='+CAST(ISNULL(LEN(@KueriII),0) AS VARCHAR)
 +' inicio='+LEFT(ISNULL(@KueriII,'(null)'),200))

SELECT @KueriIII = ' FROM dbo.#PlanesSabanaVida P ORDER BY OFICINA,EMNUMEROEMPLEADO,EMIDPARENTESCO'

-- sin columnas dinamicas cuando #Configuracion esta vacio (evita execute(NULL) = sin resultset)
IF @KueriII IS NULL SET @KueriII = ''

INSERT INTO dbo.bf_RepConf_Debug (etapa,detalle) VALUES ('opc_execute_query',
 'longitud='+CAST(LEN(@KueriI+@KueriII+@KueriIII) AS VARCHAR)
 +' inicio='+LEFT(@KueriI+@KueriII+@KueriIII, 400))

BEGIN TRY
    execute (@KueriI + @KueriII + @KueriIII)
    INSERT INTO dbo.bf_RepConf_Debug (etapa,detalle) VALUES ('opc_fin', 'SP ejecutado correctamente')
END TRY
BEGIN CATCH
    INSERT INTO dbo.bf_RepConf_Debug (etapa,detalle) VALUES ('opc_execute_error',
        'num='+CAST(ERROR_NUMBER() AS VARCHAR)
        +' linea='+CAST(ERROR_LINE() AS VARCHAR)
        +' msg='+LEFT(ERROR_MESSAGE(),500))
END CATCH
drop table #PlanesSabanaVida;

end
GO

-- =============================================================================
-- SCRIPT 4: ff_Sabana_v2 (wrapper - igual que ff_Sabana_BF3 pero llama _v2)
-- =============================================================================
CREATE OR ALTER PROCEDURE [dbo].[ff_Sabana_v2]
    @idEmpresa    INT,
    @FechaIni     VARCHAR(50),
    @FechaFin     VARCHAR(50),
    @idEstatus    INT,
    @idVigencia   INT,
    @Confidencial INT = 0
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        EXEC dbo.ff_SabanaGMM_v2
            @idEmpresa    = @idEmpresa,
            @FechaIni     = @FechaIni,
            @FechaFin     = @FechaFin,
            @idEstatus    = @idEstatus,
            @idVigencia   = @idVigencia,
            @Confidencial = @Confidencial;
    END TRY BEGIN CATCH END CATCH;

    BEGIN TRY
        EXEC dbo.ff_SabanaVIDA_v2
            @idEmpresa    = @idEmpresa,
            @FechaIni     = @FechaIni,
            @FechaFin     = @FechaFin,
            @idEstatus    = @idEstatus,
            @idVigencia   = @idVigencia,
            @Confidencial = @Confidencial;
    END TRY BEGIN CATCH END CATCH;

    BEGIN TRY
        EXEC dbo.ff_SabanaOPC_v2
            @idEmpresa    = @idEmpresa,
            @FechaIni     = @FechaIni,
            @FechaFin     = @FechaFin,
            @idEstatus    = @idEstatus,
            @idVigencia   = @idVigencia,
            @Confidencial = @Confidencial;
    END TRY BEGIN CATCH END CATCH;

    IF (@idEstatus <> 2)
    BEGIN
        BEGIN TRY
            EXEC dbo.ff_SabanaMascotas_BF3
                @idEmpresa    = @idEmpresa,
                @FechaIni     = @FechaIni,
                @FechaFin     = @FechaFin,
                @idVigencia   = @idVigencia,
                @idEstatus    = @idEstatus;
        END TRY BEGIN CATCH END CATCH;
    END
END
GO

-- =============================================================================
-- SCRIPT 5: apuntar reporteId=3 a ff_Sabana_v2

-- =============================================================================
UPDATE dbo.bf_CatReportesSP
SET catReportesSPNombre = 'ff_Sabana_v2'
WHERE catReportesSPId = 3;
GO
