/*
    Configura passwords independientes para los Excel de Sabana y Cobranza.

    Clases:
      SABANA_EXCEL_PASSWORD
      COBRANZA_EXCEL_PASSWORD

    El registro historico paId=12 se reutiliza para Sabana cuando existe.
    Para Cobranza se genera un paId nuevo con MAX(paId) + 1.
    El script es idempotente y no muestra los passwords en el resultado.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa        int           = 186;
DECLARE @PasswordSabana   varchar(1500) = 'PRUEBA'; -- CAMBIAR
DECLARE @PasswordCobranza varchar(1500) = 'PRUEBA'; -- CAMBIAR
DECLARE @Usuario          int           = 1;
DECLARE @ClaseSabana      char(30)      = 'SABANA_EXCEL_PASSWORD';
DECLARE @ClaseCobranza    char(30)      = 'COBRANZA_EXCEL_PASSWORD';
DECLARE @IdSabana         int;
DECLARE @IdCobranza       int;

IF NULLIF(LTRIM(RTRIM(@PasswordSabana)), '') IS NULL
    THROW 50001, 'El password de Sabana no puede estar vacio.', 1;

IF NULLIF(LTRIM(RTRIM(@PasswordCobranza)), '') IS NULL
    THROW 50002, 'El password de Cobranza no puede estar vacio.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP (1) @IdSabana = paId
    FROM dbo.ff_Parametro WITH (UPDLOCK, HOLDLOCK)
    WHERE paIdEmpresa = @IdEmpresa
      AND UPPER(LTRIM(RTRIM(paClase))) = @ClaseSabana
    ORDER BY paId;

    -- Compatibilidad: el parametro 12 historicamente era el password de Sabana.
    IF @IdSabana IS NULL
       AND EXISTS
       (
           SELECT 1
           FROM dbo.ff_Parametro WITH (UPDLOCK, HOLDLOCK)
           WHERE paId = 12 AND paIdEmpresa = @IdEmpresa
       )
        SET @IdSabana = 12;

    IF @IdSabana IS NULL
        SELECT @IdSabana = ISNULL(MAX(paId), 0) + 1
        FROM dbo.ff_Parametro WITH (UPDLOCK, HOLDLOCK);

    IF EXISTS
    (
        SELECT 1 FROM dbo.ff_Parametro
        WHERE paId = @IdSabana AND paIdEmpresa = @IdEmpresa
    )
        UPDATE dbo.ff_Parametro WITH (ROWLOCK)
           SET paClase       = @ClaseSabana,
               paValor       = @PasswordSabana,
               paDescripcion = 'Password Excel Sabana de beneficios',
               paidEstatus   = 1,
               paUsuarioUmod = @Usuario,
               paFechaUmod   = GETDATE(),
               paFechaDel    = NULL,
               paUsuarioDel  = NULL
         WHERE paId = @IdSabana AND paIdEmpresa = @IdEmpresa;
    ELSE
        INSERT INTO dbo.ff_Parametro
        (
            paId, paIdEmpresa, paClase, paValor, paDescripcion,
            paidEstatus, paUsuarioAdd, paFechaAdd
        )
        VALUES
        (
            @IdSabana, @IdEmpresa, @ClaseSabana, @PasswordSabana,
            'Password Excel Sabana de beneficios', 1, @Usuario, GETDATE()
        );

    SELECT TOP (1) @IdCobranza = paId
    FROM dbo.ff_Parametro WITH (UPDLOCK, HOLDLOCK)
    WHERE paIdEmpresa = @IdEmpresa
      AND UPPER(LTRIM(RTRIM(paClase))) = @ClaseCobranza
    ORDER BY paId;

    IF @IdCobranza IS NULL
        SELECT @IdCobranza = ISNULL(MAX(paId), 0) + 1
        FROM dbo.ff_Parametro WITH (UPDLOCK, HOLDLOCK);

    IF EXISTS
    (
        SELECT 1 FROM dbo.ff_Parametro
        WHERE paId = @IdCobranza AND paIdEmpresa = @IdEmpresa
    )
        UPDATE dbo.ff_Parametro WITH (ROWLOCK)
           SET paClase       = @ClaseCobranza,
               paValor       = @PasswordCobranza,
               paDescripcion = 'Password Excel Reporte de cobranza',
               paidEstatus   = 1,
               paUsuarioUmod = @Usuario,
               paFechaUmod   = GETDATE(),
               paFechaDel    = NULL,
               paUsuarioDel  = NULL
         WHERE paId = @IdCobranza AND paIdEmpresa = @IdEmpresa;
    ELSE
        INSERT INTO dbo.ff_Parametro
        (
            paId, paIdEmpresa, paClase, paValor, paDescripcion,
            paidEstatus, paUsuarioAdd, paFechaAdd
        )
        VALUES
        (
            @IdCobranza, @IdEmpresa, @ClaseCobranza, @PasswordCobranza,
            'Password Excel Reporte de cobranza', 1, @Usuario, GETDATE()
        );

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

-- Verificacion sin exponer los passwords.
SELECT
    paId,
    paIdEmpresa,
    LTRIM(RTRIM(paClase)) AS paClase,
    paDescripcion,
    paidEstatus,
    CASE WHEN NULLIF(LTRIM(RTRIM(paValor)), '') IS NULL THEN 0 ELSE 1 END
        AS PasswordConfigurado,
    LEN(RTRIM(paValor)) AS LongitudPassword
FROM dbo.ff_Parametro
WHERE paIdEmpresa = @IdEmpresa
  AND UPPER(LTRIM(RTRIM(paClase))) IN
      (@ClaseSabana, @ClaseCobranza)
ORDER BY paClase;

