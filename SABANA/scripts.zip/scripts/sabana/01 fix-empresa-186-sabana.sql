
BEGIN TRAN fix_empresa_186;

-- ============================================================================
-- 1. LIMPIAR CONFIG EXISTENTE DE EMPRESA 186
-- ============================================================================
DELETE FROM dbo.bf_RepConf_Columna
WHERE idEmpresa = 186 AND catReportesId = 3;

DELETE FROM dbo.bf_RepConf_Tabla
WHERE idEmpresa = 186 AND catReportesId = 3;


-- ============================================================================
-- 2. bf_RepConf_Tabla  (grupos / hojas)
-- ============================================================================

-- GMM (indexTable=0) — tabs separadas por NombrePestana
INSERT INTO dbo.bf_RepConf_Tabla
    (idEmpresa, catReportesId, grupo, columnaGrupo,
     agruparPorColumna, indexTable, tituloTabla,
     espacioIzquierda, espacioDerecha, alineacion,
     colorFondo, colorLetra, activo,
     repConfTablaUsuarioAdd, repConfTablaFechaAdd)
VALUES
    (186, 3, 'GMM', 'NombrePestana',
     1, 0, NULL,
     0, 0, 'Izquierda',
     'Blue', NULL, 1,
     25, GETDATE());

-- Vida (indexTable=1)
INSERT INTO dbo.bf_RepConf_Tabla
    (idEmpresa, catReportesId, grupo, columnaGrupo,
     agruparPorColumna, indexTable, tituloTabla,
     espacioIzquierda, espacioDerecha, alineacion,
     colorFondo, colorLetra, activo,
     repConfTablaUsuarioAdd, repConfTablaFechaAdd)
VALUES
    (186, 3, 'Vida', 'NombrePestana',
     1, 1, NULL,
     0, 0, 'Derecha',
     'Blue', NULL, 1,
     25, GETDATE());

-- Opcionales (indexTable=2)
INSERT INTO dbo.bf_RepConf_Tabla
    (idEmpresa, catReportesId, grupo, columnaGrupo,
     agruparPorColumna, indexTable, tituloTabla,
     espacioIzquierda, espacioDerecha, alineacion,
     colorFondo, colorLetra, activo,
     repConfTablaUsuarioAdd, repConfTablaFechaAdd)
VALUES
    (186, 3, 'Opcionales', 'NombrePestana',
     1, 2, NULL,
     0, 0, 'Derecha',
     'Blue', NULL, 1,
     25, GETDATE());


-- ============================================================================
-- 3. bf_RepConf_Columna — GMM

-- ============================================================================
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 1,'EMNumeroEmpleado'  ,'No. Empleado'         ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 2,'EMCertificado'     ,'Número Certificado'   ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 3,'EMApellidoPaterno' ,'Paterno'              ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 4,'EMApellidoMaterno' ,'Materno'              ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 5,'EMNombre1'         ,'Primer Nombre'        ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 6,'EMNombre2'         ,'Segundo Nombre'       ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 7,'SEDescripcion'     ,'Sexo'                 ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 8,'PADescripcion'     ,'Parentesco'           ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM', 9,'EMFechaNacimiento' ,'Fecha de Nacimiento'  ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',10,'RFC'               ,'RFC'                  ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',11,'EMedad'            ,'Edad'                 ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',12,'EMFechaIngresoEmpresa','Fecha Antigüedad'  ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',13,'PrimeNeta'         ,'Prima Neta'           ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',14,'Costo'             ,'Costo'                ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',15,'EMOFicina'         ,'IdOficina'            ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',16,'Oficina'           ,'Oficina'              ,1,25,GETDATE());
-- NUEVAS: Exceso_ante y GMM_ANT ya existen en ff_SabanaGMM_BF3 (rama @idEstatus=1)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',17,'Exceso_ante'       ,'Exceso_ante'          ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',18,'GMM_ANT'           ,'GMM_ANT'              ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',19,'Perfil'            ,'Perfil'               ,1,25,GETDATE());
-- Folio lo agrega SabanaBeneficiosLegacyService.java (igual que el legacy C#)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',20,'Folio'             ,'Folio'                ,1,25,GETDATE());
-- Columnas ocultas (mismas que REMOVERCOLUMNAS del SabanaConfig.xml legacy)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',21,'NombrePestana'     ,'NombrePestana'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',22,'TipoSabana'        ,'TipoSabana'           ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',23,'POidPlan'          ,'POidPlan'             ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',24,'EMidParentesco'    ,'EMidParentesco'       ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',25,'Nombres'           ,'Nombres'              ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',26,'poidplanopcion'    ,'poidplanopcion'       ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',27,'POidGrupoParentesco','POidGrupoParentesco' ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',28,'PLNombre'          ,'PLNombre'             ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',29,'EMFechaAlta'       ,'EMFechaAlta'          ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',30,'GPDescripcion'     ,'GPDescripcion'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',31,'Ubicacion'         ,'Ubicacion'            ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',32,'SONumeroSolicitud' ,'SONumeroSolicitud'    ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',33,'IDEmp'             ,'IDEmp'                ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',34,'EMArea'            ,'EMArea'               ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',35,'EMIdCentroCostos'  ,'EMIdCentroCostos'     ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',36,'INFO'              ,'INFO'                 ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',37,'EMIdParentesco1'   ,'EMIdParentesco1'      ,0,25,GETDATE());
-- Campos nuevos del BF3 que no existían en el legacy (ocultar para empresa 186)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',38,'Calle'             ,'Calle'                ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',39,'NumExt'            ,'NumExt'               ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',40,'NumInt'            ,'NumInt'               ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',41,'Colonia'           ,'Colonia'              ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',42,'Del_Municipio'     ,'Del_Municipio'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',43,'EstadoFiscal'      ,'EstadoFiscal'         ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',44,'CP'               ,'CP'                    ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'GMM',45,'grupo'            ,'grupo'                 ,0,25,GETDATE());


-- ============================================================================
-- 4. bf_RepConf_Columna — Vida

-- ============================================================================
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 1,'EMNumeroEmpleado'  ,'No. Empleado'         ,1,25,GETDATE());
-- EMCertificado se muestra con nombre raw (no renombrado en el XML legacy)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 2,'EMCertificado'     ,'EMCertificado'        ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 3,'EMApellidoPaterno' ,'Paterno'              ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 4,'EMApellidoMaterno' ,'Materno'              ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 5,'EMNombre1'         ,'Primer Nombre'        ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 6,'EMNombre2'         ,'Segundo Nombre'       ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 7,'SEDescripcion'     ,'Sexo'                 ,1,25,GETDATE());
-- Nombres (nombre completo combinado) visible en el Excel legacy
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 8,'Nombres'           ,'Nombres'              ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida', 9,'PADescripcion'     ,'Parentesco'           ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',10,'RFC'               ,'RFC'                  ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',11,'EMFechaNacimiento' ,'Fecha de Nacimiento'  ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',12,'EMedad'            ,'Edad'                 ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',13,'Perfil'            ,'Perfil'               ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',14,'EMFechaIngresoEmpresa','Fecha Antigüedad'  ,1,25,GETDATE());
-- Las columnas dinámicas de CSPestana=0 (VIDA, Costo_N, etc.) se insertan
-- automáticamente por preservarColumnasDinamicas=1 — no se listan aquí.
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',15,'EMSalarioBase'     ,'Sueldo'               ,1,25,GETDATE());
-- IDEmp e INFO pasan como raw en el legacy (no están en COLUMNAS ni en REMOVERCOLUMNAS)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',16,'IDEmp'             ,'IDEmp'                ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',17,'INFO'              ,'INFO'                 ,1,25,GETDATE());
-- Columnas ocultas (REMOVERCOLUMNAS del XML legacy)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',18,'NombrePestana'     ,'NombrePestana'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',19,'TipoSabana'        ,'TipoSabana'           ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',20,'PLNombre'          ,'PLNombre'             ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',21,'EMIdParentesco'    ,'EMIdParentesco'       ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',22,'EMOficina'         ,'EMOficina'            ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',23,'Oficina'           ,'Oficina'              ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',24,'Ubicacion'         ,'Ubicacion'            ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',25,'SONumeroSolicitud' ,'SONumeroSolicitud'    ,0,25,GETDATE());
-- Campos nuevos del BF3 no presentes en el legacy (ocultar para empresa 186)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',26,'PrimaNeta'         ,'PrimaNeta'            ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',27,'Costo'             ,'Costo'                ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',28,'Calle'             ,'Calle'                ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',29,'NumExt'            ,'NumExt'               ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',30,'NumInt'            ,'NumInt'               ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',31,'Colonia'           ,'Colonia'              ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',32,'Del_Municipio'     ,'Del_Municipio'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',33,'EstadoFiscal'      ,'EstadoFiscal'         ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',34,'CP'               ,'CP'                    ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Vida',35,'grupo'            ,'grupo'                 ,0,25,GETDATE());


-- ============================================================================
-- 5. bf_RepConf_Columna — Opcionales

-- ============================================================================
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 1,'EMNumeroEmpleado'  ,'No. Empleado'         ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 2,'EMApellidoPaterno' ,'Paterno'              ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 3,'EMApellidoMaterno' ,'Materno'              ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 4,'EMNombre1'         ,'Primer Nombre'        ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 5,'EMNombre2'         ,'Segundo Nombre'       ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 6,'SEDescripcion'     ,'Sexo'                 ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 7,'PADescripcion'     ,'Parentesco'           ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 8,'EMedad'            ,'Edad'                 ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales', 9,'EMFechaNacimiento' ,'Fecha de Nacimiento'  ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',10,'EMFechaIngresoEmpresa','EMFechaIngresoEmpresa',1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',11,'RFC'               ,'RFC'                  ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',12,'PrimaNeta'         ,'PrimaNeta'            ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',13,'Costo'             ,'Costo'                ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',14,'EMOFicina'         ,'EMOFicina'            ,1,25,GETDATE());
-- NumExt = isnull(EMColoniaFisico,'') en ff_SabanaOPC / ff_SabanaOPC_BF3
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',15,'NumExt'            ,'NumExt'               ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',16,'Oficina'           ,'Oficina'              ,1,25,GETDATE());
-- NumInt = isnull(EMCalleFisico,'') en ff_SabanaOPC / ff_SabanaOPC_BF3
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',17,'NumInt'            ,'NumInt'               ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',18,'PONombre'          ,'PONombre'             ,1,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',19,'Perfil'            ,'Perfil'               ,1,25,GETDATE());
-- VERIFICAR: puede ser 'id' o 'IDEmp' según el alias de em.id en ff_SabanaOPC_BF3
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',20,'id'               ,'id'                    ,1,25,GETDATE());
-- Folio lo agrega SabanaBeneficiosLegacyService.java (igual que el legacy C#)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',21,'Folio'             ,'Folio'                ,1,25,GETDATE());
-- Columnas ocultas (REMOVERCOLUMNAS del XML legacy)
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',22,'NombrePestana'     ,'NombrePestana'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',23,'EMSalarioBase'     ,'EMSalarioBase'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',24,'SONumeroSolicitud' ,'SONumeroSolicitud'    ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',25,'local_number'      ,'local_number'         ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',26,'EMIdCentroCostos'  ,'EMIdCentroCostos'     ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',27,'EMArea'            ,'EMArea'               ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',28,'TipoSabana'        ,'TipoSabana'           ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',29,'POidPlan'          ,'POidPlan'             ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',30,'EMidParentesco'    ,'EMidParentesco'       ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',31,'poidplanopcion'    ,'poidplanopcion'       ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',32,'POidGrupoParentesco','POidGrupoParentesco' ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',33,'Nombres'           ,'Nombres'              ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',34,'PLNombre'          ,'PLNombre'             ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',35,'EMCertificado'     ,'EMCertificado'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',36,'Calle'             ,'Calle'                ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',37,'Colonia'           ,'Colonia'              ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',38,'Del_Municipio'     ,'Del_Municipio'        ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',39,'EstadoFiscal'      ,'EstadoFiscal'         ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',40,'CP'               ,'CP'                    ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',41,'INFO'              ,'INFO'                 ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',42,'Categoria'         ,'Categoria'            ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',43,'Ubicacion'         ,'Ubicacion'            ,0,25,GETDATE());
INSERT INTO dbo.bf_RepConf_Columna (idEmpresa,catReportesId,grupo,orden,campoOrigen,encabezado,visible,repConfColumnaUsuarioAdd,repConfColumnaFechaAdd)
VALUES (186,3,'Opcionales',44,'grupo'            ,'grupo'                 ,0,25,GETDATE());


-- ============================================================================
-- 6. VERIFICACION (dentro de la misma transaccion, antes de COMMIT)
-- ============================================================================
SELECT grupo, COUNT(*) AS columnas, SUM(CAST(visible AS INT)) AS visibles
FROM   dbo.bf_RepConf_Columna
WHERE  idEmpresa = 186 AND catReportesId = 3
GROUP  BY grupo
ORDER  BY grupo;
-- Resultados esperados:
--   GMM        45   20
--   Opcionales 44   21
--   Vida       37   17

SELECT grupo, orden, campoOrigen, encabezado, visible
FROM   dbo.bf_RepConf_Columna
WHERE  idEmpresa = 186 AND catReportesId = 3
ORDER  BY grupo, orden;


COMMIT TRAN fix_empresa_186;
-- Si los resultados de verificación no son los esperados, usa:
-- ROLLBACK TRAN fix_empresa_186;
