$ErrorActionPreference = 'Stop'

$RepoApi = 'C:\repo\reportes\APIREPORTES'
$TargetBranch = 'ReporteSabanaHomologacionOK-clean'
$TargetFile = 'src/main/java/com/lockton/rpt/services/GeneradorReportesService.java'
$StashName = 'temporal-log-final-sabana-bf3'

Set-Location -LiteralPath $RepoApi
git rev-parse --is-inside-work-tree | Out-Null
if ($LASTEXITCODE -ne 0) { throw "No es un repositorio Git: $RepoApi" }
if (-not (Test-Path -LiteralPath $TargetFile -PathType Leaf)) { throw "No existe $TargetFile" }

# Guarda solamente el archivo de esta entrega. Los demas cambios locales no
# se agregan al commit ni se trasladan a la rama destino.
$HasTargetChange = -not [string]::IsNullOrWhiteSpace(
    (git status --porcelain -- $TargetFile | Out-String)
)
if (-not $HasTargetChange) {
    throw "No hay cambio pendiente en $TargetFile. Copie primero 01_API_REPORTES sobre el repositorio."
}

git stash push -m $StashName -- $TargetFile
if ($LASTEXITCODE -ne 0) { throw 'No fue posible guardar temporalmente el archivo.' }

git fetch origin
if ($LASTEXITCODE -ne 0) { throw 'Fallo git fetch.' }

git show-ref --verify --quiet "refs/heads/$TargetBranch"
if ($LASTEXITCODE -eq 0) {
    git switch $TargetBranch
} else {
    git switch -c $TargetBranch --track "origin/$TargetBranch"
}
if ($LASTEXITCODE -ne 0) { throw "No fue posible cambiar a $TargetBranch." }

git pull --ff-only origin $TargetBranch
if ($LASTEXITCODE -ne 0) { throw "No fue posible actualizar $TargetBranch sin mezclar historiales." }

git stash pop 'stash@{0}'
if ($LASTEXITCODE -ne 0) { throw 'Hay un conflicto al aplicar el archivo. No se creo commit ni se hizo push.' }

git diff --check -- $TargetFile
if ($LASTEXITCODE -ne 0) { throw 'El archivo contiene errores de formato.' }

git add -- $TargetFile
$Staged = @(git diff --cached --name-only)
if ($Staged.Count -ne 1 -or $Staged[0] -ne $TargetFile) {
    throw 'El staging contiene archivos distintos de GeneradorReportesService.java.'
}

git commit -m 'Homologa finalizacion del log de Sabana B3'
if ($LASTEXITCODE -ne 0) { throw 'No fue posible crear el commit.' }

git push -u origin $TargetBranch
if ($LASTEXITCODE -ne 0) { throw "No fue posible enviar origin/$TargetBranch." }

Write-Host "Cambio enviado correctamente a origin/$TargetBranch." -ForegroundColor Green
git status --short
