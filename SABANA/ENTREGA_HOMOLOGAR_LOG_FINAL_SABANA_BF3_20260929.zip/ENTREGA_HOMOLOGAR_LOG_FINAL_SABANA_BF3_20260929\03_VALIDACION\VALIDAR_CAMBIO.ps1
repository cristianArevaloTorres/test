$ErrorActionPreference = 'Stop'

$Archivo = Join-Path $PSScriptRoot '..\01_API_REPORTES\src\main\java\com\lockton\rpt\services\GeneradorReportesService.java'
$Contenido = Get-Content -LiteralPath $Archivo -Raw

$Validaciones = @(
    [pscustomobject]@{
        Validacion = 'Directorio inmutable durante el proceso'
        Correcto = $Contenido.Contains('final File directorioLog = resolverDirectorioLogSabana(params);')
    },
    [pscustomobject]@{
        Validacion = 'No cambia al directorio padre del Excel'
        Correcto = -not $Contenido.Contains('directorioLog = archivoGenerado.getParentFile();')
    },
    [pscustomobject]@{
        Validacion = 'Registra inicio'
        Correcto = $Contenido.Contains('Inicia proceso de SABANA')
    },
    [pscustomobject]@{
        Validacion = 'Registra finalizacion correcta'
        Correcto = $Contenido.Contains('Finaliza la SABANA')
    },
    [pscustomobject]@{
        Validacion = 'Registra finalizacion sin datos'
        Correcto = $Contenido.Contains('Finaliza Sabana sin datos para los filtros seleccionados')
    },
    [pscustomobject]@{
        Validacion = 'Registra error'
        Correcto = $Contenido.Contains('Error al generar Sabana:')
    }
)

$Validaciones | Format-Table -AutoSize
if ($Validaciones.Correcto -contains $false) {
    throw 'Una o mas validaciones no se cumplieron.'
}

Write-Host 'Validacion correcta: inicio, resultado y error usan el mismo Log.txt.' -ForegroundColor Green
