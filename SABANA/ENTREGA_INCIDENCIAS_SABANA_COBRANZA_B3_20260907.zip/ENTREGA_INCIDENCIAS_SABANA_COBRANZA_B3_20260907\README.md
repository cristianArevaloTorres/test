# Homologacion Sabana y Cobranza B3

Fecha de cierre: 7 de septiembre de 2026.

Este paquete contiene exclusivamente el instalador SQL de B3, los archivos
Java modificados y sus pruebas. B2 se utilizo como patron y no fue modificado.
Angular tampoco requiere cambios para estas incidencias.

Es una entrega incremental sobre la instalacion de cache/homologacion de
Cobranza realizada previamente. No vuelve a incluir ni reinstalar los SP del
cache de Cobranza; el unico SQL nuevo requerido por estas incidencias es el de
Sabana incluido aqui.

## Instalacion

1. Respaldar la base y ejecutar `01_BASE_DATOS/01_INSTALAR_SABANA_B3.sql` con
   una cuenta que pueda alterar procedimientos y actualizar las tablas de
   configuracion del reporte.
2. Copiar el contenido de `02_API_REPORTES` sobre la raiz del clon de
   APIREPORTS, conservando la estructura `src/main` y `src/test`.
3. En el clon de APIREPORTS ejecutar
   `03_COMANDOS_GIT/COMANDOS_API_REPORTES.ps1`.
4. Desplegar o reiniciar API Reportes. Los cambios Java no se activan solo con
   el push; necesitan pasar por el despliegue del ambiente.

El SQL es idempotente: se probo ejecutandolo varias veces. La configuracion
global de Mascotas queda en una sola fila con 19 columnas.

## Incidencias corregidas

| Incidencia anterior | Resultado nuevo | Causa y correccion |
| --- | --- | --- |
| Vida: B3 entregaba 1,271 registros contra 1,115 de B2. | B3 entrega 1,115; la comparacion de columnas y filas contra el resultset B2 dio cero diferencias. | Las coberturas adicionales multiplicaban al empleado. La salida B3 ahora proyecta el mismo nivel de detalle que B2 y elimina esa multiplicacion. |
| Gastos Funerarios: 217 contra 215. | 215, igual que B2. | Se excluyen solicitudes rechazadas/canceladas y se conserva la union solicitud-empresa. |
| Plan de Pension: 256 contra 255. | 255, igual que B2. | Se aplica el mismo filtro de estatus de solicitud de B2. |
| No aparecia la hoja de Mascotas. | El wrapper entrega un cuarto resultset con 34 registros y el generador crea `MASCOTAS`. | Se agrego el SP de Mascotas, se admite que `ff_InfoPlanMascota.idPlan` guarde plan u opcion de plan y se asegura su configuracion global. |
| Cobranza colocaba el total de Concentrada al principio. | Las filas TOTAL se colocan al final. | El orden ya no depende de que la primera fila sea el total. |
| Empresa, ID, Edad y Numero Oficina se mostraban como moneda. | Claves como texto y campos enteros como numero sin moneda. | El formato se resuelve por nombre del campo, no por el valor nulo de la fila TOTAL. |
| Los bloques y conceptos de Total por coberturas tenian otro orden. | Se conserva el orden del SP/B2 y los conceptos siguen `ImpPer`: Prima Neta, Derecho, IVA y Prima Total. | Se retiro la reubicacion artificial de resultsets y se agrego el ordinal SQL a la ordenacion. |
| La cobranza terminaba y se podia descargar, pero no notificaba. | El proceso asincrono solicita una notificacion tanto en exito como en error. | El endpoint transmite el token y el servicio usa las plantillas configuradas al finalizar. Un error del correo no cambia a ERROR un Excel ya generado. |

La observacion sobre la suma de `Costo Empleado` y `Costo Empresa` no se
modifico: el documento indica que el mismo comportamiento existe en B2 y B2
es el origen funcional que no debe alterarse.

## Evidencia local

- Base: `(localdb)\MSSQLLocalDB`, `FlexiForbesv2`.
- Empresa 2185, vigencia 4067, periodo 2025-10-13 a 2026-09-30.
- Wrapper B3: GMM 1,674; Vida 1,115; opcionales 1,723; Mascotas 34.
- Gastos Funerarios 215 y Plan de Pension 255.
- Se conservaron los trece conteos GMM informados, que suman 1,674.
- La suite Maven termino con 42 pruebas, cero fallas y cero errores; cuatro
  inspectores que requieren rutas externas se omiten en la corrida general.
- Los inspectores se ejecutaron por separado sobre los XLSX entregados de B2 y
  B3 para establecer el estado anterior.

Nota de evidencia: los dos XLSX historicos de Sabana suministrados contienen
28 hojas y ninguno contiene Mascotas. El documento de incidencias pide
expresamente restaurarla; con la informacion fuente local el resultado nuevo
tiene 29 hojas, incluyendo `MASCOTAS`. Este punto queda comprobado contra los
datos y la configuracion, no contra una hoja Mascotas B2 incluida en esos XLSX.

El envio SMTP real no puede ejecutarse en LocalDB. La regresion automatizada
comprueba que, al finalizar Cobranza, se invoca una vez el cliente de correo
con destinatario, plantillas y token correctos. La confirmacion final del correo
requiere el despliegue y conectividad del ambiente.
