package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.ResponseGralDTO;
import com.lockton.rpt.services.CobranzaService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("beflex/cobranza")
public class WSCobranzaController {

    private static final Log LOGGER = LogFactory.getLog(WSCobranzaController.class);

    @Autowired
    private CobranzaService cobranzaService;

    @PostMapping("/consultar")
    public ResponseEntity<List<Object>> consultar(
            @RequestBody Map<String, Object> body,
            @RequestHeader("authorization") String token) {

        List<Object> list = new LinkedList<>();
        try {
            int idEmpresa     = parseInt(body.get("idEmpresa"));
            int idSolTipo     = parseInt(body.get("idSolTipo"));
            String FecIni     = str(body.get("FecIni"));
            String FecFin     = str(body.get("FecFin"));
            int idVencida     = parseInt(body.get("idVencida"));
            List<Integer> ids = toIntList(body.get("IdsPerfil"));
            String empresa    = str(body.get("empresa"));
            int idCorporativo = parseInt(body.get("idCorporativo"));
            String nomCorp    = str(body.get("nomCorp"));
            String nomAdm     = str(body.get("nomAdm"));
            String nomEmp     = str(body.get("nomEmp"));
            String email      = str(body.get("email"));
            int idVigencia    = parseInt(body.get("idVigencia"));
            int bandera       = parseInt(body.get("bandera"));
            int idUsuario     = body.containsKey("idUsuario") ? parseInt(body.get("idUsuario")) : 0;

            list = cobranzaService.consultaCobranza(idEmpresa, idSolTipo, FecIni, FecFin, idVencida,
                    ids, empresa, idCorporativo, nomCorp, nomAdm, nomEmp, email, idVigencia, bandera, idUsuario);

        } catch (Exception e) {
            LOGGER.error("WSCobranzaController.consultar: " + e.getMessage(), e);
            List<Object> err = new ArrayList<>();
            Map<String, Object> json = new HashMap<>();
            json.put("error",    true);
            json.put("mssError", e.getMessage());
            err.add(json);
            return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
        }
        if (list.isEmpty()) return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @PostMapping("/solicitar")
    public ResponseEntity<ResponseGralDTO> solicitar(
            @RequestBody Map<String, Object> body,
            @RequestHeader("authorization") String token) {
        try {
            int idEmpresa     = parseInt(body.get("idEmpresa"));
            int idSolTipo     = parseInt(body.get("idSolTipo"));
            String FecIni     = str(body.get("FecIni"));
            String FecFin     = str(body.get("FecFin"));
            int idVencida     = parseInt(body.get("idVencida"));
            List<Integer> ids = toIntList(body.get("IdsPerfil"));
            String empresa    = str(body.get("empresa"));
            int idCorporativo = parseInt(body.get("idCorporativo"));
            String nomCorp    = str(body.get("nomCorp"));
            String nomAdm     = str(body.get("nomAdm"));
            String nomEmp     = str(body.get("nomEmp"));
            String email      = str(body.get("email"));
            int idVigencia    = parseInt(body.get("idVigencia"));
            int bandera       = parseInt(body.get("bandera"));
            int idUsuario     = body.containsKey("idUsuario") ? parseInt(body.get("idUsuario")) : 0;

            ResponseGralDTO response = cobranzaService.solicitarAsync(idEmpresa, idSolTipo,
                    FecIni, FecFin, idVencida, ids, empresa, idCorporativo,
                    nomCorp, nomAdm, nomEmp, email, idVigencia, bandera,
                    idUsuario, token);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            LOGGER.error("WSCobranzaController.solicitar: " + e.getMessage(), e);
            ResponseGralDTO err = new ResponseGralDTO();
            err.status = false;
            err.messages = e.getMessage();
            return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getVigenciaActiva")
    public ResponseEntity<String> getVigenciaActiva(@RequestParam int idEmpresa,
            @RequestHeader("authorization") String token) {
        try {
            return ResponseEntity.ok(cobranzaService.getVigenciaActiva(idEmpresa) + "");
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return new ResponseEntity<>("-1", HttpStatus.NO_CONTENT);
        }
    }

    @GetMapping("/getFechaInicioVigencia")
    public String getFechaInicioVigencia(@RequestParam int vigencia,
            @RequestHeader("authorization") String token) {
        try { return cobranzaService.getFechaInicioVigencia(vigencia); } catch (Exception e) { return ""; }
    }

    @GetMapping("/getFechaFinalVigencia")
    public String getFechaFinalVigencia(@RequestParam int vigencia,
            @RequestHeader("authorization") String token) {
        try { return cobranzaService.getFechaFinalVigencia(vigencia); } catch (Exception e) { return ""; }
    }

    @GetMapping("/getFechaInicioEnrollment")
    public String getFechaInicioEnrollment(@RequestParam int vigencia,
            @RequestHeader("authorization") String token) {
        try { return cobranzaService.getFechaInicioEnrollment(vigencia); } catch (Exception e) { return ""; }
    }

    @GetMapping("/getConfiguracionEnvio")
    public ResponseEntity<String> getConfiguracionEnvio(@RequestParam int idCorporativo,
            @RequestHeader("authorization") String token) {
        try {
            return ResponseEntity.ok(cobranzaService.getConfiguracionEnvio(idCorporativo) + "");
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return new ResponseEntity<>("-1", HttpStatus.NO_CONTENT);
        }
    }

    @GetMapping("/getPeriodicidadDePagos")
    public ResponseEntity<List<Object>> getPeriodicidadDePagos(@RequestParam int idVigencia,
            @RequestHeader("authorization") String token) {
        try {
            List<Object> list = cobranzaService.getPeriodicidadDePagos(idVigencia);
            if (list.isEmpty()) return new ResponseEntity<>(list, HttpStatus.NO_CONTENT);
            return ResponseEntity.ok(list);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            List<Object> err = new ArrayList<>();
            err.add(e.getMessage());
            return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private static int parseInt(Object val) {
        return val == null ? 0 : Integer.parseInt(val.toString());
    }

    private static String str(Object val) {
        return val == null ? "null" : val.toString();
    }

    @SuppressWarnings("unchecked")
    private static List<Integer> toIntList(Object val) {
        List<Integer> result = new ArrayList<>();
        if (val instanceof List) {
            for (Object item : (List<?>) val) {
                try { result.add(Integer.parseInt(item.toString())); } catch (Exception ignored) {}
            }
        }
        return result;
    }
}
