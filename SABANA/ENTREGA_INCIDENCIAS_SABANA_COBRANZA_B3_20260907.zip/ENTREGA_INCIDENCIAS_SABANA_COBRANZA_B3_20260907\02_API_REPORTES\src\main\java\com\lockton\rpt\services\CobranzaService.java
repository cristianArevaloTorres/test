package com.lockton.rpt.services;

import com.lockton.rpt.models.dto.ResponseGralDTO;
import java.util.List;

public interface CobranzaService {
    List<Object> consultaCobranza(int idEmpresa, int idSolTipo, String FecIni, String FecFin,
            int idVencida, List<Integer> IdsPerfil, String empresa, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email, int idVigencia, int bandera,
            int idUsuario);

    ResponseGralDTO solicitarAsync(int idEmpresa, int idSolTipo, String FecIni, String FecFin,
            int idVencida, List<Integer> IdsPerfil, String empresa, int idCorporativo,
            String nomCorp, String nomAdm, String nomEmp, String email, int idVigencia, int bandera,
            int idUsuario, String token);

    int  getVigenciaActiva(int idEmpresa);
    String getFechaInicioVigencia(int vigencia);
    String getFechaFinalVigencia(int vigencia);
    String getFechaInicioEnrollment(int vigencia);
    int  getConfiguracionEnvio(int idCorporativo);
    List<Object> getPeriodicidadDePagos(int idVigencia);
}
