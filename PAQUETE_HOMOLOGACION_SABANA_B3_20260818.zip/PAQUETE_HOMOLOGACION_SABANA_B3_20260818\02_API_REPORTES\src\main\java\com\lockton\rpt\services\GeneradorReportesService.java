package com.lockton.rpt.services;

import com.lockton.rpt.enumeradores.EstatusReporte;
import com.lockton.rpt.models.dto.ResponseAsyncRptDTO;
import com.lockton.rpt.util.Excel_Columna_Multiple;
import com.lockton.rpt.util.Excel_Encabezados;
import com.lockton.rpt.util.Excel_Filtros;
import com.lockton.rpt.util.Excel_Hoja_Multiple;
import com.lockton.rpt.util.Excel_Multiple;
import com.lockton.rpt.util.Excel_Tablas_Graficos;
import com.lockton.rpt.util.PDF_Filtros;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import java.sql.Types;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.stereotype.Service;

@Service
public class GeneradorReportesService {

    private static final Log LOGGER = LogFactory.getLog(GeneradorReportesService.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private SabanaBeneficiosLegacyService sabanaBeneficiosLegacyService;

    public ResponseAsyncRptDTO ReporteDinamico(int reporteId, Map<String, Object> params) throws Exception {
        return ejecutarOrquestadorBD(reporteId, params);
    }

    /**
     * Inserta un renglon de diagnostico en dbo.bf_RepConf_Debug (crear la
     * tabla con docs/create-bf_RepConf_Debug.sql) ademas de
     * imprimirlo en consola. Nunca lanza excepcion: si la tabla no existe o
     * la conexion falla, el fallo se ignora silenciosamente para no romper
     * la generacion del reporte.
     */
    private void debug(String etapa, String detalle) {
        System.out.println("DIAG " + etapa + " " + detalle);
        try {
            jdbcTemplate.update(
                    "INSERT INTO dbo.bf_RepConf_Debug (etapa, detalle) VALUES (?, ?)",
                    etapa,
                    detalle == null ? null : (detalle.length() > 3800 ? detalle.substring(0, 3800) : detalle));
        } catch (Exception ignore) {
            // No romper el flujo principal por fallas de logging.
        }
    }

    public ResponseAsyncRptDTO ejecutarOrquestadorBD(int reporteId, Map<String, Object> params) throws Exception {
        ResponseAsyncRptDTO rsAsync = new ResponseAsyncRptDTO();
        String rutaNoVacia = null;
        // Persistir diagnostico de resolucion grupo/columnas en
        // dbo.bf_RepConf_Debug (ver docs/create-bf_RepConf_Debug.sql
        // para el CREATE TABLE). Permite revisar el detalle por SQL cuando la
        // consola del proceso no es accesible/confiable (VPN).
        Excel_Hoja_Multiple.DEBUG_SINK = this::debug;
        // Exponer reporteId a los renderizadores para resolver rutas/títulos
        try {
            if (params != null && !params.containsKey("reporteId")) {
                params.put("reporteId", reporteId);
            }
        } catch (Exception ignore) {}
        // Construir TVP rpt.ParamValor: ParamNombre debe incluir '@' y Valor como string
        SQLServerDataTable tvp = new SQLServerDataTable();
        tvp.addColumnMetadata("ParamNombre", Types.NVARCHAR);
        tvp.addColumnMetadata("Valor", Types.NVARCHAR);

        for (Map.Entry<String, Object> e : params.entrySet()) {
            String key = e.getKey();
            Object val = e.getValue();
            String paramName = key.startsWith("@") ? key : ("@" + key);
            String valueStr = toStringForTvp(val);
            tvp.addRow(paramName, valueStr);
        }
        LOGGER.info("Construccion dinamica de SP...");
        jdbcTemplate.setFetchSize(500);
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withSchemaName("dbo")
                .withProcedureName("ff_orquestadorReportes")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("reporteId", java.sql.Types.INTEGER),
                        new SqlParameter("params", microsoft.sql.Types.STRUCTURED, "dbo.ParamValor")
                );
        Map<String, Object> inParamMap = new LinkedHashMap<>();
        inParamMap.put("reporteId", reporteId);
        inParamMap.put("params", tvp);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        LOGGER.info("Ejecucion de SP, reporteId: " + reporteId);
        Map<String, Object> rs = call.execute(in);

        // 1) Extraer todos los resultsets
        List<ArrayList<LinkedCaseInsensitiveMap<?>>> resultsets = extraerResultsets(rs);
        if (resultsets.isEmpty()) {
            System.out.println("sin resultsets");
            rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
            rsAsync.setMensaje("No existen registros con los parámetros ingresados");
            return rsAsync;
        }

        // 2) Detectar RS de metadatos (puede no ser RS#1)
        Integer tipoReporteId = null;
        String tipoReporteNombre = null;
        int metaIdx = -1;
        for (int i = 0; i < resultsets.size(); i++) {
            ArrayList<LinkedCaseInsensitiveMap<?>> rsx = resultsets.get(i);
            if (rsx == null || rsx.isEmpty()) continue;
            LinkedCaseInsensitiveMap<?> row = rsx.get(0);
            if (row.containsKey("TipoReporteId") || row.containsKey("TipoReporteNombre")) {
                // Adjuntar también catReportesNombre / catReportesFormato a params para que los renderizadores lo usen (p. ej. nombre de hoja, encabezados)
                try {
                    Object rptNombre = row.get("catReportesNombre");
                    if (rptNombre != null) {
                        params.put("catReportesNombre", String.valueOf(rptNombre));
                    }
                    Object rptFormato = row.get("catReportesFormato");
                    if (rptFormato != null) {
                        params.put("catReportesFormato", String.valueOf(rptFormato));
                    }
                } catch (Exception ignore) {}
                Object id = row.get("TipoReporteId");
                Object nombre = row.get("TipoReporteNombre");
                if (id instanceof Number) tipoReporteId = ((Number) id).intValue();
                else if (id != null) try { tipoReporteId = Integer.parseInt(String.valueOf(id)); } catch (Exception ignore) {}
                tipoReporteNombre = nombre == null ? null : String.valueOf(nombre);
                metaIdx = i;
                break;
            }
        }

        // 2.1) Cargar configuración de reporte desde BD (si existe)
        try {
            List<Map<String, Object>> repConf = cargarConfiguracionReporte(reporteId, params);
            if (repConf != null) {
                params.put("reporteConfig", repConf);
            }
        } catch (Exception ex) {
            LOGGER.warn("No fue posible cargar la configuracion del reporte "
                    + reporteId + " para la empresa solicitada.", ex);
        }

        // 2.2) Resolver nombre del corporativo para B2:
        //      1) Tomar EMIdCorporativo del EMIdEmpresa consultado
        //      2) Con ese Id, obtener EMRazonSocial (fallback: EMNombre)
        try {
            Object empBaseObj = params.get("admIdEmpresa");
            if (empBaseObj == null) empBaseObj = params.get("idEmpresa");
            if (empBaseObj != null) {
                String empBaseStr = String.valueOf(empBaseObj).trim();
                if (empBaseStr.contains(",")) empBaseStr = empBaseStr.split(",")[0].trim();
                Integer empBase = null;
                try { empBase = Integer.parseInt(empBaseStr); } catch (Exception ignore) {}
                if (empBase != null) {
                    // 1) Id corporativo (si no existe, usar el mismo idEmpresa)
                    String qIdCorp = "SELECT TOP 1 ISNULL(EMIdCorporativo, EMIdEmpresa) FROM ff_Empresa WITH (NOLOCK) WHERE EMIdEmpresa = ?";
                    Integer idCorp = null;
                    try { idCorp = jdbcTemplate.queryForObject(qIdCorp, Integer.class, empBase); } catch (Exception ignore) {}
                    if (idCorp == null) idCorp = empBase;
                    // 2) Nombre corporativo (preferir Razon Social; fallback a Nombre)
                    String qRazon = "SELECT TOP 1 EMRazonSocial FROM ff_Empresa WITH (NOLOCK) WHERE EMIdEmpresa = ?";
                    String corporativo = null;
                    try { corporativo = jdbcTemplate.queryForObject(qRazon, String.class, idCorp); } catch (Exception ignore) {}
                    if (corporativo == null || corporativo.trim().isEmpty()) {
                        String qNom = "SELECT TOP 1 EMNombre FROM ff_Empresa WITH (NOLOCK) WHERE EMIdEmpresa = ?";
                        try { corporativo = jdbcTemplate.queryForObject(qNom, String.class, idCorp); } catch (Exception ignore) {}
                    }
                    if (corporativo != null && !corporativo.trim().isEmpty()) {
                        params.put("corporativoNombre", corporativo);
                    }
                }
            }
        } catch (Exception ignore) {}

        // 2.3) Para Reporte 2 (Población/Asegurados): obtener títulos dinámicos desde bf_CatSubReportes
        try {
            if (reporteId == 2) {
                Integer idEstatusSel = resolverIdEstatusParaPoblacion(params);
                if (idEstatusSel != null) {
                    String qSub = "SELECT TOP 1 catSubReportesNombre, catSubReportesNombreHoja " +
                            "FROM bf_CatSubReportes WITH (NOLOCK) " +
                            "WHERE catReportesId = ? AND catSubEstatusId = ? " +
                            "ORDER BY catSubReportesId";
                    try {
                        Map<String, Object> sub = jdbcTemplate.queryForMap(qSub, 2, idEstatusSel);
                        if (sub != null) {
                            Object nom = sub.get("catSubReportesNombre");
                            Object hoja = sub.get("catSubReportesNombreHoja");
                            if (nom != null) {
                                params.put("tituloReporteB1", String.valueOf(nom));
                                // también exponer con un alias genérico ampliamente usado
                                params.put("tituloReporte", String.valueOf(nom));
                            }
                            if (hoja != null) {
                                params.put("nombreHoja", String.valueOf(hoja));
                                // alias adicional por compatibilidad
                                params.put("sheetName", String.valueOf(hoja));
                            }
                        }
                    } catch (Exception ignore) {}
                }
            }
        } catch (Exception ignore) {}

        // 3) Data: el resto de RS
        List<ArrayList<LinkedCaseInsensitiveMap<?>>> data = new java.util.ArrayList<>();
        for (int i = 0; i < resultsets.size(); i++) {
            if (i == metaIdx) continue; // omitir RS de metadatos
            data.add(resultsets.get(i));
        }

        // Diagnóstico sábana: cuando algún data-RS tiene 0 filas, revelar causa
        if (esSabanaBeneficios(reporteId, params)) {
            StringBuilder dsizes = new StringBuilder();
            boolean hayVacio = false;
            for (int i = 0; i < data.size(); i++) {
                ArrayList<LinkedCaseInsensitiveMap<?>> d = data.get(i);
                int sz = (d == null) ? 0 : d.size();
                if (dsizes.length() > 0) dsizes.append(" ");
                dsizes.append("data[").append(i).append("]:").append(sz);
                if (sz == 0) hayVacio = true;
            }
            debug("sabana_data_sizes", dsizes.toString());
            try {
                List<Map<String, Object>> vidaDef = jdbcTemplate.queryForList(
                    "SELECT CAST(definition AS NVARCHAR(MAX)) AS def"
                    + " FROM sys.sql_modules WHERE object_id=OBJECT_ID('dbo.ff_SabanaVIDA_v2')");
                if (vidaDef.isEmpty()) {
                    debug("sabana_vida_sp_def", "ff_SabanaVIDA_v2=NO-EXISTE");
                } else {
                    String d = String.valueOf(vidaDef.get(0).get("def"));
                    int chunk = 500, n = (int) Math.ceil((double) d.length() / chunk);
                    debug("sabana_vida_sp_def_total", "len=" + d.length() + " chunks=" + n);
                    for (int ci = 0; ci < n; ci++) {
                        int s = ci * chunk, e = Math.min(s + chunk, d.length());
                        debug("sabana_vida_sp_def_" + (ci + 1), d.substring(s, e));
                    }
                }
            } catch (Exception exVida) {
                debug("sabana_vida_sp_def", "ERROR: " + exVida.getMessage());
            }
            if (hayVacio) {
                debug("sabana_params_enviados",
                    "idEmpresa=" + params.get("idEmpresa")
                    + " idVigencia=" + params.get("idVigencia")
                    + " fechaIni=" + params.get("fechaIni")
                    + " fechaFin=" + params.get("fechaFin")
                    + " idEstatus=" + params.get("idEstatus"));
                try {
                    List<Map<String, Object>> diagRows = jdbcTemplate.queryForList(
                        "SELECT CASE WHEN CAST(definition AS NVARCHAR(MAX)) "
                        + "LIKE '%AND cs.CSidVigencia=@idVigencia%' THEN 1 ELSE 0 END AS tieneFiltroBloqueante,"
                        + "CASE WHEN CAST(definition AS NVARCHAR(MAX)) LIKE '%flujo aislado%' THEN 1 ELSE 0 END AS esFlujoAislado "
                        + "FROM sys.sql_modules WHERE object_id = OBJECT_ID('dbo.ff_SabanaOPC_v2')");
                    if (diagRows.isEmpty()) {
                        debug("sabana_opc_sp_estado", "ff_SabanaOPC_v2=NO-EXISTE-EN-BD");
                    } else {
                        Object filtro = diagRows.get(0).get("tieneFiltroBloqueante");
                        Object aislado = diagRows.get(0).get("esFlujoAislado");
                        String version = (filtro instanceof Number && ((Number) filtro).intValue() == 1)
                            ? "ANTIGUA-con-filtro-vigencia" : "OK-sin-filtro-vigencia";
                        debug("sabana_opc_sp_estado",
                            "ff_SabanaOPC_v2=EXISTE tieneFiltroBloqueante=" + filtro
                            + " esFlujoAislado=" + aislado
                            + " version=" + version);
                    }
                } catch (Exception exDiag) {
                    debug("sabana_opc_sp_estado", "ERROR-diagnostico: " + exDiag.getMessage());
                }
            }
        }

        // El generador legacy enriquecia GMM y Opcionales despues de ejecutar
        // los SP y antes de escribir el libro. El flujo asincrono no pasa por
        // JDBCSabana, por lo que estas reglas deben aplicarse aqui.
        if (esSabanaBeneficios(reporteId, params)) {
            try {
                sabanaBeneficiosLegacyService.homologar(data, params);
            } catch (Exception ex) {
                // Igual que legacy: una falla de membresias/Folio no invalida
                // el resto del reporte; deja Folio vacio y registra el detalle.
                LOGGER.warn("No fue posible homologar las reglas legacy de "
                        + "Folio para la Sabana de Beneficios.", ex);
            }
        }

        // 3.1) Fallback: si no recibimos metadatos en RS, consultar tipo de reporte en BD
        // Usamos el número lógico (catReportesNum = reporteId) para resolver el tipo.
        if (tipoReporteNombre == null || tipoReporteNombre.trim().isEmpty()) {
            try {
                String qTipo = "SELECT TOP 1 tr.catTipoReportesDesc " +
                        "FROM bf_CatReportes r WITH (NOLOCK) " +
                        "JOIN bf_CatTipoReportes tr WITH (NOLOCK) ON tr.catTipoReportesId = r.catTipoReporteId " +
                        "WHERE r.catReportesNum = ?";
                tipoReporteNombre = jdbcTemplate.queryForObject(qTipo, String.class, reporteId);
            } catch (Exception ignore) {}
        }
        // 3.2) Completar nombre y formato de reporte desde BD si no vino en metadatos
        try {
            if (!params.containsKey("catReportesNombre") || !params.containsKey("catReportesFormato")) {
                String qInfo = "SELECT TOP 1 catReportesNombre, catReportesFormato FROM bf_CatReportes WITH (NOLOCK) WHERE catReportesNum = ?";
                Map<String, Object> meta = jdbcTemplate.queryForMap(qInfo, reporteId);
                if (meta != null) {
                    if (!params.containsKey("catReportesNombre") && meta.get("catReportesNombre") != null) {
                        params.put("catReportesNombre", String.valueOf(meta.get("catReportesNombre")));
                    }
                    if (!params.containsKey("catReportesFormato") && meta.get("catReportesFormato") != null) {
                        params.put("catReportesFormato", String.valueOf(meta.get("catReportesFormato")));
                    }
                }
            }
        } catch (Exception ignore) {}

        // 4) Despacho por tipo (dinámico): primero registro local (estable), luego reflexión
        debug("despacho_tipoReporte", "reporteId=" + reporteId + " tipoReporteNombre='" + tipoReporteNombre
                + "' metaIdx=" + metaIdx + " resultsetsCount=" + resultsets.size() + " dataCount=" + data.size());
        if (tipoReporteNombre != null && !tipoReporteNombre.trim().isEmpty()) {
            // Normalizar/desambiguar posibles descripciones a nombres de clase
            String tn = tipoReporteNombre.trim();
            String tnComp = tn.replaceAll("\\s+", "_").replace("-", "_");
            String tnCompNoSep = tn.replaceAll("[_\\s\\-]", "");
            if (tnComp.equalsIgnoreCase("Excel_Filtros") || tnCompNoSep.equalsIgnoreCase("ExcelFiltros")) {
                tipoReporteNombre = "Excel_Filtros";
            } else if (tnComp.equalsIgnoreCase("Excel_Hoja_Multiple") || tnCompNoSep.equalsIgnoreCase("ExcelHojaMultiple")) {
                tipoReporteNombre = "Excel_Hoja_Multiple";
            } else if (tnComp.equalsIgnoreCase("Excel_Columna_Multiple") || tnCompNoSep.equalsIgnoreCase("ExcelColumnaMultiple")) {
                tipoReporteNombre = "Excel_Columna_Multiple";
            } else {
                tipoReporteNombre = tn;
            }

            // Nota: el TipoReporteNombre que llega desde BD/metadatos del SP para
            // el reporte de Sabana de Beneficios (reporteId 3) puede venir
            // configurado como "Excel_Columna_Multiple" (valor de catalogo),
            // NO como "Excel_Hoja_Multiple". esSabanaBeneficios() es la fuente
            // de verdad real para detectar este caso especial (reporteId==3 o
            // catReportesNombre contiene "sabana"), por lo que forzamos aqui
            // el tipo de renderizador correcto en vez de exigir que ya venga
            // como "Excel_Hoja_Multiple" desde BD.
            boolean sabanaBeneficios = esSabanaBeneficios(reporteId, params);
            if (sabanaBeneficios) {
                tipoReporteNombre = "Excel_Hoja_Multiple";
            }
            debug("despacho_sabana", "tipoReporteNombre='" + tipoReporteNombre + "' sabanaBeneficios=" + sabanaBeneficios
                    + " esSabanaBeneficios=" + esSabanaBeneficios(reporteId, params));

            // Caso especial: Reporte 7 (reporteAccesosBeMobile) -> Excel_Tablas_Graficos:
            // requiere TODOS los RS de datos en una sola llamada, ya que la clase decide
            // internamente qué RS va a Detalle (último) y cuáles se usarán para Resumen.
            if ("Excel_Tablas_Graficos".equalsIgnoreCase(tipoReporteNombre) && reporteId == 7) {
                try {
                    String tmp = Excel_Tablas_Graficos.generar(data, params, "./out");
                    if (tieneRuta(tmp)) {
                        rutaNoVacia = tmp;
                    }
                    if (tieneRuta(rutaNoVacia)) {
                        rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                        rsAsync.setMensaje("Reporte generado exitosamente.");
                        rsAsync.setRuta(rutaNoVacia);
                    }
                    else{
                        rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                        rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                    }
                    return rsAsync;
                } catch (Exception e) {
                    System.out.println("Error al generar reporte 7 con Excel_Tablas_Graficos: " +
                            (e.getMessage() == null ? e.getClass().getName() : e.getMessage()));
                    if (e.getCause() != null) {
                        System.out.println("Causa: " + e.getCause().getClass().getName() + ": " + e.getCause().getMessage());
                    }
                    // Si falla, continuar con el flujo estándar de despacho como fallback.
                }
            }

            // Caso especial: Sábana de Beneficios (reporteId 3) debe consolidar todos los RS en un solo archivo
            if (sabanaBeneficios) {
                try {
                    String tmp = Excel_Hoja_Multiple.generar(data, params, "./out");
                    if (tieneRuta(tmp)) {
                        rutaNoVacia = tmp;
                        // Password propio de Sabana. Durante la migracion conserva
                        // compatibilidad con el parametro 12 anterior.
                        aplicarPasswordSabanaSiCorresponde(tmp, params);
                    }
                    if (tieneRuta(rutaNoVacia)) {
                        rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                        rsAsync.setMensaje("Reporte generado exitosamente");
                        rsAsync.setRuta(rutaNoVacia);
                    } else{
                        rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                        rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                    }
                    return rsAsync;
                } catch (Exception e) {
                    /*
                     * La Sabana es un único libro consolidado. El despacho
                     * genérico genera un archivo por resultset y sólo conserva
                     * la última ruta, por lo que usarlo como fallback puede
                     * entregar un reporte parcial o sobrescrito.
                     */
                    LOGGER.error("No fue posible generar la Sabana de "
                            + "Beneficios consolidada.", e);
                    throw new IllegalStateException(
                            "No fue posible generar la Sabana de Beneficios "
                            + "consolidada.", e);
                }
            }

            // Caso especial: Excel_Columna_Multiple consolida TODOS los RS en un solo archivo.
            // A diferencia de Excel_Hoja_Multiple, las pestañas y columnas se resuelven por los
            // valores de las columnas 'NombrePestana' y 'grupo' que vienen en los propios datos,
            // no por la posición/indexTable del resultset.
            if ("Excel_Columna_Multiple".equalsIgnoreCase(tipoReporteNombre)) {
                try {
                    String tmp = Excel_Columna_Multiple.generar(data, params, "./out");
                    if (tieneRuta(tmp)) {
                        rutaNoVacia = tmp;
                    }
                    if (tieneRuta(rutaNoVacia)) {
                        rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                        rsAsync.setMensaje("Reporte generado exitosamente");
                        rsAsync.setRuta(rutaNoVacia);
                    } else {
                        rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                        rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                    }
                    return rsAsync;
                } catch (Exception e) {
                    System.out.println("Error al generar Excel_Columna_Multiple: " +
                            (e.getMessage() == null ? e.getClass().getName() : e.getMessage()));
                    if (e.getCause() != null) {
                        System.out.println("Causa: " + e.getCause().getClass().getName() + ": " + e.getCause().getMessage());
                    }
                    // Si falla, continuar con el flujo estándar de despacho como fallback.
                }
            }

            // Caso especial: Reporte 4 (Costos y Créditos) debe generar UN solo archivo de Excel
            // con todas las hojas configuradas en bf_RepConf_Tabla / bf_RepConf_Columna.
            // Para eso enviamos todos los resultsets juntos a Excel_Hoja_Multiple.
            if ("Excel_Hoja_Multiple".equalsIgnoreCase(tipoReporteNombre) && reporteId == 4) {
                try {
                    if(Boolean.TRUE.equals(params.get("porTitular"))){
                        List<Map<String, Object>> list = (List<Map<String, Object>>) params.get("reporteConfig");
                        list = list.subList(list.size() - 1, list.size());
                        params.remove("reporteConfig");
                        params.put("reporteConfig", list);
                    }

                    String tmp = Excel_Hoja_Multiple.generar(data, params, "./out");
                    if (tieneRuta(tmp)) {
                        rutaNoVacia = tmp;
                    }
                    if (tieneRuta(rutaNoVacia)) {
                        rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                        rsAsync.setMensaje("Reporte generado exitosamente");
                        rsAsync.setRuta(rutaNoVacia);
                    }
                    else{
                        rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                        rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                    }
                } catch (Exception e) {
                    System.out.println("Error al generar reporte 11 con Excel_Hoja_Multiple: " +
                            (e.getMessage() == null ? e.getClass().getName() : e.getMessage()));
                    if (e.getCause() != null) {
                        System.out.println("Causa: " + e.getCause().getClass().getName() + ": " + e.getCause().getMessage());
                    }
                    // Si falla, continuar con el flujo estándar de despacho como fallback.
                }
            }
            // === Cortar flujo para encabezados: una sola llamada y return inmediato ===
            if ("Excel_Encabezado".equalsIgnoreCase(tipoReporteNombre)
                    || "Excel_Encabezado_Hoja_Multiple".equalsIgnoreCase(tipoReporteNombre)) {
                if (sinDatos(data)) {
                    rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                    rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                    return rsAsync;
                }
                String tmp = SeleccionarInvocacion(tipoReporteNombre, data, params);
                if (tieneRuta(tmp)) {
                    rutaNoVacia = tmp;
                    rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                    rsAsync.setMensaje("Reporte generado exitosamente");
                    rsAsync.setRuta(rutaNoVacia);
                } else {
                    rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                    rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                }
                return rsAsync; // no permitir más invocaciones ni iteraciones
            }

            // Registro estable
            Map<String, Class<?>> registry = new HashMap<>();
            registry.put("Excel_Hoja_Multiple", Excel_Hoja_Multiple.class);
            registry.put("Excel_Columna_Multiple", Excel_Columna_Multiple.class);
            registry.put("Excel_Filtros", Excel_Filtros.class);
            registry.put("Excel_Tablas_Graficos", Excel_Tablas_Graficos.class);
            registry.put("Excel_Encabezado", Excel_Encabezados.class);
            registry.put("Excel_Encabezado_Hoja_Multiple", Excel_Multiple.class);
            try {
                Class<?> clazzReg = registry.get(tipoReporteNombre);
                if (clazzReg != null) {
                    Method m = clazzReg.getMethod("generar", List.class, Map.class, String.class);
                    LOGGER.info("Clase usada: " + clazzReg.getName()); 
                    if ("Excel_Encabezado".equals(tipoReporteNombre) || "Excel_Encabezado_Hoja_Multiple".equals(tipoReporteNombre)){
                        if (sinDatos(data)){
                            rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                            rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                            return rsAsync;
                        }                            
                        String tmp = SeleccionarInvocacion(tipoReporteNombre, data, params);
                        if(tieneRuta(tmp)) rutaNoVacia=tmp;
                    }else{
                        if (!data.isEmpty()) {
                            for (int i = 0; i < data.size(); i++) {
                                List<ArrayList<LinkedCaseInsensitiveMap<?>>> solo = java.util.Collections.singletonList(data.get(i));
                                Map<String, Object> paramsC = new LinkedHashMap<>(params);
                                Map<String, Object> grp = obtenerGrupoPorIndex(params, i);
                                if (grp != null) {
                                    Object nombre = grp.get("grupo");
                                    if (nombre != null) {
                                        paramsC.put("grupoNombre", String.valueOf(nombre));
                                        paramsC.put("fileSuffix", "_" + String.valueOf(nombre));
                                    }
                                    paramsC.put("grupoIndex", grp.get("indexTable"));
                                    java.util.List<java.util.Map<String, Object>> cfgUno = new java.util.ArrayList<>();
                                    cfgUno.add(grp);
                                    paramsC.put("reporteConfig", cfgUno);
                                }
                                String tmp = SeleccionarInvocacion(tipoReporteNombre,  solo, paramsC);
                                if (tieneRuta(tmp)) {
                                    rutaNoVacia = tmp;
                                }
                            }
                        } else {
                            String tmp = SeleccionarInvocacion(tipoReporteNombre,  data, params);
                            if (tieneRuta(tmp)) {
                                rutaNoVacia = tmp;
                            }
                            //m.invoke(null, data, params, "./out");
                        }
                        if (tieneRuta(rutaNoVacia)) {
                            rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                            rsAsync.setMensaje("Reporte generado exitosamente");
                            rsAsync.setRuta(rutaNoVacia);
                        }
                        else{
                            rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                            rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                        }
                        return rsAsync;
                    }
                }
            } catch (Exception e) {
                System.out.println("Despacho por registro fallo para " + tipoReporteNombre + ": " + (e.getMessage() == null ? e.getClass().getName() : e.getMessage()));
                if (e.getCause() != null) {
                    System.out.println("Causa: " + e.getCause().getClass().getName() + ": " + e.getCause().getMessage());
                }
            }
            try {
                Class<?> clazz = Class.forName(tipoReporteNombre);
                Method m = clazz.getMethod("generar", List.class, Map.class, String.class);
                // Si hay 1..N resultsets, generar N archivos (uno por RS)
                if ("Excel_Encabezados".equalsIgnoreCase(tipoReporteNombre) || "Excel_Encabezado_Hoja_Multiple".equals(tipoReporteNombre)){
                    if (sinDatos(data)){
                            rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                            rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                            return rsAsync;
                        }
                    Object tmp = m.invoke(null,data,params, "./out");
                    if (tmp instanceof String && tieneRuta((String)tmp)) rutaNoVacia = (String) tmp;
                }else{
                    if (!data.isEmpty()) {
                        for (int i = 0; i < data.size(); i++) {
                            List<ArrayList<LinkedCaseInsensitiveMap<?>>> solo = java.util.Collections.singletonList(data.get(i));
                            Map<String, Object> paramsC = new LinkedHashMap<>(params);
                            // Resolver grupo por índice de RS y pasarlo explícito
                            Map<String, Object> grp = obtenerGrupoPorIndex(params, i);
                            if (grp != null) {
                                Object nombre = grp.get("grupo");
                                if (nombre != null) {
                                    paramsC.put("grupoNombre", String.valueOf(nombre));
                                    paramsC.put("fileSuffix", "_" + String.valueOf(nombre));
                                }
                                paramsC.put("grupoIndex", grp.get("indexTable"));
                                // Enviar SOLO la configuración del grupo actual
                                java.util.List<java.util.Map<String, Object>> cfgUno = new java.util.ArrayList<>();
                                cfgUno.add(grp);
                                paramsC.put("reporteConfig", cfgUno);
                            }
                            Object tmp = m.invoke(null, solo, paramsC, "./out");
                            if (tmp instanceof String && tieneRuta((String) tmp)) {
                                rutaNoVacia = (String) tmp;
                            }
                        }
                        
                    } else {
                        Object tmp = m.invoke(null, data, params, "./out");
                        if (tmp instanceof String && tieneRuta((String) tmp)) {
                            rutaNoVacia = (String) tmp;
                        }
                    }
                    if (tieneRuta(rutaNoVacia)) {
                        rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                        rsAsync.setMensaje("Reporte generado exitosamente");
                        rsAsync.setRuta(rutaNoVacia);
                    }
                    else{
                        rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                        rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                    }
                    return rsAsync;
                }
            } catch (Exception e) {
                System.out.println("No se pudo despachar a " + tipoReporteNombre + ": " + (e.getMessage() == null ? e.getClass().getName() : e.getMessage()));
                if (e.getCause() != null) {
                    System.out.println("Causa: " + e.getCause().getClass().getName() + ": " + e.getCause().getMessage());
                }
                // Fallback: registro local por nombre simple (evita dependencia de paquete)
                try {
                    Map<String, Class<?>> registry2 = new HashMap<>();
                    registry2.put("Excel_Hoja_Multiple", Excel_Hoja_Multiple.class);
                    registry2.put("Excel_Columna_Multiple", Excel_Columna_Multiple.class);
                    registry2.put("Excel_Filtros", Excel_Filtros.class);
                    registry2.put("Excel_Tablas_Graficos", Excel_Tablas_Graficos.class);
                    registry2.put("Excel_Encabezado", Excel_Encabezados.class);
                    registry2.put("Excel_Encabezado_Hoja_Multiple", Excel_Multiple.class);
                    Class<?> clazz = registry2.get(tipoReporteNombre.trim());
                    if (clazz != null) {
                        Method m = clazz.getMethod("generar", List.class, Map.class, String.class);
                        if ("Excel_Encabezados".equalsIgnoreCase(tipoReporteNombre) || "Excel_Encabezado_Hoja_Multiple".equals(tipoReporteNombre)){
                            if (sinDatos(data)){
                            rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                            rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                            return rsAsync;
                        }
                    Object tmp = m.invoke(null,data,params, "./out");
                    if (tmp instanceof String && tieneRuta((String)tmp)) rutaNoVacia = (String) tmp;
                }else{ 
                        if (!data.isEmpty()) {
                            for (int i = 0; i < data.size(); i++) {
                                List<ArrayList<LinkedCaseInsensitiveMap<?>>> solo = java.util.Collections.singletonList(data.get(i));
                                Map<String, Object> paramsC = new LinkedHashMap<>(params);
                                Map<String, Object> grp = obtenerGrupoPorIndex(params, i);
                                if (grp != null) {
                                    Object nombre = grp.get("grupo");
                                    if (nombre != null) {
                                        paramsC.put("grupoNombre", String.valueOf(nombre));
                                        paramsC.put("fileSuffix", "_" + String.valueOf(nombre));
                                    }
                                    paramsC.put("grupoIndex", grp.get("indexTable"));
                                    java.util.List<java.util.Map<String, Object>> cfgUno = new java.util.ArrayList<>();
                                    cfgUno.add(grp);
                                    paramsC.put("reporteConfig", cfgUno);
                                }
                                Object tmp = m.invoke(null, solo, paramsC, "./out");
                                if (tmp instanceof String && tieneRuta((String) tmp)) {
                                    rutaNoVacia = (String) tmp;
                                }
                            }
                        } else {
                            Object tmp = m.invoke(null, data, params, "./out");
                            if (tmp instanceof String && tieneRuta((String) tmp)) {
                                rutaNoVacia = (String) tmp;
                            }}
                        }
                        if (tieneRuta(rutaNoVacia)) {
                            rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                            rsAsync.setMensaje("Reporte generado exitosamente");
                            rsAsync.setRuta(rutaNoVacia);
                        }
                        else{
                            rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                            rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                        }
                    }
                    // Último fallback: llamada directa si el tipo es Excel_Hoja_Multiple
                    if ("Excel_Hoja_Multiple".equalsIgnoreCase(tipoReporteNombre)) {
                        if (!data.isEmpty()) {
                            for (int i = 0; i < data.size(); i++) {
                                List<ArrayList<LinkedCaseInsensitiveMap<?>>> solo = java.util.Collections.singletonList(data.get(i));
                                Map<String, Object> paramsC = new LinkedHashMap<>(params);
                                Map<String, Object> grp = obtenerGrupoPorIndex(params, i);
                                if (grp != null) {
                                    Object nombre = grp.get("grupo");
                                    if (nombre != null) {
                                        paramsC.put("grupoNombre", String.valueOf(nombre));
                                        paramsC.put("fileSuffix", "_" + String.valueOf(nombre));
                                    }
                                    paramsC.put("grupoIndex", grp.get("indexTable"));
                                    java.util.List<java.util.Map<String, Object>> cfgUno = new java.util.ArrayList<>();
                                    cfgUno.add(grp);
                                    paramsC.put("reporteConfig", cfgUno);
                                }
                                String tmp = Excel_Hoja_Multiple.generar(solo, paramsC, "./out");
                                if (tieneRuta(tmp)) {
                                    rutaNoVacia = tmp;
                                }
                            }
                        } else {
                            String tmp = Excel_Hoja_Multiple.generar(data, params, "./out");
                            if (tieneRuta(tmp)) {
                                rutaNoVacia = tmp;
                            }
                        }
                        if (tieneRuta(rutaNoVacia)) {
                            rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
                            rsAsync.setMensaje("Reporte generado exitosamente");
                            rsAsync.setRuta(rutaNoVacia);
                        }
                        else{
                            rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
                            rsAsync.setMensaje("No existen registros con los parámetros ingresados");
                        }
                    }
                } catch (Exception ex2) {
                    System.out.println("Fallback de registro simple falló: " + (ex2.getMessage() == null ? ex2.getClass().getName() : ex2.getMessage()));
                    if (ex2.getCause() != null) {
                        System.out.println("Causa: " + ex2.getCause().getClass().getName() + ": " + ex2.getCause().getMessage());
                    }
                }
            }
        }
        // Fallback: imprimir si no hubo clase o falló el despacho
        debug("despacho_final", "tipoReporteNombre='" + tipoReporteNombre + "' rutaNoVacia=" + rutaNoVacia);
        if (tieneRuta(rutaNoVacia)) {
            rsAsync.setEstatus(EstatusReporte.DISPONIBLE);
            rsAsync.setMensaje("Reporte generado exitosamente");
            rsAsync.setRuta(rutaNoVacia);
        }
        else{
            rsAsync.setEstatus(EstatusReporte.SIN_DATOS);
            rsAsync.setMensaje("No existen registros con los parámetros ingresados");
        }
        return rsAsync;
    }

    private static boolean tieneRuta(String ruta) {
        return ruta != null && !ruta.trim().isEmpty();
    }
    private static String toStringForTvp(Object val) {
        if (val == null) return null;
        if (val instanceof java.util.Date) {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            return f.format((java.util.Date) val);
        }
        if (val instanceof Boolean) {
            return ((Boolean) val) ? "1" : "0";
        }
        if (val instanceof BigDecimal) {
            return ((BigDecimal) val).toPlainString();
        }
        if (val instanceof Number) {
            return String.valueOf(val);
        }
        if (val instanceof Iterable<?>) {
            StringBuilder sb = new StringBuilder();
            for (Object o : (Iterable<?>) val) {
                if (sb.length() > 0) sb.append(',');
                sb.append(String.valueOf(o));
            }
            return sb.toString();
        }
        if (val.getClass().isArray()) {
            int len = java.lang.reflect.Array.getLength(val);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < len; i++) {
                if (sb.length() > 0) sb.append(',');
                sb.append(String.valueOf(java.lang.reflect.Array.get(val, i)));
            }
            return sb.toString();
        }
        return String.valueOf(val);
    }

    // Configuración de reporte en BD (sustituye SabanaConfig.xml)
    private List<Map<String, Object>> cargarConfiguracionReporte(int reporteId, Map<String, Object> params) {
        Object idEmpObj = params.get("idEmpresa");
        if (idEmpObj == null) idEmpObj = params.get("admIdEmpresa");
        int idEmpresa = 0;
        try {
            if (idEmpObj != null) {
                String raw = String.valueOf(idEmpObj).replaceAll("[\\[\\]{}]", "").trim();
                if (raw.contains(",")) raw = raw.split(",")[0].trim();
                idEmpresa = Integer.parseInt(raw);
            }
        } catch (Exception ignore) {}

        String qTablas = "SELECT idEmpresa, catReportesId, grupo, columnaGrupo, agruparPorColumna, indexTable, tituloTabla, espacioIzquierda, espacioDerecha, alineacion, colorFondo, colorLetra, activo\n" +
                "FROM bf_RepConf_Tabla WITH (NOLOCK)\n" +
                "WHERE catReportesId = ? AND idEmpresa IN (?,0)\n" +
                "ORDER BY CASE WHEN idEmpresa = ? THEN 0 ELSE 1 END, indexTable";
        // catReportesId en bf_RepConf_* almacena el número lógico (catReportesNum)
        List<Map<String, Object>> tablas = jdbcTemplate.queryForList(qTablas, reporteId, idEmpresa, idEmpresa);
        if (reporteId == 3 && tablas != null) {
            final int empresaSolicitada = idEmpresa;
            tablas.sort((a, b) -> {
                int empresaA = parseIntConfig(a.get("idEmpresa"));
                int empresaB = parseIntConfig(b.get("idEmpresa"));
                int prioridadEmpresaA = empresaA == empresaSolicitada ? 0 : 1;
                int prioridadEmpresaB = empresaB == empresaSolicitada ? 0 : 1;
                int comparacion = Integer.compare(prioridadEmpresaA, prioridadEmpresaB);
                if (comparacion != 0) return comparacion;
                comparacion = Integer.compare(
                        parseIntConfig(a.get("indexTable")),
                        parseIntConfig(b.get("indexTable")));
                if (comparacion != 0) return comparacion;
                return Integer.compare(
                        prioridadAliasGrupoSabana(a),
                        prioridadAliasGrupoSabana(b));
            });
        }
        if (reporteId == 3) {
            debug("bf_RepConf_Tabla", "reporteId=" + reporteId + " idEmpresaParam=" + idEmpresa
                    + " filas=" + (tablas == null ? 0 : tablas.size()));
            if (tablas != null) {
                for (Map<String, Object> t : tablas) {
                    debug("bf_RepConf_Tabla_fila", "grupo=" + t.get("grupo") + " idEmpresa=" + t.get("idEmpresa")
                            + " indexTable=" + t.get("indexTable") + " columnaGrupo=" + t.get("columnaGrupo")
                            + " agruparPorColumna=" + t.get("agruparPorColumna"));
                }
            }
        }
        if (tablas == null || tablas.isEmpty()) return null;

      
        Map<String, Map<String, Object>> tablaEfectiva = new LinkedHashMap<>();
        for (Map<String, Object> tabla : tablas) {
            String key = claveTablaConfiguracion(reporteId, tabla);
            if (!tablaEfectiva.containsKey(key)) {
                tablaEfectiva.put(key, tabla);
            }
        }
        tablas = new ArrayList<>(tablaEfectiva.values());
        // Primero se resuelve empresa -> global y despues se filtra activo.
        // De esta forma una fila de empresa con activo=0 realmente desactiva
        // el grupo y no reaparece por la configuracion global activa.
        if (reporteId != 11) {
            tablas = tablas.stream()
                    .filter(this::tablaConfiguracionActiva)
                    .collect(Collectors.toList());
        }
        if (reporteId == 3) {
            tablas.sort((a, b) -> Integer.compare(
                    ordenGrupoSabana(a),
                    ordenGrupoSabana(b)));
        } else {
            tablas.sort((a, b) -> Integer.compare(
                    parseIntConfig(a.get("indexTable")),
                    parseIntConfig(b.get("indexTable"))));
        }

        if(reporteId == 2) {
            String subReporte = FiltraSubReportePoblacion(params.get("idSubReporte").toString(), Boolean.TRUE.equals(params.get("sueldo")));
            tablas = tablas.stream()
                .filter(mapa -> subReporte.equals(mapa.get("grupo")))
                .collect(Collectors.toList());
        }
        // Para cada grupo/tabla, adjuntar columnas
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> t : tablas) {
            String grupo = String.valueOf(t.get("grupo"));
            int idEmpresaConfig = parseIntConfig(t.get("idEmpresa"));
            boolean sabana = reporteId == 3;
            // bf_RepConf_Tabla admite fallback idEmpresa -> 0 (ver qTablas),
            // pero bf_RepConf_Columna exigia idEmpresa exacto. Si la tabla
            // resuelta quedo en 0 (o las columnas se insertaron con un
            // idEmpresa distinto al de la tabla), la busqueda exacta
            // regresaba 0 filas y el grupo se procesaba sin configuracion
            // (columnas crudas del SP). Se replica aqui el mismo fallback:
            // preferir columnas especificas de idEmpresaConfig y, si no
            // existen, usar las de idEmpresa=0.
            // El grupo se compara sin distinguir mayusculas/minusculas ni
            // espacios sobrantes: buscarGrupoConfig (lado Java) ya es
            // tolerante a esas variaciones al resolver el grupo de la tabla,
            // por lo que un typo de captura (" Opcionales" / "OPCIONALES")
            // en bf_RepConf_Columna no debe volver a dejar el grupo sin
            // columnas configuradas.
            String qCols = "SELECT idEmpresa, catReportesId, grupo, orden, campoOrigen, encabezado, visible, ancho, formato, alinear, tipoDato\n" +
                    "FROM bf_RepConf_Columna WITH (NOLOCK)\n" +
                    "WHERE catReportesId = ? AND idEmpresa IN (?,0) AND UPPER(LTRIM(RTRIM(grupo))) = UPPER(LTRIM(RTRIM(?)))\n" +
                    ((sabana || reporteId == 11)
                            ? "" : "AND visible = 1\n") +
                    "ORDER BY orden";
            List<Map<String, Object>> colsRaw = jdbcTemplate.queryForList(
                    qCols, reporteId, idEmpresaConfig, grupo);
            boolean hayColsEspecificas = colsRaw.stream()
                    .anyMatch(c -> parseIntConfig(c.get("idEmpresa")) == idEmpresaConfig);
            List<Map<String, Object>> cols = hayColsEspecificas
                    ? colsRaw.stream()
                            .filter(c -> parseIntConfig(c.get("idEmpresa")) == idEmpresaConfig)
                            .collect(Collectors.toList())
                    : colsRaw;

            // Sabana necesita conocer tambien las columnas ocultas para
            // reproducir la lista negra del XML y anexar aliases dinamicos.
            // Para los demas reportes se conserva el comportamiento previo.
            List<Map<String, Object>> colsEfectivas;
            if (sabana) {
                colsEfectivas = cols;
            } else {
                colsEfectivas = cols.stream()
                        .collect(Collectors.toMap(
                                m -> String.valueOf(m.get("campoOrigen")),
                                m -> m,
                                (a, b) -> a,
                                java.util.LinkedHashMap::new
                        ))
                        .values().stream().collect(Collectors.toList());
            }
            Map<String, Object> tab = new LinkedHashMap<>(t);
            tab.put("columnas", colsEfectivas);
            if (sabana) {
                debug("bf_RepConf_Columna", "grupo='" + grupo + "' idEmpresaConfig=" + idEmpresaConfig
                        + " catReportesId=" + reporteId + " colsRaw=" + colsRaw.size()
                        + " hayColsEspecificas=" + hayColsEspecificas + " colsEfectivas=" + colsEfectivas.size()
                        + " campos=" + colsEfectivas.stream().map(c -> String.valueOf(c.get("campoOrigen"))).collect(Collectors.joining(",")));
            }
            if (colsEfectivas.isEmpty()) {
                System.out.println("Advertencia: bf_RepConf_Tabla tiene grupo='" + grupo
                        + "' (catReportesId=" + reporteId + ", idEmpresa=" + idEmpresaConfig
                        + ") pero bf_RepConf_Columna no devolvio columnas; se usaran las"
                        + " columnas crudas del SP para este grupo.");
            }
            // flujo aislado: layout siempre desde bf_RepConf_Columna, sin columnas dinamicas por vigencia
            // El legacy activaba blAddTableName (tabla con autofiltro) en la
            // Sábana; se replica para todos sus grupos, incluida Mascotas.
            if (sabana) {
                tab.put("autofiltro", true);
                // Vida: el SP ff_SabanaVIDA_v2 genera columnas dinámicas (VIDA, Costo_1…)
                // que no están en bf_RepConf_Columna; se agregan al final igual que en legacy.
                // La configuracion legacy ordena y excluye columnas; no es
                // una lista cerrada. Esto aplica a GMM, Vida y Opcionales.
                tab.put("preservarColumnasDinamicas", true);
            }
            if (reporteId == 11) {
                // Cobranza se instala con una columna ancla por grupo. El
                // resto del layout puede variar por empresa/vigencia y debe
                // conservarse despues de las columnas configuradas.
                tab.put("preservarColumnasDinamicas", true);
            }
            out.add(tab);
        }
        return out;
    }

    private boolean tablaConfiguracionActiva(Map<String, Object> tabla) {
        if (tabla == null || tabla.get("activo") == null) return true;
        Object activo = tabla.get("activo");
        if (activo instanceof Boolean) return (Boolean) activo;
        if (activo instanceof Number) {
            return ((Number) activo).intValue() != 0;
        }
        String value = String.valueOf(activo).trim();
        return !("0".equals(value) || "false".equalsIgnoreCase(value)
                || "no".equalsIgnoreCase(value));
    }

    private boolean esColumnaOculta(Object value) {
        if (value instanceof Boolean) {
            return !((Boolean) value);
        }
        if (value instanceof Number) {
            return ((Number) value).intValue() == 0;
        }
        if (value == null) {
            return false;
        }
        String raw = String.valueOf(value).trim();
        return "0".equals(raw)
                || "false".equalsIgnoreCase(raw)
                || "no".equalsIgnoreCase(raw);
    }

    private String claveTablaConfiguracion(
            int reporteId, Map<String, Object> tabla) {
        Object grupoObj = tabla.get("grupo");
        String grupo = grupoObj == null ? ""
                : String.valueOf(grupoObj).trim()
                        .toLowerCase(java.util.Locale.ROOT);
        if (reporteId == 3) {
            if ("opc".equals(grupo)
                    || "opcional".equals(grupo)
                    || "opcionales".equals(grupo)) {
                grupo = "opcionales";
            }
            if (!grupo.isEmpty()) {
                return "grupo:" + grupo;
            }
            return "index:" + parseIntConfig(tabla.get("indexTable"));
        }
        return "grupo:" + grupo;
    }

    private int ordenGrupoSabana(Map<String, Object> tabla) {
        String clave = claveTablaConfiguracion(3, tabla);
        if ("grupo:gmm".equals(clave)) return 0;
        if ("grupo:vida".equals(clave)) return 1;
        if ("grupo:opcionales".equals(clave)) return 2;
        // Las extensiones migradas se mantienen después de los tres grupos
        // legacy y conservan entre sí el orden configurado en indexTable.
        return 1000 + parseIntConfig(tabla.get("indexTable"));
    }

    private int prioridadAliasGrupoSabana(Map<String, Object> tabla) {
        Object grupoObj = tabla == null ? null : tabla.get("grupo");
        String grupo = grupoObj == null ? ""
                : String.valueOf(grupoObj).trim()
                        .toLowerCase(java.util.Locale.ROOT);
        // La configuracion global contiene el alias historico "Opcionales"
        // y el alias canonico migrado "OPC". Se elige siempre OPC para que
        // el resultado no dependa del orden fisico de SQL Server.
        if ("opc".equals(grupo)) return 0;
        if ("opcional".equals(grupo)) return 1;
        if ("opcionales".equals(grupo)) return 2;
        return 0;
    }

    private int parseIntConfig(Object value) {
        try {
            return value == null ? 0 : Integer.parseInt(String.valueOf(value));
        } catch (Exception ex) {
            return 0;
        }
    }

    private String obtenerSufijoGrupo(Map<String, Object> params, int index) {
        try {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> cfg = (List<Map<String, Object>>) params.get("reporteConfig");
            if (cfg == null) return null;
            Map<String, Object> tab = cfg.stream()
                    .filter(m -> {
                        Object it = m.get("indexTable");
                        try { return Integer.parseInt(String.valueOf(it)) == index; } catch (Exception e) { return false; }
                    })
                    .findFirst().orElse(null);
            if (tab == null) return null;
            Object g = tab.get("grupo");
            return g == null ? null : String.valueOf(g);
        } catch (Exception e) {
            return null;
        }
    }

    private Map<String, Object> obtenerGrupoPorIndex(Map<String, Object> params, int index) {
        try {
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> cfg = (List<Map<String, Object>>) params.get("reporteConfig");
            if (cfg == null) return null;
            for (Map<String, Object> m : cfg) {
                Object it = m.get("indexTable");
                try {
                    if (Integer.parseInt(String.valueOf(it)) == index) return m;
                } catch (Exception ignore) {}
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private boolean esSabanaBeneficios(int reporteId, Map<String, Object> params) {
        if (reporteId == 3) return true;
        try {
            Object nombre = params == null ? null : params.get("catReportesNombre");
            if (nombre != null) {
                String n = String.valueOf(nombre).toLowerCase(java.util.Locale.ROOT);
                if (n.contains("sabana")) {
                    return true;
                }
            }
        } catch (Exception ignore) {}
        return false;
    }

    /**
     * Replica el comportamiento legacy de proteger la Sábana con la contraseña
     * del parámetro 12 de la empresa. Si la empresa no tiene param 12, no hace
     * nada. Un error no invalida el reporte ya generado.
     */
    private void aplicarPasswordSabanaSiCorresponde(String ruta, Map<String, Object> params) {
        if (ruta == null || ruta.trim().isEmpty()) return;
        Integer idEmpresa = resolverIdEmpresaParam(params);
        if (idEmpresa == null || idEmpresa <= 0) return;
        String password;
        try {
            password = leerPasswordSabana(idEmpresa);
        } catch (Exception ex) {
            LOGGER.warn("No fue posible consultar el password de Sabana "
                    + "para la empresa " + idEmpresa + ".", ex);
            return;
        }
        if (password == null || password.trim().isEmpty()) return;
        try {
            cifrarXlsx(ruta, password.trim());
            LOGGER.info("Se aplico password a la Sabana de la empresa "
                    + idEmpresa + ".");
        } catch (Exception ex) {
            LOGGER.warn("No fue posible aplicar password a la Sabana "
                    + "de la empresa " + idEmpresa
                    + ". El archivo se entrega sin proteccion.", ex);
        }
    }

    private Integer resolverIdEmpresaParam(Map<String, Object> params) {
        if (params == null) return null;
        String[] llaves = {"idEmpresa", "admIdEmpresa"};
        for (String k : llaves) {
            Object v = params.get(k);
            if (v == null) continue;
            try {
                return Integer.parseInt(String.valueOf(v).trim());
            } catch (Exception ignore) {}
        }
        return null;
    }

    private String leerPasswordSabana(int idEmpresa) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT TOP (1) paValor "
              + "FROM dbo.ff_Parametro "
              + "WHERE paIdEmpresa = ? "
              + "  AND paidEstatus = 1 "
              + "  AND UPPER(LTRIM(RTRIM(paClase))) = ? "
              + "ORDER BY paId DESC",
                idEmpresa, "SABANA_EXCEL_PASSWORD");
        if (rows == null || rows.isEmpty()) return null;
        Object v = valorParametro(rows.get(0));
        return v == null ? null : String.valueOf(v).trim();
    }

    private Object valorParametro(Map<String, Object> row) {
        if (row == null) return null;
        if (row.containsKey("paValor")) return row.get("paValor");
        for (Map.Entry<String, Object> e : row.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase("paValor")) {
                return e.getValue();
            }
        }
        return null;
    }

    /**
     * Cifra un XLSX con contraseña usando Apache POI (modo agile). Sobrescribe
     * el archivo. Requiere poi-ooxml (ya presente por SXSSFWorkbook).
     */
    private void cifrarXlsx(String ruta, String password) throws Exception {
        java.nio.file.Path original = java.nio.file.Paths.get(ruta)
                .toAbsolutePath();
        java.nio.file.Path directorio = original.getParent();
        if (directorio == null || !java.nio.file.Files.isRegularFile(original)) {
            throw new java.io.IOException(
                    "No existe el XLSX de Sabana que se debe cifrar.");
        }

        java.nio.file.Path temporal = java.nio.file.Files.createTempFile(
                directorio, ".sabana-cifrada-", ".xlsx");
        try {
            try (org.apache.poi.poifs.filesystem.POIFSFileSystem fs =
                        new org.apache.poi.poifs.filesystem.POIFSFileSystem()) {
                org.apache.poi.poifs.crypt.EncryptionInfo info =
                        new org.apache.poi.poifs.crypt.EncryptionInfo(
                                org.apache.poi.poifs.crypt.EncryptionMode.standard);
                org.apache.poi.poifs.crypt.Encryptor enc = info.getEncryptor();
                enc.confirmPassword(password);

                // Cerrar el stream cifrador antes de serializar POIFS evita
                // producir archivos parciales de aproximadamente 4 KB.
                try (java.io.InputStream source =
                            java.nio.file.Files.newInputStream(original);
                     org.apache.poi.openxml4j.opc.OPCPackage opc =
                            org.apache.poi.openxml4j.opc.OPCPackage.open(source);
                     java.io.OutputStream encrypted = enc.getDataStream(fs)) {
                    opc.save(encrypted);
                }
                try (java.io.OutputStream out =
                            java.nio.file.Files.newOutputStream(temporal)) {
                    fs.writeFilesystem(out);
                }
            }

            try {
                java.nio.file.Files.move(temporal, original,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException e) {
                java.nio.file.Files.move(temporal, original,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            java.nio.file.Files.deleteIfExists(temporal);
        }
    }

    private void imprimirResultsets(Map<String, Object> callResult) {
        List<Object> values = new ArrayList<>(callResult.values());
        int idx = 1;
        for (Object v : values) {
            if (v instanceof ArrayList) {
                System.out.println("-- Resultset #" + (idx++) + " --");
                @SuppressWarnings("unchecked")
                ArrayList<LinkedCaseInsensitiveMap<?>> rows = (ArrayList<LinkedCaseInsensitiveMap<?>>) v;
                if (rows.isEmpty()) {
                    System.out.println("<sin filas>");
                    continue;
                }
                // encabezados
                LinkedCaseInsensitiveMap<?> first = rows.get(0);
                StringBuilder header = new StringBuilder();
                int c = 0;
                for (Object key : first.keySet()) {
                    if (c++ > 0) header.append('|');
                    header.append(String.valueOf(key));
                }
                System.out.println(header);
                // filas (máx 50)
                int printed = 0;
                for (LinkedCaseInsensitiveMap<?> row : rows) {
                    if (printed++ >= 50) break;
                    StringBuilder line = new StringBuilder();
                    c = 0;
                    for (Object key : first.keySet()) {
                        if (c++ > 0) line.append('|');
                        Object val = row.get(key);
                        line.append(val == null ? "" : String.valueOf(val));
                    }
                    System.out.println(line);
                }
            }
        }
    }

    private List<ArrayList<LinkedCaseInsensitiveMap<?>>> extraerResultsets(Map<String, Object> callResult) {
        List<ArrayList<LinkedCaseInsensitiveMap<?>>> out = new ArrayList<>();
        // Preserve every numbered resultset, even when SQL omits an
        // intermediate group. Stopping at the first gap displaced the
        // Sabana group configuration and could discard later sheets.
        Map<Integer, Object> ordenados = new java.util.TreeMap<>();
        for (Map.Entry<String, Object> entry : callResult.entrySet()) {
            String key = entry.getKey();
            if (key == null || !key.matches("#result-set-\\d+")) continue;
            try {
                int index = Integer.parseInt(
                        key.substring("#result-set-".length()));
                ordenados.put(index, entry.getValue());
            } catch (NumberFormatException ignore) {}
        }
        for (Object value : ordenados.values()) {
            ArrayList<LinkedCaseInsensitiveMap<?>> resultset =
                    copiarResultset(value);
            if (resultset != null) out.add(resultset);
        }

        if (out.isEmpty()) {
            for (Object value : callResult.values()) {
                ArrayList<LinkedCaseInsensitiveMap<?>> resultset =
                        copiarResultset(value);
                if (resultset != null) out.add(resultset);
            }
        }
        return out;
    }

    private ArrayList<LinkedCaseInsensitiveMap<?>> copiarResultset(Object value) {
        if (!(value instanceof List)) return null;
        ArrayList<LinkedCaseInsensitiveMap<?>> resultset = new ArrayList<>();
        for (Object row : (List<?>) value) {
            if (row instanceof LinkedCaseInsensitiveMap) {
                resultset.add((LinkedCaseInsensitiveMap<?>) row);
            }
        }
        return resultset;
    }

    // Eliminado soporte JSON: no se requiere más

    // Construir valores de ejemplo por reporteId. Ajustar en pruebas reales.
    public static Map<String, Object> construirValoresEjemplo(int reporteId) {
        Map<String, Object> m = new LinkedHashMap<>();
        switch (reporteId) {
            case 1: // Documentos personalizados
                m.put("administradorId", 1001);
                m.put("corporativoId", 2001);
                m.put("empresasIds", "45,46");
                m.put("estatusDocumentoIds", "1,2");
                m.put("seccionIds", "10,11");
                m.put("modalidadesIds", "5");
                m.put("estatusEmpleadoIds", "1");
                m.put("administradoresCargaIds", "1001");
                m.put("vigenciasIds", "2025");
                m.put("filtraFecha", 1);
                m.put("fechaInicio", "2025-01-01");
                m.put("fechaFin", "2025-12-31");
                break;
            case 2: // Población / Asegurados
                m.put("fechaIni", "2025-01-01");
                m.put("fechaFin", "2025-12-31");
                m.put("sueldo", 1);
                m.put("parentescos", "1,2,3");
                m.put("estatus", "1,2");
                m.put("admIdEmpresa", 45);
                m.put("admIdPerfil", 7);
                m.put("perfiles", "7,8");
                m.put("empresas", "45,46");
                // Parámetros de aplicación (no del SP) se manejan fuera del orquestador si aplica
                break;
            case 3: // Sábana de beneficios
                m.put("idEmpresa", 45);
                m.put("fechaIni", "2025-01-01");
                m.put("fechaFin", "2025-12-31");
                m.put("idEstatus", 2); // o idStatus
                m.put("idVigencia", 2025);
                break;
            default:
                break;
        }
        return m;
    }

    private Integer resolverIdEstatusParaPoblacion(Map<String, Object> params) {
        if (params == null) return null;
        Object raw = null;
        String[] keys = new String[] { "idSubReporte", "@idSubReporte" };
        for (String k : keys) {
            if (params.containsKey(k)) {
                raw = params.get(k);
                if (raw != null) break;
            }
        }
        // Si no viene estatus, considerar Total (0)
        if (raw == null) return 0;
        if (raw instanceof Number) {
            return ((Number) raw).intValue();
        }
        String s = String.valueOf(raw).trim();
        if (s.isEmpty()) return 0;
        // Si viene lista (p. ej. "1,2") => Total (0). Si trae un solo valor, usarlo.
        if (s.contains(",")) {
            // Si incluye 1 y 2, tratar como total=0; si trae un único dato repetido, tomarlo.
            String[] parts = s.split(",");
            java.util.Set<String> uniq = new java.util.HashSet<>();
            for (String p : parts) {
                String t = p.trim();
                if (!t.isEmpty()) uniq.add(t);
            }
            if (uniq.size() == 1) {
                try { return Integer.parseInt(uniq.iterator().next()); } catch (Exception ignore) { return 0; }
            }
            return 0;
        }
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        }
    }

    private String SeleccionarInvocacion(String tipo, List<ArrayList<LinkedCaseInsensitiveMap<?>>> solo, Map<String, Object> paramsC) throws Exception {
        String rsStr = "";
        switch (tipo) {
            case "Excel_Hoja_Multiple":
                rsStr = Excel_Hoja_Multiple.generar(solo, paramsC, "./out");
                break;
            case "Excel_Columna_Multiple":
                rsStr = Excel_Columna_Multiple.generar(solo, paramsC, "./out");
                break;
            case "Excel_Tablas_Graficos":
                rsStr = Excel_Tablas_Graficos.generar(solo, paramsC, "./out");
            break;
            case "Excel_Filtros":
                rsStr = Excel_Filtros.generar(solo, paramsC, "./out");
            break;
            case "Excel_Encabezado":
            int id = Integer.parseInt( String.valueOf(paramsC.get("reporteId")));
                if (esPdf(paramsC) || id == 2){
                     rsStr = Excel_Encabezados.generar(solo, paramsC, "./out");
                }   else{
                     rsStr = PDF_Filtros.generar(solo, paramsC, "./out");
                } 
            break;
            case "Excel_Encabezado_Hoja_Multiple":
                rsStr = Excel_Multiple.generar(solo, paramsC, "./out");
            break;
            default:
                break;
        }
        LOGGER.info("Archivo generado: " + rsStr );
        return rsStr;
    }

    private boolean esPdf(Map<String,Object>params){
        try{
            Object flag = params.get("tipoArchivo");
            if (flag instanceof Boolean){
                return !((Boolean)flag);
            }
            if (flag != null){
            String v = String.valueOf(flag).trim().toLowerCase();
            if(v.equals("true")) return false;
            if(v.equals("false")) return true;
            }
            return false;
        }catch(Exception e){
            return false;
        }
    }
    
    private boolean sinDatos(List<ArrayList<LinkedCaseInsensitiveMap<?>>> rsList){
        if ( rsList == null || rsList.isEmpty()) return true;
        for (ArrayList<LinkedCaseInsensitiveMap<?>> rs : rsList){
            if(rs != null && !rs.isEmpty()){
                return false;
            }
        }
        return true;
    }

    private String FiltraSubReportePoblacion(String estatus, boolean sueldo) {
        String subReporte = "";
        switch (estatus) {
                case "1":
                    subReporte = "PoblacionTotal";
                    break;
                case "2":
                    subReporte = "PoblacionActiva";
                    break;
                case "3":
                    subReporte = "PoblacionInactiva";
                    break;
                case "4":
                    subReporte = "PoblacionAlta";
                    break;
                case "5":
                    subReporte = "PoblacionBaja";
                    break;
                case "6":
                    subReporte = "PoblacionModificacion";
                    break;
            }
        if(sueldo)
            subReporte += "ConSueldo";
        return subReporte;
    }
}
