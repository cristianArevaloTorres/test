/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lockton.WSBeFlex.DAO;

import com.lockton.WSBeFlex.POJO.Especiales.FfCOpcionesCargaMasiva;
import com.lockton.WSBeFlex.POJO.Especiales.FfLogCargaMasiva;
import java.util.List;
import java.util.Map;

/**
 *
 * @author JHON
 */
public interface FfCargaMasivaDAO {

    public List<FfCOpcionesCargaMasiva> opcionesCargaMasiva(int idEmpresa);
//    opcionesCargaMasiva

    public FfLogCargaMasiva crearTitularM(String atributos, String valores);
    public FfLogCargaMasiva crearDependienteM(String atributos, String valores);
    public FfLogCargaMasiva bajaMasivaT(int idEmpresa, int eMId, String eMObservaciones, int eMUsuarioUMod, int eMIdTitular,
			String numeroEmpleado, String FechaBaja);

    public FfLogCargaMasiva bajaMasivaD(String atributos, String valores);
    
    public FfLogCargaMasiva procesarCargaMasiva(String atributos, String valores);
    
    public Map<String, Object> procesarTransferenciaMasiva(Map<String, Object> parametros, String sp);
}