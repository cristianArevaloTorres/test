# Resultados de validacion

## Comparacion de alcance

- Los 9 reemplazos Angular entregados para QA son identicos a la linea base productiva.
- Los 5 reemplazos Java son identicos a produccion.
- Las 26 rutas de `QA\ELIMINAR.txt` existen en el estado actual de QA y ninguna existe en los repositorios productivos proporcionados.
- Defaulteo queda limitado a 5 reemplazos y 1 eliminacion del frontend de casos especiales.
- Backend de defaulteo, API de reportes, defaulteo general y legacy BF2: 0 archivos reemplazados o eliminados.

## Pruebas

- `GIT\QA.patch`: validado con `git apply --check` contra el estado actual de ambos repositorios QA.
- La compilacion Angular se ejecuto con `NODE_OPTIONS=--openssl-legacy-provider` y `npm run build:prod`.
- Resultado Angular: codigo de salida 0, hash de build `7715752e5c1c4d592f88` y tiempo reportado de 1,437,609 ms.
- Las advertencias fueron de presupuesto CSS y dependencias CommonJS preexistentes; no impidieron generar los bundles ES2015 y ES5.

## Base local

Validacion previa en `(localdb)\MSSQLLocalDB`, base `FlexiForbesv2`:

- El script 01 se ejecuto con `@Aplicar = 0`, retiro la fila durante la simulacion y comprobo su restauracion mediante `ROLLBACK`.
- Los scripts de validacion/configuracion BF2/BF3 no forman parte de esta entrega de reset.

## Limitacion Maven

La construccion Maven local se bloquea antes de JUnit porque la generacion de fuentes requiere el WSDL interno `172.17.0.59:2003`. La compilacion final y las pruebas Java deben ejecutarse en el ambiente con acceso a ese WSDL.

El filtro Deloitte/BF3 y sus pruebas quedaron fuera de este paquete por solicitud expresa; se entregaran posteriormente como un cambio independiente.
