# Scripts de base de datos

Ejecutar siempre en `FlexiForbesv2` del ambiente correspondiente.

1. `01_RESTAURAR_ROUTING_QA_DELOITTE.sql`
   - Exclusivo de la restauracion de QA.
   - Con `@Aplicar = 0` simula y ejecuta `ROLLBACK`.
   - Con `@Aplicar = 1` elimina solamente la fila de Deloitte 186 en `bf_ConfiguracionFlujoCargaMasiva`.
   - No modifica `ff_CargaMasivaOperacionEmpresa`; BF2 y BF3 permanecen activas para SOAP.

Los scripts fuente `database/001_catalogo_y_flujo_carga_masiva.sql` y `database/009_infraestructura_cadena_ws_ford.sql` se retiran del repositorio de QA porque no existen en produccion. Esta entrega no borra tablas o procedimientos ya instalados: quedan inactivos y se evita una eliminacion destructiva de datos o auditoria.

No se incluyen validadores ni scripts de configuracion BF2/BF3 porque esta entrega es exclusivamente de reset.
