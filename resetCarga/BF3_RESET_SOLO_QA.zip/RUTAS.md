# Rutas destino

| Carpeta | Destino |
|---|---|
| `QA\A\*` | Raiz de `BeFlex3-EmpAdm` en QA |
| `QA\W\*` | Raiz de `WSBeFlex-EmpAdm` en QA |

Copiar el contenido de cada carpeta, no la letra contenedora.

Ejemplo:

```text
QA\W\src\main\java\com\lockton\WSBeFlex\REST\WSTitularesAdm.java
```

se copia en:

```text
<raiz-WSBeFlex>\src\main\java\com\lockton\WSBeFlex\REST\WSTitularesAdm.java
```

Despues de copiar, eliminar exclusivamente las rutas de `QA\ELIMINAR.txt`. El manifiesto usa rutas internas cortas para que el ZIP pueda extraerse en Windows.

Este paquete no contiene archivos para produccion ni pruebas del filtro Deloitte/BF3.
