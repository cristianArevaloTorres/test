# Entrega final: reset de QA contra produccion

La comparacion se realizo contra estas lineas base proporcionadas como produccion:

- Frontend Angular: `C:\Users\sanel\Downloads\BeFlex3-EmpAdm-master\BeFlex3-EmpAdm-master`.
- Backend Java: `C:\Users\sanel\Downloads\WSBeFlex-EmpAdm-master\WSBeFlex-EmpAdm-master`.

Extraer el ZIP en una ruta corta, por ejemplo `C:\BF3R`, para evitar el limite de rutas de Windows.

## Resultado

### Carga masiva en QA

Carga masiva regresa literalmente a la linea base productiva. Este paquete no contiene el filtro Deloitte/BF3 ni ninguna funcionalidad nueva.

El reset incluye:

- Cuatro reemplazos Angular: los tres archivos de la pantalla y `titulares.service.ts`.
- Dos eliminaciones Angular del parser TXT agregado.
- Cinco reemplazos Java identicos a produccion.
- Veintitres eliminaciones Java/scripts fuente que no existen en produccion y pertenecen a los flujos agregados de TXT, B2, Ford/CadenaWs, routing y trace.

Los objetos auxiliares ya instalados en la base de QA no se eliminan de forma destructiva. Quedan sin consumidores despues del reset. El script `BD\01_RESTAURAR_ROUTING_QA_DELOITTE.sql` permite retirar solamente la fila de routing de Deloitte con simulacion previa.

### Defaulteo en QA

Se restaura exclusivamente el frontend de **defaulteo de casos especiales**:

- Cinco archivos se reemplazan exactamente desde produccion.
- Se elimina un CSS agregado que no existe en produccion.
- No se toca el defaulteo general.
- No se cambian rutas generales, servicios Angular, backend Java ni API de reportes.

## Instalacion en QA

1. Respaldar fuentes, artefactos y base de datos.
2. Copiar el contenido de `QA\A` sobre la raiz del repositorio Angular.
3. Copiar el contenido de `QA\W` sobre la raiz del repositorio Java.
4. Eliminar solamente los 26 archivos enumerados en `QA\ELIMINAR.txt`.
5. Construir y desplegar Angular y `WSBeFlex.war`.
6. Ejecutar `BD\01_RESTAURAR_ROUTING_QA_DELOITTE.sql` primero con `@Aplicar = 0`. Usar `@Aplicar = 1` solamente despues de revisar la simulacion y solamente en QA.

## Produccion

No se libera nada de este paquete a produccion. Produccion ya contiene el comportamiento que se esta restaurando en QA.

El filtro visual Deloitte/BF3 queda expresamente fuera de esta entrega y se preparara despues como un cambio independiente.

## Evidencia incluida

- `GIT\QA.patch`: diferencia completa del estado actual de QA al resultado final.
- `TEST\RESULTADOS.md`: verificaciones realizadas y limitaciones del ambiente local.
- `MANIFIESTO.csv`: huellas SHA-256 de todos los archivos del paquete.
