# Parches Git

## QA

`QA.patch` representa la restauracion completa desde el estado actual de QA. Incluye los dos repositorios con estos nombres de carpeta:

- `BeFlex3-EmpAdm-defaulteoCargaMaisva`
- `WSBeFlex-EmpAdm-defaulteoCargaMaisva`

Para una instalacion manual son mas claros `QA\A`, `QA\W` y `QA\ELIMINAR.txt`. El parche se entrega como evidencia reproducible de todas las diferencias.

No se incluye parche de produccion porque esta entrega es exclusivamente para restaurar QA. `QA.patch` fue verificado con `git apply --check` antes de crear el ZIP.
