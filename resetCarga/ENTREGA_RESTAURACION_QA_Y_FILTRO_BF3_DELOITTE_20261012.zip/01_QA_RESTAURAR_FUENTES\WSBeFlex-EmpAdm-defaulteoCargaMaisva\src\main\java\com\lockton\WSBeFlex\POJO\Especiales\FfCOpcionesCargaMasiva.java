/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lockton.WSBeFlex.POJO.Especiales;

/**
 *
 * @author JHON
 */
public class FfCOpcionesCargaMasiva {
    public int opcion;
    public String nombre;
    public String sp;
    public int plantilla;

    public FfCOpcionesCargaMasiva() {
        super();
    }

    public FfCOpcionesCargaMasiva(int opcion, String nombre) {
        this.opcion = opcion;
        this.nombre = nombre;
    }

    public int getOpcion() {
        return opcion;
    }

    public void setOpcion(int opcion) {
        this.opcion = opcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSp() {
        return sp;
    }

    public void setSp(String sp) {
        this.sp = sp;
    }

    public int getPlantilla() {
        return plantilla;
    }

    public void setPlantilla(int plantilla) {
        this.plantilla = plantilla;
    }
    
    @Override
    public String toString() {
            try {
                    return new com.fasterxml.jackson.databind.ObjectMapper().writerWithDefaultPrettyPrinter()
                                    .writeValueAsString(this);
            } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
                    e.printStackTrace();
            }
            return null;
    }

    

    
    
}
