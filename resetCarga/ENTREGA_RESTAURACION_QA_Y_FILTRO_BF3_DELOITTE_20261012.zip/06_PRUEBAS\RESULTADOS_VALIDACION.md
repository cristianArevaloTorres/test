# Resultados de validacion

## Casos cubiertos por la prueba unitaria

`JDBCFfCargaMasivaTest.java` cubre seis escenarios:

1. Otras empresas conservan la plantilla BF2.
2. Otras operaciones de Deloitte no se filtran.
3. Deloitte, operacion 2, muestra BF3 (12062).
4. Deloitte, operacion 2, oculta BF2 (507).
5. Una fila de operacion 2 sin plantilla no se expone a la pantalla de Deloitte.
6. Se aceptan tipos numericos JDBC, incluido `BigDecimal`.

## Base de datos local

- Servidor utilizado: `(localdb)\MSSQLLocalDB`.
- Base utilizada: `FlexiForbesv2`.
- Se ejecuto `01_RESTAURAR_ROUTING_QA_DELOITTE.sql` con `@Aplicar = 0`.
- El script detecto una fila de routing para Deloitte, simulo retirar una fila, hizo `ROLLBACK` y la fila permanecio; no hubo cambios permanentes.
- La base local contiene la configuracion BF2 de Deloitte, pero no la configuracion BF3. Por eso la coexistencia completa BF2/BF3 debe validarse en QA con `02_VALIDAR_DELOITTE_BF2_BF3.sql`.

## Compilacion Maven

Se intento ejecutar:

```powershell
.\mvnw.cmd -Dtest=JDBCFfCargaMasivaTest test
```

La compilacion no alcanzo la ejecucion de JUnit porque la fase de generacion de fuentes intenta acceder a un WSDL interno no disponible desde el equipo local (`172.17.0.59:2003`) y termina por timeout. Un intento de compilacion directa tambien encontro que esas clases generadas no existen localmente. Es un bloqueo de dependencias del proyecto y no un error reportado en el filtro agregado.

Antes de liberar `WSBeFlex.war`, el pipeline o equipo con acceso a los WSDL internos debe ejecutar la compilacion completa y esta prueba unitaria.

## Validacion estatica

- El archivo de produccion y el archivo final de QA contienen el mismo filtro minimo.
- El parche de produccion cambia solamente `JDBCFfCargaMasiva.java`.
- `git apply --check` fue satisfactorio para el parche minimo de produccion y para el parche completo de restauracion de QA.
- Se comprobaron 32 archivos de reemplazo (18 Angular, 11 WS Java y 3 legacy BF2).
- Se comprobo que los 28 archivos del manifiesto de eliminacion existen en el estado actual entregado.
- No se modifican contratos REST/SOAP ni la forma de la respuesta.
- El filtro ocurre despues del procedimiento `ff_CCMOperacionesEmpresaAdm` y solamente afecta la lista que consume la pantalla.
