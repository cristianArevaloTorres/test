package com.lockton.WSBeFlex.Services;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

import com.lockton.WSBeFlex.DAO.FfDefaulteoAvanzadoDAO;
import com.lockton.WSBeFlex.POJO.Especiales.FFDefaulteo;
import com.lockton.WSBeFlex.POJO.Especiales.FFEjecutarDefaulteoAvanzado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * CREA 06 - Ejecuta el lote de defaulteo en BACKGROUND (hilo del pool
 * "defaulteoExecutor"). Es un bean aparte para que el proxy de @Async aplique
 * (un @Async invocado desde el mismo bean NO se interceptaria).
 *
 * El flujo por empleado es identico al que vivia dentro de
 * {@link LogicaFfDefaulteoAvanzado#ejecutar}; lo unico que cambia es que ahora
 * corre fuera del request HTTP y va reportando avance al
 * {@link ProgresoDefaulteoRegistry} y los contadores finales a bf_LogDefaulteo.
 */
@Component
public class DefaulteoAvanzadoAsyncRunner {

    @Autowired
    private FfDefaulteoAvanzadoDAO dao;

    @Autowired
    private FfTitularService ffTitularService;

    @Autowired
    private ProgresoDefaulteoRegistry progreso;

    @Async("defaulteoExecutor")
    public void procesarLote(int idLog, FFEjecutarDefaulteoAvanzado req) {
        int totalEmpleados = req.idEmpleado != null ? req.idEmpleado.length : 0;
        int idAdmin        = req.idAdmin != null ? req.idAdmin : 0;
        int exitosos = 0;
        int errores  = 0;

        try {
            for (int i = 0; i < totalEmpleados; i++) {
                int idEmpleado = req.idEmpleado[i];
                String numEmpleado = (req.numEmpleado != null && i < req.numEmpleado.length)
                        ? req.numEmpleado[i] : null;
                progreso.marcarEmpleadoActual(idLog, idEmpleado);

                try {
                    // RF001.1 - Reproceso por cambio de perfil ANTES del defaulteo normal.
                    if (req.idVigencia != null) {
                        try {
                            Map<String, Object> rfc = dao.reprocesarCambioPerfil(
                                    idEmpleado, req.idVigencia, idAdmin, idLog);
                            if (Boolean.TRUE.equals(rfc.get("huboCambio"))) {
                                System.out.println("[CREA06 RF001.1] Cambio de perfil reprocesado para empleado "
                                        + idEmpleado + " (perfilAnterior=" + rfc.get("idPerfilAnterior")
                                        + " -> perfilActual=" + rfc.get("idPerfilActual") + ")");
                            }
                        } catch (Exception rfcEx) {
                            System.out.println("[CREA06 RF001.1] reproceso fallo para empleado "
                                    + idEmpleado + ": " + rfcEx.getMessage());
                        }
                    }

                    FFDefaulteo unico = buildUnicoEmpleado(req, idEmpleado, numEmpleado);
                    ffTitularService.defaultearEmpleadosMasivo(unico);

                    // RF001.2 - Regla Scotiabank antiguedad plan de retiro (opt-in via acciones)
                    if (req.idVigencia != null
                            && req.acciones != null && Boolean.TRUE.equals(req.acciones.aplicarReglaAntiguedad)) {
                        int mesesMin = req.acciones.mesesAntiguedadMinimos != null
                                ? req.acciones.mesesAntiguedadMinimos : 6;
                        try {
                            Map<String, Object> ant = dao.aplicarAntiguedad(
                                    idEmpleado, req.idVigencia, idAdmin, idLog, mesesMin);
                            if (Boolean.TRUE.equals(ant.get("ajusteAplicado"))) {
                                System.out.println("[CREA06 RF001.2] Antiguedad insuficiente para empleado "
                                        + idEmpleado + " (" + ant.get("mesesAntiguedad") + " meses) - "
                                        + ant.get("coberturasRemovidas") + " coberturas de retiro removidas");
                            }
                        } catch (Exception antEx) {
                            System.out.println("[CREA06 RF001.2] aplicarAntiguedad fallo para empleado "
                                    + idEmpleado + ": " + antEx.getMessage());
                        }
                    }

                    exitosos++;
                    progreso.incrementar(idLog, true);
                } catch (Exception ex) {
                    errores++;
                    progreso.incrementar(idLog, false);
                    String msg = ex.getMessage() != null ? ex.getMessage() : ex.getClass().getName();
                    try {
                        dao.registrarEvento(idLog, idEmpleado, numEmpleado, req.idEmpresa,
                                null, "ERROR", truncate(msg, 2000), stackTraceToString(ex), null);
                    } catch (Exception logEx) {
                        System.out.println("[CREA06] No se pudo registrar evento de error: " + logEx.getMessage());
                    }
                    System.out.println("[CREA06] ERROR defaulteo empleado " + idEmpleado + ": " + msg);
                }
            }

            String estadoFinal = errores > 0
                    ? ProgresoDefaulteoRegistry.COMPLETADO_CON_ERRORES
                    : ProgresoDefaulteoRegistry.COMPLETADO;
            dao.finalizarLote(idLog, totalEmpleados, exitosos, errores, estadoFinal);
            progreso.finalizar(idLog, estadoFinal);
        } catch (Exception fatal) {
            // Falla inesperada del lote completo: marcamos ERROR para que el front no quede colgado
            System.out.println("[CREA06] ERROR FATAL en lote " + idLog + ": " + fatal.getMessage());
            try {
                dao.finalizarLote(idLog, totalEmpleados, exitosos, errores, ProgresoDefaulteoRegistry.ERROR);
            } catch (Exception ignore) { /* best effort */ }
            progreso.finalizar(idLog, ProgresoDefaulteoRegistry.ERROR);
        }
    }

    // -------------------------------------------------------------------------
    private FFDefaulteo buildUnicoEmpleado(FFEjecutarDefaulteoAvanzado req, int idEmpleado, String numEmpleado) {
        FFDefaulteo d = req.toFfDefaulteo();
        d.idEmpleado  = new int[]{ idEmpleado };
        d.numEmpleado = new String[]{ numEmpleado };
        d.idEmpresa   = req.idEmpresa != null ? new int[]{ req.idEmpresa } : null;
        return d;
    }

    private String stackTraceToString(Throwable t) {
        try {
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            return sw.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private String truncate(String s, int max) {
        if (s == null) return null;
        return s.length() <= max ? s : s.substring(0, max);
    }
}
