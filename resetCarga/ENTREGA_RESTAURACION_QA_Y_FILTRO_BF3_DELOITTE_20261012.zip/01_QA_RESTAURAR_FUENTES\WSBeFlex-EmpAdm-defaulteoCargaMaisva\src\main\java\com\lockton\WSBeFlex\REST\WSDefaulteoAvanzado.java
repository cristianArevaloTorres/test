package com.lockton.WSBeFlex.REST;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionDefaulteo;
import com.lockton.WSBeFlex.POJO.Especiales.FFEjecutarDefaulteoAvanzado;
import com.lockton.WSBeFlex.POJO.Especiales.FFFiltroDefaulteoAvanzado;
import com.lockton.WSBeFlex.Services.FfDefaulteoAvanzadoService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * CREA 06 - Endpoints REST de defaulteo avanzado.
 *
 * Rutas:
 *   POST   /beflex/defaulteo-avanzado/buscar
 *   POST   /beflex/defaulteo-avanzado/ejecutar
 *   POST   /beflex/defaulteo-avanzado/configuraciones
 *   PUT    /beflex/defaulteo-avanzado/configuraciones
 *   GET    /beflex/defaulteo-avanzado/configuraciones
 *   DELETE /beflex/defaulteo-avanzado/configuraciones/{id}?idAdmin=...
 *   GET    /beflex/defaulteo-avanzado/log-errores/{idLog}/descarga
 */
@RestController
@RequestMapping("beflex/defaulteo-avanzado")
public class WSDefaulteoAvanzado {

    private static final Log bitacora = LogFactory.getLog(WSDefaulteoAvanzado.class);

    @Autowired
    private FfDefaulteoAvanzadoService service;

    // -------------------------------------------------------------------------
    // RN001 / RN010 - Busqueda con 15 filtros
    // -------------------------------------------------------------------------
    @PostMapping("/buscar")
    public ResponseEntity<List<Object>> buscar(@RequestBody FFFiltroDefaulteoAvanzado filtros) {
        try {
            List<Object> data = service.buscarEmpleados(filtros);
            if (data == null || data.isEmpty()) {
                return new ResponseEntity<>(data, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] /buscar: " + e.getMessage(), e);
            System.out.println("[CREA06] /buscar ERROR: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // -------------------------------------------------------------------------
    // RN006 / RN007 / RN008 - Ejecutar defaulteo (lote en BACKGROUND)
    // Responde 202 ACCEPTED con { idLog, estado:"EN_PROCESO", totalEmpleados }.
    // El front consulta el avance con GET /estado/{idLog}.
    // -------------------------------------------------------------------------
    @PostMapping("/ejecutar")
    public ResponseEntity<Map<String, Object>> ejecutar(@RequestBody FFEjecutarDefaulteoAvanzado req,
                                                        HttpServletRequest httpReq) {
        try {
            String ip = obtenerIp(httpReq);
            Map<String, Object> resp = service.ejecutar(req, ip);
            return new ResponseEntity<>(resp, HttpStatus.ACCEPTED);
        } catch (Exception e) {
            bitacora.error("[CREA06] /ejecutar: " + e.getMessage(), e);
            System.out.println("[CREA06] /ejecutar ERROR: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
    }

    // -------------------------------------------------------------------------
    // Estado del lote (polling). Devuelve avance en vivo o el persistido en BD.
    // -------------------------------------------------------------------------
    @GetMapping("/estado/{idLog}")
    public ResponseEntity<Map<String, Object>> estado(@PathVariable int idLog) {
        try {
            Map<String, Object> resp = service.consultarEstado(idLog);
            return new ResponseEntity<>(resp, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] /estado: " + e.getMessage(), e);
            System.out.println("[CREA06] /estado ERROR: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // -------------------------------------------------------------------------
    // RN003 / RN009 - Configuraciones guardadas (CRUD)
    // -------------------------------------------------------------------------
    @PostMapping("/configuraciones")
    public ResponseEntity<Map<String, Object>> crearConfiguracion(@RequestBody FFConfiguracionDefaulteo c) {
        return guardarInterno(c);
    }

    @PutMapping("/configuraciones")
    public ResponseEntity<Map<String, Object>> actualizarConfiguracion(@RequestBody FFConfiguracionDefaulteo c) {
        return guardarInterno(c);
    }

    @GetMapping("/configuraciones")
    public ResponseEntity<List<Object>> listarConfiguraciones(
            @RequestParam(required = false) Integer idCorporativo,
            @RequestParam(required = false) Integer idEmpresa,
            @RequestParam(required = false) Integer idAdmin) {
        try {
            List<Object> data = service.listarConfiguraciones(idCorporativo, idEmpresa, idAdmin);
            if (data == null || data.isEmpty()) {
                return new ResponseEntity<>(data, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] /configuraciones GET: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/configuraciones/{id}")
    public ResponseEntity<Void> eliminarConfiguracion(@PathVariable int id, @RequestParam int idAdmin) {
        try {
            service.eliminarConfiguracion(id, idAdmin);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            bitacora.error("[CREA06] /configuraciones DELETE: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
    }

    // -------------------------------------------------------------------------
    // Catalogo de perfiles activos (el endpoint /perfil/empresa/:id filtra demasiado)
    // -------------------------------------------------------------------------
    @GetMapping("/catalogo/perfiles")
    public ResponseEntity<List<Map<String, Object>>> listarPerfilesEmpresa(@RequestParam int idEmpresa) {
        try {
            List<Map<String, Object>> data = service.listarPerfilesEmpresa(idEmpresa);
            if (data == null || data.isEmpty()) {
                return new ResponseEntity<>(data, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] /catalogo/perfiles: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // -------------------------------------------------------------------------
    // RN007 - Descarga CSV del log de errores
    // -------------------------------------------------------------------------
    @GetMapping("/log-errores/{idLog}/descarga")
    public ResponseEntity<byte[]> descargarLogErrores(@PathVariable int idLog) {
        try {
            List<Map<String, Object>> eventos = service.obtenerEventosDeLote(idLog);
            byte[] csv = toCsv(eventos).getBytes(StandardCharsets.UTF_8);
            return ResponseEntity.ok()
                    .header("Content-Type",        "text/csv; charset=UTF-8")
                    .header("Content-Disposition", "attachment; filename=CREA06_log_errores_" + idLog + ".csv")
                    .body(csv);
        } catch (Exception e) {
            bitacora.error("[CREA06] /log-errores descarga: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private ResponseEntity<Map<String, Object>> guardarInterno(FFConfiguracionDefaulteo c) {
        try {
            Integer id = service.guardarConfiguracion(c);
            Map<String, Object> resp = new java.util.HashMap<>();
            resp.put("id",     id);
            resp.put("exito",  Boolean.TRUE);
            return new ResponseEntity<>(resp, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] guardar configuracion: " + e.getMessage(), e);
            Map<String, Object> resp = new java.util.HashMap<>();
            resp.put("exito",   Boolean.FALSE);
            resp.put("mensaje", e.getMessage());
            return new ResponseEntity<>(resp, HttpStatus.OK);
        }
    }

    private String obtenerIp(HttpServletRequest req) {
        if (req == null) return null;
        String xff = req.getHeader("X-Forwarded-For");
        if (xff != null && !xff.isEmpty()) {
            int comma = xff.indexOf(',');
            return comma < 0 ? xff.trim() : xff.substring(0, comma).trim();
        }
        return req.getRemoteAddr();
    }

    private String toCsv(List<Map<String, Object>> filas) {
        StringBuilder sb = new StringBuilder();
        sb.append("LEDId,LEDIdLog,LEDIdEmpleado,LEDNumeroEmpleado,LEDIdEmpresa,LEDIdPerfil,")
          .append("LEDTipoEvento,LEDMensaje,LEDStackTrace,LEDFechaAdd\n");
        if (filas == null) return sb.toString();
        for (Map<String, Object> r : filas) {
            sb.append(esc(r.get("LEDId"))).append(',')
              .append(esc(r.get("LEDIdLog"))).append(',')
              .append(esc(r.get("LEDIdEmpleado"))).append(',')
              .append(esc(r.get("LEDNumeroEmpleado"))).append(',')
              .append(esc(r.get("LEDIdEmpresa"))).append(',')
              .append(esc(r.get("LEDIdPerfil"))).append(',')
              .append(esc(r.get("LEDTipoEvento"))).append(',')
              .append(esc(r.get("LEDMensaje"))).append(',')
              .append(esc(r.get("LEDStackTrace"))).append(',')
              .append(esc(r.get("LEDFechaAdd"))).append('\n');
        }
        return sb.toString();
    }

    private String esc(Object o) {
        if (o == null) return "";
        String s = o.toString();
        boolean needsQuote = s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0;
        if (!needsQuote) return s;
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }
}
