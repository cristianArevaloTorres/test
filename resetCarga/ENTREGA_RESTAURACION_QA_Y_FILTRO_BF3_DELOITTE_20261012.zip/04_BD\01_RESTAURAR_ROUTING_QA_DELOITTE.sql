/*
  RESTAURA LA CONFIGURACION DE ENRUTAMIENTO DE QA PARA DELOITTE.

  Alcance:
    - Elimina solamente la seleccion B2/B3 agregada para la empresa 186 en
      dbo.bf_ConfiguracionFlujoCargaMasiva.
    - NO elimina la tabla ni sus procedimientos porque pueden ser usados por
      integraciones posteriores y porque pueden contener informacion auditable.
    - NO modifica ff_CargaMasivaOperacionEmpresa: las configuraciones BF2 y
      BF3 de la operacion 2 permanecen activas para el SOAP.

  Seguridad:
    - @Aplicar = 0 simula y termina con ROLLBACK.
    - Cambiar a 1 solamente en QA durante la restauracion.
*/

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET LOCK_TIMEOUT 15000;

DECLARE @Aplicar BIT = 0;
DECLARE @IdEmpresa INT = 186;
DECLARE @IdOperacion INT = 2;

IF DB_NAME() <> 'FlexiForbesv2'
BEGIN
    RAISERROR('Base incorrecta. Debe ejecutarse en FlexiForbesv2.', 16, 1);
    RETURN;
END;

SELECT
    '00_CONTEXTO' AS bloque,
    CONVERT(NVARCHAR(128), SERVERPROPERTY('ServerName')) AS servidor,
    DB_NAME() AS baseDatos,
    @Aplicar AS aplicar,
    @IdEmpresa AS idEmpresa;

SELECT
    '01_CONFIGURACIONES_SOAP_QUE_NO_SE_MODIFICAN' AS bloque,
    CE.CEIdOperacionEmpresa,
    CE.CEIdEmpresa,
    CE.CEIdOperacion,
    CE.CEIdPlantilla,
    LTRIM(RTRIM(CE.CEStoredProc)) AS storedProcedure,
    CE.CEIdEstatus
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
WHERE CE.CEIdEmpresa = @IdEmpresa
  AND CE.CEIdOperacion = @IdOperacion
ORDER BY CE.CEIdEstatus DESC, CE.CEIdPlantilla;

IF OBJECT_ID('dbo.bf_ConfiguracionFlujoCargaMasiva', 'U') IS NULL
BEGIN
    SELECT '02_SIN_CAMBIOS' AS bloque,
           'La tabla de enrutamiento no existe; no hay configuracion que retirar.' AS resultado;
    RETURN;
END;

SELECT
    '02_ROUTING_ANTES' AS bloque,
    C.*
FROM dbo.bf_ConfiguracionFlujoCargaMasiva C
WHERE C.CFIdEmpresa = @IdEmpresa;

BEGIN TRANSACTION;

DELETE FROM dbo.bf_ConfiguracionFlujoCargaMasiva
WHERE CFIdEmpresa = @IdEmpresa;

SELECT
    '03_RESULTADO_SIMULADO' AS bloque,
    @@ROWCOUNT AS filasRetiradas,
    CASE WHEN @Aplicar = 1 THEN 'LISTO_PARA_COMMIT' ELSE 'LISTO_PARA_ROLLBACK' END AS resultado;

IF @Aplicar = 1
BEGIN
    COMMIT TRANSACTION;
    SELECT '04_COMMIT_REALIZADO' AS bloque;
END
ELSE
BEGIN
    ROLLBACK TRANSACTION;
    SELECT '04_ROLLBACK_REALIZADO_SIN_CAMBIOS' AS bloque;
END;

SELECT
    '05_ROUTING_FINAL' AS bloque,
    C.*
FROM dbo.bf_ConfiguracionFlujoCargaMasiva C
WHERE C.CFIdEmpresa = @IdEmpresa;

