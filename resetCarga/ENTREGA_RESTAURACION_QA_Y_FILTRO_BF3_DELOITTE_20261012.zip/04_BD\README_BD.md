# Scripts de base de datos

Ejecutar siempre en `FlexiForbesv2` del ambiente correspondiente.

1. `01_RESTAURAR_ROUTING_QA_DELOITTE.sql`
   - Es exclusivo de la restauracion de QA.
   - Con `@Aplicar = 0` simula y hace `ROLLBACK`.
   - Con `@Aplicar = 1` elimina solamente la fila de Deloitte 186 en `bf_ConfiguracionFlujoCargaMasiva`.
   - No modifica `ff_CargaMasivaOperacionEmpresa` y, por lo tanto, conserva activas BF2 y BF3 para SOAP.

2. `02_VALIDAR_DELOITTE_BF2_BF3.sql`
   - Es de solo lectura.
   - Valida empresa, plantillas, stored procedures, numero de campos y las dos configuraciones activas de la operacion 2.

3. `03_CONFIGURAR_DELOITTE_BF3_SI_FALTA.sql`
   - Es idempotente y su valor inicial es de simulacion.
   - Usarlo solamente si el validador confirma que falta la configuracion BF3.
   - No aplicarlo hasta confirmar que el binario SOAP con selector BF2/BF3 ya se encuentra desplegado.

El filtro de la pantalla incluido para produccion no necesita ejecutar ninguno de estos scripts. Los scripts 01 y 03 contienen controles explicitos para evitar una aplicacion accidental.
