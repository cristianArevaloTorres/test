# Uso de los parches

## Produccion

Desde la raiz del repositorio `WSBeFlex-EmpAdm-defaulteoCargaMaisva`:

```powershell
git apply --check <ruta>\PRODUCCION_FILTRO_BF3_DELOITTE.patch
git apply <ruta>\PRODUCCION_FILTRO_BF3_DELOITTE.patch
```

Este parche cambia un solo archivo: `src/main/java/com/lockton/WSBeFlex/DAO/JDBCFfCargaMasiva.java`.

## QA

`QA_RESTAURACION_COMPLETA_DESDE_ESTADO_ACTUAL.patch` documenta la diferencia completa entre el estado actual de QA y el estado restaurado. Sus rutas comienzan con el nombre de cada solucion, por lo que debe revisarse/aplicarse desde un directorio padre que contenga las soluciones con esos nombres.

Como las soluciones originales fueron entregadas sin metadatos `.git` y pertenecen a repositorios separados, para el despliegue de QA se recomienda usar `01_QA_RESTAURAR_FUENTES` junto con `02_QA_ARCHIVOS_A_ELIMINAR.txt`. El parche completo queda como evidencia revisable del cambio.

Antes de aplicar cualquier parche en un repositorio real:

1. Crear rama de trabajo y respaldo.
2. Ejecutar `git status` y conservar cambios ajenos.
3. Ejecutar `git apply --check`.
4. Revisar el diff antes de confirmar el commit.
