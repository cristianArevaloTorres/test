# Entrega: restauracion de QA y filtro BF3 para Deloitte

Fecha: 12 de octubre de 2026

## Resultado funcional

- Se regresan **carga masiva** y **defaulteo** de QA a su implementacion original.
- No se crean roles, perfiles ni configuraciones del MVP.
- En `ff_CargaMasivaOperacionEmpresa` permanecen activas las dos configuraciones SOAP de Deloitte (empresa 186, operacion 2):
  - BF2: plantilla 507 / `ff_XCMTitularesAltaCMDeloitte`.
  - BF3: plantilla 12062 / `ff_XCMTitularesAltaCMM_BF3`.
- La pantalla normal de carga masiva filtra exclusivamente a Deloitte y, para la operacion 2, devuelve solamente la plantilla BF3 (12062).
- Las demas empresas y las demas operaciones de Deloitte conservan el comportamiento original.
- El filtro se aplica en el endpoint que alimenta la pantalla. No modifica el SOAP, sus contratos, sus parametros ni sus respuestas.

## Contenido

- `01_QA_RESTAURAR_FUENTES`: archivos originales que deben reemplazarse en QA; incluye el unico filtro nuevo en `JDBCFfCargaMasiva.java`.
- `02_QA_ARCHIVOS_A_ELIMINAR.txt`: archivos de las mejoras anteriores que deben retirarse de QA antes de compilar.
- `03_PRODUCCION_SOLO_FILTRO_BF3`: unico archivo fuente que debe integrarse para produccion.
- `04_BD`: restauracion controlada del enrutamiento de QA y validadores de la configuracion SOAP.
- `05_GIT_PATCH`: parches para revision e integracion con Git.
- `06_PRUEBAS`: prueba unitaria del filtro y resultados de validacion.
- `MANIFIESTO_SHA256.csv`: huellas SHA-256 de los archivos entregados.

## Aplicacion en QA

1. Respaldar fuentes, artefactos desplegados y base de datos.
2. Reemplazar los archivos con los de `01_QA_RESTAURAR_FUENTES`, respetando las rutas incluidas.
3. Eliminar solamente los archivos enumerados en `02_QA_ARCHIVOS_A_ELIMINAR.txt`.
4. No retirar `WSCargaMasivaCadenaWs`, `Services/CadenaWs` ni `database/009_infraestructura_cadena_ws_ford.sql`; pertenecen al flujo Ford y quedan fuera de este cambio.
5. Reconstruir y desplegar los componentes afectados por la restauracion:
   - Frontend Angular de administracion.
   - `WSBeFlex.war`.
   - API de reportes, cuando los archivos restaurados formen parte del artefacto de QA.
   - Aplicacion legacy BF2, porque se restauran tres archivos de esa solucion.
6. En `FlexiForbesv2` de QA ejecutar `04_BD/01_RESTAURAR_ROUTING_QA_DELOITTE.sql` primero con `@Aplicar = 0`. Revisar el resultado y repetir con `@Aplicar = 1` para retirar solamente la seleccion de flujo agregada para Deloitte.
7. Ejecutar `04_BD/02_VALIDAR_DELOITTE_BF2_BF3.sql`, que es de solo lectura. Debe confirmar dos configuraciones activas para la empresa 186 y operacion 2.
8. Solamente si falta BF3, revisar `04_BD/03_CONFIGURAR_DELOITTE_BF3_SI_FALTA.sql`. Primero se simula; su aplicacion requiere confirmar que el selector SOAP correspondiente ya esta desplegado.
9. Reciclar los artefactos/servicios y limpiar cache del navegador.
10. Probar:
    - Deloitte: la pantalla muestra y descarga unicamente la plantilla BF3.
    - SOAP Deloitte: siguen disponibles internamente BF2 y BF3.
    - Otra empresa: conserva todas sus operaciones originales.
    - Defaulteo: funciona como antes de las mejoras de QA.

## Liberacion a produccion

Produccion **no necesita la restauracion de QA**, porque las mejoras anteriores no fueron liberadas ahi.

Para produccion se integra solamente:

`03_PRODUCCION_SOLO_FILTRO_BF3/WSBeFlex-EmpAdm-defaulteoCargaMaisva/src/main/java/com/lockton/WSBeFlex/DAO/JDBCFfCargaMasiva.java`

Como alternativa, se puede aplicar `05_GIT_PATCH/PRODUCCION_FILTRO_BF3_DELOITTE.patch` sobre la version original del repositorio `WSBeFlex-EmpAdm-defaulteoCargaMaisva`.

Artefacto a construir y liberar: **`WSBeFlex.war`**.

No se libera a produccion por este ajuste:

- Frontend Angular.
- API de reportes.
- Aplicacion legacy BF2.
- Lista de eliminaciones de QA.
- Restauracion del routing de QA.
- Cambios de roles, perfiles o MVP.

El filtro de pantalla no requiere un cambio de base de datos en produccion. De manera independiente, si tambien se habilitara el SOAP BF2/BF3 en produccion, previamente se deberia validar que existan las dos configuraciones activas y que el binario SOAP con selector haya sido liberado.

## Punto de implementacion

La pantalla llama `POST titulares/op-masiva`. `WSTitularesAdm` delega en `JDBCFfCargaMasiva.opcionesCargaMasiva`, que consulta `ff_CCMOperacionesEmpresaAdm`. El filtro se aplica despues de recibir las filas del procedimiento y antes de construir la respuesta de la pantalla. Por eso no modifica la configuracion que utiliza el SOAP.

## Reversion

- Codigo: restaurar el respaldo previo del artefacto o revertir el parche/commit.
- QA base de datos: si fuera necesario recuperar el routing retirado, restaurar la fila respaldada de `bf_ConfiguracionFlujoCargaMasiva`. El script no elimina tablas ni procedimientos.
- Las filas BF2/BF3 de `ff_CargaMasivaOperacionEmpresa` no son eliminadas por esta entrega.
