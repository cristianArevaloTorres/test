package com.lockton.WSBeFlex.POJO.Especiales;

import java.math.BigDecimal;

/**
 * CREA 06 RN004 - Acciones de defaulteo aplicables a los empleados filtrados.
 * Solo los campos editables del documento (perfil, plan, cobertura, suma asegurada,
 * salario, oficina, area, vigencia, etc). El backend solo aplica los campos no-null.
 */
public class FFAccionDefaulteoAvanzado {

    public Integer idPerfilDestino;
    public Integer idPlanDestino;
    public Integer idCoberturaDestino;
    public Integer idOficinaDestino;
    public Integer idAreaDestino;
    public Integer idVigenciaDestino;
    public Integer idSexoDestino;
    public Integer idParentescoDestino;

    public BigDecimal salarioDestino;
    public BigDecimal sumaAseguradaDestino;

    /** Tipo de asignacion de planes (1, 2, 3...) — alineado con tipoDefaulteo actual */
    public Integer tipoAsignacionPlanes;

    // RF001.2 - Regla Scotiabank antiguedad plan de retiro (opt-in)
    public Boolean aplicarReglaAntiguedad;
    public Integer mesesAntiguedadMinimos; // default 6 si null
}
