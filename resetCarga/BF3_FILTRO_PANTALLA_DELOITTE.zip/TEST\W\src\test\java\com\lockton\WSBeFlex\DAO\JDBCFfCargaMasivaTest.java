package com.lockton.WSBeFlex.DAO;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class JDBCFfCargaMasivaTest {

    @Test
    public void conservaTodasLasOperacionesDeOtrasEmpresas() {
        assertTrue(JDBCFfCargaMasiva.mostrarEnPantallaCargaMasiva(
                496, operacion(2, 507)));
    }

    @Test
    public void conservaOtrasOperacionesDeDeloitte() {
        assertTrue(JDBCFfCargaMasiva.mostrarEnPantallaCargaMasiva(
                186, operacion(3, 507)));
    }

    @Test
    public void muestraLaPlantillaBf3DeDeloitte() {
        assertTrue(JDBCFfCargaMasiva.mostrarEnPantallaCargaMasiva(
                186, operacion(2, 12062)));
    }

    @Test
    public void ocultaLaPlantillaBf2DeDeloitte() {
        assertFalse(JDBCFfCargaMasiva.mostrarEnPantallaCargaMasiva(
                186, operacion(2, 507)));
    }

    @Test
    public void ocultaOperacionDosDeDeloitteSiNoTraePlantilla() {
        Map<String, Object> fila = new HashMap<>();
        fila.put("COIdOperacion", 2);

        assertFalse(JDBCFfCargaMasiva.mostrarEnPantallaCargaMasiva(186, fila));
    }

    @Test
    public void aceptaTiposNumericosDevueltosPorJdbc() {
        Map<String, Object> fila = new HashMap<>();
        fila.put("COIdOperacion", BigDecimal.valueOf(2));
        fila.put("CEIdPlantilla", BigDecimal.valueOf(12062));

        assertTrue(JDBCFfCargaMasiva.mostrarEnPantallaCargaMasiva(186, fila));
    }

    private Map<String, Object> operacion(int idOperacion, int idPlantilla) {
        Map<String, Object> fila = new HashMap<>();
        fila.put("COIdOperacion", idOperacion);
        fila.put("CEIdPlantilla", idPlantilla);
        return fila;
    }
}
