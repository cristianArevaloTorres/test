# Resultados de revision

- El archivo modificado parte exactamente de la version productiva/restaurada de `JDBCFfCargaMasiva.java`.
- La diferencia contiene solamente tres constantes, una llamada de filtrado y el metodo `mostrarEnPantallaCargaMasiva`.
- `GIT\FILTRO_PANTALLA.patch` pasa `git apply --check` contra la linea base productiva.
- La prueba JUnit 4 incluida cubre:
  - otra empresa sin filtro;
  - otra operacion de Deloitte sin filtro;
  - BF3 12062 visible;
  - BF2 507 oculta en la pantalla;
  - plantilla ausente rechazada para Deloitte/operacion 2;
  - valores numericos JDBC representados como `BigDecimal`.
- No se modificaron contratos, controladores REST, frontend Angular, SOAP ni base de datos.
- Maven requiere los WSDL internos configurados en el `pom.xml`; la prueba y construccion final deben ejecutarse en el ambiente con acceso a dichos servicios.
