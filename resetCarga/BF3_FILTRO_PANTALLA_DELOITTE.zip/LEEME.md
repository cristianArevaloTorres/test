# Filtro independiente de plantilla BF3 en la pantalla de carga masiva

Esta entrega contiene solamente el ajuste visual solicitado para Deloitte.

## Comportamiento

- Empresa: Deloitte, `EMIdEmpresa = 186`.
- Operacion de altas: `COIdOperacion = 2`.
- La pantalla de carga masiva muestra solamente la plantilla BF3 `12062`.
- La configuracion BF2 `507` permanece activa en base de datos.
- La configuracion BF3 `12062` permanece activa en base de datos.
- El SOAP puede seguir resolviendo BF2 o BF3; este filtro no modifica su flujo.
- Las demas empresas y las demas operaciones de Deloitte conservan todas sus opciones.
- No cambia contratos REST ni estructuras de respuesta.

## Archivo que se libera

```text
W\src\main\java\com\lockton\WSBeFlex\DAO\JDBCFfCargaMasiva.java
```

Copiarlo sobre la misma ruta del repositorio `WSBeFlex-EmpAdm`, construir y desplegar `WSBeFlex.war`.

## Base de datos

No se ejecuta ningun `INSERT`, `UPDATE` o `DELETE`. Las dos configuraciones de Deloitte deben continuar activas en `ff_CargaMasivaOperacionEmpresa` para la operacion 2.

## Validacion funcional

1. Entrar a la pantalla de carga masiva con Deloitte 186.
2. Confirmar que altas muestra solamente la plantilla 12062.
3. Confirmar que no aparece la plantilla 507 en esa pantalla.
4. Confirmar que otra empresa mantiene sus opciones normales.
5. Probar por separado el SOAP con una cadena BF2 y una BF3 para confirmar que ambas configuraciones continúan disponibles.

`TEST` contiene una prueba unitaria opcional. El proyecto requiere acceso al WSDL interno para completar su construccion Maven en el ambiente formal.
