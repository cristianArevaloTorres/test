# Comandos Git del backend

Ejecutar desde la rama `CargaDefaulteo` del repositorio backend, despues de copiar el archivo de `W`:

```powershell
$RamaActual = (git branch --show-current).Trim()

if ($RamaActual -ne "CargaDefaulteo") {
    throw "Debes estar en CargaDefaulteo. Rama actual: $RamaActual"
}

$Archivo = "src/main/java/com/lockton/WSBeFlex/DAO/JDBCFfCargaMasiva.java"

git add -- $Archivo
git --no-pager diff --cached -- $Archivo
git commit -m "Mostrar solo plantilla BF3 de Deloitte en carga masiva"
git push
```

No usar `git add .` ni modificar archivos de base de datos para este cambio.
