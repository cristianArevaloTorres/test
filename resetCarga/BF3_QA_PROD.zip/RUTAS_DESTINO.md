# Mapeo de rutas

Copiar **el contenido** de cada carpeta corta, no la carpeta con la letra.

| Carpeta del ZIP | Destino |
|---|---|
| `QA\A\*` | Raiz del repositorio `BeFlex3-EmpAdm-defaulteoCargaMaisva` de QA |
| `QA\W\*` | Raiz del repositorio `WSBeFlex-EmpAdm-defaulteoCargaMaisva` de QA |
| `QA\B\*` | Raiz de la solucion `BeflexProduccion-QA` de QA |
| `PROD\W\*` | Raiz del repositorio `WSBeFlex-EmpAdm-defaulteoCargaMaisva` de produccion |
| `TEST\W\*` | Ruta equivalente del repositorio WS, solo cuando se incorporen las pruebas |

Ejemplo:

```text
QA\W\src\main\java\com\lockton\WSBeFlex\DAO\JDBCFfCargaMasiva.java
```

se copia como:

```text
<raiz-WSBeFlex>\src\main\java\com\lockton\WSBeFlex\DAO\JDBCFfCargaMasiva.java
```

Las rutas contenidas en `QA\ELIMINAR.txt` ya son relativas a la raiz indicada por cada encabezado.
