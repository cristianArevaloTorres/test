# Entrega corta para Windows

Este paquete evita el error de ruta larga. Extraer directamente en una ruta corta, por ejemplo:

```text
C:\BF3
```

No extraerlo dentro de una cadena de carpetas como `Descargas\entrega\version\...`.

## Codigos de repositorio

- `A`: frontend Angular `BeFlex3-EmpAdm-defaulteoCargaMaisva`.
- `W`: servicio Java `WSBeFlex-EmpAdm-defaulteoCargaMaisva`.
- `B`: aplicacion legacy `BeflexProduccion-QA`.
- El API de reportes no lleva archivos de reemplazo; sus eliminaciones se encuentran en `QA\ELIMINAR.txt`.

Dentro de cada codigo se conserva la ruta relativa real desde la raiz del repositorio (`src\...`, `Business\...`, etc.). Consultar `RUTAS_DESTINO.md`.

## QA

1. Respaldar fuentes, artefactos y base de datos.
2. Copiar el contenido de `QA\A`, `QA\W` y `QA\B` en las raices correspondientes.
3. Eliminar solamente los archivos de `QA\ELIMINAR.txt`.
4. No eliminar `WSCargaMasivaCadenaWs`, `Services\CadenaWs` ni `database\009_infraestructura_cadena_ws_ford.sql`.
5. Reconstruir y desplegar Angular, `WSBeFlex.war`, el API de reportes afectado por las eliminaciones y la aplicacion legacy BF2.
6. En `FlexiForbesv2` ejecutar `BD\01_RESTAURAR_ROUTING_QA_DELOITTE.sql` primero con `@Aplicar = 0`; revisar y despues usar `@Aplicar = 1` solamente en QA.
7. Ejecutar el validador de solo lectura `BD\02_VALIDAR_DELOITTE_BF2_BF3.sql`.
8. Usar `BD\03_CONFIGURAR_DELOITTE_BF3_SI_FALTA.sql` solamente si el validador confirma que BF3 no existe y ya esta desplegado el selector SOAP.

## Produccion

Produccion no contiene las mejoras anteriores de QA, por lo que no debe recibir la restauracion.

Para produccion se copia solamente el archivo incluido bajo:

```text
PROD\W\src\main\java\com\lockton\WSBeFlex\DAO\JDBCFfCargaMasiva.java
```

Despues se construye y libera unicamente `WSBeFlex.war`.

No se libera Angular, reportes, legacy BF2, eliminaciones de QA ni restauracion de routing. El filtro de pantalla no requiere cambio de base de datos en produccion.

## Comportamiento final

- Deloitte 186, operacion 2: la pantalla muestra solo BF3, plantilla 12062.
- SOAP Deloitte: conserva activas BF2 507 y BF3 12062.
- Otras operaciones de Deloitte y otras empresas: sin cambios.
- Sin cambios en contratos ni respuestas SOAP/REST.

## Validaciones

- Los parches de QA y produccion pasaron `git apply --check`.
- El script de restauracion de routing se simulo localmente con `ROLLBACK` satisfactorio.
- La compilacion Maven local no alcanzo JUnit porque la generacion de fuentes requiere un WSDL interno en `172.17.0.59:2003`. La compilacion final debe ejecutarse en el ambiente con acceso a ese WSDL.
- `MANIFIESTO.csv` permite comprobar todos los archivos del paquete.
