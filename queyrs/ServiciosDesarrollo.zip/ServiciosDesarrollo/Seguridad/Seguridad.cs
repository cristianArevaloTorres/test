﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace ServiciosLocktonTI.Seguridad
{
    public class Seguridad
    {
        public static string Cifra(string cadena)
        {

            byte[] bytes1 = Encoding.ASCII.GetBytes("@1B2c3D4e5F6g7H8");
            byte[] bytes2 = Encoding.ASCII.GetBytes("FLEXIFORBES");
            byte[] bytes3 = Encoding.UTF8.GetBytes(cadena);
            byte[] bytes4 = new PasswordDeriveBytes("FLEXIFORBES", bytes2, "MD5", 2).GetBytes(32);
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            rijndaelManaged.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = rijndaelManaged.CreateEncryptor(bytes4, bytes1);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(bytes3, 0, bytes3.Length);
            cryptoStream.FlushFinalBlock();
            byte[] array = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();

            return Convert.ToBase64String(array);
        }

        public static string Descifra(string cadena)
        {
            string contrasena = string.Empty;
            cadena = HttpUtility.UrlDecode(cadena);

            string passPhrase = "FLEXIFORBES";
            string saltValue = "FLEXIFORBES";
            string hashAlgorithm = "MD5";
            int passwordIterations = 2;
            string initVector = "@1B2c3D4e5F6g7H8";
            int keySize = 256;
            byte[] bytes1 = Encoding.ASCII.GetBytes(initVector);
            byte[] bytes2 = Encoding.ASCII.GetBytes(saltValue);
            byte[] buffer = Convert.FromBase64String(cadena);
            byte[] bytes3 = new PasswordDeriveBytes(passPhrase, bytes2, hashAlgorithm, passwordIterations).GetBytes(keySize / 8);
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            rijndaelManaged.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = rijndaelManaged.CreateDecryptor(bytes3, bytes1);
            MemoryStream memoryStream = new MemoryStream(buffer);
            CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] numArray = buffer;
            int count = cryptoStream.Read(numArray, 0, numArray.Length);
            memoryStream.Close();
            cryptoStream.Close();
            contrasena = Encoding.UTF8.GetString(numArray, 0, count);

            return contrasena;
        }

    }
}