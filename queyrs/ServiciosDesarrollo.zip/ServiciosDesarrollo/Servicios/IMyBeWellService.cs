﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IMyBeWellService" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IMyBeWellService
    {
        [OperationContract]
        string CifrarCadena(string value);

        [OperationContract]
        string DescifrarCadena(string value);
    }
}
