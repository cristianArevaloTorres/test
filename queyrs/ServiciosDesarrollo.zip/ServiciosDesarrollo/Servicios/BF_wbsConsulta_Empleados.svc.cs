﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "BF_wbsConsulta_Empleados" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione BF_wbsConsulta_Empleados.svc o BF_wbsConsulta_Empleados.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class BF_wbsConsulta_Empleados : IBF_wbsConsulta_Empleados
    {
        public DataSet ObtieneConsultaPanel(
           string empresa,
           string usuario,
           string contrasena,
           string NumEmpleado,
           string EmpresaEmpleado)
        {
            return new Administracion.ConsultaEmpleado().Get_ConsultaEmpleados(empresa, usuario, contrasena, NumEmpleado);
        }
    }
}
