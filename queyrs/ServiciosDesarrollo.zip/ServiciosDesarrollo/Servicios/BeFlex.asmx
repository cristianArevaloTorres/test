﻿<%@ WebService Language="C#" CodeBehind="BeFlex.asmx.cs" Class="ServiciosLocktonTI.Servicios.BeFlex" %>
