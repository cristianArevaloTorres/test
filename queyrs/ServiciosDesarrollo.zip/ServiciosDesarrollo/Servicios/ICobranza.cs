﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "ICobranza" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface ICobranza
    {
        [OperationContract]

         DataSet CobranzaTd
       (string idEmpresa, string idTipoSolicitud, string FechaIni, string FechaFin, string idVencida, string pathLog);
    }
}
