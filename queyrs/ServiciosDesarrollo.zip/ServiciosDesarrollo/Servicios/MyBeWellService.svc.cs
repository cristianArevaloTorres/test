﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "MyBeWellService" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione MyBeWellService.svc o MyBeWellService.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class MyBeWellService : IMyBeWellService
    {
        private const string ENCRYPTION_KEY = "wlns2019X";
        private readonly static byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY.Length.ToString());

        public string CifrarCadena(string cadena)
        {            
            return HttpUtility.UrlEncode(Seguridad.Seguridad.Cifra(cadena));
        }

        public string DescifrarCadena(string cadena)
        {
            return Seguridad.Seguridad.Descifra(cadena); 
        }

    }
}
