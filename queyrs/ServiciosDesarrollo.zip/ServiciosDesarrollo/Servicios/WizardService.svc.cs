﻿using ServiciosLocktonTI.Modelo;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    public class WizardService : IWizardService
    {
        public Archivo GetFile(int aIdSistema, string aArchivo)
        {
            Archivo oRespuesta = new Archivo();

            try
            {
                using (FlexiForbesEntities _db = new FlexiForbesEntities())
                {
                    bf_ObtieneRutaSistema_Result oRuta = _db.bf_ObtieneRutaSistema(aIdSistema).FirstOrDefault();

                    if (oRuta != null)
                    {
                        FileInfo archivo = new FileInfo(string.Format("{0}{1}", oRuta.SINombreRuta, aArchivo));
                        if (archivo.Exists && File.ReadAllBytes(archivo.FullName).Length > 0)
                        {
                            oRespuesta = new Archivo()
                            {
                                Estatus = EEstatusArchivo.Correcto,
                                Nombre = archivo.Name,
                                Directorio = archivo.DirectoryName,
                                DirectorioCompleto = string.Format("{0}/{1}", archivo.DirectoryName, archivo.Name),
                                ArregloBytes = File.ReadAllBytes(archivo.FullName),
                                Base64 = string.Format("{0},{1}", Comun.Utilerias.ObtenerTipoArchivo(archivo.Extension), Convert.ToBase64String(File.ReadAllBytes(archivo.FullName))),
                                SoloBase = Comun.Utilerias.ObtenerTipoArchivo(archivo.Extension),
                                Solo64 = Convert.ToBase64String(File.ReadAllBytes(archivo.FullName)),
                                Width = Comun.Utilerias.ObtenerWidthHeightImagen(archivo.FullName, Comun.Utilerias.EWidthHeight.Width),
                                Height = Comun.Utilerias.ObtenerWidthHeightImagen(archivo.FullName, Comun.Utilerias.EWidthHeight.Heigth)
                            };
                        }
                        else
                        {
                            FileInfo dummie = new FileInfo(string.Format(@"{0}Comun\ImagenNoEncontrada.png", System.AppDomain.CurrentDomain.BaseDirectory));
                            oRespuesta = new Archivo()
                            {
                                Estatus = EEstatusArchivo.Incorrecto,
                                Nombre = archivo.Name,
                                Mensaje = "El archivo no se encuentra en el directorio.",
                                Directorio = archivo.DirectoryName,
                                DirectorioCompleto = string.Format("{0}/{1}", archivo.DirectoryName, archivo.Name),
                                ArregloBytes = File.ReadAllBytes(dummie.FullName),
                                Base64 = string.Format("{0},{1}", Comun.Utilerias.ObtenerTipoArchivo(dummie.Extension), Convert.ToBase64String(File.ReadAllBytes(dummie.FullName))),
                                SoloBase = Comun.Utilerias.ObtenerTipoArchivo(archivo.Extension),
                                Solo64 = Convert.ToBase64String(File.ReadAllBytes(archivo.FullName)),
                                Width = Comun.Utilerias.ObtenerWidthHeightImagen(archivo.FullName, Comun.Utilerias.EWidthHeight.Width),
                                Height = Comun.Utilerias.ObtenerWidthHeightImagen(archivo.FullName, Comun.Utilerias.EWidthHeight.Heigth)
                            };
                        }
                    }
                    else
                    {
                        oRespuesta = new Archivo()
                        {
                            Estatus = EEstatusArchivo.Incorrecto,
                            Mensaje = "El IdSistema proporcionado no se encuentra configurado."
                        };
                    }
                }
            }
            catch (Exception aE)
            {
                Comun.Utilerias.EscribirLog(string.Format("Insumos: IdSistema={2}, Archivo:{3}  Mensaje: {0}, StackTrace: {1}", aE.Message, aE.StackTrace, aIdSistema, aArchivo));
                oRespuesta = new Archivo()
                {
                    Estatus = EEstatusArchivo.Incorrecto,
                    Mensaje = "No fue posible ejecutar la acción solicitada"
                };
            }

            return oRespuesta;
        }

        public List<Archivo> GetFiles(int aIdSistema, string aDirectorio)
        {
            List<Archivo> archivos = new List<Archivo>();

            try
            {
                using (FlexiForbesEntities _db = new FlexiForbesEntities())
                {
                    bf_ObtieneRutaSistema_Result oRuta = _db.bf_ObtieneRutaSistema(aIdSistema).FirstOrDefault();

                    if (oRuta != null)
                    {
                        FileInfo directorio = new FileInfo(string.Format("{0}{1}", oRuta.SINombreRuta, aDirectorio));

                        foreach (string rutaArchivo in Directory.GetFiles(directorio.DirectoryName))
                        {
                            FileInfo archivo = new FileInfo(rutaArchivo);
                            if (archivo.Exists && File.ReadAllBytes(archivo.FullName).Length > 0)
                            {
                                archivos.Add(new Archivo()
                                {
                                    Estatus = EEstatusArchivo.Correcto,
                                    Nombre = archivo.Name,
                                    Directorio = archivo.DirectoryName,
                                    DirectorioCompleto = string.Format("{0}/{1}", archivo.DirectoryName, archivo.Name),
                                    ArregloBytes = File.ReadAllBytes(archivo.FullName),
                                    Base64 = string.Format("{0},{1}", Comun.Utilerias.ObtenerTipoArchivo(archivo.Extension), Convert.ToBase64String(File.ReadAllBytes(archivo.FullName))),
                                    SoloBase = Comun.Utilerias.ObtenerTipoArchivo(archivo.Extension),
                                    Solo64 = Convert.ToBase64String(File.ReadAllBytes(archivo.FullName)),
                                    Width = Comun.Utilerias.ObtenerWidthHeightImagen(archivo.FullName, Comun.Utilerias.EWidthHeight.Width),
                                    Height = Comun.Utilerias.ObtenerWidthHeightImagen(archivo.FullName, Comun.Utilerias.EWidthHeight.Heigth)
                                });
                            }
                            else
                            {
                                FileInfo dummie = new FileInfo(string.Format(@"{0}Comun\ImagenNoEncontrada.png", System.AppDomain.CurrentDomain.BaseDirectory));
                                archivos.Add(new Archivo()
                                {
                                    Estatus = EEstatusArchivo.Incorrecto,
                                    Nombre = archivo.Name,
                                    Directorio = archivo.DirectoryName,
                                    DirectorioCompleto = string.Format("{0}/{1}", archivo.DirectoryName, archivo.Name),
                                    Mensaje = "El archivo no se encuentra en el directorio.",
                                    ArregloBytes = File.ReadAllBytes(dummie.FullName),
                                    Base64 = string.Format("{0},{1}", Comun.Utilerias.ObtenerTipoArchivo(dummie.Extension), Convert.ToBase64String(File.ReadAllBytes(dummie.FullName))),
                                    SoloBase = Comun.Utilerias.ObtenerTipoArchivo(archivo.Extension),
                                    Solo64 = Convert.ToBase64String(File.ReadAllBytes(archivo.FullName)),
                                    Width = Comun.Utilerias.ObtenerWidthHeightImagen(archivo.FullName, Comun.Utilerias.EWidthHeight.Width),
                                    Height = Comun.Utilerias.ObtenerWidthHeightImagen(archivo.FullName, Comun.Utilerias.EWidthHeight.Heigth)
                                });
                            }
                        }
                    }
                    else
                    {
                        archivos.Add(new Archivo()
                        {
                            Estatus = EEstatusArchivo.Incorrecto,
                            Mensaje = "El IdSistema proporcionado no se encuentra configurado."
                        });
                    }
                }
            }
            catch (Exception aE)
            {
                Comun.Utilerias.EscribirLog(string.Format("Insumos: IdSistema={2}, Archivo:{3}  Mensaje: {0}, StackTrace: {1}", aE.Message, aE.StackTrace, aIdSistema, aDirectorio));
                archivos = new List<Archivo>();
                archivos.Add(new Archivo()
                {
                    Estatus = EEstatusArchivo.Incorrecto,
                    Mensaje = "No fue posible ejecutar la acción solicitada"
                });
            }

            return archivos;
        }

        public Archivo PutFile(int aIdSistema, string aArchivo, byte[] aArregloBytes)
        {
            Archivo oRespuesta = new Archivo();

            try
            {
                using (FlexiForbesEntities _db = new FlexiForbesEntities())
                {
                    bf_ObtieneRutaSistema_Result oRuta = _db.bf_ObtieneRutaSistema(aIdSistema).FirstOrDefault();

                    if (oRuta != null)
                    {
                        FileInfo archivo = new FileInfo(string.Format("{0}{1}", oRuta.SINombreRuta, aArchivo));
                        if (!archivo.Directory.Exists)
                            Directory.CreateDirectory(archivo.Directory.FullName);
                        else
                            if (!archivo.Exists)
                            File.Delete(archivo.FullName);

                        if (aArregloBytes != null)
                            File.WriteAllBytes(archivo.FullName, aArregloBytes);

                        FileInfo archivoGuardado = new FileInfo(archivo.FullName);
                        if (archivoGuardado.Exists && File.ReadAllBytes(archivoGuardado.FullName).Length > 0)
                        {
                            oRespuesta = new Archivo()
                            {
                                Estatus = EEstatusArchivo.Correcto,
                                Nombre = archivoGuardado.Name,
                                Directorio = archivoGuardado.DirectoryName,
                                DirectorioCompleto = string.Format("{0}{1}", archivoGuardado.DirectoryName, archivoGuardado.Name),
                                ArregloBytes = File.ReadAllBytes(archivoGuardado.FullName),
                                Base64 = string.Format("{0},{1}", Comun.Utilerias.ObtenerTipoArchivo(archivoGuardado.Extension), Convert.ToBase64String(File.ReadAllBytes(archivoGuardado.FullName))),
                                SoloBase = Comun.Utilerias.ObtenerTipoArchivo(archivoGuardado.Extension),
                                Solo64 = Convert.ToBase64String(File.ReadAllBytes(archivoGuardado.FullName)),
                                Width = Comun.Utilerias.ObtenerWidthHeightImagen(archivoGuardado.FullName, Comun.Utilerias.EWidthHeight.Width),
                                Height = Comun.Utilerias.ObtenerWidthHeightImagen(archivoGuardado.FullName, Comun.Utilerias.EWidthHeight.Heigth)
                            };
                        }
                        else
                        {
                            FileInfo dummie = new FileInfo(string.Format(@"{0}Comun\ImagenNoEncontrada.png", System.AppDomain.CurrentDomain.BaseDirectory));
                            oRespuesta = new Archivo()
                            {
                                Estatus = EEstatusArchivo.Incorrecto,
                                Nombre = archivo.Name,
                                Directorio = archivo.DirectoryName,
                                DirectorioCompleto = string.Format("{0}/{1}", archivo.DirectoryName, archivo.Name),
                                Mensaje = "No fue posible almacenar el archivo, intente más tarde.",
                                ArregloBytes = File.ReadAllBytes(dummie.FullName),
                                Base64 = string.Format("{0},{1}", Comun.Utilerias.ObtenerTipoArchivo(dummie.Extension), Convert.ToBase64String(File.ReadAllBytes(dummie.FullName))),
                                SoloBase = Comun.Utilerias.ObtenerTipoArchivo(dummie.Extension),
                                Solo64 = Convert.ToBase64String(File.ReadAllBytes(dummie.FullName)),
                                Width = Comun.Utilerias.ObtenerWidthHeightImagen(dummie.FullName, Comun.Utilerias.EWidthHeight.Width),
                                Height = Comun.Utilerias.ObtenerWidthHeightImagen(dummie.FullName, Comun.Utilerias.EWidthHeight.Heigth)
                            };
                        }
                    }
                    else
                    {
                        oRespuesta = new Archivo()
                        {
                            Estatus = EEstatusArchivo.Incorrecto,
                            Mensaje = "El IdSistema proporcionado no se encuentra configurado."
                        };
                    }
                }
            }
            catch (Exception aE)
            {
                Comun.Utilerias.EscribirLog(string.Format("Insumos: IdSistema={2}, Archivo:{3}  Mensaje: {0}, StackTrace: {1}", aE.Message, aE.StackTrace, aIdSistema, aArchivo));
                oRespuesta = new Archivo()
                {
                    Estatus = EEstatusArchivo.Incorrecto,
                    Mensaje = "No fue posible ejecutar la acción solicitada"
                };
            }

            return oRespuesta;
        }

        public Archivo DeleteFile(int aIdSistema, string aArchivo)
        {
            Archivo oRespuesta;

            try
            {
                using (FlexiForbesEntities _db = new FlexiForbesEntities())
                {
                    bf_ObtieneRutaSistema_Result oRuta = _db.bf_ObtieneRutaSistema(aIdSistema).FirstOrDefault();

                    if (oRuta != null)
                    {
                        FileInfo archivo = new FileInfo(string.Format("{0}{1}", oRuta.SINombreRuta, aArchivo));
                        if (archivo.Exists)
                        {
                            archivo.Delete();
                            oRespuesta = new Archivo()
                            {
                                Estatus = EEstatusArchivo.Correcto,
                                Mensaje = "Archivo eliminado correctamente."
                            };
                        }
                        else
                        {
                            oRespuesta = new Archivo()
                            {
                                Estatus = EEstatusArchivo.Incorrecto,
                                Mensaje = "No fue posible eliminar el archivo porque no existe."
                            };
                        }
                    }
                    else
                    {
                        oRespuesta = new Archivo()
                        {
                            Estatus = EEstatusArchivo.Incorrecto,
                            Mensaje = "El IdSistema proporcionado no se encuentra configurado."
                        };
                    }
                }
            }
            catch (Exception aE)
            {
                Comun.Utilerias.EscribirLog(string.Format("Insumos: IdSistema={2}, Archivo:{3}  Mensaje: {0}, StackTrace: {1}", aE.Message, aE.StackTrace, aIdSistema, aArchivo));
                oRespuesta = new Archivo()
                {
                    Estatus = EEstatusArchivo.Incorrecto,
                    Mensaje = "No fue posible ejecutar la acción solicitada"
                };
            }

            return oRespuesta;
        }
    }
}
