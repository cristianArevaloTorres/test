﻿using ServiciosLocktonTI.Administracion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace ServiciosLocktonTI.Servicios
{
    /// <summary>
    /// Descripción breve de WSDescuentoSMNYL
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WSDescuentoSMNYL : System.Web.Services.WebService
    {

        string pathLogWsDescuentos = string.Format("{0}DocumentoEmpresa\\0\\Log\\pathLogWsDescuentos_{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
        DateTime Hoy = DateTime.Today;
        DayOfWeek day = DateTime.Now.DayOfWeek;




        [WebMethod]
        public Descuentos.EEstatus GeneraArchivoDescuentosSMNYL(int aIdOrigen, string aContraseña, int aIdEmpresa)
        {

            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, aIdEmpresa, Negocio.Encrypt(aContraseña), pathLogWsDescuentos);


            if (dtDatosprovedor.Rows.Count > 0)
            {
                if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                     , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                {
                    if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                    TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                    , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                    {
                        if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                        {
                            if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                      && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                {
                                    Negocio.EscribirArchivo("Inicia método en Web Service...", pathLogWsDescuentos);
                                     Negocio  oDocumento = new  Negocio ();
                                    return oDocumento.WsDescuentos(aIdEmpresa, pathLogWsDescuentos);
                                }
                                else
                                {
                                    BaseDatos.InsertaEstatusWSBitacoraFtp("Origeninvalido", (int)Descuentos.EEstatus.Origeninvalido, "Origeninvalido: ", "Origeninvalido", "Origeninvalido", aIdEmpresa, pathLogWsDescuentos);
                                    return Descuentos.EEstatus.Origeninvalido;
                                }
                            else
                            {
                                BaseDatos.InsertaEstatusWSBitacoraFtp("Diaslaboralesinvalido", (int)Descuentos.EEstatus.Diaslaboralesinvalido, "Diaslaboralesinvalido: ", "Diaslaboralesinvalido", "Diaslaboralesinvalido", aIdEmpresa, pathLogWsDescuentos);
                                return Descuentos.EEstatus.Diaslaboralesinvalido;
                            }
                        }
                        else
                        {
                            if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                  && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                            {
                                Negocio.EscribirArchivo("Inicia método en Web Service...", pathLogWsDescuentos);
                                 Negocio  oDocumento = new  Negocio ();
                                return oDocumento.WsDescuentos(aIdEmpresa, pathLogWsDescuentos);

                            }
                            else
                            {
                                BaseDatos.InsertaEstatusWSBitacoraFtp("Origeninvalido", (int)Descuentos.EEstatus.Origeninvalido, "Origeninvalido: ", "Origeninvalido", "Origeninvalido", aIdEmpresa, pathLogWsDescuentos);
                                return Descuentos.EEstatus.Origeninvalido;
                            }
                        }
                    }
                    else
                    {
                        BaseDatos.InsertaEstatusWSBitacoraFtp("Fueradehorario", (int)Descuentos.EEstatus.Fueradehorario, "Fueradehorario: ", "Fueradehorario", "Fueradehorario", aIdEmpresa, pathLogWsDescuentos);
                        return Descuentos.EEstatus.Fueradehorario;
                    }
                }
                else
                {
                    BaseDatos.InsertaEstatusWSBitacoraFtp("Horarioinvalido", (int)Descuentos.EEstatus.Horarioinvalido, "Horarioinvalido: ", "Horarioinvalido", "Horarioinvalido", aIdEmpresa, pathLogWsDescuentos);
                    return Descuentos.EEstatus.Horarioinvalido;
                }

            }
            else
            {
                BaseDatos.InsertaEstatusWSBitacoraFtp("Configuración de seguridad No coincide", (int)Descuentos.EEstatus.NoDisponible, "NoDisponible: ", "NoDisponible", "NoDisponible", aIdEmpresa, pathLogWsDescuentos);
                return Descuentos.EEstatus.NoDisponible;
            }





        }


    }
}
