﻿using ServiciosLocktonTI.Administracion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace ServiciosLocktonTI.Servicios
{
    /// <summary>
    /// Descripción breve de WSDocumentos
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WSDocumentos : System.Web.Services.WebService
    {



        DateTime Hoy = DateTime.Today;
        DayOfWeek day = DateTime.Now.DayOfWeek;

        [WebMethod]
        public Resultado CargaDocumento(int aIdOrigen, string aContraseña, int aIdEmpresa, Documento aDocumento)
        {
            string pathLog = string.Format(@"{0}Log\{1}\WSDocumentos{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, aIdEmpresa, DateTime.Now.ToString("ddMMyyyy"));

            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, aIdEmpresa, Negocio.Encrypt(aContraseña), pathLog);

            if (dtDatosprovedor.Columns.Count == 0) 
            {
                return new Resultado()
                {
                    Estatus = Documento.EEstatus.NoDisponible,
                    Descripcion = "Servicio no  disponible."
                };
            }
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                    {
                                        Negocio oReporte = new Negocio();
                                        return oReporte.CargaDocumento(aIdOrigen, aIdEmpresa, aDocumento, pathLog);
                                    }
                                    else
                                        return new Resultado()
                                        {
                                            Estatus = Documento.EEstatus.CredencialesNoValidas,
                                            Descripcion = "Origen y/o contraseña inválida"// cambio  de leyanda 
                                        };
                                else
                                    return new Resultado()
                                    {
                                        Estatus = Documento.EEstatus.FueraDeHorario,
                                        Descripcion = "Fuera de horario"
                                    };
                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                {
                                    Negocio oReporte = new Negocio();
                                    return oReporte.CargaDocumento(aIdOrigen, aIdEmpresa, aDocumento, pathLog);
                                }
                                else
                                    return new Resultado()
                                    {
                                        Estatus = Documento.EEstatus.CredencialesNoValidas,
                                        Descripcion = "Origen y/o contraseña inválida"// cambio  de leyanda 
                                    };
                            }
                        }
                        else
                            return new Resultado()
                            {
                                Estatus = Documento.EEstatus.FueraDeHorario,
                                Descripcion = "Fuera de horario"// cambio  de leyanda 
                            };
                    }
                    else
                        return new Resultado()
                        {
                            Estatus = Documento.EEstatus.FueraDeHorario,
                            Descripcion = "Fuera de horario"// cambio  de leyanda 
                        };
                }
                else
                    return new Resultado()
                    {
                        Estatus = Documento.EEstatus.CredencialesNoValidas,
                        Descripcion = "Origen no configurado"
                    };

            }

        }

        [WebMethod]
        public List<Documento> ConsultaDocumento(int aIdOrigen, string aContraseña, int aIdEmpresa, string NumeroEmpleado)
        {
            string pathLogDocumentos = string.Format(@"{0}Log\{1}\WSDocumentos{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, aIdEmpresa, DateTime.Now.ToString("ddMMyyyy"));
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, aIdEmpresa, Negocio.Encrypt(aContraseña), pathLogDocumentos);
         
            Documento respuesta = new Documento();
            
            List<Documento> resplist = new List<Documento>();

            if (dtDatosprovedor.Columns.Count == 0)
            {

                respuesta.Estatus = Documento.EEstatus.NoDisponible;
                respuesta.Descripcion = "Servicio no  disponible.";
                resplist.Add(respuesta);
                return resplist;
            }
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                    {
                                        Negocio oReporte = new Negocio();
                                        return oReporte.ConsultadeDocumento(aIdOrigen, aIdEmpresa, NumeroEmpleado, pathLogDocumentos);
                                    }
                                    else
                                    {

                                        respuesta.Estatus = Documento.EEstatus.CredencialesNoValidas;
                                        respuesta.Descripcion = "Origen y/o contraseña inválida";
                                        resplist.Add(respuesta);
                                        return resplist;

                                    }

                                else
                                {

                                    respuesta.Estatus = Documento.EEstatus.FueraDeHorario;
                                    respuesta.Descripcion = "Fuera de horario";
                                    resplist.Add(respuesta);
                                    return resplist;
                                }

                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                {
                                    Negocio oReporte = new Negocio();
                                    return oReporte.ConsultadeDocumento(aIdOrigen, aIdEmpresa, NumeroEmpleado, pathLogDocumentos);
                                }
                                else
                                {

                                    respuesta.Estatus = Documento.EEstatus.CredencialesNoValidas;
                                    respuesta.Descripcion = "Origen y/o contraseña inválida";
                                    resplist.Add(respuesta);
                                    return resplist;

                                }

                            }
                        }
                        else
                        {

                            respuesta.Estatus = Documento.EEstatus.FueraDeHorario;
                            respuesta.Descripcion = "Fuera de horario";
                            resplist.Add(respuesta);
                            return resplist;
                        }
                    }
                    else
                    {

                        respuesta.Estatus = Documento.EEstatus.FueraDeHorario;
                        respuesta.Descripcion = "Fuera de horario";
                        resplist.Add(respuesta);
                        return resplist;
                    }
                }
                else
                {
                    respuesta.Estatus = Documento.EEstatus.NoDisponible;
                    respuesta.Descripcion = "Origen no configurado";
                    resplist.Add(respuesta);
                    return resplist;

                }
            }


        }

        [WebMethod]
        public Resultado EliminaDocumento(int aIdOrigen, string aContraseña, int aIdEmpresa, Int64 IdDocumento)
        {
            string pathLogDocumentos = string.Format(@"{0}Log\{1}\WSDocumentos{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, aIdEmpresa, DateTime.Now.ToString("ddMMyyyy"));
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, aIdEmpresa, Negocio.Encrypt(aContraseña), pathLogDocumentos);




            if (dtDatosprovedor.Columns.Count == 0)
            {
                return new Resultado()
                {
                    Estatus = Documento.EEstatus.NoDisponible,
                    Descripcion = "Servicio no  disponible."
                };
            }
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                    {
                                        Negocio oReporte = new Negocio();
                                        return oReporte.EliminaDocumento(aIdOrigen, aIdEmpresa, IdDocumento, pathLogDocumentos);
                                    }
                                    else
                                        return new Resultado()
                                        {
                                            Estatus = Documento.EEstatus.CredencialesNoValidas,
                                            Descripcion = "Origen y/o contraseña inválida"// cambio  de leyanda 
                                        };
                                else
                                    return new Resultado()
                                    {
                                        Estatus = Documento.EEstatus.FueraDeHorario,
                                        Descripcion = "Fuera de horario"
                                    };
                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aContraseña))
                                {
                                    Negocio oReporte = new Negocio();
                                    return oReporte.EliminaDocumento(aIdOrigen, aIdEmpresa, IdDocumento, pathLogDocumentos);
                                }
                                else
                                    return new Resultado()
                                    {
                                        Estatus = Documento.EEstatus.CredencialesNoValidas,
                                        Descripcion = "Origen y/o contraseña inválida"// cambio  de leyanda 
                                    };
                            }
                        }
                        else
                            return new Resultado()
                            {
                                Estatus = Documento.EEstatus.FueraDeHorario,
                                Descripcion = "Fuera de horario"// cambio  de leyanda 
                            };
                    }
                    else
                        return new Resultado()
                        {
                            Estatus = Documento.EEstatus.FueraDeHorario,
                            Descripcion = "Fuera de horario"// cambio  de leyanda 
                        };
                }
                else
                    return new Resultado()
                    {
                        Estatus = Documento.EEstatus.NoDisponible,
                        Descripcion = "Origen no configurado"
                    };

            }

        }



    }
}
