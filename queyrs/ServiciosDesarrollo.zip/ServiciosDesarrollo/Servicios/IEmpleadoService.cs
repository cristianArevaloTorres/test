﻿using ServiciosLocktonTI.Administracion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IEmpleadoService" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IEmpleadoService
    {
        [OperationContract]
        Mensaje CargaMasiva(string empresa, string usuario, string contrasena, string cadena);

        [OperationContract]
        Mensaje RegistrarOTs(List<OT> aOTs);
    }
}
