﻿using ServiciosLocktonTI.Administracion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "CryptoBeflex" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione CryptoBeflex.svc o CryptoBeflex.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class CryptoBeflex : ICryptoBeflex
    {
        DateTime Hoy = DateTime.Today;
        DayOfWeek day = DateTime.Now.DayOfWeek;
        public string Code(int IdOrigen, string Password, string Cadena, int IdControl)
        {
            string pathLog = string.Format(@"{0}Log\{1}\Acceso{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, IdControl, DateTime.Now.ToString("ddMMyyyy"));
            string Descripcion = string.Empty;
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(IdOrigen, IdControl, Negocio.Encrypt(Password), pathLog);

            if (dtDatosprovedor.Columns.Count == 0)
                Descripcion = "Servicio no  disponible.";
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == IdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(Password))
                                    {
                                        Administracion.Beflex.Crypto encripta = new Administracion.Beflex.Crypto();
                                        Descripcion = encripta.Encriptar(Cadena);
                                    }
                                    else
                                        Descripcion = "Origen y/o contraseña inválida";// cambio  de leyanda 

                                else
                                    Descripcion = "Fuera de horario";

                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == IdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(Password))
                                {
                                    Administracion.Beflex.Crypto encripta = new Administracion.Beflex.Crypto();
                                    Descripcion = encripta.Encriptar(Cadena);
                                }
                                else
                                    Descripcion = "Origen y/o contraseña inválida";// cambio  de leyanda 

                            }
                        }
                        else
                            Descripcion = "Fuera de horario";// cambio  de leyanda 

                    }
                    else
                        Descripcion = "Fuera de horario";// cambio  de leyanda 

                }
                else
                    Descripcion = "Origen no configurado";


            }






            return Descripcion;
        }



        public string Decipher(int IdOrigen, string Password, string Cadena, int IdControl)
        {
            string pathLog = string.Format(@"{0}Log\{1}\Acceso{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, IdControl, DateTime.Now.ToString("ddMMyyyy"));
            string Descripcion = string.Empty;
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(IdOrigen, IdControl, Negocio.Encrypt(Password), pathLog);

            if (dtDatosprovedor.Columns.Count == 0)
                Descripcion = "Servicio no  disponible.";
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == IdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(Password))
                                    {
                                        Administracion.Beflex.Crypto encripta = new Administracion.Beflex.Crypto();
                                        Descripcion = encripta.Desencriptar(Cadena);
                                    }
                                    else
                                        Descripcion = "Origen y/o contraseña inválida";// cambio  de leyanda 

                                else
                                    Descripcion = "Fuera de horario";

                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == IdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(Password))
                                {
                                    Administracion.Beflex.Crypto encripta = new Administracion.Beflex.Crypto();
                                    Descripcion = encripta.Desencriptar(Cadena);
                                }
                                else
                                    Descripcion = "Origen y/o contraseña inválida";// cambio  de leyanda 

                            }
                        }
                        else
                            Descripcion = "Fuera de horario";// cambio  de leyanda 

                    }
                    else
                        Descripcion = "Fuera de horario";// cambio  de leyanda 

                }
                else
                    Descripcion = "Origen no configurado";


            }






            return Descripcion;
        }



        public List<string> ListCode(int IdOrigen, string Password, List<string> Cadena, int IdControl)
        {
            string pathLog = string.Format(@"{0}Log\{1}\Acceso{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, IdControl, DateTime.Now.ToString("ddMMyyyy"));
            List<string> Descripcion = new List<string>();
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(IdOrigen, IdControl, Negocio.Encrypt(Password), pathLog);

            if (dtDatosprovedor.Columns.Count == 0)
                Descripcion.Add ("Servicio no  disponible.");
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == IdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(Password))
                                    {
                                        Administracion.Beflex.Crypto encripta = new Administracion.Beflex.Crypto();
                                        Descripcion = encripta.ListEncriptar(Cadena);
                                    }
                                    else
                                        Descripcion.Add("Origen y/o contraseña inválida");// cambio  de leyanda 

                                else
                                    Descripcion.Add("Fuera de horario");

                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == IdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(Password))
                                {
                                    Administracion.Beflex.Crypto encripta = new Administracion.Beflex.Crypto();
                                    Descripcion =encripta.ListEncriptar(Cadena);
                                }
                                else
                                    Descripcion.Add("Origen y/o contraseña inválida");// cambio  de leyanda 

                            }
                        }
                        else
                            Descripcion.Add("Fuera de horario");// cambio  de leyanda 

                    }
                    else
                        Descripcion.Add("Fuera de horario");// cambio  de leyanda 

                }
                else
                    Descripcion.Add("Origen no configurado");


            }






            return Descripcion;
        }

        public List<string> ListDecipher(int IdOrigen, string Password, List<string> Cadena, int IdControl)
        {
            string pathLog = string.Format(@"{0}Log\{1}\Acceso{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, IdControl, DateTime.Now.ToString("ddMMyyyy"));
            List<string> Descripcion = new List<string>();
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(IdOrigen, IdControl, Negocio.Encrypt(Password), pathLog);

            if (dtDatosprovedor.Columns.Count == 0)
                Descripcion.Add("Servicio no  disponible.");
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == IdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(Password))
                                    {
                                        Administracion.Beflex.Crypto encripta = new Administracion.Beflex.Crypto();
                                        Descripcion = encripta.ListDesencriptar(Cadena);
                                    }
                                    else
                                        Descripcion.Add("Origen y/o contraseña inválida");// cambio  de leyanda 

                                else
                                    Descripcion.Add("Fuera de horario");

                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == IdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(Password))
                                {
                                    Administracion.Beflex.Crypto encripta = new Administracion.Beflex.Crypto();
                                    Descripcion = encripta.ListDesencriptar(Cadena);
                                }
                                else
                                    Descripcion.Add("Origen y/o contraseña inválida");// cambio  de leyanda 

                            }
                        }
                        else
                            Descripcion.Add("Fuera de horario");// cambio  de leyanda 

                    }
                    else
                        Descripcion.Add("Fuera de horario");// cambio  de leyanda 

                }
                else
                    Descripcion.Add("Origen no configurado");


            }






            return Descripcion;
        }


    }
}
