﻿using ServiciosLocktonTI.Administracion.Beflex;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace ServiciosLocktonTI.Servicios
{
    /// <summary>
    /// Descripción breve de BeFlex
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class BeFlex : System.Web.Services.WebService
    {
        [WebMethod]
        public DataSet Login(string strEmpleado, string strContrasena)
        {
           return Administracion.Beflex.BeflexService.LoginService(strEmpleado, strContrasena);
        }

        [WebMethod]
        public DateTime ActualizacionEmpleado(string numeroEmpleado)
        {
            return Administracion.Beflex.BeflexService.ActualizacionEmpleadoService(numeroEmpleado);
        }
    }
}
