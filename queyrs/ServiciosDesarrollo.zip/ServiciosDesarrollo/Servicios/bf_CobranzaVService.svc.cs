﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "bf_CobranzaVService" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione bf_CobranzaVService.svc o bf_CobranzaVService.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class bf_CobranzaVService : Ibf_CobranzaVService
    {
        public DataSet CobranzaTd(string idEmpresa, string idTipoSolicitud, string FechaIni, string FechaFin, string idVencida, string pathLog)
        {
            return new Administracion.BaseDatos()._Cobranza(idEmpresa.ToString(), idTipoSolicitud.ToString()
                        , FechaIni.ToString(), FechaFin.ToString(), idVencida.ToString(), pathLog);
        }
    }
}
