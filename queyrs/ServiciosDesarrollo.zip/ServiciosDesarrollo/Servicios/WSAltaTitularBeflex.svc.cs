﻿using ServiciosLocktonTI.Administracion.AltaTitular_DAL;
using ServiciosLocktonTI.Modelo.AltaEmpleadoBeflex;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "WSAltaTitularBeflex" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione WSAltaTitularBeflex.svc o WSAltaTitularBeflex.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class WSAltaTitularBeflex : IWSAltaTitularBeflex
    {
        public RespuestaBeflex AltaTitularBeflex(ff_Empleado empleado, int IdCorporativo, int IdEmpresa)
        {
            return AltaTitularDAL.AltaTitularBeflex(empleado, IdCorporativo, IdEmpresa);
        }
    }
}
