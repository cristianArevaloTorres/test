﻿<%@ WebService Language="C#" CodeBehind="WSDocumentos.asmx.cs" Class="ServiciosLocktonTI.Servicios.WSDocumentos" %>
