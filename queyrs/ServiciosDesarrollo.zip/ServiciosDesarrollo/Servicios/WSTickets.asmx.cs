﻿using ServiciosLocktonTI.Administracion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace ServiciosLocktonTI.Servicios
{
    /// <summary>
    /// Descripción breve de WSTickets
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WSTickets : System.Web.Services.WebService
    {

      //  string pathLogDocumentos = 

        DateTime Hoy = DateTime.Today;
        DayOfWeek day = DateTime.Now.DayOfWeek;

        [WebMethod]
        public List<Ticket> ObtenerTicketsBeflex(int aIdOrigen, string aPassword, List<int> aIdsTicket, int aIdEmpresa, bool aDocumento)
        {

            List<Ticket> resplist = new List<Ticket>();
            Ticket respuesta = new Ticket();
            string pathLog = string.Format("{0}DocumentoEmpresa\\0\\Log\\WSTicketsObtenerTicketsBeflex{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, aIdEmpresa, Negocio.Encrypt(aPassword), pathLog);
            if (dtDatosprovedor.Columns.Count == 0)
            {
                respuesta.TTEstatus = Ticket.TTEEstatus.NoDisponible;
                respuesta.TTDescripcion = "Servicio no  disponible.";
                resplist.Add(respuesta);
                return resplist;

            }
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aPassword))
                                    {
                                        Negocio oTicket = new Negocio();
                                        return oTicket.ObtenerTicketsBeflex(aIdsTicket, aIdEmpresa, aDocumento, pathLog);
                                    }
                                    else
                                    {
                                        respuesta.TTEstatus = Ticket.TTEEstatus.CredencialesNoValidas;
                                        respuesta.TTDescripcion = "Origen y/o contraseña inválida";
                                        resplist.Add(respuesta);
                                        return resplist;
                                    }
                                else
                                {
                                    respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                                    respuesta.TTDescripcion = "Fuera de horario";
                                    resplist.Add(respuesta);
                                    return resplist;
                                }
                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aPassword))
                                {
                                    Negocio oTicket = new Negocio();
                                    return oTicket.ObtenerTicketsBeflex(aIdsTicket, aIdEmpresa, aDocumento, pathLog);
                                }
                                else
                                {
                                    respuesta.TTEstatus = Ticket.TTEEstatus.CredencialesNoValidas;
                                    respuesta.TTDescripcion = "Origen y/o contraseña inválida";
                                    resplist.Add(respuesta);
                                    return resplist;
                                }
                            }
                        }
                        else
                        {
                            respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                            respuesta.TTDescripcion = "Fuera de horario";
                            resplist.Add(respuesta);
                            return resplist;
                        }
                    }
                    else
                    {
                        respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                        respuesta.TTDescripcion = "Fuera de horario";
                        resplist.Add(respuesta);
                        return resplist;
                    }
                }
                else
                {
                    respuesta.TTEstatus = Ticket.TTEEstatus.NoDisponible;
                    respuesta.TTDescripcion = "Origen no configurado";
                    resplist.Add(respuesta);
                    return resplist;

                }

            }

        }
        //public List<Ticket> ObtenerTicketsBeflex(List<int> aIdsTicket, int aIdEmpresa, bool aDocumento)
        //{
        //    Negocio oTicket = new Negocio();
        //    return oTicket.ObtenerTicketsBeflex(aIdsTicket, aIdEmpresa, aDocumento, pathLogDocumentos);
        //}

        [WebMethod]

        public List<Ticket> ObtenerTicketsBeflexFechaInicioFechaFin(int aIdOrigen, string aPassword, int IdEmpresa, DateTime FechaInicio, DateTime FechaFinal, bool aDocumento)
        {
            List<Ticket> resplist = new List<Ticket>();
            Ticket respuesta = new Ticket();
            string pathLog = string.Format("{0}DocumentoEmpresa\\0\\Log\\WSTicketsObtenerTicketsBeflexFechaInicioFechaFin{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, IdEmpresa, Negocio.Encrypt(aPassword), pathLog);
            if (dtDatosprovedor.Columns.Count == 0)
            {
                respuesta.TTEstatus = Ticket.TTEEstatus.NoDisponible;
                respuesta.TTDescripcion = "Servicio no  disponible.";
                resplist.Add(respuesta);
                return resplist;

            }
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aPassword))
                                    {
                                        Negocio oTicket = new Negocio();
                                        return oTicket.ObtenerTicketsBeflex(IdEmpresa, FechaInicio, FechaFinal, aDocumento, pathLog);
                                    }
                                    else
                                    {
                                        respuesta.TTEstatus = Ticket.TTEEstatus.CredencialesNoValidas;
                                        respuesta.TTDescripcion = "Origen y/o contraseña inválida";
                                        resplist.Add(respuesta);
                                        return resplist;
                                    }
                                else
                                {
                                    respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                                    respuesta.TTDescripcion = "Fuera de horario";
                                    resplist.Add(respuesta);
                                    return resplist;
                                }
                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aPassword))
                                {
                                    Negocio oTicket = new Negocio();
                                    return oTicket.ObtenerTicketsBeflex(IdEmpresa, FechaInicio, FechaFinal, aDocumento, pathLog);
                                }
                                else
                                {
                                    respuesta.TTEstatus = Ticket.TTEEstatus.CredencialesNoValidas;
                                    respuesta.TTDescripcion = "Origen y/o contraseña inválida";
                                    resplist.Add(respuesta);
                                    return resplist;
                                }
                            }
                        }
                        else
                        {
                            respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                            respuesta.TTDescripcion = "Fuera de horario";
                            resplist.Add(respuesta);
                            return resplist;
                        }
                    }
                    else
                    {
                        respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                        respuesta.TTDescripcion = "Fuera de horario";
                        resplist.Add(respuesta);
                        return resplist;
                    }
                }
                else
                {
                    respuesta.TTEstatus = Ticket.TTEEstatus.NoDisponible;
                    respuesta.TTDescripcion = "Origen no configurado";
                    resplist.Add(respuesta);
                    return resplist;

                }

            }
        }

        //public List<Ticket> ObtenerTicketsBeflexFechaInicioFechaFin(int IdEmpresa, DateTime FechaInicio, DateTime FechaFinal, bool aDocumento)
        //{
        //    Negocio oTicket = new Negocio();
        //    return oTicket.ObtenerTicketsBeflex(IdEmpresa, FechaInicio, FechaFinal, aDocumento, pathLogDocumentos);
        //}

        [WebMethod]

        public List<Ticket> ObtenerTicketsBeflexFechaInicioFechaFinCorporativo(int aIdOrigen, string aPassword, int IdEmpresa, DateTime FechaInicio, DateTime FechaFinal, bool aDocumento)
        {

            List<Ticket> resplist = new List<Ticket>();
            Ticket respuesta = new Ticket();
            string pathLog = string.Format("{0}DocumentoEmpresa\\0\\Log\\WSTicketsObtenerTicketsBeflexFechaInicioFechaFinCorporativo{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            DataTable dtDatosprovedor = BaseDatos.ValidaEntradaWSdocumentos(aIdOrigen, IdEmpresa, Negocio.Encrypt(aPassword), pathLog);
            if (dtDatosprovedor.Columns.Count == 0)
            {
                respuesta.TTEstatus = Ticket.TTEEstatus.NoDisponible;
                respuesta.Descripcion = "Servicio no  disponible.";
                resplist.Add(respuesta);
                return resplist;

            }
            else
            {
                if (dtDatosprovedor.Rows.Count > 0)
                {
                    if (Negocio.ValidarRangoFecha(DateTime.Parse(Hoy.ToString("yyyy-MM-dd"))/// Validacion de dias 
                    , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaInicio"].ToString())
                        , DateTime.Parse(dtDatosprovedor.Rows[0]["PPPFechaFinal"].ToString())) == true)
                    {
                        if (Negocio.ValidaRangoTiempo(DateTime.Now,// validacion  de horas 
                        TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraInicio"].ToString())
                        , TimeSpan.Parse(dtDatosprovedor.Rows[0]["PPPHoraFin"].ToString())) == true)
                        {
                            if ((day == DayOfWeek.Saturday) || (day == DayOfWeek.Sunday))/// valiadacion   si es  sabado  o domingo 
                            {
                                if (bool.Parse(dtDatosprovedor.Rows[0]["PPPSemanaLaboral"].ToString()) == false)
                                    if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                     && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aPassword))
                                    {
                                        Negocio oTicket = new Negocio();
                                        return oTicket.ObtenerTicketsBeflexporCorporativo(IdEmpresa, FechaInicio, FechaFinal, aDocumento, pathLog);

                                    }
                                    else
                                    {
                                        respuesta.TTEstatus = Ticket.TTEEstatus.CredencialesNoValidas;
                                        respuesta.TTDescripcion = "Origen y/o contraseña inválida";
                                        resplist.Add(respuesta);
                                        return resplist;
                                    }
                                else
                                {
                                    respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                                    respuesta.TTDescripcion = "Fuera de horario";
                                    resplist.Add(respuesta);
                                    return resplist;
                                }
                            }
                            else
                            {
                                if (int.Parse(dtDatosprovedor.Rows[0]["PPPIdProvedor"].ToString()) == aIdOrigen /// provedor ,contraseña  y idEmpresa 
                                 && dtDatosprovedor.Rows[0]["PRContraseña"].ToString() == Negocio.Encrypt(aPassword))
                                {
                                    Negocio oTicket = new Negocio();
                                    return oTicket.ObtenerTicketsBeflexporCorporativo(IdEmpresa, FechaInicio, FechaFinal, aDocumento, pathLog);
                                }
                                else
                                {
                                    respuesta.TTEstatus = Ticket.TTEEstatus.CredencialesNoValidas;
                                    respuesta.TTDescripcion = "Origen y/o contraseña inválida";
                                    resplist.Add(respuesta);
                                    return resplist;
                                }
                            }
                        }
                        else
                        {
                            respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                            respuesta.TTDescripcion = "Fuera de horario";
                            resplist.Add(respuesta);
                            return resplist;
                        }
                    }
                    else
                    {
                        respuesta.TTEstatus = Ticket.TTEEstatus.FueraDeHorario;
                        respuesta.TTDescripcion = "Fuera de horario";
                        resplist.Add(respuesta);
                        return resplist;
                    }
                }
                else
                {
                    respuesta.TTEstatus = Ticket.TTEEstatus.NoDisponible;
                    respuesta.TTDescripcion = "Origen no configurado";
                    resplist.Add(respuesta);
                    return resplist;

                }

            }

        }
        //public List<Ticket> ObtenerTicketsBeflexFechaInicioFechaFinCorporativo(int IdEmpresa, DateTime FechaInicio, DateTime FechaFinal, bool aDocumento)
        //{
        //    Negocio oTicket = new Negocio();
        //    return oTicket.ObtenerTicketsBeflexporCorporativo(IdEmpresa, FechaInicio, FechaFinal, aDocumento, pathLogDocumentos);
        //}

    }
}
