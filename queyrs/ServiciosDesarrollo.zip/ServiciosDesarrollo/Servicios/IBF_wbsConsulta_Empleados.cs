﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IBF_wbsConsulta_Empleados" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IBF_wbsConsulta_Empleados
    {
        [OperationContract]
        DataSet ObtieneConsultaPanel(
     string empresa,
     string usuario,
     string contrasena,
     string NumEmpleado,
     string EmpresaEmpleado);
    }
}
