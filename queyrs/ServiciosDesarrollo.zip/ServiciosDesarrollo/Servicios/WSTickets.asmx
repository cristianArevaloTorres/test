﻿<%@ WebService Language="C#" CodeBehind="WSTickets.asmx.cs" Class="ServiciosLocktonTI.Servicios.WSTickets" %>
