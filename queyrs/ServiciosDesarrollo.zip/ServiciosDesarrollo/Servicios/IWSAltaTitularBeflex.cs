﻿using ServiciosLocktonTI.Modelo.AltaEmpleadoBeflex;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IWSAltaTitularBeflex" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IWSAltaTitularBeflex
    {
        [OperationContract]
        RespuestaBeflex AltaTitularBeflex(ff_Empleado empleado, int IdCorporativo, int IdEmpresa);
    }
}
