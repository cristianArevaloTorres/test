﻿using ServiciosLocktonTI.Administracion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web.Hosting;


namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "BF_wbsABC_Empleados" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione BF_wbsABC_Empleados.svc o BF_wbsABC_Empleados.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class BF_wbsABC_Empleados : IBF_wbsABC_Empleados
    {
        public int GuardaDatos(string empresa, string usuario, string contrasena, string cadena)
        {
            CargaMasivaProcess cargaMasivaProcess = new CargaMasivaProcess(HostingEnvironment.ApplicationPhysicalPath, false, "");
            cargaMasivaProcess.RegistrarEntradaRapida("Empresa:" + empresa + ":Usuario:" + usuario + ":Contraseña:" + contrasena + ":Cadena:" + cadena, 0);
            try
            {
                cadena = this.Conversion(cadena);
                return cargaMasivaProcess.CargaRapida(empresa, cadena, usuario, contrasena);
            }
            finally
            {
                cargaMasivaProcess.Dispose();
            }
        }

        private string Conversion(string ConversionCadena)
        {
            ConversionCadena = ConversionCadena.Replace("[160]", "á");
            ConversionCadena = ConversionCadena.Replace("[130]", "é");
            ConversionCadena = ConversionCadena.Replace("[161]", "í");
            ConversionCadena = ConversionCadena.Replace("[162]", "ó");
            ConversionCadena = ConversionCadena.Replace("[163]", "ú");
            ConversionCadena = ConversionCadena.Replace("[143]", "Á");
            ConversionCadena = ConversionCadena.Replace("[144]", "É");
            ConversionCadena = ConversionCadena.Replace("[141]", "Í");
            ConversionCadena = ConversionCadena.Replace("[149]", "Ó");
            ConversionCadena = ConversionCadena.Replace("[151]", "Ú");
            ConversionCadena = ConversionCadena.Replace("[132]", "ä");
            ConversionCadena = ConversionCadena.Replace("[137]", "ë");
            ConversionCadena = ConversionCadena.Replace("[139]", "ï");
            ConversionCadena = ConversionCadena.Replace("[148]", "ö");
            ConversionCadena = ConversionCadena.Replace("[129]", "ü");
            ConversionCadena = ConversionCadena.Replace("[142]", "Ä");
            ConversionCadena = ConversionCadena.Replace("[138]", "Ë");
            ConversionCadena = ConversionCadena.Replace("[140]", "Ï");
            ConversionCadena = ConversionCadena.Replace("[153]", "Ö");
            ConversionCadena = ConversionCadena.Replace("[154]", "Ü");
            ConversionCadena = ConversionCadena.Replace("[164]", "ñ");
            ConversionCadena = ConversionCadena.Replace("[165]", "Ñ");
            ConversionCadena = ConversionCadena.Replace("|*|", "|");
            ConversionCadena = ConversionCadena.Replace("'", "");
            return ConversionCadena;
        }
    }
}
