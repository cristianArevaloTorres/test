﻿using ServiciosLocktonTI.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    [ServiceContract]
    public interface IWizardService
    {
        [OperationContract]
        Archivo GetFile(int aIdSistema, string aArchivo);

        [OperationContract]
        Archivo PutFile(int aIdSistema, string aArchivo, byte[] aArregloBytes);

        [OperationContract]
        List<Archivo> GetFiles(int aIdSistema, string aDirectorio);

        [OperationContract]
        Archivo DeleteFile(int aIdSistema, string aArchivo);
    }
}
