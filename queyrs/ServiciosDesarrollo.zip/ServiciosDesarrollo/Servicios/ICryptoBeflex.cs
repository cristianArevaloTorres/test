﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiciosLocktonTI.Servicios
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "ICryptoBeflex" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface ICryptoBeflex
    {
        [OperationContract]
        string Code(int IdOrigen, string Password, string Cadena, int IdControl);

        [OperationContract]
        string Decipher(int IdOrigen, string Password, string Cadena, int IdControl);

        [OperationContract]
        List<string> ListCode(int IdOrigen, string Password, List<string> Cadena, int IdControl);
        [OperationContract]
        List<string> ListDecipher(int IdOrigen, string Password, List<string> Cadena, int IdControl);
    }
}
