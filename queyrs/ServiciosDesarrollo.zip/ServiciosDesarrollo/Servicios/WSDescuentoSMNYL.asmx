﻿<%@ WebService Language="C#" CodeBehind="WSDescuentoSMNYL.asmx.cs" Class="ServiciosLocktonTI.Servicios.WSDescuentoSMNYL" %>
