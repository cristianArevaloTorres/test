﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Modelo.AltaEmpleadoBeflex
{
    public class ff_Empleado
    {
        public int EMId { get; set; }
        public int EMIdEmpresa { get; set; }
        public int EMIdPerfil { get; set; }
        public int EMIdParentesco { get; set; }
        public int EMIdTitular { get; set; }
        public string EMCertificado { get; set; }
        public string EMContraseña { get; set; }
        public string EMClaveAcceso { get; set; }
        public int EMIdRol { get; set; }
        public int EMIdUsuarioAdd { get; set; }
        public string EMFechaIngresoEmpresa { get; set; }
        public int EMEdad { get; set; }
        public string EMNumeroEmpleado { get; set; }

        public string EMApellidoPaterno { get; set; } //Obligatorio
        public string EMApellidoMaterno { get; set; } 
        public string EMNombre1 { get; set; } //Obligatorio
        public string EMNombre2 { get; set; }
        public string EMFechaNacimiento { get; set; } //Obligatorio
        public string EMRFC { get; set; }
        public string EMCorreoElectronico { get; set; } 
        public int EMIdSexo { get; set; } //Obligatorio
    }
}