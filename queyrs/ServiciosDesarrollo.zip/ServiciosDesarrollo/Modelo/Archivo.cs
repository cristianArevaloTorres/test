﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Modelo
{
    public enum EEstatusArchivo
    {
        NoEspecificado,
        Correcto,
        Incorrecto
    }

    public class Archivo
    {
        private EEstatusArchivo estatus;
        public EEstatusArchivo Estatus
        {
            get { return estatus; }
            set { estatus = value; }
        }
        private string directorio;
        public string Directorio
        {
            get { return directorio; }
            set { directorio = value; }
        }

        private string directorioCompleto;
        public string DirectorioCompleto
        {
            get { return directorioCompleto; }
            set { directorioCompleto = value; }
        }

        private string nombre;
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        private string base64;
        public string Base64
        {
            get { return base64; }
            set { base64 = value; }
        }

        private string soloBase;
        public string SoloBase
        {
            get { return soloBase; }
            set { soloBase = value; }
        }

        private string solo64;
        public string Solo64
        {
            get { return solo64; }
            set { solo64 = value; }
        }

        private byte[] arregloBytes;
        public byte[] ArregloBytes
        {
            get { return arregloBytes; }
            set { arregloBytes = value; }
        }

        private string mensaje;
        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value; }
        }

        private int width;
        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        private int height;
        public int Height
        {
            get { return height; }
            set { height = value; }
        }
    }
}