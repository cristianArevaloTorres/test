﻿using ServiciosLocktonTI.Administracion;
using ServiciosLocktonTI.Administracion.Beflex;
using ServiciosLocktonTI.Administracion.BeflexV3;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace ServiciosLocktonTI.Comun
{
    public class Utilerias
    {
        public enum EWidthHeight
        {
            NoEspecificado,
            Width,
            Heigth
        }
        public static void EscribirLog(string aContenido, bool aEnviarCorreo = true)
        {
            string ruta = string.Format("{0}Log_{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            FileInfo archivo = new FileInfo(ruta);
            StreamWriter documento;

            if (!archivo.Exists)
            {
                Directory.CreateDirectory(archivo.Directory.FullName);
                documento = new StreamWriter(archivo.FullName, false, System.Text.Encoding.UTF8);
            }
            else
                documento = archivo.AppendText();

            documento.WriteLine(string.Format("{0} ({1})", aContenido, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
            documento.Flush();
            documento.Close();

            if (aEnviarCorreo)
                Comun.Utilerias.EnviarCorreo("Error en servicios web Lockton", aContenido, new List<string>() { "jjhernandez@mx.lockton.com", "consultorti7@mx.lockton.com" }, new List<string>());
        }

        public static void EnviarCorreo(string aAsunto, string aDescripcion, List<string> aDestinatarios, List<string> aArchivosAdjuntos)
        {
            Crypto Crypto_ = new Crypto();
 
            try
            {

                string smtpClientHost = Crypto_.Desencriptar(ConfigurationManager.AppSettings["HostCorreo"].ToString());
                string smtpClienUser = Crypto_.Desencriptar(ConfigurationManager.AppSettings["smtpClientUser"].ToString());
                string smtpClienPass = Crypto_.Desencriptar(ConfigurationManager.AppSettings["smtpClientPass"].ToString());

                //string smtpClientHost = ConfigurationManager.AppSettings["HostCorreo"].ToString();
                //string smtpClienUser = ConfigurationManager.AppSettings["smtpClientUser"].ToString();
                //string smtpClienPass = ConfigurationManager.AppSettings["smtpClientPass"].ToString();

                Parametro moParametro = new Parametro();
                moParametro.Proc_LeeParametro("0", "172");
                string remitente = moParametro.Valor.Trim().ToString();

                using (MailMessage correo = new MailMessage())
                {
                    using (SmtpClient smtpClient = new SmtpClient())
                    {
                        NetworkCredential basicCredential = new NetworkCredential(smtpClienUser, smtpClienPass);
                        smtpClient.Host = smtpClientHost;
                        smtpClient.UseDefaultCredentials = false;
                        smtpClient.Credentials = basicCredential;
                        smtpClient.Port = 587;
                        correo.Subject = aDescripcion;
                        correo.Body = aDescripcion;
                        correo.BodyEncoding = System.Text.Encoding.UTF8;
                        correo.IsBodyHtml = true;
                        correo.From = new MailAddress(remitente);

                        foreach (string destinarario in aDestinatarios)
                            correo.To.Add(destinarario.Trim());

                        foreach (string ruta in aArchivosAdjuntos)
                        {
                            if (!string.IsNullOrEmpty(ruta))
                            {
                                FileInfo archivo = new FileInfo(ruta);

                                if (archivo.Exists)
                                {
                                    Attachment attachment = new Attachment(ruta);
                                    attachment.Name = archivo.Name;
                                    correo.Attachments.Add(attachment);
                                }
                            }
                        }
                        smtpClient.Send(correo);
                    }
                }
            }
            catch(Exception aE)
            {
                Comun.Utilerias.EscribirLog(string.Format("Mensaje: {0}, StackTrace: {1}", aE.Message, aE.StackTrace), false);
            }
        }

        public static string ObtenerTipoArchivo(string aExtensionArchivo)
        {
            string respuesta = string.Empty;
            switch (aExtensionArchivo.Trim().ToLower().Replace(".", ""))
            {
                case "pdf":
                    respuesta = "data:application/pdf;base64";
                    break;

                case "jpg":
                    respuesta = "data:image/jpg;base64";
                    break;

                case "png":
                    respuesta = "data:image/png;base64";
                    break;

                case "gif":
                    respuesta = "data:image/gif;base64";
                    break;

                case "xml":
                    respuesta = "data:application/xml;base64";
                    break;

                case "txt":
                    respuesta = "data:application/txt;base64";
                    break;

                case "xls":
                    respuesta = "data:application/xls;base64";
                    break;

                case "xlsx":
                    respuesta = "data:application/xlsx;base64";
                    break;

                case "doc":
                    respuesta = "data:application/doc;base64";
                    break;

                case "docx":
                    respuesta = "data:application/docx;base64";
                    break;

                case "css":
                    respuesta = "data:application/css;base64";
                    break;
            }

            return respuesta;
        }

        public static int ObtenerWidthHeightImagen(string aArchivo, EWidthHeight aTipo)
        {
            int valor = 0;
            string[] extensiones = { "jpg", "gif", "png" };

            FileInfo archivo = new FileInfo(aArchivo);
            System.Drawing.Image image = System.Drawing.Image.FromFile(aArchivo);
            if (extensiones.Contains(archivo.Extension.Replace(".",""))) {
                switch (aTipo)
                {
                    case EWidthHeight.Width:
                        valor = image.Width;
                        break;

                    case EWidthHeight.Heigth:
                        valor = image.Height;
                        break;
                }
            }

            image.Dispose();

            return valor;
        }
    }
}