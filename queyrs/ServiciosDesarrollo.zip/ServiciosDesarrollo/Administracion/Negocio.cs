﻿using ClosedXML.Excel;
using ServiciosLocktonTI.Administracion.BeflexV3;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace ServiciosLocktonTI.Administracion
{
  
    public class Negocio
    {
        private static Parametro moParametro;
        #region Ws_Documentos
        public static void EscribirArchivo(string contenido, string ruta)
        {
            FileInfo archivo = new FileInfo(ruta);
            StreamWriter documento;
            if (!archivo.Exists)
            {
                Directory.CreateDirectory(archivo.Directory.FullName);
                documento = new StreamWriter(archivo.FullName, false, System.Text.Encoding.UTF8);
            }
            else
                documento = archivo.AppendText();

            documento.WriteLine(string.Format("{0} ({1})", contenido, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
            documento.Flush();
            documento.Close();
        }

        public static bool ValidarRangoFecha(DateTime fechaDiaHoy, DateTime fechaInicio, DateTime fechaFinal)
        {
            return (fechaDiaHoy >= fechaInicio && fechaDiaHoy <= fechaFinal);
        }

        public static bool ValidaRangoTiempo(DateTime Horario, TimeSpan HoraInicio, TimeSpan HoraFinal)
        {
            var tiempo = Horario.TimeOfDay;

            if (HoraInicio <= HoraFinal)
                return tiempo >= HoraInicio && tiempo <= HoraFinal;

            return tiempo >= HoraInicio || tiempo <= HoraFinal;
        }

        public string CargaMasivaDocumentos(int aIdOrigen, int aIdEmpresa, Documento[] aDocumentos,string Log)
        {
             string respuesta = string.Empty;
            try
            {
                int idFolio = 0;
                DataTable dtFolio = BaseDatos.InsertaFolioDocumento(aIdOrigen, Log);
                if (dtFolio != null && dtFolio.Rows.Count > 0 && int.TryParse(dtFolio.Rows[0]["IdFolio"].ToString(), out idFolio))
                {
                    respuesta = dtFolio.Rows[0]["Folio"].ToString();
                    Thread thread = new Thread(() => ProcesaCargaMasivaDocumentos(aIdOrigen, idFolio, aIdEmpresa, aDocumentos,Log));
                    thread.Start();
                }
                else
                    respuesta = "Por el momento no es posible atender tu petición, intenta más tarde.";
            }
            catch (Exception aE)
            {
                Negocio.EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), Log);
                respuesta = "No fue posible atender tu solicitud, intenta más tarde.";
            }

            return respuesta;
        }

        private void ProcesaCargaMasivaDocumentos(int aIdOrigen, int aIdFolio, int aIdEmpresa, Documento[] aDocumentos,string  Log)
        {
             try
            {
                int Origen = BaseDatos.ConsultaAdministradorporProcesos(aIdOrigen);

                string[] validExtensions = this.getExtensionesValidas();
                List<string> Validos = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "_", "-", " " };
                char p = ' ';
                Validos.Add(p.ToString());

                foreach (Documento documento in aDocumentos)
                {
                    string[] partesNombre = documento.Nombre.Trim().Split('_');
                    if (partesNombre.Length < 2)
                        BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("El nombre del archivo: {0} no cuenta con un formato adecuado.", documento.Nombre), aIdOrigen, Log);
                    else
                    {
                        int c = 0;
                        string numeroEmpleado = string.Empty;
                        string fileBaseDescripcion = string.Empty;
                        string fileBaseName = string.Empty;
                        foreach (string filePart in partesNombre)
                        {
                            if (c == 0)
                                numeroEmpleado = filePart;
                            else if (c == 1)
                            {
                                fileBaseDescripcion = filePart;
                                fileBaseName += filePart;
                            }
                            else
                                fileBaseName += filePart;
                            c++;
                        }

                        FileInfo archivo = new FileInfo(documento.Nombre.Trim().ToLower());
                        bool validaCaracteresEspeciales = false;
                        foreach (char a in fileBaseName.Replace(archivo.Extension, ""))
                        {
                            if (!Validos.Contains(a.ToString().ToUpperInvariant()))
                            {
                                validaCaracteresEspeciales = true;
                                BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("El caracter {0} en el documento {1} contiene caracteres invalidos.", a, documento.Nombre), aIdOrigen, Log);
                                break;
                            }
                        }

                        if (!validaCaracteresEspeciales)
                        {
                            if (!validExtensions.Contains(archivo.Extension.Replace(".", "")))
                                BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("La extension del documento {0} no existe", documento.Nombre), aIdOrigen, Log);
                            else
                            {
                                DataTable dtEmpleado = BaseDatos.ObtenerEmpleadoPorNumeroEmpleado(aIdEmpresa, numeroEmpleado, Log);
                                if (dtEmpleado != null && dtEmpleado.Rows.Count > 0)
                                {
                                    if (dtEmpleado.Rows[0]["EMIdEstatus"].ToString() != "1")
                                        BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("Empleado {0} se encuentra dado de baja, en el archivo {1}", numeroEmpleado, documento.Nombre), aIdOrigen, Log);
                                    else
                                    {
                                        string idEmpleado = dtEmpleado.Rows[0]["Id"].ToString();
                                        DataTable dtSeccion = BaseDatos.ObtenerSeccionPorId((int)documento.Seccion, Log);
                                        if (dtSeccion != null && dtSeccion.Rows.Count > 0)
                                        {
                                            DataTable dtVigencia = BaseDatos.ObtenerVigenciaPorTipoNegocio(aIdEmpresa, (int)documento.TipoNegocio, Log);

                                            if (dtVigencia != null && dtVigencia.Rows.Count > 0)
                                            {
                                                string idVigencia = dtVigencia.Rows[0][0].ToString();
                                                string idSeccionDocumento = dtSeccion.Rows[0]["sdIdSeccionDocumento"].ToString();
                                                string seccionDocumento = dtSeccion.Rows[0]["sdSeccionDocumento"].ToString();
                                                string rutaDocumento = dtSeccion.Rows[0]["sdRutaDocumento"].ToString().Replace("{0}", aIdEmpresa.ToString()).Replace("{1}", idVigencia);
                                                int eEstatus = 0;


                                                string basePath = @"\\lockmx-demolmn\WS_Documentos\";

                                                string filePath = Path.Combine(basePath, rutaDocumento);

                                                if (!Directory.Exists(filePath))    
                                                    Directory.CreateDirectory(filePath);


                                                FileInfo Fileset = new FileInfo(filePath + "\\" + documento.Nombre.Trim());
                                                eEstatus = (File.Exists(Fileset.FullName)) ? 1 : 0;

                                                if (eEstatus == 1)
                                                {
                                                    FileInfo FilesetRename = new FileInfo(Fileset.FullName);
                                                    string aArchivoRename = FilesetRename.Name.Replace(FilesetRename.Extension, DateTime.Now.Ticks.ToString()) + FilesetRename.Extension;
                                                    File.WriteAllBytes(filePath + "\\" + aArchivoRename, File.ReadAllBytes(FilesetRename.FullName));
                                                }
                                                
                                                    File.WriteAllBytes(Fileset.FullName, documento.Archivo);

                                                DataTable dtDocumento = BaseDatos.InsertarEmpleadoDocumento(
                                                    Origen,
                                                    idEmpleado,
                                                    idSeccionDocumento,
                                                    idVigencia,
                                                    fileBaseDescripcion,
                                                    rutaDocumento + "\\" + documento.Nombre.Trim(),
                                                    Log
                                                    );

                                                if (dtDocumento != null && dtDocumento.Rows.Count > 0)
                                                {
                                                    int IdDocumento = 0, Respuesta = 0, Actualiza = 0, Axdocumento = 0;

                                                    if ((eEstatus == 1 || eEstatus == 0) && (dtDocumento.Rows[0]["result"].ToString() == "3" || dtDocumento.Rows[0]["result"].ToString() == "4"))
                                                    { 
                                                        Actualiza = BaseDatos.ActualizaDocumentoRemplazado(int.Parse(idEmpleado), fileBaseDescripcion, rutaDocumento + "\\" + documento.Nombre.Trim(), Origen);
                                                        Respuesta = int.Parse(BaseDatos.InsertarEmpleadoDocumento(Origen, idEmpleado, idSeccionDocumento, idVigencia, fileBaseDescripcion, rutaDocumento + "\\" + documento.Nombre.Trim(), Log).Rows[0]["result"].ToString());

                                                        int BDOTotal = (dtDocumento.Rows[0]["result"].ToString() == "3" || dtDocumento.Rows[0]["result"].ToString() == "4") ? 1 : 0;

                                                       

                                                        if (Respuesta == 1 || Respuesta == 2)
                                                            IdDocumento = BaseDatos.InsertaDetalleFolioDocumentoDetalleIdDocumento(aIdFolio, documento, (int)Documento.EEstatus.Exitoso, string.Format( "El archivo {0} fue reemplazado exitosamente. Registro: {1}  Directorio: {2}  ", documento.Nombre, BDOTotal, eEstatus), Origen, Log);
                                                        else
                                                            BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("No fue posible almacenar el archivo {0} de la empresa {1} debido a un error interno, favor de contactar al administrador.", documento.Nombre, aIdEmpresa), aIdOrigen, Log);
                                                       
                                                        if (Actualiza > 0)
                                                            Axdocumento = BaseDatos.EliminaAseguradospordocumento(Fileset.Name, Actualiza, Origen, Log);
                                                    }
                                                    else
                                                        IdDocumento = BaseDatos.InsertaDetalleFolioDocumentoDetalleIdDocumento(aIdFolio, documento, (int)Documento.EEstatus.Exitoso, string.Format("El archivo {0} fue cargado exitosamente.", documento.Nombre), Origen, Log);

                                                    if (IdDocumento > 0)
                                                    {
                                                        for (int a = 0; a < aDocumentos.Length; a++)
                                                        {
                                                            if ((int)aDocumentos[a].TipoNegocio != 2 && (int)aDocumentos[a].Seccion != 16)
                                                            {
                                                                foreach (var item in aDocumentos[a].Asegurado)
                                                                    BaseDatos.InsertaAseguradoporDocumento(IdDocumento, int.Parse(idEmpleado), item.NumeroEmpleado, item.Nombre1, item.Nombre2, item.ApellidoPaterno, item.ApellidoMaterno, item.IdParentesco, Log);
                                                            }
                                                        }
                                                    }


                                                }
                                                else
                                                    BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("No fue posible almacenar el archivo {0} de la empresa Log debido a un error interno, favor de contactar al administrador. {1}", documento.Nombre, aIdEmpresa), aIdOrigen, Log);
                                            }
                                            else
                                                BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("No fue posible cargar el archivo debido a que la empresa {0} no tiene una vigencia valida ", aIdEmpresa), aIdOrigen, Log);
                                        }
                                        else
                                            BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("La seccion del documento {0} no existe", documento.Seccion.ToString()), aIdOrigen, Log);
                                    }
                                }
                                else
                                    BaseDatos.InsertaDetalleFolioDocumento(aIdFolio, documento, (int)Documento.EEstatus.NoExitoso, string.Format("Empleado {0} no existe, en el archivo {1}", numeroEmpleado, documento.Nombre), aIdOrigen, Log);
                            }
                        }
                    }
                }

                BaseDatos.ActualizarFolioDocumentosEstatus(aIdFolio, (int)Documento.EEstatus.Finalizado, aIdOrigen, Log);

            }
            catch (Exception aE)
            {
                Negocio.EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), Log );
            }
        }
        private string[] getExtensionesValidas()
        {
            string[] extensiones = new string[] { "pdf", "xls", "ppt", "doc", "docx", "pptx", "pps", "xlsx", "xml", "jpg", "png" };
            return extensiones;
        }

       

        public Resultado ConsultaEstatusDocumento(int  aIdFolio)
        {
            string pathLogDocumentos = string.Format("{0}Log\\WSDocumentos{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            Resultado oResultado = new Resultado();

            try
            {
                DataTable dtDetalle = BaseDatos.ObtenerDetalleFolioDocumentos(aIdFolio, pathLogDocumentos);
                if (dtDetalle.Rows.Count > 0)
                {
                    oResultado.Estatus = (Documento.EEstatus)int.Parse(dtDetalle.Rows[0]["DDIdEstatusAdd"].ToString());
                    oResultado.Descripcion = dtDetalle.Rows[0]["DDMensajeArchivo"].ToString();
                }
                else
                    oResultado.Estatus = Documento.EEstatus.Inexistente;

            }
            catch (Exception aE)
            {
                oResultado.Estatus = Documento.EEstatus.NoDisponible;
                Negocio.EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLogDocumentos);
            }
            return oResultado;
        }

        public Resultado CargaDocumento(int aIdOrigen, int aIdEmpresa, Documento aDocumento,string Log)
        {
            bool PropiedadesRequeridas = false;
           /// string pathLogDocumentos = string.Format("{0}DocumentoEmpresa\\0\\Log\\WSDocumentos{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            Resultado resultado = new Resultado();

            try
            {
                if ((((int)aDocumento.TipoNegocio == 2 && (int)aDocumento.Seccion == 16)) || ((int)aDocumento.TipoNegocio == 1 && (int)aDocumento.Seccion == 16))
                    PropiedadesRequeridas = true;
                else
                if (((int)aDocumento.TipoNegocio == 2 && (int)aDocumento.Seccion == 16) || ((int)aDocumento.TipoNegocio == 1 && (int)aDocumento.Seccion == 16))
                    PropiedadesRequeridas = true;
                else
                {
                    DataTable IdParentescos = BaseDatos.ConsultaIdPrentescoIniciofin(Log);
                    int IdInicio = (IdParentescos != null && IdParentescos.Rows.Count > 0) ? int.Parse(IdParentescos.Rows[0]["Inicio"].ToString()) : 1;
                    int IdFin = (IdParentescos != null && IdParentescos.Rows.Count > 0) ? int.Parse(IdParentescos.Rows[0]["Fin"].ToString()) : 25;

                    foreach (var item in aDocumento.Asegurado)
                        if ((!string.IsNullOrWhiteSpace(item.Nombre1)) && (item.IdParentesco >= IdInicio && item.IdParentesco <= IdFin))
                            PropiedadesRequeridas = true;
                        else
                            PropiedadesRequeridas = false;
                    if (aDocumento.TipoDeDocumento == Documento.EFactura.Factura && aDocumento.Asegurado.FindAll(a => string.IsNullOrEmpty(a.NumeroEmpleado)).Count > 0)
                    {
                        PropiedadesRequeridas = false;
                    }
                    else
                    {
                        if (aDocumento.TipoDeDocumento == Documento.EFactura.Factura && aDocumento.Asegurado.FindAll(a => string.IsNullOrEmpty(a.NumeroEmpleado)).Count == 0)
                        {
                            PropiedadesRequeridas = true;
                        }
                        else
                        {
                            foreach (var item in aDocumento.Asegurado)
                                if ((!string.IsNullOrWhiteSpace(item.Nombre1)) && (item.IdParentesco >= IdInicio && item.IdParentesco <= IdFin))
                                    PropiedadesRequeridas = true;
                                else
                                    PropiedadesRequeridas = false;
                        }
                    }
                }
                if (PropiedadesRequeridas == true)
                {
                    int idFolio = 0;
                    DataTable dtFolio = BaseDatos.InsertaFolioDocumento(aIdOrigen, Log);
                    if (dtFolio != null && dtFolio.Rows.Count > 0 && int.TryParse(dtFolio.Rows[0]["IdFolio"].ToString(), out idFolio))
                    {
                        ProcesaCargaMasivaDocumentos(aIdOrigen, idFolio, aIdEmpresa, new List<Documento>() { aDocumento }.ToArray(), Log);
                        resultado = ConsultaEstatusDocumento(int.Parse(dtFolio.Rows[0]["IdFolio"].ToString()));
                    }
                    else
                        resultado = new Resultado()
                        {
                            Estatus = Documento.EEstatus.NoDisponible,
                            Descripcion = "Por el momento no es posible atender tu petición, intenta más tarde."+aDocumento.Nombre
                        };
                }
                else
                    resultado = new Resultado()
                    {
                        Estatus = Documento.EEstatus.PropiedadesRequeridas,
                        Descripcion = "Algunas propiedades del objeto asegurado son requeridas en este método." + aDocumento.Nombre
                    };

            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), Log);
                resultado = new Resultado()
                {
                    Estatus = Documento.EEstatus.NoDisponible,
                    Descripcion = "No fue posible atender tu solicitud, intenta más tarde." + aDocumento.Nombre
                };
            }
            Negocio.EscribirArchivo(string.Format("Estatus: {0} Descripcion: {1}", resultado.Estatus, resultado.Descripcion), Log);
            return resultado;
        }

        public static string Encrypt(string inputText)
        {
            moParametro = new Parametro();
            moParametro.Proc_LeeParametro("0", "181");
            string valorParametro = moParametro.Valor.Trim();

            string ENCRYPTION_KEY = valorParametro;
            byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY.Length.ToString());


            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            byte[] plainText = Encoding.Unicode.GetBytes(inputText);
            PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT);

            using (ICryptoTransform encryptor = rijndaelCipher.CreateEncryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16)))
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(plainText, 0, plainText.Length);
                        cryptoStream.FlushFinalBlock();
                        return Convert.ToBase64String(memoryStream.ToArray());
                    }
                }
            }

        }

        public static string Decrypt(string inputText)
        {

            moParametro = new Parametro();
            moParametro.Proc_LeeParametro("0", "181");
            string valorParametro = moParametro.Valor.Trim();
            string ENCRYPTION_KEY = valorParametro;
            byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY.Length.ToString());

            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            byte[] encryptedData = Convert.FromBase64String(inputText);
            PasswordDeriveBytes secretKey = new PasswordDeriveBytes(ENCRYPTION_KEY, SALT);

            using (ICryptoTransform decryptor = rijndaelCipher.CreateDecryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)))
            {
                using (MemoryStream memoryStream = new MemoryStream(encryptedData))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        byte[] plainText = new byte[encryptedData.Length];
                        int decryptedCount = cryptoStream.Read(plainText, 0, plainText.Length);
                        return Encoding.Unicode.GetString(plainText, 0, decryptedCount);
                    }
                }
            }





        }


        #region MantenimientoDocumentos
        public List<Documento> ConsultadeDocumento(int aIdOrigen, int aIdEmpresa, string aNumeroEmpleado, string pathLog)
        {
            List<Documento> WS_Respuetas = new List<Documento>();
            try
            {
                DataSet dt = BaseDatos.ConsultaDatosDocumentos(aIdEmpresa, aNumeroEmpleado, pathLog);
                if (dt.Tables.Count > 0)
                {
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        var Documentos = (from s in dt.Tables[0].AsEnumerable()
                                          select new
                                          {
                                              DEIdDocumentoEmpleado = s["DEIdDocumentoEmpleado"].ToString(),
                                              DEDocumento = s["DEDocumento"].ToString()
                                          });
                        foreach (var itemDoc in Documentos)
                        {
                            FileInfo fi = new FileInfo(itemDoc.DEDocumento);
                            Documento WS_Objeto = new Documento();
                            WS_Objeto.IdDocumento = Int64.Parse(itemDoc.DEIdDocumentoEmpleado);
                            WS_Objeto.Nombre = fi.Name;
                            WS_Objeto.Estatus = Documento.EEstatus.Exitoso;
                            WS_Objeto.Descripcion = "Exitoso";

                            if (dt.Tables[1].Rows.Count > 0)
                            {
                                var Asegurados = (from s in dt.Tables[1].AsEnumerable()
                                                  select new
                                                  {
                                                     // ADIdDocumento = s["ADIdDocumento"].ToString(),
                                                      ADIdEmpleado = s["ADIdEmpleado"].ToString(),
                                                      ADNumeroEmpleado = s["ADNumeroEmpleado"].ToString(),
                                                      ADNombre1 = s["ADNombre1"].ToString(),
                                                      ADNombre2 = s["ADNombre2"].ToString(),
                                                      ADApellidoPaterno = s["ADApellidoPaterno"].ToString(),
                                                      ADApellidoMaterno = s["ADApellidoMaterno"].ToString(),
                                                      ADIdParentesco = s["ADIdParentesco"].ToString(),
                                                      DDNombreDocumento = s["DDNombreDocumento"].ToString()
                                                  }).Distinct();
                                WS_Objeto.Asegurado = new List<Asegurados>();


                                foreach (var itemAs in Asegurados)
                                {

                                    Asegurados WS_Asegurado = new Asegurados();
                                    if (itemAs.DDNombreDocumento.ToUpper().Equals(fi.Name.ToUpper()))
                                    {
                                        WS_Asegurado.NumeroEmpleado = itemAs.ADNumeroEmpleado;
                                        WS_Asegurado.Nombre1 = itemAs.ADNombre1;
                                        WS_Asegurado.Nombre2 = itemAs.ADNombre2;
                                        WS_Asegurado.ApellidoPaterno = itemAs.ADApellidoPaterno;
                                        WS_Asegurado.ApellidoMaterno = itemAs.ADApellidoMaterno;
                                        WS_Asegurado.IdParentesco = int.Parse(itemAs.ADIdParentesco);
                                        WS_Objeto.Asegurado.Add(WS_Asegurado);
                                    }
                                }
                            }
                            WS_Respuetas.Add(WS_Objeto);
                        }
                    }
                }
            }
            catch (Exception aE)
            {
                EscribirArchivo(aE.Message + "Error" + aE.StackTrace, pathLog);
            }

            return WS_Respuetas;

        }

        public Resultado EliminaDocumento(int aIdOrigen, int aIdEmpresa, Int64 IdDocumento, string pathLog)
        {
            Resultado resultado = new Resultado();
            try
            {
                int Origen = BaseDatos.ConsultaAdministradorporProcesos(aIdOrigen);

                DataTable dtRespuesa = BaseDatos.EliminaDocumento(aIdEmpresa, IdDocumento.ToString(), Origen, pathLog);
                if (dtRespuesa.Rows.Count > 0)
                {

                    string basePath = @"\\lockmx-demolmn\WS_Documentos\";

                    string archivo = dtRespuesa.Rows[0]["DEDocumento"].ToString();
                    string IdEmpleado = dtRespuesa.Rows[0]["Id"].ToString();// utilizar fileinfo 
                    string filepath = Path.Combine(basePath, archivo); ;
                    FileInfo fi = new FileInfo(filepath);
                    string NombreDocumento = fi.Name;


                    int respuesta = BaseDatos.EliminaAseguradospordocumento(NombreDocumento.Trim(), int.Parse(IdEmpleado), Origen, pathLog);

                    #region EliminaDocuemento
                    if (respuesta == 1)
                    {
                        if (fi.Exists)
                            fi.Delete();

                        resultado = new Resultado()
                        {
                            Estatus = Documento.EEstatus.Eliminado,
                            Descripcion = "Se ha eliminado todo lo relacionado al documento"
                        };
                    }
                    else
                    {
                        if (fi.Exists)
                            fi.Delete();

                        resultado = new Resultado()
                        {
                            Estatus = Documento.EEstatus.Eliminado,
                            Descripcion = "Se ha eliminado todo lo relacionado al documento"
                        };
                    }
                    #endregion// utilizar fileinfo
                }
                else
                    resultado = new Resultado()
                    {
                        Estatus = Documento.EEstatus.Inexistente,
                        Descripcion = "Documento no encontrado."
                    };
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLog);
                resultado = new Resultado()
                {
                    Estatus = Documento.EEstatus.NoDisponible,
                    Descripcion = "No fue posible atender tu solicitud, intenta más tarde."
                };
            }

            return resultado;
        }
        #endregion
        
        #endregion

        #region Ws_Descuentos
        public Descuentos.EEstatus WsDescuentos(int aIdEmpresa, string pathLogWsDescuentos)
        {
            EscribirArchivo("Inicia método en API Service...", pathLogWsDescuentos);
            Descuentos oResultado = new Descuentos();
            try
            {
                EscribirArchivo("Busca  configuración de ftp", pathLogWsDescuentos);
                DataTable ConfigFtp = BaseDatos.ConsultaFTP(aIdEmpresa, pathLogWsDescuentos);
                if (ConfigFtp.Rows.Count > 0)
                {
                    EscribirArchivo("Se encontró configuración ftp", pathLogWsDescuentos);
                    try
                    {
                        EscribirArchivo("Inicio creación Documento Hilo", pathLogWsDescuentos);
                        Thread oThdGeneraDescuentos = new Thread(delegate ()
                        {
                            IncioDescuentos(ConfigFtp, aIdEmpresa, pathLogWsDescuentos);
                        });
                        EscribirArchivo("Inicio de Hilo", pathLogWsDescuentos);

                        oThdGeneraDescuentos.Start();
                        EscribirArchivo("Respuesta de hilo", pathLogWsDescuentos);
                        oResultado.Estatus = Descuentos.EEstatus.EnProceso;
                    }
                    catch (Exception e)
                    {
                        EscribirArchivo("Ocurrio un errror ", pathLogWsDescuentos);
                        EscribirArchivo(e.ToString(), pathLogWsDescuentos);
                        oResultado.Estatus = Descuentos.EEstatus.NoExitoso;
                        BaseDatos.InsertaEstatusWSBitacoraFtp(ConfigFtp.Rows[0]["WCFNombreDocFTP"].ToString(), (int)Descuentos.EEstatus.NoExitoso, "NoExitoso: " + e.ToString(), ConfigFtp.Rows[0]["WCFCarpeta"].ToString(), ConfigFtp.Rows[0]["WCFServidor"].ToString(), aIdEmpresa, pathLogWsDescuentos);
                    }
                }
                else
                {
                    oResultado.Estatus = Descuentos.EEstatus.NoDisponible;
                    EscribirArchivo("No se encontro configuracion ftp", pathLogWsDescuentos);
                    BaseDatos.InsertaEstatusWSBitacoraFtp("No se encontro configuracion ftp", (int)Descuentos.EEstatus.NoDisponible, "NoDisponible: ", "NoDisponible", "NoDisponible", aIdEmpresa, pathLogWsDescuentos);
                }
            }
            catch (Exception aE)
            {
                oResultado.Estatus = Descuentos.EEstatus.NoExitoso;
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLogWsDescuentos);
                BaseDatos.InsertaEstatusWSBitacoraFtp("NoExitoso", (int)Descuentos.EEstatus.NoExitoso, "NoExitoso: " + string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), "NoExitoso", "NoExitoso", aIdEmpresa, pathLogWsDescuentos);
            }
            return oResultado.Estatus;
        }

        private void IncioDescuentos(DataTable ConfigFtp, int aIdEmpresa, string pathLogWsDescuentos)
        {

            DataSet dt = new DataSet();
            string Date = DateTime.Now.ToString("yyyy-mm-dd_HHmmss");
            int Dias = DateTime.Now.Day;
            string Quincena = string.Empty;
            string fileNameCarpeta = string.Empty;
            Quincena = (Dias <= 15) ? "Q1" : "Q2";
            fileNameCarpeta = (ConfigFtp.Rows[0]["WCFNombreDocFTP"].ToString().Trim().Contains("QU")) ? fileNameCarpeta = ConfigFtp.Rows[0]["WCFNombreDocFTP"].ToString().Replace("QU", Quincena) : fileNameCarpeta = ConfigFtp.Rows[0]["WCFNombreDocFTP"].ToString().Trim();
            string fileNameLocal = ConfigFtp.Rows[0]["WCFArchivo"].ToString().Replace("Fecha", Date);
            string fileName = fileNameLocal.Replace(".ext", ".xlsx");
            string Ruta = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "DocumentoEmpresa/" + aIdEmpresa + "//WSDescuentos//" + ConfigFtp.Rows[0]["WCFCarpeta"].ToString().Trim() + "//";
            int idBitacora = BaseDatos.InsertaEstatusWSBitacoraFtp(fileName, 4, "EnProceso", ConfigFtp.Rows[0]["WCFCarpeta"].ToString(), ConfigFtp.Rows[0]["WCFServidor"].ToString(), aIdEmpresa, pathLogWsDescuentos);
            // creacion  de coumento inserta en bitacora  con estaus   4  
            dt = BaseDatos.WSDescuentosSMNYL(aIdEmpresa, pathLogWsDescuentos);
            if (dt.Tables.Count > 0)
            {
                try
                {
                    XLWorkbook workbook = new XLWorkbook();
                    var worksheet = workbook.Worksheets.Add(dt.Tables[0], "Tabla1");
                    worksheet.Column(5).CellsUsed().SetDataType(XLDataType.Text);
                    var worksheetDetalledeSolicitudes = workbook.Worksheets.Add(dt.Tables[1], "Tabla2");
                    worksheetDetalledeSolicitudes.Column(6).CellsUsed().SetDataType(XLDataType.Text);
                    var worksheetBajas = workbook.Worksheets.Add(dt.Tables[2], "Tabla3");
                    workbook.SaveAs(Ruta + fileName);
                    string ip = ConfigFtp.Rows[0]["WCFServidor"].ToString().Trim() + ConfigFtp.Rows[0]["WCFCarpeta"].ToString().Trim();
                    DirectoryInfo carpetaCompartida = new DirectoryInfo(@ip);
                    EscribirArchivo("Validación  de Ruta: " + carpetaCompartida.ToString(), pathLogWsDescuentos);


                    if (carpetaCompartida.Exists)
                    {
                        EscribirArchivo("Inicia  proceso de colocar Archivo: " + carpetaCompartida.ToString(), pathLogWsDescuentos);
                        try
                        {
                            FileInfo archivoOrigen = new FileInfo(Ruta + fileName);
                            FileInfo archivoDestino = new FileInfo(carpetaCompartida.FullName + @"\\" + fileNameCarpeta);

                            if (File.Exists(archivoDestino.FullName))
                                File.Delete(archivoDestino.FullName);

                            File.Copy(archivoOrigen.FullName, archivoDestino.FullName);
                            EscribirArchivo("Exitoso: " + carpetaCompartida.ToString(), pathLogWsDescuentos);
                            //File.Delete(archivoOrigen.FullName);
                            BaseDatos.ActualizaEstatusWSBitacoraFtp(idBitacora, 1, "Exitoso", pathLogWsDescuentos);

                            if (Directory.Exists(Ruta))
                                System.IO.Directory.Delete(Ruta, true);
                        }
                        catch (Exception aE)
                        {
                            EscribirArchivo("Error al colocar en  carpeta en red " + string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLogWsDescuentos);
                            //if (File.Exists(archivoOrigen.FullName))
                            //    File.Delete(archivoOrigen.FullName);
                            BaseDatos.ActualizaEstatusWSBitacoraFtp(idBitacora, (int)Descuentos.EEstatus.NoExitoso, "NoExitoso: " + string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLogWsDescuentos);
                        }
                    }
                    else
                    {
                        EscribirArchivo("Error al colocar en  carpeta en red: No encontro la ruta  solicitar permmisos  ", pathLogWsDescuentos);
                        //if (File.Exists(archivoOrigen.FullName))
                        //    File.Delete(archivoOrigen.FullName);
                        BaseDatos.ActualizaEstatusWSBitacoraFtp(idBitacora, (int)Descuentos.EEstatus.NoExitoso, "NoExitoso: No encontro la ruta  solicitar permmisos  ", pathLogWsDescuentos);
                    }
                }
                catch (Exception aE)
                {
                    EscribirArchivo("Error al generar Exel" + string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLogWsDescuentos);
                    BaseDatos.ActualizaEstatusWSBitacoraFtp(idBitacora, (int)Descuentos.EEstatus.NoExitoso, "NoExitoso Error al generar Exel: " + string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLogWsDescuentos);
                }
            }
            else
            {
                EscribirArchivo("Error al generar QUERY", pathLogWsDescuentos);
                BaseDatos.ActualizaEstatusWSBitacoraFtp(idBitacora, (int)Descuentos.EEstatus.NoExitoso, "NoExitoso Error al generar QUERY: ", pathLogWsDescuentos);
            }



        }
        #endregion

        #region Ws_Tickets
        public List<Ticket> ObtenerTicketsBeflex(List<int> aIdsTicket, int aIdEmpresa, bool Documentos, string pathLog)
        {
            List<Ticket> tickets = new List<Ticket>();

            DataTable dtTickets = BaseDatos.ObtenerHistoricoNotificacionesTickets(aIdsTicket, aIdEmpresa, pathLog);

            List<int> idsTicket = dtTickets.AsEnumerable().Select(x => int.Parse(x["Ticket_id"].ToString())).Distinct().ToList();

            foreach (var idTicket in idsTicket)
            {
                Ticket _ticket = new Ticket();
                var encabezadoTicket = (from t in dtTickets.AsEnumerable()
                                        where t["Ticket_id"].ToString() == idTicket.ToString()
                                        select new
                                        {

                                            Ticket_id = int.Parse(t["Ticket_id"].ToString()),
                                            EMNumeroEmpleado = t["EMNumeroEmpleado"].ToString(),
                                            Ticket_Descripcion = t["Ticket_Descripcion"].ToString(),
                                            Ticket_idEstatus = int.Parse(t["Ticket_idEstatus"].ToString()),
                                            Ticket_FechaAdd = DateTime.Parse(t["Ticket_FechaAdd"].ToString()),
                                            Nombre = t["Nombre"].ToString(),
                                            Ticket_Mail = t["Ticket_Mail"].ToString(),
                                            Ticket_ContactodeEmergencia = t["Ticket_ContactodeEmergencia"].ToString(),
                                            Ticket_Telefono1 = t["Ticket_Telefono1"].ToString(),
                                            Ticket_Telefono2 = t["Ticket_Telefono2"].ToString(),
                                            Ticket_Hospital = t["Ticket_Hospital"].ToString(),
                                            TicketEstatus_Descripcion = t["TicketEstatus_Descripcion"].ToString(),
                                            Solicitud_id = int.Parse(t["Solicitud_id"].ToString()),
                                            Solicitud_Descripcion = t["Solicitud_Descripcion"].ToString(),
                                            Segmento_descripcion = t["Segmento_descripcion"].ToString(),
                                            Segmento_id = int.Parse(t["Segmento_id"].ToString())
                                        }).Distinct().FirstOrDefault();

                _ticket.Id = encabezadoTicket.Ticket_id;
                _ticket.Clave = encabezadoTicket.EMNumeroEmpleado;
                _ticket.Descripcion = encabezadoTicket.Ticket_Descripcion;
                _ticket.Estatus = new Tipo() { Id = encabezadoTicket.Ticket_idEstatus, Nombre = encabezadoTicket.TicketEstatus_Descripcion };
                _ticket.FechaAdd = encabezadoTicket.Ticket_FechaAdd;
                _ticket.Asegurado = encabezadoTicket.Nombre;
                _ticket.Correoelectronico = encabezadoTicket.Ticket_Mail;
                _ticket.Telefono1 = encabezadoTicket.Ticket_Telefono1;
                _ticket.Telefono2 = encabezadoTicket.Ticket_Telefono2;
                _ticket.Hospital = encabezadoTicket.Ticket_Hospital;
                _ticket.TipoSolicitud = new Tipo() { Id = encabezadoTicket.Solicitud_id, Nombre = encabezadoTicket.Solicitud_Descripcion };
                _ticket.Segmento = new Tipo() { Id = encabezadoTicket.Segmento_id, Nombre = encabezadoTicket.Segmento_descripcion };


                var seguimientoTicket = (from s in dtTickets.AsEnumerable()
                                            where s["Ticket_id"].ToString() == idTicket.ToString()
                                            select new
                                            {
                                                idEtapa = int.Parse(s["TicketEtapa_id"].ToString()),
                                                Etapa_id = int.Parse(s["Etapa_id"].ToString()),
                                                Observaciones = s["Observacion"].ToString(),
                                                Ticket_Etapa_EstatusId = int.Parse(s["Ticket_Etapa_EstatusId"].ToString()),//objeto
                                                TicketEstatus_Descripcion = s["TicketEstatus_Descripcion"].ToString(),//objeto
                                                Descripcion = s["Etapa_Descripcion"].ToString(),
                                                Responsable = s["Etapa_Responsable"].ToString(),
                                                ResponsableCorreo = s["Etapa_ResponsableCorreo"].ToString(),
                                                SeguimientoFechaAdd = DateTime.Parse(s["TicketEtapa_FechaAdd"].ToString()),
                                            });

                _ticket.Seguimientos = new List<Seguimiento>();

                foreach (var seguimiento in seguimientoTicket)
                {
                    Seguimiento _seguimiento = new Seguimiento();
                    _seguimiento.Id = seguimiento.idEtapa;
                    _seguimiento.Etapa = new Etapa()
                    {
                        Idetapa = seguimiento.Etapa_id,
                        Descripcion = seguimiento.Descripcion,
                        Responsable = seguimiento.Responsable,
                        ResponsableCorreo = seguimiento.ResponsableCorreo,

                    };
                    _seguimiento.Observacion = seguimiento.Observaciones;
                    _seguimiento.SeguimientoFechaAdd = seguimiento.SeguimientoFechaAdd;
                    _ticket.Seguimientos.Add(_seguimiento);
                }



                if (Documentos == true)
                {

                    string basePath = @"\\lockmx-demolmn\WS_Documentos\";

                    var archivoTicket = (from a in dtTickets.AsEnumerable()
                                            where a["Ticket_id"].ToString() == idTicket.ToString() && !string.IsNullOrEmpty(a["Ticket_Archivo"].ToString())
                                            select new
                                            {
                                                idArchivo = int.Parse(a["TicketArchivo"].ToString()),
                                                NombreArchivo = a["Ticket_Archivo"].ToString(),
                                                Ticket_ArchivoRuta = a["Ticket_ArchivoRuta"].ToString(),
                                                Ticket_Archivo = !string.IsNullOrEmpty(a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()) ? (new FileInfo(basePath + a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()).Exists ? File.ReadAllBytes(basePath + a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()) : null) : null

                                            }).Distinct();

                    _ticket.Archivos = new List<Archivo>();


                    foreach (var archivo in archivoTicket)
                    {

                        Archivo _archivo = new Archivo();
                        _archivo.Id = archivo.idArchivo;
                        _archivo.Nombre = archivo.NombreArchivo;
                        _archivo.Ruta = archivo.Ticket_ArchivoRuta;
                        _archivo.Document = archivo.Ticket_Archivo;
                        _ticket.Archivos.Add(_archivo);
                    }

                }
                tickets.Add(_ticket);
            }
            return tickets;
        }


        public List<Ticket> ObtenerTicketsBeflex(int IdEmpresa, DateTime FechaInicio, DateTime FechaFinal, bool Documentos, string pathLog)
        {
            List<Ticket> tickets = new List<Ticket>();


            DataTable dtTickets = BaseDatos.ObtenerHistoricoNotificacionesTicketsporFecha(IdEmpresa, FechaInicio, FechaFinal, pathLog);

            List<int> idsTicket = dtTickets.AsEnumerable().Select(x => int.Parse(x["Ticket_id"].ToString())).Distinct().ToList();

            foreach (var idTicket in idsTicket)
            {
                Ticket _ticket = new Ticket();
                var encabezadoTicket = (from t in dtTickets.AsEnumerable()
                                        where t["Ticket_id"].ToString() == idTicket.ToString()
                                        select new
                                        {

                                            Ticket_id = int.Parse(t["Ticket_id"].ToString()),
                                            EMNumeroEmpleado = t["EMNumeroEmpleado"].ToString(),
                                            Ticket_Descripcion = t["Ticket_Descripcion"].ToString(),
                                            Ticket_idEstatus = int.Parse(t["Ticket_idEstatus"].ToString()),
                                            Ticket_FechaAdd = DateTime.Parse(t["Ticket_FechaAdd"].ToString()),
                                            Nombre = t["Nombre"].ToString(),
                                            Ticket_Mail = t["Ticket_Mail"].ToString(),
                                            Ticket_ContactodeEmergencia = t["Ticket_ContactodeEmergencia"].ToString(),
                                            Ticket_Telefono1 = t["Ticket_Telefono1"].ToString(),
                                            Ticket_Telefono2 = t["Ticket_Telefono2"].ToString(),
                                            Ticket_Hospital = t["Ticket_Hospital"].ToString(),
                                            TicketEstatus_Descripcion = t["TicketEstatus_Descripcion"].ToString(),
                                            Solicitud_id = int.Parse(t["Solicitud_id"].ToString()),
                                            Solicitud_Descripcion = t["Solicitud_Descripcion"].ToString(),
                                            Segmento_descripcion = t["Segmento_descripcion"].ToString(),
                                            Segmento_id = int.Parse(t["Segmento_id"].ToString())
                                        }).Distinct().FirstOrDefault();

                _ticket.Id = encabezadoTicket.Ticket_id;
                _ticket.Clave = encabezadoTicket.EMNumeroEmpleado;
                _ticket.Descripcion = encabezadoTicket.Ticket_Descripcion;
                _ticket.Estatus = new Tipo() { Id = encabezadoTicket.Ticket_idEstatus, Nombre = encabezadoTicket.TicketEstatus_Descripcion };
                _ticket.FechaAdd = encabezadoTicket.Ticket_FechaAdd;
                _ticket.Asegurado = encabezadoTicket.Nombre;
                _ticket.Correoelectronico = encabezadoTicket.Ticket_Mail;
                _ticket.Telefono1 = encabezadoTicket.Ticket_Telefono1;
                _ticket.Telefono2 = encabezadoTicket.Ticket_Telefono2;
                _ticket.Hospital = encabezadoTicket.Ticket_Hospital;
                _ticket.TipoSolicitud = new Tipo() { Id = encabezadoTicket.Solicitud_id, Nombre = encabezadoTicket.Solicitud_Descripcion };
                _ticket.Segmento = new Tipo() { Id = encabezadoTicket.Segmento_id, Nombre = encabezadoTicket.Segmento_descripcion };


                var seguimientoTicket = (from s in dtTickets.AsEnumerable()
                                            where s["Ticket_id"].ToString() == idTicket.ToString()
                                            select new
                                            {
                                                idEtapa = int.Parse(s["TicketEtapa_id"].ToString()),
                                                Etapa_id = int.Parse(s["Etapa_id"].ToString()),
                                                Observaciones = s["Observacion"].ToString(),
                                                Ticket_Etapa_EstatusId = int.Parse(s["Ticket_Etapa_EstatusId"].ToString()),//objeto
                                                TicketEstatus_Descripcion = s["TicketEstatus_Descripcion"].ToString(),//objeto
                                                Descripcion = s["Etapa_Descripcion"].ToString(),
                                                Responsable = s["Etapa_Responsable"].ToString(),
                                                ResponsableCorreo = s["Etapa_ResponsableCorreo"].ToString(),
                                                SeguimientoFechaAdd = DateTime.Parse(s["TicketEtapa_FechaAdd"].ToString()),
                                            });

                _ticket.Seguimientos = new List<Seguimiento>();

                foreach (var seguimiento in seguimientoTicket)
                {
                    Seguimiento _seguimiento = new Seguimiento();
                    _seguimiento.Id = seguimiento.idEtapa;
                    _seguimiento.Etapa = new Etapa()
                    {
                        Idetapa = seguimiento.Etapa_id,
                        Descripcion = seguimiento.Descripcion,
                        Responsable = seguimiento.Responsable,
                        ResponsableCorreo = seguimiento.ResponsableCorreo,

                    };
                    _seguimiento.Observacion = seguimiento.Observaciones;
                    _seguimiento.SeguimientoFechaAdd = seguimiento.SeguimientoFechaAdd;
                    _ticket.Seguimientos.Add(_seguimiento);
                }



                if (Documentos == true)
                {

                    string basePath = @"\\lockmx-demolmn\WS_Documentos\";


                    var archivoTicket = (from a in dtTickets.AsEnumerable()
                                            where a["Ticket_id"].ToString() == idTicket.ToString() && !string.IsNullOrEmpty(a["Ticket_Archivo"].ToString())
                                            select new
                                            {
                                                idArchivo = int.Parse(a["TicketArchivo"].ToString()),
                                                NombreArchivo = a["Ticket_Archivo"].ToString(),
                                                Ticket_ArchivoRuta = a["Ticket_ArchivoRuta"].ToString(),
                                                Ticket_Archivo = !string.IsNullOrEmpty(a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()) ? (new FileInfo(basePath + a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()).Exists ? File.ReadAllBytes(basePath + a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()) : null) : null

                                            }).Distinct();

                    _ticket.Archivos = new List<Archivo>();


                    foreach (var archivo in archivoTicket)
                    {

                        Archivo _archivo = new Archivo();
                        _archivo.Id = archivo.idArchivo;
                        _archivo.Nombre = archivo.NombreArchivo;
                        _archivo.Ruta = archivo.Ticket_ArchivoRuta;
                        _archivo.Document = archivo.Ticket_Archivo;
                        _ticket.Archivos.Add(_archivo);
                    }

                }
                tickets.Add(_ticket);
            }
            return tickets;
        }


        public List<Ticket> ObtenerTicketsBeflexporCorporativo(int IdEmpresa, DateTime FechaInicio, DateTime FechaFinal, bool Documentos, string pathLog)
        {
            List<Ticket> tickets = new List<Ticket>();


            DataTable dtTickets = BaseDatos.ObtenerHistoricoNotificacionesTicketsporFechaporCorporativo(IdEmpresa, FechaInicio, FechaFinal, pathLog);

            List<int> idsTicket = dtTickets.AsEnumerable().Select(x => int.Parse(x["Ticket_id"].ToString())).Distinct().ToList();

            foreach (var idTicket in idsTicket)
            {
                Ticket _ticket = new Ticket();
                var encabezadoTicket = (from t in dtTickets.AsEnumerable()
                                        where t["Ticket_id"].ToString() == idTicket.ToString()
                                        select new
                                        {

                                            Ticket_id = int.Parse(t["Ticket_id"].ToString()),
                                            EMNumeroEmpleado = t["EMNumeroEmpleado"].ToString(),
                                            Ticket_Descripcion = t["Ticket_Descripcion"].ToString(),
                                            Ticket_idEstatus = int.Parse(t["Ticket_idEstatus"].ToString()),
                                            Ticket_FechaAdd = DateTime.Parse(t["Ticket_FechaAdd"].ToString()),
                                            Nombre = t["Nombre"].ToString(),
                                            Ticket_Mail = t["Ticket_Mail"].ToString(),
                                            Ticket_ContactodeEmergencia = t["Ticket_ContactodeEmergencia"].ToString(),
                                            Ticket_Telefono1 = t["Ticket_Telefono1"].ToString(),
                                            Ticket_Telefono2 = t["Ticket_Telefono2"].ToString(),
                                            Ticket_Hospital = t["Ticket_Hospital"].ToString(),
                                            TicketEstatus_Descripcion = t["TicketEstatus_Descripcion"].ToString(),
                                            Solicitud_id = int.Parse(t["Solicitud_id"].ToString()),
                                            Solicitud_Descripcion = t["Solicitud_Descripcion"].ToString(),
                                            Segmento_descripcion = t["Segmento_descripcion"].ToString(),
                                            Segmento_id = int.Parse(t["Segmento_id"].ToString())
                                        }).Distinct().FirstOrDefault();

                _ticket.Id = encabezadoTicket.Ticket_id;
                _ticket.Clave = encabezadoTicket.EMNumeroEmpleado;
                _ticket.Descripcion = encabezadoTicket.Ticket_Descripcion;
                _ticket.Estatus = new Tipo() { Id = encabezadoTicket.Ticket_idEstatus, Nombre = encabezadoTicket.TicketEstatus_Descripcion };
                _ticket.FechaAdd = encabezadoTicket.Ticket_FechaAdd;
                _ticket.Asegurado = encabezadoTicket.Nombre;
                _ticket.Correoelectronico = encabezadoTicket.Ticket_Mail;
                _ticket.Telefono1 = encabezadoTicket.Ticket_Telefono1;
                _ticket.Telefono2 = encabezadoTicket.Ticket_Telefono2;
                _ticket.Hospital = encabezadoTicket.Ticket_Hospital;
                _ticket.TipoSolicitud = new Tipo() { Id = encabezadoTicket.Solicitud_id, Nombre = encabezadoTicket.Solicitud_Descripcion };
                _ticket.Segmento = new Tipo() { Id = encabezadoTicket.Segmento_id, Nombre = encabezadoTicket.Segmento_descripcion };


                var seguimientoTicket = (from s in dtTickets.AsEnumerable()
                                         where s["Ticket_id"].ToString() == idTicket.ToString()
                                         select new
                                         {
                                             idEtapa = int.Parse(s["TicketEtapa_id"].ToString()),
                                             Etapa_id = int.Parse(s["Etapa_id"].ToString()),
                                             Observaciones = s["Observacion"].ToString(),
                                             Ticket_Etapa_EstatusId = int.Parse(s["Ticket_Etapa_EstatusId"].ToString()),//objeto
                                             TicketEstatus_Descripcion = s["TicketEstatus_Descripcion"].ToString(),//objeto
                                             Descripcion = s["Etapa_Descripcion"].ToString(),
                                             Responsable = s["Etapa_Responsable"].ToString(),
                                             ResponsableCorreo = s["Etapa_ResponsableCorreo"].ToString(),
                                             SeguimientoFechaAdd = DateTime.Parse(s["TicketEtapa_FechaAdd"].ToString()),
                                         });

                _ticket.Seguimientos = new List<Seguimiento>();

                foreach (var seguimiento in seguimientoTicket)
                {
                    Seguimiento _seguimiento = new Seguimiento();
                    _seguimiento.Id = seguimiento.idEtapa;
                    _seguimiento.Etapa = new Etapa()
                    {
                        Idetapa = seguimiento.Etapa_id,
                        Descripcion = seguimiento.Descripcion,
                        Responsable = seguimiento.Responsable,
                        ResponsableCorreo = seguimiento.ResponsableCorreo,

                    };
                    _seguimiento.Observacion = seguimiento.Observaciones;
                    _seguimiento.SeguimientoFechaAdd = seguimiento.SeguimientoFechaAdd;
                    _ticket.Seguimientos.Add(_seguimiento);
                }



                if (Documentos == true)
                {

                    string basePath = @"C:\inetpub\wwwroot\BeflexV3_Desarrollo";


                    var archivoTicket = (from a in dtTickets.AsEnumerable()
                                         where a["Ticket_id"].ToString() == idTicket.ToString() && !string.IsNullOrEmpty(a["Ticket_Archivo"].ToString())
                                         select new
                                         {
                                             idArchivo = int.Parse(a["TicketArchivo"].ToString()),
                                             NombreArchivo = a["Ticket_Archivo"].ToString(),
                                             Ticket_ArchivoRuta = a["Ticket_ArchivoRuta"].ToString(),
                                             Ticket_Archivo = !string.IsNullOrEmpty(a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()) ? (new FileInfo(basePath + a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()).Exists ? File.ReadAllBytes(basePath + a["Ticket_ArchivoRuta"].ToString() + a["Ticket_Archivo"].ToString()) : null) : null

                                         }).Distinct();

                    _ticket.Archivos = new List<Archivo>();


                    foreach (var archivo in archivoTicket)
                    {

                        Archivo _archivo = new Archivo();
                        _archivo.Id = archivo.idArchivo;
                        _archivo.Nombre = archivo.NombreArchivo;
                        _archivo.Ruta = archivo.Ticket_ArchivoRuta;
                        _archivo.Document = archivo.Ticket_Archivo;
                        _ticket.Archivos.Add(_archivo);
                    }

                }
                tickets.Add(_ticket);
            }
            return tickets;
        }





        #endregion
    }
}