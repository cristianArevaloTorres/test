﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

using System.Diagnostics;
namespace ServiciosLocktonTI.Administracion
{
    public class Plantilla
    {
        private readonly CommonBusiness commonBiz;
        private int _IdPlantilla;
        private readonly string WebServiceAccesKey;
        private PlantillaCampoItemCollection _campos;

        public Plantilla(int IdPlantilla, SortedList options)
        {
            this.commonBiz = new CommonBusiness();
            this.WebServiceAccesKey = ConfigurationSettings.AppSettings["localValidator"];
            this._IdPlantilla = IdPlantilla;
            this.CreateFields(options);
        }

        public Plantilla(int IdPlantilla, SortedList options, string Validator)
        {
            this.commonBiz = new CommonBusiness();
            this.WebServiceAccesKey = ConfigurationSettings.AppSettings[nameof(Validator)];
            this._IdPlantilla = IdPlantilla;
            this.CreateFields(options);
        }

        public PlantillaCampoItemCollection Campos
        {
            get
            {
                return this._campos;
            }
        }

        public PlantillaCampoItemCollection CamposRequeridos
        {
            get
            {
                PlantillaCampoItemCollection campoItemCollection = new PlantillaCampoItemCollection();
                foreach (DictionaryEntry campo in (DictionaryBase)this._campos)
                {
                    if (((PlantillaCampoItem)campo.Value).Requerido)
                        campoItemCollection.Add((string)campo.Key, (PlantillaCampoItem)campo.Value);
                }
                return campoItemCollection;
            }
        }


private void CreateFields(SortedList options)
    {
        Debug.WriteLine("IdPlantilla: " + this._IdPlantilla);

        DataTable table = this.commonBiz.ExecuteStoredProcedure(
            new SqlParameter[1]
            {
            new SqlParameter("@IdPlantilla", (object)this._IdPlantilla)
            },
            "ff_CPlantillaCampos",
            string.Empty
        ).Tables[0];

        Debug.WriteLine("Total filas: " + table.Rows.Count);

        this._campos = new PlantillaCampoItemCollection();

        foreach (DataRow row in table.Rows)
        {
            Debug.WriteLine("Campo: " + row["CANombreCampo"].ToString());

            this._campos.Add(
                row["CANombreCampo"].ToString(),
                new PlantillaCampoItem(row, options)
            );
        }
    }

    public void Dispose()
        {
            this._campos.Clear();
        }
    }
}