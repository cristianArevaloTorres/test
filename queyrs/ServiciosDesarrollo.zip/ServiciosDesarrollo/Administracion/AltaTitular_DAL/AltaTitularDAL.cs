﻿using FlexiForbesV2.Data.DataAccess;
using ServiciosLocktonTI.Administracion.NPS_DAL;
using ServiciosLocktonTI.Modelo.AltaEmpleadoBeflex;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion.AltaTitular_DAL
{
    public class AltaTitularDAL
    {
        public static RespuestaBeflex AltaTitularBeflex(ff_Empleado empleado, int IdCorporativo, int IdEmpresa)
        {
            string pathLogWsTitular = string.Format("{0}Log\\AltaBeflexLocktonOne\\pathLogWsTitular_{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            RespuestaBeflex respuestaBeflex = new RespuestaBeflex();
            EncriptacionPasswordBeflex encriptacion = new EncriptacionPasswordBeflex();
            SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                string validaciones = ValidacionCampos(empleado, IdCorporativo, IdEmpresa);

                if (validaciones == "")
                {
                    string parameters = "EMIdEmpresa,EMIdTitular,EMCertificado,EMContraseña,EMClaveAcceso,EMEdad,EMIdParentesco,EMIdRol,EMUsuarioAdd,EMFechaAntiguedadGMM,EMAntiguedadGMM,EMNumeroEmpleado,EMIdPerfil,EMIdSexo,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMFechaIngresoEmpresa,EMrfc";
                    string cadena = ObtenerPerfilRolEmpresa(IdCorporativo, IdEmpresa);

                    if(!string.IsNullOrEmpty(cadena))
                    {
                        CultureInfo ci = new CultureInfo("es-MX");

                        empleado.EMIdEmpresa = Convert.ToInt32(cadena.Split('_')[0]);
                        empleado.EMIdTitular = 1;
                        empleado.EMIdParentesco = 1;
                        empleado.EMNumeroEmpleado = empleado.EMRFC;
                        empleado.EMCertificado = ObtenerPrefijoEmpresa(IdCorporativo, IdEmpresa).ToString() +""+ empleado.EMNumeroEmpleado;
                        empleado.EMClaveAcceso = empleado.EMNumeroEmpleado;
                        empleado.EMContraseña = encriptacion.Encriptar(empleado.EMFechaNacimiento.Replace("/",""));
                        empleado.EMEdad = CalcularEdad(empleado.EMFechaNacimiento);
                        empleado.EMIdRol = Convert.ToInt32(cadena.Split('_')[1]);
                        empleado.EMIdPerfil = Convert.ToInt32(cadena.Split('_')[2]);
                        empleado.EMIdUsuarioAdd = 25;
                        empleado.EMFechaIngresoEmpresa = DateTime.Now.ToString("yyyy/MM/dd");
                        empleado.EMFechaNacimiento = Convert.ToDateTime(empleado.EMFechaNacimiento, ci).ToString("yyyy/MM/dd");

                        string values = "" + empleado.EMIdEmpresa + "," + empleado.EMIdTitular + ",'" + empleado.EMCertificado + "','" + empleado.EMContraseña + "','" + empleado.EMClaveAcceso + "'," + empleado.EMEdad + "," + empleado.EMIdParentesco + "," + empleado.EMIdRol + ",25,0,0,'" + empleado.EMNumeroEmpleado + "'," + empleado.EMIdPerfil + "," + empleado.EMIdSexo + ",'" + empleado.EMApellidoPaterno + "','" + empleado.EMApellidoMaterno + "','" + empleado.EMNombre1 + "','" + empleado.EMNombre2 + "','" + empleado.EMFechaNacimiento +"','" + empleado.EMFechaIngresoEmpresa + "','" + empleado.EMRFC+"'";
                        
                        //Valida que no se duplique el empleado en la empresa validadndo nombre y apellido paterno
                        SqlParameter[] arParms3 = new SqlParameter[7];
                        arParms3[0] = new SqlParameter("@IdEmpresa", empleado.EMIdEmpresa);
                        arParms3[1] = new SqlParameter("@ApellidoPaterno", empleado.EMApellidoPaterno);
                        arParms3[2] = new SqlParameter("@Nombre1", empleado.EMNombre1);
                        arParms3[3] = new SqlParameter("@FechaNacimiento", empleado.EMFechaNacimiento);
                        arParms3[4] = new SqlParameter("@IdTitular", empleado.EMIdTitular.ToString());
                        arParms3[5] = new SqlParameter("@NumeroEmpleado", empleado.EMNumeroEmpleado);
                        arParms3[6] = new SqlParameter("@ApellidoMaterno", empleado.EMApellidoMaterno);


                        conn.Open();
                        SqlDataReader myReader1 = SqlHelper.ExecuteReader(conn, CommandType.StoredProcedure, "ff_CValidaDuplicadoEmpleadoNAP", arParms3);
                        if (myReader1.Read())
                        {
                            respuestaBeflex.Mensaje = "El nombre y apellidos de empleado ya se encuentra en la base de datos.";
                            respuestaBeflex.Respuesta = false;
                            respuestaBeflex.EMIdEmpleado = ObtenerEmpleado(IdCorporativo, IdEmpresa, empleado.EMRFC);
                            myReader1.Close();
                        }
                        else
                        {
                            conn.Close();

                            SqlParameter[] arParms = new SqlParameter[3];
                            arParms[0] = new SqlParameter("@Sql", parameters);
                            arParms[1] = new SqlParameter("@Sqlvalues", values);
                            arParms[2] = new SqlParameter("@IdEmpresa", empleado.EMIdEmpresa);

                            conn.Open();

                            SqlDataReader myReader2 = SqlHelper.ExecuteReader(conn, CommandType.StoredProcedure, "ff_IInsertaAltaTitulares", arParms);
                            if (myReader2.Read())
                            {
                                respuestaBeflex.Mensaje = "Se dio de alta correcatmente el titular.";
                                respuestaBeflex.Respuesta = true;
                                respuestaBeflex.EMIdEmpleado = Convert.ToInt32(myReader2["id"].ToString());
                            }
                        }
                    }
                    else
                    {
                        respuestaBeflex.Mensaje = "No hay una configuracion para el Idcorporativo e IdEmpresa proporcionado.";
                        respuestaBeflex.Respuesta = false;
                    }
                }
                else
                {
                    respuestaBeflex.Mensaje = validaciones;
                    respuestaBeflex.Respuesta = false;
                }

            }
            catch (Exception e)
            {
                respuestaBeflex.Mensaje = e.Message;
                respuestaBeflex.Respuesta = false;
                LogNPS.EscribirArchivo(string.Format("Mensaje: {0}, StackTrace: {1}", e.Message, e.StackTrace), pathLogWsTitular);
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }

            return respuestaBeflex;
        }

        public static int ObtenerEmpleado(int IdCorporativo, int IdEmpresa, string RFC)
        {
            string pathLogWsAltaBF = string.Format("{0}Log\\AltaBeflexLocktonOne\\pathLogWsAltaTitularBF_{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            int IdEmpleado = 0;
            SqlConnection conn2 = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            DataTable dtPrefijoEmpresa = new DataTable();
            try
            {
                SqlParameter[] param = {
                                            new SqlParameter("@IdCorporativo", IdCorporativo),
                                            new SqlParameter("@IdEmpresa",IdEmpresa),
                                            new SqlParameter("@RFC",RFC)
                                };
                conn2.Open();
                dtPrefijoEmpresa = SqlHelper.ExecuteDataset(conn2, CommandType.StoredProcedure, "bf_ObtenerEmpleadoLocktonOne", param).Tables[0];
                IdEmpleado = Convert.ToInt32(dtPrefijoEmpresa.Rows[0]["EMIdEmpleado"]);

            }
            catch (Exception e)
            {
                LogNPS.EscribirArchivo(string.Format("Mensaje: {0}, StackTrace: {1}", e.Message, e.StackTrace), pathLogWsAltaBF);
            }
            finally
            {
                conn2.Close();
                conn2.Dispose();
            }
            return IdEmpleado;
        }

        public static string ObtenerPerfilRolEmpresa(int IdCorporativo, int IdEmpresa)
        {
            string pathLogWsAltaBF = string.Format("{0}Log\\AltaBeflexLocktonOne\\pathLogWsAltaTitularBF_{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            string idEmpresa = "", idRol = "", idPerfil = "",resultado = "";
            SqlConnection conn2 = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            DataTable dtPrefijoEmpresa = new DataTable();
            try
            {
                SqlParameter[] param = {
                                            new SqlParameter("@IdCorporativo", IdCorporativo),
                                            new SqlParameter("@IdEmpresa",IdEmpresa)
                                };
                conn2.Open();
                dtPrefijoEmpresa = SqlHelper.ExecuteDataset(conn2, CommandType.StoredProcedure, "bf_ObtenerEmpresaRolLocktonOne", param).Tables[0];
                idRol = dtPrefijoEmpresa.Rows[0]["CEIdRolBF"].ToString();
                idEmpresa = dtPrefijoEmpresa.Rows[0]["CEIdEmpresaBF"].ToString();
                idPerfil = dtPrefijoEmpresa.Rows[0]["CEIdPerfilBF"].ToString();

                if (string.IsNullOrEmpty(idRol))
                    resultado = null;
                else
                    resultado = idEmpresa + "_" + idRol + "_" + idPerfil;
            }
            catch (Exception e)
            {
                LogNPS.EscribirArchivo(string.Format("Mensaje: {0}, StackTrace: {1}", e.Message, e.StackTrace), pathLogWsAltaBF);
            }
            finally
            {
                conn2.Close();
                conn2.Dispose();
            }
            return resultado;
        }

        public static string ObtenerPrefijoEmpresa(int IdCorporativo, int IdEmpresa)
        {
            string pathLogWsAltaBF = string.Format("{0}Log\\AltaBeflexLocktonOne\\pathLogWsAltaTitularBF_{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            string PrefijoEmpresa = "";
            SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            DataTable dtPrefijoEmpresa = new DataTable();
            try
            {
                SqlParameter[] param = {
                new SqlParameter("@IdCorporativo", IdCorporativo),
                new SqlParameter("@IdEmpresa",IdEmpresa)
            };

                dtPrefijoEmpresa = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "bf_ObtenerPrefijoEmpresaLocktonOne", param).Tables[0];
                PrefijoEmpresa = dtPrefijoEmpresa.Rows[0]["EMPrefijo"].ToString();
            }
            catch (Exception e)
            {
                LogNPS.EscribirArchivo(string.Format("Mensaje: {0}, StackTrace: {1}", e.Message, e.StackTrace), pathLogWsAltaBF);
            }
            return PrefijoEmpresa;
        }

        private static string GenerarNumeroEmpleado(int IdCorporativo, int IdEmpresa)
        {
            string pathLogWsAltaBF = string.Format("{0}Log\\AltaBeflexLocktonOne\\pathLogWsAltaTitularBF_{1}.txt", System.AppDomain.CurrentDomain.BaseDirectory, DateTime.Now.ToString("ddMMyyyy"));
            string NumeroEmpleado = "";
            SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            DataTable dtNumeroEmpleado = new DataTable();
            try
            {
                SqlParameter[] param = {
                new SqlParameter("@IdCorporativo", IdCorporativo),
                new SqlParameter("@IdEmpresa",IdEmpresa)
            };

                dtNumeroEmpleado = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "bf_ObtenerNumeroEmpleadoLocktonOne", param).Tables[0];

                int nEmpleado = Convert.ToInt32(dtNumeroEmpleado.Rows[0]["EMNumeroEmpleado"]);
                NumeroEmpleado = "" + (nEmpleado + 1);
            }
            catch (Exception e)
            {
                LogNPS.EscribirArchivo(string.Format("Mensaje: {0}, StackTrace: {1}", e.Message, e.StackTrace), pathLogWsAltaBF);
            }
            return NumeroEmpleado;
        }

        public static int CalcularEdad(string FechaNacimiento)
        {
            CultureInfo ci = new CultureInfo("es-MX");
            DateTime fechaNacimiento = Convert.ToDateTime(FechaNacimiento, ci);

            var hoy = DateTime.Today;
            int edad = hoy.Year - fechaNacimiento.Year;
            if (fechaNacimiento.Date > hoy.AddYears(-edad))
                edad--;

            return edad;
        }

        public static string ValidacionCampos(ff_Empleado _Empleado, int _IdCorporativo, int _IdEmpresa)
        {
            string mensaje = "";

            if(_IdCorporativo == 0 || _IdCorporativo == null)
                mensaje += "El campo IdCorporativo es obligatorio. ";
            if (_IdEmpresa == 0 || _IdEmpresa == null)
                mensaje += "El campo IdEmpresa es obligatorio. ";
            if (string.IsNullOrEmpty(_Empleado.EMNombre1))
                mensaje += "El campo EMNombre1 es obligatorio. ";
            if (string.IsNullOrEmpty(_Empleado.EMFechaNacimiento))
                mensaje += "El campo EMFechaNacimiento es obligatorio. ";
            if (_Empleado.EMIdSexo == null || _Empleado.EMIdSexo == 0)
                mensaje += "El campo EMIdSexo es obligatorio. ";
            if (string.IsNullOrEmpty(_Empleado.EMFechaNacimiento))
                mensaje += "El campo EMFechaNacimiento es obligatorio. ";
            if (string.IsNullOrEmpty(_Empleado.EMRFC))
                mensaje += "El campo EMRFC es obligatorio. ";

            return mensaje;
        }
    }
}