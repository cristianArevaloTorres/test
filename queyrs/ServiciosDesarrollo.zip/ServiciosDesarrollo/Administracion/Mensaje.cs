﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    [DataContract]
    public class Mensaje
    {
        private int id;
        private string descripcion;
        private string detalle;

        [DataMember]
        public string Detalle
        {
            get
            {
                return this.detalle;
            }
            set
            {
                this.detalle = value;
            }
        }

        [DataMember]
        public string Descripcion
        {
            get
            {
                return this.descripcion;
            }
            set
            {
                this.descripcion = value;
            }
        }

        [DataMember]
        public int Id
        {
            get
            {
                return this.id;
            }
            set
            {
                this.id = value;
            }
        }
    }
}