﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using FlexiForbesV2.Data.DataAccess;
using System.Collections.Generic;

namespace ServiciosLocktonTI.Administracion
{
    public class BaseDatos
    {
        #region Ws_Documentos

        public static DataTable InsertaFolioDocumento(int aIdOrigen, string aPathLog)
        {
            DataTable dtFolioDocumento = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = { new SqlParameter("@UsuarioAdd", aIdOrigen) };
                dtFolioDocumento = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_InsertaFolioDocumento", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }

            return dtFolioDocumento;
        }

        public static void InsertaDetalleFolioDocumento(int aIdFolio, Documento aDocumento, int aIdEstatus, string aMensaje, int aIdOrigen, string aPathLog)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdFolio", aIdFolio),
                                           new SqlParameter("@NombreArchivo", aDocumento.Nombre),
                                           //new SqlParameter("@BytesArchivo", Convert.ToBase64String(aDocumento.Archivo)),
                                           new SqlParameter("@IdSeccion", (int)aDocumento.Seccion),
                                           new SqlParameter("@IdTipoNegocio", (int)aDocumento.TipoNegocio),
                                           new SqlParameter("@Estatus", aIdEstatus),
                                           new SqlParameter("@MensajeArchivo", aMensaje),
                                           new SqlParameter("@UsuarioAdd", aIdOrigen)
                                       };
                SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_InsertaDatosDocumento", param);
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
        }

        public static DataTable ObtenerEmpleadoPorNumeroEmpleado(int aIdEmpresa, string aNumeroEmpleado, string aPathLog)
        {
            DataTable dtEmpleado = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdEmpresa", aIdEmpresa),
                                           new SqlParameter("@NumeroEmpleado", aNumeroEmpleado)
                                       };
                dtEmpleado = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ObtenerEmpleadoXNumSinEstatus", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }

            return dtEmpleado;
        }

        public static DataTable ObtenerSeccionPorId(int aIdSeccionDocumento, string aPathLog)
        {
            DataTable dtSeccion = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdSeccionDocumento", aIdSeccionDocumento)
                                       };
                dtSeccion = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_GetSeccionDocumento", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }

            return dtSeccion;
        }

        public static DataTable ObtenerVigenciaPorTipoNegocio(int aIdEmpresa, int aIdTipoNegocio, string aPathLog)
        {
            DataTable dtVigencia = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@aIdEmpresa", aIdEmpresa),
                                           new SqlParameter("@IdTipoNegocio", aIdTipoNegocio)
                                       };
                dtVigencia = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ObtenerVigenciaPorTipoNegocio", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }

            return dtVigencia;
        }

        public static DataTable InsertarEmpleadoDocumento(int aIdOrigen, string aIdEmpleado, string aIdSeccion, string aIdVigencia, string aNombreDocumento, string aRutaDocumento, string aPathLog)
        {
            DataTable dtDocumento = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdEmpleado", aIdEmpleado),
                                           new SqlParameter("@idSeccionDocumento", aIdSeccion),
                                           new SqlParameter("@IdVigencia", aIdVigencia),
                                           new SqlParameter("@NombreDocumento", aNombreDocumento),
                                           new SqlParameter("@RutaDocumento", aRutaDocumento),
                                           new SqlParameter("@idAdmin", aIdOrigen)
                                       };
                dtDocumento = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_InsertaEmpleadoDocumento", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }

            return dtDocumento;
        }

        public static DataTable ObtenerDetalleFolioDocumentos(int  aIdFolio, string aPathLog)
        {
            DataTable dtVigencia = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {new SqlParameter("@IdFolio", aIdFolio)};
                dtVigencia = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ObtenerDetalleFolioDocumentos", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }

            return dtVigencia;
        }

        public static void ActualizarFolioDocumentosEstatus(int aIdFolio, int aIdEstatus, int aIdOrigen, string aPathLog)
        {

            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdFolio", aIdFolio),
                                           new SqlParameter("@IdEstatus", aIdEstatus),
                                           new SqlParameter("@UsuarioMod", aIdOrigen)
                                       };
                SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ActualizarFolioDocumentosEstatus", param);
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }


        }

        public static DataTable ValidaEntradaWSdocumentos(int aIdOrigen, int aIdEmpresa, string aContraseña, string aPathLog)
        {
            DataTable dtDatosprovedor = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@aIdOrigen", aIdOrigen),
                                           new SqlParameter("@aIdEmpresa", aIdEmpresa),
                                           new SqlParameter("@aContraseña", aContraseña)
                                       };
                dtDatosprovedor = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ValidaEntradaWSdocumentos", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }

            return dtDatosprovedor;
        }

        #region MantenimientosDocuemntos
        public static void InsertaAseguradoporDocumento(int ADIdDocumento, int ADIdEmpleado, string ADNumeroEmpleado, string ADNombre1, string ADNombre2, string ADApellidoPaterno, string ADApellidoMaterno, int ADIdParentesco, string aPathLog)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@ADIdDocumento", ADIdDocumento),
                                           new SqlParameter("@ADIdEmpleado", ADIdEmpleado),
                                           new SqlParameter("@ADNumeroEmpleado",ADNumeroEmpleado),
                                           new SqlParameter("@ADNombre1", ADNombre1),
                                           new SqlParameter("@ADNombre2", ADNombre2),
                                           new SqlParameter("@ADApellidoPaterno", ADApellidoPaterno),
                                           new SqlParameter("@ADApellidoMaterno", ADApellidoMaterno),
                                           new SqlParameter("@ADIdParentesco", ADIdParentesco)
                                       };
                SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_InsertaAseguradosporDocumento", param);
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
        }
        public static DataSet ConsultaDatosDocumentos(int IdEmpresa, string NumeroEmpleado, string aPathLog)
        {
            DataSet ds = new DataSet();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            SqlCommand command = cn.CreateCommand();
            try
            {
                try
                {
                    cn.Open();
                    SqlParameter[] param = { new SqlParameter("@IdEmpresa", IdEmpresa),
                                           new SqlParameter("@NumeroEmpleado", NumeroEmpleado)};
                    ds = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ConsultaDatosDocumentos", param);
                 
                }
                finally
                {
                    cn.Close();
                    cn.Dispose();
                }
                return ds;
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
                return ds;
            }
        }
        public static DataTable EliminaDocumento(int IdEmpresa, string IdDocumento, int IdOrigen, string aPathLog)
        {
            DataTable ds = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            SqlCommand command = cn.CreateCommand();
            try
            {
                try
                {
                    cn.Open();
                    SqlParameter[] param = {
                                            new SqlParameter("@IdEmpresa", IdEmpresa),
                                            new SqlParameter("@IdDocumento", IdDocumento),
                                            new SqlParameter("@IdOrigen", IdOrigen)


                    };
                    ds = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_EliminaDocumento", param).Tables[0];
                }
                finally
                {
                    cn.Close();
                    cn.Dispose();
                }

                return ds;
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
                return ds;
            }
        }
        public static int EliminaAseguradospordocumento(string NombreDocumento, int ADIdEmpleado, int IdOrigen, string aPathLog)
        {
            int resultado = 0;
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            SqlCommand command = cn.CreateCommand();
            try
            {
                try
                {
                    cn.Open();
                    SqlParameter[] param = { new SqlParameter("@NombreDocumento", NombreDocumento),
                                           new SqlParameter("@ADIdEmpleado", ADIdEmpleado) ,
                                            new SqlParameter("@IdOrigen", IdOrigen)
                    };
                    resultado = int.Parse(SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_EliminaAseguradospordocumento", param).Tables[0].Rows[0]["RESPUESTA"].ToString());
                }
                finally
                {
                    cn.Close();
                    cn.Dispose();
                }
                return resultado;
            }
            catch (Exception aE)
            {

                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
                return resultado;

            }
        }
        /// Alterar para  que regrese  un  entero  IdDocumento 
        public static int InsertaDetalleFolioDocumentoDetalleIdDocumento(int aIdFolio, Documento aDocumento, int aIdEstatus, string aMensaje, int aIdOrigen, string aPathLog)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            int resultado = 0;
            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdFolio", aIdFolio),
                                           new SqlParameter("@NombreArchivo", aDocumento.Nombre),
                                           new SqlParameter("@IdSeccion", (int)aDocumento.Seccion),
                                           new SqlParameter("@IdTipoNegocio", (int)aDocumento.TipoNegocio),
                                           new SqlParameter("@Estatus", aIdEstatus),
                                           new SqlParameter("@MensajeArchivo", aMensaje),
                                           new SqlParameter("@UsuarioAdd", aIdOrigen)
                                       };
                resultado = int.Parse(SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_InsertaDatosDocumentoDetalle", param).Tables[0].Rows[0]["Resultado"].ToString());
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return resultado;

        }
        public static int ConsultaAdministradorporProcesos(int IdOrigen)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            int resultado = 0;
            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdOrigen", IdOrigen),

                                       };
                resultado = int.Parse(SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ConsultaAdministradorporProcesos", param).Tables[0].Rows[0]["Resultado"].ToString());
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return resultado;

        }
        public static DataTable ConsultaIdPrentescoIniciofin(string aPathLog) 
        {
            DataTable Respueta = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                cn.Open();
                Respueta = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ConsultaIdPrentescoIniciofin").Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return Respueta;
        
        }
        #endregion
        #endregion
        
        #region WsDescuentos
        public static DataSet WSDescuentosSMNYL(int aIdEmpresa, string aPathLog)
        {
            EscribirArchivo("Inicia QUERY", aPathLog);

            DataSet ds = new DataSet();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            SqlCommand command = cn.CreateCommand();
            try
            {
                try
                {
                    cn.Open();
                    SqlParameter[] param = { new SqlParameter("@aIdEmpresa", aIdEmpresa) };
                    ds = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ConsultaDescuentos", param);
                    EscribirArchivo("fin DataSet", aPathLog);
                }
                finally
                {
                    command.CommandTimeout = 30;
                    EscribirArchivo("FinTimeOut", aPathLog);
                    cn.Close();
                    cn.Dispose();
                }

                return ds;
            }
            catch (Exception aE)
            {

                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
                return ds;
            }
        }
        public static DataTable ConsultaFTP(int aIdEmpresa, string aPathLog)
        {
            DataTable dtftp = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                cn.Open();
                SqlParameter[] param = { new SqlParameter("@aIdEmpresa", aIdEmpresa) };
                dtftp = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ConsultaWSConfiguracionftp", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return dtftp;
        }
        public static int InsertaEstatusWSBitacoraFtp(string NombreArchivo, int IdEstatus, string Descripccion, string Carpeta, string Servidor, int IdEmpresa, string aPathLog)
        {
            EscribirArchivo("Inserta  en bitácora", aPathLog);
            int resultado = 0;
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                try
                {
                    cn.Open();
                    SqlParameter[] param = {
                                   new SqlParameter("@NombreArchivo", NombreArchivo),
                                   new SqlParameter("@IdEstatus", IdEstatus),
                                   new SqlParameter("@Descripccion", Descripccion),
                                   new SqlParameter("@Carpeta", Carpeta),
                                   new SqlParameter("@Servidor", Servidor),
                                   new SqlParameter("@IdEmpresa", IdEmpresa)
                                   };
                    resultado = int.Parse(SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_InsertaEstatusWSBitacoraFtp", param).Tables[0].Rows[0]["Resultado"].ToString());
                }
                finally
                {
                    cn.Close();
                    cn.Dispose();
                }
                return resultado;
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
                return resultado;
            }
        }
        public static void ActualizaEstatusWSBitacoraFtp(int IdWSBitacoraFtp, int IdEstatus, string Descripccion, string aPathLog)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdWSBitacoraFtp", IdWSBitacoraFtp),
                                           new SqlParameter("@IdEstatus", IdEstatus),
                                           new SqlParameter("@Descripccion",Descripccion),

                                       };
                SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ActualizaEstatusWSBitacoraFtp", param);
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("Mensaje: {0} Trace: {1}", aE.Message, aE.StackTrace), aPathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
        }
        #endregion

        public static int ActualizaDocumentoRemplazado(int aIdEmpleado, string aNombreDocumento, string aRutaDocumento, int IdOrigen)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            int resultado = 0;
      
            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@IdEmpleado", aIdEmpleado),
                                           new SqlParameter("@NombreDocumento", aNombreDocumento),
                                           new SqlParameter("@RutaDocumento", aRutaDocumento),
                                           new SqlParameter("@idAdmin", IdOrigen)
                                       };
                resultado = int.Parse(SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ActualizaDocumentoRemplazado", param).Tables[0].Rows[0]["Total"].ToString());

            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return resultado;

        }

        #region Tickets

        public static DataTable ObtenerHistoricoNotificacionesTickets(List<int> aIdsTipoNotificacion, int aIdEmpresa, string pathLog)
        {
            DataTable ds = new DataTable();
            DataTable dtIdsTipoNotificacion = new DataTable();
            dtIdsTipoNotificacion.Columns.Add("IdTipoNotificacionCorreo");
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();

                foreach (int idTipoNotificacion in aIdsTipoNotificacion)
                    dtIdsTipoNotificacion.Rows.Add(idTipoNotificacion);

                SqlParameter[] param = {

                                   new SqlParameter("@IdsTipoNotificacion", dtIdsTipoNotificacion),
                                   new SqlParameter("@aIdEmpresa", aIdEmpresa)
                                   };

                ds = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ObtenerHistoricoNotificacionesTickets", param).Tables[0];
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("ObtenerHistoricoNotificacionesTickets: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }

            return ds;
        }

        public static DataTable ObtenerHistoricoNotificacionesTicketsporFecha(int IdEmpresa, DateTime FechaInicio, DateTime FechaFinal, string pathLog)
        {
            DataTable dtTickets = new DataTable();


            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                cn.Open();
                SqlParameter[] param = {
                                new SqlParameter("@aIdEmpresa", IdEmpresa),
                                new SqlParameter("@fechaInicio", FechaInicio),
                                new SqlParameter("@fechaFinal", FechaFinal),
                                       };
                dtTickets = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ObtenerHistoricoNotificacionesTicketsporFecha", param).Tables[0];

            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("ObtenerHistoricoNotificacionesTicketsporFecha: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return dtTickets;

        }

        public static DataTable ObtenerHistoricoNotificacionesTicketsporFechaporCorporativo(int IdEmpresa, DateTime FechaInicio, DateTime FechaFinal, string pathLog)
        {
            DataTable dtTickets = new DataTable();


            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                cn.Open();
                SqlParameter[] param = {
                                new SqlParameter("@aIdEmpresa", IdEmpresa),
                                new SqlParameter("@fechaInicio", FechaInicio),
                                new SqlParameter("@fechaFinal", FechaFinal),
                                       };
                dtTickets = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ObtenerHistoricoNotificacionesTicketsporFechaporCorporativo", param).Tables[0];

            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format("bf_ObtenerHistoricoNotificacionesTicketsporFechaporCorporativo: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return dtTickets;

        }

        #endregion

        public static DataTable RecuperaId(string Numemp)
        {
            DataTable Id =new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                cn.Open();
                SqlParameter[] param = { new SqlParameter("@ClaveEmpleado", Numemp)   };
                Id = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ConsultaIdMobile", param).Tables[0];
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return Id;
        }

        public static string ConsultaPassword(int IdEmpleado)
        {
            string result = string.Empty;


            DataSet reader = new DataSet();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                cn.Open();
                SqlParameter[] param = { new SqlParameter("@IdEmpleado", IdEmpleado) };
                reader = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ConsultaPassword", param);
                result = (reader.Tables[0].Rows.Count > 0) ? reader.Tables[0].Rows[0][0].ToString() : string.Empty;
            }
            catch (Exception aE)
            {
                
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return result;

        }

        public static int  AccesoMobile(int IdEmpleado,int RecalculaTarifa,int  CampoPassIni, string strContrasena)
        {
            int respuesta = 0;
            string  result = string.Empty;

        

            DataSet reader = new DataSet();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                Beflex.Crypto encripta = new Beflex.Crypto();
                if (RecalculaTarifa == 1 )

                {
                    cn.Open();
                    SqlParameter[] param = { new SqlParameter("@IdEmpleado", IdEmpleado) };
                    reader = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "Get_DefaultPassXIdEmpleado", param);
                    result = reader.Tables[0].Rows[0][0].ToString().ToUpper();
                    if (encripta.Encriptar(result.Trim()).Equals(strContrasena)) 
                        respuesta = IdEmpleado; 
                }
                else 
                {
                    string pass = ConsultaPassword(IdEmpleado);
                    if (strContrasena.Equals(pass)) 
                        respuesta = IdEmpleado;
                }
               
            }
            catch (Exception aE)
            {
               
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return respuesta;

        }


        public static DataSet LoginB(string strEmpleado, int strContrasena) 
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                cn.Open();
                SqlParameter[] param = {   new SqlParameter("@ClaveEmpleado", strEmpleado),
                                           new SqlParameter("@Contrasena", strContrasena),
                                       };
                ds = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_MobileDatosEmpleado", param);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
                return ds;
        }

        public static DataSet ConsultaPanelEmpleados(string IdEmpresa, string User, string Pws, string NumeroEmpleado,string pathLog)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                cn.Open();
                SqlParameter[] param = {   new SqlParameter("@IdEmpresa", IdEmpresa),
                                           new SqlParameter("@User", User),
                                           new SqlParameter("@Pws", Pws),
                                           new SqlParameter("@NumeroEmpleado", NumeroEmpleado),
                                       };
                ds = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_ConsultaPanelEmpleados", param);
            }
            catch (Exception ex)
            {
                Negocio.EscribirArchivo(ex.Message + "\n" + ex.StackTrace.ToString(), pathLog);
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return ds;
        }
        public static DateTime ActualizacionEmpleadoB(string numeroEmpleado)
        {
            DateTime time  = new DateTime();
            DataTable ds = new DataTable();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);

            try
            {
                cn.Open();
                SqlParameter[] param = {
                                           new SqlParameter("@ClaveEmpleado", numeroEmpleado)
                                       };
                ds = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "bf_MobileObtineFechaActualizacionEmpleado", param).Tables[0];
                time  = DateTime.Parse(ds.Rows[0][0].ToString());
            }
            finally
            {
                cn.Close();
                cn.Dispose();
            }
            return time;
   
        }
        public static void EscribirArchivo(string contenido, string ruta)
        {
            FileInfo archivo = new FileInfo(ruta);
            StreamWriter documento;
            if (!archivo.Exists)
            {
                Directory.CreateDirectory(archivo.Directory.FullName);
                documento = new StreamWriter(archivo.FullName, false, System.Text.Encoding.UTF8);
            }
            else
                documento = archivo.AppendText();

            documento.WriteLine(string.Format("{0} {1}", contenido, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
            documento.Flush();
            documento.Close();
        }


        public  DataSet _Cobranza(string idEmpresa, string idTipoSolicitud, string FechaIni, string FechaFin, string idVencida, string pathLog)
        {
            DataSet dtReporte = new DataSet();
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            SqlCommand command = cn.CreateCommand();
            string strParamentros = "";
            try
            {
                cn.Open();
                SqlParameter[] ps =
                               {
                                     new SqlParameter("@idEmpresa", idEmpresa),
                                        new SqlParameter("@idSolTipo", idTipoSolicitud),
                                        new SqlParameter("@FecIni", FechaIni),
                                        new SqlParameter("@FecFin", FechaFin),
                                        new SqlParameter("@idVencida", idVencida)
                                   };

                foreach (SqlParameter param in ps)
                {
                    if (string.IsNullOrEmpty(strParamentros))
                    {
                        try
                        {
                            strParamentros = param.Value.ToString();
                        }
                        catch (Exception aE)
                        {
                            EscribirArchivo(string.Format("Servicio Web: Error  en  parametro : {0} Trace: {1}", aE.Message, aE.StackTrace), pathLog);

                        }
                    }
                    else
                    {
                        strParamentros += "," + param.Value.ToString();
                    }
                }
                EscribirArchivo("Servicio Web: Se invoca el stored ObtenCobranzaConcentrada con los parametros (" + strParamentros + ")", pathLog);
                command.CommandTimeout = 32767;
                dtReporte = SqlHelper.ExecuteDataset(cn, CommandType.StoredProcedure, "ObtenCobranzaConcentrada", ps);
            }
            catch (Exception aE)
            {
                EscribirArchivo(string.Format(" Servicio Web ObtenCobranzaConcentrada: {0} Trace: {1}", aE.Message, aE.StackTrace), pathLog);
                EscribirArchivo(" Servicio Web Se invoca el stored ObtenCobranzaConcentrada con los parametros (" + strParamentros + ")", pathLog);
            }
            finally
            {
               
                EscribirArchivo(" Servicio Web FinTimeOut", pathLog);
                cn.Close();
                cn.Dispose();
            }


            return dtReporte;
        }

    }
}