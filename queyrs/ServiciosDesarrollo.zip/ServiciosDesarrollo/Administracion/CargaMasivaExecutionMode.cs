﻿namespace ServiciosLocktonTI.Administracion
{
    public enum CargaMasivaExecutionMode
    {
        ExecuteToFirstError,
        ExecuteAll,
    }
}