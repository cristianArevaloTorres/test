﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    public class Ticket
    {
        public enum TTEEstatus
        {
            NoEspecificado = 0,
            Exitoso = 1,
            NoDisponible = 2,
            CredencialesNoValidas = 3,
            FueraDeHorario = 4,
            PropiedadesRequeridas = 5
        }
       
        private int id;
        private string descripcion;
        private Tipo segmento;
        private Tipo estatus;
        private List<Seguimiento> seguimientos;
        private string ttdescripcion;
        private TTEEstatus ttestatus;

        public List<Seguimiento> Seguimientos
        {
            get { return seguimientos; }
            set { seguimientos = value; }
        }
        private List<Archivo> archivos;

        public List<Archivo> Archivos
        {
            get { return archivos; }
            set { archivos = value; }
        }

        public Tipo Estatus
        {
            get { return estatus; }
            set { estatus = value; }
        }

        public Tipo Segmento
        {
            get { return segmento; }
            set { segmento = value; }
        }

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        private string asegurado;

        public string Asegurado
        {
            get { return asegurado; }
            set { asegurado = value; }
        }

        private string contacto;

        public string Contacto
        {
            get { return contacto; }
            set { contacto = value; }
        }

        private string telefono1;

        public string Telefono1
        {
            get { return telefono1; }
            set { telefono1 = value; }
        }

        private string telefono2;

        public string Telefono2
        {
            get { return telefono2; }
            set { telefono2 = value; }
        }

        private string hospital;

        public string Hospital
        {
            get { return hospital; }
            set { hospital = value; }
        }

        private string correoelectronico;

        public string Correoelectronico
        {
            get { return correoelectronico; }
            set { correoelectronico = value; }
        }

        private string clave;

        public string Clave
        {
            get { return clave; }
            set { clave = value; }
        }

        private DateTime fechaAdd;

        public DateTime FechaAdd
        {
            get { return fechaAdd; }
            set { fechaAdd = value; }
        }

        private Tipo tipoSolicitud;

        public Tipo TipoSolicitud
        {
            get { return tipoSolicitud; }
            set { tipoSolicitud = value; }
        }

      
        public string TTDescripcion
        {
            get { return ttdescripcion; }
            set { ttdescripcion = value; }
        }

      

        public TTEEstatus TTEstatus
        {
            get { return ttestatus; }
            set { ttestatus = value; }
        }

    }
    public class Tipo
    {
        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        private string nombre;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
    }
    public class Archivo
    {
        private int id;
        private string ruta;
        private string nombre;
        private byte[] document;

        public byte[] Document
        {
            get { return document; }
            set { document = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string Ruta
        {
            get { return ruta; }
            set { ruta = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
    }
    public class Etapa
    {
        private int idetapa;

        public int Idetapa
        {
            get { return idetapa; }
            set { idetapa = value; }
        }
        private string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }
        private string responsable;

        public string Responsable
        {
            get { return responsable; }
            set { responsable = value; }
        }
        private string responsableCorreo;

        public string ResponsableCorreo
        {
            get { return responsableCorreo; }
            set { responsableCorreo = value; }
        }
    }
    public class Seguimiento
    {
        private int id;
        private string observacion;
        private Etapa etapa;
        private DateTime seguimientoFechaAdd;

        public DateTime SeguimientoFechaAdd
        {
            get { return seguimientoFechaAdd; }
            set { seguimientoFechaAdd = value; }
        }

        public Etapa Etapa
        {
            get { return etapa; }
            set { etapa = value; }
        }

        public string Observacion
        {
            get { return observacion; }
            set { observacion = value; }
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
    }
  
}