﻿using FlexiForbesV2.Data.DataAccess;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    public class CommonBD
    {
        public DataSet ExecuteStoredProcedure(
    SqlParameter[] sqlParams,
    string storedProcedureName,
    string validator)
        {
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]))
            {
                try
                {
                    connection.Open();
                    return SqlHelper.ExecuteDataset(connection, CommandType.StoredProcedure, storedProcedureName, sqlParams);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }
            }
        }
    }
}