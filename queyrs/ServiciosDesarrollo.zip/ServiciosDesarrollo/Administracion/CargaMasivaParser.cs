﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;


namespace ServiciosLocktonTI.Administracion
{
    public class CargaMasivaParser
    {
        private bool _validDocument;
        private string _logStr;
        private string _register;
        private CargaMasivaDocumento _documento;
        private Plantilla _plantilla;

        public CargaMasivaParser(Plantilla plantilla, CargaMasivaDocumento documento)
        {
            if (plantilla == null || documento == null)
                throw new ArgumentNullException("La plantilla y el documento no pueden ser nulos.");
            this._plantilla = plantilla;
            this._documento = documento;
            this._logStr = "";
            this._validDocument = false;
        }

        public CargaMasivaParser(Plantilla plantilla)
        {
            if (plantilla == null)
                throw new ArgumentNullException("La plantilla no puede ser nula.");
            this._plantilla = plantilla;
            this._logStr = "";
            this._validDocument = false;
        }

        private bool CheckFieldNames()
        {
            bool flag = true;
            ArrayList arrayList = ArrayList.Adapter((IList)this._documento.FieldNames);
            foreach (string name in this._plantilla.Campos.Names)
            {
                if (!arrayList.Contains((object)name.Trim()))
                {
                    this._logStr += string.Format("[{0}][linea {1}]: La plantilla define el campo '{2}', el cual no esta incluido en el documento de datos.", (object)DateTime.Now.ToLongTimeString(), (object)this._documento.CurrentLine, (object)name);
                    flag = false;
                }
            }
            return flag;
        }

        public bool NextRegister()
        {
            this._logStr = "";
            if (!this._validDocument)
                return false;
            this._register = this._documento.NextRegister();
            return this._register != null;
        }

        public bool Initialize()
        {
            this._logStr = "";
            this._validDocument = this.CheckFieldNames();
            return this._validDocument;
        }

        public string GetLastError()
        {
            string logStr = this._logStr;
            this._logStr = "";
            return logStr;
        }

        public new void Finalize()
        {
            this._plantilla = (Plantilla)null;
            this._documento = (CargaMasivaDocumento)null;
            this._validDocument = false;
        }

        public CargaMasivaParsingResult Parse(out ArrayList spParam)
        {
            if (!this._validDocument || this._register == null || this._register.Equals(""))
                throw new InvalidOperationException("El documento de datos o el registro a convertir no es válido.");
            char ch = '|';
            string[] fieldNames = this._documento.FieldNames;
            string[] strArray = this._register.Split(ch);
            SortedList sortedList = new SortedList();
            ArrayList arrayList = new ArrayList();
            spParam = (ArrayList)null;
            if (fieldNames.Length != strArray.Length)
            {
                this._logStr += string.Format("[{0}][linea {1}][registro {2}]: Número insuficiente de parámetros en el actual registro.", (object)DateTime.Now.ToLongTimeString(), (object)this._documento.CurrentLine, (object)this._documento.RegisterCount);
                return CargaMasivaParsingResult.FieldValueCountError;
            }
            for (int index = 0; index < fieldNames.Length; ++index)
                sortedList.Add((object)fieldNames[index], (object)strArray[index]);
            foreach (DictionaryEntry campo in (DictionaryBase)this._plantilla.Campos)
            {
                PlantillaCampoItem plantillaCampoItem = (PlantillaCampoItem)campo.Value;
                if (plantillaCampoItem.Validate((string)sortedList[(object)plantillaCampoItem.Nombre]))
                {
                    arrayList.Add((object)new SqlParameter("@" + plantillaCampoItem.Nombre, plantillaCampoItem.Convert((string)sortedList[(object)plantillaCampoItem.Nombre])));
                }
                else
                {
                    this._logStr += string.Format("[{0}][linea {1}][registro {2}]: La validación para el valor correspondiente al campo '{3}' ha fallado por la siguiente razón: {4}", (object)DateTime.Now.ToLongTimeString(), (object)this._documento.CurrentLine, (object)this._documento.RegisterCount, (object)plantillaCampoItem.Nombre, (object)plantillaCampoItem.GetLastError());
                    return CargaMasivaParsingResult.FieldValueValidationError;
                }
            }
            spParam = arrayList;
            return CargaMasivaParsingResult.Success;
        }

        public CargaMasivaParsingResult FastParse(
          string[] documentFieldNames,
          string[] documentFieldValues,
          out ArrayList spParam)
        {
            SortedList sortedList = new SortedList();
            ArrayList arrayList = new ArrayList();
            spParam = (ArrayList)null;
            if (documentFieldNames.Length != documentFieldValues.Length)
                return CargaMasivaParsingResult.FieldValueCountError;
            for (int index = 0; index < documentFieldNames.Length; ++index)
                sortedList.Add((object)documentFieldNames[index], (object)documentFieldValues[index]);
            foreach (DictionaryEntry campo in (DictionaryBase)this._plantilla.Campos)
            {
                PlantillaCampoItem plantillaCampoItem = (PlantillaCampoItem)campo.Value;
                if (plantillaCampoItem.TipoDato == 'D')
                {
                    string[] strArray = sortedList[(object)plantillaCampoItem.Nombre].ToString().Split('-');
                    if (strArray.Length == 3)
                    {
                        if (strArray[0].Length == 4)
                            sortedList[(object)plantillaCampoItem.Nombre] = (object)(strArray[2].ToString() + "/" + strArray[1].ToString() + "/" + strArray[0].ToString());
                        else if (strArray[2].Length == 4)
                            sortedList[(object)plantillaCampoItem.Nombre] = (object)(strArray[0].ToString() + "/" + strArray[1].ToString() + "/" + strArray[2].ToString());
                    }
                }
                if (!plantillaCampoItem.Validate((string)sortedList[(object)plantillaCampoItem.Nombre]))
                    return CargaMasivaParsingResult.FieldValueValidationError;
                arrayList.Add((object)new SqlParameter("@" + plantillaCampoItem.Nombre, plantillaCampoItem.Convert((string)sortedList[(object)plantillaCampoItem.Nombre])));
            }
            spParam = arrayList;
            return CargaMasivaParsingResult.Success;
        }

        public CargaMasivaParsingResult TryParse()
        {
            ArrayList spParam = (ArrayList)null;
            CargaMasivaParsingResult masivaParsingResult;
            try
            {
                masivaParsingResult = this.Parse(out spParam);
                spParam?.Clear();
            }
            catch (Exception ex)
            {
                this._logStr += string.Format("[{0}]: Error desconocido durante la prueba de conversion: {1}", (object)DateTime.Now.ToLongTimeString(), (object)ex.Message);
                masivaParsingResult = CargaMasivaParsingResult.UnknownError;
            }
            return masivaParsingResult;
        }



        public CargaMasivaParsingResult FastParse(
   string[] documentFieldNames,
   string[] documentFieldValues,
   out ArrayList spParam,
   out Mensaje aMensaje)
        {
            SortedList sortedList = new SortedList();
            ArrayList arrayList = new ArrayList();
            spParam = (ArrayList)null;
            aMensaje = new Mensaje();
            if (documentFieldNames.Length != documentFieldValues.Length)
                return CargaMasivaParsingResult.FieldValueCountError;
            for (int index = 0; index < documentFieldNames.Length; ++index)
                sortedList.Add((object)documentFieldNames[index], (object)documentFieldValues[index]);
            foreach (DictionaryEntry campo in (DictionaryBase)this._plantilla.Campos)
            {
                PlantillaCampoItem plantillaCampoItem = (PlantillaCampoItem)campo.Value;
                if (plantillaCampoItem.TipoDato == 'D')
                {
                    string[] strArray = sortedList[(object)plantillaCampoItem.Nombre].ToString().Split('-');
                    if (strArray.Length == 3)
                    {
                        if (strArray[0].Length == 4)
                            sortedList[(object)plantillaCampoItem.Nombre] = (object)(strArray[2].ToString() + "/" + strArray[1].ToString() + "/" + strArray[0].ToString());
                        else if (strArray[2].Length == 4)
                            sortedList[(object)plantillaCampoItem.Nombre] = (object)(strArray[0].ToString() + "/" + strArray[1].ToString() + "/" + strArray[2].ToString());
                    }
                }
                string str = plantillaCampoItem.Validate_((string)sortedList[(object)plantillaCampoItem.Nombre]);
                if (string.IsNullOrEmpty(str))
                {
                    arrayList.Add((object)new SqlParameter("@" + plantillaCampoItem.Nombre, plantillaCampoItem.Convert((string)sortedList[(object)plantillaCampoItem.Nombre])));
                }
                else
                {
                    aMensaje.Detalle = string.Format("{0} para la columna {1}", (object)str, (object)(((IEnumerable<string>)documentFieldNames).ToList<string>().IndexOf(plantillaCampoItem.Nombre) + 1));
                    return CargaMasivaParsingResult.FieldValueValidationError;
                }
            }
            spParam = arrayList;
            return CargaMasivaParsingResult.Success;
        }
    }
  
}