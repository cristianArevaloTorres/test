﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace ServiciosLocktonTI.Administracion
{
    public class CargaMasivaDocumento
    {
        private const string DocumentFolder = "DocumentoEmpresa";
        private readonly CommonBusiness commonBiz;
        private bool _refreshPosition;
        private int _currentLine;
        private int _currentRegister;
        private int _idDocumento;
        private string _appRootPath;
        private string _filepath;
        private string _filename;
        private string[] _fieldNames;
        private SortedList _commonFields;
        private StreamReader _documentStream;

        public CargaMasivaDocumento(int idDocumento, string appRootPath)
        {
            this.commonBiz = new CommonBusiness();
            this._idDocumento = idDocumento;
            this._appRootPath = appRootPath;
            this._currentLine = this._currentRegister = 0;
            this.GetDocumentProperties();
        }

        public int CurrentLine
        {
            get
            {
                return this._currentLine;
            }
        }

        public int RegisterCount
        {
            get
            {
                return this._currentRegister;
            }
        }

        public string FileName
        {
            get
            {
                return this._filename;
            }
        }

        public string FilePath
        {
            get
            {
                return this._filepath;
            }
        }

        public string Text
        {
            get
            {
                if (this._documentStream == null || !this._documentStream.BaseStream.CanRead)
                    throw new InvalidOperationException("Hay un problema con el stream del documento de Carga Masiva.");
                this._refreshPosition = true;
                this._documentStream.BaseStream.Seek(0L, SeekOrigin.Begin);
                this._documentStream.DiscardBufferedData();
                return this._documentStream.ReadToEnd();
            }
            set
            {
                if (this._documentStream == null || !this._documentStream.BaseStream.CanRead)
                    throw new InvalidOperationException("Hay un problema con el stream del documento de Carga Masiva.");
                if (this._documentStream != null && this._documentStream.BaseStream.CanRead)
                    this._documentStream.Close();
             //   StreamWriter streamWriter = new StreamWriter(this._appRootPath + this._filepath + this._filename, false, Encoding.UTF8);
                //streamWriter.WriteLine(value);
                //streamWriter.Flush();
                //streamWriter.Close();
                this._documentStream = (StreamReader)null;
                this.Open();
            }
        }

        public string[] FieldNames
        {
            get
            {
                if (this._documentStream == null || !this._documentStream.BaseStream.CanRead)
                    throw new InvalidOperationException("Hay un problema con el stream del documento de Carga Masiva.");
                string[] strArray;
                if (this._commonFields != null)
                {
                    strArray = new string[this._fieldNames.Length + this._commonFields.Count];
                    this._fieldNames.CopyTo((Array)strArray, 0);
                    this._commonFields.Keys.CopyTo((Array)strArray, this._fieldNames.Length);
                }
                else
                {
                    strArray = new string[this._fieldNames.Length];
                    this._fieldNames.CopyTo((Array)strArray, 0);
                }
                return strArray;
            }
        }

        private string GetValueForKey(string key)
        {
            if (this._documentStream == null || !this._documentStream.BaseStream.CanRead)
                throw new InvalidOperationException("El stream del documento de Carga Masiva no esta disponible.");
            this._documentStream.BaseStream.Seek(0L, SeekOrigin.Begin);
            this._documentStream.DiscardBufferedData();
            this._currentLine = 0;
            string str1;
            while ((str1 = this._documentStream.ReadLine()) != null)
            {
                ++this._currentLine;
                string str2 = str1.Trim();
                if (str2.StartsWith("@"))
                {
                    if (str2.Split(':')[0].Trim().Equals("@" + key))
                        return str2.Split(':')[1].Trim();
                }
            }
            return (string)null;
        }

        private void GetDocumentProperties()
        {
            DataRow row = this.commonBiz.ExecuteStoredProcedure(new SqlParameter[1]
            {
        new SqlParameter("@idDocumento", (object) this._idDocumento)
            }, "ff_CCMDocumentoPropiedades", string.Empty).Tables[0].Rows[0];
            this._filepath = "DocumentoEmpresa" + (object)'\\' + row["DOIdEmpresa"].ToString() + (object)'\\' + row["DOCarpeta"].ToString() + (object)'\\';
            this._filename = row["DODocumento"].ToString();
        }

        private void LoadCommonFields()
        {
            if (this._documentStream == null || !this._documentStream.BaseStream.CanRead)
                throw new InvalidOperationException("El stream del documento de Carga Masiva no esta disponible.");
            switch (this.GetValueForKey("commonFields"))
            {
                case null:
                    break;
                default:
                    this._commonFields = new SortedList();
                    string str;
                    while ((str = this._documentStream.ReadLine()) != null)
                    {
                        ++this._currentLine;
                        if (!str.Trim().Equals(""))
                            this._commonFields.Add((object)str.Split('=')[0], (object)str.Split('=')[1]);
                        else
                            break;
                    }
                    if (this._commonFields.Count > 0)
                        break;
                    this._commonFields = (SortedList)null;
                    break;
            }
        }

        private void LoadSettings()
        {
            if (this._documentStream == null || !this._documentStream.BaseStream.CanRead)
                throw new InvalidOperationException("El stream del documento de Carga Masiva no esta disponible.");
            string valueForKey;
            if ((valueForKey = this.GetValueForKey("fieldNames")) == null)
                throw new ArgumentException("El documento de datos no incluye los nombres de las columnas que utliza.", "fieldNames");
            this._fieldNames = valueForKey.Split(',');
        }

        public void Close()
        {
            if (this._documentStream != null && this._documentStream.BaseStream.CanRead)
                this._documentStream.Close();
            this._documentStream = (StreamReader)null;
        }

        public void Dispose()
        {
            if (this._documentStream != null && this._documentStream.BaseStream.CanRead)
                this._documentStream.Close();
            this._documentStream = (StreamReader)null;
        }

        public string NextRegister()
        {
            if (this._documentStream == null || !this._documentStream.BaseStream.CanRead)
                throw new InvalidOperationException("El stream del documento de Carga Masiva no esta disponible.");
            if (this._refreshPosition)
            {
                this.GetValueForKey("data");
                int num = 0;
                while (num < this._currentRegister)
                {
                    this._documentStream.ReadLine();
                    ++num;
                    ++this._currentLine;
                }
            }
            string str;
            if ((str = this._documentStream.ReadLine()) == null || str.Trim().Equals(""))
                return (string)null;
            ++this._currentLine;
            ++this._currentRegister;
            if (this._commonFields != null)
            {
                foreach (DictionaryEntry commonField in this._commonFields)
                    str = str + (object)'|' + commonField.Value.ToString();
            }
            return str;
        }

        public void Open()
        {
            if (this._documentStream != null && this._documentStream.BaseStream.CanRead)
                return;
            if (!File.Exists(this._appRootPath + this._filepath + this._filename))
                throw new FileNotFoundException("No se encuentra el documento de Carga Masiva.", this._appRootPath + this._filepath + this._filename);
       //     this._documentStream = new StreamReader(this._appRootPath + this._filepath + this._filename, Encoding.Default);
            this._currentLine = 0;
            this.LoadSettings();
            this.LoadCommonFields();
            if (this.GetValueForKey("data") == null)
                throw new ArgumentException("El documento de datos no especifica el inicio de los registros de datos.", "data");
            this._currentRegister = 0;
        }
    }
}