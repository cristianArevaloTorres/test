﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    public class EnvioOpera
    {
        public static Mensaje RegistrarOTs(List<OT> aOTs)
        {
            Mensaje mensaje = new Mensaje();
            try
            {
                mensaje.Id = CC.InsertaOT(aOTs);
                if (mensaje.Id > 0)
                {
                    mensaje.Descripcion = string.Format("Se registrarón {0} OTs exitosamente", (object)mensaje.Id);
                }
                else
                {
                    mensaje.Descripcion = "No fue posible registrar las OT, intente mas tarde.";
                    mensaje.Detalle = "Error al momento de ejecutar el Stored Procedure";
                }
            }
            catch (Exception ex)
            {
                mensaje = new Mensaje()
                {
                    Id = -1,
                    Descripcion = "No fue posible registrar las OT, intente mas tarde.",
                    Detalle = string.Format("Mensaje: {0} \n Trace: {1}", (object)ex.Message, (object)ex.StackTrace)
                };
            }
            return mensaje;
        }
    }
}