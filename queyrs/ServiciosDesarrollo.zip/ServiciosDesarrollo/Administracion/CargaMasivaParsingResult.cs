﻿namespace ServiciosLocktonTI.Administracion
{
    public enum CargaMasivaParsingResult
    {
        Success,
        FieldValueCountError,
        FieldValueValidationError,
        CriticalFail,
        UnknownError,
    }
}