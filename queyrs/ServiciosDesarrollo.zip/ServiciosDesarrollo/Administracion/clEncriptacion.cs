﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    public class clEncriptacion
    {
        private string passPhrase = "FLEXIFORBES";
        private string saltValue = "FLEXIFORBES";
        private string hashAlgorithm = "MD5";
        private int passwordIterations = 2;
        private string initVector = "@1B2c3D4e5F6g7H8";
        private int keySize = 256;

        public string Encriptar(string plainText)
        {
            byte[] bytes1 = Encoding.ASCII.GetBytes(this.initVector);
            byte[] bytes2 = Encoding.ASCII.GetBytes(this.saltValue);
            byte[] bytes3 = Encoding.UTF8.GetBytes(plainText);
            byte[] bytes4 = new PasswordDeriveBytes(this.passPhrase, bytes2, this.hashAlgorithm, this.passwordIterations).GetBytes(this.keySize / 8);
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            rijndaelManaged.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = rijndaelManaged.CreateEncryptor(bytes4, bytes1);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(bytes3, 0, bytes3.Length);
            cryptoStream.FlushFinalBlock();
            byte[] array = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(array);
        }

        public string Desencriptar(string cipherText)
        {
            byte[] bytes1 = Encoding.ASCII.GetBytes(this.initVector);
            byte[] bytes2 = Encoding.ASCII.GetBytes(this.saltValue);
            byte[] buffer = Convert.FromBase64String(cipherText);
            byte[] bytes3 = new PasswordDeriveBytes(this.passPhrase, bytes2, this.hashAlgorithm, this.passwordIterations).GetBytes(this.keySize / 8);
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            rijndaelManaged.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = rijndaelManaged.CreateDecryptor(bytes3, bytes1);
            MemoryStream memoryStream = new MemoryStream(buffer);
            CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] numArray = buffer;
            int count = cryptoStream.Read(numArray, 0, numArray.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(numArray, 0, count);
        }
    }
}