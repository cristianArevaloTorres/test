﻿namespace ServiciosLocktonTI.Administracion
{
    public enum CargaMasivaExecutionResult
    {
        Success,
        InitError,
        ParsingError,
        DBError,
        ThreadError,
        AuthenticationError,
        UnknownError,
    }
}