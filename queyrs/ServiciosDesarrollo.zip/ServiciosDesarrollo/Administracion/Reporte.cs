﻿using System.Data;
using System.Data.SqlClient;

namespace ServiciosLocktonTI.Administracion
{
    public class Reporte
    {
        private string _correoAdministrador = "";
        private string _nombreEmpresa = "";
        private string _nombreArchivo = "";
        private string _tipoArchivo = "";
        private string _strValidador = "";
        private readonly CommonBusiness commonBiz;
        private int _idEmpresa;
        private int _idTipoSolicitud;
        private string _FechaIni;
        private string _FechaFin;
        private int _idVencida;
        private int _idVigencia;
        private string _FechaCorte;
        private int _idEstatus;
        private int _idConfidencial;
        private int _idUsuario;
        private int _idPlantilla;
        private string _pathAttach;
        private bool _guardar;

        public Reporte()
        {
            this.commonBiz = new CommonBusiness();
        }

        public Reporte(
          int idEmpresa,
          int idTipoSolicitud,
          string FechaIni,
          string FechaFin,
          int idVencida)
        {
            this._idEmpresa = idEmpresa;
            this._idTipoSolicitud = idTipoSolicitud;
            this._FechaIni = FechaIni;
            this._FechaFin = FechaFin;
            this._idVencida = idVencida;
            this._idPlantilla = 11;
        }

        public Reporte(
          int idEmpresa,
          int idVigencia,
          string FechaCorte,
          int idEstatus,
          int idConfidencial)
        {
            this._idEmpresa = idEmpresa;
            this._idVigencia = idVigencia;
            this._FechaCorte = FechaCorte;
            this._idEstatus = idEstatus;
            this._idConfidencial = idConfidencial;
            this._idPlantilla = 11;
        }

        public Reporte(
          int idEmpresa,
          int idVigencia,
          int idTipoSolicitud,
          string FechaIni,
          string FechaFin,
          int idVencida,
          int idUsuario)
        {
            this._idEmpresa = idEmpresa;
            this._idVigencia = idVigencia;
            this._idTipoSolicitud = idTipoSolicitud;
            this._FechaIni = FechaIni;
            this._FechaFin = FechaFin;
            this._idVencida = idVencida;
            this._idUsuario = idUsuario;
            this._idPlantilla = 11;
        }

        public Reporte(
          int idEmpresa,
          int idVigencia,
          int idTipoSolicitud,
          string FechaIni,
          string FechaFin,
          int idVencida,
          int idUsuario,
          int idPlantilla)
        {
            this._idEmpresa = idEmpresa;
            this._idVigencia = idVigencia;
            this._idTipoSolicitud = idTipoSolicitud;
            this._FechaIni = FechaIni;
            this._FechaFin = FechaFin;
            this._idVencida = idVencida;
            this._idUsuario = idUsuario;
            this._idPlantilla = idPlantilla;
        }

        public string FechaIni
        {
            get
            {
                return this._FechaIni;
            }
            set
            {
                this._FechaIni = value;
            }
        }

        public string FechaFin
        {
            get
            {
                return this._FechaFin;
            }
            set
            {
                this._FechaFin = value;
            }
        }

        public int idEmpresa
        {
            get
            {
                return this._idEmpresa;
            }
            set
            {
                this._idEmpresa = value;
            }
        }

        public int idTipoSolicitud
        {
            get
            {
                return this._idTipoSolicitud;
            }
            set
            {
                this._idTipoSolicitud = value;
            }
        }

        public int idVencida
        {
            get
            {
                return this._idVencida;
            }
            set
            {
                this._idVencida = value;
            }
        }

        public int idVigencia
        {
            get
            {
                return this._idVigencia;
            }
            set
            {
                this._idVigencia = value;
            }
        }

        public string FechaCorte
        {
            get
            {
                return this._FechaCorte;
            }
            set
            {
                this._FechaCorte = value;
            }
        }

        public int idEstatus
        {
            get
            {
                return this._idEstatus;
            }
            set
            {
                this._idEstatus = value;
            }
        }

        public int idConfidencial
        {
            get
            {
                return this._idConfidencial;
            }
            set
            {
                this._idConfidencial = value;
            }
        }

        public int idUsuario
        {
            get
            {
                return this._idUsuario;
            }
            set
            {
                this._idUsuario = value;
            }
        }

        public int idPlantilla
        {
            get
            {
                return this._idPlantilla;
            }
            set
            {
                this._idPlantilla = value;
            }
        }

        public string pathAttach
        {
            get
            {
                return this._pathAttach;
            }
            set
            {
                this._pathAttach = value;
            }
        }

        public bool Guardar
        {
            get
            {
                return this._guardar;
            }
            set
            {
                this._guardar = value;
            }
        }

        public string correoAdministrador
        {
            set
            {
                this._correoAdministrador = value;
            }
            get
            {
                return this._correoAdministrador;
            }
        }

        public string nombreEmpresa
        {
            set
            {
                this._nombreEmpresa = value;
            }
            get
            {
                return this._nombreEmpresa;
            }
        }

        public string nombreArchivo
        {
            set
            {
                this._nombreArchivo = value;
            }
            get
            {
                return this._nombreArchivo;
            }
        }

        public string tipoArchivo
        {
            set
            {
                this._tipoArchivo = value;
            }
            get
            {
                return this._tipoArchivo;
            }
        }

        public string strValidador
        {
            set
            {
                this._strValidador = value;
            }
        }

        public void EnviaCorreo()
        {
            DataSet dataSet = this.commonBiz.ExecuteStoredProcedure(new SqlParameter[3]
            {
        new SqlParameter("@IdEmplado", (object) this._idUsuario.ToString()),
        new SqlParameter("@Tipo", (object) 1),
        new SqlParameter("@IdEmpresa", (object) this.idEmpresa.ToString())
            }, "ff_DatosMenuEmpleado", this._strValidador);
            this.correoAdministrador = dataSet.Tables[0].Rows[0]["CorreoElectronico"].ToString();
          //  ClCorreo clCorreo = new ClCorreo();
            //if (this.pathAttach != null)
            //    clCorreo.fileAttach = this._pathAttach;
            //clCorreo.AddData("#TipoArchivo", this._tipoArchivo);
            //clCorreo.AddData("#NombreArchivo", this._nombreArchivo);
            //clCorreo.AddData("#NombreAdministrador", dataSet.Tables[0].Rows[0]["Nombre"].ToString());
            //clCorreo.AddData("#NombreEmpresa", this.nombreEmpresa);
            //clCorreo.AddData("#FechaGeneracion", DateTime.Now.Day.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString());
            //clCorreo.MeEnviaCorreo(this._idPlantilla, this.correoAdministrador, this.idEmpresa.ToString());
        }

        public void GuardaLog(string msgReporte, string msgSource)
        {
            //try
            //{
            //    new ClErrores().MeEnviaError(new Exception(msgReporte)
            //    {
            //        Source = msgSource
            //    });
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
        }
    }
}