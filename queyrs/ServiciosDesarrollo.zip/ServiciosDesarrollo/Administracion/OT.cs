﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    [DataContract]
    public class OT
    {
        private int numeroOT;
        private int ticket;
        private int ticketDetalle;

        [DataMember]
        public int TicketDetalle
        {
            get
            {
                return this.ticketDetalle;
            }
            set
            {
                this.ticketDetalle = value;
            }
        }

        [DataMember]
        public int Ticket
        {
            get
            {
                return this.ticket;
            }
            set
            {
                this.ticket = value;
            }
        }

        [DataMember]
        public int NumeroOT
        {
            get
            {
                return this.numeroOT;
            }
            set
            {
                this.numeroOT = value;
            }
        }
    }
}