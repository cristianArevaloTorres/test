﻿using System;
using System.Collections;

namespace ServiciosLocktonTI.Administracion
{
    public class PlantillaCampoItemCollection : DictionaryBase
    {
        public string[] Names
        {
            get
            {
                string[] strArray = new string[this.Dictionary.Keys.Count];
                this.Dictionary.Keys.CopyTo((Array)strArray, 0);
                return strArray;
            }
        }

        public PlantillaCampoItem this[string key]
        {
            get
            {
                return (PlantillaCampoItem)this.Dictionary[(object)key];
            }
            set
            {
                this.Dictionary[(object)key] = (object)value;
            }
        }

        public bool Contains(string campo)
        {
            return this.Dictionary.Contains((object)campo);
        }

        public void Add(string key, PlantillaCampoItem item)
        {
            this.Dictionary.Add((object)key, (object)item);
        }
    }
}