﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    public class Descuentos
    {
        public enum EEstatus
        {

            Exitoso = 1,
            NoExitoso = 2,
            NoDisponible = 3,
            EnProceso = 4,
            Horarioinvalido = 5,
            Fueradehorario = 6,
            Origeninvalido = 7,
            Diaslaboralesinvalido = 8
        }

        private Descuentos.EEstatus estatus;

        public Descuentos.EEstatus Estatus
        {
            get { return estatus; }
            set { estatus = value; }
        }
    }
}