﻿using DocumentFormat.OpenXml.Office2010.Excel;
using DocumentFormat.OpenXml.Office2013.Drawing.ChartStyle;
using ServiciosLocktonTI.Autos;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using DataTable = System.Data.DataTable;

namespace ServiciosLocktonTI.Administracion
{
    public class ConsultaEmpleado
    {
        private DataTable dtBeneficios = new DataTable("dt1");

        public DataSet Get_ConsultaEmpleados(
          string _admin,
          string _user,
          string _pws,
          string _NumEmpleado)
        {

            string pathLog = string.Format(@"{0}Log\{1}\ConsultaEmpleados{2}.txt", System.AppDomain.CurrentDomain.BaseDirectory, _admin, DateTime.Now.ToString("ddMMyyyy"));


            if (ConfigurationManager.AppSettings["Validator"] == null)
                return new DataSet();
            clEncriptacion clEncriptacion = new clEncriptacion();
          
           
             DataSet dataSet = BaseDatos.ConsultaPanelEmpleados(_admin, _user, clEncriptacion.Encriptar(_pws.Trim()), _NumEmpleado,pathLog);           
            dataSet.DataSetName = "Seguros";
            try
            {
                if (dataSet.Tables.Count == 1)
                    dataSet.Tables[0].TableName = "Resultado";
                else if (dataSet.Tables.Count > 1)
                {
                    dataSet.Tables[0].TableName = "Beneficios";
                    dataSet.Tables[1].TableName = "Beneficiarios";
                    dataSet.Tables[2].TableName = "SiniestrosBeneficios";
                    string Id = (!string.IsNullOrEmpty(dataSet.Tables[5].Rows[0]["Id"].ToString())) ? dataSet.Tables[5].Rows[0]["Id"].ToString():null;
                    dataSet.Tables[5].TableName = "ID";
                    dataSet.Tables.Remove("ID");
                    DataTable Autos = new DataTable();
                    Autos = AutosSolicitud(dataSet.Tables[3], Id, pathLog);
                    Autos.TableName = "Autos";
                    try
                    {
                        dataSet.Tables[4].TableName = "SiniestrosAutos";
                    }
                    catch
                    {
                    }
                    dataSet.Tables[0].Columns[0].ColumnName = dataSet.Tables[0].Columns[0].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[1].ColumnName = dataSet.Tables[0].Columns[1].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[2].ColumnName = dataSet.Tables[0].Columns[2].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[3].ColumnName = dataSet.Tables[0].Columns[3].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[4].ColumnName = dataSet.Tables[0].Columns[4].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[5].ColumnName = dataSet.Tables[0].Columns[5].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[6].ColumnName = dataSet.Tables[0].Columns[6].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[7].ColumnName = dataSet.Tables[0].Columns[7].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[8].ColumnName = dataSet.Tables[0].Columns[8].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[9].ColumnName = dataSet.Tables[0].Columns[9].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[10].ColumnName = dataSet.Tables[0].Columns[10].ColumnName.Replace(" ", "_");
                    dataSet.Tables[0].Columns[11].ColumnName = dataSet.Tables[0].Columns[11].ColumnName.Replace(" ", "_");
                    dataSet.Tables[1].Columns[0].ColumnName = dataSet.Tables[1].Columns[0].ColumnName.Replace(" ", "_");
                    dataSet.Tables[1].Columns[1].ColumnName = dataSet.Tables[1].Columns[1].ColumnName.Replace(" ", "_");
                    dataSet.Tables[1].Columns[2].ColumnName = dataSet.Tables[1].Columns[2].ColumnName.Replace(" ", "_");
                    dataSet.Tables[1].Columns[3].ColumnName = dataSet.Tables[1].Columns[3].ColumnName.Replace(" ", "_");
                    dataSet.Tables[1].Columns[4].ColumnName = dataSet.Tables[1].Columns[4].ColumnName.Replace(" ", "_");
                    dataSet.Tables[2].Columns[0].ColumnName = dataSet.Tables[2].Columns[0].ColumnName.Replace(" ", "_");
                    dataSet.Tables[2].Columns[1].ColumnName = dataSet.Tables[2].Columns[1].ColumnName.Replace(" ", "_");
                    dataSet.Tables[2].Columns[2].ColumnName = dataSet.Tables[2].Columns[2].ColumnName.Replace(" ", "_");
                    dataSet.Tables[2].Columns[3].ColumnName = dataSet.Tables[2].Columns[3].ColumnName.Replace(" ", "_");
                    dataSet.Tables[2].Columns[4].ColumnName = dataSet.Tables[2].Columns[4].ColumnName.Replace(" ", "_");
                    dataSet.Tables[2].Columns[5].ColumnName = dataSet.Tables[2].Columns[5].ColumnName.Replace(" ", "_");
                    dataSet.Tables[2].Columns[6].ColumnName = dataSet.Tables[2].Columns[6].ColumnName.Replace(" ", "_");
                    dataSet.Tables[2].Columns[7].ColumnName = dataSet.Tables[2].Columns[7].ColumnName.Replace(" ", "_");
                    
                    
                    Autos.Columns[0].ColumnName = Autos.Columns[0].ColumnName.Replace(" ", "_");
                    Autos.Columns[1].ColumnName = Autos.Columns[1].ColumnName.Replace(" ", "_");
                    Autos.Columns[2].ColumnName = Autos.Columns[2].ColumnName.Replace(" ", "_");
                    Autos.Columns[3].ColumnName = Autos.Columns[3].ColumnName.Replace(" ", "_");
                    Autos.Columns[4].ColumnName = Autos.Columns[4].ColumnName.Replace(" ", "_");
                    Autos.Columns[5].ColumnName = Autos.Columns[5].ColumnName.Replace(" ", "_");
                    Autos.Columns[6].ColumnName = Autos.Columns[6].ColumnName.Replace(" ", "_");
                    Autos.Columns[7].ColumnName = Autos.Columns[7].ColumnName.Replace(" ", "_");
                    Autos.Columns[8].ColumnName = Autos.Columns[8].ColumnName.Replace(" ", "_");
                    Autos.Columns[9].ColumnName = Autos.Columns[9].ColumnName.Replace(" ", "_");
                    Autos.Columns[10].ColumnName = Autos.Columns[10].ColumnName.Replace(" ", "_");
                    Autos.Columns[11].ColumnName = Autos.Columns[11].ColumnName.Replace(" ", "_");
                    Autos.Columns[12].ColumnName = Autos.Columns[12].ColumnName.Replace(" ", "_");
                    Autos.Columns[13].ColumnName = Autos.Columns[13].ColumnName.Replace(" ", "_");
                    try
                    {
                        dataSet.Tables[4].Columns[0].ColumnName = dataSet.Tables[4].Columns[0].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[1].ColumnName = dataSet.Tables[4].Columns[1].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[2].ColumnName = dataSet.Tables[4].Columns[2].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[3].ColumnName = dataSet.Tables[4].Columns[3].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[4].ColumnName = dataSet.Tables[4].Columns[4].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[5].ColumnName = dataSet.Tables[4].Columns[5].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[6].ColumnName = dataSet.Tables[4].Columns[6].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[7].ColumnName = dataSet.Tables[4].Columns[7].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[8].ColumnName = dataSet.Tables[4].Columns[8].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[9].ColumnName = dataSet.Tables[4].Columns[9].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[10].ColumnName = dataSet.Tables[4].Columns[10].ColumnName.Replace(" ", "_");
                        dataSet.Tables[4].Columns[11].ColumnName = dataSet.Tables[4].Columns[11].ColumnName.Replace(" ", "_");
                    }catch
                   (Exception ex)
                        {
                        Negocio.EscribirArchivo(ex.Message + "\n" + ex.StackTrace.ToString(), pathLog);
                    }
                }
                return dataSet;
            }
            catch (Exception ex)
            {
                Negocio.EscribirArchivo(ex.Message +"\n" +ex.StackTrace.ToString(), pathLog);
            }
            return dataSet;
        }


        private DataTable AutosSolicitud(DataTable Columnas, string Id ,string PpathLog) 
        
        {
            DataTable Autos = Columnas;
            if (!string.IsNullOrEmpty(Id)) 
            {
                try
                {
                    InsercionSICASClient Locktonone = new InsercionSICASClient();
                    List<sp_POLIZA_DSpace> dt = Locktonone.ObtenerPolizasDSpace(Id).ToList();
                    if (dt.Count > 0)
                    {
                        foreach (var obj in dt)
                            Autos.Rows.Add(obj.Estatus.ToString(), obj.Numero_Empleado.ToString(), obj.Propietario.ToString(), obj.Poliza.ToString(),
                                                    obj.CIS.ToString(), obj.Cobertura.ToString(), obj.Marca.ToString(), obj.Vehiculo.ToString(),
                                                    obj.Serie_Vehiculo.ToString(), obj.Modelo.ToString(), obj.Fecha_Solicitud.ToString(),
                                                    obj.Numero_Descuentos, obj.Monto_Descuento.ToString(), obj.Prima_Total.ToString());

                    }
                }
                catch (Exception ex)
                {
                    Negocio.EscribirArchivo(
                     "Servicio Autos" + "\n" + ex.Message + "\n" + ex.StackTrace.ToString(), PpathLog);
                }

            }
            return Autos;
        }



    }
}