﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    public class Documento
    {
        public enum EFactura
        {
            NoEspecificado = 0,
            Factura = 1,
            No_Factura = 2
        }
        public enum ESeccion
        {
            NoEspecificado = 0,
            BeMobile_GMM = 15,
            BeMobile_AUTOS = 16
        }

        public enum ETipoNegocio
        {
            NoEspecificado = 0,
            Beflex = 1,
            LocktonOne = 2
        }

        public enum EEstatus
        {
            NoEspecificado = 0,
            Exitoso = 1,
            NoExitoso = 2,
            EnProceso = 3,
            Finalizado = 4,
            NoDisponible = 5,
            Inexistente = 6,
            CredencialesNoValidas = 7,
            FueraDeHorario = 8,
            Eliminado = 9,
            PropiedadesRequeridas = 10
        }

        private byte[] archivo;
        private string nombre;
        private ETipoNegocio tipoNegocio;

        public ETipoNegocio TipoNegocio
        {
            get { return tipoNegocio; }
            set { tipoNegocio = value; }
        }
        private ESeccion seccion;

        public ESeccion Seccion
        {
            get { return seccion; }
            set { seccion = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public byte[] Archivo
        {
            get { return archivo; }
            set { archivo = value; }
        }

        private string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        private EEstatus estatus;

        public EEstatus Estatus
        {
            get { return estatus; }
            set { estatus = value; }
        }

        private EFactura tipoDeDocumento;

        public EFactura TipoDeDocumento
        {
            get { return tipoDeDocumento; }
            set { tipoDeDocumento = value; }
        }

        private Int64 idDocumento;

        public Int64 IdDocumento
        {
            get { return idDocumento; }
            set { idDocumento = value; }
        }

        private List<Asegurados> asegurado;

        public List<Asegurados> Asegurado
        {
            get { return asegurado; }
            set { asegurado = value; }
        }
    }

    public class EstatusCarga
    {
        private string folio;
        private Documento.EEstatus estatus;

        public Documento.EEstatus Estatus
        {
            get { return estatus; }
            set { estatus = value; }
        }
        private Documento[] documentos;

        public Documento[] Documentos
        {
            get { return documentos; }
            set { documentos = value; }
        }

        public string Folio
        {
            get { return folio; }
            set { folio = value; }
        }
    }

    public class Resultado
    {
        private Documento.EEstatus estatus;
        private string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        public Documento.EEstatus Estatus
        {
            get { return estatus; }
            set { estatus = value; }
        }
    }

    public class Asegurados
    {
        private string numeroEmpleado;

        public string NumeroEmpleado
        {
            get { return numeroEmpleado; }
            set { numeroEmpleado = value; }
        }
        private string nombre1;

        public string Nombre1
        {
            get { return nombre1; }
            set { nombre1 = value; }
        }
        private string nombre2;

        public string Nombre2
        {
            get { return nombre2; }
            set { nombre2 = value; }
        }
        private string apellidoPaterno;

        public string ApellidoPaterno
        {
            get { return apellidoPaterno; }
            set { apellidoPaterno = value; }
        }
        private string apellidoMaterno;

        public string ApellidoMaterno
        {
            get { return apellidoMaterno; }
            set { apellidoMaterno = value; }
        }
        private int idParentesco;

        public int IdParentesco
        {
            get { return idParentesco; }
            set { idParentesco = value; }
        }
    }
}