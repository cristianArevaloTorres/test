﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    public class CC
    {
        public static int InsertaOT(List<OT> OTs)
        {
            CommonBusiness commonBusiness = new CommonBusiness();
            int num;
            try
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("Ticket");
                dataTable.Columns.Add("TicketDetalle");
                dataTable.Columns.Add("OT");
                foreach (OT ot in OTs)
                    dataTable.Rows.Add((object)ot.Ticket, (object)ot.TicketDetalle, (object)ot.NumeroOT);
                SqlParameter[] sqlParams = new SqlParameter[1]
                {
          new SqlParameter("@OTs", (object) dataTable)
                };
                num = int.Parse(commonBusiness.ExecuteStoredProcedure(sqlParams, "bf_InsertaOTsOPERA", string.Empty).Tables[0].Rows[0][0].ToString());
            }
            catch (Exception ex)
            {
                num = -1;
            }
            return num;
        }
    }
}