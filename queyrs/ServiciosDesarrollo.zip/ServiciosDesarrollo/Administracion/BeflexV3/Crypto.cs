﻿using ServiciosLocktonTI.Administracion.BeflexV3;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace ServiciosLocktonTI.Administracion.Beflex
{
    public class Crypto
    {
        private  Parametro moParametro;

        public  string CifrarCadena(string cadenaOriginal)
        {
            moParametro = new Parametro();
            moParametro.Proc_LeeParametro("0", "180");
            string valorParametro = moParametro.Valor.Trim();
            string[] PWSl;
            PWSl = valorParametro.ToString().Split(',');
            moParametro.Valor = string.Empty;
            byte[] bytes1 = Encoding.ASCII.GetBytes(PWSl[0].ToString());
            byte[] bytes2 = Encoding.ASCII.GetBytes(PWSl[1].ToString());
            byte[] bytes3 = Encoding.UTF8.GetBytes(cadenaOriginal);
            byte[] bytes4 = new PasswordDeriveBytes(PWSl[1].ToString(), bytes2, PWSl[2].ToString(), 2).GetBytes(32);
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            rijndaelManaged.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = rijndaelManaged.CreateEncryptor(bytes4, bytes1);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(bytes3, 0, bytes3.Length);
            cryptoStream.FlushFinalBlock();
            byte[] array = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(array);
        }
        public string Encriptar(string plainText)
        {
            string[] PSWRDBLX;
            moParametro = new Parametro();
            moParametro.Proc_LeeParametro("0", "182");
            string valorParametro = moParametro.Valor.Trim();
            PSWRDBLX = valorParametro.Split(',');
            string passPhrase = PSWRDBLX[0].ToString();
            string saltValue = PSWRDBLX[0].ToString();
            string hashAlgorithm = PSWRDBLX[1].ToString();
            int passwordIterations = int.Parse(PSWRDBLX[2].ToString());
            string initVector = PSWRDBLX[3].ToString();
            int keySize = int.Parse(PSWRDBLX[4].ToString());
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes;
            saltValueBytes = Encoding.ASCII.GetBytes(saltValue);
            byte[] plainTextBytes;
            plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations);
            byte[] keyBytes = password.GetBytes(keySize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            string cipherText = Convert.ToBase64String(cipherTextBytes);
            return cipherText;
        }
        public string Desencriptar(string cipherText)
        {
            string[] PSWRDBLX;
            moParametro = new Parametro();
            moParametro.Proc_LeeParametro("0", "182");
            string valorParametro = moParametro.Valor.Trim();
            PSWRDBLX = valorParametro.Split(',');
            string passPhrase = PSWRDBLX[0].ToString();
            string saltValue = PSWRDBLX[0].ToString();
            string hashAlgorithm = PSWRDBLX[1].ToString();
            int passwordIterations = int.Parse(PSWRDBLX[2].ToString());
            string initVector = PSWRDBLX[3].ToString();
            int keySize = int.Parse(PSWRDBLX[4].ToString());
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations);
            byte[] keyBytes = password.GetBytes(keySize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = cipherTextBytes;
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            string plainText = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
            return plainText;
        }
        public List<string> ListEncriptar(List<string> Elemento)
        {
            List<string> Result = new List<string>();
                foreach (var bc in Elemento)
                Result.Add(Encriptar(bc));

            return Result;
        }
        public List<string> ListDesencriptar(List<string> Elemento)
        {
            List<string> Result = new List<string>();
            foreach (var bc in Elemento)
                Result.Add(Desencriptar(bc));

            return Result;

        }

    }
}