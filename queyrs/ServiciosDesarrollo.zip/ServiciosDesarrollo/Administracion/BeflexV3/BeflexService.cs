﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion.Beflex
{
    public class BeflexService
    {
        public static  DataSet LoginService(string strEmpleado, string strContrasena)
        {
            DataSet ds = new DataSet();
            string str = new Crypto().CifrarCadena(strContrasena);

            try
            {
                DataTable id = new DataTable();
                id = BaseDatos.RecuperaId(strEmpleado);
                if (id != null && id.Rows.Count > 0  )
                {
                    ds = BaseDatos.LoginB(strEmpleado, BaseDatos.AccesoMobile(int.Parse(id.Rows[0]["Id"].ToString()), 
                        int.Parse(id.Rows[0]["RecalculaTarifa"].ToString()), int.Parse(id.Rows[0]["CampoPassIni"].ToString()), str));
                }
            }
            catch { }
            
            return ds;
        }

     
        public static DateTime ActualizacionEmpleadoService(string numeroEmpleado)
        {
            return BaseDatos.ActualizacionEmpleadoB(numeroEmpleado);
        }
    }
}