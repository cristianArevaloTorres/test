﻿using FlexiForbesV2.Data.DataAccess;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion.BeflexV3
{
    public class Parametro
    {
        private string mDescripcion;
        private string mValor;
        private int mId;

        public Parametro()
        {
            mDescripcion = "";
            mValor = "";
        }

        public string Valor
        {
            set
            {
                mValor = value;
            }
            get
            {
                return mValor;

            }

        }

        public string Descripcion
        {
            set
            {
                mDescripcion = value;
            }
            get
            {
                return mDescripcion;

            }

        }

        public int Id
        {
            set
            {
                mId = value;
            }
            get
            {
                return mId;

            }

        }

        public void Proc_LeeParametro(string idEmpresa, string Parametro)
        {
            string salida = "";
            SqlConnection cn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                SqlParameter[] arParmsTransfe = new SqlParameter[2];
                arParmsTransfe[0] = new SqlParameter("@Empresa", idEmpresa);
                arParmsTransfe[1] = new SqlParameter("@Parametro", Parametro);
                cn.Open();
                SqlDataReader myReader = SqlHelper.ExecuteReader(cn, CommandType.StoredProcedure, "dbo.ff_GetParametro", arParmsTransfe);
                while (myReader.Read())
                {
                    this.Valor = myReader["paValor"].ToString();
                    salida = myReader["paValor"].ToString();
                    this.Descripcion = myReader["paDescripcion"].ToString().Trim();
                }

                myReader.Close();
                cn.Close();
                cn.Dispose();
            }
            catch (Exception ff)
            {
                cn.Close();
                cn.Dispose();

            }
        }
        //return salida;
    }
    }
