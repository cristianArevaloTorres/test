﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion
{
    public class CommonBusiness
    {
        public DataSet ExecuteStoredProcedure(
      SqlParameter[] sqlParams,
      string storedProcedureName,
      string validator)
        {
           return new CommonBD().ExecuteStoredProcedure(sqlParams, storedProcedureName, validator);
        }
    }
}