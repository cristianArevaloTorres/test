﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace ServiciosLocktonTI.Administracion.NPS_DAL
{
    public class LogNPS
    {
        public static void EscribirArchivo(string contenido, string ruta)
        {
            FileInfo archivo = new FileInfo(ruta);
            StreamWriter documento;
            if (!archivo.Exists)
            {
                Directory.CreateDirectory(archivo.Directory.FullName);
                documento = new StreamWriter(archivo.FullName, false, System.Text.Encoding.UTF8);
            }
            else
                documento = archivo.AppendText();

            documento.WriteLine(string.Format("{0} {1}", contenido, DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
            documento.Flush();
            documento.Close();
        }
    }
}