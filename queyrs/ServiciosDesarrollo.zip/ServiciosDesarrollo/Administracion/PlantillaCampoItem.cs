﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Configuration;

namespace ServiciosLocktonTI.Administracion
{
    public class PlantillaCampoItem
    {
        private readonly CommonBusiness commonBiz;
        private bool _CPEncriptado;
        private bool _CPRequerido;
        private char _CATipoDato;
        private int _PCIdPlantillaCampo;
        private int _CALongitud;
        private readonly string WebServiceAccesKey;
        private string _logStr;
        private string _CADescripcionCampo;
        private string _CACaracteresValidos;
        private string _CANombreCampo;
        private string _CATipoValor;
        private string _sp_CPRangoValores;
        private DataTable _PCRangoValores;
        private SortedList _options;

        public PlantillaCampoItem(DataRow row, SortedList options)
        {
            this.WebServiceAccesKey = ConfigurationSettings.AppSettings["Validator"];
            this.commonBiz = new CommonBusiness();
            this._options = options;
            this._logStr = "";
            this._PCIdPlantillaCampo = int.Parse(row["CPIdConfiguracionPlantilla"].ToString());
            this._CANombreCampo = row["CANombreCampo"].ToString();
            this._CADescripcionCampo = row["CADescripcionCampo"].ToString();
            this._CATipoDato = row["CATipoDato"].ToString()[0];
            this._CALongitud = int.Parse(row["CALongitud"].ToString());
            this._CATipoValor = row["CATipoValor"].ToString();
            this._CACaracteresValidos = row["CACaracteresValidos"].ToString();
            this._sp_CPRangoValores = row["CPRangoValores"].ToString();
            this._CPRequerido = row["CPRequerido"].ToString().Equals("1");
            this._CPEncriptado = row["CPEncriptado"].ToString().Equals("1");
            if (!this._CATipoValor.Equals("Especifico"))
                return;
            this.CreateSpecificValuesMap();
        }

        public bool Requerido
        {
            get
            {
                return this._CPRequerido;
            }
        }

        public string Nombre
        {
            get
            {
                return this._CANombreCampo;
            }
        }

        public char TipoDato
        {
            get
            {
                return this._CATipoDato;
            }
        }

        private object ConvertDataToType(string data)
        {
            switch (this._CATipoDato)
            {
                case '%':
                case 'F':
                case 'M':
                    return (object)double.Parse("0" + data);
                case 'B':
                case 'E':
                case 'N':
                    return (object)int.Parse(data);
                case 'D':
                    return (object)DateTime.ParseExact(data, "dd/MM/yyyy", (IFormatProvider)null);
                case 'T':
                    return (object)data;
                default:
                    throw new ArgumentException("No se reconoce el tipo de dato al que se desea convertir: " + (object)this._CATipoDato, "_CATipoDato");
            }
        }

        private string GetSpecificValue(string key)
        {
            string str = (string)null;
            DataRow[] dataRowArray = this._PCRangoValores.Select("key = '" + key + "'");
            if (dataRowArray.Length == 1)
                str = dataRowArray[0]["value"].ToString();
            return str;
        }

        private void CreateSpecificValuesMap()
        {
            if (this._sp_CPRangoValores == null || this._sp_CPRangoValores.Equals(""))
                throw new ArgumentException("El parametro " + this._CANombreCampo + " usa valores especificos pero no se provee origen de datos para construir el mapa de valores.");
            string storedProcedureName = this._sp_CPRangoValores.Split(':')[0];
            SqlParameter[] sqlParams = (SqlParameter[])null;
            if (!this._sp_CPRangoValores.Split(':')[1].Trim().Equals(""))
            {
                string[] strArray = this._sp_CPRangoValores.Split(':')[1].Trim().Split(',');
                sqlParams = new SqlParameter[strArray.Length];
                for (int index = 0; index < strArray.Length; ++index)
                    sqlParams[index] = new SqlParameter("@" + strArray[index], this._options[(object)strArray[index]]);
            }
            this._PCRangoValores = this.commonBiz.ExecuteStoredProcedure(sqlParams, storedProcedureName, string.Empty).Tables[0];
        }

        public bool Validate(string data)
        {
            if (data == null)
            {
                this._logStr += "El dato a validar no puede ser nulo.";
                return false;
            }
            string str = data;
            if (str.Equals(""))
            {
                if (!this._CPRequerido)
                    return true;
                this._logStr += "Se requiere estrictamente de un valor para este campo.";
                return false;
            }
            if (!this._CACaracteresValidos.Equals("") && !this._CACaracteresValidos.Equals(" ") && !Regex.Match(str, this._CACaracteresValidos).Success)
            {
                this._logStr += "El valor no cumple con el formato especificado para este campo.";
                return false;
            }
            if (this._CATipoValor.Equals("Especifico") && (str = this.GetSpecificValue(str)) == null)
            {
                PlantillaCampoItem plantillaCampoItem = this;
                plantillaCampoItem._logStr = plantillaCampoItem._logStr + "El campo de valores específicos no encuentra una eqivalencia para el valor: " + data;
                return false;
            }
            if (this._CATipoDato == 'T')
            {
                if (this._CPEncriptado)
                    str = new clEncriptacion().Encriptar(str);
            }
            object type;
            try
            {
                type = this.ConvertDataToType(str);
            }
            catch (Exception ex)
            {
                this._logStr += string.Format("{0} ({1})", (object)ex.Message, (object)ex.GetType().ToString());
                return false;
            }
            return type != null;
        }

        public string GetLastError()
        {
            string logStr = this._logStr;
            this._logStr = "";
            return logStr;
        }

        public object Convert(string data)
        {
            if (data == null)
                throw new ArgumentNullException(nameof(data), "El dato a convertir no puede ser nulo.");
            string str = data;
            if (str.Equals(""))
            {
                if (this._CPRequerido)
                    throw new ArgumentException("El campo requiere que se proporcione un valor distinto de nulo.", nameof(data));
                return (object)null;
            }
            if (!this._CACaracteresValidos.Equals("") && !this._CACaracteresValidos.Equals(" ") && !Regex.Match(str, this._CACaracteresValidos).Success)
                throw new FormatException("El dato no cumple el formato requerido para el campo: " + this._CANombreCampo);
            if (this._CATipoValor.Equals("Especifico") && (str = this.GetSpecificValue(str)) == "")
                throw new ArgumentException("El dato no se encuentra dentro del rango de valores aceptables.", nameof(data));
            if (this._CATipoDato == 'T' && this._CPEncriptado)
                str = new clEncriptacion().Encriptar(str);
            return this.ConvertDataToType(str);
        }

        public void Dispose()
        {
            if (this._PCRangoValores != null)
                this._PCRangoValores.Dispose();
            if (this._options == null)
                return;
            this._options.Clear();
        }

        public string Validate_(string data)
        {
            if (data == null)
            {
                this._logStr += "El valor no puede ser nulo";
                return this._logStr;
            }
            string str = data;
            if (str.Equals(""))
            {
                if (!this._CPRequerido)
                    return string.Empty;
                this._logStr += "Se requiere estrictamente de un valor";
                return this._logStr;
            }
            if (!this._CACaracteresValidos.Equals("") && !this._CACaracteresValidos.Equals(" ") && !Regex.Match(str, this._CACaracteresValidos).Success)
            {
                this._logStr += "El valor no cumple con el formato especificado";
                return this._logStr;
            }
            if (this._CATipoValor.Equals("Especifico") && (str = this.GetSpecificValue(str)) == null)
            {
                this._logStr += "No se reconoce el valor";
                return this._logStr;
            }
            if (this._CATipoDato == 'T' && this._CPEncriptado)
                str = new clEncriptacion().Encriptar(str);
            object type;
            try
            {
                type = this.ConvertDataToType(str);
            }
            catch (Exception ex)
            {
                this._logStr += ex.Message.Replace(".", "");
                return this._logStr;
            }
            return type != null ? string.Empty : "Error al reconocer tipo de dato";
        }

    }
}