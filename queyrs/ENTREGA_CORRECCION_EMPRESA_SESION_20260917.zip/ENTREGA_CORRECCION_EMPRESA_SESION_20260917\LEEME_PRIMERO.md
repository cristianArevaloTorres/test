# Entrega: carga posicional por empresa de sesion

Esta entrega corrige el flujo **Archivo posicional Ford (01 / 02 / 03)** para que pueda utilizarse desde cualquier empresa y para que la empresa seleccionada en la sesion sea el destino real de la operacion.

## Contenido

- `01_BACKEND_WSBeFlex`: archivos con su ruta relativa para copiar sobre el repositorio Java.
- `02_FRONTEND_BeFlex3`: archivos con su ruta relativa para copiar sobre el repositorio Angular.
- `03_PRUEBAS_DELOITTE`: dos archivos de alta con siete empleados dummy y un SQL de validacion.
- `COMANDOS_GIT.md`: comandos sugeridos para revisar y registrar los cambios.
- `RESULTADOS_PRUEBAS.md`: verificaciones realizadas antes de generar el ZIP.

## Cambio funcional principal

- El flujo ya no envia todas las cadenas a la empresa Ford `517`.
- Usa la empresa de la sesion, su clave externa (`EMIdEmpresaFlexiForbes`) y la operacion 2 configurada para esa empresa.
- Para Deloitte `186`, la clave correcta que consume el SP es `S001`; enviar `186` o `deloitte` hacia `EMEmpresa` provocaba un falso positivo: el SP devolvia exito, pero no insertaba en `ff_Empleado`.
- Antes de ejecutar se valida que la accion sea coherente con el estado actual del empleado.
- Despues de ejecutar se comprueba en `ff_Empleado` que la accion realmente ocurrio. Si el SP reporta exito pero no hay efecto, el registro termina como error y se informa al usuario.

## Acciones validadas

- Alta: el empleado no debe existir en el corporativo y debe terminar activo en la empresa destino.
- Reactivacion: debe existir inactivo en destino y terminar activo.
- Baja: debe existir activo en destino y terminar sin registro activo.
- Cambio de empresa: debe existir activo en otra empresa del corporativo y terminar activo solamente en destino.
- Actualizacion y movimientos PAY/POS/PRO/DEM/DTA: el empleado debe estar activo en destino; para actualizacion tambien se verifica que los datos hayan cambiado.

## Instalacion

1. Copiar el contenido de `01_BACKEND_WSBeFlex` sobre la raiz del repositorio `WSBeFlex` conservando las carpetas.
2. Copiar el contenido de `02_FRONTEND_BeFlex3` sobre la raiz del repositorio `BeFlex3` conservando las carpetas.
3. Ejecutar `database/009_infraestructura_cadena_ws_ford.sql` en la base correspondiente si la infraestructura de bitacora posicional aun no existe.
4. Compilar y desplegar primero el backend y despues el frontend.
5. Ingresar con la empresa que sera el destino real. Para la prueba incluida, seleccionar Deloitte con ID interno `186`.
6. Cargar uno de los archivos de `03_PRUEBAS_DELOITTE/TXT` y luego ejecutar `03_PRUEBAS_DELOITTE/SQL/VALIDAR_ALTAS_DELOITTE_186.sql`.

El repositorio APIReports no requiere cambios para esta correccion.
