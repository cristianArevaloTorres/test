package com.lockton.WSBeFlex.DAO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

/** Acceso al mismo contrato de configuracion y SP consumido por B2. */
@Repository
public class CargaMasivaB2DAO {
    private static final Pattern IDENTIFICADOR = Pattern.compile("[A-Za-z0-9_\\[\\]\\.]+");
    private final JdbcTemplate jdbcTemplate;

    public CargaMasivaB2DAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Map<String, Object> obtenerOperacion(int idEmpresa, int idOperacion) {
        Integer activas = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM dbo.ff_CargaMasivaOperacionEmpresa "
                + "WHERE CEIdEmpresa=? AND CEIdOperacion=? AND CEIdEstatus=1",
                new Object[] { idEmpresa, idOperacion }, Integer.class);
        if (activas == null || activas != 1) {
            throw new IllegalArgumentException("La operacion no esta activa o no es unica para la empresa.");
        }
        Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("IdOperacion", idOperacion);
        parametros.put("IdEmpresa", idEmpresa);
        Map<String, Object> fila = primeraFila(ejecutar("ff_CCMOperacionPropiedades", parametros));
        if (fila == null) throw new IllegalArgumentException("B2 no devolvio propiedades para la operacion.");
        String sp = texto(fila, "CEStoredProc");
        Number plantilla = numero(fila, "CEIdPlantilla");
        if (sp == null || plantilla == null) {
            throw new IllegalArgumentException("La operacion no tiene CEStoredProc o CEIdPlantilla.");
        }
        validarProcedimiento(sp);
        fila.put("CEStoredProc", sp.trim());
        fila.put("CEIdPlantilla", plantilla.intValue());
        return fila;
    }

    public List<Map<String, Object>> obtenerCamposPlantilla(int idPlantilla) {
        Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("IdPlantilla", idPlantilla);
        return filas(ejecutar("ff_CPlantillaCampos", parametros));
    }

    public Map<String, String> obtenerRango(String declaracion, int idEmpresa) {
        if (declaracion == null || declaracion.trim().isEmpty()) return Collections.emptyMap();
        String[] partes = declaracion.split(":", 2);
        String procedimiento = partes[0].trim();
        validarProcedimiento(procedimiento);
        Map<String, Object> parametros = new LinkedHashMap<>();
        if (partes.length > 1 && !partes[1].trim().isEmpty()) {
            for (String nombre : partes[1].split(",")) {
                String limpio = nombre.trim();
                if (!"SIdEmpresa".equals(limpio)) {
                    throw new IllegalArgumentException("El rango requiere una opcion B2 no soportada: " + limpio + ".");
                }
                parametros.put(limpio, idEmpresa);
            }
        }
        List<Map<String, Object>> filas = filas(ejecutar(procedimiento, parametros));
        Map<String, String> salida = new LinkedHashMap<>();
        for (Map<String, Object> fila : filas) {
            Object clave = valor(fila, "key");
            Object dato = valor(fila, "value");
            if (clave != null && dato != null) salida.put(String.valueOf(clave), String.valueOf(dato));
        }
        return salida;
    }

    public Map<String, Object> ejecutarOperacion(String procedimiento, Map<String, Object> parametros) {
        validarProcedimiento(procedimiento);
        return ejecutar(procedimiento, parametros);
    }

    public String obtenerClaveExternaEmpresa(int idEmpresa) {
        List<String> claves = jdbcTemplate.query("SELECT CONVERT(VARCHAR(100),EMIdEmpresaFlexiForbes) "
                        + "FROM dbo.ff_Empresa WITH (NOLOCK) WHERE EMIdEmpresa=? AND EMIdEstatus=1",
                new Object[]{idEmpresa}, (rs, rowNum) -> rs.getString(1));
        if (claves.size() != 1 || claves.get(0) == null || claves.get(0).trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "La empresa de la sesion no tiene una clave externa activa y unica.");
        }
        return claves.get(0).trim();
    }

    /** Comprueba la alta de titular, cuya operacion global es 2. */
    public String validarOperacionTitular(int idEmpresa, int idOperacion, String numeroEmpleado) {
        if (idOperacion != 2) return null;
        List<Map<String, Object>> filas = jdbcTemplate.queryForList("SELECT COUNT(1) total,"
                        + "SUM(CASE WHEN EMIdEstatus=1 THEN 1 ELSE 0 END) activos "
                        + "FROM dbo.ff_Empleado WITH (NOLOCK) WHERE EMIdEmpresa=? "
                        + "AND EMIdParentesco=1 AND EMNumeroEmpleado=?",
                idEmpresa, numeroEmpleado);
        int total = entero(filas.get(0).get("total"));
        int activos = entero(filas.get(0).get("activos"));
        return activos > 0 ? null
                : "El procedimiento respondio exito, pero el titular no quedo activo en ff_Empleado para la empresa de la sesion.";
    }

    private Map<String, Object> ejecutar(String procedimiento, Map<String, Object> parametros) {
        String limpio = limpiarProcedimiento(procedimiento);
        SimpleJdbcCall llamada = new SimpleJdbcCall(jdbcTemplate).withProcedureName(limpio);
        return llamada.execute(new MapSqlParameterSource(parametros));
    }

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> filas(Map<String, Object> resultado) {
        if (resultado == null) return Collections.emptyList();
        List<Map<String, Object>> filas = new ArrayList<>();
        for (Object valor : resultado.values()) {
            if (!(valor instanceof List)) continue;
            for (Object elemento : (List<Object>) valor) {
                if (elemento instanceof Map) filas.add((Map<String, Object>) elemento);
            }
        }
        return filas;
    }

    public Map<String, Object> primeraFila(Map<String, Object> resultado) {
        List<Map<String, Object>> filas = filas(resultado);
        return filas.isEmpty() ? null : new LinkedHashMap<>(filas.get(0));
    }

    public Object valor(Map<String, Object> fila, String nombre) {
        if (fila == null) return null;
        for (Map.Entry<String, Object> entry : fila.entrySet()) {
            if (nombre.equalsIgnoreCase(entry.getKey())) return entry.getValue();
        }
        return null;
    }

    public String texto(Map<String, Object> fila, String nombre) {
        Object value = valor(fila, nombre);
        return value == null ? null : String.valueOf(value);
    }

    public Number numero(Map<String, Object> fila, String nombre) {
        Object value = valor(fila, nombre);
        if (value instanceof Number) return (Number) value;
        try { return value == null ? null : Integer.valueOf(String.valueOf(value)); }
        catch (NumberFormatException e) { return null; }
    }

    private void validarProcedimiento(String procedimiento) {
        if (procedimiento == null || !IDENTIFICADOR.matcher(procedimiento.trim()).matches()) {
            throw new IllegalArgumentException("Nombre de procedimiento almacenado invalido.");
        }
    }

    private String limpiarProcedimiento(String procedimiento) {
        String limpio = procedimiento.trim().replace("[", "").replace("]", "");
        if (limpio.toLowerCase().startsWith("dbo.")) limpio = limpio.substring(4);
        return limpio;
    }

    private int entero(Object valor) {
        if (valor instanceof Number) return ((Number) valor).intValue();
        try { return valor == null ? 0 : Integer.parseInt(String.valueOf(valor)); }
        catch (NumberFormatException e) { return 0; }
    }
}
