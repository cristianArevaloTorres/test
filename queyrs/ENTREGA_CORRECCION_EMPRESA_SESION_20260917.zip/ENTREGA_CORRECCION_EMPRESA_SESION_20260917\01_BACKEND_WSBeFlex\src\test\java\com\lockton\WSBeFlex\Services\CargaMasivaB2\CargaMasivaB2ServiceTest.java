package com.lockton.WSBeFlex.Services.CargaMasivaB2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.lockton.WSBeFlex.DAO.CargaMasivaB2DAO;
import com.lockton.WSBeFlex.DAO.FfCargaMasivaDAO;
import com.lockton.WSBeFlex.Services.CargaMasivaFlujoService;
import com.lockton.WSBeFlex.Services.Crypto.CryptoBeflexService;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mock.web.MockMultipartFile;

class CargaMasivaB2ServiceTest {
    @Test
    void completaContratoTecnicoDelAltaFordSinEnviarUsuarioUmod() throws Exception {
        CargaMasivaB2DAO dao = mock(CargaMasivaB2DAO.class);
        CargaMasivaFlujoService flujo = mock(CargaMasivaFlujoService.class);
        CryptoBeflexService crypto = mock(CryptoBeflexService.class);
        FfCargaMasivaDAO legacy = mock(FfCargaMasivaDAO.class);
        CargaMasivaB2Service service = new CargaMasivaB2Service(dao, flujo, crypto, legacy);

        when(flujo.resolver(517, "PANTALLA")).thenReturn(mapa("flujo", "B2"));
        when(dao.obtenerClaveExternaEmpresa(517)).thenReturn("109");
        Map<String, Object> operacion = mapa("CEIdPlantilla", 3748);
        operacion.put("CEStoredProc", "ff_XCMTitularesAltaCMFORD");
        operacion.put("Return_Code", 1);
        operacion.put("Return_Msg", 1);
        when(dao.obtenerOperacion(517, 2)).thenReturn(operacion);
        when(dao.obtenerCamposPlantilla(3748)).thenReturn(Arrays.asList(
                campo("EMEmpresa", "T", 0),
                campo("EMNumeroEmpleado", "T", 1),
                campo("EMFechaBaja", "D", 0)));

        Map<String, Object> filaSp = mapa("Return_Code", 0);
        filaSp.put("Return_Msg", "Titular Ford registrado");
        Map<String, Object> respuestaSp = mapa("#result-set-1", Arrays.asList(filaSp));
        when(dao.ejecutarOperacion(eq("ff_XCMTitularesAltaCMFORD"), anyMap()))
                .thenReturn(respuestaSp);
        when(dao.primeraFila(respuestaSp)).thenReturn(filaSp);
        when(dao.valor(filaSp, "Return_Code")).thenReturn(0);
        when(dao.valor(filaSp, "Return_Msg")).thenReturn("Titular Ford registrado");

        String txt = "@commonFields:\nEMEmpresa=109\n\n"
                + "@fieldNames: EMNumeroEmpleado,EMFechaBaja\n@data:\nQB26B20001|\n";
        MockMultipartFile archivo = new MockMultipartFile("archivo", "ford.txt", "text/plain",
                txt.getBytes(StandardCharsets.UTF_8));

        Map<String, Object> resultado = service.ejecutar(
                517, 2, "PRIMER_ERROR", archivo, 3043, "TRACE-FORD-B2-01");

        assertEquals("OK", resultado.get("resultado"));
        assertTrue(((java.util.List<?>) resultado.get("log")).stream()
                .anyMatch(linea -> String.valueOf(linea).contains("[ETAPA:COMPATIBILIDAD_SP]")));
        ArgumentCaptor<Map<String, Object>> parametros = ArgumentCaptor.forClass(Map.class);
        verify(dao).ejecutarOperacion(eq("ff_XCMTitularesAltaCMFORD"), parametros.capture());
        assertEquals("109", parametros.getValue().get("EMEmpresa"));
        assertEquals(517, parametros.getValue().get("EMIdEmpresa"));
        assertEquals(0, parametros.getValue().get("EMIdEstatus"));
        assertEquals("", parametros.getValue().get("EMPerfil"));
        assertNull(parametros.getValue().get("EMFechaBaja"));
        assertTrue(!parametros.getValue().containsKey("EMUsuarioUMod"));
    }

    @Test
    void usaLaPlantillaYElStoredProcedureDeLaConfiguracionB2() throws Exception {
        CargaMasivaB2DAO dao = mock(CargaMasivaB2DAO.class);
        CargaMasivaFlujoService flujo = mock(CargaMasivaFlujoService.class);
        CryptoBeflexService crypto = mock(CryptoBeflexService.class);
        FfCargaMasivaDAO legacy = mock(FfCargaMasivaDAO.class);
        CargaMasivaB2Service service = new CargaMasivaB2Service(dao, flujo, crypto, legacy);

        when(flujo.resolver(186, "PANTALLA")).thenReturn(mapa("flujo", "B2"));
        when(dao.obtenerClaveExternaEmpresa(186)).thenReturn("S001");
        Map<String, Object> operacion = mapa("CEIdPlantilla", 507);
        operacion.put("CEStoredProc", "ff_XCMTitularesAltaCMDeloitte");
        operacion.put("Return_Code", 1);
        operacion.put("Return_Msg", 1);
        when(dao.obtenerOperacion(186, 2)).thenReturn(operacion);
        // La plantilla 507 de ALTA TITULARES expone la clave externa legacy,
        // aunque el SP desplegado tambien requiere el ID interno de empresa.
        Map<String, Object> campoEmpresa = campo("EMEmpresa", "T", 0);
        Map<String, Object> campoEmpleado = campo("EMNumeroEmpleado", "T", 1);
        when(dao.obtenerCamposPlantilla(507)).thenReturn(Arrays.asList(campoEmpresa, campoEmpleado));

        Map<String, Object> filaSp = mapa("Return_Code", 0);
        filaSp.put("Return_Msg", "Titular registrado");
        Map<String, Object> respuestaSp = mapa("#result-set-1", Arrays.asList(filaSp));
        when(dao.ejecutarOperacion(eq("ff_XCMTitularesAltaCMDeloitte"), anyMap()))
                .thenReturn(respuestaSp);
        when(dao.primeraFila(respuestaSp)).thenReturn(filaSp);
        when(dao.valor(filaSp, "Return_Code")).thenReturn(0);
        when(dao.valor(filaSp, "Return_Msg")).thenReturn("Titular registrado");

        String txt = "@commonFields:\nEMEmpresa=186edf\n\n"
                + "@fieldNames: EMNumeroEmpleado\n@data:\nDUMMY001\n";
        MockMultipartFile archivo = new MockMultipartFile("archivo", "carga.txt", "text/plain",
                txt.getBytes(StandardCharsets.UTF_8));

        Map<String, Object> resultado = service.ejecutar(
                186, 2, "PRIMER_ERROR", archivo, 3043, "TRACE-12345678");

        assertEquals("OK", resultado.get("resultado"));
        assertEquals("ff_XCMTitularesAltaCMDeloitte", resultado.get("procedimiento"));
        assertEquals("carga.txt", resultado.get("nombreArchivo"));
        assertTrue(((java.util.List<?>) resultado.get("log")).stream()
                .anyMatch(linea -> String.valueOf(linea).contains("[ETAPA:ESTRUCTURA_TXT]")));
        assertTrue(((java.util.List<?>) resultado.get("log")).stream()
                .anyMatch(linea -> String.valueOf(linea).contains("[ETAPA:RESUMEN]")));
        assertTrue(((java.util.List<?>) resultado.get("log")).stream()
                .anyMatch(linea -> String.valueOf(linea).contains("[ETAPA:CONTEXTO_SEGURO]")));
        assertTrue(((java.util.List<?>) resultado.get("log")).stream()
                .anyMatch(linea -> String.valueOf(linea).contains("[ETAPA:COMPATIBILIDAD_SP]")));
        ArgumentCaptor<Map<String, Object>> parametros = ArgumentCaptor.forClass(Map.class);
        verify(dao).ejecutarOperacion(eq("ff_XCMTitularesAltaCMDeloitte"), parametros.capture());
        assertEquals("S001", parametros.getValue().get("EMEmpresa"));
        assertEquals(186, parametros.getValue().get("EMIdEmpresa"));
        assertTrue(!parametros.getValue().containsKey("EMUsuarioUMod"));
        assertEquals("", parametros.getValue().get("EMPuesto2"));
        assertEquals("", parametros.getValue().get("EMPerfil"));
    }

    @Test
    void fuerzaLaEmpresaAutorizadaAunqueElTxtIntenteEnviarOtra() throws Exception {
        CargaMasivaB2DAO dao = mock(CargaMasivaB2DAO.class);
        CargaMasivaFlujoService flujo = mock(CargaMasivaFlujoService.class);
        CryptoBeflexService crypto = mock(CryptoBeflexService.class);
        FfCargaMasivaDAO legacy = mock(FfCargaMasivaDAO.class);
        CargaMasivaB2Service service = new CargaMasivaB2Service(dao, flujo, crypto, legacy);

        when(flujo.resolver(186, "PANTALLA")).thenReturn(mapa("flujo", "B2"));
        when(dao.obtenerClaveExternaEmpresa(186)).thenReturn("S001");
        Map<String, Object> operacion = mapa("CEIdPlantilla", 12059);
        operacion.put("CEStoredProc", "ff_ActualizaNumEmpleadoTitular");
        when(dao.obtenerOperacion(186, 13)).thenReturn(operacion);
        when(dao.obtenerCamposPlantilla(12059)).thenReturn(Arrays.asList(
                campo("EMIdEmpresa", "E", 1),
                campo("EMNumeroEmpleado", "T", 1),
                campo("EMNuevoNumeroEmpleado", "T", 1)));

        Map<String, Object> filaSp = mapa("codigo", 1);
        filaSp.put("mensaje", "Numero actualizado");
        Map<String, Object> respuestaSp = mapa("#result-set-1", Arrays.asList(filaSp));
        when(dao.ejecutarOperacion(eq("ff_ActualizaNumEmpleadoTitular"), anyMap()))
                .thenReturn(respuestaSp);
        when(dao.primeraFila(respuestaSp)).thenReturn(filaSp);
        when(dao.valor(filaSp, "codigo")).thenReturn(1);
        when(dao.valor(filaSp, "mensaje")).thenReturn("Numero actualizado");

        String txt = "@commonFields:\nEMIdEmpresa=999\n\n"
                + "@fieldNames: EMNumeroEmpleado,EMNuevoNumeroEmpleado\n"
                + "@data:\nQACMCHGA186|QACMCHGB186\n";
        MockMultipartFile archivo = new MockMultipartFile("archivo", "seguridad.txt", "text/plain",
                txt.getBytes(StandardCharsets.UTF_8));

        service.ejecutar(186, 13, "PRIMER_ERROR", archivo, 3043, "TRACE-SECURITY-01");

        ArgumentCaptor<Map<String, Object>> parametros = ArgumentCaptor.forClass(Map.class);
        verify(dao).ejecutarOperacion(eq("ff_ActualizaNumEmpleadoTitular"), parametros.capture());
        assertEquals(186, parametros.getValue().get("EMIdEmpresa"));
    }

    @Test
    void normalizaCodigoUnoComoExitoEnCambioDeNumero() throws Exception {
        CargaMasivaB2DAO dao = mock(CargaMasivaB2DAO.class);
        CargaMasivaFlujoService flujo = mock(CargaMasivaFlujoService.class);
        CryptoBeflexService crypto = mock(CryptoBeflexService.class);
        FfCargaMasivaDAO legacy = mock(FfCargaMasivaDAO.class);
        CargaMasivaB2Service service = new CargaMasivaB2Service(dao, flujo, crypto, legacy);

        when(flujo.resolver(186, "PANTALLA")).thenReturn(mapa("flujo", "B2"));
        when(dao.obtenerClaveExternaEmpresa(186)).thenReturn("S001");
        Map<String, Object> operacion = mapa("CEIdPlantilla", 12059);
        operacion.put("CEStoredProc", "ff_ActualizaNumEmpleadoTitular");
        when(dao.obtenerOperacion(186, 13)).thenReturn(operacion);
        when(dao.obtenerCamposPlantilla(12059)).thenReturn(Arrays.asList(
                campo("EMIdEmpresa", "E", 1),
                campo("EMNumeroEmpleado", "T", 1),
                campo("EMNuevoNumeroEmpleado", "T", 1)));

        Map<String, Object> filaSp = mapa("codigo", 1);
        filaSp.put("mensaje", "Numero actualizado");
        Map<String, Object> respuestaSp = mapa("#result-set-1", Arrays.asList(filaSp));
        when(dao.ejecutarOperacion(eq("ff_ActualizaNumEmpleadoTitular"), anyMap()))
                .thenReturn(respuestaSp);
        when(dao.primeraFila(respuestaSp)).thenReturn(filaSp);
        when(dao.valor(filaSp, "codigo")).thenReturn(1);
        when(dao.valor(filaSp, "mensaje")).thenReturn("Numero actualizado");

        String txt = "@commonFields:\nEMIdEmpresa=186\n\n"
                + "@fieldNames: EMNumeroEmpleado,EMNuevoNumeroEmpleado\n"
                + "@data:\nQACMCHGA186|QACMCHGB186\n";
        MockMultipartFile archivo = new MockMultipartFile("archivo", "cambio.txt", "text/plain",
                txt.getBytes(StandardCharsets.UTF_8));

        Map<String, Object> resultado = service.ejecutar(
                186, 13, "PRIMER_ERROR", archivo, 3043, "TRACE-CHANGE-01");

        assertEquals("OK", resultado.get("resultado"));
        assertEquals(1, ((Map<?, ?>) ((java.util.List<?>) resultado.get("registros")).get(0)).get("spCode"));
    }

    @Test
    void transferenciaUsaElAdaptadorLegacyQueConstruyeParametrosCarga() throws Exception {
        CargaMasivaB2DAO dao = mock(CargaMasivaB2DAO.class);
        CargaMasivaFlujoService flujo = mock(CargaMasivaFlujoService.class);
        CryptoBeflexService crypto = mock(CryptoBeflexService.class);
        FfCargaMasivaDAO legacy = mock(FfCargaMasivaDAO.class);
        CargaMasivaB2Service service = new CargaMasivaB2Service(dao, flujo, crypto, legacy);

        when(flujo.resolver(186, "PANTALLA")).thenReturn(mapa("flujo", "B2"));
        when(dao.obtenerClaveExternaEmpresa(186)).thenReturn("S001");
        Map<String, Object> operacion = mapa("CEIdPlantilla", 12391);
        operacion.put("CEStoredProc", "ff_transferenciaMasivaEmpleado");
        when(dao.obtenerOperacion(186, 15)).thenReturn(operacion);
        when(dao.obtenerCamposPlantilla(12391)).thenReturn(Arrays.asList(
                campo("EMIdEmpresa", "E", 1),
                campo("EMIdEmpresaOrigen", "E", 1),
                campo("EMNumeroEmpleado", "T", 1),
                campo("EMFecha_solicitud_movimiento", "D", 1)));
        Map<String, Object> respuesta = mapa("code", 200);
        respuesta.put("msg", "Transferencia correcta");
        when(legacy.procesarTransferenciaMasiva(anyMap(), eq("ff_transferenciaMasivaEmpleado")))
                .thenReturn(respuesta);
        when(dao.valor(respuesta, "code")).thenReturn(200);
        when(dao.valor(respuesta, "msg")).thenReturn("Transferencia correcta");

        String txt = "@commonFields:\nEMIdEmpresa=186\n\n"
                + "@fieldNames: EMIdEmpresaOrigen,EMNumeroEmpleado,EMFecha_solicitud_movimiento\n"
                + "@data:\n187|QACMTRANS186|24/08/2026\n";
        MockMultipartFile archivo = new MockMultipartFile("archivo", "transferencia.txt", "text/plain",
                txt.getBytes(StandardCharsets.UTF_8));

        Map<String, Object> resultado = service.ejecutar(
                186, 15, "PRIMER_ERROR", archivo, 3043, "TRACE-TRANSFER-01");

        assertEquals("OK", resultado.get("resultado"));
        verify(legacy).procesarTransferenciaMasiva(anyMap(), eq("ff_transferenciaMasivaEmpleado"));
    }

    private static Map<String, Object> campo(String nombre, String tipo, int requerido) {
        Map<String, Object> campo = new LinkedHashMap<>();
        campo.put("CANombreCampo", nombre);
        campo.put("CATipoDato", tipo);
        campo.put("CATipoValor", "Libre");
        campo.put("CACaracteresValidos", "");
        campo.put("CPRangoValores", "");
        campo.put("CPRequerido", requerido);
        campo.put("CPEncriptado", 0);
        return campo;
    }

    private static Map<String, Object> mapa(String clave, Object valor) {
        Map<String, Object> mapa = new LinkedHashMap<>();
        mapa.put(clave, valor);
        return mapa;
    }
}
