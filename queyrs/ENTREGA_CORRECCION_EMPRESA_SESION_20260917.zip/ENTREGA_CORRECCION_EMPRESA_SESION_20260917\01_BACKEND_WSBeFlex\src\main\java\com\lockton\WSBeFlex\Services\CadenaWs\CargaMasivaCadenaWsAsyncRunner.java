package com.lockton.WSBeFlex.Services.CadenaWs;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.DAO.CargaCadenaWsDAO;
import com.lockton.WSBeFlex.Services.CargaMasivaB2.CargaMasivaOperacionExecutor;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/** Worker independiente: el lote continua aunque termine la peticion HTTP. */
@Service
public class CargaMasivaCadenaWsAsyncRunner {
    private static final Log LOG = LogFactory.getLog(CargaMasivaCadenaWsAsyncRunner.class);
    private final CargaCadenaWsDAO dao;
    private final CargaMasivaOperacionExecutor executor;
    private final ObjectMapper objectMapper;

    public CargaMasivaCadenaWsAsyncRunner(CargaCadenaWsDAO dao,
                                          CargaMasivaOperacionExecutor executor,
                                          ObjectMapper objectMapper) {
        this.dao = dao;
        this.executor = executor;
        this.objectMapper = objectMapper;
    }

    @Async("cadenaWsExecutor")
    public void ejecutar(UUID idLote, int idUsuario, String modo) {
        try {
            Map<String, Object> lote = dao.obtenerLote(idLote);
            if (lote == null || numero(lote.get("idEmpresa")) <= 0) {
                throw new IllegalStateException("El lote no tiene una empresa de contexto valida.");
            }
            int idEmpresa = numero(lote.get("idEmpresa"));
            CargaMasivaOperacionExecutor.Preparacion preparacion = executor.preparar(
                    idEmpresa,
                    CargaMasivaCadenaWsService.OPERACION_FORD);
            List<Map<String, Object>> pendientes = dao.listarPendientes(idLote);
            validarContrato(preparacion, pendientes);
            boolean detener = false;
            for (Map<String, Object> detalle : pendientes) {
                if (detener) break;
                long idDetalle = numeroLargo(detalle.get("idDetalle"));
                String hashRegistro = String.valueOf(detalle.get("hashRegistro"));
                String codigoMovimiento = String.valueOf(detalle.get("codigoMovimiento"));
                if (!dao.reclamarRegistro(idEmpresa,
                        hashRegistro, codigoMovimiento, idLote, idDetalle)) {
                    dao.registrarDuplicadoEnEjecucion(idLote, idDetalle);
                    if ("PRIMER_ERROR".equals(modo)) detener = true;
                    continue;
                }
                if (!dao.marcarProcesando(idDetalle)) {
                    dao.liberarReclamo(idEmpresa,
                            hashRegistro, codigoMovimiento, idLote, idDetalle);
                    continue;
                }
                boolean exitoso = false;
                CargaMasivaOperacionExecutor.Resultado resultado;
                String numeroEmpleado = null;
                String huellaAnterior = null;
                String tipoMovimiento = String.valueOf(detalle.get("tipoMovimiento"));
                try {
                    String json = String.valueOf(detalle.get("parametrosJson"));
                    Map<String, String> parametros = objectMapper.readValue(
                            json, new TypeReference<Map<String, String>>() { });
                    numeroEmpleado = parametros.get("EMNumeroEmpleado");
                    huellaAnterior = dao.obtenerHuellaEmpleado(idEmpresa, numeroEmpleado);
                    resultado = executor.ejecutarRegistro(
                            preparacion, parametros, idUsuario,
                            CargaMasivaCadenaWsService.contexto(preparacion));
                } catch (Exception e) {
                    LOG.error("Fallo detalle CadenaWS. Lote=" + idLote
                            + ", renglon=" + detalle.get("renglon"), e);
                    dao.registrarResultado(idLote, idDetalle,
                            idEmpresa,
                            hashRegistro, codigoMovimiento, false, -1,
                            "El registro no pudo procesarse. Consulte el log del WS.");
                    if ("PRIMER_ERROR".equals(modo)) detener = true;
                    continue;
                }
                exitoso = resultado.esExitoso();
                int codigoResultado = resultado.getCodigoSp();
                String mensajeResultado = resultado.getMensaje();
                if (exitoso) {
                    String inconsistencia = dao.validarAccionAplicada(
                            idEmpresa, numeroEmpleado, tipoMovimiento, huellaAnterior);
                    if (inconsistencia != null) {
                        exitoso = false;
                        codigoResultado = -2;
                        mensajeResultado = inconsistencia;
                    } else {
                        mensajeResultado = resultado.getMensaje()
                                + " Validacion posterior en ff_Empleado: OK ("
                                + tipoMovimiento + ").";
                    }
                }
                /* Si falla esta persistencia despues del SP, el reclamo queda EN_PROCESO.
                   Se privilegia no duplicar una operacion de resultado incierto. */
                dao.registrarResultado(idLote, idDetalle,
                        idEmpresa,
                        hashRegistro, codigoMovimiento, exitoso,
                        codigoResultado, mensajeResultado);
                if (!exitoso && "PRIMER_ERROR".equals(modo)) detener = true;
            }
            if (detener) {
                dao.omitirPendientes(idLote, "Omitido por configuracion: detener al primer error.");
            }
            dao.finalizar(idLote);
        } catch (Exception e) {
            LOG.error("Fallo fatal CadenaWS. Lote=" + idLote, e);
            try { dao.finalizarConError(idLote, "El lote termino por un error tecnico."); }
            catch (Exception persistencia) {
                LOG.error("No fue posible cerrar el lote CadenaWS. Lote=" + idLote, persistencia);
            }
        }
    }

    private void validarContrato(CargaMasivaOperacionExecutor.Preparacion preparacion,
                                 List<Map<String, Object>> pendientes) {
        if (pendientes.isEmpty()) return;
        Map<String, Object> detalle = pendientes.get(0);
        String procedimientoAnalizado = normalizarProcedimiento(
                String.valueOf(detalle.get("procedimiento")));
        String procedimientoActual = normalizarProcedimiento(preparacion.getProcedimiento());
        if (numero(detalle.get("idEmpresa")) != preparacion.getIdEmpresa()
                || numero(detalle.get("idOperacion")) != preparacion.getIdOperacion()
                || numero(detalle.get("idPlantilla")) != preparacion.getIdPlantilla()
                || !procedimientoAnalizado.equalsIgnoreCase(procedimientoActual)) {
            throw new IllegalStateException(
                    "La configuracion de la empresa cambio despues del analisis; vuelva a analizar el archivo.");
        }
    }

    private String normalizarProcedimiento(String procedimiento) {
        String limpio = procedimiento == null ? "" : procedimiento.replace("[", "").replace("]", "").trim();
        return limpio.toLowerCase().startsWith("dbo.") ? limpio.substring(4) : limpio;
    }

    private int numero(Object valor) {
        if (valor instanceof Number) return ((Number) valor).intValue();
        return valor == null ? 0 : Integer.parseInt(String.valueOf(valor));
    }

    private long numeroLargo(Object valor) {
        if (valor instanceof Number) return ((Number) valor).longValue();
        return valor == null ? 0L : Long.parseLong(String.valueOf(valor));
    }
}
