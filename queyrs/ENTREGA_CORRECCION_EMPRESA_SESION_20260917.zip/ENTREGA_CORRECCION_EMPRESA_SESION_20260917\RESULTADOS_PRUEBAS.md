# Resultados de validacion

Fecha: 2026-09-17.

## Java

- Compilacion directa con Java 11 de los seis archivos modificados: correcta.
- `CargaMasivaCadenaWsServiceTest`: 3 pruebas, 0 fallos, 0 errores.
- `CargaMasivaB2ServiceTest`: 5 pruebas, 0 fallos, 0 errores.
- `FordCadenaParserTest`: 4 pruebas, 0 fallos, 0 errores.
- Total dirigido: 12 pruebas correctas.

El ciclo Maven completo intenta descargar WSDL internos desde `172.17.0.59:2003`; ese host no estuvo disponible en este entorno. Esta limitacion es externa al cambio y no impidio compilar las clases ni ejecutar las pruebas dirigidas.

## SQL Server LocalDB

Servidor: `(localdb)\MSSQLLocalDB`.

Base: `FlexiForbesv2`.

- Se comprobo que Deloitte interno `186` corresponde a la clave externa `S001`.
- Se ejecuto una alta transaccional con `S001`: el empleado se creo activo en `ff_Empleado`, empresa `186`, perfil `678`.
- Se probaron siete altas dummy: las siete quedaron activas dentro de la transaccion.
- Se probaron alta, actualizacion, baja, reactivacion y cambio de empresa, verificando el estado resultante.
- Todas las pruebas de escritura se hicieron con `ROLLBACK`; no quedaron registros dummy en la base local.

## Archivos de prueba

- El archivo posicional contiene siete detalles de 29 posiciones y trailer con total 7.
- El parser lo reconoce como formato `FORD_29` con siete registros.
- El archivo B2 tiene 31 encabezados y 31 valores en cada una de sus siete filas.
- Ambos archivos utilizan `S001` como clave externa de Deloitte.

## Frontend

La compilacion de Angular requirio `NODE_OPTIONS=--openssl-legacy-provider` por la version local de Node/OpenSSL. La ejecucion completa se detuvo para no retrasar esta entrega; el cambio visual esta limitado al HTML y la integracion conserva los metodos existentes del componente y del servicio.
