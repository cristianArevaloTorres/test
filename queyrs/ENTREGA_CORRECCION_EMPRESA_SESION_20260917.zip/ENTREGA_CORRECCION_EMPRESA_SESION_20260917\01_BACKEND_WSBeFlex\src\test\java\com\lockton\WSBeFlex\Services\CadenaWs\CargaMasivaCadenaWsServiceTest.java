package com.lockton.WSBeFlex.Services.CadenaWs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.DAO.CargaCadenaWsDAO;
import com.lockton.WSBeFlex.Services.CargaMasivaB2.CargaMasivaOperacionExecutor;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mock.web.MockMultipartFile;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class CargaMasivaCadenaWsServiceTest {

    @Test
    void usaLaEmpresaDeSesionYElContratoConfiguradoParaEsaEmpresa() throws Exception {
        FordCadenaParser parser = mock(FordCadenaParser.class);
        CargaCadenaWsDAO dao = mock(CargaCadenaWsDAO.class);
        CargaMasivaOperacionExecutor executor = mock(CargaMasivaOperacionExecutor.class);
        CargaMasivaCadenaWsAsyncRunner asyncRunner = mock(CargaMasivaCadenaWsAsyncRunner.class);
        CargaMasivaCadenaWsService service = new CargaMasivaCadenaWsService(
                parser, dao, executor, asyncRunner, new ObjectMapper());

        FordCadenaRegistro registro = new FordCadenaRegistro(2, posicionesValidas(), "hash-registro");
        FordCadenaDocumento documento = new FordCadenaDocumento(
                "FORD.TXT", "FORD_29", "hash-archivo", Collections.singletonList(registro));
        CargaMasivaOperacionExecutor.Preparacion preparacion = preparacionDeloitte();

        when(parser.parse(any(byte[].class))).thenReturn(documento);
        when(executor.preparar(186, 2)).thenReturn(preparacion);
        Map<String, Object> empresa = new LinkedHashMap<>();
        empresa.put("idEmpresa", 186);
        empresa.put("nombreEmpresa", "DELOITTE");
        empresa.put("claveExterna", "S001");
        when(dao.obtenerEmpresaContexto(186)).thenReturn(empresa);
        when(dao.buscarEstadoEmpleadosCorporativo(eq(186), anySet()))
                .thenReturn(Collections.emptyMap());
        when(dao.buscarMovimientosExitosos(eq(186), anySet())).thenReturn(Collections.emptySet());

        Map<String, Object> respuesta = service.analizar(186,
                new MockMultipartFile("archivo", "ford.txt", "text/plain", "contenido".getBytes()),
                77, "trace-1234");

        assertEquals(186, respuesta.get("empresaContexto"));
        assertEquals(186, respuesta.get("empresaConfiguracion"));
        assertEquals("S001", respuesta.get("claveExternaAplicada"));
        assertEquals(1, respuesta.get("ejecutables"));
        verify(executor).preparar(186, 2);
        verify(dao).buscarMovimientosExitosos(eq(186), anySet());
        verify(dao).crearLote(any(UUID.class), eq(186), eq("hash-archivo"), eq("ford.txt"),
                eq("FORD.TXT"), eq("FORD_29"), eq(1), eq(1), eq(0), eq(0),
                eq(77), eq("trace-1234"));
        ArgumentCaptor<String> parametrosJson = ArgumentCaptor.forClass(String.class);
        verify(dao).insertarDetalle(any(UUID.class), eq(186), eq(2), eq("hash-registro"),
                anyString(), eq("S001"), eq("HIR"), eq("ALTA"), eq(2), eq(507),
                eq("ff_XCMTitularesAltaCMDeloitte"), eq("VALIDO"), anyString(),
                parametrosJson.capture());
        @SuppressWarnings("unchecked")
        Map<String, String> parametros = new ObjectMapper().readValue(
                parametrosJson.getValue(), Map.class);
        assertEquals("S001", parametros.get("EMEmpresa"));
        assertEquals("3", parametros.get("EMIdEstatus"));
        assertEquals("0", parametros.get("EMColoniaFisico"));
        assertEquals("0", parametros.get("EMMunicipioDelegacionFisico"));
        assertEquals("0", parametros.get("EMCodigoPostalFisico"));
    }

    @Test
    void rechazaEmpresaDeContextoNoValida() {
        FordCadenaParser parser = mock(FordCadenaParser.class);
        CargaCadenaWsDAO dao = mock(CargaCadenaWsDAO.class);
        CargaMasivaOperacionExecutor executor = mock(CargaMasivaOperacionExecutor.class);
        CargaMasivaCadenaWsAsyncRunner asyncRunner = mock(CargaMasivaCadenaWsAsyncRunner.class);
        CargaMasivaCadenaWsService service = new CargaMasivaCadenaWsService(
                parser, dao, executor, asyncRunner, new ObjectMapper());

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> service.analizar(0,
                        new MockMultipartFile("archivo", "ford.txt", "text/plain", "x".getBytes()),
                        77, "trace-1234"));

        assertEquals("La empresa de contexto no es valida.", error.getMessage());
        verify(executor, never()).preparar(anyInt(), anyInt());
    }

    @Test
    void informaCuandoHirNoCorrespondePorqueElTitularYaEstaActivo() throws Exception {
        FordCadenaParser parser = mock(FordCadenaParser.class);
        CargaCadenaWsDAO dao = mock(CargaCadenaWsDAO.class);
        CargaMasivaOperacionExecutor executor = mock(CargaMasivaOperacionExecutor.class);
        CargaMasivaCadenaWsAsyncRunner asyncRunner = mock(CargaMasivaCadenaWsAsyncRunner.class);
        CargaMasivaCadenaWsService service = new CargaMasivaCadenaWsService(
                parser, dao, executor, asyncRunner, new ObjectMapper());
        FordCadenaRegistro registro = new FordCadenaRegistro(2, posicionesValidas(), "hash-activo");
        when(parser.parse(any(byte[].class))).thenReturn(new FordCadenaDocumento(
                "DELOITTE.TXT", "FORD_29", "hash-archivo-activo",
                Collections.singletonList(registro)));
        when(executor.preparar(186, 2)).thenReturn(preparacionDeloitte());
        Map<String, Object> empresa = new LinkedHashMap<>();
        empresa.put("idEmpresa", 186);
        empresa.put("nombreEmpresa", "DELOITTE");
        empresa.put("claveExterna", "S001");
        when(dao.obtenerEmpresaContexto(186)).thenReturn(empresa);
        Map<String, Object> estado = new LinkedHashMap<>();
        estado.put("existeDestino", true);
        estado.put("activoDestino", true);
        estado.put("estatusDestino", 1);
        estado.put("otraEmpresaActiva", 0);
        when(dao.buscarEstadoEmpleadosCorporativo(eq(186), anySet()))
                .thenReturn(Collections.singletonMap("QA9990001", estado));
        when(dao.buscarMovimientosExitosos(eq(186), anySet())).thenReturn(Collections.emptySet());

        Map<String, Object> respuesta = service.analizar(186,
                new MockMultipartFile("archivo", "deloitte.txt", "text/plain", "x".getBytes()),
                77, "trace-activo");

        assertEquals(0, respuesta.get("ejecutables"));
        assertEquals(1, respuesta.get("erroresValidacion"));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> detalles = (List<Map<String, Object>>) respuesta.get("detalles");
        assertEquals("ERROR_VALIDACION", detalles.get(0).get("estado"));
        org.junit.jupiter.api.Assertions.assertTrue(
                String.valueOf(detalles.get(0).get("mensaje")).contains("HIR solicita una alta"));
    }

    private CargaMasivaOperacionExecutor.Preparacion preparacionDeloitte() throws Exception {
        Constructor<CargaMasivaOperacionExecutor.Preparacion> constructor =
                CargaMasivaOperacionExecutor.Preparacion.class.getDeclaredConstructor(
                        int.class, int.class, int.class, String.class, String.class,
                        Map.class, List.class, Map.class);
        constructor.setAccessible(true);
        return constructor.newInstance(186, 2, 507, "ff_XCMTitularesAltaCMDeloitte",
                "Alta de Titulares DELOITTE", new LinkedHashMap<>(),
                new ArrayList<>(), new LinkedHashMap<>());
    }

    private List<String> posicionesValidas() {
        List<String> posiciones = new ArrayList<>(Collections.nCopies(29, ""));
        posiciones.set(0, "FORD");
        posiciones.set(1, "S001");
        posiciones.set(2, "M");
        posiciones.set(3, "A");
        posiciones.set(4, "QA9990001");
        posiciones.set(5, "PRUEBA");
        posiciones.set(6, "GENERAL");
        posiciones.set(7, "USUARIO");
        posiciones.set(8, "01/01/1990");
        posiciones.set(9, "01/01/2020");
        posiciones.set(10, "01/09/2026");
        posiciones.set(12, "MEX11");
        posiciones.set(13, "QA");
        posiciones.set(14, "TEST900101AA1");
        posiciones.set(15, "1000.00");
        posiciones.set(16, "qa9990001@example.com");
        posiciones.set(22, "HIR");
        posiciones.set(25, "TEST900101HDFABC01");
        posiciones.set(26, "12345678901");
        posiciones.set(27, "EMPLEADO");
        posiciones.set(28, "01/01/2020");
        return posiciones;
    }
}
