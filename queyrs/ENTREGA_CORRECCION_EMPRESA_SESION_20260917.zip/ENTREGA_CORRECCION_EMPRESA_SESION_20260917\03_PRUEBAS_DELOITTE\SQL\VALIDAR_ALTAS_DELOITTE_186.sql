/* Validacion de solo lectura para los siete titulares dummy de la entrega. */
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @Empresa INT = 186;
DECLARE @Esperados TABLE (NumeroEmpleado VARCHAR(20) PRIMARY KEY);
INSERT @Esperados (NumeroEmpleado) VALUES
('QADL260911'),('QADL260912'),('QADL260913'),('QADL260914'),
('QADL260915'),('QADL260916'),('QADL260917');

SELECT
    '01_EMPRESA_Y_CLAVE' AS bloque,
    E.EMIdEmpresa,
    E.EMNombre,
    E.EMIdEmpresaFlexiForbes AS claveExternaEsperada,
    E.EMIdEstatus
FROM dbo.ff_Empresa E
WHERE E.EMIdEmpresa = @Empresa;

SELECT
    '02_OPERACION_ALTA_CONFIGURADA' AS bloque,
    CE.CEIdEmpresa,
    CE.CEIdOperacion,
    CE.CEIdPlantilla,
    CE.CEStoredProc,
    CE.CEIdEstatus
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
WHERE CE.CEIdEmpresa = @Empresa
  AND CE.CEIdOperacion = 2;

SELECT
    '03_DETALLE_ALTAS' AS bloque,
    X.NumeroEmpleado esperado,
    E.ID idEmpleado,
    E.EMIdEmpresa,
    E.EMNumeroEmpleado,
    E.EMIdEstatus,
    E.EMIdPerfil,
    E.EMIdParentesco,
    E.EMNombre1,
    E.EMApellidoPaterno,
    E.EMFechaAdd,
    E.EMFechaUMod,
    CASE
        WHEN E.ID IS NULL THEN 'NO_CREADO'
        WHEN E.EMIdEmpresa <> @Empresa THEN 'EMPRESA_INCORRECTA'
        WHEN E.EMIdParentesco <> 1 THEN 'NO_ES_TITULAR'
        WHEN E.EMIdEstatus <> 1 THEN 'NO_ESTA_ACTIVO'
        ELSE 'OK'
    END AS validacion
FROM @Esperados X
LEFT JOIN dbo.ff_Empleado E
  ON E.EMNumeroEmpleado = X.NumeroEmpleado
 AND E.EMIdEmpresa = @Empresa
 AND E.EMIdParentesco = 1
ORDER BY X.NumeroEmpleado, E.ID DESC;

SELECT
    '04_RESUMEN' AS bloque,
    COUNT(*) AS esperados,
    SUM(CASE WHEN E.ID IS NOT NULL THEN 1 ELSE 0 END) AS encontrados,
    SUM(CASE WHEN E.ID IS NOT NULL AND E.EMIdEstatus = 1 THEN 1 ELSE 0 END) AS activos,
    SUM(CASE WHEN E.ID IS NULL OR E.EMIdEstatus <> 1 THEN 1 ELSE 0 END) AS fallidos,
    CASE
        WHEN SUM(CASE WHEN E.ID IS NOT NULL AND E.EMIdEstatus = 1 THEN 1 ELSE 0 END) = COUNT(*)
        THEN 'ALTA_CORRECTA'
        ELSE 'REVISAR_DETALLE'
    END AS resultado
FROM @Esperados X
OUTER APPLY
(
    SELECT TOP 1 F.ID, F.EMIdEstatus
    FROM dbo.ff_Empleado F
    WHERE F.EMIdEmpresa = @Empresa
      AND F.EMIdParentesco = 1
      AND F.EMNumeroEmpleado = X.NumeroEmpleado
    ORDER BY F.ID DESC
) E;

IF OBJECT_ID('dbo.bf_CargaCadenaWsLote', 'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        SELECT TOP 10
            ''05_ULTIMOS_LOTES_POSICIONALES'' AS bloque,
            L.CLId,L.CLEstado,L.CLTotal,L.CLExitosos,L.CLErroresValidacion,
            L.CLErroresEjecucion,L.CLMensaje,L.CLFechaInicio,L.CLFechaFin
        FROM dbo.bf_CargaCadenaWsLote L
        WHERE L.CLIdEmpresa = @Empresa
        ORDER BY L.CLFechaAnalisis DESC;',
        N'@Empresa INT', @Empresa;
END
ELSE
    SELECT '05_ULTIMOS_LOTES_POSICIONALES' AS bloque,
           'Ejecute primero database/009_infraestructura_cadena_ws_ford.sql.' AS advertencia;
