# Comandos Git sugeridos

Ejecutarlos dentro de cada repositorio despues de copiar y revisar los archivos.

## Backend WSBeFlex

```powershell
cd C:\RUTA\AL\WSBeFlex
git status --short
git diff --check
git add database/009_infraestructura_cadena_ws_ford.sql
git add src/main/java/com/lockton/WSBeFlex/AsyncConfig.java
git add src/main/java/com/lockton/WSBeFlex/DAO/CargaCadenaWsDAO.java
git add src/main/java/com/lockton/WSBeFlex/DAO/CargaMasivaB2DAO.java
git add src/main/java/com/lockton/WSBeFlex/REST/WSCargaMasivaCadenaWs.java
git add src/main/java/com/lockton/WSBeFlex/Services/CadenaWs
git add src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2Service.java
git add src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaOperacionExecutor.java
git add src/test/java/com/lockton/WSBeFlex/Services/CadenaWs
git add src/test/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2ServiceTest.java
git diff --cached --stat
git diff --cached --check
git commit -m "fix(carga-masiva): usar empresa de sesion y validar acciones"
```

## Frontend BeFlex3

```powershell
cd C:\RUTA\AL\BeFlex3
git status --short
git diff --check
git add src/app/beflex/cargamasivaadm/cargamasivaadm.component.html
git add src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts
git add src/app/services/titulares.service.ts
git diff --cached --stat
git diff --cached --check
git commit -m "feat(carga-masiva): habilitar archivo posicional por empresa"
```

El `push` se deja deliberadamente fuera para que primero se revise la rama y el remoto correctos. Cuando corresponda:

```powershell
git branch --show-current
git remote -v
git push origin NOMBRE_DE_LA_RAMA
```
