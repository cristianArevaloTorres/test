# Corrección de altas Deloitte / empresa 186

La causa fue confirmada en `FlexiForbesv2`: `ff_XCMTitularesAltaCMDeloitte` vuelve a obtener
`EMIdEmpresa` buscando `ff_Empresa.EMIdEmpresaFlexiForbes = @EMEmpresa`. Para la empresa interna
186 la clave externa correcta es `S001`. Los archivos anteriores enviaban `186` o `deloitte` y el
SP finalizaba con `Return_Code=0` aunque no hubiera insertado el titular.

Se incluyen dos archivos con los mismos siete identificadores dummy:

- `TXT/ALTA_POSICIONAL_01_02_03_DELOITTE_186_7.txt`: usar en la opción
  **Archivo posicional Ford (01 / 02 / 03)** con la empresa 186 seleccionada.
- `TXT/B2_ALTA_TITULARES_DELOITTE_186_7.txt`: usar únicamente cuando la pantalla/endpoint B2
  esté habilitado para probar la operación 2 y la plantilla 507.

El backend corregido toma la empresa autenticada como destino, sustituye `EMEmpresa` por su clave
externa configurada y usa la operación 2/plantilla/SP de esa empresa. Para el archivo posicional,
además valida que cada evento corresponda al estado actual y confirma después de ejecutar que la
acción quedó reflejada en `ff_Empleado`; de lo contrario el renglón se reporta como error.

Después de cargar cualquiera de los TXT, ejecutar `SQL/VALIDAR_ALTAS_DELOITTE_186.sql`. El bloque
`04_RESUMEN` debe devolver `esperados=7`, `activos=7`, `fallidos=0` y `ALTA_CORRECTA`.
