﻿USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* Validación de solo lectura. No ejecuta ningún lote de carga o defaulteo. */
CREATE TABLE #Resultado
(
    Orden int NOT NULL,
    Componente nvarchar(120) NOT NULL,
    Estado varchar(10) NOT NULL,
    Valor nvarchar(500) NULL,
    Detalle nvarchar(max) NULL
);

INSERT #Resultado VALUES
(10,N'Contexto',N'INFO',CONCAT(CONVERT(nvarchar(128),SERVERPROPERTY('ServerName')),N' / ',DB_NAME()),N'Confirmar que sea la base utilizada por WSBeFlex.');

DECLARE @Objetos TABLE(Orden int,Nombre sysname,Tipo char(2));
INSERT @Objetos VALUES
(20,N'bf_ConfiguracionDefaulteo','U'),
(21,N'bf_LogDefaulteo','U'),
(22,N'bf_LogErroresDefaulteo','U'),
(23,N'bf_ConfiguracionFlujoCargaMasiva','U'),
(30,N'bf_LogDefaulteo_IniciarLote','P'),
(31,N'bf_LogDefaulteo_RegistrarEvento','P'),
(32,N'bf_LogDefaulteo_FinalizarLote','P'),
(33,N'bf_LogDefaulteo_ConsultarLote','P'),
(34,N'bf_LogDefaulteo_ObtenerEventos','P'),
(35,N'bf_ConfiguracionDefaulteo_Listar','P'),
(36,N'bf_ConfiguracionDefaulteo_Guardar','P'),
(37,N'bf_ConfiguracionDefaulteo_Eliminar','P'),
(38,N'bf_DefaulteoAvanzado_ListarPerfilesEmpresa','P'),
(39,N'bf_DefaulteoAvanzado_ResolverVigencia','P'),
(40,N'bf_DefaulteoAvanzado_Buscar','P'),
(41,N'bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado','P'),
(42,N'bf_ReporteDefaulteo_Consultar','P'),
(43,N'bf_CargaMasivaFlujo_Obtener','P'),
(44,N'bf_CargaMasivaFlujo_Guardar','P'),
(45,N'bf_CargaMasivaFlujo_Resolver','P');

INSERT #Resultado
SELECT O.Orden,N'Objeto '+O.Nombre,
       CASE WHEN OBJECT_ID(N'dbo.'+O.Nombre,O.Tipo) IS NULL THEN 'ALERTA' ELSE 'OK' END,
       CASE WHEN OBJECT_ID(N'dbo.'+O.Nombre,O.Tipo) IS NULL THEN N'NO EXISTE' ELSE N'EXISTE' END,
       NULL
FROM @Objetos O;

DECLARE @Multivigencia nvarchar(max)=OBJECT_DEFINITION(
            OBJECT_ID(N'dbo.bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado',N'P')),
        @Buscar nvarchar(max)=OBJECT_DEFINITION(
            OBJECT_ID(N'dbo.bf_DefaulteoAvanzado_Buscar',N'P')),
        @ResolverCarga nvarchar(max)=OBJECT_DEFINITION(
            OBJECT_ID(N'dbo.bf_CargaMasivaFlujo_Resolver',N'P'));

INSERT #Resultado VALUES
(60,N'Procedimiento multivigencia definitivo',
 CASE WHEN @Multivigencia LIKE N'%OUTER APPLY%'
            AND @Multivigencia LIKE N'%SULT.SOIdVigencia%'
            AND @Multivigencia LIKE N'%sp_executesql%'
      THEN 'OK' ELSE 'ALERTA' END,
 N'Versión corregida',N'Debe recuperar la última solicitud dentro de la vigencia solicitada.'),
(61,N'Búsqueda avanzada con exclusiones',
 CASE WHEN @Buscar LIKE N'%NOT EXISTS%'
            AND @Buscar LIKE N'%ff_Solicitud%'
            AND @Buscar LIKE N'%@IdVigencia%'
      THEN 'OK' ELSE 'ALERTA' END,
 N'Exclusión por solicitud/vigencia',N'Evita proponer empleados que ya tienen una solicitud aplicable.'),
(62,N'Resolución parametrizada de Carga Masiva',
 CASE WHEN @ResolverCarga LIKE N'%CFFlujoPantalla%'
            AND @ResolverCarga LIKE N'%CFFlujoAutomatico%'
            AND @ResolverCarga LIKE N'%WHEN c.CFIdEmpresa IS NULL AND @Canal = ''AUTOMATICO'' THEN ''B2''%'
            AND @ResolverCarga LIKE N'%WHEN c.CFIdEmpresa IS NULL THEN ''B3''%'
      THEN 'OK' ELSE 'ALERTA' END,
 N'Pantalla B3 / automático B2 configurables',N'La decisión de flujo debe permanecer centralizada en base de datos.');

DECLARE @Callers TABLE(Orden int,Nombre sysname);
INSERT @Callers VALUES
(70,N'ff_IInsertaPlanesFlexiblesTmp'),
(71,N'ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3');

INSERT #Resultado
SELECT C.Orden,N'Compatibilidad IdCorporativo: '+C.Nombre,
       CASE WHEN OBJECT_ID(N'dbo.'+C.Nombre,N'P') IS NULL THEN 'ALERTA'
            WHEN OBJECT_DEFINITION(OBJECT_ID(N'dbo.'+C.Nombre,N'P')) LIKE N'%IdCorporativoCompat%'
            THEN 'OK' ELSE 'ALERTA' END,
       CASE WHEN OBJECT_ID(N'dbo.'+C.Nombre,N'P') IS NULL THEN N'NO EXISTE'
            WHEN OBJECT_DEFINITION(OBJECT_ID(N'dbo.'+C.Nombre,N'P')) LIKE N'%IdCorporativoCompat%'
            THEN N'CORREGIDO' ELSE N'SIN MARCADOR' END,
       N'La llamada a ff_IInsertaPlanesFlexiblesTmpCreditos debe enviar IdCorporativo.'
FROM @Callers C;

IF OBJECT_ID(N'dbo.bf_ConfiguracionFlujoCargaMasiva',N'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        DECLARE @Invalidas int=(SELECT COUNT(*) FROM dbo.bf_ConfiguracionFlujoCargaMasiva
                                WHERE CFFlujoPantalla NOT IN (''B2'',''B3'')
                                   OR CFFlujoAutomatico NOT IN (''B2'',''B3'')
                                   OR CFIdEstatus NOT IN (1,2));
        INSERT #Resultado VALUES
        (80,N''Parametrizaciones válidas'',CASE WHEN @Invalidas=0 THEN ''OK'' ELSE ''ALERTA'' END,
         CONCAT(N''Filas inválidas='',@Invalidas),N''Sólo se permiten flujos B2/B3 y estatus 1/2.'');';
END
ELSE
    INSERT #Resultado VALUES(80,N'Parametrizaciones válidas','ALERTA',N'NO VALIDABLE',N'Falta la tabla de parametrización.');

IF OBJECT_ID(N'dbo.ff_Menu',N'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        DECLARE @Menus int=(SELECT COUNT(*) FROM dbo.ff_Menu
                            WHERE MEIdEstatus=1
                              AND (LOWER(LTRIM(RTRIM(MERutaLiga))) IN
                                  (N''administracion/titulares/defaulteo'',N''/pages/administracion/titulares/defaulteo'',
                                   N''pages/administracion/titulares/defaulteo'')
                                   OR LOWER(LTRIM(RTRIM(MENombreMenu)))=N''defaulteo''));
        INSERT #Resultado VALUES
        (90,N''Menú de Defaulteo'',N''INFO'',CONCAT(N''Coincidencias activas='',@Menus),
         N''La asignación por empresa/rol no forma parte del consolidado porque requiere IDs propios del ambiente.'');';
END
ELSE
    INSERT #Resultado VALUES(90,N'Menú de Defaulteo','INFO',N'NO VALIDABLE',N'La tabla ff_Menu no existe en esta base.');

DECLARE @Alertas int=(SELECT COUNT(*) FROM #Resultado WHERE Estado='ALERTA');
INSERT #Resultado VALUES
(999,N'Resultado general',CASE WHEN @Alertas=0 THEN 'OK' ELSE 'ALERTA' END,
 CONCAT(N'Alertas=',@Alertas),N'La instalación de objetos se considera válida solamente cuando Alertas=0.');

SELECT Componente,Estado,Valor,Detalle
FROM #Resultado
ORDER BY Orden,Componente;
GO
