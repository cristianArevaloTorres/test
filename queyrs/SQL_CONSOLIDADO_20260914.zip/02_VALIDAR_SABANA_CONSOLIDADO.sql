﻿USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* Validación de solo lectura. Devuelve un único resultset. */
CREATE TABLE #Resultado
(
    Orden int NOT NULL,
    Componente nvarchar(80) NOT NULL,
    Estado varchar(10) NOT NULL,
    Valor nvarchar(500) NULL,
    Detalle nvarchar(max) NULL
);

INSERT #Resultado VALUES
(10,N'Contexto',N'INFO',CONCAT(CONVERT(nvarchar(128),SERVERPROPERTY('ServerName')),N' / ',DB_NAME()),N'Confirmar que sea la base utilizada por API Reports.');

DECLARE @Objetos TABLE(Orden int,Nombre sysname,Tipo char(2));
INSERT @Objetos VALUES
(20,N'ff_Sabana_BF3','P'),
(21,N'ff_SabanaGMM_BF3','P'),
(22,N'ff_SabanaVIDA_BF3','P'),
(23,N'ff_SabanaOPC_BF3','P'),
(24,N'ff_SabanaMascotas_BF3','P'),
(25,N'bf_RepConf_Debug','U'),
(26,N'bf_RepConf_Tabla','U'),
(27,N'bf_RepConf_Columna','U'),
(28,N'bf_CatReportesSP','U'),
(29,N'bf_CatReportesParams','U');

INSERT #Resultado
SELECT O.Orden,N'Objeto '+O.Nombre,
       CASE WHEN OBJECT_ID(N'dbo.'+O.Nombre,O.Tipo) IS NULL THEN 'ALERTA' ELSE 'OK' END,
       CASE WHEN OBJECT_ID(N'dbo.'+O.Nombre,O.Tipo) IS NULL THEN N'NO EXISTE' ELSE N'EXISTE' END,
       NULL
FROM @Objetos O;

DECLARE @Wrapper nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_Sabana_BF3',N'P')),
        @Opc nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaOPC_BF3',N'P'));

DECLARE @WrapperNorm nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
    ISNULL(@Wrapper,N''),N'[',N''),N']',N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N''));
DECLARE @OpcNorm nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
    ISNULL(@Opc,N''),N'[',N''),N']',N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N''));

INSERT #Resultado VALUES
(40,N'Ruta interna BF3',
 CASE WHEN @WrapperNorm LIKE N'%EXECDBO.FF_SABANAGMM_BF3%'
            AND @WrapperNorm LIKE N'%EXECDBO.FF_SABANAVIDA_BF3%'
            AND @WrapperNorm LIKE N'%EXECDBO.FF_SABANAOPC_BF3%'
            AND @WrapperNorm LIKE N'%EXECDBO.FF_SABANAMASCOTAS_BF3%'
            AND @WrapperNorm NOT LIKE N'%EXECDBO.FF_SABANA_V2%'
            AND @WrapperNorm NOT LIKE N'%EXECDBO.FF_SABANAGMM_V2%'
            AND @WrapperNorm NOT LIKE N'%EXECDBO.FF_SABANAVIDA_V2%'
            AND @WrapperNorm NOT LIKE N'%EXECDBO.FF_SABANAOPC_V2%'
      THEN 'OK' ELSE 'ALERTA' END,
 N'GMM + VIDA + OPCIONALES + MASCOTAS',
 N'El wrapper debe utilizar exclusivamente procedimientos BF3.'),
(41,N'Filtro Opcionales BF3',
 CASE WHEN @OpcNorm LIKE N'%SO.SOIDEMPRESA=POS.POIDEMPRESA%'
            AND @OpcNorm LIKE N'%SO.SOESTATUSSOLICITUDIN(1,3)%'
            AND @OpcNorm LIKE N'%CS.CSIDTIPOSABANA=3%'
            AND @OpcNorm LIKE N'%POIDEMPRESA=@IDEMPRESA%'
            AND @OpcNorm LIKE N'%POS.POIDVIGENCIA=@IDVIGENCIA%'
      THEN 'OK' ELSE 'ALERTA' END,
 N'Empresa + estatus activo + vigencia',
 N'Evita incluir solicitudes ajenas, canceladas o de otra vigencia.');

IF OBJECT_ID(N'dbo.bf_CatReportesSP',N'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        DECLARE @Activas int=(SELECT COUNT(*) FROM dbo.bf_CatReportesSP
                              WHERE catReportesId=3 AND ISNULL(ESid,1)=1),
                @Correctas int=(SELECT COUNT(*) FROM dbo.bf_CatReportesSP
                                WHERE catReportesId=3 AND ISNULL(ESid,1)=1
                                  AND catReportesSPNombre=N''ff_Sabana_BF3'');
        INSERT #Resultado VALUES
        (50,N''Ruta del reporte 3'',
         CASE WHEN @Activas=1 AND @Correctas=1 THEN ''OK'' ELSE ''ALERTA'' END,
         CONCAT(N''Activas='',@Activas,N''; BF3='',@Correctas),
         N''Debe existir una sola ruta activa y llamarse ff_Sabana_BF3.'');';
END
ELSE
    INSERT #Resultado VALUES(50,N'Ruta del reporte 3','ALERTA',N'NO VALIDABLE',N'Falta bf_CatReportesSP.');

IF OBJECT_ID(N'dbo.bf_CatReportesSP',N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.bf_CatReportesParams',N'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        DECLARE @Duplicados int,
                @Faltantes int,
                @Adicionales int;
        DECLARE @Esperados TABLE(Nombre nvarchar(100) PRIMARY KEY);
        INSERT @Esperados VALUES
        (N''@IDEMPRESA''),(N''@FECHAINI''),(N''@FECHAFIN''),
        (N''@IDESTATUS''),(N''@IDVIGENCIA''),(N''@CONFIDENCIAL'');

        ;WITH Ruta AS
        (
            SELECT catReportesSPId
            FROM dbo.bf_CatReportesSP
            WHERE catReportesId=3 AND ISNULL(ESid,1)=1
        ), D AS
        (
            SELECT UPPER(LTRIM(RTRIM(P.catReportesParamsNombre))) Nombre
            FROM dbo.bf_CatReportesParams P JOIN Ruta R ON R.catReportesSPId=P.catReportesSPId
            GROUP BY UPPER(LTRIM(RTRIM(P.catReportesParamsNombre)))
            HAVING COUNT(*)>1
        )
        SELECT @Duplicados=COUNT(*) FROM D;

        ;WITH Ruta AS
        (
            SELECT catReportesSPId
            FROM dbo.bf_CatReportesSP
            WHERE catReportesId=3 AND ISNULL(ESid,1)=1
        ), P AS
        (
            SELECT DISTINCT UPPER(LTRIM(RTRIM(X.catReportesParamsNombre))) Nombre
            FROM dbo.bf_CatReportesParams X
            JOIN Ruta R ON R.catReportesSPId=X.catReportesSPId
            WHERE ISNULL(X.ESid,1)=1
        )
        SELECT @Faltantes=(SELECT COUNT(*) FROM @Esperados E
                           WHERE NOT EXISTS(SELECT 1 FROM P WHERE P.Nombre=E.Nombre)),
               @Adicionales=(SELECT COUNT(*) FROM P
                             WHERE NOT EXISTS(SELECT 1 FROM @Esperados E WHERE E.Nombre=P.Nombre));

        INSERT #Resultado VALUES
        (51,N''Parámetros de Sábana'',
         CASE WHEN @Duplicados=0 AND @Faltantes=0 AND @Adicionales=0 THEN ''OK'' ELSE ''ALERTA'' END,
         CONCAT(N''Faltantes='',@Faltantes,N''; duplicados='',@Duplicados,N''; adicionales='',@Adicionales),
         N''Se esperan exactamente los seis argumentos del wrapper BF3.'');';
END
ELSE
    INSERT #Resultado VALUES(51,N'Parámetros de Sábana','ALERTA',N'NO VALIDABLE',N'Faltan tablas de configuración.');

CREATE TABLE #Ocultar(idEmpresa int,grupo nvarchar(20));
INSERT #Ocultar VALUES
(332,N'GMM'),(332,N'VIDA'),(856,N'GMM'),(856,N'VIDA'),
(1038,N'GMM'),(1038,N'VIDA'),(1039,N'GMM'),(1039,N'VIDA'),
(1806,N'GMM'),(1806,N'VIDA'),(1807,N'GMM'),(1807,N'VIDA');

CREATE TABLE #Restaurar(idEmpresa int,grupo nvarchar(20));
INSERT #Restaurar VALUES
(166,N'OPCIONALES'),(116,N'OPCIONALES'),(117,N'OPCIONALES'),
(856,N'OPCIONALES'),(1038,N'OPCIONALES');

CREATE TABLE #Campos(campo nvarchar(30),SoloVida bit);
INSERT #Campos VALUES
(N'CALLE',0),(N'NUMEXT',0),(N'NUMINT',0),(N'COLONIA',0),
(N'DEL_MUNICIPIO',0),(N'ESTADOFISCAL',0),(N'CP',0),
(N'PRIMANETA',1),(N'PRIMENETA',1),(N'COSTO',1);

IF OBJECT_ID(N'dbo.bf_RepConf_Columna',N'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        DECLARE @FaltantesOcultar int=(
            SELECT COUNT(*)
            FROM #Ocultar O
            JOIN #Campos F ON F.SoloVida=0 OR O.grupo=N''VIDA''
            WHERE NOT EXISTS
            (
                SELECT 1
                FROM dbo.bf_RepConf_Columna C
                WHERE C.idEmpresa=O.idEmpresa
                  AND C.catReportesId=3
                  AND CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                    (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                                THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END=O.grupo
                  AND UPPER(LTRIM(RTRIM(C.campoOrigen)))=F.campo
            )
        );
        DECLARE @VisiblesIndebidas int=(
            SELECT COUNT(*)
            FROM dbo.bf_RepConf_Columna C
            JOIN #Ocultar O ON O.idEmpresa=C.idEmpresa
             AND O.grupo=CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                  (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                              THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END
            JOIN #Campos F ON F.campo=UPPER(LTRIM(RTRIM(C.campoOrigen)))
             AND (F.SoloVida=0 OR O.grupo=N''VIDA'')
            WHERE C.catReportesId=3 AND ISNULL(C.visible,1)<>0
        );
        DECLARE @DuplicadosOcultar int=(
            SELECT COUNT(*)
            FROM
            (
                SELECT C.idEmpresa,
                       CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                      (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                            THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END grupo,
                       UPPER(LTRIM(RTRIM(C.campoOrigen))) campo
                FROM dbo.bf_RepConf_Columna C
                JOIN #Ocultar O ON O.idEmpresa=C.idEmpresa
                 AND O.grupo=CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                      (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                                  THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END
                JOIN #Campos F ON F.campo=UPPER(LTRIM(RTRIM(C.campoOrigen)))
                 AND (F.SoloVida=0 OR O.grupo=N''VIDA'')
                WHERE C.catReportesId=3
                GROUP BY C.idEmpresa,
                         CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                        (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                              THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END,
                         UPPER(LTRIM(RTRIM(C.campoOrigen)))
                HAVING COUNT(*)>1
            ) D
        );
        DECLARE @FaltantesRestaurar int=(
            SELECT COUNT(*)
            FROM #Restaurar R
            JOIN #Campos F ON F.SoloVida=0
            WHERE NOT EXISTS
            (
                SELECT 1
                FROM dbo.bf_RepConf_Columna C
                WHERE C.idEmpresa=R.idEmpresa
                  AND C.catReportesId=3
                  AND CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                    (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                                THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END=R.grupo
                  AND UPPER(LTRIM(RTRIM(C.campoOrigen)))=F.campo
            )
        );
        DECLARE @OcultasIndebidas int=(
            SELECT COUNT(*)
            FROM dbo.bf_RepConf_Columna C
            JOIN #Restaurar R ON R.idEmpresa=C.idEmpresa
             AND R.grupo=CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                  (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                              THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END
            JOIN #Campos F ON F.campo=UPPER(LTRIM(RTRIM(C.campoOrigen))) AND F.SoloVida=0
            WHERE C.catReportesId=3 AND ISNULL(C.visible,1)=0
        );
        DECLARE @DuplicadosRestaurar int=(
            SELECT COUNT(*)
            FROM
            (
                SELECT C.idEmpresa,
                       CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                      (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                            THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END grupo,
                       UPPER(LTRIM(RTRIM(C.campoOrigen))) campo
                FROM dbo.bf_RepConf_Columna C
                JOIN #Restaurar R ON R.idEmpresa=C.idEmpresa
                 AND R.grupo=CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                      (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                                  THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END
                JOIN #Campos F ON F.campo=UPPER(LTRIM(RTRIM(C.campoOrigen))) AND F.SoloVida=0
                WHERE C.catReportesId=3
                GROUP BY C.idEmpresa,
                         CASE WHEN UPPER(LTRIM(RTRIM(C.grupo))) IN
                                        (N''OPC'',N''OPCIONAL'',N''OPCIONALES'')
                              THEN N''OPCIONALES'' ELSE UPPER(LTRIM(RTRIM(C.grupo))) END,
                         UPPER(LTRIM(RTRIM(C.campoOrigen)))
                HAVING COUNT(*)>1
            ) D
        );
        INSERT #Resultado VALUES
        (60,N''Matriz de ocultamiento'',CASE WHEN @FaltantesOcultar=0 AND @VisiblesIndebidas=0 AND @DuplicadosOcultar=0 THEN ''OK'' ELSE ''ALERTA'' END,
         CONCAT(N''Faltantes='',@FaltantesOcultar,N''; visibles indebidas='',@VisiblesIndebidas,N''; duplicados='',@DuplicadosOcultar),
         N''Direcciones y, en Vida, prima/costo deben quedar ocultos para las empresas objetivo.''),
        (61,N''Columnas que deben permanecer visibles'',CASE WHEN @FaltantesRestaurar=0 AND @OcultasIndebidas=0 AND @DuplicadosRestaurar=0 THEN ''OK'' ELSE ''ALERTA'' END,
         CONCAT(N''Faltantes='',@FaltantesRestaurar,N''; ocultas indebidas='',@OcultasIndebidas,N''; duplicados='',@DuplicadosRestaurar),
         N''ATT, SSGT y Opcionales de Corteva/BH no deben heredar el ocultamiento.'');';
END
ELSE
BEGIN
    INSERT #Resultado VALUES(60,N'Matriz de ocultamiento','ALERTA',N'NO VALIDABLE',N'Falta bf_RepConf_Columna.');
    INSERT #Resultado VALUES(61,N'Columnas que deben permanecer visibles','ALERTA',N'NO VALIDABLE',N'Falta bf_RepConf_Columna.');
END;

IF OBJECT_ID(N'dbo.bf_RepConf_Tabla',N'U') IS NOT NULL
   AND OBJECT_ID(N'dbo.bf_RepConf_Columna',N'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        DECLARE @Tablas int=(SELECT COUNT(*) FROM dbo.bf_RepConf_Tabla
                             WHERE idEmpresa=0 AND catReportesId=3 AND grupo=N''Mascotas'' AND activo=1),
                @Columnas int=(SELECT COUNT(*) FROM dbo.bf_RepConf_Columna
                               WHERE idEmpresa=0 AND catReportesId=3 AND grupo=N''Mascotas'');
        INSERT #Resultado VALUES
        (70,N''Configuración Mascotas'',CASE WHEN @Tablas=1 AND @Columnas=19 THEN ''OK'' ELSE ''ALERTA'' END,
         CONCAT(N''Tablas='',@Tablas,N''; columnas='',@Columnas),N''Se espera una tabla activa y 19 columnas.'');';
END
ELSE
    INSERT #Resultado VALUES(70,N'Configuración Mascotas','ALERTA',N'NO VALIDABLE',N'Faltan tablas de configuración.');

DECLARE @Alertas int=(SELECT COUNT(*) FROM #Resultado WHERE Estado='ALERTA');
INSERT #Resultado VALUES
(999,N'Resultado general',CASE WHEN @Alertas=0 THEN 'OK' ELSE 'ALERTA' END,
 CONCAT(N'Alertas=',@Alertas),N'La instalación se considera válida solamente cuando Alertas=0.');

SELECT Componente,Estado,Valor,Detalle
FROM #Resultado
ORDER BY Orden,Componente;
GO
