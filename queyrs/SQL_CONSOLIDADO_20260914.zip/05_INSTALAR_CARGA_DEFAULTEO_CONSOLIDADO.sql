﻿/*
    INSTALACION CONSOLIDADA - CARGA MASIVA Y DEFAULTEO
    Generada: 2026-09-14

    Integra infraestructura, seguridad, busqueda, bitacora, reporte historico,
    correccion multivigencia y parametrizacion B2/B3.

    Se excluyen deliberadamente:
      - 06_CONFIGURAR_MENU...--NO MANDAR.sql: especifico de empresa 186/rol 570.
      - 09_menu.sql: contiene sintaxis invalida, IDs fijos y una ruta obsoleta.
    La asignacion de menu debe realizarse con los IDs propios de cada ambiente.
*/
USE [FlexiForbesv2];
GO
SET NOEXEC OFF;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* ==========================================================================
   00. Prechequeo: cancela antes de cualquier cambio si falta una dependencia
   ========================================================================== */
DECLARE @FaltantesCarga TABLE(Requisito nvarchar(300) NOT NULL);

IF DB_NAME() IN (N'master',N'model',N'msdb',N'tempdb')
    INSERT @FaltantesCarga VALUES(N'Seleccione la base funcional FlexiForbesv2.');
IF OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmp',N'P') IS NULL
    INSERT @FaltantesCarga VALUES(N'Falta dbo.ff_IInsertaPlanesFlexiblesTmp.');
IF OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3',N'P') IS NULL
    INSERT @FaltantesCarga VALUES(N'Falta dbo.ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3.');
IF OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmpCreditos',N'P') IS NULL
    INSERT @FaltantesCarga VALUES(N'Falta dbo.ff_IInsertaPlanesFlexiblesTmpCreditos.');
IF OBJECT_ID(N'dbo.ff_Empresa',N'U') IS NULL
    INSERT @FaltantesCarga VALUES(N'Falta dbo.ff_Empresa.');
IF OBJECT_ID(N'dbo.ff_Empleado',N'U') IS NULL
    INSERT @FaltantesCarga VALUES(N'Falta dbo.ff_Empleado.');
IF OBJECT_ID(N'dbo.ff_Solicitud',N'U') IS NULL
    INSERT @FaltantesCarga VALUES(N'Falta dbo.ff_Solicitud.');

DECLARE @LlamadaAnteriorCarga nvarchar(500)=
N'exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp';

IF OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmp',N'P') IS NOT NULL
   AND OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmp',N'P')) NOT LIKE N'%IdCorporativoCompat%'
   AND CHARINDEX(@LlamadaAnteriorCarga,
                 OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmp',N'P')))=0
    INSERT @FaltantesCarga VALUES(N'La version de ff_IInsertaPlanesFlexiblesTmp no contiene la llamada compatible que debe corregirse.');

IF OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3',N'P') IS NOT NULL
   AND OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3',N'P')) NOT LIKE N'%IdCorporativoCompat%'
   AND CHARINDEX(@LlamadaAnteriorCarga,
                 OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3',N'P')))=0
    INSERT @FaltantesCarga VALUES(N'La version de ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3 no contiene la llamada compatible que debe corregirse.');

IF EXISTS(SELECT 1 FROM @FaltantesCarga)
BEGIN
    SELECT N'PRECHEQUEO_CANCELADO' AS Estado,Requisito
    FROM @FaltantesCarga
    ORDER BY Requisito;
    RAISERROR(N'[CARGA/DEFAULTEO] Instalacion cancelada: faltan dependencias base.',16,1);
    SET NOEXEC ON;
END;

GO

/* ==========================================================================
   01. Infraestructura y bitacora de lotes
   ========================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.bf_ConfiguracionDefaulteo', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_ConfiguracionDefaulteo
    (
        CDId             INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_bf_ConfiguracionDefaulteo PRIMARY KEY,
        CDNombre         VARCHAR(150) NOT NULL,
        CDDescripcion    VARCHAR(500) NULL,
        CDIdCorporativo  INT NULL,
        CDIdEmpresa      INT NULL,
        CDIdAdmin        INT NOT NULL,
        CDFiltrosJson    NVARCHAR(MAX) NOT NULL,
        CDAccionesJson   NVARCHAR(MAX) NULL,
        CDIdEstatus      INT NOT NULL
            CONSTRAINT DF_bf_ConfiguracionDefaulteo_Estatus DEFAULT (1),
        CDFechaAdd       DATETIME NOT NULL
            CONSTRAINT DF_bf_ConfiguracionDefaulteo_FechaAdd DEFAULT (GETDATE()),
        CDFechaUmod      DATETIME NULL,
        CDUsuarioUmod    INT NULL
    );

    CREATE INDEX IX_bf_ConfiguracionDefaulteo_Admin
        ON dbo.bf_ConfiguracionDefaulteo (CDIdAdmin, CDIdEstatus)
        INCLUDE (CDIdEmpresa, CDIdCorporativo, CDNombre);
END;
GO

IF OBJECT_ID(N'dbo.bf_LogDefaulteo', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_LogDefaulteo
    (
        LDId               INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_bf_LogDefaulteo PRIMARY KEY,
        LDIdConfiguracion  INT NULL,
        LDIdCorporativo    INT NULL,
        LDIdEmpresa        INT NULL,
        LDIdVigencia       INT NULL,
        LDIdAdmin          INT NOT NULL,
        LDFiltrosJson      NVARCHAR(MAX) NULL,
        LDAccionesJson     NVARCHAR(MAX) NULL,
        LDTotalEmpleados   INT NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Total DEFAULT (0),
        LDTotalExitosos    INT NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Exitosos DEFAULT (0),
        LDTotalErrores     INT NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Errores DEFAULT (0),
        LDFechaInicio      DATETIME NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Inicio DEFAULT (GETDATE()),
        LDFechaFin         DATETIME NULL,
        LDDuracionMs       BIGINT NULL,
        LDIpOrigen         VARCHAR(64) NULL,
        LDOrigen           VARCHAR(30) NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Origen DEFAULT ('AVANZADO'),
        LDEstado           VARCHAR(30) NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Estado DEFAULT ('EN_PROCESO')
    );

    CREATE INDEX IX_bf_LogDefaulteo_AdminFecha
        ON dbo.bf_LogDefaulteo (LDIdAdmin, LDFechaInicio DESC)
        INCLUDE (LDEstado, LDTotalEmpleados, LDTotalExitosos, LDTotalErrores);
END;
GO

IF OBJECT_ID(N'dbo.bf_LogErroresDefaulteo', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_LogErroresDefaulteo
    (
        LEDId               INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_bf_LogErroresDefaulteo PRIMARY KEY,
        LEDIdLog            INT NOT NULL,
        LEDIdEmpleado       INT NULL,
        LEDNumeroEmpleado   VARCHAR(100) NULL,
        LEDIdEmpresa        INT NULL,
        LEDIdPerfil         INT NULL,
        LEDTipoEvento       VARCHAR(30) NOT NULL,
        LEDMensaje          NVARCHAR(2000) NULL,
        LEDStackTrace       NVARCHAR(MAX) NULL,
        LEDContextoJson     NVARCHAR(MAX) NULL,
        LEDFechaAdd         DATETIME NOT NULL
            CONSTRAINT DF_bf_LogErroresDefaulteo_FechaAdd DEFAULT (GETDATE())
    );

    CREATE INDEX IX_bf_LogErroresDefaulteo_Log
        ON dbo.bf_LogErroresDefaulteo (LEDIdLog, LEDId)
        INCLUDE (LEDIdEmpleado, LEDNumeroEmpleado, LEDTipoEvento, LEDFechaAdd);
END;
GO

/* Si las tablas ya existian, se detiene ante un contrato incompatible. */
DECLARE @Faltantes TABLE (Objeto SYSNAME, Columna SYSNAME);

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_ConfiguracionDefaulteo', V.Columna
FROM (VALUES
    (N'CDId'), (N'CDNombre'), (N'CDDescripcion'), (N'CDIdCorporativo'),
    (N'CDIdEmpresa'), (N'CDIdAdmin'), (N'CDFiltrosJson'),
    (N'CDAccionesJson'), (N'CDIdEstatus'), (N'CDFechaAdd'),
    (N'CDFechaUmod'), (N'CDUsuarioUmod')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_ConfiguracionDefaulteo', V.Columna) IS NULL;

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_LogDefaulteo', V.Columna
FROM (VALUES
    (N'LDId'), (N'LDIdConfiguracion'), (N'LDIdCorporativo'),
    (N'LDIdEmpresa'), (N'LDIdVigencia'), (N'LDIdAdmin'),
    (N'LDFiltrosJson'), (N'LDAccionesJson'), (N'LDTotalEmpleados'),
    (N'LDTotalExitosos'), (N'LDTotalErrores'), (N'LDFechaInicio'),
    (N'LDFechaFin'), (N'LDDuracionMs'), (N'LDIpOrigen'),
    (N'LDOrigen'), (N'LDEstado')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_LogDefaulteo', V.Columna) IS NULL;

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_LogErroresDefaulteo', V.Columna
FROM (VALUES
    (N'LEDId'), (N'LEDIdLog'), (N'LEDIdEmpleado'),
    (N'LEDNumeroEmpleado'), (N'LEDIdEmpresa'), (N'LEDIdPerfil'),
    (N'LEDTipoEvento'), (N'LEDMensaje'), (N'LEDStackTrace'),
    (N'LEDContextoJson'), (N'LEDFechaAdd')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_LogErroresDefaulteo', V.Columna) IS NULL;

IF EXISTS (SELECT 1 FROM @Faltantes)
BEGIN
    SELECT 'COLUMNAS_REQUERIDAS_FALTANTES' AS Bloque, Objeto, Columna
    FROM @Faltantes ORDER BY Objeto, Columna;
    THROW 51900, 'Existe una tabla bf_* de Defaulteo con contrato incompatible. No se reemplazo ni altero.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_IniciarLote
    @IdConfiguracion INT = NULL,
    @IdCorporativo   INT = NULL,
    @IdEmpresa       INT = NULL,
    @IdVigencia      INT = NULL,
    @IdAdmin         INT,
    @FiltrosJson     NVARCHAR(MAX) = NULL,
    @AccionesJson    NVARCHAR(MAX) = NULL,
    @TotalEmpleados  INT,
    @IpOrigen        VARCHAR(64) = NULL,
    @Origen          VARCHAR(30) = 'AVANZADO',
    @IdLog           INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @IdAdmin <= 0
        THROW 51901, 'IdAdmin invalido para iniciar el lote.', 1;
    IF ISNULL(@TotalEmpleados, 0) <= 0
        THROW 51902, 'El lote debe contener al menos un empleado.', 1;

    INSERT dbo.bf_LogDefaulteo
    (
        LDIdConfiguracion, LDIdCorporativo, LDIdEmpresa, LDIdVigencia,
        LDIdAdmin, LDFiltrosJson, LDAccionesJson, LDTotalEmpleados,
        LDTotalExitosos, LDTotalErrores, LDFechaInicio, LDIpOrigen,
        LDOrigen, LDEstado
    )
    VALUES
    (
        @IdConfiguracion, @IdCorporativo, @IdEmpresa, @IdVigencia,
        @IdAdmin, @FiltrosJson, @AccionesJson, @TotalEmpleados,
        0, 0, GETDATE(), @IpOrigen, COALESCE(NULLIF(@Origen, ''), 'AVANZADO'),
        'EN_PROCESO'
    );

    SET @IdLog = CONVERT(INT, SCOPE_IDENTITY());
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_RegistrarEvento
    @IdLog          INT,
    @IdEmpleado     INT = NULL,
    @NumeroEmpleado VARCHAR(100) = NULL,
    @IdEmpresa      INT = NULL,
    @IdPerfil       INT = NULL,
    @TipoEvento     VARCHAR(30),
    @Mensaje        NVARCHAR(2000) = NULL,
    @StackTrace     NVARCHAR(MAX) = NULL,
    @ContextoJson   NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM dbo.bf_LogDefaulteo WHERE LDId = @IdLog)
        THROW 51903, 'El lote indicado no existe.', 1;

    INSERT dbo.bf_LogErroresDefaulteo
    (
        LEDIdLog, LEDIdEmpleado, LEDNumeroEmpleado, LEDIdEmpresa,
        LEDIdPerfil, LEDTipoEvento, LEDMensaje, LEDStackTrace,
        LEDContextoJson, LEDFechaAdd
    )
    VALUES
    (
        @IdLog, @IdEmpleado, @NumeroEmpleado, @IdEmpresa,
        @IdPerfil, COALESCE(NULLIF(@TipoEvento, ''), 'EVENTO'), @Mensaje,
        @StackTrace, @ContextoJson, GETDATE()
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_FinalizarLote
    @IdLog          INT,
    @TotalEmpleados INT,
    @TotalExitosos  INT,
    @TotalErrores   INT,
    @Estado         VARCHAR(30)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.bf_LogDefaulteo
       SET LDTotalEmpleados = ISNULL(@TotalEmpleados, LDTotalEmpleados),
           LDTotalExitosos = ISNULL(@TotalExitosos, 0),
           LDTotalErrores = ISNULL(@TotalErrores, 0),
           LDFechaFin = GETDATE(),
           LDDuracionMs = DATEDIFF_BIG(MILLISECOND, LDFechaInicio, GETDATE()),
           LDEstado = COALESCE(NULLIF(@Estado, ''), 'FINALIZADO')
     WHERE LDId = @IdLog;

    IF @@ROWCOUNT = 0
        THROW 51904, 'El lote indicado no existe.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_ConsultarLote
    @IdLog INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        LDId AS idLog,
        LDEstado AS estado,
        LDTotalEmpleados AS totalEmpleados,
        LDTotalExitosos + LDTotalErrores AS procesados,
        LDTotalExitosos AS totalExitosos,
        LDTotalErrores AS totalErrores,
        LDFechaInicio AS fechaInicio,
        LDFechaFin AS fechaFin,
        LDDuracionMs AS duracionMs,
        LDOrigen AS origen
    FROM dbo.bf_LogDefaulteo
    WHERE LDId = @IdLog;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_ObtenerEventos
    @IdLog INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        LEDId, LEDIdLog, LEDIdEmpleado, LEDNumeroEmpleado, LEDIdEmpresa,
        LEDIdPerfil, LEDTipoEvento, LEDMensaje, LEDStackTrace,
        LEDContextoJson, LEDFechaAdd
    FROM dbo.bf_LogErroresDefaulteo
    WHERE LEDIdLog = @IdLog
    ORDER BY LEDId;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Listar
    @IdCorporativo INT = NULL,
    @IdEmpresa     INT = NULL,
    @IdAdmin       INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        CDId AS id,
        CDNombre AS nombre,
        CDDescripcion AS descripcion,
        CDIdCorporativo AS idCorporativo,
        CDIdEmpresa AS idEmpresa,
        CDIdAdmin AS idAdmin,
        CDFiltrosJson AS filtrosJson,
        CDAccionesJson AS accionesJson
    FROM dbo.bf_ConfiguracionDefaulteo
    WHERE CDIdAdmin = @IdAdmin
      AND CDIdEstatus = 1
      AND (@IdCorporativo IS NULL OR CDIdCorporativo IS NULL OR CDIdCorporativo = @IdCorporativo)
      AND (@IdEmpresa IS NULL OR CDIdEmpresa IS NULL OR CDIdEmpresa = @IdEmpresa)
    ORDER BY CDNombre, CDId;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_DefaulteoAvanzado_ListarPerfilesEmpresa
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        P.PEIdPerfil AS idPerfil,
        P.PEDescripcion AS nombrePerfil
    FROM dbo.ff_Perfil P
    WHERE P.PEIdEmpresa = @IdEmpresa
      AND P.PEIdEstatus = 1
    ORDER BY P.PEDescripcion, P.PEIdPerfil;
END;
GO

SELECT
    'INFRAESTRUCTURA_LOTES_DEFAULTEO' AS Bloque,
    O.Tipo,
    O.Nombre,
    CASE
        WHEN O.Tipo = 'TABLA' AND OBJECT_ID(N'dbo.' + O.Nombre, N'U') IS NOT NULL THEN 'OK'
        WHEN O.Tipo = 'SP' AND OBJECT_ID(N'dbo.' + O.Nombre, N'P') IS NOT NULL THEN 'OK'
        ELSE 'FALTA'
    END AS Resultado
FROM (VALUES
    ('TABLA', 'bf_ConfiguracionDefaulteo'),
    ('TABLA', 'bf_LogDefaulteo'),
    ('TABLA', 'bf_LogErroresDefaulteo'),
    ('SP', 'bf_LogDefaulteo_IniciarLote'),
    ('SP', 'bf_LogDefaulteo_RegistrarEvento'),
    ('SP', 'bf_LogDefaulteo_FinalizarLote'),
    ('SP', 'bf_LogDefaulteo_ConsultarLote'),
    ('SP', 'bf_LogDefaulteo_ObtenerEventos'),
    ('SP', 'bf_ConfiguracionDefaulteo_Listar'),
    ('SP', 'bf_DefaulteoAvanzado_ListarPerfilesEmpresa')
) O(Tipo, Nombre)
ORDER BY O.Tipo, O.Nombre;
GO

GO

/* ==========================================================================
   02. Seguridad, vigencia y configuraciones
   ========================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.bf_DefaulteoAvanzado_ResolverVigencia
    @IdEmpresa INT,
    @IdVigenciaSeleccionada INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdConfiguracion INT;
    DECLARE @IdVigenciaActual INT;
    DECLARE @IdVigenciaAnterior INT;
    DECLARE @EsValida BIT = 0;

    SELECT @IdConfiguracion = EMIdConfiguracion
    FROM dbo.ff_Empresa
    WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1;

    IF EXISTS (
        SELECT 1 FROM dbo.ff_Vigencia
        WHERE VIIdVigencia = @IdVigenciaSeleccionada
          AND VIIdConfiguracion = @IdConfiguracion
          AND VIIdEstatus = 1)
    BEGIN
        SET @EsValida = 1;
        SELECT @IdVigenciaAnterior = VIRenovada
        FROM dbo.ff_Vigencia
        WHERE VIIdVigencia = @IdVigenciaSeleccionada;
    END;

    SELECT TOP (1) @IdVigenciaActual = VIIdVigencia
    FROM dbo.ff_Vigencia
    WHERE VIIdConfiguracion = @IdConfiguracion
      AND VIIdEstatus = 1
      AND CONVERT(DATE, GETDATE()) BETWEEN CONVERT(DATE, VIVigenciaIni) AND CONVERT(DATE, VIVigenciaFin)
    ORDER BY VIVigenciaIni DESC, VIIdVigencia DESC;

    IF @IdVigenciaActual IS NULL
        SELECT TOP (1) @IdVigenciaActual = VIIdVigencia
        FROM dbo.ff_Vigencia
        WHERE VIIdConfiguracion = @IdConfiguracion AND VIIdEstatus = 1
        ORDER BY VIVigenciaIni DESC, VIIdVigencia DESC;

    SELECT
        @EsValida AS esValida,
        CONVERT(BIT, CASE WHEN @EsValida = 1 AND @IdVigenciaSeleccionada = @IdVigenciaActual THEN 1 ELSE 0 END) AS esActual,
        @IdVigenciaActual AS idVigenciaActual,
        @IdVigenciaAnterior AS idVigenciaAnterior;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Guardar
    @Id              INT           = NULL,
    @Nombre          VARCHAR(150),
    @Descripcion     VARCHAR(500)  = NULL,
    @IdCorporativo   INT           = NULL,
    @IdEmpresa       INT           = NULL,
    @IdAdmin         INT,
    @FiltrosJson     NVARCHAR(MAX),
    @AccionesJson    NVARCHAR(MAX) = NULL,
    @IdResult        INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @IdResult = 0;

    IF @Id IS NULL OR @Id = 0
    BEGIN
        INSERT INTO dbo.bf_ConfiguracionDefaulteo
            (CDNombre, CDDescripcion, CDIdCorporativo, CDIdEmpresa, CDIdAdmin,
             CDFiltrosJson, CDAccionesJson, CDIdEstatus, CDFechaAdd)
        VALUES
            (@Nombre, @Descripcion, @IdCorporativo, @IdEmpresa, @IdAdmin,
             @FiltrosJson, @AccionesJson, 1, GETDATE());
        SET @IdResult = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.bf_ConfiguracionDefaulteo
           SET CDNombre = @Nombre,
               CDDescripcion = @Descripcion,
               CDIdCorporativo = @IdCorporativo,
               CDIdEmpresa = @IdEmpresa,
               CDFiltrosJson = @FiltrosJson,
               CDAccionesJson = @AccionesJson,
               CDFechaUmod = GETDATE(),
               CDUsuarioUmod = @IdAdmin
         WHERE CDId = @Id
           AND CDIdAdmin = @IdAdmin
           AND CDIdEstatus = 1;
        IF @@ROWCOUNT = 1 SET @IdResult = @Id;
    END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Eliminar
    @Id      INT,
    @IdAdmin INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.bf_ConfiguracionDefaulteo
       SET CDIdEstatus = 2,
           CDFechaUmod = GETDATE(),
           CDUsuarioUmod = @IdAdmin
     WHERE CDId = @Id
       AND CDIdAdmin = @IdAdmin
       AND CDIdEstatus = 1;
END;
GO

GO

/* ==========================================================================
   03. Compatibilidad IdCorporativo de insercion de planes
   ========================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Objetos TABLE (Nombre sysname PRIMARY KEY);
INSERT @Objetos(Nombre) VALUES
 ('ff_IInsertaPlanesFlexiblesTmp'),
 ('ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3');

DECLARE @Nombre sysname,@Def nvarchar(max),@PosProc int,@CallOld nvarchar(500),@CallNew nvarchar(1000);
DECLARE C CURSOR LOCAL FAST_FORWARD FOR SELECT Nombre FROM @Objetos ORDER BY Nombre;
OPEN C;
FETCH NEXT FROM C INTO @Nombre;
WHILE @@FETCH_STATUS=0
BEGIN
  SET @Def=OBJECT_DEFINITION(OBJECT_ID(N'dbo.'+@Nombre,N'P'));
  IF @Def IS NULL
    THROW 51501,'No existe uno de los procedimientos caller que debe corregirse.',1;

  IF CHARINDEX('IdCorporativoCompat',@Def)=0
  BEGIN
    SET @CallOld=N'exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp';
    IF CHARINDEX(@CallOld,@Def)=0
      THROW 51502,'No se encontro la invocacion de seis parametros esperada. Revise la version del procedimiento.',1;

    SET @CallNew=N'DECLARE @IdCorporativoCompat int =
      (SELECT TOP (1) EMIdCorporativo FROM dbo.ff_Empresa WHERE EMIdEmpresa=@idEmpresa);
exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp,@IdCorporativoCompat';
    SET @Def=REPLACE(@Def,@CallOld,@CallNew);

    SET @PosProc=CHARINDEX('PROCEDURE',UPPER(@Def));
    IF @PosProc=0 THROW 51503,'La definicion no contiene PROCEDURE.',1;
    SET @Def=STUFF(@Def,1,@PosProc-1,'ALTER ');
    EXEC sys.sp_executesql @Def;
  END;

  FETCH NEXT FROM C INTO @Nombre;
END;
CLOSE C;
DEALLOCATE C;

SELECT P.name,
       CASE WHEN OBJECT_DEFINITION(P.object_id) LIKE '%IdCorporativoCompat%'
            THEN 'OK' ELSE 'REVISAR' END Resultado
FROM sys.procedures P
WHERE P.name IN('ff_IInsertaPlanesFlexiblesTmp','ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3')
ORDER BY P.name;

GO

/* ==========================================================================
   04. Busqueda avanzada con exclusion de solicitudes generadas
   ========================================================================== */
CREATE OR ALTER PROCEDURE [dbo].[bf_DefaulteoAvanzado_Buscar]
    @IdCorporativo         INT,
    @IdVigencia            INT,
    @IdsEmpresa            NVARCHAR(MAX) = NULL, -- CSV
    @IdsPerfil             NVARCHAR(MAX) = NULL, -- CSV
    @IdsOficina            NVARCHAR(MAX) = NULL, -- CSV
    @IdsArea               NVARCHAR(MAX) = NULL, -- CSV
    @IdsSexo               NVARCHAR(MAX) = NULL, -- CSV
    @IdsParentesco         NVARCHAR(MAX) = NULL, -- CSV
    @IdsPlan               NVARCHAR(MAX) = NULL, -- CSV (plan asignado actual)
    @IdsCobertura          NVARCHAR(MAX) = NULL, -- CSV
    @NumerosEmpleado       NVARCHAR(MAX) = NULL, -- CSV
    @SalarioMin            DECIMAL(18,2) = NULL,
    @SalarioMax            DECIMAL(18,2) = NULL,
    @SumaAseguradaMin      DECIMAL(18,2) = NULL,
    @SumaAseguradaMax      DECIMAL(18,2) = NULL,
    @FechaIngresoIni       DATETIME      = NULL,
    @FechaIngresoFin       DATETIME      = NULL,
    @FechaAntiguedadIni    DATETIME      = NULL,
    @FechaAntiguedadFin    DATETIME      = NULL,
    @FechaNacimientoIni    DATETIME      = NULL,
    @FechaNacimientoFin    DATETIME      = NULL,
    @FechaVigenciaIni      DATETIME      = NULL,
    @FechaVigenciaFin      DATETIME      = NULL,
    -- Filtros adicionales del Anexo del documento CREA06
    @Nombre                VARCHAR(150)  = NULL, -- LIKE
    @ApellidoPaterno       VARCHAR(150)  = NULL, -- LIKE
    @ApellidoMaterno       VARCHAR(150)  = NULL, -- LIKE
    @EdadMin               INT           = NULL,
    @EdadMax               INT           = NULL,
    @Top                   INT           = 1000
AS
BEGIN
    SET NOCOUNT ON;

    -- Normalizar CSVs a tablas temporales (solo si vienen poblados)
    DECLARE @tEmpresas    TABLE (Id INT);
    DECLARE @tPerfiles    TABLE (Id INT);
    DECLARE @tOficinas    TABLE (Id INT);
    DECLARE @tAreas       TABLE (Id INT);
    DECLARE @tSexos       TABLE (Id INT);
    DECLARE @tParentescos TABLE (Id INT);
    DECLARE @tPlanes      TABLE (Id INT);
    DECLARE @tCoberturas  TABLE (Id INT);
    DECLARE @tNumEmp      TABLE (NumeroEmpleado VARCHAR(50));

    IF (@IdsEmpresa     IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsEmpresa))) > 0)
        INSERT INTO @tEmpresas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsEmpresa, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsPerfil      IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsPerfil))) > 0)
        INSERT INTO @tPerfiles (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsPerfil, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsOficina     IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsOficina))) > 0)
        INSERT INTO @tOficinas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsOficina, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsArea        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsArea))) > 0)
        INSERT INTO @tAreas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsArea, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsSexo        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsSexo))) > 0)
        INSERT INTO @tSexos (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsSexo, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsParentesco  IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsParentesco))) > 0)
        INSERT INTO @tParentescos (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsParentesco, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsPlan        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsPlan))) > 0)
        INSERT INTO @tPlanes (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsPlan, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsCobertura   IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsCobertura))) > 0)
        INSERT INTO @tCoberturas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsCobertura, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@NumerosEmpleado IS NOT NULL AND LEN(LTRIM(RTRIM(@NumerosEmpleado))) > 0)
        INSERT INTO @tNumEmp (NumeroEmpleado) SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(@NumerosEmpleado, ',') WHERE LTRIM(RTRIM(value)) <> '';

    DECLARE @hayEmpresas    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tEmpresas)    THEN 1 ELSE 0 END;
    DECLARE @hayPerfiles    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tPerfiles)    THEN 1 ELSE 0 END;
    DECLARE @hayOficinas    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tOficinas)    THEN 1 ELSE 0 END;
    DECLARE @hayAreas       BIT = CASE WHEN EXISTS(SELECT 1 FROM @tAreas)       THEN 1 ELSE 0 END;
    DECLARE @haySexos       BIT = CASE WHEN EXISTS(SELECT 1 FROM @tSexos)       THEN 1 ELSE 0 END;
    DECLARE @hayParentescos BIT = CASE WHEN EXISTS(SELECT 1 FROM @tParentescos) THEN 1 ELSE 0 END;
    DECLARE @hayPlanes      BIT = CASE WHEN EXISTS(SELECT 1 FROM @tPlanes)      THEN 1 ELSE 0 END;
    DECLARE @hayCoberturas  BIT = CASE WHEN EXISTS(SELECT 1 FROM @tCoberturas)  THEN 1 ELSE 0 END;
    DECLARE @hayNumEmp      BIT = CASE WHEN EXISTS(SELECT 1 FROM @tNumEmp)      THEN 1 ELSE 0 END;

    SELECT TOP (@Top)
        e.Id                       AS idEmpleado,
        e.EMNumeroEmpleado         AS numeroEmpleado,
        e.EMApellidoPaterno        AS apellidoPaterno,
        e.EMApellidoMaterno        AS apellidoMaterno,
        e.EMNombre1                AS nombre1,
        e.EMNombre2                AS nombre2,
        e.EMFechaNacimiento        AS fechaNacimiento,
        e.EMEdad                   AS edad,
        e.EMFechaIngresoEmpresa    AS fechaIngreso,
        e.EMFechaAntiguedadGmm     AS fechaAntiguedad,
        e.EMIdEmpresa              AS idEmpresa,
        emp.EMRazonSocial          AS razonSocial,
        e.EMIdPerfil               AS idPerfil,
        per.PEDescripcion          AS perfil,
        e.EMOficina                AS idOficina,
        e.EMArea                   AS idArea,
        e.EMSalarioBase            AS salarioBase,
        e.EMIdSexo                 AS idSexo,
        e.EMIdParentesco           AS idParentesco,
        DATEDIFF(MONTH, e.EMFechaIngresoEmpresa, GETDATE()) AS mesesAntiguedad
    FROM ff_Empleado e
        INNER JOIN ff_Empresa emp ON emp.EMidEmpresa = e.EMIdEmpresa
        INNER JOIN ff_Vigencia vig
            ON vig.VIIdVigencia = @IdVigencia
           AND vig.VIIdConfiguracion = emp.EMIdConfiguracion
           AND vig.VIIdEstatus = 1
        LEFT  JOIN ff_Perfil  per ON per.PEIdPerfil  = e.EMIdPerfil
    WHERE e.EMIdParentesco = 1  -- titular
      AND e.EMIdEstatus = 1
      AND emp.EMIdEstatus = 1
      AND emp.EMidCorporativo = @IdCorporativo
      -- No tiene solicitud activa en la vigencia
      AND NOT EXISTS (
          SELECT 1
            FROM ff_Solicitud s
           WHERE s.SOIdEmpleado = e.Id
             AND s.SOIdVigencia = @IdVigencia
             AND s.SOIdEstatus IN (1, 10)
             AND s.SOEstatusSolicitud IN (1, 3) -- 1=Autorizada / 3=Por Autorizar (ff_Estatus). FIX 21-jul: antes usaba SOIdEstatus, que se queda en 1 al rechazar y ocultaba de la busqueda a titulares con solicitud Rechazada.
      )
      AND (@hayEmpresas    = 0 OR e.EMIdEmpresa    IN (SELECT Id FROM @tEmpresas))
      AND (@hayPerfiles    = 0 OR e.EMIdPerfil     IN (SELECT Id FROM @tPerfiles))
      AND (@hayOficinas    = 0 OR e.EMOficina      IN (SELECT Id FROM @tOficinas))
      AND (@hayAreas       = 0 OR e.EMArea         IN (SELECT Id FROM @tAreas))
      AND (@haySexos       = 0 OR e.EMIdSexo       IN (SELECT Id FROM @tSexos))
      AND (@hayParentescos = 0 OR e.EMIdParentesco IN (SELECT Id FROM @tParentescos))
      AND (@hayNumEmp      = 0 OR e.EMNumeroEmpleado IN (SELECT NumeroEmpleado FROM @tNumEmp))
      AND (@SalarioMin         IS NULL OR e.EMSalarioBase         >= @SalarioMin)
      AND (@SalarioMax         IS NULL OR e.EMSalarioBase         <= @SalarioMax)
      AND (@FechaIngresoIni    IS NULL OR e.EMFechaIngresoEmpresa >= @FechaIngresoIni)
      AND (@FechaIngresoFin    IS NULL OR e.EMFechaIngresoEmpresa <= @FechaIngresoFin)
      AND (@FechaAntiguedadIni IS NULL OR e.EMFechaAntiguedadGmm  >= @FechaAntiguedadIni)
      AND (@FechaAntiguedadFin IS NULL OR e.EMFechaAntiguedadGmm  <= @FechaAntiguedadFin)
      AND (@FechaNacimientoIni IS NULL OR e.EMFechaNacimiento     >= @FechaNacimientoIni)
      AND (@FechaNacimientoFin IS NULL OR e.EMFechaNacimiento     <= @FechaNacimientoFin)
      -- Anexo: nombre / apellidos / edad
      AND (@Nombre          IS NULL OR LEN(LTRIM(RTRIM(@Nombre))) = 0
            OR e.EMNombre1 LIKE '%' + LTRIM(RTRIM(@Nombre)) + '%'
            OR e.EMNombre2 LIKE '%' + LTRIM(RTRIM(@Nombre)) + '%')
      AND (@ApellidoPaterno IS NULL OR LEN(LTRIM(RTRIM(@ApellidoPaterno))) = 0
            OR e.EMApellidoPaterno LIKE '%' + LTRIM(RTRIM(@ApellidoPaterno)) + '%')
      AND (@ApellidoMaterno IS NULL OR LEN(LTRIM(RTRIM(@ApellidoMaterno))) = 0
            OR e.EMApellidoMaterno LIKE '%' + LTRIM(RTRIM(@ApellidoMaterno)) + '%')
      AND (@EdadMin IS NULL OR e.EMEdad >= @EdadMin)
      AND (@EdadMax IS NULL OR e.EMEdad <= @EdadMax)
      -- Plan: el empleado tiene una opcion del perfil que pertenezca a uno de los planes elegidos
      AND (@hayPlanes      = 0 OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POidPlan IN (SELECT Id FROM @tPlanes)))
      -- Cobertura: en BeFlex la "cobertura" se materializa como ff_PlanOpcion
      AND (@hayCoberturas  = 0 OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND pp.PPidPlanOpcion IN (SELECT Id FROM @tCoberturas)))
      -- Suma asegurada: rango contra POValorSumaAsegurada de las opciones del perfil
      AND (@SumaAseguradaMin IS NULL OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POValorSumaAsegurada >= @SumaAseguradaMin))
      AND (@SumaAseguradaMax IS NULL OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POValorSumaAsegurada <= @SumaAseguradaMax))
      -- Fecha de vigencia: usar columnas reales VIVigenciaIni/VIVigenciaFin
      AND (@FechaVigenciaIni IS NULL OR EXISTS (
            SELECT 1 FROM ff_Vigencia v WHERE v.VIidVigencia = @IdVigencia AND v.VIVigenciaIni >= @FechaVigenciaIni))
      AND (@FechaVigenciaFin IS NULL OR EXISTS (
            SELECT 1 FROM ff_Vigencia v WHERE v.VIidVigencia = @IdVigencia AND v.VIVigenciaFin <= @FechaVigenciaFin))
    ORDER BY e.EMIdEmpresa, e.EMApellidoPaterno, e.EMApellidoMaterno, e.EMNombre1;
END
GO

GO

/* ==========================================================================
   05. Reporte historico de defaulteo
   ========================================================================== */
/* Reporte sin la tabla permanente compartida PruebaTemp del procedimiento legado. */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ReporteDefaulteo_Consultar
    @IdEmpresa  INT,
    @FechaInicio DATE,
    @FechaFin    DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF @IdEmpresa <= 0
        THROW 50010, 'La empresa es obligatoria.', 1;
    IF @FechaInicio IS NULL OR @FechaFin IS NULL OR @FechaFin < @FechaInicio
        THROW 50011, 'El rango de fechas no es valido.', 1;

    ;WITH SeleccionesIndividuales AS
    (
        SELECT
            POS.POidEmpresa AS idEmpresa,
            POS.PONumeroEmpleado AS numeroEmpleado,
            POS.POTarifaNeta AS costo,
            POS.POUsuarioAdd AS idUsuario,
            CONVERT(DATE, SO.SOFechaAprovacion) AS fechaDefaulteo
        FROM dbo.ff_PlanOpcionSeleccion POS
        INNER JOIN dbo.ff_Solicitud SO
            ON SO.SOIdSolicitud = POS.POIdSolicitud
        WHERE POS.POIdEmpresa = @IdEmpresa
          AND POS.PODefaulteo = 1
          AND POS.POIdEstatus = 1
          AND SO.SOEstatusSolicitud = 1
          AND POS.POIdParentesco IS NOT NULL
          AND SO.SOFechaAprovacion >= @FechaInicio
          AND SO.SOFechaAprovacion < DATEADD(DAY, 1, @FechaFin)
    ),
    SeleccionesGrupo AS
    (
        SELECT DISTINCT
            POS.POidEmpresa AS idEmpresa,
            POS.PONumeroEmpleado AS numeroEmpleado,
            POS.POTarifaNeta AS costo,
            POS.POUsuarioAdd AS idUsuario,
            CONVERT(DATE, SO.SOFechaAprovacion) AS fechaDefaulteo,
            POS.POIdPlanOpcion,
            POS.POIdGrupoParentesco
        FROM dbo.ff_PlanOpcionSeleccion POS
        INNER JOIN dbo.ff_Solicitud SO
            ON SO.SOIdSolicitud = POS.POIdSolicitud
        WHERE POS.POIdEmpresa = @IdEmpresa
          AND POS.PODefaulteo = 1
          AND POS.POIdEstatus = 1
          AND SO.SOEstatusSolicitud = 1
          AND POS.POIdGrupoParentesco IS NOT NULL
          AND SO.SOFechaAprovacion >= @FechaInicio
          AND SO.SOFechaAprovacion < DATEADD(DAY, 1, @FechaFin)
    ),
    Selecciones AS
    (
        SELECT idEmpresa, numeroEmpleado, costo, idUsuario, fechaDefaulteo
        FROM SeleccionesIndividuales
        UNION ALL
        SELECT idEmpresa, numeroEmpleado, costo, idUsuario, fechaDefaulteo
        FROM SeleccionesGrupo
    )
    SELECT
        S.idEmpresa,
        S.numeroEmpleado,
        LTRIM(RTRIM(
            ISNULL(E.EMApellidoPaterno, '') + ' '
          + ISNULL(E.EMApellidoMaterno, '') + ' '
          + ISNULL(E.EMNombre1, '') + ' '
          + ISNULL(E.EMNombre2, ''))) AS nombreEmpleado,
        CONVERT(DECIMAL(18, 2), SUM(ISNULL(S.costo, 0))) AS costoAnual,
        S.idUsuario,
        S.fechaDefaulteo
    FROM Selecciones S
    INNER JOIN dbo.ff_Empleado E
      ON E.EMIdEmpresa = S.idEmpresa
     AND E.EMNumeroEmpleado = S.numeroEmpleado
     AND E.EMIdParentesco = 1
    GROUP BY
        S.idEmpresa, S.numeroEmpleado, S.idUsuario, S.fechaDefaulteo,
        E.EMApellidoPaterno, E.EMApellidoMaterno, E.EMNombre1, E.EMNombre2
    ORDER BY S.numeroEmpleado, S.fechaDefaulteo;
END;
GO

GO

/* ==========================================================================
   06. Procedimiento multivigencia definitivo
   ========================================================================== */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [dbo].[bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado]
(
    @IdsEmpresas varchar(max),
    @IdAdministrador int,
    @idAtributo1 varchar(100),
    @idAtributo2 varchar(100),
    @idTipoOperador1 varchar(100),
    @idTipoOperador2 varchar(100),
    @parametroBusqueda1 varchar(max),
    @parametroBusqueda2 varchar(max),
    @BusquedaAvanzada int = 1,
    @idTipoOperadorAvanzado varchar(100),
    @idPerfiles varchar(max),
    @Vigencia int
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE
        @sql_str nvarchar(max) = N'',
        @sql_empresas nvarchar(max) = N'',
        @sql_where1 nvarchar(max) = N'',
        @sql_where2 nvarchar(max) = N'';

    SET @sql_str = N'SELECT DISTINCT
        EMPL.Id,
        CAST(0 AS bit) AS seleccion,
        EMPL.EMIdEmpresa,
        EMPL.EMNumeroEmpleado AS numEmpleado,
        P.EMNombre AS nombreEmpresa,
        PERF.PEDescripcion AS perfil,
        PERF.PEIdPerfil AS idPerfil,
        EMPL.EMApellidoPaterno AS ApellidoPaterno,
        EMPL.EMApellidoMaterno AS ApellidoMaterno,
        EMPL.EMNombre1 AS Nombre1,
        EMPL.EMNombre2 AS Nombre2,
        EMPL.EMFechaNacimiento AS fechaNacimiento,
        EMPL.EMEdad AS edad,
        PAR.PADescripcion AS parentesco,
        EMPL.EMIdEmpresa AS idEmpresa,
        CASE WHEN ULT.SONumeroSolicitud IS NULL THEN ''''
             ELSE CONCAT(ULT.SONumeroSolicitud, ''-'', ULT.SOAnexoSolicitud)
        END AS NumeroSolicitud
    FROM dbo.ff_Empleado EMPL WITH (NOLOCK)
    OUTER APPLY
    (
        SELECT TOP (1)
            SULT.SONumeroSolicitud,
            SULT.SOAnexoSolicitud
        FROM dbo.ff_Solicitud SULT WITH (NOLOCK)
        WHERE SULT.SOIdEmpleado = EMPL.Id
          AND SULT.SOIdVigencia = ' + CONVERT(varchar(20), @Vigencia) + N'
        ORDER BY SULT.SOFechaAdd DESC, SULT.SOIdSolicitud DESC
    ) ULT
    INNER JOIN dbo.ff_Perfil PERF
        ON PERF.PEIdPerfil = EMPL.EMIdPerfil
       AND PERF.PEIdPerfil IN (' + @idPerfiles + N')
    INNER JOIN dbo.ff_Parentesco PAR
        ON PAR.PAIdParentesco = EMPL.EMIdParentesco
    INNER JOIN dbo.ff_Empresa P
        ON P.EMIdEmpresa = EMPL.EMIdEmpresa
    WHERE ';

    SET @sql_empresas = N' (EMPL.EMIdEmpresa IN (' + @IdsEmpresas + N')
        AND EMPL.EMNumeroEmpleado NOT LIKE ''PR%''
        AND EMPL.EMIdEstatus = 1
        AND EMPL.EMIdTitular = 1 ';

    IF LTRIM(RTRIM(ISNULL(@parametroBusqueda1, ''))) = ''
    BEGIN
        SET @sql_where1 = @sql_empresas + N')';
    END
    ELSE
    BEGIN
        SET @sql_where1 = @sql_empresas + N' AND EMPL.' + @idAtributo1 +
            CASE @idTipoOperador1
                WHEN 'igual'      THEN N' = ''' + @parametroBusqueda1 + N''''
                WHEN 'contiene'   THEN N' LIKE ''%' + @parametroBusqueda1 + N'%'''
                WHEN 'noigual'    THEN N' <> ''' + UPPER(@parametroBusqueda1) + N''''
                WHEN 'iniciapor'  THEN N' LIKE ''' + @parametroBusqueda1 + N'%'''
                WHEN 'terminapor' THEN N' LIKE ''%' + @parametroBusqueda1 + N''''
                WHEN 'nocontiene' THEN N' NOT LIKE ''%' + @parametroBusqueda1 + N'%'''
                ELSE N' LIKE ''%' + @parametroBusqueda1 + N'%'''
            END + N')';

        IF @BusquedaAvanzada = 1
        BEGIN
            SET @sql_where2 = N' ' + @idTipoOperadorAvanzado + @sql_empresas
                + N' AND EMPL.' + @idAtributo2 +
                CASE @idTipoOperador2
                    WHEN 'igual'      THEN N' = ''' + @parametroBusqueda2 + N''''
                    WHEN 'contiene'   THEN N' LIKE ''%' + @parametroBusqueda2 + N'%'''
                    WHEN 'noigual'    THEN N' <> ''' + @parametroBusqueda2 + N''''
                    WHEN 'iniciapor'  THEN N' LIKE ''' + @parametroBusqueda2 + N'%'''
                    WHEN 'terminapor' THEN N' LIKE ''%' + @parametroBusqueda2 + N''''
                    WHEN 'nocontiene' THEN N' NOT LIKE ''%' + @parametroBusqueda2 + N'%'''
                    ELSE N' LIKE ''%' + @parametroBusqueda2 + N'%'''
                END + N')';
        END;
    END;

    SET @sql_str = @sql_str + @sql_where1 + @sql_where2;
    EXEC sys.sp_executesql @sql_str;
END;
GO

GO

/* ==========================================================================
   07. Parametrizacion de Carga Masiva B2/B3
   ========================================================================== */
/*
  CORRECCION QA - PARAMETRIZACION DE CARGA MASIVA B2/B3

  Instala exclusivamente los cuatro objetos que el diagnostico reporto como
  faltantes. Es idempotente: puede ejecutarse varias veces.

  No modifica objetos ni datos de Defaulteo.
  No requiere insertar una configuracion inicial por empresa: si no existe una
  fila, el flujo devuelve Pantalla=B3 y Automatico=B2 como valores por defecto.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.bf_ConfiguracionFlujoCargaMasiva', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_ConfiguracionFlujoCargaMasiva
    (
        CFIdEmpresa          INT      NOT NULL,
        CFFlujoPantalla      CHAR(2)  NOT NULL,
        CFFlujoAutomatico    CHAR(2)  NOT NULL,
        CFIdEstatus          INT      NOT NULL
            CONSTRAINT DF_bf_CargaFlujo_Estatus DEFAULT (1),
        CFUsuarioAdd         INT      NOT NULL,
        CFFechaAdd           DATETIME NOT NULL
            CONSTRAINT DF_bf_CargaFlujo_FechaAdd DEFAULT (GETDATE()),
        CFUsuarioUMod        INT      NULL,
        CFFechaUMod          DATETIME NULL,

        CONSTRAINT PK_bf_ConfiguracionFlujoCargaMasiva
            PRIMARY KEY (CFIdEmpresa),
        CONSTRAINT CK_bf_CargaFlujo_Pantalla
            CHECK (CFFlujoPantalla IN ('B2', 'B3')),
        CONSTRAINT CK_bf_CargaFlujo_Automatico
            CHECK (CFFlujoAutomatico IN ('B2', 'B3')),
        CONSTRAINT CK_bf_CargaFlujo_Estatus
            CHECK (CFIdEstatus IN (1, 2))
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Obtener
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        @IdEmpresa AS idEmpresa,
        COALESCE(c.CFFlujoPantalla, 'B3') AS flujoPantalla,
        COALESCE(c.CFFlujoAutomatico, 'B2') AS flujoAutomatico,
        CONVERT(BIT, CASE WHEN c.CFIdEmpresa IS NULL THEN 0 ELSE 1 END) AS configurado,
        c.CFUsuarioAdd AS usuarioAdd,
        c.CFFechaAdd AS fechaAdd,
        c.CFUsuarioUMod AS usuarioUMod,
        c.CFFechaUMod AS fechaUmod
    FROM (SELECT 1 AS n) x
    LEFT JOIN dbo.bf_ConfiguracionFlujoCargaMasiva c
        ON c.CFIdEmpresa = @IdEmpresa
       AND c.CFIdEstatus = 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Guardar
    @IdEmpresa       INT,
    @FlujoPantalla   CHAR(2),
    @FlujoAutomatico CHAR(2),
    @IdUsuario       INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @FlujoPantalla = UPPER(LTRIM(RTRIM(@FlujoPantalla)));
    SET @FlujoAutomatico = UPPER(LTRIM(RTRIM(@FlujoAutomatico)));

    IF @IdEmpresa <= 0
       OR NOT EXISTS
          (SELECT 1
           FROM dbo.ff_Empresa
           WHERE EMIdEmpresa = @IdEmpresa
             AND EMIdEstatus = 1)
        THROW 50001, 'La empresa indicada no existe o esta inactiva.', 1;

    IF @IdUsuario <= 0
        THROW 50002, 'El usuario es obligatorio.', 1;

    IF @FlujoPantalla NOT IN ('B2', 'B3')
       OR @FlujoAutomatico NOT IN ('B2', 'B3')
        THROW 50003, 'Los flujos permitidos son B2 y B3.', 1;

    BEGIN TRANSACTION;

    UPDATE dbo.bf_ConfiguracionFlujoCargaMasiva WITH (UPDLOCK, SERIALIZABLE)
       SET CFFlujoPantalla = @FlujoPantalla,
           CFFlujoAutomatico = @FlujoAutomatico,
           CFIdEstatus = 1,
           CFUsuarioUMod = @IdUsuario,
           CFFechaUMod = GETDATE()
     WHERE CFIdEmpresa = @IdEmpresa;

    IF @@ROWCOUNT = 0
    BEGIN
        INSERT dbo.bf_ConfiguracionFlujoCargaMasiva
            (CFIdEmpresa, CFFlujoPantalla, CFFlujoAutomatico, CFIdEstatus,
             CFUsuarioAdd, CFFechaAdd)
        VALUES
            (@IdEmpresa, @FlujoPantalla, @FlujoAutomatico, 1,
             @IdUsuario, GETDATE());
    END;

    COMMIT TRANSACTION;

    EXEC dbo.bf_CargaMasivaFlujo_Obtener @IdEmpresa = @IdEmpresa;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Resolver
    @IdEmpresa INT,
    @Canal     VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    SET @Canal = UPPER(LTRIM(RTRIM(@Canal)));

    IF @Canal NOT IN ('PANTALLA', 'AUTOMATICO')
        THROW 50004, 'El canal debe ser PANTALLA o AUTOMATICO.', 1;

    SELECT
        @IdEmpresa AS idEmpresa,
        @Canal AS canal,
        CASE
            WHEN c.CFIdEmpresa IS NULL AND @Canal = 'AUTOMATICO' THEN 'B2'
            WHEN c.CFIdEmpresa IS NULL THEN 'B3'
            WHEN @Canal = 'PANTALLA' THEN c.CFFlujoPantalla
            ELSE c.CFFlujoAutomatico
        END AS flujo,
        CONVERT(BIT, CASE WHEN c.CFIdEmpresa IS NULL THEN 0 ELSE 1 END) AS configurado
    FROM (SELECT 1 AS n) x
    LEFT JOIN dbo.bf_ConfiguracionFlujoCargaMasiva c
        ON c.CFIdEmpresa = @IdEmpresa
       AND c.CFIdEstatus = 1;
END;
GO

SELECT
    DB_NAME() AS BaseDatos,
    x.Objeto,
    CASE WHEN OBJECT_ID(x.Objeto, x.Tipo) IS NULL THEN 'FALTA' ELSE 'OK' END AS Resultado
FROM (VALUES
    (N'dbo.bf_ConfiguracionFlujoCargaMasiva', N'U'),
    (N'dbo.bf_CargaMasivaFlujo_Obtener', N'P'),
    (N'dbo.bf_CargaMasivaFlujo_Guardar', N'P'),
    (N'dbo.bf_CargaMasivaFlujo_Resolver', N'P')
) x(Objeto, Tipo)
ORDER BY x.Objeto;
GO

GO
RAISERROR(N'[CARGA/DEFAULTEO] Instalacion consolidada finalizada.',10,1) WITH NOWAIT;
GO
SET NOEXEC OFF;
GO
