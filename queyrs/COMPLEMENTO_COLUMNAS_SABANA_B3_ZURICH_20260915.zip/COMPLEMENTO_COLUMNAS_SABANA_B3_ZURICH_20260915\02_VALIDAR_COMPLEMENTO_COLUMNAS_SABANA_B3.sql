USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*
    VALIDACION DE SOLO LECTURA

    Ejecutar despues de 01_APLICAR_COMPLEMENTO_COLUMNAS_SABANA_B3.sql
    en la misma base configurada en APIREPORTS.
*/

DECLARE @Resultado TABLE
(
    Orden   int            NOT NULL,
    Seccion varchar(40)    NOT NULL,
    Estado  varchar(10)    NOT NULL,
    Clave   nvarchar(100)  NOT NULL,
    Valor   nvarchar(max)  NULL,
    Detalle nvarchar(max)  NULL
);

INSERT @Resultado
VALUES
(100,'01_CONTEXTO','INFO','Servidor',CONVERT(nvarchar(128),SERVERPROPERTY('ServerName')),
 N'Debe ser el servidor usado por APIREPORTS.'),
(101,'01_CONTEXTO','INFO','BaseDatos',DB_NAME(),
 N'Debe ser la base usada por APIREPORTS.'),
(102,'01_CONTEXTO','INFO','Empresa',N'2185 - Zurich',NULL);

DECLARE @DefGMM  nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaGMM_BF3')),
        @DefVida nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaVIDA_BF3')),
        @DefOPC  nvarchar(max)=OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_SabanaOPC_BF3'));

DECLARE @GMM nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
            ISNULL(@DefGMM,N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N''),N'[',N'')),
        @Vida nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
            ISNULL(@DefVida,N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N''),N'[',N'')),
        @OPC nvarchar(max)=UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
            ISNULL(@DefOPC,N''),N' ',N''),CHAR(9),N''),CHAR(10),N''),CHAR(13),N''),N'[',N''));

SET @GMM=REPLACE(@GMM,N']',N'');
SET @Vida=REPLACE(@Vida,N']',N'');
SET @OPC=REPLACE(@OPC,N']',N'');

INSERT @Resultado
SELECT 200,'02_OBJETOS',
       CASE WHEN @DefGMM IS NOT NULL THEN 'OK' ELSE 'ALERTA' END,
       'ff_SabanaGMM_BF3',
       CASE WHEN @DefGMM IS NOT NULL THEN N'EXISTE' ELSE N'NO EXISTE' END,
       N'Procedimiento fuente del bloque GMM.';

INSERT @Resultado
SELECT 201,'02_OBJETOS',
       CASE WHEN @DefVida IS NOT NULL THEN 'OK' ELSE 'ALERTA' END,
       'ff_SabanaVIDA_BF3',
       CASE WHEN @DefVida IS NOT NULL THEN N'EXISTE' ELSE N'NO EXISTE' END,
       N'Procedimiento fuente del bloque Vida.';

INSERT @Resultado
SELECT 202,'02_OBJETOS',
       CASE WHEN @DefOPC IS NOT NULL THEN 'OK' ELSE 'ALERTA' END,
       'ff_SabanaOPC_BF3',
       CASE WHEN @DefOPC IS NOT NULL THEN N'EXISTE' ELSE N'NO EXISTE' END,
       N'Procedimiento fuente de las hojas opcionales.';

DECLARE @GMMParentesco bit=CASE
    WHEN @GMM LIKE N'%EM.EMIDPARENTESCOASEMIDPARENTESCO1%' THEN 1 ELSE 0 END;

INSERT @Resultado
VALUES
(300,'03_GMM',CASE WHEN @GMMParentesco=1 THEN 'OK' ELSE 'ALERTA' END,
 'EMIdParentesco1',CONVERT(nvarchar(1),@GMMParentesco),
 N'Debe ser 1. Al regenerar, cada hoja GMM debe terminar con esta columna (33 columnas).');

DECLARE @InicioConfig int=CHARINDEX(N'INTO#CONFIGURACION',@Vida),
        @FinConfig int;
SET @FinConfig=CASE WHEN @InicioConfig>0
    THEN CHARINDEX(N'SET@REGISTROS',@Vida,@InicioConfig) ELSE 0 END;

DECLARE @BloqueConfigVida nvarchar(max)=CASE
    WHEN @InicioConfig>0 AND @FinConfig>@InicioConfig
    THEN SUBSTRING(@Vida,@InicioConfig,@FinConfig-@InicioConfig)
    ELSE N'' END;

DECLARE @VidaIdemp bit=CASE WHEN @Vida LIKE N'%RFC,IDASIDEMP,INFO%' THEN 1 ELSE 0 END,
        @VidaConsolidada bit=CASE
            WHEN @Vida LIKE N'%AND1=0%FLUJOREDUNDANTE%' THEN 1 ELSE 0 END,
        @VidaAliasDinamico bit=CASE
            WHEN @Vida LIKE N'%ALIASCONSECUTIVO%' AND @Vida LIKE N'%COSTO_%'
            THEN 1 ELSE 0 END,
        @VidaConfigSinVigencia bit=CASE
            WHEN @BloqueConfigVida<>N''
             AND CHARINDEX(N'CSIDVIGENCIA',@BloqueConfigVida)=0
            THEN 1 ELSE 0 END,
        @VidaSinCostoBase bit=CASE
            WHEN CHARINDEX(N'P.NOMBRES,P.PRIMANETA,P.COSTOASCOSTO',@Vida)=0
            THEN 1 ELSE 0 END;

INSERT @Resultado
VALUES
(400,'04_VIDA',CASE WHEN @VidaIdemp=1 THEN 'OK' ELSE 'ALERTA' END,
 'AliasIdemp',CONVERT(nvarchar(1),@VidaIdemp),
 N'Debe ser 1; B2 muestra Idemp, no Id.'),
(401,'04_VIDA',CASE WHEN @VidaConsolidada=1 THEN 'OK' ELSE 'ALERTA' END,
 'UnaFilaPorBeneficiario',CONVERT(nvarchar(1),@VidaConsolidada),
 N'Debe ser 1; evita una fila separada por cada cobertura.'),
(402,'04_VIDA',CASE WHEN @VidaAliasDinamico=1 THEN 'OK' ELSE 'ALERTA' END,
 'CoberturasYCostosDinamicos',CONVERT(nvarchar(1),@VidaAliasDinamico),
 N'Debe ser 1; recupera las coberturas y sus columnas Costo_n.'),
(403,'04_VIDA',CASE WHEN @VidaConfigSinVigencia=1 THEN 'OK' ELSE 'ALERTA' END,
 'ConfiguracionHistoricaDisponible',CONVERT(nvarchar(1),@VidaConfigSinVigencia),
 N'Debe ser 1; Zurich conserva la configuracion de coberturas en una vigencia anterior.'),
(404,'04_VIDA',CASE WHEN @VidaSinCostoBase=1 THEN 'OK' ELSE 'ALERTA' END,
 'SinCostoBaseEnResultset',CONVERT(nvarchar(1),@VidaSinCostoBase),
 N'Debe ser 1; Costo y PrimaNeta base no forman parte del layout B2 de Vida.');

DECLARE @OPCCampos bit=CASE
    WHEN @OPC LIKE N'%P.LOCAL_NUMBER,P.EMAREA,P.EMIDCENTROCOSTOS%'
    THEN 1 ELSE 0 END;

INSERT @Resultado
VALUES
(500,'05_OPCIONALES',CASE WHEN @OPCCampos=1 THEN 'OK' ELSE 'ALERTA' END,
 'CamposFaltantes',CONVERT(nvarchar(1),@OPCCampos),
 N'Debe ser 1. Al regenerar, cada hoja opcional debe incluir EMArea, EMIdCentroCostos y local_number (24 columnas).');

DECLARE @CamposConfigOPC int=
(
    SELECT COUNT(DISTINCT UPPER(LTRIM(RTRIM(campoOrigen))))
    FROM dbo.bf_RepConf_Columna
    WHERE catReportesId=3
      AND idEmpresa IN(0,2185)
      AND UPPER(LTRIM(RTRIM(grupo))) IN(N'OPC',N'OPCIONALES')
      AND visible=1
      AND UPPER(LTRIM(RTRIM(campoOrigen))) IN(N'EMAREA',N'EMIDCENTROCOSTOS',N'LOCAL_NUMBER')
);

INSERT @Resultado
VALUES
(510,'05_OPCIONALES',CASE WHEN @CamposConfigOPC=3 THEN 'OK' ELSE 'ALERTA' END,
 'ConfiguracionCampos',CONVERT(nvarchar(10),@CamposConfigOPC),
 N'Debe ser 3. El complemento no agrega configuracion porque los tres campos ya deben estar registrados.');

DECLARE @RutaActiva int=
(
    SELECT COUNT(*)
    FROM dbo.bf_CatReportesSP
    WHERE catReportesId=3
      AND ISNULL(ESid,1)=1
      AND UPPER(LTRIM(RTRIM(catReportesSPNombre)))=N'FF_SABANA_BF3'
);

INSERT @Resultado
VALUES
(600,'06_RUTA',CASE WHEN @RutaActiva=1 THEN 'OK' ELSE 'ALERTA' END,
 'RutaSabanaBF3',CONVERT(nvarchar(10),@RutaActiva),
 N'Debe ser 1; confirma que el reporte 3 usa el wrapper BF3.');

DECLARE @Alertas int=(SELECT COUNT(*) FROM @Resultado WHERE Estado='ALERTA');

INSERT @Resultado
VALUES
(900,'07_RESUMEN',CASE WHEN @Alertas=0 THEN 'OK' ELSE 'ALERTA' END,
 'Resultado',
 CASE WHEN @Alertas=0 THEN N'COMPLEMENTO INSTALADO'
      ELSE CONCAT(N'ALERTAS=',@Alertas) END,
 CASE WHEN @Alertas=0
      THEN N'Generar una sabana B3 nueva de Zurich y comparar columnas contra B2.'
      ELSE N'No generar evidencia final hasta corregir las alertas.' END);

SELECT Seccion,Estado,Clave,Valor,Detalle
FROM @Resultado
ORDER BY Orden,Clave;
GO

