
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.bf_ConfiguracionDefaulteo', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_ConfiguracionDefaulteo
    (
        CDId             INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_bf_ConfiguracionDefaulteo PRIMARY KEY,
        CDNombre         VARCHAR(150) NOT NULL,
        CDDescripcion    VARCHAR(500) NULL,
        CDIdCorporativo  INT NULL,
        CDIdEmpresa      INT NULL,
        CDIdAdmin        INT NOT NULL,
        CDFiltrosJson    NVARCHAR(MAX) NOT NULL,
        CDAccionesJson   NVARCHAR(MAX) NULL,
        CDIdEstatus      INT NOT NULL
            CONSTRAINT DF_bf_ConfiguracionDefaulteo_Estatus DEFAULT (1),
        CDFechaAdd       DATETIME NOT NULL
            CONSTRAINT DF_bf_ConfiguracionDefaulteo_FechaAdd DEFAULT (GETDATE()),
        CDFechaUmod      DATETIME NULL,
        CDUsuarioUmod    INT NULL
    );

    CREATE INDEX IX_bf_ConfiguracionDefaulteo_Admin
        ON dbo.bf_ConfiguracionDefaulteo (CDIdAdmin, CDIdEstatus)
        INCLUDE (CDIdEmpresa, CDIdCorporativo, CDNombre);
END;
GO

IF OBJECT_ID(N'dbo.bf_LogDefaulteo', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_LogDefaulteo
    (
        LDId               INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_bf_LogDefaulteo PRIMARY KEY,
        LDIdConfiguracion  INT NULL,
        LDIdCorporativo    INT NULL,
        LDIdEmpresa        INT NULL,
        LDIdVigencia       INT NULL,
        LDIdAdmin          INT NOT NULL,
        LDFiltrosJson      NVARCHAR(MAX) NULL,
        LDAccionesJson     NVARCHAR(MAX) NULL,
        LDTotalEmpleados   INT NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Total DEFAULT (0),
        LDTotalExitosos    INT NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Exitosos DEFAULT (0),
        LDTotalErrores     INT NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Errores DEFAULT (0),
        LDFechaInicio      DATETIME NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Inicio DEFAULT (GETDATE()),
        LDFechaFin         DATETIME NULL,
        LDDuracionMs       BIGINT NULL,
        LDIpOrigen         VARCHAR(64) NULL,
        LDOrigen           VARCHAR(30) NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Origen DEFAULT ('AVANZADO'),
        LDEstado           VARCHAR(30) NOT NULL
            CONSTRAINT DF_bf_LogDefaulteo_Estado DEFAULT ('EN_PROCESO')
    );

    CREATE INDEX IX_bf_LogDefaulteo_AdminFecha
        ON dbo.bf_LogDefaulteo (LDIdAdmin, LDFechaInicio DESC)
        INCLUDE (LDEstado, LDTotalEmpleados, LDTotalExitosos, LDTotalErrores);
END;
GO

IF OBJECT_ID(N'dbo.bf_LogErroresDefaulteo', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_LogErroresDefaulteo
    (
        LEDId               INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_bf_LogErroresDefaulteo PRIMARY KEY,
        LEDIdLog            INT NOT NULL,
        LEDIdEmpleado       INT NULL,
        LEDNumeroEmpleado   VARCHAR(100) NULL,
        LEDIdEmpresa        INT NULL,
        LEDIdPerfil         INT NULL,
        LEDTipoEvento       VARCHAR(30) NOT NULL,
        LEDMensaje          NVARCHAR(2000) NULL,
        LEDStackTrace       NVARCHAR(MAX) NULL,
        LEDContextoJson     NVARCHAR(MAX) NULL,
        LEDFechaAdd         DATETIME NOT NULL
            CONSTRAINT DF_bf_LogErroresDefaulteo_FechaAdd DEFAULT (GETDATE())
    );

    CREATE INDEX IX_bf_LogErroresDefaulteo_Log
        ON dbo.bf_LogErroresDefaulteo (LEDIdLog, LEDId)
        INCLUDE (LEDIdEmpleado, LEDNumeroEmpleado, LEDTipoEvento, LEDFechaAdd);
END;
GO

/* Si las tablas ya existian, se detiene ante un contrato incompatible. */
DECLARE @Faltantes TABLE (Objeto SYSNAME, Columna SYSNAME);

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_ConfiguracionDefaulteo', V.Columna
FROM (VALUES
    (N'CDId'), (N'CDNombre'), (N'CDDescripcion'), (N'CDIdCorporativo'),
    (N'CDIdEmpresa'), (N'CDIdAdmin'), (N'CDFiltrosJson'),
    (N'CDAccionesJson'), (N'CDIdEstatus'), (N'CDFechaAdd'),
    (N'CDFechaUmod'), (N'CDUsuarioUmod')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_ConfiguracionDefaulteo', V.Columna) IS NULL;

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_LogDefaulteo', V.Columna
FROM (VALUES
    (N'LDId'), (N'LDIdConfiguracion'), (N'LDIdCorporativo'),
    (N'LDIdEmpresa'), (N'LDIdVigencia'), (N'LDIdAdmin'),
    (N'LDFiltrosJson'), (N'LDAccionesJson'), (N'LDTotalEmpleados'),
    (N'LDTotalExitosos'), (N'LDTotalErrores'), (N'LDFechaInicio'),
    (N'LDFechaFin'), (N'LDDuracionMs'), (N'LDIpOrigen'),
    (N'LDOrigen'), (N'LDEstado')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_LogDefaulteo', V.Columna) IS NULL;

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_LogErroresDefaulteo', V.Columna
FROM (VALUES
    (N'LEDId'), (N'LEDIdLog'), (N'LEDIdEmpleado'),
    (N'LEDNumeroEmpleado'), (N'LEDIdEmpresa'), (N'LEDIdPerfil'),
    (N'LEDTipoEvento'), (N'LEDMensaje'), (N'LEDStackTrace'),
    (N'LEDContextoJson'), (N'LEDFechaAdd')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_LogErroresDefaulteo', V.Columna) IS NULL;

IF EXISTS (SELECT 1 FROM @Faltantes)
BEGIN
    SELECT 'COLUMNAS_REQUERIDAS_FALTANTES' AS Bloque, Objeto, Columna
    FROM @Faltantes ORDER BY Objeto, Columna;
    THROW 51900, 'Existe una tabla bf_* de Defaulteo con contrato incompatible. No se reemplazo ni altero.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_IniciarLote
    @IdConfiguracion INT = NULL,
    @IdCorporativo   INT = NULL,
    @IdEmpresa       INT = NULL,
    @IdVigencia      INT = NULL,
    @IdAdmin         INT,
    @FiltrosJson     NVARCHAR(MAX) = NULL,
    @AccionesJson    NVARCHAR(MAX) = NULL,
    @TotalEmpleados  INT,
    @IpOrigen        VARCHAR(64) = NULL,
    @Origen          VARCHAR(30) = 'AVANZADO',
    @IdLog           INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @IdAdmin <= 0
        THROW 51901, 'IdAdmin invalido para iniciar el lote.', 1;
    IF ISNULL(@TotalEmpleados, 0) <= 0
        THROW 51902, 'El lote debe contener al menos un empleado.', 1;

    INSERT dbo.bf_LogDefaulteo
    (
        LDIdConfiguracion, LDIdCorporativo, LDIdEmpresa, LDIdVigencia,
        LDIdAdmin, LDFiltrosJson, LDAccionesJson, LDTotalEmpleados,
        LDTotalExitosos, LDTotalErrores, LDFechaInicio, LDIpOrigen,
        LDOrigen, LDEstado
    )
    VALUES
    (
        @IdConfiguracion, @IdCorporativo, @IdEmpresa, @IdVigencia,
        @IdAdmin, @FiltrosJson, @AccionesJson, @TotalEmpleados,
        0, 0, GETDATE(), @IpOrigen, COALESCE(NULLIF(@Origen, ''), 'AVANZADO'),
        'EN_PROCESO'
    );

    SET @IdLog = CONVERT(INT, SCOPE_IDENTITY());
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_RegistrarEvento
    @IdLog          INT,
    @IdEmpleado     INT = NULL,
    @NumeroEmpleado VARCHAR(100) = NULL,
    @IdEmpresa      INT = NULL,
    @IdPerfil       INT = NULL,
    @TipoEvento     VARCHAR(30),
    @Mensaje        NVARCHAR(2000) = NULL,
    @StackTrace     NVARCHAR(MAX) = NULL,
    @ContextoJson   NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM dbo.bf_LogDefaulteo WHERE LDId = @IdLog)
        THROW 51903, 'El lote indicado no existe.', 1;

    INSERT dbo.bf_LogErroresDefaulteo
    (
        LEDIdLog, LEDIdEmpleado, LEDNumeroEmpleado, LEDIdEmpresa,
        LEDIdPerfil, LEDTipoEvento, LEDMensaje, LEDStackTrace,
        LEDContextoJson, LEDFechaAdd
    )
    VALUES
    (
        @IdLog, @IdEmpleado, @NumeroEmpleado, @IdEmpresa,
        @IdPerfil, COALESCE(NULLIF(@TipoEvento, ''), 'EVENTO'), @Mensaje,
        @StackTrace, @ContextoJson, GETDATE()
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_FinalizarLote
    @IdLog          INT,
    @TotalEmpleados INT,
    @TotalExitosos  INT,
    @TotalErrores   INT,
    @Estado         VARCHAR(30)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.bf_LogDefaulteo
       SET LDTotalEmpleados = ISNULL(@TotalEmpleados, LDTotalEmpleados),
           LDTotalExitosos = ISNULL(@TotalExitosos, 0),
           LDTotalErrores = ISNULL(@TotalErrores, 0),
           LDFechaFin = GETDATE(),
           LDDuracionMs = DATEDIFF_BIG(MILLISECOND, LDFechaInicio, GETDATE()),
           LDEstado = COALESCE(NULLIF(@Estado, ''), 'FINALIZADO')
     WHERE LDId = @IdLog;

    IF @@ROWCOUNT = 0
        THROW 51904, 'El lote indicado no existe.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_ConsultarLote
    @IdLog INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        LDId AS idLog,
        LDEstado AS estado,
        LDTotalEmpleados AS totalEmpleados,
        LDTotalExitosos + LDTotalErrores AS procesados,
        LDTotalExitosos AS totalExitosos,
        LDTotalErrores AS totalErrores,
        LDFechaInicio AS fechaInicio,
        LDFechaFin AS fechaFin,
        LDDuracionMs AS duracionMs,
        LDOrigen AS origen
    FROM dbo.bf_LogDefaulteo
    WHERE LDId = @IdLog;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_LogDefaulteo_ObtenerEventos
    @IdLog INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        LEDId, LEDIdLog, LEDIdEmpleado, LEDNumeroEmpleado, LEDIdEmpresa,
        LEDIdPerfil, LEDTipoEvento, LEDMensaje, LEDStackTrace,
        LEDContextoJson, LEDFechaAdd
    FROM dbo.bf_LogErroresDefaulteo
    WHERE LEDIdLog = @IdLog
    ORDER BY LEDId;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Listar
    @IdCorporativo INT = NULL,
    @IdEmpresa     INT = NULL,
    @IdAdmin       INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        CDId AS id,
        CDNombre AS nombre,
        CDDescripcion AS descripcion,
        CDIdCorporativo AS idCorporativo,
        CDIdEmpresa AS idEmpresa,
        CDIdAdmin AS idAdmin,
        CDFiltrosJson AS filtrosJson,
        CDAccionesJson AS accionesJson
    FROM dbo.bf_ConfiguracionDefaulteo
    WHERE CDIdAdmin = @IdAdmin
      AND CDIdEstatus = 1
      AND (@IdCorporativo IS NULL OR CDIdCorporativo IS NULL OR CDIdCorporativo = @IdCorporativo)
      AND (@IdEmpresa IS NULL OR CDIdEmpresa IS NULL OR CDIdEmpresa = @IdEmpresa)
    ORDER BY CDNombre, CDId;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_DefaulteoAvanzado_ListarPerfilesEmpresa
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        P.PEIdPerfil AS idPerfil,
        P.PEDescripcion AS nombrePerfil
    FROM dbo.ff_Perfil P
    WHERE P.PEIdEmpresa = @IdEmpresa
      AND P.PEIdEstatus = 1
    ORDER BY P.PEDescripcion, P.PEIdPerfil;
END;
GO

SELECT
    'INFRAESTRUCTURA_LOTES_DEFAULTEO' AS Bloque,
    O.Tipo,
    O.Nombre,
    CASE
        WHEN O.Tipo = 'TABLA' AND OBJECT_ID(N'dbo.' + O.Nombre, N'U') IS NOT NULL THEN 'OK'
        WHEN O.Tipo = 'SP' AND OBJECT_ID(N'dbo.' + O.Nombre, N'P') IS NOT NULL THEN 'OK'
        ELSE 'FALTA'
    END AS Resultado
FROM (VALUES
    ('TABLA', 'bf_ConfiguracionDefaulteo'),
    ('TABLA', 'bf_LogDefaulteo'),
    ('TABLA', 'bf_LogErroresDefaulteo'),
    ('SP', 'bf_LogDefaulteo_IniciarLote'),
    ('SP', 'bf_LogDefaulteo_RegistrarEvento'),
    ('SP', 'bf_LogDefaulteo_FinalizarLote'),
    ('SP', 'bf_LogDefaulteo_ConsultarLote'),
    ('SP', 'bf_LogDefaulteo_ObtenerEventos'),
    ('SP', 'bf_ConfiguracionDefaulteo_Listar'),
    ('SP', 'bf_DefaulteoAvanzado_ListarPerfilesEmpresa')
) O(Tipo, Nombre)
ORDER BY O.Tipo, O.Nombre;
GO
