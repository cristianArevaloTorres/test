
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [dbo].[bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado]
(
    @IdsEmpresas varchar(max),
    @IdAdministrador int,
    @idAtributo1 varchar(100),
    @idAtributo2 varchar(100),
    @idTipoOperador1 varchar(100),
    @idTipoOperador2 varchar(100),
    @parametroBusqueda1 varchar(max),
    @parametroBusqueda2 varchar(max),
    @BusquedaAvanzada int = 1,
    @idTipoOperadorAvanzado varchar(100),
    @idPerfiles varchar(max),
    @Vigencia int
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE
        @sql_str nvarchar(max) = N'',
        @sql_empresas nvarchar(max) = N'',
        @sql_where1 nvarchar(max) = N'',
        @sql_where2 nvarchar(max) = N'';

    SET @sql_str = N'SELECT DISTINCT
        EMPL.Id,
        CAST(0 AS bit) AS seleccion,
        EMPL.EMIdEmpresa,
        EMPL.EMNumeroEmpleado AS numEmpleado,
        P.EMNombre AS nombreEmpresa,
        PERF.PEDescripcion AS perfil,
        PERF.PEIdPerfil AS idPerfil,
        EMPL.EMApellidoPaterno AS ApellidoPaterno,
        EMPL.EMApellidoMaterno AS ApellidoMaterno,
        EMPL.EMNombre1 AS Nombre1,
        EMPL.EMNombre2 AS Nombre2,
        EMPL.EMFechaNacimiento AS fechaNacimiento,
        EMPL.EMEdad AS edad,
        PAR.PADescripcion AS parentesco,
        EMPL.EMIdEmpresa AS idEmpresa,
        CASE WHEN ULT.SONumeroSolicitud IS NULL THEN ''''
             ELSE CONCAT(ULT.SONumeroSolicitud, ''-'', ULT.SOAnexoSolicitud)
        END AS NumeroSolicitud
    FROM dbo.ff_Empleado EMPL WITH (NOLOCK)
    OUTER APPLY
    (
        SELECT TOP (1)
            SULT.SONumeroSolicitud,
            SULT.SOAnexoSolicitud
        FROM dbo.ff_Solicitud SULT WITH (NOLOCK)
        WHERE SULT.SOIdEmpleado = EMPL.Id
          AND SULT.SOIdVigencia = ' + CONVERT(varchar(20), @Vigencia) + N'
        ORDER BY SULT.SOFechaAdd DESC, SULT.SOIdSolicitud DESC
    ) ULT
    INNER JOIN dbo.ff_Perfil PERF
        ON PERF.PEIdPerfil = EMPL.EMIdPerfil
       AND PERF.PEIdPerfil IN (' + @idPerfiles + N')
    INNER JOIN dbo.ff_Parentesco PAR
        ON PAR.PAIdParentesco = EMPL.EMIdParentesco
    INNER JOIN dbo.ff_Empresa P
        ON P.EMIdEmpresa = EMPL.EMIdEmpresa
    WHERE ';

    SET @sql_empresas = N' (EMPL.EMIdEmpresa IN (' + @IdsEmpresas + N')
        AND EMPL.EMNumeroEmpleado NOT LIKE ''PR%''
        AND EMPL.EMIdEstatus = 1
        AND EMPL.EMIdTitular = 1 ';

    IF LTRIM(RTRIM(ISNULL(@parametroBusqueda1, ''))) = ''
    BEGIN
        SET @sql_where1 = @sql_empresas + N')';
    END
    ELSE
    BEGIN
        SET @sql_where1 = @sql_empresas + N' AND EMPL.' + @idAtributo1 +
            CASE @idTipoOperador1
                WHEN 'igual'      THEN N' = ''' + @parametroBusqueda1 + N''''
                WHEN 'contiene'   THEN N' LIKE ''%' + @parametroBusqueda1 + N'%'''
                WHEN 'noigual'    THEN N' <> ''' + UPPER(@parametroBusqueda1) + N''''
                WHEN 'iniciapor'  THEN N' LIKE ''' + @parametroBusqueda1 + N'%'''
                WHEN 'terminapor' THEN N' LIKE ''%' + @parametroBusqueda1 + N''''
                WHEN 'nocontiene' THEN N' NOT LIKE ''%' + @parametroBusqueda1 + N'%'''
                ELSE N' LIKE ''%' + @parametroBusqueda1 + N'%'''
            END + N')';

        IF @BusquedaAvanzada = 1
        BEGIN
            SET @sql_where2 = N' ' + @idTipoOperadorAvanzado + @sql_empresas
                + N' AND EMPL.' + @idAtributo2 +
                CASE @idTipoOperador2
                    WHEN 'igual'      THEN N' = ''' + @parametroBusqueda2 + N''''
                    WHEN 'contiene'   THEN N' LIKE ''%' + @parametroBusqueda2 + N'%'''
                    WHEN 'noigual'    THEN N' <> ''' + @parametroBusqueda2 + N''''
                    WHEN 'iniciapor'  THEN N' LIKE ''' + @parametroBusqueda2 + N'%'''
                    WHEN 'terminapor' THEN N' LIKE ''%' + @parametroBusqueda2 + N''''
                    WHEN 'nocontiene' THEN N' NOT LIKE ''%' + @parametroBusqueda2 + N'%'''
                    ELSE N' LIKE ''%' + @parametroBusqueda2 + N'%'''
                END + N')';
        END;
    END;

    SET @sql_str = @sql_str + @sql_where1 + @sql_where2;
    EXEC sys.sp_executesql @sql_str;
END;
GO
