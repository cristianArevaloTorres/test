if not exists(select top 1 MEidMenu  from ff_Menu where MENombreMenu= 'Defaulteo tipo 1,2,31')
begin
						insert into ff_Menu 
						values ('Defaulteo tipo 1,2,3',	'/defaulteo',	'Defaulteo tipo 1,2,3',	0	,'centro',	10	,1,	580	,NULL,	3	,1	,NULL,	'2020-12-07 12:08:35.600',	NULL	,'2020-12-07 12:08:35.600'	,NULL	,NULL)


						INSERT INTO FF_MENUROL2 (MRidRol,
						MRidMenu,
						MRidEstatus,	
						MRUsuarioAdd,
						MRFechaAdd,	
						MRUsuarioUMod,
						MRFechaUMod,
						MRUsuarioDel,
						MRFechaDel,
						MRRutaBanner,
						MRImagenMenu)
						SELECT 
							MRidRol,
							(select top 1 MEidMenu  from ff_Menu where MENombreMenu= 'Defaulteo tipo 1,2,3'), 
							MRidEstatus,	
							MRUsuarioAdd,
							MRFechaAdd,	
							MRUsuarioUMod,
							MRFechaUMod,
							MRUsuarioDel,
							MRFechaDel,
							MRRutaBanner,
							MRImagenMenu
							'Boton_CARGA MASIVA DE POBLACIONES.png'
						FROM FF_MENUROL2 
						where MRidMenu in (583) and MRImagenMenu = 'Boton_CARGA MASIVA.png'
end 


