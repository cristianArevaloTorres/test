USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;



IF OBJECT_ID(N'dbo.bf_CatalogoEstatusReporteGen', N'U') IS NULL
    THROW 56100, 'No existe dbo.bf_CatalogoEstatusReporteGen.', 1;

IF COL_LENGTH(N'dbo.bf_CatalogoEstatusReporteGen', N'CatERptId') IS NULL
   OR COL_LENGTH(N'dbo.bf_CatalogoEstatusReporteGen', N'CatERptNombre') IS NULL
   OR COL_LENGTH(N'dbo.bf_CatalogoEstatusReporteGen', N'CatERptUsuarioAdd') IS NULL
   OR COL_LENGTH(N'dbo.bf_CatalogoEstatusReporteGen', N'CatERptFechaAdd') IS NULL
    THROW 56101, 'La estructura de bf_CatalogoEstatusReporteGen no es la esperada.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.bf_CatalogoEstatusReporteGen
    WHERE CatERptId = 7
      AND UPPER(LTRIM(RTRIM(CatERptNombre))) <> N'EN ESPERA'
)
    THROW 56102, 'El identificador de estatus 7 ya esta ocupado por otro valor.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.bf_CatalogoEstatusReporteGen WITH (UPDLOCK, HOLDLOCK)
        WHERE CatERptId = 7
    )
    BEGIN
        IF COLUMNPROPERTY(
                OBJECT_ID(N'dbo.bf_CatalogoEstatusReporteGen'),
                N'CatERptId', 'IsIdentity') = 1
        BEGIN
            SET IDENTITY_INSERT dbo.bf_CatalogoEstatusReporteGen ON;

            INSERT dbo.bf_CatalogoEstatusReporteGen
                (CatERptId, CatERptNombre, CatERptUsuarioAdd, CatERptFechaAdd)
            VALUES
                (7, N'En espera', 0, GETDATE());

            SET IDENTITY_INSERT dbo.bf_CatalogoEstatusReporteGen OFF;
        END
        ELSE
        BEGIN
            INSERT dbo.bf_CatalogoEstatusReporteGen
                (CatERptId, CatERptNombre, CatERptUsuarioAdd, CatERptFechaAdd)
            VALUES
                (7, N'En espera', 0, GETDATE());
        END
    END

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    BEGIN TRY
        SET IDENTITY_INSERT dbo.bf_CatalogoEstatusReporteGen OFF;
    END TRY
    BEGIN CATCH
        -- Puede no estar activo; se conserva el error original.
    END CATCH;
    THROW;
END CATCH;

SELECT CatERptId, CatERptNombre, CatERptFechaAdd
FROM dbo.bf_CatalogoEstatusReporteGen
WHERE CatERptId = 7;
GO
