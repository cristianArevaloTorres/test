/*
   Homologa B3 con B2 y conserva un cache persistente de los dos resultsets base.
   La lectura del cache vuelve a utilizar el generador de resumen de B2, por lo
   que el contrato final permanece en ocho resultsets sin hojas informativas.
*/
USE [FlexiForbesv2];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/*
   Prechequeo unico. Si algo falta, NOEXEC evita que SSMS continue con los
   lotes separados por GO y deja la base sin cambios parciales.
*/
DECLARE @Faltantes table(Requisito nvarchar(500) NOT NULL);

IF OBJECT_ID(N'dbo.ObtenCobranzaConcentrada',N'P') IS NULL
    INSERT @Faltantes VALUES(N'No existe o no es visible dbo.ObtenCobranzaConcentrada (B2).');
IF OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada',N'P') IS NULL
    INSERT @Faltantes VALUES(N'No existe o no es visible dbo.ff_ObtenCobranzaDesg_Adaptada (B2).');
IF OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado',N'P') IS NULL
    INSERT @Faltantes VALUES(N'No existe o no es visible dbo.ff_ObtenDivisionCtos_Adaptado (B2).');
IF OBJECT_ID(N'dbo.bf_CobranzaCache_CapturaBasesV2',N'P') IS NULL
    INSERT @Faltantes VALUES(N'No existe o no es visible la infraestructura bf_CobranzaCache_*V2.');

IF HAS_PERMS_BY_NAME(DB_NAME(),N'DATABASE',N'CREATE PROCEDURE')<>1
    INSERT @Faltantes VALUES(N'Falta CREATE PROCEDURE en FlexiForbesv2.');
IF HAS_PERMS_BY_NAME(N'dbo',N'SCHEMA',N'ALTER')<>1
    INSERT @Faltantes VALUES(N'Falta ALTER sobre el esquema dbo.');
IF HAS_PERMS_BY_NAME(N'dbo.ff_Parametro',N'OBJECT',N'SELECT')<>1
    INSERT @Faltantes VALUES(N'Falta SELECT sobre dbo.ff_Parametro.');
IF HAS_PERMS_BY_NAME(N'dbo.ff_Parametro',N'OBJECT',N'INSERT')<>1
    INSERT @Faltantes VALUES(N'Falta INSERT sobre dbo.ff_Parametro.');
IF HAS_PERMS_BY_NAME(N'dbo.ff_Parametro',N'OBJECT',N'UPDATE')<>1
    INSERT @Faltantes VALUES(N'Falta UPDATE sobre dbo.ff_Parametro.');
IF HAS_PERMS_BY_NAME(N'dbo.ListInt',N'TYPE',N'EXECUTE')<>1
    INSERT @Faltantes VALUES(N'Falta EXECUTE sobre TYPE::dbo.ListInt.');
IF HAS_PERMS_BY_NAME(N'dbo.ListInt',N'TYPE',N'REFERENCES')<>1
    INSERT @Faltantes VALUES(N'Falta REFERENCES sobre TYPE::dbo.ListInt.');

IF EXISTS(SELECT 1 FROM @Faltantes)
BEGIN
    SELECT DB_NAME() AS BaseDatos,
           ORIGINAL_LOGIN() AS LoginInstalacion,
           Requisito
    FROM @Faltantes
    ORDER BY Requisito;

    RAISERROR
    (
        N'INSTALACION CANCELADA: prerrequisitos o permisos incompletos. No se aplicaron cambios.',
        16,1
    );
    SET NOEXEC ON;
END;
GO

BEGIN TRY
    BEGIN TRANSACTION;

    DROP PROCEDURE IF EXISTS dbo.ObtenCobranzaConcentrada_B2_CacheCapture;
    DROP PROCEDURE IF EXISTS dbo.ff_ObtenCobranzaDesg_Adaptada_B2_CacheCapture;
    DROP PROCEDURE IF EXISTS dbo.ff_ObtenDivisionCtos_Adaptado_B2_CacheCapture;

    /*
       Copias internas de B2. La unica diferencia es que la ultima rutina no
       emite resultsets cuando el cargador activa el contexto de captura.
    */
    DECLARE @Division nvarchar(max)=
        OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_ObtenDivisionCtos_Adaptado'));
    SET @Division=REPLACE
    (
        @Division,
        N'[dbo].[ff_ObtenDivisionCtos_Adaptado]',
        N'[dbo].[ff_ObtenDivisionCtos_Adaptado_B2_CacheCapture]'
    );
    DECLARE @PuntoCaptura int=
        CHARINDEX(N'INSERT INTO #tablatemp (NumEMpleado, Paterno',@Division);
    IF @PuntoCaptura=0
        THROW 55201,'No se encontro el punto de captura en la division de costos B2.',1;
    SET @Division=STUFF
    (
        @Division,@PuntoCaptura,0,
        N'IF TRY_CONVERT(bit,SESSION_CONTEXT(N''bf_CobranzaCacheCapturar''))=1
BEGIN
    /* B2 no crea las temporales de tarjeta que algunas versiones del capturador compilan. */
    IF OBJECT_ID(N''tempdb..#isEmpresaTC'') IS NULL
        CREATE TABLE #isEmpresaTC (result int);

    IF OBJECT_ID(N''tempdb..#CobranzaBanwire'') IS NULL
        CREATE TABLE #CobranzaBanwire
        (
            idEmpleado int NULL,
            CobroTarjeta money NULL,
            Dif money NULL,
            Transaccion varchar(200) NULL,
            FechaCobro varchar(200) NULL,
            CodigoAutorizacion varchar(200) NULL,
            Referencia varchar(200) NULL,
            ext_ref_cliente varchar(300) NULL,
            Card varchar(50) NULL,
            Telefono varchar(100) NULL,
            mail varchar(200) NULL,
            Comercio varchar(100) NULL
        );

    EXEC dbo.bf_CobranzaCache_CapturaBasesV2;
    RETURN;
END;

'
    );
    EXEC sys.sp_executesql @Division;

    DECLARE @Desglosada nvarchar(max)=
        OBJECT_DEFINITION(OBJECT_ID(N'dbo.ff_ObtenCobranzaDesg_Adaptada'));
    SET @Desglosada=REPLACE
    (
        @Desglosada,
        N'[dbo].[ff_ObtenCobranzaDesg_Adaptada]',
        N'[dbo].[ff_ObtenCobranzaDesg_Adaptada_B2_CacheCapture]'
    );
    SET @Desglosada=REPLACE
    (
        @Desglosada,
        N'EXEC dbo.ff_ObtenDivisionCtos_Adaptado',
        N'EXEC dbo.ff_ObtenDivisionCtos_Adaptado_B2_CacheCapture'
    );
    EXEC sys.sp_executesql @Desglosada;

    DECLARE @Concentrada nvarchar(max)=
        OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenCobranzaConcentrada'));
    SET @Concentrada=REPLACE
    (
        @Concentrada,
        N'[dbo].[ObtenCobranzaConcentrada]',
        N'[dbo].[ObtenCobranzaConcentrada_B2_CacheCapture]'
    );
    SET @Concentrada=REPLACE
    (
        @Concentrada,
        N'EXEC dbo.ff_ObtenCobranzaDesg_Adaptada',
        N'EXEC dbo.ff_ObtenCobranzaDesg_Adaptada_B2_CacheCapture'
    );
    EXEC sys.sp_executesql @Concentrada;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    DECLARE @ErrorCopias nvarchar(2048)=ERROR_MESSAGE();
    RAISERROR(N'INSTALACION CANCELADA al preparar las copias B2: %s',16,1,@ErrorCopias);
    SET NOEXEC ON;
END CATCH;
GO

/*
   La version homologada siempre usa una clave exacta. Si hubo cambios se
   reconstruye completa porque B2 no implementa el filtro incremental de B3.
*/
DECLARE @Cargador nvarchar(max)=
    OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_CobranzaCache_CargarUnaV2'));
IF @Cargador NOT LIKE N'%La ruta homologada necesita una fotografia exacta%'
BEGIN
    /* Normaliza CREATE/ALTER sin depender de la cantidad de espacios del servidor. */
    DECLARE @FinPrimeraLinea int=CHARINDEX(CHAR(10),@Cargador);
    IF @FinPrimeraLinea=0
    BEGIN
        RAISERROR(N'INSTALACION CANCELADA: definicion invalida de bf_CobranzaCache_CargarUnaV2.',16,1);
        SET NOEXEC ON;
    END;
    SET @Cargador=STUFF
        (@Cargador,1,@FinPrimeraLinea-1,N'ALTER PROCEDURE dbo.bf_CobranzaCache_CargarUnaV2');

    DECLARE @IniExacta int=CHARINDEX
        (N'IF @EsUniverso',@Cargador);
    DECLARE @FinExacta int=CHARINDEX
        (N'IF @Estado',@Cargador,@IniExacta);
    IF @IniExacta=0 OR @FinExacta=0
    BEGIN
        RAISERROR(N'INSTALACION CANCELADA: no se encontro la seleccion del cache.',16,1);
        SET NOEXEC ON;
    END;

    DECLARE @SeleccionExacta nvarchar(max)=N'IF @EsUniverso=1
        BEGIN
            SELECT TOP (1) @CacheId=CacheId,@FechaAnterior=FechaFuenteHasta,@Estado=Estado,
                   @CacheFecIni=FecIni,@CacheFecFin=FecFin
            FROM dbo.bf_CobranzaCache_ConsultaV2
            WHERE IdEmpresa=@idEmpresa AND IdSolTipo=@idSolTipo
              AND IdVencida=@idVencida AND IdVigencia=@idVigencia
              AND PerfilHash=@PerfilHash AND EsUniverso=1
            ORDER BY CacheId DESC;
        END
        ELSE
        BEGIN
            /* La ruta homologada necesita una fotografia exacta: no sustituirla por un universo. */
            SELECT TOP (1) @CacheId=CacheId,@FechaAnterior=FechaFuenteHasta,@Estado=Estado,
                   @CacheFecIni=FecIni,@CacheFecFin=FecFin
            FROM dbo.bf_CobranzaCache_ConsultaV2
            WHERE IdEmpresa=@idEmpresa AND IdSolTipo=@idSolTipo
              AND FecIni=@FecIni AND FecFin=@FecFin
              AND IdVencida=@idVencida AND IdVigencia=@idVigencia
              AND PerfilHash=@PerfilHash AND EsUniverso=0
            ORDER BY CacheId DESC;
        END;

';
    SET @Cargador=STUFF
        (@Cargador,@IniExacta,@FinExacta-@IniExacta,@SeleccionExacta);
END;

IF @Cargador NOT LIKE N'%B2 no consume #FiltroIncrementalEmps%'
BEGIN
    DECLARE @IniModoFull int=CHARINDEX
        (N'/* Si el SP de empleados no reconoce el filtro temporal',@Cargador);
    IF @IniModoFull=0
        SET @IniModoFull=CHARINDEX(N'IF @idVencida NOT IN',@Cargador);
    DECLARE @FinModoFull int=CHARINDEX
        (N'SET @Modo=''FULL'';',@Cargador,@IniModoFull);
    IF @IniModoFull=0 OR @FinModoFull=0
    BEGIN
        RAISERROR(N'INSTALACION CANCELADA: no se encontro el control DELTA del cache.',16,1);
        SET NOEXEC ON;
    END;

    SET @FinModoFull=@FinModoFull+LEN(N'SET @Modo=''FULL'';');
    SET @Cargador=STUFF
    (
        @Cargador,@IniModoFull,@FinModoFull-@IniModoFull,
        N'/* B2 no consume #FiltroIncrementalEmps: cualquier cambio exige reconstruccion completa. */
            SET @Modo=''FULL'';'
    );
END;

IF @Cargador NOT LIKE N'%La ruta homologada necesita una fotografia exacta%'
   OR @Cargador NOT LIKE N'%B2 no consume #FiltroIncrementalEmps%'
BEGIN
    RAISERROR(N'INSTALACION CANCELADA: no fue posible adaptar el cargador de cache.',16,1);
    SET NOEXEC ON;
END;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.bf_CobranzaCache_CargarUnaV2'))<>@Cargador
    EXEC sys.sp_executesql @Cargador;
GO

CREATE OR ALTER PROCEDURE dbo.ObtenCobranzaConcentrada_otro_V2_BF3
    @idEmpresa int=0,
    @idSolTipo int=0,
    @FecIni varchar(16)='',
    @FecFin varchar(16)='',
    @idVencida int=0,
    @IdPerfil dbo.ListInt READONLY,
    @idVIgencia int=0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @IdPerfilB2 int=NULL,@CantidadPerfiles int;
    SELECT @CantidadPerfiles=COUNT(*),
           @IdPerfilB2=CASE WHEN COUNT(*)=1
                            THEN MIN(IdTipoNotificacionCorreo) ELSE NULL END
    FROM @IdPerfil;

    BEGIN TRY
        INSERT dbo.bf_RepConf_Debug(etapa,detalle)
        VALUES
        (
            'cobranza_bf3_ruta_sql',
            CONCAT('ruta=B2_HOMOLOGADA; empresa=',@idEmpresa,
                   '; vigencia=',@idVIgencia,
                   '; perfiles=',@CantidadPerfiles,
                   '; perfilB2=',COALESCE(CONVERT(varchar(20),@IdPerfilB2),'NULL'),
                   '; cache=',COALESCE(TRY_CONVERT(varchar(10),
                       SESSION_CONTEXT(N'bf_CobranzaCacheCapturar')),'0'))
        );
    END TRY
    BEGIN CATCH
    END CATCH;

    IF TRY_CONVERT(bit,SESSION_CONTEXT(N'bf_CobranzaCacheCapturar'))=1
    BEGIN
        EXEC dbo.ObtenCobranzaConcentrada_B2_CacheCapture
             @idEmpresa=@idEmpresa,
             @idSolTipo=@idSolTipo,
             @FecIni=@FecIni,
             @FecFin=@FecFin,
             @idVencida=@idVencida,
             @IdPerfil=@IdPerfilB2;
        RETURN;
    END;

    EXEC dbo.ObtenCobranzaConcentrada
         @idEmpresa=@idEmpresa,
         @idSolTipo=@idSolTipo,
         @FecIni=@FecIni,
         @FecFin=@FecFin,
         @idVencida=@idVencida,
         @IdPerfil=@IdPerfilB2;
END;
GO

CREATE OR ALTER PROCEDURE dbo.ObtenCobranzaConcentrada_otro_V2_BF3_Cache
    @idEmpresa int=0,
    @idSolTipo int=0,
    @FecIni varchar(16)='',
    @FecFin varchar(16)='',
    @idVencida int=0,
    @IdPerfil dbo.ListInt READONLY,
    @idVIgencia int=0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PerfilClave varchar(2000),
            @PerfilHash varbinary(32),
            @CacheId bigint;

    SELECT @PerfilClave=STUFF
    ((
        SELECT ','+CONVERT(varchar(11),P.IdTipoNotificacionCorreo)
        FROM (SELECT DISTINCT IdTipoNotificacionCorreo FROM @IdPerfil) P
        ORDER BY P.IdTipoNotificacionCorreo
        FOR XML PATH(''),TYPE
    ).value('.','varchar(2000)'),1,1,'');
    SET @PerfilClave=ISNULL(@PerfilClave,'');
    SET @PerfilHash=HASHBYTES('SHA2_256',@PerfilClave);

    SELECT TOP(1) @CacheId=CacheId
    FROM dbo.bf_CobranzaCache_ConsultaV2 WITH(NOLOCK)
    WHERE IdEmpresa=@idEmpresa
      AND IdSolTipo=@idSolTipo
      AND FecIni=@FecIni
      AND FecFin=@FecFin
      AND IdVencida=@idVencida
      AND IdVigencia=@idVIgencia
      AND PerfilHash=@PerfilHash
      AND EsUniverso=0
      AND Estado='COMPLETA'
    ORDER BY CacheId DESC;

    IF @CacheId IS NULL
        THROW 51005,'No existe una cache completa para esos parametros.',1;

    CREATE TABLE #ListEmpresas (EMidEmpresa int NOT NULL PRIMARY KEY);
    INSERT #ListEmpresas VALUES(@idEmpresa);

    CREATE TABLE #isEmpresaTC (result int);

    SELECT @FecIni AS FechaInicio,
           @FecFin AS FechaFin,
           @idVIgencia AS idVigencia
    INTO #ParametrosCobranza;

    SELECT CONVERT(int,ROW_NUMBER() OVER(ORDER BY Orden)) AS Id_tablatemp,
           empresa,NumEMpleado,CveEmpl,Paterno,MAterno,Nombre1,Nombre2,Sexo,FechaNac,Edad,
           Confidencial,SueldoMensual,SueldoMensualAnt,SueldoMensualDif,TRANSFERIDO,NumSolicitud,
           Perfil,FechaAutorizacion,MontoGMM,MontoVIDA,MontoOTROSPLANES,CreditosGMM,CreditosViDA,
           MontoTotalCreditos,MontoTotalCreditosAnt,DiferenciaCreditos,MontoTotalSelecciones,
           MontoTotalSeleccionesAnt,SobranteCreditos,MontoPagCred,MontoDescMensual,MontoDescMensualAnt,
           GrupoParentescoGMM,Excedentes,ExcedentesAnt,MontoFondoAhorroMensual,
           MontoFondoAhorroMensualAnt,SobranteExcedentes,DescuentoEmpleadoFH,DescuentoEmpleadoFinal,
           SobranteExceFinal,CoberturaDesc,Q1,Q2,Diferencia,CtoEmpleadoNomSeg,AplicExcedentes,
           NumOficina,NomOficina,POFH,LocalNumber,PagoEmpresa,PagoEmpleado,CentroCostos
    INTO #tablatemp
    FROM dbo.bf_CobranzaCache_ConcentradaV2 WITH(NOLOCK)
    WHERE CacheId=@CacheId;

    SELECT EMPRESA,NUMEMPLEADO,idemp,Paterno,Materno,Nombre1,Nombre2,idSexo,Sexo,FechaNac,Edad,
           Perfil,CVEParentesco,NombreParentesco,TRANSFERIDO,SueldoMensual,NumSolicitud,POidSolicitud,
           PlanD,PlanOpcion,IdGRUPOP,GRUPOPARENTESCO,CVEPO,CVEP,TIPOSUMASEG,VALSUMA,PLOrdenCobranza,
           ImporteAnual,ImportexPeriodo,MontoTotalCreditos,MontoPeridoCreditos,CostoEmpresa,
           CtoEmpresaCash,CtoEmpresa1erexc,CtoEmpresaStoploss,CostoEmpleado,CtoEmpleadoCash,
           CtoEmpleado1erexc,CtoEmpleadoStoploss,CostoEmpleadoExcedente,CostoEmpleadoReal,
           SobranteExcedentes,PrimaNetaAnual,PrimaNetaxPer,idVigencia
    INTO #TablaCobDesg
    FROM dbo.bf_CobranzaCache_DesglosadaV2 WITH(NOLOCK)
    WHERE CacheId=@CacheId;

    INSERT INTO #tablatemp
    (Id_tablatemp,NumEMpleado,Paterno,MAterno,Nombre1,Nombre2,Sexo,Confidencial,TRANSFERIDO,
     NumSolicitud,Perfil,GrupoParentescoGMM,FechaNac,FechaAutorizacion,MontoGMM,MontoVIDA,
     MontoOTROSPLANES,CreditosGMM,CreditosViDA,MontoTotalCreditos,MontoTotalSelecciones,
     SobranteCreditos,MontoPagCred,MontoDescMensual,Q1,Q2,Diferencia,Excedentes,ExcedentesAnt,
     MontoFondoAhorroMensual,SobranteExcedentes,DescuentoEmpleadoFH,DescuentoEmpleadoFinal,
     CtoEmpleadoNomSeg,SobranteExceFinal,CoberturaDesc,AplicExcedentes)
    SELECT ISNULL(MAX(Id_tablatemp),0)+1,'TOTALES: ','','','','','','','','','','','','',
           SUM(MontoGMM),SUM(MontoVIDA),SUM(MontoOTROSPLANES),SUM(CreditosGMM),SUM(CreditosViDA),
           SUM(MontoTotalCreditos),SUM(MontoTotalSelecciones),SUM(SobranteCreditos),SUM(MontoPagCred),
           ISNULL(SUM(MontoDescMensual),0),SUM(Q1),SUM(Q2),SUM(Diferencia),SUM(Excedentes),
           SUM(ExcedentesAnt),SUM(MontoFondoAhorroMensual),SUM(SobranteExcedentes),
           SUM(DescuentoEmpleadoFH),SUM(DescuentoEmpleadoFinal),SUM(CtoEmpleadoNomSeg),
           SUM(SobranteExceFinal),SUM(CoberturaDesc),SUM(AplicExcedentes)
    FROM #tablatemp;

    SELECT empresa,NumEMpleado,CveEmpl,Paterno,MAterno,Nombre1,Nombre2,Sexo,FechaNac,Edad,
           Confidencial,SueldoMensual,ISNULL(SueldoMensualAnt,0) AS SueldoMensualAnt,
           ISNULL(SueldoMensualDif,0) AS SueldoMensualDif,TRANSFERIDO,NumSolicitud,Perfil,
           FechaAutorizacion,GrupoParentescoGMM AS GrupoParentescoGMM,MontoGMM,MontoVIDA,
           MontoOTROSPLANES,CreditosGMM,CreditosViDA,MontoTotalCreditos,
           ISNULL(MontoTotalCreditosAnt,0) AS MontoTotalCreditosAnt,
           ISNULL(MontoTotalCreditos-MontoTotalCreditosAnt,0) AS DiferenciaCreditos,
           MontoTotalSelecciones,ISNULL(MontoTotalSeleccionesAnt,0) AS MontoTotalSeleccionesAnt,
           ISNULL(MontoTotalSelecciones-MontoTotalSeleccionesAnt,0) AS DiferenciaSelecciones,
           SobranteCreditos,MontoPagCred,MontoDescMensual,
           ISNULL(MontoDescMensualAnt,0) AS MontoDescMensualAnt,
           ISNULL(MontoDescMensual-MontoDescMensualAnt,0) AS DiferenciaMonto,Q1,Q2,Diferencia,
           Excedentes,ISNULL(ExcedentesAnt,0) AS ExcedentesAnt,
           ISNULL(Excedentes-ExcedentesAnt,0) AS DiferenciaExcedentes,
           MontoFondoAhorroMensual,ISNULL(MontoFondoAhorroMensualAnt,0) AS MontoFondoAhorroMensualAnt,
           ISNULL(MontoFondoAhorroMensual-MontoFondoAhorroMensualAnt,0) AS DiferenciaFH,
           SobranteExcedentes,AplicExcedentes,DescuentoEmpleadoFH,DescuentoEmpleadoFinal,
           CtoEmpleadoNomSeg,SobranteExceFinal,CoberturaDesc,NumOficina,NomOficina,POFH,LocalNumber,
           CentroCostos AS PagoEmpresa,PagoEmpleado
    FROM #tablatemp
    ORDER BY NumEmpleado;

    EXEC dbo.ff_ObtenPlanConcentrado_Adaptado;
END;
GO

CREATE OR ALTER PROCEDURE dbo.ReporteCobranzaConcentrada_BF3_Cache
    @idEmpresa int=0,
    @idSolTipo int=0,
    @FecIni varchar(16)='',
    @FecFin varchar(16)='',
    @idVencida int=0,
    @IdPerfil dbo.ListInt READONLY,
    @idVIgencia int=0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF TRY_CONVERT(date,@FecIni) IS NULL OR TRY_CONVERT(date,@FecFin) IS NULL
        THROW 51004,'FecIni o FecFin no tienen un formato valido.',1;

    /*
       B2 recibe varchar(10), por lo que su granularidad real es la fecha. La
       normalizacion permite reutilizar la misma fotografia aunque el cliente
       mande 2026-09-30, 20260930 o 2026-09-30 23:59.
    */
    DECLARE @FecIniNormalizada varchar(16)=CONVERT(char(10),TRY_CONVERT(date,@FecIni),120),
            @FecFinNormalizada varchar(16)=CONVERT(char(10),TRY_CONVERT(date,@FecFin),120),
            @Resultado varchar(30);

    IF TRY_CONVERT(date,@FecIniNormalizada)>TRY_CONVERT(date,@FecFinNormalizada)
        THROW 51004,'FecIni no puede ser posterior a FecFin.',1;

    EXEC dbo.bf_CobranzaCache_CargarUnaV2
         @idEmpresa=@idEmpresa,
         @idSolTipo=@idSolTipo,
         @FecIni=@FecIniNormalizada,
         @FecFin=@FecFinNormalizada,
         @idVencida=@idVencida,
         @IdPerfil=@IdPerfil,
         @idVigencia=@idVIgencia,
         @ForzarRecarga=0,
         @EsUniverso=0,
         @Resultado=@Resultado OUTPUT;

    EXEC dbo.ObtenCobranzaConcentrada_otro_V2_BF3_Cache
         @idEmpresa=@idEmpresa,
         @idSolTipo=@idSolTipo,
         @FecIni=@FecIniNormalizada,
         @FecFin=@FecFinNormalizada,
         @idVencida=@idVencida,
         @IdPerfil=@IdPerfil,
         @idVIgencia=@idVIgencia;
END;
GO

/*
   Precarga segura del universo de una vigencia como fotografias de periodos.
   No intenta derivar un mes filtrando el resultado anual: cada particion se
   genera con los parametros exactos de B2. Los rangos personalizados que no
   coincidan con una particion se calculan bajo demanda por el wrapper anterior.
*/
CREATE OR ALTER PROCEDURE dbo.PrecargaUniversoCobranzaVigencia_BF3_Cache
    @idEmpresa int,
    @idVigencia int,
    @IdPerfil dbo.ListInt READONLY,
    @Desde date=NULL,
    @Hasta date=NULL,
    @idSolTipo int=0,
    @idVencida int=1,
    @ForzarRecarga bit=0,
    @EmitirResultado bit=1
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @InicioVigencia date,
            @FinVigencia date,
            @PerfilClave varchar(2000),
            @PerfilHash varbinary(32);

    SELECT @InicioVigencia=CONVERT
           (
               date,
               CASE WHEN VIEnrollmentIni IS NOT NULL AND VIEnrollmentIni<VIVigenciaIni
                    THEN VIEnrollmentIni ELSE VIVigenciaIni END
           ),
           @FinVigencia=CONVERT(date,VIVigenciaFin)
    FROM dbo.ff_Vigencia WITH(NOLOCK)
    WHERE VIidVigencia=@idVigencia;

    IF @InicioVigencia IS NULL OR @FinVigencia IS NULL
        THROW 55210,'La vigencia solicitada no existe.',1;

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ff_Empresa E WITH(NOLOCK)
        INNER JOIN dbo.ff_Vigencia V WITH(NOLOCK)
            ON V.VIidConfiguracion=E.EMidConfiguracion
        WHERE E.EMidEmpresa=@idEmpresa
          AND V.VIidVigencia=@idVigencia
    )
        THROW 55210,'La vigencia no pertenece a la empresa solicitada.',1;

    SET @Desde=CASE WHEN @Desde IS NULL OR @Desde<@InicioVigencia
                    THEN @InicioVigencia ELSE @Desde END;
    SET @Hasta=CASE WHEN @Hasta IS NULL OR @Hasta>@FinVigencia
                    THEN @FinVigencia ELSE @Hasta END;

    IF @Desde>@Hasta
        THROW 55210,'El rango de precarga no intersecta la vigencia.',1;

    SELECT @PerfilClave=STUFF
    ((
        SELECT ','+CONVERT(varchar(11),P.IdTipoNotificacionCorreo)
        FROM (SELECT DISTINCT IdTipoNotificacionCorreo FROM @IdPerfil) P
        ORDER BY P.IdTipoNotificacionCorreo
        FOR XML PATH(''),TYPE
    ).value('.','varchar(2000)'),1,1,'');
    SET @PerfilClave=ISNULL(@PerfilClave,'');
    SET @PerfilHash=HASHBYTES('SHA2_256',@PerfilClave);

    CREATE TABLE #PeriodosGenerados
    (
        Orden int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        FecIni varchar(16) NOT NULL,
        FecFin varchar(16) NOT NULL,
        Resultado varchar(30) NOT NULL,
        CacheId bigint NULL,
        Estado varchar(20) NULL,
        FilasConcentrada int NULL,
        FilasDesglosada int NULL
    );

    DECLARE @Mes date=DATEFROMPARTS(YEAR(@Desde),MONTH(@Desde),1),
            @InicioPeriodo date,
            @FinPeriodo date,
            @Ini varchar(16),
            @Fin varchar(16),
            @Resultado varchar(30),
            @CacheId bigint;

    WHILE @Mes<=@Hasta
    BEGIN
        SET @InicioPeriodo=CASE WHEN @Mes<@Desde THEN @Desde ELSE @Mes END;
        SET @FinPeriodo=CASE WHEN EOMONTH(@Mes)>@Hasta THEN @Hasta ELSE EOMONTH(@Mes) END;
        SET @Ini=CONVERT(char(10),@InicioPeriodo,120);
        SET @Fin=CONVERT(char(10),@FinPeriodo,120);
        SET @Resultado=NULL;
        SET @CacheId=NULL;

        EXEC dbo.bf_CobranzaCache_CargarUnaV2
             @idEmpresa=@idEmpresa,
             @idSolTipo=@idSolTipo,
             @FecIni=@Ini,
             @FecFin=@Fin,
             @idVencida=@idVencida,
             @IdPerfil=@IdPerfil,
             @idVigencia=@idVigencia,
             @ForzarRecarga=@ForzarRecarga,
             @EsUniverso=0,
             @Resultado=@Resultado OUTPUT;

        SELECT TOP(1) @CacheId=CacheId
        FROM dbo.bf_CobranzaCache_ConsultaV2 WITH(NOLOCK)
        WHERE IdEmpresa=@idEmpresa
          AND IdSolTipo=@idSolTipo
          AND FecIni=@Ini
          AND FecFin=@Fin
          AND IdVencida=@idVencida
          AND IdVigencia=@idVigencia
          AND PerfilHash=@PerfilHash
          AND EsUniverso=0
        ORDER BY CacheId DESC;

        INSERT #PeriodosGenerados
        (FecIni,FecFin,Resultado,CacheId,Estado,FilasConcentrada,FilasDesglosada)
        SELECT @Ini,@Fin,ISNULL(@Resultado,'SIN_RESULTADO'),Q.CacheId,Q.Estado,
               Q.FilasConcentrada,Q.FilasDesglosada
        FROM (VALUES(1)) X(N)
        LEFT JOIN dbo.bf_CobranzaCache_ConsultaV2 Q WITH(NOLOCK)
            ON Q.CacheId=@CacheId;

        SET @Mes=DATEADD(month,1,@Mes);
    END;

    IF @EmitirResultado=1
        SELECT FecIni,FecFin,Resultado,CacheId,Estado,
               FilasConcentrada,FilasDesglosada
        FROM #PeriodosGenerados
        ORDER BY Orden;
END;
GO

/* ========================================================================
   CONFIGURACION DE CACHE PARA LA EMPRESA 917
   ======================================================================== */
USE [FlexiForbesv2];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresaCache int=917,
        @UsuarioCache int=1,
        @IdParametroCache int;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP(1) @IdParametroCache=paId
    FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=@IdEmpresaCache
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))='COBRANZA_CACHE'
    ORDER BY paidEstatus DESC,paId DESC;

    IF @IdParametroCache IS NULL
    BEGIN
        SELECT @IdParametroCache=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paidEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@IdParametroCache,@IdEmpresaCache,'COBRANZA_CACHE','1',
         'Habilita cache B2 homologado de cobranza para la empresa',
         1,@UsuarioCache,GETDATE());
    END
    ELSE
        UPDATE dbo.ff_Parametro WITH(ROWLOCK)
           SET paClase='COBRANZA_CACHE',
               paValor='1',
               paDescripcion='Habilita cache B2 homologado de cobranza para la empresa',
               paidEstatus=1,
               paUsuarioUmod=@UsuarioCache,
               paFechaUmod=GETDATE(),
               paFechaDel=NULL,
               paUsuarioDel=NULL
         WHERE paId=@IdParametroCache;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* ========================================================================
   HORARIO DIARIO DEL WORKER
   Ajustar @HoraWorker antes de ejecutar. Zona: America/Mexico_City.
   ======================================================================== */
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @HoraWorker varchar(5)='01:00',
        @UsuarioWorker int=1,
        @IdParametroWorker int;

IF LEN(@HoraWorker)<>5
   OR SUBSTRING(@HoraWorker,3,1)<>':'
   OR TRY_CONVERT(int,LEFT(@HoraWorker,2)) NOT BETWEEN 0 AND 23
   OR TRY_CONVERT(int,RIGHT(@HoraWorker,2)) NOT BETWEEN 0 AND 59
    THROW 55331,'COBRANZA_CACHE_HORA debe tener formato HH:mm.',1;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP(1) @IdParametroWorker=paId
    FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK)
    WHERE paIdEmpresa=0
      AND UPPER(LTRIM(RTRIM(ISNULL(paClase,''))))='COBRANZA_CACHE_HORA'
    ORDER BY paidEstatus DESC,paId DESC;

    IF @IdParametroWorker IS NULL
    BEGIN
        SELECT @IdParametroWorker=ISNULL(MAX(paId),0)+1
        FROM dbo.ff_Parametro WITH(UPDLOCK,HOLDLOCK);

        INSERT dbo.ff_Parametro
        (paId,paIdEmpresa,paClase,paValor,paDescripcion,
         paidEstatus,paUsuarioAdd,paFechaAdd)
        VALUES
        (@IdParametroWorker,0,'COBRANZA_CACHE_HORA',@HoraWorker,
         'Horario diario del worker de cache Cobranza (HH:mm America/Mexico_City)',
         1,@UsuarioWorker,GETDATE());
    END
    ELSE
        UPDATE dbo.ff_Parametro WITH(ROWLOCK)
           SET paClase='COBRANZA_CACHE_HORA',
               paValor=@HoraWorker,
               paDescripcion='Horario diario del worker de cache Cobranza (HH:mm America/Mexico_City)',
               paidEstatus=1,
               paUsuarioUmod=@UsuarioWorker,
               paFechaUmod=GETDATE(),
               paFechaDel=NULL,
               paUsuarioDel=NULL
         WHERE paId=@IdParametroWorker;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* ========================================================================
   PRECARGA INICIAL: SOLO EL MES ACTUAL DE LA EMPRESA 917 / VIGENCIA 4251
   Los demas periodos se generan y conservan bajo demanda.
   ======================================================================== */
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresaPrecarga int=917,
        @IdVigenciaPrecarga int=4251,
        @IdSolTipoPrecarga int=1,
        @DesdePrecarga date=DATEFROMPARTS(YEAR(GETDATE()),MONTH(GETDATE()),1),
        @HastaPrecarga date=EOMONTH(GETDATE()),
        @ForzarRecargaPrecarga bit=0;

DECLARE @PerfilesPrecarga dbo.ListInt;

INSERT @PerfilesPrecarga(IdTipoNotificacionCorreo)
SELECT DISTINCT P.PEIdPerfil
FROM dbo.ff_Perfil P WITH(NOLOCK)
WHERE P.PEIdEmpresa=@IdEmpresaPrecarga
  AND P.PEIdEstatus=1
  AND P.PEAdministrador=0;

IF NOT EXISTS(SELECT 1 FROM @PerfilesPrecarga)
    THROW 55310,'La empresa no tiene perfiles activos no administradores.',1;

EXEC dbo.PrecargaUniversoCobranzaVigencia_BF3_Cache
     @idEmpresa=@IdEmpresaPrecarga,
     @idVigencia=@IdVigenciaPrecarga,
     @IdPerfil=@PerfilesPrecarga,
     @Desde=@DesdePrecarga,
     @Hasta=@HastaPrecarga,
     @idSolTipo=@IdSolTipoPrecarga,
     @idVencida=1,
     @ForzarRecarga=@ForzarRecargaPrecarga,
     @EmitirResultado=1;
GO

/* Reactiva la ejecucion si el prechequeo la desactivo. */
SET NOEXEC OFF;
GO