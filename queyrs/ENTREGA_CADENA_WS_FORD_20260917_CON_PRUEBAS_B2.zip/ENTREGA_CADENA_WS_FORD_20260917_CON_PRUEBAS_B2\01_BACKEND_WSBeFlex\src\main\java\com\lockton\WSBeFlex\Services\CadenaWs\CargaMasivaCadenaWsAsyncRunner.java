package com.lockton.WSBeFlex.Services.CadenaWs;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.DAO.CargaCadenaWsDAO;
import com.lockton.WSBeFlex.Services.CargaMasivaB2.CargaMasivaOperacionExecutor;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/** Worker independiente: el lote continua aunque termine la peticion HTTP. */
@Service
public class CargaMasivaCadenaWsAsyncRunner {
    private static final Log LOG = LogFactory.getLog(CargaMasivaCadenaWsAsyncRunner.class);
    private final CargaCadenaWsDAO dao;
    private final CargaMasivaOperacionExecutor executor;
    private final ObjectMapper objectMapper;

    public CargaMasivaCadenaWsAsyncRunner(CargaCadenaWsDAO dao,
                                          CargaMasivaOperacionExecutor executor,
                                          ObjectMapper objectMapper) {
        this.dao = dao;
        this.executor = executor;
        this.objectMapper = objectMapper;
    }

    @Async("cadenaWsExecutor")
    public void ejecutar(UUID idLote, int idUsuario, String modo) {
        try {
            Map<String, Object> lote = dao.obtenerLote(idLote);
            if (lote == null || numero(lote.get("idEmpresa")) != CargaMasivaCadenaWsService.EMPRESA_FORD) {
                throw new IllegalStateException("El lote no pertenece a la configuracion Ford.");
            }
            CargaMasivaOperacionExecutor.Preparacion preparacion = executor.preparar(
                    CargaMasivaCadenaWsService.EMPRESA_FORD,
                    CargaMasivaCadenaWsService.OPERACION_FORD);
            validarContrato(preparacion);
            List<Map<String, Object>> pendientes = dao.listarPendientes(idLote);
            boolean detener = false;
            for (Map<String, Object> detalle : pendientes) {
                if (detener) break;
                long idDetalle = numeroLargo(detalle.get("idDetalle"));
                String hashRegistro = String.valueOf(detalle.get("hashRegistro"));
                String codigoMovimiento = String.valueOf(detalle.get("codigoMovimiento"));
                if (!dao.reclamarRegistro(CargaMasivaCadenaWsService.EMPRESA_FORD,
                        hashRegistro, codigoMovimiento, idLote, idDetalle)) {
                    dao.registrarDuplicadoEnEjecucion(idLote, idDetalle);
                    if ("PRIMER_ERROR".equals(modo)) detener = true;
                    continue;
                }
                if (!dao.marcarProcesando(idDetalle)) {
                    dao.liberarReclamo(CargaMasivaCadenaWsService.EMPRESA_FORD,
                            hashRegistro, codigoMovimiento, idLote, idDetalle);
                    continue;
                }
                boolean exitoso = false;
                CargaMasivaOperacionExecutor.Resultado resultado;
                try {
                    String json = String.valueOf(detalle.get("parametrosJson"));
                    Map<String, String> parametros = objectMapper.readValue(
                            json, new TypeReference<Map<String, String>>() { });
                    resultado = executor.ejecutarRegistro(
                            preparacion, parametros, idUsuario,
                            CargaMasivaOperacionExecutor.Contexto.ford());
                } catch (Exception e) {
                    LOG.error("Fallo detalle CadenaWS. Lote=" + idLote
                            + ", renglon=" + detalle.get("renglon"), e);
                    dao.registrarResultado(idLote, idDetalle,
                            CargaMasivaCadenaWsService.EMPRESA_FORD,
                            hashRegistro, codigoMovimiento, false, -1,
                            "El registro no pudo procesarse. Consulte el log del WS.");
                    if ("PRIMER_ERROR".equals(modo)) detener = true;
                    continue;
                }
                exitoso = resultado.esExitoso();
                /* Si falla esta persistencia despues del SP, el reclamo queda EN_PROCESO.
                   Se privilegia no duplicar una operacion de resultado incierto. */
                dao.registrarResultado(idLote, idDetalle,
                        CargaMasivaCadenaWsService.EMPRESA_FORD,
                        hashRegistro, codigoMovimiento, exitoso,
                        resultado.getCodigoSp(), resultado.getMensaje());
                if (!exitoso && "PRIMER_ERROR".equals(modo)) detener = true;
            }
            if (detener) {
                dao.omitirPendientes(idLote, "Omitido por configuracion: detener al primer error.");
            }
            dao.finalizar(idLote);
        } catch (Exception e) {
            LOG.error("Fallo fatal CadenaWS. Lote=" + idLote, e);
            try { dao.finalizarConError(idLote, "El lote termino por un error tecnico."); }
            catch (Exception persistencia) {
                LOG.error("No fue posible cerrar el lote CadenaWS. Lote=" + idLote, persistencia);
            }
        }
    }

    private void validarContrato(CargaMasivaOperacionExecutor.Preparacion preparacion) {
        String procedimiento = preparacion.getProcedimiento().replace("[", "").replace("]", "");
        if (procedimiento.toLowerCase(Locale.ROOT).startsWith("dbo.")) procedimiento = procedimiento.substring(4);
        if (preparacion.getIdPlantilla() != CargaMasivaCadenaWsService.PLANTILLA_FORD
                || !CargaMasivaCadenaWsService.SP_FORD.equalsIgnoreCase(procedimiento)) {
            throw new IllegalStateException("La configuracion Ford cambio despues del analisis.");
        }
    }

    private int numero(Object valor) {
        if (valor instanceof Number) return ((Number) valor).intValue();
        return valor == null ? 0 : Integer.parseInt(String.valueOf(valor));
    }

    private long numeroLargo(Object valor) {
        if (valor instanceof Number) return ((Number) valor).longValue();
        return valor == null ? 0L : Long.parseLong(String.valueOf(valor));
    }
}
