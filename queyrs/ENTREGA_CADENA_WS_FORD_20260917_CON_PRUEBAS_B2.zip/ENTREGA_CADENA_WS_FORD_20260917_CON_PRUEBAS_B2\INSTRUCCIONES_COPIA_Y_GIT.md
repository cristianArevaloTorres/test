# Entrega CadenaWS Ford y TXT BF3/B2

El paquete conserva las rutas relativas de los archivos dentro de cada repositorio. No contiene `target`, `dist`, `node_modules`, resultados de diagnóstico ni datos reales de empleados.

## 1. Backend

Copiar **el contenido** de `01_BACKEND_WSBeFlex` sobre la raíz del repositorio backend `WSBeFlex-EmpAdm-defaulteoCargaMaisva`.

Antes de habilitar CadenaWS, ejecutar en la base BeFlex correspondiente:

`database/009_infraestructura_cadena_ws_ford.sql`

Además del flujo CadenaWS, esta versión incorpora en `CargaMasivaB2Service.java` la compatibilidad requerida por `ff_XCMTitularesAltaCMFORD`: agrega `EMIdEstatus` y `EMPerfil`, y no envía `EMUsuarioUMod`, que ese SP no declara.

## 2. Frontend

Copiar **el contenido** de `02_FRONTEND_BeFlex3` sobre la raíz del repositorio frontend `BeFlex3-EmpAdm-defaulteoCargaMaisva`.

## 3. Material de prueba DEV/QA

Estas carpetas no se copian a los repositorios:

- `03_CADENAS_PRUEBA`: nueve archivos CadenaWS, con siete registros dummy por evento.
- `04_TXT_CARGA_MASIVA_B2`: nueve archivos TXT para los templates activos de la pantalla BF3 en flujo B2.

Leer primero los README y ejecutar las prevalidaciones de sólo lectura. No utilizar los archivos en producción ni ejecutar dos etapas simultáneamente.

## 4. Validación realizada y recomendada

En esta entrega se comprobó:

- Los nueve TXT BF3/B2 fueron aceptados por el mismo `CargaMasivaTxtParser` del backend.
- Cada archivo contiene siete registros y exactamente los campos activos de su template.
- Las pruebas `CargaMasivaB2ServiceTest` y `CargaMasivaTxtParserTest` terminaron con 10 pruebas correctas y 0 fallos.

En el ambiente destino:

1. Revisar `git status --short` antes y después de copiar.
2. Confirmar los archivos con `MANIFEST_SHA256.txt`.
3. Ejecutar las compilaciones normales de ambos repositorios.
4. Ejecutar primero las prevalidaciones SQL en QA.
5. Probar las etapas en el orden indicado por cada matriz.

## 5. Archivos de código incluidos

### Backend

- `database/009_infraestructura_cadena_ws_ford.sql`
- `src/main/java/com/lockton/WSBeFlex/AsyncConfig.java`
- `src/main/java/com/lockton/WSBeFlex/DAO/CargaCadenaWsDAO.java`
- `src/main/java/com/lockton/WSBeFlex/REST/WSCargaMasivaCadenaWs.java`
- `src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaOperacionExecutor.java`
- `src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2Service.java`
- `src/main/java/com/lockton/WSBeFlex/Services/CadenaWs/*`
- `src/test/java/com/lockton/WSBeFlex/Services/CadenaWs/FordCadenaParserTest.java`
- `src/test/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2ServiceTest.java`

### Frontend

- `src/app/beflex/cargamasivaadm/cargamasivaadm.component.html`
- `src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts`
- `src/app/services/titulares.service.ts`

## 6. Comandos Git

Si ya existe una rama de trabajo, omitir `git switch -c`.

### Backend

```powershell
cd C:\RUTA\WSBeFlex-EmpAdm-defaulteoCargaMaisva
git status --short
git switch -c feat/cadena-ws-ford
git add database/009_infraestructura_cadena_ws_ford.sql src/main/java/com/lockton/WSBeFlex/AsyncConfig.java src/main/java/com/lockton/WSBeFlex/DAO/CargaCadenaWsDAO.java src/main/java/com/lockton/WSBeFlex/REST/WSCargaMasivaCadenaWs.java src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaOperacionExecutor.java src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2Service.java src/main/java/com/lockton/WSBeFlex/Services/CadenaWs src/test/java/com/lockton/WSBeFlex/Services/CadenaWs src/test/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2ServiceTest.java
git diff --cached --check
git diff --cached --stat
git commit -m "feat: integra carga Ford por CadenaWS y compatibilidad B2"
git push -u origin feat/cadena-ws-ford
```

### Frontend

```powershell
cd C:\RUTA\BeFlex3-EmpAdm-defaulteoCargaMaisva
git status --short
git switch -c feat/cadena-ws-ford
git add src/app/beflex/cargamasivaadm/cargamasivaadm.component.html src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts src/app/services/titulares.service.ts
git diff --cached --check
git diff --cached --stat
git commit -m "feat: agrega origen Ford CadenaWS a carga masiva"
git push -u origin feat/cadena-ws-ford
```
