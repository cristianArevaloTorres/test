package com.lockton.WSBeFlex.Services.CadenaWs;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

class FordCadenaParserTest {
    private final FordCadenaParser parser = new FordCadenaParser();

    @Test
    void interpretaLayoutHistoricoDe28Posiciones() {
        String[] detalle = detalle(28);
        detalle[1] = "109";
        detalle[2] = "M";
        detalle[3] = "A";
        detalle[4] = "GPID001";
        detalle[22] = "HIR";
        detalle[27] = "S";
        FordCadenaDocumento documento = parser.parse(archivo(detalle, 1)
                .getBytes(StandardCharsets.UTF_8));

        assertEquals("FORD_28", documento.getVersionLayout());
        assertEquals(1, documento.getRegistros().size());
        assertEquals("109", documento.getRegistros().get(0).getEmpresaExterna());
        assertEquals("HIR", documento.getRegistros().get(0).getCodigoMovimiento());
        assertEquals("", documento.getRegistros().get(0).getFechaAntiguedadPp());
    }

    @Test
    void interpretaLayoutNuevoDe29PosicionesYWindows1252() {
        String[] detalle = detalle(29);
        detalle[1] = "137";
        detalle[7] = "José";
        detalle[28] = "01/01/2020";
        FordCadenaDocumento documento = parser.parse(archivo(detalle, 1)
                .getBytes(Charset.forName("windows-1252")));

        assertEquals("FORD_29", documento.getVersionLayout());
        assertEquals("01/01/2020", documento.getRegistros().get(0).getFechaAntiguedadPp());
        assertEquals("José", documento.getRegistros().get(0).posicion(8));
    }

    @Test
    void rechazaConteoDeSumarioIncorrecto() {
        assertThrows(IllegalArgumentException.class,
                () -> parser.parse(archivo(detalle(28), 2).getBytes(StandardCharsets.UTF_8)));
    }

    @Test
    void rechazaVersionesMezcladas() {
        String texto = "01|MOVIMIENTOS_PERSONAL\n"
                + String.join("|", detalle(28)) + "\n"
                + String.join("|", detalle(29)) + "\n03|2\n";
        assertThrows(IllegalArgumentException.class,
                () -> parser.parse(texto.getBytes(StandardCharsets.UTF_8)));
    }

    private String archivo(String[] detalle, int total) {
        return "01|MOVIMIENTOS_PERSONAL\r\n" + String.join("|", detalle)
                + "\r\n03|" + total + "\r\n";
    }

    private String[] detalle(int posiciones) {
        String[] campos = new String[posiciones];
        Arrays.fill(campos, "");
        campos[0] = "02";
        return campos;
    }
}
