package com.lockton.WSBeFlex.Services.CadenaWs;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Component;

/** Parser estricto para MOVIMIENTOS_PERSONAL Ford (01 / 02 / 03). */
@Component
public class FordCadenaParser {
    public static final int MAX_BYTES = 10 * 1024 * 1024;
    public static final int MAX_REGISTROS = 10000;
    private static final int MAX_LONGITUD_LINEA = 12000;

    public FordCadenaDocumento parse(byte[] contenido) {
        if (contenido == null || contenido.length == 0) {
            throw new IllegalArgumentException("El archivo Ford esta vacio.");
        }
        if (contenido.length > MAX_BYTES) {
            throw new IllegalArgumentException("El archivo Ford no puede exceder 10 MB.");
        }
        String texto = decodificar(contenido);
        if (!texto.isEmpty() && texto.charAt(0) == '\uFEFF') texto = texto.substring(1);
        if (texto.indexOf('\0') >= 0) {
            throw new IllegalArgumentException("El archivo contiene datos binarios no permitidos.");
        }

        String[] lineas = texto.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
        String nombreDeclarado = null;
        Integer totalDeclarado = null;
        boolean trailerEncontrado = false;
        List<FordCadenaRegistro> registros = new ArrayList<>();
        Integer posiciones = null;

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];
            int renglon = i + 1;
            if (linea.trim().isEmpty()) continue;
            if (linea.length() > MAX_LONGITUD_LINEA) {
                throw new IllegalArgumentException("El renglon " + renglon + " excede la longitud permitida.");
            }
            validarControles(linea, renglon);
            List<String> campos = Arrays.asList(linea.split("\\|", -1));
            String tipo = campos.get(0).trim();
            if ("01".equals(tipo)) {
                if (nombreDeclarado != null || !registros.isEmpty() || trailerEncontrado) {
                    throw new IllegalArgumentException("El encabezado 01 debe aparecer una sola vez al inicio.");
                }
                if (campos.size() != 2 || campos.get(1).trim().isEmpty()) {
                    throw new IllegalArgumentException("El encabezado 01 no contiene el nombre logico del archivo.");
                }
                nombreDeclarado = campos.get(1).trim();
            } else if ("02".equals(tipo)) {
                if (nombreDeclarado == null) {
                    throw new IllegalArgumentException("Se encontro un detalle 02 antes del encabezado 01.");
                }
                if (trailerEncontrado) {
                    throw new IllegalArgumentException("Se encontro un detalle 02 despues del sumario 03.");
                }
                if (campos.size() != 28 && campos.size() != 29) {
                    throw new IllegalArgumentException("El renglon " + renglon
                            + " debe contener 28 o 29 posiciones y contiene " + campos.size() + ".");
                }
                if (posiciones == null) posiciones = campos.size();
                if (posiciones.intValue() != campos.size()) {
                    throw new IllegalArgumentException("El archivo mezcla versiones de 28 y 29 posiciones.");
                }
                registros.add(new FordCadenaRegistro(renglon, campos, sha256(linea)));
                if (registros.size() > MAX_REGISTROS) {
                    throw new IllegalArgumentException("El archivo excede el limite de 10000 registros.");
                }
            } else if ("03".equals(tipo)) {
                if (nombreDeclarado == null || trailerEncontrado) {
                    throw new IllegalArgumentException("El sumario 03 es duplicado o aparece fuera de orden.");
                }
                if (campos.size() != 2) {
                    throw new IllegalArgumentException("El sumario 03 debe contener exactamente dos posiciones.");
                }
                try {
                    totalDeclarado = Integer.valueOf(campos.get(1).trim());
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("El total declarado en el sumario 03 no es numerico.");
                }
                trailerEncontrado = true;
            } else {
                throw new IllegalArgumentException("Tipo de registro no reconocido en el renglon " + renglon + ".");
            }
        }

        if (nombreDeclarado == null) throw new IllegalArgumentException("Falta el encabezado 01.");
        if (!trailerEncontrado || totalDeclarado == null) throw new IllegalArgumentException("Falta el sumario 03.");
        if (registros.isEmpty()) throw new IllegalArgumentException("El archivo no contiene detalles 02.");
        if (totalDeclarado.intValue() != registros.size()) {
            throw new IllegalArgumentException("El sumario declara " + totalDeclarado
                    + " registros, pero se encontraron " + registros.size() + ".");
        }
        String version = posiciones != null && posiciones == 29 ? "FORD_29" : "FORD_28";
        return new FordCadenaDocumento(nombreDeclarado, version, sha256(contenido), registros);
    }

    private String decodificar(byte[] contenido) {
        try {
            return decodificarEstricto(contenido, StandardCharsets.UTF_8);
        } catch (CharacterCodingException e) {
            try {
                return decodificarEstricto(contenido, Charset.forName("windows-1252"));
            } catch (CharacterCodingException imposible) {
                throw new IllegalArgumentException("La codificacion del archivo no es UTF-8 ni Windows-1252.");
            }
        }
    }

    private String decodificarEstricto(byte[] contenido, Charset charset) throws CharacterCodingException {
        CharBuffer chars = charset.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(contenido));
        return chars.toString();
    }

    private void validarControles(String linea, int renglon) {
        for (int i = 0; i < linea.length(); i++) {
            char c = linea.charAt(i);
            if (c < 32 && c != '\t') {
                throw new IllegalArgumentException("El renglon " + renglon
                        + " contiene caracteres de control no permitidos.");
            }
        }
    }

    static String sha256(String dato) {
        return sha256(dato.getBytes(StandardCharsets.UTF_8));
    }

    static String sha256(byte[] dato) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(dato);
            StringBuilder salida = new StringBuilder(hash.length * 2);
            for (byte b : hash) salida.append(String.format("%02x", b & 0xff));
            return salida.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 no esta disponible.", e);
        }
    }
}
