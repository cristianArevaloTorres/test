/*
  Infraestructura Archivo/CadenaWS Ford.

  - No modifica objetos legacy ni el SP ff_XCMTitularesAltaCMFORD.
  - Persiste analisis, progreso, resultado e idempotencia por renglon.
  - Los parametros con datos personales son transitorios: el backend los
    elimina al concluir correctamente cada detalle.
  - Script idempotente para SQL Server 2016+.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.bf_CargaCadenaWsLote', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_CargaCadenaWsLote
    (
        CLId                    UNIQUEIDENTIFIER NOT NULL
            CONSTRAINT PK_bf_CargaCadenaWsLote PRIMARY KEY,
        CLIdEmpresa             INT NOT NULL,
        CLHashArchivo           CHAR(64) NOT NULL,
        CLNombreArchivo         NVARCHAR(260) NOT NULL,
        CLNombreDeclarado       NVARCHAR(260) NULL,
        CLVersionLayout         VARCHAR(20) NOT NULL,
        CLEstado                VARCHAR(40) NOT NULL,
        CLModo                  VARCHAR(20) NULL,
        CLTotal                 INT NOT NULL,
        CLEjecutables           INT NOT NULL,
        CLAdvertencias          INT NOT NULL,
        CLErroresValidacion     INT NOT NULL,
        CLProcesados            INT NOT NULL CONSTRAINT DF_bf_CadenaWs_Procesados DEFAULT (0),
        CLExitosos              INT NOT NULL CONSTRAINT DF_bf_CadenaWs_Exitosos DEFAULT (0),
        CLErroresEjecucion      INT NOT NULL CONSTRAINT DF_bf_CadenaWs_Errores DEFAULT (0),
        CLIdUsuario             INT NOT NULL,
        CLIdTraza               VARCHAR(100) NULL,
        CLMensaje               NVARCHAR(1000) NULL,
        CLFechaAnalisis         DATETIME2(0) NOT NULL CONSTRAINT DF_bf_CadenaWs_Analisis DEFAULT (SYSDATETIME()),
        CLFechaInicio           DATETIME2(0) NULL,
        CLFechaFin              DATETIME2(0) NULL
    );

    CREATE INDEX IX_bf_CargaCadenaWsLote_UsuarioFecha
        ON dbo.bf_CargaCadenaWsLote (CLIdUsuario, CLFechaAnalisis DESC)
        INCLUDE (CLIdEmpresa, CLEstado, CLTotal, CLProcesados, CLExitosos);

    CREATE INDEX IX_bf_CargaCadenaWsLote_Hash
        ON dbo.bf_CargaCadenaWsLote (CLIdEmpresa, CLHashArchivo, CLFechaAnalisis DESC)
        INCLUDE (CLId, CLEstado);
END;
GO

IF OBJECT_ID(N'dbo.bf_CargaCadenaWsIdempotencia', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_CargaCadenaWsIdempotencia
    (
        CIIdEmpresa          INT NOT NULL,
        CIHashRegistro       CHAR(64) NOT NULL,
        CICodigoMovimiento   VARCHAR(10) NOT NULL,
        CIEstado             VARCHAR(20) NOT NULL,
        CIIdLote             UNIQUEIDENTIFIER NOT NULL,
        CIIdDetalle          BIGINT NOT NULL,
        CIFechaActualizacion DATETIME2(0) NOT NULL
            CONSTRAINT DF_bf_CadenaWsIdem_Fecha DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_bf_CargaCadenaWsIdempotencia PRIMARY KEY
            (CIIdEmpresa, CIHashRegistro, CICodigoMovimiento)
    );
END;
GO

IF OBJECT_ID(N'dbo.bf_CargaCadenaWsDetalle', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_CargaCadenaWsDetalle
    (
        CDId                       BIGINT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_bf_CargaCadenaWsDetalle PRIMARY KEY,
        CDIdLote                   UNIQUEIDENTIFIER NOT NULL,
        CDIdEmpresa                INT NOT NULL,
        CDNumeroRenglon            INT NOT NULL,
        CDHashRegistro             CHAR(64) NOT NULL,
        CDIdentificadorProtegido   VARCHAR(40) NULL,
        CDEmpresaExterna           VARCHAR(20) NULL,
        CDCodigoMovimiento         VARCHAR(10) NULL,
        CDTipoMovimiento           VARCHAR(40) NULL,
        CDIdOperacion              INT NOT NULL,
        CDIdPlantilla              INT NULL,
        CDProcedimiento            SYSNAME NULL,
        CDEstado                   VARCHAR(40) NOT NULL,
        CDCodigoResultado          INT NULL,
        CDMensaje                  NVARCHAR(2000) NULL,
        CDParametrosJson           NVARCHAR(MAX) NULL,
        CDFechaProceso             DATETIME2(0) NULL,
        CDFechaAdd                 DATETIME2(0) NOT NULL CONSTRAINT DF_bf_CadenaWsDet_Add DEFAULT (SYSDATETIME()),
        CONSTRAINT FK_bf_CargaCadenaWsDetalle_Lote FOREIGN KEY (CDIdLote)
            REFERENCES dbo.bf_CargaCadenaWsLote (CLId)
    );

    CREATE UNIQUE INDEX UX_bf_CargaCadenaWsDetalle_LoteRenglon
        ON dbo.bf_CargaCadenaWsDetalle (CDIdLote, CDNumeroRenglon);

    CREATE INDEX IX_bf_CargaCadenaWsDetalle_LoteEstado
        ON dbo.bf_CargaCadenaWsDetalle (CDIdLote, CDEstado, CDNumeroRenglon)
        INCLUDE (CDHashRegistro, CDCodigoMovimiento, CDCodigoResultado);

    /* Un movimiento exitoso no se ejecuta otra vez de forma accidental. */
    CREATE UNIQUE INDEX UX_bf_CargaCadenaWsDetalle_IdempotenciaExitosa
        ON dbo.bf_CargaCadenaWsDetalle
           (CDIdEmpresa, CDHashRegistro, CDCodigoMovimiento)
        WHERE CDEstado = 'EXITOSO';
END;
GO

DECLARE @Faltantes TABLE (Objeto SYSNAME, Columna SYSNAME);

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_CargaCadenaWsLote', V.Columna
FROM (VALUES
    (N'CLId'), (N'CLIdEmpresa'), (N'CLHashArchivo'), (N'CLNombreArchivo'),
    (N'CLNombreDeclarado'), (N'CLVersionLayout'), (N'CLEstado'), (N'CLModo'),
    (N'CLTotal'), (N'CLEjecutables'), (N'CLAdvertencias'),
    (N'CLErroresValidacion'), (N'CLProcesados'), (N'CLExitosos'),
    (N'CLErroresEjecucion'), (N'CLIdUsuario'), (N'CLIdTraza'),
    (N'CLMensaje'), (N'CLFechaAnalisis'), (N'CLFechaInicio'), (N'CLFechaFin')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_CargaCadenaWsLote', V.Columna) IS NULL;

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_CargaCadenaWsDetalle', V.Columna
FROM (VALUES
    (N'CDId'), (N'CDIdLote'), (N'CDIdEmpresa'), (N'CDNumeroRenglon'),
    (N'CDHashRegistro'), (N'CDIdentificadorProtegido'), (N'CDEmpresaExterna'),
    (N'CDCodigoMovimiento'), (N'CDTipoMovimiento'), (N'CDIdOperacion'),
    (N'CDIdPlantilla'), (N'CDProcedimiento'), (N'CDEstado'),
    (N'CDCodigoResultado'), (N'CDMensaje'), (N'CDParametrosJson'),
    (N'CDFechaProceso'), (N'CDFechaAdd')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_CargaCadenaWsDetalle', V.Columna) IS NULL;

INSERT @Faltantes (Objeto, Columna)
SELECT N'bf_CargaCadenaWsIdempotencia', V.Columna
FROM (VALUES
    (N'CIIdEmpresa'), (N'CIHashRegistro'), (N'CICodigoMovimiento'),
    (N'CIEstado'), (N'CIIdLote'), (N'CIIdDetalle'), (N'CIFechaActualizacion')
) V(Columna)
WHERE COL_LENGTH(N'dbo.bf_CargaCadenaWsIdempotencia', V.Columna) IS NULL;

IF EXISTS (SELECT 1 FROM @Faltantes)
BEGIN
    SELECT 'COLUMNAS_REQUERIDAS_FALTANTES' AS bloque, Objeto, Columna
    FROM @Faltantes ORDER BY Objeto, Columna;
    THROW 51950, 'Existe infraestructura CadenaWS con contrato incompatible.', 1;
END;
GO

SELECT
    'INFRAESTRUCTURA_CADENA_WS_FORD' AS bloque,
    O.nombre,
    CASE WHEN OBJECT_ID(N'dbo.' + O.nombre, N'U') IS NOT NULL THEN 'OK' ELSE 'FALTA' END AS resultado
FROM (VALUES
    ('bf_CargaCadenaWsLote'),
    ('bf_CargaCadenaWsDetalle'),
    ('bf_CargaCadenaWsIdempotencia')
) O(nombre);
GO
