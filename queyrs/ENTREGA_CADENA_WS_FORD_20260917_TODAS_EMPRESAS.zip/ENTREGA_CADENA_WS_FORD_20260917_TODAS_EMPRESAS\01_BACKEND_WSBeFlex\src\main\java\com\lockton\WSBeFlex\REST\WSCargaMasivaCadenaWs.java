package com.lockton.WSBeFlex.REST;

import com.lockton.WSBeFlex.Services.CadenaWs.CargaMasivaCadenaWsService;
import com.lockton.WSBeFlex.Services.CargaMasivaFlujoService;
import com.lockton.WSBeFlex.Services.GeneralesService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.UsuarioToken;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/** API del tercer origen de carga: archivo plano recibido por CadenaWS Ford. */
@RestController
@RequestMapping("beflex/carga-masiva/cadena-ws")
public class WSCargaMasivaCadenaWs {
    private static final Log LOG = LogFactory.getLog(WSCargaMasivaCadenaWs.class);
    private final CargaMasivaCadenaWsService service;
    private final CargaMasivaFlujoService flujoService;
    private final GeneralesService generalesService;
    private final JwtService jwtService;

    public WSCargaMasivaCadenaWs(CargaMasivaCadenaWsService service,
                                 CargaMasivaFlujoService flujoService,
                                 GeneralesService generalesService,
                                 JwtService jwtService) {
        this.service = service;
        this.flujoService = flujoService;
        this.generalesService = generalesService;
        this.jwtService = jwtService;
    }

    @PostMapping(value = "/analizar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> analizar(
            @RequestParam int idEmpresa,
            @RequestParam("archivo") MultipartFile archivo,
            @RequestHeader(value = "authorization", required = false) String token,
            HttpServletRequest request) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!flujoService.tieneAccesoEmpresa(usuario.n, idEmpresa)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        String idTraza = idTraza(request);
        try {
            return ResponseEntity.ok(service.analizar(idEmpresa, archivo, usuario.n, idTraza));
        } catch (IllegalArgumentException e) {
            return error(HttpStatus.BAD_REQUEST, idTraza, "ANALISIS_VALIDACION", e.getMessage());
        } catch (Exception e) {
            LOG.error("Fallo al analizar CadenaWS. Traza=" + idTraza, e);
            return error(HttpStatus.CONFLICT, idTraza, "ANALISIS_SERVIDOR",
                    "El archivo no pudo analizarse. Consulte el log del WS con el identificador de traza.");
        }
    }

    @PostMapping(value = "/ejecutar", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> ejecutar(
            @RequestBody Map<String, Object> solicitud,
            @RequestHeader(value = "authorization", required = false) String token,
            HttpServletRequest request) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        String idTraza = idTraza(request);
        try {
            UUID idLote = uuid(solicitud.get("idAnalisis"));
            Map<String, Object> lote = service.obtenerLotePropio(idLote, usuario.n);
            if (!flujoService.tieneAccesoEmpresa(usuario.n, numero(lote.get("idEmpresa")))) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            }
            Map<String, Object> respuesta = service.ejecutar(idLote,
                    texto(solicitud.get("modo"), "CONTINUAR"), usuario.n, idTraza);
            return new ResponseEntity<>(respuesta, HttpStatus.ACCEPTED);
        } catch (SecurityException e) {
            return error(HttpStatus.FORBIDDEN, idTraza, "AUTORIZACION", e.getMessage());
        } catch (IllegalArgumentException e) {
            return error(HttpStatus.BAD_REQUEST, idTraza, "EJECUCION_VALIDACION", e.getMessage());
        } catch (Exception e) {
            LOG.error("Fallo al iniciar CadenaWS. Traza=" + idTraza, e);
            return error(HttpStatus.CONFLICT, idTraza, "EJECUCION_SERVIDOR",
                    "El lote no pudo iniciarse. Consulte el log del WS con el identificador de traza.");
        }
    }

    @GetMapping("/lotes/{idLote}")
    public ResponseEntity<Map<String, Object>> consultar(
            @PathVariable String idLote,
            @RequestHeader(value = "authorization", required = false) String token,
            HttpServletRequest request) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        String idTraza = idTraza(request);
        try {
            UUID id = uuid(idLote);
            Map<String, Object> lote = service.obtenerLotePropio(id, usuario.n);
            if (!flujoService.tieneAccesoEmpresa(usuario.n, numero(lote.get("idEmpresa")))) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            }
            return ResponseEntity.ok(service.consultar(id, usuario.n));
        } catch (SecurityException e) {
            return error(HttpStatus.FORBIDDEN, idTraza, "AUTORIZACION", e.getMessage());
        } catch (IllegalArgumentException e) {
            return error(HttpStatus.BAD_REQUEST, idTraza, "CONSULTA_VALIDACION", e.getMessage());
        } catch (Exception e) {
            LOG.error("Fallo al consultar CadenaWS. Traza=" + idTraza, e);
            return error(HttpStatus.CONFLICT, idTraza, "CONSULTA_SERVIDOR",
                    "No fue posible consultar el lote.");
        }
    }

    @GetMapping(value = "/lotes/{idLote}/detalle", produces = "text/csv")
    public ResponseEntity<byte[]> descargar(
            @PathVariable String idLote,
            @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        try {
            UUID id = uuid(idLote);
            Map<String, Object> lote = service.obtenerLotePropio(id, usuario.n);
            if (!flujoService.tieneAccesoEmpresa(usuario.n, numero(lote.get("idEmpresa")))) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            }
            byte[] contenido = csv(service.detalleDescarga(id, usuario.n));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(new MediaType("text", "csv", StandardCharsets.UTF_8));
            headers.setContentDisposition(ContentDisposition.attachment()
                    .filename("resultado-cadena-ws-" + id + ".csv", StandardCharsets.UTF_8).build());
            return new ResponseEntity<>(contenido, headers, HttpStatus.OK);
        } catch (SecurityException e) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    private byte[] csv(List<Map<String, Object>> detalles) {
        StringBuilder salida = new StringBuilder("\uFEFFRenglon,Identificador,Empresa externa,Codigo movimiento,Tipo movimiento,Estado,Codigo resultado,Mensaje\r\n");
        for (Map<String, Object> fila : detalles) {
            salida.append(celda(fila.get("renglon"))).append(',')
                    .append(celda(fila.get("identificador"))).append(',')
                    .append(celda(fila.get("empresaExterna"))).append(',')
                    .append(celda(fila.get("codigoMovimiento"))).append(',')
                    .append(celda(fila.get("tipoMovimiento"))).append(',')
                    .append(celda(fila.get("estado"))).append(',')
                    .append(celda(fila.get("codigoResultado"))).append(',')
                    .append(celda(fila.get("mensaje"))).append("\r\n");
        }
        return salida.toString().getBytes(StandardCharsets.UTF_8);
    }

    private String celda(Object valor) {
        String texto = valor == null ? "" : String.valueOf(valor);
        if (!texto.isEmpty() && "=+-@".indexOf(texto.charAt(0)) >= 0) texto = "'" + texto;
        return "\"" + texto.replace("\"", "\"\"") + "\"";
    }

    private UsuarioToken usuarioAutenticado(String token) {
        try {
            if (token == null || !generalesService.validarTokenId(0, token, 4)) return null;
            UsuarioToken usuario = jwtService.getPayloadFromToken(token);
            return usuario != null && usuario.n > 0 ? usuario : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String idTraza(HttpServletRequest request) {
        String id = request.getHeader("X-Correlation-ID");
        return id != null && id.matches("[A-Za-z0-9._-]{8,100}") ? id : UUID.randomUUID().toString();
    }

    private UUID uuid(Object valor) {
        try { return UUID.fromString(valor == null ? "" : String.valueOf(valor)); }
        catch (IllegalArgumentException e) { throw new IllegalArgumentException("El identificador del analisis no es valido."); }
    }

    private int numero(Object valor) {
        if (valor instanceof Number) return ((Number) valor).intValue();
        try { return valor == null ? 0 : Integer.parseInt(String.valueOf(valor)); }
        catch (NumberFormatException e) { return 0; }
    }

    private String texto(Object valor, String defecto) {
        return valor == null ? defecto : String.valueOf(valor);
    }

    private ResponseEntity<Map<String, Object>> error(HttpStatus estado, String idTraza,
                                                       String etapa, String mensaje) {
        Map<String, Object> cuerpo = new LinkedHashMap<>();
        cuerpo.put("idTraza", idTraza);
        cuerpo.put("resultado", "ERROR");
        cuerpo.put("etapa", etapa);
        cuerpo.put("mensaje", mensaje);
        return new ResponseEntity<>(cuerpo, estado);
    }
}
