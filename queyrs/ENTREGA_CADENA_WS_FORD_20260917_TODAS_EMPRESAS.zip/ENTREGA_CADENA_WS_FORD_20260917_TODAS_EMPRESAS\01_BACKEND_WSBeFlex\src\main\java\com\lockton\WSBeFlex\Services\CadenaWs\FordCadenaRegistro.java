package com.lockton.WSBeFlex.Services.CadenaWs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Un detalle 02 del archivo Ford, sin exponer la cadena completa en logs. */
public final class FordCadenaRegistro {
    private static final String[] CAMPOS = {
        "EMArchivoInformacion", "EMEmpresa", "EMIdSexo", "EMColoniaFisico",
        "EMNumeroEmpleado", "EMApellidoPaterno", "EMApellidoMaterno", "EMNombre1",
        "EMFechaNacimiento", "EMFechaIngresoEmpresa", "EMFechaAlta", "EMFechaBaja",
        "EMOficina_text", "EMCentroCostos_text", "EMrfc", "EMSalarioBase",
        "EMCorreoElectronico", "EMCalleFiscal", "EMColoniaFiscal",
        "EMMunicipioDelegacionFiscal", "EMEstadoFisical_text", "EMCodigoPostalFiscal",
        "EMArea_text", "EMPuestoDescripcion", "Desarrollo", "EMcurp", "EMnss",
        "EMCalleFisico", "EMFechaAntiguedadPP"
    };

    private final int renglon;
    private final List<String> posiciones;
    private final String hash;

    FordCadenaRegistro(int renglon, List<String> posiciones, String hash) {
        this.renglon = renglon;
        this.posiciones = Collections.unmodifiableList(new ArrayList<>(posiciones));
        this.hash = hash;
    }

    public int getRenglon() { return renglon; }
    public int getNumeroPosiciones() { return posiciones.size(); }
    public String getHash() { return hash; }
    public String getEmpresaExterna() { return posicion(2); }
    public String getSexo() { return posicion(3); }
    public String getEstatus() { return posicion(4); }
    public String getNumeroEmpleado() { return posicion(5); }
    public String getFechaNacimiento() { return posicion(9); }
    public String getFechaIngreso() { return posicion(10); }
    public String getFechaMovimiento() { return posicion(11); }
    public String getFechaBaja() { return posicion(12); }
    public String getOficina() { return posicion(13); }
    public String getSalario() { return posicion(16); }
    public String getCorreo() { return posicion(17); }
    public String getCodigoMovimiento() { return posicion(23).toUpperCase(); }
    public String getNss() { return posicion(27); }
    public String getClaseEmpleado() { return posicion(28); }
    public String getFechaAntiguedadPp() { return posicion(29); }

    public String posicion(int numero) {
        int indice = numero - 1;
        return indice >= 0 && indice < posiciones.size() ? posiciones.get(indice).trim() : "";
    }

    public Map<String, String> parametrosPlantilla() {
        Map<String, String> parametros = new LinkedHashMap<>();
        for (int i = 0; i < CAMPOS.length; i++) {
            parametros.put(CAMPOS[i], i < posiciones.size() ? posiciones.get(i).trim() : "");
        }
        return parametros;
    }
}
