# Resumen de la actualización

## Pantalla

La opción **Archivo posicional Ford (01 / 02 / 03)** aparece en el selector **Origen para esta ejecución** para cualquier empresa de sesión.

Al seleccionarla, la pantalla:

1. Oculta el selector de templates/operaciones genéricas.
2. Explica la estructura 01/02/03 y cómo se determina la empresa destino.
3. Permite seleccionar y analizar el archivo sin modificar empleados.
4. Habilita la ejecución sólo después de un análisis válido.

## Backend

La petición continúa validando que el usuario tenga acceso a la empresa enviada por la pantalla. Esa empresa identifica el contexto y la auditoría del lote, pero no cambia el motor Ford.

La ejecución permanece fijada a:

- Empresa de configuración: `517`.
- Operación: `2`.
- Plantilla: `3748`.
- Procedimiento: `ff_XCMTitularesAltaCMFORD`.

El destino funcional se resuelve a partir de la clave externa incluida en cada detalle del archivo. La idempotencia se mantiene global para el proceso Ford.

No hay cambios para APIReports ni cambios adicionales de base de datos respecto de la entrega anterior.
