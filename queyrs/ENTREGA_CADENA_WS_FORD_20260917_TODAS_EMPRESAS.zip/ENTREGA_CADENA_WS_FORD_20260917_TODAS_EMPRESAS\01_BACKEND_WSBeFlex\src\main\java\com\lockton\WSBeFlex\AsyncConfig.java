package com.lockton.WSBeFlex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * CREA 06 - Habilita ejecucion asincrona y define el pool dedicado para el
 * defaulteo avanzado, para que el lote corra en background y el request HTTP
 * responda de inmediato (evita el timeout del gateway de QA).
 */
@Configuration
@EnableAsync
public class AsyncConfig {

    @Bean(name = "defaulteoExecutor")
    public Executor defaulteoExecutor() {
        ThreadPoolTaskExecutor ex = new ThreadPoolTaskExecutor();
        ex.setCorePoolSize(2);
        ex.setMaxPoolSize(4);
        ex.setQueueCapacity(50);
        ex.setThreadNamePrefix("defaulteo-");
        // Si el pool esta lleno, ejecuta en el hilo que llama (no se pierde el lote)
        ex.setRejectedExecutionHandler(new java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy());
        ex.initialize();
        return ex;
    }

    /** Pool acotado para cargas Ford; evita competir con los lotes de defaulteo. */
    @Bean(name = "cadenaWsExecutor")
    public Executor cadenaWsExecutor() {
        ThreadPoolTaskExecutor ex = new ThreadPoolTaskExecutor();
        ex.setCorePoolSize(1);
        ex.setMaxPoolSize(2);
        ex.setQueueCapacity(20);
        ex.setThreadNamePrefix("cadena-ws-");
        ex.setRejectedExecutionHandler(new java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy());
        ex.initialize();
        return ex;
    }
}
