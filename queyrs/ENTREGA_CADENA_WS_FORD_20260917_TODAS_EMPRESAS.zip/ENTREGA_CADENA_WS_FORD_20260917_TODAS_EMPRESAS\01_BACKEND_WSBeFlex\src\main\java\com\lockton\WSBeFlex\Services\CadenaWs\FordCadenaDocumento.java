package com.lockton.WSBeFlex.Services.CadenaWs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Documento Ford ya validado estructuralmente. */
public final class FordCadenaDocumento {
    private final String nombreDeclarado;
    private final String versionLayout;
    private final String hashArchivo;
    private final List<FordCadenaRegistro> registros;

    FordCadenaDocumento(String nombreDeclarado, String versionLayout,
                        String hashArchivo, List<FordCadenaRegistro> registros) {
        this.nombreDeclarado = nombreDeclarado;
        this.versionLayout = versionLayout;
        this.hashArchivo = hashArchivo;
        this.registros = Collections.unmodifiableList(new ArrayList<>(registros));
    }

    public String getNombreDeclarado() { return nombreDeclarado; }
    public String getVersionLayout() { return versionLayout; }
    public String getHashArchivo() { return hashArchivo; }
    public List<FordCadenaRegistro> getRegistros() { return registros; }
}
