# Entrega Archivo posicional Ford para todas las empresas

El paquete conserva las rutas relativas de ambos repositorios. No contiene `target`, `dist`, `node_modules`, resultados de diagnóstico ni datos reales de empleados.

## Cambio de esta versión

La opción de pantalla ahora se llama **Archivo posicional Ford (01 / 02 / 03)** y se muestra desde cualquier empresa a la que el usuario tenga acceso.

- La empresa de la sesión se conserva como contexto de autorización y auditoría.
- El servidor continúa ejecutando el contrato Ford comprobado: empresa de configuración `517`, operación `2`, plantilla `3748` y `ff_XCMTitularesAltaCMFORD`.
- Las claves externas de cada detalle (`109`/`137`) determinan la empresa Ford destino.
- La idempotencia permanece unificada bajo la configuración Ford `517`, evitando repetir el mismo movimiento desde sesiones de empresas diferentes.
- APIReports no requiere cambios.

## 1. Backend

Copiar **el contenido** de `01_BACKEND_WSBeFlex` sobre la raíz del repositorio backend `WSBeFlex-EmpAdm-defaulteoCargaMaisva`.

Si `database/009_infraestructura_cadena_ws_ford.sql` todavía no fue aplicado en ese ambiente, ejecutarlo una vez en la base BeFlex. Esta versión no agrega cambios nuevos al esquema respecto del ZIP anterior.

## 2. Frontend

Copiar **el contenido** de `02_FRONTEND_BeFlex3` sobre la raíz del repositorio frontend `BeFlex3-EmpAdm-defaulteoCargaMaisva`.

Después de compilar y desplegar, realizar una recarga forzada del navegador (`Ctrl+F5`). En **Carga masiva de poblaciones**, el selector **Origen para esta ejecución** debe mostrar **Archivo posicional Ford (01 / 02 / 03)** sin importar la empresa seleccionada.

## 3. Material de prueba DEV/QA

Estas carpetas no se copian a los repositorios:

- `03_CADENAS_PRUEBA`: nueve archivos posicionales, con siete registros dummy por evento.
- `04_TXT_CARGA_MASIVA_B2`: nueve TXT para los templates activos del flujo B2.

Leer primero los README y ejecutar las prevalidaciones de sólo lectura. No utilizar los archivos en producción ni ejecutar dos etapas simultáneamente.

## 4. Validación realizada

- Compilación Java aislada de los componentes modificados: correcta.
- `CargaMasivaCadenaWsServiceTest`: 2 pruebas correctas; incluye empresa de contexto `999` y verifica ejecución sobre contrato `517/2/3748`.
- `FordCadenaParserTest`: 4 pruebas correctas.
- `CargaMasivaB2ServiceTest`: 5 pruebas correctas.
- `CargaMasivaTxtParserTest`: 5 pruebas correctas.
- Total backend: 16 pruebas, 0 fallos y 0 errores.
- TypeScript del frontend (`tsc --noEmit`): correcto.

## 5. Archivos de código incluidos

### Backend

- `database/009_infraestructura_cadena_ws_ford.sql`
- `src/main/java/com/lockton/WSBeFlex/AsyncConfig.java`
- `src/main/java/com/lockton/WSBeFlex/DAO/CargaCadenaWsDAO.java`
- `src/main/java/com/lockton/WSBeFlex/REST/WSCargaMasivaCadenaWs.java`
- `src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaOperacionExecutor.java`
- `src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2Service.java`
- `src/main/java/com/lockton/WSBeFlex/Services/CadenaWs/*`
- `src/test/java/com/lockton/WSBeFlex/Services/CadenaWs/FordCadenaParserTest.java`
- `src/test/java/com/lockton/WSBeFlex/Services/CadenaWs/CargaMasivaCadenaWsServiceTest.java`
- `src/test/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2ServiceTest.java`

### Frontend

- `src/app/beflex/cargamasivaadm/cargamasivaadm.component.html`
- `src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts`
- `src/app/services/titulares.service.ts`

## 6. Comandos Git para actualizar una rama que ya contiene la entrega anterior

### Backend

```powershell
cd C:\RUTA\WSBeFlex-EmpAdm-defaulteoCargaMaisva
git status --short
git switch feat/cadena-ws-ford
git add src/main/java/com/lockton/WSBeFlex/Services/CadenaWs/CargaMasivaCadenaWsService.java src/main/java/com/lockton/WSBeFlex/Services/CadenaWs/CargaMasivaCadenaWsAsyncRunner.java src/test/java/com/lockton/WSBeFlex/Services/CadenaWs/CargaMasivaCadenaWsServiceTest.java
git diff --cached --check
git diff --cached --stat
git commit -m "fix: habilita archivo posicional Ford para todas las empresas"
git push
```

### Frontend

```powershell
cd C:\RUTA\BeFlex3-EmpAdm-defaulteoCargaMaisva
git status --short
git switch feat/cadena-ws-ford
git add src/app/beflex/cargamasivaadm/cargamasivaadm.component.html src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts
git diff --cached --check
git diff --cached --stat
git commit -m "fix: muestra origen posicional Ford para cualquier empresa"
git push
```

## 7. Comandos Git para una integración nueva

Si la entrega anterior aún no existe en el repositorio, copiar el paquete completo y usar los comandos siguientes.

### Backend

```powershell
cd C:\RUTA\WSBeFlex-EmpAdm-defaulteoCargaMaisva
git status --short
git switch -c feat/cadena-ws-ford
git add database/009_infraestructura_cadena_ws_ford.sql src/main/java/com/lockton/WSBeFlex/AsyncConfig.java src/main/java/com/lockton/WSBeFlex/DAO/CargaCadenaWsDAO.java src/main/java/com/lockton/WSBeFlex/REST/WSCargaMasivaCadenaWs.java src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaOperacionExecutor.java src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2Service.java src/main/java/com/lockton/WSBeFlex/Services/CadenaWs src/test/java/com/lockton/WSBeFlex/Services/CadenaWs src/test/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2ServiceTest.java
git diff --cached --check
git diff --cached --stat
git commit -m "feat: integra archivo posicional Ford en carga masiva"
git push -u origin feat/cadena-ws-ford
```

### Frontend

```powershell
cd C:\RUTA\BeFlex3-EmpAdm-defaulteoCargaMaisva
git status --short
git switch -c feat/cadena-ws-ford
git add src/app/beflex/cargamasivaadm/cargamasivaadm.component.html src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts src/app/services/titulares.service.ts
git diff --cached --check
git diff --cached --stat
git commit -m "feat: agrega origen posicional Ford a carga masiva"
git push -u origin feat/cadena-ws-ford
```
