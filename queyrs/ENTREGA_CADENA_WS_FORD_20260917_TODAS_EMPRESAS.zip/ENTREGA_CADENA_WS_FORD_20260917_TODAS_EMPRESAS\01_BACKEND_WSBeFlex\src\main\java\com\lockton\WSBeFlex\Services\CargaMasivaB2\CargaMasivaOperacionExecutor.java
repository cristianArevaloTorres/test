package com.lockton.WSBeFlex.Services.CargaMasivaB2;

import com.lockton.WSBeFlex.DAO.CargaMasivaB2DAO;
import com.lockton.WSBeFlex.DAO.FfCargaMasivaDAO;
import com.lockton.WSBeFlex.Services.Crypto.CryptoBeflexService;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;

/**
 * Ejecuta un registro contra la operacion/plantilla/SP configurados en BF2.
 * No conoce la gramatica del archivo de entrada; por eso puede ser reutilizado
 * por el TXT B2 y por adaptadores posicionales como Archivo/CadenaWS Ford.
 */
@Service
public class CargaMasivaOperacionExecutor {
    private static final DateTimeFormatter FECHA = DateTimeFormatter
            .ofPattern("dd/MM/uuuu", new Locale("es", "MX"))
            .withResolverStyle(ResolverStyle.STRICT);

    private final CargaMasivaB2DAO dao;
    private final CryptoBeflexService crypto;
    private final FfCargaMasivaDAO cargaMasivaLegacy;

    public CargaMasivaOperacionExecutor(CargaMasivaB2DAO dao,
                                        CryptoBeflexService crypto,
                                        FfCargaMasivaDAO cargaMasivaLegacy) {
        this.dao = dao;
        this.crypto = crypto;
        this.cargaMasivaLegacy = cargaMasivaLegacy;
    }

    public Preparacion preparar(int idEmpresa, int idOperacion) {
        Map<String, Object> operacion = dao.obtenerOperacion(idEmpresa, idOperacion);
        int idPlantilla = ((Number) operacion.get("CEIdPlantilla")).intValue();
        String procedimiento = String.valueOf(operacion.get("CEStoredProc")).trim();
        List<Map<String, Object>> campos = dao.obtenerCamposPlantilla(idPlantilla);
        if (campos.isEmpty()) {
            throw new IllegalArgumentException("La plantilla configurada no tiene campos activos.");
        }
        Map<String, Map<String, String>> rangos = cargarRangos(campos, idEmpresa);
        return new Preparacion(idEmpresa, idOperacion, idPlantilla, procedimiento,
                texto(valor(operacion, "CONombre"), "Operacion " + idOperacion).trim(),
                operacion, campos, rangos);
    }

    public Resultado ejecutarRegistro(Preparacion preparacion,
                                       Map<String, String> valores,
                                       int idUsuario,
                                       Contexto contexto) {
        if (preparacion == null) throw new IllegalArgumentException("La operacion no fue preparada.");
        if (contexto == null) contexto = Contexto.estandar();

        Map<String, Object> parametros = validarYConvertir(
                preparacion.campos, valores, preparacion.rangos, contexto, true);
        parametros.put("EMIdEmpresa", preparacion.idEmpresa);
        if (contexto.incluirUsuarioUmod) parametros.put("EMUsuarioUMod", idUsuario);
        parametros.putAll(contexto.parametrosAdicionales);
        completarCompatibilidad(preparacion.procedimiento, parametros);

        Map<String, Object> primeraFila;
        if (esTransferencia(preparacion.procedimiento)) {
            primeraFila = cargaMasivaLegacy.procesarTransferenciaMasiva(
                    normalizarFechas(parametros), preparacion.procedimiento);
        } else {
            Map<String, Object> salida = dao.ejecutarOperacion(preparacion.procedimiento, parametros);
            primeraFila = dao.primeraFila(salida);
        }
        return interpretar(preparacion.operacion, primeraFila);
    }

    /** Valida el contrato completo sin ejecutar el SP ni cifrar datos. */
    public void validarRegistro(Preparacion preparacion, Map<String, String> valores,
                                Contexto contexto) {
        if (preparacion == null) throw new IllegalArgumentException("La operacion no fue preparada.");
        if (contexto == null) contexto = Contexto.estandar();
        validarYConvertir(preparacion.campos, valores, preparacion.rangos, contexto, false);
    }

    private Map<String, Map<String, String>> cargarRangos(List<Map<String, Object>> campos,
                                                           int idEmpresa) {
        Map<String, Map<String, String>> rangos = new HashMap<>();
        for (Map<String, Object> campo : campos) {
            if ("Especifico".equalsIgnoreCase(texto(valor(campo, "CATipoValor"), ""))) {
                String nombre = requerido(campo, "CANombreCampo");
                rangos.put(nombre, dao.obtenerRango(requerido(campo, "CPRangoValores"), idEmpresa));
            }
        }
        return rangos;
    }

    private Map<String, Object> validarYConvertir(List<Map<String, Object>> campos,
                                                   Map<String, String> valores,
                                                   Map<String, Map<String, String>> rangos,
                                                   Contexto contexto,
                                                   boolean aplicarEncriptacion) {
        Map<String, Object> parametros = new LinkedHashMap<>();
        for (Map<String, Object> campo : campos) {
            String nombre = requerido(campo, "CANombreCampo");
            String dato = valores == null ? null : valores.get(nombre);
            boolean requerido = entero(valor(campo, "CPRequerido"), 0) == 1
                    && !contexto.requeridosOpcionales.contains(nombre);
            if (dato == null) {
                if (requerido) throw new IllegalArgumentException("Falta el campo " + nombre + ".");
                parametros.put(nombre, null);
                continue;
            }
            if (dato.isEmpty()) {
                if (requerido) throw new IllegalArgumentException("El campo " + nombre + " requiere un valor.");
                parametros.put(nombre, contexto.vaciosComoNull ? null : "");
                continue;
            }
            int longitud = entero(valor(campo, "CALongitud"), 0);
            if (longitud > 0 && dato.length() > longitud) {
                throw new IllegalArgumentException("El campo " + nombre + " excede la longitud maxima de "
                        + longitud + " caracteres.");
            }
            String regex = texto(valor(campo, "CACaracteresValidos"), "").trim();
            if (!regex.isEmpty() && !Pattern.compile(regex).matcher(dato).find()) {
                throw new IllegalArgumentException("El campo " + nombre + " no cumple el formato configurado.");
            }
            if ("Especifico".equalsIgnoreCase(texto(valor(campo, "CATipoValor"), ""))) {
                String equivalencia = equivalencia(rangos.get(nombre), dato);
                if (equivalencia == null) {
                    throw new IllegalArgumentException("El campo " + nombre
                            + " no tiene equivalencia para el valor recibido.");
                }
                dato = equivalencia;
            }
            String tipo = requerido(campo, "CATipoDato");
            if (aplicarEncriptacion && "T".equalsIgnoreCase(tipo)
                    && entero(valor(campo, "CPEncriptado"), 0) == 1) {
                dato = crypto.encriptar(dato);
                if (dato == null) throw new IllegalArgumentException("No fue posible encriptar " + nombre + ".");
            }
            parametros.put(nombre, convertir(tipo, dato, nombre));
        }
        return parametros;
    }

    private String equivalencia(Map<String, String> rango, String dato) {
        if (rango == null) return null;
        String directa = rango.get(dato);
        if (directa != null) return directa;
        for (Map.Entry<String, String> entry : rango.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(dato)) return entry.getValue();
        }
        return null;
    }

    private void completarCompatibilidad(String procedimiento, Map<String, Object> parametros) {
        String nombre = nombreProcedimiento(procedimiento);
        if ("ff_XCMTitularesAltaCMDeloitte".equalsIgnoreCase(nombre)) {
            parametros.putIfAbsent("EMPuesto2", "");
            parametros.putIfAbsent("EMPerfil", "");
        }
        if ("ff_XCMTitularesAltaCMFORD".equalsIgnoreCase(nombre)) {
            parametros.remove("EMUsuarioUMod");
            parametros.putIfAbsent("EMIdEstatus", 0);
            parametros.putIfAbsent("EMPerfil", "");
        }
    }

    private Resultado interpretar(Map<String, Object> operacion, Map<String, Object> fila) {
        if (fila == null || fila.isEmpty()) {
            return new Resultado(-1, -1, "El procedimiento no devolvio resultado.");
        }
        Object valorCodigo = dao.valor(fila, "Return_Code");
        String contrato = "Return_Code";
        if (valorCodigo == null) {
            valorCodigo = dao.valor(fila, "codigo");
            contrato = "codigo";
        }
        if (valorCodigo == null) {
            valorCodigo = dao.valor(fila, "code");
            contrato = "code";
        }
        int original;
        int normalizado;
        if (valorCodigo == null) {
            original = soporta(operacion, "Return_Code") ? -1 : 0;
            normalizado = original;
        } else {
            original = entero(valorCodigo, -1);
            boolean exito = "Return_Code".equals(contrato)
                    ? original == 0 : original == 1 || original == 200;
            normalizado = exito ? 0 : original == 0 ? -1 : original;
        }
        Object valorMensaje = dao.valor(fila, "Return_Msg");
        if (valorMensaje == null) valorMensaje = dao.valor(fila, "mensaje");
        if (valorMensaje == null) valorMensaje = dao.valor(fila, "msg");
        return new Resultado(normalizado, original, texto(valorMensaje,
                normalizado == 0 ? "Registro procesado correctamente."
                        : "El procedimiento no devolvio un mensaje de error."));
    }

    private Object convertir(String tipo, String dato, String nombre) {
        try {
            switch (tipo.charAt(0)) {
                case 'T': return dato;
                case 'E': case 'N': case 'B': return Integer.valueOf(dato.trim());
                case 'D': return Date.valueOf(LocalDate.parse(dato.trim(), FECHA));
                case 'M': case '%': case 'F': return new BigDecimal(dato.trim().replace(',', '.'));
                default: throw new IllegalArgumentException("Tipo no reconocido: " + tipo + ".");
            }
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("El campo " + nombre + " no es valido para el tipo " + tipo + ".");
        }
    }

    private Map<String, Object> normalizarFechas(Map<String, Object> parametros) {
        Map<String, Object> salida = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : parametros.entrySet()) {
            Object value = entry.getValue();
            salida.put(entry.getKey(), value instanceof Date ? value.toString() : value);
        }
        return salida;
    }

    private boolean esTransferencia(String procedimiento) {
        return "ff_transferenciaMasivaEmpleado".equalsIgnoreCase(nombreProcedimiento(procedimiento));
    }

    private String nombreProcedimiento(String procedimiento) {
        String limpio = procedimiento == null ? "" : procedimiento.trim().replace("[", "").replace("]", "");
        return limpio.toLowerCase(Locale.ROOT).startsWith("dbo.") ? limpio.substring(4) : limpio;
    }

    private boolean soporta(Map<String, Object> operacion, String propiedad) {
        Object dato = valor(operacion, propiedad);
        if (dato instanceof Boolean) return (Boolean) dato;
        if (dato instanceof Number) return ((Number) dato).intValue() != 0;
        return dato != null && ("true".equalsIgnoreCase(String.valueOf(dato))
                || "1".equals(String.valueOf(dato)));
    }

    private Object valor(Map<String, Object> mapa, String nombre) {
        if (mapa == null) return null;
        for (Map.Entry<String, Object> entry : mapa.entrySet()) {
            if (nombre.equalsIgnoreCase(entry.getKey())) return entry.getValue();
        }
        return null;
    }

    private String requerido(Map<String, Object> mapa, String nombre) {
        Object dato = valor(mapa, nombre);
        if (dato == null) throw new IllegalArgumentException("La configuracion no contiene " + nombre + ".");
        return String.valueOf(dato).trim();
    }

    private String texto(Object dato, String defecto) {
        return dato == null ? defecto : String.valueOf(dato);
    }

    private int entero(Object dato, int defecto) {
        if (dato instanceof Number) return ((Number) dato).intValue();
        try { return dato == null ? defecto : Integer.parseInt(String.valueOf(dato)); }
        catch (NumberFormatException e) { return defecto; }
    }

    public static final class Preparacion {
        private final int idEmpresa;
        private final int idOperacion;
        private final int idPlantilla;
        private final String procedimiento;
        private final String nombreOperacion;
        private final Map<String, Object> operacion;
        private final List<Map<String, Object>> campos;
        private final Map<String, Map<String, String>> rangos;

        private Preparacion(int idEmpresa, int idOperacion, int idPlantilla,
                            String procedimiento, String nombreOperacion,
                            Map<String, Object> operacion, List<Map<String, Object>> campos,
                            Map<String, Map<String, String>> rangos) {
            this.idEmpresa = idEmpresa;
            this.idOperacion = idOperacion;
            this.idPlantilla = idPlantilla;
            this.procedimiento = procedimiento;
            this.nombreOperacion = nombreOperacion;
            this.operacion = new LinkedHashMap<>(operacion);
            this.campos = Collections.unmodifiableList(new ArrayList<>(campos));
            this.rangos = Collections.unmodifiableMap(new LinkedHashMap<>(rangos));
        }

        public int getIdEmpresa() { return idEmpresa; }
        public int getIdOperacion() { return idOperacion; }
        public int getIdPlantilla() { return idPlantilla; }
        public String getProcedimiento() { return procedimiento; }
        public String getNombreOperacion() { return nombreOperacion; }
        public List<Map<String, Object>> getCampos() { return campos; }
        public Map<String, Object> getOperacion() { return new LinkedHashMap<>(operacion); }
    }

    public static final class Contexto {
        private boolean incluirUsuarioUmod = true;
        private boolean vaciosComoNull;
        private final Set<String> requeridosOpcionales = new LinkedHashSet<>();
        private final Map<String, Object> parametrosAdicionales = new LinkedHashMap<>();

        public static Contexto estandar() { return new Contexto(); }

        public static Contexto ford() {
            Contexto contexto = new Contexto();
            contexto.incluirUsuarioUmod = false;
            contexto.vaciosComoNull = true;
            contexto.requeridosOpcionales.add("EMFechaAntiguedadPP");
            contexto.parametrosAdicionales.put("EMIdEstatus", 0);
            contexto.parametrosAdicionales.put("EMPerfil", "");
            return contexto;
        }

        public Contexto incluirUsuarioUmod(boolean incluir) {
            this.incluirUsuarioUmod = incluir;
            return this;
        }

        public Contexto vaciosComoNull(boolean comoNull) {
            this.vaciosComoNull = comoNull;
            return this;
        }

        public Contexto permitirRequeridoVacio(String campo) {
            this.requeridosOpcionales.add(campo);
            return this;
        }

        public Contexto parametro(String nombre, Object dato) {
            this.parametrosAdicionales.put(nombre, dato);
            return this;
        }
    }

    public static final class Resultado {
        private final int codigo;
        private final int codigoSp;
        private final String mensaje;

        private Resultado(int codigo, int codigoSp, String mensaje) {
            this.codigo = codigo;
            this.codigoSp = codigoSp;
            this.mensaje = mensaje;
        }

        public int getCodigo() { return codigo; }
        public int getCodigoSp() { return codigoSp; }
        public String getMensaje() { return mensaje; }
        public boolean esExitoso() { return codigo == 0; }
    }
}
