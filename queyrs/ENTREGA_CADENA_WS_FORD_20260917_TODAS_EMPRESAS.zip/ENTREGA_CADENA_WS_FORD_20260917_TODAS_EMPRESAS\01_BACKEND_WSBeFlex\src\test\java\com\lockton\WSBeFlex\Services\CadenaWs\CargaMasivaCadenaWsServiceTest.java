package com.lockton.WSBeFlex.Services.CadenaWs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.DAO.CargaCadenaWsDAO;
import com.lockton.WSBeFlex.Services.CargaMasivaB2.CargaMasivaOperacionExecutor;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class CargaMasivaCadenaWsServiceTest {

    @Test
    void permiteAnalizarDesdeCualquierEmpresaAutorizadaSinCambiarElContratoFord() throws Exception {
        FordCadenaParser parser = mock(FordCadenaParser.class);
        CargaCadenaWsDAO dao = mock(CargaCadenaWsDAO.class);
        CargaMasivaOperacionExecutor executor = mock(CargaMasivaOperacionExecutor.class);
        CargaMasivaCadenaWsAsyncRunner asyncRunner = mock(CargaMasivaCadenaWsAsyncRunner.class);
        CargaMasivaCadenaWsService service = new CargaMasivaCadenaWsService(
                parser, dao, executor, asyncRunner, new ObjectMapper());

        FordCadenaRegistro registro = new FordCadenaRegistro(2, posicionesValidas(), "hash-registro");
        FordCadenaDocumento documento = new FordCadenaDocumento(
                "FORD.TXT", "FORD_29", "hash-archivo", Collections.singletonList(registro));
        CargaMasivaOperacionExecutor.Preparacion preparacion = preparacionFord();

        when(parser.parse(any(byte[].class))).thenReturn(documento);
        when(executor.preparar(517, 2)).thenReturn(preparacion);
        when(dao.resolverEmpresasExternas(anySet())).thenReturn(Collections.singletonMap("109", 517));
        when(dao.buscarEmpleadosFord(anySet())).thenReturn(Collections.emptyMap());
        when(dao.buscarMovimientosExitosos(eq(517), anySet())).thenReturn(Collections.emptySet());

        Map<String, Object> respuesta = service.analizar(999,
                new MockMultipartFile("archivo", "ford.txt", "text/plain", "contenido".getBytes()),
                77, "trace-1234");

        assertEquals(999, respuesta.get("empresaContexto"));
        assertEquals(517, respuesta.get("empresaConfiguracion"));
        assertEquals(1, respuesta.get("ejecutables"));
        verify(executor).preparar(517, 2);
        verify(dao).buscarMovimientosExitosos(eq(517), anySet());
        verify(dao).crearLote(any(UUID.class), eq(999), eq("hash-archivo"), eq("ford.txt"),
                eq("FORD.TXT"), eq("FORD_29"), eq(1), eq(1), eq(0), eq(0),
                eq(77), eq("trace-1234"));
        verify(dao).insertarDetalle(any(UUID.class), eq(517), eq(2), eq("hash-registro"),
                anyString(), eq("109"), eq("HIR"), eq("ALTA"), eq(2), eq(3748),
                eq("ff_XCMTitularesAltaCMFORD"), eq("VALIDO"), anyString(), anyString());
    }

    @Test
    void rechazaEmpresaDeContextoNoValida() {
        FordCadenaParser parser = mock(FordCadenaParser.class);
        CargaCadenaWsDAO dao = mock(CargaCadenaWsDAO.class);
        CargaMasivaOperacionExecutor executor = mock(CargaMasivaOperacionExecutor.class);
        CargaMasivaCadenaWsAsyncRunner asyncRunner = mock(CargaMasivaCadenaWsAsyncRunner.class);
        CargaMasivaCadenaWsService service = new CargaMasivaCadenaWsService(
                parser, dao, executor, asyncRunner, new ObjectMapper());

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> service.analizar(0,
                        new MockMultipartFile("archivo", "ford.txt", "text/plain", "x".getBytes()),
                        77, "trace-1234"));

        assertEquals("La empresa de contexto no es valida.", error.getMessage());
        verify(executor, never()).preparar(anyInt(), anyInt());
    }

    private CargaMasivaOperacionExecutor.Preparacion preparacionFord() throws Exception {
        Constructor<CargaMasivaOperacionExecutor.Preparacion> constructor =
                CargaMasivaOperacionExecutor.Preparacion.class.getDeclaredConstructor(
                        int.class, int.class, int.class, String.class, String.class,
                        Map.class, List.class, Map.class);
        constructor.setAccessible(true);
        return constructor.newInstance(517, 2, 3748, "ff_XCMTitularesAltaCMFORD",
                "Alta de Titulares FORD", new LinkedHashMap<>(),
                new ArrayList<>(), new LinkedHashMap<>());
    }

    private List<String> posicionesValidas() {
        List<String> posiciones = new ArrayList<>(Collections.nCopies(29, ""));
        posiciones.set(0, "FORD");
        posiciones.set(1, "109");
        posiciones.set(2, "M");
        posiciones.set(3, "A");
        posiciones.set(4, "QA9990001");
        posiciones.set(5, "PRUEBA");
        posiciones.set(6, "GENERAL");
        posiciones.set(7, "USUARIO");
        posiciones.set(8, "01/01/1990");
        posiciones.set(9, "01/01/2020");
        posiciones.set(10, "01/09/2026");
        posiciones.set(12, "MEX11");
        posiciones.set(13, "QA");
        posiciones.set(14, "TEST900101AA1");
        posiciones.set(15, "1000.00");
        posiciones.set(16, "qa9990001@example.com");
        posiciones.set(22, "HIR");
        posiciones.set(25, "TEST900101HDFABC01");
        posiciones.set(26, "12345678901");
        posiciones.set(27, "EMPLEADO");
        posiciones.set(28, "01/01/2020");
        return posiciones;
    }
}
