package com.lockton.WSBeFlex.Services.CadenaWs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.DAO.CargaCadenaWsDAO;
import com.lockton.WSBeFlex.Services.CargaMasivaB2.CargaMasivaOperacionExecutor;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

/** Caso de uso de analisis y ejecucion del archivo posicional Ford/CadenaWS. */
@Service
public class CargaMasivaCadenaWsService {
    public static final int EMPRESA_FORD = 517;
    public static final int OPERACION_FORD = 2;
    public static final int PLANTILLA_FORD = 3748;
    public static final String SP_FORD = "ff_XCMTitularesAltaCMFORD";
    private static final int PREVIA_MAXIMA = 500;
    private static final Set<String> EVENTOS = Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(
            "HIR", "REH", "TER", "XFR", "PAY", "POS", "PRO", "DEM", "DTA")));
    private static final Set<String> SEXOS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "M", "F", "MASCULINO", "FEMENINO", "MALE", "FEMALE", "1", "2")));
    private static final DateTimeFormatter FECHA = DateTimeFormatter
            .ofPattern("dd/MM/uuuu", new Locale("es", "MX"))
            .withResolverStyle(ResolverStyle.STRICT);

    private final FordCadenaParser parser;
    private final CargaCadenaWsDAO dao;
    private final CargaMasivaOperacionExecutor executor;
    private final CargaMasivaCadenaWsAsyncRunner asyncRunner;
    private final ObjectMapper objectMapper;

    public CargaMasivaCadenaWsService(FordCadenaParser parser,
                                      CargaCadenaWsDAO dao,
                                      CargaMasivaOperacionExecutor executor,
                                      CargaMasivaCadenaWsAsyncRunner asyncRunner,
                                      ObjectMapper objectMapper) {
        this.parser = parser;
        this.dao = dao;
        this.executor = executor;
        this.asyncRunner = asyncRunner;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public Map<String, Object> analizar(int idEmpresa, MultipartFile archivo,
                                        int idUsuario, String idTraza) throws Exception {
        validarEmpresaContexto(idEmpresa);
        if (archivo == null || archivo.isEmpty()) {
            throw new IllegalArgumentException("Seleccione un archivo de cadena Ford.");
        }
        CargaMasivaOperacionExecutor.Preparacion preparacion = prepararContratoFord();
        FordCadenaDocumento documento = parser.parse(archivo.getBytes());
        dao.limpiarAnalisisExpirados();

        Set<String> empresasExternas = new LinkedHashSet<>();
        Set<String> empleados = new LinkedHashSet<>();
        Set<String> hashes = new LinkedHashSet<>();
        for (FordCadenaRegistro registro : documento.getRegistros()) {
            empresasExternas.add(registro.getEmpresaExterna());
            empleados.add(normalizar(registro.getNumeroEmpleado()));
            hashes.add(registro.getHash());
        }
        Map<String, Integer> mapeoEmpresas = dao.resolverEmpresasExternas(empresasExternas);
        Map<String, Map<String, Object>> empleadosActuales = dao.buscarEmpleadosFord(empleados);
        // El acceso y la auditoria pertenecen a la empresa de la sesion, pero la
        // idempotencia es unica para el proceso Ford. Asi se evita reprocesar la
        // misma cadena al abrir la pantalla desde otra empresa autorizada.
        Set<String> movimientosExitosos = dao.buscarMovimientosExitosos(EMPRESA_FORD, hashes);

        List<RegistroAnalizado> analizados = new ArrayList<>();
        Set<String> llavesArchivo = new HashSet<>();
        int ejecutables = 0;
        int advertencias = 0;
        int errores = 0;
        Map<String, Integer> porEvento = new LinkedHashMap<>();
        for (FordCadenaRegistro registro : documento.getRegistros()) {
            RegistroAnalizado analizado = analizarRegistro(registro, documento.getVersionLayout(),
                    preparacion, mapeoEmpresas, empleadosActuales, llavesArchivo,
                    movimientosExitosos);
            analizados.add(analizado);
            porEvento.put(registro.getCodigoMovimiento(),
                    porEvento.getOrDefault(registro.getCodigoMovimiento(), 0) + 1);
            if (analizado.ejecutable) ejecutables++;
            if (analizado.advertencia) advertencias++;
            if (analizado.error) errores++;
        }

        UUID idLote = UUID.randomUUID();
        String nombreArchivo = nombreSeguro(archivo.getOriginalFilename());
        dao.crearLote(idLote, idEmpresa, documento.getHashArchivo(), nombreArchivo,
                documento.getNombreDeclarado(), documento.getVersionLayout(),
                analizados.size(), ejecutables, advertencias, errores, idUsuario, idTraza);
        for (RegistroAnalizado analizado : analizados) {
            FordCadenaRegistro registro = analizado.registro;
            dao.insertarDetalle(idLote, EMPRESA_FORD, registro.getRenglon(), registro.getHash(),
                    proteger(registro.getNumeroEmpleado()), registro.getEmpresaExterna(),
                    registro.getCodigoMovimiento(), analizado.tipoMovimiento,
                    OPERACION_FORD, preparacion.getIdPlantilla(), preparacion.getProcedimiento(),
                    analizado.estado, analizado.mensaje,
                    analizado.ejecutable ? serializar(registro.parametrosPlantilla()) : null);
        }

        Map<String, Object> respuesta = new LinkedHashMap<>();
        respuesta.put("idAnalisis", idLote.toString());
        respuesta.put("idTraza", idTraza);
        respuesta.put("estado", "ANALIZADO");
        respuesta.put("nombreArchivo", nombreArchivo);
        respuesta.put("nombreDeclarado", documento.getNombreDeclarado());
        respuesta.put("versionLayout", documento.getVersionLayout());
        respuesta.put("total", analizados.size());
        respuesta.put("ejecutables", ejecutables);
        respuesta.put("advertencias", advertencias);
        respuesta.put("erroresValidacion", errores);
        respuesta.put("porEvento", porEvento);
        respuesta.put("operacion", OPERACION_FORD);
        respuesta.put("plantilla", PLANTILLA_FORD);
        respuesta.put("procedimiento", SP_FORD);
        respuesta.put("empresaContexto", idEmpresa);
        respuesta.put("empresaConfiguracion", EMPRESA_FORD);
        respuesta.put("previaLimitada", analizados.size() > PREVIA_MAXIMA);
        respuesta.put("detalles", detallesRespuesta(analizados));
        respuesta.put("ejecucionAnterior", dao.ultimoLoteMismoArchivo(
                idEmpresa, documento.getHashArchivo(), idLote));
        return respuesta;
    }

    public Map<String, Object> ejecutar(UUID idLote, String modo, int idUsuario,
                                        String idTraza) {
        String modoNormalizado = normalizarModo(modo);
        Map<String, Object> lote = dao.obtenerLote(idLote);
        validarPropiedad(lote, idUsuario);
        int disponibles = dao.iniciarEjecucion(idLote, idUsuario, modoNormalizado, idTraza);
        if (disponibles == 0) {
            throw new IllegalArgumentException("El analisis no esta disponible para ejecutar o ya esta en proceso.");
        }
        asyncRunner.ejecutar(idLote, idUsuario, modoNormalizado);
        Map<String, Object> respuesta = dao.obtenerLote(idLote);
        respuesta.put("aceptados", disponibles);
        return respuesta;
    }

    public Map<String, Object> consultar(UUID idLote, int idUsuario) {
        Map<String, Object> lote = dao.obtenerLote(idLote);
        validarPropiedad(lote, idUsuario);
        Map<String, Object> respuesta = new LinkedHashMap<>(lote);
        respuesta.put("detalles", dao.listarDetalles(idLote, PREVIA_MAXIMA));
        respuesta.put("detallesLimitados", numero(lote.get("total")) > PREVIA_MAXIMA);
        return respuesta;
    }

    public List<Map<String, Object>> detalleDescarga(UUID idLote, int idUsuario) {
        validarPropiedad(dao.obtenerLote(idLote), idUsuario);
        return dao.listarDetallesDescarga(idLote);
    }

    public Map<String, Object> obtenerLotePropio(UUID idLote, int idUsuario) {
        Map<String, Object> lote = dao.obtenerLote(idLote);
        validarPropiedad(lote, idUsuario);
        return lote;
    }

    private CargaMasivaOperacionExecutor.Preparacion prepararContratoFord() {
        CargaMasivaOperacionExecutor.Preparacion preparacion = executor.preparar(
                EMPRESA_FORD, OPERACION_FORD);
        String procedimiento = preparacion.getProcedimiento().replace("[", "").replace("]", "");
        if (procedimiento.toLowerCase(Locale.ROOT).startsWith("dbo.")) {
            procedimiento = procedimiento.substring(4);
        }
        if (preparacion.getIdPlantilla() != PLANTILLA_FORD
                || !SP_FORD.equalsIgnoreCase(procedimiento)) {
            throw new IllegalStateException("La operacion Ford no apunta a la plantilla 3748 y al SP esperado.");
        }
        return preparacion;
    }

    private RegistroAnalizado analizarRegistro(FordCadenaRegistro registro, String version,
                                                CargaMasivaOperacionExecutor.Preparacion preparacion,
                                                Map<String, Integer> empresas,
                                                Map<String, Map<String, Object>> empleados,
                                                Set<String> llavesArchivo,
                                                Set<String> movimientosExitosos) {
        List<String> errores = new ArrayList<>();
        List<String> avisos = new ArrayList<>();
        String evento = registro.getCodigoMovimiento();
        String estatus = registro.getEstatus().toUpperCase(Locale.ROOT);
        validarRequerido(registro.getNumeroEmpleado(), "GPID/numero de empleado", 20, errores);
        validarRequerido(registro.posicion(6), "apellido paterno", 30, errores);
        validarRequerido(registro.posicion(8), "nombre", 70, errores);
        validarFecha(registro.getFechaNacimiento(), "fecha de nacimiento", true, errores);
        validarFecha(registro.getFechaIngreso(), "fecha de ingreso", true, errores);
        validarFecha(registro.getFechaMovimiento(), "fecha de movimiento", false, errores);
        validarFecha(registro.getFechaBaja(), "fecha de baja", "T".equals(estatus), errores);
        validarRequerido(registro.getOficina(), "oficina", 100, errores);
        validarDecimal(registro.getSalario(), "salario", errores);
        validarCorreo(registro.getCorreo(), errores);
        validarRequerido(registro.getNss(), "NSS", 15, errores);
        if (!registro.getNss().isEmpty() && !registro.getNss().matches("[0-9]+")) {
            errores.add("El NSS debe contener solo digitos.");
        }
        validarRequerido(registro.getClaseEmpleado(), "clase de empleado", 100, errores);
        validarFecha(registro.getFechaAntiguedadPp(), "fecha de antiguedad del plan de pensiones",
                false, errores);

        if (!EVENTOS.contains(evento)) errores.add("El codigo de movimiento no esta soportado.");
        if (!"A".equals(estatus) && !"T".equals(estatus)) {
            errores.add("El estatus debe ser A o T.");
        }
        if ("TER".equals(evento) && !"T".equals(estatus)) {
            errores.add("El movimiento TER requiere estatus T.");
        }
        if (!"TER".equals(evento) && "T".equals(estatus)) {
            errores.add("Solo el movimiento TER puede usar estatus T.");
        }
        if (!SEXOS.contains(registro.getSexo().toUpperCase(Locale.ROOT))) {
            errores.add("El sexo no tiene una equivalencia valida en el catalogo.");
        }
        try {
            executor.validarRegistro(preparacion, registro.parametrosPlantilla(),
                    CargaMasivaOperacionExecutor.Contexto.ford());
        } catch (IllegalArgumentException e) {
            errores.add(e.getMessage());
        }
        Integer empresaDestino = empresas.get(registro.getEmpresaExterna());
        if (empresaDestino == null) errores.add("La empresa externa no tiene mapeo activo Ford.");
        else if (empresaDestino < 0) errores.add("La empresa externa tiene un mapeo ambiguo.");

        String llave = registro.getHash() + "|" + evento;
        if (!llavesArchivo.add(llave)) {
            return new RegistroAnalizado(registro, "DUPLICADO", "DUPLICADO",
                    "El mismo movimiento aparece mas de una vez en el archivo.", false, false, true);
        }
        if (movimientosExitosos.contains(llave)) {
            return new RegistroAnalizado(registro, "DUPLICADO", "DUPLICADO",
                    "El movimiento ya fue procesado exitosamente.", false, false, true);
        }

        if ("FORD_28".equals(version)) {
            avisos.add("Layout historico de 28 posiciones; la antiguedad del plan de pensiones se enviara vacia.");
        }
        String tipoMovimiento = clasificar(registro, empresaDestino, empleados);
        if (!errores.isEmpty()) {
            return new RegistroAnalizado(registro, tipoMovimiento, "ERROR_VALIDACION",
                    unir(errores), false, false, true);
        }
        return new RegistroAnalizado(registro, tipoMovimiento, "VALIDO",
                avisos.isEmpty() ? "Registro listo para ejecutar." : unir(avisos),
                true, !avisos.isEmpty(), false);
    }

    private String clasificar(FordCadenaRegistro registro, Integer empresaDestino,
                              Map<String, Map<String, Object>> empleados) {
        if ("T".equalsIgnoreCase(registro.getEstatus())) return "BAJA";
        Map<String, Object> empleado = empleados.get(normalizar(registro.getNumeroEmpleado()));
        if (empleado == null) return "ALTA";
        if (numero(empleado.get("idEstatus")) != 1) return "REACTIVACION";
        if (empresaDestino != null && empresaDestino > 0
                && numero(empleado.get("idEmpresa")) != empresaDestino) return "CAMBIO_EMPRESA";
        return "ACTUALIZACION";
    }

    private List<Map<String, Object>> detallesRespuesta(List<RegistroAnalizado> analizados) {
        List<Map<String, Object>> detalles = new ArrayList<>();
        for (int i = 0; i < analizados.size() && i < PREVIA_MAXIMA; i++) {
            RegistroAnalizado a = analizados.get(i);
            Map<String, Object> fila = new LinkedHashMap<>();
            fila.put("renglon", a.registro.getRenglon());
            fila.put("identificador", proteger(a.registro.getNumeroEmpleado()));
            fila.put("empresaExterna", a.registro.getEmpresaExterna());
            fila.put("codigoMovimiento", a.registro.getCodigoMovimiento());
            fila.put("tipoMovimiento", a.tipoMovimiento);
            fila.put("estado", a.estado);
            fila.put("mensaje", a.mensaje);
            detalles.add(fila);
        }
        return detalles;
    }

    private void validarPropiedad(Map<String, Object> lote, int idUsuario) {
        if (lote == null) throw new IllegalArgumentException("El analisis solicitado no existe.");
        if (numero(lote.get("idUsuario")) != idUsuario) {
            throw new SecurityException("El analisis pertenece a otro usuario.");
        }
    }

    private void validarEmpresaContexto(int idEmpresa) {
        if (idEmpresa <= 0) {
            throw new IllegalArgumentException("La empresa de contexto no es valida.");
        }
    }

    private String normalizarModo(String modo) {
        String valor = modo == null ? "CONTINUAR" : modo.trim().toUpperCase(Locale.ROOT);
        if (!"CONTINUAR".equals(valor) && !"PRIMER_ERROR".equals(valor)) {
            throw new IllegalArgumentException("El modo debe ser CONTINUAR o PRIMER_ERROR.");
        }
        return valor;
    }

    private void validarRequerido(String valor, String campo, int maximo, List<String> errores) {
        if (valor == null || valor.trim().isEmpty()) errores.add("Falta " + campo + ".");
        else if (valor.trim().length() > maximo) errores.add(campo + " excede " + maximo + " caracteres.");
    }

    private void validarFecha(String valor, String campo, boolean requerida, List<String> errores) {
        if (valor == null || valor.trim().isEmpty()) {
            if (requerida) errores.add("Falta " + campo + ".");
            return;
        }
        try { LocalDate.parse(valor.trim(), FECHA); }
        catch (DateTimeParseException e) { errores.add(campo + " debe usar el formato dd/MM/yyyy."); }
    }

    private void validarDecimal(String valor, String campo, List<String> errores) {
        if (valor == null || valor.trim().isEmpty()) return;
        try { new BigDecimal(valor.trim().replace(',', '.')); }
        catch (NumberFormatException e) { errores.add(campo + " no es numerico."); }
    }

    private void validarCorreo(String valor, List<String> errores) {
        validarRequerido(valor, "correo electronico", 30, errores);
        if (valor != null && !valor.trim().isEmpty()
                && (!valor.contains("@") || valor.startsWith("@") || valor.endsWith("@"))) {
            errores.add("El correo electronico no tiene un formato valido.");
        }
    }

    private String serializar(Map<String, String> valores) {
        try { return objectMapper.writeValueAsString(valores); }
        catch (JsonProcessingException e) { throw new IllegalStateException("No fue posible preparar el registro.", e); }
    }

    private String nombreSeguro(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) return "cadena-ford.txt";
        String limpio = nombre.replace('\\', '/');
        limpio = limpio.substring(limpio.lastIndexOf('/') + 1).replaceAll("[\\p{Cntrl}]", "").trim();
        return limpio.isEmpty() ? "cadena-ford.txt" : limitar(limpio, 260);
    }

    private String proteger(String identificador) {
        if (identificador == null || identificador.trim().isEmpty()) return "***";
        String limpio = identificador.trim();
        return "***" + limpio.substring(Math.max(0, limpio.length() - 4));
    }

    private String unir(List<String> mensajes) { return limitar(String.join(" ", mensajes), 2000); }
    private String limitar(String valor, int maximo) {
        return valor == null || valor.length() <= maximo ? valor : valor.substring(0, maximo);
    }
    private String normalizar(String valor) {
        return valor == null ? "" : valor.trim().toUpperCase(Locale.ROOT);
    }
    private int numero(Object valor) {
        if (valor instanceof Number) return ((Number) valor).intValue();
        try { return valor == null ? 0 : Integer.parseInt(String.valueOf(valor)); }
        catch (NumberFormatException e) { return 0; }
    }

    private static final class RegistroAnalizado {
        private final FordCadenaRegistro registro;
        private final String tipoMovimiento;
        private final String estado;
        private final String mensaje;
        private final boolean ejecutable;
        private final boolean advertencia;
        private final boolean error;

        private RegistroAnalizado(FordCadenaRegistro registro, String tipoMovimiento,
                                  String estado, String mensaje, boolean ejecutable,
                                  boolean advertencia, boolean error) {
            this.registro = registro;
            this.tipoMovimiento = tipoMovimiento;
            this.estado = estado;
            this.mensaje = mensaje;
            this.ejecutable = ejecutable;
            this.advertencia = advertencia;
            this.error = error;
        }
    }
}
