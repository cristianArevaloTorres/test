package com.lockton.WSBeFlex.DAO;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/** Persistencia de analisis, progreso e idempotencia de Archivo/CadenaWS. */
@Repository
public class CargaCadenaWsDAO {
    private static final int TAMANO_BLOQUE = 500;
    private final JdbcTemplate jdbc;

    public CargaCadenaWsDAO(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void crearLote(UUID id, int idEmpresa, String hashArchivo, String nombreArchivo,
                          String nombreDeclarado, String version, int total, int ejecutables,
                          int advertencias, int errores, int idUsuario, String idTraza) {
        jdbc.update("INSERT dbo.bf_CargaCadenaWsLote "
                        + "(CLId,CLIdEmpresa,CLHashArchivo,CLNombreArchivo,CLNombreDeclarado,"
                        + "CLVersionLayout,CLEstado,CLTotal,CLEjecutables,CLAdvertencias,"
                        + "CLErroresValidacion,CLIdUsuario,CLIdTraza) "
                        + "VALUES (?,?,?,?,?,?,'ANALIZADO',?,?,?,?,?,?)",
                id.toString(), idEmpresa, hashArchivo, nombreArchivo, nombreDeclarado,
                version, total, ejecutables, advertencias, errores, idUsuario, idTraza);
    }

    public void insertarDetalle(UUID idLote, int idEmpresa, int renglon, String hashRegistro,
                                String identificador, String empresaExterna, String codigoMovimiento,
                                String tipoMovimiento, int idOperacion, int idPlantilla,
                                String procedimiento, String estado, String mensaje,
                                String parametrosJson) {
        jdbc.update("INSERT dbo.bf_CargaCadenaWsDetalle "
                        + "(CDIdLote,CDIdEmpresa,CDNumeroRenglon,CDHashRegistro,"
                        + "CDIdentificadorProtegido,CDEmpresaExterna,CDCodigoMovimiento,"
                        + "CDTipoMovimiento,CDIdOperacion,CDIdPlantilla,CDProcedimiento,"
                        + "CDEstado,CDMensaje,CDParametrosJson) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                idLote.toString(), idEmpresa, renglon, hashRegistro, identificador,
                empresaExterna, codigoMovimiento, tipoMovimiento, idOperacion, idPlantilla,
                procedimiento, estado, mensaje, parametrosJson);
    }

    public boolean existeExitoso(int idEmpresa, String hashRegistro, String codigoMovimiento) {
        Integer total = jdbc.queryForObject("SELECT COUNT(1) FROM ("
                        + "SELECT 1 encontrado FROM dbo.bf_CargaCadenaWsIdempotencia "
                        + "WHERE CIIdEmpresa=? AND CIHashRegistro=? AND CICodigoMovimiento=? "
                        + "AND CIEstado='EXITOSO' UNION ALL "
                        + "SELECT 1 FROM dbo.bf_CargaCadenaWsDetalle "
                        + "WHERE CDIdEmpresa=? AND CDHashRegistro=? AND CDCodigoMovimiento=? "
                        + "AND CDEstado='EXITOSO') X",
                new Object[]{idEmpresa, hashRegistro, codigoMovimiento,
                        idEmpresa, hashRegistro, codigoMovimiento}, Integer.class);
        return total != null && total > 0;
    }

    public Set<String> buscarMovimientosExitosos(int idEmpresa, Set<String> hashes) {
        if (hashes == null || hashes.isEmpty()) return Collections.emptySet();
        List<String> lista = new ArrayList<>(hashes);
        Set<String> salida = new java.util.HashSet<>();
        for (int inicio = 0; inicio < lista.size(); inicio += TAMANO_BLOQUE) {
            List<String> bloque = lista.subList(inicio, Math.min(inicio + TAMANO_BLOQUE, lista.size()));
            String marcadores = placeholders(bloque.size());
            String sql = "SELECT hashRegistro,codigoMovimiento FROM ("
                    + "SELECT CIHashRegistro hashRegistro,CICodigoMovimiento codigoMovimiento "
                    + "FROM dbo.bf_CargaCadenaWsIdempotencia WITH (NOLOCK) "
                    + "WHERE CIIdEmpresa=? AND CIEstado='EXITOSO' AND CIHashRegistro IN (" + marcadores + ") "
                    + "UNION SELECT CDHashRegistro,CDCodigoMovimiento FROM dbo.bf_CargaCadenaWsDetalle WITH (NOLOCK) "
                    + "WHERE CDIdEmpresa=? AND CDEstado='EXITOSO' AND CDHashRegistro IN (" + marcadores + ")) X";
            List<Object> parametros = new ArrayList<>();
            parametros.add(idEmpresa);
            parametros.addAll(bloque);
            parametros.add(idEmpresa);
            parametros.addAll(bloque);
            jdbc.query(sql, parametros.toArray(), rs -> {
                salida.add(rs.getString("hashRegistro").trim() + "|"
                        + rs.getString("codigoMovimiento").trim());
            });
        }
        return salida;
    }

    public Map<String, Integer> resolverEmpresasExternas(Set<String> claves) {
        if (claves == null || claves.isEmpty()) return Collections.emptyMap();
        List<String> lista = new ArrayList<>(claves);
        Map<String, Integer> salida = new HashMap<>();
        for (int inicio = 0; inicio < lista.size(); inicio += TAMANO_BLOQUE) {
            List<String> bloque = lista.subList(inicio, Math.min(inicio + TAMANO_BLOQUE, lista.size()));
            String sql = "SELECT CONVERT(VARCHAR(100),EMIdEmpresaFlexiForbes) clave, EMIdEmpresa idEmpresa "
                    + "FROM dbo.ff_Empresa WITH (NOLOCK) WHERE EMIdEstatus=1 "
                    + "AND EMIdEmpresa IN (517,518,661) AND CONVERT(VARCHAR(100),EMIdEmpresaFlexiForbes) IN ("
                    + placeholders(bloque.size()) + ")";
            jdbc.query(sql, bloque.toArray(), rs -> {
                String clave = rs.getString("clave");
                int empresa = rs.getInt("idEmpresa");
                if (salida.containsKey(clave) && salida.get(clave) != empresa) salida.put(clave, -1);
                else salida.put(clave, empresa);
            });
        }
        return salida;
    }

    public Map<String, Map<String, Object>> buscarEmpleadosFord(Set<String> numeros) {
        if (numeros == null || numeros.isEmpty()) return Collections.emptyMap();
        List<String> lista = new ArrayList<>(numeros);
        Map<String, Map<String, Object>> salida = new HashMap<>();
        for (int inicio = 0; inicio < lista.size(); inicio += TAMANO_BLOQUE) {
            List<String> bloque = lista.subList(inicio, Math.min(inicio + TAMANO_BLOQUE, lista.size()));
            String sql = "SELECT EMNumeroEmpleado numeroEmpleado, EMIdEmpresa idEmpresa, "
                    + "EMIdEstatus idEstatus FROM dbo.ff_Empleado WITH (NOLOCK) "
                    + "WHERE EMIdEmpresa IN (517,518,661) AND EMIdParentesco=1 "
                    + "AND EMNumeroEmpleado IN (" + placeholders(bloque.size()) + ") "
                    + "ORDER BY Id DESC";
            jdbc.query(sql, bloque.toArray(), rs -> {
                String numero = normalizar(rs.getString("numeroEmpleado"));
                if (!salida.containsKey(numero)) {
                    Map<String, Object> empleado = new LinkedHashMap<>();
                    empleado.put("numeroEmpleado", rs.getString("numeroEmpleado"));
                    empleado.put("idEmpresa", rs.getInt("idEmpresa"));
                    empleado.put("idEstatus", rs.getInt("idEstatus"));
                    salida.put(numero, empleado);
                }
            });
        }
        return salida;
    }

    public Map<String, Object> obtenerLote(UUID idLote) {
        List<Map<String, Object>> filas = jdbc.queryForList("SELECT "
                + "CLId idLote,CLIdEmpresa idEmpresa,CLHashArchivo hashArchivo,"
                + "CLNombreArchivo nombreArchivo,CLNombreDeclarado nombreDeclarado,"
                + "CLVersionLayout versionLayout,CLEstado estado,CLModo modo,CLTotal total,"
                + "CLEjecutables ejecutables,CLAdvertencias advertencias,"
                + "CLErroresValidacion erroresValidacion,CLProcesados procesados,"
                + "CLExitosos exitosos,CLErroresEjecucion erroresEjecucion,"
                + "CLIdUsuario idUsuario,CLIdTraza idTraza,CLMensaje mensaje,"
                + "CLFechaAnalisis fechaAnalisis,CLFechaInicio fechaInicio,CLFechaFin fechaFin "
                + "FROM dbo.bf_CargaCadenaWsLote WHERE CLId=?", idLote.toString());
        return filas.isEmpty() ? null : new LinkedHashMap<>(filas.get(0));
    }

    public Map<String, Object> ultimoLoteMismoArchivo(int idEmpresa, String hashArchivo, UUID excepto) {
        List<Map<String, Object>> filas = jdbc.queryForList("SELECT TOP 1 CLId idLote,CLEstado estado,"
                        + "CLFechaAnalisis fechaAnalisis,CLExitosos exitosos,CLErroresEjecucion errores "
                        + "FROM dbo.bf_CargaCadenaWsLote WHERE CLIdEmpresa=? AND CLHashArchivo=? "
                        + "AND CLId<>? ORDER BY CLFechaAnalisis DESC",
                idEmpresa, hashArchivo, excepto.toString());
        return filas.isEmpty() ? null : new LinkedHashMap<>(filas.get(0));
    }

    public List<Map<String, Object>> listarDetalles(UUID idLote, int limite) {
        int maximo = limite <= 0 ? 500 : Math.min(limite, 10000);
        return jdbc.queryForList("SELECT TOP " + maximo + " CDId idDetalle,"
                + "CDNumeroRenglon renglon,CDIdentificadorProtegido identificador,"
                + "CDEmpresaExterna empresaExterna,CDCodigoMovimiento codigoMovimiento,"
                + "CDTipoMovimiento tipoMovimiento,CDIdOperacion idOperacion,"
                + "CDIdPlantilla idPlantilla,CDProcedimiento procedimiento,CDEstado estado,"
                + "CDCodigoResultado codigoResultado,CDMensaje mensaje,CDFechaProceso fechaProceso "
                + "FROM dbo.bf_CargaCadenaWsDetalle WHERE CDIdLote=? ORDER BY CDNumeroRenglon",
                idLote.toString());
    }

    public List<Map<String, Object>> listarDetallesDescarga(UUID idLote) {
        return listarDetalles(idLote, 10000);
    }

    @Transactional
    public int iniciarEjecucion(UUID idLote, int idUsuario, String modo, String idTraza) {
        Map<String, Object> lote = obtenerLote(idLote);
        if (lote == null || numero(lote.get("idUsuario")) != idUsuario) return 0;
        String estado = String.valueOf(lote.get("estado"));
        if (!"ANALIZADO".equals(estado) && !"COMPLETADO_CON_ERRORES".equals(estado)) return 0;

        Integer disponibles = jdbc.queryForObject("SELECT COUNT(1) FROM dbo.bf_CargaCadenaWsDetalle "
                        + "WHERE CDIdLote=? AND CDEstado IN ('VALIDO','ERROR_EJECUCION','OMITIDO')",
                new Object[]{idLote.toString()}, Integer.class);
        if (disponibles == null || disponibles == 0) return 0;

        int actualizado = jdbc.update("UPDATE L SET CLEstado='EN_PROCESO',CLModo=?,"
                        + "CLProcesados=(SELECT COUNT(1) FROM dbo.bf_CargaCadenaWsDetalle D "
                        + "WHERE D.CDIdLote=L.CLId AND D.CDEstado='EXITOSO'),"
                        + "CLExitosos=(SELECT COUNT(1) FROM dbo.bf_CargaCadenaWsDetalle D "
                        + "WHERE D.CDIdLote=L.CLId AND D.CDEstado='EXITOSO'),"
                        + "CLErroresEjecucion=0,CLFechaInicio=SYSDATETIME(),"
                        + "CLFechaFin=NULL,CLIdTraza=?,CLMensaje=NULL "
                        + "FROM dbo.bf_CargaCadenaWsLote L WHERE CLId=? AND CLIdUsuario=? "
                        + "AND CLEstado IN ('ANALIZADO','COMPLETADO_CON_ERRORES') "
                        + "AND NOT EXISTS (SELECT 1 FROM dbo.bf_CargaCadenaWsLote X "
                        + "WHERE X.CLIdEmpresa=L.CLIdEmpresa AND X.CLHashArchivo=L.CLHashArchivo "
                        + "AND X.CLEstado='EN_PROCESO' AND X.CLId<>L.CLId)",
                modo, idTraza, idLote.toString(), idUsuario);
        if (actualizado == 0) return 0;
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsDetalle SET CDEstado='PENDIENTE',"
                        + "CDCodigoResultado=NULL,CDMensaje=NULL,CDFechaProceso=NULL "
                        + "WHERE CDIdLote=? AND CDEstado IN ('VALIDO','ERROR_EJECUCION','OMITIDO')",
                idLote.toString());
        return disponibles;
    }

    public List<Map<String, Object>> listarPendientes(UUID idLote) {
        return jdbc.queryForList("SELECT CDId idDetalle,CDNumeroRenglon renglon,"
                + "CDHashRegistro hashRegistro,CDCodigoMovimiento codigoMovimiento,"
                + "CDParametrosJson parametrosJson FROM dbo.bf_CargaCadenaWsDetalle "
                + "WHERE CDIdLote=? AND CDEstado='PENDIENTE' ORDER BY CDNumeroRenglon",
                idLote.toString());
    }

    @Transactional
    public boolean reclamarRegistro(int idEmpresa, String hashRegistro, String codigoMovimiento,
                                    UUID idLote, long idDetalle) {
        int recuperado = jdbc.update("UPDATE dbo.bf_CargaCadenaWsIdempotencia WITH (UPDLOCK,HOLDLOCK) "
                        + "SET CIEstado='EN_PROCESO',CIIdLote=?,CIIdDetalle=?,CIFechaActualizacion=SYSDATETIME() "
                        + "WHERE CIIdEmpresa=? AND CIHashRegistro=? AND CICodigoMovimiento=? "
                        + "AND CIEstado='ERROR'",
                idLote.toString(), idDetalle, idEmpresa, hashRegistro, codigoMovimiento);
        if (recuperado == 1) return true;
        return jdbc.update("INSERT dbo.bf_CargaCadenaWsIdempotencia "
                        + "(CIIdEmpresa,CIHashRegistro,CICodigoMovimiento,CIEstado,CIIdLote,CIIdDetalle) "
                        + "SELECT ?,?,?,'EN_PROCESO',?,? WHERE NOT EXISTS (SELECT 1 "
                        + "FROM dbo.bf_CargaCadenaWsIdempotencia WITH (UPDLOCK,HOLDLOCK) "
                        + "WHERE CIIdEmpresa=? AND CIHashRegistro=? AND CICodigoMovimiento=?)",
                idEmpresa, hashRegistro, codigoMovimiento, idLote.toString(), idDetalle,
                idEmpresa, hashRegistro, codigoMovimiento) == 1;
    }

    public void liberarReclamo(int idEmpresa, String hashRegistro, String codigoMovimiento,
                               UUID idLote, long idDetalle) {
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsIdempotencia SET CIEstado='ERROR',"
                        + "CIFechaActualizacion=SYSDATETIME() WHERE CIIdEmpresa=? AND CIHashRegistro=? "
                        + "AND CICodigoMovimiento=? AND CIIdLote=? AND CIIdDetalle=? AND CIEstado='EN_PROCESO'",
                idEmpresa, hashRegistro, codigoMovimiento, idLote.toString(), idDetalle);
    }

    public boolean marcarProcesando(long idDetalle) {
        return jdbc.update("UPDATE dbo.bf_CargaCadenaWsDetalle SET CDEstado='PROCESANDO' "
                + "WHERE CDId=? AND CDEstado='PENDIENTE'", idDetalle) == 1;
    }

    @Transactional
    public void registrarResultado(UUID idLote, long idDetalle, int idEmpresa,
                                   String hashRegistro, String codigoMovimiento,
                                   boolean exitoso, int codigo, String mensaje) {
        int reclamo = jdbc.update("UPDATE dbo.bf_CargaCadenaWsIdempotencia SET CIEstado=?,"
                        + "CIFechaActualizacion=SYSDATETIME() WHERE CIIdEmpresa=? AND CIHashRegistro=? "
                        + "AND CICodigoMovimiento=? AND CIIdLote=? AND CIIdDetalle=?",
                exitoso ? "EXITOSO" : "ERROR", idEmpresa, hashRegistro, codigoMovimiento,
                idLote.toString(), idDetalle);
        if (reclamo != 1) throw new IllegalStateException("Se perdio el reclamo idempotente del registro.");
        int detalle = jdbc.update("UPDATE dbo.bf_CargaCadenaWsDetalle SET CDEstado=?,CDCodigoResultado=?,"
                        + "CDMensaje=?,CDFechaProceso=SYSDATETIME(),"
                        + "CDParametrosJson=CASE WHEN ?=1 THEN NULL ELSE CDParametrosJson END "
                        + "WHERE CDId=? AND CDEstado='PROCESANDO'",
                exitoso ? "EXITOSO" : "ERROR_EJECUCION", codigo, limitar(mensaje, 2000),
                exitoso ? 1 : 0, idDetalle);
        if (detalle != 1) throw new IllegalStateException("El detalle dejo de estar en proceso.");
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsLote SET CLProcesados=CLProcesados+1,"
                        + "CLExitosos=CLExitosos+?,CLErroresEjecucion=CLErroresEjecucion+? WHERE CLId=?",
                exitoso ? 1 : 0, exitoso ? 0 : 1, idLote.toString());
    }

    @Transactional
    public void registrarDuplicadoEnEjecucion(UUID idLote, long idDetalle) {
        int detalle = jdbc.update("UPDATE dbo.bf_CargaCadenaWsDetalle SET CDEstado='DUPLICADO',"
                        + "CDMensaje='El movimiento ya fue reclamado o procesado por otro lote.',"
                        + "CDFechaProceso=SYSDATETIME(),CDParametrosJson=NULL "
                        + "WHERE CDId=? AND CDEstado='PENDIENTE'",
                idDetalle);
        if (detalle != 1) return;
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsLote SET CLProcesados=CLProcesados+1,"
                        + "CLErroresEjecucion=CLErroresEjecucion+1 WHERE CLId=?",
                idLote.toString());
    }

    public void omitirPendientes(UUID idLote, String mensaje) {
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsDetalle SET CDEstado='OMITIDO',CDMensaje=? "
                        + "WHERE CDIdLote=? AND CDEstado='PENDIENTE'",
                limitar(mensaje, 2000), idLote.toString());
    }

    public void finalizar(UUID idLote) {
        jdbc.update("UPDATE L SET CLEstado=CASE "
                        + "WHEN CLErroresValidacion>0 OR CLErroresEjecucion>0 "
                        + "OR EXISTS(SELECT 1 FROM dbo.bf_CargaCadenaWsDetalle D "
                        + "WHERE D.CDIdLote=L.CLId AND D.CDEstado IN ('OMITIDO','DUPLICADO')) "
                        + "THEN 'COMPLETADO_CON_ERRORES' ELSE 'COMPLETADO' END,"
                        + "CLFechaFin=SYSDATETIME() FROM dbo.bf_CargaCadenaWsLote L WHERE L.CLId=?",
                idLote.toString());
    }

    public void finalizarConError(UUID idLote, String mensaje) {
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsLote SET CLEstado='FALLIDO_TECNICO',"
                        + "CLMensaje=?,CLFechaFin=SYSDATETIME() WHERE CLId=?",
                limitar(mensaje, 1000), idLote.toString());
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsDetalle SET CDEstado='ERROR_EJECUCION',"
                        + "CDMensaje=COALESCE(CDMensaje,?) WHERE CDIdLote=? "
                        + "AND CDEstado IN ('PENDIENTE','PROCESANDO')",
                "El lote termino por un error tecnico.", idLote.toString());
    }

    public void limpiarAnalisisExpirados() {
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsDetalle SET CDParametrosJson=NULL "
                + "WHERE CDParametrosJson IS NOT NULL AND CDIdLote IN "
                + "(SELECT CLId FROM dbo.bf_CargaCadenaWsLote WHERE CLEstado='ANALIZADO' "
                + "AND CLFechaAnalisis<DATEADD(HOUR,-24,SYSDATETIME()))");
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsLote SET CLEstado='EXPIRADO',"
                + "CLMensaje='El analisis expiro antes de ejecutarse.' "
                + "WHERE CLEstado='ANALIZADO' AND CLFechaAnalisis<DATEADD(HOUR,-24,SYSDATETIME())");
        jdbc.update("UPDATE dbo.bf_CargaCadenaWsDetalle SET CDParametrosJson=NULL "
                + "WHERE CDParametrosJson IS NOT NULL AND CDIdLote IN "
                + "(SELECT CLId FROM dbo.bf_CargaCadenaWsLote "
                + "WHERE CLEstado IN ('COMPLETADO','COMPLETADO_CON_ERRORES','FALLIDO_TECNICO','EXPIRADO') "
                + "AND COALESCE(CLFechaFin,CLFechaAnalisis)<DATEADD(DAY,-7,SYSDATETIME()))");
    }

    private String placeholders(int total) {
        if (total <= 0) return "NULL";
        StringBuilder sql = new StringBuilder();
        for (int i = 0; i < total; i++) {
            if (i > 0) sql.append(',');
            sql.append('?');
        }
        return sql.toString();
    }

    private String normalizar(String dato) {
        return dato == null ? "" : dato.trim().toUpperCase();
    }

    private int numero(Object dato) {
        if (dato instanceof Number) return ((Number) dato).intValue();
        try { return dato == null ? 0 : Integer.parseInt(String.valueOf(dato)); }
        catch (NumberFormatException e) { return 0; }
    }

    private String limitar(String dato, int maximo) {
        if (dato == null) return null;
        return dato.length() <= maximo ? dato : dato.substring(0, maximo);
    }
}
