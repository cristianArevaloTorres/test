/*
  Prevalidacion de los TXT dummy BF3/B2 para Ford.
  SOLO LECTURA: no modifica empleados, solicitudes ni configuracion.
*/
SET NOCOUNT ON;
SET LOCK_TIMEOUT 15000;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @IdCompensacion INT = 900001;

SELECT '01_EMPRESAS' AS bloque,
       EMIdEmpresa, EMNombre, EMIdEmpresaFlexiForbes, EMIdEstatus
FROM dbo.ff_Empresa
WHERE EMIdEmpresa IN (517, 661)
ORDER BY EMIdEmpresa;

SELECT '02_OPERACIONES_ACTIVAS_517' AS bloque,
       CE.CEIdOperacion, O.CONombre, CE.CEIdPlantilla,
       CE.CEStoredProc, CE.CEStoredProcAtributos, CE.CEIdEstatus
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
INNER JOIN dbo.ff_CargaMasivaOperacion O ON O.COIdOperacion = CE.CEIdOperacion
WHERE CE.CEIdEmpresa = 517
  AND CE.CEIdOperacion IN (1, 2, 3, 13, 14, 15, 16)
  AND CE.CEIdEstatus = 1
ORDER BY CE.CEIdOperacion;

SELECT '03_CAMPOS_PLANTILLAS' AS bloque,
       CP.PLIdPlantilla, CP.CPOrden,
       LTRIM(RTRIM(C.CANombreCampo)) AS campo,
       C.CATipoDato, C.CALongitud, CP.CPRequerido, CP.CPRangoValores
FROM dbo.ff_ConfiguracionPlantilla CP
INNER JOIN dbo.ff_Campo C ON C.CAIdCampo = CP.CAIdCampo
WHERE CP.PLIdPlantilla IN (182, 3748, 154, 12059, 12060, 12391, 12531)
  AND CP.CPIdEstatus = 1
  AND C.CAIdEstatus = 1
ORDER BY CP.PLIdPlantilla, CP.CPOrden, CP.CPIdConfiguracionPlantilla;

DECLARE @Sexo TABLE ([key] VARCHAR(32), [value] VARCHAR(32));
DECLARE @Parentesco TABLE ([key] VARCHAR(32), [value] VARCHAR(32));
INSERT @Sexo EXEC dbo.ff_CMCSexo;
INSERT @Parentesco EXEC dbo.ff_CMCParentesco;

SELECT '04A_CATALOGO_SEXO' AS bloque, [key], [value]
FROM @Sexo WHERE [key] IN ('M', 'F');

SELECT '04B_CATALOGO_PARENTESCO' AS bloque, [key], [value]
FROM @Parentesco WHERE [key] IN ('H', 'Hijo', 'HIJO(A)');

SELECT '05_OFICINAS_USADAS' AS bloque,
       H.ENIdEmpresa, H.ENEncabezado,
       LEFT(LTRIM(RTRIM(D.TEDescripcion)), 5) AS claveOficina,
       D.TEDescripcion
FROM dbo.ff_TablaEncabezado H
INNER JOIN dbo.ff_TablaEncabezadoDetalle D ON D.TEEnClave = H.ENClave
WHERE H.ENIdEmpresa IN (517, 661)
  AND H.ENIdEstatus = 1
  AND H.ENEncabezado = 'FORD MOTOR'
  AND LEFT(LTRIM(RTRIM(D.TEDescripcion)), 5) IN ('MEX11', 'MEX51')
ORDER BY H.ENIdEmpresa, claveOficina;

SELECT '06_PERFILES_Y_ROLES' AS bloque,
       P.PEIdEmpresa, P.PEIdPerfil, P.PEIdRolDefault,
       P.PEIdEstatus, R.RODefault, R.ROIdEstatus AS estatusRol
FROM dbo.ff_Perfil P
LEFT JOIN dbo.ff_Rol R ON R.ROIdRol = P.PEIdRolDefault
WHERE P.PEIdPerfil IN (1792, 5344)
ORDER BY P.PEIdEmpresa, P.PEIdPerfil;

SELECT '07_COLISION_NUMEROS_DUMMY' AS bloque,
       E.EMIdEmpresa, E.EMNumeroEmpleado, E.EMIdEstatus, E.EMIdParentesco
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa IN (517, 518, 661)
  AND E.EMNumeroEmpleado IN
  (
      'QB26B20001','QB26B20002','QB26B20003','QB26B20004',
      'QB26B20005','QB26B20006','QB26B20007',
      'QB26B2N001','QB26B2N002','QB26B2N003','QB26B2N004',
      'QB26B2N005','QB26B2N006','QB26B2N007'
  )
ORDER BY E.EMNumeroEmpleado, E.EMIdEmpresa, E.Id;

SELECT '08_COMPENSACION_SELECCIONADA' AS bloque,
       @IdCompensacion AS idCompensacion,
       COUNT(*) AS asignacionesExistentes
FROM dbo.bf_Compensacion_STEmpleado
WHERE CSIdCompensacion = @IdCompensacion;

IF OBJECT_ID('dbo.bf_ConfiguracionFlujoCargaMasiva', 'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql N'
        SELECT ''09_FLUJO_PANTALLA_517'' AS bloque,
               CFIdEmpresa, CFFlujoPantalla, CFFlujoAutomatico, CFIdEstatus
        FROM dbo.bf_ConfiguracionFlujoCargaMasiva
        WHERE CFIdEmpresa = 517;';
END
ELSE
    SELECT '09_FLUJO_PANTALLA_517' AS bloque,
           'No existe bf_ConfiguracionFlujoCargaMasiva' AS advertencia;

SELECT '10_USUARIO_TECNICO_FORD' AS bloque,
       ADIdAdministrador, ADClaveAcceso, ADIdEstatus
FROM dbo.ff_administrador
WHERE ADClaveAcceso = 'FORDCARGA';

SELECT '11_RESUMEN' AS bloque,
       CASE WHEN EXISTS
       (
           SELECT 1 FROM dbo.ff_Empleado E
           WHERE E.EMIdEmpresa IN (517, 518, 661)
             AND (E.EMNumeroEmpleado LIKE 'QB26B2%')
       ) THEN 'NO EJECUTAR: hay numeros dummy ocupados'
         ELSE 'OK: numeros dummy disponibles'
       END AS validacionNumeros;
