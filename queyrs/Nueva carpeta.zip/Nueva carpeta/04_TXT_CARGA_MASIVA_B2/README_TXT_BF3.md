# TXT de prueba para Carga Masiva BF3 (motor B2)

Estos archivos no son cadenas SOAP. Son documentos para cargarse desde la pantalla **Carga masiva** de BF3 cuando el flujo de pantalla de la empresa 517 está configurado como `B2`.

Cada archivo utiliza la gramática real del parser:

```text
@commonFields:
CampoComun=Valor

@fieldNames:CampoPorRegistro1,CampoPorRegistro2
@data:
Valor1|Valor2
```

Los nueve archivos contienen siete registros ficticios. Cubren todas las operaciones activas identificadas para Ford y los dos sentidos de compensación. Los campos comunes y por registro, juntos, contienen exactamente los campos activos de cada plantilla.

## Antes de comenzar

1. Usar únicamente un ambiente DEV/QA aislado y con snapshot recuperable.
2. Desplegar primero la corrección incluida de `CargaMasivaB2Service.java`; agrega la compatibilidad técnica de `ff_XCMTitularesAltaCMFORD` que la plantilla 3748 no expone.
3. Ejecutar `00_PREVALIDACION_B2_SOLO_LECTURA.sql` en la base del ambiente.
4. Confirmar `MEX11` para la empresa 517 y `MEX51` para la 661.
5. Confirmar que `QB26B20001..QB26B20007` y `QB26B2N001..QB26B2N007` no existen.
6. Seleccionar en BF3 la operación indicada por el nombre del archivo y cargar sólo ese TXT.
7. Esperar el resultado completo antes de avanzar a la siguiente etapa.

## Orden obligatorio

La secuencia está detallada en `MATRIZ_SECUENCIA_B2.csv`:

1. Alta de titulares Ford, operación 2 / plantilla 3748.
2. Alta de dependientes, operación 1 / plantilla 182.
3. Alta o actualización de compensación, operación 16 / plantilla 12531.
4. Baja de esa compensación, operación 16 / plantilla 12531.
5. Cambio de número, operación 13 / plantilla 12059.
6. Baja, operación 3 / plantilla 154.
7. Reactivación, operación 14 / plantilla 12060.
8. Movimiento Ford XFR de 517 a 661, nuevamente por operación 2 / plantilla 3748.
9. Transferencia genérica B2 de 661 a 517, operación 15 / plantilla 12391.

Las etapas reutilizan a los mismos siete empleados lógicos. Después de la etapa 5, el número cambia de `QB26B2000N` a `QB26B2N00N`.

## Valores dependientes del ambiente

- `EMEmpresa=109` corresponde a la empresa interna 517; `EMEmpresa=137`, a la interna 661.
- Los perfiles usados son 1792 para 517 y 5344 para 661, conforme al diagnóstico recibido.
- El generador usa `CSIdCompensacion=900001` de forma predeterminada. El SP no valida ese ID contra un catálogo antes de insertar, pero puede indicarse un ID real del ambiente al regenerar.
- `EMUsuarioUMod=0` del TXT de baja es sólo un valor estructural: el backend lo sustituye por el usuario autenticado.
- `EMIdEmpresa` también se fuerza desde la empresa autenticada. Por eso la etapa 9 debe ejecutarse en el contexto interno 517: el destino es 517 y el origen capturado es 661.
- Las fechas vacías de `EMFechaBaja` en las altas son intencionales porque el empleado está activo.

## Regeneración

```powershell
cd C:\RUTA\04_TXT_CARGA_MASIVA_B2
.\GENERAR_TXT_CARGA_MASIVA_B2.ps1
```

Con otro prefijo e ID de compensación:

```powershell
.\GENERAR_TXT_CARGA_MASIVA_B2.ps1 -Prefijo QB27OT -IdCompensacion 12345
```

`ValidarTxtConParser.java` permite repetir la validación con las clases
`CargaMasivaTxtParser.java` y `CargaMasivaTxtDocumento.java` del backend. No
requiere Spring ni acceso a base de datos.

No se incluye limpieza automática: estas operaciones pueden afectar solicitudes, planes, estados de cuenta, dependientes y compensaciones. Para repetir la corrida, restaurar el snapshot de QA o acordar una limpieza controlada con DBA.
