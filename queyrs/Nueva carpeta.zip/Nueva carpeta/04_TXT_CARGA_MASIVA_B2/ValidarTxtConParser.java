import com.lockton.WSBeFlex.Services.CargaMasivaB2.CargaMasivaTxtDocumento;
import com.lockton.WSBeFlex.Services.CargaMasivaB2.CargaMasivaTxtParser;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.stream.Stream;

/** Validador sin dependencias externas que usa el mismo parser Java del backend. */
public final class ValidarTxtConParser {
    private ValidarTxtConParser() { }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new IllegalArgumentException("Uso: ValidarTxtConParser <directorio-archivos>");
        }
        Path directorio = Paths.get(args[0]);
        CargaMasivaTxtParser parser = new CargaMasivaTxtParser();
        int archivos = 0;
        try (Stream<Path> rutas = Files.list(directorio).sorted(Comparator.naturalOrder())) {
            for (Path ruta : (Iterable<Path>) rutas.filter(p -> p.toString().endsWith(".txt"))::iterator) {
                CargaMasivaTxtDocumento documento = parser.parse(Files.readAllBytes(ruta));
                if (documento.getRegistros().size() != 7) {
                    throw new IllegalStateException(ruta.getFileName() + " no contiene 7 registros.");
                }
                archivos++;
                System.out.println("OK " + ruta.getFileName()
                        + " registros=" + documento.getRegistros().size()
                        + " campos=" + documento.getNombresCampo().size()
                        + " comunes=" + documento.getCamposComunes().size());
            }
        }
        if (archivos != 9) {
            throw new IllegalStateException("Se esperaban 9 TXT y se validaron " + archivos + ".");
        }
    }
}
