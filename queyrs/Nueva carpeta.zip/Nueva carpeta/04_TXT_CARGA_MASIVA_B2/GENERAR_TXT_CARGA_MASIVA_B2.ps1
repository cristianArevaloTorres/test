param(
    [ValidateRange(1, 99)]
    [int]$Cantidad = 7,

    [ValidatePattern('^[A-Z0-9]+$')]
    [string]$Prefijo = 'QB26B2',

    [ValidateRange(1, 2147483647)]
    [int]$IdCompensacion = 900001,

    [ValidatePattern('^[A-Z0-9]{5}$')]
    [string]$Oficina517 = 'MEX11',

    [ValidatePattern('^[A-Z0-9]{5}$')]
    [string]$Oficina661 = 'MEX51'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Prefijo.Length + 4 -gt 20 -or $Prefijo.Length + 5 -gt 20) {
    throw 'El prefijo excede la longitud de 20 caracteres al agregar los consecutivos.'
}

$salida = Join-Path $PSScriptRoot 'archivos'
New-Item -ItemType Directory -Force -Path $salida | Out-Null
$utf8SinBom = New-Object System.Text.UTF8Encoding($false)

function New-NumeroOriginal([int]$Indice) {
    return $Prefijo + ('{0:D4}' -f $Indice)
}

function New-NumeroCambiado([int]$Indice) {
    return $Prefijo + 'N' + ('{0:D3}' -f $Indice)
}

function New-TxtB2 {
    param(
        [string]$Archivo,
        [int]$Operacion,
        [int]$Plantilla,
        [string]$Descripcion,
        [System.Collections.Specialized.OrderedDictionary]$Comunes,
        [string[]]$Campos,
        [object[]]$Registros,
        [string[]]$CamposPlantilla,
        [string[]]$Requeridos
    )

    $nombresComunes = @($Comunes.Keys | ForEach-Object { [string]$_ })
    $todos = @($nombresComunes + $Campos)
    $duplicados = @($todos | Group-Object | Where-Object Count -gt 1)
    if ($duplicados.Count -gt 0) {
        throw "$Archivo contiene campos duplicados: $($duplicados.Name -join ', ')."
    }

    $faltantes = @($CamposPlantilla | Where-Object { $todos -notcontains $_ })
    $extras = @($todos | Where-Object { $CamposPlantilla -notcontains $_ })
    if ($faltantes.Count -gt 0 -or $extras.Count -gt 0) {
        throw "$Archivo no coincide con la plantilla. Faltantes=[$($faltantes -join ', ')]; extras=[$($extras -join ', ')]."
    }

    foreach ($requerido in $Requeridos) {
        if ($nombresComunes -contains $requerido -and [string]::IsNullOrWhiteSpace([string]$Comunes[$requerido])) {
            throw "$Archivo deja vacio el campo comun requerido $requerido."
        }
    }

    if ($Registros.Count -ne $Cantidad) {
        throw "$Archivo contiene $($Registros.Count) registros en lugar de $Cantidad."
    }

    $lineas = [System.Collections.Generic.List[string]]::new()
    $lineas.Add('# TXT ejecutable desde Carga Masiva BF3 / flujo B2')
    $lineas.Add("# Operacion $Operacion; plantilla $Plantilla; $Descripcion")
    $lineas.Add('# Datos exclusivamente ficticios para DEV/QA. No ejecutar en produccion.')
    $lineas.Add('@commonFields:')
    foreach ($nombre in $nombresComunes) {
        $valor = [string]$Comunes[$nombre]
        if ($valor -match '[\r\n|]') { throw "$Archivo contiene un valor comun no valido en $nombre." }
        $lineas.Add($nombre + '=' + $valor)
    }
    $lineas.Add('')
    $lineas.Add('@fieldNames:' + ($Campos -join ','))
    $lineas.Add('##')
    $lineas.Add('@data:')

    foreach ($registro in $Registros) {
        $valores = @($registro)
        if ($valores.Count -ne $Campos.Count) {
            throw "$Archivo contiene un registro con $($valores.Count) valores y $($Campos.Count) campos."
        }
        for ($i = 0; $i -lt $Campos.Count; $i++) {
            $valor = [string]$valores[$i]
            if ($valor -match '[\r\n|]') { throw "$Archivo contiene un valor no valido en $($Campos[$i])." }
            if (($Requeridos -contains $Campos[$i]) -and [string]::IsNullOrWhiteSpace($valor)) {
                throw "$Archivo deja vacio el campo requerido $($Campos[$i])."
            }
        }
        $lineas.Add(($valores -join '|'))
    }

    $destino = Join-Path $salida $Archivo
    [System.IO.File]::WriteAllText($destino, ($lineas -join "`r`n") + "`r`n", $utf8SinBom)
}

$camposAltaFord = @(
    'EMArchivoInformacion', 'EMEmpresa', 'EMIdSexo', 'EMColoniaFisico',
    'EMNumeroEmpleado', 'EMApellidoPaterno', 'EMApellidoMaterno', 'EMNombre1',
    'EMFechaNacimiento', 'EMFechaIngresoEmpresa', 'EMFechaAlta', 'EMFechaBaja',
    'EMOficina_text', 'EMCentroCostos_text', 'EMrfc', 'EMSalarioBase',
    'EMCorreoElectronico', 'EMCalleFiscal', 'EMColoniaFiscal',
    'EMMunicipioDelegacionFiscal', 'EMEstadoFisical_text', 'EMCodigoPostalFiscal',
    'EMArea_text', 'EMPuestoDescripcion', 'Desarrollo', 'EMcurp', 'EMnss',
    'EMCalleFisico', 'EMFechaAntiguedadPP'
)
$requeridosAltaFord = @(
    'EMIdSexo', 'EMNumeroEmpleado', 'EMApellidoPaterno', 'EMNombre1',
    'EMFechaNacimiento', 'EMFechaIngresoEmpresa', 'EMOficina_text',
    'EMCorreoElectronico', 'EMnss', 'EMCalleFisico', 'EMFechaAntiguedadPP'
)
$camposRegistroAltaFord = @(
    'EMNumeroEmpleado', 'EMApellidoPaterno', 'EMApellidoMaterno', 'EMNombre1',
    'EMFechaNacimiento', 'EMFechaBaja', 'EMrfc', 'EMSalarioBase',
    'EMCorreoElectronico', 'EMCalleFiscal', 'EMColoniaFiscal',
    'EMMunicipioDelegacionFiscal', 'EMEstadoFisical_text', 'EMCodigoPostalFiscal',
    'EMcurp', 'EMnss'
)

$comunesAlta = [ordered]@{
    EMArchivoInformacion = 'HIR'
    EMEmpresa = '109'
    EMIdSexo = 'M'
    EMColoniaFisico = 'A'
    EMFechaIngresoEmpresa = '01/09/2026'
    EMFechaAlta = '01/09/2026'
    EMOficina_text = $Oficina517
    EMCentroCostos_text = 'CCQB2'
    EMArea_text = 'HIR'
    EMPuestoDescripcion = 'NHR'
    Desarrollo = 'D03'
    EMCalleFisico = 'STD'
    EMFechaAntiguedadPP = '01/09/2026'
}
$registrosAlta = @()
for ($i = 1; $i -le $Cantidad; $i++) {
    $registrosAlta += ,@(
        (New-NumeroOriginal $i), 'BULKQA', 'FORDTEST', ('PRUEBA{0:D2}' -f $i),
        ('{0:D2}/01/1990' -f $i), '', ('QBTX90010{0}A01' -f $i),
        [string](25000 + ($i * 1000)), ('qb2.{0:D2}@example.test' -f $i),
        ('CALLE QA {0}' -f $i), 'COLONIA QA', 'CUAUHTEMOC', 'DF',
        ('{0:D5}' -f (1200 + $i)), ('QBTX90010{0}HDFRRS0{0}' -f $i),
        ('9911000{0:D4}' -f $i)
    )
}
New-TxtB2 -Archivo '01_OP2_PL3748_ALTA_TITULARES_FORD_7.txt' -Operacion 2 -Plantilla 3748 `
    -Descripcion 'Alta inicial de siete titulares Ford en empresa interna 517 / externa 109.' `
    -Comunes $comunesAlta -Campos $camposRegistroAltaFord -Registros $registrosAlta `
    -CamposPlantilla $camposAltaFord -Requeridos $requeridosAltaFord

$camposDependiente = @(
    'EMIdEmpresa', 'EMIdSexo', 'EMNumeroEmpleado', 'EMApellidoPaterno',
    'EMApellidoMaterno', 'EMNombre1', 'EMNombre2', 'EMFechaNacimiento',
    'EMFechaAntiguedadGMM', 'EMIdParentesco', 'EMFechaAlta',
    'EMObservaciones', 'EMCertificado'
)
$comunesDependiente = [ordered]@{
    EMIdEmpresa = '517'
    EMIdSexo = 'F'
    EMFechaAntiguedadGMM = '01/09/2026'
    EMIdParentesco = 'H'
    EMFechaAlta = '02/09/2026'
}
$camposRegistroDependiente = @(
    'EMNumeroEmpleado', 'EMApellidoPaterno', 'EMApellidoMaterno', 'EMNombre1',
    'EMNombre2', 'EMFechaNacimiento', 'EMObservaciones', 'EMCertificado'
)
$registrosDependiente = @()
for ($i = 1; $i -le $Cantidad; $i++) {
    $registrosDependiente += ,@(
        (New-NumeroOriginal $i), 'BULKQA', 'DEPENDIENTE', ('HIJA{0:D2}' -f $i),
        'PRUEBA', ('{0:D2}/06/2015' -f $i), ('QA DEP B2 {0:D2}' -f $i),
        ((New-NumeroOriginal $i) + 'D1')
    )
}
New-TxtB2 -Archivo '02_OP1_PL182_ALTA_DEPENDIENTES_7.txt' -Operacion 1 -Plantilla 182 `
    -Descripcion 'Un dependiente ficticio para cada titular creado en la etapa 01.' `
    -Comunes $comunesDependiente -Campos $camposRegistroDependiente -Registros $registrosDependiente `
    -CamposPlantilla $camposDependiente `
    -Requeridos @('EMIdEmpresa','EMIdSexo','EMNumeroEmpleado','EMApellidoPaterno','EMNombre1','EMFechaNacimiento','EMIdParentesco','EMFechaAlta')

$camposCompensacion = @('EMIdEmpresa','EMNumeroEmpleado','CSIdCompensacion','CSMontoCompensacion','EMTipoCargaComp')
$comunesCompAlta = [ordered]@{ EMIdEmpresa = '517'; CSIdCompensacion = [string]$IdCompensacion; EMTipoCargaComp = '1' }
$registrosCompAlta = @()
for ($i = 1; $i -le $Cantidad; $i++) {
    $registrosCompAlta += ,@((New-NumeroOriginal $i), [string](1000 + ($i * 100)))
}
New-TxtB2 -Archivo '03_OP16_PL12531_COMPENSACION_ALTA_ACTUALIZA_7.txt' -Operacion 16 -Plantilla 12531 `
    -Descripcion 'Alta o actualizacion de una compensacion dummy; EMTipoCargaComp=1.' `
    -Comunes $comunesCompAlta -Campos @('EMNumeroEmpleado','CSMontoCompensacion') -Registros $registrosCompAlta `
    -CamposPlantilla $camposCompensacion -Requeridos $camposCompensacion

$comunesCompBaja = [ordered]@{ EMIdEmpresa = '517'; CSIdCompensacion = [string]$IdCompensacion; CSMontoCompensacion = '0'; EMTipoCargaComp = '2' }
$registrosCompBaja = @()
for ($i = 1; $i -le $Cantidad; $i++) { $registrosCompBaja += ,@((New-NumeroOriginal $i)) }
New-TxtB2 -Archivo '04_OP16_PL12531_COMPENSACION_BAJA_7.txt' -Operacion 16 -Plantilla 12531 `
    -Descripcion 'Baja de la compensacion creada en la etapa 03; EMTipoCargaComp=2.' `
    -Comunes $comunesCompBaja -Campos @('EMNumeroEmpleado') -Registros $registrosCompBaja `
    -CamposPlantilla $camposCompensacion -Requeridos $camposCompensacion

$camposCambio = @('EMIdEmpresa','EMNumeroEmpleado','EMNuevoNumeroEmpleado')
$comunesCambio = [ordered]@{ EMIdEmpresa = '517' }
$registrosCambio = @()
for ($i = 1; $i -le $Cantidad; $i++) {
    $registrosCambio += ,@((New-NumeroOriginal $i), (New-NumeroCambiado $i))
}
New-TxtB2 -Archivo '05_OP13_PL12059_CAMBIO_NUMERO_7.txt' -Operacion 13 -Plantilla 12059 `
    -Descripcion 'Cambio controlado de los siete numeros dummy.' `
    -Comunes $comunesCambio -Campos @('EMNumeroEmpleado','EMNuevoNumeroEmpleado') -Registros $registrosCambio `
    -CamposPlantilla $camposCambio -Requeridos $camposCambio

$camposBaja = @('EMIdEmpresa','EMNumeroEmpleado','EMFechaBaja','EMObservaciones','EMUsuarioUMod')
$comunesBaja = [ordered]@{ EMIdEmpresa = '517'; EMFechaBaja = '06/09/2026'; EMObservaciones = 'QA BAJA B2'; EMUsuarioUMod = '0' }
$registrosBaja = @()
for ($i = 1; $i -le $Cantidad; $i++) { $registrosBaja += ,@((New-NumeroCambiado $i)) }
New-TxtB2 -Archivo '06_OP3_PL154_BAJA_7.txt' -Operacion 3 -Plantilla 154 `
    -Descripcion 'Baja de los siete titulares dummy con el numero cambiado.' `
    -Comunes $comunesBaja -Campos @('EMNumeroEmpleado') -Registros $registrosBaja `
    -CamposPlantilla $camposBaja -Requeridos @('EMNumeroEmpleado','EMFechaBaja','EMObservaciones','EMUsuarioUMod')

$camposReactivacion = @('EMIdEmpresa','EMNumeroEmpleado','EMFechaReingreso')
$comunesReactivacion = [ordered]@{ EMIdEmpresa = '517'; EMFechaReingreso = '07/09/2026' }
$registrosReactivacion = @()
for ($i = 1; $i -le $Cantidad; $i++) { $registrosReactivacion += ,@((New-NumeroCambiado $i)) }
New-TxtB2 -Archivo '07_OP14_PL12060_REACTIVACION_7.txt' -Operacion 14 -Plantilla 12060 `
    -Descripcion 'Reactivacion de los siete titulares dados de baja en la etapa 06.' `
    -Comunes $comunesReactivacion -Campos @('EMNumeroEmpleado') -Registros $registrosReactivacion `
    -CamposPlantilla $camposReactivacion -Requeridos $camposReactivacion

$comunesXfrFord = [ordered]@{
    EMArchivoInformacion = 'XFR'
    EMEmpresa = '137'
    EMIdSexo = 'M'
    EMColoniaFisico = 'A'
    EMFechaIngresoEmpresa = '01/09/2026'
    EMFechaAlta = '08/09/2026'
    EMOficina_text = $Oficina661
    EMCentroCostos_text = 'CCQB2'
    EMArea_text = 'XFR'
    EMPuestoDescripcion = 'INT'
    Desarrollo = 'D03'
    EMCalleFisico = 'STD'
    EMFechaAntiguedadPP = '01/09/2026'
}
$registrosXfrFord = @()
for ($i = 1; $i -le $Cantidad; $i++) {
    $registrosXfrFord += ,@(
        (New-NumeroCambiado $i), 'BULKQA', 'FORDTEST', ('PRUEBA{0:D2}' -f $i),
        ('{0:D2}/01/1990' -f $i), '', ('QBTX90010{0}A01' -f $i),
        [string](30000 + ($i * 1000)), ('qb2.{0:D2}@example.test' -f $i),
        ('CALLE QA {0}' -f $i), 'COLONIA QA', 'CUAUHTEMOC', 'DF',
        ('{0:D5}' -f (1200 + $i)), ('QBTX90010{0}HDFRRS0{0}' -f $i),
        ('9911000{0:D4}' -f $i)
    )
}
New-TxtB2 -Archivo '08_OP2_PL3748_XFR_A_EMPRESA_661_7.txt' -Operacion 2 -Plantilla 3748 `
    -Descripcion 'El SP especial Ford mueve los siete dummy de externa 109/interna 517 a externa 137/interna 661.' `
    -Comunes $comunesXfrFord -Campos $camposRegistroAltaFord -Registros $registrosXfrFord `
    -CamposPlantilla $camposAltaFord -Requeridos $requeridosAltaFord

$camposTransferencia = @(
    'EMIdEmpresa','EMIdEmpresaOrigen','EMNumeroEmpleado','EMIdPerfil','EMSalarioBase',
    'EMPuesto','EMCorreoElectronico','EMFecha_solicitud_movimiento',
    'EMSeleccionUsuario','EMObservacionesTransferencia'
)
$comunesTransferencia = [ordered]@{
    EMIdEmpresa = '517'
    EMIdEmpresaOrigen = '661'
    EMIdPerfil = '1792'
    EMSalarioBase = '32000'
    EMPuesto = 'STAFF'
    EMFecha_solicitud_movimiento = '09/09/2026'
    EMSeleccionUsuario = '0'
    EMObservacionesTransferencia = 'QA RETORNO B2'
}
$registrosTransferencia = @()
for ($i = 1; $i -le $Cantidad; $i++) {
    $registrosTransferencia += ,@((New-NumeroCambiado $i), ('qb2.{0:D2}@example.test' -f $i))
}
New-TxtB2 -Archivo '09_OP15_PL12391_TRANSFERENCIA_661_A_517_7.txt' -Operacion 15 -Plantilla 12391 `
    -Descripcion 'Transferencia generica B2 desde la empresa interna 661 hacia la empresa autenticada 517.' `
    -Comunes $comunesTransferencia -Campos @('EMNumeroEmpleado','EMCorreoElectronico') -Registros $registrosTransferencia `
    -CamposPlantilla $camposTransferencia `
    -Requeridos @('EMIdEmpresa','EMIdEmpresaOrigen','EMNumeroEmpleado','EMIdPerfil','EMFecha_solicitud_movimiento','EMSeleccionUsuario')

$matriz = @(
    [pscustomobject]@{ Orden=1; Operacion=2; Plantilla=3748; Archivo='01_OP2_PL3748_ALTA_TITULARES_FORD_7.txt'; Precondicion='Los numeros originales no existen'; Resultado='7 titulares activos en 517' },
    [pscustomobject]@{ Orden=2; Operacion=1; Plantilla=182; Archivo='02_OP1_PL182_ALTA_DEPENDIENTES_7.txt'; Precondicion='Etapa 01 exitosa'; Resultado='1 dependiente por titular' },
    [pscustomobject]@{ Orden=3; Operacion=16; Plantilla=12531; Archivo='03_OP16_PL12531_COMPENSACION_ALTA_ACTUALIZA_7.txt'; Precondicion='Titulares activos'; Resultado='Compensacion activa/actualizada' },
    [pscustomobject]@{ Orden=4; Operacion=16; Plantilla=12531; Archivo='04_OP16_PL12531_COMPENSACION_BAJA_7.txt'; Precondicion='Etapa 03 exitosa con el mismo ID'; Resultado='Compensacion en baja' },
    [pscustomobject]@{ Orden=5; Operacion=13; Plantilla=12059; Archivo='05_OP13_PL12059_CAMBIO_NUMERO_7.txt'; Precondicion='Numeros destino libres'; Resultado='7 numeros actualizados' },
    [pscustomobject]@{ Orden=6; Operacion=3; Plantilla=154; Archivo='06_OP3_PL154_BAJA_7.txt'; Precondicion='Etapa 05 exitosa'; Resultado='Titulares y dependientes en baja' },
    [pscustomobject]@{ Orden=7; Operacion=14; Plantilla=12060; Archivo='07_OP14_PL12060_REACTIVACION_7.txt'; Precondicion='Etapa 06 exitosa'; Resultado='Titulares y dependientes reactivados' },
    [pscustomobject]@{ Orden=8; Operacion=2; Plantilla=3748; Archivo='08_OP2_PL3748_XFR_A_EMPRESA_661_7.txt'; Precondicion='MEX51 valido para 661'; Resultado='7 empleados movidos a 661' },
    [pscustomobject]@{ Orden=9; Operacion=15; Plantilla=12391; Archivo='09_OP15_PL12391_TRANSFERENCIA_661_A_517_7.txt'; Precondicion='Etapa 08 exitosa; ejecutar autenticado en 517'; Resultado='7 empleados regresan a 517' }
)
$matriz | Export-Csv -LiteralPath (Join-Path $PSScriptRoot 'MATRIZ_SECUENCIA_B2.csv') -NoTypeInformation -Encoding UTF8

Write-Host "Se generaron 9 TXT de prueba con $Cantidad registros cada uno en: $salida"
Write-Host "ID de compensacion utilizado: $IdCompensacion"
