/*
  PREVALIDACION DE CADENAS DUMMY FORD

  SOLO LECTURA. No contiene INSERT, UPDATE, DELETE, MERGE ni ejecuta SP de negocio.
  Ejecutar en la base BeFlex del ambiente DEV/QA antes de cargar 01_HIR_ALTA_7.txt.
*/

SET NOCOUNT ON;
SET LOCK_TIMEOUT 15000;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @GPID TABLE (EMNumeroEmpleado VARCHAR(20) PRIMARY KEY);
INSERT INTO @GPID (EMNumeroEmpleado)
VALUES
('QA26CW0001'), ('QA26CW0002'), ('QA26CW0003'), ('QA26CW0004'),
('QA26CW0005'), ('QA26CW0006'), ('QA26CW0007');

/* Debe devolver existentes = 0 antes de la primera etapa HIR. */
SELECT
    '01_COLISION_GPID' AS bloque,
    COUNT(E.Id) AS existentes,
    CASE WHEN COUNT(E.Id) = 0 THEN 'OK_PARA_INICIAR'
         ELSE 'NO_EJECUTAR_CAMBIAR_PREFIJO' END AS validacion
FROM @GPID G
LEFT JOIN dbo.ff_Empleado E
  ON E.EMNumeroEmpleado = G.EMNumeroEmpleado
 AND E.EMIdEmpresa IN (517, 518, 661)
WHERE E.Id IS NOT NULL;

/* Debe devolver 109 -> 517 y 137 -> 661, ambos activos. */
SELECT
    '02_MAPEO_EMPRESA' AS bloque,
    E.EMIdEmpresaFlexiForbes AS empresaExterna,
    E.EMIdEmpresa AS empresaInterna,
    E.EMNombre,
    E.EMIdEstatus
FROM dbo.ff_Empresa E
WHERE E.EMIdEstatus = 1
  AND CONVERT(VARCHAR(20), E.EMIdEmpresaFlexiForbes) IN ('109', '137')
ORDER BY empresaExterna;

/* Debe confirmar MEX11 para 517 y MEX51 para 661. */
SELECT
    '03_OFICINAS' AS bloque,
    H.ENIdEmpresa,
    LEFT(LTRIM(RTRIM(D.TEDescripcion)), 5) AS claveOficina,
    COUNT(*) AS coincidencias
FROM dbo.ff_TablaEncabezado H
INNER JOIN dbo.ff_TablaEncabezadoDetalle D
  ON D.TEEnClave = H.ENClave
WHERE H.ENIdEstatus = 1
  AND H.ENEncabezado = 'FORD MOTOR'
  AND
  (
      (H.ENIdEmpresa = 517 AND LEFT(LTRIM(RTRIM(D.TEDescripcion)), 5) = 'MEX11')
      OR
      (H.ENIdEmpresa = 661 AND LEFT(LTRIM(RTRIM(D.TEDescripcion)), 5) = 'MEX51')
  )
GROUP BY H.ENIdEmpresa, LEFT(LTRIM(RTRIM(D.TEDescripcion)), 5)
ORDER BY H.ENIdEmpresa;

/* Debe apuntar a plantilla 3748 y al SP Ford especial. */
SELECT
    '04_CONTRATO_OPERACION' AS bloque,
    CE.CEIdEmpresa,
    CE.CEIdOperacion,
    CE.CEIdPlantilla,
    LTRIM(RTRIM(CE.CEStoredProc)) AS storedProcedure,
    CE.CEIdEstatus
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
WHERE CE.CEIdEmpresa = 517
  AND CE.CEIdOperacion = 2
  AND CE.CEIdEstatus = 1;

/* Debe devolver al usuario técnico FORDCARGA activo. */
SELECT
    '05_USUARIO_TECNICO' AS bloque,
    A.ADIdAdministrador,
    A.ADClaveAcceso,
    A.ADIdEstatus
FROM dbo.ff_administrador A
WHERE A.ADClaveAcceso = 'FORDCARGA';

