param(
    [ValidateRange(1, 99)]
    [int]$Cantidad = 7,

    [ValidatePattern('^[A-Z0-9]+$')]
    [string]$Prefijo = 'QA26CW'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Prefijo.Length + 4 -gt 20) {
    throw 'El prefijo, junto con el consecutivo de cuatro posiciones, excede los 20 caracteres del GPID.'
}

$etapas = @(
    [pscustomobject]@{ Orden = 1; Archivo = '01_HIR_ALTA_7.txt'; Evento = 'HIR'; Motivo = 'NHR'; Estatus = 'A'; Empresa = '109'; Oficina = 'MEX11'; Fecha = '01/09/2026'; FechaBaja = ''; Desarrollo = 'D03'; Direccion = $true },
    [pscustomobject]@{ Orden = 2; Archivo = '02_PAY_ACTUALIZACION_7.txt'; Evento = 'PAY'; Motivo = 'MER'; Estatus = 'A'; Empresa = '109'; Oficina = 'MEX11'; Fecha = '02/09/2026'; FechaBaja = ''; Desarrollo = 'D03'; Direccion = $false },
    [pscustomobject]@{ Orden = 3; Archivo = '03_POS_ACTUALIZACION_7.txt'; Evento = 'POS'; Motivo = 'REO'; Estatus = 'A'; Empresa = '109'; Oficina = 'MEX11'; Fecha = '03/09/2026'; FechaBaja = ''; Desarrollo = 'D04'; Direccion = $false },
    [pscustomobject]@{ Orden = 4; Archivo = '04_PRO_ACTUALIZACION_7.txt'; Evento = 'PRO'; Motivo = 'NSR'; Estatus = 'A'; Empresa = '109'; Oficina = 'MEX11'; Fecha = '04/09/2026'; FechaBaja = ''; Desarrollo = 'M13'; Direccion = $false },
    [pscustomobject]@{ Orden = 5; Archivo = '05_DEM_ACTUALIZACION_7.txt'; Evento = 'DEM'; Motivo = 'EXI'; Estatus = 'A'; Empresa = '109'; Oficina = 'MEX11'; Fecha = '05/09/2026'; FechaBaja = ''; Desarrollo = 'D03'; Direccion = $false },
    [pscustomobject]@{ Orden = 6; Archivo = '06_DTA_ACTUALIZACION_7.txt'; Evento = 'DTA'; Motivo = 'PAS'; Estatus = 'A'; Empresa = '109'; Oficina = 'MEX11'; Fecha = '06/09/2026'; FechaBaja = ''; Desarrollo = 'D03'; Direccion = $false },
    [pscustomobject]@{ Orden = 7; Archivo = '07_XFR_CAMBIO_EMPRESA_7.txt'; Evento = 'XFR'; Motivo = 'INT'; Estatus = 'A'; Empresa = '137'; Oficina = 'MEX51'; Fecha = '07/09/2026'; FechaBaja = ''; Desarrollo = 'D03'; Direccion = $false },
    [pscustomobject]@{ Orden = 8; Archivo = '08_TER_BAJA_7.txt'; Evento = 'TER'; Motivo = 'VAE'; Estatus = 'T'; Empresa = '137'; Oficina = 'MEX51'; Fecha = '08/09/2026'; FechaBaja = '08/09/2026'; Desarrollo = 'D03'; Direccion = $false },
    [pscustomobject]@{ Orden = 9; Archivo = '09_REH_REACTIVACION_7.txt'; Evento = 'REH'; Motivo = 'REH'; Estatus = 'A'; Empresa = '137'; Oficina = 'MEX51'; Fecha = '09/09/2026'; FechaBaja = ''; Desarrollo = 'D03'; Direccion = $false }
)

$salida = Join-Path $PSScriptRoot 'archivos'
New-Item -ItemType Directory -Force -Path $salida | Out-Null

foreach ($etapa in $etapas) {
    $lineas = [System.Collections.Generic.List[string]]::new()
    $lineas.Add("01|MOVIMIENTOS_PERSONAL_QA_$($etapa.Evento)")

    for ($i = 1; $i -le $Cantidad; $i++) {
        $numeroEmpleado = $Prefijo + ('{0:D4}' -f $i)
        $sexo = if ($i % 2 -eq 0) { 'F' } else { 'M' }
        $fechaNacimiento = ('{0:D2}/01/1990' -f $i)
        $salario = if ($etapa.Orden -eq 1) { 25000 + ($i * 1000) } else { 30000 + ($i * 1000) }
        $correo = ('qa.ford{0:D2}@example.test' -f $i)
        $calle = if ($etapa.Direccion) { "CALLE PRUEBA $i" } else { '' }
        $colonia = if ($etapa.Direccion) { 'COLONIA QA' } else { '' }
        $municipio = if ($etapa.Direccion) { 'CUAUHTEMOC' } else { '' }
        $estado = if ($etapa.Direccion) { 'DF' } else { '' }
        $codigoPostal = if ($etapa.Direccion) { '{0:D5}' -f (1200 + $i) } else { '' }
        $nss = '9900000' + ('{0:D4}' -f $i)

        # Las 29 posiciones incluyen 02 como la primera posición del detalle.
        $campos = @(
            '02',                         # 01 tipo/grupo
            $etapa.Empresa,               # 02 empresa externa Ford
            $sexo,                        # 03 sexo
            $etapa.Estatus,               # 04 estatus A/T
            $numeroEmpleado,              # 05 GPID
            'CADENAQA',                    # 06 apellido paterno ficticio
            'FORDTEST',                    # 07 apellido materno ficticio
            ('PRUEBA{0:D2}' -f $i),        # 08 nombre ficticio
            $fechaNacimiento,              # 09 fecha nacimiento
            '01/09/2026',                 # 10 fecha ingreso
            $etapa.Fecha,                  # 11 fecha movimiento
            $etapa.FechaBaja,              # 12 fecha baja
            $etapa.Oficina,                # 13 oficina Ford
            ('CCQA{0:D2}' -f $i),          # 14 centro de costo
            '',                            # 15 RFC: vacío intencionalmente
            ([string]$salario),            # 16 salario
            $correo,                       # 17 correo reservado example.test
            $calle,                        # 18 calle
            $colonia,                      # 19 colonia
            $municipio,                    # 20 municipio/delegación
            $estado,                       # 21 estado
            $codigoPostal,                 # 22 código postal
            $etapa.Evento,                 # 23 evento Ford
            $etapa.Motivo,                 # 24 motivo Ford
            $etapa.Desarrollo,             # 25 categoría/desarrollo
            '',                            # 26 CURP: vacío intencionalmente
            $nss,                          # 27 NSS ficticio
            'STD',                         # 28 clase empleado
            '01/09/2026'                  # 29 antigüedad plan de pensiones
        )

        if ($campos.Count -ne 29) {
            throw "La etapa $($etapa.Evento) generó $($campos.Count) posiciones en lugar de 29."
        }
        $lineas.Add(($campos -join '|'))
    }

    $lineas.Add("03|$Cantidad")
    $destino = Join-Path $salida $etapa.Archivo
    Set-Content -LiteralPath $destino -Value $lineas -Encoding UTF8

    # Validación estructural inmediata del archivo generado.
    $contenido = @(Get-Content -LiteralPath $destino | Where-Object { $_.Trim() -ne '' })
    $detalles = @($contenido | Where-Object { $_.StartsWith('02|') })
    if ($contenido[0] -notlike '01|*' -or $contenido[-1] -ne "03|$Cantidad") {
        throw "El archivo $($etapa.Archivo) no tiene encabezado o sumario válido."
    }
    if ($detalles.Count -ne $Cantidad) {
        throw "El archivo $($etapa.Archivo) no contiene $Cantidad detalles."
    }
    foreach ($detalle in $detalles) {
        $posiciones = @($detalle -split '\|', -1)
        if ($posiciones.Count -ne 29) {
            throw "El archivo $($etapa.Archivo) contiene un detalle con $($posiciones.Count) posiciones."
        }
        if ($posiciones[22] -ne $etapa.Evento -or $posiciones[3] -ne $etapa.Estatus) {
            throw "El archivo $($etapa.Archivo) no conserva el evento/estatus esperado."
        }
    }
}

Write-Host "Se generaron $($etapas.Count) archivos con $Cantidad registros cada uno en: $salida"

