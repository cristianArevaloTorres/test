# Cadenas dummy para CadenaWS Ford

Estos archivos contienen exclusivamente datos ficticios y están preparados para un ambiente aislado de desarrollo o QA. No deben ejecutarse en producción.

## Qué se prueba

Se reutilizan los mismos siete GPID dummy (`QA26CW0001` a `QA26CW0007`) a través de los nueve eventos Ford conocidos. Cada archivo contiene encabezado `01`, siete detalles `02` de 29 posiciones y sumario `03|7`.

Aunque cambie el código de evento, todos los registros se procesan mediante la operación Ford 2, plantilla 3748 y `ff_XCMTitularesAltaCMFORD`. La acción efectiva depende del estado actual del empleado, el estatus `A/T` y la empresa destino; el evento de la posición 23 se conserva como trazabilidad.

## Orden obligatorio

1. Ejecutar `00_PREVALIDACION_SOLO_LECTURA.sql` y comprobar que los siete GPID no existen.
2. Cargar y terminar `01_HIR_ALTA_7.txt`.
3. Cargar y terminar `02_PAY_ACTUALIZACION_7.txt`.
4. Cargar y terminar `03_POS_ACTUALIZACION_7.txt`.
5. Cargar y terminar `04_PRO_ACTUALIZACION_7.txt`.
6. Cargar y terminar `05_DEM_ACTUALIZACION_7.txt`.
7. Cargar y terminar `06_DTA_ACTUALIZACION_7.txt`.
8. Cargar y terminar `07_XFR_CAMBIO_EMPRESA_7.txt`.
9. Cargar y terminar `08_TER_BAJA_7.txt`.
10. Cargar y terminar `09_REH_REACTIVACION_7.txt`.

No cargar dos etapas simultáneamente. Antes de avanzar, verificar que los siete registros de la etapa anterior terminaron exitosamente.

## Resultado esperado

- `HIR`: siete altas nuevas en la empresa externa 109, interna 517.
- `PAY`, `POS`, `PRO`, `DEM` y `DTA`: actualizaciones sobre empleados activos.
- `XFR`: cambio de empresa externa 109/interna 517 a externa 137/interna 661.
- `TER`: baja de los siete empleados ya transferidos.
- `REH`: reactivación de esos mismos siete empleados en la empresa 661.

La matriz completa está en `MATRIZ_SECUENCIA.csv`.

## Consideraciones

- Los correos usan el dominio reservado `example.test`; no corresponden a destinatarios reales.
- RFC y CURP se envían vacíos porque son opcionales en la plantilla Ford.
- Los NSS son sintéticos y sólo sirven para satisfacer el contrato técnico.
- `MEX11` y `MEX51`, las empresas externas `109` y `137`, y los motivos usados fueron observados en la configuración/histórico Ford analizado.
- La prevalidación debe confirmar nuevamente esos catálogos en la base donde se hará la prueba.
- No se incluye un script de limpieza: el procedimiento afecta empleados, solicitudes, planes y estados de cuenta. Para repetir desde cero se recomienda restaurar el snapshot de QA o acordar una limpieza controlada con DBA.
- Si algún GPID ya existe, no ejecutar los archivos tal como están. Cambiar `Prefijo` en `GENERAR_CADENAS_PRUEBA.ps1`, regenerar y volver a ejecutar la prevalidación adaptando la lista.

## Regeneración opcional

Desde PowerShell:

```powershell
cd C:\RUTA\03_CADENAS_PRUEBA
.\GENERAR_CADENAS_PRUEBA.ps1
```

Para usar otro prefijo ficticio:

```powershell
.\GENERAR_CADENAS_PRUEBA.ps1 -Prefijo QA27OTRA
```

