/*
  GENERADOR ORGANIZADO DE INPUTS TXT PARA CARGA MASIVA B2 DESDE BF3

  Empresa: 186

  Este script es SOLO LECTURA. Devuelve una fila por cada tipo de carga activo
  configurado en ff_CargaMasivaOperacionEmpresa y el contenido completo que se
  puede copiar y pegar en el editor TXT de BF3 o guardar como archivo .txt.

  Antes de utilizar los contenidos, ejecutar:
    PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql
*/
SET NOCOUNT ON;

DECLARE @IdEmpresa INT = 186;
DECLARE @CRLF VARCHAR(2) = CHAR(13) + CHAR(10);

DECLARE @Inputs TABLE
(
    Orden INT NOT NULL PRIMARY KEY,
    IdOperacion INT NOT NULL UNIQUE,
    Archivo VARCHAR(100) NOT NULL,
    ParaQueSirve VARCHAR(500) NOT NULL,
    Precondicion VARCHAR(500) NOT NULL,
    NumeroEmpleadoPrueba VARCHAR(50) NOT NULL,
    ResultadoEsperado VARCHAR(500) NOT NULL,
    CamposComunes VARCHAR(MAX) NOT NULL,
    CamposRegistro VARCHAR(MAX) NOT NULL,
    DatosRegistro VARCHAR(MAX) NOT NULL
);

INSERT @Inputs
(
    Orden, IdOperacion, Archivo, ParaQueSirve, Precondicion,
    NumeroEmpleadoPrueba, ResultadoEsperado,
    CamposComunes, CamposRegistro, DatosRegistro
)
VALUES
(
    1, 1, '01_ALTA_DEPENDIENTE_186.txt',
    'Agrega un dependiente a un titular que ya existe en la empresa 186.',
    'Debe existir activo el titular numerico 186990001. Lo crea el preparador.',
    '186990001',
    'Se crea un dependiente del titular 186990001 con certificado 18699000101.',
    'EMIdEmpresa=186' + @CRLF + 'EMUsuarioUMod=3043',
    'EMIdSexo,EMNumeroEmpleado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMFechaAntiguedadGMM,EMIdParentesco,EMFechaAlta,EMObservaciones,EMCertificado',
    'F|186990001|PRUEBA|DEPENDIENTE|DUMMY|CARGA|15/06/2015|01/01/2024|H|24/08/2026|QA CARGA B2 BF3|18699000101'
),
(
    2, 2, '02_ALTA_TITULAR_186.txt',
    'Crea un titular nuevo mediante la plantilla de alta de titulares.',
    'El numero 186990002 no debe existir antes de ejecutar la carga. El preparador lo elimina si pertenece a esta prueba.',
    '186990002',
    'Se crea un titular nuevo con numero 186990002.',
    'EMEmpresa=S001' + @CRLF + 'EMUsuarioUMod=3043',
    'EMNumeroEmpleado,EMPuestoDescripcion,EMNombre1,EMApellidoPaterno,EMApellidoMaterno,EMFechaNacimiento,EMIdSexo,EMFechaIngresoEmpresa,EMIdEstatus,EMFechaBaja,EMFechaEstatus,EMcurp,EMrfc,EMIdTransferido,EMEstadoFisical_text,EMnss,EMPuesto,EMCentroCostos_text,EMOficina_text,EMArea_text,EMArchivoInformacion,EMCorreoElectronico,EMCalleFisico,EMMunicipioDelegacionFiscal,EMJefe,EMEstadoFisico_text,EMColoniaFiscal,EMColoniaFisico,EMMunicipioDelegacionFisico,EMSalarioBase,EMCodigoPostalFisico',
    '186990002|STAFF|DUMMY|ALTA|TITULAR|20/05/1990|M|24/08/2026|3||24/08/2026|QACM900520HDFLRN01|QACM900520AA1|0|CIUDAD DE MEXICO|90052000001|STAFF|10001|MEX|MEX|STAFF|qacm.alta@dummy.mx|DOMICILIO DUMMY||0|||0|0|4|0'
),
(
    3, 5, '05_CONCILIACION_AUTOS_186.txt',
    'Aplica una conciliacion de descuento para una solicitud de autos.',
    'Debe existir la cadena dummy de calendario, solicitud y estado de cuenta asociada al empleado 186990007.',
    '186990007',
    'Se concilian 100.00 para el periodo QACM202699 y registro QACM-CIS-186.',
    'EMEmpresa=S001' + @CRLF + 'EMUsuarioUMod=3043',
    'EMNumeroEmpleado,Quincenaanio,SANumeroRegistroAseguradora,CDMontoConciliacion',
    '186990007|QACM202699|QACM-CIS-186|100.00'
),
(
    4, 13, '13_CAMBIO_NUMERO_EMPLEADO_186.txt',
    'Cambia el numero de un titular y sus referencias relacionadas.',
    'Debe existir activo 186990003 y no debe existir 186990004.',
    '186990003 -> 186990004',
    'El titular queda identificado con el nuevo numero 186990004.',
    'EMIdEmpresa=186' + @CRLF + 'EMUsuarioUMod=3043',
    'EMNumeroEmpleado,EMNuevoNumeroEmpleado',
    '186990003|186990004'
),
(
    5, 14, '14_REACTIVACION_EMPLEADO_186.txt',
    'Reactiva a un titular que se encuentra dado de baja.',
    'Debe existir 186990005 con EMIdEstatus=2 y fecha de baja. Lo prepara el script de dummies.',
    '186990005',
    'El titular y sus dependientes quedan activos con fecha de reingreso 24/08/2026.',
    'EMIdEmpresa=186' + @CRLF + 'EMUsuarioUMod=3043',
    'EMNumeroEmpleado,EMFechaReingreso',
    '186990005|24/08/2026'
),
(
    6, 15, '15_TRANSFERENCIA_EMPLEADO_186.txt',
    'Transfiere un titular de la empresa origen 187 a la empresa destino 186.',
    'Debe existir activo 186990008 en la empresa 187 y existir un rol default activo en la empresa 186.',
    '186990008',
    'El titular cambia de empresa 187 a 186 y se registra la trazabilidad de transferencia.',
    'EMIdEmpresa=186' + @CRLF + 'EMUsuarioUMod=3043',
    'EMIdEmpresaOrigen,EMNumeroEmpleado,EMIdPerfil,EMSalarioBase,EMCorreoElectronico,EMFecha_solicitud_movimiento,EMSeleccionUsuario,EMObservacionesTransferencia',
    '187|186990008|678|20000.00|qacm.trans@dummy.mx|24/08/2026|0|QA TRANSFERENCIA B2 BF3'
),
(
    7, 16, '16_COMPENSACION_EMPLEADO_186.txt',
    'Agrega o actualiza una compensacion para un titular activo.',
    'Debe existir activo 186990006 y estar disponible la compensacion de prueba 900001.',
    '186990006',
    'Se registra o actualiza una compensacion de 1500.00 para el empleado.',
    'EMIdEmpresa=186' + @CRLF + 'EMUsuarioUMod=3043',
    'EMNumeroEmpleado,CSIdCompensacion,CSMontoCompensacion,EMTipoCargaComp',
    '186990006|900001|1500.00|1'
);

/*
  BLOQUE 01: relacion exacta entre el input y la configuracion activa de BD.
  Si ResultadoConfiguracion no es OK, no utilizar ese input hasta corregir BD.
*/
SELECT
    '01_CATALOGO_INPUTS' AS Bloque,
    I.Orden,
    I.IdOperacion,
    CO.CONombre AS TipoCarga,
    CO.CODescripcion AS DescripcionConfigurada,
    CE.CEIdOperacionEmpresa,
    CE.CEIdPlantilla,
    P.PLDescripcion AS Plantilla,
    CE.CEStoredProc AS StoredProcedure,
    CE.CEStoredProcAtributos,
    I.Archivo,
    I.NumeroEmpleadoPrueba,
    I.ParaQueSirve,
    I.Precondicion,
    I.ResultadoEsperado,
    CASE
        WHEN CE.CEIdOperacionEmpresa IS NULL THEN 'FALTA CONFIGURACION ACTIVA PARA EMPRESA 186'
        WHEN OBJECT_ID('dbo.' + CE.CEStoredProc, 'P') IS NULL THEN 'FALTA STORED PROCEDURE'
        WHEN P.PLIdPlantilla IS NULL THEN 'FALTA PLANTILLA'
        ELSE 'OK'
    END AS ResultadoConfiguracion
FROM @Inputs I
LEFT JOIN dbo.ff_CargaMasivaOperacion CO
    ON CO.COIdOperacion = I.IdOperacion
OUTER APPLY
(
    SELECT TOP (1) X.*
    FROM dbo.ff_CargaMasivaOperacionEmpresa X
    WHERE X.CEIdEmpresa = @IdEmpresa
      AND X.CEIdOperacion = I.IdOperacion
      AND X.CEIdEstatus = 1
    ORDER BY X.CEIdOperacionEmpresa DESC
) CE
LEFT JOIN dbo.ff_Plantilla P
    ON P.PLIdPlantilla = CE.CEIdPlantilla
   AND P.PLIdEstatus = 1
ORDER BY I.Orden;

/*
  BLOQUE 02: contenido listo para copiar/pegar o guardar como .txt.
  Cada fila corresponde exactamente a un tipo de carga del bloque anterior.
*/
SELECT
    '02_CONTENIDO_TXT_LISTO' AS Bloque,
    I.Orden,
    I.IdOperacion,
    CO.CONombre AS TipoCarga,
    I.Archivo,
    I.NumeroEmpleadoPrueba,
    CAST(
        '@commonFields:' + @CRLF +
        I.CamposComunes + @CRLF + @CRLF +
        '@fieldNames: ' + I.CamposRegistro + @CRLF +
        '@data:' + @CRLF +
        I.DatosRegistro
        AS VARCHAR(MAX)
    ) AS ContenidoTXT
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO
    ON CO.COIdOperacion = I.IdOperacion
ORDER BY I.Orden;

/* Campos reales y orden configurado en las plantillas de la base. */
SELECT
    '03_CAMPOS_REALES_PLANTILLA' AS Bloque,
    I.Orden,
    I.IdOperacion,
    CO.CONombre AS TipoCarga,
    CE.CEIdPlantilla,
    CP.CPOrden AS OrdenCampo,
    RTRIM(C.CANombreCampo) AS Campo,
    CP.CPRequerido AS Requerido,
    C.CATipoDato AS TipoDato,
    C.CALongitud AS Longitud
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO
    ON CO.COIdOperacion = I.IdOperacion
INNER JOIN dbo.ff_CargaMasivaOperacionEmpresa CE
    ON CE.CEIdEmpresa = @IdEmpresa
   AND CE.CEIdOperacion = I.IdOperacion
   AND CE.CEIdEstatus = 1
INNER JOIN dbo.ff_ConfiguracionPlantilla CP
    ON CP.PLIdPlantilla = CE.CEIdPlantilla
   AND CP.CPIdEstatus = 1
INNER JOIN dbo.ff_Campo C
    ON C.CAIdCampo = CP.CAIdCampo
   AND C.CAIdEstatus = 1
ORDER BY I.Orden, CP.CPOrden, CP.CPIdConfiguracionPlantilla;

/* Detecta futuras operaciones activas que todavia no tengan input preparado. */
SELECT
    '04_OPERACIONES_ACTIVAS_SIN_INPUT' AS Bloque,
    CE.CEIdOperacion,
    CO.CONombre AS TipoCarga,
    CE.CEIdPlantilla,
    CE.CEStoredProc
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
INNER JOIN dbo.ff_CargaMasivaOperacion CO
    ON CO.COIdOperacion = CE.CEIdOperacion
WHERE CE.CEIdEmpresa = @IdEmpresa
  AND CE.CEIdEstatus = 1
  AND NOT EXISTS
      (SELECT 1 FROM @Inputs I WHERE I.IdOperacion = CE.CEIdOperacion)
ORDER BY CE.CEIdOperacion;

SELECT
    '05_RESUMEN' AS Bloque,
    (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
     WHERE CEIdEmpresa = @IdEmpresa AND CEIdEstatus = 1) AS OperacionesActivasBD,
    (SELECT COUNT(*) FROM @Inputs) AS InputsPreparados,
    CASE
        WHEN NOT EXISTS
        (
            SELECT 1
            FROM dbo.ff_CargaMasivaOperacionEmpresa CE
            WHERE CE.CEIdEmpresa = @IdEmpresa
              AND CE.CEIdEstatus = 1
              AND NOT EXISTS
                  (SELECT 1 FROM @Inputs I WHERE I.IdOperacion = CE.CEIdOperacion)
        ) THEN 'OK: TODAS LAS OPERACIONES ACTIVAS TIENEN INPUT TXT'
        ELSE 'REVISAR: EXISTEN OPERACIONES ACTIVAS SIN INPUT'
    END AS Resultado;
GO
