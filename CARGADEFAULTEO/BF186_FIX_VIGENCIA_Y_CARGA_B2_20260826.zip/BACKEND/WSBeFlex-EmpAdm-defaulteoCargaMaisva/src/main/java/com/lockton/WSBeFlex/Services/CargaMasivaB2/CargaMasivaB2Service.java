package com.lockton.WSBeFlex.Services.CargaMasivaB2;

import com.lockton.WSBeFlex.DAO.CargaMasivaB2DAO;
import com.lockton.WSBeFlex.DAO.FfCargaMasivaDAO;
import com.lockton.WSBeFlex.Services.CargaMasivaFlujoService;
import com.lockton.WSBeFlex.Services.Crypto.CryptoBeflexService;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class CargaMasivaB2Service {
    private static final DateTimeFormatter FECHA_B2 = DateTimeFormatter
            .ofPattern("dd/MM/uuuu", new Locale("es", "MX"))
            .withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter FECHA_LOG = DateTimeFormatter
            .ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private final CargaMasivaTxtParser parser;
    private final CargaMasivaB2DAO dao;
    private final CargaMasivaFlujoService flujoService;
    private final CryptoBeflexService crypto;
    private final FfCargaMasivaDAO cargaMasivaLegacy;

    public CargaMasivaB2Service(CargaMasivaB2DAO dao,
                                CargaMasivaFlujoService flujoService,
                                CryptoBeflexService crypto,
                                FfCargaMasivaDAO cargaMasivaLegacy) {
        this.parser = new CargaMasivaTxtParser();
        this.dao = dao;
        this.flujoService = flujoService;
        this.crypto = crypto;
        this.cargaMasivaLegacy = cargaMasivaLegacy;
    }

    public Map<String, Object> ejecutar(int idEmpresa, int idOperacion, String modo,
                                        MultipartFile archivo, int idUsuario,
                                        String idTraza) throws Exception {
        long inicioCarga = System.currentTimeMillis();
        validarEntrada(idEmpresa, idOperacion, modo, archivo, idUsuario);
        Map<String, Object> resolucion = flujoService.resolver(idEmpresa, "PANTALLA");
        if (!"B2".equalsIgnoreCase(String.valueOf(resolucion.get("flujo")))) {
            throw new IllegalArgumentException("La pantalla no esta configurada para ejecutar el flujo B2.");
        }

        CargaMasivaTxtDocumento documento = parser.parse(archivo.getBytes());
        Map<String, Object> operacion = dao.obtenerOperacion(idEmpresa, idOperacion);
        int idPlantilla = ((Number) operacion.get("CEIdPlantilla")).intValue();
        String procedimiento = String.valueOf(operacion.get("CEStoredProc"));
        String nombreOperacion = texto(valor(operacion, "CONombre"),
                "Operacion " + idOperacion).trim();
        List<Map<String, Object>> campos = dao.obtenerCamposPlantilla(idPlantilla);
        if (campos.isEmpty()) throw new IllegalArgumentException("La plantilla B2 no tiene campos activos.");
        validarEncabezados(documento, campos);

        List<String> log = new ArrayList<>();
        List<Map<String, Object>> resultados = new ArrayList<>();
        Map<String, Map<String, String>> rangos = cargarRangos(campos, idEmpresa);
        boolean continuarErrores = "TODOS".equalsIgnoreCase(modo);
        String nombreArchivo = nombreArchivoSeguro(archivo.getOriginalFilename());
        List<String> camposRegistro = new ArrayList<>(documento.getNombresCampo().subList(
                0, documento.getNombresCampo().size() - documento.getCamposComunes().size()));
        registrar(log, idTraza, idEmpresa, "INICIO",
                "Archivo='" + nombreArchivo + "'; tamano=" + archivo.getSize()
                + " bytes; usuario=" + idUsuario + "; modo=" + modo + ".");
        registrar(log, idTraza, idEmpresa, "CONFIGURACION",
                "Operacion=" + idOperacion + " ('" + nombreOperacion + "'); plantilla="
                + idPlantilla + "; procedimiento=" + procedimiento + ".");
        registrar(log, idTraza, idEmpresa, "ESTRUCTURA_TXT",
                "Registros=" + documento.getRegistros().size()
                + "; campos comunes=" + documento.getCamposComunes().size()
                + " [" + nombres(documento.getCamposComunes().keySet()) + "]"
                + "; campos por registro=" + camposRegistro.size()
                + " [" + nombres(camposRegistro) + "].");
        registrar(log, idTraza, idEmpresa, "VALIDACIONES_B2",
                "Plantilla activa con " + campos.size() + " campos; catalogos especificos="
                + rangos.size() + "; politica de errores="
                + (continuarErrores ? "CONTINUAR_TODOS" : "DETENER_PRIMER_ERROR") + ".");
        registrar(log, idTraza, idEmpresa, "CONTEXTO_SEGURO",
                "EMIdEmpresa=" + idEmpresa + " y EMUsuarioUMod=" + idUsuario
                + " se obtienen de la solicitud autenticada. EMEmpresa, cuando la plantilla"
                + " legacy lo define, se conserva como clave externa.");
        int correctos = 0;
        int errores = 0;

        for (int i = 0; i < documento.getRegistros().size(); i++) {
            int renglon = i + 1;
            long inicioRenglon = System.currentTimeMillis();
            String etapa = "VALIDACION_CAMPOS";
            Map<String, Object> resultadoFila = new LinkedHashMap<>();
            resultadoFila.put("renglon", renglon);
            try {
                Map<String, String> valores = unir(documento.getNombresCampo(),
                        documento.getRegistros().get(i));
                Map<String, Object> parametros = validarYConvertir(campos, valores, rangos);
                // B2 obtiene ambos valores del contexto de la sesion. En BF3 se
                // fuerzan desde la solicitud ya autorizada: EMEmpresa puede ser
                // una clave legacy (por ejemplo 186edf), mientras que los SP
                // actuales requieren tambien el identificador interno entero.
                parametros.put("EMIdEmpresa", idEmpresa);
                parametros.put("EMUsuarioUMod", idUsuario);

                etapa = "EJECUCION_SP";
                Map<String, Object> primeraFila;
                if (esTransferencia(procedimiento)) {
                    primeraFila = cargaMasivaLegacy.procesarTransferenciaMasiva(
                            normalizarFechas(parametros), procedimiento);
                } else {
                    Map<String, Object> respuestaSp = dao.ejecutarOperacion(procedimiento, parametros);
                    primeraFila = dao.primeraFila(respuestaSp);
                }

                etapa = "INTERPRETACION_RESPUESTA";
                RespuestaSp respuesta = interpretarRespuesta(operacion, primeraFila);
                int codigo = respuesta.codigoNormalizado;
                String mensaje = respuesta.mensaje;
                resultadoFila.put("code", codigo);
                resultadoFila.put("spCode", respuesta.codigoOriginal);
                resultadoFila.put("msg", mensaje);
                resultadoFila.put("etapa", codigo == 0 ? "FINALIZADO" : "RESPUESTA_SP");
                resultadoFila.put("duracionMs", System.currentTimeMillis() - inicioRenglon);
                if (codigo == 0) {
                    correctos++;
                    registrar(log, idTraza, idEmpresa, "RENGLON_OK",
                            "Renglon=" + renglon + "/" + documento.getRegistros().size()
                            + "; validacion=OK; procedimiento=" + procedimiento
                            + "; codigoSP=" + respuesta.codigoOriginal
                            + "; duracion=" + (System.currentTimeMillis() - inicioRenglon)
                            + " ms; mensaje='" + mensajeLogSeguro(mensaje) + "'.");
                } else {
                    errores++;
                    registrar(log, idTraza, idEmpresa, "RENGLON_ERROR_SP",
                            "Renglon=" + renglon + "/" + documento.getRegistros().size()
                            + "; validacion=OK; procedimiento=" + procedimiento
                            + "; codigoSP=" + respuesta.codigoOriginal
                            + "; duracion=" + (System.currentTimeMillis() - inicioRenglon)
                            + " ms; mensaje='" + mensajeLogSeguro(mensaje) + "'.");
                    if (!continuarErrores) {
                        resultados.add(resultadoFila);
                        break;
                    }
                }
            } catch (Exception e) {
                errores++;
                resultadoFila.put("code", -1);
                resultadoFila.put("msg", mensajeSeguro(e));
                resultadoFila.put("etapa", etapa);
                resultadoFila.put("duracionMs", System.currentTimeMillis() - inicioRenglon);
                registrar(log, idTraza, idEmpresa, "RENGLON_ERROR",
                        "Renglon=" + renglon + "/" + documento.getRegistros().size()
                        + "; etapa=" + etapa + "; procedimiento=" + procedimiento
                        + "; duracion=" + (System.currentTimeMillis() - inicioRenglon)
                        + " ms; mensaje='" + mensajeLogSeguro(mensajeSeguro(e)) + "'.");
                if (!continuarErrores) {
                    resultados.add(resultadoFila);
                    break;
                }
            }
            resultados.add(resultadoFila);
        }

        int omitidos = documento.getRegistros().size() - resultados.size();
        long duracionCarga = System.currentTimeMillis() - inicioCarga;
        registrar(log, idTraza, idEmpresa, "RESUMEN",
                "Resultado=" + (errores == 0 ? "OK" : "CON_ERRORES")
                + "; total=" + documento.getRegistros().size()
                + "; procesados=" + resultados.size() + "; correctos=" + correctos
                + "; errores=" + errores + "; omitidos=" + omitidos
                + "; duracionTotal=" + duracionCarga + " ms.");

        Map<String, Object> salida = new LinkedHashMap<>();
        salida.put("idTraza", idTraza);
        salida.put("idEmpresa", idEmpresa);
        salida.put("idOperacion", idOperacion);
        salida.put("idPlantilla", idPlantilla);
        salida.put("procedimiento", procedimiento);
        salida.put("nombreOperacion", nombreOperacion);
        salida.put("nombreArchivo", nombreArchivo);
        salida.put("tamanioArchivoBytes", archivo.getSize());
        salida.put("modo", modo.toUpperCase(Locale.ROOT));
        salida.put("camposComunes", new ArrayList<>(documento.getCamposComunes().keySet()));
        salida.put("camposPorRegistro", camposRegistro);
        salida.put("total", documento.getRegistros().size());
        salida.put("procesados", resultados.size());
        salida.put("correctos", correctos);
        salida.put("errores", errores);
        salida.put("omitidos", omitidos);
        salida.put("duracionMs", duracionCarga);
        salida.put("resultado", errores == 0 ? "OK" : "CON_ERRORES");
        salida.put("registros", resultados);
        salida.put("log", log);
        return salida;
    }

    private void validarEntrada(int idEmpresa, int idOperacion, String modo,
                                MultipartFile archivo, int idUsuario) {
        if (idEmpresa <= 0 || idOperacion <= 0) throw new IllegalArgumentException("Empresa y operacion son obligatorias.");
        if (idUsuario <= 0) throw new IllegalArgumentException("No fue posible identificar al usuario autenticado.");
        if (!"PRIMER_ERROR".equalsIgnoreCase(modo) && !"TODOS".equalsIgnoreCase(modo)) {
            throw new IllegalArgumentException("Modo de ejecucion invalido.");
        }
        if (archivo == null || archivo.isEmpty()) throw new IllegalArgumentException("Seleccione un archivo TXT.");
        String nombre = archivo.getOriginalFilename();
        if (nombre == null || !nombre.toLowerCase().endsWith(".txt")) {
            throw new IllegalArgumentException("Solo se permiten archivos .txt.");
        }
    }

    private void validarEncabezados(CargaMasivaTxtDocumento documento, List<Map<String, Object>> campos) {
        for (Map<String, Object> campo : campos) {
            String nombre = requerido(campo, "CANombreCampo");
            if (!documento.getNombresCampo().contains(nombre.trim())) {
                throw new IllegalArgumentException("La plantilla define el campo '" + nombre
                        + "', pero el TXT no lo incluye.");
            }
        }
    }

    private Map<String, Map<String, String>> cargarRangos(List<Map<String, Object>> campos, int idEmpresa) {
        Map<String, Map<String, String>> rangos = new HashMap<>();
        for (Map<String, Object> campo : campos) {
            if ("Especifico".equals(requerido(campo, "CATipoValor"))) {
                String declaracion = requerido(campo, "CPRangoValores");
                rangos.put(requerido(campo, "CANombreCampo"), dao.obtenerRango(declaracion, idEmpresa));
            }
        }
        return rangos;
    }

    private Map<String, Object> validarYConvertir(List<Map<String, Object>> campos,
                                                   Map<String, String> valores,
                                                   Map<String, Map<String, String>> rangos) {
        Map<String, Object> parametros = new LinkedHashMap<>();
        for (Map<String, Object> campo : campos) {
            String nombre = requerido(campo, "CANombreCampo");
            String valor = valores.get(nombre);
            boolean obligatorio = entero(valor(campo, "CPRequerido"), 0) == 1;
            if (valor == null) throw new IllegalArgumentException("Falta el campo " + nombre + ".");
            if (valor.isEmpty()) {
                if (obligatorio) throw new IllegalArgumentException("El campo " + nombre + " requiere un valor.");
                parametros.put(nombre, ""); // el proceso B2 convierte el nulo opcional en cadena vacia
                continue;
            }
            String regex = texto(valor(campo, "CACaracteresValidos"), "").trim();
            if (!regex.isEmpty() && !Pattern.compile(regex).matcher(valor).find()) {
                throw new IllegalArgumentException("El campo " + nombre + " no cumple el formato configurado.");
            }
            if ("Especifico".equals(texto(valor(campo, "CATipoValor"), ""))) {
                String equivalencia = rangos.getOrDefault(nombre, new HashMap<>()).get(valor);
                if (equivalencia == null) {
                    throw new IllegalArgumentException("El campo " + nombre
                            + " no tiene equivalencia para el valor '" + valor + "'.");
                }
                valor = equivalencia;
            }
            String tipo = requerido(campo, "CATipoDato");
            if ("T".equals(tipo) && entero(valor(campo, "CPEncriptado"), 0) == 1) {
                valor = crypto.encriptar(valor);
                if (valor == null) throw new IllegalArgumentException("No fue posible encriptar " + nombre + ".");
            }
            parametros.put(nombre, convertir(tipo, valor, nombre));
        }
        return parametros;
    }

    private boolean esTransferencia(String procedimiento) {
        String limpio = procedimiento == null ? "" : procedimiento.trim()
                .replace("[", "").replace("]", "");
        if (limpio.toLowerCase(Locale.ROOT).startsWith("dbo.")) limpio = limpio.substring(4);
        return "ff_transferenciaMasivaEmpleado".equalsIgnoreCase(limpio);
    }

    /**
     * El adaptador legado serializa estos parametros a JSON. Las fechas SQL se
     * convierten a ISO para conservar el contrato usado por el SP de transferencia.
     */
    private Map<String, Object> normalizarFechas(Map<String, Object> parametros) {
        Map<String, Object> salida = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : parametros.entrySet()) {
            Object value = entry.getValue();
            salida.put(entry.getKey(), value instanceof Date ? value.toString() : value);
        }
        return salida;
    }

    private RespuestaSp interpretarRespuesta(Map<String, Object> operacion,
                                               Map<String, Object> fila) {
        if (fila == null || fila.isEmpty()) {
            return new RespuestaSp(-1, -1, "El procedimiento no devolvio resultado.");
        }

        Object valorCodigo = dao.valor(fila, "Return_Code");
        String contrato = "Return_Code";
        if (valorCodigo == null) {
            valorCodigo = dao.valor(fila, "codigo");
            contrato = "codigo";
        }
        if (valorCodigo == null) {
            valorCodigo = dao.valor(fila, "code");
            contrato = "code";
        }

        int original;
        int normalizado;
        if (valorCodigo == null) {
            original = soporta(operacion, "Return_Code") ? -1 : 0;
            normalizado = original;
        } else {
            original = entero(valorCodigo, -1);
            boolean exito = "Return_Code".equals(contrato)
                    ? original == 0
                    : original == 1 || original == 200;
            normalizado = exito ? 0 : original == 0 ? -1 : original;
        }

        Object valorMensaje = dao.valor(fila, "Return_Msg");
        if (valorMensaje == null) valorMensaje = dao.valor(fila, "mensaje");
        if (valorMensaje == null) valorMensaje = dao.valor(fila, "msg");
        String mensaje = texto(valorMensaje, normalizado == 0
                ? "Registro procesado correctamente."
                : "El procedimiento no devolvio un mensaje de error.");
        return new RespuestaSp(normalizado, original, mensaje);
    }

    private Object convertir(String tipo, String valor, String nombre) {
        try {
            switch (tipo.charAt(0)) {
                case 'T': return valor;
                case 'E': case 'N': case 'B': return Integer.valueOf(valor.trim());
                case 'D': return Date.valueOf(LocalDate.parse(valor.trim(), FECHA_B2));
                case 'M': case '%': case 'F': return new BigDecimal(valor.trim().replace(',', '.'));
                default: throw new IllegalArgumentException("Tipo B2 no reconocido: " + tipo + ".");
            }
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("El campo " + nombre + " no es valido para el tipo " + tipo + ".");
        }
    }

    private Map<String, String> unir(List<String> nombres, List<String> datos) {
        Map<String, String> salida = new LinkedHashMap<>();
        for (int i = 0; i < nombres.size(); i++) salida.put(nombres.get(i), datos.get(i));
        return salida;
    }

    private boolean soporta(Map<String, Object> operacion, String nombre) {
        Object value = valor(operacion, nombre);
        if (value instanceof Boolean) return (Boolean) value;
        if (value instanceof Number) return ((Number) value).intValue() != 0;
        return "true".equalsIgnoreCase(String.valueOf(value)) || "1".equals(String.valueOf(value));
    }

    private Object valor(Map<String, Object> mapa, String nombre) {
        for (Map.Entry<String, Object> entry : mapa.entrySet()) {
            if (nombre.equalsIgnoreCase(entry.getKey())) return entry.getValue();
        }
        return null;
    }

    private String requerido(Map<String, Object> mapa, String nombre) {
        Object value = valor(mapa, nombre);
        if (value == null) throw new IllegalArgumentException("La configuracion B2 no devolvio " + nombre + ".");
        return String.valueOf(value).trim();
    }

    private int entero(Object value, int defecto) {
        if (value instanceof Number) return ((Number) value).intValue();
        try { return value == null ? defecto : Integer.parseInt(String.valueOf(value)); }
        catch (NumberFormatException e) { return defecto; }
    }

    private String texto(Object value, String defecto) { return value == null ? defecto : String.valueOf(value); }
    private void registrar(List<String> log, String idTraza, int idEmpresa,
                           String etapa, String detalle) {
        log.add("[" + LocalDateTime.now().format(FECHA_LOG) + "]"
                + " [TRAZA:" + idTraza + "] [FLUJO:B2] [EMPRESA:" + idEmpresa + "]"
                + " [ETAPA:" + etapa + "] " + detalle);
    }

    private String nombres(Iterable<String> valores) {
        StringBuilder salida = new StringBuilder();
        for (String valor : valores) {
            if (salida.length() > 0) salida.append(", ");
            salida.append(valor);
        }
        return salida.toString();
    }

    private String nombreArchivoSeguro(String nombre) {
        String limpio = nombre == null ? "carga.txt" : nombre.replaceAll("[\\r\\n\\t]", "_").trim();
        if (limpio.isEmpty()) limpio = "carga.txt";
        return limpio.length() <= 150 ? limpio : limpio.substring(0, 150);
    }

    private String mensajeLogSeguro(String mensaje) {
        String limpio = mensaje == null ? "Sin mensaje" : mensaje.replaceAll("[\\r\\n\\t]", " ").trim();
        return limpio.length() <= 500 ? limpio : limpio.substring(0, 500) + "...";
    }

    private String mensajeSeguro(Exception e) {
        String mensaje = e.getMessage();
        return mensaje == null || mensaje.trim().isEmpty() ? "Error no identificado durante la carga." : mensaje;
    }

    private static final class RespuestaSp {
        private final int codigoNormalizado;
        private final int codigoOriginal;
        private final String mensaje;

        private RespuestaSp(int codigoNormalizado, int codigoOriginal, String mensaje) {
            this.codigoNormalizado = codigoNormalizado;
            this.codigoOriginal = codigoOriginal;
            this.mensaje = mensaje;
        }
    }
}
