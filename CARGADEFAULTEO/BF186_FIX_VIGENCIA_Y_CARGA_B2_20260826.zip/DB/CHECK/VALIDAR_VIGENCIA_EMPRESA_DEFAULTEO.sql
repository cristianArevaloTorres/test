/*
  DIAGNOSTICO DE VIGENCIA PARA DEFAULTEO 1, 2 Y 3

  Solo lectura. No inserta, actualiza ni elimina datos.

  La regla que usa el backend es:
      ff_Empleado.EMIdEmpresa
        -> ff_Empresa.EMIdConfiguracion
        = ff_Vigencia.VIIdConfiguracion

  Si una operacion contiene empleados de varias empresas, la vigencia elegida
  debe pertenecer a la configuracion de CADA empresa procesada.

  USO:
  1. Capture en @IdVigencia el ID que aparece seleccionado en la pantalla.
  2. En @IdsEmpresas indique una o varias empresas separadas por coma.
  3. Opcionalmente capture @IdEmpleado o @NumeroEmpleado para revisar el
     registro exacto que fallo.
  4. Ejecute todo el archivo y revise primero 02_VALIDACION_EMPRESA_VIGENCIA.
*/
SET NOCOUNT ON;

/* ===================== PARAMETROS EDITABLES ====================== */
DECLARE @IdsEmpresas     NVARCHAR(MAX) = N'186';
DECLARE @IdVigencia      INT           = NULL; -- OBLIGATORIO para validar la seleccion de pantalla.
DECLARE @IdEmpleado      INT           = NULL; -- Opcional.
DECLARE @NumeroEmpleado  VARCHAR(50)   = NULL; -- Opcional; usar si no conoce el ID interno.
/* ================================================================= */

DECLARE @Empresas TABLE
(
    IdEmpresa INT NOT NULL PRIMARY KEY
);

INSERT @Empresas (IdEmpresa)
SELECT DISTINCT TRY_CONVERT(INT, LTRIM(RTRIM(value)))
FROM STRING_SPLIT(@IdsEmpresas, ',')
WHERE TRY_CONVERT(INT, LTRIM(RTRIM(value))) IS NOT NULL;

SELECT
    '00_PARAMETROS' AS Bloque,
    @IdsEmpresas AS EmpresasCapturadas,
    @IdVigencia AS IdVigenciaSeleccionada,
    @IdEmpleado AS IdEmpleado,
    @NumeroEmpleado AS NumeroEmpleado,
    CASE
        WHEN NOT EXISTS (SELECT 1 FROM @Empresas)
            THEN 'REVISAR: CAPTURE AL MENOS UNA EMPRESA VALIDA'
        WHEN @IdVigencia IS NULL
            THEN 'REVISAR: CAPTURE EL ID DE VIGENCIA SELECCIONADO EN BF3'
        ELSE 'PARAMETROS LISTOS'
    END AS Resultado;

/*
  Este es el resultado principal. Debe devolver OK para todas las empresas
  cuyos empleados se quieran incluir en la misma ejecucion.
*/
SELECT
    '02_VALIDACION_EMPRESA_VIGENCIA' AS Bloque,
    x.IdEmpresa,
    e.EMNombre AS Empresa,
    e.EMIdEstatus AS EstatusEmpresa,
    e.EMIdConfiguracion AS ConfiguracionEmpresa,
    @IdVigencia AS IdVigenciaSeleccionada,
    v.VIIdConfiguracion AS ConfiguracionVigencia,
    v.VIIdEstatus AS EstatusVigencia,
    v.VIVigenciaIni AS InicioVigencia,
    v.VIVigenciaFin AS FinVigencia,
    CASE
        WHEN e.EMIdEmpresa IS NULL
            THEN 'ERROR: LA EMPRESA NO EXISTE'
        WHEN e.EMIdEstatus <> 1
            THEN 'ERROR: LA EMPRESA ESTA INACTIVA'
        WHEN @IdVigencia IS NULL
            THEN 'NO EVALUADO: CAPTURE @IdVigencia'
        WHEN v.VIIdVigencia IS NULL
            THEN 'ERROR: LA VIGENCIA NO EXISTE'
        WHEN v.VIIdEstatus <> 1
            THEN 'ERROR: LA VIGENCIA ESTA INACTIVA'
        WHEN e.EMIdConfiguracion IS NULL
            THEN 'ERROR: LA EMPRESA NO TIENE CONFIGURACION'
        WHEN v.VIIdConfiguracion = e.EMIdConfiguracion
            THEN 'OK: LA VIGENCIA PERTENECE A LA EMPRESA'
        ELSE 'ERROR: LA VIGENCIA NO PERTENECE A LA CONFIGURACION DE LA EMPRESA'
    END AS Resultado
FROM @Empresas x
LEFT JOIN dbo.ff_Empresa e
    ON e.EMIdEmpresa = x.IdEmpresa
LEFT JOIN dbo.ff_Vigencia v
    ON v.VIIdVigencia = @IdVigencia
ORDER BY x.IdEmpresa;

/*
  Alternativas correctas: muestra las vigencias activas que SI corresponden
  a cada empresa indicada. Use uno de estos IDs en la pantalla.
*/
SELECT
    '03_VIGENCIAS_VALIDAS_POR_EMPRESA' AS Bloque,
    e.EMIdEmpresa AS IdEmpresa,
    e.EMNombre AS Empresa,
    e.EMIdConfiguracion AS ConfiguracionEmpresa,
    v.VIIdVigencia AS IdVigenciaValida,
    v.VIVigenciaIni AS InicioVigencia,
    v.VIVigenciaFin AS FinVigencia,
    v.VIRenovada AS IdVigenciaAnterior,
    CASE WHEN v.VIIdVigencia = @IdVigencia
         THEN 'SELECCIONADA EN BF3'
         ELSE 'DISPONIBLE'
    END AS Seleccion
FROM @Empresas x
INNER JOIN dbo.ff_Empresa e
    ON e.EMIdEmpresa = x.IdEmpresa
   AND e.EMIdEstatus = 1
INNER JOIN dbo.ff_Vigencia v
    ON v.VIIdConfiguracion = e.EMIdConfiguracion
   AND v.VIIdEstatus = 1
ORDER BY e.EMIdEmpresa, v.VIVigenciaIni DESC, v.VIIdVigencia DESC;

/*
  Diagnostico del empleado exacto. Es importante usar su empresa real, no
  solamente la empresa de la sesion del administrador.
*/
SELECT
    '04_VALIDACION_EMPLEADO' AS Bloque,
    em.Id AS IdEmpleado,
    em.EMNumeroEmpleado AS NumeroEmpleado,
    LTRIM(RTRIM(
        ISNULL(em.EMNombre1, '') + ' ' + ISNULL(em.EMNombre2, '') + ' '
        + ISNULL(em.EMApellidoPaterno, '') + ' ' + ISNULL(em.EMApellidoMaterno, '')
    )) AS Empleado,
    em.EMIdEmpresa AS IdEmpresaRealEmpleado,
    emp.EMNombre AS EmpresaRealEmpleado,
    emp.EMIdConfiguracion AS ConfiguracionEmpresa,
    @IdVigencia AS IdVigenciaSeleccionada,
    vig.VIIdConfiguracion AS ConfiguracionVigencia,
    CASE
        WHEN @IdVigencia IS NULL
            THEN 'NO EVALUADO: CAPTURE @IdVigencia'
        WHEN vig.VIIdVigencia IS NULL
            THEN 'ERROR: LA VIGENCIA NO EXISTE'
        WHEN emp.EMIdConfiguracion = vig.VIIdConfiguracion
             AND emp.EMIdEstatus = 1
             AND vig.VIIdEstatus = 1
            THEN 'OK: EL EMPLEADO PUEDE PROCESARSE CON ESTA VIGENCIA'
        ELSE 'ERROR: ESTE EMPLEADO NO PUEDE PROCESARSE CON ESTA VIGENCIA'
    END AS Resultado
FROM dbo.ff_Empleado em
INNER JOIN dbo.ff_Empresa emp
    ON emp.EMIdEmpresa = em.EMIdEmpresa
LEFT JOIN dbo.ff_Vigencia vig
    ON vig.VIIdVigencia = @IdVigencia
WHERE
    (@IdEmpleado IS NOT NULL AND em.Id = @IdEmpleado)
    OR
    (@IdEmpleado IS NULL
     AND NULLIF(LTRIM(RTRIM(@NumeroEmpleado)), '') IS NOT NULL
     AND em.EMNumeroEmpleado = LTRIM(RTRIM(@NumeroEmpleado)))
ORDER BY em.Id;

/*
  Dimensiona el efecto de la regla en los titulares activos de las empresas
  indicadas. Compatible = puede mostrarse/procesarse; incompatible = debe
  seleccionar otra vigencia o revisar la configuracion de la empresa.
*/
SELECT
    '05_RESUMEN_TITULARES' AS Bloque,
    em.EMIdEmpresa AS IdEmpresa,
    emp.EMNombre AS Empresa,
    COUNT_BIG(*) AS TitularesActivos,
    SUM(CASE WHEN vig.VIIdVigencia IS NOT NULL THEN CONVERT(BIGINT, 1)
             ELSE CONVERT(BIGINT, 0) END) AS CompatiblesConVigencia,
    SUM(CASE WHEN vig.VIIdVigencia IS NULL THEN CONVERT(BIGINT, 1)
             ELSE CONVERT(BIGINT, 0) END) AS IncompatiblesConVigencia
FROM dbo.ff_Empleado em
INNER JOIN @Empresas x
    ON x.IdEmpresa = em.EMIdEmpresa
INNER JOIN dbo.ff_Empresa emp
    ON emp.EMIdEmpresa = em.EMIdEmpresa
LEFT JOIN dbo.ff_Vigencia vig
    ON vig.VIIdVigencia = @IdVigencia
   AND vig.VIIdConfiguracion = emp.EMIdConfiguracion
   AND vig.VIIdEstatus = 1
WHERE em.EMIdTitular = 1
  AND em.EMIdEstatus = 1
GROUP BY em.EMIdEmpresa, emp.EMNombre
ORDER BY em.EMIdEmpresa;

PRINT 'La correccion no elimina esta validacion: evita que BF3 ofrezca registros incompatibles antes de procesarlos.';
GO
