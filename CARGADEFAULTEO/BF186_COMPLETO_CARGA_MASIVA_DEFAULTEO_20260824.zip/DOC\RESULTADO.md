# Validacion final - empresa 186

Fecha: 24 de agosto de 2026.

Ambiente SQL validado: `(localdb)\MSSQLLocalDB`, base `FlexiForbesv2`.

## Resultado

La homologacion conserva dos contratos distintos de carga:

- B3 usa plantillas Excel y ejecuta desde BF3.
- B2 usa documentos TXT con `@commonFields`, `@fieldNames` y `@data`, con
  valores separados por `|`. BF3 descarga una guia dinamica de la operacion,
  pero la ejecucion permanece en el modulo legacy B2.

No se modifico B2. El cambio nuevo de interfaz esta concentrado en B3; el WS
solo agrega correlacion segura para diagnosticar peticiones.

## Pruebas realizadas

| Area | Resultado |
|---|---|
| TypeScript BF3 | Correcto, sin errores |
| Build Angular BF3 | Correcto, bundles ES2015 y ES5 generados |
| API Reportes | 14/14 pruebas correctas |
| Filtro de correlacion WS | 2/2 pruebas correctas |
| Configuracion B2/B2 | Correcta dentro de transaccion |
| Configuracion B2/B3 | Correcta dentro de transaccion |
| Configuracion B3/B2 | Correcta dentro de transaccion |
| Configuracion B3/B3 | Correcta dentro de transaccion |
| Estado posterior a las simulaciones | `B3/B2`, igual al estado inicial |
| Defaulteo 1 | Motor ejecutado para `QADEF1-186` |
| Defaulteo 2 | Motor ejecutado para `QADEF2-186` |
| Defaulteo 3 sin dependientes | Motor ejecutado para `QADEF3C-186` |
| Defaulteo 3 con dependiente | Motor ejecutado para `QADEF3D-186` |
| Creacion de solicitud | `Antes=0`, `Durante=1`, `Despues=0`, resultado `OK` |
| Objetos SQL requeridos | Presentes y activos |
| Menu Defaulteo | ID 566 local, rol 570, ruta e imagen correctas |

Las pruebas que escriben utilizaron rollback. No se dejo una solicitud ni un
cambio de configuracion generado por esta revision.

## Correcciones incluidas

1. Selector visual B2/B3 con herramientas que cambian segun el flujo.
2. Guia TXT B2 generada a partir de los campos reales de la operacion.
3. Excel B3 conservado sin cambiar su logica de ejecucion.
4. Log visible y descargable aun antes de tener filas procesadas.
5. Respaldo de trazas finalizadas, canceladas, interrumpidas, con error o con
   validacion incompleta.
6. Correlacion HTTP hacia Java sin registrar credenciales ni datos del body.
7. Correccion del ciclo del modal de Defaulteo para que cierre aun si una
   solicitud individual falla y para evitar que el overlay quede bloqueado.
8. Exclusion SQL de empleados con solicitud activa o por autorizar; despues
   de generar correctamente la solicitud ya no aparecen como procesables.

Los empleados procesados se consultan en BF3 en **Administracion de
Solicitudes** (`/pages/administracion/solicitudes/administracion`). Una
solicitud cancelada o rechazada puede volver a habilitar el reproceso conforme
al estatus definido por la regla SQL.

## Limitacion conocida del ambiente

El ciclo Maven completo de `WSBeFlex` no puede generar los clientes SOAP sin
el WSDL privado configurado en el proyecto. Para no ocultar esa dependencia,
se compilaron de forma aislada el filtro y su prueba con el classpath Maven, y
se ejecutaron las dos pruebas correctamente. La aceptacion HTTP completa debe
repetirse en DEV/QA con el WSDL y los servicios internos disponibles.

No se ejecutaron cargas reales por HTTP en la empresa 186 porque eso produciria
datos funcionales. Los contratos de frontend, Java, Reportes y SQL se probaron
por separado y las operaciones SQL de escritura se revirtieron.
