# Paquete completo BF3 - Carga Masiva B2/B3 y Defaulteo 1/2/3

Fecha de cierre: 24 de agosto de 2026.

Este paquete contiene todos los cambios necesarios de BF3, WS Java, API de
Reportes y base de datos. Descomprima en una ruta corta, por ejemplo
`C:\TMP\BF186`, para evitar el limite `MAX_PATH` de Windows.

## Alcance

- Carga Masiva BF3 con seleccion independiente de flujo de pantalla y flujo
  automatico.
- Descarga Excel cuando la pantalla usa B3.
- Descarga de una guia TXT compatible con el parser B2 cuando la pantalla usa
  B2. La edicion, registro y ejecucion del documento siguen en el B2 legacy.
- Traza por ejecucion con identificador `CM-<empresa>-<fecha>-<aleatorio>`, log
  visible/descargable en BF3 y correlacion en las peticiones al WS.
- Defaulteo 1, 2 y 3, historico, exclusion de empleados que ya tienen una
  solicitud vigente y correccion del modal de generacion.
- Menu BF3 de Defaulteo para empresa 186 y rol 570.

## Instalacion

1. Respaldar los archivos que se sustituiran.
2. Reemplazar los archivos de `SRC/B3`, `SRC/WS` y `SRC/RPT` respetando la
   misma ruta dentro de cada proyecto.
3. Agregar los archivos nuevos del filtro y su prueba en `SRC/WS`.
4. Ejecutar `DB/INSTALL/ALL.sql` en SSMS solamente en ambientes que aun no
   tengan instalados los objetos. El instalador es idempotente.
5. Desplegar y reiniciar los componentes correspondientes.

No es necesario borrar archivos del frontend. Tampoco hay cambios que copiar
al proyecto B2 legacy, por lo que deliberadamente no existe una carpeta
`SRC/B2` en este paquete.

Los SQL de `DB/PRUEBAS` son diagnosticos y simulaciones independientes; no
forman parte de `DB/INSTALL/ALL.sql`. Los scripts dummy deben usarse solo en
DEV/QA.

## Mapa

| Carpeta | Destino |
|---|---|
| `SRC/B3` | Frontend Angular `BeFlex3-EmpAdm` |
| `SRC/WS` | Backend Java `WSBeFlex` |
| `SRC/RPT` | API Java de reportes |
| `DB/INSTALL` | Instalacion de objetos SQL |
| `DB/PRUEBAS` | Pruebas, menu, dummy y diagnosticos separados |
| `EJEMPLOS` | Archivos de referencia B2 y B3 |
| `DOC` | Resultado y guia de trazabilidad |

## Validacion ejecutada

- TypeScript: correcto.
- Build Angular completo: correcto.
- API Reportes: 14 pruebas, 0 fallas.
- Filtro de trazabilidad WS: 2 pruebas, 0 fallas.
- Base local empresa 186: cuatro combinaciones B2/B3 correctas y restauradas
  por rollback.
- Defaulteo 1, 2 y 3: motores ejecutados.
- Creacion de solicitud: `Durante=1`, `Despues=0` por rollback.
- Verificacion de objetos, menu y configuracion: correcta.

Consulte `DOC/RESULTADO.md` y `DOC/TRAZABILIDAD_CARGA_MASIVA.md` antes del
despliegue.
