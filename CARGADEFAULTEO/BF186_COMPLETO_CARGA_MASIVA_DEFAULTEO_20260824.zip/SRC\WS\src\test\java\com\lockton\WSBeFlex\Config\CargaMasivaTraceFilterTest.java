package com.lockton.WSBeFlex.Config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

class CargaMasivaTraceFilterTest {

    @Test
    void conservaLaCorrelacionEnLaRespuestaYLaLimpiaAlTerminar() throws Exception {
        CargaMasivaTraceFilter filter = new CargaMasivaTraceFilter();
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/beflex/titulares/nuevoTM");
        request.addHeader(CargaMasivaTraceFilter.HEADER, "CM-186-ABC123");
        MockHttpServletResponse response = new MockHttpServletResponse();

        filter.doFilter(request, response, new MockFilterChain());

        assertEquals("CM-186-ABC123", response.getHeader(CargaMasivaTraceFilter.HEADER));
        assertNull(MDC.get("cargaMasivaTraceId"));
    }

    @Test
    void ignoraUnaCorrelacionInvalida() throws Exception {
        CargaMasivaTraceFilter filter = new CargaMasivaTraceFilter();
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/beflex/titulares/op-masiva");
        request.addHeader(CargaMasivaTraceFilter.HEADER, "CM 186?token=NO");
        MockHttpServletResponse response = new MockHttpServletResponse();

        filter.doFilter(request, response, new MockFilterChain());

        assertNull(response.getHeader(CargaMasivaTraceFilter.HEADER));
        assertNull(MDC.get("cargaMasivaTraceId"));
    }
}
