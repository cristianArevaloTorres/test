import { Component, ViewEncapsulation, OnInit,ElementRef ,ViewChild,Input, Output, EventEmitter, ChangeDetectionStrategy, AfterContentInit } from '@angular/core';
import { EmpleadoService } from '../../../../services/empleado.service';
import { TitularesService } from '../../../../services/titulares.service';
import 'rxjs/add/observable/fromEvent';
import swal from 'sweetalert2';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { GLOBAL } from '../../../../services/global';
import { buscaPlanesPerfilService } from '../../../../services/buscaPlanesPerfil.service';

import { BeneficiarioService } from '../../../../services/beneficiario.service';
import { Bitacora } from '../../../../services/bitacora.service'
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { NgbModal,NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { ReporteCifrasControlService } from '../../../../services/cifrasControl/reporte-cifras-control.service';
import { DocumentosPerService } from '../../../../services/documentosPer/documentos-per.service';
import { ExcelService } from '../../../../services/excel.service';
import * as FileSaver from 'file-saver';
import { SelectItem } from 'primeng/api';
import { EmpresaComboService } from 'src/app/services/empresas.service';
import { BitacoraService } from 'src/app/services/bitacora-navegacion/bitacora.service';
declare var $:any;

type Option = { key: string; value: string };
@Component({
  selector: 'app-tabla-defaulteo',
  templateUrl: './tabla-defaulteo.component.html',
  styleUrls: ['./tabla-defaulteo.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [
    NgbModal, DatePipe
  ]
})
export class TablaDefaulteoComponent implements OnInit {

public planesDefaulteo;
public empleadosSeleccionados= [];
public titulares = 'Titulares';
public identity;
public token;
public tituloTabla;
public busquedaPor = 'numero';
public valorBusqueda: string;
public campoBusca: string;
public loadEditar = false;
public datosTabla = [null];
public datosTitul = [null];
public regex;
public errorEntrada;

public datosDefaulteo;
public procesoEnEjecucion=true;
public procesoFinalizado=false;
public urlWs;

public opcionesBusqueda = [
  {    nombre:'Número de empleado' , value: 'numero'},  
  {    nombre:'Primer nombre' , value: 'nombre'},
  {    nombre:'Segundo nombre' , value: 'nombre2'},
  {    nombre:'Apellido paterno' , value: 'paterno'},
  {    nombre:'Apellido materno' , value: 'materno'} 
]

public existenDatosTabla=false;
public msjNoHayDatos=false;

//variables defaulteo master


  //variables defaulteo master fin

  //variables defaulteo 
  public tipoDefaulteo;
  public seccionDefaulteo='none';
  public iconoCargando;
  public tipoBusqueda=-1;
  public componentBlock = false;
  public procesando;
  public reporte;

  public comboVigencias=[];

  public iconoAyuda;
  public textAyuda;

    public multivigencia= true;
    public idVigenciaSeleccionada=0;
    public idMultivigencia = 0;
    public idVigenciaVigente = 0;
    public fila=0;

    public datosCotizador;
    public datosCotizadorV3;
    public modal;
    public ejecutando;
    public numEmpleadoTmp;
    public modalReporte;
    public modalReporteElement;

    public page = 1;
    public pageSize = 10;
    public collectionSize = 0;
    @ViewChild('tiposPlanes') inputEl: ElementRef;
    
      
    /*variables multivigencia*/

  public correo = {
    correo: '',
    nombre: '',
    listado: []
  }
  public correosCopia:string = "";
  public empresaAccion;
  public correoAdmin="beflex@mx.lockton.com";

  public plantillaCorreo = "<DIV ALIGN='center'>" +
  "<FONT COLOR='black' SIZE='3' FACE='Arial'><B>#TipoNotificacion</B> </FONT> <BR> <BR>" +
  "<FONT COLOR='black' SIZE='2' FACE='Arial'>El administrador: #Administrador, ha ejecutado la asignación de planes." +
  " Favor de revisar el log de resultados .</FONT> <BR>" +
  "<FONT COLOR='black' SIZE='2' FACE='Arial'>Fecha y hora de fin del proceso: #Fecha</FONT> <BR>" +
  "<HR NOSHADE WIDTH='50%' COLOR='black'><BR>" +
  "</DIV>";

  /* Variables de busqueda avanzada */
  
  // Objeto de errrores
  public errorRep = {
    empresas: false,
    perfiles: false,
    parametroBusqueda1: false,
    parametroBusqueda2: false,
    estatusSolicitudes: false
  };
  public validRep = {
    empresas: false,
    perfiles: false,
    parametroBusqueda1: false,
    parametroBusqueda2: false,
    estatusSolicitudes: false
  };
  public arbol = [];
  public empresasRegistradas: any[] = [];
  public seleccionArbol: any[] = [];
  public tipoOperadorLogico: Option[] = [
    {'key': 'and', 'value':' Y '},
    {'key': 'or', 'value':' O '}
  ];
  public atributoEmpleado: Option[] = [ // Solo una seleccion
    {'key': 'EMNumeroEmpleado', 'value':'Número de empleado'},
    {'key': 'EMNombre1', 'value':'Primer nombre'},
    {'key': 'EMNombre2', 'value':'Segundo nombre'},
    {'key': 'EMApellidoPaterno', 'value':'Apellido paterno'},
    {'key': 'EMApellidoMaterno', 'value':'Apellido materno'}
  ];
  public tipoOperador: Option[] = [ // Solo una seleccion
    {'key': 'contiene', 'value':'Contiene'},
    {'key': 'igual', 'value':'Es igual a'},
    {'key': 'noigual', 'value':'No es igual a'}, // != o <>
    {'key': 'iniciapor', 'value':'Comienza por'},
    {'key': 'terminapor', 'value':'Termina con'},
    {'key': 'nocontiene', 'value':'No contiene'} // Not like
  ];
  public esBusquedaAvanzada: boolean = false;
  
  // Objeto de parametros seleccionados
  public parametrosBusqueda: IBusquedaRequest = {
    idEmpresas: [],
    perfiles: [],
    idAtributo1: 'EMNumeroEmpleado',
    idTipoOperador1: 'contiene',
    parametroBusqueda1: '',
    idTipoOperadorAvanzado: 'and',
    idAtributo2: 'EMNumeroEmpleado',
    idTipoOperador2: 'contiene',
    parametroBusqueda2: '',
    idEstatus: ['Rechazada','Autorizada','Por Autorizar','Cancelada'],
    idVigencia: 0,
    BusquedaAvanzada:0
  };

  constructor(
    private _titularesService: TitularesService,
    private _BuscarPlanesv2: buscaPlanesPerfilService,
    private _empleadoService: EmpleadoService,
    public _http: HttpClient,
    private _modalService: NgbModal,
    private datePipe: DatePipe,
    public _cifrasControlService: ReporteCifrasControlService,
    config: NgbModalConfig,
    private _docPerService : DocumentosPerService,
    public _excelService: ExcelService,
    private _empresaService: EmpresaComboService,
    public _BitacoraService: BitacoraService,
    ) {
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();
    this.errorEntrada = false;
    this.urlWs = GLOBAL.url;
    this.inicializarFormularioBusqueda();
    // config.backdrop = 'static';
    // config.keyboard = false;
  }

  async ngOnInit() {
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();
    this.consultaVigencias();
    this.obtenerPlanesDefaulteo();
    this.getDatosCorreo();
    this.getCorreosParaCopiaAdmin();
    await this.obtenerEmpresas();
  }


  ngOnDestroy() {
    swal.close();

    if(this.modal){
        this.modal.close();
    }

    if(this.modalReporte){
      this.modalReporte.close();
  }

  }

  seleccionarTodos($event){

    this.empleadosSeleccionados = [];

    if($event.target.checked == false){

      for(let i = 0; i < this.datosTabla.length; i++){

        for(let j = 0; j < this.datosTabla[i].length; j++){
          
          
          if(this.datosTabla[i][j].key == "seleccion"){
  
            this.datosTabla[i][j].value = false;
  
           
            
  
  
          }
  
  
        }
  
      }

    }else{

      for(let i = 0; i < this.datosTabla.length; i++){

        for(let j = 0; j < this.datosTabla[i].length; j++){
          
          
          if(this.datosTabla[i][j].key == "seleccion"){
  
            this.datosTabla[i][j].value = true;
  
            this.generarListaEmpleados(this.datosTabla[i]);
  
  
          }
  
  
        }
  
      }

    }

    

  }

  

  iniciarDefaulteo(modalProcesando,modalReporte){
    this.modalReporteElement = modalReporte;
    
    if(this.tipoDefaulteo == 1 || this.tipoDefaulteo == 2 || this.tipoDefaulteo == 3 ){
      if(this.empleadosSeleccionados.length > 0){
        swal({
          title: `¿Está seguro de defaultear los usuarios seleccionados?`,
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Aceptar',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
          if (result.value) {
            this.iconoCargando = true;
            this.ejecutando = true;
            if(!this.modal){
              this.modal = this._modalService.open(modalProcesando, {  backdrop : 'static',windowClass: 'confirmacionModal1', centered: true });
            }
            this.defaultearEmpleadosSeleccionadosModal(modalProcesando);
          }else{
            this.iconoCargando = false;
            this.ejecutando = false;
          }
        });
      } 
      else{
        Swal.fire({
          title: '¡Atención!',
          text: 'Favor de seleccionar un usuario',
          type: 'warning'
        });
        this.iconoCargando = false;
        this.ejecutando = false;
      } 
    }else{
      Swal.fire({
        title: '¡Atención!',
        text: 'Favor de completar el campo Tipo de Asignación de planes!',
        type: 'warning'
      });
      this.iconoCargando = false;
      this.ejecutando = false;
    }

  }

  obtenerTipoUrl(paso,idEmpleado,planesSeleccionados?){
      let datos = {
        url:null,
        datosGuardado:null

      }
        switch(+paso){

            //obtencion de planes
            case 1:

              if( (this.tipoDefaulteo == "2" || this.tipoDefaulteo == "1") && this.idVigenciaSeleccionada == this.idVigenciaVigente){
                datos.url = GLOBAL.url + "planesPerfil/empleado/" + idEmpleado + "/v3-1Defaulteo"
              }else if(this.tipoDefaulteo == "2" && this.idVigenciaSeleccionada != this.idVigenciaVigente){
                
                datos.url = GLOBAL.url + "planesPerfil/empleado/" + idEmpleado + "/v3-1DefaulteoMultivigencia/" + this.idVigenciaSeleccionada;
              }else{
                datos.url = GLOBAL.url + "planesPerfil/empleado/" + idEmpleado + "/v3-1DefaulteoMultivigencia/" + this.idMultivigencia;

              }

            break;
            //guardar planes
            case 2:

            if(this.identity.idEmpresa != 369){


              datos.datosGuardado =
              {
                "idEmpleado": this.datosCotizadorV3.declaraciones['idEmpleado'],
                "idEmpresa": this.datosCotizadorV3.declaraciones['idEmpresa'],
                "xmlPlanesSeleccionados": planesSeleccionados,
              }
              
              if ( (this.tipoDefaulteo == "2" || this.tipoDefaulteo == "1")  && this.idVigenciaSeleccionada == this.idVigenciaVigente) {
                datos.url = GLOBAL.url + "planesPerfil/tmp/";
              }else if(+this.tipoDefaulteo == 2 && this.idVigenciaSeleccionada != this.idVigenciaVigente){
                datos.url = GLOBAL.url + "planesPerfil/tmp/multivigencia/" + this.idVigenciaSeleccionada;

              }else {
                datos.url = GLOBAL.url + "planesPerfil/tmp/multivigencia/" + this.idMultivigencia;

              }


            }else{

              datos.datosGuardado =
                                        {
                                          "idEmpleado": this.datosCotizadorV3.declaraciones['idEmpleado'],
                                          "idEmpresa": this.datosCotizadorV3.declaraciones['idEmpresa'],
                                          "xmlPlanesSeleccionados": planesSeleccionados,
                                          "cantidadPago": this.datosCotizadorV3.declaraciones['cantidadPago'],
                                          "idConfiguracion": this.datosCotizadorV3.declaraciones['idConfiguracion'],
                                          "idPerfil": this.datosCotizadorV3.declaraciones['idPerfil'],
                                          "idPeriodicidadPago": this.datosCotizadorV3.datosIniciales['idPeriocidadPago'],
                                          "idVigencia": this.datosCotizadorV3.declaraciones['idVigencia'],
                                          "numeroEmpleado": this.datosCotizadorV3.declaraciones['numeroEmpleado'],
                                          "periodicidadNombre": this.datosCotizadorV3.declaraciones['peridicidadNombre']
                                        }

              if (+this.tipoDefaulteo == 2 && this.idVigenciaSeleccionada == this.idVigenciaVigente) {
                datos.url = GLOBAL.url + "planesPerfil/v2/tmp";
              } else {
                datos.url = GLOBAL.url + "planesPerfil/v2/tmp/" + this.idMultivigencia;

              }

                
              
            }



            break;

        }


        return datos;

  }

  recuperarPlanes(idEmpleado,idVigenciaTarifas){

    let defaulteo;
    switch(+this.tipoDefaulteo){
      case 1:
        defaulteo = 'def1';
        break;
      case 2:
        defaulteo = 'def2';
        break;
      case 3:
        defaulteo = 'def1';
        break;

    }

    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    let urlWs = GLOBAL.url;
    let inicio = {
      "idEmpresa": this.identity.idEmpresa,
      "planesSeleccionados": [
        {
          "costo": null,
          "idempleado": -1,
          "nuevo": null,
          "tcidtarifacosto": -1
        }
      ],
      "planesSeleccionadosOld": [
        {
          "costoOld": null,
          "idempleadoOld": -1,
          "nuevoOld": null,
          "tcidtarifacostoOld": -1
        }
      ],
      "transfer": defaulteo
    }

    


    // let buscaPlanes = urlWs + "planesPerfil/empleado/" + idEmpleado + "/v3-1DefaulteoMultivigencia/" + idVigenciaTarifas;
    let datos = this.obtenerTipoUrl(1,idEmpleado);


    this._http.post(datos.url,
      JSON.stringify(inicio),
      { headers: getHeaders }
    ).subscribe(
      response => {
          let respuesta;

          respuesta = response;


          if(respuesta.datosCotizador && respuesta.boton){

            this.datosCotizador = response;
            this.recuperarPlanesV3(idEmpleado,this.token);

          }else{

            this.reporte.push(`numero de empleado ${this.numEmpleadoTmp}:error \n`);
            this.fila++;
            this.defaultearEmpleadosSeleccionadosModal("",this.fila);

          }
           

         
      
      }, error => {
     
      }
    );


  }



  recuperarPlanesV3(idEmpleado,token){


    this._BuscarPlanesv2.getPlanesPerfilV3(idEmpleado, token).then(
      response => {

        this.datosCotizadorV3 = response;

          this.guardarPlanesSeleccionados();

      },
      error => {

       


      }
    );
  
  
  }


  guardarPlanesSeleccionados(){

    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });

    let datosCotizador = this.datosCotizador.datosCotizador;
    
    let planesSeleccionados = "<ROOT>";
    for (let i = 0; i < datosCotizador.length; i++) {
      if (datosCotizador[i]['checked'] == "true") {
        const cantidad = this.datosCotizadorV3.declaraciones['cantidadPago'];
        const idTC = datosCotizador[i]['tcIdTarifaCosto'];
        var PT = datosCotizador[i]['tcPrimaTotal'];
        PT = parseFloat(PT).toFixed(4)
        const id = datosCotizador[i]['id'];
        planesSeleccionados += "<TarifaCosto TCidTarifaCosto=\"" + idTC + "\" Costo=\"" + PT + "\" idEmpleado=\"" + id + "\"></TarifaCosto>";
      }
    }
    planesSeleccionados += "</ROOT>";
    
    // let urlInsertarPlanesTmp = this.urlWs + "planesPerfil/v2/tmp/" + this.idMultivigencia;
    let datos = this.obtenerTipoUrl(2,this.datosCotizadorV3.declaraciones['idEmpleado'],planesSeleccionados);

    this._http.post(datos.url,datos.datosGuardado, { headers: getHeaders })
      .subscribe(
        response => {
           this.generarSolicitud(this.datosCotizadorV3.declaraciones['idEmpleado']);
        }, error => {
          this.reporte.push(`numero de empleado ${this.numEmpleadoTmp}:error \n`);
          this.fila++;
          this.defaultearEmpleadosSeleccionadosModal("",this.fila);
        }
      )

  }


  generarSolicitud(idEmpleado){

    this._BuscarPlanesv2.crearSolicitudEmpleadoDefaulteo(idEmpleado, this.idVigenciaSeleccionada).subscribe(
    response2 => {

   

     
       let datos= {
        idEmpleado:idEmpleado,
        idEmpresa:this.identity.idEmpresa
       }

       this._BuscarPlanesv2.verificarSolicitudExist2(datos, this.idVigenciaSeleccionada, this.token)
       .then(
         response => {
           
           if(response == 1){
            this.reporte.push(`numero de empleado ${this.numEmpleadoTmp}:ok \n`);

          }else{

            this.reporte.push(`numero de empleado ${this.numEmpleadoTmp}:error \n`);
          }
          
          
                     this.fila++;
                    this.defaultearEmpleadosSeleccionadosModal("",this.fila);
          
        }, error => {
          
         }
       );
    
    }, error => {
    
    
    }
  
  );

  }



  //nuevos metodos para la optimizacion del modulo


  obtenerMultivigencia(idVigenciaSelecionada){


    this.idMultivigencia =idVigenciaSelecionada;

    for(let i = 0; i < this.comboVigencias.length; i++){


      if(this.comboVigencias[i].VIidVigencia == idVigenciaSelecionada ){
          let j = i;
          j++
          
          if(!(j < this.comboVigencias.length)){
              j = i;
          }
          
          
          console.log("idMultivigenciaAnterior:" + this.comboVigencias[j].VIidVigencia);
          this.idMultivigencia = this.comboVigencias[j].VIidVigencia;
        break;

      }

      

    }


  }

  buscaAyuda(){
    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    this.iconoAyuda = 1;
            this.textAyuda = "Texto de ayuda Defaulteo, Crear y Actualizar Solicitudes.";
    this._http
      .get(this.urlWs + 'ayuda/menu/558', { headers: getHeaders })
      .subscribe(
        response => {
          const pagina = response;

          this._http.get(
            this.urlWs +
            'ayuda/empresa/' +
            this.identity.idEmpresa +
            '/pagina?pagina=' +
            pagina['paNombreArchivo'],
            { headers: getHeaders }
          )
            .subscribe(
              response => {
                this.iconoAyuda = 1;
                const textoayuda = response;
                this.textAyuda = textoayuda[0].paTextoAyuda;

              },
              error => {
                const errorMessage = <any>error;
                this.iconoAyuda = 0;
                swal({
                  title: '¡Error!',
                  html: '<small style="color: grey; text-align: justify;">Ha ocurrido un problema al obtener los datos de ayuda.</small>',
                  type: 'error',
                  confirmButtonText: 'Aceptar',
                  timer: 3000,
                }).then((result) => {
                  $('#modalAyuda').modal('hide');
                });
              }
            );
        },
        error => {
          this.iconoAyuda = 1;
            this.textAyuda = "Texto de ayuda Defaulteo, Crear y Actualizar Solicitudes.";
        }
      );

  }

  consultaVigencias(){
    return this._cifrasControlService.getConsultaVigenciasXEmpresa(this.identity.idEmpresa).then(response=>{
      console.log("Estas son las vigencias_");
      console.log(response);
      this.comboVigencias=response[0];
      this.obtenerVigenciaActual();

    });
  }

 

  obtenerVigenciaActual(){
    this._titularesService.obtenerVigenciaActual(this.identity.idEmpresa).then(
      response => {
        this.idVigenciaVigente = response[0].idVigencia;

          this.idVigenciaSeleccionada = response[0].idVigencia;
          this.obtenerMultivigencia(this.idVigenciaSeleccionada);
       
      },
      error => {
            console.log("error en la obtencion de la vigencia actual")
      }); 

  }


  obtenerPlanesDefaulteo(){

    this._titularesService.obtenerPlanesDefaulteo().then(
      response => {

        // this.datosVigenciasCorporativo = response[0][0].VINombreCompuesto;
        this.planesDefaulteo = response[0];
        
  });

  }

 


  asignarTipoDefaulteo(tipoDefaulteo){
    // 1 selecciones anteriores 
    // 2 plan basico 
  this.tipoDefaulteo = tipoDefaulteo;
  }

  generarListaEmpleados(datosEmpleado){
  let existeEmpleado;
  let idEmpleado = datosEmpleado[0].value;
  let indexEmpleadoExistente;

    for(let i = 0; i < this.empleadosSeleccionados.length; i++){

      for(let j = 0; j < this.empleadosSeleccionados[i].length; j++){

        if(this.empleadosSeleccionados[i][j].key == "Id"){

          if(this.empleadosSeleccionados[i][j].value == idEmpleado){

            indexEmpleadoExistente = i;
            existeEmpleado = true;
            break;

          }

        }
      }

    }

    if(existeEmpleado){

      this.empleadosSeleccionados.splice(indexEmpleadoExistente, 1);
    }else{

      this.empleadosSeleccionados.push(datosEmpleado);
    }

    console.log("empleados seleccionados", this.empleadosSeleccionados);
  }

  //antes de multivigencia
  getTitulares(parametros: any) {
    this._titularesService.getTitularesDefaulteo(parametros, this.token).then(
      response => {
        console.log(response);
        if (response) {
          if (response[1].length == 0){
            this.componentBlock= false;
            Swal.fire({
              title:'¡Atención!',
              text: 'No se encontraron datos que coincidan con tu busqueda',
              icon: 'warning'
            });
          }
          else{
            this.datosTitul = [];
            this.datosTitul = this.titularesUnicos(response[1])
              .map(titulares => this.valuesToArray(titulares));

            for (let elemento of this.datosTitul) {
              elemento[8].value = this.datePipe.transform(elemento[8].value, 'dd-MM-yyyy');
            }
            this.vaciarDatosTitu();

          }
        }
      },
      error => {
        const errorMessage = <any>error;
        console.error('Error getTitulares()', error);
      }
    );
  }
  getTitularesMultivigencia() {
    this.loadEditar = true;

    let parametros = {
      "IdsEmpresas" : this.parametrosBusqueda.idEmpresas.join(',')
      ,"IdAdministrador" : this.identity.id
      ,"idPerfiles" : this.parametrosBusqueda.perfiles.join(',')
      ,"idAtributo1" : this.parametrosBusqueda.idAtributo1
      ,"idAtributo2" : this.parametrosBusqueda.idAtributo2
      ,"idTipoOperador1" : this.parametrosBusqueda.idTipoOperador1
      ,"idTipoOperador2" : this.parametrosBusqueda.idTipoOperador2
      ,"parametroBusqueda1" : this.parametrosBusqueda.parametroBusqueda1
      ,"parametroBusqueda2" : this.parametrosBusqueda.parametroBusqueda2
      ,"BusquedaAvanzada" : this.esBusquedaAvanzada ? 1 : 0
      ,"idTipoOperadorAvanzado" : this.parametrosBusqueda.idTipoOperadorAvanzado
      ,"Vigencia": this.parametrosBusqueda.idVigencia
    }

    this._titularesService.getTitularesMultiVigAvanzado(parametros, this.token).then(
      response => {
        if (response != undefined && response != null) {
          if (response.length == 0){
            this.componentBlock= false; // Volver a habilitar campos
            this.msjNoHayDatos = true;
            this.existenDatosTabla = false;
            this.seccionDefaulteo='none';
          }
          else{
            this.loadEditar = true;
            this.datosTitul = [];
            this.datosTitul = this.titularesUnicos(response)
              .map(titulares => this.valuesToArray(titulares));
            for (let elemento of this.datosTitul) {
              elemento[11].value = this.datePipe.transform(elemento[11].value, 'dd-MM-yyyy');
            }
            this.vaciarDatosTitu();
            this.loadEditar = false;
            this.existenDatosTabla = true;
          }
        }else{
          this.loadEditar = false;
          this.msjNoHayDatos = true;
          this.existenDatosTabla = false;
          this.componentBlock = false; // Habilitar campos
          this.seccionDefaulteo='none';
        }
      },
      error => {
        const errorMessage = <any>error;
        console.error('Error getTitulares()', error);
        this.loadEditar = false;
        this.msjNoHayDatos = true;
        this.existenDatosTabla = false;
        this.componentBlock = false;
        this.seccionDefaulteo='none';
        this.restaurarSeccionDefaulteo();
      }
    );
  }

  // Desuso
  buscar(parametro?) {
    // console.log("Entro a metodo",parametro, parametro.length);
    this.page = 1;
    this.pageSize = 10;
    this.collectionSize = 0;
    console.log(this.busquedaPor);
    this.empleadosSeleccionados = [];
    this.datosTabla = [];
    this.errorEntrada  = false;
    this.componentBlock= true;
    // if(!this.valorBusqueda)
    this.valorBusqueda = parametro;
  
    const regexpNumber = new RegExp('^[\u00F1\u00D1A-ZÁ-Üa-zá-ü .]+$');
    console.log(regexpNumber.test(parametro));
    switch (this.busquedaPor) {
        case "nada":
          if (parametro == '') {
            console.log("Entro a nada primer case");
              this.buscarTitulares();  
          } else {
            this.errorEntrada = true;
            this.componentBlock= false;
          } 
        break;
  
        case 'nombre':
          if (regexpNumber.test(parametro) || parametro == '') {
              this.buscarTitulares();
          } else {
            this.errorEntrada = true;
            this.componentBlock= false;
          }
        break;
  
        case 'nombre2':
          if (regexpNumber.test(parametro) || parametro == '') {
              this.buscarTitulares();  
          } else {  
            this.errorEntrada = true;
            this.componentBlock= false;
          }
        break;

        case 'numero':
          console.log("Es numero");
          this.buscarTitulares();
        break;
  
        case 'paterno':
          if (regexpNumber.test(parametro) || parametro == '') {  
              this.buscarTitulares();  
          } else {
            this.errorEntrada = true;
            this.componentBlock= false;
          }
        break;
  
        case 'materno':
          if (regexpNumber.test(parametro) || parametro == '') {
            this.buscarTitulares();
          } else {
            this.errorEntrada = true;
            this.componentBlock= false;
          }
        break;
  
        default:
          console.log("Entro a nada default");
          this.buscarTitulares(); 
        break;
    }
  }
    
  buscarTitulares() {
    let parametros;
    switch (this.busquedaPor) {
      case 'nada':
        if (this.valorBusqueda == '' || this.busquedaPor=="nada") {
     
        parametros = {
          'idCorporativo':1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno': null,
          'apellidoMaterno': null,
          'nombreUno': null,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      }
      break;
      case 'nombre':
        parametros = {
          'idCorporativo':1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno': null,
          'apellidoMaterno': null,
          'nombreUno': this.valorBusqueda,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };  
      break;

      case 'nombre2':
        parametros = {
          'idCorporativo': 1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno': null,
          'apellidoMaterno': null,
          'nombreUno': null,
          'nombreDos': this.valorBusqueda,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      break;

      case 'numero':
        parametros = {
          'idCorporativo': 1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': this.valorBusqueda,
          'apellidoPaterno': null,
          'apellidoMaterno': null,
          'nombreUno': null,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      break;

      case 'paterno':
        parametros = {
          'idCorporativo': 1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno': this.valorBusqueda,
          'apellidoMaterno': null,
          'nombreUno': null,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      break;

      case 'materno':
        parametros = {
          'idCorporativo': 1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno':null ,
          'apellidoMaterno': this.valorBusqueda,
          'nombreUno': null,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      break;

      default:
        this.campoBusca = 'EMNombre1';
      break;
    }
  
    if(this.tipoBusqueda ==1){
      parametros.idCorporativo=1;
      parametros.idEmpresa = this.identity.idEmpresa;
    }else{
      parametros.idCorporativo=-1;
      parametros.idEmpresa = this.identity.idEmpresa;
    }

    this.datosTabla = [];
    //busqueda de titulares
    if(this.multivigencia){
      this.getTitularesMultivigencia();
    }else{
      this.getTitulares(parametros);
    }
  }

  cambiarNivelBusqueda(tipoBusqueda){
      this.tipoBusqueda = tipoBusqueda;
  }

  valuesToArray(obj) {
    const objeto = [];
    Object.keys(obj).map(
      (key) => {


        objeto.push({
          value: obj[key] != 'NULL' ? obj[key] : '',
          key: key
        });
      }
    );
    return objeto;
  }

  /**
   * Evita filas repetidas cuando un titular tiene solicitudes rechazadas o
   * canceladas previas. El filtro definitivo vive en SQL; esta proteccion
   * mantiene estable la UI durante despliegues escalonados.
   */
  private titularesUnicos(titulares: any[]): any[] {
    const vistos = new Set<string>();
    return (titulares || []).filter(titular => {
      const id = titular && (titular.Id || titular.idEmpleado || titular.id);
      if (id === null || id === undefined) {
        return true;
      }
      const llave = String(id);
      if (vistos.has(llave)) {
        return false;
      }
      vistos.add(llave);
      return true;
    });
  }

  public valorFila(fila: any[], llave: string): any {
    const dato = (fila || []).find(item => item && item.key === llave);
    return dato ? dato.value : '';
  }

  public nombreCompletoFila(fila: any[]): string {
    return [
      this.valorFila(fila, 'ApellidoPaterno'),
      this.valorFila(fila, 'ApellidoMaterno'),
      this.valorFila(fila, 'Nombre1'),
      this.valorFila(fila, 'Nombre2')
    ].filter(valor => valor !== null && valor !== undefined && String(valor).trim() !== '')
      .join(' ');
  }

  vaciarDatosTitu() {
    if (this.datosTitul != null) {
      this.datosTabla = [];
      this.datosTabla = this.datosTitul;
      this.empleadosSeleccionados=[];
      console.log("Empleados seleccionados", this.empleadosSeleccionados);
      this.seccionDefaulteo = 'block';
      this.collectionSize = this.datosTabla.length;

    }else{
      this.empleadosSeleccionados=[];
      this.seccionDefaulteo='none';
    }
  }

  defaultearEmpleadosSeleccionadosModal(modal,fila?){
   
   
   const idEmpleado = [];
   const numEmpleado = [];
   const empresas = [];
    console.log(this.empleadosSeleccionados);


    for(let i = 0; i <this.empleadosSeleccionados.length; i++){
      for(let j = 0; j < this.empleadosSeleccionados[i].length; j++){

        if(this.empleadosSeleccionados[i][j].key == "Id"){
          idEmpleado.push(this.empleadosSeleccionados[i][j].value);
        }
        if(this.empleadosSeleccionados[i][j].key == "numEmpleado"){
          numEmpleado.push(this.empleadosSeleccionados[i][j].value);
        }
        
        if(this.empleadosSeleccionados[i][j].key == "idEmpresa"){
          empresas.push(this.empleadosSeleccionados[i][j].value);
        }

      }
    }


    let defaulteo;
    switch(+this.tipoDefaulteo){
      case 1:
        defaulteo = 'def1';
        break;
      case 2:
        defaulteo = 'def2';
        break;
      case 3:
        defaulteo = 'def3';
        break;

    }

    /* El endpoint Java exige un idEmpresa y un numEmpleado por cada ID. */
    if(!defaulteo || !this.identity || idEmpleado.length === 0 ||
       idEmpleado.length !== numEmpleado.length ||
       idEmpleado.length !== empresas.length){
      this.manejarErrorDefaulteo({ status: 400, datosIncompletos: true });
      return;
    }

    if(this.idVigenciaSeleccionada == this.idVigenciaVigente){
      
          this._http.post(`${GLOBAL.url}titulares/defaultearMasivo`,
          {
            "idEmpleado":idEmpleado,
            "numEmpleado":numEmpleado,
            "idEmpresa": empresas,
            "idVigencia":0,
            "idVigenciaAnterior":0,
            "tipoDefaulteo":defaulteo,
            "tmpplanesseleccionados":'{"costo": null,"idempleado": -1,"nuevo": null,"tcidtarifacosto": -1}',
            "tmpplanesseleccionadosold":'{"costoOld": null,"idempleadoOld": -1,"nuevoOld": null,"tcidtarifacostoOld": -1}',
            "idAdmin":this.identity.id,
            "idVigenciaVigente":this.idVigenciaVigente
          }
            ).subscribe(response => {
            console.log("RESPUESTA DEFAULTEO MASIVO", response);
            if(!Array.isArray(response) || response.length === 0){
              this.manejarErrorDefaulteo({ respuestaIncompleta: true });
              return;
            }
            if(!JSON.parse(localStorage.getItem('identity'))){
              this.manejarErrorDefaulteo({ sesionInvalida: true });
              return;
            }
            this.cerrarModalProcesandoDefaulteo();
            if(JSON.parse(localStorage.getItem('identity'))){

              this.componentBlock= true;
              this.reporte = this.construirDatosLog(response);
              let modalReporteAux
              this.fila = null;
              this.restaurarSeccionDefaulteo();
              // alert(this.reporte);
              // this.reporte=[]; 
              modalReporteAux = this._modalService.open(this.modalReporteElement, { backdrop : 'static', keyboard: false ,windowClass: 'confirmacionModal2', centered: true });
              this.modalReporte = modalReporteAux; 
              let tiposDefaulteoSelect: HTMLSelectElement = this.inputEl.nativeElement;
              tiposDefaulteoSelect.selectedIndex = 0;

            }
            let encabezadosLog = ["Empresa"," Número de Empleado", "Mensaje"];
            let datos = this.construirDatosExcel(response);
            this.generarExcel(datos, encabezadosLog, this.colocarFechaAlNombre("ReporteDefaulteo"));
          }, error => this.manejarErrorDefaulteo(error))
            
    }else{
      
      this._http.post(`${GLOBAL.url}titulares/defaultearMasivo`,
      {
        "idEmpleado":idEmpleado,
        "numEmpleado":numEmpleado,
        "idEmpresa": empresas,
        "idVigencia":this.idVigenciaSeleccionada,
        "idVigenciaAnterior":this.idMultivigencia,
        "tipoDefaulteo":defaulteo,
        "tmpplanesseleccionados":'{"costo": null,"idempleado": -1,"nuevo": null,"tcidtarifacosto": -1}',
        "tmpplanesseleccionadosold":'{"costoOld": null,"idempleadoOld": -1,"nuevoOld": null,"tcidtarifacostoOld": -1}',
        "idAdmin":this.identity.id,
        "idVigenciaVigente":this.idVigenciaVigente
      }
      ).subscribe(response => {
        console.log("RESPUESTA DEFAULTEO MASIVO", response);
        if(!Array.isArray(response) || response.length === 0){
          this.manejarErrorDefaulteo({ respuestaIncompleta: true });
          return;
        }
        if(!JSON.parse(localStorage.getItem('identity'))){
          this.manejarErrorDefaulteo({ sesionInvalida: true });
          return;
        }
        this.cerrarModalProcesandoDefaulteo();
        if(JSON.parse(localStorage.getItem('identity'))){
          this.componentBlock= true;
          this.reporte = this.construirDatosLog(response);
          let modalReporteAux  
          this.fila = null;
          this.restaurarSeccionDefaulteo();
          // alert(this.reporte);
          // this.reporte=[];
          modalReporteAux = this._modalService.open(this.modalReporteElement, {  backdrop : 'static', keyboard: false ,windowClass: 'confirmacionModal2', centered: true });
          this.modalReporte = modalReporteAux;
          let tiposDefaulteoSelect: HTMLSelectElement = this.inputEl.nativeElement;
          tiposDefaulteoSelect.selectedIndex = 0
        }
        let encabezadosLog = ["Empresa"," Número de Empleado", "Mensaje"];
        let datos = this.construirDatosExcel(response);
        this.generarExcel(datos, encabezadosLog, this.colocarFechaAlNombre("ReporteDefaulteo"));
      }, error => this.manejarErrorDefaulteo(error))
    }   
  }

  private cerrarModalProcesandoDefaulteo(): void {
    if(this.modal){
      try{
        this.modal.close();
      }catch(error){
        console.log('No fue posible cerrar el modal de procesamiento.', error);
      }
    }
    this.modal = null;
    this.iconoCargando = false;
    this.ejecutando = false;
  }

  private manejarErrorDefaulteo(error): void {
    this.cerrarModalProcesandoDefaulteo();

    let mensaje = 'Ocurrio un error al procesar el defaulteo.';
    if(error && error.datosIncompletos){
      mensaje = 'La seleccion contiene datos incompletos de empleado o empresa. Actualiza la busqueda y vuelve a seleccionar los registros.';
    }else if(error && error.sesionInvalida){
      mensaje = 'La sesion ya no es valida. Inicia sesion nuevamente antes de reintentar.';
    }else if(error && error.respuestaIncompleta){
      mensaje = 'El servicio termino sin devolver el resultado de las solicitudes.';
    }else if(error && error.status === 0){
      mensaje = 'No hubo respuesta del servicio. Verifica la conexion y el estado del servidor.';
    }else if(error && error.status === 400){
      mensaje = 'El servicio rechazo los datos enviados. Actualiza la busqueda y vuelve a seleccionar los empleados.';
    }else if(error && error.status === 401){
      mensaje = 'La sesion expiro. Inicia sesion nuevamente antes de reintentar.';
    }else if(error && error.status === 403){
      mensaje = 'No fue posible validar el acceso o la empresa de uno de los empleados seleccionados.';
    }else if(error && error.status === 409){
      mensaje = 'El servidor no pudo completar el proceso de defaulteo.';
    }

    Swal.fire({
      title: 'No fue posible generar las solicitudes',
      html: mensaje + '<br><br>Antes de reintentar, consulta las solicitudes existentes para confirmar si algun empleado ya fue procesado.',
      type: 'error',
      confirmButtonText: 'Aceptar'
    });
  }

  /********************************************************************************** */
  /* METODOS PROVISIONALES PARA ENVIO DE NOTIFICACIONES Y ENVIO DEL LOG DE RESULTADOS */
  /********************************************************************************** */

  public generarExcel(datos, header, nombre) {
    let workbook = this._excelService.generarLogDefaulteo(header, datos, nombre);

    workbook.xlsx.writeBuffer().then((archivo: any) => {
      const blob = new Blob([archivo], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      //FileSaver.saveAs(blob, nombre);
      this.crearCorreo(blob, nombre);
    });
  }

  public construirDatosExcel(datos): string[]{
    let resultados:string[] = [];
    datos.forEach(dato => {
      let partes = dato.split("_");
      //Provisionalmente se esperan 3 datos
      resultados.push(partes);
    });
    return resultados;
  }

  public construirDatosLog(datos): any[]{
    let resultados:any[] = [];
    datos.forEach(dato => {
      let partes = dato.split("_");
      //Provisionalmente se esperan 3 datos
      resultados.push("Empresa: " + partes[0] + " Número de Empleado: " + partes[1] + " Mensaje: " + partes[2]);
    });
    return resultados;
  }

  public crearCorreo(archivo, nombreArchivo) {

    var contenido = this.plantillaCorreo;
    var subject = "Notificación resultado de asignación de planes.";
    var tipoNotificacion = "Notificación resultado de asignación de planes.";
    //subject = subject.replace('#Empresa ', this.identity.nomEmpresa);
    contenido = contenido.replace("#TipoNotificacion", tipoNotificacion);
    contenido = contenido.replace('#Administrador', this.correo.nombre);
    contenido = contenido.replace('#Accion', "Defaulteo Masivo");
    contenido = contenido.replace("#Fecha", this.datePipe.transform(new Date(), "dd/MM/yyyy HH:mm"));

    var file = new File([archivo], nombreArchivo);
    var form = new FormData();
    form.append("file", file);
    this._empleadoService.sendMailUnificado(this.correoAdmin, this.correosCopia, '', subject, contenido, '', form, '', '', 14, this.token).
      then((res) => {
        //swal('¡Correo Enviado!', '', 'success');
        console.log(res['ok'] ? '¡Correo Enviado!' : '¡Error al enviar correo!');
      }, error => {
        console.log(error);
      });

  }

  restaurarSeccionDefaulteo(inputBuscar?){
    this.seccionDefaulteo = 'none';
    this.empleadosSeleccionados = [];
    this.datosTabla = [];
    // this.componentBlock= false;
    this.procesoEnEjecucion = true;
    this.procesoFinalizado = false;
    // this.valorBusqueda = null;
    // if(inputBuscar)
    //   inputBuscar.value = '';
    let tiposDefaulteoSelect: HTMLSelectElement = this.inputEl.nativeElement;
    tiposDefaulteoSelect.selectedIndex = 0;
    this.msjNoHayDatos = false;
    this.existenDatosTabla = false;
  }
  
  public getDatosCorreo(): void {
    this._empleadoService.getDatos(this.identity).then((datos: any) => {
      if (this.identity.clave != "") {
        this.correo.correo = datos.emCorreoElectronico;
        this.correo.nombre = datos.emNombre1 ? datos.emNombre1 : "";
        this.correo.nombre += datos.emNombre2 ? " " + datos.emNombre2 : "";
        this.correo.nombre += datos.emApellidoPaterno ? " " + datos.emApellidoPaterno : "";
        this.correo.nombre += datos.emApellidoMaterno ? " " + datos.emApellidoMaterno : "";
        this.correoAdmin = !datos.emCorreoElectronico || datos.emCorreoElectronico == "" ?  
        "beflex@mx.lockton.com" : datos.emCorreoElectronico.trim();
        if (!datos.emCorreoElectronico || datos.emCorreoElectronico == "") {
          swal({
            title: '¡Aviso, no se cuenta con un correo electrónico registrado!',
            html: `<small clas="text-dark">Correo: "${datos.emCorreoElectronico}"</small>`,
            type: 'warning',
            confirmButtonText: 'Aceptar',
            timer: 3000
          });
        }
      }
    });
  }

  getCorreosParaCopiaAdmin( idEmpresa = this.identity.idEmpresa){
    this.correosCopia = "";
    this._docPerService.getCorreosAdmin(idEmpresa, this.token).then(
      response => {
        if (response.length > 0) {
          response.forEach(
            correo => {
              this.correosCopia += correo + ",";
            }
          );
        }
      }
    );
  }

  colocarFechaAlNombre(nombreArch: any) {
    const f = new Date();
    let nombre = `${nombreArch}${f.getFullYear()}`;
    let mes;
    let m;
    m = (f.getMonth() < 10) ? `0${f.getMonth()}` : f.getMonth();
    mes = parseInt(m) + 1;
    nombre += (f.getMonth() < 10) ? `0${mes}` : mes;
    nombre += (f.getDate() < 10) ? `0${f.getDate()}` : f.getDate();
    nombre += (f.getHours() < 10) ? `0${f.getHours()}` : f.getHours();
    nombre += (f.getMinutes() < 10) ? `0${f.getMinutes()}` : f.getMinutes();
    nombre += (f.getSeconds() < 10) ? `0${f.getSeconds()}` : f.getSeconds();
    nombre += '.xlsx';
    return nombre;
  }

  public async obtenerEmpresas() {
    try {
      const empresas = [];
      const response: any = await this._empresaService.getComboLogin(this.identity.idCorporativo, this.token);
      if (response) {
        response.forEach(element => empresas.push(element.emidEmpresa));
      }
      this.crearArbolEmpresas(empresas);
    } catch (error) { }
  }

  /* Arbol: Empresa - Perfil */
  public async crearArbolEmpresas(empresas: any[]) {
    try {
      const response: any = await this._BitacoraService.getEmpPerfil(empresas, this.token);
      if (response != null && response != undefined && response.length > 0) {
        const datos = [];
        response.forEach(empresa => {
          const hojas = [];
          empresa.perfiles.forEach(perfil => {
            const hoja = { 'id': perfil.idPerfil, 'name': perfil.nombrePerfil.toUpperCase(), 'child': null, 'selected': false };
            hojas.push(hoja);
          });
          const rama = { 'id': empresa.idEmpresa, 'name': empresa.nombreEmpresa.toUpperCase(), 'child': hojas, 'selected': false };
          datos.push(rama);
          this.parametrosBusqueda.idEmpresas.push(empresa.idEmpresa);
        });
        datos.forEach(padre => padre.child.forEach(hijo => Object.assign(hijo, { 'selected': true })));

        const hojasPadre = { 'id': 0, 'name': 'TODOS', 'child': datos, 'selected': false, 'expandable': false };
        this.arbol = [];
        this.arbol.push(hojasPadre);
      }
    } catch (error) { }
  }

  validarEmpresasAsignar() {
    this.arbol.forEach(padre => {
      padre.child.forEach(empresa => {
        empresa.child.forEach(perfil => {
          if (this.parametrosBusqueda.perfiles.includes(perfil.id) && !this.parametrosBusqueda.idEmpresas.includes(empresa.id)) {
            this.parametrosBusqueda.idEmpresas.push(empresa.id);
          }
        });
      });
    });
  }

  obtenerEmpresasPerfilesSeleccionados() {
    this.parametrosBusqueda.idEmpresas = [];
    this.parametrosBusqueda.perfiles = [];
    this.seleccionArbol.forEach(entry => {
      switch (entry.level) {
        case 1:
          this.parametrosBusqueda.idEmpresas.push(entry.id);
          break;
        case 2:
          this.parametrosBusqueda.perfiles.push(entry.id);
          break;
        default:
          break;
      }
    });
    this.validarEmpresasAsignar();
  }

  public seleccionEmpresa(event) {
    this.seleccionArbol = event;
    this.parametrosBusqueda.idEmpresas = [];
    this.obtenerEmpresasPerfilesSeleccionados();
    if (this.parametrosBusqueda.idEmpresas.length == 0) { // Valida lista empresas
      this.errorRep.empresas = true;
      this.validRep.empresas = false;
    } else {
      this.errorRep.empresas = false;
      this.validRep.empresas = true;
    }
    if (this.parametrosBusqueda.perfiles.length == 0) { // Valida lista de perfiles
      this.errorRep.perfiles = true;
      this.validRep.perfiles = false;
    } else {
      this.errorRep.perfiles = false;
      this.validRep.perfiles = true;
    }
  }

  public inicializarFormularioBusqueda(){
    this.parametrosBusqueda = {
      idEmpresas: [],
      perfiles: [],
      idAtributo1: 'EMNumeroEmpleado',
      idTipoOperador1: 'contiene',
      parametroBusqueda1: '',
      idTipoOperadorAvanzado: 'and',
      idAtributo2: 'EMNumeroEmpleado',
      idTipoOperador2: 'contiene',
      parametroBusqueda2: '',
      idEstatus: ['Rechazada','Autorizada','Por Autorizar','Cancelada'],
      idVigencia: 0,
      BusquedaAvanzada:0
    };
  }

  public reiniciarFormularioBusqueda(){
    this.esBusquedaAvanzada = false;
    this.parametrosBusqueda.idTipoOperadorAvanzado = 'and';
    this.parametrosBusqueda.idAtributo1 = 'EMNumeroEmpleado';
    this.parametrosBusqueda.idAtributo2 = 'EMNumeroEmpleado';
    this.parametrosBusqueda.idTipoOperador1 = 'contiene';
    this.parametrosBusqueda.idTipoOperador2 = 'contiene';
    this.parametrosBusqueda.parametroBusqueda1 = '';
    this.parametrosBusqueda.parametroBusqueda2 = '';
    this.parametrosBusqueda.idEstatus = ['Rechazada','Autorizada','Por Autorizar','Cancelada'];
    this.restaurarSeccionDefaulteo();
  }
  validarInput(parametro: string) {
      const regexpNumber = new RegExp('^[\u00F1\u00D1 A-ZÁ-Üa-zá-ü .]+$');
      const regexpNumber2 = new RegExp('^[a-zA-Z0-9]+$');
      if (this.busquedaPor != 'EMNumeroEmpleado' && parametro.length > 0) {
        if (regexpNumber.test(parametro)) {
          this.errorRep.parametroBusqueda1 = false;
        } else {
          this.errorRep.parametroBusqueda1 = true;
        }
      } else {
        if (this.busquedaPor == 'EMNumeroEmpleado' && parametro.length > 0) {
          if (regexpNumber2.test(parametro)) {
            this.errorRep.parametroBusqueda1 = false;
          } else {
            this.errorRep.parametroBusqueda1 = true;
          }
        } else {
          this.errorRep.parametroBusqueda1 = false;
        }
      }
    }
  
    cambiarBuscarPor(busquedaPor: string, valorBusqueda: string) {
      this.busquedaPor = this.parametrosBusqueda.idAtributo1;
      this.validarInput(valorBusqueda);
    }

    // Metodo de busqueda
    busquedaAvanzada() {
      this.page = 1;
      this.pageSize = 10;
      this.collectionSize = 0;
      this.empleadosSeleccionados = [];
      this.datosTabla = [];
      this.errorEntrada  = false;
      this.componentBlock= true;
      this.existenDatosTabla = false;
      this.msjNoHayDatos = false;
      this.seccionDefaulteo='none';

      this.parametrosBusqueda.idVigencia = this.idVigenciaSeleccionada;

      let estatus = true;
      if(!this.validarParametros(1)){
        estatus = false;
        this.errorEntrada = true;
        this.componentBlock= false;
      }
      if(this.esBusquedaAvanzada && (!this.validarParametros(2))){
        estatus = false;
        this.errorEntrada = true;
        this.componentBlock= false;
      }

      if (estatus) {
        this.consultaSolicitudesAvanzado();
      }else{
        this.restaurarSeccionDefaulteo();
        swal({
          title: '¡Atención!',
          html: 'Los parámetros de búsqueda no son válidos, no se permiten caracteres especiales y campos vacíos.',
          type: 'warning',
          confirmButtonText: 'Aceptar',
          showConfirmButton: true,
          onOpen: () => {
            swal.hideLoading();
          }
        });
      }
    }
  
    // Validacion de campos de parametro
    public validarParametros(idCampo) {
      let parametrosValidos = true;
      const buscar = idCampo === 1 ? this.parametrosBusqueda.parametroBusqueda1 : this.parametrosBusqueda.parametroBusqueda2;
      const campoAtributo = idCampo === 1 ? this.parametrosBusqueda.idAtributo1 : this.parametrosBusqueda.idAtributo2;
  
      if(!this.validaContenidoParametroBusqueda(buscar, campoAtributo, idCampo)){
        parametrosValidos = false;
        if(idCampo === 1){
          this.errorRep.parametroBusqueda1 = true;
        }else{
          this.errorRep.parametroBusqueda2 = true;
        }
      }else{
        if(idCampo === 1){
          this.errorRep.parametroBusqueda1 = false;
        }else{
          this.errorRep.parametroBusqueda2 = false;
        }
      }
      return parametrosValidos;
    }
    validaContenidoParametroBusqueda(contenido: string, parametro: string, idCampo: number){
      const regexpCampo  = new RegExp('^[\u00F1\u00D1A-ZÁ-Üa-zá-ü .]+$');
      const regexpNumber2 = new RegExp('^[\u00F1\u00D1A-ZÁ-Üa-zá-ü0-9.]+$');
      let esValido = true;
  
      // Comprobar contenido de parametros
      if(!(idCampo === 1 && contenido.trim() === '' && !this.esBusquedaAvanzada)){
        if (contenido === null || contenido === '' || contenido.length === 0 || parametro === '') {
          esValido =  false;
        }else{
          if(parametro === "EMNumeroEmpleado"){ // Validar campo de numero de empleado
            if (!regexpNumber2.test(contenido)) {
              esValido =  false;
            }
          }else{ // Validar campos distintos a numero de empleado
            if (!regexpCampo.test(contenido)) {
              esValido =  false;
            }
          }
        }
      }
      return esValido;
    }

    public async consultaSolicitudesAvanzado() {
      if(this.parametrosBusqueda.idEmpresas.length === 0) {
        this.restaurarSeccionDefaulteo();
        swal({
          title: '¡Alto!',
          html: 'Selecciona al menos una empresa.',
          type: 'error',
          confirmButtonText: 'Aceptar',
          showConfirmButton: true,
          onOpen: () => {
            swal.hideLoading();
          }
        });
        this.loadEditar = false
        return;
      }
      try {
        this.getTitularesMultivigencia();
      } catch (error) {
        this.loadEditar = false;
        this.restaurarSeccionDefaulteo();
      }
    }

}
export interface IBusquedaRequest {
    idEmpresas: number[],
    perfiles: number[],
    idAtributo1: string,
    idTipoOperador1: string,
    parametroBusqueda1: string,
    BusquedaAvanzada: number,
    idTipoOperadorAvanzado: string,
    idAtributo2: string,
    idTipoOperador2: string,
    parametroBusqueda2: string,
    idEstatus: any[],
    idVigencia: number
}
