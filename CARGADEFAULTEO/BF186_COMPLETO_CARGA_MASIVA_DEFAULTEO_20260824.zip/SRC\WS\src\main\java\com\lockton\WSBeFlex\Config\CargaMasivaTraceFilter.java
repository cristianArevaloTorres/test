package com.lockton.WSBeFlex.Config;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Registra el recorrido de una carga masiva cuando BF3 envia un identificador
 * de correlacion. No almacena tokens, cuerpos, nombres ni numeros de empleado.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 20)
public class CargaMasivaTraceFilter extends OncePerRequestFilter {
    public static final String HEADER = "X-Correlation-ID";
    private static final Logger LOGGER = LoggerFactory.getLogger(CargaMasivaTraceFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {
        String traceId = normalizar(request.getHeader(HEADER));
        if (traceId == null) {
            filterChain.doFilter(request, response);
            return;
        }

        long inicio = System.currentTimeMillis();
        MDC.put("cargaMasivaTraceId", traceId);
        response.setHeader(HEADER, traceId);
        LOGGER.info("CARGA_MASIVA_TRACE inicio trace={} metodo={} ruta={}",
                traceId, request.getMethod(), request.getRequestURI());
        try {
            filterChain.doFilter(request, response);
        } finally {
            LOGGER.info("CARGA_MASIVA_TRACE fin trace={} metodo={} ruta={} status={} duracionMs={}",
                    traceId, request.getMethod(), request.getRequestURI(),
                    response.getStatus(), System.currentTimeMillis() - inicio);
            MDC.remove("cargaMasivaTraceId");
        }
    }

    static String normalizar(String value) {
        if (value == null) return null;
        String limpio = value.trim();
        return limpio.matches("[A-Za-z0-9._-]{1,80}") ? limpio : null;
    }
}
