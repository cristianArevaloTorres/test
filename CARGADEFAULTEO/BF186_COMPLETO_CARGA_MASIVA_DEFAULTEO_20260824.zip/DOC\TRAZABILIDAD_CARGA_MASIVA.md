# Trazabilidad de Carga Masiva

Cada intento B3 genera un identificador similar a:

`CM-186-1787550000000-A1B2C3`

El mismo valor aparece en la pantalla, en el TXT descargable y en el header
HTTP `X-Correlation-ID`. El filtro Java registra inicio y fin de cada peticion
con ruta, estatus HTTP y duracion. No registra el token, el body, el query
string ni datos personales.

## Diagnostico

1. Copiar el ID mostrado en **Trazabilidad de esta carga**.
2. Descargar el log desde BF3 o consultarlo en el historico existente.
3. Buscar el mismo ID en el log de `WSBeFlex` usando el texto
   `CARGA_MASIVA_TRACE`.
4. Revisar el estatus HTTP y `duracionMs` de la ultima llamada completada.
5. Si la solicitud no alcanzo el WS, revisar consola/red del navegador y la
   disponibilidad del endpoint configurado en `GLOBAL.url`/`GLOBAL.url2`.

La correlacion se elimina de `sessionStorage` al finalizar, cancelar, fallar
la validacion o abandonar la pantalla. No modifica tablas nuevas; reutiliza el
registro historico de logs de Carga Masiva ya existente.

## Archivos involucrados

- `SRC/B3/src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts`
- `SRC/B3/src/app/beflex/cargamasivaadm/cargamasivaadm.component.html`
- `SRC/B3/src/app/beflex/cargamasivaadm/cargamasivaadm.component.css`
- `SRC/B3/src/app/services/auth-interceptor.service.ts`
- `SRC/WS/src/main/java/com/lockton/WSBeFlex/Config/CargaMasivaTraceFilter.java`
- `SRC/WS/src/test/java/com/lockton/WSBeFlex/Config/CargaMasivaTraceFilterTest.java`
