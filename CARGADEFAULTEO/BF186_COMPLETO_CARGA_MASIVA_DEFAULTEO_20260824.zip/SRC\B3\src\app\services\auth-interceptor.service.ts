import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent
} from '@angular/common/http';
import { Observable, EMPTY } from 'rxjs';
import swal from 'sweetalert2';

@Injectable({
  providedIn: 'root',
})
export class AuthInterceptorService implements HttpInterceptor {

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const identity = JSON.parse(localStorage.getItem('identity'));
    const token = JSON.parse(localStorage.getItem('tokenB3'));

    let request = req;
    let rutaCorrecta = true;
    let esWS = false;
    let admToken = false;

    if (request.method === 'GET') {
      const url = request.url;
      if (url.indexOf('beflex') !== -1) {
        esWS = true;
        const partes = url.split('beflex/');
        if (partes.length > 1) {
          const fragmento = partes[1].split(/[|!"#$<>¡¿*;+]/);
          if (fragmento.length > 1) {
            // separo el path de la ruta, contiene los caracteres especificados
            rutaCorrecta = false;
          }
        } else {
          // no separo bien la ruta, no es correcto
          rutaCorrecta = false;
        }
      }
    }

    if (
      request.method === 'POST' ||
      request.method === 'PUT' ||
      request.method === 'DELETE'
    ) {
      const url = request.url;
      if (url.indexOf('beflex') !== -1) {
        esWS = true;
        admToken = true;
      }
    }

    if (rutaCorrecta) {
      if (esWS) {
        if (token && !admToken) {
          const partesToken = token.split('.');
          const datos = JSON.parse(atob(partesToken[1]));
          if (identity) {
            if (identity.id === datos.n) {
              // datos correctos agrega y realiza la peticion
              request = req.clone({ setHeaders: { authorization: token } });
            } else {
              swal({
                title: '¡La sesión expiró!',
                html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
                type: 'error',
                confirmButtonText: 'Aceptar',
              }).then((result) => localStorage.clear());
              return EMPTY;
            }
          }
        } else if (token && admToken) {
          request = req.clone({
            setHeaders: {
              authorization: token,
            },
          });
        }
      }
      const correlationId = sessionStorage.getItem('bf3CargaMasivaTraceId');
      if (esWS && correlationId && /^[A-Za-z0-9._-]{1,80}$/.test(correlationId)) {
        request = request.clone({
          setHeaders: { 'X-Correlation-ID': correlationId }
        });
      }
      return next.handle(request);
    } else {
      swal({
        title: '¡La sesión expiró!',
        html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      }).then((result) => localStorage.clear());
      return EMPTY;
    }
  }
}
