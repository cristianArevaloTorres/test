package com.lockton.WSBeFlex.POJO.Especiales;

/**
 * CREA 06 - Request del endpoint POST /defaulteo-avanzado/ejecutar.
 * Incluye los filtros y acciones (para auditoria), la lista de empleados
 * efectivamente seleccionados (subset del resultado de buscar) y el admin.
 */
public class FFEjecutarDefaulteoAvanzado {

    public Integer idConfiguracion;
    public Integer idCorporativo;
    public Integer idEmpresa;
    public Integer idVigencia;
    public Integer idVigenciaAnterior;
    public Integer idAdmin;

    public int[]    idEmpleado;
    public String[] numEmpleado;

    public FFFiltroDefaulteoAvanzado filtros;
    public FFAccionDefaulteoAvanzado acciones;

    /** Conversion al DTO usado por el flujo de defaulteo actual (FFDefaulteo). */
    public FFDefaulteo toFfDefaulteo() {
        FFDefaulteo d = new FFDefaulteo();
        d.idEmpleado    = this.idEmpleado;
        d.numEmpleado   = this.numEmpleado;
        d.setIdAdmin(this.idAdmin != null ? this.idAdmin : 0);
        if (this.idVigencia != null)         d.setIdVigencia(this.idVigencia);
        if (this.idVigenciaAnterior != null) d.setIdVigenciaAnterior(this.idVigenciaAnterior);
        if (acciones != null && acciones.tipoAsignacionPlanes != null)
            d.setTipoDefaulteo("def" + acciones.tipoAsignacionPlanes);
        return d;
    }
}
