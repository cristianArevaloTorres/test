package com.lockton.WSBeFlex.Services;

import java.util.List;
import java.util.Map;

import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionDefaulteo;
import com.lockton.WSBeFlex.POJO.Especiales.FFEjecutarDefaulteoAvanzado;
import com.lockton.WSBeFlex.POJO.Especiales.FFFiltroDefaulteoAvanzado;

/**
 * CREA 06 - Logica de negocio del defaulteo avanzado.
 *
 * Mantiene el flujo de defaulteo actual (LogicaFfTitular.defaultearEmpleadosMasivo)
 * y le agrega: filtros avanzados, configuraciones guardadas, log por empleado y
 * bitacora auditable (RN001-RN010).
 */
public interface FfDefaulteoAvanzadoService {

    boolean tieneAccesoEmpresas(int idAdmin, int[] idsEmpresa);

    boolean tieneAccesoEmpleados(int idAdmin, int[] idsEmpleado);

    boolean lotePerteneceAdministrador(int idLog, int idAdmin);

    boolean configuracionPerteneceAdministrador(int idConfiguracion, int idAdmin);

    /** RN001 / RN010 — busqueda con 15 filtros. */
    List<Object> buscarEmpleados(FFFiltroDefaulteoAvanzado filtros);

    /**
     * RN006 / RN007 / RN008 — ejecuta defaulteo masivo iterando por empleado:
     *   1. Inicia lote en bf_LogDefaulteo
     *   2. Por cada empleado: invoca LogicaFfTitular.defaultearEmpleadosMasivo (1 empleado por llamada)
     *   3. Captura errores -> bf_LogErroresDefaulteo
     *   4. Finaliza lote con contadores y duracion
     *
     * El procesamiento corre en BACKGROUND: este metodo inicia el lote y
     * responde de inmediato con { idLog, estado:"EN_PROCESO", totalEmpleados }.
     * El avance se consulta despues con {@link #consultarEstado(int)}.
     */
    Map<String, Object> ejecutar(FFEjecutarDefaulteoAvanzado req, String ipOrigen);

    /**
     * Estado de un lote para el polling del front. Devuelve idLog, estado,
     * totalEmpleados, procesados, totalExitosos, totalErrores. Toma el avance
     * del registro en memoria mientras corre; si ya termino, lo lee de
     * bf_LogDefaulteo.
     */
    Map<String, Object> consultarEstado(int idLog);

    /** RN003 — guardar / actualizar configuracion. Devuelve CDId. */
    Integer guardarConfiguracion(FFConfiguracionDefaulteo c);

    /** RN003 — borrado logico. */
    void eliminarConfiguracion(int id, int idAdmin);

    /** RN009 — listar configuraciones disponibles. */
    List<Object> listarConfiguraciones(Integer idCorporativo, Integer idEmpresa, Integer idAdmin);

    /** RN007 — obtener eventos de un lote (para descarga). */
    List<Map<String, Object>> obtenerEventosDeLote(int idLog);

    /** Lista todos los perfiles activos de una empresa. */
    List<Map<String, Object>> listarPerfilesEmpresa(int idEmpresa);
}
