/*
  VALIDACION SOLO LECTURA - DEFAULTEO 1, 2 Y 3 EN BF3

  Cambie unicamente estos parametros cuando corresponda. El script no crea,
  actualiza ni elimina registros.
*/
SET NOCOUNT ON;

DECLARE @IdEmpresa INT = 186;
DECLARE @IdAdministrador INT = NULL; -- opcional: valida acceso del usuario real
DECLARE @IdVigencia INT = NULL;      -- NULL: toma la vigente/mas reciente de la empresa
DECLARE @Top INT = 30;

DECLARE @IdConfiguracion INT;
DECLARE @IdVigenciaOrigen INT;

SELECT @IdConfiguracion = E.EMIdConfiguracion
FROM dbo.ff_Empresa E
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdEstatus = 1;

IF @IdConfiguracion IS NULL
    THROW 51920, 'La empresa no existe, esta inactiva o no tiene configuracion.', 1;

IF @IdVigencia IS NULL
BEGIN
    SELECT TOP (1) @IdVigencia = V.VIIdVigencia
    FROM dbo.ff_Vigencia V
    WHERE V.VIIdConfiguracion = @IdConfiguracion
      AND V.VIIdEstatus = 1
    ORDER BY
        CASE WHEN CONVERT(DATE, GETDATE()) BETWEEN CONVERT(DATE, V.VIVigenciaIni)
             AND CONVERT(DATE, V.VIVigenciaFin) THEN 0 ELSE 1 END,
        V.VIVigenciaIni DESC,
        V.VIIdVigencia DESC;
END;

SELECT @IdVigenciaOrigen = V.VIRenovada
FROM dbo.ff_Vigencia V
WHERE V.VIIdVigencia = @IdVigencia
  AND V.VIIdConfiguracion = @IdConfiguracion
  AND V.VIIdEstatus = 1;

IF @IdVigencia IS NULL
    THROW 51921, 'No se encontro una vigencia activa para la empresa.', 1;

/* 01. Contrato funcional tomado del legacy y conservado por el motor BF3. */
SELECT *
FROM (VALUES
    (1, 'TIPO 1', 'Conservar selecciones anteriores',
        'Busca selecciones elegibles de la vigencia origen y las lleva a la vigencia destino.'),
    (2, 'TIPO 2', 'Asignar plan basico o espejo',
        'No depende de una eleccion previa; toma la configuracion basica vigente del perfil.'),
    (3, 'TIPO 3', 'Recalcular titular y dependientes',
        'Reevalua la composicion familiar elegible. En legacy solo se permite por empleados seleccionados.')
) T(Tipo, Nombre, ReglaPrincipal, ResultadoEsperado)
ORDER BY Tipo;

/* 02. Catalogo real. Debe devolver activos 1, 2 y 3. */
IF OBJECT_ID(N'dbo.ff_TipoDefaulteo', N'U') IS NOT NULL
    EXEC sys.sp_executesql N'
        SELECT ''02_CATALOGO_TIPOS'' AS Bloque,
               TDIdTipoDefaulteo AS Tipo,
               RTRIM(TDNombre) AS Nombre,
               TDIdEstatus AS Estatus
        FROM dbo.ff_TipoDefaulteo
        WHERE TDIdEstatus = 1
        ORDER BY TDIdTipoDefaulteo;';
ELSE
    SELECT '02_CATALOGO_TIPOS' AS Bloque, 'FALTA dbo.ff_TipoDefaulteo' AS Resultado;

/* 03. Objetos exactos consumidos por el flujo nuevo. */
DECLARE @Objetos TABLE
(
    Orden INT NOT NULL,
    Grupo VARCHAR(40) NOT NULL,
    TipoObjeto CHAR(2) NOT NULL,
    Nombre SYSNAME NOT NULL,
    Obligatorio BIT NOT NULL,
    Uso VARCHAR(300) NOT NULL
);

INSERT @Objetos (Orden, Grupo, TipoObjeto, Nombre, Obligatorio, Uso)
VALUES
 (1,  'CATALOGO', 'U', 'ff_TipoDefaulteo', 1, 'Tipos 1, 2 y 3.'),
 (2,  'BUSQUEDA', 'P', 'bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado', 1, 'Operacion guiada; excluye solicitudes activas/por autorizar.'),
 (3,  'BUSQUEDA', 'P', 'bf_DefaulteoAvanzado_Buscar', 1, 'Filtros avanzados; excluye solicitudes activas/por autorizar.'),
 (4,  'VIGENCIA', 'P', 'bf_DefaulteoAvanzado_ResolverVigencia', 1, 'Valida la vigencia por cada empresa.'),
 (5,  'MOTOR', 'P', 'ff_CBuscaPlanesPerfil_V31Test', 1, 'Calcula planes en vigencia actual con transfer def1/def2/def3.'),
 (6,  'MOTOR', 'P', 'ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3', 1, 'Calcula planes para multivigencia.'),
 (7,  'MOTOR', 'P', 'ff_IInsertaPlanesPerfilTmp', 1, 'Persiste seleccion temporal en flujo estandar actual.'),
 (8,  'MOTOR', 'P', 'ff_IInsertaPlanesPerfilTmpTestMultivigenciaBF3', 1, 'Persiste seleccion temporal multivigencia.'),
 (9,  'MOTOR_369', 'P', 'ff_IInsertaPlanesPerfilTmp_V2', 0, 'Variante actual para empresa 369.'),
 (10, 'MOTOR_369', 'P', 'ff_IInsertaPlanesPerfilTmp_V2TestMultivigenciaBF3', 0, 'Variante multivigencia para empresa 369.'),
 (11, 'SOLICITUD', 'P', 'ff_CreateSolicitudTest', 1, 'Crea la solicitud BF3.'),
 (12, 'SOLICITUD', 'P', 'bf_ValidaSolicitudExistente2', 1, 'Confirma que la solicitud fue creada.'),
 (13, 'LOTES', 'U', 'bf_LogDefaulteo', 1, 'Cabecera, contadores y estado del lote asincrono.'),
 (14, 'LOTES', 'U', 'bf_LogErroresDefaulteo', 1, 'Errores/advertencias por empleado.'),
 (15, 'LOTES', 'P', 'bf_LogDefaulteo_IniciarLote', 1, 'Abre el folio antes de procesar.'),
 (16, 'LOTES', 'P', 'bf_LogDefaulteo_RegistrarEvento', 1, 'Registra incidencias por empleado.'),
 (17, 'LOTES', 'P', 'bf_LogDefaulteo_FinalizarLote', 1, 'Cierra el folio aun con errores parciales.'),
 (18, 'LOTES', 'P', 'bf_LogDefaulteo_ConsultarLote', 1, 'Recupera el avance despues de recargar BF3.'),
 (19, 'LOTES', 'P', 'bf_LogDefaulteo_ObtenerEventos', 1, 'Descarga el detalle CSV.'),
 (20, 'CONFIG', 'U', 'bf_ConfiguracionDefaulteo', 1, 'Configuraciones guardadas por administrador.'),
 (21, 'CONFIG', 'P', 'bf_ConfiguracionDefaulteo_Guardar', 1, 'Alta/edicion segura por administrador.'),
 (22, 'CONFIG', 'P', 'bf_ConfiguracionDefaulteo_Eliminar', 1, 'Baja logica segura por administrador.'),
 (23, 'CONFIG', 'P', 'bf_ConfiguracionDefaulteo_Listar', 1, 'Lista solo configuraciones del administrador.'),
 (24, 'CATALOGO', 'P', 'bf_DefaulteoAvanzado_ListarPerfilesEmpresa', 1, 'Perfiles activos de la empresa.'),
 (25, 'HISTORICO', 'P', 'bf_ReporteDefaulteo_Consultar', 1, 'Consulta solicitudes/selecciones marcadas como defaulteo.'),
 (26, 'REGLA_OPCIONAL', 'P', 'bf_DefaulteoAvanzado_ReprocesarCambioPerfil', 0, 'Mejora optativa; una falla no aborta el motor base.'),
 (27, 'REGLA_OPCIONAL', 'P', 'bf_DefaulteoAvanzado_AplicaAntiguedad', 0, 'Solo aplica cuando la accion opt-in esta habilitada.');

SELECT
    '03_OBJETOS' AS Bloque,
    O.Grupo,
    CASE O.TipoObjeto WHEN 'U' THEN 'TABLA' ELSE 'SP' END AS Tipo,
    O.Nombre,
    CASE WHEN OBJECT_ID(N'dbo.' + O.Nombre, O.TipoObjeto) IS NOT NULL THEN 'OK'
         WHEN O.Obligatorio = 1 THEN 'FALTA_OBLIGATORIO'
         ELSE 'NO_INSTALADO_OPCIONAL' END AS Resultado,
    O.Uso
FROM @Objetos O
ORDER BY O.Orden;

/* 04. Empresa, vigencia y seguridad del usuario indicado. */
SELECT
    '04_CONTEXTO' AS Bloque,
    E.EMIdEmpresa AS IdEmpresa,
    E.EMNombre AS Empresa,
    @IdConfiguracion AS IdConfiguracion,
    @IdVigencia AS IdVigenciaDestino,
    @IdVigenciaOrigen AS IdVigenciaOrigen,
    @IdAdministrador AS IdAdministradorEvaluado,
    CASE
        WHEN @IdAdministrador IS NULL THEN 'NO_EVALUADO: CAPTURE @IdAdministrador'
        WHEN EXISTS
        (
            SELECT 1 FROM dbo.ff_AdministradorEmpresa AE
            WHERE AE.ADIdAdministrador = @IdAdministrador
              AND AE.AEIdEmpresa = @IdEmpresa
              AND AE.AEIdEstatus = 1
        ) THEN 'OK_ACCESO_EMPRESA'
        ELSE 'FALTA_ACCESO_EMPRESA'
    END AS Seguridad
FROM dbo.ff_Empresa E
WHERE E.EMIdEmpresa = @IdEmpresa;

/*
  05. Candidatos orientativos. La validacion definitiva siempre la hace el
  motor ff_CBuscaPlanesPerfil_V31* porque evalua tarifas, parentescos, edades,
  planes y reglas particulares de cada configuracion.
*/
IF OBJECT_ID(N'dbo.ff_Empleado', N'U') IS NOT NULL
AND OBJECT_ID(N'dbo.ff_Perfil', N'U') IS NOT NULL
AND OBJECT_ID(N'dbo.ff_Solicitud', N'U') IS NOT NULL
AND OBJECT_ID(N'dbo.ff_PlanOpcionSeleccion', N'U') IS NOT NULL
AND OBJECT_ID(N'dbo.ff_PlanBasico', N'U') IS NOT NULL
BEGIN
    DECLARE @SqlCandidatos NVARCHAR(MAX) = N'
    SELECT TOP (@Top)
        ''05_CANDIDATOS'' AS Bloque,
        E.Id AS IdEmpleado,
        E.EMNumeroEmpleado AS NumeroEmpleado,
        LTRIM(RTRIM(ISNULL(E.EMNombre1, '''') + '' '' + ISNULL(E.EMNombre2, '''')
          + '' '' + ISNULL(E.EMApellidoPaterno, '''') + '' '' + ISNULL(E.EMApellidoMaterno, ''''))) AS Nombre,
        E.EMIdPerfil AS IdPerfil,
        P.PEDescripcion AS Perfil,
        X.SeleccionesOrigen,
        B.PlanesBasicosDestino,
        D.DependientesActivos,
        CASE WHEN X.SeleccionesOrigen > 0 THEN ''APTO_PRELIMINAR'' ELSE ''REQUIERE_SELECCION_ORIGEN'' END AS Tipo1,
        CASE WHEN B.PlanesBasicosDestino > 0 THEN ''APTO_PRELIMINAR'' ELSE ''REQUIERE_PLAN_BASICO'' END AS Tipo2,
        CASE WHEN D.DependientesActivos > 0 THEN ''APTO_PRELIMINAR_CON_FAMILIA'' ELSE ''APTO_PRELIMINAR_SIN_DEPENDIENTES'' END AS Tipo3
    FROM dbo.ff_Empleado E
    INNER JOIN dbo.ff_Perfil P ON P.PEIdPerfil = E.EMIdPerfil AND P.PEIdEstatus = 1
    OUTER APPLY
    (
        SELECT COUNT(*) AS SeleccionesOrigen
        FROM dbo.ff_PlanOpcionSeleccion POS
        WHERE POS.POIdEmpleado = E.Id
          AND POS.POIdEmpresa = @IdEmpresa
          AND POS.POIdVigencia = @IdVigenciaOrigen
          AND POS.POIdEstatus = 1
    ) X
    OUTER APPLY
    (
        SELECT COUNT(*) AS PlanesBasicosDestino
        FROM dbo.ff_PlanBasico PB
        WHERE PB.PBIdPerfil = E.EMIdPerfil
          AND PB.PBIdVigencia = @IdVigencia
          AND PB.PBIdEstatus = 1
    ) B
    OUTER APPLY
    (
        SELECT COUNT(*) AS DependientesActivos
        FROM dbo.ff_Empleado DEP
        WHERE DEP.EMIdTitular = E.Id
          AND DEP.EMIdParentesco <> 1
          AND DEP.EMIdEstatus = 1
    ) D
    WHERE E.EMIdEmpresa = @IdEmpresa
      AND E.EMIdTitular = 1
      AND E.EMIdEstatus = 1
      AND NOT EXISTS
      (
          SELECT 1
          FROM dbo.ff_Solicitud S
          WHERE S.SOIdEmpleado = E.Id
            AND S.SOIdEmpresa = @IdEmpresa
            AND S.SOIdVigencia = @IdVigencia
            AND S.SOIdEstatus IN (1, 10)
            AND S.SOEstatusSolicitud IN (1, 3)
      )
    ORDER BY
        CASE WHEN X.SeleccionesOrigen > 0 THEN 0 ELSE 1 END,
        CASE WHEN B.PlanesBasicosDestino > 0 THEN 0 ELSE 1 END,
        E.Id;';

    EXEC sys.sp_executesql @SqlCandidatos,
        N'@IdEmpresa INT, @IdVigencia INT, @IdVigenciaOrigen INT, @Top INT',
        @IdEmpresa, @IdVigencia, @IdVigenciaOrigen, @Top;
END
ELSE
    SELECT '05_CANDIDATOS' AS Bloque,
           'No se genero el listado porque falta una tabla base indicada en 03_OBJETOS.' AS Resultado;

/* 06. Comprobacion posterior: una solicitud correcta debe excluir al empleado. */
IF OBJECT_ID(N'dbo.ff_Solicitud', N'U') IS NOT NULL
BEGIN
    DECLARE @SqlSolicitudes NVARCHAR(MAX) = N'
    SELECT TOP (@Top)
        ''06_SOLICITUDES_CREADAS'' AS Bloque,
        S.SOIdSolicitud,
        S.SONumeroSolicitud,
        S.SOAnexoSolicitud,
        S.SOIdEmpleado,
        E.EMNumeroEmpleado,
        S.SOIdVigencia,
        S.SOIdEstatus,
        S.SOEstatusSolicitud,
        S.SOFechaAdd,
        CASE WHEN EXISTS
        (
            SELECT 1 FROM dbo.ff_PlanOpcionSeleccion POS
            WHERE POS.POIdSolicitud = S.SOIdSolicitud
              AND POS.PODefaulteo = 1
              AND POS.POIdEstatus = 1
        ) THEN ''OK_MARCADA_COMO_DEFAULTEO'' ELSE ''REVISAR_SIN_MARCA_DEFAULTEO'' END AS Resultado
    FROM dbo.ff_Solicitud S
    INNER JOIN dbo.ff_Empleado E ON E.Id = S.SOIdEmpleado
    WHERE S.SOIdEmpresa = @IdEmpresa
      AND S.SOIdVigencia = @IdVigencia
      AND S.SOIdEstatus IN (1, 10)
      AND S.SOEstatusSolicitud IN (1, 3)
    ORDER BY S.SOFechaAdd DESC, S.SOIdSolicitud DESC;';

    EXEC sys.sp_executesql @SqlSolicitudes,
        N'@IdEmpresa INT, @IdVigencia INT, @Top INT',
        @IdEmpresa, @IdVigencia, @Top;
END;

SELECT
    '07_RESUMEN' AS Bloque,
    @IdEmpresa AS IdEmpresa,
    @IdVigencia AS IdVigenciaDestino,
    @IdVigenciaOrigen AS IdVigenciaOrigen,
    SUM(CASE WHEN O.Obligatorio = 1 THEN 1 ELSE 0 END) AS ObjetosObligatorios,
    SUM(CASE WHEN O.Obligatorio = 1
              AND OBJECT_ID(N'dbo.' + O.Nombre, O.TipoObjeto) IS NOT NULL THEN 1 ELSE 0 END) AS ObligatoriosOK,
    SUM(CASE WHEN O.Obligatorio = 1
              AND OBJECT_ID(N'dbo.' + O.Nombre, O.TipoObjeto) IS NULL THEN 1 ELSE 0 END) AS ObligatoriosFaltantes,
    CASE WHEN SUM(CASE WHEN O.Obligatorio = 1
                        AND OBJECT_ID(N'dbo.' + O.Nombre, O.TipoObjeto) IS NULL THEN 1 ELSE 0 END) = 0
         THEN 'OK_ESTRUCTURA'
         ELSE 'INCOMPLETO: REVISE 03_OBJETOS' END AS Resultado
FROM @Objetos O;
GO
