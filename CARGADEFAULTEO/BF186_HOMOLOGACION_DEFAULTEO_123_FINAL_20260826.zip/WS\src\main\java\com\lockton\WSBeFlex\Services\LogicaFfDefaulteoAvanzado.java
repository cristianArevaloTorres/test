package com.lockton.WSBeFlex.Services;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.DAO.FfDefaulteoAvanzadoDAO;
import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionDefaulteo;
import com.lockton.WSBeFlex.POJO.Especiales.FFEjecutarDefaulteoAvanzado;
import com.lockton.WSBeFlex.POJO.Especiales.FFFiltroDefaulteoAvanzado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * CREA 06 - Implementacion de {@link FfDefaulteoAvanzadoService}.
 *
 * El "ejecutar" delega al flujo existente {@link FfTitularService#defaultearEmpleadosMasivo}
 * iterando por empleado para poder capturar errores individuales sin abortar el lote.
 */
@Service
public class LogicaFfDefaulteoAvanzado implements FfDefaulteoAvanzadoService {

    @Autowired
    private FfDefaulteoAvanzadoDAO dao;

    @Autowired
    private DefaulteoAvanzadoAsyncRunner asyncRunner;

    @Autowired
    private ProgresoDefaulteoRegistry progreso;

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Override
    public boolean tieneAccesoEmpresas(int idAdmin, int[] idsEmpresa) {
        return dao.tieneAccesoEmpresas(idAdmin, idsEmpresa);
    }

    @Override
    public boolean tieneAccesoEmpleados(int idAdmin, int[] idsEmpleado) {
        return dao.tieneAccesoEmpleados(idAdmin, idsEmpleado);
    }

    @Override
    public boolean lotePerteneceAdministrador(int idLog, int idAdmin) {
        return dao.lotePerteneceAdministrador(idLog, idAdmin);
    }

    @Override
    public boolean configuracionPerteneceAdministrador(int idConfiguracion, int idAdmin) {
        return dao.configuracionPerteneceAdministrador(idConfiguracion, idAdmin);
    }

    @Override
    public List<Object> buscarEmpleados(FFFiltroDefaulteoAvanzado f) {
        return dao.buscarEmpleados(f);
    }

    /**
     * Inicia el lote y lanza el procesamiento en BACKGROUND. Responde de
     * inmediato con { idLog, estado:"EN_PROCESO", totalEmpleados } para que el
     * request HTTP no quede colgado hasta terminar (evita el timeout del gateway).
     * El avance se consulta despues via {@link #consultarEstado(int)}.
     */
    @Override
    public Map<String, Object> ejecutar(FFEjecutarDefaulteoAvanzado req, String ipOrigen) {
        int totalEmpleados = req.idEmpleado != null ? req.idEmpleado.length : 0;
        int idAdmin        = req.idAdmin != null ? req.idAdmin : 0;
        String filtrosJson  = toJson(req.filtros);
        String accionesJson = toJson(req.acciones);

        Integer idLog = dao.iniciarLote(
                req.idConfiguracion, req.idCorporativo, req.idEmpresa, req.idVigencia,
                idAdmin, filtrosJson, accionesJson, totalEmpleados, ipOrigen, "AVANZADO");

        if (idLog == null) {
            throw new IllegalStateException("No se pudo iniciar el lote de defaulteo (idLog nulo)");
        }

        // Registra el lote en memoria y lo lanza en background.
        progreso.iniciar(idLog, totalEmpleados);
        asyncRunner.procesarLote(idLog, req);

        Map<String, Object> resp = new HashMap<>();
        resp.put("idLog",          idLog);
        resp.put("estado",         ProgresoDefaulteoRegistry.EN_PROCESO);
        resp.put("totalEmpleados", totalEmpleados);
        resp.put("totalExitosos",  0);
        resp.put("totalErrores",   0);
        resp.put("procesados",     0);
        return resp;
    }

    /**
     * Estado de un lote para el polling del front. Mientras corre, lo toma del
     * registro en memoria (con avance procesados/total); si ya no esta en
     * memoria (finalizado hace rato o el server se reinicio), lo lee de
     * bf_LogDefaulteo.
     */
    @Override
    public Map<String, Object> consultarEstado(int idLog) {
        Map<String, Object> live = progreso.snapshot(idLog);
        if (live != null) {
            return live;
        }
        Map<String, Object> bd = dao.consultarLote(idLog);
        if (bd == null) {
            Map<String, Object> noEnc = new LinkedHashMap<>();
            noEnc.put("idLog",  idLog);
            noEnc.put("estado", "NO_ENCONTRADO");
            return noEnc;
        }
        return bd;
    }

    @Override
    public Integer guardarConfiguracion(FFConfiguracionDefaulteo c) {
        return dao.guardarConfiguracion(c);
    }

    @Override
    public void eliminarConfiguracion(int id, int idAdmin) {
        dao.eliminarConfiguracion(id, idAdmin);
    }

    @Override
    public List<Object> listarConfiguraciones(Integer idCorporativo, Integer idEmpresa, Integer idAdmin) {
        return dao.listarConfiguraciones(idCorporativo, idEmpresa, idAdmin);
    }

    @Override
    public List<Map<String, Object>> obtenerEventosDeLote(int idLog) {
        return dao.obtenerEventosDeLote(idLog);
    }

    @Override
    public List<Map<String, Object>> listarPerfilesEmpresa(int idEmpresa) {
        return dao.listarPerfilesEmpresa(idEmpresa);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private String toJson(Object o) {
        if (o == null) return null;
        try {
            return MAPPER.writeValueAsString(o);
        } catch (Exception e) {
            return null;
        }
    }
}
