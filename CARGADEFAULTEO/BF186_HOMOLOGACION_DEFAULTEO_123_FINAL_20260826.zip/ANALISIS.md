# Análisis de homologación de Defaulteo 1, 2 y 3: legacy vs. BF3

Fecha de revisión: 26 de agosto de 2026  
Nueva ubicación: `/pages/administracion/titulares/defaulteo`

## Conclusión ejecutiva

El cálculo de Defaulteo 1, 2 y 3 no se volvió a programar desde cero. BF3 reutiliza su motor ya existente de búsqueda de planes, inserción temporal y creación de solicitudes, enviándole el mismo indicador funcional que usa el legacy: `def1`, `def2` o `def3`.

La homologación nueva construye la operación alrededor de ese motor: selección segura de empleados, validación de empresa y vigencia, ejecución asincrónica, trazabilidad por folio, recuperación después de recargar la página, exclusión de empleados que ya tienen solicitud y consulta histórica.

Durante esta revisión se encontraron y corrigieron tres huecos en la ruta nueva:

1. La operación guiada podía quedarse esperando a que terminara todo el lote dentro del mismo request. Ahora usa el procesamiento asincrónico y consulta el avance por folio.
2. La consulta guiada reutilizaba un SP con columnas y operadores recibidos como texto. Ahora pasa por un endpoint exclusivo que valida token, empresas, perfiles, vigencia, atributos y operadores antes de llamar al SP.
3. El Java ya esperaba tablas y SP de trazabilidad/configuraciones, pero sus definiciones no estaban dentro de los scripts del repositorio. Se agregó una instalación idempotente del contrato exacto consumido por Java.

La pantalla anterior en `administracion/solicitudes/defaulteo` queda intacta. Tampoco se modifica el código ASP.NET del sistema legacy.

## Qué hace cada tipo

| Tipo | Entrada funcional | Flujo de información | Qué debe verse al terminar |
|---|---|---|---|
| 1 | Empleado y sus selecciones elegibles de la vigencia origen | El motor recibe `transfer=def1`, consulta las elecciones anteriores y genera las selecciones aplicables para la vigencia destino | Solicitud nueva con los planes que pudieron conservarse; las opciones quedan marcadas como originadas por defaulteo |
| 2 | Empleado, perfil y configuración básica/espejo de la vigencia destino | El motor recibe `transfer=def2`; no requiere que el empleado haya elegido planes previamente | Solicitud nueva con el plan básico o espejo configurado para el perfil |
| 3 | Titular seleccionado y su composición familiar elegible | El motor recibe `transfer=def3` y recalcula las opciones según titular, dependientes, parentesco, sexo, edad, tarifas y reglas vigentes | Solicitud nueva con la composición recalculada; puede diferir de la selección anterior si cambió la familia o la elegibilidad |

El tipo 3 no es una copia literal de todas las selecciones anteriores. Su propósito es volver a evaluar la composición familiar con la configuración vigente.

## Flujo comprobado en el legacy

La pantalla legacy es `FlexiForbesV2/Plan/DefaulteoV2.aspx`.

1. Lee los tipos activos desde `ff_TipoDefaulteo`.
2. Busca empleados con `bf_DefaulteoEmpleados`.
3. Para cada empleado seleccionado llama `ff_IProcesoDefaulteoxEmpresa_V2(@idEmpresa, @idEmpleado, @tipoDefault)`.
4. Por cada empleado devuelto crea la solicitud con `ff_CreateSolicitud`.

La opción de empresa completa del legacy solo permite los tipos 1 y 2. El código rechaza un índice mayor a 2. El tipo 3 se ejecuta únicamente sobre empleados seleccionados.

Las pantallas legacy `ff_Genera_PDF_Defaulteo.aspx` y `ff_Envia_Notificacion_Defaulteo.aspx` son procesos posteriores separados; no forman parte de la creación básica de la solicitud. Por eso no deben invocarse automáticamente desde el botón de BF3.

## Flujo comprobado en BF3

La nueva pantalla envía el tipo numérico 1, 2 o 3. `FFEjecutarDefaulteoAvanzado.toFfDefaulteo()` lo convierte en `def1`, `def2` o `def3`.

Por cada empleado, el backend:

1. Obtiene la empresa real desde `ff_Empleado`; no confía en una empresa enviada libremente por la pantalla.
2. Valida que la vigencia pertenezca a la configuración de esa empresa con `bf_DefaulteoAvanzado_ResolverVigencia`.
3. Ejecuta el motor de planes:
   - vigencia actual: `ff_CBuscaPlanesPerfil_V31Test`;
   - multivigencia: `ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3`.
4. Envía `transfer=def1`, `def2` o `def3` al motor existente.
5. Reúne únicamente las opciones que el motor devuelve con `Checked=true`.
6. Si no hay opciones elegibles, reporta error para ese empleado y no crea una solicitud vacía.
7. Persiste la selección temporal con el SP correspondiente:
   - `ff_IInsertaPlanesPerfilTmp`;
   - `ff_IInsertaPlanesPerfilTmpTestMultivigenciaBF3`;
   - variantes `_V2` para la empresa 369.
8. Crea la solicitud mediante `ff_CreateSolicitudTest`.
9. Confirma el resultado con `bf_ValidaSolicitudExistente2`.
10. Continúa con los demás empleados aunque uno falle y conserva el detalle de la incidencia.

## Qué construimos y qué reutilizamos

### Reutilizado

- Catálogo `ff_TipoDefaulteo`.
- Tablas funcionales `ff_Empleado`, `ff_Empresa`, `ff_Perfil`, `ff_Vigencia`, `ff_Solicitud`, `ff_PlanBasico` y `ff_PlanOpcionSeleccion`.
- Motor BF3 `ff_CBuscaPlanesPerfil_V31Test` y su variante multivigencia.
- SP de inserción temporal de planes y sus variantes.
- Creación y confirmación de solicitudes con `ff_CreateSolicitudTest` y `bf_ValidaSolicitudExistente2`.
- Servicio Java `FfTitularService.defaultearEmpleadosMasivo` como núcleo funcional.
- API de reportes para la consulta histórica de selecciones con `PODefaulteo=1`.

### Construido o integrado para la nueva ubicación

- Módulo Angular aislado en `administracion/titulares/defaulteo`.
- Operación guiada con explicación de los tipos 1, 2 y 3.
- Filtros avanzados, configuraciones guardadas e histórico dentro del módulo nuevo.
- Endpoint seguro `POST /beflex/defaulteo-titulares/buscar-guiado`.
- Endpoint/lógica de lotes asincrónicos bajo `/beflex/defaulteo-avanzado`.
- Progreso, folio, recuperación después de recargar y descarga de errores.
- Tablas/SP `bf_*` para configuraciones y trazabilidad.
- Exclusión en las búsquedas de empleados que ya tienen solicitud activa o por autorizar en la vigencia destino.
- Ruta y opción de menú bajo Administración de titulares y dependientes.

## Solicitudes existentes y empleados que deben desaparecer

Después de un procesamiento correcto, el empleado ya no debe aparecer como pendiente para la misma vigencia.

Las dos búsquedas nuevas excluyen solicitudes que cumplan simultáneamente:

- `SOIdEstatus IN (1, 10)`;
- `SOEstatusSolicitud IN (1, 3)`, que corresponde a autorizada o por autorizar;
- misma empresa y vigencia destino.

Una solicitud rechazada o cancelada no bloquea permanentemente al empleado: puede volver a procesarse. Esto evita duplicar solicitudes vigentes y permite corregir un caso rechazado.

La pantalla también elimina duplicados por `IdEmpleado` como protección adicional durante despliegues escalonados.

## Diferencias deliberadas respecto del legacy

- El legacy tiene un botón sin límite para procesar una empresa completa, pero solo para tipos 1 y 2.
- BF3 usa selección explícita y filtros. El usuario puede seleccionar todos los resultados devueltos, pero no se ejecuta silenciosamente una empresa completa fuera del conjunto revisado.
- El tipo 3 conserva la restricción conceptual del legacy: solo empleados seleccionados.
- PDF y correo siguen siendo procesos posteriores; no se acoplaron a la transacción de defaulteo.

Esta diferencia reduce el riesgo de lanzar accidentalmente miles de solicitudes y permite conservar trazabilidad por empleado.

## Seguridad incorporada

- El administrador efectivo se obtiene del JWT; se ignora cualquier ID de administrador enviado por el navegador.
- Las empresas se deduplican y se validan contra `ff_AdministradorEmpresa`.
- Los empleados seleccionados se vuelven a validar contra las empresas accesibles al administrador.
- La consulta guiada acepta únicamente cinco atributos conocidos y seis operadores conocidos.
- El endpoint guiado fuerza `CasosEspeciales=0`; no puede cambiarse a otro SP agregando un campo al request.
- Cada folio, configuración y descarga se valida contra el administrador autenticado.

## Objetos nuevos de base de datos

El archivo `007_infraestructura_lotes_defaulteo.sql` agrega únicamente si no existen:

- `bf_ConfiguracionDefaulteo`;
- `bf_LogDefaulteo`;
- `bf_LogErroresDefaulteo`.

También instala o actualiza:

- `bf_LogDefaulteo_IniciarLote`;
- `bf_LogDefaulteo_RegistrarEvento`;
- `bf_LogDefaulteo_FinalizarLote`;
- `bf_LogDefaulteo_ConsultarLote`;
- `bf_LogDefaulteo_ObtenerEventos`;
- `bf_ConfiguracionDefaulteo_Listar`;
- `bf_DefaulteoAvanzado_ListarPerfilesEmpresa`.

Si una tabla con el mismo nombre ya existe pero le falta una columna requerida, el script se detiene y la muestra. No intenta reconstruir ni alterar a ciegas una tabla existente.

## Cómo comprobar correctamente cada tipo

1. Ejecute `VALIDAR_HOMOLOGACION_DEFAULTEO_1_2_3.sql` y revise que `07_RESUMEN` diga `OK_ESTRUCTURA`.
2. Use el bloque `05_CANDIDATOS`:
   - tipo 1: prefiera `Tipo1=APTO_PRELIMINAR`;
   - tipo 2: prefiera `Tipo2=APTO_PRELIMINAR`;
   - tipo 3: pruebe uno con dependientes y otro sin dependientes.
3. Procese un empleado por prueba y conserve el folio.
4. Espere `COMPLETADO` o `COMPLETADO_CON_ERRORES`.
5. Compruebe en `06_SOLICITUDES_CREADAS` que exista la solicitud en la vigencia destino y que el resultado sea `OK_MARCADA_COMO_DEFAULTEO`.
6. Repita la búsqueda de pendientes. El empleado correcto debe desaparecer.
7. Revise el histórico. Debe mostrar la solicitud y sus opciones defaulteadas.

El bloque de candidatos es orientativo. La decisión final siempre pertenece al motor, porque este evalúa tarifas, edades, sexos, parentescos, planes, coberturas y reglas específicas de la configuración.

## Verificaciones realizadas en el código

- TypeScript de la aplicación BF3: compilación estática exitosa con `tsc --noEmit`.
- Ruta nueva: registrada bajo `administracion/titulares/defaulteo`.
- Mapeo: tipos 1/2/3 terminan como `def1/def2/def3`.
- Operación guiada: ya no contiene el camino síncrono anterior ni el mapeo muerto que podía enviar el tipo 3 como `def1`.
- Pantalla anterior: comparada contra los archivos originales; no hay cambio funcional.
- Pruebas Java agregadas para token inválido, atributo no permitido, deduplicación de empresas, administrador tomado del JWT y bloqueo de `CasosEspeciales`.

La ejecución Maven completa no pudo finalizar sin VPN porque el `pom.xml` descarga WSDL internos durante `generate-sources`. No se omitió un error del cambio: el bloqueo ocurre antes de compilar estos archivos y corresponde a dependencias externas del proyecto. La validación dinámica contra SQL Server también queda para el ambiente con conexión; el script entregado es de solo lectura.

