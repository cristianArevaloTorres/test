package com.lockton.WSBeFlex.POJO.Especiales;

import java.math.BigDecimal;
import java.util.Date;

/**
 * CREA 06 RN001 / RN010 - Filtros avanzados de defaulteo (15 campos).
 * Se mapea uno-a-uno con los parametros de bf_DefaulteoAvanzado_Buscar.
 * Listas multi-valor llegan como arrays y el DAO las serializa a CSV.
 */
public class FFFiltroDefaulteoAvanzado {

    public Integer idCorporativo;
    public Integer idVigencia;

    public int[]    idsEmpresa;
    public int[]    idsPerfil;
    public int[]    idsOficina;
    public int[]    idsArea;
    public int[]    idsSexo;
    public int[]    idsParentesco;
    public int[]    idsPlan;
    public int[]    idsCobertura;
    public String[] numerosEmpleado;

    public BigDecimal salarioMin;
    public BigDecimal salarioMax;
    public BigDecimal sumaAseguradaMin;
    public BigDecimal sumaAseguradaMax;

    public Date fechaIngresoIni;
    public Date fechaIngresoFin;
    public Date fechaAntiguedadIni;
    public Date fechaAntiguedadFin;
    public Date fechaNacimientoIni;
    public Date fechaNacimientoFin;
    public Date fechaVigenciaIni;
    public Date fechaVigenciaFin;

    // Filtros adicionales del Anexo del documento
    public String  nombre;
    public String  apellidoPaterno;
    public String  apellidoMaterno;
    public Integer edadMin;
    public Integer edadMax;

    public Integer top;
}
