import { Component, OnInit } from '@angular/core';
import { MenusService } from 'src/app/services/menus.service';
import { GLOBAL } from "../../../../services/global";
import { EmpleadoService } from "../../../../services/empleado.service";

@Component({
  selector: 'app-reporte-defaulteo-casos-especiales',
  templateUrl: './reporte-defaulteo-casos-especiales.component.html',
  styleUrls: ['../reporte-defaulteo.component.css']
})
export class ReporteDefaulteoCasosEspecialesComponent implements OnInit {

  public title: string;
  public banner;
  public urlWs;
  public identity;
  public id;

  constructor(
    private _menuService: MenusService,
    private _empleadoService: EmpleadoService
  ) {
    this.title = 'Crear y Actualizar Solicitudes Casos especiales';
    this.urlWs = GLOBAL.url2;
  }

  ngOnInit() {
    this.banner = this._menuService.getbackground();
    this.identity = this._empleadoService.getIdentity();
    this.menuId();
  }

  menuId() {
    let informacion = JSON.parse(localStorage.getItem("MenuPadre"));
    if (informacion != "undefined") {
      this.id = informacion;
    } else {
      this.id = null;
    }
  }

}
