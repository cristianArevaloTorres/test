# Paquete final de homologación de Defaulteo 1, 2 y 3

## Resultado

Los cambios funcionales están aislados en la ruta nueva:

`/pages/administracion/titulares/defaulteo`

La ruta anterior conserva su pantalla original:

`/pages/administracion/solicitudes/defaulteo`

El paquete no contiene cambios para el proyecto ASP.NET legacy.

## Contenido del ZIP

- `01_FRONT_BF3`: módulo completo de la ruta nueva, servicios y archivo de rutas.
- `02_BACKEND_JAVA`: fachada segura de la operación guiada, motor asincrónico, trazabilidad y pruebas.
- `03_API_REPORTES`: endpoint y repositorio del histórico de defaulteo.
- `04_SQL_INSTALACION`: objetos requeridos por el flujo nuevo y alta del menú.
- `05_SQL_VALIDACION`: diagnóstico de solo lectura para tipos 1, 2 y 3.
- `06_RESTAURAR_PANTALLA_ORIGINAL`: archivos originales de la pantalla anterior por si el ambiente todavía conserva una versión modificada.
- `ANALISIS.md`: comparación profunda contra el legacy y explicación de los flujos.

## Orden de instalación

1. Respaldar los proyectos y la base de datos del ambiente destino.
2. Si la pantalla anterior fue modificada en ese ambiente, copiar primero `06_RESTAURAR_PANTALLA_ORIGINAL` sobre el proyecto front.
3. Copiar `01_FRONT_BF3`, `02_BACKEND_JAVA` y `03_API_REPORTES` respetando exactamente las carpetas `src/...`.
4. Ejecutar los SQL en este orden:
   1. `01_007_infraestructura_lotes_defaulteo.sql`;
   2. `02_003_seguridad_y_vigencia_defaulteo_avanzado.sql`;
   3. `03_005_compatibilidad_idcorporativo_inserta_planes.sql`;
   4. `04_006_exclusion_solicitudes_generadas_defaulteo.sql`;
   5. `05_002_reporte_historico_defaulteo.sql`;
   6. `06_CONFIGURAR_MENU_DEFAULTEO_EMPRESA_186.sql`.
5. Ejecutar `05_SQL_VALIDACION/VALIDAR_HOMOLOGACION_DEFAULTEO_1_2_3.sql`.
6. Compilar y desplegar BF3, WSBeFlex y API Reportes.
7. Cerrar sesión, borrar `localStorage.menurol` si el menú estaba en caché y volver a entrar.

## Archivos que se reemplazan y archivos nuevos

### Front BF3

Se reemplaza:

- `src/app/beflex/pages-routing.module.ts`.

Se agregan/reemplazan únicamente para la ruta nueva:

- `src/app/beflex/administracion/titulares/defaulteo/**`;
- `src/app/services/defaulteo-titulares-avanzado.service.ts`;
- `src/app/services/defaulteo-titulares-historico.service.ts`.

No es necesario borrar manualmente otra carpeta. La pantalla anterior se restaura copiando la carpeta incluida en `06_RESTAURAR_PANTALLA_ORIGINAL` solo si el ambiente aún tiene cambios viejos.

### WSBeFlex

Copiar todos los archivos incluidos. `WSDefaulteoTitulares.java` es nuevo; los demás conforman el motor asincrónico y sus contratos.

### API Reportes

Copiar los dos archivos incluidos. No hay cambios adicionales en esa API.

## Validación mínima en pantalla

Para cada tipo, use un solo empleado primero:

1. Tipo 1: empleado con selecciones activas en la vigencia origen.
2. Tipo 2: empleado cuyo perfil tenga plan básico activo en la vigencia destino.
3. Tipo 3: un titular con dependientes activos y otro sin dependientes.

En los tres casos:

- el servidor debe devolver un folio sin mantener bloqueado el request;
- el progreso debe avanzar hasta `COMPLETADO` o `COMPLETADO_CON_ERRORES`;
- si terminó correctamente, debe existir la solicitud y el empleado debe desaparecer de pendientes para esa vigencia;
- si falló, el empleado debe permanecer disponible y el detalle debe poder descargarse por folio.

## Verificaciones ejecutadas

- `npx tsc -p src/tsconfig.app.json --noEmit`: correcto.
- Revisión estática del mapeo 1/2/3 a `def1/def2/def3`: correcto.
- Comparación de la pantalla anterior con los archivos originales: sin diferencia funcional.
- Pruebas unitarias Java incluidas para la nueva fachada de búsqueda.

La ejecución Maven integral requiere los WSDL internos que el `pom.xml` descarga durante `generate-sources`; sin VPN no puede completarse. La ejecución dinámica de los SP requiere la conexión a SQL Server del ambiente.

