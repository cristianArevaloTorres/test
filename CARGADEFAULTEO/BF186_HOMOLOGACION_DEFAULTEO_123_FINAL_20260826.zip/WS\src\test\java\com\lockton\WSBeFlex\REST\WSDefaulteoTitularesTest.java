package com.lockton.WSBeFlex.REST;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lockton.WSBeFlex.Services.FfDefaulteoAvanzadoService;
import com.lockton.WSBeFlex.Services.FfTitularService;
import com.lockton.WSBeFlex.Services.GeneralesService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.UsuarioToken;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

class WSDefaulteoTitularesTest {

    private WSDefaulteoTitulares controller;
    private FfTitularService titularService;
    private FfDefaulteoAvanzadoService seguridad;
    private GeneralesService generales;
    private JwtService jwt;

    @BeforeEach
    void preparar() {
        controller = new WSDefaulteoTitulares();
        titularService = mock(FfTitularService.class);
        seguridad = mock(FfDefaulteoAvanzadoService.class);
        generales = mock(GeneralesService.class);
        jwt = mock(JwtService.class);
        ReflectionTestUtils.setField(controller, "titularService", titularService);
        ReflectionTestUtils.setField(controller, "seguridadDefaulteo", seguridad);
        ReflectionTestUtils.setField(controller, "generalService", generales);
        ReflectionTestUtils.setField(controller, "jwtService", jwt);
    }

    @Test
    void rechazaTokenInvalido() {
        when(generales.validarTokenId(anyInt(), anyString(), anyInt())).thenReturn(false);
        ResponseEntity<List<Object>> respuesta = controller.buscarGuiado(peticionValida(), "token");
        assertEquals(HttpStatus.UNAUTHORIZED, respuesta.getStatusCode());
        verify(titularService, never()).busquedaDefaulteoAvanzada(any());
    }

    @Test
    void rechazaAtributoNoPermitidoAntesDeInvocarElSp() {
        autenticar(25);
        Map<String, Object> peticion = peticionValida();
        peticion.put("idAtributo1", "EMNumeroEmpleado; DROP TABLE ff_Empleado");

        ResponseEntity<List<Object>> respuesta = controller.buscarGuiado(peticion, "token");

        assertEquals(HttpStatus.BAD_REQUEST, respuesta.getStatusCode());
        verify(titularService, never()).busquedaDefaulteoAvanzada(any());
    }

    @Test
    void normalizaEmpresasDuplicadasYUsaAdministradorDelToken() {
        autenticar(25);
        when(seguridad.tieneAccesoEmpresas(anyInt(), any(int[].class))).thenReturn(true);
        List<Object> filas = new ArrayList<>();
        filas.add(new HashMap<String, Object>());
        when(titularService.busquedaDefaulteoAvanzada(any())).thenReturn(filas);
        Map<String, Object> peticion = peticionValida();
        peticion.put("IdsEmpresas", "186,186");
        peticion.put("IdAdministrador", 9999);
        peticion.put("CasosEspeciales", "1");

        ResponseEntity<List<Object>> respuesta = controller.buscarGuiado(peticion, "token");

        assertEquals(HttpStatus.OK, respuesta.getStatusCode());
        assertEquals(25, peticion.get("IdAdministrador"));
        assertEquals("186", peticion.get("IdsEmpresas"));
        assertEquals("0", peticion.get("CasosEspeciales"));
        ArgumentCaptor<int[]> empresas = ArgumentCaptor.forClass(int[].class);
        verify(seguridad).tieneAccesoEmpresas(anyInt(), empresas.capture());
        assertArrayEquals(new int[] { 186 }, empresas.getValue());
    }

    private void autenticar(int idAdmin) {
        UsuarioToken usuario = new UsuarioToken();
        usuario.n = idAdmin;
        when(generales.validarTokenId(anyInt(), anyString(), anyInt())).thenReturn(true);
        when(jwt.getPayloadFromToken(anyString())).thenReturn(usuario);
    }

    private Map<String, Object> peticionValida() {
        Map<String, Object> peticion = new HashMap<>();
        peticion.put("IdsEmpresas", "186");
        peticion.put("IdAdministrador", 25);
        peticion.put("idPerfiles", "1");
        peticion.put("idAtributo1", "EMNumeroEmpleado");
        peticion.put("idAtributo2", "EMNumeroEmpleado");
        peticion.put("idTipoOperador1", "contiene");
        peticion.put("idTipoOperador2", "contiene");
        peticion.put("parametroBusqueda1", "");
        peticion.put("parametroBusqueda2", "");
        peticion.put("BusquedaAvanzada", 0);
        peticion.put("idTipoOperadorAvanzado", "and");
        peticion.put("Vigencia", 2026);
        return peticion;
    }
}
