package com.lockton.WSBeFlex.POJO.Especiales;

/**
 * CREA 06 RN003 / RN009 - DTO CRUD de configuraciones guardadas.
 * Filtros y acciones viajan como JSON serializado para soportar
 * combinaciones libres sin acoplar el schema a cada campo.
 */
public class FFConfiguracionDefaulteo {

    public Integer id;
    public String  nombre;
    public String  descripcion;
    public Integer idCorporativo;
    public Integer idEmpresa;
    public Integer idAdmin;

    /** JSON con la estructura de FFFiltroDefaulteoAvanzado */
    public String filtrosJson;
    /** JSON con la estructura de FFAccionDefaulteoAvanzado */
    public String accionesJson;
}
