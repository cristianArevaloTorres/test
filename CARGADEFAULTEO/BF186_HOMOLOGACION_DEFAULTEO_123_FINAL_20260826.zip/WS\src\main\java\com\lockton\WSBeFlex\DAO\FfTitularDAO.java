package com.lockton.WSBeFlex.DAO;

import java.util.List;
import java.util.Map;

import com.lockton.WSBeFlex.POJO.Especiales.FFDefaulteo;




/**
 * <p>
 * Esta interface define los métodos que se implementan en la clase
 * {@link com.lockton.WSBeFlex.DAO.JDBCFfTitular} para acceder a la 
 * información de las consultas establecidas en ella.
 * </p>
 *   
 * @author Andrea Hernández / BigPink
 * @since 1.0
 */
public interface FfTitularDAO {
 
	public List<Object> consultarPlantilla(Integer IdEmpresa, String Pantalla,
	int IdPerfil, String busca,String campoBusca,int idAdm);
	
	public List<Object> obtenerIndicadoresPorRelacion(String idEmpresa);
	
	public List<Object> obtenerEmpresasVigenciasPorCorporativo(int idCorporativo);
	public List<Object> obtenerconfiguracionEnvio(int idCorporativo);
	public List<Object> obtenerPlantillaYnotificacionCorreo(String idCorporativo,String idAdm);
	public List<Object> insertarConfiguracionNotificacionEmpresa(String idEmpresa , String idTipoNotificacionCorreo, String idPlantilla, String numeroDias,
	String orden, String idUsuario);
	public List<Object> insertarConfiguracionEnvio(String idConfiguracionNotificacion ,  String idVigencia,  String diaInicial,  boolean envioAdministradores,
	String idPeriodicidad);
	public List<Object> eliminarConfiguracionMantenimiento(String idConfiguracionEnvio );
	public List<Object> insertarConfiguracionMantenimiento(String idConfiguracionEnvio, String fecha);
	public List<Object> eliminarConfiguracion(String idConfiguracionEnvio);
	
	public List<Object> editarConfiguracion(String idEmpresa , String idCorporativo);
	
	public List<Object> obtenerLeyendaEmpresa(String idVigencia);
	public List<Object> obtenerReporteBitacora( String tipoReporte,String fechaInicio,  String fechaFinal,String idEmpresa, String idEmpleado, String idPerfil, String CampoBusca, String Busca);
	public List<Object> obtenerEmpleadosBitacora(String IdEmpresa,String Pantalla,  String IdPerfil, String CampoBusca, String Busca,  String idAdm);
	
	
	public List<Object> buscarTitularPorNumeroEmpleado(String nombreEmpleado, String idEmpresa);

	public  List<Map<String, Object>> bajaTitularDatosMail(List<Map<String, Object>> datos);
	public  List<Map<String, Object>> datosMailDependiente(List<Map<String, Object>> datos);

	public List<Object> obtenerConfiguracionTotalStatement( String idParametro,String idEmpresa,  String idPerfil ); 
	
	public List<Object> obtenerReporteSolicitudesEmpleado(String idCorporativo,  String idEmpresa,String idPerfil, String idVigencia, String fechaInicio, String fechaFinal); 
	
	public List<Object> obtenerGridDefaulteo( String idCorporativo,  String idEmpresa,  String numEmpleado,  String apellidoPaterno,String apellidoMaterno ,String nombreUno, String nombreDos ); 
	
	public List<Object> obtenerPlanesDefault(); 
        
        public List<Object> verificarUsuarioBitacora(String idUsuario);
        
        public List<Object> obtenerPlanesVigenciaAnterior(String idUsuario,  String idVigencia,  String idEmpresa);
        
        public List<Object> verificarSolicitudDefaulteada(String idAdm,String idEmpleadoDefaulteado); 
        
        public List<Object> obtenerGridDefaulteoMultivigencia( String idCorporativo,  String idEmpresa,  String numEmpleado,  String apellidoPaterno,String apellidoMaterno ,String nombreUno, String nombreDos, String vigencia,int idAdministrador ); 

        public List<Object> consultarTitularesCorpEmp(Integer IdEmpresa, String Pantalla,
	int IdPerfil, String busca,String campoBusca,int idAdm);

	public List<Object> defaultearEmpleadosMasivo(FFDefaulteo datos);

	// CREA06 casos especiales: variante que respeta condiciones especiales (forzar coberturas/planes).
	public List<Object> defaultearEmpleadosMasivoCasosEspeciales(FFDefaulteo datos, java.util.Set<Integer> forzarCob, java.util.Set<Integer> forzarPlan);

	// CREA06 casos especiales (incidencias 2-4): valida existencia del empleado, pertenencia a la empresa del
	// layout y si ya tiene solicitud en la vigencia destino. Devuelve {existe, empresaReal, perteneceEmpresa, yaTieneSolicitud}.
	public Map<String,Object> validarEmpleadoCasoEspecial(int idEmpleado, int idEmpresaLayout, int idVigencia);

        public List<Object> getConfPassword(int idEmpresa);

        public List<Object> getIdEyRetiro(int idAdm);

        // INC002/RF019: Obtener datos de ultima solicitud para lista de empleados
        public List<Map<String, Object>> obtenerUltimasSolicitudesEmpleados(String idEmpleados);

	public List<Object> consultarTitularesAvanzado(Integer IdCorporativo,String IdEmpresas,String Busca,String Operador1,String CampoBusca,Integer BusquedaAvanzada,String OperadorAvanzado,String Busca2,String Operador2,String CampoBusca2,int idAdm);
	
	public List<Object> consultarDependientesAvanzado(Integer IdCorporativo,String IdEmpresas,String Busca,String Operador1,String CampoBusca,Integer BusquedaAvanzada,String OperadorAvanzado,String Busca2,String Operador2,String CampoBusca2,int idAdm);

	public List<Object> getCoberturasPorPlanVigencia(int idPlan, int idVigencia);

	public Integer getUltimoIdSolicitud(int idEmpleado, int idVigencia);

	public List<Object> busquedaDefaulteoAvanzada(Map<String,Object> parametros);
	
	public List<Object> buscaTitularesAvanzado(Map<String, Object> parametros);
	
	public List<Object> buscaTitularesMovimientosAvanzado(Map<String, Object> parametros);
	
	public List<Object> buscaTitularesStatement(Map<String, Object> parametros);

}
