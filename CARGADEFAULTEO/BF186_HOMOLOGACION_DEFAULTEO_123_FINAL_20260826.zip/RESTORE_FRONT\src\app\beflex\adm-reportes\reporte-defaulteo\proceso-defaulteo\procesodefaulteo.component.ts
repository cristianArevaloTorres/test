import { Component, ViewEncapsulation, OnInit, DoCheck, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/observable/fromEvent';
import swal from 'sweetalert2';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { GLOBAL } from '../../../../services/global';
import { EmpleadoService } from '../../../../services/empleado.service';
import { buscaPlanesPerfilService } from '../../../../services/buscaPlanesPerfil.service';
import { ExecCotizadorCandados, planesSeleccionados, planesSeleccionadosOld, declaraciones, seleccionado, seleccionado2 } from '../../../../models/cotizador'
import { ViewChild, ElementRef } from '@angular/core';
import { Sesion } from '../../../../services/sesion.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BeneficiarioService } from '../../../../services/beneficiario.service';
import { parametrosAsegurado } from '../../../../models/parametrosAsegurado';
import { aceptar } from '../../../../models/aceptar';
import { Bitacora } from '../../../../services/bitacora.service'
import { MensajeSolicitud } from '../../../../models/mensajesolicitud';
declare var $: any;
@Component({
  selector: 'app-procesodefaulteo',
  templateUrl: './procesodefaulteo.component.html',
  styleUrls: ['./procesodefaulteo.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [buscaPlanesPerfilService, EmpleadoService, Sesion, BeneficiarioService, Bitacora]
})
export class ProcesodefaulteoComponent implements OnInit, DoCheck {
  public mensajesolicitud: MensajeSolicitud;
  public solicitud: string;
  public token;
  public tablaPlanes;
  public tablaPlanes2;
  public planesSeleccionados;
  public costoSelecciones;
  public estadoCuenta;
  public Clip;
  public ramos;
  public cotizador;
  public cotizadorValido;
  public cotizadorv3;
  public planes;
  public usuarios;
  public usuarios2;
  public tarifaPlanes;
  public tarifaPlanesParent;
  public tarifaPlanesGrupo;
  public tarifaPlanes2;
  public mostrarCotizador = false;
  public mostrarCotizadorEjecutor = false;
  public ocultar = false;
  public trustUrlDoc: SafeResourceUrl;
  public compensacionPlanOpcion;
  public resObtenerDatos;
  public varCandado: ExecCotizadorCandados;
  public planesSeleccionadosNew: planesSeleccionados;
  public planesSeleccionadosOld: planesSeleccionadosOld;
  public declaraciones: declaraciones;
  public eleccion: seleccionado;
  public eleccion2: seleccionado2;
  public urlWs;
  public api;
  public habilitarSelecciones = "enabled";
  public habilitarPanel = "disabled";
  public habilitarSelects = true;
  public trustUrl2: SafeResourceUrl;
  public trustUrl3: SafeResourceUrl;
  public estilo;
  public url3 = '../../../../../../src/app/beflex/shared/nav/nav.component.css';
  public wizard;
  public etiqueta;
  public mensajesSolicitud;
  public mensajesSolicitudExist;
  public mensajesCotizador;
  public validacionSolicitud;
  public mensajesProgreso;
  public archivoAyuda;
  public planAyuda;
  public descripcionAyuda;
  public RutaImagenGrupoAyuda;
  public planesGrupo;
  public planesGrupoJson;
  public planesJson;
  private idVigencia;
  public planesPanel3;
  public bottones;
  public porcentaje;
  public verificarCambios;
  public xmlCOsto;
  private datosTitular;
  private returnEstado;
  public opcionN;
  public opcionO;
  public planCollapse;
  private carga;
  public parametro119;
  public parametro126;
  public parametro114;
  private urlIconos = GLOBAL.iconos;
  public solicitudCreada = false;
  public cierreBeneficiarios;
  public ocultarSolicitud = false;
  public urlSolicitudEspera;
  public solicitudes;
  public consentimientopdf;
  public nombreSolicitud;
  public pathFileSS;
  public plantilla;
  public sujeto;
  public to = "";
  public cc = "";
  public bcc = "";
  public to2 = "";
  public cc2 = "";
  public bcc2 = "";
  public plantilla2;
  public sujeto2;
  public correosAdministradores;
  public newRamoJson;
  public auxAnexoSolicitud = {
    'anexoSolicitud': [],
  }
  public auxPlanSeleccion = {
    'planSeleccion': []
  }
  public btnAgregarBenf;
  public planesOrdenJsonF;
  public opcionRedirigir = 0;
  public errorConexion = false;
  public planesOrdenJsonFArray;
  public planesOrdenInvertido;
  public planOpcionAyuda;
  public planOpcion = [];
  public planOpcionArchivo = [];
  public temp2 = [];
  public urlArchivo;
  public parametrosAseguradoT: parametrosAsegurado;
  public mostrarMultipleAyuda;
  public mensajesCotizadorRes;
  private prefijoSolicitud;
  public planSami;
  public planNombreOpcion;
  public SAAdicional;
  public planidTarifaCosto;
  private planSami2
  private SAAdicional2;
  private planidTarifaCosto2;
  public displayEscedentes = 'none';
  private tsrifasAceptadas = {
    'idtarifacosto': [],
    'planSami': [],
    'SAAdicional': []
  }
  private tsrifasRechazadas = {
    'idtarifacosto': []
  }
  private planSamiVerificar;
  private planSeleccionadoId;
  private planSeleccionadoId2;
  public validacionSA = true;
  public diferenciaCostos;
  public diferenciaCostos2;
  public acepto: aceptar;

  private idPagina = '401';
  private paginaActual;
  private ipPrivada;


  private anexos = false;
  private consentimeinto = false;

  private crearSolicitudArch = false;
  private paramsSolicitud4: any;

  public cerrarModal: Boolean = true;

  public quitarFirmas = false;
  public quitarSeleccionesAnteriores = false;
  public quitarResumenDescuento = false;

  public mostrarEncabezado = false;
  public encabezadoCotizador: any;
  public idsegmentarplan: any;
  public accion: Boolean = false;
  public btnEstadoCuenta: Boolean = true;

  public colorModal = '';

  @Input() identity;
  @Output() solicitudCreadaDefaulteo: EventEmitter<any> = new EventEmitter();
  @Input() tipoDefaulteo;
  @Input() idMultivigencia;
  @Input() idMultivigenciaActual;
  @Input() idVigenciaVigente;

  constructor(
    private _route: ActivatedRoute,
    private _router: Router,
    private _BuscarPlanesv2: buscaPlanesPerfilService,
    private _empleadoService: EmpleadoService,
    private sanitizer: DomSanitizer,
    public _http: HttpClient,
    private _sesion: Sesion,
    private spinner: NgxSpinnerService,
    private _beneficiarioService: BeneficiarioService,
    @Inject(DOCUMENT) private document: Document
  ) {

    this.planesSeleccionadosNew = new planesSeleccionados('', '', '', '');
    this.planesSeleccionadosOld = new planesSeleccionadosOld('', '', '', '');
    this.parametrosAseguradoT = new parametrosAsegurado('', '', '', '', '', '', '', '', '');
    this.acepto = new aceptar(false);

    this.urlWs = GLOBAL.url;
    this.api = GLOBAL.url2;
    this.eleccion = new seleccionado(0);
    this.eleccion2 = new seleccionado2(0);
    this.wizard = GLOBAL.wizard;
    localStorage.removeItem('cierreBeneficiarios');
    localStorage.removeItem('cotizador');
    localStorage.removeItem('ejecutor');
    this.mensajesolicitud = { 'titulo': '¿Estás de acuerdo en confirmar tu solicitud?', 'subtitulo': 'Una vez dando aceptar no será posible repetir este paso.' };
  }
  @Output() onCreateUser: EventEmitter<any> = new EventEmitter();
  @Output() onApproveAll: EventEmitter<any> = new EventEmitter();
  @ViewChild('fileInput') inputEl: ElementRef;

  async ngOnInit() {
    this.token = this._empleadoService.getToken();
    try {
      await this._sesion.comprobarSession(this.token)
      this.getDatosEmpleado();
      this.getEstados();
      this.cotizador = this._BuscarPlanesv2.getPlanesPerfilSave();
      this.cotizadorv3 = this._BuscarPlanesv2.getEjecutor();
      this.validarSesion();
      if (this.identity) {
        this.paginaActual = this.document.location.href;
        let myIP = localStorage.getItem('myIP');
        if (!myIP)
          myIP = '0.0.0.0';
        this.ipPrivada = myIP;
        var parametroVitacora = {
          'idPagina': this.idPagina,
          'id': this.identity.id,
          'ipPrivada': encodeURIComponent(this.ipPrivada),
          'url': encodeURIComponent(this.paginaActual),
          'idEmpresa': this.identity.idEmpresa,
          'nombrePagina': 0
        }
        try {
          const response: any = await this._BuscarPlanesv2.getParametrosFirmasMostrar(this.identity.idEmpresa, 202);
          if (response.paValor == 1) {
            this.quitarFirmas = true;
          }
        } catch (error) { }
        try {
          const response: any = await this._BuscarPlanesv2.getParametrosFirmasMostrar(this.identity.idEmpresa, 206);
          if (response.paValor == 1) {
            this.quitarSeleccionesAnteriores = true;
          }
        } catch (error) { }
        try {
          const response: any = await this._BuscarPlanesv2.getParametrosFirmasMostrar(this.identity.idEmpresa, 228);
          if (response.paValor == 1) {
            this.quitarResumenDescuento = true;
          }
        } catch (error) { }
        try {
          const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 203);
          this.encabezadoCotizador = this.sanitizer.bypassSecurityTrustHtml(response.paValor);
          this.mostrarEncabezado = true;
        } catch (error) {
          this.encabezadoCotizador = "<div></div>";
        }
        try {
          const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 207);
          this.idsegmentarplan = response.paValor;
        } catch (error) { }
        this.solicitudExistente();
        this.getParametros();
        this.getPrefijoSolicitud();
        try {
          const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 218);
          if (response != null) {
            let cadenas = response.paValor.split("#");
            this.mensajesolicitud = { 'titulo': cadenas[0], 'subtitulo': cadenas[1] };
          }
        } catch (error) { }
      }
    } catch (error) {
      console.clear();
      if (error == 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión de nuevo.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      } else if (error.statusText == 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión de nuevo.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      } else {
        swal({
          title: '¡Error de conexión! 1',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
      }
    }
    /*
    * Ocultar boton de estado de cuenta por parametro
    */
    try {
      const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 219);
      let resultado = parseInt(response.paValor, 10);
      if (resultado == 0) {
        this.btnEstadoCuenta = true;
      } else {
        this.btnEstadoCuenta = false;
      }
    } catch (error) {
      this.btnEstadoCuenta = true;
    }
  }

  async ngDoCheck() {
    this.mostrarCotizador;
    this.verificarCambios = this._BuscarPlanesv2.verificaCambios();
    this.cierreBeneficiarios = this._BuscarPlanesv2.verificaBeneficiarios();
    this.btnAgregarBenf = this._BuscarPlanesv2.habilitarContinuar();
    if (this.verificarCambios != null) {
      this.mostrarCotizador = false;
      localStorage.removeItem('cotizador');
      this.buscarPlanes();
    }
    if (this.cierreBeneficiarios != null && !this.crearSolicitudArch) {
      this.crearSolicitudArch = true;
      if (this.identity.idEmpresa != 369) {
        this.crearSolicitud();
      } else {
        this.createSolicitud(this.paramsSolicitud4, 2);
      }
    }
    if (this.planSeleccionadoId)
      if (this.planSeleccionadoId == '1151') {
        this.verificacionSami();
      }
    if (this.mostrarCotizador && this.mostrarCotizadorEjecutor || this.ocultar && this.mostrarCotizador) {
      if (!this.accion) {
        let prueba = localStorage.getItem('prueba');
        if (prueba != "undefined" && prueba != null) {
          let cotizador = JSON.parse(localStorage.getItem('cotizador'));
          if (cotizador.plantillaMembresia != "undefined" && cotizador.plantillaMembresia != null) {
            this.mensajesolicitud = { 'titulo': '', 'subtitulo': cotizador.plantillaMembresia[0].mensaje };
          } else {
            this.mensajesolicitud = { 'titulo': '¿Estás de acuerdo en confirmar tu solicitud?', 'subtitulo': 'Una vez dando aceptar no será posible repetir este paso.' };
          }          
          try {
            const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 218);
            if (response != null) {
              let cadenas = response.paValor.split("#");
              this.mensajesolicitud = { 'titulo': cadenas[0], 'subtitulo': cadenas[1] };
            }
            this.mostrarCotizadorEjecutor = false;
            if (this.cotizador.boton != null) {
              this.accion = true;
              if (this.identity.idEmpresa != 369) {
                this.guardarSeleccionadosPDF(2)
              } else {
                this.validarOpcionSamiSolicitud(2)
              }
            } else {
              this.solicitudCreadaDefaulteo.emit({ solicitudCreada: false, numEmpleado: this.identity.numEmpleado, msj: 'TU BOLSA FLEXIBLE HA SIDO APLICADA. EXISTEN COBERTURAS SELECCIONADAS QUE PASARÁN A DESCUENTO POR NÓMINA' });
            }
          } catch (error) {
            this.mostrarCotizadorEjecutor = false;
            if (this.cotizador.boton != null) {
              this.accion = true;
              if (this.identity.idEmpresa != 369) {
                this.guardarSeleccionadosPDF(2)
              } else {
                this.validarOpcionSamiSolicitud(2)
              }
            } else {
              this.solicitudCreadaDefaulteo.emit({ solicitudCreada: false, numEmpleado: this.identity.numEmpleado, msj: 'TU BOLSA FLEXIBLE HA SIDO APLICADA. EXISTEN COBERTURAS SELECCIONADAS QUE PASARÁN A DESCUENTO POR NÓMINA' });
            }
          }
        }
        this.accion = true;
      }
    }
  }

  ngOnDestroy() {
    localStorage.removeItem('prueba');
  }


  verificaA() {
    let prueba = localStorage.getItem('prueba');
    if (prueba != "undefined" && prueba != null) {
      return true;
    } else {
      return false;
    }
  }

  regresar() {
    this._router.navigate(['pages/beflex']);
  }
  loader() {
    this.spinner.show();

    setTimeout(() => {
      this.spinner.hide();
    }, 5000);

  }

  validarSesion() {
    if (this.identity != null) {
    } else {
      this.logout();
    }
  }

  async comprobarSesion() {
    try {
      await this._sesion.comprobarSession(this.token);
    } catch (error) {
      if (error == 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión de nuevo.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      } else if (error.statusText == 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión de nuevo.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      } else {
        swal({
          title: '¡Error de conexión! 2',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
      }
    }
  }

  logout() {
    localStorage.removeItem('identity');
    localStorage.clear();
    this.identity = null;
    this._router.navigate(['/']);
  }
  habilitado() {
    return this.habilitarSelecciones;
  }

  getPrefijoSolicitud() {
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.urlWs + "empresas/" + this.identity.idEmpresa + "/prefijoSolicitud",
      "method": "GET",
      "headers": {
        "cache-control": "no-cache",
        "Postman-Token": "da447d6f-3df8-4033-8a63-52cc8a448971"
      }
    }

    $.ajax(settings).done((response) => {
      if (response) {
        this.prefijoSolicitud = response;
      } else {
        response = '{"emPrefijoSolicitud": 1}';
        this.prefijoSolicitud = JSON.parse(response);
      }

    }).fail((error) => {
      var errorMessage = <any>error;
    });
  }

  procesoAceptado() {
    this.tsrifasAceptadas = {
      'idtarifacosto': [],
      'planSami': [],
      'SAAdicional': []
    }
    this.tsrifasRechazadas = {
      'idtarifacosto': []
    }
    this.displayEscedentes = 'none';
    this.tsrifasAceptadas.idtarifacosto.push(this.planidTarifaCosto);
    this.tsrifasAceptadas.planSami.push(this.planSami2);
    this.tsrifasAceptadas.SAAdicional.push(this.SAAdicional2);
    swal({
      title: '<small style="color: grey; text-align: justify;">El asesor de LOCKTON te contactará para continuar con el trámite</small>',
      type: 'info',
      confirmButtonText: 'Aceptar',
    });
    this.displayEscedentes = 'none';
  }
  obtenerSumaAsegurada(emSalarioBase, poValorSumaAsegurada, tcPrimaTotal) {
    return (((emSalarioBase * poValorSumaAsegurada))).toFixed(2);
  }
  obtenerDiferenciaCosto(SumaAsegurada, tcPrimaTotal) {
    return (((SumaAsegurada) / 1000) * tcPrimaTotal).toFixed(2);
  }
  obtenerExcedente(plSami, idEmpresa, idPlanOpcion, idTarifaCosto, idVigencia, sami, sumaAsegurada) {
    let excedente;
    if (sumaAsegurada > plSami) {
      var obj = {
        "idEmpresa": idEmpresa,
        "idPlanOpcion": idPlanOpcion,
        "idSolicitud": idTarifaCosto,
        "idTarifaCosto": 123,
        "idVigencia": idVigencia,
        "sami": sami,
        "sumaAsegurada": sumaAsegurada
      }
      swal({
        title: '¡Atención!',
        text: "¿Estás de acuerdo en agregar el plan?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aceptar',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.value) {
          swal({
            title: 'Espere un momento...',
            html: '',
            allowOutsideClick: false,
            onOpen: () => {
              swal.showLoading();
              var settings = {
                "async": true,
                "crossDomain": true,
                "url": this.urlWs + "excedentes/empleado/" + this.identity.id,
                "method": "POST",
                "headers": {
                  "content-type": "application/json"
                },
                "processData": false,
                "data": obj
              }

              $.ajax(settings).done(function (response) {
                swal('¡Plan agregado!', 'success');
              }).fail((error) => {
                // // console.log("error")
              });

            },

          }).then((result) => {
            if (
              // Read more about handling dismissals
              result.dismiss === swal.DismissReason.timer
            ) {

            }
          })
        }
      })
    }
  }

  //busca planes perfil v-31
  buscarPlanes(inicio?) {
    let defaulteo;
    switch (+this.tipoDefaulteo) {
      case 1:
        defaulteo = 'def1';
        break;
      case 2:
        defaulteo = 'def2';
        break;
      case 3:
        defaulteo = 'def1';
        break;

    }

    var banderaInicio = false;
    this.porcentaje = "30%";
    localStorage.removeItem('cambios');
    ////////////////// // // // console.log('buscando planes');
    this.mensajesProgreso = "CONECTANDO...";
    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    if (!inicio) {
      banderaInicio = true;
      inicio = {
        "idEmpresa": this.identity.idEmpresa,
        "planesSeleccionados": [
          {
            "costo": null,
            "idempleado": -1,
            "nuevo": null,
            "tcidtarifacosto": -1
          }
        ],
        "planesSeleccionadosOld": [
          {
            "costoOld": null,
            "idempleadoOld": -1,
            "nuevoOld": null,
            "tcidtarifacostoOld": -1
          }
        ],
        "transfer": defaulteo
      }
    }

    let planBasicoVigenciaActiva = false;
    let buscaPlanes;

    if (this.idMultivigenciaActual == this.idVigenciaVigente) {
      planBasicoVigenciaActiva = true;
    }

    if (planBasicoVigenciaActiva && defaulteo == 'def2') {

      buscaPlanes = this.urlWs + "planesPerfil/empleado/" + this.identity.id + "/v3-1Defaulteo";
    } else {
      buscaPlanes = this.urlWs + "planesPerfil/empleado/" + this.identity.id + "/v3-1DefaulteoMultivigencia/" + this.idMultivigencia;
    }








    this._http.post(buscaPlanes,
      JSON.stringify(inicio),
      { headers: getHeaders }
    ).subscribe(
      response => {
        if (response) {
          this.displayEscedentes = 'none';
          // window.location.reload();

          console.log('response planesPerfil');
          //           console.log(response);
          // // console.log(JSON.stringify(response));

          this.cotizadorValido = response;

          this.mensajesCotizadorRes = null;
          if (this.cotizadorValido.mensajes != null) {
            this.mensajesCotizadorRes = this.cotizadorValido.mensajes;
            if (banderaInicio) {
              localStorage.removeItem('cotizador');
              localStorage.setItem('cotizador', JSON.stringify(response));
              this.cotizador = response
              if (this.cotizador.boton) {
                this.bottones = this.cotizador.boton; //mensajes
              } else {
                this.bottones = "";
              }
            }
          } else {
            localStorage.removeItem('cotizador');
            localStorage.setItem('cotizador', JSON.stringify(response));
            this.cotizador = response
            if (this.cotizador.boton) {
              this.bottones = this.cotizador.boton; //mensajes
            } else {
              this.bottones = "";
            }
          }
          this.planSamiVerificar = response['planesSami']
        } else {
          swal({
            title: '¡Error de conexión! 3',
            html: '<small style="color: grey; text-align: justify;">Intenta nuevamente.</small>',
            type: 'info',
            confirmButtonText: 'Aceptar',
          });
        }
        if (this.cotizador.datosCotizador) {
          this.buscaPlanesSave();
        } else {
          window.location.reload();
        }
      }, error => {
        var errorMessage = <any>error;
        swal({
          title: '¡Error de conexión! 4',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'info',
          confirmButtonText: 'Aceptar',
        });
      }
    );
  }


  verificacionSami() {
    let sumaAsegurada;
    let excedente;
    let poValorSumaAseguradaTotal = {
      sumaAsegurada: []
    }
    this.planSeleccionadoId = null;

    var plSami = this.planSamiVerificar;

    if (plSami)
      plSami.map((val) => {
        poValorSumaAseguradaTotal.sumaAsegurada.push(
          this.obtenerSumaAsegurada(val.emSalarioBase, val.poValorSumaAsegurada, val.tcPrimaTotal)
        )
      });

    for (let index = 0; index < plSami.length; index++) {
      const costoSami = plSami[index]['plSami'];
      const resultados = poValorSumaAseguradaTotal.sumaAsegurada[index];

      if (plSami[index]['poIdPlan'] == '1151') {

        if (costoSami < resultados) {
          var diferencia = resultados - costoSami;

          const datosCotizador = this.cotizador.datosCotizador;
          var primatotal;
          for (let i = 0; i < datosCotizador.length; i++) {
            if (datosCotizador[i]['checked'] == "true" && datosCotizador[i]['tcIdTarifaCosto'] == plSami[index]['tcIdTarifaCosto']) {
              this.planNombreOpcion = datosCotizador[i]['poNombre'];
              this.planidTarifaCosto = datosCotizador[i]['tcIdTarifaCosto'];
              primatotal = plSami[index]['tcPrimaNeta'];

            }
          }
          this.planSami = this.redondear(costoSami);
          this.SAAdicional = this.redondear(diferencia);
          this.planSami2 = (costoSami);
          this.diferenciaCostos = this.redondear(this.obtenerDiferenciaCosto(diferencia, primatotal));
          this.diferenciaCostos2 = (this.obtenerDiferenciaCosto(diferencia, primatotal));
          this.SAAdicional2 = diferencia;
          var busca = this.tsrifasAceptadas.idtarifacosto.indexOf(this.planidTarifaCosto);
          var buscaRechaza = this.tsrifasRechazadas.idtarifacosto.indexOf(this.planidTarifaCosto);
          if (busca == -1 && buscaRechaza == -1) {
            this.displayEscedentes = 'block';
          }
        }
      }
    }
  }

  buscaPlanesSave() {
    this.comprobarSesion();
    this.bottones = this.cotizador.boton;
    this.planSamiVerificar = this.cotizador.planesSami;
    if (this.planSeleccionadoId2)
      if (this.planSeleccionadoId2 == '1151') {
        this.verificacionSami();
      }
    this.porcentaje = "50%";
    this.mensajesProgreso = "CALCULANDO SELECCIONES...";
    this.eleccion = new seleccionado(0);
    this.cotizador.datosCotizador = JSON.stringify(this.cotizador.datosCotizador);
    this.cotizador.datosCotizador = this.cotizador.datosCotizador.replace(/False/g, "false");
    this.cotizador.datosCotizador = this.cotizador.datosCotizador.replace(/FALSE/g, "false");
    this.cotizador.datosCotizador = this.cotizador.datosCotizador.replace(/True/g, "true");
    this.cotizador.datosCotizador = this.cotizador.datosCotizador.replace(/TRUE/g, "true");
    this.cotizador.datosCotizador = JSON.parse(this.cotizador.datosCotizador);
    this.tablaPlanes = this.cotizador.datosCotizador;
    this.estadoCuenta = this.cotizador.estadoCuenta;
    this.idVigencia = this.cotizadorv3.declaraciones['idVigencia'];
    const datosCotizador2 = this.cotizador.datosCotizador;
    var names = this.tablaPlanes.map(function (ramos) { return ramos.plIdRamo; });
    var sorted = names.sort();
    var unique = (sorted.filter(function (value, index) {
      return value !== sorted[index + 1];
    }));
    var array = {
      'IdRamo': [],
      'NombreRamo': [],
      'RamoOrden': []
    }
    for (let i1 = 0; i1 < unique.length; i1++) {
      array.IdRamo.push(unique[i1]);
    }
    for (let i2 = 0; i2 < this.tablaPlanes.length; i2++) {
      for (let i3 = 0; i3 < array.IdRamo.length; i3++) {
        if (this.tablaPlanes[i2]['plIdRamo'] == array.IdRamo[i3]) {
          array.NombreRamo[i3] = this.tablaPlanes[i2]['raNombre'];
          array.RamoOrden[i3] = this.tablaPlanes[i2]['raOrden'];
        }
      }
    }
    this.ramos = array;
    this.getColor();
    var ramoJson = "[";
    for (let i22 = 0; i22 < this.ramos.IdRamo.length; i22++) {
      ramoJson += "{\"IdRamo\":" + this.ramos.IdRamo[i22] + ",\"NombreRamo\":\"" + this.ramos.NombreRamo[i22] + "\",\"RamoOrden\":" + this.ramos.RamoOrden[i22] + "},";
    }
    if (ramoJson.length != 1)
      ramoJson = ramoJson.substring(0, ramoJson.length - 1);
    ramoJson += "]";
    ramoJson = JSON.parse(ramoJson);
    this.newRamoJson = ramoJson;
    this.newRamoJson.sort(function (a, b) {
      if (a.RamoOrden > b.RamoOrden) {
        return 1;
      }
      if (a.RamoOrden < b.RamoOrden) {
        return -1;
      }
      return 0;
    });
    for (let i23 = 0; i23 < this.ramos.IdRamo.length; i23++) {
      this.ramos.IdRamo[i23] = this.newRamoJson[i23]['IdRamo'];
      this.ramos.NombreRamo[i23] = this.newRamoJson[i23]['NombreRamo'];
      this.ramos.RamoOrden[i23] = this.newRamoJson[i23]['RamoOrden'];
    }

    var array2 = {
      'IdRamo': [],
      'idPlan': [],
      'nombrePlan': [],
      'grupo': [],
      'planOrden': [],
      'archivoPlan': [],
      'gpRutaImagenGrupo': [],
      'plDescripcion': [],
      'visible': [],
      'enabled': [],
      'gpGrupoEtiqueta': [],
      'gpIdGrupo': [],
      'plAyuda': [],
      'checked': []
    }
    var idPlanes = this.tablaPlanes.map(function (ramos) { return ramos.poIdPlan; });
    var sorted = idPlanes.sort((a, b) => a - b);
    var unique = (sorted.filter(function (value, index) {
      return value !== sorted[index + 1];
    }));
    array2.idPlan = unique;
    for (let i4 = 0; i4 < this.tablaPlanes.length; i4++) {
      for (let i5 = 0; i5 < array2.idPlan.length; i5++) {
        if (this.tablaPlanes[i4]['poIdPlan'] == array2.idPlan[i5]) {
          array2.IdRamo[i5] = this.tablaPlanes[i4]['plIdRamo'];
          array2.idPlan[i5] = this.tablaPlanes[i4]['poIdPlan'];
          array2.nombrePlan[i5] = this.tablaPlanes[i4]['plNombre'];
          array2.grupo[i5] = this.tablaPlanes[i4]['gpIdGrupo'];
          array2.planOrden[i5] = this.tablaPlanes[i4]['plOrden'];
          array2.archivoPlan[i5] = this.tablaPlanes[i4]['archivoPlan'];
          array2.gpRutaImagenGrupo[i5] = this.tablaPlanes[i4]['gpRutaImagenGrupo'];
          array2.plDescripcion[i5] = this.tablaPlanes[i4]['plDescripcion'];
          array2.visible[i5] = this.tablaPlanes[i4]['visible'];
          array2.enabled[i5] = this.tablaPlanes[i4]['enabled'];
          array2.gpGrupoEtiqueta[i5] = this.tablaPlanes[i4]['gpGrupoEtiqueta'];
          array2.gpIdGrupo[i5] = this.tablaPlanes[i4]['gpIdGrupo'];
          if (this.tablaPlanes[i4]['plAyuda'])
            array2.plAyuda[i5] = this.tablaPlanes[i4]['plAyuda'];
          array2.checked[i5] = this.tablaPlanes[i4]['checked'];
        }
      }
    }
    for (let i4 = 0; i4 < this.tablaPlanes.length; i4++) {
      for (let i5 = 0; i5 < array2.idPlan.length; i5++) {
        if (this.tablaPlanes[i4]['poIdPlan'] == array2.idPlan[i5] && this.tablaPlanes[i4]['enabled'] == 'true') {
          array2.enabled[i5] = this.tablaPlanes[i4]['enabled'];
        }
      }
    }
    this.planes = array2;
    var planesOrden = "[";
    for (let o = 0; o < array2.idPlan.length; o++) {
      planesOrden += "{\"IdRamo\":" + array2.IdRamo[o] + ",\"idPlan\":" + array2.idPlan[o] + ",\"nombrePlan\":\"" + array2.nombrePlan[o] + "\",\"grupo\":" + array2.grupo[o] + ",\"planOrden\":" + array2.planOrden[o] + ",\"archivoPlan\":\"" + array2.archivoPlan[o] + "\",\"gpRutaImagenGrupo\":\"" + array2.gpRutaImagenGrupo[o] + "\",\"plDescripcion\":\"" + array2.plDescripcion[o] + "\",\"visible\":" + array2.visible[o] + ",\"enabled\":" + array2.enabled[o] + ",\"gpGrupoEtiqueta\":\"" + array2.gpGrupoEtiqueta[o] + "\",\"gpIdGrupo\":" + array2.gpIdGrupo[o] + "},"
    }
    if (planesOrden.length != 1)
      planesOrden = planesOrden.substring(0, planesOrden.length - 1);
    planesOrden += "]";
    planesOrden = planesOrden.replace(/\\/g, "/");
    planesOrden = planesOrden.trim();
    var patron = /\n/gi
    planesOrden = planesOrden.replace(patron, " ");
    patron = /\r/gi
    planesOrden = planesOrden.replace(patron, " ");
    planesOrden = planesOrden.replace('\r\n', " ");
    this.planesJson = JSON.parse(planesOrden);
    const planesJsonOrden = this.planesJson;
    this.planesOrdenJsonF = planesJsonOrden;
    this.planesJson.sort(function (a, b) {
      if (a.gpIdGrupo > b.gpIdGrupo) {
        return 1;
      }
      if (a.gpIdGrupo < b.gpIdGrupo) {
        return -1;
      }
      return 0;
    });

    this.planesOrdenJsonF.sort(function (a, b) {
      if (a.planOrden > b.planOrden) {
        return 1;
      }
      if (a.planOrden < b.planOrden) {
        return -1;
      }
      return 0;
    });

    var elegidos = [];
    for (let ijs = 0; ijs < this.planesJson.length; ijs++) {
      if (ijs < this.planesJson.length - 1) {
        const element = this.planesJson[ijs];
        const element2 = this.planesJson[ijs + 1];
        if (this.planesJson[ijs]['gpIdGrupo'] == this.planesJson[ijs + 1]['gpIdGrupo']) {
          var op1 = (this.planesJson[ijs]['planOrden']);
          var op2 = (this.planesJson[ijs + 1]['planOrden']);
          if (op1 < op2) {
            const l = elegidos.length;
            var b1 = false;
            for (let ijs2 = 0; ijs2 < elegidos.length; ijs2++) {
              if (ijs2 > 0) {
                if (elegidos[ijs2]['gpIdGrupo'] == this.planesJson[ijs]['gpIdGrupo']) {
                  var op3 = (elegidos[ijs2]['planOrden']);

                  if (op1 < op3) {
                    elegidos[ijs2] = this.planesJson[ijs];
                    b1 = true;
                    break;
                  }
                }
              }
            }
            if (b1 == false) {
              elegidos[l] = this.planesJson[ijs];
            }
          } else {
            const l = elegidos.length;
            var b1 = false;
            for (let ijs2 = 0; ijs2 < elegidos.length; ijs2++) {
              if (ijs2 > 0) {
                if (elegidos[ijs2]['gpIdGrupo'] == this.planesJson[ijs + 1]['gpIdGrupo']) {
                  var op3 = (elegidos[ijs2]['planOrden']);
                  if (op2 < op3) {
                    elegidos[ijs2] = this.planesJson[ijs + 1];
                    b1 = true;
                    break;
                  }
                }
              }
            }
            if (b1 == false) {
              elegidos[l] = this.planesJson[ijs + 1];
            }
          }
        }
      }
    }
    var array22 = {
      'IdRamo': [],
      'idPlan': [],
      'nombrePlan': [],
      'grupo': [],
      'planOrden': [],
      'archivoPlan': [],
      'gpRutaImagenGrupo': [],
      'plDescripcion': [],
      'visible': [],
      'enabled': [],
      'gpGrupoEtiqueta': [],
      'gpIdGrupo': []
    }

    var idGrupo = this.tablaPlanes.map(function (ramos) { return ramos.gpIdGrupo; });
    var sorted = idGrupo.sort((a, b) => a - b);
    sorted = sorted.reverse();
    var unique = (sorted.filter(function (value, index) {
      return value !== sorted[index + 1];
    }));
    array22.gpIdGrupo = unique;
    for (let i4 = 0; i4 < this.tablaPlanes.length; i4++) {
      for (let i5 = 0; i5 < array22.gpIdGrupo.length; i5++) {
        if (this.tablaPlanes[i4]['gpIdGrupo'] == array22.gpIdGrupo[i5]) {
          array22.IdRamo[i5] = this.tablaPlanes[i4]['plIdRamo'];
          array22.idPlan[i5] = this.tablaPlanes[i4]['poIdPlan'];
          array22.nombrePlan[i5] = this.tablaPlanes[i4]['plNombre'];
          array22.grupo[i5] = this.tablaPlanes[i4]['gpIdGrupo'];
          array22.planOrden[i5] = this.tablaPlanes[i4]['plOrden'];
          array22.archivoPlan[i5] = this.tablaPlanes[i4]['archivoPlan'];
          array22.gpRutaImagenGrupo[i5] = this.tablaPlanes[i4]['gpRutaImagenGrupo'];
          array22.plDescripcion[i5] = this.tablaPlanes[i4]['plDescripcion'];
          array22.visible[i5] = this.tablaPlanes[i4]['visible'];
          array22.enabled[i5] = this.tablaPlanes[i4]['enabled'];
          array22.gpGrupoEtiqueta[i5] = this.tablaPlanes[i4]['gpGrupoEtiqueta'];
          array22.gpIdGrupo[i5] = this.tablaPlanes[i4]['gpIdGrupo'];
        }
      }
    }

    this.planesGrupo = array22;
    var planesGrupoOrden = "[";
    for (let o = 0; o < array22.idPlan.length; o++) {
      planesGrupoOrden += "{\"IdRamo\":" + array22.IdRamo[o] + ",\"idPlan\":" + array22.idPlan[o] + ",\"nombrePlan\":\"" + array22.nombrePlan[o] + "\",\"grupo\":" + array22.grupo[o] + ",\"planOrden\":" + array22.planOrden[o] + ",\"archivoPlan\":\"" + array22.archivoPlan[o] + "\",\"gpRutaImagenGrupo\":\"" + array22.gpRutaImagenGrupo[o] + "\",\"plDescripcion\":\"" + array22.plDescripcion[o] + "\",\"visible\":" + array22.visible[o] + ",\"enabled\":" + array22.enabled[o] + ",\"gpGrupoEtiqueta\":\"" + array22.gpGrupoEtiqueta[o] + "\",\"gpIdGrupo\":" + array22.gpIdGrupo[o] + "},"
    }
    if (planesGrupoOrden.length != 1)
      planesGrupoOrden = planesGrupoOrden.substring(0, planesGrupoOrden.length - 1);
    planesGrupoOrden += "]";
    planesGrupoOrden = planesGrupoOrden.replace(/\\/g, "/");
    this.planesGrupoJson = JSON.parse(planesGrupoOrden);
    for (let re1 = 0; re1 < this.planesGrupoJson.length; re1++) {
      for (let re2 = 0; re2 < elegidos.length; re2++) {
        if (elegidos[re2]['gpIdGrupo'] == this.planesGrupoJson[re1]['gpIdGrupo']) {
          this.planesGrupoJson[re1] = elegidos[re2];
        }
      }
    }
    this.planesGrupoJson.sort(function (a, b) {
      if (a.planOrden > b.planOrden) {
        return 1;
      }
      if (a.planOrden < b.planOrden) {
        return -1;
      }
      return 0;
    });

    var array222 = {
      'IdRamo': [],
      'idPlan': [],
      'nombrePlan': [],
      'grupo': [],
      'planOrden': [],
      'archivoPlan': [],
      'gpRutaImagenGrupo': [],
      'plDescripcion': [],
      'visible': [],
      'enabled': [],
      'gpGrupoEtiqueta': [],
      'gpIdGrupo': []
    }
    for (let a1j = 0; a1j < this.planesOrdenJsonF.length; a1j++) {
      array222.IdRamo[a1j] = this.planesOrdenJsonF[a1j]['IdRamo'];
      array222.idPlan[a1j] = this.planesOrdenJsonF[a1j]['idPlan'];
      array222.nombrePlan[a1j] = this.planesOrdenJsonF[a1j]['nombrePlan'];
      array222.grupo[a1j] = this.planesOrdenJsonF[a1j]['grupo'];
      array222.planOrden[a1j] = this.planesOrdenJsonF[a1j]['planOrden'];
      array222.archivoPlan[a1j] = this.planesOrdenJsonF[a1j]['archivoPlan'];
      array222.gpRutaImagenGrupo[a1j] = this.planesOrdenJsonF[a1j]['gpRutaImagenGrupo'];
      array222.plDescripcion[a1j] = this.planesOrdenJsonF[a1j]['plDescripcion'];
      array222.visible[a1j] = this.planesOrdenJsonF[a1j]['visible'];
      array222.enabled[a1j] = this.planesOrdenJsonF[a1j]['enabled'];
      array222.gpGrupoEtiqueta[a1j] = this.planesOrdenJsonF[a1j]['gpGrupoEtiqueta'];
      array222.gpIdGrupo[a1j] = this.planesOrdenJsonF[a1j]['gpIdGrupo'];
    }
    this.planesOrdenJsonFArray = array222;

    var NombresD = this.tablaPlanes.map(function (ramos) {
      var nombreall = ramos.emApellidoPaterno + ' ' + ramos.emApellidoMaterno + ' ' + ramos.emNombre1 + ' ' + ramos.emNombre2;
      return nombreall;
    });


    var sorted = NombresD.sort();
    var unique = (sorted.filter(function (value, index) {
      return value !== sorted[index + 1];
    }));

    var array3 = {
      'idParentesco': [],
      'descParentesco': [],
      'nombres': []
    }
    array3.nombres = unique;
    for (let i6 = 0; i6 < this.tablaPlanes.length; i6++) {
      for (let i7 = 0; i7 < array3.nombres.length; i7++) {
        var paterno;
        var materno;
        var nombre1;
        var nombre2;
        paterno = this.tablaPlanes[i6]['emApellidoPaterno'];
        materno = this.tablaPlanes[i6]['emApellidoMaterno'];
        nombre1 = this.tablaPlanes[i6]['emNombre1'];
        nombre2 = this.tablaPlanes[i6]['emNombre2'];
        var nom = paterno + ' ' + materno + ' ' + nombre1 + ' ' + nombre2;
        nom = nom.replace(/null/g, "");
        nom = nom.replace(/NULL/g, "");

        if (nom == array3.nombres[i7]) {
          array3.idParentesco[i7] = this.tablaPlanes[i6]['emIdParentesco'];
          array3.descParentesco[i7] = this.tablaPlanes[i6]['paDescripcion'];
        }
      }
    }
    this.usuarios = array3;
    var array4 = {
      'idPlan': [],
      'descParentesco': [],
      'idParentesco': [],
      'nombres': [],
      'descParen': [],
      'id': [],
      'tcIdTipoTarifa': []
    }
    var NombresD2 = this.tablaPlanes.map(function (ramos) {
      var idplan2 = ramos.poIdPlan;
      var nombreall = ramos.emApellidoPaterno + ' ' + (ramos.emApellidoMaterno ? ramos.emApellidoMaterno : '') + ' ' + ramos.emNombre1 + ' ' + (ramos.emNombre2 ? ramos.emNombre2 : '');
      var parent = ramos.emIdParentesco;
      var nombres = ramos.emNombre1 + ' ' + ramos.emNombre2;
      var tipo = ramos.paDescripcion;
      var id = ramos.id;
      var tcIdTipoTarifa = ramos.tcIdTipoTarifa;
      return [idplan2, nombreall, parent, nombres, tipo, id, tcIdTipoTarifa];
    });
    array4.idPlan[0] = NombresD2[0][0];
    array4.descParentesco[0] = NombresD2[0][1];
    array4.idParentesco[0] = NombresD2[0][2];
    array4.nombres[0] = NombresD2[0][1];
    array4.descParen[0] = NombresD2[0][4];
    array4.id[0] = NombresD2[0][5];
    array4.tcIdTipoTarifa[0] = NombresD2[0][6];
    for (let i8 = 0; i8 < NombresD2.length; i8++) {
      var l = array4.idPlan.length;
      var flag = false;
      for (let i9 = 0; i9 < array4.idPlan.length; i9++) {
        if (array4.idPlan[i9] == NombresD2[i8][0] && array4.descParentesco[i9] == NombresD2[i8][1] && array4.idParentesco[i9] == NombresD2[i8][2]) {
          flag = false;
          break;
        } else {
          flag = true;
        }
      }
      if (flag == true) {
        array4.idPlan[l] = NombresD2[i8][0];
        array4.descParentesco[l] = NombresD2[i8][1];
        array4.idParentesco[l] = NombresD2[i8][2];
        array4.nombres[l] = NombresD2[i8][1];
        array4.nombres[l] = array4.nombres[l].replace(/null/g, "");
        array4.nombres[l] = array4.nombres[l].replace(/NULL/g, "");
        array4.descParen[l] = NombresD2[i8][4];
        array4.id[l] = NombresD2[i8][5];
        array4.tcIdTipoTarifa[l] = NombresD2[i8][6];
      }
    }
    this.usuarios2 = array4;
    var array5 = {
      'poIdPlan': [],
      'pONombre': [],
      'poIdPlanoPCION': [],
      'iDPARENTESCO': [],
      'Nombre': [],
      'nombrePlan': [],
      'checked': [],
      'visible': [],
      'enabled': [],
      'gpRutaImagenGrupo': [],
      'gpIdGrupo': [],
      'tcIdTarifaCosto': [],
      'tcPrimaNeta': [],
      'tcPrimaTotal': [],
      'id': [],
      'tcIdTipoTarifa': [],
      'tcIdGrupoParentesco': [],
      'parentescosDescripcion': [],
      'idgrupoParentesco': [],
      'plOrden': [],
      'tipoMonto': []
    }
    var arrayTarifas = this.tablaPlanes.map(function (ramos) {
      var poIdPlan = ramos.poIdPlan;
      var pONombre = ramos.poNombre;
      var poIdPlanoPCION = ramos.poIdPlanOpcion;
      var iDPARENTESCO = ramos.emIdParentesco;
      var Nombre = ramos.emApellidoPaterno + ' ' + ramos.emApellidoMaterno + ' ' + ramos.emNombre1 + ' ' + ramos.emNombre2;
      var patron = "NULL";
      var nuevoValor = "";
      Nombre = Nombre.replace(patron, nuevoValor);
      Nombre = Nombre.replace('null', nuevoValor);
      var checked = ramos.checked;
      var visible = ramos.visible;
      var enabled = ramos.enabled;
      var plNombre = ramos.plNombre;
      var gpRutaImagenGrupo = ramos.gpRutaImagenGrupo;
      var gpIdGrupo = ramos.gpIdGrupo;
      var tcIdTarifaCosto = ramos.tcIdTarifaCosto;
      var tcPrimaNeta = ramos.tcPrimaNeta;
      var tcPrimaTotal = ramos.tcPrimaTotal;
      var id = ramos.id;
      var tcIdTipoTarifa = ramos.tcIdTipoTarifa;
      var tcIdGrupoParentesco = ramos.tcIdGrupoParentesco;
      var parentescosDescripcion = ramos.parentescosDescripcion;
      var idgrupoParentesco = ramos.idParentesco;
      var plOrden = ramos.plOrden;
      var tipoMonto = ramos.poImg;
      return [poIdPlan, pONombre, poIdPlanoPCION, iDPARENTESCO, Nombre, plNombre, checked, visible, enabled, gpRutaImagenGrupo, gpIdGrupo, tcIdTarifaCosto, tcPrimaNeta, tcPrimaTotal, id, tcIdTipoTarifa, tcIdGrupoParentesco, parentescosDescripcion, idgrupoParentesco, plOrden, tipoMonto];
    });
    for (let i10 = 0; i10 < arrayTarifas.length; i10++) {
      array5.poIdPlan[i10] = arrayTarifas[i10][0];
      array5.pONombre[i10] = arrayTarifas[i10][1];
      array5.poIdPlanoPCION[i10] = arrayTarifas[i10][2];
      array5.iDPARENTESCO[i10] = arrayTarifas[i10][3];
      array5.Nombre[i10] = arrayTarifas[i10][4];
      array5.nombrePlan[i10] = arrayTarifas[i10][5];
      array5.checked[i10] = arrayTarifas[i10][6];
      array5.visible[i10] = arrayTarifas[i10][7];
      array5.enabled[i10] = arrayTarifas[i10][8];
      array5.gpRutaImagenGrupo[i10] = arrayTarifas[i10][9];
      array5.gpIdGrupo[i10] = arrayTarifas[i10][10];
      array5.tcIdTarifaCosto[i10] = arrayTarifas[i10][11];
      array5.tcPrimaNeta[i10] = arrayTarifas[i10][12];
      array5.tcPrimaTotal[i10] = arrayTarifas[i10][13];
      array5.id[i10] = arrayTarifas[i10][14];
      array5.tcIdTipoTarifa[i10] = arrayTarifas[i10][15];
      array5.tcIdGrupoParentesco[i10] = arrayTarifas[i10][16];
      array5.parentescosDescripcion[i10] = arrayTarifas[i10][17];
      array5.idgrupoParentesco[i10] = arrayTarifas[i10][18];
      array5.plOrden[i10] = arrayTarifas[i10][19];
      array5.tipoMonto[i10] = arrayTarifas[i10][20];
    }
    this.tarifaPlanes = array5;

    var array52 = {
      'poIdPlan': [],
      'pONombre': [],
      'poIdPlanoPCION': [],
      'iDPARENTESCO': [],
      'Nombre': [],
      'nombrePlan': [],
      'checked': [],
      'visible': [],
      'enabled': [],
      'gpRutaImagenGrupo': [],
      'gpIdGrupo': [],
      'tcIdTarifaCosto': [],
      'tcPrimaNeta': [],
      'tcPrimaTotal': [],
      'id': [],
      'tcIdTipoTarifa': [],
      'parentescosDescripcion': [],
      'idgrupoParentesco': [],
      'tipoMonto': []
    }
    var arrayTarifas2 = this.tablaPlanes.map(function (ramos) {
      if (ramos.tcIdTipoTarifa == 2) {
        var poIdPlan = ramos.poIdPlan;
        var pONombre = ramos.poNombre;
        var poIdPlanoPCION = ramos.poIdPlanOpcion;
        var iDPARENTESCO = ramos.emIdParentesco;
        var Nombre = ramos.emApellidoPaterno + ' ' + ramos.emApellidoMaterno + ' ' + ramos.emNombre1 + ' ' + ramos.emNombre2;
        var checked = ramos.checked;
        var visible = ramos.visible;
        var enabled = ramos.enabled;
        var plNombre = ramos.plNombre;
        var gpRutaImagenGrupo = ramos.gpRutaImagenGrupo;
        var gpIdGrupo = ramos.gpIdGrupo;
        var tcIdTarifaCosto = ramos.tcIdTarifaCosto;
        var tcPrimaNeta = ramos.tcPrimaNeta;
        var tcPrimaTotal = ramos.tcPrimaTotal;
        var id = ramos.id;
        var tcIdTipoTarifa = ramos.tcIdTipoTarifa;
        var parentescosDescripcion = ramos.parentescosDescripcion;
        var idgrupoParentesco = ramos.idgrupoParentesco;
        var tipoMonto = ramos.poImg;
        return [poIdPlan, pONombre, poIdPlanoPCION, iDPARENTESCO, Nombre, plNombre, checked, visible, enabled, gpRutaImagenGrupo, gpIdGrupo, tcIdTarifaCosto, tcPrimaNeta, tcPrimaTotal, id, tcIdTipoTarifa, parentescosDescripcion, idgrupoParentesco, tipoMonto];
      }
    });
    for (let i10 = 0; i10 < arrayTarifas2.length; i10++) {
      if (arrayTarifas2[i10] != undefined) {
        array52.poIdPlan[i10] = arrayTarifas2[i10][0];
        array52.pONombre[i10] = arrayTarifas2[i10][1];
        array52.poIdPlanoPCION[i10] = arrayTarifas2[i10][2];
        array52.iDPARENTESCO[i10] = arrayTarifas2[i10][3];
        array52.Nombre[i10] = arrayTarifas2[i10][4];
        array52.nombrePlan[i10] = arrayTarifas2[i10][5];
        array52.checked[i10] = arrayTarifas2[i10][6];
        array52.visible[i10] = arrayTarifas2[i10][7];
        array52.enabled[i10] = arrayTarifas2[i10][8];
        array52.gpRutaImagenGrupo[i10] = arrayTarifas2[i10][9];
        array52.gpIdGrupo[i10] = arrayTarifas2[i10][10];
        array52.tcIdTarifaCosto[i10] = arrayTarifas2[i10][11];
        array52.tcPrimaNeta[i10] = arrayTarifas2[i10][12];
        array52.tcPrimaTotal[i10] = arrayTarifas2[i10][13];
        array52.id[i10] = arrayTarifas2[i10][14];
        array52.tcIdTipoTarifa[i10] = arrayTarifas2[i10][15];
        array52.parentescosDescripcion[i10] = arrayTarifas2[i10][16];
        array52.idgrupoParentesco[i10] = arrayTarifas2[i10][17];
        array52.tipoMonto[i10] = arrayTarifas2[i10][18];
      }
    }
    this.tarifaPlanesGrupo = array52;

    var idTarifa = this.tablaPlanes.map(function (ramos) {
      if (ramos.tcIdTipoTarifa == 2) {
        return ramos.tcIdTarifaCosto;
      }
    });
    var sorted = idTarifa.sort((a, b) => a - b);
    var unique = (sorted.filter(function (value, index) {
      return value !== sorted[index + 1];
    }));
    var arrayG = {
      'poIdPlan': [],
      'pONombre': [],
      'poIdPlanoPCION': [],
      'iDPARENTESCO': [],
      'Nombre': [],
      'nombrePlan': [],
      'checked': [],
      'visible': [],
      'enabled': [],
      'gpRutaImagenGrupo': [],
      'gpIdGrupo': [],
      'tcIdTarifaCosto': [],
      'tcPrimaNeta': [],
      'tcPrimaTotal': [],
      'id': [],
      'tcIdTipoTarifa': [],
      'parentescosDescripcion': [],
      'idgrupoParentesco': [],
      'tipoMonto': []
    }
    for (let idg = 0; idg < this.tarifaPlanesGrupo.id.length; idg++) {
      for (let idg2 = 0; idg2 < unique.length; idg2++) {
        if (unique[idg2] == this.tarifaPlanesGrupo.tcIdTarifaCosto[idg]) {
          arrayG.poIdPlan[idg2] = this.tarifaPlanesGrupo.poIdPlan[idg];
          arrayG.pONombre[idg2] = this.tarifaPlanesGrupo.pONombre[idg];
          arrayG.poIdPlanoPCION[idg2] = this.tarifaPlanesGrupo.poIdPlanoPCION[idg];
          arrayG.iDPARENTESCO[idg2] = this.tarifaPlanesGrupo.iDPARENTESCO[idg];
          arrayG.Nombre[idg2] = this.tarifaPlanesGrupo.Nombre[idg];
          arrayG.nombrePlan[idg2] = this.tarifaPlanesGrupo.nombrePlan[idg];
          arrayG.checked[idg2] = this.tarifaPlanesGrupo.checked[idg];
          arrayG.visible[idg2] = this.tarifaPlanesGrupo.visible[idg];
          arrayG.enabled[idg2] = this.tarifaPlanesGrupo.enabled[idg];
          arrayG.gpRutaImagenGrupo[idg2] = this.tarifaPlanesGrupo.gpRutaImagenGrupo[idg];
          arrayG.gpIdGrupo[idg2] = this.tarifaPlanesGrupo.gpIdGrupo[idg];
          arrayG.tcIdTarifaCosto[idg2] = this.tarifaPlanesGrupo.tcIdTarifaCosto[idg];
          arrayG.tcPrimaNeta[idg2] = this.tarifaPlanesGrupo.tcPrimaNeta[idg];
          arrayG.tcPrimaTotal[idg2] = this.tarifaPlanesGrupo.tcPrimaTotal[idg];
          arrayG.id[idg2] = this.tarifaPlanesGrupo.id[idg];
          arrayG.tcIdTipoTarifa[idg2] = this.tarifaPlanesGrupo.tcIdTipoTarifa[idg];
          arrayG.parentescosDescripcion[idg2] = this.tarifaPlanesGrupo.parentescosDescripcion[idg];
          arrayG.idgrupoParentesco[idg2] = this.tarifaPlanesGrupo.idgrupoParentesco[idg];
          arrayG.tipoMonto[idg2] = this.tarifaPlanesGrupo.tipoMonto[idg];
        }
      }
    }
    this.tarifaPlanesParent = arrayG;
    var selecciones = "[";
    for (let i13 = 0; i13 < this.cotizador.datosCotizador.length; i13++) {
      if (this.cotizador.datosCotizador[i13]['checked'] == "true") {
        var tcIdTarifaCosto = this.cotizador.datosCotizador[i13]['tcIdTarifaCosto'];
        var enabled = this.cotizador.datosCotizador[i13]['enabled'];
        var visible = this.cotizador.datosCotizador[i13]['visible'];
        var checked = this.cotizador.datosCotizador[i13]['checked'];
        var id = this.cotizador.datosCotizador[i13]['id'];
        var plNombre = this.cotizador.datosCotizador[i13]['plNombre'];
        var tcPrimaTotal = this.cotizador.datosCotizador[i13]['tcPrimaTotal'];
        var tcPrimaNeta = this.cotizador.datosCotizador[i13]['tcPrimaNeta'];
        var idParentesco = this.cotizador.datosCotizador[i13]['emIdParentesco'];
        var gpIdGrupo = this.cotizador.datosCotizador[i13]['gpIdGrupo'];
        var gpRutaImagenGrupo = this.cotizador.datosCotizador[i13]['gpRutaImagenGrupo'];
        var poIdPlan = this.cotizador.datosCotizador[i13]['poIdPlan'];
        var poIdPlanOpcion = this.cotizador.datosCotizador[i13]['poIdPlanOpcion'];
        var parentescosDescripcion = this.cotizador.datosCotizador[i13]['parentescosDescripcion'];
        var nombre = this.cotizador.datosCotizador[i13]['emNombre1'] + " " + this.cotizador.datosCotizador[i13]['emNombre2'];
        nombre = nombre.replace(/NULL/g, "");
        nombre = nombre.replace(/null/g, "");
        var poNombre = this.cotizador.datosCotizador[i13]['poNombre'];
        var tcIdTipoTarifa = this.cotizador.datosCotizador[i13]['tcIdTipoTarifa'];
        var plDescripcion = this.cotizador.datosCotizador[i13]['plDescripcion'];
        var poNombre = this.cotizador.datosCotizador[i13]['poNombre'];
        var TCidGrupoParentesco = this.cotizador.datosCotizador[i13]['tcIdGrupoParentesco'];   // Prioridad 4 (Si aplica)
        var TCidParentesco = this.cotizador.datosCotizador[i13]['tcIdParentesco']; // Prioridad 4 (Si aplica)
        var Raorden = this.cotizador.datosCotizador[i13]['raOrden'];       //  – Prioridad 1
        var Plorden = this.cotizador.datosCotizador[i13]['plOrden'];     // - Prioridad 2
        var Poorden = this.cotizador.datosCotizador[i13]['poOrden'];    //– Prioridad 3
        selecciones += "{\"tcIdTarifaCosto\":" + tcIdTarifaCosto + ", \"enabled\":" + enabled + ",\"visible\":" + visible + ",\"checked\":" + checked + ",\"id\":" + id + ",\"plNombre\":\"" + plNombre + "\",\"tcPrimaTotal\":\"" + tcPrimaTotal + "\",\"tcPrimaNeta\":\"" + tcPrimaNeta + "\",\"idParentesco\":" + idParentesco + ",\"gpIdGrupo\":" + gpIdGrupo + ",\"gpRutaImagenGrupo\":\"" + gpRutaImagenGrupo + "\",\"poIdPlan\":\"" + poIdPlan + "\",\"poIdPlanOpcion\":" + poIdPlanOpcion + ",\"parentescosDescripcion\":\"" + parentescosDescripcion + "\",\"nombre\":\"" + nombre + "\",\"poNombre\":\"" + poNombre + "\" ,\"tcIdTipoTarifa\":" + tcIdTipoTarifa + " ,\"plDescripcion\":\"" + plDescripcion + "\" ,\"poNombre\":\"" + poNombre + "\",\"tcIdGrupoParentesco\":\"" + TCidGrupoParentesco + "\",\"tcIdParentesco\":\"" + TCidParentesco + "\",\"raOrden\":\"" + Raorden + "\",\"plOrden\":\"" + Plorden + "\",\"poorden\":\"" + Poorden + "\"},";
      }
    }
    if (selecciones.length != 1) {
      selecciones = selecciones.substring(0, selecciones.length - 1);
    }
    selecciones += "]";
    selecciones = selecciones.replace(/\\/g, "/");
    var patron = /\n/gi
    selecciones = selecciones.replace(patron, " ");
    patron = /\r/gi
    selecciones = selecciones.replace(patron, " ");
    selecciones = selecciones.replace('\r\n', " ");
    this.costoSelecciones = JSON.parse(selecciones);
    this.ordenarPlanesPorPrioridad(selecciones);
    var selectplanes = this.costoSelecciones.map(function (ramos) { return ramos.plNombre; });
    var sorted = selectplanes.sort();
    var unique = (sorted.filter(function (value, index) {
      return value !== sorted[index + 1];
    }));
    var rutas = [];
    var costoTotal = [];
    var orden = [];
    var idplan = [];
    for (let imag = 0; imag < this.costoSelecciones.length; imag++) {
      for (let imag2 = 0; imag2 < unique.length; imag2++) {
        if (unique[imag2] == this.costoSelecciones[imag]['plNombre']) {
          rutas[imag2] = this.costoSelecciones[imag]['gpRutaImagenGrupo'];
          orden[imag2] = this.costoSelecciones[imag]['plOrden'];
          idplan[imag2] = this.costoSelecciones[imag]['poIdPlan'];
          if (!costoTotal[imag2]) {
            costoTotal[imag2] = 0;
          }
          var conv = parseFloat(this.costoSelecciones[imag]['tcPrimaTotal']);
          var conv2 = parseFloat(costoTotal[imag2]);
          if (this.costoSelecciones[imag]['tcIdTipoTarifa'] == 1) {
            costoTotal[imag2] = (conv + conv2).toFixed(2);
          } else {
            costoTotal[imag2] = conv;
          }
        }
      }
    }
    var planesPanel = {
      'planes': unique,
      'imagen': rutas,
      'costoTotal': costoTotal,
      'plOrden': orden,
      'idplan': idplan
    }
    this.planesPanel3 = planesPanel
    this.compensacionPlanOpcion = this.cotizador.compensacionPlanOpcion;
    this.estadoCuenta = this.cotizador.estadoCuenta;
    for (let c1 = 0; c1 < this.estadoCuenta.length; c1++) {
      if (this.estadoCuenta[c1].tipo == "4" && this.estadoCuenta[c1].abono == "0") {
        const element = this.estadoCuenta[c1];
        this.Clip = element;
        break;
      }
    }
    var xmlCosto = "<estadoCuenta>";
    for (const iterator of this.estadoCuenta) {
      xmlCosto += "<estadoCuenta><ecDescripcion>" + iterator.descripcion + "</ecDescripcion><total>" + iterator.cantidad + "</total></estadoCuenta>"
    }
    xmlCosto += "</estadoCuenta>";
    this.xmlCOsto = xmlCosto;

    var tarifas = this.tablaPlanes.map(function (ramos) {
      return ramos.tcIdTarifaCosto;
    });
    var sorted = tarifas.sort();
    var unique = (sorted.filter(function (value, index) {
      return value !== sorted[index + 1];
    }));
    if (!this.carga) {
      var opcionR;
      for (let ir = 0; ir < this.ramos.IdRamo.length; ir++) {
        if (ir == 0)
          for (let ir2 = 0; ir2 < this.planesGrupoJson.length; ir2++) {
            if (this.ramos.IdRamo[ir] == this.planesGrupoJson[ir2]['IdRamo']) {
              opcionR = this.planesGrupoJson[ir2]['gpIdGrupo'];
              break;
            }
          }
      }
      this.planCollapse = opcionR;
      this.carga = true;
    }

    let invertir = this.planesOrdenJsonF
    invertir.sort(function (c, d) {
      if (c.planOrden < d.planOrden) {
        return 1;
      }
      if (c.planOrden > d.planOrden) {
        return -1;
      }
      return 0;
    });

    for (let in1 = 0; in1 < this.planesGrupoJson.length; in1++) {
      for (let in2 = 0; in2 < invertir.length; in2++) {
        if (this.planesGrupoJson[in1]['gpIdGrupo'] == invertir[in2]['gpIdGrupo']) {
          this.planesGrupoJson[in1]['plIdRamo'] = invertir[in2]['plIdRamo'];
          this.planesGrupoJson[in1]['poIdPlan'] = invertir[in2]['poIdPlan'];
          this.planesGrupoJson[in1]['plNombre'] = invertir[in2]['plNombre'];
          this.planesGrupoJson[in1]['gpIdGrupo'] = invertir[in2]['gpIdGrupo'];
          this.planesGrupoJson[in1]['plOrden'] = invertir[in2]['plOrden'];
          this.planesGrupoJson[in1]['archivoPlan'] = invertir[in2]['archivoPlan'];
          this.planesGrupoJson[in1]['gpRutaImagenGrupo'] = invertir[in2]['gpRutaImagenGrupo'];
          this.planesGrupoJson[in1]['plDescripcion'] = invertir[in2]['plDescripcion'];
          this.planesGrupoJson[in1]['visible'] = invertir[in2]['visible'];
          this.planesGrupoJson[in1]['enabled'] = invertir[in2]['enabled'];
          this.planesGrupoJson[in1]['gpGrupoEtiqueta'] = invertir[in2]['gpGrupoEtiqueta'];
          this.planesGrupoJson[in1]['gpIdGrupo'] = invertir[in2]['gpIdGrupo'];
        }
      }
    }
    this.planesOrdenJsonF.sort(function (c, d) {
      if (c.planOrden > d.planOrden) {
        return 1;
      }
      if (c.planOrden < d.planOrden) {
        return -1;
      }
      return 0;
    });
    this.spinner.hide();

    try {
      this._BuscarPlanesv2.regresarDatos(this.ramos);
      this.habilitarSelects = true;
      this.mensajesProgreso = null;
      this.mostrarCotizador = true;
      this.habilitarSelecciones = 'enable';
      this.porcentaje = "100%";
    } catch (error) {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 5 ',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'info',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  ordenarPlanesPorPrioridad(arr) {
    var array = JSON.parse(arr);
    var temp;
    for (let i = 1; i < array.length; i++) {
      for (let j = 0; j < array.length - i; j++) {
        if (parseInt(array[j]['raOrden']) > parseInt(array[j + 1]['raOrden'])) {
          temp = array[j];
          array[j] = array[j + 1];
          array[j + 1] = temp;
        }
        if (parseInt(array[j]['raOrden']) == parseInt(array[j + 1]['raOrden'])) {
          if (parseInt(array[j]['plOrden']) > parseInt(array[j + 1]['plOrden'])) {
            temp = array[j];
            array[j] = array[j + 1];
            array[j + 1] = temp;
          }
          if (parseInt(array[j]['plOrden']) == parseInt(array[j + 1]['plOrden'])) {
            if (parseInt(array[j]['poorden']) > parseInt(array[j + 1]['poorden'])) {
              temp = array[j];
              array[j] = array[j + 1];
              array[j + 1] = temp;
            }
            if (parseInt(array[j]['poorden']) == parseInt(array[j + 1]['poorden'])) {
              if (parseInt(array[j]['tcIdGrupoParentesco']) > parseInt(array[j + 1]['tcIdGrupoParentesco'])) {
                temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
              }
              if (parseInt(array[j]['tcIdGrupoParentesco']) == parseInt(array[j + 1]['tcIdGrupoParentesco'])) {
                if (parseInt(array[j]['tcIdParentesco']) > parseInt(array[j + 1]['tcIdParentesco'])) {
                  temp = array[j];
                  array[j] = array[j + 1];
                  array[j + 1] = temp;
                }

              }
            }
          }
        }
      }
    }
    this.costoSelecciones = array;
    this.temp2 = [];
    for (let i = 0; i < array.length; i++) {
      this.temp2.push(array[i]['poIdPlan']);
    }
    this.temp2 = this.temp2.filter((item, index) => {
      return this.temp2.indexOf(item) === index;
    });
  }

  eliminarObjetosDuplicados(arr, prop) {
    var nuevoArray = [];
    var lookup = {};

    for (var i in arr) {
      lookup[arr[i][prop]] = arr[i];
    }

    for (i in lookup) {
      nuevoArray.push(lookup[i]);
    }

    return nuevoArray;
  }

  ordenarCampos(data, key, orden) {
    return data.sort(function (a, b) {
      var x = a[key],
        y = b[key];

      if (orden === 'asc') {
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
      }

      if (orden === 'desc') {
        return ((x > y) ? -1 : ((x < y) ? 1 : 0));
      }
    });
  }

  getlink(idramos) {
    var ramo = '#' + idramos;
    return ramo;
  }

  getLinkTarifas(idPlan) {
    var plan = '#' + idPlan;
    return plan;
  }

  getLinkAyuda(idPlan) {
    var plan = '#modal' + idPlan;
    return plan;
  }

  getLinkDocumentoPlan(link) {
    var cadenaDeTexto = link == undefined ? '' : link;
    var resultado = cadenaDeTexto.replace(/\\/g, "/");
    var resultado = resultado.replace("../", this.urlIconos);
    if (resultado.length > 10) {
      this.trustUrlDoc = this.sanitizer.bypassSecurityTrustResourceUrl(resultado);
    } else {
      this.trustUrlDoc = this.urlIconos + '0';
    }
    return this.trustUrlDoc;
  }

  decargarPDF(link) {
    var cadenaDeTexto = link == undefined ? '' : link;
    var resultado = cadenaDeTexto.replace(/\\/g, "/");
    var resultado = resultado.replace("../", this.urlIconos);
    if (resultado.length > 10) {
      this.trustUrlDoc = this.sanitizer.bypassSecurityTrustResourceUrl(resultado);
    } else {
      this.trustUrlDoc = this.urlIconos + '0';
    }
    return this.trustUrlDoc;
  }
  getLinkIcono(link) {
    if (link != undefined) {
      var cadenaDeTexto = link;
      var resultado = cadenaDeTexto.replace(/\\/g, "/");
      var resultado = resultado.replace("../", this.urlIconos);
      this.trustUrlDoc = this.sanitizer.bypassSecurityTrustResourceUrl(resultado);
      return this.trustUrlDoc;
    }
  }

  async obtenerDatos() {
    try {
      const response: any = await this._BuscarPlanesv2.getPlanesToken(this.identity.id, this.token)
      this.resObtenerDatos = response.body['data'];
    } catch (error) {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 6 ',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'info',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  async capturar() {
    this.comprobarSesion();
    this.spinner.show();
    this.habilitarSelecciones = "disabled";
    this.habilitarSelects = true;
    try {
      await this._BuscarPlanesv2.regresarDatos('INICIANDO');
      this.mensajesProgreso = "CAPTURANDO DATOS...";
      this.porcentaje = "5%";
    } catch (error) {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 7',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'info',
        confirmButtonText: 'Aceptar',
      });
    }

    var oldSeleccionXml = "";
    if (this.eleccion.tarifa != "0") {
      var seleccionesOld = "[";
      for (let i13 = 0; i13 < this.cotizador.datosCotizador.length; i13++) {
        if (this.cotizador.datosCotizador[i13]['checked'] == "true") {
          var tcIdTarifaCosto = this.cotizador.datosCotizador[i13]['tcIdTarifaCosto'];
          var idEmpleado = this.cotizador.datosCotizador[i13]['id'];
          var costo = this.cotizador.datosCotizador[i13]['tcPrimaTotal'];
          oldSeleccionXml += "<TarifaCosto TCidTarifaCosto=\"" + tcIdTarifaCosto + "\" idEmpleado=\"" + idEmpleado + "\"></TarifaCosto>"
          seleccionesOld += "{\"tcidtarifacostoOld\":" + tcIdTarifaCosto + ", \"costoOld\":null,\"idempleadoOld\":" + idEmpleado + ",\"nuevoOld\":null},";
        }
      }
      var newSeleccionXml = "";
      var selecciones = "[";
      for (let i13 = 0; i13 < this.cotizador.datosCotizador.length; i13++) {
        if (this.cotizador.datosCotizador[i13]['tcIdTarifaCosto'] == this.eleccion.tarifa) {
          var tcIdTarifaCosto = this.cotizador.datosCotizador[i13]['tcIdTarifaCosto'];
          var idEmpleado = this.cotizador.datosCotizador[i13]['id'];
          var costo = this.cotizador.datosCotizador[i13]['tcPrimaTotal'];
          newSeleccionXml += "<TarifaCosto TCidTarifaCosto=\"" + tcIdTarifaCosto + "\"  idEmpleado=\"" + idEmpleado + "\"></TarifaCosto>"
          selecciones += "{\"tcidtarifacosto\":" + this.eleccion.tarifa + ",\"costo\":null, \"idempleado\":" + idEmpleado + ", \"nuevo\": null },";
        }
      }
      for (let i13 = 0; i13 < this.cotizador.datosCotizador.length; i13++) {
        if (this.cotizador.datosCotizador[i13]['checked'] == "true") {
          var tcIdTarifaCosto = this.cotizador.datosCotizador[i13]['tcIdTarifaCosto'];
          var idEmpleado = this.cotizador.datosCotizador[i13]['id'];
          var costo = this.cotizador.datosCotizador[i13]['tcPrimaTotal'];
          newSeleccionXml += "<TarifaCosto TCidTarifaCosto=\"" + tcIdTarifaCosto + "\"   idEmpleado=\"" + idEmpleado + "\"></TarifaCosto>"
          selecciones += "{\"tcidtarifacosto\":" + tcIdTarifaCosto + ",\"costo\":null, \"idempleado\":" + idEmpleado + ", \"nuevo\": null },";
        }
      }
      if (seleccionesOld.length != 1)
        seleccionesOld = seleccionesOld.substring(0, seleccionesOld.length - 1);
      seleccionesOld += "]";
      if (selecciones.length != 1)
        selecciones = selecciones.substring(0, selecciones.length - 1);
      selecciones += "]";
      var inicio = {
        "idEmpresa": this.identity.idEmpresa,
        "planesSeleccionados": JSON.parse(selecciones),
        "planesSeleccionadosOld": JSON.parse(seleccionesOld),
        "transfer": null
      }
      this.tarifaPlanes = "";
      this.porcentaje = "10%";
      this.buscarPlanes(inicio);
    }
  }

  capturarFalse(idtaridaFalse) {
    this.comprobarSesion();
    this.spinner.show();
    this.displayEscedentes = 'none';
    this.habilitarSelecciones = "disabled";
    this.habilitarSelects = false;
    var seleccionesOld = "[";
    var oldSeleccionXml = "";
    for (let i13 = 0; i13 < this.cotizador.datosCotizador.length; i13++) {
      if (this.cotizador.datosCotizador[i13]['checked'] == "true") {
        var tcIdTarifaCosto = this.cotizador.datosCotizador[i13]['tcIdTarifaCosto'];
        var idEmpleado = this.cotizador.datosCotizador[i13]['id'];
        oldSeleccionXml += "<TarifaCosto TCidTarifaCosto=\"" + tcIdTarifaCosto + "\"  idEmpleado=\"" + idEmpleado + "\"></TarifaCosto>"
        seleccionesOld += "{\"tcidtarifacostoOld\":" + tcIdTarifaCosto + ", \"costoOld\":null,\"idempleadoOld\":" + idEmpleado + ",\"nuevoOld\":null},";
      }
    }
    if (seleccionesOld.length != 1)
      seleccionesOld = seleccionesOld.substring(0, seleccionesOld.length - 1);
    seleccionesOld += "]";
    for (let i13 = 0; i13 < this.cotizador.datosCotizador.length; i13++) {
      if (this.cotizador.datosCotizador[i13]['tcIdTarifaCosto'] == idtaridaFalse) {
        this.cotizador.datosCotizador[i13]['checked'] = "false";
      }
    }
    var selecciones = "[";
    var newSeleccionXml = "";
    for (let i13 = 0; i13 < this.cotizador.datosCotizador.length; i13++) {
      if (this.cotizador.datosCotizador[i13]['checked'] == "true") {
        var tcIdTarifaCosto = this.cotizador.datosCotizador[i13]['tcIdTarifaCosto'];
        var idEmpleado = this.cotizador.datosCotizador[i13]['id'];
        //var costo = this.cotizador.datosCotizador[i13]['tcPrimaTotal'];
        newSeleccionXml += "<TarifaCosto TCidTarifaCosto=\"" + tcIdTarifaCosto + "\"  idEmpleado=\"" + idEmpleado + "\"></TarifaCosto>"
        selecciones += "{\"tcidtarifacosto\":" + tcIdTarifaCosto + ",\"costo\":null, \"idempleado\":" + idEmpleado + ", \"nuevo\": null },";
      }
    }
    if (selecciones.length != 1)
      selecciones = selecciones.substring(0, selecciones.length - 1);
    selecciones += "]";
    var inicio = {
      "idEmpresa": this.identity.idEmpresa,
      "planesSeleccionados": JSON.parse(selecciones),
      "planesSeleccionadosOld": JSON.parse(seleccionesOld),
      "transfer": null
    }
    this.eleccion = new seleccionado(0);
    this.buscarPlanes(inicio);
  }

  candados2(parametros) {
    this.habilitarSelecciones = "disabled";
    let getHeaders: HttpHeaders = new HttpHeaders({
      'token': this.token
    });
    this._http.post(this.api + "candados/",
      {
        "id": parametros.id,
        "idEmpresa": parametros.idEmpresa,
        "numeroEmpleado": parametros.numeroEmpleado,
        "idPerfil": parametros.idPerfil,
        "emOficina": parametros.emOficina,
        "emSalarioBase": parametros.emSalarioBase,
        "emFechaIngreso": parametros.emFechaIngreso,
        "antiguedadEmpresa": parametros.antiguedadEmpresa,
        "tcIdTarifaCosto": parseInt(parametros.tcIdTarifaCosto),
        "tcIdPlanOpcion": parametros.tcIdPlanOpcion,
        "poIdPlan": parametros.poIdPlan,
        "checked": parametros.checked,
      }, { headers: getHeaders })
      .subscribe(
        data => {
          if (data['data']) {
            if (data['data']['planesPerfilTemp']) {
              var array5 = {
                'poIdPlan': [],
                'pONombre': [],
                'poIdPlanoPCION': [],
                'iDPARENTESCO': [],
                'Nombre': [],
                'nombrePlan': [],
                'checked': [],
                'visible': [],
                'enabled': [],
                'gpRutaImagenGrupo': [],
                'gpIdGrupo': [],
                'tcIdTarifaCosto': []
              }
              var arrayTarifas = data['data']['planesPerfilTemp'].map(function (ramos) {
                var poIdPlan = ramos.poIdPlan;
                var pONombre = ramos.poNombre;
                var poIdPlanoPCION = ramos.poIdPlanOpcion;
                var iDPARENTESCO = ramos.emIdParentesco;
                var Nombre = ramos.emApellidoPaterno + ' ' + ramos.emApellidoMaterno + ' ' + ramos.emNombre1 + ' ' + ramos.emNombre2;
                var checked = ramos.checked;
                var visible = ramos.visible;
                var enabled = ramos.enabled;
                var plNombre = ramos.plNombre;
                var gpRutaImagenGrupo = ramos.gpRutaImagenGrupo;
                var gpIdGrupo = ramos.gpIdGrupo;
                var tcIdTarifaCosto = ramos.tcIdTarifaCosto;
                return [poIdPlan, pONombre, poIdPlanoPCION, iDPARENTESCO, Nombre, plNombre, checked, visible, enabled, gpRutaImagenGrupo, gpIdGrupo, tcIdTarifaCosto];
              });
              for (let i10 = 0; i10 < arrayTarifas.length; i10++) {
                array5.poIdPlan[i10] = arrayTarifas[i10][0];
                array5.pONombre[i10] = arrayTarifas[i10][1];
                array5.poIdPlanoPCION[i10] = arrayTarifas[i10][2];
                array5.iDPARENTESCO[i10] = arrayTarifas[i10][3];
                array5.Nombre[i10] = arrayTarifas[i10][4];
                array5.nombrePlan[i10] = arrayTarifas[i10][5];
                array5.checked[i10] = arrayTarifas[i10][6];
                array5.visible[i10] = arrayTarifas[i10][7];
                array5.enabled[i10] = arrayTarifas[i10][8];
                array5.gpRutaImagenGrupo[i10] = arrayTarifas[i10][9];
                array5.gpIdGrupo[i10] = arrayTarifas[i10][10];
                array5.tcIdTarifaCosto[i10] = arrayTarifas[i10][11];
              }
              this.tarifaPlanes2 = array5;
              var resultCandados = data['data']['planesPerfilTemp']
              var info = data['info'];
              var mensajes = data['data']['mensajes'];
              this.obtenerJson(resultCandados);
            }
          } else {
            swal({
              title: '¡Error de conexión! 8',
              html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
              type: 'error',
              confirmButtonText: 'Aceptar',
            });

            this.habilitarSelecciones = "enabled";
            this.eleccion = new seleccionado(0);
          }
        },
        error => {
          var errorMessage = <any>error;
          swal({
            title: '¡Error de conexión! 9',
            html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
            type: 'error',
            confirmButtonText: 'Aceptar',
          });
          this.habilitarSelecciones = "enabled";
          this.eleccion = new seleccionado(0);

        }
      );
  }
  obtenerJson(datosCotizador) {
    var seleccionadosOld = "[";
    var seleccionados = "[";
    const id = this.identity.id;
    for (let i = 0; i < datosCotizador.length; i++) {
      if (datosCotizador[i]['checked'] == "true") {
        const idTC = datosCotizador[i]['tcIdTarifaCosto'];
        const PT = datosCotizador[i]['tcPrimaTotal'];
        const string = "{\"costo\":" + PT + ",\"idempleado\":" + id + ",\"nuevo\":\"N\",\"tcidtarifacosto\":" + idTC + "},";
        const string2 = "{\"costo\":" + PT + ",\"idempleado\":" + id + ",\"nuevo\":\"U\",\"tcidtarifacosto\":" + idTC + "},";
        seleccionadosOld += string2;
        seleccionados += string;
      }
    }
    if (seleccionados.length != 1)
      seleccionados = seleccionados.substring(0, seleccionados.length - 1);
    seleccionados += "]";
    if (seleccionadosOld.length != 1)
      seleccionadosOld = seleccionadosOld.substring(0, seleccionadosOld.length - 1);
    seleccionadosOld += "]";
    // // // // console.log(seleccionados);

    var ejecutor = {
      "declaraciones": {},
      "planesPerfil": [],
      "planesSeleccionados": JSON.parse(seleccionados),
      "planesSeleccionadosOld": JSON.parse(seleccionadosOld)
    }
    ejecutor.declaraciones = this.cotizadorv3.declaraciones;
    ejecutor.planesPerfil = datosCotizador;
    ejecutor.planesSeleccionadosOld = this.cotizadorv3.planesSeleccionadosOld;
    this.calcularSelcecciones(ejecutor);
  }

  calcularSelcecciones(ejecutor) {
    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    this._http.post(this.urlWs + "cotizador/calculos",
      JSON.stringify(ejecutor),
      { headers: getHeaders }
    ).subscribe(
      data => {
        this.eleccion = new seleccionado(0);
        if (data['planesPerfilTemp']) {
          this.cotizador.datosCotizador = data['planesPerfilTemp'];
          if (this.identity.idEmpresa == 369) {
            this.cotizador.estadoCuenta = data['edoCuenta'];
          } else {
            this.cotizador.estadoCuenta = data['estadoCuenta'];
          }
          this.cotizador.tarifas = data['tmpDistribucionCFF'];
          this.cotizador.compensacionPlanOpcion = data['compensacionPlanOpcion'];
          localStorage.setItem('cotizador', JSON.stringify(this.cotizador));
          this.habilitarSelecciones = "enabled";
          if (data['mensajes']) {
            var mensajes = data['mensajes'];
            for (let m1 = 0; m1 < mensajes.length; m1++) {
              var descripcion = mensajes[m1]['descripcion'];
              var tipo = mensajes[m1]['tipo'];
              swal(descripcion, '', tipo);
            }
          }
          this.buscaPlanesSave();
        }
      },
      error => {
        var errorMessage = <any>error;
        this.eleccion = new seleccionado(0);
        swal({
          title: '¡Error de conexión! 10',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.habilitarSelecciones = "enabled";
      }
    );
  }

  async borrarMatriz() {
    try {
      await this._BuscarPlanesv2.deleteMatriz(this.token);
    } catch (error) { }
  }

  guardarSeleccionados() {
    this.comprobarSesion();
    this.habilitarSelecciones = "disabled";
    this.mostrarAlert();
    const datosCotizador = this.cotizador.datosCotizador;
    var planesSeleccionados = "<ROOT>";
    const id = this.identity.id;
    for (let i = 0; i < datosCotizador.length; i++) {
      if (datosCotizador[i]['checked'] == "true") {
        const cantidad = this.cotizadorv3.declaraciones['cantidadPago'];
        const idTC = datosCotizador[i]['tcIdTarifaCosto'];
        const idempleado = datosCotizador[i]['id'];
        var PT = datosCotizador[i]['tcPrimaTotal'];
        PT = parseFloat(PT).toFixed(4)
        planesSeleccionados += "<TarifaCosto TCidTarifaCosto=\"" + idTC + "\" Costo=\"" + PT + "\" idEmpleado=\"" + idempleado + "\"></TarifaCosto>";
      }
    }
    planesSeleccionados += "</ROOT>";
    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    this.idVigencia = this.cotizadorv3.declaraciones['idVigencia'];
    this._http.post(this.urlWs + "planesPerfil/tmp/",
      {
        "idEmpleado": this.cotizadorv3.declaraciones['idEmpleado'],
        "idEmpresa": this.cotizadorv3.declaraciones['idEmpresa'],
        "xmlPlanesSeleccionados": planesSeleccionados
      }, { headers: getHeaders })
      .subscribe(async (response) => {
        // aqui se pondria el guardado del pago btn1
        if (!this.Clip) {
          // this.solicitudCreadaDefaulteo.emit({solicitudCreada:false,numEmpleado:this.identity.numEmpleado});
        } else {
          try {
            await this._BuscarPlanesv2.registraCostoPago(this.identity.id, this.Clip.cantidad, 0);
          } catch (error) { }
        }
        this.habilitarSelecciones = "enabled";
        swal({
          title: '¡Guardado correctamente!',
          type: 'success',
          confirmButtonText: 'Aceptar',
        });
      }, error => {
        var errorMessage = <any>error;
        swal({
          title: '¡Error de conexión! 11',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.habilitarSelecciones == 'enabled';
      });
  }

  async getParametros() {
    try {
      const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 119);
      if (!response) {
        var status = "error";
      } else {
        if (response.paId == 119) {
          this.parametro119 = response.paValor.replace(/ /g, "");
        }
      }
    } catch (error) { }
    try {
      const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 126);
      if (!response) {
        var status = "error";
      } else {
        if (response.paId == 126) {
          this.parametro126 = response.paValor.replace(/ /g, "");
          if (this.parametro126 == 1)
            this.consentimeinto = true;
          // console.log('parametro126-' + this.parametro126 + '--');
        }
      }
    } catch (error) { }
    try {
      const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 114);
      if (!response) {
        var status = "error";
      } else {
        if (response.paId == 114) {
          this.parametro114 = response.paValor.replace(/ /g, "");
        }
      }
    } catch (error) { }
  }

  guardarSeleccionadosPDF(opcion: Number) {
    this.comprobarSesion();
    localStorage.removeItem('validando2');
    if (opcion == 2) {
      this.opcionRedirigir = 1;
    }
    this.solicitud = null;
    this.mensajesSolicitud = "Conectando...";
    localStorage.removeItem('cierreBeneficiarios');
    this.solicitudCreada = false;
    const datosCotizador = this.cotizador.datosCotizador;
    var planesSeleccionados = "<ROOT>";
    for (let i = 0; i < datosCotizador.length; i++) {
      if (datosCotizador[i]['checked'] == "true") {
        const cantidad = this.cotizadorv3.declaraciones['cantidadPago'];
        const idTC = datosCotizador[i]['tcIdTarifaCosto'];
        var PT = datosCotizador[i]['tcPrimaTotal'];
        PT = parseFloat(PT).toFixed(4)
        const id = datosCotizador[i]['id'];
        planesSeleccionados += "<TarifaCosto TCidTarifaCosto=\"" + idTC + "\" Costo=\"" + PT + "\" idEmpleado=\"" + id + "\"></TarifaCosto>";
      }
    }
    planesSeleccionados += "</ROOT>";
    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    if (opcion != 2) {
      this.ocultarSolicitud = false;
    }
    var entrada = {
      "idEmpleado": this.cotizadorv3.declaraciones['idEmpleado'],
      "idEmpresa": this.cotizadorv3.declaraciones['idEmpresa'],
      "xmlPlanesSeleccionados": planesSeleccionados
    }
    let planBasicoVigenciaActiva;
    let insertaPlanes;
    if (this.idMultivigenciaActual == this.idVigenciaVigente) {
      planBasicoVigenciaActiva = true;
    }
    if (planBasicoVigenciaActiva && +this.tipoDefaulteo == 2) {
      insertaPlanes = this.urlWs + "planesPerfil/tmp/";
    } else {
      insertaPlanes = this.urlWs + "planesPerfil/tmp/multivigencia/" + this.idMultivigencia;
    }
    this._http.post(insertaPlanes,
      {
        "idEmpleado": this.cotizadorv3.declaraciones['idEmpleado'],
        "idEmpresa": this.cotizadorv3.declaraciones['idEmpresa'],
        "xmlPlanesSeleccionados": planesSeleccionados
      }, { headers: getHeaders })
      .subscribe(async response => {
        if (!this.Clip) {
          // this.solicitudCreadaDefaulteo.emit({solicitudCreada:false,numEmpleado:this.identity.numEmpleado});
        }
        if (!this.Clip) {
          // this.solicitudCreadaDefaulteo.emit({solicitudCreada:false,numEmpleado:this.identity.numEmpleado});
        } else {
          try {
            await this._BuscarPlanesv2.registraCostoPago(this.identity.id, this.Clip.cantidad, 0)
          } catch (error) { }
        }
        this.mensajesSolicitud = "Conectado..."
        if (opcion == 2)
          this.limpiarAnexos();

        if (opcion == 2) {

          console.log('buscar modalA');
          if (this.parametro126 == 1) {
            console.log('activar modalA');
            this.solicitudCreada = true;
            this.ocultarSolicitud = true;
            this.crearSolicitud();
          } else {
            console.log('no activar modal');
            this.crearSolicitud();
          }
        } else {
          this.crearXML2(opcion);
        }
      }, error => {
        var errorMessage = <any>error;
        this.habilitarSelecciones = "enabled";
        swal({
          title: '¡Error de conexión! 13 ',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        localStorage.setItem('validando2', 'true');
        //localStorage.removeItem('validando2');
      }
      )
  }
  //-- no se esta usando
  async crearXML(opcion: Number, bene: Number) {
    this.comprobarSesion();
    this.mensajesSolicitud = "Creando documento...";
    try {
      let response: any = await this._BuscarPlanesv2.getXmlSolicitud(this.identity.id, this.token, opcion)
      if (opcion == 2) {
        response = response.replace("</item>", "<preview>false</preview></item>");
      } else if (opcion == 1) {
        response = response.replace("</item>", "<preview>true</preview></item>");
      }

      //Adaptacion para mostrar o quitar firmas
      if (this.quitarFirmas) {
        response = response.replace("</item>", "<firmas>true</firmas></item>");
      } else {
        response = response.replace("</item>", "<firmas>false</firmas></item>");
      }

      if (this.quitarSeleccionesAnteriores) {
        response = response.replace("</item>", "<seleccionesanteriores>true</seleccionesanteriores></item>");
      } else {
        response = response.replace("</item>", "<seleccionesanteriores>false</seleccionesanteriores></item>");
      }

      if (this.prefijoSolicitud.emPrefijoSolicitud == 5) {
        if (this.quitarResumenDescuento) {
          response = response.replace("</item>", "<descuentos>true</descuentos></item>");
        } else {
          response = response.replace("</item>", "<descuentos>false</descuentos></item>");
        }
      }

      var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "")

      var d = new Date();
      var n = d.toLocaleTimeString();
      var hhmmss = n.slice(0, new Date().toISOString().indexOf("Z")).replace(/:/g, "");
      var rutaPDF = {
        //DocumentoEmpresa\64\Documento_Empleado\idVigencia\
        //DocumentoEmpresa\64\Solicitud
        //'ruta': "DocumentoEmpresa/" + this.identity.idEmpresa + "/" + this.idVigencia + "/Solicitud",
        'ruta': "DocumentoEmpresa/" + this.identity.idEmpresa + "/Solicitud",
        //'archivo': "Solicitud_" + this.identity.id + "_" + this.identity.idEmpresa + ".pdf"
        'archivo': "" + this.identity.id + "_" + YYYYMMDD + hhmmss + ".pdf"
      }

      this.nombreSolicitud = rutaPDF.archivo;
      this.pathFileSS = rutaPDF.ruta + "/" + rutaPDF.archivo;
      try {
        const data = await this._BuscarPlanesv2.convertirPdf(rutaPDF, String(response), this.token, this.prefijoSolicitud.emPrefijoSolicitud);
        localStorage.setItem('validando2', 'true');
        //localStorage.removeItem('validando2');
        console.log('convirtiendo xml');
        // //////////////// // // // console.log(data);
        this.mensajesSolicitud = null;
        if (this.parametro126 != 1) {
          if (this.anexos == false) {
            var solicitud = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
            ///this.trustUrlDoc = this.sanitizer.bypassSecurityTrustResourceUrl(solicitud);
            this.solicitud = solicitud;
            if (opcion == 2) {

              this.validacionSolicitud = this.solicitudExistente2();
            }
            //this.habilitarSelecciones = "disabled";
            this.habilitarSelecciones = "enabled";
          } else {
            this.prueba();
          }
        } else {
          if (opcion == 2) {
            this.validacionSolicitud = this.solicitudExistente2();
          }
          this.getSolicitud();
          this.solicitudCreada = true;
          this.urlSolicitudEspera = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
        }
        if (this.parametro119 == 1 && opcion == 2) {
          console.log('entra mandar correo');
          this.correo(this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta + '/' + rutaPDF.archivo));
        }
      } catch (error) {
        var errorMessage = <any>error;
        swal({
          title: '¡Error de conexión! 14',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.habilitarSelecciones = "enabled";
        localStorage.setItem('validando2', 'true');
      }
    } catch (error) {

      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 15',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.habilitarSelecciones = "enabled";
    }

  }


  async crearXML2(opcion: Number) {
    this.comprobarSesion();
    this.mensajesSolicitud = "Creando documento...";
    try {
      let response = await this._BuscarPlanesv2.getXmlSolicitud(this.identity.id, this.token, opcion)
      if (opcion == 2) {
        response = response.replace("</item>", "<preview>false</preview></item>");
      } else if (opcion == 1) {
        response = response.replace("</item>", "<preview>true</preview></item>");
      }

      //Adaptacion para mostrar o quitar firmas
      if (this.quitarFirmas) {
        response = response.replace("</item>", "<firmas>true</firmas></item>");
      } else {
        response = response.replace("</item>", "<firmas>false</firmas></item>");
      }

      if (this.quitarSeleccionesAnteriores) {
        response = response.replace("</item>", "<seleccionesanteriores>true</seleccionesanteriores></item>");
      } else {
        response = response.replace("</item>", "<seleccionesanteriores>false</seleccionesanteriores></item>");
      }

      if (this.prefijoSolicitud.emPrefijoSolicitud == 5) {
        if (this.quitarResumenDescuento) {
          response = response.replace("</item>", "<descuentos>true</descuentos></item>");
        } else {
          response = response.replace("</item>", "<descuentos>false</descuentos></item>");
        }
      }
      var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "")
      var d = new Date();
      var n = d.toLocaleTimeString();
      var hhmmss = n.slice(0, new Date().toISOString().indexOf("Z")).replace(/:/g, "");
      var rutaPDF = {
        'ruta': "preview/" + this.identity.idEmpresa + "/Solicitud",
        'archivo': "" + this.identity.id + "_" + YYYYMMDD + hhmmss + ".pdf"
      }
      this.nombreSolicitud = rutaPDF.archivo;

      try {
        await this._BuscarPlanesv2.convertirPdf(rutaPDF, String(response), this.token, this.prefijoSolicitud.emPrefijoSolicitud)
        this.habilitarSelecciones = "enabled";
        localStorage.setItem('validando2', 'true');
        this.mensajesSolicitud = null;
        if (this.parametro126 != 1) {
          if (this.anexos == false) {
            var solicitud = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
            this.solicitud = solicitud;
            if (opcion == 2) {
              this.validacionSolicitud = this.solicitudExistente2();
              this.getSolicitud();
            }
            this.habilitarSelecciones = "enabled";
          } else {
            this.prueba();
          }
        } else {
          if (opcion == 2) {
            this.validacionSolicitud = this.solicitudExistente2();
          }
          this.getSolicitud();
          this.solicitudCreada = true;
          this.urlSolicitudEspera = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
          this.solicitud = this.urlSolicitudEspera;
        }
      } catch (error) {
        var errorMessage = <any>error;
        swal({
          title: '¡Error de conexión! 16',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.habilitarSelecciones = "enabled";
      }
    } catch (error) {

      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 17',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.habilitarSelecciones = "enabled";
    }
  }

  async getSolicitud() {
    try {
      const request = await this._empleadoService.getSolicitudBeneficioBF3(this.identity.id);
      this.solicitudes = request;
      for (let i = 0; i < this.solicitudes.length; i++) {
        this.solicitudes = this.solicitudes[0]['soIdSolicitud'];
        if (this.Clip) {
          await this._BuscarPlanesv2.registraCostoPago(this.identity.id, this.Clip.cantidad, this.solicitudes);
        }
        break;
      }
    } catch (error) { }
  }

  async buscarPlanesv3() {
    try {
      const response: any = await this._BuscarPlanesv2.getPlanesPerfilV3(this.identity.id, this.token)
      if (response) {
        if (response.datosCotizador) {
          this.cotizadorv3 = response;
          localStorage.setItem('ejecutor', JSON.stringify(response));
          if (!this.verificaA()) {
            this.mostrarCotizadorEjecutor = true;
            console.log("Muestra----");
          } else {
            this.ocultar = true;
            console.log("No Muestra------ es auto");
          }
          this.buscarPlanes();
        }
      } else {
        window.location.reload();
      }
    } catch (error) {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 18 ',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  async solicitudExistente() {
    var mostrar = false;
    var parametros = {
      'idEmpleado': this.identity.id,
      'idEmpresa': this.identity.idEmpresa
    }

    try {
      const response = await this._BuscarPlanesv2.verificarSolicitudExist(parametros, this.token);
      localStorage.removeItem('solicitud')
      if (!this.cotizador || !this.cotizadorv3) {
        this.buscarPlanesv3();
      } else {
        this.buscaPlanesSave();
        if (!this.verificaA()) {
          this.mostrarCotizadorEjecutor = true;
        } else {
          this.ocultar = true;
        }
      }
      return mostrar = true;
    } catch (error) {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 19 ',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.mensajesSolicitudExist = 'La conexción falló';
      let prueba = localStorage.getItem('prueba');
      if (prueba != "undefined" && prueba != null) {
        let timerInterval;
        swal({
          title: '¡Ya tienes una solicitud! A',
          imageUrl: 'assets/img/beflex/cotizador/beneficios/file.png',
          imageWidth: 200,
          imageAlt: 'Custom image',
          confirmButtonText: 'Aceptar',
          allowOutsideClick: false
        }).then((result) => {
          if (result.value) {
            this.regresar();
          }
        });
      }
      return mostrar
    }
  }

  async solicitudExistente2() {
    var mostrar = false;
    var parametros = {
      'idEmpleado': this.identity.id,
      'idEmpresa': this.identity.idEmpresa
    }
    try {
      await this._BuscarPlanesv2.verificarSolicitudExist(parametros, this.token);
      localStorage.removeItem('solicitud');
      this.solicitudCreadaDefaulteo.emit({ solicitudCreada: true, numEmpleado: this.identity.numEmpleado });
      return mostrar = true;
    } catch (error) {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 20',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.mensajesSolicitudExist = 'Problemas de conexion, Intente más tarde';
      return mostrar;
    }
  }


  redondear(cantidad: any) {
    return this.format(parseFloat(cantidad).toFixed(2))
  }

  async optenerAyuda(pintarPlanes2) {
    try {
      await this._BuscarPlanesv2.regresarDatos(this.ramos);
      this.mostrarMultipleAyuda = false;
    } catch (error) {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 21',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
    }
    this.planOpcion = [];
    this.planOpcionAyuda = pintarPlanes2;
    this.archivoAyuda = null;
    this.planAyuda = null;
    this.descripcionAyuda = null;
    this.RutaImagenGrupoAyuda = null;
    this.urlArchivo = null;
    for (let i = 0; i < this.planes.idPlan.length; i++) {
      if (pintarPlanes2 == this.planes.idPlan[i]) {
        this.archivoAyuda = this.planes.archivoPlan[i];
        this.planAyuda = this.planes.nombrePlan[i];
        this.descripcionAyuda = this.planes.plAyuda[i];
        this.RutaImagenGrupoAyuda = this.planes.gpRutaImagenGrupo[i];
      }
    }
    var archivos = this.tablaPlanes.map(function (ramos) {
      if (ramos.archivo && ramos.poIdPlan == pintarPlanes2) {
        return ramos.archivo;
      }
    });
    var sorted = archivos.sort();
    var unique = (sorted.filter(function (value, index) {
      return value !== sorted[index + 1];
    }));

    if (this.archivoAyuda == 0) {
      for (let i = 0; i < this.tablaPlanes.length; i++) {
        if (pintarPlanes2 == this.tablaPlanes[i]['poIdPlan']) {
          var archivo = this.tablaPlanes[i]['archivo'];
          for (let i2 = 0; i2 < unique.length; i2++) {
            if (this.tablaPlanes[i]['archivo'] == unique[i2]) {
              this.planOpcion[i2] = this.tablaPlanes[i]['poNombre'];
              this.planOpcionArchivo[i2] = unique[i2];
            }
          }
        }
      }
    }
    try {
      await this._BuscarPlanesv2.regresarDatos(this.ramos);
      this.mostrarMultipleAyuda = true;
    } catch (error) {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 22',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
    }
  }

  limpiarVariables() {
    this.planOpcion = [];
    this.planOpcionAyuda = [];
    this.planOpcionArchivo = [];
    this.descripcionAyuda = "";
    this.mostrarMultipleAyuda = false;
    this.eleccion2.tarifa2 = 0;
  }
  archivoAyudaOpcion() {
    for (let i = 0; i < this.planes.idPlan.length; i++) {
      if (this.eleccion2.tarifa2 == this.planOpcion[i]) {
        this.urlArchivo = this.planOpcionArchivo[i];
      }
    }
  }

  format(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
      x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
  }

  async getDatosEmpleado() {
    try {
      const response = await this._empleadoService.getAllEmpleadoDefaulteo(this.identity.id, this._empleadoService.getToken());
      this.datosTitular = response;
      if (this.datosTitular.EMNombre1 == 'NULL') {
        this.datosTitular.EMNombre1 = " ";
      } else if (this.datosTitular.EMNombre2 == 'NULL') {
        this.datosTitular.EMNombre2 = " ";
      } else if (this.datosTitular.EMApellidoPaterno == 'NULL') {
        this.datosTitular.EMApellidoPaterno = " ";
      } else if (this.datosTitular.EMApellidoMaterno == 'NULL') {
        this.datosTitular.EMApellidoMaterno = " ";
      }
    } catch (error) { }
  }

  async getEstados() {
    try {
      const response = await this._empleadoService.getEstadosFiscal();
      this.returnEstado = response;
    } catch (error) { }
  }

  ocultarPlanes(idgrupo, IdRamo) {
    this.planSeleccionadoId = null;
    this.planSeleccionadoId2 = null;
    this.habilitarPanel = idgrupo;
    this.actualizar(IdRamo);
  }

  actualizar(IdRamo) {
    var opcionR;
    for (let ir2 = 0; ir2 < this.planesGrupoJson.length; ir2++) {
      if (IdRamo == this.planesGrupoJson[ir2]['IdRamo']) {
        opcionR = this.planesGrupoJson[ir2]['gpIdGrupo'];
        break;
      }
    }
    this.planCollapse = opcionR;
  }

  compareFn(c1: any, c2: any): boolean {
    return c1 && c2 ? c1.id === c2.id : c1 === c2;
  }
  mostrarAlert() {
    let timerInterval
    swal({
      title: 'Procesando...',
      html: '',
      timer: 4000,
      onOpen: () => {
        swal.showLoading()
        timerInterval = setInterval(() => {

        }, 100)
      },
      onClose: () => {
        clearInterval(timerInterval)
      }
    });
  }

  async Consentimiento(plIdPlan: Number, poIdPlanOpcion: Number, n: Number, idAsegurado: Number, solicitudes: Number) {
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.api + "consentimientos",
      "method": "POST",
      "headers": {
        "content-type": "application/x-www-form-urlencoded"
      },
      xhrFields: {
        responseType: 'blob'
      },
      "data": {
        "idTitular": this.identity.id,
        "idDependiente": idAsegurado.toString(),
        "idPlan": plIdPlan.toString(),
        "idPlanOpcion": poIdPlanOpcion,
        "idCorporativo": this.identity.idCorporativo,
        "idEmpresa": this.identity.idEmpresa,
        "numEmpleado": this.identity.numEmpleado,
        "idEmpleado": '',
        "idSolicitud": solicitudes,
        "idAsegurado": idAsegurado.toString(),
        "num": n
      }
    }
    await $.ajax(settings).done((response) => {
    }).fail((error) => {
      swal({
        title: '¡Error!',
        html: '<small style="color: grey; text-align: justify;">Error al generar el consentimiento.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.habilitarSelecciones = "enabled";
      this.solicitud = this.urlSolicitudEspera;
      this.ocultarSolicitud = false;
    });
  }

  async recorrerAnexos() {
    localStorage.removeItem('cierreBeneficiarios');
    var planesvida = this._BuscarPlanesv2.anexosPosibles();
    const datosCotizador = this.cotizador.datosCotizador;
    var n = 0;
    if (planesvida != null) {
      for (let i = 0; i < datosCotizador.length; i++) {
        if (datosCotizador[i]['checked'] == "true") {
          for (const iterator of planesvida) {
            if (iterator.plIdPlan == datosCotizador[i]['poIdPlan']) {
              n++;
              var plIdPlan = datosCotizador[i]['poIdPlan'];
              var poIdPlanOpcion = datosCotizador[i]['poIdPlanOpcion'];
              var idAsegurado = datosCotizador[i]['id'];
              if (plIdPlan != this.idsegmentarplan) {
                await this.Consentimiento(plIdPlan, poIdPlanOpcion, n, idAsegurado, this.solicitudes);
              } else {
                if (idAsegurado === this.identity.id) {
                  await this.Consentimiento(plIdPlan, poIdPlanOpcion, n, idAsegurado, this.solicitudes);
                }
              }
            }
          }
        }
        if (i == (datosCotizador.length - 1)) {
          this.prueba();
        }
      }
    } else {
      this.prueba();
    }
  }

  prueba() {
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.api + "merge/pdf",
      "method": "POST",
      "headers": {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      "data": {
        "idCorporativo": this.identity.idCorporativo,
        "idEmpresa": this.identity.idEmpresa,
        "idEmpleado": this.identity.id,
        "idSolicitud": this.solicitudes,
        "file": this.nombreSolicitud,
        "anexos": this.anexos,
        "consentimeinto": this.consentimeinto,
        "numeroEmpleado": this.identity.numEmpleado
      }
    }

    $.ajax(settings).done((response) => {
      this.habilitarSelecciones = "enabled";
      if (response.uri) {
        this.pathFileSS = response.uri + "/" + response.file;
        this.solicitud = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(response.uri) + '%2F' + encodeURIComponent(response.file);
      } else {
        this.solicitud = this.urlSolicitudEspera;
      }
      this.ocultarSolicitud = false;
    }).fail((error) => {
      this.solicitud = this.urlSolicitudEspera;
      this.ocultarSolicitud = false;
      swal({
        title: '¡Error de conexión! 23',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.habilitarSelecciones = "enabled";
    });
  }

  async correo(nombreArchivo?: any) {
    if (this.parametro119 == 1)
      try {
        const response: any = await this._BuscarPlanesv2.getCorreosNotificacion(this.identity, this.token)
        this.correosAdministradores = response['tblAdministradores'];
        this.to = this.datosTitular.emcorreoElectronico;
        if (this.to == null) {
          for (let i = 0; i < this.correosAdministradores.length; i++) {
            const correoCopiaTo = this.correosAdministradores[i]['gcCorreoCopia'];
            this.to += correoCopiaTo + ",";
          }
        }
        if (this.to != null) {
          var date = new Date(),  // 2009-11-10
            locale = "es-us",
            month = date.toLocaleString(locale, {
              month: "long"
            });
          var today_date = date.getDate().toString() + '/' + month + '/' + date.getFullYear().toString();
          let nombreCompleto = this.datosTitular.EMNombre1 + " " + this.datosTitular.EMNombre2 + " " + this.datosTitular.EMApellidoPaterno + " " + this.datosTitular.EMApellidoMaterno;
          nombreCompleto = nombreCompleto.replace("NULL", '');
          nombreCompleto = nombreCompleto.replace("null", '');
          nombreCompleto = nombreCompleto.replace("Null", '');

          this.plantilla = response['plantillaCorreo'][0]['contenido'];
          this.plantilla = this.plantilla.replace("#Titular", nombreCompleto);

          this.plantilla = this.plantilla.replace("#FechaSolicitud", today_date);

          this.sujeto = response['plantillaCorreo'][0]['sujeto'];

          this.sujeto = this.sujeto.replace("#NombreEmpresa", this.identity.nomEmpresa);
          if (this.correosAdministradores)
            for (let i = 0; i < this.correosAdministradores.length; i++) {
              const correoCopia = this.correosAdministradores[i]['gcCorreoCopia'];
              const correoCopiaOculta = this.correosAdministradores[i]['gcCorreoCopiaOculta'];
              const adcorreos = this.correosAdministradores[i]['adCorreoElectronico'];

              if (this.to != null) {
                if (correoCopia == true) {
                  this.cc += this.correosAdministradores[i]['adCorreoElectronico'].toString() + ","
                }
                if (correoCopiaOculta == true) {
                  this.bcc += adcorreos + ","
                }
              } else {
                if (correoCopia == true) {
                  this.to += 'tvillegas@mx.lockton.com' + ",";
                }
              }
            }
          var rutaSol;
          if (nombreArchivo) {
            rutaSol = nombreArchivo;
          } else {
            rutaSol = this.solicitud;
          }

          var settings = {
            "async": true,
            "url": rutaSol,
            "method": "GET",
            "headers": {
              "Cache-Control": "no-cache"
            }
            , xhrFields: {
              responseType: 'blob'
            }
            , contentType: "application/pdf"
          }

          $.ajax(settings).done((data2) => {
            console.log('datos listos');
            this.mandarCorreo(data2);
          }).fail((error2) => {
            console.log('error insertando solicitud');
            console.log(error2);
            var errorMessage = <any>error2;
          });
        }
      } catch (error) {

      }
  }

  async mandarCorreo(archivo: any) {
    var file = new File([archivo], "solicitud.pdf");
    var form = new FormData();
    form.append("file", file);
    try {
      await this._empleadoService.sendMailUnificado(this.to, this.cc, this.bcc, this.sujeto, this.plantilla.toString(), '', form, this.pathFileSS, '', 13, this.token);
    } catch (error) { }
  }

  convertirXmlToJson(xmlResponse): string {
    let parseString = require('xml2js').parseString;
    let xmlIn = xmlResponse;
    let auxAnexoSolicitudNodoPadre: any[] = [];
    let auxAnexoSolicitudHijo: any[] = [];
    let auxPlanSeleccionNodoPadre: any[] = [];
    let auxPlanSeleccionHijo: any[] = [];
    let auxPlantilla: string;
    let objXMLtoString = {
      'paser': []
    };


    parseString(xmlIn, (err, result) => {
      auxAnexoSolicitudNodoPadre = result['List']['item'][0]['anexoSolicitud'];
      var cadena = [];
      for (let i = 0; i < auxAnexoSolicitudNodoPadre.length; i++) {
        const a = auxAnexoSolicitudNodoPadre[i];
        for (let j = 0; j < a.anexoSolicitud.length; j++) {
          const b = a.anexoSolicitud[j];
          cadena.push(b.descripcion[i] + " - " + b.cobertura[i] + " - " + b.plOrden + " - " + b.poOrden);
        }
      }
      cadena.sort();

      var n = "";
      var ante = "";
      var separador = "-";
      var Descripcion = "";
      var cadenaFinal = [];
      var cadenaFinal2 = [];

      for (let i = 0; i < cadena.length; i++) {
        const b = cadena[i];
        Descripcion = b.split(separador);
        n = Descripcion[0] + Descripcion[1];
        if (n != ante) {
          // // // // console.log(Descripcion);
          cadenaFinal2.push({ descripcion: Descripcion[0], cobertura: Descripcion[1], plOrden: Descripcion[2], poOrden: Descripcion[3] });
          // cadenaFinal.push(b); 
        }
        ante = n
      }
      var prueba = { anexoSolicitud: cadenaFinal2 };
      auxPlanSeleccionNodoPadre = result['List']['item'][0]['planSeleccion']

      for (let index = 0; index < auxAnexoSolicitudNodoPadre.length; index++) {
        let element: any[] = auxAnexoSolicitudNodoPadre[index]; //Elementos posibles del Nodo Padre
        auxAnexoSolicitudHijo = Object.values(element)
        for (var i = 0; i < auxAnexoSolicitudHijo.length; i++) {
          this.auxAnexoSolicitud.anexoSolicitud = this.removerDuplicados(auxAnexoSolicitudHijo[i], 'cobertura')
        }
      }

      for (let index = 0; index < auxPlanSeleccionNodoPadre.length; index++) {
        let element: any[] = auxPlanSeleccionNodoPadre[index]; //Elementos posibles del Nodo Padre
        auxPlanSeleccionHijo = Object.values(element)
        for (var i = 0; i < auxPlanSeleccionHijo.length; i++) {
          this.auxPlanSeleccion.planSeleccion = this.removerDuplicados(auxPlanSeleccionHijo[i], 'cobertura')
        }
      }
      result['List']['item'][0]['anexoSolicitud'] = [prueba];
      var xml2js = require('xml2js');
      var builder = new xml2js.Builder();
      var xml = builder.buildObject(result)
      objXMLtoString.paser[0] = xml;
      auxPlantilla = objXMLtoString.paser[0].toString();
      let xmlReplaceString = auxPlantilla.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "")
      return auxPlantilla;
    });
    return auxPlantilla;
  }

  removerDuplicados(originalArray, propiedad) {
    var newArray = [];
    var lookupObject = {};

    for (var i in originalArray) {
      lookupObject[originalArray[i][propiedad]] = originalArray[i];
    }

    for (i in lookupObject) {
      newArray.push(lookupObject[i]);
    }
    return newArray;
  }
  butactive(el) {
    console.log("Entro al butactive");
    const m: HTMLElement = $('.btn-general-color').css("backgroundColor")
    el.target.parentElement.querySelectorAll(".btn-general-color").forEach(e => {
      e.style.backgroundColor = '#eee';
      e.classList.remove("btn-general-color");
    });

    el.target.style.backgroundColor = m;
    el.target.classList.add("btn-general-color");
  }


  getColor() {
    setTimeout(() => {
      const m: HTMLElement = $('.btn-general-color').css("backgroundColor")
      const styleElem = document.head.appendChild(document.createElement("style"));
      styleElem.innerHTML = `.nav-tabs .nav-link.btn-general-color::after {
          content: '';
          width: 0;
          height: 0;
          position: absolute;
          top: 0%;
          right: 0;
          z-index: 5;
          transform: translateX(100%);
          border: 14px solid ${m};
          border-bottom-color: transparent;
          border-top-color: transparent;
          border-right-color: transparent;
      }`;
      const c: HTMLElement = $('.btn-general-color').css("color")
      Array.from(document.querySelectorAll('#tabs .nav-tabs .nav-link.active')).forEach((e: any) => {
        e.style.backgroundColor = m
        e.classList.add('btn-general-color')
      });
    }, 100);
  }

  redirigir() {
    if (this.opcionRedirigir == 1) {
      this._router.navigate(['pages/home']);
    }
  }

  async limpiarAnexos() {
    var settings = {
      "async": true,
      "crossDomain": true,
      "url": this.api + "limpiar/anexos",
      "method": "POST",
      "headers": {
        "Content-Type": "application/x-www-form-urlencoded",
        "token": this.token
      },
      "data": {
        "idCorporativo": this.identity.idCorporativo,
        "idEmpresa": this.identity.idEmpresa,
        "idEmpleado": this.identity.id,
        "numeroEmpleado": this.identity.numEmpleado
      }
    }

    await $.ajax(settings).done((response) => { });
  }

  guardarPlanesSeleccionados() {
    this.comprobarSesion();
    this.habilitarSelecciones = "disabled";
    this.mostrarAlert();
    const datosCotizador = this.cotizador.datosCotizador;
    var planesSeleccionados = "<ROOT>";
    const id = this.identity.id;
    for (let i = 0; i < datosCotizador.length; i++) {
      if (datosCotizador[i]['checked'] == "true") {
        const cantidad = this.cotizadorv3.declaraciones['cantidadPago'];
        const idTC = datosCotizador[i]['tcIdTarifaCosto'];
        const idempleado = datosCotizador[i]['id'];
        var PT = datosCotizador[i]['tcPrimaTotal'];
        PT = parseFloat(PT).toFixed(4)
        planesSeleccionados += "<TarifaCosto TCidTarifaCosto=\"" + idTC + "\" Costo=\"" + PT + "\" idEmpleado=\"" + idempleado + "\"></TarifaCosto>";
      }
    }
    planesSeleccionados += "</ROOT>";
    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });

    this._http.post(this.urlWs + "planesPerfil/v2/tmp",
      {
        "idEmpleado": this.cotizadorv3.declaraciones['idEmpleado'],
        "idEmpresa": this.cotizadorv3.declaraciones['idEmpresa'],
        "xmlPlanesSeleccionados": planesSeleccionados,
        "cantidadPago": this.cotizadorv3.declaraciones['cantidadPago'],
        "idConfiguracion": this.cotizadorv3.declaraciones['idConfiguracion'],
        "idPerfil": this.cotizadorv3.declaraciones['idPerfil'],
        "idPeriodicidadPago": this.cotizadorv3.datosIniciales['idPeriocidadPago'],
        "idVigencia": this.cotizadorv3.declaraciones['idVigencia'],
        "numeroEmpleado": this.cotizadorv3.declaraciones['numeroEmpleado'],
        "periodicidadNombre": this.cotizadorv3.declaraciones['peridicidadNombre']
      }, { headers: getHeaders })
      .subscribe(
        response => {
          this.habilitarSelecciones = "enabled";
          swal({
            title: '¡Guardado correctamente!',
            type: 'success',
            confirmButtonText: 'Aceptar',
          });
        }, error => {
          var errorMessage = <any>error;
          swal({
            title: '¡Error de conexión! 24',
            html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
            type: 'error',
            confirmButtonText: 'Aceptar',
          });
          this.habilitarSelecciones == 'enabled';
        }
      )
  }

  guardarSeleccionadosPDF2(opcion: Number) {

    this.comprobarSesion();
    localStorage.removeItem('validando2');
    if (opcion == 2) {
      this.opcionRedirigir = 1;
    }

    this.solicitud = null;
    this.mensajesSolicitud = "Conectando...";
    localStorage.removeItem('cierreBeneficiarios');
    this.solicitudCreada = false;

    const datosCotizador = this.cotizador.datosCotizador;
    var planesSeleccionados = "<ROOT>";
    for (let i = 0; i < datosCotizador.length; i++) {
      if (datosCotizador[i]['checked'] == "true") {
        const cantidad = this.cotizadorv3.declaraciones['cantidadPago'];
        const idTC = datosCotizador[i]['tcIdTarifaCosto'];
        var PT = datosCotizador[i]['tcPrimaTotal'];
        PT = parseFloat(PT).toFixed(4)
        const id = datosCotizador[i]['id'];
        planesSeleccionados += "<TarifaCosto TCidTarifaCosto=\"" + idTC + "\" Costo=\"" + PT + "\" idEmpleado=\"" + id + "\"></TarifaCosto>";
      }
    }
    planesSeleccionados += "</ROOT>";

    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    if (opcion == 2) {
      if (this.parametro126 == 1) {
        this.ocultarSolicitud = true
      }
    } else {
      this.ocultarSolicitud = false;
    }
    let urlInsertarPlanesTmp = null;
    urlInsertarPlanesTmp = this.urlWs + "planesPerfil/v2/tmp/" + this.idMultivigencia;
    this._http.post(urlInsertarPlanesTmp,
      {
        "idEmpleado": this.cotizadorv3.declaraciones['idEmpleado'],
        "idEmpresa": this.cotizadorv3.declaraciones['idEmpresa'],
        "xmlPlanesSeleccionados": planesSeleccionados,
        "cantidadPago": this.cotizadorv3.declaraciones['cantidadPago'],
        "idConfiguracion": this.cotizadorv3.declaraciones['idConfiguracion'],
        "idPerfil": this.cotizadorv3.declaraciones['idPerfil'],
        "idPeriodicidadPago": this.cotizadorv3.datosIniciales['idPeriocidadPago'],
        "idVigencia": this.cotizadorv3.declaraciones['idVigencia'],
        "numeroEmpleado": this.cotizadorv3.declaraciones['numeroEmpleado'],
        "periodicidadNombre": this.cotizadorv3.declaraciones['peridicidadNombre']
      }, { headers: getHeaders })
      .subscribe(
        response => {
          this.mensajesSolicitud = "Conectado..."
          if (opcion == 2)
            this.limpiarAnexos();
          var parmams =
          {
            "idEmpleado": this.cotizadorv3.declaraciones['idEmpleado'],
            "idEmpresa": this.cotizadorv3.declaraciones['idEmpresa'],
            "cantidadPago": this.cotizadorv3.declaraciones['cantidadPago'],
            "idConfiguracion": this.cotizadorv3.declaraciones['idConfiguracion'],
            "idEstatusVigencia": this.cotizadorv3.declaraciones['idEstatusVigencia'],
            "idPerfil": this.cotizadorv3.declaraciones['idPerfil'],
            "idVigencia": this.cotizadorv3.declaraciones['idVigencia'],
            "numeroEmpleado": this.cotizadorv3.declaraciones['numeroEmpleado']
          };
          var parmamsString = JSON.stringify(parmams);
          this.paramsSolicitud4 = parmamsString;
          if (opcion == 2) {
            if (this.parametro126 == 1) {
              this.solicitudCreada = true;
              this.ocultarSolicitud = true;
              localStorage.setItem('cierreBeneficiarios', '1');

            } else {
              this.createSolicitud(this.paramsSolicitud4, opcion);
            }
          } else {
            var settings = {
              "async": true,
              "crossDomain": true,
              "url": this.urlWs + "solicitud/previewV2/b3/xml",
              "method": "POST",
              "headers": {
                "Content-Type": "application/json",
                "cache-control": "no-cache"
              },
              "processData": false,
              "data": parmamsString,
              "dataType": "text"
            }

            $.ajax(settings).done(async (response) => {

              if (opcion == 2) {
                response = response.replace("</item>", "<preview>false</preview></item>");
              } else if (opcion == 1) {
                response = response.replace("</item>", "<preview>true</preview></item>");
              }

              //Adaptacion para mostrar o quitar firmas
              if (this.quitarFirmas) {
                response = response.replace("</item>", "<firmas>true</firmas></item>");
              } else {
                response = response.replace("</item>", "<firmas>false</firmas></item>");
              }

              if (this.quitarSeleccionesAnteriores) {
                response = response.replace("</item>", "<seleccionesanteriores>true</seleccionesanteriores></item>");
              } else {
                response = response.replace("</item>", "<seleccionesanteriores>false</seleccionesanteriores></item>");
              }

              if (this.prefijoSolicitud.emPrefijoSolicitud == 5) {
                if (this.quitarResumenDescuento) {
                  response = response.replace("</item>", "<descuentos>true</descuentos></item>");
                } else {
                  response = response.replace("</item>", "<descuentos>false</descuentos></item>");
                }
              }

              response = String(response);
              var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "");
              var d = new Date();
              var n = d.toLocaleTimeString();
              var hhmmss = n.slice(0, new Date().toISOString().indexOf("Z")).replace(/:/g, "");
              var rutaPDF = {
                'ruta': "preview/" + this.identity.idEmpresa + "/Solicitud",
                //'archivo': "" + this.identity.id + "_" + YYYYMMDD + hhmmss + ".pdf"
                'archivo': "" + this.identity.id + ".pdf"
              }
              this.nombreSolicitud = rutaPDF.archivo;

              try {
                await this._BuscarPlanesv2.convertirPdf(rutaPDF, String(response), this.token, this.prefijoSolicitud.emPrefijoSolicitud);
                this.habilitarSelecciones = "enabled";
                localStorage.setItem('validando2', 'true');
                this.mensajesSolicitud = null;
                this.solicitudCreada = true;
                this.urlSolicitudEspera = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
                this.solicitud = this.urlSolicitudEspera;
              } catch (error) {
                var errorMessage = <any>error;
                swal({
                  title: '¡Error de conexión! 25',
                  html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
                  type: 'error',
                  confirmButtonText: 'Aceptar',
                });
                this.habilitarSelecciones = "enabled";
              }
            }).fail((error) => {
              var errorMessage = <any>error;
            });
          }
        }, error => {
          var errorMessage = <any>error;
          this.habilitarSelecciones = "enabled";
          swal({
            title: '¡Error de conexión! 26',
            html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
            type: 'error',
            confirmButtonText: 'Aceptar',
          });
          localStorage.setItem('validando2', 'true');
        }
      )
  }

  createSolicitud(parmamsString: String, opcion: any) {
    console.log("A7");
    if (opcion == 2) {
      if (this.parametro126 == 1) {
      }
      this.ocultarSolicitud = true
    } else {
      this.ocultarSolicitud = false;
    }
    this._BuscarPlanesv2.crearSolicitudEmpleadoDefaulteo(this.identity.id, this.idMultivigenciaActual).subscribe(async response2 => {
      this.cerrarModal = false;
      this.getSolicitud();
      var settings = {
        "async": true,
        "crossDomain": true,
        "url": this.urlWs + "documento/solicitud/empleado/" + this.identity.id,
        "method": "GET",
        "headers": {
          "cache-control": "no-cache"
        }
      }
      $.ajax(settings).done((response) => {
        if (response) {
          this.anexos = true;
        }
      });
      this.parametrosAseguradoT.idCorporativo = this.identity.idCorporativo;
      this.parametrosAseguradoT.idTitular = this.identity.id;
      this.parametrosAseguradoT.numeroEmpleado = this.identity.numEmpleado;
      try {
        this.parametrosAseguradoT.idEmpresa = this.identity.idEmpresa;
        const response3: any = await this._beneficiarioService.consultarPlanesVidaV2(this.parametrosAseguradoT, this.token);
        if (response3.length == 1) {
          this.consentimeinto = false;
        }
        const bene = response3.length;
        let settings = {
          "async": true,
          "crossDomain": true,
          "url": this.urlWs + "solicitud/v2/b3/xml",
          "method": "POST",
          "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
          },
          "processData": false,
          "data": parmamsString,
          "dataType": "text"
        }

        $.ajax(settings).done(async (response) => {
          if (opcion == 2) {
            response = response.replace("</item>", "<preview>false</preview></item>");
          } else if (opcion == 1) {
            response = response.replace("</item>", "<preview>true</preview></item>");
          }

          //Adaptacion para mostrar o quitar firmas
          if (this.quitarFirmas) {
            response = response.replace("</item>", "<firmas>true</firmas></item>");
          } else {
            response = response.replace("</item>", "<firmas>false</firmas></item>");
          }

          if (this.quitarSeleccionesAnteriores) {
            response = response.replace("</item>", "<seleccionesanteriores>true</seleccionesanteriores></item>");
          } else {
            response = response.replace("</item>", "<seleccionesanteriores>false</seleccionesanteriores></item>");
          }
          if (this.prefijoSolicitud.emPrefijoSolicitud == 5) {
            if (this.quitarResumenDescuento) {
              response = response.replace("</item>", "<descuentos>true</descuentos></item>");
            } else {
              response = response.replace("</item>", "<descuentos>false</descuentos></item>");
            }
          }
          response = String(response);

          var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "");
          var d = new Date();
          var n = d.toLocaleTimeString();
          var hhmmss = n.slice(0, new Date().toISOString().indexOf("Z")).replace(/:/g, "");
          var rutaPDF = {
            'ruta': "DocumentoEmpresa/" + this.identity.idEmpresa + "/Solicitud",
            'archivo': "Solicitud_" + this.identity.id + "_" + YYYYMMDD + hhmmss + "_" + this.solicitudes + ".pdf"
          }
          this.nombreSolicitud = rutaPDF.archivo;

          try {
            await this._BuscarPlanesv2.convertirPdf(rutaPDF, String(response), this.token, this.prefijoSolicitud.emPrefijoSolicitud);
            localStorage.setItem('validando2', 'true');
            this.mensajesSolicitud = null;
            if (this.parametro126 != 1) {
              var solicitud = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
              this.solicitud = solicitud;
              this.validacionSolicitud = this.solicitudExistente2();
              this.habilitarSelecciones = "enabled";
            } else {
              this.validacionSolicitud = this.solicitudExistente2();
              const datosCotizador = this.cotizador.datosCotizador;
              for (let i1 = 0; i1 < this.tsrifasAceptadas.idtarifacosto.length; i1++) {
                const element = this.tsrifasAceptadas.idtarifacosto[i1];
                for (let i = 0; i < datosCotizador.length; i++) {
                  if (datosCotizador[i]['checked'] == "true" && datosCotizador[i]['tcIdTarifaCosto'] == element && datosCotizador[i]['idParentesco'] == 1) {
                    this.planNombreOpcion = datosCotizador[i]['poNombre'];
                    this.planidTarifaCosto = datosCotizador[i]['tcIdTarifaCosto'];
                    var poIdPlanOpcion = datosCotizador[i]['poIdPlanOpcion'];
                    var settings = {
                      "async": true,
                      "crossDomain": true,
                      "url": this.urlWs + "excedentes/empleado/" + this.identity.id,
                      "method": "POST",
                      "headers": {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "cache-control": "no-cache",
                      },
                      "processData": false,
                      "data": "{\r\n  \"idEmpresa\": " + this.identity.idEmpresa + ",\r\n  \"idPlanOpcion\": " + poIdPlanOpcion + ",\r\n  \"idSolicitud\": " + this.solicitudes + ",\r\n  \"idTarifaCosto\": " + this.planidTarifaCosto + ",\r\n  \"idVigencia\": " + this.cotizadorv3.declaraciones['idVigencia'] + ",\r\n  \"sami\": " + this.diferenciaCostos2 + ",\r\n  \"sumaAsegurada\": " + this.SAAdicional2 + "\r\n}"
                    }
                    $.ajax(settings).done((response) => {
                      this.correosExcedentes();
                    }).fail((error) => { });
                  }
                }
              }
              this.solicitudCreada = true;
              this.urlSolicitudEspera = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
              this.recorrerAnexos();
            }
          } catch (error) {
            swal({
              title: '¡Error de conexión! 27',
              html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
              type: 'error',
              confirmButtonText: 'Aceptar',
            });
            this.habilitarSelecciones = "enabled";
          }
        });
      } catch (error) {
        this.solicitudCreadaDefaulteo.emit({ solicitudCreada: false, numEmpleado: this.identity.numEmpleado });
      }
    }, error => {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 28 ',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.habilitarSelecciones = "enabled";
      localStorage.setItem('validando2', 'true');
    }
    );
  }
  getIdPlan(idPlan: any) {
    this.planSeleccionadoId = idPlan;
    this.planSeleccionadoId2 = idPlan;
  }

  validarOpcionSamiSolicitud(opcion: Number) {
    this.verificacionSami2(opcion);
  }
  verificacionSami2(opcion: Number) {
    let sumaAsegurada;
    let excedente;
    let poValorSumaAseguradaTotal = {
      sumaAsegurada: []
    }
    this.planSeleccionadoId = null;

    var plSami = this.planSamiVerificar;
    if (plSami)
      plSami.map((val) => {
        poValorSumaAseguradaTotal.sumaAsegurada.push(
          this.obtenerSumaAsegurada(val.emSalarioBase, val.poValorSumaAsegurada, val.tcPrimaTotal)
        )
      });
    for (let index = 0; index < plSami.length; index++) {
      const costoSami = plSami[index]['plSami'];
      const resultados = poValorSumaAseguradaTotal.sumaAsegurada[index];
      if (plSami[index]['poIdPlan'] == '1151') {
        if (costoSami < resultados) {
          var diferencia = resultados - costoSami;
          const datosCotizador = this.cotizador.datosCotizador;
          var primatotal;
          for (let i = 0; i < datosCotizador.length; i++) {
            if (datosCotizador[i]['checked'] == "true" && datosCotizador[i]['tcIdTarifaCosto'] == plSami[index]['tcIdTarifaCosto']) {
              this.planNombreOpcion = datosCotizador[i]['poNombre'];
              this.planidTarifaCosto = datosCotizador[i]['tcIdTarifaCosto'];
              primatotal = plSami[index]['tcPrimaNeta'];
            }
          }
          this.planSami = this.redondear(costoSami);
          this.SAAdicional = this.redondear(diferencia);
          this.planSami2 = (costoSami);
          this.diferenciaCostos = this.redondear(this.obtenerDiferenciaCosto(diferencia, primatotal));
          this.diferenciaCostos2 = (this.obtenerDiferenciaCosto(diferencia, primatotal));

          this.SAAdicional2 = diferencia;
          var busca = this.tsrifasAceptadas.idtarifacosto.indexOf(this.planidTarifaCosto);
          var buscaRechaza = this.tsrifasRechazadas.idtarifacosto.indexOf(this.planidTarifaCosto);
          if (busca == -1 && buscaRechaza == -1) {
            this.displayEscedentes = 'block';
            this.validacionSA = false;
          } else {
            this.validacionSA = true;
            this.guardarSeleccionadosPDF2(opcion);
          }
        } else {
          this.validacionSA = true;
          this.guardarSeleccionadosPDF2(opcion);
        }
      }
    }
  }

  mensajeSami(planidTarifaCosto: any) {
    this.tsrifasAceptadas = {
      'idtarifacosto': [],
      'planSami': [],
      'SAAdicional': []
    }
    this.tsrifasRechazadas = {
      'idtarifacosto': []
    }
    this.tsrifasRechazadas.idtarifacosto.push(planidTarifaCosto);
    // // console.log(this.tsrifasRechazadas);

    swal({
      // title: '¡Error!',
      title: '<small style="color: grey; text-align: justify;">Tu suma asegurada autorizada es de $15,300,000.00</small>',
      type: 'info',
      confirmButtonText: 'Aceptar',
    });
    this.displayEscedentes = 'none';
  }

  async correosExcedentes() {
    try {
      const response = await this._BuscarPlanesv2.getCorreosGrupoSolicitud(this.identity.idEmpresa, this.token);
      this.correosAdministradores = response;
      if (this.acepto.opcion) {
        try {
          const response = await this._BuscarPlanesv2.getPlantillaConfirmacion(this.token);
          this.plantilla2 = response[0]['plantilla'];
          this.plantilla2 = this.plantilla2.replace("#Empleado", this.identity.numEmpleado);
          this.sujeto2 = response[0]['sujeto'];
          this.sujeto2 = this.sujeto2.replace("#Nombre", this.identity.nomEmpresa);
          if (this.correosAdministradores)
            for (let i = 0; i < this.correosAdministradores.length; i++) {
              const correoCopia = response[i]['gcCorreoCopia'];
              const correoCopiaOculta = response[i]['gcCorreoCopiaOculta'];
              const adcorreos = response[i]['adCorreoElectronico'];
              if (this.to2 != "") {
                if (correoCopia == true) {
                  this.cc2 += response[i]['adCorreoElectronico'].toString() + ","
                }
                if (correoCopiaOculta == true) {
                  this.bcc2 += adcorreos + ","
                }
              } else {
                this.to2 = " ";
                if (correoCopia == true) {
                  this.to2 += 'tvillegas@mx.lockton.com' + ","
                }
              }
            }
          try {
            await this._empleadoService.sendMailUnificado(this.to2, this.cc2, this.bcc2, this.sujeto2, this.plantilla2.toString(), '', '', '', '', 8, this.token)
          } catch (error) { }
        } catch (error) { }
      } else {
        try {
          await this._BuscarPlanesv2.getPlantillaRechazo(this.token);
          this.plantilla2 = response[0]['plantilla'];
          this.plantilla2 = this.plantilla2.replace("#Empleado", this.identity.numEmpleado);
          this.sujeto2 = response[0]['sujeto'];
          this.sujeto2 = this.sujeto2.replace("#Nombre", this.identity.nomEmpresa);
          if (this.correosAdministradores)
            for (let i = 0; i < this.correosAdministradores.length; i++) {
              const correoCopia = response[i]['gcCorreoCopia'];
              const correoCopiaOculta = response[i]['gcCorreoCopiaOculta'];
              const adcorreos = response[i]['adCorreoElectronico'];
              if (this.to2 != "") {
                if (correoCopia == true) {
                  this.cc2 += response[i]['adCorreoElectronico'].toString() + ","
                }
                if (correoCopiaOculta == true) {
                  this.bcc2 += adcorreos + ","
                }
              } else {
                this.to2 = " ";
                if (correoCopia == true) {
                  this.to2 += 'tvillegas@mx.lockton.com' + ","
                }
              }
            }
          try {
            await this._empleadoService.sendMailUnificado(this.to2, this.cc2, this.bcc2, this.sujeto2, this.plantilla2.toString(), '', '', '', '', 8, this.token);
          } catch (error) { }
        } catch (error) { }
      }
    } catch (error) { }
  }

  pruebasM() {
    this.acepto;
  }

  comprobarTextoMonto(texto: String) {
    if (texto == "" || texto == null || texto == undefined) {
      return texto = 'Costo: '
    } else {
      return texto
    }
  }

  validaControl(checked: any, visible: any, enabled: any) {
    if (checked == 'false' && visible == 'true' && enabled == 'false') {
      return false;
    } else {
      return true;
    }
  }

  async crearSolicitud() {
    this.colorModal = '#FFFFFF';
    this._BuscarPlanesv2.crearSolicitudEmpleadoDefaulteo(this.identity.id, this.idMultivigenciaActual).subscribe(async response2 => {
      this.cerrarModal = false;
      this.parametrosAseguradoT.idCorporativo = this.identity.idCorporativo;
      this.parametrosAseguradoT.idTitular = this.identity.id;
      this.parametrosAseguradoT.numeroEmpleado = this.identity.numEmpleado;
      this.parametrosAseguradoT.idEmpresa = this.identity.idEmpresa;
      this.getSolicitud();

      try {
        const response3: any = await this._beneficiarioService.consultarPlanesVidaV2(this.parametrosAseguradoT, this.token)
        if (response3.length == 1) {
          this.consentimeinto = false;
        }
        let settings = {
          "async": true,
          "crossDomain": true,
          "url": this.urlWs + "documento/solicitud/empleado/" + this.identity.id,
          "method": "GET",
          "headers": {
            "cache-control": "no-cache"
          }
        }
        $.ajax(settings).done((response) => {
          if (response) {
            this.anexos = true;
          }
          this.crearXMLFinal(2, response3.length);
        }).fail((error) => {
          var errorMessage = <any>error;
          this.crearXMLFinal(2, response3.length);
        });

      } catch (error) { }
    }, error => {
      var errorMessage = <any>error;
      swal({
        title: '¡Error de conexión! 29 ',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.habilitarSelecciones = "enabled";
      localStorage.setItem('validando2', 'true');
    }
    );
  }

  async crearXMLFinal(opcion: Number, bene: Number) {
    this.comprobarSesion();
    console.log('creando XMLFinal');
    this.mensajesSolicitud = "Creando documento...";
    try {
      let response: any = await this._BuscarPlanesv2.getXmlSolicitud(this.identity.id, this.token, opcion)

      response = response.replace("</item>", "<preview>false</preview></item>");
      if (this.quitarFirmas) {
        response = response.replace("</item>", "<firmas>true</firmas></item>");
      } else {
        response = response.replace("</item>", "<firmas>false</firmas></item>");
      }
      if (this.quitarSeleccionesAnteriores) {
        response = response.replace("</item>", "<seleccionesanteriores>true</seleccionesanteriores></item>");
      } else {
        response = response.replace("</item>", "<seleccionesanteriores>false</seleccionesanteriores></item>");
      }
      if (this.prefijoSolicitud.emPrefijoSolicitud == 5) {
        if (this.quitarResumenDescuento) {
          response = response.replace("</item>", "<descuentos>true</descuentos></item>");
        } else {
          response = response.replace("</item>", "<descuentos>false</descuentos></item>");
        }
      }
      var YYYYMMDD = new Date().toISOString().slice(0, new Date().toISOString().indexOf("T")).replace(/-/g, "")
      var d = new Date();
      var n = d.toLocaleTimeString();
      var hhmmss = n.slice(0, new Date().toISOString().indexOf("Z")).replace(/:/g, "");
      var rutaPDF = {
        'ruta': "DocumentoEmpresa/" + this.identity.idEmpresa + "/Solicitud",
        'archivo': "Solicitud_" + this.identity.id + "_" + YYYYMMDD + hhmmss + "_" + this.solicitudes + ".pdf"
      }
      this.nombreSolicitud = rutaPDF.archivo;
      try {
        await this._BuscarPlanesv2.convertirPdf(rutaPDF, String(response), this.token, this.prefijoSolicitud.emPrefijoSolicitud)
        localStorage.setItem('validando2', 'true');
        console.log('convirtiendo xml');
        this.mensajesSolicitud = null;
        if (this.parametro126 != 1) {
          if (this.anexos == false) {
            var solicitud = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
            this.solicitud = solicitud;
            if (opcion == 2) {
              this.validacionSolicitud = this.solicitudExistente2();
            }
            this.habilitarSelecciones = "enabled";
          } else {
            this.prueba();
          }
        } else {
          if (opcion == 2) {
            this.validacionSolicitud = this.solicitudExistente2();
          }
          this.getSolicitud();
          this.solicitudCreada = true;
          this.urlSolicitudEspera = this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta) + '%2F' + encodeURIComponent(rutaPDF.archivo);
          this.recorrerAnexos();
        }
        if (this.parametro119 == 1 && opcion == 2) {
          this.correo(this.urlWs + 'solicitud/get-pdf?ruta=' + encodeURIComponent(rutaPDF.ruta + '/' + rutaPDF.archivo));
        }
      } catch (error) {
        swal({
          title: '¡Error de conexión!30 ',
          html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.habilitarSelecciones = "enabled";
        localStorage.setItem('validando2', 'true');
      }
    } catch (error) {
      swal({
        title: '¡Error de conexión! 31',
        html: '<small style="color: grey; text-align: justify;">Intenta nuevamente más tarde.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });
      this.habilitarSelecciones = "enabled";
    }
  }

  activarX() {
    this.cerrarModal = true;
  }
}