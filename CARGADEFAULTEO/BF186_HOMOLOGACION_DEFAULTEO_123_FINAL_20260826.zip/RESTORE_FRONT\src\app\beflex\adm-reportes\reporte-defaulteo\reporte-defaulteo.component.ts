import { Component, OnInit } from '@angular/core';
import { MenusService } from 'src/app/services/menus.service';
import { GLOBAL } from "../../../services/global";
import { EmpleadoService } from "../../../services/empleado.service";

@Component({
  selector: 'app-reporte-defaulteo',
  templateUrl: './reporte-defaulteo.component.html',
  styleUrls: ['./reporte-defaulteo.component.css']
})
export class ReporteDefaulteoComponent implements OnInit {

  public title: string;
  public banner;
  public urlWs;
  public identity;

  // ================= Modal variables Ayuda ================= //
  public id;
  public iconoAyuda;
  public textAyuda;

  constructor(
    private _menuService: MenusService,
    private _empleadoService: EmpleadoService
  ) {
    this.title = 'Reporte defaulteo';
    this.urlWs = GLOBAL.url2;
  }

  ngOnInit() {
    this.banner = this._menuService.getbackground();
    this.identity = this._empleadoService.getIdentity();
    this.menuId();
  }

  menuId() {
    let informacion = JSON.parse(localStorage.getItem("MenuPadre"));
    if (informacion != "undefined") {
      this.id = informacion;
    } else {
      this.id = null;
    }
  }

}







