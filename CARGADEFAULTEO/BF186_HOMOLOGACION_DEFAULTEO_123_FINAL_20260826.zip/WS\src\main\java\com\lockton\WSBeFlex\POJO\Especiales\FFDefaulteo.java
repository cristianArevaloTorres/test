package com.lockton.WSBeFlex.POJO.Especiales;

public class FFDefaulteo {

	public int[] idEmpleado;
	public String[] numEmpleado;
	public int []idEmpresa;
	public int idVigencia;
	public int idVigenciaAnterior;
	public String tipoDefaulteo;
	public String tmpplanesseleccionados;
	public String tmpplanesseleccionadosold;
	int idAdmin;
	int idVigenciaVigente;

	public FFDefaulteo() {
		super();
	}

	public FFDefaulteo(int []idEmpleado, int []idEmpresa,String tipoDefaulteo,String tmpplanesseleccionados, String tmpplanesseleccionadosold,String [] numEmpleado,int idAdmin,int idVigenciaVigente){
		super();
		this.idEmpleado = idEmpleado;
		this.idEmpresa = idEmpresa;
		this.tipoDefaulteo = tipoDefaulteo;
		this.tmpplanesseleccionados = tmpplanesseleccionados;
		this.tmpplanesseleccionadosold = tmpplanesseleccionadosold;
		this.numEmpleado = numEmpleado;
		this.idAdmin = idAdmin;
		this.idVigenciaVigente = idVigenciaVigente;
	}

	public int[] getIdEmpleado() {
		return this.idEmpleado;
	}

	public void setIdEmpleado(int []idEmpleado) {
		this.idEmpleado = idEmpleado;
	}

	public int[] getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(int[] idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	public int getIdVigencia() {
		return idVigencia;
	}

	public void setIdVigencia(int idVigencia) {
		this.idVigencia = idVigencia;
	}

	public String getTipoDefaulteo() {
		return tipoDefaulteo;
	}

	public void setTipoDefaulteo(String tipoDefaulteo) {
		this.tipoDefaulteo = tipoDefaulteo;
	}

	public String getTmpplanesseleccionados() {
		return tmpplanesseleccionados;
	}

	public void setTmpplanesseleccionados(String tmpplanesseleccionados) {
		this.tmpplanesseleccionados = tmpplanesseleccionados;
	}


	public String getTmpplanesseleccionadosold() {
		return tmpplanesseleccionadosold;
	}

	public void setTmpplanesseleccionadosold(String tmpplanesseleccionadosold) {
		this.tmpplanesseleccionadosold = tmpplanesseleccionadosold;
	}


	public int getIdVigenciaAnterior() {
		return idVigenciaAnterior;
	}

	public void setIdVigenciaAnterior(int idVigenciaAnterior) {
		this.idVigenciaAnterior = idVigenciaAnterior;
	}

	public String[] getNumEmpleado() {
		return this.numEmpleado;
	}

	public void setNumEmpleado(String []numEmpleado) {
		this.numEmpleado = numEmpleado;
	}

	public int getIdAdmin() {
		return this.idAdmin;
	}

	public void setIdAdmin(int idAdmin) {
		this.idAdmin = idAdmin;
	}

	public int getIdVigenciaVigente() {
		return this.idVigenciaVigente;
	}

	public void setIdVigenciaVigente(int idVigenciaVigente) {
		this.idVigenciaVigente = idVigenciaVigente;
	}


}
