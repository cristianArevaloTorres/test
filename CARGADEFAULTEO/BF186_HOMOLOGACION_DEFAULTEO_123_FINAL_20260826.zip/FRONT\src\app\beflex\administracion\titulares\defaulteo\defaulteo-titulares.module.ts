import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { DefaulteoTitularesAvanzadoComponent } from './filtros-avanzados/defaulteo-titulares-avanzado.component';
import { DefaulteoTitularesHistoricoComponent } from './historico/defaulteo-titulares-historico.component';
import { TablaDefaulteoTitularesComponent } from './operacion-guiada/tabla-defaulteo-titulares.component';
import { DefaulteoTitularesComponent } from './defaulteo-titulares.component';

const routes: Routes = [
  {
    path: '',
    component: DefaulteoTitularesComponent
  }
];

@NgModule({
  declarations: [
    DefaulteoTitularesComponent,
    TablaDefaulteoTitularesComponent,
    DefaulteoTitularesAvanzadoComponent,
    DefaulteoTitularesHistoricoComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    RouterModule.forChild(routes)
  ]
})
export class DefaulteoTitularesModule { }
