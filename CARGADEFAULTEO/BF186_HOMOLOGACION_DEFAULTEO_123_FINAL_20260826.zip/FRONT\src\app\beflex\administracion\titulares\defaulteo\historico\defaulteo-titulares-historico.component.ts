import { Component, OnInit } from '@angular/core';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import swal from 'sweetalert2';
import { DefaulteoTitularesHistorico, DefaulteoTitularesHistoricoService } from 'src/app/services/defaulteo-titulares-historico.service';
import { EmpleadoService } from 'src/app/services/empleado.service';
import { EmpresaComboService } from 'src/app/services/empresas.service';

@Component({
  selector: 'app-defaulteo-titulares-historico',
  templateUrl: './defaulteo-titulares-historico.component.html',
  styleUrls: ['./defaulteo-titulares-historico.component.css']
})
export class DefaulteoTitularesHistoricoComponent implements OnInit {
  public empresas: Array<{ id: number, nombre: string }> = [];
  public idEmpresa: number = null;
  public fechaInicio = '';
  public fechaFin = '';
  public resultados: DefaulteoTitularesHistorico[] = [];
  public consultado = false;
  public cargando = false;
  public errorEmpresas = false;

  private identity: any;
  private token: string;

  constructor(
    private defaulteoHistoricoService: DefaulteoTitularesHistoricoService,
    private empleadoService: EmpleadoService,
    private empresaService: EmpresaComboService
  ) { }

  async ngOnInit() {
    this.identity = this.empleadoService.getIdentity();
    this.token = this.empleadoService.getToken();
    const hoy = new Date();
    this.fechaFin = this.formatearFecha(hoy);
    this.fechaInicio = this.formatearFecha(new Date(hoy.getFullYear(), hoy.getMonth(), 1));
    await this.cargarEmpresas();
  }

  async consultar() {
    if (!this.idEmpresa || !this.fechaInicio || !this.fechaFin) {
      swal('Atención', 'Selecciona una empresa y el rango de fechas.', 'warning');
      return;
    }
    if (this.fechaFin < this.fechaInicio) {
      swal('Atención', 'La fecha final no puede ser menor que la fecha inicial.', 'warning');
      return;
    }

    this.cargando = true;
    this.consultado = false;
    try {
      this.resultados = await this.defaulteoHistoricoService.consultar(
        this.idEmpresa, this.fechaInicio, this.fechaFin, this.token
      ) || [];
      this.consultado = true;
    } catch (error) {
      this.resultados = [];
      if (error && error.status === 401) {
        swal('Sesión expirada', 'Inicia sesión nuevamente para consultar el reporte.', 'warning');
      } else if (error && error.status === 403) {
        swal('Sin permiso', 'No tienes acceso a la empresa seleccionada.', 'warning');
      } else if (error && error.status === 400) {
        swal('Atención', 'La empresa o el rango de fechas no son válidos.', 'warning');
      } else {
        swal('Error', 'No fue posible consultar el reporte histórico de defaulteo.', 'error');
      }
    } finally {
      this.cargando = false;
    }
  }

  exportar() {
    if (!this.resultados.length) {
      return;
    }
    const filas = this.resultados.map(row => ({
      'Número empleado': row.numeroEmpleado,
      'Nombre empleado': row.nombreEmpleado,
      'Costo anual de coberturas defaulteadas': row.costoAnual,
      'Usuario': row.idUsuario,
      'Fecha default': row.fechaDefaulteo
    }));
    const hoja = XLSX.utils.json_to_sheet(filas);
    const libro = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libro, hoja, 'Defaulteados');
    const archivo = XLSX.write(libro, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([archivo], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    FileSaver.saveAs(blob, `Reporte_Defaulteo_${this.fechaInicio}_${this.fechaFin}.xlsx`);
  }

  private async cargarEmpresas() {
    this.errorEmpresas = false;
    if (!this.identity || !this.token) {
      this.errorEmpresas = true;
      return;
    }
    try {
      const response: any = await this.empresaService.getComboCambioEmpresa(
        this.identity.idCorporativo, this.identity.id, this.token
      );
      const empresas = (response || []).map(item => ({
        id: Number(item.IdEmpresa || item.emidEmpresa || item.idEmpresa),
        nombre: item.NomEmpresa || item.emclaveAcceso || item.emNombre || item.nombreEmpresa
          || `Empresa ${item.IdEmpresa || item.emidEmpresa || item.idEmpresa}`
      })).filter(item => item.id > 0);
      this.empresas = empresas.filter((item, index, lista) =>
        lista.findIndex(empresa => empresa.id === item.id) === index
      );
    } catch (error) {
      this.empresas = [];
      this.errorEmpresas = true;
    }

    const empresaSesion = Number(this.identity.idEmpresa);
    if (empresaSesion > 0 && !this.empresas.some(item => item.id === empresaSesion)) {
      this.empresas.unshift({ id: empresaSesion, nombre: this.identity.nomEmpresa || `Empresa ${empresaSesion}` });
    }
    if (this.empresas.length) {
      this.idEmpresa = empresaSesion > 0 ? empresaSesion : this.empresas[0].id;
    } else {
      this.errorEmpresas = true;
    }
  }

  private formatearFecha(fecha: Date): string {
    const mes = String(fecha.getMonth() + 1).padStart(2, '0');
    const dia = String(fecha.getDate()).padStart(2, '0');
    return `${fecha.getFullYear()}-${mes}-${dia}`;
  }
}
