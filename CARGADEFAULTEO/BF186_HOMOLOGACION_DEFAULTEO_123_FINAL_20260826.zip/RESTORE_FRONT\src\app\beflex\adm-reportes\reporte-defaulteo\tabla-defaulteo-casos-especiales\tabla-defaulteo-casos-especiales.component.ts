import { Component, ViewEncapsulation, OnInit,ElementRef ,ViewChild,Input, Output, EventEmitter, ChangeDetectionStrategy, AfterContentInit } from '@angular/core';
import { EmpleadoService } from '../../../../services/empleado.service';
import { TitularesService } from '../../../../services/titulares.service';
import 'rxjs/add/observable/fromEvent';
import swal from 'sweetalert2';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { GLOBAL } from '../../../../services/global';
import { buscaPlanesPerfilService } from '../../../../services/buscaPlanesPerfil.service';

import { BeneficiarioService } from '../../../../services/beneficiario.service';
import { Bitacora } from '../../../../services/bitacora.service'
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { NgbModal,NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { ReporteCifrasControlService } from '../../../../services/cifrasControl/reporte-cifras-control.service';
import { DocumentosPerService } from '../../../../services/documentosPer/documentos-per.service';
import { ExcelService } from '../../../../services/excel.service';
import * as FileSaver from 'file-saver';
import { Workbook } from 'exceljs';
import readXlsxFile from 'read-excel-file';
import { SelectItem } from 'primeng/api';
import { EmpresaComboService } from 'src/app/services/empresas.service';
import { BitacoraService } from 'src/app/services/bitacora-navegacion/bitacora.service';
import { DefaulteoAvanzadoService } from '../../../../services/defaulteo-avanzado.service';
declare var $:any;

type Option = { key: string; value: string };
@Component({
  selector: 'app-tabla-defaulteo-casos-especiales',
  templateUrl: './tabla-defaulteo-casos-especiales.component.html',
  styleUrls: ['./tabla-defaulteo-casos-especiales.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [
    NgbModal, DatePipe
  ]
})
export class TablaDefaulteoCasosEspecialesComponent implements OnInit {

public planesDefaulteo;
public empleadosSeleccionados= [];
public titulares = 'Titulares';
public identity;
public token;
public tituloTabla;
public busquedaPor = 'numero';
public valorBusqueda: string;
public campoBusca: string;
public loadEditar = false;
public datosTabla = [null];
public datosTitul = [null];
public regex;
public errorEntrada;

public datosDefaulteo;
public procesoEnEjecucion=true;
public procesoFinalizado=false;
public urlWs;

public opcionesBusqueda = [
  {    nombre:'Número de empleado' , value: 'numero'},  
  {    nombre:'Primer nombre' , value: 'nombre'},
  {    nombre:'Segundo nombre' , value: 'nombre2'},
  {    nombre:'Apellido paterno' , value: 'paterno'},
  {    nombre:'Apellido materno' , value: 'materno'} 
]

public existenDatosTabla=false;
public msjNoHayDatos=false;

//variables defaulteo master


  //variables defaulteo master fin

  //variables defaulteo 
  public tipoDefaulteo;
  public seccionDefaulteo='none';
  public iconoCargando;
  public tipoBusqueda=-1;
  public componentBlock = false;
  public procesando;
  public reporte;

  public comboVigencias=[];

  public iconoAyuda;
  public textAyuda;

    public multivigencia= true;
    public idVigenciaSeleccionada=0;
    public idMultivigencia = 0;
    public idVigenciaVigente = 0;
    public fila=0;

    public datosCotizador;
    public datosCotizadorV3;
    public modal;
    public ejecutando;
    public numEmpleadoTmp;
    public modalReporte;
    public modalReporteElement;

    public page = 1;
    public pageSize = 10;
    public collectionSize = 0;

    // CREA06 casos especiales (F3): layout descargar/cargar
    public layoutCargado: any[] = null;
    public layoutNombreArchivo = '';
    public layoutFilas = 0;
    // CREA06 R2: cuantos del layout NO se aplicaran (defaulteo tipo 2 + cambio de perfil). Se calcula
    // al cargar el layout y se reutiliza en el popup de confirmacion de ejecucion.
    public layoutNoSeProcesan = 0;
    // CREA06 (sesion 30-jun): resumen de validaciones previas del layout (validos / invalidos por tipo, empleado
    // inexistente, no pertenece, ya con solicitud). Alimenta las pantallas de confirmacion.
    public resumenLayout: any = null;

    // CREA06 casos especiales (F4): condiciones especiales (planes + coberturas)
    public catPlanesCondiciones: any[] = [];
    // CREA06 (obs 21-jul): true mientras se filtran los planes por vigencia (una consulta de coberturas por plan).
    public cargandoPlanesCond = false;
    public catCoberturasCondiciones: any[] = [];
    // CREA06 (incidencia 12): catalogos en formato SelectItem para los controles PrimeNG estandarizados
    // (p-dropdown con filtro para plan, p-multiSelect para coberturas), como en reporte-doc-personalizados.
    public itemsPlanesCond: SelectItem[] = [];
    public itemsCoberturasCond: SelectItem[] = [];
    public planSelCond: any = null;
    public coberturasSelCond: any[] = [];
    public condicionesEspeciales: any[] = [];
    // CREA06 (incidencia 9): "Condiciones especiales" colapsable, arranca contraida para no cargar la pantalla.
    public mostrarCondicionesEspeciales = false;

    // CREA06 (incidencia 11): tipo de defaulteo global del flujo individual sin layout (patron del combo
    // "Tipo asignacion de planes" del defaulteo normal); '0' = sin asignar. El tipo por renglon del grid gana.
    public tipoDefaulteoGlobal: any = '0';

    // CREA06 casos especiales (F5): ejecucion del lote + log
    public ejecutandoLote = false;
    // CREA06 async: avance del lote en background { procesados, total, estado } para el indicador de progreso.
    public progresoLote: { procesados: number, total: number, estado: string } = null;
    // Tras una corrida COMPLETADA el boton se bloquea para evitar re-ejecuciones accidentales del mismo
    // layout; se rehabilita al cargar otro layout. En error de red NO se marca (queda habilitado para reintentar).
    public loteEjecutado = false;
    public logEjecucion: any[] = [];
    public resumenEjecucion: any = null;
    @ViewChild('tiposPlanes') inputEl: ElementRef;
    // Minuta 22-jun: ref al input de archivo para reiniciar el apartado de carga tras la ejecucion.
    @ViewChild('fileLayoutInput') fileLayoutInput: ElementRef;
    
      
    /*variables multivigencia*/

  public correo = {
    correo: '',
    nombre: '',
    listado: []
  }
  public correosCopia:string = "";
  public empresaAccion;
  public correoAdmin="beflex@mx.lockton.com";

  public plantillaCorreo = "<DIV ALIGN='center'>" +
  "<FONT COLOR='black' SIZE='3' FACE='Arial'><B>#TipoNotificacion</B> </FONT> <BR> <BR>" +
  "<FONT COLOR='black' SIZE='2' FACE='Arial'>El administrador: #Administrador, ha ejecutado la asignación de planes." +
  " Favor de revisar el log de resultados .</FONT> <BR>" +
  "<FONT COLOR='black' SIZE='2' FACE='Arial'>Fecha y hora de fin del proceso: #Fecha</FONT> <BR>" +
  "<HR NOSHADE WIDTH='50%' COLOR='black'><BR>" +
  "</DIV>";

  /* Variables de busqueda avanzada */
  
  // Objeto de errrores
  public errorRep = {
    empresas: false,
    perfiles: false,
    parametroBusqueda1: false,
    parametroBusqueda2: false,
    estatusSolicitudes: false
  };
  public validRep = {
    empresas: false,
    perfiles: false,
    parametroBusqueda1: false,
    parametroBusqueda2: false,
    estatusSolicitudes: false
  };
  public arbol = [];
  public empresasRegistradas: any[] = [];
  public seleccionArbol: any[] = [];
  public tipoOperadorLogico: Option[] = [
    {'key': 'and', 'value':' Y '},
    {'key': 'or', 'value':' O '}
  ];
  public atributoEmpleado: Option[] = [ // Solo una seleccion
    {'key': 'EMNumeroEmpleado', 'value':'Número de empleado'},
    {'key': 'EMNombre1', 'value':'Primer nombre'},
    {'key': 'EMNombre2', 'value':'Segundo nombre'},
    {'key': 'EMApellidoPaterno', 'value':'Apellido paterno'},
    {'key': 'EMApellidoMaterno', 'value':'Apellido materno'}
  ];
  public tipoOperador: Option[] = [ // Solo una seleccion
    {'key': 'contiene', 'value':'Contiene'},
    {'key': 'igual', 'value':'Es igual a'},
    {'key': 'noigual', 'value':'No es igual a'}, // != o <>
    {'key': 'iniciapor', 'value':'Comienza por'},
    {'key': 'terminapor', 'value':'Termina con'},
    {'key': 'nocontiene', 'value':'No contiene'} // Not like
  ];
  public esBusquedaAvanzada: boolean = false;
  
  // Objeto de parametros seleccionados
  public parametrosBusqueda: IBusquedaRequest = {
    idEmpresas: [],
    perfiles: [],
    idAtributo1: 'EMNumeroEmpleado',
    idTipoOperador1: 'contiene',
    parametroBusqueda1: '',
    idTipoOperadorAvanzado: 'and',
    idAtributo2: 'EMNumeroEmpleado',
    idTipoOperador2: 'contiene',
    parametroBusqueda2: '',
    idEstatus: ['Rechazada','Autorizada','Por Autorizar','Cancelada'],
    idVigencia: 0,
    BusquedaAvanzada:0
  };

  constructor(
    private _titularesService: TitularesService,
    private _BuscarPlanesv2: buscaPlanesPerfilService,
    private _empleadoService: EmpleadoService,
    public _http: HttpClient,
    private _modalService: NgbModal,
    private datePipe: DatePipe,
    public _cifrasControlService: ReporteCifrasControlService,
    config: NgbModalConfig,
    private _docPerService : DocumentosPerService,
    public _excelService: ExcelService,
    private _empresaService: EmpresaComboService,
    public _BitacoraService: BitacoraService,
    private _defAvanzadoService: DefaulteoAvanzadoService,
    ) {
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();
    this.errorEntrada = false;
    this.urlWs = GLOBAL.url;
    this.inicializarFormularioBusqueda();
    // config.backdrop = 'static';
    // config.keyboard = false;
  }

  async ngOnInit() {
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();
    // CREA06 casos especiales (async): si quedo un lote corriendo en el backend y el operador salio de la
    // pantalla, al volver reconectamos el seguimiento del avance/resultado.
    this.reanudarLoteEnCursoSiExiste();
    this.consultaVigencias();
    this.obtenerPlanesDefaulteo();
    this.getDatosCorreo();
    this.getCorreosParaCopiaAdmin();
    await this.obtenerEmpresas();
  }


  ngOnDestroy() {
    // Frena el polling de ESTA instancia al salir (el lote sigue en el backend; si el operador
    // vuelve, una instancia nueva lo reconecta desde localStorage). Evita polls duplicados.
    this.componenteVivo = false;
    swal.close();

    if(this.modal){
        this.modal.close();
    }

    if(this.modalReporte){
      this.modalReporte.close();
  }

  }

  seleccionarTodos($event){

    this.empleadosSeleccionados = [];

    if($event.target.checked == false){

      for(let i = 0; i < this.datosTabla.length; i++){

        for(let j = 0; j < this.datosTabla[i].length; j++){
          
          
          if(this.datosTabla[i][j].key == "seleccion"){
  
            this.datosTabla[i][j].value = false;
  
           
            
  
  
          }
  
  
        }
  
      }

    }else{

      for(let i = 0; i < this.datosTabla.length; i++){

        for(let j = 0; j < this.datosTabla[i].length; j++){
          
          
          if(this.datosTabla[i][j].key == "seleccion"){
  
            this.datosTabla[i][j].value = true;
  
            this.generarListaEmpleados(this.datosTabla[i]);
  
  
          }
  
  
        }
  
      }

    }

    

  }

  

  iniciarDefaulteo(modalProcesando,modalReporte){

    this.iconoCargando = true;
    this.ejecutando = true;
    this.modalReporteElement = modalReporte;
    
    if(this.tipoDefaulteo == 1 || this.tipoDefaulteo == 2 || this.tipoDefaulteo == 3 ){
      if(this.empleadosSeleccionados.length > 0){
        swal({
          title: `¿Está seguro de defaultear los usuarios seleccionados?`,
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Aceptar',
          cancelButtonText: 'Cancelar'
        }).then((result) => {
          if (result.value) {
            if(!this.modal){
              this.modal = this._modalService.open(modalProcesando, {  backdrop : 'static',windowClass: 'confirmacionModal1', centered: true });
            }
            this.defaultearEmpleadosSeleccionadosModal(modalProcesando);
          }
        });
      } 
      else{
        Swal.fire({
          title: '¡Atención!',
          text: 'Favor de seleccionar un usuario',
          type: 'warning'
        });
        this.iconoCargando = false;
      } 
    }else{
      Swal.fire({
        title: '¡Atención!',
        text: 'Favor de completar el campo Tipo de Asignación de planes!',
        type: 'warning'
      });
      this.iconoCargando = false;
    }

  }

  obtenerTipoUrl(paso,idEmpleado,planesSeleccionados?){
      let datos = {
        url:null,
        datosGuardado:null

      }
        switch(+paso){

            //obtencion de planes
            case 1:

              if( (this.tipoDefaulteo == "2" || this.tipoDefaulteo == "1") && this.idVigenciaSeleccionada == this.idVigenciaVigente){
                datos.url = GLOBAL.url + "planesPerfil/empleado/" + idEmpleado + "/v3-1Defaulteo"
              }else if(this.tipoDefaulteo == "2" && this.idVigenciaSeleccionada != this.idVigenciaVigente){
                
                datos.url = GLOBAL.url + "planesPerfil/empleado/" + idEmpleado + "/v3-1DefaulteoMultivigencia/" + this.idVigenciaSeleccionada;
              }else{
                datos.url = GLOBAL.url + "planesPerfil/empleado/" + idEmpleado + "/v3-1DefaulteoMultivigencia/" + this.idMultivigencia;

              }

            break;
            //guardar planes
            case 2:

            if(this.identity.idEmpresa != 369){


              datos.datosGuardado =
              {
                "idEmpleado": this.datosCotizadorV3.declaraciones['idEmpleado'],
                "idEmpresa": this.datosCotizadorV3.declaraciones['idEmpresa'],
                "xmlPlanesSeleccionados": planesSeleccionados,
              }
              
              if ( (this.tipoDefaulteo == "2" || this.tipoDefaulteo == "1")  && this.idVigenciaSeleccionada == this.idVigenciaVigente) {
                datos.url = GLOBAL.url + "planesPerfil/tmp/";
              }else if(+this.tipoDefaulteo == 2 && this.idVigenciaSeleccionada != this.idVigenciaVigente){
                datos.url = GLOBAL.url + "planesPerfil/tmp/multivigencia/" + this.idVigenciaSeleccionada;

              }else {
                datos.url = GLOBAL.url + "planesPerfil/tmp/multivigencia/" + this.idMultivigencia;

              }


            }else{

              datos.datosGuardado =
                                        {
                                          "idEmpleado": this.datosCotizadorV3.declaraciones['idEmpleado'],
                                          "idEmpresa": this.datosCotizadorV3.declaraciones['idEmpresa'],
                                          "xmlPlanesSeleccionados": planesSeleccionados,
                                          "cantidadPago": this.datosCotizadorV3.declaraciones['cantidadPago'],
                                          "idConfiguracion": this.datosCotizadorV3.declaraciones['idConfiguracion'],
                                          "idPerfil": this.datosCotizadorV3.declaraciones['idPerfil'],
                                          "idPeriodicidadPago": this.datosCotizadorV3.datosIniciales['idPeriocidadPago'],
                                          "idVigencia": this.datosCotizadorV3.declaraciones['idVigencia'],
                                          "numeroEmpleado": this.datosCotizadorV3.declaraciones['numeroEmpleado'],
                                          "periodicidadNombre": this.datosCotizadorV3.declaraciones['peridicidadNombre']
                                        }

              if (+this.tipoDefaulteo == 2 && this.idVigenciaSeleccionada == this.idVigenciaVigente) {
                datos.url = GLOBAL.url + "planesPerfil/v2/tmp";
              } else {
                datos.url = GLOBAL.url + "planesPerfil/v2/tmp/" + this.idMultivigencia;

              }

                
              
            }



            break;

        }


        return datos;

  }

  recuperarPlanes(idEmpleado,idVigenciaTarifas){

    let defaulteo;
    switch(+this.tipoDefaulteo){
      case 1:
        defaulteo = 'def1';
        break;
      case 2:
        defaulteo = 'def2';
        break;
      case 3:
        defaulteo = 'def1';
        break;

    }

    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    let urlWs = GLOBAL.url;
    let inicio = {
      "idEmpresa": this.identity.idEmpresa,
      "planesSeleccionados": [
        {
          "costo": null,
          "idempleado": -1,
          "nuevo": null,
          "tcidtarifacosto": -1
        }
      ],
      "planesSeleccionadosOld": [
        {
          "costoOld": null,
          "idempleadoOld": -1,
          "nuevoOld": null,
          "tcidtarifacostoOld": -1
        }
      ],
      "transfer": defaulteo
    }

    


    // let buscaPlanes = urlWs + "planesPerfil/empleado/" + idEmpleado + "/v3-1DefaulteoMultivigencia/" + idVigenciaTarifas;
    let datos = this.obtenerTipoUrl(1,idEmpleado);


    this._http.post(datos.url,
      JSON.stringify(inicio),
      { headers: getHeaders }
    ).subscribe(
      response => {
          let respuesta;

          respuesta = response;


          if(respuesta.datosCotizador && respuesta.boton){

            this.datosCotizador = response;
            this.recuperarPlanesV3(idEmpleado,this.token);

          }else{

            this.reporte.push(`numero de empleado ${this.numEmpleadoTmp}:error \n`);
            this.fila++;
            this.defaultearEmpleadosSeleccionadosModal("",this.fila);

          }
           

         
      
      }, error => {
     
      }
    );


  }



  recuperarPlanesV3(idEmpleado,token){


    this._BuscarPlanesv2.getPlanesPerfilV3(idEmpleado, token).then(
      response => {

        this.datosCotizadorV3 = response;

          this.guardarPlanesSeleccionados();

      },
      error => {

       


      }
    );
  
  
  }


  guardarPlanesSeleccionados(){

    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });

    let datosCotizador = this.datosCotizador.datosCotizador;
    
    let planesSeleccionados = "<ROOT>";
    for (let i = 0; i < datosCotizador.length; i++) {
      if (datosCotizador[i]['checked'] == "true") {
        const cantidad = this.datosCotizadorV3.declaraciones['cantidadPago'];
        const idTC = datosCotizador[i]['tcIdTarifaCosto'];
        var PT = datosCotizador[i]['tcPrimaTotal'];
        PT = parseFloat(PT).toFixed(4)
        const id = datosCotizador[i]['id'];
        planesSeleccionados += "<TarifaCosto TCidTarifaCosto=\"" + idTC + "\" Costo=\"" + PT + "\" idEmpleado=\"" + id + "\"></TarifaCosto>";
      }
    }
    planesSeleccionados += "</ROOT>";
    
    // let urlInsertarPlanesTmp = this.urlWs + "planesPerfil/v2/tmp/" + this.idMultivigencia;
    let datos = this.obtenerTipoUrl(2,this.datosCotizadorV3.declaraciones['idEmpleado'],planesSeleccionados);

    this._http.post(datos.url,datos.datosGuardado, { headers: getHeaders })
      .subscribe(
        response => {
           this.generarSolicitud(this.datosCotizadorV3.declaraciones['idEmpleado']);
        }, error => {
          this.reporte.push(`numero de empleado ${this.numEmpleadoTmp}:error \n`);
          this.fila++;
          this.defaultearEmpleadosSeleccionadosModal("",this.fila);
        }
      )

  }


  generarSolicitud(idEmpleado){

    this._BuscarPlanesv2.crearSolicitudEmpleadoDefaulteo(idEmpleado, this.idVigenciaSeleccionada).subscribe(
    response2 => {

   

     
       let datos= {
        idEmpleado:idEmpleado,
        idEmpresa:this.identity.idEmpresa
       }

       this._BuscarPlanesv2.verificarSolicitudExist2(datos, this.idVigenciaSeleccionada, this.token)
       .then(
         response => {
           
           if(response == 1){
            this.reporte.push(`numero de empleado ${this.numEmpleadoTmp}:ok \n`);

          }else{

            this.reporte.push(`numero de empleado ${this.numEmpleadoTmp}:error \n`);
          }
          
          
                     this.fila++;
                    this.defaultearEmpleadosSeleccionadosModal("",this.fila);
          
        }, error => {
          
         }
       );
    
    }, error => {
    
    
    }
  
  );

  }



  //nuevos metodos para la optimizacion del modulo


  obtenerMultivigencia(idVigenciaSelecionada){


    this.idMultivigencia =idVigenciaSelecionada;

    for(let i = 0; i < this.comboVigencias.length; i++){


      if(this.comboVigencias[i].VIidVigencia == idVigenciaSelecionada ){
          let j = i;
          j++
          
          if(!(j < this.comboVigencias.length)){
              j = i;
          }
          
          
          console.log("idMultivigenciaAnterior:" + this.comboVigencias[j].VIidVigencia);
          this.idMultivigencia = this.comboVigencias[j].VIidVigencia;
        break;

      }

      

    }


  }

  buscaAyuda(){
    let getHeaders: HttpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    });
    this.iconoAyuda = 1;
            this.textAyuda = "Texto de ayuda Defaulteo, Crear y Actualizar Solicitudes.";
    this._http
      .get(this.urlWs + 'ayuda/menu/558', { headers: getHeaders })
      .subscribe(
        response => {
          const pagina = response;

          this._http.get(
            this.urlWs +
            'ayuda/empresa/' +
            this.identity.idEmpresa +
            '/pagina?pagina=' +
            pagina['paNombreArchivo'],
            { headers: getHeaders }
          )
            .subscribe(
              response => {
                this.iconoAyuda = 1;
                const textoayuda = response;
                this.textAyuda = textoayuda[0].paTextoAyuda;

              },
              error => {
                const errorMessage = <any>error;
                this.iconoAyuda = 0;
                swal({
                  title: '¡Error!',
                  html: '<small style="color: grey; text-align: justify;">Ha ocurrido un problema al obtener los datos de ayuda.</small>',
                  type: 'error',
                  confirmButtonText: 'Aceptar',
                  timer: 3000,
                }).then((result) => {
                  $('#modalAyuda').modal('hide');
                });
              }
            );
        },
        error => {
          this.iconoAyuda = 1;
            this.textAyuda = "Texto de ayuda Defaulteo, Crear y Actualizar Solicitudes.";
        }
      );

  }

  consultaVigencias(){
    return this._cifrasControlService.getConsultaVigenciasXEmpresa(this.identity.idEmpresa).then(response=>{
      console.log("Estas son las vigencias_");
      console.log(response);
      this.comboVigencias=response[0];
      this.obtenerVigenciaActual();

    });
  }

 

  obtenerVigenciaActual(){
    this._titularesService.obtenerVigenciaActual(this.identity.idEmpresa).then(
      response => {
        // El endpoint .../vigencia puede devolver null/vacio (p.ej. en local/DEV si la empresa del admin
        // no tiene "vigencia actual" resuelta). Antes esto reventaba con response[0] y dejaba la vigencia en 0
        // -> coberturas/defaulteo salian con vigencia 0. Fallback: primera vigencia del combo (la mas nueva
        // = la vigente; el combo viene ordenado nuevo->viejo, ver obtenerMultivigencia).
        this.aplicarVigenciaActual((response && response[0] && response[0].idVigencia != null) ? response[0].idVigencia : null);
      },
      error => {
        console.log("error en la obtencion de la vigencia actual");
        this.aplicarVigenciaActual(null);
      });

  }

  /** CREA06: fija la vigencia vigente/seleccionada con fallback al combo de vigencias si el endpoint no la da. */
  private aplicarVigenciaActual(idVigencia: any): void {
    let vig = idVigencia;
    if (vig == null || vig === 0) {
      vig = (this.comboVigencias && this.comboVigencias.length > 0) ? this.comboVigencias[0].VIidVigencia : 0;
    }
    this.idVigenciaVigente = vig;
    this.idVigenciaSeleccionada = vig;
    if (vig) { this.obtenerMultivigencia(vig); }
  }


  obtenerPlanesDefaulteo(){

    this._titularesService.obtenerPlanesDefaulteo().then(
      response => {

        // this.datosVigenciasCorporativo = response[0][0].VINombreCompuesto;
        this.planesDefaulteo = response[0];
        
  });

  }

 


  asignarTipoDefaulteo(tipoDefaulteo){
    // 1 selecciones anteriores 
    // 2 plan basico 
  this.tipoDefaulteo = tipoDefaulteo;
  }

  generarListaEmpleados(datosEmpleado){
  let existeEmpleado;
  let idEmpleado = datosEmpleado[0].value;
  let indexEmpleadoExistente;

    for(let i = 0; i < this.empleadosSeleccionados.length; i++){

      for(let j = 0; j < this.empleadosSeleccionados[i].length; j++){

        if(this.empleadosSeleccionados[i][j].key == "Id"){

          if(this.empleadosSeleccionados[i][j].value == idEmpleado){

            indexEmpleadoExistente = i;
            existeEmpleado = true;
            break;

          }

        }
      }

    }

    if(existeEmpleado){

      this.empleadosSeleccionados.splice(indexEmpleadoExistente, 1);
    }else{

      this.empleadosSeleccionados.push(datosEmpleado);
    }

    console.log("empleados seleccionados", this.empleadosSeleccionados);
  }

  //antes de multivigencia
  getTitulares(parametros: any) {
    this._titularesService.getTitularesDefaulteo(parametros, this.token).then(
      response => {
        console.log(response);
        if (response) {
          if (response[1].length == 0){
            this.componentBlock= false;
            Swal.fire({
              title:'¡Atención!',
              text: 'No se encontraron datos que coincidan con tu busqueda',
              icon: 'warning'
            });
          }
          else{
            this.datosTitul = [];
            this.datosTitul = response[1].map(titulares => this.valuesToArray(titulares));

            for (let elemento of this.datosTitul) {
              elemento[8].value = this.datePipe.transform(elemento[8].value, 'dd-MM-yyyy');
            }
            this.vaciarDatosTitu();

          }
        }
      },
      error => {
        const errorMessage = <any>error;
        console.error('Error getTitulares()', error);
      }
    );
  }
  getTitularesMultivigencia() {
    this.loadEditar = true;

    let parametros = {
      "IdsEmpresas" : this.parametrosBusqueda.idEmpresas.join(',')
      ,"IdAdministrador" : this.identity.id
      ,"idPerfiles" : this.parametrosBusqueda.perfiles.join(',')
      ,"idAtributo1" : this.parametrosBusqueda.idAtributo1
      ,"idAtributo2" : this.parametrosBusqueda.idAtributo2
      ,"idTipoOperador1" : this.parametrosBusqueda.idTipoOperador1
      ,"idTipoOperador2" : this.parametrosBusqueda.idTipoOperador2
      ,"parametroBusqueda1" : this.parametrosBusqueda.parametroBusqueda1
      ,"parametroBusqueda2" : this.parametrosBusqueda.parametroBusqueda2
      ,"BusquedaAvanzada" : this.esBusquedaAvanzada ? 1 : 0
      ,"idTipoOperadorAvanzado" : this.parametrosBusqueda.idTipoOperadorAvanzado
      ,"Vigencia": this.parametrosBusqueda.idVigencia
      ,"CasosEspeciales": 1
    }

    this._titularesService.getTitularesMultiVigAvanzado(parametros, this.token).then(
      response => {
        if (response != undefined && response != null) {
          if (response.length == 0){
            this.componentBlock= false; // Volver a habilitar campos
            this.msjNoHayDatos = true;
            this.existenDatosTabla = false;
            this.seccionDefaulteo='none';
          }
          else{
            this.loadEditar = true;
            this.datosTitul = [];
            this.datosTitul = response.map(titulares => this.valuesToArray(titulares));
            for (let elemento of this.datosTitul) {
              elemento[11].value = this.datePipe.transform(elemento[11].value, 'dd-MM-yyyy');
            }
            // CREA06 casos especiales: columna editable "Tipo defaulteo" por fila (default '0' = Seleccionar)
            this.datosTitul.forEach((f: any[]) => { if (!f.some((d: any) => d && d.key === 'tipoDefaulteo')) { f.push({ key: 'tipoDefaulteo', value: '0' }); } });
            this.cargarPlanesCondiciones();
            this.vaciarDatosTitu();
            this.loadEditar = false;
            this.existenDatosTabla = true;
          }
        }else{
          this.loadEditar = false;
          this.msjNoHayDatos = true;
          this.existenDatosTabla = false;
          this.componentBlock = false; // Habilitar campos
          this.seccionDefaulteo='none';
        }
      },
      error => {
        const errorMessage = <any>error;
        console.error('Error getTitulares()', error);
        this.loadEditar = false;
        this.msjNoHayDatos = true;
        this.existenDatosTabla = false;
        this.componentBlock = false;
        this.seccionDefaulteo='none';
        this.restaurarSeccionDefaulteo();
      }
    );
  }

  // Desuso
  buscar(parametro?) {
    // console.log("Entro a metodo",parametro, parametro.length);
    this.page = 1;
    this.pageSize = 5;
    this.collectionSize = 0;
    console.log(this.busquedaPor);
    this.empleadosSeleccionados = [];
    this.datosTabla = [];
    this.errorEntrada  = false;
    this.componentBlock= true;
    // if(!this.valorBusqueda)
    this.valorBusqueda = parametro;
  
    const regexpNumber = new RegExp('^[\u00F1\u00D1A-ZÁ-Üa-zá-ü .]+$');
    console.log(regexpNumber.test(parametro));
    switch (this.busquedaPor) {
        case "nada":
          if (parametro == '') {
            console.log("Entro a nada primer case");
              this.buscarTitulares();  
          } else {
            this.errorEntrada = true;
            this.componentBlock= false;
          } 
        break;
  
        case 'nombre':
          if (regexpNumber.test(parametro) || parametro == '') {
              this.buscarTitulares();
          } else {
            this.errorEntrada = true;
            this.componentBlock= false;
          }
        break;
  
        case 'nombre2':
          if (regexpNumber.test(parametro) || parametro == '') {
              this.buscarTitulares();  
          } else {  
            this.errorEntrada = true;
            this.componentBlock= false;
          }
        break;

        case 'numero':
          console.log("Es numero");
          this.buscarTitulares();
        break;
  
        case 'paterno':
          if (regexpNumber.test(parametro) || parametro == '') {  
              this.buscarTitulares();  
          } else {
            this.errorEntrada = true;
            this.componentBlock= false;
          }
        break;
  
        case 'materno':
          if (regexpNumber.test(parametro) || parametro == '') {
            this.buscarTitulares();
          } else {
            this.errorEntrada = true;
            this.componentBlock= false;
          }
        break;
  
        default:
          console.log("Entro a nada default");
          this.buscarTitulares(); 
        break;
    }
  }
    
  buscarTitulares() {
    let parametros;
    switch (this.busquedaPor) {
      case 'nada':
        if (this.valorBusqueda == '' || this.busquedaPor=="nada") {
     
        parametros = {
          'idCorporativo':1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno': null,
          'apellidoMaterno': null,
          'nombreUno': null,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      }
      break;
      case 'nombre':
        parametros = {
          'idCorporativo':1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno': null,
          'apellidoMaterno': null,
          'nombreUno': this.valorBusqueda,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };  
      break;

      case 'nombre2':
        parametros = {
          'idCorporativo': 1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno': null,
          'apellidoMaterno': null,
          'nombreUno': null,
          'nombreDos': this.valorBusqueda,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      break;

      case 'numero':
        parametros = {
          'idCorporativo': 1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': this.valorBusqueda,
          'apellidoPaterno': null,
          'apellidoMaterno': null,
          'nombreUno': null,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      break;

      case 'paterno':
        parametros = {
          'idCorporativo': 1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno': this.valorBusqueda,
          'apellidoMaterno': null,
          'nombreUno': null,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      break;

      case 'materno':
        parametros = {
          'idCorporativo': 1,
          'idEmpresa': this.identity.idEmpresa,
          'numEmpleado': null,
          'apellidoPaterno':null ,
          'apellidoMaterno': this.valorBusqueda,
          'nombreUno': null,
          'nombreDos': null,
          'vigencia':this.idVigenciaSeleccionada,
          'idAdministrador':this.identity.id
        };
      break;

      default:
        this.campoBusca = 'EMNombre1';
      break;
    }
  
    if(this.tipoBusqueda ==1){
      parametros.idCorporativo=1;
      parametros.idEmpresa = this.identity.idEmpresa;
    }else{
      parametros.idCorporativo=-1;
      parametros.idEmpresa = this.identity.idEmpresa;
    }

    this.datosTabla = [];
    //busqueda de titulares
    if(this.multivigencia){
      this.getTitularesMultivigencia();
    }else{
      this.getTitulares(parametros);
    }
  }

  cambiarNivelBusqueda(tipoBusqueda){
      this.tipoBusqueda = tipoBusqueda;
  }

  valuesToArray(obj) {
    const objeto = [];
    Object.keys(obj).map(
      (key) => {


        objeto.push({
          value: obj[key] != 'NULL' ? obj[key] : '',
          key: key
        });
      }
    );
    return objeto;
  }

  /**
   * CREA06 casos especiales (F2): lee de la fila (array de {key,value}) el valor de una columna por su key.
   * Forward-compatible: hoy las 4 columnas nuevas no vienen en la respuesta (stub '-'); cuando el backend
   * agregue estos campos, valuesToArray los mapea automaticamente y la celda se autopuebla.
   * Contrato de keys esperadas del backend:
   *   estatusSolicitudVigActual, numeroSolicitudVigAnterior, estatusSolicitudVigAnterior, tipoDefaulteo
   */
  colVal(fila: any[], key: string): any {
    if (!fila) { return ''; }
    const item = fila.find((d: any) => d && d.key === key);
    return item ? item.value : '';
  }

  /** CREA06 casos especiales: setea el "Tipo defaulteo" (columna editable) en la fila. */
  setTipoDefaulteo(fila: any[], value: any): void {
    if (!fila) { return; }
    const item = fila.find((d: any) => d && d.key === 'tipoDefaulteo');
    if (item) { item.value = value; } else { fila.push({ key: 'tipoDefaulteo', value: value }); }
  }

  // -----------------------------------------------------------------------
  // CREA06 casos especiales (F3): Exportar layout a Excel / Cargar layout
  // -----------------------------------------------------------------------
  /**
   * Descarga el grid (las selecciones si hay, si no todo) como .xlsx que sirve de layout
   * para defaulteo masivo. Patron alineado con adminsolicitudes (AoA + celdas texto + bookSST:true
   * para que read-excel-file 4.x pueda re-parsear el archivo al volver a cargarlo).
   */
  exportarLayout(): void {
    // CREA06: solo exportar empleados SELECCIONADOS (checkbox) o cuyo Tipo defaulteo se modifico (!= '0'),
    // no todo el grid de la busqueda.
    const filas: any[] = (this.datosTabla || []).filter((f: any[]) => {
      const sel = this.colVal(f, 'seleccion');
      const tipo = this.colVal(f, 'tipoDefaulteo');
      const seleccionado = sel === true || sel === 'true';
      const tipoModificado = tipo != null && tipo.toString() !== '' && tipo.toString() !== '0';
      return seleccionado || tipoModificado;
    });
    if (!filas || filas.length === 0) {
      swal('Seleccionar empleados', 'Selecciona empleados o cambia su Tipo defaulteo para exportarlos al layout.', 'warning');
      return;
    }
    const headers = ['Id', 'idEmpresa', 'NumeroEmpleado', 'Empresa', 'Perfil',
      'ApellidoPaterno', 'ApellidoMaterno', 'Nombre1', 'Nombre2', 'FechaNacimiento',
      'Edad', 'Parentesco', 'NumeroSolicitud', 'EstatusSolicitudVigActual',
      'NumSolVigAnterior', 'EstatusSolVigAnterior', 'TipoDefaulteo'];
    // CREA06 (obs 21-jul): layout con formato tipo carga masiva (patron excel.service / ExcelJS):
    //   encabezados con estilo, FechaNacimiento con formato de fecha y TipoDefaulteo como combo de
    //   seleccion (id + descripcion) tomado del catalogo planesDefaulteo.
    const tipos: any[] = this.planesDefaulteo || [];
    const etiquetaTipo = (id: any): string => {
      const t = tipos.find((x: any) => String(x.TDIdTipoDefaulteo) === String(id));
      return t ? (t.TDIdTipoDefaulteo + ' - ' + t.Nombre) : '';
    };
    const opcionesTipo: string[] = tipos.map((t: any) => t.TDIdTipoDefaulteo + ' - ' + t.Nombre);

    const workbook = new Workbook();
    const worksheet = workbook.addWorksheet('Layout Casos Especiales');

    // Encabezados con formato
    const headerRow = worksheet.addRow(headers);
    headerRow.eachCell((cell: any) => {
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '4F81BD' }, bgColor: { argb: '4F81BD' } };
      cell.font = { color: { argb: 'FFFFFF' }, bold: true, name: 'Calibri' };
      cell.alignment = { horizontal: 'center' };
    });

    // Formato de columnas: texto para claves/ids (preserva el numero de empleado al recargar),
    // fecha para FechaNacimiento (col 10).
    const colsTexto = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17];
    colsTexto.forEach(c => worksheet.getColumn(c).numFmt = '@');
    worksheet.getColumn(10).numFmt = 'dd/mm/yyyy';

    // Filas de datos
    const s = (v: any): string => (v === null || v === undefined) ? '' : v.toString();
    filas.forEach((f: any[]) => {
      const tipoId = this.colVal(f, 'tipoDefaulteo');
      const tipoTxt = (tipoId != null && tipoId.toString() !== '' && tipoId.toString() !== '0') ? etiquetaTipo(tipoId) : '';
      const row = worksheet.addRow([
        s(this.colVal(f, 'Id')), s(this.colVal(f, 'idEmpresa')), s(this.colVal(f, 'numEmpleado')),
        s(this.colVal(f, 'nombreEmpresa')), s(this.colVal(f, 'perfil')),
        s(this.colVal(f, 'ApellidoPaterno')), s(this.colVal(f, 'ApellidoMaterno')),
        s(this.colVal(f, 'Nombre1')), s(this.colVal(f, 'Nombre2')),
        this.parseFechaLayout(this.colVal(f, 'fechaNacimiento')),
        s(this.colVal(f, 'edad')), s(this.colVal(f, 'parentesco')), s(this.colVal(f, 'NumeroSolicitud')),
        s(this.colVal(f, 'estatusSolicitudVigActual')), s(this.colVal(f, 'numeroSolicitudVigAnterior')),
        s(this.colVal(f, 'estatusSolicitudVigAnterior')), tipoTxt
      ]);
      row.eachCell((cell: any) => { cell.border = { bottom: { style: 'thin', color: { argb: 'DDE0E3' } } }; });
    });

    // Combo (dataValidation lista) de TipoDefaulteo en la columna Q (17), en las filas de datos.
    if (opcionesTipo.length > 0) {
      const lista = '"' + opcionesTipo.join(',') + '"';
      for (let r = 2; r <= filas.length + 1; r++) {
        (worksheet.getCell('Q' + r) as any).dataValidation = {
          type: 'list', allowBlank: true, formulae: [lista],
          showErrorMessage: true, errorStyle: 'stop',
          errorTitle: 'Tipo de defaulteo', error: 'Selecciona un tipo de defaulteo de la lista.'
        };
      }
    }

    // Ancho aproximado por encabezado
    worksheet.columns.forEach((col: any, i: number) => {
      const largo = headers[i] ? headers[i].length : 10;
      col.width = largo < 12 ? 14 : Math.min(28, largo + 2);
    });

    const nombre = 'Layout_Defaulteo_Casos_Especiales_' + filas.length + '.xlsx';
    workbook.xlsx.writeBuffer().then((buf: any) => {
      const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      FileSaver.saveAs(blob, nombre);
      swal('Layout descargado', filas.length + ' registro(s) en ' + nombre, 'success');
    });
  }

  /** CREA06: convierte el valor de FechaNacimiento del grid a Date (para formato de fecha en el layout).
   *  Acepta Date, 'yyyy-MM-dd(...)' o 'dd/MM/yyyy'. Si no puede, regresa el texto original. */
  private parseFechaLayout(valor: any): any {
    if (valor === null || valor === undefined || valor === '') { return ''; }
    if (valor instanceof Date) { return valor; }
    const txt = valor.toString().trim();
    let m = txt.match(/^(\d{4})-(\d{2})-(\d{2})/);            // yyyy-MM-dd
    if (m) { return new Date(+m[1], +m[2] - 1, +m[3]); }
    m = txt.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);             // dd/MM/yyyy
    if (m) { return new Date(+m[3], +m[2] - 1, +m[1]); }
    return txt;
  }

  /** CREA06: extrae el id numerico de TipoDefaulteo del layout, tolerando 'id - descripcion' o solo 'id'. */
  private extraerIdTipoDefaulteo(valor: any): any {
    if (valor === null || valor === undefined) { return null; }
    const n = parseInt(valor.toString().trim(), 10);
    return isNaN(n) ? null : n;
  }

  /** Lee el layout .xlsx cargado por el admin y lo guarda en memoria (el procesado/ejecucion es F5). */
  cargarLayout(event: any): void {
    const file = event && event.target && event.target.files && event.target.files[0];
    if (!file) { return; }
    this.layoutNombreArchivo = file.name;
    // CREA06 casos especiales: al cargar otro layout limpiamos el log/resumen de la ejecucion anterior
    // y rehabilitamos el boton (se habia bloqueado tras la corrida previa).
    this.logEjecucion = [];
    this.resumenEjecucion = null;
    this.loteEjecutado = false;
    this.layoutNoSeProcesan = 0;
    this.resumenLayout = null;
    readXlsxFile(file).then((rows: any[]) => {
      this.layoutCargado = rows || [];
      this.layoutFilas = Math.max(0, this.layoutCargado.length - 1);
      // CREA06 (obs 3-ago): en el flujo de layout directo (sin pulsar Buscar) el catalogo de planes
      // de condiciones especiales nunca se cargaba y los combos quedaban vacios ("No hay resultados").
      if ((this.catPlanesCondiciones || []).length === 0 && !this.cargandoPlanesCond) {
        this.cargarPlanesCondiciones();
      }
      // CREA06 R2 (minuta 22-jun): avisar en popup cuantos NO se procesaran (tipo 2 + cambio de perfil).
      this.validarCambioPerfilLayout(file.name);
    }).catch(() => {
      this.layoutCargado = null;
      this.layoutFilas = 0;
      swal('Error', 'No se pudo leer el archivo. Usa el layout .xlsx descargado.', 'error');
    });
  }

  /**
   * CREA06 R2 (minuta 22-jun): mapea el layout cargado (.xlsx) a [{idEmpleado, idEmpresa, numeroEmpleado, tipoDefaulteo}]
   * leyendo por nombre de encabezado (mismo criterio que ejecutarDefaulteos).
   */
  private mapearLayoutCargado(): any[] {
    if (!this.layoutCargado || this.layoutCargado.length < 2) { return []; }
    const headers = (this.layoutCargado[0] || []).map((h: any) => (h || '').toString().toLowerCase());
    const idx = (name: string) => headers.indexOf(name.toLowerCase());
    const iNum = idx('numeroempleado'), iTipo = idx('tipodefaulteo'), iId = idx('id'), iIdEmp = idx('idempresa');
    return this.layoutCargado.slice(1).map((r: any[]) => ({
      idEmpleado: iId >= 0 ? r[iId] : null,
      idEmpresa: iIdEmp >= 0 ? r[iIdEmp] : null,
      numeroEmpleado: iNum >= 0 ? r[iNum] : null,
      tipoDefaulteo: iTipo >= 0 ? this.extraerIdTipoDefaulteo(r[iTipo]) : null
    }));
  }

  /**
   * CREA06 R2 (minuta 22-jun): al cargar el layout, consulta cuantos empleados NO se procesaran por tener
   * defaulteo tipo 2 + cambio de perfil, y lo informa en un popup de confirmacion. Si la deteccion falla,
   * NO bloquea la carga (degrada al mensaje normal de "Layout cargado").
   */
  private validarCambioPerfilLayout(nombreArchivo: string): void {
    const req = {
      idVigencia: this.idVigenciaSeleccionada || this.idVigenciaVigente,
      idVigenciaAnterior: this.idMultivigencia,
      idVigenciaVigente: this.idVigenciaVigente,
      layout: this.mapearLayoutCargado()
    };
    this._titularesService.detectarCambioPerfilCasosEspeciales(req, this.token).then(
      (r: any) => {
        const noProc = (r && r.noSeProcesan) || 0;
        this.layoutNoSeProcesan = noProc;
        this.resumenLayout = r || null;
        // CREA06 (sesion 30-jun): la pantalla de confirmacion informa validos vs no validos, detallando
        // los invalidos por causa (tipo de defaulteo inexistente / empleado que no existe o no pertenece /
        // ya con solicitud) y, aparte, los que no se aplican por defaulteo tipo 2 + cambio de perfil.
        swal({
          title: 'Layout cargado',
          html: this.construirResumenLayoutHtml(nombreArchivo),
          type: (noProc > 0 || ((r && r.invalidos) || 0) > 0) ? 'warning' : 'success'
        });
      },
      () => {
        this.layoutNoSeProcesan = 0;
        this.resumenLayout = null;
        swal('Layout cargado', this.layoutFilas + ' registro(s) leídos de ' + nombreArchivo, 'success');
      }
    );
  }

  /**
   * CREA06 (sesion 30-jun): arma el texto del resumen del layout para las pantallas de confirmacion.
   * Distingue: validos (crean solicitud), invalidos por dato (con su desglose) y no aplican por tipo 2 + perfil.
   */
  private construirResumenLayoutHtml(nombreArchivo: string): string {
    const r = this.resumenLayout || {};
    const total = (r.total != null ? r.total : this.layoutFilas) || 0;
    const noProc = r.noSeProcesan || 0;
    const invalidos = r.invalidos || 0;
    const validos = (r.validos != null) ? r.validos : Math.max(0, total - noProc - invalidos);
    let html = 'Se cargaron <b>' + total + '</b> registro(s) de <b>' + nombreArchivo + '</b>.<br>'
             + '<b>' + validos + '</b> válido(s) que se procesará(n) y <b>' + (invalidos + noProc) + '</b> no.';
    const causas: string[] = [];
    if ((r.tipoNoExiste || 0) > 0) { causas.push('<b>' + r.tipoNoExiste + '</b> con tipo de defaulteo que no existe'); }
    if ((r.noExiste || 0) > 0) { causas.push('<b>' + r.noExiste + '</b> que no existe(n) en la empresa'); }
    if ((r.noPertenece || 0) > 0) { causas.push('<b>' + r.noPertenece + '</b> que no pertenece(n) a la empresa'); }
    if ((r.yaTieneSolicitud || 0) > 0) { causas.push('<b>' + r.yaTieneSolicitud + '</b> que ya tiene(n) una solicitud'); }
    if (causas.length > 0) {
      html += '<br><small>No válidos: ' + causas.join(', ') + '.</small>';
    }
    if (noProc > 0) {
      html += '<br><small><b>' + noProc + '</b> no se aplica(n) por <b>defaulteo tipo 2 + cambio de perfil</b>.</small>';
    }
    return html;
  }

  /**
   * Minuta 22-jun: reinicia SOLO el apartado de carga de layout (archivo + badge), dejando visible el
   * resultado (log/resumen). Se invoca al terminar la ejecucion para que el operador parta de cero al
   * volver a cargar un layout. NO toca loteEjecutado (el boton sigue bloqueado hasta cargar otro layout).
   */
  resetCargaLayout(): void {
    this.layoutCargado = null;
    this.layoutFilas = 0;
    this.layoutNombreArchivo = '';
    if (this.fileLayoutInput && this.fileLayoutInput.nativeElement) {
      this.fileLayoutInput.nativeElement.value = '';
    }
  }

  /**
   * CREA06 (incidencia 5): al iniciar una nueva busqueda la pantalla no debe arrastrar el resultado del
   * proceso anterior. Limpia el log de ejecucion, el resumen, el layout cargado y las condiciones especiales.
   */
  private resetCasosEspecialesLog(): void {
    this.logEjecucion = [];
    this.resumenEjecucion = null;
    this.loteEjecutado = false;
    this.layoutNoSeProcesan = 0;
    this.resumenLayout = null;
    this.condicionesEspeciales = [];
    this.planSelCond = null;
    this.coberturasSelCond = [];
    this.catCoberturasCondiciones = [];
    this.itemsCoberturasCond = [];
    this.resetCargaLayout();
  }

  // -----------------------------------------------------------------------
  // CREA06 casos especiales (F4): condiciones especiales (planes + coberturas)
  // -----------------------------------------------------------------------
  /** Carga los planes de la empresa seleccionada (reusa endpoint preview-BeMobile/planes). */
  cargarPlanesCondiciones(): void {
    const ids = this.parametrosBusqueda.idEmpresas as any[];
    let idEmpresa = ids && ids.length > 0 ? Number(ids[0]) : null;
    // CREA06 (obs 3-ago): en el flujo de layout directo puede no haber empresa marcada en el arbol;
    // se toma la empresa del propio layout (misma logica de "primera empresa" que la busqueda).
    if (!idEmpresa && this.layoutCargado && this.layoutCargado.length > 1) {
      const filaConEmpresa = this.mapearLayoutCargado().find((f: any) => f.idEmpresa);
      idEmpresa = filaConEmpresa ? Number(filaConEmpresa.idEmpresa) : null;
    }
    if (!idEmpresa) { this.catPlanesCondiciones = []; this.mapItemsPlanesCond(); return; }
    // CREA06 (obs 21-jul): mostrar SOLO los planes con coberturas configuradas en la vigencia destino
    // (la vigente). Se reutiliza getCoberturas(plan, vigencia): un plan sin coberturas en la vigencia no
    // se puede agregar como condicion, asi que se oculta del combo.
    const idVigencia = this.idVigenciaSeleccionada || this.idVigenciaVigente;
    this._defAvanzadoService.getPlanes(idEmpresa, this.token).subscribe(
      (r: any) => {
        const todos = this.aplanarCat(r) || [];
        if (!idVigencia || todos.length === 0) { this.catPlanesCondiciones = todos; this.mapItemsPlanesCond(); return; }
        this.cargandoPlanesCond = true;
        const checks = todos.map((p: any) =>
          this._defAvanzadoService.getCoberturas(Number(this.idPlanCond(p)), Number(idVigencia), this.token)
            .toPromise()
            .then((cob: any) => ((this.aplanarCat(cob) || []).length > 0) ? p : null)
            .catch(() => null)
        );
        Promise.all(checks).then((res: any[]) => {
          this.catPlanesCondiciones = res.filter(Boolean);
          this.mapItemsPlanesCond();
          this.cargandoPlanesCond = false;
        }).catch(() => {
          // Si algo falla, no dejar al usuario sin planes: mostrar todos como fallback.
          this.catPlanesCondiciones = todos;
          this.mapItemsPlanesCond();
          this.cargandoPlanesCond = false;
        });
      },
      () => { this.catPlanesCondiciones = []; this.mapItemsPlanesCond(); this.cargandoPlanesCond = false; }
    );
  }

  // CREA06 (incidencia 12): catalogos en SelectItem para los controles PrimeNG (mismo formato de
  // etiqueta "[id] nombre" que ya se usaba en los combos nativos).
  private mapItemsPlanesCond(): void {
    this.itemsPlanesCond = (this.catPlanesCondiciones || []).map((p: any) =>
      ({ label: this.labelPlanCond(p), value: this.idPlanCond(p) }));
  }

  private mapItemsCoberturasCond(): void {
    this.itemsCoberturasCond = (this.catCoberturasCondiciones || []).map((c: any) =>
      ({ label: this.labelCobCond(c), value: this.idCobCond(c) }));
  }

  /**
   * TODO backend: cargar coberturas (ff_PlanOpcion) configuradas para el plan + vigencia actual.
   * Por ahora stub vacio (contrato: GET coberturas por plan+vigencia -> [{POidPlanOpcion, PONombre}]).
   */
  onPlanCondChange(): void {
    this.coberturasSelCond = [];
    this.catCoberturasCondiciones = [];
    this.itemsCoberturasCond = [];
    const idPlan = this.planSelCond;
    // CREA06 (incidencia 6): la vigencia de las coberturas es la vigencia DESTINO del defaulteo
    // (la seleccionada; fallback a la vigente). Antes se usaba parametrosBusqueda.idVigencia, que
    // podia venir en 0 y hacia que el combo saliera vacio para TODOS los planes.
    const idVigencia = this.idVigenciaSeleccionada || this.idVigenciaVigente;
    if (!idPlan || !idVigencia) { return; }
    this._defAvanzadoService.getCoberturas(Number(idPlan), Number(idVigencia), this.token).subscribe(
      (r: any) => { this.catCoberturasCondiciones = this.aplanarCat(r); this.mapItemsCoberturasCond(); },
      () => { this.catCoberturasCondiciones = []; this.itemsCoberturasCond = []; }
    );
  }

  agregarCondicion(): void {
    if (!this.planSelCond) { swal('Falta plan', 'Selecciona un plan para agregar.', 'warning'); return; }
    // CREA06 (incidencia 6): la cobertura es OBLIGATORIA. No se puede agregar un plan sin cobertura.
    if (!this.coberturasSelCond || this.coberturasSelCond.length === 0) {
      const msg = (this.catCoberturasCondiciones.length === 0)
        ? 'Este plan no tiene coberturas disponibles para la vigencia; no se puede agregar como condición.'
        : 'Selecciona al menos una cobertura para agregar el plan.';
      swal('Falta cobertura', msg, 'warning');
      return;
    }
    const p = this.catPlanesCondiciones.find(x => this.idPlanCond(x) == this.planSelCond);
    // CREA06 (incidencia 12): el control de coberturas ahora es multiseleccion (p-multiSelect, como el
    // reporte de documentos personalizados): se agrega un renglon por cada cobertura seleccionada.
    let agregadas = 0;
    let duplicadas = 0;
    this.coberturasSelCond.forEach((idCob: any) => {
      const yaExiste = this.condicionesEspeciales.some(r => r.idPlan == this.planSelCond && r.idCobertura == idCob);
      if (yaExiste) { duplicadas++; return; }
      const c = this.catCoberturasCondiciones.find(x => this.idCobCond(x) == idCob);
      this.condicionesEspeciales.push({
        idPlan: this.planSelCond,
        nombrePlan: p ? this.labelPlanCond(p) : ('Plan ' + this.planSelCond),
        idCobertura: idCob,
        nombreCobertura: c ? this.labelCobCond(c) : null
      });
      agregadas++;
    });
    if (agregadas === 0 && duplicadas > 0) {
      swal('Duplicado', 'Esa(s) combinación(es) plan/cobertura ya está(n) en la lista.', 'warning');
      return;
    }
    this.planSelCond = null;
    this.coberturasSelCond = [];
    this.catCoberturasCondiciones = [];
    this.itemsCoberturasCond = [];
  }

  quitarCondicion(i: number): void {
    if (i >= 0 && i < this.condicionesEspeciales.length) { this.condicionesEspeciales.splice(i, 1); }
  }

  private aplanarCat(res: any): any[] {
    if (Array.isArray(res)) { return res.length > 0 && Array.isArray(res[0]) ? res[0] : res; }
    if (res && typeof res === 'object') { for (const k of Object.keys(res)) { if (Array.isArray(res[k])) { return res[k]; } } }
    return [];
  }
  // CREA06 casos especiales: concatenar el id al nombre para distinguir planes/coberturas homonimos en el combo.
  labelPlanCond(p: any): string {
    const id = this.idPlanCond(p);
    const nombre = p.PLDescripcion || p.PLNombre || p.nombre || 'Plan';
    return (id != null ? '[' + id + '] ' : '') + nombre;
  }
  idPlanCond(p: any): any { return p.PLidPlan || p.id || p.idPlan; }
  labelCobCond(c: any): string {
    const id = this.idCobCond(c);
    const nombre = c.PONombre || c.nombre || c.descripcion || 'Cobertura';
    return (id != null ? '[' + id + '] ' : '') + nombre;
  }
  idCobCond(c: any): any { return c.POidPlanOpcion || c.id || c.idCobertura; }

  // -----------------------------------------------------------------------
  // CREA06 casos especiales (F5): ejecutar el layout cargado + log de resultados
  // -----------------------------------------------------------------------
  ejecutarDefaulteos(): void {
    if (!this.layoutCargado || this.layoutFilas === 0) {
      swal('Falta layout', 'Primero carga el layout (.xlsx) con los empleados a procesar.', 'warning');
      return;
    }
    const headers = (this.layoutCargado[0] || []).map((h: any) => (h || '').toString().toLowerCase());
    const idx = (name: string) => headers.indexOf(name.toLowerCase());
    const iNum = idx('numeroempleado'), iTipo = idx('tipodefaulteo'), iId = idx('id'), iIdEmp = idx('idempresa');
    const filas = this.layoutCargado.slice(1);
    const ids = this.parametrosBusqueda.idEmpresas as any[];
    // CREA06 (obs 3-ago): el combo "Tipo asignacion de planes" es el tipo POR DEFECTO de todo el lote;
    // el tipo por empleado del Excel tiene prioridad cuando viene informado.
    const globalValido = this.tieneTipo(this.tipoDefaulteoGlobal);
    const req = {
      idAdmin: this.identity ? this.identity.id : null,
      idVigencia: (this.idVigenciaSeleccionada == this.idVigenciaVigente ? 0 : this.idVigenciaSeleccionada),
      idVigenciaAnterior: this.idMultivigencia,
      idVigenciaVigente: this.idVigenciaVigente,
      condiciones: this.condicionesEspeciales,
      layout: filas.map((r: any[]) => {
        const tipoExcel = iTipo >= 0 ? this.extraerIdTipoDefaulteo(r[iTipo]) : null;
        return {
          idEmpleado: iId >= 0 ? r[iId] : null,
          idEmpresa: iIdEmp >= 0 ? r[iIdEmp] : null,
          numeroEmpleado: iNum >= 0 ? r[iNum] : null,
          tipoDefaulteo: this.tieneTipo(tipoExcel) ? Number(tipoExcel)
                       : (globalValido ? Number(this.tipoDefaulteoGlobal) : tipoExcel)
        };
      })
    };

    // CREA06 (obs 3-ago): la validacion previa se recalcula aqui (no solo al cargar el layout) para que
    // los conteos de validos/no validos reflejen el tipo por defecto recien aplicado.
    this.validarYConfirmarLote(req, 'del layout');
  }

  /** CREA06 (obs 3-ago): true si el valor es un tipo de defaulteo asignado (no vacio ni '0' placeholder). */
  private tieneTipo(t: any): boolean {
    return t != null && t.toString() !== '' && t.toString() !== '0';
  }

  /**
   * CREA06 (obs 3-ago): validacion previa (invalidos / tipo 2 + cambio de perfil) recalculada JUSTO antes
   * de confirmar, comun a ambos origenes. Si la deteccion falla NO bloquea: se confirma solo con totales.
   */
  private validarYConfirmarLote(req: any, origen: string): void {
    const reqDeteccion = {
      idVigencia: this.idVigenciaSeleccionada || this.idVigenciaVigente,
      idVigenciaAnterior: this.idMultivigencia,
      idVigenciaVigente: this.idVigenciaVigente,
      layout: req.layout
    };
    this._titularesService.detectarCambioPerfilCasosEspeciales(reqDeteccion, this.token).then(
      (r: any) => {
        this.layoutNoSeProcesan = (r && r.noSeProcesan) || 0;
        this.resumenLayout = r || null;
        this.confirmarYEjecutarLote(req, origen);
      },
      () => {
        this.layoutNoSeProcesan = 0;
        this.resumenLayout = null;
        this.confirmarYEjecutarLote(req, origen);
      }
    );
  }

  /**
   * CREA06 (incidencia 11): confirmacion + arranque del lote, comun a ambos origenes
   * (layout cargado o seleccion directa del grid). Usa el resumen de validacion previa
   * (resumenLayout / layoutNoSeProcesan) que cada flujo dejo calculado.
   */
  private confirmarYEjecutarLote(req: any, origen: string): void {
    const r = this.resumenLayout || {};
    const invalidos = r.invalidos || 0;
    const noProc = this.layoutNoSeProcesan || 0;
    const validos = (r.validos != null) ? r.validos : Math.max(0, req.layout.length - invalidos - noProc);
    swal({
      title: '¿Ejecutar defaulteos?',
      html: 'Se procesarán <b>' + req.layout.length + '</b> registro(s) ' + origen
            + (this.condicionesEspeciales.length > 0 ? ' con <b>' + this.condicionesEspeciales.length + '</b> condición(es) especial(es)' : '')
            + '.<br><b>' + validos + '</b> válido(s), <b>' + invalidos + '</b> no válido(s)'
            + (noProc > 0
                ? '.<br><b>' + noProc + '</b> no se aplicará(n) por <b>defaulteo tipo 2 + cambio de perfil</b>'
                : '')
            + '.<br><small>Esta acción crea solicitudes reales.</small>',
      type: 'question',
      showCancelButton: true,
      confirmButtonText: 'Ejecutar',
      cancelButtonText: 'Cancelar'
    }).then((res: any) => {
      if (!res || !res.value) { return; }
      this.ejecutandoLote = true;
      this.ejecutarLoteCasosEspecialesAsync(req);
    });
  }

  /**
   * CREA06 (incidencia 11): defaulteo individual SIN layout. Procesa los empleados del grid marcados con
   * checkbox o con tipo de defaulteo modificado (mismo criterio que "Descargar layout"), armando el mismo
   * request del flujo por layout: la validacion previa (cambio de perfil / invalidos), la confirmacion, el
   * lote asincrono con polling y el log de resultados se reutilizan tal cual. El combo global "Tipo
   * asignacion de planes" aplica a los seleccionados sin tipo; el tipo por renglon tiene prioridad.
   */
  ejecutarDefaulteosSeleccion(): void {
    const filas: any[] = (this.datosTabla || []).filter((f: any[]) => {
      const sel = this.colVal(f, 'seleccion');
      return sel === true || sel === 'true' || this.tieneTipo(this.colVal(f, 'tipoDefaulteo'));
    });
    if (filas.length === 0) {
      swal('Seleccionar empleados', 'Selecciona empleados del grid (o cambia su Tipo defaulteo) para procesarlos.', 'warning');
      return;
    }
    const globalValido = this.tieneTipo(this.tipoDefaulteoGlobal);
    const layout = filas.map((f: any[]) => {
      const tipoFila = this.colVal(f, 'tipoDefaulteo');
      return {
        idEmpleado: this.colVal(f, 'Id'),
        idEmpresa: this.colVal(f, 'idEmpresa'),
        numeroEmpleado: this.colVal(f, 'numEmpleado'),
        tipoDefaulteo: this.tieneTipo(tipoFila) ? Number(tipoFila) : (globalValido ? Number(this.tipoDefaulteoGlobal) : null)
      };
    });
    const sinTipo = layout.filter((r: any) => r.tipoDefaulteo == null).length;
    if (sinTipo > 0) {
      swal('Falta tipo de defaulteo',
        sinTipo + ' empleado(s) seleccionado(s) no tienen tipo de defaulteo. Asigna el "Tipo asignación de planes" o cambia el tipo por renglón en el grid.',
        'warning');
      return;
    }
    const req = {
      idAdmin: this.identity ? this.identity.id : null,
      idVigencia: (this.idVigenciaSeleccionada == this.idVigenciaVigente ? 0 : this.idVigenciaSeleccionada),
      idVigenciaAnterior: this.idMultivigencia,
      idVigenciaVigente: this.idVigenciaVigente,
      condiciones: this.condicionesEspeciales,
      layout: layout
    };
    this.validarYConfirmarLote(req, 'seleccionado(s) del grid');
  }

  /**
   * CREA06 casos especiales (async): arranca el lote en background y hace polling del estado hasta
   * que termina, evitando el timeout del gateway/CDN con lotes grandes (cada empleado exitoso genera
   * su PDF via FOP). Al terminar delega en procesarResultadoEjecucion() para pintar el grid.
   */
  private ejecutarLoteCasosEspecialesAsync(req: any): void {
    this.progresoLote = { procesados: 0, total: (req.layout || []).length, estado: 'EN_PROCESO' };
    this._titularesService.ejecutarDefaulteoCasosEspecialesAsync(req, this.token).then(
      (ini: any) => {
        const idLog = ini && ini.idLog;
        if (!idLog || idLog <= 0) {
          this.ejecutandoLote = false;
          this.progresoLote = null;
          swal('Error', 'No se pudo iniciar el defaulteo. Revisa el log del backend.', 'error');
          return;
        }
        // Persistir el lote para poder reconectar el seguimiento si el operador sale y vuelve.
        this.guardarLoteEnCurso(idLog, this.progresoLote ? this.progresoLote.total : (req.layout || []).length);
        this.sondearEstadoLote(idLog);
      },
      (_err: any) => {
        this.ejecutandoLote = false;
        this.progresoLote = null;
        swal('Error', 'No se pudo iniciar el defaulteo. Revisa el log del backend.', 'error');
      }
    );
  }

  // CREA06 casos especiales (async): clave de localStorage y bandera de vida para el seguimiento del lote.
  private readonly LOTE_EN_CURSO_KEY = 'crea06_loteCasosEspecialesEnCurso';
  private componenteVivo = true;

  /** CREA06 casos especiales: poll del estado del lote cada ~2s hasta COMPLETADO/ERROR.
   *  reanudado = true cuando se retoma un lote guardado en localStorage tras volver a la pantalla. */
  private sondearEstadoLote(idLog: number, reanudado: boolean = false): void {
    if (!this.componenteVivo) { return; }  // instancia vieja tras salir de la pantalla: no seguir polleando
    this._titularesService.estadoDefaulteoCasosEspeciales(idLog, this.token).then(
      (st: any) => {
        if (!this.componenteVivo) { return; }
        const estado = st && st.estado;
        if (st) {
          this.progresoLote = {
            procesados: st.procesados || 0,
            total: st.totalEmpleados || (this.progresoLote ? this.progresoLote.total : 0),
            estado: estado
          };
        }
        if (estado === 'EN_PROCESO') {
          setTimeout(() => this.sondearEstadoLote(idLog, reanudado), 2000);
          return;
        }
        // Terminado (COMPLETADO / COMPLETADO_CON_ERRORES / ERROR / DESCONOCIDO): ya no hay lote que seguir.
        this.progresoLote = null;
        this.limpiarLoteEnCurso();
        if (estado === 'DESCONOCIDO') {
          // El lote ya no esta en memoria del backend (reinicio del servidor o pasaron >10 min desde que termino).
          this.ejecutandoLote = false;
          swal(
            'Lote no disponible en pantalla',
            reanudado
              ? 'El defaulteo ya no está disponible para mostrarse aquí (pudo haber terminado mientras no estabas). Verifica el resultado en las solicitudes generadas o en la bitácora.'
              : 'El defaulteo ya no está disponible en memoria. Verifica el resultado en las solicitudes generadas o en la bitácora.',
            'info'
          );
          return;
        }
        if (estado === 'ERROR' || !st || !st.resultado) {
          this.ejecutandoLote = false;
          swal('Error', 'No se pudo ejecutar el defaulteo. Revisa el log del backend.', 'error');
          return;
        }
        this.procesarResultadoEjecucion(st.resultado);
      },
      (_err: any) => {
        // Un poll fallido no aborta el lote (sigue corriendo en el backend); reintentamos.
        if (!this.componenteVivo) { return; }
        setTimeout(() => this.sondearEstadoLote(idLog, reanudado), 2500);
      }
    );
  }

  /** Guarda el lote en curso (por admin) para poder reconectar el seguimiento al volver a la pantalla. */
  private guardarLoteEnCurso(idLog: number, total: number): void {
    try {
      const idAdmin = this.identity ? this.identity.id : null;
      localStorage.setItem(this.LOTE_EN_CURSO_KEY, JSON.stringify({ idLog: idLog, total: total, idAdmin: idAdmin }));
    } catch (e) { /* localStorage no disponible: el seguimiento en vivo de esta sesion sigue funcionando */ }
  }

  /** Olvida el lote guardado (al terminar o quedar no disponible). */
  private limpiarLoteEnCurso(): void {
    try { localStorage.removeItem(this.LOTE_EN_CURSO_KEY); } catch (e) { /* no-op */ }
  }

  /** Si al entrar a la pantalla hay un lote guardado (de este admin), reconecta el polling para seguir
   *  mostrando el avance/resultado del defaulteo que quedo corriendo en el backend. */
  private reanudarLoteEnCursoSiExiste(): void {
    let guardado: any = null;
    try {
      const raw = localStorage.getItem(this.LOTE_EN_CURSO_KEY);
      guardado = raw ? JSON.parse(raw) : null;
    } catch (e) { guardado = null; }
    if (!guardado || !guardado.idLog) { return; }
    const idAdmin = this.identity ? this.identity.id : null;
    // Solo reanudar si es del mismo admin (no mostrar el lote de otra sesion/usuario en el mismo equipo).
    if (guardado.idAdmin != null && idAdmin != null && guardado.idAdmin !== idAdmin) { return; }
    this.ejecutandoLote = true;
    this.progresoLote = { procesados: 0, total: guardado.total || 0, estado: 'EN_PROCESO' };
    this.sondearEstadoLote(guardado.idLog, true);
  }

  /**
   * CREA06 casos especiales: pinta el resultado del lote en el grid (log por empleado + resumen).
   * Recibe { total, exitosos, errores, detalle } (mismo shape que devolvia el endpoint sincrono).
   */
  private procesarResultadoEjecucion(r: any): void {
          this.ejecutandoLote = false;
          // Corrida completada (con o sin errores de negocio): bloquea el boton hasta cargar otro layout.
          this.loteEjecutado = true;
          this.resumenEjecucion = { total: (r && r.total) || 0, exitosos: (r && r.exitosos) || 0, errores: (r && r.errores) || 0 };
          // CREA06: mapas id->nombre (plan + cobertura) desde las condiciones que el admin agrego (ya traen nombre).
          const condPorCobertura = new Map<string, { plan: string, cobertura: string }>();
          const nombrePlanPorId = new Map<string, string>();
          (this.condicionesEspeciales || []).forEach((c: any) => {
            const nomPlan = c.nombrePlan || ('Plan ' + c.idPlan);
            if (c.idPlan != null) { nombrePlanPorId.set(String(c.idPlan), nomPlan); }
            if (c.idCobertura != null) {
              condPorCobertura.set(String(c.idCobertura), { plan: nomPlan, cobertura: c.nombreCobertura || ('Cobertura ' + c.idCobertura) });
            }
          });
          // "Plan — Cobertura" de una cobertura forzada. Acepta el id (number) o el objeto
          // {id, nombrePlan, nombreCobertura} que ahora manda el backend (nombres resueltos para CUALQUIER
          // cobertura, no solo las forzadas en la UI). Fallback: condiciones de la UI o "Cobertura <id>".
          const etiquetaCob = (o: any) => {
            if (o && typeof o === 'object') {
              const plan = o.nombrePlan || '';
              const cob = o.nombreCobertura || '';
              if (plan && cob) { return plan + ' — ' + cob; }
              if (cob || plan) { return cob || plan; }
              const cc = condPorCobertura.get(String(o.id));
              return cc ? (cc.plan + ' — ' + cc.cobertura) : ('Cobertura ' + o.id);
            }
            const c = condPorCobertura.get(String(o));
            return c ? (c.plan + ' — ' + c.cobertura) : ('Cobertura ' + o);
          };
          const idDe = (o: any) => (o && typeof o === 'object') ? o.id : o;
          const motivoDe = (o: any) => (o && typeof o === 'object') ? (o.motivo || '') : '';

          this.logEjecucion = ((r && r.detalle) || []).map((d: any) => {
            // Aplicados: plan + cobertura forzados que SI se aplicaron.
            const aplicados: string[] = (d.forzadasAplicadas || []).map((o: any) => etiquetaCob(o));
            // No aplicados: cada uno con su motivo (cobertura no elegible, plan completo, o sin equivalencia por cambio de perfil).
            const noAplicados: { item: string, motivo: string }[] = [];
            (d.forzadasOmitidas || []).forEach((o: any) => noAplicados.push({ item: etiquetaCob(o), motivo: motivoDe(o) }));
            (d.planesOmitidos || []).forEach((o: any) => {
              const plan = nombrePlanPorId.get(String(idDe(o))) || ('Plan ' + idDe(o));
              noAplicados.push({ item: plan + ' (plan completo)', motivo: motivoDe(o) });
            });
            (d.coberturasSinEquivalencia || []).forEach((nombre: string) =>
              noAplicados.push({ item: nombre, motivo: 'Sin equivalencia en el nuevo perfil' }));
            // RF026-029: regla especial del plan de retiro (6 meses) — visibilidad destacada.
            const reglaRetiro = d.reglaRetiroAplicada ? {
              aplicada: true,
              mesesAntiguedad: d.mesesAntiguedad,
              mesesMinimos: d.mesesMinimosRetiro || 6,
              coberturas: d.coberturasRetiroRemovidasNombres || []
            } : null;
            // Observaciones a nivel del empleado. En pantalla y en el log mostramos un mensaje AMIGABLE
            // (POR QUE fallo, en lenguaje del operador). El "Detalle tecnico (soporte)" ahora lista cada
            // cobertura/plan rebotado con su motivo; antes se volcaba la clave interna
            // "RazonSocial_Num_error", que no aportaba nada y hacia el mensaje circular.
            // El "cambio de perfil" ya NO va aqui: se muestra como aviso destacado (azul) en la plantilla via l.cambioPerfil.
            let observaciones = '';
            let observacionesTec = '';
            if (!d.exito) {
              const tecCrudo = (d.mensaje || '').toString();
              // Detalle tecnico real: coberturas/planes no aplicados con su motivo.
              const detalleMotivos = noAplicados
                .filter(na => na && na.item)
                .map(na => na.motivo ? (na.item + ' (' + na.motivo + ')') : na.item)
                .join('; ');
              // La clave interna termina en "_ok"/"_error"; no aporta nada al operador -> se descarta.
              const esClaveInterna = /_(?:ok|error)\s*$/i.test(tecCrudo);
              observacionesTec = detalleMotivos || (esClaveInterna ? '' : tecCrudo);
              observaciones = this.mensajeAmigable(tecCrudo, noAplicados);
            }
            return {
              numeroEmpleado: d.numeroEmpleado,
              tipoDefaulteo: d.tipoDefaulteo,
              resultado: d.exito ? 'Correcto' : 'Incorrecto',
              cambioPerfil: !!d.cambioPerfil,
              reglaRetiro: reglaRetiro,
              aplicados: aplicados,
              noAplicados: noAplicados,
              observaciones: observaciones,
              observacionesTec: observacionesTec
            };
          });
          // Minuta 22-jun: una vez generado el resultado, limpiar el apartado de carga de layout.
          this.resetCargaLayout();
          swal({
            title: 'Ejecución finalizada',
            html: '<b>' + this.resumenEjecucion.total + '</b> procesado(s): <b>' + this.resumenEjecucion.exitosos
                + '</b> correcto(s) / <b>' + this.resumenEjecucion.errores + '</b> incorrecto(s).'
                + (this.resumenEjecucion.errores > 0
                    ? '<br><small>Revisa el detalle por empleado abajo y descarga el log para el detalle técnico.</small>'
                    : '<br><small>Revisa el detalle por empleado abajo.</small>'),
            type: this.resumenEjecucion.errores > 0 ? 'warning' : 'success'
          });
  }

  /** Descarga el log de resultados de la ejecucion como .xlsx. */
  /**
   * CREA06: traduce el resultado del backend a un mensaje entendible para el operador (POR QUE fallo).
   * Si el backend no manda un motivo claro (solo la clave interna "..._error"), resume el motivo real a
   * partir de las coberturas/planes no elegibles (candado del cotizador). El detalle por cobertura queda
   * en la columna "Detalle tecnico (soporte)" del log descargable.
   */
  private mensajeAmigable(tecnico: string, noAplicados?: { item: string, motivo: string }[]): string {
    const t = (tecnico || '').toLowerCase();
    // CREA06 (incidencias 1-4): los mensajes de validacion del backend ya son claros para el operador
    // (tipo inexistente, empleado no existe / no pertenece a la empresa, ya tiene solicitud); mostrarlos tal cual.
    if (t.indexOf('no existe') >= 0 || t.indexOf('no pertenece') >= 0
        || t.indexOf('ya tiene una solicitud') >= 0
        || t.indexOf('cambio de perfil') >= 0
        || t.indexOf('tipo de defaulteo') >= 0 || t.indexOf('tipo defaulteo') >= 0) {
      return tecnico;
    }
    if (t.indexOf('incorrect result size') >= 0 || t.indexOf('empty result') >= 0) {
      return 'El empleado no tiene una vigencia activa configurada; no se pudo generar la solicitud.';
    }
    if (t.indexOf('timeout') >= 0 || t.indexOf('deadlock') >= 0) {
      return 'El proceso tardó demasiado o la base estaba ocupada; vuelve a intentar.';
    }
    if (t.indexOf('null') >= 0 && (t.indexOf('perfil') >= 0 || t.indexOf('plan') >= 0)) {
      return 'El empleado no tiene perfil/plan configurado para esta vigencia.';
    }
    // Caso mas comun: el candado del cotizador rechazo TODAS las coberturas/planes forzados -> 0 elegibles
    // -> no se creo solicitud. El motivo real esta en las coberturas no aplicadas; se resume aqui en vez de
    // mandar al operador a un "detalle tecnico" que no aportaba nada (mensaje circular anterior).
    const rebotadas = (noAplicados || []).filter(na => na && na.item);
    if (rebotadas.length > 0) {
      return 'No se generó solicitud: ninguna de las ' + rebotadas.length
        + ' cobertura(s)/plan(es) es elegible para el perfil/condiciones del empleado (candado del cotizador): '
        + rebotadas.map(na => na.item).join(', ') + '.';
    }
    return 'No se pudo generar la solicitud.';
  }

  /**
   * CREA06 (incidencia 7): descripcion legible del tipo de defaulteo a partir del catalogo planesDefaulteo,
   * mismo criterio "id - Nombre" que ya usa la descarga de layout. Los usuarios finales no reconocen el ID
   * suelto, asi que en el log (pantalla y Excel) mostramos "id - Nombre". Si no esta en el catalogo, regresa
   * el id tal cual para no perder informacion.
   */
  public descTipoDefaulteo(id: any): string {
    if (id === null || id === undefined || id.toString().trim() === '') { return ''; }
    const t = (this.planesDefaulteo || []).find((x: any) => String(x.TDIdTipoDefaulteo) === String(id));
    return t ? (t.TDIdTipoDefaulteo + ' - ' + t.Nombre) : id.toString();
  }

  descargarLogEjecucion(): void {
    if (!this.logEjecucion || this.logEjecucion.length === 0) { return; }
    // CREA06 (incidencia 4): homologar el formato del Excel del log al del layout (encabezados con color/fuente,
    // bordes y anchos) usando ExcelJS (mismo patron que exportarLayout), en vez del volcado plano de SheetJS.
    const headers = ['NumeroEmpleado', 'TipoDefaulteo', 'Resultado', 'Aplicados',
      'No aplicados (motivo)', 'Observaciones', 'Detalle técnico (soporte)'];
    const workbook = new Workbook();
    const worksheet = workbook.addWorksheet('Log Defaulteo');

    // Encabezados con formato (identico al layout: fondo 4F81BD, fuente blanca bold, centrado)
    const headerRow = worksheet.addRow(headers);
    headerRow.eachCell((cell: any) => {
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '4F81BD' }, bgColor: { argb: '4F81BD' } };
      cell.font = { color: { argb: 'FFFFFF' }, bold: true, name: 'Calibri' };
      cell.alignment = { horizontal: 'center' };
    });

    const s = (v: any): string => (v === null || v === undefined) ? '' : v.toString();
    this.logEjecucion.forEach(l => {
      const aplicados = (l.aplicados || []).join('; ');
      const noAplicados = (l.noAplicados || []).map((na: any) => na.item + (na.motivo ? (' (' + na.motivo + ')') : '')).join('; ');
      let obs = (l.observaciones || '').toString();
      if (l.reglaRetiro && l.reglaRetiro.aplicada) {
        const retiro = 'Plan de retiro NO aplicado (antiguedad ' + l.reglaRetiro.mesesAntiguedad
          + ' mes(es) < ' + l.reglaRetiro.mesesMinimos + '): ' + (l.reglaRetiro.coberturas || []).join(', ');
        obs = obs ? (retiro + ' | ' + obs) : retiro;
      }
      // CREA06 (incidencia 7): en el Excel tambien la descripcion del tipo de defaulteo, no solo el ID.
      const row = worksheet.addRow([
        s(l.numeroEmpleado), this.descTipoDefaulteo(l.tipoDefaulteo), s(l.resultado),
        aplicados, noAplicados, obs, s(l.observacionesTec)
      ]);
      row.eachCell((cell: any) => { cell.border = { bottom: { style: 'thin', color: { argb: 'DDE0E3' } } }; });
    });

    // Anchos por columna (las de texto largo mas anchas).
    const anchos = [16, 22, 12, 40, 48, 48, 40];
    worksheet.columns.forEach((col: any, i: number) => { col.width = anchos[i] || 16; });

    const nombre = 'Log_Defaulteo_Casos_Especiales_' + this.logEjecucion.length + '.xlsx';
    workbook.xlsx.writeBuffer().then((buf: any) => {
      const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      FileSaver.saveAs(blob, nombre);
    });
  }

  vaciarDatosTitu() {
    if (this.datosTitul != null) {
      this.datosTabla = [];
      this.datosTabla = this.datosTitul;
      this.empleadosSeleccionados=[];
      console.log("Empleados seleccionados", this.empleadosSeleccionados);
      this.seccionDefaulteo = 'block';
      this.collectionSize = this.datosTabla.length;

    }else{
      this.empleadosSeleccionados=[];
      this.seccionDefaulteo='none';
    }
  }

  defaultearEmpleadosSeleccionadosModal(modal,fila?){
   
   
   let idEmpleado = [];
   let numEmpleado = [];
   let empresas = [];
   let url = "";
    console.log(this.empleadosSeleccionados);


    for(let i = 0; i <this.empleadosSeleccionados.length; i++){
      for(let j = 0; j < this.empleadosSeleccionados[i].length; j++){

        if(this.empleadosSeleccionados[i][j].key == "Id"){
          idEmpleado.push(this.empleadosSeleccionados[i][j].value);
        }
        if(this.empleadosSeleccionados[i][j].key == "numEmpleado"){
          numEmpleado.push(this.empleadosSeleccionados[i][j].value);
        }
        
        if(this.empleadosSeleccionados[i][j].key == "idEmpresa"){
          empresas.push(this.empleadosSeleccionados[i][j].value);
        }

      }
    }


    let defaulteo;
    switch(+this.tipoDefaulteo){
      case 1:
        defaulteo = 'def1';
        break;
      case 2:
        defaulteo = 'def2';
        break;
      case 3:
        defaulteo = 'def3';
        break;

    }

    if(this.idVigenciaSeleccionada == this.idVigenciaVigente){
      
          this._http.post(`${GLOBAL.url}titulares/defaultearMasivo`,
          {
            "idEmpleado":idEmpleado,
            "numEmpleado":numEmpleado,
            "idEmpresa": empresas,
            "idVigencia":0,
            "idVigenciaAnterior":0,
            "tipoDefaulteo":defaulteo,
            "tmpplanesseleccionados":'{"costo": null,"idempleado": -1,"nuevo": null,"tcidtarifacosto": -1}',
            "tmpplanesseleccionadosold":'{"costoOld": null,"idempleadoOld": -1,"nuevoOld": null,"tcidtarifacostoOld": -1}',
            "idAdmin":this.identity.id,
            "idVigenciaVigente":this.idVigenciaVigente
          }
            ).subscribe(response => {
            console.log("RESPUESTA DEFAULTEO MASIVO", response);
            if(JSON.parse(localStorage.getItem('identity'))){

              this.componentBlock= true;
              this.reporte = this.construirDatosLog(response);
              let modalReporteAux
              this.fila = null;
              this.modal.close();
              this.restaurarSeccionDefaulteo();
              this.modal = null;
              this.ejecutando =false;
              // alert(this.reporte);
              // this.reporte=[]; 
              modalReporteAux = this._modalService.open(this.modalReporteElement, { backdrop : 'static', keyboard: false ,windowClass: 'confirmacionModal2', centered: true });
              this.modalReporte = modalReporteAux; 
              let tiposDefaulteoSelect: HTMLSelectElement = this.inputEl.nativeElement;
              tiposDefaulteoSelect.selectedIndex = 0;

            }
            let encabezadosLog = ["Empresa"," Número de Empleado", "Mensaje"];
            let datos = this.construirDatosExcel(response);
            this.generarExcel(datos, encabezadosLog, this.colocarFechaAlNombre("ReporteDefaulteo"));
          }, error => {})
            
    }else{
      
      this._http.post(`${GLOBAL.url}titulares/defaultearMasivo`,
      {
        "idEmpleado":idEmpleado,
        "numEmpleado":numEmpleado,
        "idEmpresa": this.identity.idEmpresa,
        "idVigencia":this.idVigenciaSeleccionada,
        "idVigenciaAnterior":this.idMultivigencia,
        "tipoDefaulteo":defaulteo,
        "tmpplanesseleccionados":'{"costo": null,"idempleado": -1,"nuevo": null,"tcidtarifacosto": -1}',
        "tmpplanesseleccionadosold":'{"costoOld": null,"idempleadoOld": -1,"nuevoOld": null,"tcidtarifacostoOld": -1}',
        "idAdmin":this.identity.id,
        "idVigenciaVigente":this.idVigenciaVigente
      }
      ).subscribe(response => {
        console.log("RESPUESTA DEFAULTEO MASIVO", response);
        if(JSON.parse(localStorage.getItem('identity'))){
          this.componentBlock= true;
          this.reporte = this.construirDatosLog(response);
          let modalReporteAux  
          this.fila = null;
          this.modal.close();
          this.restaurarSeccionDefaulteo();
          this.modal = null;
          this.ejecutando =false;
          // alert(this.reporte);
          // this.reporte=[];
          modalReporteAux = this._modalService.open(this.modalReporteElement, {  backdrop : 'static', keyboard: false ,windowClass: 'confirmacionModal2', centered: true });
          this.modalReporte = modalReporteAux;
          let tiposDefaulteoSelect: HTMLSelectElement = this.inputEl.nativeElement;
          tiposDefaulteoSelect.selectedIndex = 0
        }
        let encabezadosLog = ["Empresa"," Número de Empleado", "Mensaje"];
        let datos = this.construirDatosExcel(response);
        this.generarExcel(datos, encabezadosLog, this.colocarFechaAlNombre("ReporteDefaulteo"));
      }, error => {})
    }   
  }

  /********************************************************************************** */
  /* METODOS PROVISIONALES PARA ENVIO DE NOTIFICACIONES Y ENVIO DEL LOG DE RESULTADOS */
  /********************************************************************************** */

  public generarExcel(datos, header, nombre) {
    let workbook = this._excelService.generarLogDefaulteo(header, datos, nombre);

    workbook.xlsx.writeBuffer().then((archivo: any) => {
      const blob = new Blob([archivo], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      //FileSaver.saveAs(blob, nombre);
      this.crearCorreo(blob, nombre);
    });
  }

  public construirDatosExcel(datos): string[]{
    let resultados:string[] = [];
    datos.forEach(dato => {
      let partes = dato.split("_");
      //Provisionalmente se esperan 3 datos
      resultados.push(partes);
    });
    return resultados;
  }

  public construirDatosLog(datos): any[]{
    let resultados:any[] = [];
    datos.forEach(dato => {
      let partes = dato.split("_");
      //Provisionalmente se esperan 3 datos
      resultados.push("Empresa: " + partes[0] + " Número de Empleado: " + partes[1] + " Mensaje: " + partes[2]);
    });
    return resultados;
  }

  public crearCorreo(archivo, nombreArchivo) {

    var contenido = this.plantillaCorreo;
    var subject = "Notificación resultado de asignación de planes.";
    var tipoNotificacion = "Notificación resultado de asignación de planes.";
    //subject = subject.replace('#Empresa ', this.identity.nomEmpresa);
    contenido = contenido.replace("#TipoNotificacion", tipoNotificacion);
    contenido = contenido.replace('#Administrador', this.correo.nombre);
    contenido = contenido.replace('#Accion', "Defaulteo Masivo");
    contenido = contenido.replace("#Fecha", this.datePipe.transform(new Date(), "dd/MM/yyyy HH:mm"));

    var file = new File([archivo], nombreArchivo);
    var form = new FormData();
    form.append("file", file);
    this._empleadoService.sendMailUnificado(this.correoAdmin, this.correosCopia, '', subject, contenido, '', form, '', '', 14, this.token).
      then((res) => {
        //swal('¡Correo Enviado!', '', 'success');
        console.log(res['ok'] ? '¡Correo Enviado!' : '¡Error al enviar correo!');
      }, error => {
        console.log(error);
      });

  }

  restaurarSeccionDefaulteo(inputBuscar?){
    this.seccionDefaulteo = 'none';
    this.empleadosSeleccionados = [];
    this.datosTabla = [];
    // this.componentBlock= false;
    this.procesoEnEjecucion = true;
    this.procesoFinalizado = false;
    // this.valorBusqueda = null;
    // if(inputBuscar)
    //   inputBuscar.value = '';
    let tiposDefaulteoSelect: HTMLSelectElement = this.inputEl.nativeElement;
    tiposDefaulteoSelect.selectedIndex = 0;
    this.msjNoHayDatos = false;
    this.existenDatosTabla = false;
  }
  
  public getDatosCorreo(): void {
    this._empleadoService.getDatos(this.identity).then((datos: any) => {
      if (this.identity.clave != "") {
        this.correo.correo = datos.emCorreoElectronico;
        this.correo.nombre = datos.emNombre1 ? datos.emNombre1 : "";
        this.correo.nombre += datos.emNombre2 ? " " + datos.emNombre2 : "";
        this.correo.nombre += datos.emApellidoPaterno ? " " + datos.emApellidoPaterno : "";
        this.correo.nombre += datos.emApellidoMaterno ? " " + datos.emApellidoMaterno : "";
        this.correoAdmin = !datos.emCorreoElectronico || datos.emCorreoElectronico == "" ?  
        "beflex@mx.lockton.com" : datos.emCorreoElectronico.trim();
        if (!datos.emCorreoElectronico || datos.emCorreoElectronico == "") {
          swal({
            title: '¡Aviso, no se cuenta con un correo electrónico registrado!',
            html: `<small clas="text-dark">Correo: "${datos.emCorreoElectronico}"</small>`,
            type: 'warning',
            confirmButtonText: 'Aceptar',
            timer: 3000
          });
        }
      }
    });
  }

  getCorreosParaCopiaAdmin( idEmpresa = this.identity.idEmpresa){
    this.correosCopia = "";
    this._docPerService.getCorreosAdmin(idEmpresa, this.token).then(
      response => {
        if (response.length > 0) {
          response.forEach(
            correo => {
              this.correosCopia += correo + ",";
            }
          );
        }
      }
    );
  }

  colocarFechaAlNombre(nombreArch: any) {
    const f = new Date();
    let nombre = `${nombreArch}${f.getFullYear()}`;
    let mes;
    let m;
    m = (f.getMonth() < 10) ? `0${f.getMonth()}` : f.getMonth();
    mes = parseInt(m) + 1;
    nombre += (f.getMonth() < 10) ? `0${mes}` : mes;
    nombre += (f.getDate() < 10) ? `0${f.getDate()}` : f.getDate();
    nombre += (f.getHours() < 10) ? `0${f.getHours()}` : f.getHours();
    nombre += (f.getMinutes() < 10) ? `0${f.getMinutes()}` : f.getMinutes();
    nombre += (f.getSeconds() < 10) ? `0${f.getSeconds()}` : f.getSeconds();
    nombre += '.xlsx';
    return nombre;
  }

  public async obtenerEmpresas() {
    try {
      const empresas = [];
      const response: any = await this._empresaService.getComboLogin(this.identity.idCorporativo, this.token);
      if (response) {
        response.forEach(element => empresas.push(element.emidEmpresa));
      }
      this.crearArbolEmpresas(empresas);
    } catch (error) { }
  }

  /* Arbol: Empresa - Perfil */
  public async crearArbolEmpresas(empresas: any[]) {
    try {
      const response: any = await this._BitacoraService.getEmpPerfil(empresas, this.token);
      if (response != null && response != undefined && response.length > 0) {
        const datos = [];
        response.forEach(empresa => {
          const hojas = [];
          empresa.perfiles.forEach(perfil => {
            const hoja = { 'id': perfil.idPerfil, 'name': perfil.nombrePerfil.toUpperCase(), 'child': null, 'selected': false };
            hojas.push(hoja);
          });
          const rama = { 'id': empresa.idEmpresa, 'name': empresa.nombreEmpresa.toUpperCase(), 'child': hojas, 'selected': false };
          datos.push(rama);
          this.parametrosBusqueda.idEmpresas.push(empresa.idEmpresa);
        });
        datos.forEach(padre => padre.child.forEach(hijo => Object.assign(hijo, { 'selected': true })));

        const hojasPadre = { 'id': 0, 'name': 'TODOS', 'child': datos, 'selected': false, 'expandable': false };
        this.arbol = [];
        this.arbol.push(hojasPadre);
      }
    } catch (error) { }
  }

  validarEmpresasAsignar() {
    this.arbol.forEach(padre => {
      padre.child.forEach(empresa => {
        empresa.child.forEach(perfil => {
          if (this.parametrosBusqueda.perfiles.includes(perfil.id) && !this.parametrosBusqueda.idEmpresas.includes(empresa.id)) {
            this.parametrosBusqueda.idEmpresas.push(empresa.id);
          }
        });
      });
    });
  }

  obtenerEmpresasPerfilesSeleccionados() {
    this.parametrosBusqueda.idEmpresas = [];
    this.parametrosBusqueda.perfiles = [];
    this.seleccionArbol.forEach(entry => {
      switch (entry.level) {
        case 1:
          this.parametrosBusqueda.idEmpresas.push(entry.id);
          break;
        case 2:
          this.parametrosBusqueda.perfiles.push(entry.id);
          break;
        default:
          break;
      }
    });
    this.validarEmpresasAsignar();
  }

  public seleccionEmpresa(event) {
    this.seleccionArbol = event;
    this.parametrosBusqueda.idEmpresas = [];
    this.obtenerEmpresasPerfilesSeleccionados();
    if (this.parametrosBusqueda.idEmpresas.length == 0) { // Valida lista empresas
      this.errorRep.empresas = true;
      this.validRep.empresas = false;
    } else {
      this.errorRep.empresas = false;
      this.validRep.empresas = true;
    }
    if (this.parametrosBusqueda.perfiles.length == 0) { // Valida lista de perfiles
      this.errorRep.perfiles = true;
      this.validRep.perfiles = false;
    } else {
      this.errorRep.perfiles = false;
      this.validRep.perfiles = true;
    }
  }

  public inicializarFormularioBusqueda(){
    this.parametrosBusqueda = {
      idEmpresas: [],
      perfiles: [],
      idAtributo1: 'EMNumeroEmpleado',
      idTipoOperador1: 'contiene',
      parametroBusqueda1: '',
      idTipoOperadorAvanzado: 'and',
      idAtributo2: 'EMNumeroEmpleado',
      idTipoOperador2: 'contiene',
      parametroBusqueda2: '',
      idEstatus: ['Rechazada','Autorizada','Por Autorizar','Cancelada'],
      idVigencia: 0,
      BusquedaAvanzada:0
    };
  }

  public reiniciarFormularioBusqueda(){
    this.esBusquedaAvanzada = false;
    this.parametrosBusqueda.idTipoOperadorAvanzado = 'and';
    this.parametrosBusqueda.idAtributo1 = 'EMNumeroEmpleado';
    this.parametrosBusqueda.idAtributo2 = 'EMNumeroEmpleado';
    this.parametrosBusqueda.idTipoOperador1 = 'contiene';
    this.parametrosBusqueda.idTipoOperador2 = 'contiene';
    this.parametrosBusqueda.parametroBusqueda1 = '';
    this.parametrosBusqueda.parametroBusqueda2 = '';
    this.parametrosBusqueda.idEstatus = ['Rechazada','Autorizada','Por Autorizar','Cancelada'];
    this.restaurarSeccionDefaulteo();
  }
  validarInput(parametro: string) {
      const regexpNumber = new RegExp('^[\u00F1\u00D1 A-ZÁ-Üa-zá-ü .]+$');
      const regexpNumber2 = new RegExp('^[a-zA-Z0-9]+$');
      if (this.busquedaPor != 'EMNumeroEmpleado' && parametro.length > 0) {
        if (regexpNumber.test(parametro)) {
          this.errorRep.parametroBusqueda1 = false;
        } else {
          this.errorRep.parametroBusqueda1 = true;
        }
      } else {
        if (this.busquedaPor == 'EMNumeroEmpleado' && parametro.length > 0) {
          if (regexpNumber2.test(parametro)) {
            this.errorRep.parametroBusqueda1 = false;
          } else {
            this.errorRep.parametroBusqueda1 = true;
          }
        } else {
          this.errorRep.parametroBusqueda1 = false;
        }
      }
    }
  
    cambiarBuscarPor(busquedaPor: string, valorBusqueda: string) {
      this.busquedaPor = this.parametrosBusqueda.idAtributo1;
      this.validarInput(valorBusqueda);
    }

    // Metodo de busqueda
    busquedaAvanzada() {
      this.page = 1;
      this.pageSize = 5;
      this.collectionSize = 0;
      this.empleadosSeleccionados = [];
      this.datosTabla = [];
      this.errorEntrada  = false;
      this.componentBlock= true;
      this.existenDatosTabla = false;
      this.msjNoHayDatos = false;
      this.seccionDefaulteo='none';
      // CREA06 (incidencia 5): no arrastrar el log/resumen/layout del proceso anterior al re-buscar.
      this.resetCasosEspecialesLog();

      this.parametrosBusqueda.idVigencia = this.idVigenciaSeleccionada;

      let estatus = true;
      if(!this.validarParametros(1)){
        estatus = false;
        this.errorEntrada = true;
        this.componentBlock= false;
      }
      if(this.esBusquedaAvanzada && (!this.validarParametros(2))){
        estatus = false;
        this.errorEntrada = true;
        this.componentBlock= false;
      }

      if (estatus) {
        this.consultaSolicitudesAvanzado();
      }else{
        this.restaurarSeccionDefaulteo();
        swal({
          title: '¡Atención!',
          html: 'Los parámetros de búsqueda no son válidos, no se permiten caracteres especiales y campos vacíos.',
          type: 'warning',
          confirmButtonText: 'Aceptar',
          showConfirmButton: true,
          onOpen: () => {
            swal.hideLoading();
          }
        });
      }
    }
  
    // Validacion de campos de parametro
    public validarParametros(idCampo) {
      let parametrosValidos = true;
      const buscar = idCampo === 1 ? this.parametrosBusqueda.parametroBusqueda1 : this.parametrosBusqueda.parametroBusqueda2;
      const campoAtributo = idCampo === 1 ? this.parametrosBusqueda.idAtributo1 : this.parametrosBusqueda.idAtributo2;
  
      if(!this.validaContenidoParametroBusqueda(buscar, campoAtributo, idCampo)){
        parametrosValidos = false;
        if(idCampo === 1){
          this.errorRep.parametroBusqueda1 = true;
        }else{
          this.errorRep.parametroBusqueda2 = true;
        }
      }else{
        if(idCampo === 1){
          this.errorRep.parametroBusqueda1 = false;
        }else{
          this.errorRep.parametroBusqueda2 = false;
        }
      }
      return parametrosValidos;
    }
    validaContenidoParametroBusqueda(contenido: string, parametro: string, idCampo: number){
      const regexpCampo  = new RegExp('^[\u00F1\u00D1A-ZÁ-Üa-zá-ü .]+$');
      const regexpNumber2 = new RegExp('^[\u00F1\u00D1A-ZÁ-Üa-zá-ü0-9.]+$');
      let esValido = true;
  
      // Comprobar contenido de parametros
      if(!(idCampo === 1 && contenido.trim() === '' && !this.esBusquedaAvanzada)){
        if (contenido === null || contenido === '' || contenido.length === 0 || parametro === '') {
          esValido =  false;
        }else{
          if(parametro === "EMNumeroEmpleado"){ // Validar campo de numero de empleado
            if (!regexpNumber2.test(contenido)) {
              esValido =  false;
            }
          }else{ // Validar campos distintos a numero de empleado
            if (!regexpCampo.test(contenido)) {
              esValido =  false;
            }
          }
        }
      }
      return esValido;
    }

    public async consultaSolicitudesAvanzado() {
      if(this.parametrosBusqueda.idEmpresas.length === 0) {
        this.restaurarSeccionDefaulteo();
        swal({
          title: '¡Alto!',
          html: 'Selecciona al menos una empresa.',
          type: 'error',
          confirmButtonText: 'Aceptar',
          showConfirmButton: true,
          onOpen: () => {
            swal.hideLoading();
          }
        });
        this.loadEditar = false
        return;
      }
      try {
        this.getTitularesMultivigencia();
      } catch (error) {
        this.loadEditar = false;
        this.restaurarSeccionDefaulteo();
      }
    }

}
export interface IBusquedaRequest {
    idEmpresas: number[],
    perfiles: number[],
    idAtributo1: string,
    idTipoOperador1: string,
    parametroBusqueda1: string,
    BusquedaAvanzada: number,
    idTipoOperadorAvanzado: string,
    idAtributo2: string,
    idTipoOperador2: string,
    parametroBusqueda2: string,
    idEstatus: any[],
    idVigencia: number
}

