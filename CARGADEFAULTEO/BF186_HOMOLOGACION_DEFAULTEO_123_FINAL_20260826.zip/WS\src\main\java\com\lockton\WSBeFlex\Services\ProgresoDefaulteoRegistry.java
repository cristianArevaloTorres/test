package com.lockton.WSBeFlex.Services;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

/**
 * CREA 06 - Registro EN MEMORIA del progreso de cada lote de defaulteo que se
 * esta ejecutando en background. Permite que el endpoint de estado responda el
 * avance (procesados / total) mientras el lote corre, sin pegarle a la BD en
 * cada poll. Al finalizar, el estado autoritativo queda persistido en
 * bf_LogDefaulteo; este registro solo vive mientras el JVM esta arriba.
 *
 * Estados: EN_PROCESO | COMPLETADO | COMPLETADO_CON_ERRORES | ERROR
 */
@Component
public class ProgresoDefaulteoRegistry {

    public static final String EN_PROCESO              = "EN_PROCESO";
    public static final String COMPLETADO              = "COMPLETADO";
    public static final String COMPLETADO_CON_ERRORES  = "COMPLETADO_CON_ERRORES";
    public static final String ERROR                   = "ERROR";

    /** Cuanto tiempo conservamos un lote ya finalizado en memoria (ms). */
    private static final long TTL_FINALIZADO_MS = 10L * 60L * 1000L; // 10 min

    public static class Progreso {
        public volatile int total;
        public volatile int procesados;
        public volatile int exitosos;
        public volatile int errores;
        public volatile String estado = EN_PROCESO;
        public volatile Integer idEmpleadoActual;
        public volatile long finMs; // 0 mientras EN_PROCESO
        // CREA06 Casos Especiales: resultado completo del lote (mapa {total,exitosos,errores,detalle,...})
        // que el grid necesita al terminar. Solo se llena en el flujo casos especiales (async).
        public volatile Object resultado;
    }

    private final Map<Integer, Progreso> mapa = new ConcurrentHashMap<>();

    public void iniciar(int idLog, int total) {
        Progreso p = new Progreso();
        p.total = total;
        p.estado = EN_PROCESO;
        mapa.put(idLog, p);
    }

    public void marcarEmpleadoActual(int idLog, Integer idEmpleado) {
        Progreso p = mapa.get(idLog);
        if (p != null) { p.idEmpleadoActual = idEmpleado; }
    }

    public void incrementar(int idLog, boolean exito) {
        Progreso p = mapa.get(idLog);
        if (p != null) {
            p.procesados++;
            if (exito) { p.exitosos++; } else { p.errores++; }
        }
    }

    public void finalizar(int idLog, String estado) {
        Progreso p = mapa.get(idLog);
        if (p != null) {
            p.estado = estado;
            p.idEmpleadoActual = null;
            p.finMs = System.currentTimeMillis();
        }
        limpiarVencidos();
    }

    /**
     * CREA06 Casos Especiales: guarda el resultado completo del lote (con el
     * detalle por empleado) para que el endpoint de estado lo devuelva al grid
     * cuando el lote termine. Es null-safe si el lote no esta en memoria.
     */
    public void setResultado(int idLog, Object resultado) {
        Progreso p = mapa.get(idLog);
        if (p != null) { p.resultado = resultado; }
    }

    /** Snapshot para el endpoint de estado; null si el lote no esta en memoria. */
    public Map<String, Object> snapshot(int idLog) {
        Progreso p = mapa.get(idLog);
        if (p == null) { return null; }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("idLog",            idLog);
        m.put("estado",           p.estado);
        m.put("totalEmpleados",   p.total);
        m.put("procesados",       p.procesados);
        m.put("totalExitosos",    p.exitosos);
        m.put("totalErrores",     p.errores);
        m.put("idEmpleadoActual", p.idEmpleadoActual);
        m.put("enMemoria",        Boolean.TRUE);
        // CREA06 Casos Especiales: cuando el lote termino, adjuntar el detalle
        // por empleado que el grid necesita para pintar el resultado.
        if (p.resultado != null) { m.put("resultado", p.resultado); }
        return m;
    }

    /** Descarta lotes finalizados hace mas de TTL para no crecer sin limite. */
    private void limpiarVencidos() {
        long ahora = System.currentTimeMillis();
        mapa.entrySet().removeIf(e -> {
            Progreso p = e.getValue();
            return p.finMs > 0 && (ahora - p.finMs) > TTL_FINALIZADO_MS;
        });
    }
}
