import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GLOBAL } from './global';

export interface DefaulteoTitularesHistorico {
  idEmpresa: number;
  numeroEmpleado: string;
  nombreEmpleado: string;
  costoAnual: number;
  idUsuario: number;
  fechaDefaulteo: string;
}

@Injectable({ providedIn: 'root' })
export class DefaulteoTitularesHistoricoService {

  constructor(private http: HttpClient) { }

  consultar(idEmpresa: number, fechaInicio: string, fechaFin: string, token: string): Promise<DefaulteoTitularesHistorico[]> {
    const params = new HttpParams()
      .set('idEmpresa', String(idEmpresa))
      .set('fechaInicio', fechaInicio)
      .set('fechaFin', fechaFin);
    const headers = new HttpHeaders({ authorization: token });

    return this.http.get<DefaulteoTitularesHistorico[]>(
      `${GLOBAL.url5}defaulteo/historico`,
      { headers, params }
    ).toPromise();
  }
}
