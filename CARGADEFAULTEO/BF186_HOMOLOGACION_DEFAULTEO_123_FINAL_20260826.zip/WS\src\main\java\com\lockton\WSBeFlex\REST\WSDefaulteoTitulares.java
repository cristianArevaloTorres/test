package com.lockton.WSBeFlex.REST;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import com.lockton.WSBeFlex.Services.FfDefaulteoAvanzadoService;
import com.lockton.WSBeFlex.Services.FfTitularService;
import com.lockton.WSBeFlex.Services.GeneralesService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.UsuarioToken;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Endpoints exclusivos de la pantalla nueva
 * /pages/administracion/titulares/defaulteo.
 *
 * La pantalla original conserva sus contratos. Esta fachada protege la
 * consulta guiada antes de reutilizar bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado,
 * cuyo contrato recibe atributos y operadores como texto.
 */
@RestController
@RequestMapping("beflex/defaulteo-titulares")
public class WSDefaulteoTitulares {

    private static final Log bitacora = LogFactory.getLog(WSDefaulteoTitulares.class);

    private static final Set<String> ATRIBUTOS = new LinkedHashSet<>(Arrays.asList(
            "EMNumeroEmpleado", "EMNombre1", "EMNombre2",
            "EMApellidoPaterno", "EMApellidoMaterno"));
    private static final Set<String> OPERADORES = new LinkedHashSet<>(Arrays.asList(
            "contiene", "igual", "noigual", "iniciapor", "terminapor", "nocontiene"));
    private static final Set<String> OPERADORES_LOGICOS = new LinkedHashSet<>(Arrays.asList("and", "or"));
    private static final Pattern PARAMETRO = Pattern.compile("^[\\p{L}\\p{N} ._-]{0,100}$");

    @Autowired
    private FfTitularService titularService;

    @Autowired
    private FfDefaulteoAvanzadoService seguridadDefaulteo;

    @Autowired
    private GeneralesService generalService;

    @Autowired
    private JwtService jwtService;

    @PostMapping("/buscar-guiado")
    public ResponseEntity<List<Object>> buscarGuiado(
            @RequestBody Map<String, Object> requestBody,
            @RequestHeader(value = "authorization", required = false) String token) {

        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        SolicitudGuiada solicitud = validarYNormalizar(requestBody);
        if (solicitud == null) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        if (!seguridadDefaulteo.tieneAccesoEmpresas(usuario.n, solicitud.idsEmpresa)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }

        requestBody.put("IdsEmpresas", toCsv(solicitud.idsEmpresa));
        requestBody.put("idPerfiles", toCsv(solicitud.idsPerfil));
        requestBody.put("IdAdministrador", usuario.n);
        requestBody.put("Vigencia", solicitud.idVigencia);
        // Esta fachada es exclusiva de la operacion guiada normal. Evita que
        // un valor adicional enviado por el cliente cambie al SP de casos
        // especiales, que tiene otro contrato y otra pantalla.
        requestBody.put("CasosEspeciales", "0");

        try {
            List<Object> resultado = titularService.busquedaDefaulteoAvanzada(requestBody);
            if (resultado == null || resultado.isEmpty()) {
                return new ResponseEntity<>(resultado, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(resultado, HttpStatus.OK);
        } catch (Exception ex) {
            bitacora.error("[DEFAULTEO_TITULARES] buscar-guiado: " + ex.getMessage(), ex);
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
    }

    private UsuarioToken usuarioAutenticado(String token) {
        try {
            if (token == null || !generalService.validarTokenId(0, token, 4)) {
                return null;
            }
            UsuarioToken usuario = jwtService.getPayloadFromToken(token);
            return usuario != null && usuario.n > 0 ? usuario : null;
        } catch (Exception ex) {
            return null;
        }
    }

    private SolicitudGuiada validarYNormalizar(Map<String, Object> body) {
        if (body == null) return null;

        int[] empresas = csvEnterosPositivos(body.get("IdsEmpresas"));
        int[] perfiles = csvEnterosPositivos(body.get("idPerfiles"));
        Integer vigencia = enteroPositivo(body.get("Vigencia"));
        Integer avanzada = entero(body.get("BusquedaAvanzada"));
        String atributo1 = texto(body.get("idAtributo1"));
        String atributo2 = texto(body.get("idAtributo2"));
        String operador1 = texto(body.get("idTipoOperador1"));
        String operador2 = texto(body.get("idTipoOperador2"));
        String operadorLogico = texto(body.get("idTipoOperadorAvanzado")).toLowerCase();
        String parametro1 = texto(body.get("parametroBusqueda1"));
        String parametro2 = texto(body.get("parametroBusqueda2"));

        if (empresas.length == 0 || perfiles.length == 0 || vigencia == null
                || avanzada == null || (avanzada != 0 && avanzada != 1)
                || !ATRIBUTOS.contains(atributo1) || !ATRIBUTOS.contains(atributo2)
                || !OPERADORES.contains(operador1) || !OPERADORES.contains(operador2)
                || !OPERADORES_LOGICOS.contains(operadorLogico)
                || !PARAMETRO.matcher(parametro1).matches()
                || !PARAMETRO.matcher(parametro2).matches()
                || (avanzada == 1 && parametro2.trim().isEmpty())) {
            return null;
        }

        body.put("idAtributo1", atributo1);
        body.put("idAtributo2", atributo2);
        body.put("idTipoOperador1", operador1);
        body.put("idTipoOperador2", operador2);
        body.put("idTipoOperadorAvanzado", operadorLogico);
        body.put("parametroBusqueda1", parametro1.trim());
        body.put("parametroBusqueda2", parametro2.trim());
        body.put("BusquedaAvanzada", avanzada);
        return new SolicitudGuiada(empresas, perfiles, vigencia);
    }

    private int[] csvEnterosPositivos(Object valor) {
        String csv = texto(valor);
        if (csv.trim().isEmpty()) return new int[0];
        Set<Integer> unicos = new LinkedHashSet<>();
        for (String parte : csv.split(",")) {
            Integer id = enteroPositivo(parte);
            if (id == null) return new int[0];
            unicos.add(id);
        }
        List<Integer> lista = new ArrayList<>(unicos);
        int[] resultado = new int[lista.size()];
        for (int i = 0; i < lista.size(); i++) resultado[i] = lista.get(i);
        return resultado;
    }

    private Integer enteroPositivo(Object valor) {
        Integer numero = entero(valor);
        return numero != null && numero > 0 ? numero : null;
    }

    private Integer entero(Object valor) {
        try {
            if (valor instanceof Number) return ((Number) valor).intValue();
            String s = texto(valor).trim();
            return s.isEmpty() ? null : Integer.valueOf(s);
        } catch (Exception ex) {
            return null;
        }
    }

    private String texto(Object valor) {
        return valor == null ? "" : String.valueOf(valor);
    }

    private String toCsv(int[] valores) {
        StringBuilder csv = new StringBuilder();
        for (int i = 0; i < valores.length; i++) {
            if (i > 0) csv.append(',');
            csv.append(valores[i]);
        }
        return csv.toString();
    }

    private static final class SolicitudGuiada {
        private final int[] idsEmpresa;
        private final int[] idsPerfil;
        private final int idVigencia;

        private SolicitudGuiada(int[] idsEmpresa, int[] idsPerfil, int idVigencia) {
            this.idsEmpresa = idsEmpresa;
            this.idsPerfil = idsPerfil;
            this.idVigencia = idVigencia;
        }
    }
}
