import { Component, OnInit, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/observable/fromEvent';
import swal from 'sweetalert2';

import { GLOBAL } from '../../../../services/global';
import { crearbeneficiario } from '../../../../models/crearbeneficiario';
import { parametrosAsegurado } from '../../../../models/parametrosAsegurado';
import { beneficiarioSustituto } from '../../../../models/sustituo';
import { borrarbeneficiario } from '../../../../models/borrarbeneficiario';
import { BeneficiarioService } from '../../../../services/beneficiario.service';
import { EmpleadoService } from '../../../../services/empleado.service';
import { buscaPlanesPerfilService } from '../../../../services/buscaPlanesPerfil.service';
import { Sesion } from '../../../../services/sesion.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Bitacora } from '../../../../services/bitacora.service';
declare var $: any;

@Component({
  selector: 'app-registro-beneficiarios-defaulteo',
  templateUrl: './registro-beneficiarios-defaulteo.component.html',
  styleUrls: ['./registro-beneficiarios-defaulteo.component.css'],
})
export class RegistroBeneficiariosDefaulteoComponent implements OnInit, DoCheck  {

  public idparentescoactivo: number = 0;
  public identity; ba
  public status;
  public token;
  public crearbeneficiario: crearbeneficiario;
  public comboSexo;
  public parentescoAll;
  public banderaParentesco;
  public titularAll;
  public datosPerfil;
  public planes;
  public parametrosAseguradoT: parametrosAsegurado;
  public asegurado;
  public daAsegurados;
  public datosbeneficiarios;
  public borrarbeneficiario: borrarbeneficiario;
  public hideElement;
  public btnAgregarBenf;
  public btnAgregarBenfV;
  public btnAgregarDep;
  public btnAgregarNuevo;
  public tabla1;
  public tabla2;
  public empleado;
  element: HTMLElement;
  public contador: number = 0;
  public resultado;
  public statusLeyenda: boolean;

  //para los disabled del formulario
  public apellidoPa;
  public apellidoMa;
  public nom1;
  public nom2;
  public fechNac;
  public sx;
  public parents;

  public trustUrl2: SafeResourceUrl;
  public trustUrl3: SafeResourceUrl;
  public estilo;
  public url3 = '../../../../../../src/app/beflex/shared/nav/nav.component.css';
  public wizard;
  public etiqueta;
  public sustituto;
  public mensajesSolicitudExist;
  public mostrar;
  public parrafo;
  public edad;
  public fechanacimientoForm;
  public valor;
  public operacion;
  public solicitudes;
  public solicitud;
  public btnConsentimiento;
  public consentimientopdf;
  public splitParentesco;
  public bloquear = false;
  public planesocultos = 'null';
  public planesportafolios = false;
  public planesportafoliosbandera = false;
  public valorportafolio= 'null';

  // para beneficiario sustituto y porcentajes
  public btnCancelarSustituo;
  public btnAgregarSustituto;
  public btnAgSustPorcentajes;
  public paramBeneSustituto;
  public leyendaSustituto;
  public leyendasPorcentajesAux;
  public leyendasYPorcentajes;
  public valorPorcentajesAux;
  public newArray1;
  public porcentajesTotales;
  public beneSustituo: beneficiarioSustituto;
  public beneficiarioSecu;
  public leyenda1;
  public leyenda2;
  public beneSecu;
  public planPrevisor;
  public porcentaje1;

  //para el boton de continuar
  public obtenPlan;
  public obtenAsegurados;
  public obtenAsegurado;
  public sumaPorcentaes = 0;
  public resultadoSumaPorcentajes = 0;
  public validar1PlanPercent = false;
  public valido1PlanPercent = false;

  private idPagina = '376';
  private paginaActual;
  private ipPrivada;

  private cantAseguradosTotal = 0;

  private fromTabla1 = false;
  private existeDuplicadoT1 = false;
  private existeDuplicadoT2 = false;

  public bancon = 0;

  constructor(
    private _empleadoService: EmpleadoService,
    private _beneficiarioService: BeneficiarioService,
    private sanitizer: DomSanitizer,
    private _BuscarPlanesv2: buscaPlanesPerfilService,
    private _sesion: Sesion,
    private _router: Router,
    private _bitacora: Bitacora,
    @Inject(DOCUMENT) private document: Document
  ) {
    this.crearbeneficiario = new crearbeneficiario('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
    this.parametrosAseguradoT = new parametrosAsegurado('', '', '', '', '', '', '', '', '');
    this.borrarbeneficiario = new borrarbeneficiario('', '', '');
    this.beneSustituo = new beneficiarioSustituto('', '', '', '', '', '', '');
    this.wizard = GLOBAL.wizard;
    this.identity = this._empleadoService.getIdentity();
    if (this.identity) {
      if (!this.identity.cambio && this.identity.reseteo) {
        this._router.navigate(['/pages/home']);
      } else if (this.identity.cambio && this.identity.reseteo) {
        this._router.navigate(['/pages/home']);
      }
    }
  }

  async ngOnInit() {
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();
    this.setStatus();
    this.verificarPlanesVida();
    this.getTodosParentescoV2Bandera(this.identity.idEmpresa);
    try {
      const response = await this._sesion.comprobarSession(this.token);
      if (this.identity) {
        await this.solicitudExistente2();
      }

      if (this.identity) {
        this.paginaActual = this.document.location.href;
        this.ipPrivada = localStorage.getItem('myIP') || '0.0.0.0';
        const parametroVitacora = {
          idPagina: this.idPagina,
          id: 500636,
          ipPrivada: encodeURIComponent(this.ipPrivada),
          url: encodeURIComponent(this.paginaActual),
          idEmpresa: this.identity.idEmpresa,
          nombrePagina: 0
        };
        await this._bitacora.registrarBitacora(parametroVitacora);
      }
    } catch (error) {
      if (error == 'Unauthorized') {
        swal({
          title: '¡La sesión expiró!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
    }

    try {
      const response: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 214);
      this.valorportafolio = response.paValor.trim();
    } catch (error) {
      this.valorportafolio = 'null';
    }
  }

  ngDoCheck() {
    if ( this.bancon == 0 ) {
      this.validaContinuar();
    }
  }

  async setStatus() {
    try {
      const response: any = await this._beneficiarioService.consultarParametroStatusLeyenda2(this.identity.idEmpresa);
      const status = parseInt(response.paValor, 10);
      if (status === 1) {
        this.statusLeyenda = true;
      } else {
        this.statusLeyenda = false;
      }
    } catch (error) {
      const errorMessage = <any>error;
    }
  }

  async plantillaSexo() {
    try {
      const response = await this._beneficiarioService.getSexos(this.token);
      this.comboSexo = response;
    } catch (error) {
      const errorMessage = <any>error;
        if (errorMessage != null) {
          this.status = 'error';
        }
    }
  }

  async getTodosParentesco() {
    try {
      const response = await this._beneficiarioService.getParantescoAll(this.token);
      this.parentescoAll = response;
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }


  async getTodosParentescoV2(activo: any, empresa: any) {
    try {
      const response = await this._beneficiarioService.getParantescoAllV2(activo , empresa);
      this.parentescoAll = response;
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }

  async getTodosParentescoV2General(activo: any) {
    try {
      const response = await this._beneficiarioService.getParantescoAllV2General(activo);
      this.parentescoAll = response;
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }

  async getTodosParentescoV2Bandera(empresa: any) {
    try {
      const response = await this._beneficiarioService.getParantescoAllV2Bandera(empresa);
      this.banderaParentesco = response;
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }


  async titular() {
    try {
      const response = await this._empleadoService.getAllEmpleado(500636, this.token);
      this.titularAll = response;
      this.datosPerfil = this.titularAll;
      if (this.titularAll.EMNombre1 == 'NULL') {
        this.datosPerfil.EMNombre1 = ' ';
      }
      if (this.titularAll.EMNombre2 == 'NULL') {
        this.datosPerfil.EMNombre2 = ' ';
      }
      if (this.titularAll.EMApellidoPaterno == 'NULL') {
        this.datosPerfil.EMApellidoPaterno = ' ';
      }
      if (this.titularAll.EMApellidoMaterno == 'NULL') {
        this.datosPerfil.EMApellidoMaterno = ' ';
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }

  async planesVida() {
    this.parametrosAseguradoT.idCorporativo = this.identity.idCorporativo;
    this.parametrosAseguradoT.idTitular = '500636';
    this.parametrosAseguradoT.numeroEmpleado = '70000383';
    this.parametrosAseguradoT.idEmpresa = this.identity.idEmpresa;

    this._beneficiarioService.consultarPlanesVidaV2(this.parametrosAseguradoT, this.token).then(
      response => {
        localStorage.setItem('planesVida', JSON.stringify(response));
      },
      error => {
        const errorMessage = <any>error;
        if (errorMessage != null) {
          this.status = 'error';
        }
      }
    );
    this._beneficiarioService.consultarPlanesVidaV2(this.parametrosAseguradoT, this.token).then(
      (response: any) => {
        if (this.valorportafolio != null) {
          for (const key in response) {
            if ( parseInt(response[key].plIdPlan,10) == parseInt(this.valorportafolio,10)) {
              this.planesportafolios = true;
              this.consultarPorcentajesPortafolios(500636,this.valorportafolio);
            }
          }
        }
        if(this.planesocultos !=='null') {
          this.planesocultos = this.planesocultos.trim();
          const arreglo: string[] = this.planesocultos.split(',');
          let cadena = '[';
          for (const key in response) {
            if (!(arreglo.indexOf(''+response[key].plIdPlan) > -1)) {
              cadena += '{"plIdPlan":' + response[key].plIdPlan + ', "descripcion":"' + response[key].descripcion + '", "plOrden":' + response[key].plOrden + '},';
            }
          }
          cadena = cadena.substring(0, cadena.length - 1);
          cadena += ']';
          const response22 = JSON.parse(cadena);
          response = response22;

          this.planes = response;
        } else {
          this.planes = response;
        }

        this.parametrosAseguradoT.plIdPlan = this.planes[0].plIdPlan;
        if ( response.length == 1 ) {
          this.Consentimiento();
        }

        const validarPrevisor = response.map((valida) => {
          if (valida.plIdPlan == '1149') {
            return valida.plIdPlan;
          }
        });

        const sorted = validarPrevisor.sort();
        const unique = (sorted.filter((value, index) => value !== sorted[index + 1]));

        if (unique.length == 1) {
          this.validar1PlanPercent = true;
        }
        this.aseguradoT();
        this.parametrosAseguradoT.idAsegurado = '0';
        this.sumaPorcentaes = 0;
        this.aseguradosPorPlan(this.planes);
      },
      error => {
        const errorMessage = <any>error;
        if (errorMessage != null) {
          this.status = 'error';
        }
      }
    );
  }

  valoridPlan() {
    if (this.parametrosAseguradoT.plIdPlan != '0') {
      this.aseguradoT();
      this.crearbeneficiario.idPlan = this.parametrosAseguradoT.plIdPlan;
      this.beneSustituo.idPlan = this.parametrosAseguradoT.plIdPlan;
    } else {
      this.crearbeneficiario.idPlan = this.parametrosAseguradoT.plIdPlan;
      this.aseguradoT();
    }
    this.parametrosAseguradoT.idAsegurado = '0';
    this.tabla1 = false;
    this.btnAgregarBenf = false;
    this.hideElement = false;
    $('#beneficiario-form').trigger('reset');
    this.crearbeneficiario.idSexo = '0';
    this.crearbeneficiario.idParentesco = '0';
    this.tabla2 = false;
    this.btnConsentimiento = false;
    this.sustituto = false;
  }

  async aseguradoT() {
    this.parametrosAseguradoT.idCorporativo = this.identity.idCorporativo;
    this.parametrosAseguradoT.idTitular = '500636';
    this.parametrosAseguradoT.numeroEmpleado = '70000383';
    this.parametrosAseguradoT.idEmpresa = this.identity.idEmpresa;
    try {
      const response = await this._beneficiarioService.consultarAseguradoV2(this.parametrosAseguradoT, this.token);
      this.asegurado = JSON.stringify(response);
      this.asegurado = this.asegurado.replace(/null/g, '');
      this.asegurado = this.asegurado.replace(/NULL/g, '');
      this.asegurado = JSON.parse(this.asegurado);
      for (let i = 0; i < this.asegurado.length; i++) {
        const separador2 = '   ';
        this.splitParentesco = this.asegurado[i]['asegurado'].split(separador2);
      }

    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }

  async valoridAsegurado() {
    if (this.parametrosAseguradoT.idAsegurado != '0') {
      for (let i = 0; i < this.asegurado.length; i++) {
        if ( parseInt(this.asegurado[i]['id'], 10) === parseInt(this.parametrosAseguradoT.idAsegurado, 10)) {
          const separador2 = '   ';
          this.splitParentesco = this.asegurado[i]['asegurado'].split(separador2);

          try {
            const response = await this._beneficiarioService.consultarIdParentesco(this.splitParentesco[0]);
            this.idparentescoactivo = response;
            if (this.banderaParentesco > 0) {
              this.getTodosParentescoV2(this.idparentescoactivo, this.identity.idEmpresa);
            } else {
              this.getTodosParentescoV2General(this.idparentescoactivo);
            }
          } catch (error) {
            const errorMessage = <any>error;
            swal({
              title: '¡Error al obtener el parentesco, Intenta mas tarde!',
              type: 'error',
              confirmButtonText: 'Aceptar ',
            });
          }
        }
      }

      this.beneSustituo.idEmpleado = this.parametrosAseguradoT.idAsegurado;
      this.datosAsegurados();
      this.getParrafoBeneficiarios();
      this.btnAgregarBenf = true;
      this.btnAgregarDep = true;
      this.tabla1 = true;
      this.tabla2 = true;
      this.contador = 0;
    } else {
      this.planesVida();
      this.tabla1 = false;
      this.btnAgregarBenf = false;
      this.hideElement = false;
      $('#beneficiario-form').trigger('reset');
      this.crearbeneficiario.idSexo = '0';
      this.crearbeneficiario.idParentesco = '0';
      this.tabla2 = false;
      this.btnConsentimiento = false;
      this.sustituto = false;
    }
  }


  async datosAsegurados() {
    this.parametrosAseguradoT.idTitular = this.identity.id;
    this.parametrosAseguradoT.consulta = '1';
    if (this.parametrosAseguradoT.plIdPlan != '0') {
      this.beneficiarios();
    }
    try {
      const response = await this._beneficiarioService.consultarDatosAsegurados(this.parametrosAseguradoT, this.token);
      this.daAsegurados = response;
      if (this.daAsegurados != null) {
        for (let i = 0; i < this.daAsegurados.length; i++) {
          const element = this.daAsegurados[i]['nombre2'];
          const element2 = this.daAsegurados[i]['apellidoMaterno'];
          if (element == 'NULL' || element == null) {
            this.daAsegurados[i]['nombre2'] = ' ';
          }
          if (element2 == 'NULL' || element2 == null) {
            this.daAsegurados[i]['apellidoMaterno'] = ' ';
          }
        }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }


  async beneficiarios() {
    this.contador = 0;
    this.beneficiarioSustituto();
    this.obtenerParametroBeneSustituto();
    try {
      const response = await this._beneficiarioService.consultarDependientes(this.parametrosAseguradoT, this.token);
      this.datosbeneficiarios = response;
      if (this.datosbeneficiarios != null) {
        for (let i = 0; i < this.datosbeneficiarios.length; i++) {
          const element = this.datosbeneficiarios[i]['bpPorcentaje'];
          this.contador += element;
        }
        this.validacionPorcentaje(this.contador);
      } else {
        this.validacionPorcentaje(this.contador);
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }


  validacionPorcentaje(suma: any) {
    if (suma < 100 && suma >= 0) {
      this.btnAgregarBenf = true;
      this.btnAgregarBenfV = false;
      this.btnAgregarDep = true;
      this.btnConsentimiento = false;
    } else {
      this.btnAgregarBenf = false;
      this.btnAgregarBenfV = true;
      this.btnAgregarDep = false;
      this.hideElement = false;
      this.btnConsentimiento = true;
    }

    this.operacion = 100 - suma;
    if (this.operacion == 0) {
      this.aseguradosPorPlan();
    } else {
      this.aseguradosPorPlan();
    }
    this.crearbeneficiario.porcentaje = this.operacion;
  }


  async alert(identificador: any) {
    if (this.parametrosAseguradoT.idAsegurado == '0' && this.crearbeneficiario.idPlan == '0') {
      swal({
        title: '¡Espera!',
        html: '<small style="color: grey; text-align: justify;">Selecciona un plan y el asegurado.</small>',
        type: 'warning',
        confirmButtonText: 'Aceptar',
      });
    } else if (this.parametrosAseguradoT.idAsegurado == '0') {
      swal({
        title: '¡Espera!',
        html: '<small style="color: grey; text-align: justify;">Selecciona un asegurado.</small>',
        type: 'warning',
        confirmButtonText: 'Aceptar',
      });
    } else if (this.crearbeneficiario.idPlan == '0') {
      swal({
        title: '¡Espera!',
        html: '<small style="color: grey; text-align: justify;">Selecciona un plan.</small>',
        type: 'warning',
        confirmButtonText: 'Aceptar',
      });
    } else {
      try {
        const result = await swal({
          title: '¿Desea eliminarlo?',
          html: '<small style="color: grey; text-align: justify;">¡Este beneficiario se dará de baja!</small>',
          type: 'question',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          cancelButtonText: 'Cancelar ',
          confirmButtonText: 'Aceptar ',
        });

        if (result.value != '') {
          if (result.value) {
            this.borrarbeneficiario.id = this.identity.id;
            this.borrarbeneficiario.parametro = '3';
            this.borrarbeneficiario.idBeneficiario = identificador;

            try {
              await this._beneficiarioService.bajaBeneficiario(this.borrarbeneficiario, this.token);
              swal({
                title: '¡Operación Exitosa!',
                type: 'success',
                confirmButtonText: 'Aceptar ',
              });
              this.contador = 0;
              this.datosAsegurados();
            } catch (error) {
              const errorMessage = <any>error;
              swal({
                title: '¡Intenta más tarde!',
                type: 'error',
                confirmButtonText: 'Aceptar',
              });
              if (errorMessage != null) {
                this.status = 'error';
              }
            }
          }
        }
      } catch (error) { }
    }
  }

  formulario() {
    this.hideElement = true;
    this.apellidoPa = true;
    this.apellidoMa = true;
    this.nom1 = true;
    this.nom2 = true;
    this.fechNac = true;
    this.sx = true;
    this.parents = true;
    this.btnAgregarNuevo = true;
    this.datosAsegurados();
  }

  formulario2() {
    this.hideElement = true;
    this.hideElement = true;
    this.apellidoPa = true;
    this.apellidoMa = true;
    this.nom1 = true;
    this.nom2 = true;
    this.fechNac = true;
    this.sx = true;
    this.parents = true;
    this.btnAgregarNuevo = true;
    this.fromTabla1 = false;
    this.datosAsegurados();
    $('#beneficiario-form').trigger('reset');
    this.crearbeneficiario.apellidoPaterno = '';
    this.crearbeneficiario.apellidoMaterno = '';
    this.crearbeneficiario.nombre1 = '';
    this.crearbeneficiario.nombre2 = '';
    this.crearbeneficiario.idSexo = '0';
    this.crearbeneficiario.idParentesco = '0';
  }


  async altaBeneficiario() {
    this.existeDuplicadoT1 = false;
    this.existeDuplicadoT2 = false;
    JSON.stringify(this.crearbeneficiario);
    this.crearbeneficiario.id = this.parametrosAseguradoT.idTitular;
    this.crearbeneficiario.idDep = this.parametrosAseguradoT.idAsegurado;

    if (this.crearbeneficiario.idSexo == '0' && this.crearbeneficiario.idParentesco == '0') {
      swal({
        title: '¡Espera!',
        html: '<small style="color: grey; text-align: justify;">Selecciona sexo y parentesco.</small>',
        type: 'warning',
        confirmButtonText: 'Aceptar',
      });
    } else if (this.crearbeneficiario.idParentesco == '0') {
        swal({
          title: '¡Espera!',
          html: '<small style="color: grey; text-align: justify;">Selecciona un parentesco.</small>',
          type: 'warning',
          confirmButtonText: 'Aceptar',
        });
    } else if (this.crearbeneficiario.idSexo == '0') {
        swal({
          title: '¡Espera!',
          html: '<small style="color: grey; text-align: justify;">Selecciona un sexo.</small>',
          type: 'warning',
          confirmButtonText: 'Aceptar',
        });
    } else if (this.parametrosAseguradoT.idAsegurado == '0' && this.crearbeneficiario.idPlan == '0') {
        swal({
          title: '¡Espera!',
          html: '<small style="color: grey; text-align: justify;">Selecciona un plan y el asegurado.</small>',
          type: 'warning',
          confirmButtonText: 'Aceptar',
        });
    } else if (this.parametrosAseguradoT.idAsegurado == '0') {
        swal({
          title: '¡Espera!',
          html: '<small style="color: grey; text-align: justify;">Selecciona un asegurado.</small>',
          type: 'warning',
          confirmButtonText: 'Aceptar',
        });
    } else if (this.crearbeneficiario.idPlan == '0') {
        swal({
          title: '¡Espera!',
          html: '<small style="color: grey; text-align: justify;">Seleccione un plan.</small>',
          type: 'warning',
          confirmButtonText: 'Aceptar',
        });
    } else {
      this.fechanacimientoForm = this.crearbeneficiario.fechaNacimiento;
      this.existenciaEnTablas(this.crearbeneficiario);
      const valPorcentajes: boolean = this.valorPorcentaje(this.crearbeneficiario.porcentaje);
      if ((this.existeDuplicadoT1 && !this.existeDuplicadoT2 && this.fromTabla1) || (!this.existeDuplicadoT1 && !this.existeDuplicadoT2)) {
          if (valPorcentajes) {
              const fechaDependiente = this.fechadeNacimiento(this.fechanacimientoForm);
              if (fechaDependiente >= 18) {
                try {
                  const response = await this._beneficiarioService.crearBeneficiarioPrincipal(this.crearbeneficiario, this.token);
                  swal({
                    title: '¡Operación Exitosa! ',
                    type: 'success',
                    confirmButtonText: 'Aceptar ',
                  });
                  this.contador = 0;
                  this.cancelar();
                  this.crearbeneficiario = new crearbeneficiario('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
                  this.crearbeneficiario.idPlan = this.parametrosAseguradoT.plIdPlan;
                  this.hideElement = false;
                  this.datosAsegurados();
                } catch (error) {
                  const errorMessage = <any>error;
                  swal({
                    title: '¡Verifica tus datos!',
                    type: 'error',
                    confirmButtonText: 'Aceptar ',
                  });
                  if (errorMessage != null) {
                    this.status = 'error';
                  }
                }
              } else {
                swal({
                  title: '¡Espera!',
                  html: '<small style="color: grey; text-align: justify;">El beneficiario debe ser mayor de edad.</small>',
                  type: 'warning',
                  confirmButtonText: 'Aceptar',
                });
              }
          } else {
            swal({
              title: '¡Verifica el porcentaje!',
              text: 'El total del plan no debe de pasar del 100 %',
              type: 'error',
              confirmButtonText: 'Aceptar ',
            });
          }
        } else {
          swal({
            title: '¡Beneficiario duplicado!',
            type: 'error',
            confirmButtonText: 'Aceptar ',
          });
        }
    }
  }

  existenciaEnTablas(crearbeneficiario) {
    if (crearbeneficiario.apellidoPaterno === 'NULL' || crearbeneficiario.apellidoPaterno == null) {
      crearbeneficiario.apellidoPaterno = '';
    }
    if (crearbeneficiario.apellidoMaterno === 'NULL' || crearbeneficiario.apellidoMaterno == null) {
      crearbeneficiario.apellidoMaterno = '';
    }
    if (crearbeneficiario.nombre1 === 'NULL' || crearbeneficiario.nombre1 == null) {
      crearbeneficiario.nombre1 = '';
    }
    if (crearbeneficiario.nombre2 === 'NULL' || crearbeneficiario.nombre2 == null) {
      crearbeneficiario.nombre2 = '';
    }
    crearbeneficiario.apellidoPaterno = crearbeneficiario.apellidoPaterno.trim();
    crearbeneficiario.apellidoMaterno = crearbeneficiario.apellidoMaterno.trim();
    crearbeneficiario.nombre1 = crearbeneficiario.nombre1.trim();
    crearbeneficiario.nombre2 = crearbeneficiario.nombre2.trim();
    this.existeDuplicadoT1 = false;
    this.existeDuplicadoT2 = false;
    if (this.daAsegurados !== null) {
      for (let i = 0; this.daAsegurados.length > i; i++) {
        if ( +( crearbeneficiario.idParentesco ) === +(this.daAsegurados[i].idParentesco)) {
          if (crearbeneficiario.apellidoPaterno.toUpperCase() === this.daAsegurados[i].apellidoPaterno.toUpperCase()) {
            if (crearbeneficiario.apellidoMaterno.toUpperCase() === this.daAsegurados[i].apellidoMaterno.toUpperCase()) {
              if (crearbeneficiario.nombre1.toUpperCase() === this.daAsegurados[i].nombre1.toUpperCase()) {
                if (crearbeneficiario.nombre2.toUpperCase() === this.daAsegurados[i].nombre2.toUpperCase()) {
                  this.existeDuplicadoT1 = true;
                }
              }
            }
          }
        }
      }

    } else {
      this.existeDuplicadoT1 = false;
    } if (this.datosbeneficiarios !== null) {
      for (let i = 0; this.datosbeneficiarios.length > i; i++) {
        if ( +( crearbeneficiario.idParentesco ) === +(this.datosbeneficiarios[i].bpIdParentesco)) {
          if (crearbeneficiario.apellidoPaterno.toUpperCase() === this.datosbeneficiarios[i].bpApellidoPaterno.toUpperCase()) {
            if (crearbeneficiario.apellidoMaterno.toUpperCase() === this.datosbeneficiarios[i].bpApellidoMaterno.toUpperCase()) {
              if (crearbeneficiario.nombre1.toUpperCase() === this.datosbeneficiarios[i].bpNombre1.toUpperCase()) {
                if (crearbeneficiario.nombre2.toUpperCase() === this.datosbeneficiarios[i].bpNombre2.toUpperCase()) {
                  this.existeDuplicadoT2 = true;
                }
              }
            }
          }
        }
      }
    } else {
      this.existeDuplicadoT2 = false;
    }
  }

   async alert2(identificador: any) {
    if (this.crearbeneficiario.idEmpleado != null) {
      this.crearbeneficiario.idEmpleado = identificador;
    } else {
      this.crearbeneficiario.idEmpleado = null;
    }
    try {
      const response = await this._beneficiarioService.getEmpleado(identificador, this.token);
        this.fromTabla1 = true;
        this.empleado = response;
        if (this.splitParentesco[0] != 'TITULAR') {
          if(this.banderaParentesco > 0) {
            try {
              const response: any = await this._beneficiarioService.consultarParentescoEmpresa(this.idparentescoactivo, this.empleado.emIdParentesco,this.identity.idEmpresa);
              if (parseInt(response.status, 10) === 1) {
                this.crearbeneficiario.idParentesco = response.idparentescoequivalente;
                  const separador = 'T';
                  const arregloDeSubCadenas = this.empleado.emFechaNacimiento.split(separador);
                  if (this.empleado.emNombre2 === 'NULL' || this.empleado.emNombre2 == null) {
                    this.empleado.emNombre2 = '';
                  }
                  if (this.splitParentesco[0] != 'TITULAR') {
                    this.crearbeneficiario = new crearbeneficiario(
                      this.empleado.emApellidoMaterno,
                      this.empleado.emApellidoPaterno, '', '', '',
                      arregloDeSubCadenas[0], '', '', '',
                      this.crearbeneficiario.idEmpleado,
                      this.crearbeneficiario.idParentesco,
                      this.parametrosAseguradoT.plIdPlan,
                      this.empleado.emIdSexo, '',
                      this.empleado.emNombre1,
                      this.empleado.emNombre2, ''
                    );
                  } else {
                    this.crearbeneficiario = new crearbeneficiario(
                      this.empleado.emApellidoMaterno,
                      this.empleado.emApellidoPaterno, '', '', '',
                      arregloDeSubCadenas[0], '', '', '',
                      this.crearbeneficiario.idEmpleado,
                      this.empleado.emIdParentesco,
                      this.parametrosAseguradoT.plIdPlan,
                      this.empleado.emIdSexo, '',
                      this.empleado.emNombre1,
                      this.empleado.emNombre2, ''
                    );
                  }

                  this.formulario();
                  this.apellidoPa = false;
                  this.apellidoMa = false;
                  this.nom1 = false;
                  this.nom2 = false;
                  this.fechNac = false;
                  this.sx = false;
                  this.parents = false;
                } else {
                  this.cancelar();
                  swal({
                    title: '¡El dependiente seleccionado no puede registrarse como beneficiario, Seleccione otra opcion!',
                    type: 'error',
                    confirmButtonText: 'Aceptar ',
                  });
                }
            } catch (error) {
              this.cancelar();
              swal({
                title: '¡El dependiente seleccionado no puede registrarse como beneficiario, Seleccione otra opcion!',
                type: 'error',
                confirmButtonText: 'Aceptar ',
              });
            }
          } else {
            try {
              const response: any = await this._beneficiarioService.consultarParentesco(this.idparentescoactivo, this.empleado.emIdParentesco);
              this.crearbeneficiario.idParentesco = response;
              const separador = "T";
              const arregloDeSubCadenas = this.empleado.emFechaNacimiento.split(separador);
              if (this.empleado.emNombre2 === 'NULL' || this.empleado.emNombre2 == null) {
                this.empleado.emNombre2 = '';
              }
              if (this.splitParentesco[0] != 'TITULAR') {
                this.crearbeneficiario = new crearbeneficiario(
                  this.empleado.emApellidoMaterno,
                  this.empleado.emApellidoPaterno, '', '', '',
                  arregloDeSubCadenas[0], '', '', '',
                  this.crearbeneficiario.idEmpleado,
                  this.crearbeneficiario.idParentesco,
                  this.parametrosAseguradoT.plIdPlan,
                  this.empleado.emIdSexo, '',
                  this.empleado.emNombre1,
                  this.empleado.emNombre2, ''
                );
              } else {
                this.crearbeneficiario = new crearbeneficiario(
                  this.empleado.emApellidoMaterno,
                  this.empleado.emApellidoPaterno, '', '', '',
                  arregloDeSubCadenas[0], '', '', '',
                  this.crearbeneficiario.idEmpleado,
                  this.empleado.emIdParentesco,
                  this.parametrosAseguradoT.plIdPlan,
                  this.empleado.emIdSexo, '',
                  this.empleado.emNombre1,
                  this.empleado.emNombre2, ''
                );
              }

              this.formulario();
              this.apellidoPa = false;
              this.apellidoMa = false;
              this.nom1 = false;
              this.nom2 = false;
              this.fechNac = false;
              this.sx = false;
              this.parents = false;
            } catch (error) {
              const errorMessage = <any>error;
              this.cancelar();
              swal({
                title: '¡El dependiente seleccionado no puede registrarse como beneficiario, Seleccione otra opcion!',
                type: 'error',
                confirmButtonText: 'Aceptar ',
              });
            }
          }
        } else {
          const separador = 'T';
          const arregloDeSubCadenas = this.empleado.emFechaNacimiento.split(separador);
          if (this.empleado.emNombre2 == 'NULL' || this.empleado.emNombre2 == null) {
            this.empleado.emNombre2 = ' ';
          }
          this.crearbeneficiario = new crearbeneficiario(
            this.empleado.emApellidoMaterno,
            this.empleado.emApellidoPaterno, '', '', '',
            arregloDeSubCadenas[0], '', '', '',
            this.crearbeneficiario.idEmpleado,
            this.empleado.emIdParentesco,
            this.parametrosAseguradoT.plIdPlan,
            this.empleado.emIdSexo, '',
            this.empleado.emNombre1,
            this.empleado.emNombre2, ''
          );
          this.formulario();
          this.apellidoPa = false;
          this.apellidoMa = false;
          this.nom1 = false;
          this.nom2 = false;
          this.fechNac = false;
          this.sx = false;
          this.parents = false;
        }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }

    try {
      const response = await this._beneficiarioService.getEmpleado(identificador, this.token);
      this.fromTabla1 = true;
      this.empleado = response;
      if (this.splitParentesco[0] != 'TITULAR') {
        if(this.banderaParentesco > 0) {
          this._beneficiarioService.consultarParentescoEmpresa(this.idparentescoactivo, this.empleado.emIdParentesco,this.identity.idEmpresa).then(
          (response: any) => {
            if (parseInt(response.status, 10) === 1) {
              this.crearbeneficiario.idParentesco = response.idparentescoequivalente;
                const separador = "T";
                const arregloDeSubCadenas = this.empleado.emFechaNacimiento.split(separador);
                if (this.empleado.emNombre2 === 'NULL' || this.empleado.emNombre2 == null) {
                  this.empleado.emNombre2 = '';
                }
                if (this.splitParentesco[0] != "TITULAR") {
                  this.crearbeneficiario = new crearbeneficiario(
                    this.empleado.emApellidoMaterno,
                    this.empleado.emApellidoPaterno, '', '', '',
                    arregloDeSubCadenas[0], '', '', '',
                    this.crearbeneficiario.idEmpleado,
                    this.crearbeneficiario.idParentesco,
                    this.parametrosAseguradoT.plIdPlan,
                    this.empleado.emIdSexo, '',
                    this.empleado.emNombre1, this.empleado.emNombre2, ''
                  );
                } else {
                  this.crearbeneficiario = new crearbeneficiario(
                    this.empleado.emApellidoMaterno,
                    this.empleado.emApellidoPaterno, '', '', '',
                    arregloDeSubCadenas[0], '', '', '',
                    this.crearbeneficiario.idEmpleado,
                    this.empleado.emIdParentesco,
                    this.parametrosAseguradoT.plIdPlan,
                    this.empleado.emIdSexo, '',
                    this.empleado.emNombre1,
                    this.empleado.emNombre2, ''
                  );
                }

                this.formulario();
                this.apellidoPa = false;
                this.apellidoMa = false;
                this.nom1 = false;
                this.nom2 = false;
                this.fechNac = false;
                this.sx = false;
                this.parents = false;
              } else {
                this.cancelar();
                swal({
                  title: '¡El dependiente seleccionado no puede registrarse como beneficiario, Seleccione otra opcion!',
                  type: 'error',
                  confirmButtonText: 'Aceptar ',
                });
              }
          }).catch( error => {
            this.cancelar();
            swal({
              title: '¡El dependiente seleccionado no puede registrarse como beneficiario, Seleccione otra opcion!',
              type: 'error',
              confirmButtonText: 'Aceptar ',
            });
          });
        } else {
          this._beneficiarioService.consultarParentesco(this.idparentescoactivo, this.empleado.emIdParentesco).then(
            (response: any)=> {
                this.crearbeneficiario.idParentesco = response;
                const separador = 'T';
                const arregloDeSubCadenas = this.empleado.emFechaNacimiento.split(separador);
                if (this.empleado.emNombre2 === 'NULL' || this.empleado.emNombre2 == null) {
                  this.empleado.emNombre2 = '';
                }
                if (this.splitParentesco[0] != "TITULAR") {
                  this.crearbeneficiario = new crearbeneficiario(
                    this.empleado.emApellidoMaterno,
                    this.empleado.emApellidoPaterno, '', '', '',
                    arregloDeSubCadenas[0], '', '', '',
                    this.crearbeneficiario.idEmpleado,
                    this.crearbeneficiario.idParentesco,
                    this.parametrosAseguradoT.plIdPlan,
                    this.empleado.emIdSexo, '',
                    this.empleado.emNombre1,
                    this.empleado.emNombre2, ''
                  );
                } else {
                  this.crearbeneficiario = new crearbeneficiario(
                    this.empleado.emApellidoMaterno,
                    this.empleado.emApellidoPaterno, '', '', '',
                    arregloDeSubCadenas[0], '', '', '',
                    this.crearbeneficiario.idEmpleado,
                    this.empleado.emIdParentesco,
                    this.parametrosAseguradoT.plIdPlan,
                    this.empleado.emIdSexo, '',
                    this.empleado.emNombre1,
                    this.empleado.emNombre2, ''
                  );
                }

                this.formulario();
                this.apellidoPa = false;
                this.apellidoMa = false;
                this.nom1 = false;
                this.nom2 = false;
                this.fechNac = false;
                this.sx = false;
                this.parents = false;
              }).catch(
            error => {
              const errorMessage = <any>error;
              this.cancelar();
              swal({
                title: '¡El dependiente seleccionado no puede registrarse como beneficiario, Seleccione otra opcion!',
                type: 'error',
                confirmButtonText: 'Aceptar ',
              });
            });
        }
      } else {
        const separador = 'T';
        const arregloDeSubCadenas = this.empleado.emFechaNacimiento.split(separador);
        if (this.empleado.emNombre2 == 'NULL' || this.empleado.emNombre2 == null) {
          this.empleado.emNombre2 = ' ';
        } else {
        }
        this.crearbeneficiario = new crearbeneficiario(
          this.empleado.emApellidoMaterno, this.empleado.emApellidoPaterno, '', '', '', arregloDeSubCadenas[0], '', '', '', this.crearbeneficiario.idEmpleado,
        this.empleado.emIdParentesco, this.parametrosAseguradoT.plIdPlan, this.empleado.emIdSexo, '', this.empleado.emNombre1, this.empleado.emNombre2, '');
        this.formulario();
        this.apellidoPa = false;
        this.apellidoMa = false;
        this.nom1 = false;
        this.nom2 = false;
        this.fechNac = false;
        this.sx = false;
        this.parents = false;
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }

  cancelar() {
    this.hideElement = false;
    $('#beneficiario-form').trigger('reset');
    this.crearbeneficiario.idSexo = '0';
    this.crearbeneficiario.idParentesco = '0';
    this.crearbeneficiario.idParentesco = '0';
    this.crearbeneficiario.idEmpleado = null;
  }


  valorPorcentaje(porcentaje: any) {
    porcentaje = porcentaje.toString().replace(/ /g, '');
    this.crearbeneficiario.porcentaje = porcentaje;
    this.resultado = this.contador + parseInt(porcentaje, 10);

    if (this.resultado > 100) {
      swal({
        title: '¡Verifica el porcentaje!',
        text: 'El total del plan no debe de pasar del 100 %',
        type: 'error',
        confirmButtonText: 'Aceptar ',
      });
      this.btnAgregarNuevo = true;
      return false;
    } else {
      this.btnAgregarNuevo = true;
      return true;
    }
  }

  validarEspacios(valor: any, atributo: any) {
    valor = valor.trim();
    if (atributo === 'apellidoPaterno') {
      this.crearbeneficiario.apellidoPaterno = valor;
    } else {
      if (atributo === 'apellidoMaterno') {
        this.crearbeneficiario.apellidoMaterno = valor;
      } else {
        if (atributo === 'nombre1') {
          this.crearbeneficiario.nombre1 = valor;
        } else {
          if (atributo === 'nombre2') {
            this.crearbeneficiario.nombre2 = valor;
          }
        }
      }
    }
  }


  fecha() {
    const y = new Date().getFullYear();
    let m = new Date().getMonth();
    const d = new Date().getDate();
    // d = d - 1;
    m = m + 1;
    let mes;
    let dia;
    if (m < 10) {
      mes = '0' + m;
    } else {
      mes = m;
    }
    if (d < 10) {
      dia = '0' + d;
    } else {
      dia = d;
    }
    const fechaactual = y + '-' + mes + '-' + dia;
    return fechaactual;
  }

  async solicitudExistente2() {
    this.mostrar = false;
    const parametros = {
      idEmpleado: 500636,
      idEmpresa: this.identity.idEmpresa
    };

    try {
      const response = await this._BuscarPlanesv2.verificarSolicitudExist(parametros, this.token);
      this.titular();
      this.planesVida();
      this.plantillaSexo();
      this.getTodosParentesco();
      this.getMayorDeEdad();
      this.getSolicitud();
      this.obtenerParametroBeneSustituto();
      localStorage.setItem('solicitud', '1');
      return this.mostrar = true;
    } catch (error) {
      const errorMessage = <any>error;
      swal({
        title: '¡Error de conexión!',
        html: '<small style="color: grey; text-align: justify;">¡Intenta más tarde!</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
      });

      this.mensajesSolicitudExist = '¡Intenta más tarde!';
    }
  }

  logout() {
    localStorage.removeItem('identity');
    localStorage.clear();
    this.identity = null;
    this._router.navigate(['/']);
  }

  Consentimiento() {
    localStorage.setItem('cierreBeneficiarios', '1');
    this.bloquear = true;
  }

  async getSolicitud() {
    try {
      const request: any = await this._empleadoService.getSolicitudBeneficioBF3(1);
      this.solicitudes = request;
      for (let i = 0; i < this.solicitudes.length; i++) {
        this.solicitud = this.solicitudes[0]['soIdSolicitud'];
      }
    } catch (error) { }
  }

  async getParrafoBeneficiarios() {
    try {
      const response = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idEmpresa, 123);
      this.parrafo = response['paValor'];
      this.parrafo = response['paValor'] = this.parrafo = response['paValor'].replace(/&uacute;/g, 'ú');
      this.parrafo = response['paValor'] = this.parrafo = response['paValor'].replace(/&ntilde;/g, 'ñ');
      this.parrafo = response['paValor'] = this.parrafo = response['paValor'].replace(/&iacute;/g, 'í');
      this.parrafo = response['paValor'] = this.parrafo = response['paValor'].replace(/&aacute;/g, 'á');
    } catch (error) { }
  }

  async getMayorDeEdad() {
    try {
      const response = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idEmpresa, 127);
      this.edad = response;
      this.valor = this.edad['paValor'];
    } catch (error) { }
  }

  fechadeNacimiento(fechaN: any) {
    const fecha = new Date(fechaN);
    const fechaActual = new Date();
    let edad = fechaActual.getFullYear() - fecha.getFullYear();
    const edadMes = fechaActual.getMonth() - fecha.getMonth();
    if (edadMes < 0 || (edadMes === 0 && fechaActual.getDate() < fecha.getDay())) {
      edad--;
    }
    return edad;
  }



  /*************************** Beneficirio Sustituto *********************************************************
  ***/

  async obtenerParametroBeneSustituto() {
    try {
      const request = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idEmpresa, '141');
      this.paramBeneSustituto = request['paValor'];
    } catch (error) {
      const errorMessage = <any>error;
    }
  }


  beneficiarioSustituto() {
    if (this.paramBeneSustituto == 1) {
      this.consultarLeyendasBeneficiarioSustituto(this.beneSustituo.idPlan);
      this.sustituto = true;
    }
  }

  async consultarLeyendasBeneficiarioSustituto(idPlan: any) {
    try {
      const response = await this._beneficiarioService.consultarPlanBeneficiarioParam(idPlan, this.token);
      this.leyendaSustituto = response;

      if (this.leyendaSustituto != null) {
        const leyendasPorcentajes = {};
        const leyendasSustituto = {};
        let index1 = 1;
        let index2 = 1;
        for (let i = 0; i < this.leyendaSustituto.length; i++) {
          const tipoParametro = this.leyendaSustituto[i]['tipoParametro'];
          if (tipoParametro == 0) {
            const tmp1 = this.leyendaSustituto[i];
            leyendasSustituto[index1] = tmp1;
            index1++;
            this.planPrevisor = false;
            this.btnCancelarSustituo = true;
            this.btnAgregarSustituto = true;
            this.btnAgSustPorcentajes = false;
          } else if (tipoParametro == 1) {
            const tmp2 = this.leyendaSustituto[i];
            leyendasPorcentajes[index2] = tmp2;
            index2++;
            this.planPrevisor = true;
            this.btnCancelarSustituo = true;
            this.btnAgregarSustituto = false;
            this.btnAgSustPorcentajes = true;
          }
        }
        this.leyenda1 = leyendasSustituto[1]['parametroValor'];
        this.leyenda2 = leyendasSustituto[2]['parametroValor'];
        this.leyendasPorcentajesAux = Object.values(leyendasPorcentajes);
        this.consultarValoresBeneficiarioSustituto();
      } else {
        this.planPrevisor = false;
        this.btnCancelarSustituo = true;
        this.btnAgregarSustituto = true;
        this.btnAgSustPorcentajes = false;
        this.leyenda1 = 'En caso de fallecimiento de algun beneficiario asigno a:';
        this.leyenda2 = 'En caso de fallecimiento de algun beneficiario asigno a:';
        this.beneSustituo.bpBeneficiarioSec = '';
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }


  async consultarValoresBeneficiarioSustituto() {
    try {
      const response = await this._beneficiarioService.consultaBeneficiarioSecu(this.beneSustituo, this.token);
      this.beneficiarioSecu = response;
      let contadorCeros = false;
      if (this.beneficiarioSecu != null) {
          for (let i = 0; i < this.beneficiarioSecu.length; i++) {
              const tipoParametro = this.beneficiarioSecu[i]['tipoParametro'];
              if (tipoParametro == 0) {
                  contadorCeros = true;
              } else {
                  contadorCeros = false;
                  break;
              }
          }
      }

      if (this.beneficiarioSecu == null) {
        const array = [];
        this.leyendasYPorcentajes = array;
        this.newArray1 = [];
        for (let i = 0; i < this.leyendasPorcentajesAux.length; i++) {
            this.newArray1.push(this.leyendasPorcentajesAux[i]);
        }
        if (this.newArray1.length > 0) {
          this.planesportafoliosbandera = false;
        }
        this.beneSustituo.bpBeneficiarioSec = this.leyenda2;
      } else if (contadorCeros) {
          if (this.beneSustituo.idPlan != this.valorportafolio) {
            const idPlanActual = this.beneSustituo.idPlan ;
            this.beneSustituo.idPlan = this.valorportafolio;
            const response2 = await this._beneficiarioService.consultaBeneficiarioSecu(this.beneSustituo, this.token);
            this.beneSecu = this.beneficiarioSecu[0]['bpBeneficiarioSecundario'];
            this.beneficiarioSecu = response2;
            const valorSustituto = {};
            const valorPorcentajes = {};
            let index3 = 1;
            let index4 = 1;
            if(this.beneficiarioSecu != null) {
                for (let i = 0; i < this.beneficiarioSecu.length; i++) {
                    // console.log(this.beneficiarioSecu.length)
                    const tipoParametro = this.beneficiarioSecu[i]['tipoParametro'];
                    if (tipoParametro == 0) {
                        const tmp1 = this.beneficiarioSecu[i];
                        valorSustituto[index3] = tmp1;
                        index3++;
                    } else if (tipoParametro == 1) {
                        const tmp2 = this.beneficiarioSecu[i];
                        valorPorcentajes[index4] = tmp2;
                        index4++;
                    }
                }
            }

            if (this.beneSecu == "" || this.beneSecu == null) {
              this.beneSustituo.bpBeneficiarioSec = this.leyenda2;
            } else {
              this.beneSustituo.bpBeneficiarioSec = this.beneSecu;
              this.valorPorcentajesAux = Object.values(valorPorcentajes);
              let sumatotal = 0;

              for (let j = 0; j < this.valorPorcentajesAux.length; j++) {
                const b = this.valorPorcentajesAux[j];
                sumatotal+=b.bpPorcentaje;
              }

              if (sumatotal === 100) {
                this.planesportafoliosbandera = true;
              } else {
                this.planesportafoliosbandera = false;
              }
              this.beneSustituo.idPlan = idPlanActual;
            }
          } else {
            const array = [];
            this.leyendasYPorcentajes = array;
            this.newArray1 = [];
            for (let i = 0; i < this.leyendasPorcentajesAux.length; i++) {
                this.newArray1.push(this.leyendasPorcentajesAux[i]);
            }
            if (this.newArray1.length > 0 ) {
              this.planesportafoliosbandera = false;
            }
            this.beneSustituo.bpBeneficiarioSec = this.beneficiarioSecu[0]['bpBeneficiarioSecundario'];
          }
      } else {
        const valorSustituto = {};
        const valorPorcentajes = {};
        let index3 = 1;
        let index4 = 1;
        for (let i = 0; i < this.beneficiarioSecu.length; i++) {
          // console.log(this.beneficiarioSecu.length)
          const tipoParametro = this.beneficiarioSecu[i]['tipoParametro'];
          if (tipoParametro == 0) {
            const tmp1 = this.beneficiarioSecu[i];
            valorSustituto[index3] = tmp1;
            index3++;
          } else if (tipoParametro == 1) {
            const tmp2 = this.beneficiarioSecu[i];
            valorPorcentajes[index4] = tmp2;
            index4++;
          }
        }

        this.beneSecu = valorSustituto[1]['bpBeneficiarioSecundario'];
        if (this.beneSecu == "" || this.beneSecu == null) {
          this.beneSustituo.bpBeneficiarioSec = this.leyenda2;
        } else {
          this.beneSustituo.bpBeneficiarioSec = this.beneSecu;
          this.valorPorcentajesAux = Object.values(valorPorcentajes);
          let sumatotal = 0;
          const array = [];
          for (let i = 0; i < this.leyendasPorcentajesAux.length; i++) {
            const a = this.leyendasPorcentajesAux[i];
            for (let j = 0; j < this.valorPorcentajesAux.length; j++) {
              const b = this.valorPorcentajesAux[j];
              if (a.pbpId === b.pbpId) {
                array.push({
                  pbpId: a.pbpId,
                  bpPorcentaje: b.bpPorcentaje,
                  parametroValor: a.parametroValor
                });
                sumatotal += b.bpPorcentaje;
              }
            }
          }

          if (sumatotal === 100) {
            this.planesportafoliosbandera = true;
          } else {
            this.planesportafoliosbandera = false;
          }
          this.leyendasYPorcentajes = array;

          this.newArray1 = [];
          for (let i = 0; i < this.leyendasPorcentajesAux.length; i++) {
            let igual = false;
            for (let j = 0; j < array.length && !igual; j++) {
              if (this.leyendasPorcentajesAux[i]["pbpId"] == array[j]["pbpId"]){
                igual = true;
              }
            }
            if (!igual) {
              this.newArray1.push(this.leyendasPorcentajesAux[i]);
            }
          }
        }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }

  cancelarSustituto() {
    this.beneSecu = ' ';
    this.porcentaje1 = 0;
    this.consultarValoresBeneficiarioSustituto();
  }

  async agregarSustituto() {
    this.beneSustituo.idTitular = this.parametrosAseguradoT.idTitular;
    this.beneSustituo.idDependiente = this.parametrosAseguradoT.idAsegurado;
    if (this.sustituto == true && this.planPrevisor == false) {
      if (this.beneSustituo.bpBeneficiarioSec == '') {
        swal({
          title: '¡Verifica tus datos!',
          text: 'Requiere un beneficiario sustituto',
          type: 'error',
          confirmButtonText: 'Aceptar ',
        });
      } else {
        try {
          await this._beneficiarioService.crearBeneficiarioSustituto(this.beneSustituo, this.token);
          swal({
            title: '¡Operación Exitosa! ',
            type: 'success',
            confirmButtonText: 'Aceptar ',
          });
          this.consultarValoresBeneficiarioSustituto();
        } catch (error) {
          const errorMessage = <any>error;
            swal({
              title: '¡Verifica tus datos!',
              type: 'error',
              confirmButtonText: 'Aceptar ',
            });
            if (errorMessage != null) {
              this.status = 'error';
            }
        }
      }
    } else if (this.sustituto == true && this.planPrevisor == true) {
      if (this.beneSustituo.bpBeneficiarioSec == "") {
        swal({
          title: '¡Verifica tus datos!',
          type: 'error',
          confirmButtonText: 'Aceptar ',
        });
      } else {
        try {
          await this._beneficiarioService.crearBeneficiarioSustituto(this.beneSustituo, this.token);
        } catch (error) {
          const errorMessage = <any>error;
            swal({
              title: '¡Verifica tus datos!',
              type: 'error',
              confirmButtonText: 'Aceptar ',
            });
            if (errorMessage != null) {
              this.status = 'error';
            }
        }
      }
    }
  }

  async handleValues() {
    let auxValorIncrementar1 = 0;
    let auxValorIncrementar2 = 0;
    let valoresNuevoModelo;
    let valorNuevo1;
    let valorNuevo2;
    const arrayconPorcentajes = [];
    const nuevoArray = [];
    
    for (const item of this.leyendasYPorcentajes) {
      valorNuevo1 = parseInt($('#vld' + item.pbpId).val(), 10);
      auxValorIncrementar1 += valorNuevo1;
      arrayconPorcentajes.push({
        pbpId: item.pbpId,
        bpPorcentaje: valorNuevo1
      })
    }

    for (const item of this.newArray1) {
      valorNuevo2 = parseInt($('#vld' + item.pbpId).val(), 10);
      auxValorIncrementar2 += valorNuevo2;
      nuevoArray.push({
        pbpId: item.pbpId,
        bpPorcentaje: valorNuevo2
      });
    }

    valoresNuevoModelo = auxValorIncrementar1 + auxValorIncrementar2;
    this.porcentajesTotales = arrayconPorcentajes.concat(nuevoArray);
    if (valoresNuevoModelo === 100) {
      this.agregarPorcentajes(this.porcentajesTotales);
      if (this.validar1PlanPercent) {
        this.valido1PlanPercent = true;
      } else {
        this.valido1PlanPercent = false;
      }
    } else {
      swal({
        title: '¡Verifica tus datos!',
        text: 'La suma total de los porcentajes, debe ser 100%',
        type: 'error',
        confirmButtonText: 'Aceptar ',
      });
    }
  }

  cambioPorcentaje( element: any ) {
    const id = parseInt(element, 10);
    let auxValorIncrementar1 = 0;
    let auxValorIncrementar2 = 0;
    let valoresNuevoModelo;
    let valorNuevo1;
    let valorNuevo2;
    const arrayconPorcentajes = [];
    const nuevoArray = [];
    let sumaRestantes = 0;
    let sumaRestantesFaltante = 0;

    for (const item of this.leyendasYPorcentajes) {
      valorNuevo1 = parseInt($('#vld' + item.pbpId).val(), 10);
      auxValorIncrementar1 += valorNuevo1;
      arrayconPorcentajes.push({
        pbpId: item.pbpId,
        bpPorcentaje: valorNuevo1
      });
    }

    for (const item of this.newArray1) {
      valorNuevo2 = parseInt($('#vld' + item.pbpId).val(), 10);
      auxValorIncrementar2 += valorNuevo2;
      nuevoArray.push({
        pbpId: item.pbpId,
        bpPorcentaje: valorNuevo2
      });
    }

    valoresNuevoModelo = auxValorIncrementar1 + auxValorIncrementar2;
    this.porcentajesTotales = arrayconPorcentajes.concat(nuevoArray);

    if (valoresNuevoModelo > 100) {
      for (const item of this.porcentajesTotales) {
        if ( item.pbpId !== id ) {
          sumaRestantes += item.bpPorcentaje;
        }
      }
      sumaRestantesFaltante = 100 - sumaRestantes;
        (<HTMLInputElement>document.getElementById('vld' + id)).value = sumaRestantesFaltante.toString();
    }
    if (valoresNuevoModelo < 100 || isNaN(valoresNuevoModelo)) {
      this.planesportafoliosbandera = false;
    }
    return valoresNuevoModelo;
  }


  agregarPorcentajes(valores) {
    this.beneSustituo.idTitular = this.parametrosAseguradoT.idTitular;
    this.beneSustituo.idDependiente = this.parametrosAseguradoT.idAsegurado;
    valores.forEach(async ( element ) => {
      this.beneSustituo.bpPorcentaje1 = element.bpPorcentaje;
      this.beneSustituo.bpidParametro1 = element.pbpId;
      try {
        await this._beneficiarioService.crearOperaBeneficiarioSustituto1(this.beneSustituo, this.token);
        swal({
          title: '¡Operación Exitosa! ',
          type: 'success',
          confirmButtonText: 'Aceptar ',
        });
        this.consultarValoresBeneficiarioSustituto();
      } catch (error) {
        const errorMessage = <any>error;
        swal({
          title: '¡Verifica tus datos!',
          type: 'error',
          confirmButtonText: 'Aceptar ',
        });
        if (errorMessage != null) {
          this.status = 'error';
        }
      }
    });
  }

  /***********Para el boton de continuar ***************/
  async aseguradosPorPlan(obtenerPlanes?) {
    if (!obtenerPlanes) {
      obtenerPlanes = this.planes;
      this.sumaPorcentaes = 0;
      this.resultadoSumaPorcentajes = 0;
    }
    for (let i = 0; i < obtenerPlanes.length; i++) {
      this.obtenPlan = obtenerPlanes[i]['plIdPlan'];
      if (this.obtenPlan != '0') {
        const parametros = {
          plIdPlan: this.obtenPlan,
          idCorporativo: this.identity.idCorporativo,
          // 'idTitular': this.identity.id, anterior
          idTitular: 500636,
          numeroEmpleado: '70000383',
          idEmpresa: this.identity.idEmpresa
        };
        this.idAsegurados(parametros);
      }
    }
  }

  async idAsegurados(parametros) {
    this.cantAseguradosTotal = 0;
    try {
      const response = await this._beneficiarioService.consultarAseguradoV2(parametros, this.token);
      this.obtenAsegurados = response;
      for (let i = 0; i < this.obtenAsegurados.length; i++) {
        this.obtenAsegurado = this.obtenAsegurados[i]['id'];
        if (this.obtenAsegurado !== 0) {
          this.cantAseguradosTotal ++;
        }
        this.consultaPorcentajesBeneficiarios(parametros.plIdPlan, this.obtenAsegurado);
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }
  }


  async consultaPorcentajesBeneficiarios(idPlan, asegurado) {
    if (this.obtenAsegurado != '0') {
      const parametros2 = {
        idAsegurado: asegurado,
        plIdPlan: idPlan
      };

      try {
        const beneficiarios: any = await this._beneficiarioService.consultarDependientes(parametros2, this.token);
        for (let i = 0; i < beneficiarios.length; i++) {
          const element3 = beneficiarios[i]['bpPorcentaje'];
          this.sumaPorcentaes += element3;
        }
        this.resultadoSumaPorcentajes = (this.sumaPorcentaes / 100);
          if (this.resultadoSumaPorcentajes === this.cantAseguradosTotal) {
          this.btnAgregarBenfV = true;
          if (this.validar1PlanPercent) {
            this.valido1PlanPercent = true;
          } else {
            this.valido1PlanPercent = false;
          }
        } else {
          this.btnAgregarBenfV = false;
        }
      } catch (error) {
        const errorMessage = <any>error;
        if (errorMessage != null) {
          this.status = 'error';
        }
      }
    }
  }

  async consultarPorcentajesPortafolios(idEmpleado, idPlan) {
    try {
      this.beneficiarioSecu = await this._beneficiarioService.consultaBeneficiarioSecu2(idEmpleado, idPlan, this.token);
      if (this.beneficiarioSecu == null) {
        this.planesportafoliosbandera = false;
        this.beneSustituo.bpBeneficiarioSec = this.leyenda2;
      } else {
        const valorSustituto = {};
        const valorPorcentajes = {};
        let index3 = 1;
        let index4 = 1;
        for (let i = 0; i < this.beneficiarioSecu.length; i++) {
          const tipoParametro = this.beneficiarioSecu[i]['tipoParametro'];
          if (tipoParametro == 0) {
            const tmp1 = this.beneficiarioSecu[i];
            valorSustituto[index3] = tmp1;
            index3++;
          } else if (tipoParametro == 1) {
            const tmp2 = this.beneficiarioSecu[i];
            valorPorcentajes[index4] = tmp2
            index4++;
          }
        }
        this.valorPorcentajesAux = Object.values(valorPorcentajes);
          let sumatotal = 0;
            for (let j = 0; j < this.valorPorcentajesAux.length; j++) {
              const b = this.valorPorcentajesAux[j];
                sumatotal += b.bpPorcentaje;
            }
          if (sumatotal === 100) {
            this.planesportafoliosbandera = true;
          } else {
            this.planesportafoliosbandera = false;
          }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage != null) {
        this.status = 'error';
      }
    }

  }


//CAMBIO OCULTAR PLANES
  async verificarPlanesVida() {
    this.parametrosAseguradoT.idCorporativo = this.identity.idCorporativo;
    this.parametrosAseguradoT.idTitular = '500636';
    this.parametrosAseguradoT.numeroEmpleado = '70000383';
    this.parametrosAseguradoT.idEmpresa = this.identity.idEmpresa;

    try {
      const responseparam: any = await this._empleadoService.getParametro(this.identity.idEmpresa, 213);
       this.planesocultos = responseparam.paValor;

       try {
         let response: any = await this._beneficiarioService.consultarPlanesVidaV2(this.parametrosAseguradoT, this.token);
         if (this.planesocultos !=='null') {
          this.planesocultos = this.planesocultos.trim();
          const arreglo:string[] = this.planesocultos.split(',');
          let cadena = '[';
          for (const key in response) {
            if (arreglo.indexOf(''+response[key].plIdPlan) > -1) {
            } else {
              cadena+='{"plIdPlan":'+ response[key].plIdPlan+', "descripcion":"'+ response[key].descripcion+'", "plOrden":' +response[key].plOrden+'},'; 
            }
          }
          cadena = cadena.substring(0,cadena.length-1);
          cadena+=']';
          const response22 = JSON.parse(cadena);
          response = response22;
          this.planes = response;
        } else {
          this.planes = response;
        }
        if (response.length==1) {
          this.bloquear = true;
        } else {
          swal({
            title: '¡Espera!',
            html: '<small style="color: grey; text-align: justify;">Antes de imprimir tu solicitud deberás registrar a tus beneficiarios.</small>',
            type: 'info',
            confirmButtonText: 'Aceptar',
          });
        }
       } catch (error) {
        const errorMessage = <any>error;
        if (errorMessage != null) {
          this.status = 'error';
        }
       }
    } catch (error) {
      this.planesocultos = 'null';
      try {
        let response: any = await this._beneficiarioService.consultarPlanesVidaV2(this.parametrosAseguradoT, this.token);
        if (this.planesocultos !== 'null') {
          this.planesocultos = this.planesocultos.trim();
          const arreglo:string[] = this.planesocultos.split(',');
          let cadena = '[';
          for (const key in response) {
            if (arreglo.indexOf(''+response[key].plIdPlan) > -1) {
            } else {
              cadena += '{"plIdPlan":'+ response[key].plIdPlan+', "descripcion":"'+ response[key].descripcion+'", "plOrden":' +response[key].plOrden+'},'; 
            }
          }
          cadena = cadena.substring(0,cadena.length-1);
          cadena += ']';
          const response22 = JSON.parse(cadena);
          response = response22;
          this.planes = response;
        } else {
          this.planes = response;
        }
        if (response.length==1) {
          this.bloquear = true;
        } else {
          swal({
            title: '¡Espera!',
            html: '<small style="color: grey; text-align: justify;">Antes de imprimir tu solicitud deberás registrar a tus beneficiarios.</small>',
            type: 'info',
            confirmButtonText: 'Aceptar',
          });
        }
      } catch (error) {
        const errorMessage = <any>error;
        if (errorMessage != null) {
          this.status = 'error';
        }
      }
    }
  }


  //alerta de espera
  mostrarAlert() {
    let timerInterval;
    swal({
      title: 'Procesando',
      html: '',
      timer: 4000,
      onOpen: () => {
        swal.showLoading();
        timerInterval = setInterval(() => {}, 100);
      },
      onClose: () => {
        clearInterval(timerInterval);
      }
    }).then((result) => {
    });
  }


  validaContinuar() { 
    if (this.planesportafolios) {
      if (this.validar1PlanPercent) {
        if (!this.bloquear && this.btnAgregarBenfV && this.valido1PlanPercent && this.planesportafoliosbandera) {
          this.bancon = 1;
          this.Consentimiento();
        }
      } else {
        if (!this.bloquear && this.btnAgregarBenfV) {
          this.bancon = 1;
        }
      }

    } else {
      if (this.validar1PlanPercent) {
        if (!this.bloquear && this.btnAgregarBenfV && this.valido1PlanPercent) {
          this.bancon = 1;
        }
      } else {
        if (!this.bloquear && this.btnAgregarBenfV) {
          this.bancon = 1;
        }
      }
    }
  }

}

