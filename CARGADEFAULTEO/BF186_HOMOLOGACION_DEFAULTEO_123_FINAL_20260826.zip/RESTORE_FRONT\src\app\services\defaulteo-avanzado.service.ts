import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GLOBAL } from './global';

@Injectable({ providedIn: 'root' })
export class DefaulteoAvanzadoService {
  private base    = GLOBAL.url2 + 'defaulteo-avanzado';
  private baseWS  = GLOBAL.url2;
  private jsonOpts = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json', Accept: 'application/json' })
  };

  constructor(private http: HttpClient) {}

  // ---------------------------------------------------------------------------
  // Catalogos (reusan endpoints existentes del backend)
  // ---------------------------------------------------------------------------
  getEmpresas(idCorporativo: number, idAdmin: number, token: string): Observable<any> {
    const h = new HttpHeaders({ authorization: token, 'Content-Type': 'application/json' });
    return this.http.get(
      `${this.baseWS}preview-BeMobile/empresas?idCorporativo=${idCorporativo}&idAdministrador=${idAdmin}`,
      { headers: h });
  }

  /**
   * Usa el endpoint dedicado del defaulteo avanzado que devuelve TODOS los perfiles activos
   * de la empresa. El endpoint generico /perfil/empresa/:id filtra demasiado (solo trae 5 de 13).
   */
  getPerfiles(idEmpresa: number): Observable<any> {
    return this.http.get(`${this.base}/catalogo/perfiles?idEmpresa=${idEmpresa}`);
  }

  getOficinas(idEmpresa: number, idAdmin: number, token: string): Observable<any> {
    const h = new HttpHeaders({ authorization: token, 'Content-Type': 'application/json' });
    return this.http.get(
      `${this.baseWS}preview-BeMobile/oficinas?idEmpresa=${idEmpresa}&idAdministrador=${idAdmin}`,
      { headers: h });
  }

  getPlanes(idEmpresa: number, token: string): Observable<any> {
    const h = new HttpHeaders({ authorization: token, 'Content-Type': 'application/json' });
    return this.http.get(
      `${this.baseWS}preview-BeMobile/planes?idEmpresa=${idEmpresa}`,
      { headers: h });
  }

  /** CREA06 casos especiales: coberturas (ff_PlanOpcion) configuradas para un plan en una vigencia. */
  getCoberturas(idPlan: number, idVigencia: number, token: string): Observable<any> {
    const h = new HttpHeaders({ authorization: token, 'Content-Type': 'application/json' });
    return this.http.get(
      `${this.baseWS}titulares/coberturas/plan/${idPlan}/vigencia/${idVigencia}`,
      { headers: h });
  }

  getVigencias(idEmpresa: number, token: string): Observable<any> {
    const h = new HttpHeaders({ authorization: token, 'Content-Type': 'application/json' });
    return this.http.get(
      `${this.baseWS}sabana/getVigenciasXEmpresa?idEmpresa=${idEmpresa}`,
      { headers: h });
  }

  getSexos(token: string): Observable<any> {
    const h = new HttpHeaders({ authorization: token, 'Content-Type': 'application/json' });
    return this.http.get(`${this.baseWS}general/sexo`, { headers: h });
  }

  getParentescos(idEmpresa: number, idPerfil: number, token: string): Observable<any> {
    const h = new HttpHeaders({ authorization: token, 'Content-Type': 'application/json' });
    return this.http.get(
      `${this.baseWS}parentesco/empresa/${idEmpresa}/perfil/${idPerfil}?todos=true`,
      { headers: h });
  }

  /** RN001 / RN010 - busqueda con 15 filtros */
  buscar(filtros: any): Observable<any> {
    return this.http.post(this.base + '/buscar', filtros, this.jsonOpts);
  }

  /** RN006 / RN007 / RN008 - inicia el lote en background; devuelve { idLog, estado:"EN_PROCESO", totalEmpleados } */
  ejecutar(req: any): Observable<any> {
    return this.http.post(this.base + '/ejecutar', req, this.jsonOpts);
  }

  /** Estado del lote para el polling: { idLog, estado, totalEmpleados, procesados, totalExitosos, totalErrores } */
  consultarEstado(idLog: number): Observable<any> {
    return this.http.get(this.base + '/estado/' + idLog, this.jsonOpts);
  }

  /** RN003 - guardar nueva configuracion (POST) o actualizar (PUT) */
  guardarConfiguracion(c: any): Observable<any> {
    return c && c.id ? this.http.put(this.base + '/configuraciones', c, this.jsonOpts)
                     : this.http.post(this.base + '/configuraciones', c, this.jsonOpts);
  }

  /** RN009 - listar configuraciones por corp/empresa/admin */
  listarConfiguraciones(idCorporativo?: number, idEmpresa?: number, idAdmin?: number): Observable<any> {
    let params = new HttpParams();
    if (idCorporativo != null) params = params.set('idCorporativo', String(idCorporativo));
    if (idEmpresa     != null) params = params.set('idEmpresa',     String(idEmpresa));
    if (idAdmin       != null) params = params.set('idAdmin',       String(idAdmin));
    return this.http.get(this.base + '/configuraciones', { params });
  }

  /** RN003 - borrado logico */
  eliminarConfiguracion(id: number, idAdmin: number): Observable<any> {
    const params = new HttpParams().set('idAdmin', String(idAdmin));
    return this.http.delete(this.base + '/configuraciones/' + id, { params });
  }

  /** RN007 - descarga CSV del log de errores como Blob */
  descargarLogErrores(idLog: number): Observable<Blob> {
    return this.http.get(this.base + '/log-errores/' + idLog + '/descarga', { responseType: 'blob' });
  }
}
