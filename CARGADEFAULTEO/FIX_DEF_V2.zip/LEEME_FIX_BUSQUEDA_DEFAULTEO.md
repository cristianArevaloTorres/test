# Fix de búsqueda de Defaulteo

Este paquete restaura el comportamiento que tenía la pantalla antes de su reubicación: al presionar **Buscar** sin capturar un criterio, se devuelve el universo de titulares activos correspondiente a las empresas y perfiles seleccionados.

## Aplicación

1. Copiar el contenido de `FRONT` sobre la raíz del repositorio `BeFlex3-EmpAdm-defaulteoCargaMaisva`.
2. Copiar el contenido de `WS` sobre la raíz del repositorio `WSBeFlex-EmpAdm-defaulteoCargaMaisva`.
3. Ejecutar en la base objetivo `WS/database/008_restaurar_busqueda_universo_defaulteo.sql`.
4. Compilar y desplegar el frontend.
5. Probar **Buscar** sin criterios en `/pages/administracion/titulares/defaulteo`.

## Archivos incluidos

- `FRONT/src/app/beflex/administracion/titulares/defaulteo/operacion-guiada/tabla-defaulteo-titulares.component.ts`
- `FRONT/src/app/beflex/administracion/titulares/defaulteo/operacion-guiada/tabla-defaulteo-titulares.component.html`
- `WS/database/008_restaurar_busqueda_universo_defaulteo.sql`

La búsqueda vuelve a utilizar `titulares/busquedaMultivigenciaAvanzada`, el contrato existente antes de mover la pantalla. El script de BD quita únicamente la exclusión global del listado; la generación de solicitudes conserva sus validaciones.

## Validación realizada

- TypeScript: compilación sin errores.
- SQL local, empresa 186 y vigencia 4235: 4,097 resultados sin criterio en aproximadamente 0.55 segundos.
