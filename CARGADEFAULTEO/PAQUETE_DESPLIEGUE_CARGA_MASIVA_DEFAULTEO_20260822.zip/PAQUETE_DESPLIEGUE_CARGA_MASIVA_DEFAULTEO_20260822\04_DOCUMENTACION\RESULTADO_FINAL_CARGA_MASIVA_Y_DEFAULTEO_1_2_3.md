# Resultado final — Carga masiva B2/B3 y defaulteo 1, 2 y 3

Fecha de integración y validación local: 19 de agosto de 2026.

## 1. Resultado

El requerimiento del Word y sus imágenes quedó integrado en los repositorios reales, no solamente en las copias de código de `insumos`.

Se cubrieron cinco frentes:

1. Convivencia y parametrización independiente de carga masiva B2/B3.
2. Recuperación del selector global para habilitar o deshabilitar acceso de los empleados cargados.
3. Integración y endurecimiento del defaulteo avanzado para los tipos 1, 2 y 3.
4. Reporte histórico de empleados defaulteados con descarga a Excel.
5. Scripts idempotentes instalados y probados en `(localdb)\MSSQLLocalDB`, base `FlexiForbesv2`.

## 2. Qué existía antes y qué se agregó

| Tema | Antes | Resultado integrado |
|---|---|---|
| Carga B2 | Pantalla ASP.NET que procesa archivos TXT alojados en el servidor y usa la configuración de `ff_CargaMasivaOperacionEmpresa`. | Se conserva. Ahora muestra la selección B2/B3 de la empresa y vuelve a validarla en servidor antes de ejecutar. |
| Carga B3 | Pantalla Angular que procesa Excel, valida catálogos y ejecuta las operaciones configuradas. | Se conserva y se le agrega configuración independiente de pantalla/automático, bloqueo cuando Pantalla=B2 y selector de acceso Sí/No. |
| Elección B2/B3 | No había una configuración única e independiente; se infería por implementaciones y procedimientos distintos. | Nueva tabla por empresa y procedimientos para obtener, guardar y resolver el flujo. Pantalla y automático se eligen por separado. |
| Procedimiento dinámico B3 | El navegador enviaba el nombre del SP y el backend lo ejecutaba sin comprobar que perteneciera a la empresa. | El backend normaliza el nombre y exige una fila activa coincidente en `ff_CargaMasivaOperacionEmpresa`. También valida administrador/empresa. |
| Defaulteo básico | Ya existía en la migración. | Se conserva sin reemplazar su flujo. |
| Defaulteo avanzado | Había código parcial, pero estaba desconectado, varias llamadas no enviaban token y algunas acciones aparentaban ejecutarse aunque el motor no las aplicaba. | Se conecta a la pantalla, se autentica todo el flujo, se valida propiedad de empresas/empleados/lotes/configuraciones y se ejecutan realmente plan/cobertura opcionales. |
| Tipos 1, 2 y 3 | El frontend mostraba textos genéricos y el flujo avanzado enviaba `1/2/3`, aunque el motor legado espera `def1/def2/def3`. | Catálogo real 0–3, selector desde BD y traducción correcta a `def1`, `def2` y `def3`. |
| Vigencias | La variable Java llamada `idVigenciaAnterior` podía confundirse con el origen, aunque los SP multivigencia la usan como vigencia destino. | Se valida la vigencia contra la empresa y se envía la vigencia destino en el campo legado correcto. La vigencia origen queda resuelta por la relación `VIRenovada` del motor. |
| Histórico | Solo existía el procedimiento legado, que creaba y eliminaba la tabla compartida `PruebaTemp`. | Nuevo endpoint, pantalla y SP concurrente sin tabla permanente, con fechas tipadas y Excel. |

## 3. Cómo funciona cada tipo de defaulteo

### Tipo 1 — Traer selecciones de la vigencia anterior

- Parte de la solicitud/selecciones aprobadas de la vigencia anterior.
- Busca sus equivalencias de plan, opción y grupo en la vigencia destino.
- Replica únicamente opciones que siguen siendo válidas para el perfil y condiciones del empleado.
- Respeta planes forzosos, candados y reglas de elegibilidad de la vigencia destino.
- El motor recibe el token técnico `def1`.

Uso esperado: renovaciones donde se desea conservar las elecciones previas en la nueva vigencia.

### Tipo 2 — Plan espejo o básico de la vigencia destino

- No depende de copiar toda la selección anterior del empleado.
- Obtiene los planes básicos/espejo elegibles en la vigencia destino.
- Aplica sus coberturas predeterminadas, planes forzosos y candados.
- El motor recibe `def2`.

Uso esperado: asignar la configuración estándar de la nueva vigencia.

### Tipo 3 — Actualizar dependientes de la solicitud anterior

- Usa como referencia la solicitud previa correspondiente a la vigencia destino.
- Conserva la selección de planes aplicable.
- Recalcula la integración de dependientes y grupos de parentesco con la población vigente.
- Homologa las opciones cuando cambió su identificador y respeta elegibilidad/candados.
- El motor recibe `def3`.

Uso esperado: mantener la elección de beneficios y actualizar altas, bajas o cambios en dependientes.

Los tres tipos crean la solicitud mediante el motor actual y ahora el lote solo contabiliza éxito cuando la respuesta contiene la confirmación `_ok`. Una respuesta vacía o `_error` se registra como error real.

## 4. Parametrización final B2/B3

### Tabla

`dbo.bf_ConfiguracionFlujoCargaMasiva`

Una fila activa por empresa contiene:

- `CFFlujoPantalla`: `B2` o `B3`.
- `CFFlujoAutomatico`: `B2` o `B3`.
- estatus, usuario y fechas de auditoría.

### Comportamiento

| Configuración | Pantalla permitida | Proceso automático |
|---|---|---|
| Sin fila | B2 y B3, para compatibilidad | B2 |
| B2 / B2 | Solo B2 TXT | Motor B2 |
| B2 / B3 | Solo B2 TXT | Motor B3 |
| B3 / B2 | Solo B3 Excel | Motor B2 |
| B3 / B3 | Solo B3 Excel | Motor B3 |

No se insertaron decisiones ficticias para las empresas del esquema. La tabla quedó sin filas después de las pruebas transaccionales; cada empresa se vuelve explícita cuando un administrador guarda ambos selectores en B3. Mientras tanto se conserva el comportamiento compatible indicado arriba.

### Contratos SQL

- `bf_CargaMasivaFlujo_Obtener`: devuelve ambos valores y el indicador `configurado`.
- `bf_CargaMasivaFlujo_Guardar`: inserta o actualiza la decisión y audita al usuario.
- `bf_CargaMasivaFlujo_Resolver`: contrato para consumidores de pantalla o automáticos; acepta `PANTALLA` o `AUTOMATICO`.

### Contratos REST

- `GET /beflex/carga-masiva/flujo/{idEmpresa}`
- `PUT /beflex/carga-masiva/flujo/{idEmpresa}`
- `GET /beflex/carga-masiva/flujo/{idEmpresa}/resolver?canal=PANTALLA|AUTOMATICO`

Todos exigen token administrativo y asignación activa a la empresa.

Los procesos automáticos que acceden directamente a SQL deben ejecutar `bf_CargaMasivaFlujo_Resolver` con `AUTOMATICO` antes de elegir el conjunto de SP B2 o B3. No se modificó un ejecutable automático porque ninguno forma parte de los repositorios entregados.

## 5. Selector de acceso recuperado

En B3 se muestra `Habilitar el acceso al sistema: Sí/No` solo si la operación soporta `EMIdAcceso` o `Acceso`.

- Sí envía `1`.
- No envía `0`.
- El valor de pantalla prevalece sobre el Excel.
- Si el SP lo acepta pero la plantilla no incluye la columna, se agrega antes de ejecutar.
- Al cambiar de operación vuelve a Sí y se limpia el archivo anterior.

## 6. Defaulteo avanzado integrado

- Modos visibles: básico, avanzado e histórico.
- Catálogo real de tipos 1–3 desde `ff_TipoDefaulteo`.
- Filtros por empresas asignadas y normalización de listas numéricas.
- Plan y cobertura opcionales seleccionados desde catálogo; ya no se presenta una suma asegurada que el motor no puede sobrescribir con seguridad.
- Lote asíncrono, barra de avance, reanudación del seguimiento y descarga CSV de errores.
- La empresa de cada empleado se obtiene nuevamente desde BD.
- Validación de token y propietario en búsqueda, ejecución, configuraciones, estado y descarga.
- Configuraciones guardadas aisladas por `CDIdAdmin` también en los SP, no solo en Java.
- Se rechazan campos de acción antiguos que el motor no soporta, en lugar de ignorarlos silenciosamente.
- Las omisiones de plan/cobertura forzada se registran como advertencias.

## 7. Reporte histórico

La pantalla permite elegir empresa, fecha inicial y fecha final, consultar y descargar Excel con:

- empresa;
- número de empleado;
- nombre del empleado;
- costo anual de coberturas defaulteadas;
- usuario;
- fecha del defaulteo.

El nuevo `bf_ReporteDefaulteo_Consultar` usa CTE, límite superior exclusivo para incluir todo el día final y no crea `PruebaTemp`. La API de reportes verifica token y acceso a la empresa.

## 7.1 Visibilidad de la pantalla para un usuario

La pantalla no usa una bandera adicional de Defaulteo por empresa. La ruta ya
existe en Angular como:

`/pages/administracion/solicitudes/defaulteo`

La tarjeta visible se resuelve de esta forma:

1. `ff_AdministradorEmpresa` determina el rol del administrador para la empresa seleccionada.
2. `ff_MenuRol2` determina los menús visibles para ese rol.
3. `ff_Menu` debe contener y mantener activos tanto el padre **Administración de Solicitudes** como el hijo **Crear y actualizar solicitudes/Defaulteo**.

Por lo tanto, el acceso es **por rol**; indirectamente puede variar por usuario
y empresa porque el mismo administrador puede tener roles distintos en cada
empresa. El modo básico, avanzado e histórico no necesita tres permisos: los
tres viven dentro de la misma ruta y aparecen como botones al abrirla.

Se agregó `database/004_verificar_habilitar_menu_defaulteo.sql`. El script se
ejecuta en diagnóstico con `@Aplicar=0`, muestra la asignación
usuario/empresa/rol y confirma por separado el menú padre y el hijo. Con
`@Aplicar=1` activa o inserta las dos asignaciones en `ff_MenuRol2`. La creación
del catálogo `ff_Menu` queda protegida por la bandera independiente
`@CrearMenuSiNoExiste`.

Después de aplicar el permiso es necesario cerrar sesión y entrar nuevamente,
porque B3 conserva `identity` y `menurol` en `localStorage`.

## 8. Scripts instalados

Ruta: `WSBeFlex-EmpAdm-defaulteoCargaMaisva/database/`

1. `001_catalogo_y_flujo_carga_masiva.sql`
2. `002_reporte_historico_defaulteo.sql`
3. `003_seguridad_y_vigencia_defaulteo_avanzado.sql`
4. `004_verificar_habilitar_menu_defaulteo.sql` (diagnóstico/habilitación por rol; no modifica datos con sus valores predeterminados)

Los tres primeros son idempotentes y ya se aplicaron a `FlexiForbesv2`. El
cuarto es una herramienta parametrizable y permanece en modo diagnóstico hasta
que se capture la empresa/usuario y se cambie explícitamente `@Aplicar` a `1`.

## 9. Validación ejecutada

- Angular: build generado en `dist/beflex3` y `tsc -p src/tsconfig.app.json --noEmit` sin errores.
- API de reportes: build Maven correcto; 14 pruebas, 0 fallas y 0 errores.
- SQL: catálogo 0–3, contratos B2/B3, histórico vacío, esquema de seis columnas y seguridad por propietario comprobados.
- La prueba B2/B3 se ejecutó dentro de transacción y se revirtió; no dejó parametrizaciones de empresa ficticias.
- Backend principal: Maven se bloquea en la descarga del WSDL interno `172.17.0.59:2003`; al saltar esa fase, javac solo reporta las clases SOAP que no pudieron generarse y no reporta errores en los archivos modificados.
- B2 legado: el equipo solo tiene SDK moderno y no el targeting pack de .NET Framework 4.0 requerido por el proyecto. Se realizó revisión estática; el build requiere ese developer pack/Visual Studio Build Tools legado.

## 10. Orden de despliegue

1. Ejecutar los tres scripts de `database` en la base destino.
2. Desplegar el backend principal Java.
3. Desplegar la API de reportes.
4. Desplegar Angular.
5. Desplegar B2 si se desea que su propia pantalla muestre y haga cumplir la selección.
6. Guardar la decisión de pantalla y automático para cada empresa.
7. Adaptar los procesos automáticos externos para consultar el resolvedor antes de elegir B2/B3.
8. Ejecutar aceptación con población real; el esquema local no contiene empleados ni solicitudes.

## 11. Repositorios modificados

- `WSBeFlex-EmpAdm-defaulteoCargaMaisva`: backend, seguridad, ejecución avanzada, parametrización y SQL.
- `BeFlex3-EmpAdm-defaulteoCargaMaisva`: pantalla B3, configuración, avanzado e histórico.
- `BeFlex3_Admin_API_Reportes-defaulteoCargaMaisva`: endpoint histórico y pruebas.
- `BeflexProduccion-QA (1)`: visualización y bloqueo de flujo en B2.
