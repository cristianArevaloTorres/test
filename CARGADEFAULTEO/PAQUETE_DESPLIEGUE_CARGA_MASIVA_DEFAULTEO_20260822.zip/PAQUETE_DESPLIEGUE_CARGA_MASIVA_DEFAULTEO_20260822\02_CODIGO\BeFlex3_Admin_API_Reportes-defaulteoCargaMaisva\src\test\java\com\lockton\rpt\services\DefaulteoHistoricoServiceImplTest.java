package com.lockton.rpt.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.lockton.rpt.models.dto.DefaulteoHistoricoDTO;
import com.lockton.rpt.repositories.DefaulteoHistoricoRepository;
import com.lockton.rpt.services.impl.DefaulteoHistoricoServiceImpl;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DefaulteoHistoricoServiceImplTest {
    @Mock private DefaulteoHistoricoRepository repository;
    @InjectMocks private DefaulteoHistoricoServiceImpl service;

    @Test
    void consultaDelegaUnRangoValido() {
        LocalDate inicio = LocalDate.of(2026, 1, 1);
        LocalDate fin = LocalDate.of(2026, 1, 31);
        List<DefaulteoHistoricoDTO> esperado = Collections.singletonList(new DefaulteoHistoricoDTO());
        when(repository.puedeConsultarEmpresa(900, 64, 64)).thenReturn(true);
        when(repository.consultar(64, inicio, fin)).thenReturn(esperado);

        assertEquals(esperado, service.consultar(900, 64, 64, inicio, fin));
        verify(repository).puedeConsultarEmpresa(900, 64, 64);
        verify(repository).consultar(64, inicio, fin);
    }

    @Test
    void rechazaFechaFinalAnterior() {
        assertThrows(IllegalArgumentException.class, () -> service.consultar(
                900, 64, 64, LocalDate.of(2026, 2, 1), LocalDate.of(2026, 1, 31)));
    }

    @Test
    void rechazaEmpresaInvalida() {
        assertThrows(IllegalArgumentException.class, () -> service.consultar(
                900, 64, 0, LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 31)));
    }

    @Test
    void rechazaEmpresaNoAsignada() {
        LocalDate inicio = LocalDate.of(2026, 1, 1);
        LocalDate fin = LocalDate.of(2026, 1, 31);
        when(repository.puedeConsultarEmpresa(900, 64, 99)).thenReturn(false);
        assertThrows(SecurityException.class, () -> service.consultar(900, 64, 99, inicio, fin));
        verify(repository).puedeConsultarEmpresa(900, 64, 99);
        verifyNoMoreInteractions(repository);
    }
}
