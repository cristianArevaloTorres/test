package com.lockton.WSBeFlex;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
* <p>La clase WsBeFlexApplication extiende de SpringBootServletInitializer que nos permite
* implementar de una manera tradicional la aplicación empaquetada como WAR.</p>
* 
* @author  Andrea Hernández / BigPink
* @since 1.0
*/
@ServletComponentScan
@SpringBootApplication
public class WsBeFlexApplication extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(WsBeFlexApplication.class);
	}

/*	TODO: Clase principal de puebas locales WsBeFlexApplication 
        public static void main(String[] args) {
	  SpringApplication.run(WsBeFlexApplication.class, args);
	 }
	*/
	 
	/* @Bean
	  public FilterRegistrationBean corsFilter() {
	    final CorsConfiguration config = new CorsConfiguration();
	    config.setAllowCredentials(true);
	    config.addAllowedOrigin("*");
	    config.addAllowedHeader("*");
	    config.addAllowedMethod("*");
	    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    source.registerCorsConfiguration("/**", config);
	    final FilterRegistrationBean bean = new FilterRegistrationBean(new CorsFilter(source));
	    bean.setOrder(0);
	    return bean;
	  }*/
     }


