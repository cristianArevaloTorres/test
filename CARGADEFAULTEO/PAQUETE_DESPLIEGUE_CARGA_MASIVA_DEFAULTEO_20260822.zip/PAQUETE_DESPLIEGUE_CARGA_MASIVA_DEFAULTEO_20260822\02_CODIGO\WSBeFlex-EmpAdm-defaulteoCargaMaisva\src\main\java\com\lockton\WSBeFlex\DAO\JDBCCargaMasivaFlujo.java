package com.lockton.WSBeFlex.DAO;

import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionFlujoCargaMasiva;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCCargaMasivaFlujo implements CargaMasivaFlujoDAO {
    private final JdbcTemplate jdbcTemplate;

    public JDBCCargaMasivaFlujo(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Map<String, Object> obtener(int idEmpresa) {
        return jdbcTemplate.queryForMap(
                "EXEC dbo.bf_CargaMasivaFlujo_Obtener @IdEmpresa=?", idEmpresa);
    }

    @Override
    public Map<String, Object> guardar(FFConfiguracionFlujoCargaMasiva configuracion, int idUsuario) {
        return jdbcTemplate.queryForMap(
                "EXEC dbo.bf_CargaMasivaFlujo_Guardar "
                + "@IdEmpresa=?, @FlujoPantalla=?, @FlujoAutomatico=?, @IdUsuario=?",
                configuracion.idEmpresa, configuracion.flujoPantalla,
                configuracion.flujoAutomatico, idUsuario);
    }

    @Override
    public Map<String, Object> resolver(int idEmpresa, String canal) {
        return jdbcTemplate.queryForMap(
                "EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa=?, @Canal=?",
                idEmpresa, canal);
    }

    @Override
    public boolean tieneAccesoEmpresa(int idAdministrador, int idEmpresa) {
        Integer total = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM dbo.ff_AdministradorEmpresa ae "
                + "INNER JOIN dbo.ff_Empresa e ON e.EMIdEmpresa=ae.AEIdEmpresa AND e.EMIdEstatus=1 "
                + "WHERE ae.ADIdAdministrador=? AND ae.AEIdEmpresa=? AND ae.AEIdEstatus=1",
                new Object[] { idAdministrador, idEmpresa }, Integer.class);
        return total != null && total > 0;
    }

    @Override
    public boolean operacionConfigurada(int idEmpresa, String storedProcedure) {
        String normalizado = normalizarProcedimiento(storedProcedure);
        if (normalizado == null) return false;
        Integer total = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM dbo.ff_CargaMasivaOperacionEmpresa "
                + "WHERE CEIdEmpresa=? AND CEIdEstatus=1 "
                + "AND LOWER(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(CEStoredProc)), '[', ''), ']', ''), 'dbo.', ''))=?",
                new Object[] { idEmpresa, normalizado }, Integer.class);
        return total != null && total > 0;
    }

    private String normalizarProcedimiento(String value) {
        if (value == null) return null;
        String limpio = value.trim();
        while (limpio.startsWith(":")) limpio = limpio.substring(1).trim();
        if (!limpio.matches("[A-Za-z0-9_\\[\\]\\.]+")) return null;
        limpio = limpio.replace("[", "").replace("]", "");
        if (limpio.toLowerCase().startsWith("dbo.")) limpio = limpio.substring(4);
        return limpio.toLowerCase();
    }
}
