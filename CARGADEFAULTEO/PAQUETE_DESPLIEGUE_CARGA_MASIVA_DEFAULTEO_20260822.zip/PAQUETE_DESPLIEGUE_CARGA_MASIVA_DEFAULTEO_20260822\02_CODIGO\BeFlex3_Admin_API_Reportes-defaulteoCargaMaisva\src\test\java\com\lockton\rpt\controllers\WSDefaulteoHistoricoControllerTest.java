package com.lockton.rpt.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.lockton.rpt.models.dto.DefaulteoHistoricoDTO;
import com.lockton.rpt.models.entities.UsuarioToken;
import com.lockton.rpt.services.DefaulteoHistoricoService;
import com.lockton.rpt.services.JwtService;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class WSDefaulteoHistoricoControllerTest {
    @Mock private DefaulteoHistoricoService service;
    @Mock private JwtService jwtService;
    @InjectMocks private WSDefaulteoHistoricoController controller;

    @Test
    void rechazaTokenInvalido() {
        when(jwtService.validarToken("token-invalido")).thenReturn("Unauthorized");
        ResponseEntity<List<DefaulteoHistoricoDTO>> respuesta = controller.consultar(
                64, LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 31), "token-invalido");
        assertEquals(HttpStatus.UNAUTHORIZED, respuesta.getStatusCode());
        verifyNoInteractions(service);
    }

    @Test
    void permiteConsultaConTokenValido() {
        LocalDate inicio = LocalDate.of(2026, 1, 1);
        LocalDate fin = LocalDate.of(2026, 1, 31);
        List<DefaulteoHistoricoDTO> esperado = Collections.singletonList(new DefaulteoHistoricoDTO());
        UsuarioToken usuario = new UsuarioToken();
        usuario.n = 900;
        usuario.idEmpresa = 64;
        when(jwtService.validarToken("token-valido")).thenReturn(new HashMap<>());
        when(jwtService.getPayloadFromToken("token-valido")).thenReturn(usuario);
        when(service.consultar(900, 64, 64, inicio, fin)).thenReturn(esperado);

        ResponseEntity<List<DefaulteoHistoricoDTO>> respuesta = controller.consultar(
                64, inicio, fin, "token-valido");
        assertEquals(HttpStatus.OK, respuesta.getStatusCode());
        assertEquals(esperado, respuesta.getBody());
    }

    @Test
    void rechazaEmpresaNoAutorizada() {
        LocalDate inicio = LocalDate.of(2026, 1, 1);
        LocalDate fin = LocalDate.of(2026, 1, 31);
        UsuarioToken usuario = new UsuarioToken();
        usuario.n = 900;
        usuario.idEmpresa = 64;
        when(jwtService.validarToken("token-valido")).thenReturn(new HashMap<>());
        when(jwtService.getPayloadFromToken("token-valido")).thenReturn(usuario);
        when(service.consultar(900, 64, 99, inicio, fin))
                .thenThrow(new SecurityException("Empresa no asignada"));
        ResponseEntity<List<DefaulteoHistoricoDTO>> respuesta = controller.consultar(
                99, inicio, fin, "token-valido");
        assertEquals(HttpStatus.FORBIDDEN, respuesta.getStatusCode());
    }
}
