/* Validacion de vigencia y aislamiento de configuraciones por administrador. */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.bf_DefaulteoAvanzado_ResolverVigencia
    @IdEmpresa INT,
    @IdVigenciaSeleccionada INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdConfiguracion INT;
    DECLARE @IdVigenciaActual INT;
    DECLARE @IdVigenciaAnterior INT;
    DECLARE @EsValida BIT = 0;

    SELECT @IdConfiguracion = EMIdConfiguracion
    FROM dbo.ff_Empresa
    WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1;

    IF EXISTS (
        SELECT 1 FROM dbo.ff_Vigencia
        WHERE VIIdVigencia = @IdVigenciaSeleccionada
          AND VIIdConfiguracion = @IdConfiguracion
          AND VIIdEstatus = 1)
    BEGIN
        SET @EsValida = 1;
        SELECT @IdVigenciaAnterior = VIRenovada
        FROM dbo.ff_Vigencia
        WHERE VIIdVigencia = @IdVigenciaSeleccionada;
    END;

    SELECT TOP (1) @IdVigenciaActual = VIIdVigencia
    FROM dbo.ff_Vigencia
    WHERE VIIdConfiguracion = @IdConfiguracion
      AND VIIdEstatus = 1
      AND CONVERT(DATE, GETDATE()) BETWEEN CONVERT(DATE, VIVigenciaIni) AND CONVERT(DATE, VIVigenciaFin)
    ORDER BY VIVigenciaIni DESC, VIIdVigencia DESC;

    IF @IdVigenciaActual IS NULL
        SELECT TOP (1) @IdVigenciaActual = VIIdVigencia
        FROM dbo.ff_Vigencia
        WHERE VIIdConfiguracion = @IdConfiguracion AND VIIdEstatus = 1
        ORDER BY VIVigenciaIni DESC, VIIdVigencia DESC;

    SELECT
        @EsValida AS esValida,
        CONVERT(BIT, CASE WHEN @EsValida = 1 AND @IdVigenciaSeleccionada = @IdVigenciaActual THEN 1 ELSE 0 END) AS esActual,
        @IdVigenciaActual AS idVigenciaActual,
        @IdVigenciaAnterior AS idVigenciaAnterior;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Guardar
    @Id              INT           = NULL,
    @Nombre          VARCHAR(150),
    @Descripcion     VARCHAR(500)  = NULL,
    @IdCorporativo   INT           = NULL,
    @IdEmpresa       INT           = NULL,
    @IdAdmin         INT,
    @FiltrosJson     NVARCHAR(MAX),
    @AccionesJson    NVARCHAR(MAX) = NULL,
    @IdResult        INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @IdResult = 0;

    IF @Id IS NULL OR @Id = 0
    BEGIN
        INSERT INTO dbo.bf_ConfiguracionDefaulteo
            (CDNombre, CDDescripcion, CDIdCorporativo, CDIdEmpresa, CDIdAdmin,
             CDFiltrosJson, CDAccionesJson, CDIdEstatus, CDFechaAdd)
        VALUES
            (@Nombre, @Descripcion, @IdCorporativo, @IdEmpresa, @IdAdmin,
             @FiltrosJson, @AccionesJson, 1, GETDATE());
        SET @IdResult = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.bf_ConfiguracionDefaulteo
           SET CDNombre = @Nombre,
               CDDescripcion = @Descripcion,
               CDIdCorporativo = @IdCorporativo,
               CDIdEmpresa = @IdEmpresa,
               CDFiltrosJson = @FiltrosJson,
               CDAccionesJson = @AccionesJson,
               CDFechaUmod = GETDATE(),
               CDUsuarioUmod = @IdAdmin
         WHERE CDId = @Id
           AND CDIdAdmin = @IdAdmin
           AND CDIdEstatus = 1;
        IF @@ROWCOUNT = 1 SET @IdResult = @Id;
    END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Eliminar
    @Id      INT,
    @IdAdmin INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.bf_ConfiguracionDefaulteo
       SET CDIdEstatus = 2,
           CDFechaUmod = GETDATE(),
           CDUsuarioUmod = @IdAdmin
     WHERE CDId = @Id
       AND CDIdAdmin = @IdAdmin
       AND CDIdEstatus = 1;
END;
GO
