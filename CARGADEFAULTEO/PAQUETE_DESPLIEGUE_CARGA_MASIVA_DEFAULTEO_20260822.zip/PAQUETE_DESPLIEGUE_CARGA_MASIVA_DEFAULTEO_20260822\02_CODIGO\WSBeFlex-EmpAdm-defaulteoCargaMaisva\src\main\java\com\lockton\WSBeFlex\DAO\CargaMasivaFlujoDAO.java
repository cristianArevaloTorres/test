package com.lockton.WSBeFlex.DAO;

import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionFlujoCargaMasiva;
import java.util.Map;

public interface CargaMasivaFlujoDAO {
    Map<String, Object> obtener(int idEmpresa);
    Map<String, Object> guardar(FFConfiguracionFlujoCargaMasiva configuracion, int idUsuario);
    Map<String, Object> resolver(int idEmpresa, String canal);
    boolean tieneAccesoEmpresa(int idAdministrador, int idEmpresa);
    boolean operacionConfigurada(int idEmpresa, String storedProcedure);
}
