/*
  Simula las combinaciones de enrutamiento B2/B3 para la empresa 186.

  La configuracion se modifica dentro de una transaccion y siempre se revierte.
  Este script NO ejecuta una carga masiva y NO ejecuta defaulteo.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa INT = 186;
-- Valor tecnico temporal: la tabla no tiene FK y todo se revierte al final.
DECLARE @IdUsuarioPrueba INT = 1;

IF OBJECT_ID('dbo.bf_ConfiguracionFlujoCargaMasiva', 'U') IS NULL
    THROW 51030, 'Falta instalar dbo.bf_ConfiguracionFlujoCargaMasiva.', 1;

IF OBJECT_ID('dbo.bf_CargaMasivaFlujo_Guardar', 'P') IS NULL
   OR OBJECT_ID('dbo.bf_CargaMasivaFlujo_Resolver', 'P') IS NULL
    THROW 51031, 'Faltan los procedimientos de configuracion de flujo.', 1;

SELECT
    'ANTES' AS momento,
    C.CFIdEmpresa,
    C.CFFlujoPantalla,
    C.CFFlujoAutomatico,
    C.CFIdEstatus,
    C.CFFechaUMod
FROM dbo.bf_ConfiguracionFlujoCargaMasiva C
WHERE C.CFIdEmpresa = @IdEmpresa;

BEGIN TRY
    BEGIN TRANSACTION;

    PRINT 'ESCENARIO A: pantalla B2 y proceso automatico B3';
    EXEC dbo.bf_CargaMasivaFlujo_Guardar
        @IdEmpresa = @IdEmpresa,
        @FlujoPantalla = 'B2',
        @FlujoAutomatico = 'B3',
        @IdUsuario = @IdUsuarioPrueba;

    EXEC dbo.bf_CargaMasivaFlujo_Resolver
        @IdEmpresa = @IdEmpresa,
        @Canal = 'PANTALLA';

    EXEC dbo.bf_CargaMasivaFlujo_Resolver
        @IdEmpresa = @IdEmpresa,
        @Canal = 'AUTOMATICO';

    PRINT 'ESCENARIO B: pantalla B3 y proceso automatico B2';
    EXEC dbo.bf_CargaMasivaFlujo_Guardar
        @IdEmpresa = @IdEmpresa,
        @FlujoPantalla = 'B3',
        @FlujoAutomatico = 'B2',
        @IdUsuario = @IdUsuarioPrueba;

    EXEC dbo.bf_CargaMasivaFlujo_Resolver
        @IdEmpresa = @IdEmpresa,
        @Canal = 'PANTALLA';

    EXEC dbo.bf_CargaMasivaFlujo_Resolver
        @IdEmpresa = @IdEmpresa,
        @Canal = 'AUTOMATICO';

    ROLLBACK TRANSACTION;
    PRINT 'ROLLBACK COMPLETADO: no se conservaron los escenarios simulados.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT
    'DESPUES_DEL_ROLLBACK' AS momento,
    C.CFIdEmpresa,
    C.CFFlujoPantalla,
    C.CFFlujoAutomatico,
    C.CFIdEstatus,
    C.CFFechaUMod
FROM dbo.bf_ConfiguracionFlujoCargaMasiva C
WHERE C.CFIdEmpresa = @IdEmpresa;
