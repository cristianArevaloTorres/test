package com.lockton.rpt.controllers;

import com.lockton.rpt.models.dto.DefaulteoHistoricoDTO;
import com.lockton.rpt.models.entities.UsuarioToken;
import com.lockton.rpt.services.DefaulteoHistoricoService;
import com.lockton.rpt.services.JwtService;
import java.time.LocalDate;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("beflex/defaulteo")
public class WSDefaulteoHistoricoController {
    private static final Log LOGGER = LogFactory.getLog(WSDefaulteoHistoricoController.class);
    private final DefaulteoHistoricoService service;
    private final JwtService jwtService;

    public WSDefaulteoHistoricoController(DefaulteoHistoricoService service, JwtService jwtService) {
        this.service = service;
        this.jwtService = jwtService;
    }

    @GetMapping("/historico")
    public ResponseEntity<List<DefaulteoHistoricoDTO>> consultar(
            @RequestParam int idEmpresa,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin,
            @RequestHeader("authorization") String token) {
        try {
            Object validacion = jwtService.validarToken(token);
            if ("error".equals(String.valueOf(validacion))
                    || "Unauthorized".equals(String.valueOf(validacion))) {
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }
            UsuarioToken usuario = jwtService.getPayloadFromToken(token);
            if (usuario == null || usuario.idEmpresa <= 0) {
                return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            }
            return ResponseEntity.ok(service.consultar(
                    usuario.n, usuario.idEmpresa, idEmpresa, fechaInicio, fechaFin));
        } catch (SecurityException e) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            LOGGER.error("Error al consultar el histórico de defaulteo: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
