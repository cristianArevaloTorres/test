/*
  Diagnostico de solo lectura previo a la instalacion.
  No crea ni modifica objetos o datos permanentes.

  IMPORTANTE:
  - El nombre correcto es dbo.bf_ConfiguracionFlujoCargaMasiva.
  - No agregue una diagonal inversa antes del guion bajo: SQL Server la toma
    como parte literal del nombre, no como un escape.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;

DECLARE @IdEmpresa INT = 186;

SELECT
    @@SERVERNAME AS servidor,
    DB_NAME() AS baseActual,
    SUSER_SNAME() AS usuarioSql,
    SYSDATETIMEOFFSET() AS fechaRevision;

DECLARE @Objetos TABLE
(
    orden INT NOT NULL,
    grupo VARCHAR(30) NOT NULL,
    tipo CHAR(2) NOT NULL,
    objeto SYSNAME NOT NULL
);

INSERT INTO @Objetos (orden, grupo, tipo, objeto)
VALUES
    (10, 'PRERREQUISITO', 'U', 'ff_Empresa'),
    (11, 'PRERREQUISITO', 'U', 'ff_Vigencia'),
    (12, 'PRERREQUISITO', 'U', 'ff_TipoDefaulteo'),
    (13, 'PRERREQUISITO', 'U', 'bf_ConfiguracionDefaulteo'),
    (14, 'PRERREQUISITO', 'U', 'bf_LogDefaulteo'),
    (15, 'PRERREQUISITO', 'U', 'bf_LogErroresDefaulteo'),
    (16, 'PRERREQUISITO', 'P', 'bf_DefaulteoAvanzado_Buscar'),
    (20, 'INSTALACION_001', 'U', 'bf_ConfiguracionFlujoCargaMasiva'),
    (21, 'INSTALACION_001', 'P', 'bf_CargaMasivaFlujo_Obtener'),
    (22, 'INSTALACION_001', 'P', 'bf_CargaMasivaFlujo_Guardar'),
    (23, 'INSTALACION_001', 'P', 'bf_CargaMasivaFlujo_Resolver'),
    (30, 'INSTALACION_002', 'P', 'bf_ReporteDefaulteo_Consultar'),
    (40, 'INSTALACION_003', 'P', 'bf_DefaulteoAvanzado_ResolverVigencia'),
    (41, 'INSTALACION_003', 'P', 'bf_ConfiguracionDefaulteo_Guardar'),
    (42, 'INSTALACION_003', 'P', 'bf_ConfiguracionDefaulteo_Eliminar');

SELECT
    O.grupo,
    O.tipo,
    QUOTENAME('dbo') + '.' + QUOTENAME(O.objeto) AS objeto,
    CASE
        WHEN OBJECT_ID('dbo.' + O.objeto, O.tipo) IS NULL THEN 'FALTA'
        ELSE 'OK'
    END AS estado
FROM @Objetos O
ORDER BY O.orden;

SELECT
    SUM(CASE WHEN grupo = 'PRERREQUISITO'
                  AND OBJECT_ID('dbo.' + objeto, tipo) IS NULL THEN 1 ELSE 0 END)
        AS prerrequisitosFaltantes,
    SUM(CASE WHEN grupo LIKE 'INSTALACION[_]%'
                  AND OBJECT_ID('dbo.' + objeto, tipo) IS NULL THEN 1 ELSE 0 END)
        AS objetosInstalacionPendientes
FROM @Objetos;

IF OBJECT_ID('dbo.ff_Empresa', 'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql
        N'SELECT TOP (1)
              EMIdEmpresa AS idEmpresa,
              EMNombre AS empresa,
              EMIdCorporativo AS idCorporativo,
              EMIdConfiguracion AS idConfiguracion,
              EMIdEstatus AS estatus
          FROM dbo.ff_Empresa
          WHERE EMIdEmpresa = @Empresa;',
        N'@Empresa INT',
        @Empresa = @IdEmpresa;
END
ELSE
BEGIN
    SELECT 'No se pudo validar la empresa 186 porque falta dbo.ff_Empresa.' AS advertencia;
END;

IF OBJECT_ID('dbo.bf_ConfiguracionFlujoCargaMasiva', 'U') IS NOT NULL
BEGIN
    EXEC sys.sp_executesql
        N'SELECT
              CFIdEmpresa AS idEmpresa,
              CFFlujoPantalla AS flujoPantalla,
              CFFlujoAutomatico AS flujoAutomatico,
              CFIdEstatus AS estatus,
              CFFechaUMod AS fechaUltimaModificacion
          FROM dbo.bf_ConfiguracionFlujoCargaMasiva
          WHERE CFIdEmpresa = @Empresa;',
        N'@Empresa INT',
        @Empresa = @IdEmpresa;
END
ELSE
BEGIN
    SELECT
        'PENDIENTE DE INSTALACION' AS estado,
        'Ejecute 01_SQL_INSTALACION/000_INSTALACION_COMPLETA_SSMS.sql.' AS siguientePaso;
END;

SELECT
    S.name AS esquema,
    O.name AS objetoConDiagonalInversa,
    O.type_desc
FROM sys.objects O
INNER JOIN sys.schemas S ON S.schema_id = O.schema_id
WHERE O.name LIKE '%\\[_]%' ESCAPE '\';
