/*
  Parametrizacion independiente B2/B3 para carga masiva.
  - Pantalla: decide cual interfaz puede ejecutar cargas.
  - Automatico: decide cual motor deben usar los procesos programados.
  Sin fila configurada, ambas pantallas siguen disponibles y el automatico
  conserva B2 para no romper integraciones existentes.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

SET XACT_ABORT ON;
GO

MERGE dbo.ff_TipoDefaulteo AS destino
USING (VALUES
    (0, 'Seleccionar el tipo de Default', 'Opcion inicial; no ejecuta ningun tipo de defaulteo.'),
    (1, 'Traer selecciones vigencia anterior', 'Replica las selecciones aprobadas de la vigencia anterior y las homologa a la vigencia destino.'),
    (2, 'Plan espejo ultima vigencia', 'Asigna los planes basicos o espejo elegibles de la vigencia destino.'),
    (3, 'Actualizacion de dependientes solicitud anterior', 'Conserva la seleccion previa de la solicitud destino y actualiza la composicion de dependientes.')
) AS origen (TDidTipoDefaulteo, TDNombre, TDDescripcion)
ON destino.TDidTipoDefaulteo = origen.TDidTipoDefaulteo
WHEN MATCHED THEN UPDATE SET
    TDNombre = origen.TDNombre,
    TDDescripcion = origen.TDDescripcion,
    TDidEstatus = 1,
    TDFechaUMod = GETDATE()
WHEN NOT MATCHED THEN INSERT
    (TDidTipoDefaulteo, TDNombre, TDDescripcion, TDidEstatus,
     TDUsuarioAdd, TDFechaAdd, TDFechaUMod)
VALUES
    (origen.TDidTipoDefaulteo, origen.TDNombre, origen.TDDescripcion, 1,
     0, GETDATE(), GETDATE());
GO

IF OBJECT_ID('dbo.bf_ConfiguracionFlujoCargaMasiva', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_ConfiguracionFlujoCargaMasiva
    (
        CFIdEmpresa          INT         NOT NULL,
        CFFlujoPantalla      CHAR(2)     NOT NULL,
        CFFlujoAutomatico    CHAR(2)     NOT NULL,
        CFIdEstatus          INT         NOT NULL CONSTRAINT DF_bf_CargaFlujo_Estatus DEFAULT (1),
        CFUsuarioAdd         INT         NOT NULL,
        CFFechaAdd           DATETIME    NOT NULL CONSTRAINT DF_bf_CargaFlujo_FechaAdd DEFAULT (GETDATE()),
        CFUsuarioUMod        INT         NULL,
        CFFechaUMod          DATETIME    NULL,
        CONSTRAINT PK_bf_ConfiguracionFlujoCargaMasiva PRIMARY KEY (CFIdEmpresa),
        CONSTRAINT CK_bf_CargaFlujo_Pantalla CHECK (CFFlujoPantalla IN ('B2', 'B3')),
        CONSTRAINT CK_bf_CargaFlujo_Automatico CHECK (CFFlujoAutomatico IN ('B2', 'B3')),
        CONSTRAINT CK_bf_CargaFlujo_Estatus CHECK (CFIdEstatus IN (1, 2))
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Obtener
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        @IdEmpresa AS idEmpresa,
        COALESCE(CFFlujoPantalla, 'B3') AS flujoPantalla,
        COALESCE(CFFlujoAutomatico, 'B2') AS flujoAutomatico,
        CONVERT(BIT, CASE WHEN CFIdEmpresa IS NULL THEN 0 ELSE 1 END) AS configurado,
        CFUsuarioAdd AS usuarioAdd,
        CFFechaAdd AS fechaAdd,
        CFUsuarioUMod AS usuarioUMod,
        CFFechaUMod AS fechaUmod
    FROM (SELECT 1 AS n) x
    LEFT JOIN dbo.bf_ConfiguracionFlujoCargaMasiva c
      ON c.CFIdEmpresa = @IdEmpresa
     AND c.CFIdEstatus = 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Guardar
    @IdEmpresa          INT,
    @FlujoPantalla      CHAR(2),
    @FlujoAutomatico    CHAR(2),
    @IdUsuario          INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @FlujoPantalla = UPPER(LTRIM(RTRIM(@FlujoPantalla)));
    SET @FlujoAutomatico = UPPER(LTRIM(RTRIM(@FlujoAutomatico)));

    IF @IdEmpresa <= 0 OR NOT EXISTS (
        SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1)
        THROW 50001, 'La empresa indicada no existe o esta inactiva.', 1;
    IF @IdUsuario <= 0
        THROW 50002, 'El usuario es obligatorio.', 1;
    IF @FlujoPantalla NOT IN ('B2', 'B3') OR @FlujoAutomatico NOT IN ('B2', 'B3')
        THROW 50003, 'Los flujos permitidos son B2 y B3.', 1;

    BEGIN TRANSACTION;
    UPDATE dbo.bf_ConfiguracionFlujoCargaMasiva WITH (UPDLOCK, SERIALIZABLE)
       SET CFFlujoPantalla = @FlujoPantalla,
           CFFlujoAutomatico = @FlujoAutomatico,
           CFIdEstatus = 1,
           CFUsuarioUMod = @IdUsuario,
           CFFechaUMod = GETDATE()
     WHERE CFIdEmpresa = @IdEmpresa;

    IF @@ROWCOUNT = 0
        INSERT dbo.bf_ConfiguracionFlujoCargaMasiva
            (CFIdEmpresa, CFFlujoPantalla, CFFlujoAutomatico, CFIdEstatus,
             CFUsuarioAdd, CFFechaAdd)
        VALUES
            (@IdEmpresa, @FlujoPantalla, @FlujoAutomatico, 1,
             @IdUsuario, GETDATE());
    COMMIT TRANSACTION;

    EXEC dbo.bf_CargaMasivaFlujo_Obtener @IdEmpresa = @IdEmpresa;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Resolver
    @IdEmpresa INT,
    @Canal     VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Canal = UPPER(LTRIM(RTRIM(@Canal)));

    IF @Canal NOT IN ('PANTALLA', 'AUTOMATICO')
        THROW 50004, 'El canal debe ser PANTALLA o AUTOMATICO.', 1;

    SELECT
        @IdEmpresa AS idEmpresa,
        @Canal AS canal,
        CASE
            WHEN c.CFIdEmpresa IS NULL AND @Canal = 'AUTOMATICO' THEN 'B2'
            WHEN c.CFIdEmpresa IS NULL THEN NULL
            WHEN @Canal = 'PANTALLA' THEN c.CFFlujoPantalla
            ELSE c.CFFlujoAutomatico
        END AS flujo,
        CONVERT(BIT, CASE WHEN c.CFIdEmpresa IS NULL THEN 0 ELSE 1 END) AS configurado
    FROM (SELECT 1 AS n) x
    LEFT JOIN dbo.bf_ConfiguracionFlujoCargaMasiva c
      ON c.CFIdEmpresa = @IdEmpresa
     AND c.CFIdEstatus = 1;
END;
GO
