package com.lockton.WSBeFlex.REST;

import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionFlujoCargaMasiva;
import com.lockton.WSBeFlex.Services.CargaMasivaFlujoService;
import com.lockton.WSBeFlex.Services.GeneralesService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.UsuarioToken;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("beflex/carga-masiva/flujo")
public class WSCargaMasivaFlujo {
    private final CargaMasivaFlujoService service;
    private final GeneralesService generalService;
    private final JwtService jwtService;

    public WSCargaMasivaFlujo(CargaMasivaFlujoService service,
                              GeneralesService generalService,
                              JwtService jwtService) {
        this.service = service;
        this.generalService = generalService;
        this.jwtService = jwtService;
    }

    @GetMapping("/{idEmpresa}")
    public ResponseEntity<Map<String, Object>> obtener(
            @PathVariable int idEmpresa,
            @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!service.tieneAccesoEmpresa(usuario.n, idEmpresa)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        return ResponseEntity.ok(service.obtener(idEmpresa));
    }

    @PutMapping("/{idEmpresa}")
    public ResponseEntity<Map<String, Object>> guardar(
            @PathVariable int idEmpresa,
            @RequestBody FFConfiguracionFlujoCargaMasiva configuracion,
            @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!service.tieneAccesoEmpresa(usuario.n, idEmpresa)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        try {
            configuracion.idEmpresa = idEmpresa;
            return ResponseEntity.ok(service.guardar(configuracion, usuario.n));
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{idEmpresa}/resolver")
    public ResponseEntity<Map<String, Object>> resolver(
            @PathVariable int idEmpresa,
            @RequestParam String canal,
            @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!service.tieneAccesoEmpresa(usuario.n, idEmpresa)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        try {
            return ResponseEntity.ok(service.resolver(idEmpresa, canal));
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    private UsuarioToken usuarioAutenticado(String token) {
        try {
            if (token == null || !generalService.validarTokenId(0, token, 4)) return null;
            UsuarioToken usuario = jwtService.getPayloadFromToken(token);
            return usuario != null && usuario.n > 0 ? usuario : null;
        } catch (Exception e) {
            return null;
        }
    }
}
