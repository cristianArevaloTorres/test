package com.lockton.rpt.repositories;

import com.lockton.rpt.models.dto.DefaulteoHistoricoDTO;
import java.time.LocalDate;
import java.util.List;

public interface DefaulteoHistoricoRepository {
    boolean puedeConsultarEmpresa(int idAdministrador, int idEmpresaSesion, int idEmpresaConsulta);
    List<DefaulteoHistoricoDTO> consultar(int idEmpresa, LocalDate fechaInicio, LocalDate fechaFin);
}
