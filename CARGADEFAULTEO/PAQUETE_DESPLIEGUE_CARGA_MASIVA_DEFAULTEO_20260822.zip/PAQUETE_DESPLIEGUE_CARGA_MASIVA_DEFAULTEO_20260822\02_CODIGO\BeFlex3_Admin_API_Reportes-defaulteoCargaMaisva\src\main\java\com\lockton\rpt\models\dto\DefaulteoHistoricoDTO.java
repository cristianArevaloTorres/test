package com.lockton.rpt.models.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class DefaulteoHistoricoDTO {
    private int idEmpresa;
    private String numeroEmpleado;
    private String nombreEmpleado;
    private BigDecimal costoAnual;
    private Integer idUsuario;
    private LocalDate fechaDefaulteo;

    public int getIdEmpresa() { return idEmpresa; }
    public void setIdEmpresa(int idEmpresa) { this.idEmpresa = idEmpresa; }
    public String getNumeroEmpleado() { return numeroEmpleado; }
    public void setNumeroEmpleado(String numeroEmpleado) { this.numeroEmpleado = numeroEmpleado; }
    public String getNombreEmpleado() { return nombreEmpleado; }
    public void setNombreEmpleado(String nombreEmpleado) { this.nombreEmpleado = nombreEmpleado; }
    public BigDecimal getCostoAnual() { return costoAnual; }
    public void setCostoAnual(BigDecimal costoAnual) { this.costoAnual = costoAnual; }
    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
    public LocalDate getFechaDefaulteo() { return fechaDefaulteo; }
    public void setFechaDefaulteo(LocalDate fechaDefaulteo) { this.fechaDefaulteo = fechaDefaulteo; }
}
