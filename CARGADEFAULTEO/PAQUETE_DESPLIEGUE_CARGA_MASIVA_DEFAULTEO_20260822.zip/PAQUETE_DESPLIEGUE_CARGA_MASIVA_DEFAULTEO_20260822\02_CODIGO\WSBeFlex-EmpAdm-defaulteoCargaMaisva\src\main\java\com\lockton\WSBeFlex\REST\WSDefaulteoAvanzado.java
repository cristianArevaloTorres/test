package com.lockton.WSBeFlex.REST;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionDefaulteo;
import com.lockton.WSBeFlex.POJO.Especiales.FFEjecutarDefaulteoAvanzado;
import com.lockton.WSBeFlex.POJO.Especiales.FFFiltroDefaulteoAvanzado;
import com.lockton.WSBeFlex.Services.FfDefaulteoAvanzadoService;
import com.lockton.WSBeFlex.Services.GeneralesService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.UsuarioToken;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * CREA 06 - Endpoints REST de defaulteo avanzado.
 *
 * Rutas:
 *   POST   /beflex/defaulteo-avanzado/buscar
 *   POST   /beflex/defaulteo-avanzado/ejecutar
 *   POST   /beflex/defaulteo-avanzado/configuraciones
 *   PUT    /beflex/defaulteo-avanzado/configuraciones
 *   GET    /beflex/defaulteo-avanzado/configuraciones
 *   DELETE /beflex/defaulteo-avanzado/configuraciones/{id}?idAdmin=...
 *   GET    /beflex/defaulteo-avanzado/log-errores/{idLog}/descarga
 */
@RestController
@RequestMapping("beflex/defaulteo-avanzado")
public class WSDefaulteoAvanzado {

    private static final Log bitacora = LogFactory.getLog(WSDefaulteoAvanzado.class);

    @Autowired
    private FfDefaulteoAvanzadoService service;

    @Autowired
    private GeneralesService generalService;

    @Autowired
    private JwtService jwtService;

    // -------------------------------------------------------------------------
    // RN001 / RN010 - Busqueda con 15 filtros
    // -------------------------------------------------------------------------
    @PostMapping("/buscar")
    public ResponseEntity<List<Object>> buscar(@RequestBody FFFiltroDefaulteoAvanzado filtros,
                                                @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (filtros == null || !service.tieneAccesoEmpresas(usuario.n, filtros.idsEmpresa)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        try {
            List<Object> data = service.buscarEmpleados(filtros);
            if (data == null || data.isEmpty()) {
                return new ResponseEntity<>(data, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] /buscar: " + e.getMessage(), e);
            System.out.println("[CREA06] /buscar ERROR: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // -------------------------------------------------------------------------
    // RN006 / RN007 / RN008 - Ejecutar defaulteo (lote en BACKGROUND)
    // Responde 202 ACCEPTED con { idLog, estado:"EN_PROCESO", totalEmpleados }.
    // El front consulta el avance con GET /estado/{idLog}.
    // -------------------------------------------------------------------------
    @PostMapping("/ejecutar")
    public ResponseEntity<Map<String, Object>> ejecutar(@RequestBody FFEjecutarDefaulteoAvanzado req,
                                                        HttpServletRequest httpReq,
                                                        @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        int[] empresasSolicitadas = req != null && req.filtros != null
                ? req.filtros.idsEmpresa : null;
        if (req == null || !service.tieneAccesoEmpresas(usuario.n, empresasSolicitadas)
                || (req.idEmpresa != null
                    && !service.tieneAccesoEmpresas(usuario.n, new int[] { req.idEmpresa }))
                || !service.tieneAccesoEmpleados(usuario.n, req.idEmpleado)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        if (req.idVigencia == null || req.idVigencia <= 0
                || req.idEmpleado == null || req.idEmpleado.length == 0
                || req.acciones == null || req.acciones.tipoAsignacionPlanes == null
                || req.acciones.tipoAsignacionPlanes < 1 || req.acciones.tipoAsignacionPlanes > 3
                || req.acciones.tieneCamposNoSoportados()
                || (req.acciones.idPlanDestino != null && req.acciones.idPlanDestino <= 0)
                || (req.acciones.idCoberturaDestino != null && req.acciones.idCoberturaDestino <= 0)
                || (Boolean.TRUE.equals(req.acciones.aplicarReglaAntiguedad)
                    && req.acciones.mesesAntiguedadMinimos != null
                    && req.acciones.mesesAntiguedadMinimos <= 0)) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        req.idAdmin = usuario.n;
        try {
            String ip = obtenerIp(httpReq);
            Map<String, Object> resp = service.ejecutar(req, ip);
            return new ResponseEntity<>(resp, HttpStatus.ACCEPTED);
        } catch (Exception e) {
            bitacora.error("[CREA06] /ejecutar: " + e.getMessage(), e);
            System.out.println("[CREA06] /ejecutar ERROR: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
    }

    // -------------------------------------------------------------------------
    // Estado del lote (polling). Devuelve avance en vivo o el persistido en BD.
    // -------------------------------------------------------------------------
    @GetMapping("/estado/{idLog}")
    public ResponseEntity<Map<String, Object>> estado(@PathVariable int idLog,
                                                       @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!service.lotePerteneceAdministrador(idLog, usuario.n)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        try {
            Map<String, Object> resp = service.consultarEstado(idLog);
            return new ResponseEntity<>(resp, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] /estado: " + e.getMessage(), e);
            System.out.println("[CREA06] /estado ERROR: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // -------------------------------------------------------------------------
    // RN003 / RN009 - Configuraciones guardadas (CRUD)
    // -------------------------------------------------------------------------
    @PostMapping("/configuraciones")
    public ResponseEntity<Map<String, Object>> crearConfiguracion(@RequestBody FFConfiguracionDefaulteo c,
                                                                   @RequestHeader(value = "authorization", required = false) String token) {
        return guardarInterno(c, token);
    }

    @PutMapping("/configuraciones")
    public ResponseEntity<Map<String, Object>> actualizarConfiguracion(@RequestBody FFConfiguracionDefaulteo c,
                                                                        @RequestHeader(value = "authorization", required = false) String token) {
        return guardarInterno(c, token);
    }

    @GetMapping("/configuraciones")
    public ResponseEntity<List<Object>> listarConfiguraciones(
            @RequestParam(required = false) Integer idCorporativo,
            @RequestParam(required = false) Integer idEmpresa,
            @RequestParam(required = false) Integer idAdmin,
            @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (idEmpresa != null && !service.tieneAccesoEmpresas(usuario.n, new int[] { idEmpresa })) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        try {
            List<Object> data = service.listarConfiguraciones(idCorporativo, idEmpresa, usuario.n);
            if (data == null || data.isEmpty()) {
                return new ResponseEntity<>(data, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] /configuraciones GET: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/configuraciones/{id}")
    public ResponseEntity<Void> eliminarConfiguracion(@PathVariable int id, @RequestParam int idAdmin,
                                                       @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!service.configuracionPerteneceAdministrador(id, usuario.n)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        try {
            service.eliminarConfiguracion(id, usuario.n);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            bitacora.error("[CREA06] /configuraciones DELETE: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
    }

    // -------------------------------------------------------------------------
    // Catalogo de perfiles activos (el endpoint /perfil/empresa/:id filtra demasiado)
    // -------------------------------------------------------------------------
    @GetMapping("/catalogo/perfiles")
    public ResponseEntity<List<Map<String, Object>>> listarPerfilesEmpresa(@RequestParam int idEmpresa,
                                                                           @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!service.tieneAccesoEmpresas(usuario.n, new int[] { idEmpresa })) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        try {
            List<Map<String, Object>> data = service.listarPerfilesEmpresa(idEmpresa);
            if (data == null || data.isEmpty()) {
                return new ResponseEntity<>(data, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] /catalogo/perfiles: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // -------------------------------------------------------------------------
    // RN007 - Descarga CSV del log de errores
    // -------------------------------------------------------------------------
    @GetMapping("/log-errores/{idLog}/descarga")
    public ResponseEntity<byte[]> descargarLogErrores(@PathVariable int idLog,
                                                       @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!service.lotePerteneceAdministrador(idLog, usuario.n)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        try {
            List<Map<String, Object>> eventos = service.obtenerEventosDeLote(idLog);
            byte[] csv = toCsv(eventos).getBytes(StandardCharsets.UTF_8);
            return ResponseEntity.ok()
                    .header("Content-Type",        "text/csv; charset=UTF-8")
                    .header("Content-Disposition", "attachment; filename=CREA06_log_errores_" + idLog + ".csv")
                    .body(csv);
        } catch (Exception e) {
            bitacora.error("[CREA06] /log-errores descarga: " + e.getMessage(), e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private ResponseEntity<Map<String, Object>> guardarInterno(FFConfiguracionDefaulteo c, String token) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (c == null || (c.idEmpresa != null
                && !service.tieneAccesoEmpresas(usuario.n, new int[] { c.idEmpresa }))) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        if (c.id != null && c.id > 0
                && !service.configuracionPerteneceAdministrador(c.id, usuario.n)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        c.idAdmin = usuario.n;
        try {
            Integer id = service.guardarConfiguracion(c);
            if (id == null || id <= 0) {
                throw new IllegalStateException("La configuracion no fue guardada");
            }
            Map<String, Object> resp = new java.util.HashMap<>();
            resp.put("id",     id);
            resp.put("exito",  Boolean.TRUE);
            return new ResponseEntity<>(resp, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error("[CREA06] guardar configuracion: " + e.getMessage(), e);
            Map<String, Object> resp = new java.util.HashMap<>();
            resp.put("exito",   Boolean.FALSE);
            resp.put("mensaje", e.getMessage());
            return new ResponseEntity<>(resp, HttpStatus.OK);
        }
    }

    private UsuarioToken usuarioAutenticado(String token) {
        try {
            if (token == null || !generalService.validarTokenId(0, token, 4)) return null;
            UsuarioToken usuario = jwtService.getPayloadFromToken(token);
            return usuario != null && usuario.n > 0 ? usuario : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String obtenerIp(HttpServletRequest req) {
        if (req == null) return null;
        String xff = req.getHeader("X-Forwarded-For");
        if (xff != null && !xff.isEmpty()) {
            int comma = xff.indexOf(',');
            return comma < 0 ? xff.trim() : xff.substring(0, comma).trim();
        }
        return req.getRemoteAddr();
    }

    private String toCsv(List<Map<String, Object>> filas) {
        StringBuilder sb = new StringBuilder();
        sb.append("LEDId,LEDIdLog,LEDIdEmpleado,LEDNumeroEmpleado,LEDIdEmpresa,LEDIdPerfil,")
          .append("LEDTipoEvento,LEDMensaje,LEDStackTrace,LEDFechaAdd\n");
        if (filas == null) return sb.toString();
        for (Map<String, Object> r : filas) {
            sb.append(esc(r.get("LEDId"))).append(',')
              .append(esc(r.get("LEDIdLog"))).append(',')
              .append(esc(r.get("LEDIdEmpleado"))).append(',')
              .append(esc(r.get("LEDNumeroEmpleado"))).append(',')
              .append(esc(r.get("LEDIdEmpresa"))).append(',')
              .append(esc(r.get("LEDIdPerfil"))).append(',')
              .append(esc(r.get("LEDTipoEvento"))).append(',')
              .append(esc(r.get("LEDMensaje"))).append(',')
              .append(esc(r.get("LEDStackTrace"))).append(',')
              .append(esc(r.get("LEDFechaAdd"))).append('\n');
        }
        return sb.toString();
    }

    private String esc(Object o) {
        if (o == null) return "";
        String s = o.toString();
        boolean needsQuote = s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0;
        if (!needsQuote) return s;
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }
}
