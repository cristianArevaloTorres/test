package com.lockton.WSBeFlex.Services;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lockton.WSBeFlex.DAO.FfDefaulteoAvanzadoDAO;
import com.lockton.WSBeFlex.DAO.FfTitularDAO;
import com.lockton.WSBeFlex.POJO.Especiales.FFDefaulteo;
import com.lockton.WSBeFlex.POJO.Especiales.FFEjecutarDefaulteoAvanzado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * CREA 06 - Ejecuta el lote de defaulteo en BACKGROUND (hilo del pool
 * "defaulteoExecutor"). Es un bean aparte para que el proxy de @Async aplique
 * (un @Async invocado desde el mismo bean NO se interceptaria).
 *
 * El flujo por empleado es identico al que vivia dentro de
 * {@link LogicaFfDefaulteoAvanzado#ejecutar}; lo unico que cambia es que ahora
 * corre fuera del request HTTP y va reportando avance al
 * {@link ProgresoDefaulteoRegistry} y los contadores finales a bf_LogDefaulteo.
 */
@Component
public class DefaulteoAvanzadoAsyncRunner {

    @Autowired
    private FfDefaulteoAvanzadoDAO dao;

    @Autowired
    private FfTitularService ffTitularService;

    @Autowired
    private FfTitularDAO ffTitularDao;

    @Autowired
    private ProgresoDefaulteoRegistry progreso;

    @Async("defaulteoExecutor")
    public void procesarLote(int idLog, FFEjecutarDefaulteoAvanzado req) {
        int totalEmpleados = req.idEmpleado != null ? req.idEmpleado.length : 0;
        int idAdmin        = req.idAdmin != null ? req.idAdmin : 0;
        int exitosos = 0;
        int errores  = 0;

        try {
            for (int i = 0; i < totalEmpleados; i++) {
                int idEmpleado = req.idEmpleado[i];
                String numEmpleado = (req.numEmpleado != null && i < req.numEmpleado.length)
                        ? req.numEmpleado[i] : null;
                Integer idEmpresaEmpleado = null;
                progreso.marcarEmpleadoActual(idLog, idEmpleado);

                try {
                    idEmpresaEmpleado = dao.obtenerEmpresaEmpleado(idEmpleado);
                    if (idEmpresaEmpleado == null) {
                        throw new IllegalStateException("No se encontro la empresa del empleado " + idEmpleado);
                    }
                    // RF001.1 - Reproceso por cambio de perfil ANTES del defaulteo normal.
                    if (req.idVigencia != null) {
                        try {
                            Map<String, Object> rfc = dao.reprocesarCambioPerfil(
                                    idEmpleado, req.idVigencia, idAdmin, idLog);
                            if (Boolean.TRUE.equals(rfc.get("huboCambio"))) {
                                System.out.println("[CREA06 RF001.1] Cambio de perfil reprocesado para empleado "
                                        + idEmpleado + " (perfilAnterior=" + rfc.get("idPerfilAnterior")
                                        + " -> perfilActual=" + rfc.get("idPerfilActual") + ")");
                            }
                        } catch (Exception rfcEx) {
                            System.out.println("[CREA06 RF001.1] reproceso fallo para empleado "
                                    + idEmpleado + ": " + rfcEx.getMessage());
                        }
                    }

                    Map<String, Object> contextoVigencia = dao.resolverContextoVigencia(
                            idEmpresaEmpleado, req.idVigencia);
                    FFDefaulteo unico = buildUnicoEmpleado(
                            req, idEmpleado, numEmpleado, idEmpresaEmpleado, contextoVigencia);

                    List<Object> resultado;
                    Set<Integer> coberturasForzadas = idPositivo(req.acciones != null
                            ? req.acciones.idCoberturaDestino : null);
                    Set<Integer> planesForzados = idPositivo(req.acciones != null
                            ? req.acciones.idPlanDestino : null);
                    if (!coberturasForzadas.isEmpty() || !planesForzados.isEmpty()) {
                        resultado = ffTitularDao.defaultearEmpleadosMasivoCasosEspeciales(
                                unico, coberturasForzadas, planesForzados);
                    } else {
                        resultado = ffTitularService.defaultearEmpleadosMasivo(unico);
                    }
                    validarResultadoMotor(resultado);
                    registrarOmisionesForzadas(idLog, idEmpleado, numEmpleado,
                            idEmpresaEmpleado, resultado);

                    // RF001.2 - Regla Scotiabank antiguedad plan de retiro (opt-in via acciones)
                    if (req.idVigencia != null
                            && req.acciones != null && Boolean.TRUE.equals(req.acciones.aplicarReglaAntiguedad)) {
                        int mesesMin = req.acciones.mesesAntiguedadMinimos != null
                                ? req.acciones.mesesAntiguedadMinimos : 6;
                        try {
                            Map<String, Object> ant = dao.aplicarAntiguedad(
                                    idEmpleado, req.idVigencia, idAdmin, idLog, mesesMin);
                            if (Boolean.TRUE.equals(ant.get("ajusteAplicado"))) {
                                System.out.println("[CREA06 RF001.2] Antiguedad insuficiente para empleado "
                                        + idEmpleado + " (" + ant.get("mesesAntiguedad") + " meses) - "
                                        + ant.get("coberturasRemovidas") + " coberturas de retiro removidas");
                            }
                        } catch (Exception antEx) {
                            System.out.println("[CREA06 RF001.2] aplicarAntiguedad fallo para empleado "
                                    + idEmpleado + ": " + antEx.getMessage());
                        }
                    }

                    exitosos++;
                    progreso.incrementar(idLog, true);
                } catch (Exception ex) {
                    errores++;
                    progreso.incrementar(idLog, false);
                    String msg = ex.getMessage() != null ? ex.getMessage() : ex.getClass().getName();
                    try {
                        dao.registrarEvento(idLog, idEmpleado, numEmpleado, idEmpresaEmpleado,
                                null, "ERROR", truncate(msg, 2000), stackTraceToString(ex), null);
                    } catch (Exception logEx) {
                        System.out.println("[CREA06] No se pudo registrar evento de error: " + logEx.getMessage());
                    }
                    System.out.println("[CREA06] ERROR defaulteo empleado " + idEmpleado + ": " + msg);
                }
            }

            String estadoFinal = errores > 0
                    ? ProgresoDefaulteoRegistry.COMPLETADO_CON_ERRORES
                    : ProgresoDefaulteoRegistry.COMPLETADO;
            dao.finalizarLote(idLog, totalEmpleados, exitosos, errores, estadoFinal);
            progreso.finalizar(idLog, estadoFinal);
        } catch (Exception fatal) {
            // Falla inesperada del lote completo: marcamos ERROR para que el front no quede colgado
            System.out.println("[CREA06] ERROR FATAL en lote " + idLog + ": " + fatal.getMessage());
            try {
                dao.finalizarLote(idLog, totalEmpleados, exitosos, errores, ProgresoDefaulteoRegistry.ERROR);
            } catch (Exception ignore) { /* best effort */ }
            progreso.finalizar(idLog, ProgresoDefaulteoRegistry.ERROR);
        }
    }

    // -------------------------------------------------------------------------
    private FFDefaulteo buildUnicoEmpleado(FFEjecutarDefaulteoAvanzado req, int idEmpleado,
                                           String numEmpleado, Integer idEmpresaEmpleado,
                                           Map<String, Object> contextoVigencia) {
        if (!toBoolean(contextoVigencia.get("esValida"))) {
            throw new IllegalArgumentException("La vigencia seleccionada no pertenece a la empresa del empleado");
        }
        FFDefaulteo d = req.toFfDefaulteo();
        d.idEmpleado  = new int[]{ idEmpleado };
        d.numEmpleado = new String[]{ numEmpleado };
        d.idEmpresa   = new int[]{ idEmpresaEmpleado };
        Integer actual = toInteger(contextoVigencia.get("idVigenciaActual"));
        if (toBoolean(contextoVigencia.get("esActual"))) {
            d.setIdVigencia(0);
            d.setIdVigenciaAnterior(0);
            d.setIdVigenciaVigente(actual != null ? actual : req.idVigencia);
        } else {
            d.setIdVigencia(req.idVigencia);
            // El campo legado se llama "Anterior", pero JDBCFfTitular lo envia
            // como idVigenciaD/idVigencia del destino multivigencia.
            d.setIdVigenciaAnterior(req.idVigencia);
            d.setIdVigenciaVigente(actual != null ? actual : 0);
        }
        return d;
    }

    private Set<Integer> idPositivo(Integer id) {
        return id != null && id > 0
                ? new HashSet<Integer>(Collections.singleton(id))
                : Collections.<Integer>emptySet();
    }

    private void validarResultadoMotor(List<Object> resultado) {
        if (resultado == null || resultado.isEmpty()) {
            throw new IllegalStateException("El motor de defaulteo no devolvio resultado");
        }
        Object fila = resultado.get(0);
        Object valor = fila instanceof Map ? ((Map<?, ?>) fila).get("resultado") : fila;
        String texto = valor != null ? String.valueOf(valor) : "";
        if (!texto.contains("_ok")) {
            throw new IllegalStateException(texto.isEmpty()
                    ? "El motor de defaulteo no confirmo la solicitud"
                    : texto);
        }
    }

    private void registrarOmisionesForzadas(int idLog, int idEmpleado, String numEmpleado,
                                             Integer idEmpresa, List<Object> resultado) {
        if (resultado == null || resultado.isEmpty() || !(resultado.get(0) instanceof Map)) return;
        Map<?, ?> fila = (Map<?, ?>) resultado.get(0);
        Object coberturas = fila.get("forzadasOmitidas");
        Object planes = fila.get("planesOmitidos");
        if (tieneElementos(coberturas) || tieneElementos(planes)) {
            try {
                dao.registrarEvento(idLog, idEmpleado, numEmpleado, idEmpresa, null,
                        "WARN_COBERTURA",
                        "Algunas condiciones forzadas no eran elegibles para el empleado",
                        null, "{\"coberturasOmitidas\":\"" + escaparJson(coberturas)
                                + "\",\"planesOmitidos\":\"" + escaparJson(planes) + "\"}");
            } catch (Exception logEx) {
                System.out.println("[CREA06] No se pudo registrar advertencia de condiciones forzadas: "
                        + logEx.getMessage());
            }
        }
    }

    private boolean tieneElementos(Object value) {
        return value instanceof List && !((List<?>) value).isEmpty();
    }

    private String escaparJson(Object value) {
        return String.valueOf(value).replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private Integer toInteger(Object value) {
        if (value == null) return null;
        if (value instanceof Number) return ((Number) value).intValue();
        try { return Integer.valueOf(String.valueOf(value)); }
        catch (Exception e) { return null; }
    }

    private boolean toBoolean(Object value) {
        if (value instanceof Boolean) return ((Boolean) value).booleanValue();
        if (value instanceof Number) return ((Number) value).intValue() != 0;
        return "true".equalsIgnoreCase(String.valueOf(value)) || "1".equals(String.valueOf(value));
    }

    private String stackTraceToString(Throwable t) {
        try {
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            return sw.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private String truncate(String s, int max) {
        if (s == null) return null;
        return s.length() <= max ? s : s.substring(0, max);
    }
}
