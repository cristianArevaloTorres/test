package com.lockton.rpt.repositories.jdbc;

import com.lockton.rpt.models.dto.DefaulteoHistoricoDTO;
import com.lockton.rpt.repositories.DefaulteoHistoricoRepository;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JDBCDefaulteoHistoricoRepository implements DefaulteoHistoricoRepository {
    private final JdbcTemplate jdbcTemplate;

    public JDBCDefaulteoHistoricoRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public boolean puedeConsultarEmpresa(int idAdministrador, int idEmpresaSesion, int idEmpresaConsulta) {
        Integer autorizado = jdbcTemplate.queryForObject(
                "SELECT CASE WHEN EXISTS ("
                + "SELECT 1 FROM dbo.ff_Empresa e "
                + "WHERE e.EMIdEmpresa = ? AND e.EMIdEstatus = 1 "
                + "AND (e.EMIdEmpresa = ? OR EXISTS ("
                + "SELECT 1 FROM dbo.ff_AdministradorEmpresa ae "
                + "WHERE ae.ADIdAdministrador = ? AND ae.AEIdEmpresa = e.EMIdEmpresa "
                + "AND ae.AEIdEstatus = 1))) THEN 1 ELSE 0 END",
                Integer.class, idEmpresaConsulta, idEmpresaSesion, idAdministrador);
        return Integer.valueOf(1).equals(autorizado);
    }

    @Override
    public List<DefaulteoHistoricoDTO> consultar(int idEmpresa, LocalDate fechaInicio, LocalDate fechaFin) {
        return jdbcTemplate.query(
                "EXEC dbo.bf_ReporteDefaulteo_Consultar @IdEmpresa=?, @FechaInicio=?, @FechaFin=?",
                (rs, rowNum) -> {
                    DefaulteoHistoricoDTO row = new DefaulteoHistoricoDTO();
                    row.setIdEmpresa(rs.getInt("idEmpresa"));
                    row.setNumeroEmpleado(rs.getString("numeroEmpleado"));
                    row.setNombreEmpleado(rs.getString("nombreEmpleado"));
                    row.setCostoAnual(rs.getBigDecimal("costoAnual"));
                    int idUsuario = rs.getInt("idUsuario");
                    row.setIdUsuario(rs.wasNull() ? null : idUsuario);
                    Date fecha = rs.getDate("fechaDefaulteo");
                    row.setFechaDefaulteo(fecha == null ? null : fecha.toLocalDate());
                    return row;
                },
                idEmpresa, Date.valueOf(fechaInicio), Date.valueOf(fechaFin));
    }
}
