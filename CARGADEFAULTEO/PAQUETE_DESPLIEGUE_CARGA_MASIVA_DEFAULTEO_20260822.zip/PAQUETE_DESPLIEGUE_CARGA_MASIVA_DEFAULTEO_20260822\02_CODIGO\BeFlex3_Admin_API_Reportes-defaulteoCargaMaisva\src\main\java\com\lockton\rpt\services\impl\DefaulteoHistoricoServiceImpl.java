package com.lockton.rpt.services.impl;

import com.lockton.rpt.models.dto.DefaulteoHistoricoDTO;
import com.lockton.rpt.repositories.DefaulteoHistoricoRepository;
import com.lockton.rpt.services.DefaulteoHistoricoService;
import java.time.LocalDate;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DefaulteoHistoricoServiceImpl implements DefaulteoHistoricoService {
    private final DefaulteoHistoricoRepository repository;

    public DefaulteoHistoricoServiceImpl(DefaulteoHistoricoRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<DefaulteoHistoricoDTO> consultar(
            int idAdministrador, int idEmpresaSesion, int idEmpresa,
            LocalDate fechaInicio, LocalDate fechaFin) {
        if (idEmpresa <= 0) throw new IllegalArgumentException("La empresa es obligatoria.");
        if (idEmpresaSesion <= 0) throw new IllegalArgumentException("La empresa de la sesión es obligatoria.");
        if (fechaInicio == null || fechaFin == null) {
            throw new IllegalArgumentException("El rango de fechas es obligatorio.");
        }
        if (fechaFin.isBefore(fechaInicio)) {
            throw new IllegalArgumentException("La fecha final no puede ser menor que la fecha inicial.");
        }
        if (!repository.puedeConsultarEmpresa(idAdministrador, idEmpresaSesion, idEmpresa)) {
            throw new SecurityException("El administrador no tiene acceso a la empresa solicitada.");
        }
        return repository.consultar(idEmpresa, fechaInicio, fechaFin);
    }
}
