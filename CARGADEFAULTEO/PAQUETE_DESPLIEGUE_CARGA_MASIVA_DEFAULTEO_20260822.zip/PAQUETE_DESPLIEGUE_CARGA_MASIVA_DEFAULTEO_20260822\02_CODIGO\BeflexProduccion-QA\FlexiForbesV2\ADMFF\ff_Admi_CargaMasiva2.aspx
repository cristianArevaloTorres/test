<%@ Page Language="c#" CodeBehind="ff_Admi_CargaMasiva2.aspx.cs" MasterPageFile="~/Master/BlueSkyMasterHorizontal.Master"
    AutoEventWireup="false" Inherits="FlexiForbesV2.ADMFF.ff_Admi_CargaMasiva2" %>

<%@ Register TagPrefix="cmn" Namespace="FlexiForbesV2.comun" Assembly="FlexiForbesV2" %>
<asp:Content ID="Content1" ContentPlaceHolderID="Contenido" runat="server">
    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
    <head>
        <title>ff_Admi_CargaMasiva2</title>
        <meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
        <meta content="C#" name="CODE_LANGUAGE">
        <meta content="JavaScript" name="vs_defaultClientScript">
        <meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
        <script language="JavaScript" type="text/javascript" charset="UTF-8" src="ff_Admi_CargaMasiva2.js"></script>
    </head>
    <cmn:CLEstilosControl ID="css_PageStyler" runat="server" Redirect="false" />
    <div align="center">
        <asp:Label ID="lbl_Titulo" runat="server" CssClass="ClaTitulo">Carga Masiva</asp:Label>
    </div>
    <div align="center">
        <fieldset style="width: 500px">
            <legend align="left" class="ClaInLegend" style="font-weight: bold; font-size: 10pt;
                background-color: transparent">Opciones</legend>
            <table>
                <tr>
                    <td colspan="3" align="left" style="padding-bottom: 8px">
                        <asp:Label ID="lbl_FlujoConfigurado" runat="server" CssClass="ClaEtiqueta" />
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <asp:label runat="server" CssClass="ClaEtiqueta">Operaci&oacute;n de Carga Masiva:</asp:label>
                    </td>
                    <td align="left">
                        <asp:DropDownList ID="ddl_CargaMasivaOperaciones" runat="server" CssClass="ClaInSelect"
                            AutoPostBack="True" Width="200px" />
                    </td>
                    <td align="left">
                        <asp:CustomValidator ID="cv_ValidateOperacion" runat="server" ClientValidationFunction="f_ValidarOperacion"
                            ErrorMessage="Debe seleccionar una operación.">*</asp:CustomValidator>
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <asp:label runat="server" CssClass="ClaEtiqueta">Documento de datos:</asp:label>
                    </td>
                    <td align="left">
                        <asp:DropDownList ID="ddl_CargaMasivaDocumentos" runat="server" CssClass="ClaInSelect"
                            AutoPostBack="True" Width="200px" />
                    </td>
                    <td>
                        <asp:CustomValidator ID="cv_ValidateDocumento" runat="server" ClientValidationFunction="f_ValidarDocumento"
                            ErrorMessage="Debe seleccionar un documento.">*</asp:CustomValidator>
                    </td>
                </tr>
                <tr>
                    <td align="right">
                    <asp:Label runat="server" CssClass="ClaEtiqueta">Modo de ejecuci&oacute;n:</asp:Label>
                        
                    </td>
                    <td colspan="2">
                        <asp:RadioButtonList ID="rdo_ModoEjecucion" runat="server" CssClass="ClaInRadio">
                            <asp:ListItem Selected="True" Value="0">Ejecutar hasta el primer error</asp:ListItem>
                            <asp:ListItem Value="1">Ejecutar todo (saltar errores)</asp:ListItem>
                        </asp:RadioButtonList>
                    </td>
                </tr>
            </table>
        </fieldset>
        <table id="tbl_Buttons">
            <tr>
                <td style="padding-top: 15px">
                    <asp:Button ID="btn_IniciarCarga" runat="server" CssClass="ClaBoton" Text="Iniciar" />
                </td>
                <td style="padding-top: 15px">
                    <asp:Button ID="btn_Cancelar" runat="server" CssClass="ClaBoton" Text="Cancelar"
                        CausesValidation="False" />
                </td>
                <td style="padding-top: 15px">
                    <asp:Button ID="btn_MostrarLog" runat="server" CssClass="ClaBoton" Text="Ver Reporte"
                        CausesValidation="False" Enabled="False" />
                </td>
                <td style="padding-top: 15px">
                    <asp:Button ID="btn_EditarDocumento" runat="server" CssClass="ClaBoton" Text="Editar Documento"
                        Enabled="False" />
                </td>
            </tr>
        </table>
        <br>
        <br>
        <table id="tbl_Editor" runat="server">
            <tr>
                <td>
                    <asp:TextBox ID="txt_CargaMasivaData" runat="server" TextMode="MultiLine" Rows="15"
                        Columns="100" Wrap="False" />
                </td>
            </tr>
            <tr>
                <td align="right" style="padding: 10px">
                    <asp:Button ID="btn_GuardarDocumento" runat="server" CssClass="ClaBoton" CausesValidation="False"
                        Text="Guardar" />
                    &nbsp;&nbsp;&nbsp;
                    <asp:Button ID="btn_CancelarEdicion" runat="server" CssClass="ClaBoton" CausesValidation="False"
                        Text="Cancelar" />
                </td>
            </tr>
        </table>
    </div>
    <%-- Campos Ocultos --%>
    <input id="txt_TipoEmpresa" runat="server" type="hidden" name="txt_TipoEmpresa">
    <input id="txt_LogFilename" runat="server" type="hidden" name="txt_LogFilename">
    <input id="txt_IdDocumentoEdicion" runat="server" type="hidden" name="txt_IdDocumentoEdicion">
</asp:Content>
