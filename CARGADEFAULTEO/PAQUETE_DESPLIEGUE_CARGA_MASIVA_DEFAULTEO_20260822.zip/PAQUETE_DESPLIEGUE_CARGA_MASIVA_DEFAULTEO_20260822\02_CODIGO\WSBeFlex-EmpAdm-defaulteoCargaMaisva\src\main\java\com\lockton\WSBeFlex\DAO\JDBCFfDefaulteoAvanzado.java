package com.lockton.WSBeFlex.DAO;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionDefaulteo;
import com.lockton.WSBeFlex.POJO.Especiales.FFFiltroDefaulteoAvanzado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SingleColumnRowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

/**
 * CREA 06 - Implementacion JDBC del DAO de defaulteo avanzado.
 *
 * Mapea contra los SPs aplicados en BD el 2026-05-31:
 *   bf_DefaulteoAvanzado_Buscar
 *   bf_LogDefaulteo_IniciarLote / RegistrarEvento / FinalizarLote
 *   bf_ConfiguracionDefaulteo_Guardar / Eliminar / Listar
 */
@Repository
public class JDBCFfDefaulteoAvanzado implements FfDefaulteoAvanzadoDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Override
    public boolean tieneAccesoEmpresas(int idAdmin, int[] idsEmpresa) {
        Set<Integer> ids = enterosPositivos(idsEmpresa);
        if (idAdmin <= 0 || idsEmpresa == null || ids.isEmpty()
                || ids.size() != idsEmpresa.length) return false;

        String placeholders = String.join(",", java.util.Collections.nCopies(ids.size(), "?"));
        List<Object> parametros = new ArrayList<>();
        parametros.add(idAdmin);
        parametros.addAll(ids);
        Integer total = jdbcTemplate.queryForObject(
                "SELECT COUNT(DISTINCT AE.AEIdEmpresa) "
                + "FROM dbo.ff_AdministradorEmpresa AE "
                + "INNER JOIN dbo.ff_Empresa E ON E.EMIdEmpresa=AE.AEIdEmpresa AND E.EMIdEstatus=1 "
                + "WHERE AE.ADIdAdministrador=? AND AE.AEIdEstatus=1 "
                + "AND AE.AEIdEmpresa IN (" + placeholders + ")",
                parametros.toArray(), Integer.class);
        return total != null && total == ids.size();
    }

    @Override
    public boolean tieneAccesoEmpleados(int idAdmin, int[] idsEmpleado) {
        Set<Integer> ids = enterosPositivos(idsEmpleado);
        if (idAdmin <= 0 || idsEmpleado == null || ids.isEmpty()
                || ids.size() != idsEmpleado.length) return false;

        List<Integer> lista = new ArrayList<>(ids);
        for (int inicio = 0; inicio < lista.size(); inicio += 1000) {
            List<Integer> bloque = lista.subList(inicio, Math.min(inicio + 1000, lista.size()));
            String placeholders = String.join(",", java.util.Collections.nCopies(bloque.size(), "?"));
            List<Object> parametros = new ArrayList<>();
            parametros.add(idAdmin);
            parametros.addAll(bloque);
            Integer total = jdbcTemplate.queryForObject(
                    "SELECT COUNT(DISTINCT E.Id) "
                    + "FROM dbo.ff_Empleado E "
                    + "INNER JOIN dbo.ff_AdministradorEmpresa AE ON AE.AEIdEmpresa=E.EMIdEmpresa "
                    + "AND AE.ADIdAdministrador=? AND AE.AEIdEstatus=1 "
                    + "WHERE E.Id IN (" + placeholders + ")",
                    parametros.toArray(), Integer.class);
            if (total == null || total != bloque.size()) return false;
        }
        return true;
    }

    @Override
    public boolean lotePerteneceAdministrador(int idLog, int idAdmin) {
        if (idLog <= 0 || idAdmin <= 0) return false;
        Integer total = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM dbo.bf_LogDefaulteo WHERE LDId=? AND LDIdAdmin=?",
                new Object[] { idLog, idAdmin }, Integer.class);
        return total != null && total > 0;
    }

    @Override
    public boolean configuracionPerteneceAdministrador(int idConfiguracion, int idAdmin) {
        if (idConfiguracion <= 0 || idAdmin <= 0) return false;
        Integer total = jdbcTemplate.queryForObject(
                "SELECT COUNT(1) FROM dbo.bf_ConfiguracionDefaulteo "
                + "WHERE CDId=? AND CDIdAdmin=? AND CDIdEstatus=1",
                new Object[] { idConfiguracion, idAdmin }, Integer.class);
        return total != null && total > 0;
    }

    @Override
    public Integer obtenerEmpresaEmpleado(int idEmpleado) {
        List<Integer> empresas = jdbcTemplate.query(
                "SELECT EMIdEmpresa FROM dbo.ff_Empleado WHERE Id=?",
                new Object[] { idEmpleado },
                (rs, rowNum) -> rs.getInt("EMIdEmpresa"));
        return empresas.isEmpty() ? null : empresas.get(0);
    }

    @Override
    public Map<String, Object> resolverContextoVigencia(int idEmpresa, int idVigenciaSeleccionada) {
        Map<String, Object> in = new HashMap<>();
        in.put("IdEmpresa", idEmpresa);
        in.put("IdVigenciaSeleccionada", idVigenciaSeleccionada);
        Map<String, Object> out = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_DefaulteoAvanzado_ResolverVigencia")
                .execute(new MapSqlParameterSource(in));
        for (Object value : out.values()) {
            if (value instanceof List && !((List<?>) value).isEmpty()) {
                Object row = ((List<?>) value).get(0);
                if (row instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> result = (Map<String, Object>) row;
                    return result;
                }
            }
        }
        return java.util.Collections.emptyMap();
    }

    private Set<Integer> enterosPositivos(int[] valores) {
        Set<Integer> ids = new HashSet<>();
        if (valores != null) {
            Arrays.stream(valores).filter(v -> v > 0).forEach(ids::add);
        }
        return ids;
    }

    // -------------------------------------------------------------------------
    // Busqueda
    // -------------------------------------------------------------------------
    @Override
    public List<Object> buscarEmpleados(FFFiltroDefaulteoAvanzado f) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_DefaulteoAvanzado_Buscar");

        Map<String, Object> in = new HashMap<>();
        in.put("IdCorporativo",       f.idCorporativo);
        in.put("IdVigencia",          f.idVigencia);
        in.put("IdsEmpresa",          toCsvInt(f.idsEmpresa));
        in.put("IdsPerfil",           toCsvInt(f.idsPerfil));
        in.put("IdsOficina",          toCsvInt(f.idsOficina));
        in.put("IdsArea",             toCsvInt(f.idsArea));
        in.put("IdsSexo",             toCsvInt(f.idsSexo));
        in.put("IdsParentesco",       toCsvInt(f.idsParentesco));
        in.put("IdsPlan",             toCsvInt(f.idsPlan));
        in.put("IdsCobertura",        toCsvInt(f.idsCobertura));
        in.put("NumerosEmpleado",     toCsvStr(f.numerosEmpleado));
        in.put("SalarioMin",          f.salarioMin);
        in.put("SalarioMax",          f.salarioMax);
        in.put("SumaAseguradaMin",    f.sumaAseguradaMin);
        in.put("SumaAseguradaMax",    f.sumaAseguradaMax);
        in.put("FechaIngresoIni",     toTs(f.fechaIngresoIni));
        in.put("FechaIngresoFin",     toTs(f.fechaIngresoFin));
        in.put("FechaAntiguedadIni",  toTs(f.fechaAntiguedadIni));
        in.put("FechaAntiguedadFin",  toTs(f.fechaAntiguedadFin));
        in.put("FechaNacimientoIni",  toTs(f.fechaNacimientoIni));
        in.put("FechaNacimientoFin",  toTs(f.fechaNacimientoFin));
        in.put("FechaVigenciaIni",    toTs(f.fechaVigenciaIni));
        in.put("FechaVigenciaFin",    toTs(f.fechaVigenciaFin));
        in.put("Nombre",              f.nombre);
        in.put("ApellidoPaterno",     f.apellidoPaterno);
        in.put("ApellidoMaterno",     f.apellidoMaterno);
        in.put("EdadMin",             f.edadMin);
        in.put("EdadMax",             f.edadMax);
        in.put("Top",                 f.top != null ? f.top : 1000);

        SqlParameterSource src = new MapSqlParameterSource(in);
        Map<String, Object> result = call.execute(src);
        return new ArrayList<>(result.values());
    }

    // -------------------------------------------------------------------------
    // Auditoria
    // -------------------------------------------------------------------------
    @Override
    public Integer iniciarLote(Integer idConfiguracion, Integer idCorporativo, Integer idEmpresa,
                               Integer idVigencia, int idAdmin, String filtrosJson, String accionesJson,
                               int totalEmpleados, String ipOrigen, String origen) {

        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_LogDefaulteo_IniciarLote")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("IdConfiguracion", Types.INTEGER),
                        new SqlParameter("IdCorporativo",   Types.INTEGER),
                        new SqlParameter("IdEmpresa",       Types.INTEGER),
                        new SqlParameter("IdVigencia",      Types.INTEGER),
                        new SqlParameter("IdAdmin",         Types.INTEGER),
                        new SqlParameter("FiltrosJson",     Types.NVARCHAR),
                        new SqlParameter("AccionesJson",    Types.NVARCHAR),
                        new SqlParameter("TotalEmpleados",  Types.INTEGER),
                        new SqlParameter("IpOrigen",        Types.VARCHAR),
                        new SqlParameter("Origen",          Types.VARCHAR),
                        new SqlOutParameter("IdLog",        Types.INTEGER)
                );

        Map<String, Object> in = new HashMap<>();
        in.put("IdConfiguracion", idConfiguracion);
        in.put("IdCorporativo",   idCorporativo);
        in.put("IdEmpresa",       idEmpresa);
        in.put("IdVigencia",      idVigencia);
        in.put("IdAdmin",         idAdmin);
        in.put("FiltrosJson",     filtrosJson);
        in.put("AccionesJson",    accionesJson);
        in.put("TotalEmpleados",  totalEmpleados);
        in.put("IpOrigen",        ipOrigen);
        in.put("Origen",          origen != null ? origen : "AVANZADO");

        Map<String, Object> out = call.execute(new MapSqlParameterSource(in));
        Object idLog = out.get("IdLog");
        return idLog == null ? null : ((Number) idLog).intValue();
    }

    @Override
    public void registrarEvento(int idLog, int idEmpleado, String numEmpleado, Integer idEmpresa,
                                Integer idPerfil, String tipoEvento, String mensaje,
                                String stackTrace, String contextoJson) {

        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_LogDefaulteo_RegistrarEvento");

        Map<String, Object> in = new HashMap<>();
        in.put("IdLog",          idLog);
        in.put("IdEmpleado",     idEmpleado);
        in.put("NumeroEmpleado", numEmpleado);
        in.put("IdEmpresa",      idEmpresa);
        in.put("IdPerfil",       idPerfil);
        in.put("TipoEvento",     tipoEvento);
        in.put("Mensaje",        mensaje);
        in.put("StackTrace",     stackTrace);
        in.put("ContextoJson",   contextoJson);

        call.execute(new MapSqlParameterSource(in));
    }

    @Override
    public void finalizarLote(int idLog, Integer totalEmpleados, Integer totalExitosos,
                              Integer totalErrores, String estado) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_LogDefaulteo_FinalizarLote")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("IdLog",          Types.INTEGER),
                        new SqlParameter("TotalEmpleados", Types.INTEGER),
                        new SqlParameter("TotalExitosos",  Types.INTEGER),
                        new SqlParameter("TotalErrores",   Types.INTEGER),
                        new SqlParameter("Estado",         Types.VARCHAR)
                );

        Map<String, Object> in = new HashMap<>();
        in.put("IdLog",          idLog);
        in.put("TotalEmpleados", totalEmpleados);
        in.put("TotalExitosos",  totalExitosos);
        in.put("TotalErrores",   totalErrores);
        in.put("Estado",         estado);

        call.execute(new MapSqlParameterSource(in));
    }

    @Override
    public Map<String, Object> consultarLote(int idLog) {
        try {
            SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName("bf_LogDefaulteo_ConsultarLote");
            Map<String, Object> out = call.execute(new MapSqlParameterSource("IdLog", idLog));
            Map<String, Object> row = firstRow(out);
            return row;
        } catch (Exception e) {
            return null;
        }
    }

    // -------------------------------------------------------------------------
    // Configuraciones (CRUD)
    // -------------------------------------------------------------------------
    @Override
    public Integer guardarConfiguracion(FFConfiguracionDefaulteo c) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_ConfiguracionDefaulteo_Guardar")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("Id",            Types.INTEGER),
                        new SqlParameter("Nombre",        Types.VARCHAR),
                        new SqlParameter("Descripcion",   Types.VARCHAR),
                        new SqlParameter("IdCorporativo", Types.INTEGER),
                        new SqlParameter("IdEmpresa",     Types.INTEGER),
                        new SqlParameter("IdAdmin",       Types.INTEGER),
                        new SqlParameter("FiltrosJson",   Types.NVARCHAR),
                        new SqlParameter("AccionesJson",  Types.NVARCHAR),
                        new SqlOutParameter("IdResult",   Types.INTEGER)
                );

        Map<String, Object> in = new HashMap<>();
        in.put("Id",            c.id);
        in.put("Nombre",        c.nombre);
        in.put("Descripcion",   c.descripcion);
        in.put("IdCorporativo", c.idCorporativo);
        in.put("IdEmpresa",     c.idEmpresa);
        in.put("IdAdmin",       c.idAdmin);
        in.put("FiltrosJson",   c.filtrosJson);
        in.put("AccionesJson",  c.accionesJson);

        Map<String, Object> out = call.execute(new MapSqlParameterSource(in));
        Object id = out.get("IdResult");
        return id == null ? null : ((Number) id).intValue();
    }

    @Override
    public void eliminarConfiguracion(int id, int idAdmin) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_ConfiguracionDefaulteo_Eliminar");

        Map<String, Object> in = new HashMap<>();
        in.put("Id",      id);
        in.put("IdAdmin", idAdmin);

        call.execute(new MapSqlParameterSource(in));
    }

    @Override
    public List<Object> listarConfiguraciones(Integer idCorporativo, Integer idEmpresa, Integer idAdmin) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_ConfiguracionDefaulteo_Listar");

        Map<String, Object> in = new HashMap<>();
        in.put("IdCorporativo", idCorporativo);
        in.put("IdEmpresa",     idEmpresa);
        in.put("IdAdmin",       idAdmin);

        Map<String, Object> result = call.execute(new MapSqlParameterSource(in));
        return new ArrayList<>(result.values());
    }

    // -------------------------------------------------------------------------
    // Catalogo de perfiles activos por empresa (sin filtros adicionales del endpoint legacy)
    // -------------------------------------------------------------------------
    @Override
    public List<Map<String, Object>> listarPerfilesEmpresa(int idEmpresa) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_DefaulteoAvanzado_ListarPerfilesEmpresa");
        Map<String, Object> out = call.execute(new MapSqlParameterSource("IdEmpresa", idEmpresa));
        return firstResultSet(out);
    }

    // -------------------------------------------------------------------------
    // Eventos de un lote (descarga XLSX/CSV)
    // -------------------------------------------------------------------------
    @Override
    public List<Map<String, Object>> obtenerEventosDeLote(int idLog) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_LogDefaulteo_ObtenerEventos");
        Map<String, Object> out = call.execute(new MapSqlParameterSource("IdLog", idLog));
        return firstResultSet(out);
    }

    // -------------------------------------------------------------------------
    // RF001.2 - Aplica regla de antiguedad (Scotiabank plan de retiro)
    // -------------------------------------------------------------------------
    @Override
    public Map<String, Object> aplicarAntiguedad(int idEmpleado, int idVigencia, int idAdmin,
                                                 Integer idLog, int mesesMinimos) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_DefaulteoAvanzado_AplicaAntiguedad")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("IdEmpleado",             Types.INTEGER),
                        new SqlParameter("IdVigencia",             Types.INTEGER),
                        new SqlParameter("IdAdmin",                Types.INTEGER),
                        new SqlParameter("IdLog",                  Types.INTEGER),
                        new SqlParameter("MesesMinimos",           Types.INTEGER),
                        new SqlOutParameter("MesesAntiguedad",     Types.INTEGER),
                        new SqlOutParameter("AjusteAplicado",      Types.BIT),
                        new SqlOutParameter("CoberturasRemovidas", Types.INTEGER),
                        new SqlOutParameter("IdSolicitud",         Types.INTEGER)
                );

        Map<String, Object> in = new HashMap<>();
        in.put("IdEmpleado",   idEmpleado);
        in.put("IdVigencia",   idVigencia);
        in.put("IdAdmin",      idAdmin);
        in.put("IdLog",        idLog);
        in.put("MesesMinimos", mesesMinimos);

        Map<String, Object> out = call.execute(new MapSqlParameterSource(in));

        Map<String, Object> resp = new HashMap<>();
        Object aj = out.get("AjusteAplicado");
        resp.put("mesesAntiguedad",     out.get("MesesAntiguedad"));
        resp.put("ajusteAplicado",      aj != null && ((Number) aj).intValue() == 1);
        resp.put("coberturasRemovidas", out.get("CoberturasRemovidas"));
        resp.put("idSolicitud",         out.get("IdSolicitud"));
        return resp;
    }

    // -------------------------------------------------------------------------
    // RF001.1 - Reproceso por cambio de perfil
    // -------------------------------------------------------------------------
    @Override
    public Map<String, Object> reprocesarCambioPerfil(int idEmpleado, int idVigencia, int idAdmin, Integer idLog) {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("bf_DefaulteoAvanzado_ReprocesarCambioPerfil")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("IdEmpleado",          Types.INTEGER),
                        new SqlParameter("IdVigencia",          Types.INTEGER),
                        new SqlParameter("IdAdmin",             Types.INTEGER),
                        new SqlParameter("IdLog",               Types.INTEGER),
                        new SqlOutParameter("HuboCambio",       Types.BIT),
                        new SqlOutParameter("IdPerfilActual",   Types.INTEGER),
                        new SqlOutParameter("IdPerfilAnterior", Types.INTEGER),
                        new SqlOutParameter("IdSolicitudAnterior", Types.INTEGER)
                );

        Map<String, Object> in = new HashMap<>();
        in.put("IdEmpleado", idEmpleado);
        in.put("IdVigencia", idVigencia);
        in.put("IdAdmin",    idAdmin);
        in.put("IdLog",      idLog);

        Map<String, Object> out = call.execute(new MapSqlParameterSource(in));

        Map<String, Object> resp = new HashMap<>();
        Object hubo = out.get("HuboCambio");
        resp.put("huboCambio",          hubo != null && ((Number) hubo).intValue() == 1);
        resp.put("idPerfilActual",      out.get("IdPerfilActual"));
        resp.put("idPerfilAnterior",    out.get("IdPerfilAnterior"));
        resp.put("idSolicitudAnterior", out.get("IdSolicitudAnterior"));
        return resp;
    }

    // -------------------------------------------------------------------------
    // CREA06 R2 (minuta 22-jun) - deteccion de cambio de perfil via historial OFICIAL de
    // ediciones (bf_EdicionEmpresaEmpleado), acotado a la ventana de vigencia.
    // Toda la deteccion vive en el SP bf_DefaulteoAvanzado_DetectarCambioPerfilEdicion:
    //   - OUTPUT params: HuboCambio, MotivoCambio, IdPerfil/Empresa actual/anterior, etc.
    //   - 1 result set: coberturas del perfil anterior sin equivalente (por nombre) en el actual.
    // Best-effort: nunca rompe el defaulteo (TRY/CATCH aqui y dentro del SP).
    // -------------------------------------------------------------------------
    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> detectarCambioPerfilEdicion(int idEmpleado, int idVigenciaActual, int idVigenciaAnterior) {
        Map<String, Object> r = new HashMap<>();
        r.put("huboCambio", Boolean.FALSE);
        r.put("motivoCambio", null);
        try {
            SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName("bf_DefaulteoAvanzado_DetectarCambioPerfilEdicion")
                    .withoutProcedureColumnMetaDataAccess()
                    .declareParameters(
                            new SqlParameter("IdEmpleado",            Types.INTEGER),
                            new SqlParameter("IdVigenciaActual",      Types.INTEGER),
                            new SqlParameter("IdVigenciaAnterior",    Types.INTEGER),
                            new SqlOutParameter("HuboCambio",           Types.BIT),
                            new SqlOutParameter("MotivoCambio",         Types.VARCHAR),
                            new SqlOutParameter("IdPerfilActual",       Types.INTEGER),
                            new SqlOutParameter("PerfilActualNombre",   Types.NVARCHAR),
                            new SqlOutParameter("IdPerfilAnterior",     Types.INTEGER),
                            new SqlOutParameter("PerfilAnteriorNombre", Types.NVARCHAR),
                            new SqlOutParameter("FechaCambio",          Types.TIMESTAMP),
                            new SqlOutParameter("EmpresaAnterior",      Types.INTEGER),
                            new SqlOutParameter("EmpresaActual",        Types.INTEGER))
                    .returningResultSet("coberturas", new SingleColumnRowMapper<>(String.class));

            Map<String, Object> in = new HashMap<>();
            in.put("IdEmpleado",         idEmpleado);
            in.put("IdVigenciaActual",   idVigenciaActual);
            in.put("IdVigenciaAnterior", idVigenciaAnterior);

            Map<String, Object> out = call.execute(new MapSqlParameterSource(in));

            r.put("huboCambio",           asBool(out.get("HuboCambio")) ? Boolean.TRUE : Boolean.FALSE);
            r.put("motivoCambio",         out.get("MotivoCambio"));
            r.put("idPerfilActual",       asInt(out.get("IdPerfilActual")));
            r.put("perfilActualNombre",   out.get("PerfilActualNombre"));
            r.put("idPerfilAnterior",     asInt(out.get("IdPerfilAnterior")));
            r.put("perfilAnteriorNombre", out.get("PerfilAnteriorNombre"));
            r.put("fechaCambio",          out.get("FechaCambio"));
            r.put("empresaAnterior",      asInt(out.get("EmpresaAnterior")));
            r.put("empresaActual",        asInt(out.get("EmpresaActual")));

            Object cob = out.get("coberturas");
            r.put("coberturasSinEquivalencia",
                    (cob instanceof List) ? (List<String>) cob : new ArrayList<String>());
        } catch (Exception e) {
            // deteccion best-effort: no romper el defaulteo
        }
        return r;
    }

    /** BIT OUT param de SQL Server llega como Boolean (a veces Number); normaliza a boolean. */
    private static boolean asBool(Object o) {
        if (o instanceof Boolean) { return (Boolean) o; }
        if (o instanceof Number)  { return ((Number) o).intValue() == 1; }
        return false;
    }

    /** OUT param numerico -> Integer (null si viene null/no numerico). */
    private static Integer asInt(Object o) {
        if (o == null) { return null; }
        if (o instanceof Number) { return ((Number) o).intValue(); }
        try { return Integer.valueOf(o.toString().trim()); } catch (Exception e) { return null; }
    }

    /** Primera fila (Map) del primer result set de un SimpleJdbcCall; null si no hay. */
    private static Map<String, Object> firstRow(Map<String, Object> out) {
        List<Map<String, Object>> rs = firstResultSet(out);
        return (rs != null && !rs.isEmpty()) ? rs.get(0) : null;
    }

    /** Primer result set (List<Map>) de un SimpleJdbcCall; lista vacia si no hay. */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> firstResultSet(Map<String, Object> out) {
        if (out != null) {
            for (Object v : out.values()) {
                if (v instanceof List) { return (List<Map<String, Object>>) v; }
            }
        }
        return new ArrayList<>();
    }

    // -------------------------------------------------------------------------
    // CREA06 RF026-029 - gateo de la regla de antiguedad por corporativo configurado
    // -------------------------------------------------------------------------
    @Override
    public String getWizardConfigValor(String clave) {
        try {
            SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName("bf_DefaulteoAvanzado_GetWizardConfigValor");
            Map<String, Object> out = call.execute(new MapSqlParameterSource("Clave", clave));
            Map<String, Object> row = firstRow(out);
            if (row == null) { return null; }
            Object val = row.containsKey("valor") ? row.get("valor")
                       : (row.isEmpty() ? null : row.values().iterator().next());
            return val != null ? val.toString() : null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Integer getIdCorporativoDeEmpresa(int idEmpresa) {
        try {
            SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName("bf_DefaulteoAvanzado_GetCorporativoEmpresa");
            Map<String, Object> out = call.execute(new MapSqlParameterSource("IdEmpresa", idEmpresa));
            Map<String, Object> row = firstRow(out);
            if (row == null) { return null; }
            Object val = row.containsKey("idCorporativo") ? row.get("idCorporativo")
                       : (row.isEmpty() ? null : row.values().iterator().next());
            return asInt(val);
        } catch (Exception e) {
            return null;
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private static String toCsvInt(int[] arr) {
        if (arr == null || arr.length == 0) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(arr[i]);
        }
        return sb.toString();
    }

    private static String toCsvStr(String[] arr) {
        if (arr == null || arr.length == 0) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(arr[i] != null ? arr[i] : "");
        }
        return sb.toString();
    }

    private static Timestamp toTs(Date d) {
        return d == null ? null : new Timestamp(d.getTime());
    }
}
