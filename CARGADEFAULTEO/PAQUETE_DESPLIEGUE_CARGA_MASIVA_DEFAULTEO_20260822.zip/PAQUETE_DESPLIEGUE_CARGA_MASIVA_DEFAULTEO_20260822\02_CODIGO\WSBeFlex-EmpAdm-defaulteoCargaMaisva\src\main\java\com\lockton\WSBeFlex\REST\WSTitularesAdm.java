package com.lockton.WSBeFlex.REST;

import com.lockton.WSBeFlex.POJO.Especiales.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.lockton.WSBeFlex.POJO.FfEmpleado;
import com.lockton.WSBeFlex.Services.FfEmpleadoService;
import com.lockton.WSBeFlex.Services.GeneralesService;
import com.lockton.WSBeFlex.Services.CargaMasivaFlujoService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.UsuarioToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author JHON
 */
@RestController
@RequestMapping("beflex/titulares")
public class WSTitularesAdm {

    private static final Log bitacora = LogFactory.getLog(WSTitularesAdm.class);

    @Autowired
    FfEmpleadoService ff_ems;

    @Autowired
    GeneralesService general_Serv;

    @Autowired
    CargaMasivaFlujoService cargaMasivaFlujoService;

    @Autowired
    JwtService jwtService;

    /**
     * <p>
     * Este método se utiliza para ejecutar el PA
     * <i>ff_IInsertaAltaTitulares</i>.
     * </p>
     *
	 * <p>
     * <b>Endpoint:</b>
     * beflex/titulares/nuevo
     * </p>
     * <p>
     * <b>Tipo de método:</b>
     * Post
     * </p>
     * <p>
     * <b>Codigos de estado:</b>
     * </p>
     * <p>
     * 500 - Conflicto en la petición.</p>
     * <p>
     * 200 - El PA <b>ff_IInsertaAltaTitulares</b> responde
     * satisfactoriamente.</p>
     * <p>
     * @param idEmpresa asociada al parametro <b>IdEmpresa</b> Variable obtenida
     * como parametro.
     * @param atributos asociada al parametro <b>Sql</b> Variable obtenida como
     * parametro.
     * @param valores asociada al parametro <b>Sqlvalues</b> Variable obtenida
     * como parametro.
     * @return ResponseEntity valor de tipo Integer que corresponde al id del
     * registro creado, desde el servicio
     * {@link com.lockton.WSBeFlex.Services.FfEmpleadoService#crearTitular(String, String, int)}
     * @see <a href=
     *        "https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/http/ResponseEntity.html">
     * Class ResponseEntity</a>.
     * </p>
     */
    @PostMapping("/nuevo")
    public ResponseEntity<Integer> crearDependiente(@RequestParam int idEmpresa,
            @RequestParam String atributos, @RequestParam String valores, @RequestHeader("authorization") String token) {
        int id = 0;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                id = ff_ems.crearTitular(atributos, valores, idEmpresa);
                return new ResponseEntity<Integer>(id, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<Integer>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<Integer>(id, HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/op-masiva")
    public ResponseEntity<List<FfCOpcionesCargaMasiva>> opcionesCargaMasiva(@RequestParam int idEmpresa, @RequestHeader("authorization") String token) {
        List<FfCOpcionesCargaMasiva> resultado;
        if (general_Serv.validarTokenId(0, token, 4)) {
            UsuarioToken usuario = usuarioAutenticado(token);
            if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            if (!cargaMasivaFlujoService.tieneAccesoEmpresa(usuario.n, idEmpresa)) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            }
            try {
                resultado = ff_ems.opcionesCargaMasiva(idEmpresa);
                if (resultado != null) {
                    return new ResponseEntity<List<FfCOpcionesCargaMasiva>>(resultado, HttpStatus.OK);
                } else {
                    return new ResponseEntity<List<FfCOpcionesCargaMasiva>>(HttpStatus.CONFLICT);
                }

            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<FfCOpcionesCargaMasiva>>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<List<FfCOpcionesCargaMasiva>>(HttpStatus.UNAUTHORIZED);
        }

    }

    @PostMapping("/nuevoTM")
    public ResponseEntity<FfLogCargaMasiva> crearTitularM(
            @RequestParam String atributos, @RequestParam String valores, @RequestHeader("authorization") String token) {
        FfLogCargaMasiva id = new FfLogCargaMasiva();
        if (general_Serv.validarTokenId(0, token, 4)) {
            HttpStatus autorizacion = validarEjecucionB3(token, atributos, valores, true);
            if (autorizacion != HttpStatus.OK) return new ResponseEntity<>(autorizacion);
            try {
                id = ff_ems.crearTitularM(atributos, valores);
                return new ResponseEntity<FfLogCargaMasiva>(id, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.UNAUTHORIZED);
        }

    }

    @GetMapping("/obtenerDetalleEncabezadoPorEncabezadoYEmpresa/{EMIdEmpresa}/{Encabezado}")
    public ResponseEntity<List<Map<String,Object>>> obtenerDetalleEncabezadoPorEncabezadoYEmpresa(@PathVariable int EMIdEmpresa, @PathVariable String Encabezado) {

        try {
            List<Map<String,Object>> result = ff_ems.obtenerDetalleEncabezadoPorEncabezadoYEmpresa(EMIdEmpresa, Encabezado);

            return new ResponseEntity<List<Map<String,Object>>>(result, HttpStatus.OK);
        } catch (Exception e) {
            List<Map<String,Object>> result = new ArrayList<>();
            return new ResponseEntity<List<Map<String,Object>>>(result, HttpStatus.OK);
        }
        
        
    }

    @GetMapping("/ObtenerCatalogoTablaEncabezado/{EMIdEmpresa}")
    public ResponseEntity<List<Map<String,Object>>> ObtenerCatalogoTablaEncabezado(@PathVariable int EMIdEmpresa) {

        try {
            List<Map<String,Object>> result = ff_ems.ObtenerCatalogoTablaEncabezado(EMIdEmpresa);

            return new ResponseEntity<List<Map<String,Object>>>(result, HttpStatus.OK);
        } catch (Exception e) {
            List<Map<String,Object>> result = new ArrayList<>();
            return new ResponseEntity<List<Map<String,Object>>>(result, HttpStatus.OK);
        }
        
        
    }

    @PostMapping("/cambioEmpresaTitular")
    public ResponseEntity<Boolean> cambiarEmpresaTitular(
            @RequestBody Map<String, Object> body,
            @RequestHeader("authorization") String token) {
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                
                int IdEmpleado = Integer.parseInt(body.get("idEmpleado").toString());
                int IdEmpresaDestino = Integer.parseInt(body.get("idEmpresaDestino").toString());
                int IdPerfilDestino = Integer.parseInt(body.get("idPerfilDestino").toString());
                int IdRolDestino = 0;
                int IdAdministrador = Integer.parseInt(body.get("idAdministrador").toString());
                int cancelarSolicitud = Integer.parseInt(body.get("cancelarSolicitud").toString());
                
                String EMRegimen = body.get("EMRegimen").toString();
                String EMSalarioBase = body.get("EMSalarioBase").toString();
                String EMPuesto = body.get("EMPuesto").toString();
                String EMArea = body.get("EMArea").toString();
                String EMOficina = body.get("EMOficina").toString();
                String EMrfc = body.get("EMrfc").toString();
                String EMcurp = body.get("EMcurp").toString();
                String EMCorreoElectronico = body.get("EMCorreoElectronico").toString();
                String EMObservaciones = body.get("Observaciones").toString();
                
                String EMidCentroCostos = body.get("EMidCentroCostos").toString();
                String EMTipoEmpleado = body.get("EMTipoEmpleado").toString();
                String EMVIP = body.get("EMVIP").toString();

                CambioEmpresa cambioEmpresa = new CambioEmpresa(
                    IdEmpleado
                    ,IdEmpresaDestino
                    ,IdPerfilDestino
                    ,IdRolDestino
                    ,IdAdministrador
                    ,EMRegimen
                    ,EMSalarioBase
                    ,EMPuesto
                    ,EMArea
                    ,EMOficina
                    ,EMrfc
                    ,EMcurp
                    ,EMCorreoElectronico
                    ,EMObservaciones
                    ,EMVIP
                    ,EMidCentroCostos
                    ,EMTipoEmpleado
                );

                boolean result = ff_ems.cambiarEmpresaTitular(cambioEmpresa, cancelarSolicitud);
                return new ResponseEntity<Boolean>(result, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<Boolean>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<Boolean>(HttpStatus.UNAUTHORIZED);
        }
    }
    
    @GetMapping("/validarExisteEmpleadoEnEmpresa/{NumeroEmpleado}/{EMIdEmpresa}")
    public ResponseEntity<Boolean> validarExisteEmpleadoEnEmpresa(
            @PathVariable String NumeroEmpleado,
            @PathVariable int EMIdEmpresa) {
        
        try {
            Boolean result = ff_ems.validarExisteEmpleadoEnEmpresa(NumeroEmpleado, EMIdEmpresa);
            return new ResponseEntity<Boolean>(result, HttpStatus.OK);
        } catch (DataAccessException e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<Boolean>(HttpStatus.CONFLICT);
        }
        
    }

    @GetMapping("/opcionesCambioEmpresa/{idCorporativo}/{idUsuario}")
    public ResponseEntity<CambioEmpresaOpciones> opcionesCambioEmpresa(
            @PathVariable int idCorporativo,
            @PathVariable int idUsuario,
            @RequestHeader("authorization") String token) {
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                CambioEmpresaOpciones result = ff_ems.opcionesCambioEmpresa(idUsuario, idCorporativo);
                return new ResponseEntity<CambioEmpresaOpciones>(result, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<CambioEmpresaOpciones>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<CambioEmpresaOpciones>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/opcionesCambioEmpresa_v3/{idCorporativo}/{idUsuario}/{idCurrent}")
    public ResponseEntity<CambioEmpresaOpciones_v3> opcionesCambioEmpresa_v3(
            @PathVariable int idCorporativo,
            @PathVariable int idUsuario,
            @PathVariable int idCurrent,
            @RequestHeader("authorization") String token) {
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                CambioEmpresaOpciones_v3 result = ff_ems.opcionesCambioEmpresa_v3(idUsuario, idCorporativo, idCurrent);
                return new ResponseEntity<CambioEmpresaOpciones_v3>(result, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<CambioEmpresaOpciones_v3>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<CambioEmpresaOpciones_v3>(HttpStatus.UNAUTHORIZED);
        }
    }

    

    @PostMapping("/nuevoDM")
    public ResponseEntity<FfLogCargaMasiva> crearDependienteM(
            @RequestParam String atributos, @RequestParam String valores, @RequestHeader("authorization") String token) {
        FfLogCargaMasiva id = new FfLogCargaMasiva();
        if (general_Serv.validarTokenId(0, token, 4)) {
            HttpStatus autorizacion = validarEjecucionB3(token, atributos, valores, false);
            if (autorizacion != HttpStatus.OK) return new ResponseEntity<>(autorizacion);
            try {
                id = ff_ems.crearDependienteM(atributos, valores);
                return new ResponseEntity<FfLogCargaMasiva>(id, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.UNAUTHORIZED);
        }

    }

    @PostMapping("/bajaMD")
    public ResponseEntity<FfLogCargaMasiva> bajaMasivaD(
            @RequestParam String atributos, @RequestParam String valores, @RequestHeader("authorization") String token) {
        FfLogCargaMasiva id = new FfLogCargaMasiva();
        if (general_Serv.validarTokenId(0, token, 4)) {
            HttpStatus autorizacion = validarEjecucionB3(token, atributos, valores, false);
            if (autorizacion != HttpStatus.OK) return new ResponseEntity<>(autorizacion);
            try {
                id = ff_ems.bajaMasivaD(atributos, valores);
                return new ResponseEntity<FfLogCargaMasiva>(id, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.UNAUTHORIZED);
        }

    }

    @PostMapping("/bajaMT")
    public ResponseEntity<FfLogCargaMasiva> bajaMasivaT( @RequestParam int idEmpresa,
                                                         @RequestParam int eMId,
                                                         @RequestParam String eMObservaciones,
                                                         @RequestParam int eMUsuarioUMod,
                                                         @RequestParam int eMIdTitular,
                                                         @RequestParam String numeroEmpleado,
                                                         @RequestParam String FechaBaja,
                                                         @RequestHeader("authorization") String token) {

        FfEmpleado empleado = null;
        FfLogCargaMasiva id = new FfLogCargaMasiva();
        if (general_Serv.validarTokenId(0, token, 4)) {
            UsuarioToken usuario = usuarioAutenticado(token);
            if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            if (!cargaMasivaFlujoService.tieneAccesoEmpresa(usuario.n, idEmpresa)
                    || !cargaMasivaFlujoService.permitePantallaB3(idEmpresa)) {
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            }
            try {
                // id = ff_ems.bajaMasivaT(idEmpresa, eMId, eMObservaciones, eMUsuarioUMod, eMIdTitular, numeroEmpleado, FechaBaja);
                empleado = ff_ems.buscarEmpleadoPorNumero(idEmpresa, numeroEmpleado );
                ff_ems.bajaDependiente(idEmpresa,
                                        empleado.getId(),
                                        eMObservaciones,
                                        eMUsuarioUMod,
                                        eMIdTitular,
                                        numeroEmpleado,
                                        FechaBaja);
                id.setCode(0);
                id.setMsg("Titular y Dependientes dados de baja, Numero Empleado: " + numeroEmpleado);
                return new ResponseEntity<FfLogCargaMasiva>(id, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<FfLogCargaMasiva>(id, HttpStatus.UNAUTHORIZED);
        }

    }

    @PostMapping("/crearRegistroLog")
    public ResponseEntity<Integer> crearRegistroLog(@RequestBody CargaMasivaReporte reporteBody,@RequestHeader("authorization") String token) {
        int resultInsertReporte = 0;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                // Generar registro
                resultInsertReporte = ff_ems.generaLogTitulares(reporteBody);
                return new ResponseEntity<Integer>(resultInsertReporte, HttpStatus.CREATED);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<Integer>(0,HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<Integer>(0,HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/obtenerRegistroLog")
    public ResponseEntity<List<Map<String,Object>>> obtenerRegistroLog(
            @RequestParam String tipoOperacion,@RequestParam String fechaInicio,@RequestParam String fechaFin,@RequestParam int idEmpresa,@RequestHeader("authorization") String token) {
        List<Map<String,Object>> resultInsertReporte = new ArrayList<Map<String,Object>>();
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                // Generar registro
                resultInsertReporte = ff_ems.obtenerLogCargaMasiva(tipoOperacion,fechaInicio,fechaFin,idEmpresa);
                return new ResponseEntity<List<Map<String,Object>>>(resultInsertReporte, HttpStatus.CREATED);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Map<String,Object>>>(resultInsertReporte,HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<List<Map<String,Object>>>(resultInsertReporte,HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/obtenerTextoLog")
    public ResponseEntity<List<Map<String,Object>>> obtenerTextoLog(@RequestParam int idPlantilla, @RequestHeader("authorization") String token) {
        List<Map<String,Object>> resultTextLog = new ArrayList<Map<String,Object>>();
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                // Generar registro
                resultTextLog = ff_ems.obtenerTextoLogs(idPlantilla);
                return new ResponseEntity<List<Map<String,Object>>>(resultTextLog, HttpStatus.CREATED);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Map<String,Object>>>(resultTextLog,HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<List<Map<String,Object>>>(resultTextLog,HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/editarNumeroEmpleadoTitular")
    public ResponseEntity<List<Map<String,Object>>> editarNumeroEmpleadoTitular(@RequestBody Map<String, Object> parametros,@RequestHeader("authorization") String token) {
        List<Map<String,Object>> response = new ArrayList<Map<String,Object>>();
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                response = ff_ems.actualizarNumeroEmpleado(parametros);
                return new ResponseEntity<List<Map<String,Object>>>(response, HttpStatus.CREATED);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Map<String,Object>>>(response,HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<List<Map<String,Object>>>(response,HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/reactivacionEmpleado")
    public ResponseEntity<List<Map<String,Object>>> reactivacionEmpleado(@RequestBody Map<String, Object> parametros,@RequestHeader("authorization") String token) {
        List<Map<String,Object>> response = new ArrayList<Map<String,Object>>();
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                response = ff_ems.reactivarEmpleado(parametros);
                return new ResponseEntity<List<Map<String,Object>>>(response, HttpStatus.CREATED);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Map<String,Object>>>(response,HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<List<Map<String,Object>>>(response,HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/ejecutarCargaMasiva")
    public ResponseEntity<FfLogCargaMasiva> ejecutarCargaMasiva(
            @RequestParam String atributos, @RequestParam String valores, @RequestHeader("authorization") String token) {
        FfLogCargaMasiva respuestaEjecucion = new FfLogCargaMasiva();
        if (general_Serv.validarTokenId(0, token, 4)) {
            HttpStatus autorizacion = validarEjecucionB3(token, atributos, valores, true);
            if (autorizacion != HttpStatus.OK) return new ResponseEntity<>(autorizacion);
            try {
                respuestaEjecucion = ff_ems.procesarCargaMasiva(atributos, valores);
                return new ResponseEntity<FfLogCargaMasiva>(respuestaEjecucion, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<FfLogCargaMasiva>(HttpStatus.UNAUTHORIZED);
        }

    }

    @GetMapping("/ObtenerPlantillaTransferenciaIndividual/{EMIdEmpresa}")
    public ResponseEntity<List<Map<String,Object>>> ObtenerPlantillaTransferenciaIndividual(@PathVariable int EMIdEmpresa) {

        try {
            List<Map<String,Object>> result = ff_ems.ObtenerPlantillaTrasferenciaIndividual(EMIdEmpresa);

            return new ResponseEntity<List<Map<String,Object>>>(result, HttpStatus.OK);
        } catch (Exception e) {
            List<Map<String,Object>> result = new ArrayList<>();
            return new ResponseEntity<List<Map<String,Object>>>(result, HttpStatus.OK);
        }
        
    }

    @PostMapping("/validaSolicitudExistente")
    public ResponseEntity<Map<String,Object>> validaSolicitudExistente(@RequestBody Map<String, Object> body 
        ,@RequestHeader("authorization") String token){
        Map<String,Object> result = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                result = ff_ems.validarSolicitudEmpleado(body);
                return new ResponseEntity<Map<String,Object>>(result, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<Map<String,Object>>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<Map<String,Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/runTransferenciaMasiva")
    public ResponseEntity<Map<String, Object>> runTransferenciaMasiva(
            @RequestParam String atributos, @RequestParam String valores, @RequestHeader("authorization") String token) {
        Map<String, Object> respuestaEjecucion = new HashMap<String,Object>();
        if (general_Serv.validarTokenId(0, token, 4)) {
            HttpStatus autorizacion = validarEjecucionB3(token, atributos, valores, true);
            if (autorizacion != HttpStatus.OK) return new ResponseEntity<>(autorizacion);
            try {
                respuestaEjecucion = ff_ems.procesarTransferenciaMasiva(atributos, valores);
                return new ResponseEntity<Map<String, Object>>(respuestaEjecucion, HttpStatus.OK);
            } catch (DataAccessException e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<Map<String, Object>>(HttpStatus.CONFLICT);
            }
        } else {
            return new ResponseEntity<Map<String, Object>>(HttpStatus.UNAUTHORIZED);
        }

    }

    private HttpStatus validarEjecucionB3(String token, String atributos, String valores,
                                           boolean validarProcedimiento) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return HttpStatus.UNAUTHORIZED;
        Integer idEmpresa = cargaMasivaFlujoService.obtenerEmpresa(atributos, valores);
        if ((idEmpresa == null || idEmpresa <= 0) && usuario.idEmpresa > 0) {
            idEmpresa = usuario.idEmpresa;
        }
        if (idEmpresa == null || idEmpresa <= 0) return HttpStatus.BAD_REQUEST;
        if (!cargaMasivaFlujoService.tieneAccesoEmpresa(usuario.n, idEmpresa)
                || !cargaMasivaFlujoService.permitePantallaB3(idEmpresa)) {
            return HttpStatus.FORBIDDEN;
        }
        if (validarProcedimiento) {
            String sp = cargaMasivaFlujoService.obtenerValor(atributos, valores, "Sp");
            if (!cargaMasivaFlujoService.operacionConfigurada(idEmpresa, sp)) {
                bitacora.warn("Intento de ejecutar una operacion masiva no configurada para la empresa " + idEmpresa);
                return HttpStatus.FORBIDDEN;
            }
        }
        return HttpStatus.OK;
    }

    private UsuarioToken usuarioAutenticado(String token) {
        try {
            UsuarioToken usuario = jwtService.getPayloadFromToken(token);
            return usuario != null && usuario.n > 0 ? usuario : null;
        } catch (Exception e) {
            return null;
        }
    }

}
