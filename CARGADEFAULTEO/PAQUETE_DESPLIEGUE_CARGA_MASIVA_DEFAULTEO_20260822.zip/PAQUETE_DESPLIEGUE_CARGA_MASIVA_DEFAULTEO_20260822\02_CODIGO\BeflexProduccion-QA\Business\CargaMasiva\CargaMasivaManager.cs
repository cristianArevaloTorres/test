using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using WebServiceDataHelper = FlexiForbesV2.Business.Utils.clRegresaDato;
using FlexiForbesv2Entities;

namespace FlexiForbesV2.Business.CargaMasiva
{
    /// <summary>
    /// Provee métodos para la administracion de la Carga Masiva.
    /// </summary>
    public class CargaMasivaManager
    {
        #region Campos propietarios de clase
        private readonly WebServiceDataHelper _dataHelper;
        #endregion

        #region Constructores de clase
        public CargaMasivaManager()
        {
            _dataHelper = new WebServiceDataHelper();
            _dataHelper.Verifica = ConfigurationManager.AppSettings["localValidator"];
        }
        #endregion

        #region Propiedades de clase
        #endregion

        #region Metodos de clase

        /// <summary>
        /// Obtiene los nombres de archivo de los documentos de datos asociados a una operacion de carga masiva específica de una empresa.
        /// </summary>
        /// <param name="IdEmpresa">IdEmpresa</param>
        /// <param name="idOperacion">idOperacion</param>
        /// <returns>DataTable</returns>
        public DataTable GetDocumentos(int idEmpresa, int idOperacion)
        {
            //SqlParameter[] spParams = new SqlParameter[2];
            //spParams[0] = new SqlParameter("@IdEmpresa", idEmpresa);
            //spParams[1] = new SqlParameter("@IdOperacion", idOperacion);

            ParametrosSQL param = new ParametrosSQL(2);
            param.parametros.Add(new ParametroSql("@IdEmpresa", idEmpresa));
            param.parametros.Add(new ParametroSql("@IdOperacion", idOperacion));


            _dataHelper.sqlStr = "ff_CCMOperacionDocumentos";
            DataSet dataSet = _dataHelper.EjecutaSP_DataSetNew(param);

            if (dataSet.Tables.Count > 0)
                return dataSet.Tables[0];
            else
                return null;
        }

        /// <summary>
        /// Obtiene las operaciones de Carga Masiva configuradas para una determinada empresa.
        /// </summary>
        /// <param name="IdEmpresa">IdEmpresa</param>
        /// <returns>DataTable</returns>
        public DataTable GetOperaciones(int idEmpresa)
        {
            //SqlParameter[] spParams = new SqlParameter[1];
            //spParams[0] = new SqlParameter("@IdEmpresa", idEmpresa);
            ParametrosSQL param = new ParametrosSQL(1);
            param.parametros.Add(new ParametroSql("@IdEmpresa", idEmpresa));
                    

            _dataHelper.sqlStr = "ff_CCMOperacionesEmpresa";
            DataSet dataSet = _dataHelper.EjecutaSP_DataSetNew(param);

            if (dataSet.Tables.Count > 0)
                return dataSet.Tables[0];
            else
                return null;
        }

        /// <summary>
        /// Obtiene la seleccion independiente de pantalla y proceso automatico
        /// para la convivencia B2/B3.
        /// </summary>
        public DataTable GetConfiguracionFlujo(int idEmpresa)
        {
            ParametrosSQL param = new ParametrosSQL(1);
            param.parametros.Add(new ParametroSql("@IdEmpresa", idEmpresa));

            _dataHelper.sqlStr = "bf_CargaMasivaFlujo_Obtener";
            DataSet dataSet = _dataHelper.EjecutaSP_DataSetNew(param);
            return dataSet.Tables.Count > 0 ? dataSet.Tables[0] : null;
        }
        #endregion
    }
}
