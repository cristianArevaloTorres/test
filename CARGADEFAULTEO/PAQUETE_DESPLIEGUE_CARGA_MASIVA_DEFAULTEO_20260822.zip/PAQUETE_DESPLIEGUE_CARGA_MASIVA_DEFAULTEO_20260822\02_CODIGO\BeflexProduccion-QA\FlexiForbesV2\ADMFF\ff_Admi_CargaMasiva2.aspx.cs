using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using FlexiForbesV2.Business.CargaMasiva;
using FlexiForbesV2.Business.Utils;
using Business.Utils;
using Business.LocktonOne;

namespace FlexiForbesV2.ADMFF
{
    /// <summary>
    /// Summary description for ff_Admi_CargaMasiva2.
    /// </summary>
    public class ff_Admi_CargaMasiva2 : System.Web.UI.Page
    {
        protected System.Web.UI.WebControls.Label lbl_Titulo;
        protected System.Web.UI.WebControls.Label lbl_FlujoConfigurado;
        protected System.Web.UI.WebControls.DropDownList ddl_CargaMasivaOperaciones;
        protected System.Web.UI.WebControls.DropDownList ddl_CargaMasivaDocumentos;
        protected System.Web.UI.WebControls.Button btn_IniciarCarga;
        protected System.Web.UI.WebControls.Button btn_Cancelar;
        protected System.Web.UI.WebControls.Button btn_MostrarLog;
        protected System.Web.UI.WebControls.Button btn_EditarDocumento;
        protected System.Web.UI.HtmlControls.HtmlInputHidden txt_TipoEmpresa;
        protected System.Web.UI.WebControls.RadioButtonList rdo_ModoEjecucion;
        protected System.Web.UI.WebControls.CustomValidator cv_ValidateOperacion;
        protected System.Web.UI.WebControls.CustomValidator cv_ValidateDocumento;
        protected System.Web.UI.HtmlControls.HtmlInputHidden txt_LogFilename;
        protected System.Web.UI.WebControls.TextBox txt_CargaMasivaData;
        protected System.Web.UI.HtmlControls.HtmlTable tbl_Editor;
        protected System.Web.UI.WebControls.Button btn_GuardarDocumento;
        protected System.Web.UI.WebControls.Button btn_CancelarEdicion;
        protected System.Web.UI.HtmlControls.HtmlInputHidden txt_IdDocumentoEdicion;
        protected FlexiForbesV2.comun.CLEstilosControl css_PageStyler;

        private void Page_Load(object sender, System.EventArgs e)
        {
            // Validar que la session este activa
            this.checkSession();

            // Estilizacion dinamica de pagina
            css_PageStyler.Ruta = Request.ApplicationPath + "/comun/stilos";
            css_PageStyler.IdEmpresa = Session["SIdEMpresa"].ToString();

            if (!Page.IsPostBack)
            {
                txt_TipoEmpresa.Value = Request.QueryString["tipoEmpresa"];
                tbl_Editor.Visible = false;

                FillOperaciones();
            }
            AplicarConfiguracionFlujo();
        }

        private void Page_Error(object sender, System.EventArgs e)
        {
            ClErrores error = new ClErrores();

            error.MeEnviaError(Server.GetLastError());
            Server.ClearError();

            Response.Redirect("~/UnManagedError.aspx");
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ddl_CargaMasivaOperaciones.SelectedIndexChanged += new System.EventHandler(this.ddl_CargaMasivaOperaciones_SelectedIndexChanged);
            this.ddl_CargaMasivaDocumentos.SelectedIndexChanged += new System.EventHandler(this.ddl_CargaMasivaDocumentos_SelectedIndexChanged);
            this.btn_IniciarCarga.Click += new System.EventHandler(this.btn_IniciarCarga_Click);
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            this.btn_MostrarLog.Click += new System.EventHandler(this.btn_MostrarLog_Click);
            this.btn_EditarDocumento.Click += new System.EventHandler(this.btn_EditarDocumento_Click);
            this.btn_GuardarDocumento.Click += new System.EventHandler(this.btn_GuardarDocumento_Click);
            this.btn_CancelarEdicion.Click += new System.EventHandler(this.btn_CancelarEdicion_Click);
            this.Load += new System.EventHandler(this.Page_Load);
            this.Error += new System.EventHandler(this.Page_Error);
        }
        #endregion

        #region Manejadores de eventos para controles de pagina
        private void btn_Cancelar_Click(object sender, System.EventArgs e)
        {
            string redirectToPage;

            redirectToPage = (txt_TipoEmpresa.Value.Equals("corporativo")) ? "/ADMFF/ff_wizardCorporativo.aspx" : "Master/Principal.aspx";

            Response.Redirect(Request.ApplicationPath + redirectToPage);
        }

        private void btn_CancelarEdicion_Click(object sender, System.EventArgs e)
        {
            tbl_Editor.Visible = false;
            txt_CargaMasivaData.Text = "";
        }

        private void btn_EditarDocumento_Click(object sender, System.EventArgs e)
        {
            CargaMasivaDocumento document = new CargaMasivaDocumento(Int32.Parse(ddl_CargaMasivaDocumentos.SelectedValue), Request.PhysicalApplicationPath);
            document.Open();

            tbl_Editor.Visible = true;
            txt_IdDocumentoEdicion.Value = ddl_CargaMasivaDocumentos.SelectedValue;
            txt_CargaMasivaData.Text = document.Text;

            document.Close();
            document.Dispose();
        }

        private void btn_GuardarDocumento_Click(object sender, System.EventArgs e)
        {
            CargaMasivaDocumento document = new CargaMasivaDocumento(Int32.Parse(txt_IdDocumentoEdicion.Value), Request.PhysicalApplicationPath);
            document.Open();

            tbl_Editor.Visible = false;
            document.Text = txt_CargaMasivaData.Text;

            document.Close();
            document.Dispose();
        }
        /// <summary>
        /// Se manda llamar al método que comenzará el proceso de carga masiva.
        /// </summary>
        private void btn_IniciarCarga_Click(object sender, System.EventArgs e)
        {
            StartCargaMasiva();

            btn_MostrarLog.Enabled = !txt_LogFilename.Equals("");
        }

        private void btn_MostrarLog_Click(object sender, System.EventArgs e)
        {
            this.popUp(Request.ApplicationPath + "/" + txt_LogFilename.Value, "", "");
        }
        /// <summary>
        /// Deshabilita btn_EditarDocumento cuando el índice seleccionado de ddl_CargaMasivaDocumentos es igual a -1, en caso contrario lo habilita.
        /// </summary>
        private void ddl_CargaMasivaDocumentos_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (ddl_CargaMasivaDocumentos.SelectedValue.Equals("-1"))
            {
                btn_EditarDocumento.Enabled = false;
                btn_IniciarCarga.Attributes.Remove("onclick");
            }
            else
            {
                btn_EditarDocumento.Enabled = true;
                btn_IniciarCarga.Attributes.Add("onclick", "if (!f_ConfirmExecution()) return false;");
            }
        }
        /// <summary>
        /// Al cambiar el índice del DropDownList se llama al método FillDocumentos()
        /// </summary>
        private void ddl_CargaMasivaOperaciones_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            ddl_CargaMasivaDocumentos.ClearSelection();
            FillDocumentos();
        }
        #endregion

        #region Metodos de clase
        /// <summary>
        /// Se realiza llamado al método que obtiene los documentos asociados a la carga masiva de una empresa. 
        /// Se cargan los resultados en el DropDownList ddl_CargaMasivaDocumentos.
        /// </summary>
        private void FillDocumentos()
        {
            int IdEmpresa = 0;
            int IdOperacion = 0;
            CargaMasivaManager cmManager = null;
            DataTable table = null;
            DataRow row = null;

            IdEmpresa = (txt_TipoEmpresa.Value.Equals("corporativo")) ? Int32.Parse(Session["SIdCorporativoEdita"].ToString()) : Int32.Parse(Session["SIdEmpresa"].ToString());
            IdOperacion = Int32.Parse(ddl_CargaMasivaOperaciones.SelectedValue);
            cmManager = new CargaMasivaManager();
            table = cmManager.GetDocumentos(IdEmpresa, IdOperacion);

            row = table.NewRow();
            row[0] = "-1";
            row[1] = "Seleccione...";
            table.Rows.Add(row);

            ddl_CargaMasivaDocumentos.DataSource = table;
            ddl_CargaMasivaDocumentos.DataTextField = "DODocumento";
            ddl_CargaMasivaDocumentos.DataValueField = "DOIdDocumento";
            ddl_CargaMasivaDocumentos.DataBind();
            ddl_CargaMasivaDocumentos.SelectedValue = "-1";
        }
        /// <summary>
        /// Se realiza llamado al método que obtiene las operaciones de carga masiva de una empresa. 
        /// Se cargan los resultados en el DropDownList ddl_CargaMasivaOperaciones.
        /// </summary>
        private void FillOperaciones()
        {
            int IdEmpresa = 0;
            CargaMasivaManager cmManager = null;
            DataTable table = null;
            DataRow row = null;

            IdEmpresa = (txt_TipoEmpresa.Value.Equals("corporativo")) ? Int32.Parse(Session["SIdCorporativoEdita"].ToString()) : Int32.Parse(Session["SIdEmpresa"].ToString());
            cmManager = new CargaMasivaManager();
            table = cmManager.GetOperaciones(IdEmpresa);

            row = table.NewRow();
            row[0] = "-1";
            row[1] = "Seleccione...";
            table.Rows.Add(row);

            ddl_CargaMasivaOperaciones.DataSource = table;
            ddl_CargaMasivaOperaciones.DataTextField = "CONombre";
            ddl_CargaMasivaOperaciones.DataValueField = "COIdOperacion";
            ddl_CargaMasivaOperaciones.DataBind();
            ddl_CargaMasivaOperaciones.SelectedValue = "-1";
        }
        /// <summary>
        /// Comienza el proceso de carga masiva de una empresa. 
        /// </summary>
        private void StartCargaMasiva()
        {
            // Revalidacion en servidor: no basta con deshabilitar el boton.
            if (!AplicarConfiguracionFlujo())
                return;

            int IdEmpresa = 0;
            int IdOperacion = 0;
            int IdDocumento = 0;
            CargaMasivaExecutionMode execMode;
            CargaMasivaExecutionResult result;
            CargaMasivaProcess cmProcess = null;
            SortedList options = null;

            IdEmpresa = (txt_TipoEmpresa.Value.Equals("corporativo")) ? Int32.Parse(Session["SIdCorporativoEdita"].ToString()) : Int32.Parse(Session["SIdEmpresa"].ToString());
            IdOperacion = Int32.Parse(ddl_CargaMasivaOperaciones.SelectedValue);
            IdDocumento = Int32.Parse(ddl_CargaMasivaDocumentos.SelectedValue);
            execMode = (rdo_ModoEjecucion.SelectedValue.Equals("0")) ? CargaMasivaExecutionMode.ExecuteToFirstError : CargaMasivaExecutionMode.ExecuteAll;

            options = new SortedList();
            options.Add("SIdEmpresa", IdEmpresa);

            cmProcess = new CargaMasivaProcess(Request.PhysicalApplicationPath, true);
            result = cmProcess.ExecuteCargaMasiva(IdEmpresa, IdOperacion, IdDocumento, execMode, options, int.Parse(Session["SIdEmpleado"].ToString()));
            txt_LogFilename.Value = cmProcess.LogFilePath + cmProcess.LogFileName;
            txt_LogFilename.Value = txt_LogFilename.Value.Replace('\\', '/');
            cmProcess.Dispose();

            #region Proceso carga masiva LocktonOne
            SincronizacionLocktonOne sLO = new SincronizacionLocktonOne();
            string titulares = sLO.NotificacionCargaMasiva((int)EProceso.CargaMasivaTitular, Convert.ToInt32(IdEmpresa)), cuerpoEmail = "";

            if (titulares != "")
            {
                System.Collections.Generic.Dictionary<string, string> aValoresPlantilla = new System.Collections.Generic.Dictionary<string, string>();
                cuerpoEmail = "Los siguientes titulares no se pudieron enviar a LocktonOne:</br>" + titulares;
                aValoresPlantilla.Add("#CuerpoEmail", cuerpoEmail);

                //ClassComon.ClassComon.EnviarNotificacionPorTipo(Convert.ToInt32(IdEmpresa)
                //    , Convert.ToInt32(Session["SIdEmpleado"].ToString())
                //    , aValoresPlantilla
                //    , new System.Collections.Generic.List<string>()
                //    , Business.CC.ETipoNotificacionCorreo.ActualizacionLocktonOne);
            }
            #endregion

            switch (result)
            {
                case CargaMasivaExecutionResult.Success:
                    {
                        this.MsgBox("La operacion ha sido satisfactoria. Revise el registro para mas informacion.");
                        break;
                    }

                default:
                    {
                        this.MsgBox("Ha ocurrido un error durante la operacion. Revise el registro para mas informacion.");
                        break;
                    }
            }
        }

        /// <summary>
        /// B2 queda disponible mientras no exista una fila explicita. Una vez
        /// parametrizada la empresa, solo se permite ejecutar si Pantalla=B2.
        /// </summary>
        private bool AplicarConfiguracionFlujo()
        {
            try
            {
                int idEmpresa = (txt_TipoEmpresa.Value.Equals("corporativo"))
                    ? Int32.Parse(Session["SIdCorporativoEdita"].ToString())
                    : Int32.Parse(Session["SIdEmpresa"].ToString());
                DataTable configuracion = new CargaMasivaManager().GetConfiguracionFlujo(idEmpresa);
                if (configuracion == null || configuracion.Rows.Count == 0)
                {
                    lbl_FlujoConfigurado.Text = "Flujo de pantalla: sin configurar (B2 y B3 disponibles). Proceso automático: B2.";
                    return true;
                }

                DataRow row = configuracion.Rows[0];
                bool configurado = Convert.ToBoolean(row["configurado"]);
                string pantalla = Convert.ToString(row["flujoPantalla"]).Trim().ToUpper();
                string automatico = Convert.ToString(row["flujoAutomatico"]).Trim().ToUpper();
                bool permitido = !configurado || pantalla.Equals("B2");

                lbl_FlujoConfigurado.Text = configurado
                    ? "Flujo de pantalla: " + pantalla + ". Proceso automático: " + automatico + "."
                    : "Flujo de pantalla: sin configurar (B2 y B3 disponibles). Proceso automático: B2.";
                if (!permitido)
                    lbl_FlujoConfigurado.Text += " La ejecución B2 está bloqueada para esta empresa.";
                btn_IniciarCarga.Enabled = permitido;
                return permitido;
            }
            catch (Exception)
            {
                lbl_FlujoConfigurado.Text = "No fue posible validar la parametrización B2/B3; la ejecución se bloqueó por seguridad.";
                btn_IniciarCarga.Enabled = false;
                return false;
            }
        }
        #endregion
    }
}
