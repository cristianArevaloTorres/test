/*
  Validacion de solo lectura posterior a la instalacion para la empresa 186.
  No guarda configuracion y no ejecuta carga masiva ni defaulteo.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
SET NOCOUNT ON;

DECLARE @IdEmpresa INT = 186;
DECLARE @Faltantes NVARCHAR(MAX);

;WITH Requeridos AS
(
    SELECT *
    FROM (VALUES
        ('U', 'bf_ConfiguracionFlujoCargaMasiva'),
        ('P', 'bf_CargaMasivaFlujo_Obtener'),
        ('P', 'bf_CargaMasivaFlujo_Guardar'),
        ('P', 'bf_CargaMasivaFlujo_Resolver'),
        ('P', 'bf_ReporteDefaulteo_Consultar'),
        ('P', 'bf_DefaulteoAvanzado_ResolverVigencia'),
        ('P', 'bf_ConfiguracionDefaulteo_Guardar'),
        ('P', 'bf_ConfiguracionDefaulteo_Eliminar')
    ) X(tipo, objeto)
)
SELECT @Faltantes = STUFF
(
    (
        SELECT ', dbo.' + R.objeto
        FROM Requeridos R
        WHERE OBJECT_ID('dbo.' + R.objeto, R.tipo) IS NULL
        FOR XML PATH(''), TYPE
    ).value('.', 'NVARCHAR(MAX)'),
    1,
    2,
    ''
);

IF @Faltantes IS NOT NULL
BEGIN
    SELECT 'ERROR' AS estado, @Faltantes AS objetosFaltantes;
    THROW 51020, 'La instalacion esta incompleta. Revise el resultado anterior.', 1;
END;

IF OBJECT_ID('dbo.ff_Empresa', 'U') IS NULL
    THROW 51021, 'Falta el prerrequisito dbo.ff_Empresa.', 1;

IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresa)
    THROW 51022, 'La empresa 186 no existe en esta base.', 1;

SELECT 'OK' AS estado, DB_NAME() AS baseActual, @IdEmpresa AS idEmpresa;

EXEC dbo.bf_CargaMasivaFlujo_Obtener
    @IdEmpresa = @IdEmpresa;

EXEC dbo.bf_CargaMasivaFlujo_Resolver
    @IdEmpresa = @IdEmpresa,
    @Canal = 'PANTALLA';

EXEC dbo.bf_CargaMasivaFlujo_Resolver
    @IdEmpresa = @IdEmpresa,
    @Canal = 'AUTOMATICO';

SELECT
    TDidTipoDefaulteo AS idTipoDefaulteo,
    TDNombre AS nombre,
    TDDescripcion AS descripcion,
    TDidEstatus AS estatus
FROM dbo.ff_TipoDefaulteo
WHERE TDidTipoDefaulteo BETWEEN 0 AND 3
ORDER BY TDidTipoDefaulteo;

SELECT TOP (20)
    V.VIIdVigencia,
    V.VINombre,
    V.VIVigenciaIni,
    V.VIVigenciaFin,
    V.VIRenovada,
    V.VIIdEstatus
FROM dbo.ff_Vigencia V
INNER JOIN dbo.ff_Empresa E
    ON E.EMIdConfiguracion = V.VIIdConfiguracion
WHERE E.EMIdEmpresa = @IdEmpresa
ORDER BY V.VIVigenciaIni DESC, V.VIIdVigencia DESC;
