package com.lockton.WSBeFlex.Services;

import com.lockton.WSBeFlex.DAO.CargaMasivaFlujoDAO;
import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionFlujoCargaMasiva;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CargaMasivaFlujoService {
    private final CargaMasivaFlujoDAO dao;

    public CargaMasivaFlujoService(CargaMasivaFlujoDAO dao) {
        this.dao = dao;
    }

    public Map<String, Object> obtener(int idEmpresa) {
        validarEmpresa(idEmpresa);
        return dao.obtener(idEmpresa);
    }

    public Map<String, Object> guardar(FFConfiguracionFlujoCargaMasiva configuracion, int idUsuario) {
        if (configuracion == null || configuracion.idEmpresa == null) {
            throw new IllegalArgumentException("La empresa es obligatoria");
        }
        validarEmpresa(configuracion.idEmpresa);
        configuracion.flujoPantalla = normalizarFlujo(configuracion.flujoPantalla);
        configuracion.flujoAutomatico = normalizarFlujo(configuracion.flujoAutomatico);
        return dao.guardar(configuracion, idUsuario);
    }

    public Map<String, Object> resolver(int idEmpresa, String canal) {
        validarEmpresa(idEmpresa);
        String normalizado = canal == null ? "" : canal.trim().toUpperCase();
        if (!"PANTALLA".equals(normalizado) && !"AUTOMATICO".equals(normalizado)) {
            throw new IllegalArgumentException("Canal invalido");
        }
        return dao.resolver(idEmpresa, normalizado);
    }

    public boolean tieneAccesoEmpresa(int idAdministrador, int idEmpresa) {
        return idAdministrador > 0 && idEmpresa > 0 && dao.tieneAccesoEmpresa(idAdministrador, idEmpresa);
    }

    public boolean permitePantallaB3(int idEmpresa) {
        Map<String, Object> resultado = dao.resolver(idEmpresa, "PANTALLA");
        Object configurado = resultado.get("configurado");
        boolean existe = configurado instanceof Boolean
                ? ((Boolean) configurado).booleanValue()
                : configurado instanceof Number && ((Number) configurado).intValue() != 0;
        return !existe || "B3".equalsIgnoreCase(String.valueOf(resultado.get("flujo")));
    }

    public boolean operacionConfigurada(int idEmpresa, String storedProcedure) {
        return dao.operacionConfigurada(idEmpresa, storedProcedure);
    }

    public String obtenerValor(String atributos, String valores, String nombre) {
        if (atributos == null || valores == null || nombre == null) return null;
        String[] nombres = atributos.split(",", -1);
        String[] datos = valores.split(",", -1);
        if (nombres.length != datos.length) return null;
        for (int i = 0; i < nombres.length; i++) {
            if (nombre.equalsIgnoreCase(nombres[i].trim())) return datos[i].trim();
        }
        return null;
    }

    public Integer obtenerEmpresa(String atributos, String valores) {
        String value = obtenerValor(atributos, valores, "EMIdEmpresa");
        try { return value == null ? null : Integer.valueOf(value.replace("'", "").trim()); }
        catch (NumberFormatException e) { return null; }
    }

    private String normalizarFlujo(String value) {
        String flujo = value == null ? "" : value.trim().toUpperCase();
        if (!"B2".equals(flujo) && !"B3".equals(flujo)) {
            throw new IllegalArgumentException("El flujo debe ser B2 o B3");
        }
        return flujo;
    }

    private void validarEmpresa(int idEmpresa) {
        if (idEmpresa <= 0) throw new IllegalArgumentException("La empresa es obligatoria");
    }
}
