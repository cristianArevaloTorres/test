/* Reporte sin la tabla permanente compartida PruebaTemp del procedimiento legado. */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ReporteDefaulteo_Consultar
    @IdEmpresa  INT,
    @FechaInicio DATE,
    @FechaFin    DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF @IdEmpresa <= 0
        THROW 50010, 'La empresa es obligatoria.', 1;
    IF @FechaInicio IS NULL OR @FechaFin IS NULL OR @FechaFin < @FechaInicio
        THROW 50011, 'El rango de fechas no es valido.', 1;

    ;WITH SeleccionesIndividuales AS
    (
        SELECT
            POS.POidEmpresa AS idEmpresa,
            POS.PONumeroEmpleado AS numeroEmpleado,
            POS.POTarifaNeta AS costo,
            POS.POUsuarioAdd AS idUsuario,
            CONVERT(DATE, SO.SOFechaAprovacion) AS fechaDefaulteo
        FROM dbo.ff_PlanOpcionSeleccion POS
        INNER JOIN dbo.ff_Solicitud SO
            ON SO.SOIdSolicitud = POS.POIdSolicitud
        WHERE POS.POIdEmpresa = @IdEmpresa
          AND POS.PODefaulteo = 1
          AND POS.POIdEstatus = 1
          AND SO.SOEstatusSolicitud = 1
          AND POS.POIdParentesco IS NOT NULL
          AND SO.SOFechaAprovacion >= @FechaInicio
          AND SO.SOFechaAprovacion < DATEADD(DAY, 1, @FechaFin)
    ),
    SeleccionesGrupo AS
    (
        SELECT DISTINCT
            POS.POidEmpresa AS idEmpresa,
            POS.PONumeroEmpleado AS numeroEmpleado,
            POS.POTarifaNeta AS costo,
            POS.POUsuarioAdd AS idUsuario,
            CONVERT(DATE, SO.SOFechaAprovacion) AS fechaDefaulteo,
            POS.POIdPlanOpcion,
            POS.POIdGrupoParentesco
        FROM dbo.ff_PlanOpcionSeleccion POS
        INNER JOIN dbo.ff_Solicitud SO
            ON SO.SOIdSolicitud = POS.POIdSolicitud
        WHERE POS.POIdEmpresa = @IdEmpresa
          AND POS.PODefaulteo = 1
          AND POS.POIdEstatus = 1
          AND SO.SOEstatusSolicitud = 1
          AND POS.POIdGrupoParentesco IS NOT NULL
          AND SO.SOFechaAprovacion >= @FechaInicio
          AND SO.SOFechaAprovacion < DATEADD(DAY, 1, @FechaFin)
    ),
    Selecciones AS
    (
        SELECT idEmpresa, numeroEmpleado, costo, idUsuario, fechaDefaulteo
        FROM SeleccionesIndividuales
        UNION ALL
        SELECT idEmpresa, numeroEmpleado, costo, idUsuario, fechaDefaulteo
        FROM SeleccionesGrupo
    )
    SELECT
        S.idEmpresa,
        S.numeroEmpleado,
        LTRIM(RTRIM(
            ISNULL(E.EMApellidoPaterno, '') + ' '
          + ISNULL(E.EMApellidoMaterno, '') + ' '
          + ISNULL(E.EMNombre1, '') + ' '
          + ISNULL(E.EMNombre2, ''))) AS nombreEmpleado,
        CONVERT(DECIMAL(18, 2), SUM(ISNULL(S.costo, 0))) AS costoAnual,
        S.idUsuario,
        S.fechaDefaulteo
    FROM Selecciones S
    INNER JOIN dbo.ff_Empleado E
      ON E.EMIdEmpresa = S.idEmpresa
     AND E.EMNumeroEmpleado = S.numeroEmpleado
     AND E.EMIdParentesco = 1
    GROUP BY
        S.idEmpresa, S.numeroEmpleado, S.idUsuario, S.fechaDefaulteo,
        E.EMApellidoPaterno, E.EMApellidoMaterno, E.EMNombre1, E.EMNombre2
    ORDER BY S.numeroEmpleado, S.fechaDefaulteo;
END;
GO
