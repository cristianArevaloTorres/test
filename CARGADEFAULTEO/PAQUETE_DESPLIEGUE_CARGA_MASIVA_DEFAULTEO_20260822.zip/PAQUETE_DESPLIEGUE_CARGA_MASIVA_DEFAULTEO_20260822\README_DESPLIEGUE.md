# Paquete de despliegue — Carga Masiva B2/B3 y Defaulteo 1/2/3

Fecha: 22 de agosto de 2026  
Empresa de validacion: `186`

## Aclaracion del error 208

El objeto se llama:

```sql
dbo.bf_ConfiguracionFlujoCargaMasiva
```

La diagonal inversa antes del guion bajo no es un escape valido en SQL Server.
Si el mensaje muestra esa diagonal, el texto se copio desde una representacion
Markdown que escapaba el guion bajo. Si se usa el nombre correcto y
`OBJECT_ID('dbo.bf_ConfiguracionFlujoCargaMasiva', 'U')` devuelve `NULL`, la
instalacion todavia no se ha aplicado a esa base DEV.

## Contenido

- `01_SQL_INSTALACION`: un instalador consolidado para SSMS y los tres scripts
  fuente idempotentes. No contiene pruebas, permisos de menu ni datos.
- `02_CODIGO`: 30 archivos funcionales dentro de sus cuatro proyectos y con
  la misma ruta relativa que tienen en los repositorios.
- `03_SCRIPTS_ADICIONALES_NO_INSTALAR`: diagnosticos, pruebas de lectura,
  simulacion con `ROLLBACK` y habilitacion opcional de menu.
- `04_DOCUMENTACION`: resultado funcional y documento explicativo de pruebas.
- `MANIFIESTO_SHA256.csv`: inventario y huella de cada archivo desplegable
  (el manifiesto no se lista a si mismo).

## Orden recomendado

1. Abrir `03_SCRIPTS_ADICIONALES_NO_INSTALAR/00_DIAGNOSTICO_PREINSTALACION.sql`
   en la base DEV y confirmar el valor de `DB_NAME()`.
2. Si falta algun objeto marcado como `PRERREQUISITO`, detener el despliegue.
   Esos objetos pertenecen a la base base de BeFlex y no los crea este cambio.
3. Ejecutar `01_SQL_INSTALACION/000_INSTALACION_COMPLETA_SSMS.sql` completo.
   Es un SQL normal para SSMS; no requiere activar SQLCMD Mode.
4. Ejecutar
   `03_SCRIPTS_ADICIONALES_NO_INSTALAR/01_VALIDACION_RAPIDA_POSTINSTALACION_EMPRESA_186.sql`.
5. Desplegar los proyectos en este orden: backend principal Java, API Java de
   reportes, Angular B3 y B2 legado.
6. Ejecutar el SQL independiente
   `03_SCRIPTS_ADICIONALES_NO_INSTALAR/PRUEBAS_SQL_EMPRESA_186_CARGA_MASIVA_Y_DEFAULTEO.sql`.
   El archivo es de lectura, limita la muestra a 3,000 empleados y debe
   ejecutarse completo en una sola ventana, sin agregar `GO`.
7. Para comprobar las decisiones B2/B3 sin conservar cambios, ejecutar
   `02_SIMULACION_ENRUTAMIENTO_B2_B3_EMPRESA_186_ROLLBACK.sql`.
8. Usar `004_verificar_habilitar_menu_defaulteo.sql` solamente si se debe
   revisar o habilitar el acceso por rol. Con sus valores iniciales trabaja en
   diagnostico; puede modificar permisos cuando se cambia explicitamente
   `@Aplicar` a `1`.

## SQL de instalacion

El instalador consolidado contiene exactamente, en este orden:

1. `001_catalogo_y_flujo_carga_masiva.sql`
2. `002_reporte_historico_defaulteo.sql`
3. `003_seguridad_y_vigencia_defaulteo_avanzado.sql`

El script `001` crea `dbo.bf_ConfiguracionFlujoCargaMasiva`, carga el catalogo
de tipos 0 a 3 y crea los contratos para obtener, guardar y resolver el flujo.
El `002` instala el reporte historico y el `003` instala la resolucion de
vigencia y endurece la propiedad de configuraciones de defaulteo avanzado.

El instalador no fija B2 o B3 para la empresa `186`; esa decision debe guardarse
desde la pantalla/API o mediante un cambio de datos expresamente autorizado.

## Codigo por proyecto

La carpeta `02_CODIGO` conserva estas raices:

- `WSBeFlex-EmpAdm-defaulteoCargaMaisva`: 12 archivos.
- `BeFlex3_Admin_API_Reportes-defaulteoCargaMaisva`: 7 archivos, incluidas sus
  pruebas unitarias.
- `BeFlex3-EmpAdm-defaulteoCargaMaisva`: 8 archivos.
- `BeflexProduccion-QA`: 3 archivos de B2.

Copiar o integrar cada raiz sobre el proyecto del mismo nombre. Si la rama DEV
tiene cambios posteriores, se debe hacer merge por archivo en vez de reemplazar
la carpeta completa.

`src/app/services/global.ts` no se incluye: la diferencia encontrada corresponde
solo a URLs de ambiente. Sobrescribirlo podria dirigir DEV hacia otro backend y
no es necesario para esta funcionalidad.

## Alcance de las simulaciones

La simulacion B2/B3 guarda dos combinaciones dentro de una transaccion y termina
con `ROLLBACK`. No procesa archivos. El SQL largo de empresa 186 solamente lee
configuracion, candidatos, solicitudes, selecciones y logs. No se incluye una
ejecucion automatica de Defaulteo 1/2/3 porque ese motor genera solicitudes y
puede producir efectos de negocio que no son apropiados para un script generico
sobre una base con datos reales.
