package com.lockton.WSBeFlex.DAO;

import java.util.List;
import java.util.Map;

import com.lockton.WSBeFlex.POJO.Especiales.FFConfiguracionDefaulteo;
import com.lockton.WSBeFlex.POJO.Especiales.FFFiltroDefaulteoAvanzado;

/**
 * CREA 06 - DAO de defaulteo avanzado.
 * Acceso a los SPs bf_DefaulteoAvanzado_* y bf_ConfiguracionDefaulteo_*
 * y a las tablas de bitacora bf_LogDefaulteo / bf_LogErroresDefaulteo.
 *
 * Implementacion: {@link com.lockton.WSBeFlex.DAO.JDBCFfDefaulteoAvanzado}
 */
public interface FfDefaulteoAvanzadoDAO {

    /** Confirma que todas las empresas solicitadas estan activas y asignadas al administrador. */
    boolean tieneAccesoEmpresas(int idAdmin, int[] idsEmpresa);

    /** Confirma que todos los empleados solicitados pertenecen a empresas asignadas al administrador. */
    boolean tieneAccesoEmpleados(int idAdmin, int[] idsEmpleado);

    /** Confirma que el lote fue iniciado por el administrador autenticado. */
    boolean lotePerteneceAdministrador(int idLog, int idAdmin);

    /** Confirma que la configuracion pertenece al administrador autenticado. */
    boolean configuracionPerteneceAdministrador(int idConfiguracion, int idAdmin);

    /** Obtiene la empresa real del empleado; evita confiar en el dato enviado por el navegador. */
    Integer obtenerEmpresaEmpleado(int idEmpleado);

    /** Resuelve el contexto de la vigencia elegida para invocar el motor legado. */
    Map<String, Object> resolverContextoVigencia(int idEmpresa, int idVigenciaSeleccionada);

    /** Busqueda avanzada de empleados sin solicitud (RN001 / RN010). */
    List<Object> buscarEmpleados(FFFiltroDefaulteoAvanzado f);

    /** Inicia el lote de auditoria; devuelve el LDId generado. */
    Integer iniciarLote(Integer idConfiguracion, Integer idCorporativo, Integer idEmpresa,
                        Integer idVigencia, int idAdmin, String filtrosJson, String accionesJson,
                        int totalEmpleados, String ipOrigen, String origen);

    /** Registra un evento por empleado (ERROR / WARN_* / INFO). */
    void registrarEvento(int idLog, int idEmpleado, String numEmpleado, Integer idEmpresa,
                         Integer idPerfil, String tipoEvento, String mensaje,
                         String stackTrace, String contextoJson);

    /** Cierra el lote con totales, duracion y estado final (COMPLETADO / COMPLETADO_CON_ERRORES / ERROR). */
    void finalizarLote(int idLog, Integer totalEmpleados, Integer totalExitosos, Integer totalErrores, String estado);

    /** Lee el estado actual de un lote desde bf_LogDefaulteo (null si no existe). */
    Map<String, Object> consultarLote(int idLog);

    /** Configuraciones: guardar (insert si id null/0, update si id) — devuelve CDId. */
    Integer guardarConfiguracion(FFConfiguracionDefaulteo c);

    /** Configuraciones: borrado logico. */
    void eliminarConfiguracion(int id, int idAdmin);

    /** Configuraciones: listar disponibles para corporativo/empresa/admin. */
    List<Object> listarConfiguraciones(Integer idCorporativo, Integer idEmpresa, Integer idAdmin);

    /** Lee los eventos de un lote (para descarga XLSX). */
    List<Map<String, Object>> obtenerEventosDeLote(int idLog);

    /**
     * CREA 06 RF001.1 - detecta y procesa cambio de perfil por empleado:
     *   - Si hubo cambio: rechaza solicitud anterior + log INFO + log WARN_COBERTURA
     *     por cada cobertura sin equivalencia en el nuevo perfil
     *   - Si no hubo cambio: NOOP
     * Devuelve mapa con: huboCambio, idPerfilActual, idPerfilAnterior, idSolicitudAnterior.
     */
    Map<String, Object> reprocesarCambioPerfil(int idEmpleado, int idVigencia, int idAdmin, Integer idLog);

    /**
     * CREA 06 RF001.2 - aplica regla de antiguedad Scotiabank post-defaulteo:
     * si el empleado tiene menos de @mesesMinimos meses desde EMFechaIngresoEmpresa,
     * remueve filas de ff_PlanOpcionSeleccionRetiro de la solicitud creada y registra
     * WARN_ANTIGUEDAD / WARN_CANDADO.
     * Devuelve mapa con: mesesAntiguedad, ajusteAplicado, coberturasRemovidas, idSolicitud.
     */
    Map<String, Object> aplicarAntiguedad(int idEmpleado, int idVigencia, int idAdmin,
                                          Integer idLog, int mesesMinimos);

    /** Lista todos los perfiles activos de una empresa (el endpoint /perfil/empresa/:id filtra demas). */
    List<Map<String, Object>> listarPerfilesEmpresa(int idEmpresa);

    /**
     * CREA06 R2 (minuta 22-jun) - deteccion de cambio de perfil usando el historial OFICIAL de ediciones
     * (bf_EdicionEmpresaEmpleado), acotado a la ventana de vigencia [inicio vig. anterior, fin vig. actual].
     * Cuenta como cambio: (a) cambio de perfil del empleado, o (b) cambio de empresa dentro del mismo
     * corporativo (cada empresa puede tener distinto plan basico). Best-effort: nunca rompe el defaulteo.
     * Devuelve: huboCambio, idPerfilActual, idPerfilAnterior, perfilActualNombre, perfilAnteriorNombre,
     * motivoCambio ('PERFIL'|'EMPRESA'|null), fechaCambio, coberturasSinEquivalencia.
     */
    Map<String, Object> detectarCambioPerfilEdicion(int idEmpleado, int idVigenciaActual, int idVigenciaAnterior);

    /** Lee un valor de bf_WizardConfig por clave (null si no existe o inactivo). */
    String getWizardConfigValor(String clave);

    /** idCorporativo de una empresa (null si no existe). */
    Integer getIdCorporativoDeEmpresa(int idEmpresa);
}
