package com.lockton.WSBeFlex.POJO.Especiales;

public class FFConfiguracionFlujoCargaMasiva {
    public Integer idEmpresa;
    public String flujoPantalla;
    public String flujoAutomatico;
}
