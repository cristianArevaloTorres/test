/*
  BF3 / empresa 186
  Coloca la ruta /defaulteo al mismo nivel que /cargamasivapoblaciones,
  con el nombre "Defaulteo" y la misma imagen por rol.

  Idempotente. No crea tablas ni depende de bf_ConfiguracionFlujoCargaMasiva.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @IdEmpresa INT = 186;
DECLARE @IdMenuCarga INT;
DECLARE @IdMenuDefaulteo INT;
DECLARE @IdPadre INT;
DECLARE @OrdenCarga INT;
DECLARE @Ahora DATETIME = GETDATE();

SELECT TOP (1)
    @IdMenuCarga = MEIdMenu,
    @IdPadre = MEMenuPadre,
    @OrdenCarga = MEOrden
FROM dbo.ff_Menu
WHERE MERutaLiga = '/cargamasivapoblaciones'
  AND MEIdEstatus = 1
ORDER BY MEIdMenu;

SELECT TOP (1) @IdMenuDefaulteo = MEIdMenu
FROM dbo.ff_Menu
WHERE MERutaLiga = '/defaulteo'
ORDER BY CASE WHEN MEIdEstatus = 1 THEN 0 ELSE 1 END, MEIdMenu;

IF @IdMenuCarga IS NULL
    THROW 51401, 'No existe el menu BF3 /cargamasivapoblaciones usado como referencia.', 1;
IF @IdMenuDefaulteo IS NULL
    THROW 51402, 'No existe el menu BF3 /defaulteo. Cargue primero los insumos de menu.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    UPDATE dbo.ff_Menu
    SET MENombreMenu = N'Defaulteo',
        MEComentarios = 'Defaulteo de empleados tipos 1, 2 y 3',
        MEPadre = 0,
        METarget = 'centro',
        MEOrden = ISNULL(@OrdenCarga, 0) + 1,
        MEIcono = 1,
        MEMenuPadre = @IdPadre,
        MEidTipoNegocio = (SELECT MEidTipoNegocio FROM dbo.ff_Menu WHERE MEIdMenu=@IdMenuCarga),
        MEIdEstatus = 1,
        MEUsuarioUMod = 0,
        MEFechaUMod = @Ahora,
        MEUsuarioDel = NULL,
        MEFechaDel = NULL
    WHERE MEIdMenu = @IdMenuDefaulteo;

    /* Replica la asignacion del menu de Carga Masiva para cada rol que lo ve.
       En la data recibida para la empresa 186 esto incluye al rol 570. */
    INSERT dbo.ff_MenuRol2
    (MRIdRol,MRIdMenu,MRIdEstatus,MRUsuarioAdd,MRFechaAdd,
     MRUsuarioUMod,MRFechaUMod,MRUsuarioDel,MRFechaDel,MRRutaBanner,MRImagenMenu)
    SELECT C.MRIdRol,@IdMenuDefaulteo,1,0,@Ahora,0,@Ahora,NULL,NULL,
           C.MRRutaBanner,C.MRImagenMenu
    FROM dbo.ff_MenuRol2 C
    WHERE C.MRIdMenu=@IdMenuCarga
      AND C.MRIdEstatus=1
      AND NOT EXISTS
          (SELECT 1 FROM dbo.ff_MenuRol2 D
           WHERE D.MRIdRol=C.MRIdRol AND D.MRIdMenu=@IdMenuDefaulteo);

    UPDATE D
    SET D.MRIdEstatus=1,
        D.MRImagenMenu=C.MRImagenMenu,
        D.MRRutaBanner=C.MRRutaBanner,
        D.MRUsuarioUMod=0,
        D.MRFechaUMod=@Ahora,
        D.MRUsuarioDel=NULL,
        D.MRFechaDel=NULL
    FROM dbo.ff_MenuRol2 D
    INNER JOIN dbo.ff_MenuRol2 C
        ON C.MRIdRol=D.MRIdRol
       AND C.MRIdMenu=@IdMenuCarga
       AND C.MRIdEstatus=1
    WHERE D.MRIdMenu=@IdMenuDefaulteo;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT
    D.MEIdMenu,D.MENombreMenu,D.MERutaLiga,D.MEMenuPadre,D.MEOrden,
    R.MRIdRol,R.MRIdEstatus,R.MRImagenMenu,
    CASE WHEN D.MEMenuPadre=C.MEMenuPadre
               AND D.MEOrden=C.MEOrden+1
               AND D.MENombreMenu=N'Defaulteo'
               AND ISNULL(R.MRImagenMenu,'')=ISNULL(RC.MRImagenMenu,'')
         THEN 'OK' ELSE 'REVISAR' END AS Validacion
FROM dbo.ff_Menu D
INNER JOIN dbo.ff_Menu C ON C.MEIdMenu=@IdMenuCarga
INNER JOIN dbo.ff_MenuRol2 R ON R.MRIdMenu=D.MEIdMenu
LEFT JOIN dbo.ff_MenuRol2 RC
  ON RC.MRIdMenu=C.MEIdMenu AND RC.MRIdRol=R.MRIdRol AND RC.MRIdEstatus=1
WHERE D.MEIdMenu=@IdMenuDefaulteo
ORDER BY R.MRIdRol;

