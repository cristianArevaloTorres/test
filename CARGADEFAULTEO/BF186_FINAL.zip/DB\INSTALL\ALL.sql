﻿/*
  INSTALACION COMPLETA - Carga Masiva B2/B3 y Defaulteo 1/2/3

  Ejecute este archivo en la base destino desde SSMS.
  Este archivo NO contiene USE [base] para evitar instalar por accidente en
  una base distinta. Confirme DB_NAME() antes de continuar.

  Contiene, en orden, los scripts 001, 002, 003 y 004.
  NO contiene scripts de pruebas, diagnostico, permisos de menu ni datos.
*/
SELECT DB_NAME() AS baseDestino, @@SERVERNAME AS servidor;
GO

/* ==================== INICIO 001_catalogo_y_flujo_carga_masiva.sql ==================== */
/*
  Parametrizacion independiente B2/B3 para carga masiva.
  - Pantalla: decide cual interfaz puede ejecutar cargas.
  - Automatico: decide cual motor deben usar los procesos programados.
  Sin fila configurada, ambas pantallas siguen disponibles y el automatico
  conserva B2 para no romper integraciones existentes.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

SET XACT_ABORT ON;
GO

MERGE dbo.ff_TipoDefaulteo AS destino
USING (VALUES
    (0, 'Seleccionar el tipo de Default', 'Opcion inicial; no ejecuta ningun tipo de defaulteo.'),
    (1, 'Traer selecciones vigencia anterior', 'Replica las selecciones aprobadas de la vigencia anterior y las homologa a la vigencia destino.'),
    (2, 'Plan espejo ultima vigencia', 'Asigna los planes basicos o espejo elegibles de la vigencia destino.'),
    (3, 'Actualizacion de dependientes solicitud anterior', 'Conserva la seleccion previa de la solicitud destino y actualiza la composicion de dependientes.')
) AS origen (TDidTipoDefaulteo, TDNombre, TDDescripcion)
ON destino.TDidTipoDefaulteo = origen.TDidTipoDefaulteo
WHEN MATCHED THEN UPDATE SET
    TDNombre = origen.TDNombre,
    TDDescripcion = origen.TDDescripcion,
    TDidEstatus = 1,
    TDFechaUMod = GETDATE()
WHEN NOT MATCHED THEN INSERT
    (TDidTipoDefaulteo, TDNombre, TDDescripcion, TDidEstatus,
     TDUsuarioAdd, TDFechaAdd, TDFechaUMod)
VALUES
    (origen.TDidTipoDefaulteo, origen.TDNombre, origen.TDDescripcion, 1,
     0, GETDATE(), GETDATE());
GO

IF OBJECT_ID('dbo.bf_ConfiguracionFlujoCargaMasiva', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_ConfiguracionFlujoCargaMasiva
    (
        CFIdEmpresa          INT         NOT NULL,
        CFFlujoPantalla      CHAR(2)     NOT NULL,
        CFFlujoAutomatico    CHAR(2)     NOT NULL,
        CFIdEstatus          INT         NOT NULL CONSTRAINT DF_bf_CargaFlujo_Estatus DEFAULT (1),
        CFUsuarioAdd         INT         NOT NULL,
        CFFechaAdd           DATETIME    NOT NULL CONSTRAINT DF_bf_CargaFlujo_FechaAdd DEFAULT (GETDATE()),
        CFUsuarioUMod        INT         NULL,
        CFFechaUMod          DATETIME    NULL,
        CONSTRAINT PK_bf_ConfiguracionFlujoCargaMasiva PRIMARY KEY (CFIdEmpresa),
        CONSTRAINT CK_bf_CargaFlujo_Pantalla CHECK (CFFlujoPantalla IN ('B2', 'B3')),
        CONSTRAINT CK_bf_CargaFlujo_Automatico CHECK (CFFlujoAutomatico IN ('B2', 'B3')),
        CONSTRAINT CK_bf_CargaFlujo_Estatus CHECK (CFIdEstatus IN (1, 2))
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Obtener
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        @IdEmpresa AS idEmpresa,
        COALESCE(CFFlujoPantalla, 'B3') AS flujoPantalla,
        COALESCE(CFFlujoAutomatico, 'B2') AS flujoAutomatico,
        CONVERT(BIT, CASE WHEN CFIdEmpresa IS NULL THEN 0 ELSE 1 END) AS configurado,
        CFUsuarioAdd AS usuarioAdd,
        CFFechaAdd AS fechaAdd,
        CFUsuarioUMod AS usuarioUMod,
        CFFechaUMod AS fechaUmod
    FROM (SELECT 1 AS n) x
    LEFT JOIN dbo.bf_ConfiguracionFlujoCargaMasiva c
      ON c.CFIdEmpresa = @IdEmpresa
     AND c.CFIdEstatus = 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Guardar
    @IdEmpresa          INT,
    @FlujoPantalla      CHAR(2),
    @FlujoAutomatico    CHAR(2),
    @IdUsuario          INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @FlujoPantalla = UPPER(LTRIM(RTRIM(@FlujoPantalla)));
    SET @FlujoAutomatico = UPPER(LTRIM(RTRIM(@FlujoAutomatico)));

    IF @IdEmpresa <= 0 OR NOT EXISTS (
        SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1)
        THROW 50001, 'La empresa indicada no existe o esta inactiva.', 1;
    IF @IdUsuario <= 0
        THROW 50002, 'El usuario es obligatorio.', 1;
    IF @FlujoPantalla NOT IN ('B2', 'B3') OR @FlujoAutomatico NOT IN ('B2', 'B3')
        THROW 50003, 'Los flujos permitidos son B2 y B3.', 1;

    BEGIN TRANSACTION;
    UPDATE dbo.bf_ConfiguracionFlujoCargaMasiva WITH (UPDLOCK, SERIALIZABLE)
       SET CFFlujoPantalla = @FlujoPantalla,
           CFFlujoAutomatico = @FlujoAutomatico,
           CFIdEstatus = 1,
           CFUsuarioUMod = @IdUsuario,
           CFFechaUMod = GETDATE()
     WHERE CFIdEmpresa = @IdEmpresa;

    IF @@ROWCOUNT = 0
        INSERT dbo.bf_ConfiguracionFlujoCargaMasiva
            (CFIdEmpresa, CFFlujoPantalla, CFFlujoAutomatico, CFIdEstatus,
             CFUsuarioAdd, CFFechaAdd)
        VALUES
            (@IdEmpresa, @FlujoPantalla, @FlujoAutomatico, 1,
             @IdUsuario, GETDATE());
    COMMIT TRANSACTION;

    EXEC dbo.bf_CargaMasivaFlujo_Obtener @IdEmpresa = @IdEmpresa;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Resolver
    @IdEmpresa INT,
    @Canal     VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Canal = UPPER(LTRIM(RTRIM(@Canal)));

    IF @Canal NOT IN ('PANTALLA', 'AUTOMATICO')
        THROW 50004, 'El canal debe ser PANTALLA o AUTOMATICO.', 1;

    SELECT
        @IdEmpresa AS idEmpresa,
        @Canal AS canal,
        CASE
            WHEN c.CFIdEmpresa IS NULL AND @Canal = 'AUTOMATICO' THEN 'B2'
            WHEN c.CFIdEmpresa IS NULL THEN NULL
            WHEN @Canal = 'PANTALLA' THEN c.CFFlujoPantalla
            ELSE c.CFFlujoAutomatico
        END AS flujo,
        CONVERT(BIT, CASE WHEN c.CFIdEmpresa IS NULL THEN 0 ELSE 1 END) AS configurado
    FROM (SELECT 1 AS n) x
    LEFT JOIN dbo.bf_ConfiguracionFlujoCargaMasiva c
      ON c.CFIdEmpresa = @IdEmpresa
     AND c.CFIdEstatus = 1;
END;
GO

/* ===================== FIN 001_catalogo_y_flujo_carga_masiva.sql ====================== */

/* ==================== INICIO 002_reporte_historico_defaulteo.sql ==================== */
/* Reporte sin la tabla permanente compartida PruebaTemp del procedimiento legado. */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ReporteDefaulteo_Consultar
    @IdEmpresa  INT,
    @FechaInicio DATE,
    @FechaFin    DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF @IdEmpresa <= 0
        THROW 50010, 'La empresa es obligatoria.', 1;
    IF @FechaInicio IS NULL OR @FechaFin IS NULL OR @FechaFin < @FechaInicio
        THROW 50011, 'El rango de fechas no es valido.', 1;

    ;WITH SeleccionesIndividuales AS
    (
        SELECT
            POS.POidEmpresa AS idEmpresa,
            POS.PONumeroEmpleado AS numeroEmpleado,
            POS.POTarifaNeta AS costo,
            POS.POUsuarioAdd AS idUsuario,
            CONVERT(DATE, SO.SOFechaAprovacion) AS fechaDefaulteo
        FROM dbo.ff_PlanOpcionSeleccion POS
        INNER JOIN dbo.ff_Solicitud SO
            ON SO.SOIdSolicitud = POS.POIdSolicitud
        WHERE POS.POIdEmpresa = @IdEmpresa
          AND POS.PODefaulteo = 1
          AND POS.POIdEstatus = 1
          AND SO.SOEstatusSolicitud = 1
          AND POS.POIdParentesco IS NOT NULL
          AND SO.SOFechaAprovacion >= @FechaInicio
          AND SO.SOFechaAprovacion < DATEADD(DAY, 1, @FechaFin)
    ),
    SeleccionesGrupo AS
    (
        SELECT DISTINCT
            POS.POidEmpresa AS idEmpresa,
            POS.PONumeroEmpleado AS numeroEmpleado,
            POS.POTarifaNeta AS costo,
            POS.POUsuarioAdd AS idUsuario,
            CONVERT(DATE, SO.SOFechaAprovacion) AS fechaDefaulteo,
            POS.POIdPlanOpcion,
            POS.POIdGrupoParentesco
        FROM dbo.ff_PlanOpcionSeleccion POS
        INNER JOIN dbo.ff_Solicitud SO
            ON SO.SOIdSolicitud = POS.POIdSolicitud
        WHERE POS.POIdEmpresa = @IdEmpresa
          AND POS.PODefaulteo = 1
          AND POS.POIdEstatus = 1
          AND SO.SOEstatusSolicitud = 1
          AND POS.POIdGrupoParentesco IS NOT NULL
          AND SO.SOFechaAprovacion >= @FechaInicio
          AND SO.SOFechaAprovacion < DATEADD(DAY, 1, @FechaFin)
    ),
    Selecciones AS
    (
        SELECT idEmpresa, numeroEmpleado, costo, idUsuario, fechaDefaulteo
        FROM SeleccionesIndividuales
        UNION ALL
        SELECT idEmpresa, numeroEmpleado, costo, idUsuario, fechaDefaulteo
        FROM SeleccionesGrupo
    )
    SELECT
        S.idEmpresa,
        S.numeroEmpleado,
        LTRIM(RTRIM(
            ISNULL(E.EMApellidoPaterno, '') + ' '
          + ISNULL(E.EMApellidoMaterno, '') + ' '
          + ISNULL(E.EMNombre1, '') + ' '
          + ISNULL(E.EMNombre2, ''))) AS nombreEmpleado,
        CONVERT(DECIMAL(18, 2), SUM(ISNULL(S.costo, 0))) AS costoAnual,
        S.idUsuario,
        S.fechaDefaulteo
    FROM Selecciones S
    INNER JOIN dbo.ff_Empleado E
      ON E.EMIdEmpresa = S.idEmpresa
     AND E.EMNumeroEmpleado = S.numeroEmpleado
     AND E.EMIdParentesco = 1
    GROUP BY
        S.idEmpresa, S.numeroEmpleado, S.idUsuario, S.fechaDefaulteo,
        E.EMApellidoPaterno, E.EMApellidoMaterno, E.EMNombre1, E.EMNombre2
    ORDER BY S.numeroEmpleado, S.fechaDefaulteo;
END;
GO

/* ===================== FIN 002_reporte_historico_defaulteo.sql ====================== */

/* ==================== INICIO 003_seguridad_y_vigencia_defaulteo_avanzado.sql ==================== */
/* Validacion de vigencia y aislamiento de configuraciones por administrador. */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.bf_DefaulteoAvanzado_ResolverVigencia
    @IdEmpresa INT,
    @IdVigenciaSeleccionada INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdConfiguracion INT;
    DECLARE @IdVigenciaActual INT;
    DECLARE @IdVigenciaAnterior INT;
    DECLARE @EsValida BIT = 0;

    SELECT @IdConfiguracion = EMIdConfiguracion
    FROM dbo.ff_Empresa
    WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1;

    IF EXISTS (
        SELECT 1 FROM dbo.ff_Vigencia
        WHERE VIIdVigencia = @IdVigenciaSeleccionada
          AND VIIdConfiguracion = @IdConfiguracion
          AND VIIdEstatus = 1)
    BEGIN
        SET @EsValida = 1;
        SELECT @IdVigenciaAnterior = VIRenovada
        FROM dbo.ff_Vigencia
        WHERE VIIdVigencia = @IdVigenciaSeleccionada;
    END;

    SELECT TOP (1) @IdVigenciaActual = VIIdVigencia
    FROM dbo.ff_Vigencia
    WHERE VIIdConfiguracion = @IdConfiguracion
      AND VIIdEstatus = 1
      AND CONVERT(DATE, GETDATE()) BETWEEN CONVERT(DATE, VIVigenciaIni) AND CONVERT(DATE, VIVigenciaFin)
    ORDER BY VIVigenciaIni DESC, VIIdVigencia DESC;

    IF @IdVigenciaActual IS NULL
        SELECT TOP (1) @IdVigenciaActual = VIIdVigencia
        FROM dbo.ff_Vigencia
        WHERE VIIdConfiguracion = @IdConfiguracion AND VIIdEstatus = 1
        ORDER BY VIVigenciaIni DESC, VIIdVigencia DESC;

    SELECT
        @EsValida AS esValida,
        CONVERT(BIT, CASE WHEN @EsValida = 1 AND @IdVigenciaSeleccionada = @IdVigenciaActual THEN 1 ELSE 0 END) AS esActual,
        @IdVigenciaActual AS idVigenciaActual,
        @IdVigenciaAnterior AS idVigenciaAnterior;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Guardar
    @Id              INT           = NULL,
    @Nombre          VARCHAR(150),
    @Descripcion     VARCHAR(500)  = NULL,
    @IdCorporativo   INT           = NULL,
    @IdEmpresa       INT           = NULL,
    @IdAdmin         INT,
    @FiltrosJson     NVARCHAR(MAX),
    @AccionesJson    NVARCHAR(MAX) = NULL,
    @IdResult        INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @IdResult = 0;

    IF @Id IS NULL OR @Id = 0
    BEGIN
        INSERT INTO dbo.bf_ConfiguracionDefaulteo
            (CDNombre, CDDescripcion, CDIdCorporativo, CDIdEmpresa, CDIdAdmin,
             CDFiltrosJson, CDAccionesJson, CDIdEstatus, CDFechaAdd)
        VALUES
            (@Nombre, @Descripcion, @IdCorporativo, @IdEmpresa, @IdAdmin,
             @FiltrosJson, @AccionesJson, 1, GETDATE());
        SET @IdResult = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.bf_ConfiguracionDefaulteo
           SET CDNombre = @Nombre,
               CDDescripcion = @Descripcion,
               CDIdCorporativo = @IdCorporativo,
               CDIdEmpresa = @IdEmpresa,
               CDFiltrosJson = @FiltrosJson,
               CDAccionesJson = @AccionesJson,
               CDFechaUmod = GETDATE(),
               CDUsuarioUmod = @IdAdmin
         WHERE CDId = @Id
           AND CDIdAdmin = @IdAdmin
           AND CDIdEstatus = 1;
        IF @@ROWCOUNT = 1 SET @IdResult = @Id;
    END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Eliminar
    @Id      INT,
    @IdAdmin INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.bf_ConfiguracionDefaulteo
       SET CDIdEstatus = 2,
           CDFechaUmod = GETDATE(),
           CDUsuarioUmod = @IdAdmin
     WHERE CDId = @Id
       AND CDIdAdmin = @IdAdmin
       AND CDIdEstatus = 1;
END;
GO

/* ===================== FIN 003_seguridad_y_vigencia_defaulteo_avanzado.sql ====================== */

/* ==================== INICIO 004_compatibilidad_idcorporativo_inserta_planes.sql ==================== */
/*
  Corrige la incompatibilidad de firma detectada en la cadena de defaulteo:
  ff_IInsertaPlanesFlexiblesTmpCreditos requiere @IdCorporativo como parametro 7,
  pero dos callers legados instalados lo invocan con seis parametros.

  El parche conserva la definicion instalada y solo sustituye esa invocacion.
  Es idempotente y falla de forma explicita si la firma esperada no existe.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Objetos TABLE (Nombre sysname PRIMARY KEY);
INSERT @Objetos(Nombre) VALUES
 ('ff_IInsertaPlanesFlexiblesTmp'),
 ('ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3');

DECLARE @Nombre sysname,@Def nvarchar(max),@PosProc int,@CallOld nvarchar(500),@CallNew nvarchar(1000);
DECLARE C CURSOR LOCAL FAST_FORWARD FOR SELECT Nombre FROM @Objetos ORDER BY Nombre;
OPEN C;
FETCH NEXT FROM C INTO @Nombre;
WHILE @@FETCH_STATUS=0
BEGIN
  SET @Def=OBJECT_DEFINITION(OBJECT_ID(N'dbo.'+@Nombre,N'P'));
  IF @Def IS NULL
    THROW 51501,'No existe uno de los procedimientos caller que debe corregirse.',1;

  IF CHARINDEX('IdCorporativoCompat',@Def)=0
  BEGIN
    SET @CallOld=N'exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp';
    IF CHARINDEX(@CallOld,@Def)=0
      THROW 51502,'No se encontro la invocacion de seis parametros esperada. Revise la version del procedimiento.',1;

    SET @CallNew=N'DECLARE @IdCorporativoCompat int =
      (SELECT TOP (1) EMIdCorporativo FROM dbo.ff_Empresa WHERE EMIdEmpresa=@idEmpresa);
exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp,@IdCorporativoCompat';
    SET @Def=REPLACE(@Def,@CallOld,@CallNew);

    SET @PosProc=CHARINDEX('PROCEDURE',UPPER(@Def));
    IF @PosProc=0 THROW 51503,'La definicion no contiene PROCEDURE.',1;
    SET @Def=STUFF(@Def,1,@PosProc-1,'ALTER ');
    EXEC sys.sp_executesql @Def;
  END;

  FETCH NEXT FROM C INTO @Nombre;
END;
CLOSE C;
DEALLOCATE C;

SELECT P.name,
       CASE WHEN OBJECT_DEFINITION(P.object_id) LIKE '%IdCorporativoCompat%'
            THEN 'OK' ELSE 'REVISAR' END Resultado
FROM sys.procedures P
WHERE P.name IN('ff_IInsertaPlanesFlexiblesTmp','ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3')
ORDER BY P.name;

/* ===================== FIN 004_compatibilidad_idcorporativo_inserta_planes.sql ====================== */
