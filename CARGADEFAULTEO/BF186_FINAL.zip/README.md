# Paquete corto - Carga Masiva B2/B3 y Defaulteo 1/2/3

Paquete final para la empresa 186. Descomprima directamente en una ruta corta,
por ejemplo `C:\TMP\BF186`, para evitar el limite `MAX_PATH` de Windows.

## Instalacion

Ejecute `DB/INSTALL/ALL.sql` en la base destino desde SSMS. El consolidado
incluye, en orden:

1. catalogo y configuracion independiente B2/B3;
2. reporte historico de defaulteo;
3. seguridad y vigencia del defaulteo avanzado;
4. compatibilidad de `@IdCorporativo` en la persistencia legada.

Los archivos `001.sql` a `004.sql` contienen las mismas partes por separado.
Los SQL de `DB/PRUEBAS` no forman parte de la instalacion. Se usa este nombre
porque `AUX` es una palabra reservada de Windows y puede impedir la extraccion.

## Prueba recomendada

1. `DB/PRUEBAS/PRECHECK.sql`
2. `DB/INSTALL/ALL.sql`
3. `DB/PRUEBAS/POSTCHECK.sql`
4. `DB/PRUEBAS/INSUMOS_186.sql`
5. `DB/PRUEBAS/TEST_FLUJOS_B2_B3_186.sql`
6. `DB/PRUEBAS/DUMMY_DEF_123_186.sql`
7. `DB/PRUEBAS/TEST_MOTOR_DEF_123_186.sql`
8. `DB/PRUEBAS/TEST_TRANSACCION_DEF_186.sql`
9. `DB/PRUEBAS/MENU_DEF_NIVEL_CM_186.sql`
10. `DB/PRUEBAS/VERIFICACION_FINAL_186.sql`

`TEST_TRANSACCION_DEF_186.sql` y la simulacion B2/B3 usan rollback. El script
de menu es idempotente y coloca Defaulteo al mismo nivel y con la misma imagen
que Carga Masiva BF3.

## Ejemplos para usuario

- `EJEMPLOS/EJEMPLO_B2_ALTA_DEPENDIENTE_EMPRESA_186.txt`
- `EJEMPLOS/EJEMPLO_B3_ALTA_DEPENDIENTE_EMPRESA_186.xlsx`

## Mapa de proyectos

| Carpeta | Proyecto destino |
|---|---|
| `SRC/WS` | backend principal `WSBeFlex` |
| `SRC/B3` | frontend Angular `BeFlex3-EmpAdm` |
| `SRC/RPT` | API Java de reportes |
| `SRC/B2` | aplicacion ASP.NET legada |

Las rutas debajo de cada abreviatura conservan la estructura interna del
proyecto. Consulte `DOC/RESULTADO.md` para la matriz de pruebas, correcciones y
limitaciones del ambiente local.
