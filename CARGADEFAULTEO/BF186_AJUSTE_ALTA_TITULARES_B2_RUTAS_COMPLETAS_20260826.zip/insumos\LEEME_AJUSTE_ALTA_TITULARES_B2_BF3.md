# Ajuste de Alta de Titulares B2 ejecutada desde BF3

## Diagnóstico

La plantilla activa `507` contiene 32 campos: `EMEmpresa` como campo común y
31 campos por registro. El procedimiento `ff_XCMTitularesAltaCMDeloitte`
declara 35 parámetros.

Los tres parámetros que no provienen directamente de esos 32 campos son:

- `EMIdEmpresa`: BF3 lo obtiene de la empresa autorizada en la sesión.
- `EMPuesto2`: parámetro opcional que no participa en la lógica activa del SP.
- `EMPerfil`: el SP lo calcula de acuerdo con empresa, puesto y tipo de empleado.

El error `Required input parameter 'EMPuesto2' is missing` ocurría antes de
entrar al SP: `SimpleJdbcCall` exige todos los parámetros declarados, incluso
los que SQL Server define con valor predeterminado.

## Procedencia y nombre del procedimiento

`dbo.ff_XCMTitularesAltaCMDeloitte` **no fue creado ni modificado por esta
homologación**. Es un objeto legacy que ya existe en el esquema base. La
configuración disponible en `dbo.ff_CargaMasivaOperacionEmpresa` lo relaciona
con la operación 2, plantilla 507 y empresa 186 desde el 25 de junio de 2007.

El nombre `Deloitte` identifica las reglas históricas de ese cliente/grupo. El
SP contiene decisiones para la empresa 186 y otras razones sociales o IDs del
mismo universo operativo; no significa que el procedimiento haya sido creado
ahora ni que deba renombrarse para BF3.

B2 tampoco tenía el nombre fijado en el código: obtenía `CEStoredProc` de la
parametrización y ejecutaba el procedimiento configurado. BF3 conserva ese
mismo contrato. Renombrarlo rompería la configuración existente y dejaría de
ser una homologación fiel del flujo legacy.

Este paquete no incluye ningún `CREATE PROCEDURE` ni `ALTER PROCEDURE` para
`ff_XCMTitularesAltaCMDeloitte`. Los cambios realizados son únicamente de
adaptación en backend, frontend, pruebas y generación de insumos.

## Solución aplicada

- El backend agrega `EMPuesto2` y `EMPerfil` vacíos únicamente para
  `ff_XCMTitularesAltaCMDeloitte`.
- No se agregaron esos campos al TXT ni a la plantilla 507. Esto conserva el
  contrato legacy y evita que el usuario imponga un perfil distinto al que
  determinan las reglas de B2.
- La descarga de BF3 obtiene `EMEmpresa` desde
  `ff_Empresa.EMIdEmpresaFlexiForbes`. Por eso puede ser `186edf`, `S001` u
  otra clave según la base; no debe sustituirse por el ID interno `186`.
- El ejemplo de alta usa CECO, área y oficina de catálogos reales de la empresa.
- Cada descarga genera número, nombre y apellido dummy diferentes. Esto cubre
  la validación del SP base que rechaza homónimos con la misma fecha de nacimiento.
- Los scripts validan perfil operativo, rol predeterminado, rango de edad,
  duplicados, plantilla activa y contrato completo de cada SP.

## Orden de aplicación

1. Reemplazar los archivos de backend y frontend incluidos en el paquete.
2. Compilar y desplegar ambos proyectos.
3. En la base de pruebas, ajustar los cuatro parámetros al inicio de
   `PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql` y ejecutarlo sólo si se requieren
   los siete escenarios controlados.
4. Ajustar los mismos parámetros en
   `GENERAR_INPUTS_TXT_CARGA_MASIVA_EMPRESA_186.sql` y ejecutarlo.
5. Copiar cada valor de la columna `ContenidoTXT` del bloque
   `03_CONTENIDO_TXT_LISTO`, o descargar nuevamente el ejemplo desde BF3.

`PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql` modifica únicamente el lote QA
identificado por empresa y `@NumeroPrueba`. El generador es sólo lectura.

## Rutas de reemplazo

El ZIP conserva las rutas reales desde `CARGADEFAULTEO`; puede extraerse sobre
esa carpeta para que cada archivo quede en su proyecto correspondiente:

- `WSBeFlex-EmpAdm-defaulteoCargaMaisva/WSBeFlex-EmpAdm-defaulteoCargaMaisva/src/main/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2Service.java`
- `WSBeFlex-EmpAdm-defaulteoCargaMaisva/WSBeFlex-EmpAdm-defaulteoCargaMaisva/src/main/java/com/lockton/WSBeFlex/DAO/JDBCFfEmpresa.java`
- `WSBeFlex-EmpAdm-defaulteoCargaMaisva/WSBeFlex-EmpAdm-defaulteoCargaMaisva/src/test/java/com/lockton/WSBeFlex/Services/CargaMasivaB2/CargaMasivaB2ServiceTest.java`
- `BeFlex3-EmpAdm-defaulteoCargaMaisva/BeFlex3-EmpAdm-defaulteoCargaMaisva/src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts`
- `insumos/GENERAR_INPUTS_TXT_CARGA_MASIVA_EMPRESA_186.sql`
- `insumos/PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql`
- `insumos/LEEME_AJUSTE_ALTA_TITULARES_B2_BF3.md`

Los dos archivos SQL son insumos de QA y no forman parte del script de
instalación de objetos productivos.

## Resultado esperado en la traza

Para la operación 2 deben aparecer las etapas `CONTEXTO_SEGURO` y
`COMPATIBILIDAD_SP`; después debe ejecutarse el SP. Ya no debe aparecer un
error de parámetro faltante para `EMIdEmpresa`, `EMPuesto2` o `EMPerfil`.

Si el SP devuelve después un mensaje de negocio, la traza ya identificará el
renglón y la etapa real de la validación.

## Validaciones realizadas

- Compilación TypeScript sin emisión: correcta.
- Pruebas unitarias del servicio B2: 4 ejecutadas, 0 fallas, 0 errores.
- Cruce de siete operaciones activas contra plantilla y parámetros de SP:
  ningún parámetro pendiente.
- Generador ejecutado contra LocalDB: siete estructuras `OK` y resumen final
  `OK: TODAS LAS OPERACIONES ACTIVAS TIENEN INPUT TXT`.
- Alta de titular ejecutada dentro de una transacción local:
  `Return_Code = 0`, `Carga Exitosa`.
- La transacción se revirtió y se verificó que no quedaran el titular ni el
  administrador temporal utilizados para la simulación.

La copia LocalDB usa `EMEmpresa=S001`; la base de la traza usa
`EMEmpresa=186edf`. Ambos son correctos en su propio ambiente porque el valor
se consulta y valida dinámicamente.
