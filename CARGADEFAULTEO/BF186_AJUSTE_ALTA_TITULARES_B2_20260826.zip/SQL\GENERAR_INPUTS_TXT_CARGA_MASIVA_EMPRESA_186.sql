/*
  GENERADOR PARAMETRIZABLE DE INPUTS TXT B2 PARA EJECUTAR DESDE BF3

  SOLO LECTURA: no inserta, actualiza ni elimina registros.

  Cambie solamente los parametros. Para el ejemplo solicitado:
      @IdEmpresa    = 186
      @ClaveUsuario = 'jvazquez'

  Los valores sujetos a validaciones se consultan en la BD. Solo los datos
  propios de QA (numeros reservados, nombres, RFC, CURP, correo y notas) son
  dummy. EMEmpresa siempre se obtiene de ff_Empresa.EMIdEmpresaFlexiForbes
  para la BD donde se ejecuta; no se supone ni se deja fija una clave.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ========================== PARAMETROS ========================== */
DECLARE @IdEmpresa       INT         = 186;
DECLARE @ClaveUsuario    VARCHAR(50) = 'jvazquez';
DECLARE @IdEmpresaOrigen INT         = 187; -- Solo operacion 15.
DECLARE @NumeroPrueba    INT         = 1;   -- Cambie a 2, 3, 4... para otro lote.
/* =============================================================== */

DECLARE @CRLF VARCHAR(2) = CHAR(13) + CHAR(10);
DECLARE @HoyTexto VARCHAR(10) = CONVERT(VARCHAR(10), GETDATE(), 103);
DECLARE @Ahora DATETIME = GETDATE();

DECLARE @NombreEmpresa NVARCHAR(500);
DECLARE @ClaveEmpresaLegacy VARCHAR(150);
DECLARE @IdConfiguracion INT;
DECLARE @IdCorporativo INT;
DECLARE @IdUsuario INT;
DECLARE @IdRolDestino INT;
DECLARE @IdPerfilDestino INT;
DECLARE @IdPerfilAlta INT;
DECLARE @IdRolPerfilAlta INT;
DECLARE @EdadMinAlta INT;
DECLARE @EdadMaxAlta INT;
DECLARE @IdVigencia INT;
DECLARE @IdEmpleadoReferencia INT;
DECLARE @NumeroEmpleadoReferencia VARCHAR(20);
DECLARE @NombreEmpleadoReferencia VARCHAR(250);
DECLARE @Area VARCHAR(100);
DECLARE @Oficina VARCHAR(100);
DECLARE @CentroCostos VARCHAR(100);
DECLARE @Puesto VARCHAR(50);
DECLARE @IdCompensacion INT;
DECLARE @OrigenCompensacion VARCHAR(100);

/* Empresa + lote de seis digitos + escenario de dos digitos.
   Empresa 186/prueba 1: 18600000101 ... 18600000108.
   Empresa 186/prueba 2: 18600000201 ... 18600000208. */
DECLARE @Lote VARCHAR(6) = RIGHT('000000' + CONVERT(VARCHAR(6), @NumeroPrueba), 6);
DECLARE @Prefijo VARCHAR(18) = CONVERT(VARCHAR(10), @IdEmpresa) + @Lote;
DECLARE @N1 VARCHAR(20) = @Prefijo + '01';
DECLARE @N2 VARCHAR(20) = @Prefijo + '02';
DECLARE @N3 VARCHAR(20) = @Prefijo + '03';
DECLARE @N4 VARCHAR(20) = @Prefijo + '04';
DECLARE @N5 VARCHAR(20) = @Prefijo + '05';
DECLARE @N6 VARCHAR(20) = @Prefijo + '06';
DECLARE @N7 VARCHAR(20) = @Prefijo + '07';
DECLARE @N8 VARCHAR(20) = @Prefijo + '08';
DECLARE @Periodo VARCHAR(50) = 'QACM' + CONVERT(VARCHAR(10), @IdEmpresa) + 'P' + CONVERT(VARCHAR(6), @NumeroPrueba);
DECLARE @RegistroAutos VARCHAR(100) = 'QACM-CIS-' + CONVERT(VARCHAR(10), @IdEmpresa) + '-P' + CONVERT(VARCHAR(6), @NumeroPrueba);
DECLARE @CurpDummy VARCHAR(50) = 'QACM' + @Lote + 'HDFLRN01';
DECLARE @RfcDummy VARCHAR(20) = 'QAC' + @Lote + 'AA1';
DECLARE @NombreAlta VARCHAR(70) = 'DUMMY' + @Lote;
DECLARE @ApellidoAlta VARCHAR(30) = 'PRUEBA' + RIGHT(@Lote, 4);
DECLARE @FechaNacimientoAlta DATE = CONVERT(DATE, '19900520', 112);

IF OBJECT_ID('dbo.ff_Empresa', 'U') IS NULL
    THROW 51900, 'No existe dbo.ff_Empresa en la base seleccionada.', 1;

IF @NumeroPrueba NOT BETWEEN 1 AND 999999
    THROW 51899, '@NumeroPrueba debe estar entre 1 y 999999.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1
)
    THROW 51901, 'La empresa indicada no existe o esta inactiva.', 1;

SELECT
    @NombreEmpresa = E.EMNombre,
    @ClaveEmpresaLegacy = NULLIF(LTRIM(RTRIM(E.EMIdEmpresaFlexiForbes)), ''),
    @IdConfiguracion = E.EMIdConfiguracion,
    @IdCorporativo = E.EMIdCorporativo
FROM dbo.ff_Empresa E
WHERE E.EMIdEmpresa = @IdEmpresa;

IF @ClaveEmpresaLegacy IS NULL
    THROW 51902, 'La empresa no tiene EMIdEmpresaFlexiForbes; no se puede generar EMEmpresa.', 1;

/* ff_XCMTitularesAltaCMDeloitte recibe EMEmpresa como VARCHAR(20) y vuelve a
   resolver el ID interno. Una clave larga o duplicada produciria una carga
   ambigua aunque el archivo tenga una estructura correcta. */
IF LEN(@ClaveEmpresaLegacy) > 20
    THROW 51915, 'EMIdEmpresaFlexiForbes excede VARCHAR(20), contrato del SP de alta de titulares.', 1;

IF
(
    SELECT COUNT(*)
    FROM dbo.ff_Empresa E
    WHERE E.EMIdEstatus = 1
      AND LTRIM(RTRIM(E.EMIdEmpresaFlexiForbes)) = @ClaveEmpresaLegacy
) <> 1
    THROW 51916, 'EMIdEmpresaFlexiForbes no identifica exactamente una empresa activa.', 1;

IF @ClaveEmpresaLegacy LIKE '%|%' OR @ClaveEmpresaLegacy LIKE '%' + CHAR(13) + '%'
   OR @ClaveEmpresaLegacy LIKE '%' + CHAR(10) + '%'
    THROW 51917, 'EMIdEmpresaFlexiForbes contiene caracteres incompatibles con el TXT B2.', 1;

IF NULLIF(LTRIM(RTRIM(@ClaveUsuario)), '') IS NULL
    THROW 51903, 'Capture @ClaveUsuario.', 1;

IF
(
    SELECT COUNT(*)
    FROM dbo.ff_Administrador A
    WHERE UPPER(LTRIM(RTRIM(A.ADClaveAcceso))) = UPPER(LTRIM(RTRIM(@ClaveUsuario)))
      AND A.ADIdEstatus = 1
) <> 1
    THROW 51904, 'La clave no identifica exactamente a un administrador activo.', 1;

SELECT @IdUsuario = A.ADIdAdministrador
FROM dbo.ff_Administrador A
WHERE UPPER(LTRIM(RTRIM(A.ADClaveAcceso))) = UPPER(LTRIM(RTRIM(@ClaveUsuario)))
  AND A.ADIdEstatus = 1;

/* Preferir rol default; si no existe, usar el mas frecuente en titulares. */
SELECT TOP (1) @IdRolDestino = R.ROIdRol
FROM dbo.ff_Rol R
WHERE R.ROIdEmpresa = @IdEmpresa
  AND R.ROIdEstatus = 1
  AND R.RODefault = 1
ORDER BY R.ROIdRol;

IF @IdRolDestino IS NULL
BEGIN
    SELECT TOP (1) @IdRolDestino = E.EMIdRol
    FROM dbo.ff_Empleado E
    INNER JOIN dbo.ff_Rol R
        ON R.ROIdRol = E.EMIdRol
       AND R.ROIdEmpresa = @IdEmpresa
       AND R.ROIdEstatus = 1
    WHERE E.EMIdEmpresa = @IdEmpresa
      AND E.EMIdEstatus = 1
      AND E.EMIdParentesco = 1
      AND E.EMIdTitular = 1
      AND E.EMIdRol IS NOT NULL
    GROUP BY E.EMIdRol
    ORDER BY COUNT(*) DESC, E.EMIdRol;
END;

IF @IdRolDestino IS NULL
    THROW 51905, 'No fue posible resolver un rol valido para la empresa.', 1;

/* Titular real usado unicamente como fuente de catalogos organizacionales.
   El SP Deloitte no recibe los IDs: busca TEDescripcion en los catalogos
   area/oficina/CECO. Por eso aqui se recuperan las descripciones reales. */
SELECT TOP (1)
    @IdEmpleadoReferencia = E.Id,
    @NumeroEmpleadoReferencia = E.EMNumeroEmpleado,
    @NombreEmpleadoReferencia = LTRIM(RTRIM(
        ISNULL(E.EMNombre1, '') + ' ' + ISNULL(E.EMNombre2, '') + ' ' +
        ISNULL(E.EMApellidoPaterno, '') + ' ' + ISNULL(E.EMApellidoMaterno, ''))),
    @IdPerfilDestino = E.EMIdPerfil,
    @Area = A.TEDescripcion,
    @Oficina = O.TEDescripcion,
    @CentroCostos = C.TEDescripcion,
    @Puesto = LEFT(COALESCE(NULLIF(LTRIM(RTRIM(E.EMPuesto)), ''), 'STAFF'), 50)
FROM dbo.ff_Empleado E
INNER JOIN dbo.ff_Perfil P
    ON P.PEIdPerfil = E.EMIdPerfil
   AND P.PEIdEmpresa = @IdEmpresa
   AND P.PEIdEstatus = 1
OUTER APPLY
(
    SELECT TOP (1) D.TEDescripcion
    FROM dbo.ff_TablaEncabezado H
    INNER JOIN dbo.ff_TablaEncabezadoDetalle D ON D.TEEnClave = H.ENClave
    WHERE H.ENIdEmpresa = @IdEmpresa AND H.ENIdEstatus = 1
      AND LOWER(H.ENEncabezado) = 'area' AND D.TEIdDetalle = E.EMArea
      AND D.TEIdEstatus = 1
) A
OUTER APPLY
(
    SELECT TOP (1) D.TEDescripcion
    FROM dbo.ff_TablaEncabezado H
    INNER JOIN dbo.ff_TablaEncabezadoDetalle D ON D.TEEnClave = H.ENClave
    WHERE H.ENIdEmpresa = @IdEmpresa AND H.ENIdEstatus = 1
      AND LOWER(H.ENEncabezado) = 'oficina' AND D.TEIdDetalle = E.EMOficina
      AND D.TEIdEstatus = 1
) O
OUTER APPLY
(
    SELECT TOP (1) D.TEDescripcion
    FROM dbo.ff_TablaEncabezado H
    INNER JOIN dbo.ff_TablaEncabezadoDetalle D ON D.TEEnClave = H.ENClave
    WHERE H.ENIdEmpresa = @IdEmpresa AND H.ENIdEstatus = 1
      AND UPPER(H.ENEncabezado) = 'CECO' AND D.TEIdDetalle = E.EMIdCentroCostos
      AND D.TEIdEstatus = 1
) C
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdEstatus = 1
  AND E.EMIdParentesco = 1
  AND E.EMIdTitular = 1
  AND E.EMIdPerfil IS NOT NULL
  AND E.EMArea IS NOT NULL
  AND E.EMOficina IS NOT NULL
  AND E.EMIdCentroCostos IS NOT NULL
  AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
  AND A.TEDescripcion IS NOT NULL
  AND O.TEDescripcion IS NOT NULL
  AND C.TEDescripcion IS NOT NULL
ORDER BY CASE WHEN E.EMIdRol = @IdRolDestino THEN 0 ELSE 1 END, E.Id DESC;

IF @IdEmpleadoReferencia IS NULL
    THROW 51906, 'No hay un titular activo completo para obtener perfil/area/oficina/centro de costos.', 1;

IF @Area LIKE '%|%' OR @Oficina LIKE '%|%' OR @CentroCostos LIKE '%|%' OR @Puesto LIKE '%|%'
   OR @Area LIKE '%' + CHAR(13) + '%' OR @Area LIKE '%' + CHAR(10) + '%'
   OR @Oficina LIKE '%' + CHAR(13) + '%' OR @Oficina LIKE '%' + CHAR(10) + '%'
   OR @CentroCostos LIKE '%' + CHAR(13) + '%' OR @CentroCostos LIKE '%' + CHAR(10) + '%'
   OR @Puesto LIKE '%' + CHAR(13) + '%' OR @Puesto LIKE '%' + CHAR(10) + '%'
    THROW 51918, 'Los catalogos organizacionales seleccionados contienen caracteres incompatibles con el TXT B2.', 1;

/* Perfil que el propio ff_XCMTitularesAltaCMDeloitte asigna en la rama de
   EMPLEADO. EMPerfil no forma parte de la plantilla 507 porque es un dato
   derivado, pero debe existir para que el alta llegue completa al SP base. */
SET @IdPerfilAlta = CASE @IdEmpresa
    WHEN 186 THEN 678 WHEN 187 THEN 677 WHEN 188 THEN 697 WHEN 189 THEN 696
    WHEN 248 THEN 818 WHEN 249 THEN 822 WHEN 417 THEN 1354 WHEN 479 THEN 1580
    WHEN 596 THEN 2079 WHEN 597 THEN 2090 WHEN 598 THEN 2101 WHEN 599 THEN 2112
    ELSE NULL END;

IF @IdPerfilAlta IS NULL
    THROW 51919, 'El SP Deloitte no define perfil de empleado para la empresa indicada.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Perfil P
    WHERE P.PEIdPerfil = @IdPerfilAlta
      AND P.PEIdEmpresa = @IdEmpresa
      AND P.PEIdEstatus = 1
      AND P.PEAdministrador = 0
)
    THROW 51920, 'El perfil que calcula el SP Deloitte no existe, esta inactivo o es administrador.', 1;

SELECT @IdRolPerfilAlta = CASE
    WHEN P.PEIdRolDefault = 1 THEN
    (
        SELECT TOP (1) R.ROIdRol
        FROM dbo.ff_Rol R
        WHERE R.ROIdEmpresa = @IdEmpresa
          AND R.ROIdEstatus = 1
          AND R.RODefault = 1
        ORDER BY R.ROIdRol
    )
    ELSE P.PEIdRolDefault END
FROM dbo.ff_Perfil P
WHERE P.PEIdPerfil = @IdPerfilAlta
  AND P.PEIdEmpresa = @IdEmpresa
  AND P.PEIdEstatus = 1
  AND P.PEAdministrador = 0;

IF ISNULL(@IdRolPerfilAlta, 0) < 2
    THROW 51921, 'El perfil derivado no resuelve un rol predeterminado valido.', 1;

SELECT
    @EdadMinAlta = CP.PCEdadMinima,
    @EdadMaxAlta = CP.PCEdadMaxima
FROM dbo.ff_ConfiguracionParentesco CP
WHERE CP.PCIdConfiguracion = @IdConfiguracion
  AND CP.PCIdParentesco = 1;

IF @EdadMinAlta IS NULL OR @EdadMaxAlta IS NULL
    THROW 51922, 'No existe rango de edad para titulares en la configuracion de la empresa.', 1;

DECLARE @EdadAlta INT = DATEDIFF(YEAR, @FechaNacimientoAlta, CONVERT(DATE, GETDATE()))
    - CASE WHEN DATEADD(YEAR, DATEDIFF(YEAR, @FechaNacimientoAlta, CONVERT(DATE, GETDATE())),
                              @FechaNacimientoAlta) > CONVERT(DATE, GETDATE())
           THEN 1 ELSE 0 END;

IF @EdadAlta NOT BETWEEN @EdadMinAlta AND @EdadMaxAlta
    THROW 51923, 'La fecha de nacimiento dummy no cumple el rango de edad configurado para titulares.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.ff_Empleado E
    INNER JOIN dbo.ff_Empresa EE ON EE.EMIdEmpresa = E.EMIdEmpresa
    WHERE E.EMNumeroEmpleado = @N2
      AND EE.EMIdEstatus = 1
      AND EE.EMIdCorporativo = @IdCorporativo
)
    THROW 51924, 'El numero dummy de alta de titular ya existe; cambie @NumeroPrueba.', 1;

IF EXISTS
(
    SELECT 1 FROM dbo.ff_Empleado E
    WHERE E.EMIdEmpresa = @IdEmpresa
      AND E.EMNombre1 = @NombreAlta
      AND E.EMApellidoPaterno = @ApellidoAlta
      AND CONVERT(DATE, E.EMFechaNacimiento) = @FechaNacimientoAlta
)
    THROW 51925, 'Ya existe el nombre/fecha dummy de alta de titular; cambie @NumeroPrueba.', 1;

/*
  Comprueba las equivalencias reales que aplicara el motor B2 antes de
  convertir los campos de tipo E a entero. No se asume que F=2 o H=3.
*/
IF OBJECT_ID('dbo.ff_CMCSexo', 'P') IS NULL
    THROW 51911, 'No existe dbo.ff_CMCSexo, requerido por EMIdSexo.', 1;

IF OBJECT_ID('dbo.ff_CMCParentesco', 'P') IS NULL
    THROW 51912, 'No existe dbo.ff_CMCParentesco, requerido por EMIdParentesco.', 1;

DECLARE @RangoSexo TABLE ([key] VARCHAR(32), [value] VARCHAR(32));
DECLARE @RangoParentesco TABLE ([key] VARCHAR(32), [value] VARCHAR(32));
DECLARE @SexoEntrada VARCHAR(32) = 'F';
DECLARE @SexoResuelto VARCHAR(32);
DECLARE @ParentescoEntrada VARCHAR(32) = 'H';
DECLARE @ParentescoResuelto VARCHAR(32);

INSERT @RangoSexo EXEC dbo.ff_CMCSexo;
INSERT @RangoParentesco EXEC dbo.ff_CMCParentesco;

SELECT TOP (1) @SexoResuelto = [value]
FROM @RangoSexo WHERE [key] = @SexoEntrada;

SELECT TOP (1) @ParentescoResuelto = [value]
FROM @RangoParentesco WHERE [key] = @ParentescoEntrada;

IF TRY_CONVERT(INT, @SexoResuelto) IS NULL
    THROW 51913, 'La plantilla no puede convertir F mediante dbo.ff_CMCSexo.', 1;

IF TRY_CONVERT(INT, @ParentescoResuelto) IS NULL
    THROW 51914, 'La plantilla no puede convertir H mediante dbo.ff_CMCParentesco.', 1;

SELECT TOP (1) @IdVigencia = V.VIIdVigencia
FROM dbo.ff_Vigencia V
WHERE V.VIIdConfiguracion = @IdConfiguracion
  AND V.VIIdEstatus = 1
ORDER BY
    CASE WHEN CONVERT(DATE, @Ahora) BETWEEN CONVERT(DATE, V.VIVigenciaIni)
                                      AND CONVERT(DATE, V.VIVigenciaFin)
         THEN 0 ELSE 1 END,
    V.VIVigenciaIni DESC,
    V.VIIdVigencia DESC;

IF @IdVigencia IS NULL
    THROW 51907, 'No existe una vigencia activa para la configuracion de la empresa.', 1;

/* El ID de compensacion debe existir; ya no se inventa 900001. */
SELECT TOP (1)
    @IdCompensacion = C.CSIdCompensacion,
    @OrigenCompensacion = 'bf_Compensacion_STEmpleado (movimiento real)'
FROM dbo.bf_Compensacion_STEmpleado C
INNER JOIN dbo.ff_Empleado E ON E.Id = C.CSIdEmpleado
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdParentesco = 1
  AND C.CSIdCompensacion IS NOT NULL
ORDER BY C.CSFechaAdd DESC;

IF @IdCompensacion IS NULL
BEGIN
    SELECT TOP (1)
        @IdCompensacion = C.CCSIdConfiguracion,
        @OrigenCompensacion = 'bf_Compensacion_STConfiguracion (configuracion activa)'
    FROM dbo.bf_Compensacion_STConfiguracion C
    WHERE C.CCSIdVigencia = @IdVigencia
      AND C.CCSIdEstatus = 1
    ORDER BY C.CCSOrden, C.CCSIdConfiguracion;
END;

/* El SP ff_CargaMasivaCompensacionEmpleado no valida el ID contra catalogo;
   cuando la empresa no tiene una compensacion previa/configurada, este dato
   si puede ser dummy sin romper una validacion de BD. */
IF @IdCompensacion IS NULL
BEGIN
    SET @IdCompensacion = 900001;
    SET @OrigenCompensacion = 'DUMMY QA: EL SP NO VALIDA CATALOGO DE COMPENSACION';
END;

IF @IdEmpresaOrigen IS NULL OR @IdEmpresaOrigen = @IdEmpresa
    THROW 51909, '@IdEmpresaOrigen debe existir y ser distinta de @IdEmpresa.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMIdEmpresa = @IdEmpresaOrigen AND EMIdEstatus = 1
)
    THROW 51910, 'La empresa origen de transferencia no existe o esta inactiva.', 1;

DECLARE @Inputs TABLE
(
    Orden INT NOT NULL PRIMARY KEY,
    IdOperacion INT NOT NULL UNIQUE,
    Archivo VARCHAR(120) NOT NULL,
    TipoInsumo VARCHAR(40) NOT NULL,
    ExplicacionInsumo VARCHAR(1000) NOT NULL,
    ParaQueSirve VARCHAR(500) NOT NULL,
    Precondicion VARCHAR(800) NOT NULL,
    NumeroEmpleadoPrueba VARCHAR(100) NOT NULL,
    ResultadoEsperado VARCHAR(500) NOT NULL,
    CamposComunes VARCHAR(MAX) NOT NULL,
    LineasComunes VARCHAR(MAX) NOT NULL,
    CamposRegistro VARCHAR(MAX) NOT NULL,
    DatosRegistro VARCHAR(MAX) NOT NULL
);

INSERT @Inputs
(
    Orden, IdOperacion, Archivo, TipoInsumo, ExplicacionInsumo,
    ParaQueSirve, Precondicion,
    NumeroEmpleadoPrueba, ResultadoEsperado,
    CamposComunes, LineasComunes, CamposRegistro, DatosRegistro
)
VALUES
(
    1, 1, '01_ALTA_DEPENDIENTE_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'DUMMY EXISTENTE CONTROLADO',
    'Usa el titular dummy preparado ' + @N1 + '. Ya existe y cumple empresa, titularidad, perfil, rol y estatus; el dependiente que se agrega tambien es dummy.',
    'Agrega un dependiente a un titular existente.',
    'Debe existir activo el titular dummy ' + @N1 + ' en la empresa destino.',
    @N1, 'Se crea un dependiente del titular ' + @N1 + '.',
    'EMIdEmpresa', 'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa),
    'EMIdSexo,EMNumeroEmpleado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMFechaAntiguedadGMM,EMIdParentesco,EMFechaAlta,EMObservaciones,EMCertificado',
    @SexoEntrada + '|' + @N1 + '|PRUEBA|DEPENDIENTE|DUMMY|CARGA|15/06/2015|01/01/2024|' + @ParentescoEntrada + '|' +
        @HoyTexto + '|QA CARGA B2 BF3 PRUEBA ' + CONVERT(VARCHAR(6), @NumeroPrueba) + '|' + @N1 + '01'
),
(
    2, 2, '02_ALTA_TITULAR_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'DUMMY NUEVO',
    'El numero ' + @N2 + ' no existe. Los datos personales son dummy; empresa, puesto, CECO, area y oficina provienen de la BD y ya cumplen los catalogos usados por el SP.',
    'Crea un titular nuevo mediante la plantilla configurada.',
    'El numero dummy ' + @N2 + ' no debe existir antes de ejecutar la carga.',
    @N2, 'Se crea un titular nuevo con valores organizacionales tomados de la BD.',
    'EMEmpresa', 'EMEmpresa=' + @ClaveEmpresaLegacy,
    'EMNumeroEmpleado,EMPuestoDescripcion,EMNombre1,EMApellidoPaterno,EMApellidoMaterno,EMFechaNacimiento,EMIdSexo,EMFechaIngresoEmpresa,EMIdEstatus,EMFechaBaja,EMFechaEstatus,EMcurp,EMrfc,EMIdTransferido,EMEstadoFisical_text,EMnss,EMPuesto,EMCentroCostos_text,EMOficina_text,EMArea_text,EMArchivoInformacion,EMCorreoElectronico,EMCalleFisico,EMMunicipioDelegacionFiscal,EMJefe,EMEstadoFisico_text,EMColoniaFiscal,EMColoniaFisico,EMMunicipioDelegacionFisico,EMSalarioBase,EMCodigoPostalFisico',
    @N2 + '|' + @Puesto + '|' + @NombreAlta + '|' + @ApellidoAlta + '|TITULAR|20/05/1990|M|' + @HoyTexto +
        '|3||' + @HoyTexto + '|' + @CurpDummy + '|' + @RfcDummy + '|0|' + @Oficina + '|' + RIGHT('00000000000' + @N2, 11) + '|' +
        @Puesto + '|' + @CentroCostos + '|' + @Area + '|' + @Area + '|STAFF' +
        '|qacm.' + CONVERT(VARCHAR(10), @IdEmpresa) + '.p' + CONVERT(VARCHAR(6), @NumeroPrueba) + '@dummy.mx|DOMICILIO DUMMY||0|||0|0|4|0'
),
(
    3, 5, '05_CONCILIACION_AUTOS_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'DUMMY EXISTENTE CON CADENA',
    'Usa el empleado dummy ' + @N7 + ' y una cadena QA de calendario, solicitud, estado de cuenta y desglose. Se evita conciliar descuentos reales de otro empleado.',
    'Concilia un descuento contra una solicitud de autos preparada para QA.',
    'Debe existir la cadena dummy de calendario, solicitud y estado de cuenta para ' + @N7 + '.',
    @N7, 'Se concilian 100.00 en la cadena de autos preparada.',
    'EMEmpresa,EMUsuarioUMod',
    'EMEmpresa=' + @ClaveEmpresaLegacy + @CRLF +
        'EMUsuarioUMod=' + CONVERT(VARCHAR(20), @IdUsuario),
    'EMNumeroEmpleado,Quincenaanio,SANumeroRegistroAseguradora,CDMontoConciliacion',
    @N7 + '|' + @Periodo + '|' + @RegistroAutos + '|100.00'
),
(
    4, 13, '13_CAMBIO_NUMERO_EMPLEADO_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'DUMMY EXISTENTE CONTROLADO',
    'Usa el titular dummy ' + @N3 + ' y reserva ' + @N4 + ' como nuevo numero. No modifica el identificador de un empleado real.',
    'Cambia el numero de un titular existente.',
    'Debe existir ' + @N3 + ' y no debe existir ' + @N4 + '.',
    @N3 + ' -> ' + @N4, 'El titular queda identificado con ' + @N4 + '.',
    'EMIdEmpresa', 'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa),
    'EMNumeroEmpleado,EMNuevoNumeroEmpleado', @N3 + '|' + @N4
),
(
    5, 14, '14_REACTIVACION_EMPLEADO_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'DUMMY EXISTENTE INACTIVO',
    'Usa el titular dummy ' + @N5 + ', preparado con estatus de baja y fecha de baja. Reactivar un empleado real alteraria informacion operativa.',
    'Reactiva a un titular dado de baja.',
    'Debe existir ' + @N5 + ' inactivo y con fecha de baja.',
    @N5, 'El titular y sus dependientes quedan activos.',
    'EMIdEmpresa', 'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa),
    'EMNumeroEmpleado,EMFechaReingreso', @N5 + '|' + @HoyTexto
),
(
    6, 15, '15_TRANSFERENCIA_EMPLEADO_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'DUMMY EXISTENTE EN ORIGEN',
    'Usa el titular dummy ' + @N8 + ' preparado en la empresa origen. Perfil, empresa origen y empresa destino si son registros reales validados.',
    'Transfiere un titular de la empresa origen a la empresa destino.',
    'Debe existir activo ' + @N8 + ' en la empresa ' + CONVERT(VARCHAR(10), @IdEmpresaOrigen) + '.',
    @N8, 'El titular cambia a la empresa ' + CONVERT(VARCHAR(10), @IdEmpresa) + '.',
    'EMIdEmpresa', 'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa),
    'EMIdEmpresaOrigen,EMNumeroEmpleado,EMIdPerfil,EMSalarioBase,EMCorreoElectronico,EMFecha_solicitud_movimiento,EMSeleccionUsuario,EMObservacionesTransferencia',
    CONVERT(VARCHAR(20), @IdEmpresaOrigen) + '|' + @N8 + '|' +
        CONVERT(VARCHAR(20), @IdPerfilDestino) + '|20000.00|qacm.trans.p' + CONVERT(VARCHAR(6), @NumeroPrueba) + '@dummy.mx|' +
        @HoyTexto + '|0|QA TRANSFERENCIA B2 BF3'
),
(
    7, 16, '16_COMPENSACION_EMPLEADO_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'DUMMY EXISTENTE CONTROLADO',
    'Usa el titular dummy ' + @N6 + '. El ID de compensacion se consulta en BD; solo el monto de prueba es dummy.',
    'Agrega o actualiza una compensacion para un titular activo.',
    'Debe existir activo ' + @N6 + '; el ID de compensacion se obtuvo de la BD.',
    @N6, 'Se registra o actualiza una compensacion de 1500.00.',
    'EMIdEmpresa', 'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa),
    'EMNumeroEmpleado,CSIdCompensacion,CSMontoCompensacion,EMTipoCargaComp',
    @N6 + '|' + CONVERT(VARCHAR(20), @IdCompensacion) + '|1500.00|1'
);

/* Todos los valores resueltos y su procedencia. */
SELECT *
FROM
(
    SELECT 1 Orden, 'IdEmpresa' Campo, CONVERT(VARCHAR(500), @IdEmpresa) Valor,
           'PARAMETRO VALIDADO EN ff_Empresa' Origen
    UNION ALL SELECT 2, 'NombreEmpresa', CONVERT(VARCHAR(500), @NombreEmpresa), 'ff_Empresa.EMNombre'
    UNION ALL SELECT 3, 'EMEmpresa', @ClaveEmpresaLegacy, 'ff_Empresa.EMIdEmpresaFlexiForbes'
    UNION ALL SELECT 4, 'ClaveUsuario', @ClaveUsuario, 'PARAMETRO VALIDADO EN ff_Administrador'
    UNION ALL SELECT 5, 'EMUsuarioUMod', CONVERT(VARCHAR(500), @IdUsuario), 'ff_Administrador.ADIdAdministrador'
    UNION ALL SELECT 6, 'IdConfiguracion', CONVERT(VARCHAR(500), @IdConfiguracion), 'ff_Empresa.EMIdConfiguracion'
    UNION ALL SELECT 7, 'IdCorporativo', CONVERT(VARCHAR(500), @IdCorporativo), 'ff_Empresa.EMIdCorporativo'
    UNION ALL SELECT 8, 'IdVigencia', CONVERT(VARCHAR(500), @IdVigencia), 'ff_Vigencia activa para la configuracion'
    UNION ALL SELECT 9, 'IdRolDestino', CONVERT(VARCHAR(500), @IdRolDestino), 'ff_Rol default o rol mas usado'
    UNION ALL SELECT 10, 'IdPerfilDestino', CONVERT(VARCHAR(500), @IdPerfilDestino), 'titular real activo de la empresa'
    UNION ALL SELECT 11, 'Area', @Area, 'titular real activo de la empresa'
    UNION ALL SELECT 12, 'Oficina', @Oficina, 'titular real activo de la empresa'
    UNION ALL SELECT 13, 'CentroCostos', @CentroCostos, 'titular real activo de la empresa'
    UNION ALL SELECT 14, 'Puesto', @Puesto, 'titular real activo de la empresa'
    UNION ALL SELECT 15, 'IdCompensacion', CONVERT(VARCHAR(500), @IdCompensacion), @OrigenCompensacion
    UNION ALL SELECT 16, 'NumeroPrueba', CONVERT(VARCHAR(500), @NumeroPrueba), 'PARAMETRO; IDENTIFICA EL LOTE QA'
    UNION ALL SELECT 17, 'NumerosEmpleado', @N1 + ' ... ' + @N8, 'DUMMY RESERVADO, SOLO DIGITOS'
    UNION ALL SELECT 18, 'EmpleadoRealReferencia', @NumeroEmpleadoReferencia,
        'ff_Empleado.Id=' + CONVERT(VARCHAR(20), @IdEmpleadoReferencia) +
        '; se usa solo para obtener catalogos validos, no se modifica'
    UNION ALL SELECT 19, 'NombreEmpleadoReferencia', @NombreEmpleadoReferencia,
        'ff_Empleado; dato existente mostrado para trazabilidad'
    UNION ALL SELECT 20, 'EMIdSexo entrada/resuelto', @SexoEntrada + ' -> ' + @SexoResuelto,
        'dbo.ff_CMCSexo; equivalencia que aplica el motor B2'
    UNION ALL SELECT 21, 'EMIdParentesco entrada/resuelto', @ParentescoEntrada + ' -> ' + @ParentescoResuelto,
        'dbo.ff_CMCParentesco; equivalencia que aplica el motor B2'
    UNION ALL SELECT 22, 'EMPerfil derivado por SP', CONVERT(VARCHAR(500), @IdPerfilAlta),
        'ff_XCMTitularesAltaCMDeloitte; no se captura en la plantilla 507'
    UNION ALL SELECT 23, 'EMPuesto2', '(vacio)',
        'compatibilidad tecnica BF3; parametro opcional no usado por la logica activa del SP'
    UNION ALL SELECT 24, 'Rol derivado por perfil', CONVERT(VARCHAR(500), @IdRolPerfilAlta),
        'ff_XCMTitularesAlta_Base_BF3; PEIdRolDefault o rol default de empresa'
    UNION ALL SELECT 25, 'Rango edad titular', CONVERT(VARCHAR(20), @EdadMinAlta) + '-' + CONVERT(VARCHAR(20), @EdadMaxAlta),
        'ff_ConfiguracionParentesco; edad dummy=' + CONVERT(VARCHAR(20), @EdadAlta)
) V
ORDER BY Orden;

/* Input contra configuracion activa, plantilla y SP. */
SELECT
    '02_CATALOGO_INPUTS' AS Bloque,
    I.Orden, I.IdOperacion, CO.CONombre AS TipoCarga,
    CO.CODescripcion AS DescripcionConfigurada,
    CE.CEIdOperacionEmpresa, CE.CEIdPlantilla,
    P.PLDescripcion AS Plantilla, CE.CEStoredProc AS StoredProcedure,
    CE.CEStoredProcAtributos, I.Archivo, I.NumeroEmpleadoPrueba,
    I.TipoInsumo, I.ExplicacionInsumo,
    I.ParaQueSirve, I.Precondicion, I.ResultadoEsperado,
    CASE
        WHEN CE.CEIdOperacionEmpresa IS NULL THEN 'FALTA CONFIGURACION ACTIVA PARA LA EMPRESA'
        WHEN OBJECT_ID('dbo.' + CE.CEStoredProc, 'P') IS NULL THEN 'FALTA STORED PROCEDURE'
        WHEN P.PLIdPlantilla IS NULL THEN 'FALTA PLANTILLA'
        ELSE 'OK'
    END AS ResultadoConfiguracion
FROM @Inputs I
LEFT JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
OUTER APPLY
(
    SELECT TOP (1) X.*
    FROM dbo.ff_CargaMasivaOperacionEmpresa X
    WHERE X.CEIdEmpresa = @IdEmpresa
      AND X.CEIdOperacion = I.IdOperacion
      AND X.CEIdEstatus = 1
    ORDER BY X.CEIdOperacionEmpresa DESC
) CE
LEFT JOIN dbo.ff_Plantilla P
    ON P.PLIdPlantilla = CE.CEIdPlantilla AND P.PLIdEstatus = 1
ORDER BY I.Orden;

/* Texto final con el mismo contrato de campos comunes usado por B2. */
SELECT
    '03_CONTENIDO_TXT_LISTO' AS Bloque,
    I.Orden, I.IdOperacion, CO.CONombre AS TipoCarga,
    I.Archivo, I.TipoInsumo, I.NumeroEmpleadoPrueba,
    CAST('@commonFields:' + @CRLF + I.LineasComunes + @CRLF + @CRLF +
         '@fieldNames:' + I.CamposRegistro + @CRLF +
         '@data:' + @CRLF + I.DatosRegistro AS VARCHAR(MAX)) AS ContenidoTXT
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
ORDER BY I.Orden;

/*
  Alternativa segura para SSMS: cada linea fisica aparece en una fila. El
  backend corregido reconoce @fieldNames como fin de los campos comunes aunque
  el editor elimine la linea vacia.
*/
SELECT
    '03B_LINEAS_TXT_SIN_SALTOS_OCULTOS' AS Bloque,
    I.Orden, I.IdOperacion, CO.CONombre AS TipoCarga, I.Archivo,
    L.LineaNumero, L.LineaTXT
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
CROSS APPLY
(
    VALUES
      (1, CAST('@commonFields:' AS VARCHAR(MAX))),
      (2, CAST(CASE WHEN CHARINDEX(@CRLF, I.LineasComunes) > 0
                    THEN LEFT(I.LineasComunes, CHARINDEX(@CRLF, I.LineasComunes) - 1)
                    ELSE I.LineasComunes END AS VARCHAR(MAX))),
      (3, CAST(CASE WHEN CHARINDEX(@CRLF, I.LineasComunes) > 0
                    THEN SUBSTRING(I.LineasComunes, CHARINDEX(@CRLF, I.LineasComunes) + 2, LEN(I.LineasComunes))
                    ELSE NULL END AS VARCHAR(MAX))),
      (4, CAST('@fieldNames:' + I.CamposRegistro AS VARCHAR(MAX))),
      (5, CAST('@data:' AS VARCHAR(MAX))),
      (6, CAST(I.DatosRegistro AS VARCHAR(MAX)))
) L(LineaNumero, LineaTXT)
WHERE L.LineaTXT IS NOT NULL
ORDER BY I.Orden, L.LineaNumero;

/* Campos y orden reales configurados en cada plantilla. */
SELECT
    '04_CAMPOS_REALES_PLANTILLA' AS Bloque,
    I.Orden, I.IdOperacion, CO.CONombre AS TipoCarga,
    CE.CEIdPlantilla, CP.CPOrden AS OrdenCampo,
    RTRIM(C.CANombreCampo) AS Campo, CP.CPRequerido AS Requerido,
    C.CATipoDato AS TipoDato, C.CALongitud AS Longitud
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
INNER JOIN dbo.ff_CargaMasivaOperacionEmpresa CE
    ON CE.CEIdEmpresa = @IdEmpresa
   AND CE.CEIdOperacion = I.IdOperacion
   AND CE.CEIdEstatus = 1
INNER JOIN dbo.ff_ConfiguracionPlantilla CP
    ON CP.PLIdPlantilla = CE.CEIdPlantilla AND CP.CPIdEstatus = 1
INNER JOIN dbo.ff_Campo C
    ON C.CAIdCampo = CP.CAIdCampo AND C.CAIdEstatus = 1
ORDER BY I.Orden, CP.CPOrden, CP.CPIdConfiguracionPlantilla;

/* Reglas observadas en las plantillas, equivalencias y SP configurados. */
SELECT
    '04B_VALIDACIONES_POR_TIPO_DE_CARGA' AS Bloque,
    V.Orden, V.IdOperacion, CO.CONombre AS TipoCarga,
    V.Validacion, V.InsumoGenerado, V.FuenteValidacion
FROM
(
    VALUES
    (1, 1, 'La empresa debe existir y estar activa.', CONVERT(VARCHAR(500), @IdEmpresa), 'ff_Empresa / ff_XCMDependientesAlta_Base'),
    (2, 1, 'El numero debe identificar un titular activo de esa empresa.', @N1, 'ff_Empleado: EMIdEstatus=1, EMIdParentesco=1'),
    (3, 1, 'Sexo y parentesco deben tener equivalencia B2.', @SexoEntrada + '->' + @SexoResuelto + '; ' + @ParentescoEntrada + '->' + @ParentescoResuelto, 'ff_CMCSexo y ff_CMCParentesco'),
    (4, 1, 'La edad debe estar permitida por la configuracion del parentesco y no debe existir el mismo nombre/fecha.', 'Dependiente QA nacido 15/06/2015', 'ff_XCMDependientesAlta_Base'),
    (5, 1, 'La fecha de nacimiento no puede ser posterior a la fecha de alta.', '15/06/2015 <= ' + @HoyTexto, 'ff_XCMDependientesAlta_Base'),

    (6, 2, 'EMEmpresa debe resolver una empresa activa.', @ClaveEmpresaLegacy, 'ff_Empresa.EMIdEmpresaFlexiForbes'),
    (7, 2, 'El numero nuevo no debe tener un titular activo previo en la empresa/corporativo aplicable.', @N2, 'ff_XCMTitularesAltaCMDeloitte'),
    (8, 2, 'Sexo debe tener equivalencia; CECO, area y oficina deben existir para la empresa.', 'M; CECO=' + @CentroCostos + '; area=' + @Area + '; oficina=' + @Oficina, 'ff_CMCSexo y ff_TablaEncabezadoDetalle'),
    (9, 2, 'Los campos requeridos de plantilla deben venir aun cuando los opcionales esten vacios.', '32 campos de usuario: 1 comun y 31 por registro', 'ff_CPlantillaCampos / plantilla 507'),
    (23, 2, 'BF3 completa los parametros tecnicos no expuestos por la plantilla.', 'EMPuesto2=vacio; EMPerfil lo deriva el SP como ' + CONVERT(VARCHAR(20), @IdPerfilAlta), 'CargaMasivaB2Service / ff_XCMTitularesAltaCMDeloitte'),
    (24, 2, 'El perfil derivado debe ser no administrador y resolver un rol predeterminado valido.', 'Perfil=' + CONVERT(VARCHAR(20), @IdPerfilAlta) + '; rol=' + CONVERT(VARCHAR(20), @IdRolPerfilAlta), 'ff_XCMTitularesAlta_Base_BF3 / ff_Perfil / ff_Rol'),
    (25, 2, 'La edad y la combinacion nombre/fecha deben ser validas y no estar duplicadas.', @NombreAlta + ' ' + @ApellidoAlta + '; edad=' + CONVERT(VARCHAR(20), @EdadAlta), 'ff_ConfiguracionParentesco / ff_Empleado'),

    (10, 5, 'EMEmpresa debe resolver empresa/corporativo y el empleado debe existir.', @ClaveEmpresaLegacy + ' / ' + @N7, 'ff_Empresa y ff_Empleado'),
    (11, 5, 'Periodo, CIS y monto deben localizar una cadena conciliable no duplicada.', @Periodo + ' / ' + @RegistroAutos + ' / 100.00', 'ff_XCMDescuentosCMAutos y ff_XCMDescuentosAutosBase'),
    (12, 5, 'La solicitud, estado de cuenta, desglose y calendario deben estar activos y relacionados.', 'Cadena QA preparada para ' + @N7, 'fb_SolicitudAutos, fb_EdoCuentaAutos, fb_EdoCuentaDesglose, fb_CalendarioIngresoNomina'),

    (13, 13, 'El numero actual debe pertenecer a un titular activo de la empresa.', @N3, 'ff_Empleado / ff_ActualizaNumEmpleadoTitular'),
    (14, 13, 'El numero nuevo no debe existir como titular activo ni dado de baja.', @N4, 'ff_Empleado / ff_ActualizaNumEmpleadoTitular'),

    (15, 14, 'No debe existir un titular activo con el numero indicado.', @N5, 'bf_ReactivacionEmpleadosTitular'),
    (16, 14, 'Debe existir el titular inactivo con fecha de baja en la misma empresa.', @N5, 'ff_Empleado: EMIdEstatus=2 y EMFechaBaja no nula'),

    (17, 15, 'Empresa origen y destino deben existir, estar activas y ser distintas.', CONVERT(VARCHAR(20), @IdEmpresaOrigen) + ' -> ' + CONVERT(VARCHAR(20), @IdEmpresa), 'ff_Empresa'),
    (18, 15, 'El titular debe estar activo en origen y no existir en destino.', @N8, 'ff_Empleado / ff_transferenciaMasivaEmpleado'),
    (19, 15, 'El perfil destino debe existir y la transferencia valida solicitudes/planes relacionados.', CONVERT(VARCHAR(20), @IdPerfilDestino), 'ff_Perfil, ff_Solicitud y ff_PlanOpcionSeleccion'),

    (20, 16, 'El titular debe existir activo en la empresa.', @N6, 'ff_Empleado / ff_CargaMasivaCompensacionEmpleado'),
    (21, 16, 'Tipo 1 inserta/actualiza; tipo 2 solo puede dar de baja una compensacion existente.', 'Tipo=1; compensacion=' + CONVERT(VARCHAR(20), @IdCompensacion), 'ff_CargaMasivaCompensacionEmpleado'),
    (22, 16, 'El monto debe convertirse a MONEY.', '1500.00', 'Plantilla 12460 / tipo M')
) V(Orden, IdOperacion, Validacion, InsumoGenerado, FuenteValidacion)
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = V.IdOperacion
ORDER BY V.Orden;

/* Verifica cantidad y cobertura exacta contra la plantilla activa de la BD. */
SELECT
    '05_VALIDACION_ESTRUCTURA_TXT' AS Bloque,
    I.Orden,
    I.IdOperacion,
    CO.CONombre AS TipoCarga,
    2 + LEN(I.CamposComunes) - LEN(REPLACE(I.CamposComunes, ',', ''))
      + LEN(I.CamposRegistro) - LEN(REPLACE(I.CamposRegistro, ',', '')) AS CamposTXT,
    1 + LEN(I.DatosRegistro) - LEN(REPLACE(I.DatosRegistro, '|', '')) AS ValoresTXT,
    1 + LEN(I.CamposRegistro) - LEN(REPLACE(I.CamposRegistro, ',', '')) AS CamposPorRegistro,
    X.CamposPlantilla,
    X.EncabezadoPlantilla,
    CASE
      WHEN 1 + LEN(I.CamposRegistro) - LEN(REPLACE(I.CamposRegistro, ',', ''))
         = 1 + LEN(I.DatosRegistro) - LEN(REPLACE(I.DatosRegistro, '|', ''))
       AND 2 + LEN(I.CamposComunes) - LEN(REPLACE(I.CamposComunes, ',', ''))
             + LEN(I.CamposRegistro) - LEN(REPLACE(I.CamposRegistro, ',', ''))
         = X.CamposPlantilla
       AND NOT EXISTS
       (
           SELECT 1
           FROM dbo.ff_CargaMasivaOperacionEmpresa CE3
           INNER JOIN dbo.ff_ConfiguracionPlantilla CP3
               ON CP3.PLIdPlantilla = CE3.CEIdPlantilla AND CP3.CPIdEstatus = 1
           INNER JOIN dbo.ff_Campo C3
               ON C3.CAIdCampo = CP3.CAIdCampo AND C3.CAIdEstatus = 1
           WHERE CE3.CEIdEmpresa = @IdEmpresa
             AND CE3.CEIdOperacion = I.IdOperacion
             AND CE3.CEIdEstatus = 1
             AND ',' + UPPER(I.CamposComunes + ',' + I.CamposRegistro) + ','
                 NOT LIKE '%,' + UPPER(RTRIM(C3.CANombreCampo)) + ',%'
       )
      THEN 'OK'
      ELSE 'REVISAR CAMPOS COMUNES/REGISTRO O CANTIDAD DE VALORES'
    END AS Resultado
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
OUTER APPLY
(
    SELECT
        COUNT(*) AS CamposPlantilla,
        STUFF
        (
            (
                SELECT ',' + RTRIM(C2.CANombreCampo)
                FROM dbo.ff_CargaMasivaOperacionEmpresa CE2
                INNER JOIN dbo.ff_ConfiguracionPlantilla CP2
                    ON CP2.PLIdPlantilla = CE2.CEIdPlantilla
                   AND CP2.CPIdEstatus = 1
                INNER JOIN dbo.ff_Campo C2
                    ON C2.CAIdCampo = CP2.CAIdCampo
                   AND C2.CAIdEstatus = 1
                WHERE CE2.CEIdEmpresa = @IdEmpresa
                  AND CE2.CEIdOperacion = I.IdOperacion
                  AND CE2.CEIdEstatus = 1
                ORDER BY CP2.CPOrden, CP2.CPIdConfiguracionPlantilla
                FOR XML PATH(''), TYPE
            ).value('.', 'VARCHAR(MAX)'), 1, 1, ''
        ) AS EncabezadoPlantilla
    FROM dbo.ff_CargaMasivaOperacionEmpresa CE
    INNER JOIN dbo.ff_ConfiguracionPlantilla CP
        ON CP.PLIdPlantilla = CE.CEIdPlantilla AND CP.CPIdEstatus = 1
    INNER JOIN dbo.ff_Campo C
        ON C.CAIdCampo = CP.CAIdCampo AND C.CAIdEstatus = 1
    WHERE CE.CEIdEmpresa = @IdEmpresa
      AND CE.CEIdOperacion = I.IdOperacion
      AND CE.CEIdEstatus = 1
) X
ORDER BY I.Orden;

/*
  Contrato tecnico de cada SP contra su plantilla. Esta revision detecta el
  caso que produjo "Required input parameter 'EMPuesto2' is missing" antes de
  ejecutar una carga. Los parametros marcados CONTEXTO_SEGURO,
  COMPATIBILIDAD_BACKEND o ADAPTADOR_TRANSFERENCIA no deben agregarse al TXT.
*/
IF EXISTS
(
    SELECT 1
    FROM @Inputs I
    INNER JOIN dbo.ff_CargaMasivaOperacionEmpresa CE
        ON CE.CEIdEmpresa = @IdEmpresa
       AND CE.CEIdOperacion = I.IdOperacion
       AND CE.CEIdEstatus = 1
    WHERE OBJECT_ID('dbo.' + LTRIM(RTRIM(CE.CEStoredProc)), 'P') IS NULL
)
    THROW 51926, 'Una operacion activa apunta a un stored procedure inexistente.', 1;

IF EXISTS
(
    SELECT 1
    FROM @Inputs I
    INNER JOIN dbo.ff_CargaMasivaOperacionEmpresa CE
        ON CE.CEIdEmpresa = @IdEmpresa
       AND CE.CEIdOperacion = I.IdOperacion
       AND CE.CEIdEstatus = 1
    INNER JOIN sys.parameters P
        ON P.object_id = OBJECT_ID('dbo.' + LTRIM(RTRIM(CE.CEStoredProc)))
       AND P.is_output = 0
    WHERE NOT EXISTS
          (
              SELECT 1
              FROM dbo.ff_ConfiguracionPlantilla CP
              INNER JOIN dbo.ff_Campo C ON C.CAIdCampo = CP.CAIdCampo
              WHERE CP.PLIdPlantilla = CE.CEIdPlantilla
                AND CP.CPIdEstatus = 1
                AND CP.CPHabilitado = 1
                AND C.CAIdEstatus = 1
                AND UPPER(RTRIM(C.CANombreCampo)) = UPPER(STUFF(P.name, 1, 1, ''))
          )
      AND UPPER(STUFF(P.name, 1, 1, '')) NOT IN ('EMIDEMPRESA', 'EMUSUARIOUMOD')
      AND NOT
          (I.IdOperacion = 2
           AND UPPER(STUFF(P.name, 1, 1, '')) IN ('EMPUESTO2', 'EMPERFIL'))
      AND NOT
          (I.IdOperacion = 15
           AND UPPER(STUFF(P.name, 1, 1, '')) = 'PARAMETROSCARGA')
)
    THROW 51927, 'Hay parametros del SP que no cubre la plantilla ni el backend BF3.', 1;

SELECT
    '05A_CONTRATO_PLANTILLA_SP' AS Bloque,
    I.Orden,
    I.IdOperacion,
    CE.CEIdPlantilla,
    CE.CEStoredProc,
    P.parameter_id AS OrdenParametro,
    STUFF(P.name, 1, 1, '') AS ParametroSP,
    TYPE_NAME(P.user_type_id) AS TipoSQL,
    CASE
      WHEN EXISTS
      (
          SELECT 1
          FROM dbo.ff_ConfiguracionPlantilla CP
          INNER JOIN dbo.ff_Campo C ON C.CAIdCampo = CP.CAIdCampo
          WHERE CP.PLIdPlantilla = CE.CEIdPlantilla
            AND CP.CPIdEstatus = 1
            AND CP.CPHabilitado = 1
            AND C.CAIdEstatus = 1
            AND UPPER(RTRIM(C.CANombreCampo)) = UPPER(STUFF(P.name, 1, 1, ''))
      ) THEN 'CAMPO_PLANTILLA_TXT'
      WHEN UPPER(STUFF(P.name, 1, 1, '')) IN ('EMIDEMPRESA', 'EMUSUARIOUMOD')
        THEN 'CONTEXTO_SEGURO_BF3'
      WHEN I.IdOperacion = 2
       AND UPPER(STUFF(P.name, 1, 1, '')) IN ('EMPUESTO2', 'EMPERFIL')
        THEN 'COMPATIBILIDAD_BACKEND'
      WHEN I.IdOperacion = 15
       AND UPPER(STUFF(P.name, 1, 1, '')) = 'PARAMETROSCARGA'
        THEN 'ADAPTADOR_TRANSFERENCIA'
      ELSE 'FALTA_REVISAR'
    END AS OrigenValor,
    CASE
      WHEN I.IdOperacion = 2 AND UPPER(STUFF(P.name, 1, 1, '')) = 'EMPUESTO2'
        THEN 'Opcional; no participa en la logica activa del SP.'
      WHEN I.IdOperacion = 2 AND UPPER(STUFF(P.name, 1, 1, '')) = 'EMPERFIL'
        THEN 'El SP lo calcula por empresa y puesto; BF3 no acepta que el usuario lo imponga.'
      WHEN UPPER(STUFF(P.name, 1, 1, '')) = 'EMIDEMPRESA'
        THEN 'Se fuerza con la empresa autorizada de la sesion.'
      WHEN UPPER(STUFF(P.name, 1, 1, '')) = 'EMUSUARIOUMOD'
        THEN 'Se fuerza con el usuario autenticado.'
      ELSE 'Valor cubierto por la plantilla o por el adaptador indicado.'
    END AS Explicacion
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacionEmpresa CE
    ON CE.CEIdEmpresa = @IdEmpresa
   AND CE.CEIdOperacion = I.IdOperacion
   AND CE.CEIdEstatus = 1
INNER JOIN sys.parameters P
    ON P.object_id = OBJECT_ID('dbo.' + LTRIM(RTRIM(CE.CEStoredProc)))
WHERE P.is_output = 0
ORDER BY I.Orden, P.parameter_id;

/*
  Empleado existente del que se tomaron valores de catalogo. No se utiliza
  como sujeto de una operacion destructiva; queda documentado para demostrar
  que perfil, rol, area, oficina y CECO si provienen de datos que ya pasan.
*/
SELECT
    '05B_EXISTENTE_USADO_COMO_REFERENCIA' AS Bloque,
    E.Id, E.EMIdEmpresa, E.EMNumeroEmpleado,
    LTRIM(RTRIM(ISNULL(E.EMNombre1, '') + ' ' + ISNULL(E.EMNombre2, '') + ' ' +
        ISNULL(E.EMApellidoPaterno, '') + ' ' + ISNULL(E.EMApellidoMaterno, ''))) AS Empleado,
    E.EMIdPerfil, E.EMIdRol, E.EMArea, E.EMOficina, E.EMIdCentroCostos,
    'SOLO FUENTE DE VALORES VALIDOS; NO SE MODIFICA EN LAS SIETE PRUEBAS' AS Uso
FROM dbo.ff_Empleado E
WHERE E.Id = @IdEmpleadoReferencia;

/* Estado de los dummies antes de probar. */
SELECT
    '06_ESTADO_PRECONDICIONES' AS Bloque,
    I.IdOperacion, I.NumeroEmpleadoPrueba, I.Precondicion,
    CASE I.IdOperacion
      WHEN 1 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N1 AND E.EMIdEstatus = 1
           AND E.EMIdParentesco = 1) THEN 'LISTO' ELSE 'FALTA PREPARAR' END
      WHEN 2 THEN CASE WHEN NOT EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N2) THEN 'LISTO PARA ALTA' ELSE 'YA EXISTE: RESTABLECER PRUEBA' END
      WHEN 5 THEN CASE WHEN EXISTS
          (SELECT 1
           FROM dbo.ff_Empleado E
           INNER JOIN dbo.fb_SolicitudAutos S
               ON S.SAIdEmpleadoTitular = E.Id
              AND S.SANumeroRegistroAseguradora = @RegistroAutos
           INNER JOIN dbo.fb_EdoCuentaAutos EC ON EC.ECIdSolicitud = S.SAIdSolicitudAutos
           INNER JOIN dbo.fb_EdoCuentaDesglose D ON D.ECIdEdoCuentaAutos = EC.ECIdEdoCuentaAutos
           INNER JOIN dbo.fb_CalendarioIngresoNomina CN
               ON CN.CNIdCalendarioIngresoNomina = D.ECIdCalendarioIngresoNomina
              AND CN.CNQuincenaAnioCalendario = @Periodo
           WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N7)
          THEN 'LISTO' ELSE 'FALTA PREPARAR CADENA AUTOS' END
      WHEN 13 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N3) AND NOT EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N4) THEN 'LISTO' ELSE 'FALTA PREPARAR/RESTABLECER' END
      WHEN 14 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N5 AND E.EMIdEstatus <> 1) THEN 'LISTO' ELSE 'FALTA PREPARAR' END
      WHEN 15 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresaOrigen
           AND E.EMNumeroEmpleado = @N8 AND E.EMIdEstatus = 1) THEN 'LISTO' ELSE 'FALTA PREPARAR' END
      WHEN 16 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N6 AND E.EMIdEstatus = 1) THEN 'LISTO' ELSE 'FALTA PREPARAR' END
    END AS Estado
FROM @Inputs I
ORDER BY I.Orden;

/*
  Consultas de candidatos existentes. Son informativas: los TXT recomendados
  siguen usando dummies para no cambiar datos reales. Si no devuelven filas,
  no existe un candidato real con la precondicion basica en este fragmento.
*/
SELECT TOP (10)
    '06B_CANDIDATOS_EXISTENTES_ALTA_DEPENDIENTE' AS Bloque,
    E.Id, E.EMNumeroEmpleado, E.EMIdPerfil, E.EMIdRol, E.EMIdEstatus,
    E.EMNombre1, E.EMApellidoPaterno,
    'CUMPLE PRECONDICION BASICA: TITULAR ACTIVO. NO SE USA AUTOMATICAMENTE.' AS Resultado
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdEstatus = 1
  AND E.EMIdParentesco = 1
  AND E.EMIdTitular = 1
  AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
ORDER BY E.Id DESC;

SELECT TOP (10)
    '06C_CANDIDATOS_EXISTENTES_REACTIVACION' AS Bloque,
    E.Id, E.EMNumeroEmpleado, E.EMFechaBaja, E.EMIdPerfil, E.EMIdRol,
    E.EMNombre1, E.EMApellidoPaterno,
    'CUMPLE: TITULAR INACTIVO SIN HOMONIMO ACTIVO. USARLO CAMBIARIA DATOS REALES.' AS Resultado
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdEstatus = 2
  AND E.EMIdParentesco = 1
  AND E.EMIdTitular = 1
  AND E.EMFechaBaja IS NOT NULL
  AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ff_Empleado A
      WHERE A.EMIdEmpresa = E.EMIdEmpresa
        AND A.EMNumeroEmpleado = E.EMNumeroEmpleado
        AND A.EMIdParentesco = 1
        AND A.EMIdEstatus = 1
  )
ORDER BY E.EMFechaBaja DESC, E.Id DESC;

SELECT TOP (10)
    '06D_CANDIDATOS_EXISTENTES_TRANSFERENCIA' AS Bloque,
    E.Id, E.EMIdEmpresa AS EmpresaOrigen, @IdEmpresa AS EmpresaDestino,
    E.EMNumeroEmpleado, E.EMIdPerfil, E.EMIdRol,
    'CUMPLE: ACTIVO EN ORIGEN Y NO EXISTE EN DESTINO. USARLO MOVERIA AL EMPLEADO REAL.' AS Resultado
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa = @IdEmpresaOrigen
  AND E.EMIdEstatus = 1
  AND E.EMIdParentesco = 1
  AND E.EMIdTitular = 1
  AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ff_Empleado D
      WHERE D.EMIdEmpresa = @IdEmpresa
        AND D.EMNumeroEmpleado = E.EMNumeroEmpleado
        AND D.EMIdParentesco = 1
  )
ORDER BY E.Id DESC;

SELECT TOP (10)
    '06E_CANDIDATOS_EXISTENTES_COMPENSACION' AS Bloque,
    E.Id, E.EMNumeroEmpleado, E.EMIdPerfil, E.EMIdRol,
    @IdCompensacion AS IdCompensacionAplicable,
    'CUMPLE: TITULAR ACTIVO. NO SE USA PARA EVITAR MODIFICAR SU COMPENSACION REAL.' AS Resultado
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdEstatus = 1
  AND E.EMIdParentesco = 1
  AND E.EMIdTitular = 1
  AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
ORDER BY E.Id DESC;

SELECT TOP (10)
    '06F_CADENAS_APLICABLES_CONCILIACION_AUTOS' AS Bloque,
    E.Id AS IdEmpleado, E.EMNumeroEmpleado,
    CN.CNQuincenaAnioCalendario AS Periodo,
    S.SANumeroRegistroAseguradora AS CIS,
    D.ECPrimaTotalRecibo AS MontoRecibo,
    D.ECConciliado AS Conciliado,
    D.ECEstatus,
    CASE WHEN E.EMApellidoPaterno = 'PRUEBA'
         THEN 'CADENA DUMMY PREPARADA' ELSE 'CADENA EXISTENTE; NO USAR SIN REVISAR IMPACTO' END AS Resultado
FROM dbo.ff_Empleado E
INNER JOIN dbo.fb_SolicitudAutos S ON S.SAIdEmpleadoTitular = E.Id
INNER JOIN dbo.fb_EdoCuentaAutos EC ON EC.ECIdSolicitud = S.SAIdSolicitudAutos
INNER JOIN dbo.fb_EdoCuentaDesglose D ON D.ECIdEdoCuentaAutos = EC.ECIdEdoCuentaAutos
INNER JOIN dbo.fb_CalendarioIngresoNomina CN
    ON CN.CNIdCalendarioIngresoNomina = D.ECIdCalendarioIngresoNomina
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdParentesco = 1
  AND E.EMIdEstatus = 1
  AND ISNULL(D.ECEstatus, 1) = 1
  AND ISNULL(D.ECConciliado, 0) = 0
ORDER BY CASE WHEN E.EMNumeroEmpleado = @N7 THEN 0 ELSE 1 END,
         D.ECIdEdoCuentaDesglose DESC;

/* Operaciones futuras/extra que aun no tengan un input preparado. */
SELECT
    '07_OPERACIONES_ACTIVAS_SIN_INPUT' AS Bloque,
    CE.CEIdOperacion, CO.CONombre AS TipoCarga,
    CE.CEIdPlantilla, CE.CEStoredProc
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = CE.CEIdOperacion
WHERE CE.CEIdEmpresa = @IdEmpresa
  AND CE.CEIdEstatus = 1
  AND NOT EXISTS (SELECT 1 FROM @Inputs I WHERE I.IdOperacion = CE.CEIdOperacion)
ORDER BY CE.CEIdOperacion;

SELECT
    '08_RESUMEN' AS Bloque,
    @IdEmpresa AS IdEmpresa, @NombreEmpresa AS Empresa,
    @NumeroPrueba AS NumeroPrueba,
    @ClaveUsuario AS Usuario, @IdUsuario AS IdUsuarioAuditoria,
    @ClaveEmpresaLegacy AS EMEmpresa,
    (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
     WHERE CEIdEmpresa = @IdEmpresa AND CEIdEstatus = 1) AS OperacionesActivasBD,
    (SELECT COUNT(*) FROM @Inputs) AS InputsPreparados,
    CASE WHEN NOT EXISTS
    (
        SELECT 1 FROM dbo.ff_CargaMasivaOperacionEmpresa CE
        WHERE CE.CEIdEmpresa = @IdEmpresa AND CE.CEIdEstatus = 1
          AND NOT EXISTS (SELECT 1 FROM @Inputs I WHERE I.IdOperacion = CE.CEIdOperacion)
    ) THEN 'OK: TODAS LAS OPERACIONES ACTIVAS TIENEN INPUT TXT'
      ELSE 'REVISAR: EXISTEN OPERACIONES ACTIVAS SIN INPUT' END AS Resultado;
GO
