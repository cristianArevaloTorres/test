package com.lockton.WSBeFlex.DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.lockton.WSBeFlex.POJO.FfEmpresa;
import com.lockton.WSBeFlex.POJO.Especiales.ConfiguracionNotificacionEmpresa;
import com.lockton.WSBeFlex.POJO.Especiales.EmpresaImagen;
import com.lockton.WSBeFlex.POJO.Especiales.FfEmpresas;
import com.lockton.WSBeFlex.POJO.Especiales.FfGetCorreosGrupos;
import com.lockton.WSBeFlex.POJO.Especiales.InformacionEmpleado;
import com.lockton.WSBeFlex.POJO.Especiales.PlantillaConfiguracionNotificacionEmpresa;
import com.lockton.WSBeFlex.POJO.Especiales.PrefijoEmpresa;
import org.springframework.util.LinkedCaseInsensitiveMap;

import java.util.Collection;
import java.util.stream.Collectors;
import java.util.Collections;

/**
 * <p>
 * Esta clase implementa los métodos definidos en la interface
 * {@link com.lockton.WSBeFlex.DAO.FfEmpresaDAO} 
 * </p>
 * <p>
 * La anotacion @Repository nos
 * indica que es un Data Access Object, por lo tanto, es en esta clase donde se
 * realizan las sentencias CRUD. 
 * </p>
 * <p>
 * Se utiliza un objeto de la clase JdbcTemplate
 * que ejecuta el flujo de trabajo central de JDBC, dejando el código de la
 * aplicación para proporcionar SQL y extraer resultados. Esta clase ejecuta
 * consultas o actualizaciones de SQL, inicia la iteración sobre ResultSets y
 * captura las excepciones JDBC.
 * 
 * @see <a href=
 *      "https://docs.spring.io/spring/docs/current/javadoc-api/org/springframework/jdbc/core/JdbcTemplate.html">Class
 *      JdbcTemplate</a>
 * </p>
 * 
 * @author Andrea Hernández / BigPink
 * @since 1.0
 */
@Repository
public class JDBCFfEmpresa implements FfEmpresaDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<FfEmpresas> consultarPorIdCorporativo(int idCorporativo) {
		return jdbcTemplate.query(
				"select * from ff_empresa where EMidCorporativo = ? and EMidEstatus = 1 and EMidEmpresa <> EMidCorporativo order by EMOrden",
				new BeanPropertyRowMapper<FfEmpresas>(FfEmpresas.class), idCorporativo);
	}

	@Override
	public String buscarCSSEmpresa(int id) {
		String archivo = jdbcTemplate.queryForObject(
				"select EMidEmpresa from dbo.ff_Empresa where EMidEmpresa = ? and EMIdEstatus = 1", String.class, id);
		return archivo;
	}

	@Override
	public FfEmpresa buscar(int id) throws DataAccessException {
		FfEmpresa ff_e = jdbcTemplate.queryForObject(
				"select * from dbo.ff_Empresa where EMidEmpresa = ? and EMidEstatus = 1",
				new BeanPropertyRowMapper<FfEmpresa>(FfEmpresa.class), id);
		return ff_e;
	}        

	@Override
	public List<FfEmpresa> buscar(List<Integer> ids) {
		if (ids == null || ids.isEmpty()) {				
			return Collections.emptyList();
		}

		String param = ids.stream()
							.map((t) -> t.toString())
							.collect(Collectors.joining(", "));
		String sql = "select * from dbo.ff_Empresa where EMidEmpresa IN (?) and EMidEstatus = 1 ORDER BY EMClaveAcceso";
		sql = sql.replace("?", param);
		List<FfEmpresa> ff_e = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(FfEmpresa.class));

		return ff_e;
	}

	@Override
	public List<FfEmpresa> consultar() throws DataAccessException {
		List<FfEmpresa> lff_e = jdbcTemplate.query("select * from dbo.ff_Empresa",
				new BeanPropertyRowMapper<FfEmpresa>(FfEmpresa.class));
		return lff_e;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpresaImagen> empresaImagen(int idEmpresa) {
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetEmpresaImagen")
				.returningResultSet("rs", new BeanPropertyRowMapper<EmpresaImagen>(EmpresaImagen.class));
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("EIIdEmpresa", idEmpresa);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);

		return (List<EmpresaImagen>) simpleJdbcCallResult.get("rs");

	}

	@Override
	public ConfiguracionNotificacionEmpresa obtenerConfiguracionNotificacionEmpresa(int idEmpresa,
			int idTipoNotificacion, int idEmpleado) {
		ArrayList<InformacionEmpleado> l_info_empleado = new ArrayList<InformacionEmpleado>();
		InformacionEmpleado info_empleado = null;

		ArrayList<FfGetCorreosGrupos> l_correos = new ArrayList<FfGetCorreosGrupos>();
		FfGetCorreosGrupos correos = null;

		ArrayList<PlantillaConfiguracionNotificacionEmpresa> l_plantilla = new ArrayList<PlantillaConfiguracionNotificacionEmpresa>();
		PlantillaConfiguracionNotificacionEmpresa plantilla = null;

		ConfiguracionNotificacionEmpresa configuracionNotifiEmpresa = null;
                String correoElectronicoAdm = "";
                String correoEmpleado = "";
                boolean firsTime = false;
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("bf_ObtenerConfiguracionNotificacionEmpresa");

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdEmpresa", idEmpresa);
		inParamMap.put("IdTipoNotificacion", idTipoNotificacion);
		inParamMap.put("IdEmpleado", idEmpleado);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());

		if (!listSP.isEmpty()) {
			for (int i = 0; i < listSP.size(); i++) {
				if (listSP.get(i).getClass().getName() != "java.lang.Integer") {
					@SuppressWarnings("unchecked")
					List<Object> list_valuesPAValidos = (List<Object>) listSP.get(i);
					if (!list_valuesPAValidos.isEmpty()) {
						for (int j = 0; j < list_valuesPAValidos.size(); j++) {
							configuracionNotifiEmpresa = new ConfiguracionNotificacionEmpresa();
							@SuppressWarnings("unchecked")
							Map<String, Object> mapeo = (Map<String, Object>) list_valuesPAValidos.get(j);

							// informacionEmpleado
							if (mapeo.containsKey("IdConfiguracionNotificacionEmpresa")) {
								info_empleado = new InformacionEmpleado();
								info_empleado.setIdConfiguracionNotificacionEmpresa(
										(Integer) mapeo.get("IdConfiguracionNotificacionEmpresa"));
								info_empleado.setNombreCompleto((String) mapeo.get("EMNombreCompletoEmpleado"));
								info_empleado.setNombreEmpresa((String) mapeo.get("NombreEmpresa"));
								l_info_empleado.add(info_empleado);
							}

							// informacionEmpleado
							if (mapeo.containsKey("GCCorreoCopia")) {
								correos = new FfGetCorreosGrupos();
								correos.setGcCorreoCopia((Boolean) mapeo.get("GCCorreoCopia"));
								correos.setGcCorreoCopiaOculta((Boolean) mapeo.get("GCCorreoCopiaOculta"));
								correos.setGcCorreoVisible((Boolean) mapeo.get("GCCorreoVisible"));
								correos.setAdCorreoElectronico((String) mapeo.get("ADCorreoElectronico"));
								l_correos.add(correos);
							}

							// informacionEmpleado
							if (mapeo.containsKey("Sujeto")) {
								plantilla = new PlantillaConfiguracionNotificacionEmpresa();
								plantilla.setPlantilla((String) mapeo.get("Plantilla"));
								plantilla.setSujeto((String) mapeo.get("Sujeto"));
								plantilla.setContenido((String) mapeo.get("Contenido"));
								l_plantilla.add(plantilla);
							}
                                                        
                                                        if (mapeo.containsKey("ADCorreoElectronico" ) && firsTime == false) {
								
                                                            correoElectronicoAdm = (String)mapeo.get("ADCorreoElectronico");
                                                            firsTime = true;
							}
                                                        
                                                     if (mapeo.containsKey("EMCorreoElectronico")) {
								
                                                           // configuracionNotifiEmpresa.setEmCorreoElectronico((String) mapeo.get("EMCorreoElectronico"));
                                                            correoEmpleado = (String) mapeo.get("EMCorreoElectronico");
							}

							configuracionNotifiEmpresa.setCorreosGrupo(l_correos);
							configuracionNotifiEmpresa.setInformacionEmpleado(l_info_empleado);
							configuracionNotifiEmpresa.setPlantilla(l_plantilla);
							

						}
					}
				}
			}

		}
                 configuracionNotifiEmpresa.setEmCorreoElectronico(correoEmpleado);
                configuracionNotifiEmpresa.setAdmCorreoElectronico(correoElectronicoAdm);
                
		return configuracionNotifiEmpresa;
	}

	@Override
	public PrefijoEmpresa consultarPrefijoEmpresa(int idEmpresa) {
		PrefijoEmpresa prefijo = jdbcTemplate.queryForObject(
				"select emprefijoSolicitud from ff_Empresa where EMidEmpresa = ? and EMidEstatus = 1",
				new BeanPropertyRowMapper<>(PrefijoEmpresa.class), idEmpresa);
		return prefijo;
	}
        
        @Override
        public Integer obtenerEmpresaDeEmpleado(String numeroEmpleado, Integer idCorp){
//            String sql = "select emp.EMIdEmpresa from ff_Empleado emp where emp.EMNumeroEmpleado = ? and EMIdTitular = 1";
            String sql = "select ff_Empresa.EMidEmpresa from ff_Empresa where EMidEmpresa IN (" +
"		select emp.EMIdEmpresa from ff_Empleado emp where emp.EMNumeroEmpleado = ? and EMIdTitular = 1) and EMidCorporativo = ?";
            Integer id = jdbcTemplate.queryForObject(sql, Integer.class, numeroEmpleado, idCorp);
            return id;
        }

		@Override
		public Integer obtenerEmpresaBajaDependiente(int idEmpleado, Integer idCorp){
	//            String sql = "select emp.EMIdEmpresa from ff_Empleado emp where emp.EMNumeroEmpleado = ? and EMIdTitular = 1";
			String sql = "select ff_Empresa.EMidEmpresa from ff_Empresa where EMidEmpresa IN (" +
					"		select emp.EMIdEmpresa from ff_Empleado emp where emp.id = ? and EMIdTitular = 0) and EMidCorporativo = ?";
			Integer id = jdbcTemplate.queryForObject(sql, Integer.class, idEmpleado, idCorp);
			return id;
		}

        @Override
        public boolean isCorporativo(Integer IdEmpresa) {
            String sql = "select count(*) from ff_Empresa emp where emp.EMidEmpresa = ? and emp.EMidCorporativo = emp.EMidEmpresa and emp.EMidEstatus != 2;";
            Integer count = jdbcTemplate.queryForObject(sql, Integer.class, IdEmpresa);
            return count == 1;
        }

    @Override
    public List<Object> obtenerEmpresasGridLogin(Integer idCorporativo, Integer idEmpleado) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetEmpresaXCorporativoGrid");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("EMidCorporativo", idCorporativo);
        inParamMap.put("IdEmpleado", idEmpleado);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
        return listSP.isEmpty() ? listSP : new ArrayList<Object>((Collection<? extends Object>) listSP.get(0));
    }
    
    
     @Override
    public List<Object> obtenerEmpresasGridLoginBF3(Integer idCorporativo, Integer idEmpleado) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetEmpresaXCorporativoGrid_BF3");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("EMidCorporativo", idCorporativo);
        inParamMap.put("IdEmpleado", idEmpleado);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
        return listSP.isEmpty() ? listSP : new ArrayList<Object>((Collection<? extends Object>) listSP.get(0));
    }
    

    @Override
    public List<Map<String, Object>> obtenerEmpresasCambioEmpresa(Integer idCorporativo, Integer idAdmin) {
        String sql = "select a.ADIdAdministrador as id, b.AEIdEmpresa as IdEmpresa, AEIdRol as IdRol, " +
        "AEIdPerfil as IdPerfil, EM.EMNombre as NomEmpresa, " +
        "EM.EMIdEmpresaFlexiForbes as IdEmpresaFlexiForbes, " +
        "EM.EMOrden as orden,CA.CAAyudaCampo CampoReset " +
        "from ff_administrador as a  WITH(NOLOCK, READUNCOMMITTED) " +
        "inner join ff_AdministradorEmpresa as b  WITH(NOLOCK, READUNCOMMITTED) on a.ADIdAdministrador = b.ADIdAdministrador " +
        "inner join ff_Empresa EM  WITH(NOLOCK, READUNCOMMITTED)  on b.AEIdEmpresa = EM.EMIdEmpresa and em.EMidEstatus= 1 " +
        "INNER JOIN ff_Configuracion C on C.COidConfiguracion = EM.EMidConfiguracion " +
        "INNER JOIN ff_Campo CA on CA.CAIdCampo = C.COidCampoPassIni " +
        "where EM.EMidCorporativo=? and ADIdEstatus=1 and AEIdEstatus = 1 and a.ADIdAdministrador = ? order by EM.EMOrden, EM.EMidEmpresa asc";
        List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, idCorporativo, idAdmin);
        return result;
    }

    @Override
    public List<Object> empresasXcorporativoAdm(int idCorporativo, int idAdmin) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetEmpresaXcorporativoAdministrador");
        Map<String, Object> inParamMap = new HashMap<String, Object>();
	inParamMap.put("idCorporativo", idCorporativo);
	inParamMap.put("idAdministrador", idAdmin);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);	
	Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
	List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
	return listSP;
    }


	@Override
	public Integer obtenerClaveEmpresaActiva(String numeroEmpleado, int idCorporativo, int idEmpresa) {
		SimpleJdbcCall simpleJdbcCall =  new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_BuscaUnaEmpresaActivaXCorporativoBF3");
		Map<String, Object> inParamMap =  new HashMap<>();
		inParamMap.put("IdCorporativo", idCorporativo);
		inParamMap.put("claveAcceso", numeroEmpleado);
		inParamMap.put("IdEmpresa", idEmpresa);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listResult = new ArrayList<>(simpleJdbcCallResult.values());
		Integer resultado = 0;
		if (listResult.size() > 0) {
			resultado = (Integer) ((LinkedCaseInsensitiveMap) ((ArrayList) listResult.get(0)).get(0)).get("EMidEmpresa");
		}
		return resultado;
	}

}
