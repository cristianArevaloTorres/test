/*
  PREPARA LOS DATOS DE LOS SIETE TXT DE CARGA MASIVA B2/BF3.

  Parametrizable por empresa destino, empresa origen y clave de usuario.
  Los roles, perfiles, ubicaciones, corporativo y vigencia se toman de BD.

  Puede ejecutarse antes de una primera prueba o para restablecerla. Solo
  elimina/recrea registros QA identificados por los numeros reservados
  listados abajo. Aunque las columnas son VARCHAR(20), los nuevos numeros
  contienen solo digitos para cubrir tambien validaciones legacy numericas.
  Si alguno ya tiene relaciones funcionales ajenas a estas pruebas,
  una FK detendra el script y toda la transaccion se revertira.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ========================== PARAMETROS ========================== */
DECLARE @IdEmpresa INT = 186;
DECLARE @IdEmpresaOrigen INT = 187;
DECLARE @ClaveUsuario VARCHAR(50) = 'jvazquez';
DECLARE @NumeroPrueba INT = 1; -- Cambie a 2, 3, 4... para obtener otro lote.
/* =============================================================== */

DECLARE @Usuario INT;
DECLARE @Ahora DATETIME = GETDATE();
DECLARE @IdConfiguracion INT;
DECLARE @IdCorporativo INT;
DECLARE @IdVigencia INT;
DECLARE @RolDestino INT;
DECLARE @RolOrigen INT;
DECLARE @PerfilDestino INT;
DECLARE @PerfilOrigen INT;
DECLARE @AreaDestino INT;
DECLARE @OficinaDestino INT;
DECLARE @CentroDestino INT;
DECLARE @AreaOrigen INT;
DECLARE @OficinaOrigen INT;
DECLARE @CentroOrigen INT;
DECLARE @IdEmpleadoReferenciaDestino INT;
DECLARE @NumeroEmpleadoReferenciaDestino VARCHAR(20);
DECLARE @NombreEmpleadoReferenciaDestino VARCHAR(250);

DECLARE @Lote VARCHAR(6) = RIGHT('000000' + CONVERT(VARCHAR(6), @NumeroPrueba), 6);
DECLARE @Prefijo VARCHAR(18) = CONVERT(VARCHAR(10), @IdEmpresa) + @Lote;
DECLARE @N1 VARCHAR(20) = @Prefijo + '01';
DECLARE @N2 VARCHAR(20) = @Prefijo + '02';
DECLARE @N3 VARCHAR(20) = @Prefijo + '03';
DECLARE @N4 VARCHAR(20) = @Prefijo + '04';
DECLARE @N5 VARCHAR(20) = @Prefijo + '05';
DECLARE @N6 VARCHAR(20) = @Prefijo + '06';
DECLARE @N7 VARCHAR(20) = @Prefijo + '07';
DECLARE @N8 VARCHAR(20) = @Prefijo + '08';
DECLARE @Periodo VARCHAR(50) = 'QACM' + CONVERT(VARCHAR(10), @IdEmpresa) + 'P' + CONVERT(VARCHAR(6), @NumeroPrueba);
DECLARE @RegistroAutos VARCHAR(100) = 'QACM-CIS-' + CONVERT(VARCHAR(10), @IdEmpresa) + '-P' + CONVERT(VARCHAR(6), @NumeroPrueba);
DECLARE @SerieAutos VARCHAR(100) = 'QACM-SERIE-' + CONVERT(VARCHAR(10), @IdEmpresa) + '-P' + CONVERT(VARCHAR(6), @NumeroPrueba);

BEGIN TRY
    BEGIN TRANSACTION;

    IF @NumeroPrueba NOT BETWEEN 1 AND 999999
        THROW 51799, '@NumeroPrueba debe estar entre 1 y 999999.', 1;

    IF NOT EXISTS (SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1)
        THROW 51800, 'No existe la empresa destino activa.', 1;

    IF @IdEmpresaOrigen = @IdEmpresa OR NOT EXISTS
       (SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresaOrigen AND EMIdEstatus = 1)
        THROW 51801, 'La empresa origen debe existir, estar activa y ser distinta del destino.', 1;

    IF (SELECT COUNT(*) FROM dbo.ff_Administrador
        WHERE UPPER(LTRIM(RTRIM(ADClaveAcceso))) = UPPER(LTRIM(RTRIM(@ClaveUsuario)))
          AND ADIdEstatus = 1) <> 1
        THROW 51802, 'La clave no identifica exactamente a un administrador activo.', 1;

    SELECT @Usuario = ADIdAdministrador
    FROM dbo.ff_Administrador
    WHERE UPPER(LTRIM(RTRIM(ADClaveAcceso))) = UPPER(LTRIM(RTRIM(@ClaveUsuario)))
      AND ADIdEstatus = 1;

    SELECT @IdConfiguracion = EMIdConfiguracion, @IdCorporativo = EMIdCorporativo
    FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresa;

    SELECT TOP (1) @IdVigencia = VIIdVigencia
    FROM dbo.ff_Vigencia
    WHERE VIIdConfiguracion = @IdConfiguracion AND VIIdEstatus = 1
    ORDER BY CASE WHEN CONVERT(DATE, @Ahora) BETWEEN CONVERT(DATE, VIVigenciaIni)
                                                   AND CONVERT(DATE, VIVigenciaFin)
                  THEN 0 ELSE 1 END,
             VIVigenciaIni DESC, VIIdVigencia DESC;

    IF @IdVigencia IS NULL
        THROW 51803, 'No existe una vigencia activa para la configuracion destino.', 1;

    SELECT TOP (1) @RolDestino = ROIdRol
    FROM dbo.ff_Rol
    WHERE ROIdEmpresa = @IdEmpresa AND ROIdEstatus = 1 AND RODefault = 1
    ORDER BY ROIdRol;

    SELECT TOP (1) @RolOrigen = ROIdRol
    FROM dbo.ff_Rol
    WHERE ROIdEmpresa = @IdEmpresaOrigen AND ROIdEstatus = 1 AND RODefault = 1
    ORDER BY ROIdRol;

    IF @RolDestino IS NULL OR @RolOrigen IS NULL
        THROW 51804, 'Destino y origen deben tener un rol default activo. El script no modifica roles.', 1;

    SELECT TOP (1)
        @IdEmpleadoReferenciaDestino = E.Id,
        @NumeroEmpleadoReferenciaDestino = E.EMNumeroEmpleado,
        @NombreEmpleadoReferenciaDestino = LTRIM(RTRIM(
            ISNULL(E.EMNombre1, '') + ' ' + ISNULL(E.EMNombre2, '') + ' ' +
            ISNULL(E.EMApellidoPaterno, '') + ' ' + ISNULL(E.EMApellidoMaterno, ''))),
        @PerfilDestino = E.EMIdPerfil, @AreaDestino = E.EMArea,
        @OficinaDestino = E.EMOficina, @CentroDestino = E.EMIdCentroCostos
    FROM dbo.ff_Empleado E
    INNER JOIN dbo.ff_Perfil P ON P.PEIdPerfil = E.EMIdPerfil
      AND P.PEIdEmpresa = @IdEmpresa AND P.PEIdEstatus = 1
    WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMIdEstatus = 1
      AND E.EMIdParentesco = 1 AND E.EMIdTitular = 1
      AND E.EMArea IS NOT NULL AND E.EMOficina IS NOT NULL
      AND E.EMIdCentroCostos IS NOT NULL
      AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
    ORDER BY CASE WHEN E.EMIdRol = @RolDestino THEN 0 ELSE 1 END, E.Id DESC;

    SELECT TOP (1)
        @PerfilOrigen = E.EMIdPerfil, @AreaOrigen = E.EMArea,
        @OficinaOrigen = E.EMOficina, @CentroOrigen = E.EMIdCentroCostos
    FROM dbo.ff_Empleado E
    INNER JOIN dbo.ff_Perfil P ON P.PEIdPerfil = E.EMIdPerfil
      AND P.PEIdEmpresa = @IdEmpresaOrigen AND P.PEIdEstatus = 1
    WHERE E.EMIdEmpresa = @IdEmpresaOrigen AND E.EMIdEstatus = 1
      AND E.EMIdParentesco = 1 AND E.EMIdTitular = 1
      AND E.EMArea IS NOT NULL AND E.EMOficina IS NOT NULL
      AND E.EMIdCentroCostos IS NOT NULL
      AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
    ORDER BY CASE WHEN E.EMIdRol = @RolOrigen THEN 0 ELSE 1 END, E.Id DESC;

    IF @PerfilDestino IS NULL
        THROW 51806, 'No hay un titular real completo en la empresa destino.', 1;

    /* Un fragmento de datos puede no traer titulares reales de la empresa
       origen. El perfil se toma entonces del catalogo activo de esa empresa;
       las ubicaciones solo completan el dummy y se reutilizan del destino. */
    IF @PerfilOrigen IS NULL
    BEGIN
        SELECT TOP (1) @PerfilOrigen = P.PEIdPerfil
        FROM dbo.ff_Perfil P
        WHERE P.PEIdEmpresa = @IdEmpresaOrigen
          AND P.PEIdEstatus = 1
          AND ISNULL(P.PEAdministrador, 0) = 0
        ORDER BY P.PEIdPerfil;

        SET @AreaOrigen = @AreaDestino;
        SET @OficinaOrigen = @OficinaDestino;
        SET @CentroOrigen = @CentroDestino;
    END;

    IF @PerfilOrigen IS NULL
        THROW 51807, 'No existe un perfil operativo activo en la empresa origen.', 1;

    DECLARE @Numeros TABLE (numero VARCHAR(20) NOT NULL PRIMARY KEY);
    INSERT @Numeros (numero)
    VALUES
        (@N1), (@N2), (@N3), (@N4), (@N5), (@N6), (@N7), (@N8);

    /* Proteccion contra una coincidencia accidental con datos no dummy.
       La descarga BF3 y el generador SQL agregan la semilla de la prueba al
       nombre/apellido para no chocar con la validacion de duplicados del SP.
       Solo se considera recuperable si conserva tambien el correo dummy. */
    IF EXISTS
    (
        SELECT 1
        FROM dbo.ff_Empleado E
        INNER JOIN @Numeros N ON N.numero = E.EMNumeroEmpleado
        WHERE NOT
        (
            UPPER(ISNULL(E.EMApellidoPaterno, '')) IN ('PRUEBA', 'ALTA')
            OR
            (
                UPPER(ISNULL(E.EMNombre1, '')) LIKE 'DUMMY%'
                AND UPPER(ISNULL(E.EMApellidoPaterno, '')) LIKE 'PRUEBA%'
                AND LOWER(ISNULL(E.EMCorreoElectronico, '')) LIKE '%@dummy.mx'
            )
        )
    )
        THROW 51805, 'Un numero reservado de prueba ya pertenece a un registro que no parece dummy. No se modifico nada.', 1;

    DECLARE @EmpleadosAnteriores TABLE (idEmpleado INT NOT NULL PRIMARY KEY);
    INSERT @EmpleadosAnteriores (idEmpleado)
    SELECT DISTINCT E.Id
    FROM dbo.ff_Empleado E
    INNER JOIN @Numeros N ON N.numero = E.EMNumeroEmpleado;

    /* Limpia exclusivamente resultados generados por una prueba previa. */
    DELETE C
    FROM dbo.bf_Compensacion_STEmpleado C
    INNER JOIN @EmpleadosAnteriores E ON E.idEmpleado = C.CSIdEmpleado;

    DELETE D
    FROM dbo.bf_DescuentoEmpleadoConciliacion D
    INNER JOIN @EmpleadosAnteriores E ON E.idEmpleado = D.DEIdEmpleado
    WHERE D.DENumeroRegistroAseguradora = @RegistroAutos
       OR D.DEPeriodo = @Periodo;

    DELETE L
    FROM dbo.ff_LogTranferenciaEmpleado L
    INNER JOIN @EmpleadosAnteriores E ON E.idEmpleado = L.LTEIdEmpleado
    WHERE L.LTEIdEmpresaOrigen = @IdEmpresaOrigen
      AND L.LTEIdEmpresaDestino = @IdEmpresa;

    DECLARE @SolicitudesAutos TABLE (id INT NOT NULL PRIMARY KEY);
    INSERT @SolicitudesAutos (id)
    SELECT SAIdSolicitudAutos
    FROM dbo.fb_SolicitudAutos
    WHERE SANumeroRegistroAseguradora = @RegistroAutos;

    DECLARE @EdoCuentaAutos TABLE (id INT NOT NULL PRIMARY KEY);
    INSERT @EdoCuentaAutos (id)
    SELECT ECIdEdoCuentaAutos
    FROM dbo.fb_EdoCuentaAutos E
    INNER JOIN @SolicitudesAutos S ON S.id = E.ECIdSolicitud;

    DECLARE @Desgloses TABLE (id INT NOT NULL PRIMARY KEY);
    INSERT @Desgloses (id)
    SELECT ECIdEdoCuentaDesglose
    FROM dbo.fb_EdoCuentaDesglose D
    INNER JOIN @EdoCuentaAutos E ON E.id = D.ECIdEdoCuentaAutos;

    DELETE L
    FROM dbo.bf_LogArchivoDescuentos L
    INNER JOIN @Desgloses D ON D.id = L.LAIdEdoCuentaDesglose;

    DELETE D
    FROM dbo.fb_EdoCuentaDesglose D
    INNER JOIN @Desgloses X ON X.id = D.ECIdEdoCuentaDesglose;

    DELETE E
    FROM dbo.fb_EdoCuentaAutos E
    INNER JOIN @EdoCuentaAutos X ON X.id = E.ECIdEdoCuentaAutos;

    DELETE S
    FROM dbo.fb_SolicitudAutos S
    INNER JOIN @SolicitudesAutos X ON X.id = S.SAIdSolicitudAutos;

    DELETE FROM dbo.fb_CalendarioIngresoNomina
    WHERE CNNombrePeriodo = 'QACM CONCILIACION ' + CONVERT(VARCHAR(10), @IdEmpresa) +
                            ' P' + CONVERT(VARCHAR(6), @NumeroPrueba)
       OR CNQuincenaAnioCalendario = @Periodo;

    /*
      Dependientes primero; luego titulares. Se eliminan igualmente de uno
      en uno para ser compatibles con triggers legacy que leen deleted como
      una sola fila. Una relacion externa real detiene el proceso y provoca
      ROLLBACK por XACT_ABORT.
    */
    DECLARE @IdEmpleadoEliminar INT;

    WHILE EXISTS
    (
        SELECT 1
        FROM dbo.ff_Empleado E
        INNER JOIN @Numeros N ON N.numero = E.EMNumeroEmpleado
        WHERE E.EMIdParentesco <> 1
    )
    BEGIN
        SELECT TOP (1) @IdEmpleadoEliminar = E.Id
        FROM dbo.ff_Empleado E
        INNER JOIN @Numeros N ON N.numero = E.EMNumeroEmpleado
        WHERE E.EMIdParentesco <> 1
        ORDER BY E.Id;

        DELETE FROM dbo.ff_Empleado WHERE Id = @IdEmpleadoEliminar;
    END;

    WHILE EXISTS
    (
        SELECT 1
        FROM dbo.ff_Empleado E
        INNER JOIN @Numeros N ON N.numero = E.EMNumeroEmpleado
        WHERE E.EMIdParentesco = 1
    )
    BEGIN
        SELECT TOP (1) @IdEmpleadoEliminar = E.Id
        FROM dbo.ff_Empleado E
        INNER JOIN @Numeros N ON N.numero = E.EMNumeroEmpleado
        WHERE E.EMIdParentesco = 1
        ORDER BY E.Id;

        DELETE FROM dbo.ff_Empleado WHERE Id = @IdEmpleadoEliminar;
    END;

    /*
      Titulares base de cada operacion.

      Se insertan uno por uno porque algunas instalaciones tienen el trigger
      fb_AsignacionPerfil implementado para una sola fila. Un INSERT con seis
      filas hace que su consulta sobre inserted devuelva mas de un valor y
      provoca el mensaje 512.
    */
    DECLARE @EmpleadosDummy TABLE
    (
        Orden INT NOT NULL PRIMARY KEY,
        EMIdEmpresa INT NOT NULL,
        EMIdPerfil INT NOT NULL,
        EMIdEstatus INT NOT NULL,
        EMNumeroEmpleado VARCHAR(20) NOT NULL,
        EMNombre1 VARCHAR(70) NOT NULL,
        EMFechaNacimiento DATETIME NOT NULL,
        EMFechaBaja DATETIME NULL,
        EMIdRol INT NOT NULL,
        EMArea INT NOT NULL,
        EMOficina INT NOT NULL,
        EMIdCentroCostos INT NOT NULL
    );

    INSERT @EmpleadosDummy
        (Orden, EMIdEmpresa, EMIdPerfil, EMIdEstatus, EMNumeroEmpleado,
         EMNombre1, EMFechaNacimiento, EMFechaBaja, EMIdRol,
         EMArea, EMOficina, EMIdCentroCostos)
    VALUES
        (1, @IdEmpresa, @PerfilDestino, 1, @N1, 'BASE', '1985-01-15', NULL,
         @RolDestino, @AreaDestino, @OficinaDestino, @CentroDestino),
        (2, @IdEmpresa, @PerfilDestino, 1, @N3, 'CAMBIO', '1986-02-16', NULL,
         @RolDestino, @AreaDestino, @OficinaDestino, @CentroDestino),
        (3, @IdEmpresa, @PerfilDestino, 2, @N5, 'REACTIVACION', '1987-03-17', DATEADD(DAY, -30, @Ahora),
         @RolDestino, @AreaDestino, @OficinaDestino, @CentroDestino),
        (4, @IdEmpresa, @PerfilDestino, 1, @N6, 'COMPENSACION', '1988-04-18', NULL,
         @RolDestino, @AreaDestino, @OficinaDestino, @CentroDestino),
        (5, @IdEmpresa, @PerfilDestino, 1, @N7, 'CONCILIACION', '1989-05-19', NULL,
         @RolDestino, @AreaDestino, @OficinaDestino, @CentroDestino),
        (6, @IdEmpresaOrigen, @PerfilOrigen, 1, @N8, 'TRANSFERENCIA', '1990-06-20', NULL,
         @RolOrigen, @AreaOrigen, @OficinaOrigen, @CentroOrigen);

    DECLARE @OrdenDummy INT = 1;
    WHILE EXISTS (SELECT 1 FROM @EmpleadosDummy WHERE Orden = @OrdenDummy)
    BEGIN
        INSERT dbo.ff_Empleado
        (
            EMIdEmpresa, EMIdTitular, EMIdPerfil, EMIdParentesco, EMIdSexo,
            EMIdEstatus, EMNumeroEmpleado, EMCertificado, EMNombre1,
            EMApellidoPaterno, EMApellidoMaterno, EMFechaNacimiento,
            EMFechaIngresoEmpresa, EMFechaAlta, EMFechaEstatus, EMFechaBaja,
            EMIdRol, EMArea, EMOficina, EMIdCentroCostos, EMSalarioBase,
            EMUsuarioAdd, EMFechaAdd
        )
        SELECT
            D.EMIdEmpresa, 1, D.EMIdPerfil, 1, 1,
            D.EMIdEstatus, D.EMNumeroEmpleado, D.EMNumeroEmpleado, D.EMNombre1,
            'PRUEBA', 'CARGA', D.EMFechaNacimiento,
            '2020-01-01', '2020-01-01', @Ahora, D.EMFechaBaja,
            D.EMIdRol, D.EMArea, D.EMOficina, D.EMIdCentroCostos, 20000,
            @Usuario, @Ahora
        FROM @EmpleadosDummy D
        WHERE D.Orden = @OrdenDummy;

        SET @OrdenDummy += 1;
    END;

    /* Cadena minima real que valida ff_XCMDescuentosCMAutos. */
    DECLARE @IdEmpleadoConciliacion INT =
    (
        SELECT Id FROM dbo.ff_Empleado
        WHERE EMIdEmpresa = @IdEmpresa AND EMNumeroEmpleado = @N7
          AND EMIdParentesco = 1
    );
    DECLARE @IdCalendario INT;
    DECLARE @IdSolicitudAuto INT;
    DECLARE @IdEdoCuentaAuto INT;
    DECLARE @IdDesglose INT;

    INSERT dbo.fb_CalendarioIngresoNomina
    (
        CNIdEmpresa, CNNombrePeriodo, CNFechaInicioIngreso,
        CNFechaFinIngreso, CNFechaCorteNomina, CNFechaAplicacionDescuento,
        CNNumeroQuincena, CNQuincenaAnioCalendario, CNEstatus,
        CNUsuarioAdd, CNFechaAdd, CNIdVigencia
    )
    VALUES
    (@IdCorporativo, 'QACM CONCILIACION ' + CONVERT(VARCHAR(10), @IdEmpresa) +
                     ' P' + CONVERT(VARCHAR(6), @NumeroPrueba),
     DATEADD(DAY, -15, @Ahora), DATEADD(DAY, -1, @Ahora), @Ahora,
     DATEADD(DAY, 1, @Ahora), 99, @Periodo, 1, @Usuario, @Ahora, @IdVigencia);
    SET @IdCalendario = CONVERT(INT, SCOPE_IDENTITY());

    INSERT dbo.fb_SolicitudAutos
    (
        SAIdVigencia, SAIdPaquete, SAIdTarifaVehiculo, SAIdPaqueteCopia,
        SANumeroRegistroAseguradora, SAIdEmpresaTitular, SAIdEmpleadoTitular,
        SAFechaInicioContratacion, SAFechaSolicitud, SANumeroSerieAuto,
        SAEstatus, SAUsuarioAdd, SAFechaAdd
    )
    VALUES
    (@IdVigencia, 0, 0, 0, @RegistroAutos, @IdEmpresa, @IdEmpleadoConciliacion,
     DATEADD(MONTH, -1, @Ahora), @Ahora, @SerieAutos, 1, @Usuario, @Ahora);
    SET @IdSolicitudAuto = CONVERT(INT, SCOPE_IDENTITY());

    INSERT dbo.fb_EdoCuentaAutos
        (ECIdSolicitud, ECNumeroRecibosADN, ECNumeroDescuentos, ECStatus,
         ECUsuarioAdd, ECFechaAdd)
    VALUES
        (@IdSolicitudAuto, 1, 1, 1, @Usuario, @Ahora);
    SET @IdEdoCuentaAuto = CONVERT(INT, SCOPE_IDENTITY());

    INSERT dbo.fb_EdoCuentaDesglose
    (
        ECIdEdoCuentaAutos, ECNumeroRecibo, ECPrimaTotalRecibo,
        ECProgramado, ECConciliado, ECLiquidado,
        ECIdCalendarioIngresoNomina, ECEstatus, ECUsuarioAdd, ECFechaAdd
    )
    VALUES
    (@IdEdoCuentaAuto, 1, 100.00, 1, 0, 0,
     @IdCalendario, 1, @Usuario, @Ahora);
    SET @IdDesglose = CONVERT(INT, SCOPE_IDENTITY());

    INSERT dbo.bf_LogArchivoDescuentos
    (
        LAIdEdoCuentaDesglose, LAIdCalendarioIngresoNomina,
        LAFechaCorteNomina, LANombreArchivoEnvio, LAFechaEnvio,
        LAEstatus, LAUsuarioAdd, LAFechaAdd
    )
    VALUES
    (@IdDesglose, @IdCalendario, @Ahora,
     'QACM_CONCILIACION_' + CONVERT(VARCHAR(10), @IdEmpresa) +
         '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
     @Ahora, 1, @Usuario, @Ahora);

    COMMIT TRANSACTION;

    SELECT
        '01_DUMMIES_PREPARADOS' AS Bloque,
        E.EMIdEmpresa,
        E.Id AS IdEmpleado,
        E.EMNumeroEmpleado,
        E.EMNombre1,
        E.EMApellidoPaterno,
        E.EMIdEstatus,
        E.EMFechaBaja,
        E.EMIdRol,
        CASE
            WHEN E.EMNumeroEmpleado = @N1 THEN '01 ALTA DEPENDIENTE'
            WHEN E.EMNumeroEmpleado = @N3 THEN '13 CAMBIO DE NUMERO'
            WHEN E.EMNumeroEmpleado = @N5 THEN '14 REACTIVACION'
            WHEN E.EMNumeroEmpleado = @N6 THEN '16 COMPENSACION'
            WHEN E.EMNumeroEmpleado = @N7 THEN '05 CONCILIACION AUTOS'
            WHEN E.EMNumeroEmpleado = @N8 THEN '15 TRANSFERENCIA'
        END AS escenarioPreparado,
        CASE
            WHEN E.EMNumeroEmpleado = @N5 THEN 'DUMMY EXISTENTE INACTIVO'
            WHEN E.EMNumeroEmpleado = @N7 THEN 'DUMMY EXISTENTE CON CADENA'
            WHEN E.EMNumeroEmpleado = @N8 THEN 'DUMMY EXISTENTE EN EMPRESA ORIGEN'
            ELSE 'DUMMY EXISTENTE CONTROLADO'
        END AS TipoInsumo,
        'REGISTRO QA QUE SI PUEDE SER MODIFICADO POR LA PRUEBA' AS Uso
    FROM dbo.ff_Empleado E
    WHERE E.EMNumeroEmpleado IN (@N1, @N3, @N5, @N6, @N7, @N8)
    ORDER BY E.EMIdEmpresa, E.EMNumeroEmpleado;

    SELECT
        '02_EXISTENTE_REAL_USADO_COMO_REFERENCIA' AS Bloque,
        @IdEmpleadoReferenciaDestino AS IdEmpleado,
        @IdEmpresa AS IdEmpresa,
        @NumeroEmpleadoReferenciaDestino AS NumeroEmpleado,
        @NombreEmpleadoReferenciaDestino AS Empleado,
        @PerfilDestino AS Perfil,
        @RolDestino AS Rol,
        @AreaDestino AS Area,
        @OficinaDestino AS Oficina,
        @CentroDestino AS CentroCostos,
        'Se usan sus valores de catalogo para que los dummies pasen validaciones; este empleado real no se modifica.' AS Uso;

    SELECT *
    FROM
    (
        SELECT 1 Orden, 1 IdOperacion, 'ALTA DEPENDIENTE' TipoCarga,
               @N1 NumeroEmpleado, 'DUMMY EXISTENTE CONTROLADO' TipoInsumo,
               'Titular dummy activo al que se agregara otro dependiente dummy.' Explicacion
        UNION ALL SELECT 2, 2, 'ALTA TITULAR', @N2, 'DUMMY NUEVO',
               'No se inserta aqui; el TXT debe darlo de alta.'
        UNION ALL SELECT 3, 5, 'CONCILIACION AUTOS', @N7, 'DUMMY EXISTENTE CON CADENA',
               'Tiene calendario, solicitud, estado de cuenta y desglose QA.'
        UNION ALL SELECT 4, 13, 'CAMBIO NUMERO', @N3 + ' -> ' + @N4,
               'DUMMY EXISTENTE CONTROLADO', 'Evita cambiar el numero de un empleado real.'
        UNION ALL SELECT 5, 14, 'REACTIVACION', @N5, 'DUMMY EXISTENTE INACTIVO',
               'Esta dado de baja de forma controlada para poder reactivarlo.'
        UNION ALL SELECT 6, 15, 'TRANSFERENCIA', @N8, 'DUMMY EXISTENTE EN ORIGEN',
               'Existe en la empresa origen y puede moverse sin afectar personal real.'
        UNION ALL SELECT 7, 16, 'COMPENSACION', @N6, 'DUMMY EXISTENTE CONTROLADO',
               'Permite insertar o actualizar una compensacion sin tocar un empleado real.'
    ) C
    ORDER BY Orden;

    SELECT
        'OK' AS Resultado,
        'Los dummies estan listos. El titular ' + @N2 +
            ' se crea al cargar el TXT 02.' AS Mensaje,
        @IdEmpresa AS IdEmpresa,
        @NumeroPrueba AS NumeroPrueba,
        @ClaveUsuario AS ClaveUsuario,
        @Usuario AS IdUsuarioAuditoria,
        @RolDestino AS RolDestinoBD,
        @PerfilDestino AS PerfilDestinoBD,
        @IdVigencia AS VigenciaBD;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
