/*
  COMPROBACION DE RESULTADOS DE CARGA MASIVA B2 EJECUTADA DESDE BF3

  SOLO LECTURA. Use exactamente los mismos parametros utilizados en:
    1) PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql
    2) GENERAR_INPUTS_TXT_CARGA_MASIVA_EMPRESA_186.sql

  Puede ejecutarse antes de las cargas para ver PENDIENTE y despues de cada
  TXT para confirmar que la regla correspondiente cambie a OK.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;

/* ========================== PARAMETROS ========================== */
DECLARE @IdEmpresa       INT = 186;
DECLARE @IdEmpresaOrigen INT = 187;
DECLARE @NumeroPrueba    INT = 1;
/* =============================================================== */

IF @NumeroPrueba NOT BETWEEN 1 AND 999999
    THROW 52000, '@NumeroPrueba debe estar entre 1 y 999999.', 1;

IF NOT EXISTS
   (SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1)
    THROW 52001, 'La empresa destino no existe o esta inactiva.', 1;

DECLARE @Lote VARCHAR(6) = RIGHT('000000' + CONVERT(VARCHAR(6), @NumeroPrueba), 6);
DECLARE @Prefijo VARCHAR(18) = CONVERT(VARCHAR(10), @IdEmpresa) + @Lote;
DECLARE @N1 VARCHAR(20) = @Prefijo + '01';
DECLARE @N2 VARCHAR(20) = @Prefijo + '02';
DECLARE @N3 VARCHAR(20) = @Prefijo + '03';
DECLARE @N4 VARCHAR(20) = @Prefijo + '04';
DECLARE @N5 VARCHAR(20) = @Prefijo + '05';
DECLARE @N6 VARCHAR(20) = @Prefijo + '06';
DECLARE @N7 VARCHAR(20) = @Prefijo + '07';
DECLARE @N8 VARCHAR(20) = @Prefijo + '08';
DECLARE @Periodo VARCHAR(50) = 'QACM' + CONVERT(VARCHAR(10), @IdEmpresa) +
                               'P' + CONVERT(VARCHAR(6), @NumeroPrueba);
DECLARE @RegistroAutos VARCHAR(100) = 'QACM-CIS-' + CONVERT(VARCHAR(10), @IdEmpresa) +
                                      '-P' + CONVERT(VARCHAR(6), @NumeroPrueba);

DECLARE @IdConfiguracion INT;
DECLARE @IdVigencia INT;
DECLARE @IdCompensacion INT;
DECLARE @IdPerfilDestino INT;

SELECT @IdConfiguracion = EMIdConfiguracion
FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresa;

SELECT TOP (1) @IdVigencia = VIIdVigencia
FROM dbo.ff_Vigencia
WHERE VIIdConfiguracion = @IdConfiguracion AND VIIdEstatus = 1
ORDER BY CASE WHEN CONVERT(DATE, GETDATE()) BETWEEN CONVERT(DATE, VIVigenciaIni)
                                                   AND CONVERT(DATE, VIVigenciaFin)
              THEN 0 ELSE 1 END,
         VIVigenciaIni DESC, VIIdVigencia DESC;

SELECT TOP (1) @IdPerfilDestino = E.EMIdPerfil
FROM dbo.ff_Empleado E
INNER JOIN dbo.ff_Perfil P ON P.PEIdPerfil = E.EMIdPerfil
  AND P.PEIdEmpresa = @IdEmpresa AND P.PEIdEstatus = 1
WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMIdEstatus = 1
  AND E.EMIdParentesco = 1 AND E.EMIdTitular = 1
  AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
ORDER BY E.Id DESC;

/* Misma resolucion que utiliza el generador para el caso 16. */
SELECT TOP (1) @IdCompensacion = C.CSIdCompensacion
FROM dbo.bf_Compensacion_STEmpleado C
INNER JOIN dbo.ff_Empleado E ON E.Id = C.CSIdEmpleado
WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMIdParentesco = 1
  AND C.CSIdCompensacion IS NOT NULL
  AND NOT (E.EMNumeroEmpleado = @N6 AND E.EMApellidoPaterno = 'PRUEBA')
ORDER BY C.CSFechaAdd DESC;

IF @IdCompensacion IS NULL
    SELECT TOP (1) @IdCompensacion = C.CCSIdConfiguracion
    FROM dbo.bf_Compensacion_STConfiguracion C
    WHERE C.CCSIdVigencia = @IdVigencia AND C.CCSIdEstatus = 1
    ORDER BY C.CCSOrden, C.CCSIdConfiguracion;

IF @IdCompensacion IS NULL SET @IdCompensacion = 900001;

DECLARE @R TABLE
(
    Orden INT NOT NULL PRIMARY KEY,
    IdOperacion INT NOT NULL,
    TipoCarga VARCHAR(100) NOT NULL,
    Insumo VARCHAR(200) NOT NULL,
    ReglaNegocio VARCHAR(1000) NOT NULL,
    RegistrosEncontrados INT NOT NULL,
    Resultado VARCHAR(30) NOT NULL,
    ConsultaDetalle VARCHAR(500) NOT NULL
);

DECLARE @C1 INT =
(
    SELECT COUNT(*) FROM dbo.ff_Empleado E
    WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N1
      AND E.EMIdParentesco <> 1 AND E.EMCertificado = @N1 + '01'
      AND E.EMIdEstatus = 1
);

INSERT @R VALUES
(1, 1, 'ALTA DEPENDIENTES', @N1,
 'Debe existir al menos un dependiente activo con el numero del titular y el certificado dummy del lote.',
 @C1, CASE WHEN @C1 >= 1 THEN 'OK' ELSE 'PENDIENTE/REVISAR' END,
 'Revise 02_DETALLE_ALTA_DEPENDIENTE.');

DECLARE @C2 INT =
(
    SELECT COUNT(*) FROM dbo.ff_Empleado E
    WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N2
      AND E.EMIdParentesco = 1 AND E.EMIdTitular = 1
);

INSERT @R VALUES
(2, 2, 'ALTA TITULARES', @N2,
 'Debe existir exactamente un titular con el numero nuevo; antes de la carga no debe existir.',
 @C2, CASE WHEN @C2 = 1 THEN 'OK' ELSE 'PENDIENTE/REVISAR' END,
 'Revise 03_DETALLE_ALTA_TITULAR.');

DECLARE @C5 INT =
(
    SELECT COUNT(*)
    FROM dbo.bf_DescuentoEmpleadoConciliacion D
    INNER JOIN dbo.ff_Empleado E ON E.Id = D.DEIdEmpleado
    WHERE E.EMNumeroEmpleado = @N7
      AND D.DEPeriodo = @Periodo
      AND D.DENumeroRegistroAseguradora = @RegistroAutos
      AND D.DEMonto = 100.00
      AND D.DEEstatus = 1
);

INSERT @R VALUES
(3, 5, 'CONCILIACION', @N7 + ' / ' + @Periodo,
 'Debe existir un descuento conciliado activo por 100.00 para el empleado, periodo y CIS del lote.',
 @C5, CASE WHEN @C5 = 1 THEN 'OK' ELSE 'PENDIENTE/REVISAR' END,
 'Revise 04_DETALLE_CONCILIACION.');

DECLARE @Actual13 INT =
(
    SELECT COUNT(*) FROM dbo.ff_Empleado
    WHERE EMIdEmpresa = @IdEmpresa AND EMNumeroEmpleado = @N3 AND EMIdTitular = 1
);
DECLARE @Nuevo13 INT =
(
    SELECT COUNT(*) FROM dbo.ff_Empleado
    WHERE EMIdEmpresa = @IdEmpresa AND EMNumeroEmpleado = @N4 AND EMIdTitular = 1
);

INSERT @R VALUES
(4, 13, 'CAMBIO NUMERO DE EMPLEADO', @N3 + ' -> ' + @N4,
 'El numero anterior debe desaparecer y el nuevo debe identificar exactamente al titular.',
 @Nuevo13, CASE WHEN @Actual13 = 0 AND @Nuevo13 = 1 THEN 'OK' ELSE 'PENDIENTE/REVISAR' END,
 'Revise 05_DETALLE_CAMBIO_NUMERO.');

DECLARE @C14 INT =
(
    SELECT COUNT(*) FROM dbo.ff_Empleado
    WHERE EMIdEmpresa = @IdEmpresa AND EMNumeroEmpleado = @N5
      AND EMIdParentesco = 1 AND EMIdTitular = 1
      AND EMIdEstatus = 1 AND EMFechaBaja IS NULL
);

INSERT @R VALUES
(5, 14, 'REACTIVACION DE EMPLEADO', @N5,
 'El titular debe quedar activo y sin fecha de baja.',
 @C14, CASE WHEN @C14 = 1 THEN 'OK' ELSE 'PENDIENTE/REVISAR' END,
 'Revise 06_DETALLE_REACTIVACION.');

DECLARE @EmpleadoTransferido INT =
(
    SELECT COUNT(*) FROM dbo.ff_Empleado
    WHERE EMIdEmpresa = @IdEmpresa AND EMNumeroEmpleado = @N8
      AND EMIdParentesco = 1 AND EMIdTitular = 1 AND EMIdEstatus = 1
);
DECLARE @EmpleadoEnOrigen INT =
(
    SELECT COUNT(*) FROM dbo.ff_Empleado
    WHERE EMIdEmpresa = @IdEmpresaOrigen AND EMNumeroEmpleado = @N8
      AND EMIdParentesco = 1 AND EMIdTitular = 1
);
DECLARE @LogTransferencia INT =
(
    SELECT COUNT(*)
    FROM dbo.ff_LogTranferenciaEmpleado L
    INNER JOIN dbo.ff_Empleado E ON E.Id = L.LTEIdEmpleado
    WHERE E.EMNumeroEmpleado = @N8
      AND L.LTEIdEmpresaOrigen = @IdEmpresaOrigen
      AND L.LTEIdEmpresaDestino = @IdEmpresa
);

INSERT @R VALUES
(6, 15, 'TRANSFERENCIA DE EMPLEADO', @N8,
 'El titular debe estar activo en destino, desaparecer de origen y tener log origen/destino.',
 @EmpleadoTransferido,
 CASE WHEN @EmpleadoTransferido = 1 AND @EmpleadoEnOrigen = 0 AND @LogTransferencia >= 1
      THEN 'OK' ELSE 'PENDIENTE/REVISAR' END,
 'Revise 07_DETALLE_TRANSFERENCIA.');

DECLARE @C16 INT =
(
    SELECT COUNT(*)
    FROM dbo.bf_Compensacion_STEmpleado C
    INNER JOIN dbo.ff_Empleado E ON E.Id = C.CSIdEmpleado
    WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N6
      AND E.EMIdParentesco = 1
      AND C.CSIdCompensacion = @IdCompensacion
      AND C.CSMontoCompensacion = 1500.00
      AND C.CSIdEstatus = 1
);

INSERT @R VALUES
(7, 16, 'CARGA MASIVA COMPENSACION', @N6 + ' / ' + CONVERT(VARCHAR(20), @IdCompensacion),
 'Debe existir una compensacion activa por 1500.00 para el titular y el ID usado en el TXT.',
 @C16, CASE WHEN @C16 = 1 THEN 'OK' ELSE 'PENDIENTE/REVISAR' END,
 'Revise 08_DETALLE_COMPENSACION.');

/* Este es el primer resultado que se debe revisar. */
SELECT
    '01_RESUMEN_REGLAS_NEGOCIO' AS Bloque,
    @IdEmpresa AS IdEmpresa,
    @NumeroPrueba AS NumeroPrueba,
    R.Orden,
    R.IdOperacion,
    R.TipoCarga,
    R.Insumo,
    R.ReglaNegocio,
    R.RegistrosEncontrados,
    R.Resultado,
    R.ConsultaDetalle
FROM @R R
ORDER BY R.Orden;

SELECT '02_DETALLE_ALTA_DEPENDIENTE' AS Bloque,
       E.Id, E.EMIdEmpresa, E.EMIdTitular, E.EMIdParentesco,
       E.EMNumeroEmpleado, E.EMCertificado, E.EMNombre1,
       E.EMApellidoPaterno, E.EMApellidoMaterno, E.EMIdEstatus, E.EMFechaAdd
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N1
ORDER BY E.EMIdParentesco, E.Id;

SELECT '03_DETALLE_ALTA_TITULAR' AS Bloque,
       E.Id, E.EMIdEmpresa, E.EMNumeroEmpleado, E.EMIdPerfil, E.EMIdRol,
       E.EMIdParentesco, E.EMIdTitular, E.EMIdEstatus, E.EMrfc, E.EMcurp,
       E.EMArea, E.EMOficina, E.EMIdCentroCostos, E.EMFechaAdd
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N2;

SELECT '04_DETALLE_CONCILIACION' AS Bloque,
       D.DEIdDescuentoEmpleado, D.DEIdEmpleado, E.EMNumeroEmpleado,
       D.DEPeriodo, D.DENumeroRegistroAseguradora, D.DEMonto,
       D.DEIdEmpresa, D.DEEstatus, D.DEFechaAdd
FROM dbo.bf_DescuentoEmpleadoConciliacion D
INNER JOIN dbo.ff_Empleado E ON E.Id = D.DEIdEmpleado
WHERE E.EMNumeroEmpleado = @N7
  AND (D.DEPeriodo = @Periodo OR D.DENumeroRegistroAseguradora = @RegistroAutos)
ORDER BY D.DEIdDescuentoEmpleado DESC;

SELECT '05_DETALLE_CAMBIO_NUMERO' AS Bloque,
       E.Id, E.EMIdEmpresa, E.EMNumeroEmpleado, E.EMCertificado,
       E.EMIdParentesco, E.EMIdTitular, E.EMIdEstatus, E.EMFechaUMod
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado IN (@N3, @N4)
ORDER BY E.EMNumeroEmpleado, E.EMIdParentesco;

SELECT '06_DETALLE_REACTIVACION' AS Bloque,
       E.Id, E.EMIdEmpresa, E.EMNumeroEmpleado, E.EMIdParentesco,
       E.EMIdTitular, E.EMIdEstatus, E.EMFechaBaja,
       E.EMFechaIngresoEmpresa, E.EMFechaEstatus, E.EMFechaUMod
FROM dbo.ff_Empleado E
WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N5
ORDER BY E.EMIdParentesco;

SELECT '07_DETALLE_TRANSFERENCIA' AS Bloque,
       E.Id, E.EMIdEmpresa AS EmpresaActual, E.EMNumeroEmpleado,
       E.EMIdPerfil, E.EMIdRol, E.EMIdEstatus,
       L.LTEIdEmpresaOrigen, L.LTEIdEmpresaDestino,
       L.LTEIdAccion, L.LTEDetalleAccion, L.LTEFechaAdd
FROM dbo.ff_Empleado E
LEFT JOIN dbo.ff_LogTranferenciaEmpleado L ON L.LTEIdEmpleado = E.Id
WHERE E.EMNumeroEmpleado = @N8
ORDER BY L.LTEIdLog DESC;

SELECT '08_DETALLE_COMPENSACION' AS Bloque,
       E.Id, E.EMIdEmpresa, E.EMNumeroEmpleado,
       C.CSIdCompensacion, C.CSMontoCompensacion,
       C.CSIdEstatus, C.CSFechaAdd, C.CSFechaUmod
FROM dbo.ff_Empleado E
LEFT JOIN dbo.bf_Compensacion_STEmpleado C ON C.CSIdEmpleado = E.Id
WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N6
ORDER BY C.CSFechaAdd DESC;

SELECT
    '09_RESUMEN_FINAL' AS Bloque,
    @IdEmpresa AS IdEmpresa,
    @NumeroPrueba AS NumeroPrueba,
    SUM(CASE WHEN Resultado = 'OK' THEN 1 ELSE 0 END) AS PruebasOK,
    COUNT(*) AS TotalPruebas,
    CASE WHEN SUM(CASE WHEN Resultado = 'OK' THEN 1 ELSE 0 END) = COUNT(*)
         THEN 'OK: LAS SIETE REGLAS DE NEGOCIO SE CUMPLEN'
         ELSE 'PENDIENTE: REVISE LAS OPERACIONES QUE NO ESTAN EN OK' END AS Resultado
FROM @R;
GO
