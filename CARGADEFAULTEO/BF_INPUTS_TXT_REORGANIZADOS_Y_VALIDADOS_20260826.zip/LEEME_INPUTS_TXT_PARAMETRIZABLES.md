# Inputs TXT parametrizables para Carga Masiva B2 desde BF3

## Parámetros que se cambian

Use los mismos valores en los tres scripts:

```sql
DECLARE @IdEmpresa       INT         = 186;
DECLARE @ClaveUsuario    VARCHAR(50) = 'jvazquez';
DECLARE @IdEmpresaOrigen INT         = 187;
DECLARE @NumeroPrueba    INT         = 1;
```

Para obtener otro lote cambie únicamente `@NumeroPrueba` a `2`, `3`, etc.
Cada número genera empleados, certificado, periodo, CIS, RFC, CURP y correos
QA diferentes.

## Por qué falló el TXT anterior

El motor recibió esto como un solo valor:

```text
EMIdEmpresa=186  EMUsuarioUMod=25
```

Por eso intentó convertir toda la cadena a entero y devolvió:

```text
El campo EMIdEmpresa no es valido para el tipo E.
```

Los scripts nuevos ya no dependen de `@commonFields`. Todos los campos van en
`@fieldNames` y sus valores, en el mismo orden, van en `@data`:

```text
@fieldNames:EMIdEmpresa,EMIdSexo,EMNumeroEmpleado,...
@data:
186|F|18600000101|...
```

También se comprueba en la BD que `F` exista en `ff_CMCSexo` y que `H` exista
en `ff_CMCParentesco`. El motor B2 aplica esas equivalencias antes de convertir
los valores a entero.

## Qué empleados se usan

Las operaciones modifican datos. Por seguridad, el sujeto de cada carga es un
dummy controlado y no un empleado real:

| Operación | Insumo utilizado | Motivo |
|---|---|---|
| 1 Alta dependiente | Titular dummy existente | Permite agregar un dependiente sin alterar la familia de un titular real. |
| 2 Alta titular | Número dummy nuevo | El objetivo de la operación es crear el titular. |
| 5 Conciliación | Empleado dummy con cadena de autos QA | Evita conciliar un descuento real. |
| 13 Cambio de número | Titular dummy existente | Cambiar el identificador de un empleado real sería riesgoso. |
| 14 Reactivación | Titular dummy inactivo | Ya cumple estatus y fecha de baja. |
| 15 Transferencia | Titular dummy existente en la empresa origen | Puede moverse sin afectar personal real. |
| 16 Compensación | Titular dummy activo | Evita modificar la compensación de un empleado real. |

Los valores que sí deben existir se toman de registros reales: empresa legacy,
usuario, perfil, rol, vigencia, área, oficina, centro de costos y compensación.
El generador muestra además el empleado real usado como referencia en el bloque
`05B_EXISTENTE_USADO_COMO_REFERENCIA`. Ese registro solo se consulta; no se
modifica.

## Orden de ejecución

1. Ejecute `PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql`. Este script modifica solo
   los registros QA reservados para ese `@NumeroPrueba` y deja listas las
   precondiciones.
2. Ejecute `GENERAR_INPUTS_TXT_CARGA_MASIVA_EMPRESA_186.sql` con los mismos
   parámetros.
3. Revise `02_CATALOGO_INPUTS`: explica para qué sirve cada carga, qué empleado
   usa y de dónde procede el dato.
4. Revise `05_VALIDACION_ESTRUCTURA_TXT`: las siete operaciones deben mostrar
   `OK`. Se validan cantidad, nombre y orden contra la plantilla activa.
5. Revise `06_ESTADO_PRECONDICIONES`: todos deben estar `LISTO`; el alta de
   titular debe estar `LISTO PARA ALTA`.
6. Obtenga el TXT del bloque `03_CONTENIDO_TXT_LISTO`.
7. Si SSMS no conserva saltos de línea al copiar una celda, use
   `03B_LINEAS_TXT_SIN_SALTOS_OCULTOS`: copie las tres filas de la operación en
   orden `1`, `2`, `3`, dejando cada una como una línea física.
8. Ejecute la carga desde BF3.
9. Ejecute `COMPROBAR_RESULTADOS_CARGA_MASIVA_POR_PRUEBA.sql` con el mismo
   `@NumeroPrueba`.

## Comprobación posterior

El comprobador valida una regla de negocio distinta por operación:

- Alta de dependiente: existe el dependiente activo con el certificado del lote.
- Alta de titular: existe exactamente un titular con el número nuevo.
- Conciliación: existe el descuento por monto, periodo y CIS preparados.
- Cambio de número: desapareció el anterior y existe el nuevo.
- Reactivación: el titular quedó activo y sin fecha de baja.
- Transferencia: el titular está en destino, ya no está en origen y existe log.
- Compensación: existe la compensación activa por el monto esperado.

Al terminar las siete cargas, `09_RESUMEN_FINAL` debe indicar
`PruebasOK=7`, `TotalPruebas=7` y resultado `OK`.

## Nota sobre el usuario

El TXT puede mostrar `EMUsuarioUMod` cuando la plantilla lo define, pero el
backend de BF3 siempre lo reemplaza con el identificador del usuario autenticado.
No confía en un usuario escrito manualmente dentro del archivo.
