package com.lockton.WSBeFlex.Services.CargaMasivaB2;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class CargaMasivaTxtDocumento {
    private final List<String> nombresCampo;
    private final List<List<String>> registros;
    private final Map<String, String> camposComunes;

    public CargaMasivaTxtDocumento(List<String> nombresCampo,
                                   List<List<String>> registros,
                                   Map<String, String> camposComunes) {
        this.nombresCampo = Collections.unmodifiableList(nombresCampo);
        this.registros = Collections.unmodifiableList(registros);
        this.camposComunes = Collections.unmodifiableMap(camposComunes);
    }

    public List<String> getNombresCampo() { return nombresCampo; }
    public List<List<String>> getRegistros() { return registros; }
    public Map<String, String> getCamposComunes() { return camposComunes; }
}
