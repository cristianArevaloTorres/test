package com.lockton.WSBeFlex.Services.CargaMasivaB2;

import com.lockton.WSBeFlex.DAO.CargaMasivaB2DAO;
import com.lockton.WSBeFlex.Services.CargaMasivaFlujoService;
import com.lockton.WSBeFlex.Services.Crypto.CryptoBeflexService;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class CargaMasivaB2Service {
    private static final DateTimeFormatter FECHA_B2 = DateTimeFormatter
            .ofPattern("dd/MM/uuuu", new Locale("es", "MX"))
            .withResolverStyle(ResolverStyle.STRICT);
    private final CargaMasivaTxtParser parser;
    private final CargaMasivaB2DAO dao;
    private final CargaMasivaFlujoService flujoService;
    private final CryptoBeflexService crypto;

    public CargaMasivaB2Service(CargaMasivaB2DAO dao,
                                CargaMasivaFlujoService flujoService,
                                CryptoBeflexService crypto) {
        this.parser = new CargaMasivaTxtParser();
        this.dao = dao;
        this.flujoService = flujoService;
        this.crypto = crypto;
    }

    public Map<String, Object> ejecutar(int idEmpresa, int idOperacion, String modo,
                                        MultipartFile archivo, String idTraza) throws Exception {
        validarEntrada(idEmpresa, idOperacion, modo, archivo);
        Map<String, Object> resolucion = flujoService.resolver(idEmpresa, "PANTALLA");
        if (!"B2".equalsIgnoreCase(String.valueOf(resolucion.get("flujo")))) {
            throw new IllegalArgumentException("La pantalla no esta configurada para ejecutar el flujo B2.");
        }

        CargaMasivaTxtDocumento documento = parser.parse(archivo.getBytes());
        Map<String, Object> operacion = dao.obtenerOperacion(idEmpresa, idOperacion);
        int idPlantilla = ((Number) operacion.get("CEIdPlantilla")).intValue();
        String procedimiento = String.valueOf(operacion.get("CEStoredProc"));
        List<Map<String, Object>> campos = dao.obtenerCamposPlantilla(idPlantilla);
        if (campos.isEmpty()) throw new IllegalArgumentException("La plantilla B2 no tiene campos activos.");
        validarEncabezados(documento, campos);

        List<String> log = new ArrayList<>();
        List<Map<String, Object>> resultados = new ArrayList<>();
        Map<String, Map<String, String>> rangos = cargarRangos(campos, idEmpresa);
        log.add("[INICIO] Traza " + idTraza + ". Operacion " + idOperacion
                + ", plantilla " + idPlantilla + ", SP " + procedimiento + ".");
        boolean continuarErrores = "TODOS".equalsIgnoreCase(modo);
        int correctos = 0;
        int errores = 0;

        for (int i = 0; i < documento.getRegistros().size(); i++) {
            int renglon = i + 1;
            Map<String, Object> resultadoFila = new LinkedHashMap<>();
            resultadoFila.put("renglon", renglon);
            try {
                Map<String, String> valores = unir(documento.getNombresCampo(),
                        documento.getRegistros().get(i));
                Map<String, Object> parametros = validarYConvertir(campos, valores, rangos);
                Map<String, Object> respuestaSp = dao.ejecutarOperacion(procedimiento, parametros);
                Map<String, Object> primeraFila = dao.primeraFila(respuestaSp);
                int codigo = soporta(operacion, "Return_Code")
                        ? entero(dao.valor(primeraFila, "Return_Code"), -1) : 0;
                String mensaje = soporta(operacion, "Return_Msg")
                        ? texto(dao.valor(primeraFila, "Return_Msg"), "Sin mensaje del SP")
                        : "Registro procesado correctamente.";
                resultadoFila.put("code", codigo);
                resultadoFila.put("msg", mensaje);
                if (codigo == 0) {
                    correctos++;
                    log.add("[OK] Renglon " + renglon + ": " + mensaje);
                } else {
                    errores++;
                    log.add("[ERROR SP] Renglon " + renglon + ": " + mensaje);
                    if (!continuarErrores) {
                        resultados.add(resultadoFila);
                        break;
                    }
                }
            } catch (Exception e) {
                errores++;
                resultadoFila.put("code", -1);
                resultadoFila.put("msg", mensajeSeguro(e));
                log.add("[ERROR] Renglon " + renglon + ": " + mensajeSeguro(e));
                if (!continuarErrores) {
                    resultados.add(resultadoFila);
                    break;
                }
            }
            resultados.add(resultadoFila);
        }

        Map<String, Object> salida = new LinkedHashMap<>();
        salida.put("idTraza", idTraza);
        salida.put("idEmpresa", idEmpresa);
        salida.put("idOperacion", idOperacion);
        salida.put("idPlantilla", idPlantilla);
        salida.put("procedimiento", procedimiento);
        salida.put("total", documento.getRegistros().size());
        salida.put("procesados", resultados.size());
        salida.put("correctos", correctos);
        salida.put("errores", errores);
        salida.put("resultado", errores == 0 ? "OK" : "CON_ERRORES");
        salida.put("registros", resultados);
        salida.put("log", log);
        return salida;
    }

    private void validarEntrada(int idEmpresa, int idOperacion, String modo, MultipartFile archivo) {
        if (idEmpresa <= 0 || idOperacion <= 0) throw new IllegalArgumentException("Empresa y operacion son obligatorias.");
        if (!"PRIMER_ERROR".equalsIgnoreCase(modo) && !"TODOS".equalsIgnoreCase(modo)) {
            throw new IllegalArgumentException("Modo de ejecucion invalido.");
        }
        if (archivo == null || archivo.isEmpty()) throw new IllegalArgumentException("Seleccione un archivo TXT.");
        String nombre = archivo.getOriginalFilename();
        if (nombre == null || !nombre.toLowerCase().endsWith(".txt")) {
            throw new IllegalArgumentException("Solo se permiten archivos .txt.");
        }
    }

    private void validarEncabezados(CargaMasivaTxtDocumento documento, List<Map<String, Object>> campos) {
        for (Map<String, Object> campo : campos) {
            String nombre = requerido(campo, "CANombreCampo");
            if (!documento.getNombresCampo().contains(nombre.trim())) {
                throw new IllegalArgumentException("La plantilla define el campo '" + nombre
                        + "', pero el TXT no lo incluye.");
            }
        }
    }

    private Map<String, Map<String, String>> cargarRangos(List<Map<String, Object>> campos, int idEmpresa) {
        Map<String, Map<String, String>> rangos = new HashMap<>();
        for (Map<String, Object> campo : campos) {
            if ("Especifico".equals(requerido(campo, "CATipoValor"))) {
                String declaracion = requerido(campo, "CPRangoValores");
                rangos.put(requerido(campo, "CANombreCampo"), dao.obtenerRango(declaracion, idEmpresa));
            }
        }
        return rangos;
    }

    private Map<String, Object> validarYConvertir(List<Map<String, Object>> campos,
                                                   Map<String, String> valores,
                                                   Map<String, Map<String, String>> rangos) {
        Map<String, Object> parametros = new LinkedHashMap<>();
        for (Map<String, Object> campo : campos) {
            String nombre = requerido(campo, "CANombreCampo");
            String valor = valores.get(nombre);
            boolean obligatorio = entero(valor(campo, "CPRequerido"), 0) == 1;
            if (valor == null) throw new IllegalArgumentException("Falta el campo " + nombre + ".");
            if (valor.isEmpty()) {
                if (obligatorio) throw new IllegalArgumentException("El campo " + nombre + " requiere un valor.");
                parametros.put(nombre, ""); // el proceso B2 convierte el nulo opcional en cadena vacia
                continue;
            }
            String regex = texto(valor(campo, "CACaracteresValidos"), "").trim();
            if (!regex.isEmpty() && !Pattern.compile(regex).matcher(valor).find()) {
                throw new IllegalArgumentException("El campo " + nombre + " no cumple el formato configurado.");
            }
            if ("Especifico".equals(texto(valor(campo, "CATipoValor"), ""))) {
                String equivalencia = rangos.getOrDefault(nombre, new HashMap<>()).get(valor);
                if (equivalencia == null) {
                    throw new IllegalArgumentException("El campo " + nombre
                            + " no tiene equivalencia para el valor '" + valor + "'.");
                }
                valor = equivalencia;
            }
            String tipo = requerido(campo, "CATipoDato");
            if ("T".equals(tipo) && entero(valor(campo, "CPEncriptado"), 0) == 1) {
                valor = crypto.encriptar(valor);
                if (valor == null) throw new IllegalArgumentException("No fue posible encriptar " + nombre + ".");
            }
            parametros.put(nombre, convertir(tipo, valor, nombre));
        }
        return parametros;
    }

    private Object convertir(String tipo, String valor, String nombre) {
        try {
            switch (tipo.charAt(0)) {
                case 'T': return valor;
                case 'E': case 'N': case 'B': return Integer.valueOf(valor.trim());
                case 'D': return Date.valueOf(LocalDate.parse(valor.trim(), FECHA_B2));
                case 'M': case '%': case 'F': return new BigDecimal(valor.trim().replace(',', '.'));
                default: throw new IllegalArgumentException("Tipo B2 no reconocido: " + tipo + ".");
            }
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("El campo " + nombre + " no es valido para el tipo " + tipo + ".");
        }
    }

    private Map<String, String> unir(List<String> nombres, List<String> datos) {
        Map<String, String> salida = new LinkedHashMap<>();
        for (int i = 0; i < nombres.size(); i++) salida.put(nombres.get(i), datos.get(i));
        return salida;
    }

    private boolean soporta(Map<String, Object> operacion, String nombre) {
        Object value = valor(operacion, nombre);
        if (value instanceof Boolean) return (Boolean) value;
        if (value instanceof Number) return ((Number) value).intValue() != 0;
        return "true".equalsIgnoreCase(String.valueOf(value)) || "1".equals(String.valueOf(value));
    }

    private Object valor(Map<String, Object> mapa, String nombre) {
        for (Map.Entry<String, Object> entry : mapa.entrySet()) {
            if (nombre.equalsIgnoreCase(entry.getKey())) return entry.getValue();
        }
        return null;
    }

    private String requerido(Map<String, Object> mapa, String nombre) {
        Object value = valor(mapa, nombre);
        if (value == null) throw new IllegalArgumentException("La configuracion B2 no devolvio " + nombre + ".");
        return String.valueOf(value).trim();
    }

    private int entero(Object value, int defecto) {
        if (value instanceof Number) return ((Number) value).intValue();
        try { return value == null ? defecto : Integer.parseInt(String.valueOf(value)); }
        catch (NumberFormatException e) { return defecto; }
    }

    private String texto(Object value, String defecto) { return value == null ? defecto : String.valueOf(value); }
    private String mensajeSeguro(Exception e) {
        String mensaje = e.getMessage();
        return mensaje == null || mensaje.trim().isEmpty() ? "Error no identificado durante la carga." : mensaje;
    }
}
