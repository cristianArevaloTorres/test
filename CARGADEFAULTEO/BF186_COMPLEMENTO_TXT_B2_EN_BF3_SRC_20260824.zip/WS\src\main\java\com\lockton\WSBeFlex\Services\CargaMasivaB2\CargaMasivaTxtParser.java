package com.lockton.WSBeFlex.Services.CargaMasivaB2;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Parser compatible con CargaMasivaDocumento de B2. No persiste el archivo. */
public class CargaMasivaTxtParser {
    public static final int MAX_REGISTROS = 3000;
    public static final int MAX_BYTES = 5 * 1024 * 1024;

    public CargaMasivaTxtDocumento parse(byte[] contenido) {
        if (contenido == null || contenido.length == 0) {
            throw new IllegalArgumentException("El archivo TXT esta vacio.");
        }
        if (contenido.length > MAX_BYTES) {
            throw new IllegalArgumentException("El archivo TXT excede el limite de 5 MB.");
        }

        String texto = decodificar(contenido).replace("\uFEFF", "");
        String[] lineas = texto.split("\\r?\\n", -1);
        int indiceCampos = buscarSeccion(lineas, "@fieldNames:");
        int indiceDatos = buscarSeccion(lineas, "@data:");
        if (indiceCampos < 0) throw new IllegalArgumentException("Falta la seccion @fieldNames:.");
        if (indiceDatos < 0 || indiceDatos <= indiceCampos) {
            throw new IllegalArgumentException("Falta la seccion @data: o esta fuera de orden.");
        }

        String declaracion = valorSeccion(lineas[indiceCampos]);
        List<String> camposArchivo = separarCampos(declaracion);
        if (camposArchivo.isEmpty()) throw new IllegalArgumentException("@fieldNames no contiene campos.");
        validarDuplicados(camposArchivo);

        // B2 usa SortedList: los campos comunes se anexan alfabeticamente.
        Map<String, String> comunesOrdenados = new TreeMap<>();
        int indiceComunes = buscarSeccion(lineas, "@commonFields:");
        if (indiceComunes >= 0 && indiceComunes < indiceCampos) {
            for (int i = indiceComunes + 1; i < lineas.length; i++) {
                String linea = lineas[i];
                if (linea.trim().isEmpty()) break;
                int igual = linea.indexOf('=');
                if (igual <= 0) {
                    throw new IllegalArgumentException("Campo comun invalido en la linea " + (i + 1) + ".");
                }
                String nombre = linea.substring(0, igual);
                if (comunesOrdenados.put(nombre, linea.substring(igual + 1)) != null) {
                    throw new IllegalArgumentException("Campo comun duplicado: " + nombre + ".");
                }
            }
        }

        List<String> nombres = new ArrayList<>(camposArchivo);
        nombres.addAll(comunesOrdenados.keySet());
        validarDuplicados(nombres);
        List<List<String>> registros = new ArrayList<>();
        for (int i = indiceDatos + 1; i < lineas.length; i++) {
            String linea = lineas[i];
            if (linea.trim().isEmpty()) break; // mismo fin de datos que B2
            String[] valoresBase = linea.split("\\|", -1);
            if (valoresBase.length != camposArchivo.size()) {
                throw new IllegalArgumentException("La linea " + (i + 1) + " tiene " + valoresBase.length
                        + " valores y se esperaban " + camposArchivo.size() + ".");
            }
            List<String> valores = new ArrayList<>();
            for (String valor : valoresBase) valores.add(valor);
            valores.addAll(comunesOrdenados.values());
            registros.add(valores);
            if (registros.size() > MAX_REGISTROS) {
                throw new IllegalArgumentException("El TXT excede el limite de 3000 registros.");
            }
        }
        if (registros.isEmpty()) throw new IllegalArgumentException("La seccion @data: no contiene registros.");
        return new CargaMasivaTxtDocumento(nombres, registros,
                new LinkedHashMap<>(comunesOrdenados));
    }

    private String decodificar(byte[] bytes) {
        try {
            CharBuffer chars = StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes));
            return chars.toString();
        } catch (CharacterCodingException e) {
            return new String(bytes, Charset.forName("windows-1252"));
        }
    }

    private int buscarSeccion(String[] lineas, String seccion) {
        for (int i = 0; i < lineas.length; i++) {
            if (lineas[i].trim().toLowerCase().startsWith(seccion.toLowerCase())) return i;
        }
        return -1;
    }

    private String valorSeccion(String linea) {
        int dosPuntos = linea.indexOf(':');
        return dosPuntos < 0 ? "" : linea.substring(dosPuntos + 1).trim();
    }

    private List<String> separarCampos(String valor) {
        List<String> campos = new ArrayList<>();
        for (String campo : valor.split(",", -1)) {
            String limpio = campo.trim();
            if (limpio.isEmpty()) throw new IllegalArgumentException("@fieldNames contiene un nombre vacio.");
            campos.add(limpio);
        }
        return campos;
    }

    private void validarDuplicados(List<String> campos) {
        Map<String, Boolean> vistos = new LinkedHashMap<>();
        for (String campo : campos) {
            if (vistos.put(campo, Boolean.TRUE) != null) {
                throw new IllegalArgumentException("Campo duplicado: " + campo + ".");
            }
        }
    }
}
