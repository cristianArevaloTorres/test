package com.lockton.WSBeFlex.Services.CargaMasivaB2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.lockton.WSBeFlex.DAO.CargaMasivaB2DAO;
import com.lockton.WSBeFlex.Services.CargaMasivaFlujoService;
import com.lockton.WSBeFlex.Services.Crypto.CryptoBeflexService;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

class CargaMasivaB2ServiceTest {
    @Test
    void usaLaPlantillaYElStoredProcedureDeLaConfiguracionB2() throws Exception {
        CargaMasivaB2DAO dao = mock(CargaMasivaB2DAO.class);
        CargaMasivaFlujoService flujo = mock(CargaMasivaFlujoService.class);
        CryptoBeflexService crypto = mock(CryptoBeflexService.class);
        CargaMasivaB2Service service = new CargaMasivaB2Service(dao, flujo, crypto);

        when(flujo.resolver(186, "PANTALLA")).thenReturn(mapa("flujo", "B2"));
        Map<String, Object> operacion = mapa("CEIdPlantilla", 507);
        operacion.put("CEStoredProc", "ff_XCMTitularesAltaCMDeloitte");
        operacion.put("Return_Code", 1);
        operacion.put("Return_Msg", 1);
        when(dao.obtenerOperacion(186, 2)).thenReturn(operacion);
        Map<String, Object> campoEmpresa = campo("EMIdEmpresa", "E", 1);
        Map<String, Object> campoEmpleado = campo("EMNumeroEmpleado", "T", 1);
        when(dao.obtenerCamposPlantilla(507)).thenReturn(Arrays.asList(campoEmpresa, campoEmpleado));

        Map<String, Object> filaSp = mapa("Return_Code", 0);
        filaSp.put("Return_Msg", "Titular registrado");
        Map<String, Object> respuestaSp = mapa("#result-set-1", Arrays.asList(filaSp));
        when(dao.ejecutarOperacion(eq("ff_XCMTitularesAltaCMDeloitte"), anyMap()))
                .thenReturn(respuestaSp);
        when(dao.primeraFila(respuestaSp)).thenReturn(filaSp);
        when(dao.valor(filaSp, "Return_Code")).thenReturn(0);
        when(dao.valor(filaSp, "Return_Msg")).thenReturn("Titular registrado");

        String txt = "@fieldNames: EMIdEmpresa,EMNumeroEmpleado\n@data:\n186|DUMMY001\n";
        MockMultipartFile archivo = new MockMultipartFile("archivo", "carga.txt", "text/plain",
                txt.getBytes(StandardCharsets.UTF_8));

        Map<String, Object> resultado = service.ejecutar(186, 2, "PRIMER_ERROR", archivo, "TRACE-12345678");

        assertEquals("OK", resultado.get("resultado"));
        assertEquals("ff_XCMTitularesAltaCMDeloitte", resultado.get("procedimiento"));
        verify(dao).ejecutarOperacion(eq("ff_XCMTitularesAltaCMDeloitte"), anyMap());
    }

    private static Map<String, Object> campo(String nombre, String tipo, int requerido) {
        Map<String, Object> campo = new LinkedHashMap<>();
        campo.put("CANombreCampo", nombre);
        campo.put("CATipoDato", tipo);
        campo.put("CATipoValor", "Libre");
        campo.put("CACaracteresValidos", "");
        campo.put("CPRangoValores", "");
        campo.put("CPRequerido", requerido);
        campo.put("CPEncriptado", 0);
        return campo;
    }

    private static Map<String, Object> mapa(String clave, Object valor) {
        Map<String, Object> mapa = new LinkedHashMap<>();
        mapa.put(clave, valor);
        return mapa;
    }
}
