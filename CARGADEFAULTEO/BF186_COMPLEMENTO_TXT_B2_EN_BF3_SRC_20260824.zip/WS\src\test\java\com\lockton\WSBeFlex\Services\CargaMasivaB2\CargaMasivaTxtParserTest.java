package com.lockton.WSBeFlex.Services.CargaMasivaB2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;

class CargaMasivaTxtParserTest {
    private final CargaMasivaTxtParser parser = new CargaMasivaTxtParser();

    @Test
    void conservaGramaticaB2YAnexaComunesEnOrdenAlfabetico() {
        String txt = "@commonFields:\nZCampo=Z\nACampo=A\n\n"
                + "@fieldNames: EMNumeroEmpleado,EMNombre1\n"
                + "@data:\n100|ANA\n";

        CargaMasivaTxtDocumento documento = parser.parse(txt.getBytes(StandardCharsets.UTF_8));

        assertEquals(1, documento.getRegistros().size());
        assertEquals("ACampo", documento.getNombresCampo().get(2));
        assertEquals("ZCampo", documento.getNombresCampo().get(3));
        assertEquals("A", documento.getRegistros().get(0).get(2));
        assertEquals("Z", documento.getRegistros().get(0).get(3));
    }

    @Test
    void rechazaRenglonConCantidadDistinta() {
        String txt = "@fieldNames: A,B\n@data:\n1\n";
        assertThrows(IllegalArgumentException.class,
                () -> parser.parse(txt.getBytes(StandardCharsets.UTF_8)));
    }

    @Test
    void primeraLineaVaciaTerminaLosDatosComoB2() {
        String txt = "@fieldNames: A\n@data:\n1\n\n2\n";
        assertEquals(1, parser.parse(txt.getBytes(StandardCharsets.UTF_8)).getRegistros().size());
    }
}
