import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { GLOBAL } from './global';
import * as CryptoJS from '../../../node_modules/crypto-js';
import { FiltrosAccesosSolicitudes } from '../models/filtrosAccesosSolicitudes';
@Injectable({
  providedIn: 'root'
})
export class TitularesService {

  private url: string;
  private url2: string;
  private url5: string;
  public secretKey;
  public iv;
  public filtrosAccesosSolicitudes;

  constructor(private _http: HttpClient) {
    this.url = GLOBAL.url;
    this.url2 = GLOBAL.url2;
    this.url5 = GLOBAL.url5;
    this.secretKey = CryptoJS.enc.Hex.parse(GLOBAL.keyAES256); // 256-bit key                          
    this.iv = CryptoJS.enc.Hex.parse(GLOBAL.keyIv); // Initialization Vector
  }

  private handlerHeaders(types) {
    return new HttpHeaders(types);
  }

  private getData(item: string) {
    try {
      const value = JSON.parse(localStorage.getItem(item));
      return value  ? value : null;
    } catch (error) {
      return null;
    }
  }


  obtenerLogoEmpresas(idEmpresa) {
    return this._http.get(
      `${this.url}empresas/${idEmpresa}/imagen`
    ).toPromise();
  }

  // METODO UTILIZADO PARA OBTENER LOS DATOS DE GETPREVIEWv2
  obtenerDatosEmpleadoCompensaciones(idEmpleado) {
    return this._http.get(
      `${this.url}planesPerfil/datos-inicales/empleado/${idEmpleado}`
    ).toPromise();
  }

  obtenerLeyendaXVigencia(idVigencia) {
    return this._http.get(
      `${this.url}titulares/obtenerLeyendaEmpresa?idVigencia=${idVigencia}`
    ).toPromise();
  }

  // METODO UTILIZADO PARA OBTENER LAS GRAFICAS Y TABLA PRA COMPENSACIONES
  obtenerCompensaciones(numeroEmpleado) {
    // Recuperar datos de acuerdo a la pocicion del arreglo
    const vIdEmpleado = numeroEmpleado;
    const vIdEmpresa = 369;
    const vIdPerfil = 3218;
    return this._http.get(
      `${this.url}compensaciones/empleado/${vIdEmpleado}/empresa/${vIdEmpresa}?idPerfil=${vIdPerfil}`
    ).toPromise();
  }

  obtenerMiCompensacion(idEmpleado) {
    const token = this.getData('tokenB3');
    return this._http.get(
      `${this.url2}compensaciones/mi-compensacion/empleado/${idEmpleado}`,
      { headers: this.handlerHeaders({ authorization: token, token }) }
    ).toPromise();
  }


  obtenerDatosConfiguracion(idEmpresa, idCorporativo, token: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/editarConfiguracion?idEmpresa=${idEmpresa}&idCorporativo=${idCorporativo}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  eliminarConfiguracion(idConfiguracionEnvio, token: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/eliminar?idConfiguracionEnvio=${idConfiguracionEnvio}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    );

  }

  insertarConfiguracionEnvioMantenimiento(idConfiguracionEnvio, fecha, token: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/insertarConfiguracionMantenimiento?idConfiguracionEnvio=${idConfiguracionEnvio}&fecha=${fecha}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  eliminarConfiguracionEnvioMantenimiento(idConfiguracionEnvio, token: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/eliminarConfiguracionMantenimiento?idConfiguracionEnvio=${idConfiguracionEnvio}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  insertarConfiguracionEnvio(idConfiguracion, idVigencia, diaInicial, envioAdministradores, idPeriodicidad, token: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/insertarConfiguracionEnvio?idConfiguracion=${idConfiguracion}&idVigencia=${idVigencia}&diaInicial=${diaInicial}&envioAdministradores=${envioAdministradores}&idPeriodicidad=${idPeriodicidad}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  insertarConfiguracionNotificacionEmpresa(idEmpresa: string, idTipoNotificacionCorreo: string, idPlantilla: string, numeroDias: string, orden: string, idUsuario: string, token: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/insertarConfiguracionNotificacionEmpresa?idEmpresa=${idEmpresa}&idTipoNotificacion=${idTipoNotificacionCorreo}&idPlantilla=${idPlantilla}&numeroDias=${numeroDias}&orden=${orden}&idUsuario=${idUsuario}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  obtenerPlantillaYnotificacionCorreo(idCorporativo: string, idAdm: string, token: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/obtenerPlantillaNotificacionCorreo?idCorporativo=${idCorporativo}&idAdm=${idAdm}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  async getDatos(datos: any) {

    let respuesta : any;
    let datosPersonal: any;

    let http = this._http.get(
      `${this.url}empleados/titular/datos-especificos?numeroEmpleado=${datos.numEmpleado}&idEmpresa=${datos.idEmpresa}`,
      { headers: this.handlerHeaders({ authorization: this.getData('tokenB3') }) }
    ).toPromise();

    await  http.then( resp => {
      respuesta = resp;
    });

    await this.decryptAES_GCM(respuesta.data).then( decryptMessage =>  {
      datosPersonal = decryptMessage;
    })  

    return 
  }

  getTitulares(parametros: any, token: string) {
    return this._http.get(
      `${this.url2}titulares/consultar?IdEmpresa=${parametros.IdEmpresa}&Pantalla=${parametros.Pantalla}&IdPerfil=${parametros.IdPerfil}&Busca=${parametros.Busca}&CampoBusca=${parametros.CampoBusca}&idAdm=${parametros.idAdm}`
      , { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  getTitularesCorpEmpresa(parametros: any, token: string) {
    return this._http.get(
      `${this.url2}titulares/consultarCorpEmp?IdEmpresa=${parametros.IdEmpresa}&Pantalla=${parametros.Pantalla}&IdPerfil=${parametros.IdPerfil}&Busca=${parametros.Busca}&CampoBusca=${parametros.CampoBusca}&idAdm=${parametros.idAdm}`
      , { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  getTitularesBusquedaAvanzada(parametros: any, token: string) {
    let params = `IdCorporativo=${parametros.IdCorporativo}&IdEmpresas=${parametros.IdEmpresas}&Busca=${parametros.Busca}&Operador1=${parametros.Operador1}&CampoBusca=${parametros.CampoBusca}&BusquedaAvanzada=${parametros.BusquedaAvanzada}&OperadorAvanzado=${parametros.OperadorAvanzado}&Busca2=${parametros.Busca2}&Operador2=${parametros.Operador2}&CampoBusca2=${parametros.CampoBusca2}&idAdm=${parametros.idAdm}`;
    return this._http.get(
      `${this.url2}titulares/consultarTitularAvanzado?${params}`
      , { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  getDependientesBusquedaAvanzada(parametros: any, token: string) {
    let params = `IdCorporativo=${parametros.IdCorporativo}&IdEmpresas=${parametros.IdEmpresas}&Busca=${parametros.Busca}&Operador1=${parametros.Operador1}&CampoBusca=${parametros.CampoBusca}&BusquedaAvanzada=${parametros.BusquedaAvanzada}&OperadorAvanzado=${parametros.OperadorAvanzado}&Busca2=${parametros.Busca2}&Operador2=${parametros.Operador2}&CampoBusca2=${parametros.CampoBusca2}&idAdm=${parametros.idAdm}`;
    return this._http.get(
      `${this.url2}titulares/consultarDependienteAvanzado?${params}`
      , { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  getTitularesDefaulteo(parametros: any, token: string) {
    // si es -1 es a nivel corporativo, si es 1 es a nivel empresa
    return this._http.get(
      `${this.url2}titulares/defaulteo?idCorporativo=${parametros.idCorporativo}&idEmpresa=${parametros.idEmpresa}&numEmpleado=${parametros.numEmpleado}&apellidoPaterno=${parametros.apellidoPaterno}&apellidoMaterno=${parametros.apellidoMaterno}&nombreUno=${parametros.nombreUno}&nombreDos=${parametros.nombreDos}`
    ).toPromise();
  }

  getTitularesDefaulteoMultivigencia(parametros: any, token: string) {
    // si es -1 es a nivel corporativo, si es 1 es a nivel empresa
    return this._http.get(
      `${this.url2}titulares/defaulteoMultivigencia?idCorporativo=${parametros.idCorporativo}&idEmpresa=${parametros.idEmpresa}&numEmpleado=${parametros.numEmpleado}&apellidoPaterno=${parametros.apellidoPaterno}&apellidoMaterno=${parametros.apellidoMaterno}&nombreUno=${parametros.nombreUno}&nombreDos=${parametros.nombreDos}&vigencia=${parametros.vigencia}&idAdministrador=${parametros.idAdministrador}`
    ).toPromise();
  }

  getTiposPlanesDefaulteo() {
    return this._http.get(
      `${this.url2}titulares/tiposPlanesDefault`
    ).toPromise();
  }

  getEmpleadosBitacora(parametros: any) {
    return this._http.get(
      `${this.url2}titulares/consultarBitacora?IdEmpresa=${parametros.IdEmpresa}&Pantalla=${parametros.Pantalla}&IdPerfil=${parametros.IdPerfil}&CampoBusca=${parametros.CampoBusca}&Busca=${parametros.Busca}&idAdm=${parametros.idAdm}`
    ).toPromise();
  }
  // Obtener plantillas para titulares y dependientes de carga masiva por empresa
  getOperacionesEmpresa(token: string, idEmpresa: any) {
    return this._http.post(`${this.url2}titulares/op-masiva?idEmpresa=${idEmpresa}`,
      {},
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  getConfiguracionFlujoCarga(token: string, idEmpresa: number) {
    return this._http.get(`${this.url2}carga-masiva/flujo/${idEmpresa}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  guardarConfiguracionFlujoCarga(token: string, idEmpresa: number, configuracion: any) {
    return this._http.put(`${this.url2}carga-masiva/flujo/${idEmpresa}`,
      configuracion,
      { headers: this.handlerHeaders({
        'Content-Type': 'application/json', authorization: token
      }) }
    ).toPromise();
  }

  ejecutarCargaMasivaTxtB2(token: string, idEmpresa: number, idOperacion: number,
                           modo: 'PRIMER_ERROR' | 'TODOS', archivo: File) {
    const formData = new FormData();
    formData.append('idEmpresa', String(idEmpresa));
    formData.append('idOperacion', String(idOperacion));
    formData.append('modo', modo);
    formData.append('archivo', archivo, archivo.name);
    return this._http.post(`${this.url2}carga-masiva/b2/ejecutar`, formData,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  addTitularM(parametros: any, token: string) {
    return this._http.post(
      `${this.url2}titulares/nuevoTM?atributos=${parametros.atributos}&valores=${parametros.valores}`,
      {},
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  addDependienteMsivo(parametros: any, token: string) {
    return this._http.post(`${this.url2}titulares/nuevoDM?atributos=${parametros.atributos}&valores=${parametros.valores}`,
      {},
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }


  addTitularD(atributos: any, valores: any, token: string) {
    return this._http.post(`${this.url2}titulares/nuevoDM?atributos=${atributos}&valores=${valores}`,
      {},
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  addBajaMasivaD(atributos: any, valores: any, token: string) {
    return this._http.post(`${this.url2}titulares/bajaMD?atributos=${atributos}&valores=${valores}`,
      {},
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  bajaMasivatitular(parametros: any, token: string) {
    return this._http.post(
      `${this.url2}titulares/bajaMT?idEmpresa=${parametros.idEmpresa}&eMId=${parametros.eMId}&eMObservaciones=${parametros.eMObservaciones}&eMUsuarioUMod=${parametros.eMUsuarioUMod}&eMIdTitular=${parametros.eMIdTitular}&numeroEmpleado=${parametros.numeroEmpleado}&FechaBaja=${parametros.FechaBaja}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  // metodos para modificacion de titulares
  getPlantillaTitular(parametros: any, token: string) {
    return this._http.get(
      `${this.url2}plantilla/formulario/atributos/dependientes?IdEmpresa=${parametros.IdEmpresa}&IdPerfil=${parametros.IdPerfil}&Pantalla=${parametros.Pantalla}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  // Fin modificar titulares
  consultaIndicadoresporRelacion(idCorporativo: string) {
    return this._http.get(
      `${this.url2}titulares/reportes/kpis?idCorporativo=${idCorporativo}`
    ).toPromise();
  }

  // Modulo de configuracion de envio
  obtenerConfiguracionEnvio(idCorporativo: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/configuracion?idCorporativo=${idCorporativo}`
    ).toPromise();
  }

  obtenerVigenciasPorCorporativo(idCorporativo: string) {
    return this._http.get(
      `${this.url2}titulares/configuracionEnvio/vigenciasPorCorporativo?idCorporativo=${idCorporativo}`,
      { headers: this.handlerHeaders({ authorization: this.getData('tokenB3') }) }
    ).toPromise();
  }

  obtenerPlanesDefaulteo() {
    return this._http.get(
      `${this.url2}titulares/tiposPlanesDefault`
    ).toPromise();
  }
  /**
   *
   * @param idAdm se utiliza para registrar el usuario que defaulteo al empleado verificando que se le haya generado correctamente la solicitud
   * @param idEmpleadoDefaulteado  se utiliza para ver si al empleado se le genero la solicitud
   */
  verificarSolicitudDefaulteado(idAdm, idEmpleadoDefaulteado) {
    return this._http.get(
      `${this.url2}titulares/verificarSolicitudDefaulteada?idAdm=${idAdm}&idEmpleadoDefaulteado=${idEmpleadoDefaulteado}`
    ).toPromise();
  }

  obtenerVigenciaAnterior(idEmpresa) {
    return this._http.get(
      `${this.url2}vigencias/empresa/${idEmpresa}/vigente`
    ).toPromise();
  }

  obtenerVigenciaActual(idEmpresa) {
    return this._http.get(
      `${this.url2}vigencias/empresa/${idEmpresa}/vigencia`
    ).toPromise();
  }

  consultaEmpresasXAdm(idCorporativo: any, idAdmin: any) {
    return this._http.get(
      `${this.url2}empresas/empresasXcorporativoA?idCorporativo=${idCorporativo}&idAdmin=${idAdmin}`
    ).toPromise();
  }

  cambiaEstatusSolicitud(idEstatus: any, comentario: any, idSolicitud: any, usuarioMod: any) {
    return this._http.get(
      `${this.url2}solicitud/cambiaEstatusSol?idEstatus=${idEstatus}&detalleEstatus=${comentario}&idSolicitud=${idSolicitud}&usuarioMod=${usuarioMod}`
    ).toPromise();
  }

  reactivarSolicitud(idEmpresa: any, idEmpleado: any, idSolicitud: any, idAdministrador: any) {
    return this._http.get(
      `${this.url2}solicitud/reactivarSol?idEmpresa=${idEmpresa}&idEmpleado=${idEmpleado}&idSolicitud=${idSolicitud}&idAdministrador=${idAdministrador}`
    ).toPromise();
  }

  getDatosSolicitudXId(idSolicitud: any) {
    return this._http.get(
      `${this.url2}solicitud/datosSolXId?idSolicitud=${idSolicitud}`
    ).toPromise();
  }

  validaFamiliaresEnSolicitud(idEmpresa: any, numeroEmpleado: any, idSoliciutd : any) {
    return this._http.get(
      `${this.url2}solicitud/validaFamiliaresEnSolicitud?idEmpresa=${idEmpresa}&numeroEmpleado=${numeroEmpleado}&idSoliciutd=${idSoliciutd}`
    ).toPromise();
  }



  public getTitular(numeroEmpleado: any, idEmpresa: any, token: any) {
    return this._http.get(
      `${this.url2}titulares/consultarTitular?numeroEmpleado=${numeroEmpleado}&idEmpresa=${idEmpresa}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  public async getDatosMailTiTitular(datos: any, token: string): Promise<any[]> {
    const headers = this.handlerHeaders({ authorization: token });

    try {
      const response = await this._http
        .post<any[]>(`${this.url2}titulares/datosMailTitular`, datos, { headers })
        .toPromise();
      return response;
    } catch (error) {
      console.error('Error en getDatosMailTiTitular:', error);
      throw error;
    }
  }

  public async getDatosMailDependiente(datos: any, token: string): Promise<any[]> {
    const headers = this.handlerHeaders({ authorization: token });

    try {
      const response = await this._http
        .post<any[]>(`${this.url2}titulares/datosMailDependiente`, datos, { headers })
        .toPromise();
      return response;
    } catch (error) {
      console.error('Error en getDatosMailDependiente:', error);
      throw error;
    }
  }  

  public getDatosEstadisticasEmpresa(filtro: any, idEmpresa: any, idPerfil: any) {
    return this._http.get(
      `${this.url2}titulares/reporteSolicitudesV3?idCorporativo=${filtro.idCorporativo}&idEmpresa=${idEmpresa}&idPerfil=${idPerfil}&idVigencia=${filtro.vigencia}&fechaInicio=${filtro.fechaInicio}:00&fechaFinal=${filtro.fechaFin}:00`
    ).toPromise();
  }

  public generarReporte(idUsuario,idEmpresa,idCorporativo,idPerfil,vigencias,fechaIni,fechaFin,nomAdm,nomEmp,email,token) {
      this.filtrosAccesosSolicitudes = new FiltrosAccesosSolicitudes(idUsuario,idEmpresa,idCorporativo,idPerfil,vigencias,fechaIni,fechaFin,nomAdm,nomEmp,email);
      const data = btoa(
      new TextEncoder().encode(JSON.stringify(this.filtrosAccesosSolicitudes))
      .reduce((data, byte) => data + String.fromCharCode(byte), '')
      );
      return this._http.post<any>(
          `${this.url5}solicitarReporte/6`, data , { headers: this.handlerHeaders(token) }).toPromise();
  }

  // metodos para funcionalidad de defaulteo
  public obtenerPlanesBasicos(idUsuario, idPerfil, idEmpresa) {
    return this._http.get(
      `${this.url2}plan/planesBasicos/${idEmpresa}/tarifaCosto?idPerfil=${idPerfil}&idEmpleado=${idUsuario}`
    ).toPromise();
  }

  public obtenerPlanesVienciaAnterior(idUsuario, idVigenciaAnterior, idEmpresa) {
    return this._http.get(
      `${this.url2}titulares/planesVigenciaAnterior?idUsuario=${idUsuario}&idVigencia=${idVigenciaAnterior}&idEmpresa=${idEmpresa}`
    ).toPromise();
  }

  public ocultaBtnSolicitudes(idEmpresa: any, idRol: any) {
    return this._http.get(
      `${this.url2}solicitud/ocultaBtnAdmSolicitudes?idEmpresa=${idEmpresa}&idRol=${idRol}`
    ).toPromise();
  }

  // PLANTILLAS CORREOS TITULARES

  // ALTA TITULARES
  getCorreosGrupoAltaDep(parametros: any, token: string) {
    return this._http.get(
      `${this.url2}correosGrupos/plantilla/2/empresa/${parametros}?tipoNegocio=0`
    ).toPromise();
  }

  getPlantillaAltaDep(token2: string) {
    return this._http.get(`${this.url2}plantilla/correo/2`,
      { headers: this.handlerHeaders({ authorization: this.getData('tokenB3') }) }
    ).toPromise();
  }

  // MODIFICACIÓN DEPENDIENTES
  getCorreosGrupoModDep(parametros: any, token: string) {
    return this._http.get(`${this.url2}correosGrupos/plantilla/6/empresa/${parametros}?tipoNegocio=0`).toPromise();
  }

  getPlantillaModDep(token2: string) {
    return this._http.get(`${this.url2}plantilla/correo/6`,
      { headers: this.handlerHeaders({ authorization: this.getData('tokenB3') }) }
    ).toPromise();
  }

  editTitular(parametros: any, idEmpleado, token: string) {
    return this._http.put(
      `${this.url}admindependientes/empleado/${idEmpleado}/titular`, parametros,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  getConfPassword(idEmpresa, token) {
    return this._http.get(`${this.url}titulares/getConfPassword?idEmpresa=${idEmpresa}`,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  getRolDefaultPorEmpresa(idEmpresa, token) {
    return this._http.get(`${this.url}rol/empresa/${idEmpresa}/default`,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  getRolPorPerfil(idEmpresa, idPerfil, token) {
    return this._http.get(`${this.url}rol/ObtenerRolXPerfil?idEmpresa=${idEmpresa}&idPerfil=${idPerfil}`,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  getOpcionesCambioEmpresa(idUsuario, idCorporativo, token){
    return this._http.get(`${this.url}titulares/opcionesCambioEmpresa/${idCorporativo}/${idUsuario}`,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }
  
  getOpcionesCambioEmpresaV3(idUsuario, idCorporativo, IdEmpresaCurrent, token){
    return this._http.get(`${this.url}titulares/opcionesCambioEmpresa_v3/${idCorporativo}/${idUsuario}/${IdEmpresaCurrent}`,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  updateEmpresaTitular(parametros: any, token: string) {
    return this._http.post(
      `${this.url}titulares/cambioEmpresaTitular/`,
      parametros,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  async getValidaExisteEnEmpresa(NumeroEmpleado: any , EMIdEmpresa: any ){

    return this._http.get(`${this.url}titulares/validarExisteEmpleadoEnEmpresa/${NumeroEmpleado}/${EMIdEmpresa}`).toPromise();

  }

  async ObtenerCatalogoTablaEncabezado(EMIdEmpresa){

    return this._http.get<any>(`${this.url}titulares/ObtenerCatalogoTablaEncabezado/${EMIdEmpresa}`).toPromise();

  }

  async obtenerDetalleEncabezadoPorEncabezadoYEmpresa(EMIdEmpresa, Encabezado){

    return this._http.get(`${this.url}titulares/obtenerDetalleEncabezadoPorEncabezadoYEmpresa/${EMIdEmpresa}/${Encabezado}`).toPromise();

  }
  // Logs carga masiva
  public addReporteLog(reporteMasiva: any) {
    return this._http.post(
      `${this.url2}titulares/crearRegistroLog`, reporteMasiva).toPromise();
  }

  public getReportesCargaMasiva(paramsBuscar) {
    return this._http.get<any[]>(`${this.url2}titulares/obtenerRegistroLog`, {observe: "body", headers: {'Content-Type': 'application/json'}, params: paramsBuscar}).toPromise();
  }

  public getReporteTextoLog(idPlantilla) {
    return this._http.get<any[]>(
      `${this.url2}titulares/obtenerTextoLog?idPlantilla=${idPlantilla}`,
    ).toPromise();
  }

  editNumeroEmpleadoTitular(parametros: any, token: string) {
    return this._http.post(
      `${this.url}titulares/editarNumeroEmpleadoTitular`, parametros,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  reactivarEmpleado(parametros: any, token: string) {
    return this._http.post(
      `${this.url}titulares/reactivacionEmpleado`, parametros,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  ejecutarCargaMasiva(parametros: any, token: string) {
    return this._http.post(
      `${this.url2}titulares/ejecutarCargaMasiva?atributos=${parametros.atributos}&valores=${parametros.valores}`,
      {},
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  ejecutarTransferenciaMasivaEmpleado(parametros: any, token: string) {
    return this._http.post(
      `${this.url2}titulares/runTransferenciaMasiva?atributos=${parametros.atributos}&valores=${parametros.valores}`,
      {},
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  async decryptAES_GCM(text) {
    try {
        // Convertir la clave secreta de hexadecimal a ArrayBuffer
        const secretKeyBytes = new Uint8Array(this.secretKey.words.flatMap(word => [
          (word >> 24) & 0xFF,
          (word >> 16) & 0xFF,
          (word >> 8) & 0xFF,
          word & 0xFF
      ]));

        // Decodificar el texto cifrado desde Base64
        const ivAndCipherText = Uint8Array.from(atob(text), c => c.charCodeAt(0));

        // Extraer el IV (primeros 12 bytes)
        const ivBytes = ivAndCipherText.slice(0, 12);

        // Extraer el texto cifrado (resto de los bytes)
        const cipherTextBytes = ivAndCipherText.slice(12);

        // Importar la clave para AES-GCM
        const secretKey = await crypto.subtle.importKey(
            "raw",
            secretKeyBytes,
            { name: "AES-GCM" },
            false,
            ["decrypt"]
        );

        // Desencriptar
        const plainTextBytes = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: ivBytes },
            secretKey,
            cipherTextBytes
        );

        // Convertir a texto
        const uint8Array = new Uint8Array(plainTextBytes);
        let decodedString = '';

        for (let i = 0; i < uint8Array.length; i++) {
          decodedString += String.fromCharCode(uint8Array[i]);
        }
        
        
        return JSON.parse(decodedString)
    } catch (error) {
        console.error("Error al desencriptar:", error);
        throw error;
    }
  }

  /**
   * INC002/RF019: Obtiene datos de la ultima solicitud para una lista de empleados
   * @param idEmpleados String con IDs separados por coma (ej: "1,2,3,4")
   * @param token Token de autorizacion
   * @returns Promise con lista de datos de solicitudes
   */
  obtenerUltimasSolicitudesEmpleados(idEmpleados: string, token: string): Promise<any[]> {
    const url = `${this.url2}titulares/obtenerUltimasSolicitudes?idEmpleados=${idEmpleados}`;
    console.log('INC002 DEBUG URL:', url);
    console.log('INC002 DEBUG Token:', token ? 'Token presente' : 'Token NULO');
    return this._http.get<any[]>(
      url,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  getTitularesMultiVigAvanzado(parametros: any, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.post<any>(
      `${this.url2}titulares/busquedaMultivigenciaAvanzada`
      , parametros
      ,{headers}
    ).toPromise();
  }

  // CREA06 casos especiales: ejecutar el layout (defaulteo real por tipoDefaulteo) -> { total, exitosos, errores, detalle }
  ejecutarDefaulteoCasosEspeciales(req: any, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.post<any>(
      `${this.url2}titulares/ejecutarDefaulteoCasosEspeciales`
      , req
      ,{headers}
    ).toPromise();
  }

  // CREA06 casos especiales (async): arranca el lote en background -> { idLog, estado:'EN_PROCESO', total }.
  // Evita el timeout del gateway/CDN con lotes grandes; el resultado se obtiene por polling del estado.
  ejecutarDefaulteoCasosEspecialesAsync(req: any, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.post<any>(
      `${this.url2}titulares/ejecutarDefaulteoCasosEspecialesAsync`
      , req
      ,{headers}
    ).toPromise();
  }

  // CREA06 casos especiales (async): estado del lote. Mientras corre trae el avance; al terminar
  // incluye 'resultado' = { total, exitosos, errores, detalle } para pintar el grid.
  estadoDefaulteoCasosEspeciales(idLog: number, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.get<any>(
      `${this.url2}titulares/estadoDefaulteoCasosEspeciales/${idLog}`
      ,{headers}
    ).toPromise();
  }

  // CREA06 R2 (minuta 22-jun): deteccion previa al cargar layout -> { total, noSeProcesan, detalle }
  detectarCambioPerfilCasosEspeciales(req: any, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.post<any>(
      `${this.url2}titulares/detectarCambioPerfilCasosEspeciales`
      , req
      ,{headers}
    ).toPromise();
  }

  async encryptAES_GCM(text) {
    
      const secretKeyBytes = new Uint8Array(this.secretKey.words.flatMap(word => [
        (word >> 24) & 0xFF,
        (word >> 16) & 0xFF,
        (word >> 8) & 0xFF,
        word & 0xFF
      ]));
      
      // Generar un IV aleatorio (12 bytes es común para GCM)
      const iv = crypto.getRandomValues(new Uint8Array(12));
      
      // Importar la clave secreta
      const key = await crypto.subtle.importKey(
          "raw",
          secretKeyBytes,
          { name: "AES-GCM" },
          false,
          ["encrypt"]
      );
      
      // Cifrar el texto
      const encoder = new TextEncoder();
      const encrypted = await crypto.subtle.encrypt(
          {
              name: "AES-GCM",
              iv: iv
          },
          key,
          encoder.encode(text)
      );
      
      // Combinar IV y texto cifrado en un solo array
      const combined = new Uint8Array(iv.length + encrypted.byteLength);
      combined.set(iv, 0);
      combined.set(new Uint8Array(encrypted), iv.length);
      
      // Codificar en Base64
      return btoa(String.fromCharCode(...combined));
  }

  // ==================== REENVIO DE SOLICITUDES ====================

  /**
   * Valida si una solicitud puede ser reenviada
   * @param idSolicitud ID de la solicitud
   * @param token Token de autorización
   * @returns Promise con datos de validación
   */
  validarReenvioSolicitud(idSolicitud: number, token: string) {
    return this._http.get(
      `${this.url2}reenvio/validar/${idSolicitud}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  /**
   * Realiza el reenvío individual de una solicitud
   * @param idSolicitud ID de la solicitud
   * @param idUsuario ID del usuario que realiza el reenvío
   * @param token Token de autorización
   * @returns Promise con resultado del reenvío
   */
  reenviarSolicitudIndividual(idSolicitud: number, idUsuario: number, token: string) {
    const body = {
      idSolicitud: idSolicitud,
      idUsuario: idUsuario,
      tipoReenvio: 1
    };
    return this._http.post(
      `${this.url2}reenvio/individual`,
      body,
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  /**
   * Realiza el reenvío masivo de múltiples solicitudes
   * @param registros Array de registros con idEmpresa, idSolicitud, idEmpleado
   * @param idUsuario ID del usuario que realiza el reenvío
   * @param token Token de autorización
   * @returns Promise con resultado del reenvío masivo
   */
  reenviarSolicitudMasivo(registros: any[], idUsuario: number, token: string) {
    const body = {
      registros: registros,
      idUsuario: idUsuario
    };
    // CREA25 INC-3: ahora arranca el lote en background y devuelve { idLote, estado, total }.
    return this._http.post(
      `${this.url2}reenvio/masivo`,
      body,
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  /**
   * CREA25 INC-3: consulta el estado de un lote de reenvío masivo (polling).
   * Devuelve { estado, procesados, total, totalExitosos, totalErrores, resultado? }.
   */
  estadoReenvioMasivo(idLote: number, token: string) {
    return this._http.get(
      `${this.url2}reenvio/masivo/estado/${idLote}`,
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  /**
   * Registra un log de reenvío
   * @param logData Datos del log
   * @param token Token de autorización
   * @returns Promise con ID del log creado
   */
  registrarLogReenvio(logData: any, token: string) {
    return this._http.post(
      `${this.url2}reenvio/log`,
      logData,
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  /**
   * Descarga el layout Excel para reenvío masivo desde el backend
   * @param token Token de autorización
   * @returns Promise con blob del archivo Excel
   */
  descargarLayoutReenvioMasivo(token: string) {
    return this._http.get(
      `${this.url2}reenvio/layout-template`,
      {
        headers: this.handlerHeaders({ authorization: token }),
        responseType: 'blob'
      }
    ).toPromise();
  }

  /**
   * Guarda la ruta del PDF de una solicitud
   * @param idSolicitud ID de la solicitud
   * @param rutaPdf Ruta del PDF generado
   * @param token Token de autorización
   * @returns Promise con resultado de la operación
   */
  guardarRutaPdf(idSolicitud: number, rutaPdf: string, token: string) {
    return this._http.post(
      `${this.url2}reenvio/pdf/${idSolicitud}`,
      { rutaPdf: rutaPdf },
      { headers: this.handlerHeaders({ 'Content-Type': 'application/json', authorization: token }) }
    ).toPromise();
  }

  /**
   * Obtiene la ruta del PDF de una solicitud
   * @param idSolicitud ID de la solicitud
   * @param token Token de autorización
   * @returns Promise con la ruta del PDF
   */
  obtenerRutaPdf(idSolicitud: number, token: string) {
    return this._http.get(
      `${this.url2}reenvio/pdf/${idSolicitud}`,
      { headers: this.handlerHeaders({ authorization: token }) }
    ).toPromise();
  }

  getCambiosCaliBusquedaAvanzada(parametros: any, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.post<any>(
      `${this.url2}titulares/consultaCambiosCaliAvanzada`
      , parametros
      ,{headers}
    ).toPromise();
  }

  getTitularesMovimientoAvanzado(parametros: any, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.post<any>(
      `${this.url2}titulares/consultarTitularMovimientosAvanzado`
      , parametros
      ,{headers}
    ).toPromise();
  }

  async ObtenerPlantillaTransferenciaIndividual(EMIdEmpresa){
    return this._http.get<any>(`${this.url}titulares/ObtenerPlantillaTransferenciaIndividual/${EMIdEmpresa}`).toPromise();
  }

  async obtenerValidacionSolicitudEmpleado(parametros: any, token: string) {
    return this._http.post(
      `${this.url}titulares/validaSolicitudExistente/`,
      parametros,
      { headers: this.handlerHeaders({ token }) }
    ).toPromise();
  }

  // Metodo general para la busqueda de titulares y dependientes
  consultarTitularGeneralAvanzado(parametros: any, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.post<any>(
      `${this.url2}titulares/consultarTitularGeneralAvanzado`
      , parametros
      ,{headers}
    ).toPromise();
  }

  // Metodo general para la busqueda de titulares y dependientes
  consultarTitularStatementAvanzado(parametros: any, token: string) {
    const headers = this.handlerHeaders({ authorization: token });
    return this._http.post<any>(
      `${this.url2}titulares/consultarTitularStatementAvanzado`
      , parametros
      ,{headers}
    ).toPromise();
  }
}
