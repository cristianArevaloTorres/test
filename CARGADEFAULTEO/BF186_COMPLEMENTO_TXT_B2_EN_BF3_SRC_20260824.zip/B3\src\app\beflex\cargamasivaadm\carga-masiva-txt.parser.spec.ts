import { CargaMasivaTxtParser } from './carga-masiva-txt.parser';

describe('CargaMasivaTxtParser', () => {
  it('lee el formato B2 con campos comunes y multiples registros', () => {
    const documento = CargaMasivaTxtParser.parse([
      '@commonFields:',
      'EMIdEmpresa=186',
      '',
      '@fieldNames:EMNumeroEmpleado,EMNombre1',
      '@data:',
      'TXT001|ANA',
      'TXT002|LUIS'
    ].join('\r\n'));

    expect(documento.campos).toEqual(['EMNumeroEmpleado', 'EMNombre1']);
    expect(documento.camposComunes.EMIdEmpresa).toBe('186');
    expect(documento.registros.length).toBe(2);
  });

  it('rechaza renglones cuyo numero de valores no coincide', () => {
    expect(() => CargaMasivaTxtParser.parse([
      '@fieldNames:Campo1,Campo2',
      '@data:',
      'UNO'
    ].join('\n'))).toThrowError(/se esperaban 2/);
  });

  it('rechaza campos duplicados', () => {
    expect(() => CargaMasivaTxtParser.parse([
      '@fieldNames:Campo1,campo1',
      '@data:',
      'UNO|DOS'
    ].join('\n'))).toThrowError(/repetido/);
  });
});
