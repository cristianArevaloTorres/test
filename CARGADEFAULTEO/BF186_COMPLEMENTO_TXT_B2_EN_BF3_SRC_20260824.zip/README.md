# Complemento BF3: ejecución de carga B2 por TXT

Este paquete complementa el código previamente entregado. Permite seleccionar y ejecutar desde BF3 un archivo TXT con el contrato de carga masiva de B2, sin depender de la pantalla legacy.

## Qué se implementó

- BF3 permite descargar la guía TXT, seleccionar el archivo, validarlo y ejecutar la carga.
- El WS vuelve a validar el archivo completo; la validación del navegador es únicamente informativa.
- El nombre del stored procedure no llega desde la pantalla ni está fijo en el código productivo.
- Para cada empresa y operación, el WS exige una sola configuración activa en `ff_CargaMasivaOperacionEmpresa`.
- Después consume los mismos objetos usados por B2:
  - `ff_CCMOperacionPropiedades @IdOperacion, @IdEmpresa`.
  - `ff_CPlantillaCampos @IdPlantilla`.
  - El `CEStoredProc` y la plantilla devueltos por esa configuración.
- Se conservan las reglas B2 de campos requeridos, expresión regular, tipo de dato, rango específico, equivalencias, cifrado, `Return_Code`, `Return_Msg` y los modos detenerse en el primer error o continuar con todos.
- Cada ejecución devuelve un identificador de traza y un resultado por renglón. El archivo no se guarda en disco.
- Se aceptan como máximo 3,000 registros y 5 MB por archivo.

## Instalación

Se deben copiar o reemplazar los archivos respetando las carpetas `FRONT` y `WS` del ZIP.

1. Desplegar primero el WS Java.
2. Desplegar después el front BF3.
3. No es necesario borrar archivos existentes.
4. Este complemento no contiene instalación SQL: reutiliza la tabla, plantillas, validaciones y procedimientos B2 que ya existen en la base.

El cambio no es únicamente de front. Sin el WS nuevo, BF3 puede leer el TXT localmente, pero no debe ni puede ejecutar de forma segura los procedimientos B2.

## Configuración esperada

La operación elegida debe tener exactamente una fila activa para la empresa. Por ejemplo, la consulta de diagnóstico es:

```sql
SELECT *
FROM dbo.ff_CargaMasivaOperacionEmpresa
WHERE CEIdEmpresa = 186
ORDER BY CEIdOperacion, CEIdPlantilla;
```

Las filas con `CEIdEstatus <> 1` no se ejecutan. Si hay cero o más de una filas activas para la misma empresa y operación, el WS detiene la carga antes de invocar cualquier procedimiento.

## Endpoint agregado

`POST /beflex/carga-masiva/b2/ejecutar`

Formulario multipart:

- `idEmpresa`
- `idOperacion`
- `modo`: `PRIMER_ERROR` o `TODOS`
- `archivo`: TXT

El endpoint valida token, acceso del usuario a la empresa y que el flujo de pantalla esté resuelto como B2.

## Verificación realizada

- Compilación aislada con Java 11 de las clases nuevas: correcta.
- Build Angular de producción ES2015/ES5: correcto.
- Comprobación TypeScript posterior al build: correcta.
- Pruebas del parser TXT: 3 correctas.
- Prueba del servicio y resolución del procedimiento configurado: 1 correcta.
- Total: 4 pruebas, 0 fallas y 0 errores.

La construcción Maven completa del proyecto sigue dependiendo de un WSDL privado en `172.17.0.59`; desde este ambiente esa descarga terminó por timeout antes de la fase normal de compilación. No se ejecutó una carga real contra la base compartida, para no insertar datos de prueba ni dejar movimientos. Las pruebas automatizadas simulan la capa de datos y verifican que se use la configuración B2.
