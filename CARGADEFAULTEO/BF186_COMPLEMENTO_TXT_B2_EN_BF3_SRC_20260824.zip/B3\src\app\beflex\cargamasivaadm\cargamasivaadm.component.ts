import { Component, OnInit, DoCheck, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

import swal from 'sweetalert2';
import { SafeResourceUrl } from '@angular/platform-browser';

import { GLOBAL } from '../../services/global';
import { EmpleadoService } from '../../services/empleado.service';
import { MenuRol } from '../../models/menurol';
import { EmpresaComboService } from '../../services/empresas.service';

import { dependientePlantillaForm } from '../../models/dependientePantillaForm';
import { dependientePlantillaFormAtr } from '../../models/dependientePantillaFormAtr';
import { dependienteDel } from '../../models/dependienteDel';
import { dependientePost } from '../../models/dependientePost';
import { DependienteService } from '../../services/dependiente.service';
import { dependienteParentesco } from '../../models/dependienteParentesco';

import { ReporteCifrasControlService } from '../../services/cifrasControl/reporte-cifras-control.service';

import { Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Bitacora } from '../../services/bitacora.service';

import readXlsxFile from 'read-excel-file';
import * as FileSaver from 'file-saver';

import { TitularesService } from '../../services/titulares.service';
import { ExcelService } from '../../services/excel.service';
import { Sesion } from '../../services/sesion.service';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MenusService } from 'src/app/services/menus.service';
import { DocumentosPerService } from 'src/app/services/documentosPer/documentos-per.service';
import {DomSanitizer} from '@angular/platform-browser';
import { saveAs } from 'file-saver';
import { CargaMasivaTxtDocumento, CargaMasivaTxtParser } from './carga-masiva-txt.parser';

declare var $: any;

@Component({
  selector: 'app-cargamasivaadm',
  templateUrl: './cargamasivaadm.component.html',
  styleUrls: ['./cargamasivaadm.component.css']
})
export class CargamasivaadmComponent implements OnInit, DoCheck, OnDestroy {

  public atributosArchivo;
  public title: string;
  public fullIdentity;
  public identity;
  public token;
  public trustUrl2: SafeResourceUrl;
  public estilo;
  public url3 = '';
  public SexhasChanged = false;
  public menusEmpleado;
  public status;
  public obParentesco: dependienteParentesco;
  public formularioDep: dependientePlantillaForm;
  public formularioAtrib: dependientePlantillaFormAtr;
  public dependienteInsert: dependientePost;
  public dependienteDel: dependienteDel;
  public atributos;
  public atributosCrear;
  public atributosCrear2;
  public atributosCrearDep;
  public atributosBajaT;
  public atributosBajaD;
  public atributosModificarD;
  public atributosModificarT;
  public datosPerfil;
  public datosTabla;
  public datosTabla2 = [null];
  public cabeceraTabla;
  public parentesco;
  public parentescoC;
  public parentescoAll;
  public verSeleccion;
  public opcionSeleccionado;
  public verSeleccion2;
  public verSeleccion3;
  public verSeleccion4;
  public opcionSeleccionado2;
  public opcionSeleccionado3;
  public opcionSeleccionado4;
  public comboSexo;
  public comboPerfiles;
  public comboOperaciones;
  public comboOperacionesBackup;
  public parentescoPerfil: dependienteParentesco;
  public titularAll;
  public actualizarDep;
  public menurol: MenuRol[];
  public btnAgregarDep;
  public iconBorrar;
  public iconEditar;
  public parar = false;
  private to;
  public mostrarBotones = 2;
  public atributosEditar;
  public deps = [];
  public encabezados = [];
  public valorEncabezados = [];
  public rerporteCargaMasiva = [];
  public nombreReporteTxt = '';
  public fechaInicioReporte = '';
  public catalogoTextoLog = [];

  // Formulario busqueda log
  public busqueda = {
    "tipoOperacion": '3', 
    "empresa": '0', 
    "buscar":'',
    "fechaInicio": "",
    "fechaFin": "",
    "idEmpresa": ''
  };

  public comboEmpresaModal = [];

  /* Resultado de consulta de archivos */
  public tablaArchivos;
  public consultaSinDatos = true;
  public mostrarDatosTabla = false;
  public errorBus = {"buscar": false};
  public leyenda = '';
  public url = '';
  public generoConsulta = false;

   /* PAGINADO BUSQUEDA EMPLEADO */
  public pageE = 1;
  public pageSizeE = 10;
  public collectionSizeE = 0;
  public datosE: any[] = [];
  public pageD = 1;
  public pageSizeD = 10;
  public collectionSizeD = 0;
  public datosD: any[] = [];

  public fechaInicioMin = '';
  public fechaInicioMax = '';
  public fechaFinMin = '';
  public fechaFinMax = '';
  
  // Validar resultado transaccion
  public exitoAlGuardar = 0;

  public mail = { 'to': [], 'from': [], 'subject': [], 'text': [], 'cc': [], 'bcc': [] };
  private plantillaSend;
  private sujeto;
  private bodyHTML;
  public datosMail = [];
  public objetosPlantillaMail = { 'datosActuales': [], 'valores': [] };
  public parametroValidaParentesco;
  public activarDocumentoRequerido;
  public agreDoc;
  public dateForm: FormGroup;
  public form: FormGroup;
  public tablaForm: FormGroup;
  public tablaForm2: FormGroup;
  public tablaFormEditar: FormGroup;
  public idEmpleado;
  public element: HTMLElement;
  public actualizarTabla = true;

  private idPagina = '380';
  private paginaActual;
  private ipPrivada;
  public datosArchivo;
  public input;
  public modoEjecucion = 2;
  public renglones;
  public archivoCargado = false;
  public archivoError = false;
  public empresas;
  public loadEditar;

  private listaResultados: any[] = [];
  public mostrarReporte = false;
  public mostrarMensajeReporte = false;
  private nombreDocumento: string;
  public atributosCatalogo = [];
  public catalogos = [];
  public posReco = 0;
  public catalogoPerfil;
  public catalogoRegimen;
  public catalogoPlanes;
  public catalogoEstados;
  public empresaPerfiles;
  public empresaRegimenes;
  public catalogosPersonalizados = [];
  public plantillaActual = 0;
  public errorEntrada = false;
  public error = false;
  public accesoSistema = 1;
  public parametroAcceso: string = null;
  public configuracionFlujo: any = {
    idEmpresa: null,
    flujoPantalla: 'B3',
    flujoAutomatico: 'B2',
    configurado: false
  };
  public cargandoFlujo = false;
  public guardandoFlujo = false;
  public idTrazaCarga = '';
  public estadoTrazaCarga = 'SIN INICIAR';
  public mostrarTrazaCarga = true;
  private trazaPersistida = false;
  private trazaRespaldando = false;
  public archivoTxtB2: File = null;
  public documentoTxtB2: CargaMasivaTxtDocumento = null;
  public procesandoTxtB2 = false;
  public nombreArchivoTxtB2 = 'Ningun archivo seleccionado';

  // Catalogos 
  public catalogoOficina;
  public catalogoArea;
  public catalogoCentroCostos;
  public catalogoTipoEmpleado;
  public catalogoVIP;
  public catalogoCompensacion;
  public empresaOficina;
  public empresaArea;
  public empresaCentroCostos;
  public empresaTipoEmpleado;
  public empresaVIP;
  public empresaCompensacion;

  public iconoAyuda;
  public textAyuda = 'Texto de ayuda Cargas Masivas.';
  public _url;

  public catalogosCargadosOpc = 0;
  public datosOpe;
  public estadosFiscales;

  public boolEnvia = false;
  public destinatarios = [];
  public correoAdmin = 'BeFlex@mx.lockton.com';

  public parentescoval;
  public nodependientes;

  /* Variables transferencia de empleados */
  public opcionSolicitudList = [
    { 'key': 'Defaulteo solicitud', 'value': 1 }
    ,{ 'key': 'Rechazo solicitud', 'value': 3 }
    ,{ 'key': 'Regenerar solicitud', 'value': 4 }
    ,{ 'key': 'No aplica', 'value': 0 }
  ];
  public opcionSeleccionSolicitudCat = [
    { '': 'ff_CMCSeleccionUsuario' }
    ,...this.opcionSolicitudList
  ];

  /* Variables carga compensacion por empleado */
  public tipoCargaCompensacion = [
    { 'key': 'Alta/Actualización', 'value': 1 }
    ,{ 'key': 'Baja', 'value': 2 }
  ];
  public tipoCargaCompensacionCat = [
    { '': 'ff_CMCTipoCargaComp' }
    ,...this.tipoCargaCompensacion
  ]

  constructor(
    private _empleadoService: EmpleadoService,
    private _titularesService: TitularesService,
    public _excelService: ExcelService,
    private _dependienteService: DependienteService,
    private _router: Router,
    private _empresaService: EmpresaComboService,
    private _bitacora: Bitacora,
    @Inject(DOCUMENT) private document: Document,
    private _sesion: Sesion,
    public _cifrasControlService: ReporteCifrasControlService,
    public _menus: MenusService,
    private _docPerService: DocumentosPerService,
    private sanitizer:DomSanitizer,
    private _HttpClient: HttpClient,
  ) {
    this.title = 'Titulares';
    this.formularioAtrib = new dependientePlantillaFormAtr('', '', '');
    this.formularioDep = new dependientePlantillaForm('', '', '', '');
    this.obParentesco = new dependienteParentesco('', '');
    this.dependienteInsert = new dependientePost('', '', '', '');
    this.dependienteDel = new dependienteDel('', '', '', '', '', '', '');
    this.parentescoPerfil = new dependienteParentesco('', '');
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();

    if (this.identity) {
      this.identity.reseteo ? (!this.identity.cambio ? this._router.navigate(['/pages/home']) : this._router.navigate(['/pages/home'])) : null;
    }

    this.datosArchivo = '<p>Reporte--</p><br>';
    this._url = GLOBAL.url;
    this.url = GLOBAL.url3;
  }

  async ngOnInit() {
    this.identity = this._empleadoService.getIdentity();
    this.token = this._empleadoService.getToken();
    try {
      await this._sesion.comprobarSession(this.token);
      if (this.identity) {
        if (localStorage.getItem('isAdmin') !== null && localStorage.getItem('isAdmin') !== undefined) {
          parseInt(localStorage.getItem('isAdmin')) === 1 ? this.fullIdentity = await this._empleadoService.getDatos(this.identity) : this.alertRetryLogin();
        } else {
          this.alertRetryLogin();
        }
      }
    } catch (error) {
      if (error === 'Unauthorized') {
        this.alertRetryLogin();
      }
    }


    if (this.identity) {
      this.paginaActual = this.document.location.href;
      this.ipPrivada = localStorage.getItem('myIP') || '0.0.0.0';
      const parametroVitacora = {
        idPagina: this.idPagina, id: this.identity.id, ipPrivada: encodeURIComponent(this.ipPrivada),
        url: encodeURIComponent(this.paginaActual), idEmpresa: this.identity.idEmpresa, nombrePagina: 'cargamasivaadm.component.html'
      };
      try {
        await this._bitacora.registrarBitacora(parametroVitacora);
      } catch (error) { }
    }
    if (!this.token) {
      this.logout();
    } else {
      this.infoEmpleado();
      this.getPerfilParentesco();
      this.plantillaSexo();
      this.plantillaPerfil();
      this.titular();
      this.getInformacionEmpresa();
      await this.cargarConfiguracionFlujo();
      this.plantillaOperacionesEmpresa();
      this.getEncabezadoMail();
      this.getMailAdmin();
    }

    this.input = (<HTMLInputElement>document.getElementById('input'));
    try {
      const response = await this._empresaService.getComboCambioEmpresa(this.identity.idCorporativo, this.identity.id, this.token);
      if (response) {
        this.empresas = response;
        await this.buscaCatalogoCompensaciones();
        await this.buscaPerfilesEmpresas();
        await this.buscaRegimenesEmpresas();
        await this.buscaOficinaEmpresas();
        await this.buscaAreaEmpresas();
        await this.buscaVIPEmpresas();
        await this.buscaCentroCostosEmpresas();
        await this.buscaTipoEmpleadoEmpresas();

        this.generaComboEmpresa();
      }
    } catch (error) { }
    this.buscaPlanesCorporativo();
    this.getEstados();
    this.getGrupo();
    this.proc_LeeParametro();
    this.inicializarFormulario();
    this.catalogoTextoLog = [];
  }

  alertRetryLogin() {
    swal({
      title: '¡La sesión expiró!',
      html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
      type: 'error',
      confirmButtonText: 'Aceptar',
    });
    this.logout();
  }

  updateNameForInputFile() {
    $('#input').click();
  }

  async iniciarOperacion() {
    if (!this.pantallaB3Habilitada) {
      swal('Flujo B2 activo', 'La carga desde Excel está deshabilitada para esta empresa.', 'warning');
      return;
    }
    this.parar = false;
    if (this.verificaDatos()) {
      if (this.archivoCargado) {
        if (this.validarPlantilla()) {
          this.recorreDatos();
        }
      } else {
        let ban = true;
        this.recorreArchivoA();
        ban = false;
      }
    }
  }
  // Inicia proceso de carga masiva
  iniciarOperacionesF() {
    if (!this.pantallaB3Habilitada) {
      swal('Flujo B2 activo', 'La carga desde Excel está deshabilitada para esta empresa.', 'warning');
      return;
    }
    this.mostrarReporte = false;
    this.listaResultados = [];
    this.rerporteCargaMasiva = [];
    this.iniciarTrazaCarga();
    this.rerporteCargaMasiva.push(this.generaLog("Ha comenzado el registro de sucesos."));
    this.rerporteCargaMasiva.push(this.generaLog("Archivo de registro iniciado correctamente."));
    // Verificar datos seleccionados del formulario
    if (this.verificaDatos()) {
      // Obtene datos seleccionados del formulario
      const plantilla = this.datosOperacion((<HTMLSelectElement>document.getElementById('operacion')).value, 0)?.plantilla;
      swal({
        title: '',
        html: '<small style="color: grey; text-align: justify;">Cargando archivo...</small>',
        type: 'info',
        onOpen: () => {
          swal.showLoading();
        },
        allowOutsideClick: false,
        allowEscapeKey: false
      });
      // Obtener plantilla seleccionada o generar plantilla generica
      this.plantillaActual != plantilla ? this.plantillaFormularioGen(plantilla) : this.iniciarOperacionesF1();
    } else {
      this.rerporteCargaMasiva.push(this.generaLog('[VALIDACION] La carga no inicio porque faltan datos obligatorios.'));
      this.respaldarTrazaCarga('VALIDACION').catch(() => this.cerrarTrazaEnNavegador());
    }
  }
  // Inicia llamada para lectura de archivo
  iniciarOperacionesF1() {
    // Iniciar fecha de registro 
    this.fechaInicioReporte = this.formatFecha('');
    this.rerporteCargaMasiva.push(this.generaLog("Se han cargado las propiedades de la operación."));
    this.parar = false;
    let ban = true;
    let timerInterval;
    swal({
      title: '',
      html: '<small style="color: grey; text-align: justify;">Cargando Archivo...</small>',
      onOpen: () => {
        swal.showLoading();
        // hoja 3 es la población 1
        if (ban) {
          this.recorreArchivoA();
          ban = false;
        }
        if (this.archivoCargado) {
          timerInterval = setInterval(() => { }, 100);
        }
      },
      onClose: () => clearInterval(timerInterval),
      allowOutsideClick: false,
      allowEscapeKey: false
    });
  }

  // ALTA DE TITULARES
  // Recorrer archivo cargado 
  async recorreDatos() {
    this.rerporteCargaMasiva.push(this.generaLog("Documento de datos para Carga Masiva Inicializado correctamente."));
    const valido = await this.validarPlantilla();
    // Validar 
    if (valido) {
      if(this.renglones.length > 1){
        this.rerporteCargaMasiva.push(this.generaLog("Plantilla para Carga Masiva inicializada correctamente."));
        this.datosArchivo = '<p>Reporte--</p><br>';
        let tam = this.encabezados.length - 1;
        this.valorEncabezados = [];
        for (let i = 0; i <= tam; i++) {
          const e = this.renglones[i][1];
          this.valorEncabezados.push(e);
        }
        tam++;
        tam++;
        this.loadEditar = true;
        let timerInterval;
        this.parar = false;
        swal({
          title: 'Archivo cargado, iniciando operación',
          html: '<small style="color: grey; text-align: justify;">Una vez finalizada la operación el administrador recibirá una notificación.</small>',
          type: 'info',
          onOpen: () => {
            swal.showLoading();
            const atributosMandar = this.atributosCrear2;
            // this.listaResultados = [];
            this.archivoError = false;
            this.posReco = tam;
            this.cargarDatos(tam);
            this.loadEditar = false;
            if (this.parar === true) {
              timerInterval = setInterval(() => { }, 100);
            }
          },
          onClose: () => clearInterval(timerInterval),
          allowOutsideClick: false,
          allowEscapeKey: false
        });
      }else{
        swal({
        title: 'Atención',
        html: '<small style="color: grey; text-align: justify;">El archivo no contiene registros para procesar, seleccione un archivo con al menos un registro.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
        allowOutsideClick: false,
        allowEscapeKey: false
      });
      }
    } else {
      swal({
        title: 'Atención',
        html: '<small style="color: grey; text-align: justify;">El archivo no corresponde a la plantilla, seleccione la plantilla y el tipo de operación correctos.</small>',
        type: 'error',
        confirmButtonText: 'Aceptar',
        allowOutsideClick: false,
        allowEscapeKey: false
      });
    }
  }

  // PRUEBA CARGAR DATOS POR index, del archivo cargado
  async cargarDatos(i: any) {
    // Cargar catalogo de campos para log
    await this.getCatTextoLog(this.plantillaActual);
    if (this.modoEjecucion === 2) {
      if (this.archivoError) {
        this.parar = true;
      }
    }
    this.archivoError = false;
    // Validar atributos y valores por renglon
    if (i < this.renglones.length && !this.parar) {
      const operacion = $('#operacion').val();
      let atrs = '';
      let vals = '';
      let j = 0;
      const renglon = i + 1;
      let emp = '0';
      let nombreEmp = '';
      let empOrigTmp = '0';
      let nombreEmpOrigTmp = '';
      this.rerporteCargaMasiva.push(this.generaLog(`Procesando el renglón ${renglon} del documento de datos.`));
      for (const atributo of this.atributosCrear2) {
        if (atributo.nombreCampo !== undefined && atributo.caNombreCampo === undefined) {
          const atributoMensaje = atributo.etiqueta;
          let valor = this.renglones[i][j];
          if (atributo.nombreCampo.trim() === this.parametroAcceso) {
            valor = this.accesoSistema;
          }
          // Validacion de atributos (Campos)
          if (atributo.nombreCampo !== 'EMIdParentesco') {
            if (atributo.requerido === '1' && valor === null) {
              let logMessage = '[ERROR] ' + `El campo ${this.replaceTextoLog(atributo.cpEtiqueta.trim())} es requerido, ingresa un valor.`
              this.datosArchivo += `<br>renglon No.${renglon} ${logMessage}<br>`;
              this.rerporteCargaMasiva.push(this.generaLog(logMessage));
              this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
              this.archivoError = true;
            } else {
              atrs += atributo.nombreCampo.trim() + ',';
              vals += valor + ',';
            }
          } else {
            if (atributo.requerido === '1' && valor === null) {
              let logMessage = '[ERROR] ' + `El campo ${this.replaceTextoLog(atributo.cpEtiqueta.trim())} es requerido, ingresa un parentesco correcto.`
              this.datosArchivo += '<br>renglon No.' + renglon + ' ' + logMessage + '<br>';
              this.rerporteCargaMasiva.push(this.generaLog(logMessage));
              this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
              this.archivoError = true;
            } else {
              valor = await this.obtenerParentesco(valor);
              atrs += atributo.nombreCampo.trim() + ',';
              vals += valor + ',';
            }
          }
        } else {
          let atributoMensaje = '';
          if(atributo.cpEtiqueta != null){
            atributoMensaje = atributo.cpEtiqueta.trim() === "" ? atributo.caNombreCampo.trim() : atributo.cpEtiqueta.trim();// Nombre de campo    
          }else{
            atributoMensaje = atributo.caNombreCampo.trim()
          }
          if (atributo.caDominio !== 'E') {
            let valor = this.renglones[i][j];
            if (atributo.caNombreCampo.trim() === this.parametroAcceso) {
              valor = this.accesoSistema;
            }
            if(atributo.caNombreCampo.trim() === 'EMIdEmpresa'){
              emp = valor;
              nombreEmp = valor;
            }
            if(atributo.caNombreCampo.trim() === 'EMIdEmpresaOrigen'){
              empOrigTmp = valor;
              nombreEmpOrigTmp = valor;
            }
            if (atributo.caNombreCampo.trim() === 'EMUsuarioUMod' || atributo.caNombreCampo.trim() === 'EMUsuarioAdd') {
              valor = this.identity.id;
            }

            if ((atributo.cpRangoValores !== null && atributo.cpRangoValores !== '') 
              || atributo.caNombreCampo.trim() === 'EMIdEmpresa' 
              || atributo.caNombreCampo.trim() === 'EMIdPerfil' 
              || atributo.caNombreCampo.trim() === 'EMIdEmpresaOrigen' 
              || this.catalogosPersonalizados.includes(atributo.caNombreCampo.trim()) 
              || atributo.caNombreCampo.trim() === 'EMIdPlan' 
              || atributo.caNombreCampo.trim() === 'EMEstadoFiscal' 
              || atributo.caNombreCampo.trim() === 'EMRegimen'
              || atributo.caNombreCampo.trim() === 'EMOficina'
              || atributo.caNombreCampo.trim() === 'EMArea'
              || atributo.caNombreCampo.trim() === 'EMVIP'
              || atributo.caNombreCampo.trim() === 'EMTipoEmpleado'
              || atributo.caNombreCampo.trim() === 'EMidCentroCostos'
              || atributo.caNombreCampo.trim() === 'EMSeleccionUsuario'
              || atributo.caNombreCampo.trim() === 'CSIdCompensacion'
              || atributo.caNombreCampo.trim() === 'EMTipoCargaComp'
            ) {

              let pos = -1;
              let contador = -1;
              if (atributo.caNombreCampo.trim() === 'EMIdPerfil') {
                const valorAuxPer = valor;
                for (const emPer of this.empresaPerfiles) {
                  if (parseInt(emp + '', 10) === parseInt(emPer.Empresa)) {
                    for (const catalogo of emPer.Perfiles) {
                      if (catalogo.key === valor) {
                        valor = catalogo.value;
                      }
                    }
                  }
                }

                if (parseInt(emp + '', 10) === 0) {
                  let logMessage = '[ERROR] ' + `La empresa con Id ${emp} no es valida, ingrese un Id de empresa correcto.`;
                  this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
                  this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                  this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                  this.archivoError = true;
                } else {
                  if (valorAuxPer === valor && valor !== null) {
                    valor = 0;
                    let logMessage = '[ERROR] ' + `El perfil ${valorAuxPer} no pertenece a la empresa seleccionada, ingrese un perfil correcto.`;
                    this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
                    this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                    this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                    this.archivoError = true;
                  }
                }

              } else if (atributo.caNombreCampo.trim() === 'EMRegimen') {
                const valorAuxRegimen = valor;
                for (const emReg of this.empresaRegimenes) {
                  if (parseInt(emp + '', 10) === parseInt(emReg.Empresa, 10)) {
                    for (const catalogo of emReg.Regimenes) {
                      if (catalogo.key.trim().toUpperCase() === (valor + '').trim().toUpperCase()) {
                        valor = catalogo.value;
                        break;
                      }
                    }
                    break;
                  }
                }

                if (parseInt(emp + '', 10) === 0) {
                  let logMessage = '[ERROR] ' + `La empresa con Id ${emp} no es valida, ingrese un Id de empresa correcto.`;
                  this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
                  this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                  this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                  this.archivoError = true;
                } else {
                  if (valorAuxRegimen === valor && valor !== null) {
                    valor = 0;
                    let logMessage = '[ERROR] ' + `El regimen ${valorAuxRegimen} no pertenece a la empresa seleccionada, ingrese un regimen correcto.`;
                    this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
                    this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                    this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                    this.archivoError = true;
                  }
                }

              }else if(atributo.caNombreCampo.trim() === 'EMSeleccionUsuario') {
                const valorAuxSeleccion = valor;
                // Buscar ID de opcion
                for (const catalogo of this.opcionSolicitudList) {
                  if (catalogo.key.trim().toUpperCase() === (valor + '').trim().toUpperCase()) {
                    valor = catalogo.value;
                    break;
                  }
                }

                if (valorAuxSeleccion === valor && valor !== null) {
                  valor = 0;
                  let logMessage = '[ERROR] ' + `La opción ${valorAuxSeleccion} no pertenece al catálogo de selecciones, ingrese una seleccion correcta.`;
                  this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
                  this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                  this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                  this.archivoError = true;
                }
              }else if(atributo.caNombreCampo.trim() === 'EMTipoCargaComp') {
                const valorAuxTipoCarga = valor;
                // Buscar ID de opcion
                for (const catalogo of this.tipoCargaCompensacion) {
                  if (catalogo.key.trim().toUpperCase() === (valor + '').trim().toUpperCase()) {
                    valor = catalogo.value;
                    break;
                  }
                }

                if (valorAuxTipoCarga === valor && valor !== null) {
                  valor = 0;
                  let logMessage = '[ERROR] ' + `La opción ${valorAuxTipoCarga} no pertenece al catálogo de selecciones, ingrese una seleccion correcta.`;
                  this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
                  this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                  this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                  this.archivoError = true;
                }
              }else if (atributo.caNombreCampo.trim() === 'CSIdCompensacion') {
                const valorAuxCompensacion = valor;
                for (const emComp of this.empresaCompensacion) {
                  if (parseInt(emp + '', 10) === parseInt(emComp.Empresa, 10)) {
                    for (const catalogo of emComp.Compensacion) {
                      if (catalogo.key.trim().toUpperCase() === (valor + '').trim().toUpperCase()) {
                        valor = catalogo.value;
                        break;
                      }
                    }
                    break;
                  }
                }

                if (parseInt(emp + '', 10) === 0) {
                  let logMessage = '[ERROR] ' + `La empresa con Id ${emp} no es valida, ingrese un Id de empresa correcto.`;
                  this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
                  this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                  this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                  this.archivoError = true;
                } else {
                  if (valorAuxCompensacion === valor && valor !== null) {
                    valor = 0;
                    let logMessage = '[ERROR] ' + `El opción ${valorAuxCompensacion} no pertenece a la empresa seleccionada, ingrese un valor correcto.`;
                    this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
                    this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                    this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                    this.archivoError = true;
                  }
                }

              } else {
                for (const catalogo of this.catalogos) {
                  contador++;
                  if(catalogo.length == 1){

                    var hasKey = (catalogo[0][''] !== undefined);

                    if (hasKey) {
                      let n2 = catalogo[0][''].trim();
                      n2 = n2.replace('ff_CMC', '');
                      n2 = n2.replace('General', '');
                      let nomAtributo = atributo.caNombreCampo;
                      nomAtributo = nomAtributo.replace('EMId', '');
                      nomAtributo = nomAtributo.replace('EM', '');
                      if (nomAtributo.toUpperCase().indexOf(n2.toUpperCase()) >= 0) {
                        pos = contador + 1;
                      }
                    }
                  }
                }
                if (pos >= 0) {
                  for (const listCat of this.catalogos[pos]) {
                    if (listCat.key.trim() === valor) {
                      valor = listCat.value;
                    }
                  }
                  if (atributo.caNombreCampo.trim() === 'EMIdEmpresa') {
                    emp = valor;
                  }
                  if (atributo.caNombreCampo.trim() === 'EMIdEmpresaOrigen') {
                    empOrigTmp = valor;
                  }
                }

              }
            }

            if (atributo.cpRequerido === '1' && valor === null) {
              let logMessage = '[ERROR] ' + `El campo ${this.replaceTextoLog(atributoMensaje)} es requerido, ingresa un valor.`;
              this.datosArchivo += '<br>renglon No.' + renglon + logMessage + '<br>';
              this.rerporteCargaMasiva.push(this.generaLog(logMessage));
              this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
              this.archivoError = true;
            } else {
              if (valor === null || valor === 'null') {
                atrs += atributo.caNombreCampo.trim() + ',';

                if (atributo.caTipoDato === 'N') {
                  vals += 0 + ',';
                } else {
                  if (atributo.caTipoDato === 'E') {
                      vals += '0,';
                    } else {
                      vals += 'NULL,';
                    }

                }
              } else {
                if (valor !== undefined) {
                  const etiqueta = atributo.caNombreCampo.trim();
                  if ((etiqueta.indexOf('Fecha') > -1 || etiqueta.indexOf('fecha') > -1) && valor !== null && valor !== 'null') {
                    const fecha = new Date(valor);
                    if (isNaN(fecha.getTime())) {
                      const nom = atributo.caNombreCampo.replace('EM', '');
                      let logMessage = '[ERROR] ' + `El formato del campo ${this.replaceTextoLog(atributoMensaje)} no es correcto, ingrese una fecha con formato dd/mm/yyyy.`;
                      this.datosArchivo += `<br>renglon No.${renglon} ${logMessage}<br>`;
                      this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                      this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                      this.archivoError = true;
                    } else {
                      atrs += atributo.caNombreCampo.trim() + ',';
                      vals += valor + ',';
                    }
                  } else {
                    if(atributo.caTipoDato.trim() === 'T' && valor.toString().indexOf(',') > -1){
                      let logMessage = '[ERROR] ' + `El campo ${this.replaceTextoLog(atributoMensaje)} contiene comas y estas no están permitidas, asegúrate de que los campos de texto libre no contengan comas ",".`;
                      this.datosArchivo += `<br>renglon No.${renglon} ${logMessage}<br>`;
                      this.rerporteCargaMasiva.push(this.generaLog(logMessage));
                      this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
                      this.archivoError = true;
                    }else{
                      atrs += atributo.caNombreCampo.trim() + ',';
                      vals += valor + ',';
                    }
                  }
                } else {
                  vals += 'NULL,';
                }
              }
            }
          } else {
            j = j - 1;
          }
        }
        j = j + 1;

      }

      // Validar atributos extra
      let existe = false;
      for (const atrib of atrs.split(',')) {
        if (atrib === 'EMUsuarioUMod') {
          existe = true;
          break;
        }
      }
      if (!existe) {
        atrs += 'EMUsuarioUMod,';
        vals += this.identity.id + ',';
      }
      if (operacion === '3' || operacion === '12') {
        atrs += 'Id,';
        vals += '0,';
        atrs += 'EMFechaBaja,';
        vals += new Date() + ',';
      }
      if (operacion === '11') {
        atrs += 'Id,';
        vals += '1,';
      }
      // Validar catalogos
      for (let i = 0; i < this.encabezados.length; i++) {
        atrs += this.encabezados[i].caNombreCampo.trim() + ',';
        const nomEm = this.encabezados[i].caNombreCampo.trim();
        if ((nomEm === 'EMIdEmpresa' || nomEm === 'EMIdEmpresaOrigen') && parseInt(emp, 10) === 0) {
          emp = this.valorEncabezados[i];
          let pos = -1;
          let contador = -1;
          for (const catalogo of this.catalogos) {
            if(catalogo.length === 1){
              contador++;
              var hasKey = (catalogo[0][''] !== undefined);

              if ( hasKey ) {
                let n2 = catalogo[0][''].trim();
                n2 = n2.replace('ff_CMC', '');
                n2 = n2.replace('General', '');
                const nomAtributo = this.encabezados[i].caNombreCampo;
                if (nomAtributo.toUpperCase().indexOf(n2.toUpperCase()) >= 0) {
                  pos = contador + 1;
                }
              }
            }

          }
          if (pos >= 0) {
            for (const listCat of this.catalogos[pos]) {
              if (listCat.key === this.valorEncabezados[i]) {
                this.valorEncabezados[i] = listCat.value;
                emp = listCat.value;
              }
            }
          } else {
            const nom = 'Empresa';
            let logMessage = '[ERROR] ' + `El campo ${this.replaceTextoLog(nom)} es requerido, ingresa un valor.`;
            this.datosArchivo += `<br>renglon No.${renglon} ${logMessage}<br>`;
            this.rerporteCargaMasiva.push(this.generaLog(logMessage));
            this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
            this.archivoError = true;
          }
        }
        vals += nomEm === this.parametroAcceso ? this.accesoSistema + ',' : this.valorEncabezados[i] + ',';
      }

      // Algunas operaciones reciben el acceso como parámetro del SP y no como columna de plantilla.
      if (this.parametroAcceso && !atrs.split(',').includes(this.parametroAcceso)) {
        atrs += this.parametroAcceso + ',';
        vals += this.accesoSistema + ',';
      }
      // Plantillas heredadas (por ejemplo, la 507) identifican a la empresa por
      // EMEmpresa y dejan que el SP resuelva EMIdEmpresa. Para autorización B3 la
      // empresa efectiva sigue siendo la del usuario autenticado.
      const atributosRegistro = atrs.split(',').map(a => a.trim());
      const usaCodigoEmpresa = atributosRegistro.includes('EMEmpresa');
      const usaIdEmpresa = atributosRegistro.includes('EMIdEmpresa');
      if (!usaIdEmpresa && usaCodigoEmpresa && parseInt(emp, 10) === 0) {
        emp = this.identity.idEmpresa;
      }
      // Validacion de empresas
      let validoEmp = false;
      if (this.empresas) {
        const empresaPermitida = this.empresas.find(empre => Number(empre.IdEmpresa) === Number(emp));
        const empresaOrigenPermitida = this.empresas.find(empre => Number(empre.IdEmpresa) === Number(empOrigTmp));
        if((operacion === '15' && empresaPermitida && empresaOrigenPermitida)
            || (operacion !== '15' && empresaPermitida)){
          validoEmp = true;
        }
      } else {
        validoEmp = true;
      }
      // Validar que la empresa exista, en el usuario logueado o lista del grupo
      if (emp === null) {
        let logMessage = '[ERROR] ' + `El campo de empresa está vacío, ingrese un Id de empresa correcto.`;
        this.datosArchivo += `<br>renglon No.${i} ${logMessage}<br>`;
        this.rerporteCargaMasiva.push(this.generaLog(logMessage));
        this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
        this.archivoError = true;
        this.cargarDatos(renglon); // Se genera error y se continua con el siguiente registro
      } else {
        if (validoEmp) {
          atrs += 'Sp';
          vals += '' + this.datosOpe.sp;
          if (this.modoEjecucion === 1) {
            if (!this.archivoError) { // Flujo ejecutar todo y continuar
              const resultado = 0;
              this.mandarDatosAltaT(atrs, vals, renglon, resultado); // Si no hay errores se continua con el siguiente registro
              if (resultado !== 0) {
                this.parar = true;
              }
              atrs = '';
              vals = '';
            } else {
              this.cargarDatos(renglon); // Se genera error y se continua con el siguiente registro
            }

          } else { // Flujo ejecutar hasta encontrar algun error
            if (!this.archivoError) {
              const resultado = 0;
              this.mandarDatosAltaT(atrs, vals, renglon, resultado); // Si no hay errores se continua con el siguiente registro
              if (resultado !== 0) {
                this.parar = true;
              }
              atrs = '';
              vals = '';
            } else {
              this.parar = true;
              this.cargarDatos(renglon); // Se genera error y se continua con el siguiente registro
            }
          }
        } else {
          const esNumerico = (texto) => /^\d+$/.test(texto);
          let etiquetaEmpresa = !esNumerico(emp) ? nombreEmp : (!esNumerico(empOrigTmp) ? nombreEmpOrigTmp : '');
          let logMessage = '[ERROR] ' + `La empresa con Id ${etiquetaEmpresa} no es valida, ingrese un Id de empresa correcto.`;
          this.datosArchivo += `<br>renglon No.${i} ${`La empresa con Id ${emp} no es valida, ingrese un Id de empresa correcto.`}<br>`;
          this.rerporteCargaMasiva.push(this.generaLog(logMessage));
          this.agregarResultados(this.formatFecha(''), renglon, logMessage, 0);
          this.archivoError = true;
          this.cargarDatos(renglon); // Se genera error y se continua con el siguiente registro
        }
      }
    } else {
      const data = [];
      const keys = ['Tiempo', 'Renglón', 'Mensaje'];
      this.listaResultados.forEach(element => {
        const values = Object.values(element);
        data.push(values);
      });
      // Reducir lista de resultados para mostrar reporte
      const reporteResultados = this.listaResultados.filter((objeto, indice, arreglo) => 
        arreglo.findIndex(item => item.renglon === objeto.renglon) === indice
      );
      const nomArchivoExcel = this.colocarFechaAlNombre(`ReporteCargaMasiva_${this.identity.nomEmpresa}`);

      try{
        const workbook = this._excelService.crearArchivoExcelNuevo3(keys, data, `ReporteCargaMasiva_${this.identity.nomEmpresa}`);
        let to = this.datosMail['correo'];
        workbook.xlsx.writeBuffer().then((archivo: any) => {
          const blob = new Blob([archivo], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          // FileSaver.saveAs(blob, nomArchivoExcel);
          this.enviarMailNotificacion(nomArchivoExcel, blob, to, this.sujeto, this.bodyHTML, reporteResultados);
        });
      }catch(e){
        console.log("Ocurrió un error al enviar correo con reporte de carga masiva.");
      }
      
      this.respaldarTrazaCarga('FINALIZADO').catch(() => {
        console.log("Ocurrió un error al respaldar el reporte de carga masiva.");
      });
      swal({
        title: 'Finalizado',
        html: '<small style="color: grey; text-align: justify;">Ha finalizado el procesamiento de la carga masiva, consulte el reporte para más información.</small>',
        type: 'info',
        confirmButtonText: 'Aceptar',
        allowOutsideClick: false,
        allowEscapeKey: false
      });
    }
  }
  // FIN CARGAR DATOS POR INDEX

  // Procesar archivo excel de carga masiva
  recorreArchivoA() {
    const archivo = this.input.files[0];
    readXlsxFile(archivo, {
      sheet: 2, transformData(data) {
        // Remover filas vacias
        return data.filter(row => row.filter(column => column !== null).length > 0);
      }
    }).then((rows) => {
      this.renglones = rows;
      this.archivoCargado = true;
      this.recorreDatos();
    },
    (error) =>{
      const logMessage = '[ERROR] No se pudo leer el archivo Excel seleccionado.';
      this.rerporteCargaMasiva.push(this.generaLog(logMessage));
      this.agregarResultados(this.formatFecha(''), 0, logMessage, 0);
      this.mostrarReporte = true;
      this.respaldarTrazaCarga('ERROR').catch(() => {
        console.log('No fue posible respaldar la traza de lectura del archivo.');
      });
      swal({
        title: '',
        html: '<small style="color: grey; text-align: justify;">No se pudo cargar el archivo, intenta cargarlo de nuevo.</small>',
        type: 'error',
        onOpen: () => {
          swal.hideLoading();
        },
        allowOutsideClick: false,
        allowEscapeKey: false
      });
    });
  }
  // Generacion de parametros y llamado a tipo de operacion
  async capturaDatosT(atributos, valores, ren, resultado: number) {
    let arrayAtributos = atributos.split(',');
    let arrayValores = valores.split(',');
    let empresa = '';
    let appat = '';
    let apmat = '';
    let nom1 = '';
    let nom2 = '';
    let numEmp = '';
    let fechaNac = '';
    let existePassword = false;
    let emRFCValue = '';
    for (let i = 0; i < arrayAtributos.length; i++) {
      switch (arrayAtributos[i]) {
        case 'EMIdEmpresa':
          empresa = arrayValores[i];
          break;
        case 'EMApellidoPaterno':
          appat = arrayValores[i];
          break;
        case 'EMApellidoMaterno':
          apmat = arrayValores[i];
          break;
        case 'EMNombre1':
          nom1 = arrayValores[i];
          break;
        case 'EMNombre2':
          nom2 = arrayValores[i];
          break;
        case 'EMFechaNacimiento':
          fechaNac = arrayValores[i];
          break;
        case 'EMNumeroEmpleado':
          numEmp = arrayValores[i];
          break;
        case 'EMrfc':
          emRFCValue = arrayValores[i];
          break;
        case 'EMContraseña':
        case 'EMPassword':
          existePassword = true;
          break;
      }
    }
    arrayAtributos = atributos.split(',');
    arrayValores = valores.split(',');

    let param = {
      IdEmpresa: empresa, ApellidoPaterno: appat, Nombre1: nom1, FechaNacimiento: fechaNac,
      NumeroEmpleado: numEmp, IdTitular: '1', ApellidoMaterno: apmat, IdDependiente: '0'
    };

    const operacion = $('#operacion').val();
    let mismoNombre: any = { 'resultado': '0', 'empresa': '' };

    if (operacion === 1 || operacion === 2) {
      if (operacion === 1) {
        param['IdTitular'] = '0';
      }
      mismoNombre = await this.validaduplicado(param);
    }

    // Validar generacion de clave para titulares
    if(operacion === "2" && !existePassword && empresa != ''){
      try{
        let confPass = await this._titularesService.getConfPassword(empresa,this.token);
        let newPass;
        if(confPass[0].length>0){
          let configKey = confPass[0];
          for(let i=0; i<configKey.length;i++){
            if(configKey[i].CANombreCampo.trim() == 'EMFechaNacimiento'){
              if(fechaNac.toUpperCase().search("T")){ // Limpiar formato de fecha
                let indexTiempo = fechaNac.indexOf("T");
                fechaNac = fechaNac.substring(0,indexTiempo);
              }
              let newfecha = fechaNac.split('-');
              newPass =  newfecha[2] +""+newfecha[1] +""+newfecha[0];
            }
            if(configKey[i].CANombreCampo.trim() == 'EMrfc'){
              // Generar RFC si no viene en el layout
              if(!emRFCValue || emRFCValue === '' || emRFCValue === 'NULL'){
                nom2 = nom2 === 'NULL' ? '' : nom2.trim();
                // Limpiar formato de fecha
                if(fechaNac.includes("T")){
                  let indexTiempo = fechaNac.indexOf("T");
                  fechaNac = fechaNac.substring(0,indexTiempo);
                }
                await this._empleadoService.getRFC(nom1.toUpperCase() + " " + nom2, appat, apmat, fechaNac).then(
                  (response: any) => {
                    emRFCValue = response.rfc.trim();
                });
              }
              newPass =  emRFCValue
            }
          }
        }
        let password = await this._empleadoService.getPasswordEncrypt(newPass);
        valores = valores + password.encriptada + ",";
        atributos = atributos + "EMPassword,";
      }catch(e){
        console.log("Ha ocurrido un error al generar generar el atributo", e);
      }
    }

    // FIN VALIDA
    if (mismoNombre.resultado === '0') {
      this.dependienteInsert.idEmpresa = this.identity.idEmpresa;
      this.dependienteInsert.valores = valores;
      this.dependienteInsert.atributos = atributos;

      let cadena = this.dependienteInsert.valores;
      cadena = cadena.substring(0, cadena.length - 1);
      this.dependienteInsert.valores = encodeURIComponent(cadena);
      cadena = this.dependienteInsert.atributos;
      cadena = cadena.substring(0, cadena.length - 1);
      this.dependienteInsert.atributos = encodeURIComponent(cadena);
      try { // Mandar datos a back
        let response: any = {};
        const operacion = $('#operacion').val();
        switch (operacion) {
          case '1':
            //Dependiente
            response = await this._titularesService.addDependienteMsivo(this.dependienteInsert, this.token);
            break;
          case '2':
            //Titular
            response = await this._titularesService.addTitularM(this.dependienteInsert, this.token);
            break;
          case '3':
            //Baja
            // response = await this._titularesService.addBajaMasiva(this.dependienteInsert, this.token);
            response = await this.mandarDatosBajaT(atributos, valores , ren);
            break;
          case '15': // Transferencia de empleados
            response = await this._titularesService.ejecutarTransferenciaMasivaEmpleado(this.dependienteInsert, this.token);
            break;
          default:
            response = await this._titularesService.ejecutarCargaMasiva(this.dependienteInsert, this.token);
            break;
        }
        if(operacion === '15'){
          if(response.code && response.code === 200){
            if(response.EMSeleccionUsuario){
              this.ejecutarSeleccionUsuario(response.IdEmpleado,response.EMNumeroEmpleado,response.EMIdEmpresa,response.idSolicitud,response.EMSeleccionUsuario);
            }
          }
        }
        this.datosArchivo += `<br>renglon No.${ren} Code= ${response.code}: msg= ${response.msg}<br>`;
        let logMessage = operacion === "2" ? '[INFO] ' + `El registro ha sido enviado y procesado con la siguiente respuesta: ${response.msg}. Recuerda que el número de empleado y el certificado no se actualiza desde este proceso.`: '[INFO] ' + `El registro ha sido enviado y procesado con la siguiente respuesta: ${response.msg}`;
        this.rerporteCargaMasiva.push(this.generaLog(logMessage));
        this.agregarResultados(this.formatFecha(''), ren, logMessage, 1);
        resultado = response.code;
        this.posReco++;
        this.cargarDatos(ren);
      } catch (error) {
        let logMessage = '[ERROR] ' + `No fue posible realizar la operación, intente más tarde.`;
        this.datosArchivo += `<br>renglon No.${ren} ${logMessage}<br>`;
        this.rerporteCargaMasiva.push(this.generaLog(logMessage));
        this.agregarResultados(this.formatFecha(''), ren, logMessage, 0);
        resultado = 1;
        this.posReco++;
        this.cargarDatos(ren);
      }
    } else {
      this.archivoError = true;
      let logMessage = '[ERROR] ' + `Ya existe un empleado con el mismo nombre en ${mismoNombre.empresa}.`;
      this.datosArchivo += `<br>renglon No.${ren} ${logMessage}<br>`;
      this.rerporteCargaMasiva.push(this.generaLog(logMessage));
      this.agregarResultados(this.formatFecha(''), ren, logMessage, 0);
      resultado = 1;
      this.posReco++;
      this.cargarDatos(ren);
      return 'Error';
    }
  }

  async mandarDatosAltaD(atributos: any, valores: any, ren: any) {
    const arrayForm = [
      'EMIdEmpresa', 'EMIdParentesco', 'EMIdSexo', 'EMNumeroEmpleado', 'EMApellidoPaterno',
      'EMApellidoMaterno', 'EMNombre1', 'EMNombre2', 'EMFechaNacimiento', 'EMFechaIngresoEmpresa',
      'EMFechaAntiguedadGMM', 'EMFechaAlta', 'EMObservaciones', 'EMCertificado'
    ];

    const arrayAtributos = atributos.split(',');
    const arrayValores = valores.split(',');

    if (arrayAtributos.indexOf('EMFechaIngresoEmpresa') === -1) {
      arrayAtributos.push('EMFechaIngresoEmpresa');
      arrayValores.push(new Date());
    }
    if (arrayAtributos.indexOf('EMFechaAntiguedadGMM') === -1) {
      arrayAtributos.push('EMFechaAntiguedadGMM');
      arrayValores.push(new Date());
    }
    if (arrayAtributos.indexOf('EMFechaAlta') === -1) {
      arrayAtributos.push('EMFechaAlta');
      arrayValores.push(new Date());
    }

    let atributos2 = '';
    let valores2 = '';
    for (let i = 0; i < arrayForm.length; i++) {
      let posicion = -1;
      for (let j = 0; j < arrayAtributos.length; j++) {
        if (arrayForm[i] === arrayAtributos[j]) {
          posicion = j;
          break;
        }
      }

      atributos2 += arrayForm[i] + ',';
      if (posicion !== -1) {
        const indice = arrayForm[i].indexOf('Fecha');
        if (arrayForm[i] === 'EMIdSexo') {
          if (arrayValores[posicion] === 'Femenino') {
            valores2 += '2,';
          } else {
            valores2 += '1,';
          }
        } else {
          if (indice > 0) {
            try {
              const fecha = new Date(arrayValores[posicion]);
              const y = fecha.getFullYear();
              let m = fecha.getMonth();
              const d = fecha.getDate();
              m = m + 1;
              let mes;
              let dia;
              if (m < 10) {
                mes = '0' + m;
              } else {
                mes = m;
              }
              if (d < 10) {
                dia = '0' + d;
              } else {
                dia = d;
              }

              valores2 += y + '-' + mes + '-' + dia + ',';
            } catch (e) {
              this.archivoError = true;
            }
          } else {
            let entero = 0;
            if (arrayForm[i] !== 'EMSalarioBase') {
              entero = -1;
              if (entero === null) {
                entero = -1;
              }
            } else {
              entero = parseFloat(arrayValores[posicion]);
            }
            if (entero >= 0) {
              valores2 += entero + ',';
            } else {
              valores2 += arrayValores[posicion].replace('+', ',') + ',';
            }
          }
        }
      } else {
        valores2 += 'NULL,';
      }
    }
    // Convierte los valores a mayusculas, para el caso de numeroempleado no debe ser totalmente mayusculas
    valores2 = valores2.toUpperCase();
    let cadena = valores2;
    cadena = cadena.substring(0, cadena.length - 1);
    valores2 = cadena;
    cadena = atributos2;
    cadena = cadena.substring(0, cadena.length - 1);
    atributos2 = encodeURIComponent(cadena);
    atributos2 = cadena;
    try {
      const response: any = await this._titularesService.addTitularD(atributos2, valores2, this.token);
      if (parseInt(response.code, 10) !== 0) {
        this.archivoError = true;
        let logMessage = '[INFO] ' + `Mensaje devuelto por el StoredProc: ${response.msg}`;
        this.datosArchivo += `<br style=\'color:red;background-color:green;\'>renglon No.${ren} Code= ${response.code}: msg= ${response.msg}<br>`;
        this.rerporteCargaMasiva.push(this.generaLog(logMessage));
        this.agregarResultados(this.formatFecha(''), ren, logMessage, 1);
      } else {
        let logMessage = '[ERROR] ' + `Mensaje devuelto por el StoredProc: ${response.msg}`;
        this.datosArchivo += `<br>renglon No.${ren} Code= ${response.code}: msg= ${response.msg}<br>`;
        this.rerporteCargaMasiva.push(this.generaLog(logMessage));
        this.agregarResultados(this.formatFecha(''), ren, logMessage, 0);
      }
      return 'bien';
    } catch (error) {
      this.archivoError = true;
      let logMessage = '[ERROR] ' + `Error de conexión, intente más tarde.`;
      this.datosArchivo += '<br>renglon No.' + ren + ' Error de conexion<br>';
      this.rerporteCargaMasiva.push(this.generaLog(logMessage));
      this.agregarResultados(this.formatFecha(''), ren, logMessage, 0);
      return 'fallo';
    }
  }

  async mandarDatosBajaD(atributos: any, valores: any, ren: any) {
    const arrayForm = [
      'EMIdEmpresa', 'Id', 'EMObservaciones', 'EMUsuarioUMod', 'EMIdTitular',
      'EMNumeroEmpleado', 'EMFechaBaja', 'EMIdParentesco', 'EMApellidoPaterno',
      'EMApellidoMaterno', 'EMNombre1', 'EMNombre2', 'EMFechaNacimiento'
    ];

    const arrayAtributos = atributos.split(',');
    const arrayValores = valores.split(',');

    let atributos2 = '';
    let valores2 = '';
    let aprobacion = true;
    for (let i = 0; i < arrayForm.length; i++) {
      const index = arrayAtributos.indexOf(arrayForm[i]);
      let valor = '-1';
      if (index !== -1) {
        if (arrayForm[i].indexOf('Fecha') !== -1) {
          const f = new Date(arrayValores[arrayAtributos.indexOf(arrayForm[i])]);
          const y = f.getFullYear();
          let m = f.getMonth();
          const d = f.getDate();
          m = m + 1;
          let mes;
          let dia;
          if (m < 10) {
            mes = '0' + m;
          } else {
            mes = m;
          }
          if (d < 10) {
            dia = '0' + d;
          } else {
            dia = d;
          }
          valor = y + '-' + mes + '-' + dia;
        } else {
          valor = arrayValores[index];
        }
      } else {
        switch (arrayForm[i]) {
          case 'Id':
            valor = '0';
            break;
          case 'EMObservaciones':
            valor = 'Baja masiva dependientes';
            break;
          case 'EMUsuarioUMod':
            valor = this.identity.id;
            break;
          case 'EMIdTitular':
            valor = '0';
            break;
          case 'EMFechaBaja':
            const y = new Date().getFullYear();
            let m = new Date().getMonth();
            const d = new Date().getDate();
            m = m + 1;
            let mes;
            let dia;
            if (m < 10) {
              mes = '0' + m;
            } else {
              mes = m;
            }
            if (d < 10) {
              dia = '0' + d;
            } else {
              dia = d;
            }
            valor = y + '-' + mes + '-' + dia;
            break;
          case 'EMNombre2':
            valor = 'NULL';
            break;
        }
      }
      if (valor !== '-1') {
        atributos2 += arrayForm[i] + ',';
        valores2 += valor + ',';
      } else {
        this.archivoError = true;
        let logMessage = '[ERROR] ' + `Atributo ${this.replaceTextoLog(arrayForm[i])} es requerido, ingresa un valor.`;
        this.datosArchivo += '<br style=\'color:red;background-color:green;\'>Error renglon No.' + ren + ' ' + logMessage + '<br>';
        this.rerporteCargaMasiva.push(this.generaLog(logMessage));
        this.agregarResultados(this.formatFecha(''), ren, logMessage, 0);
        aprobacion = false;
      }

    }

    if (aprobacion) {
      // Convierte los valores a mayusculas, para el caso de numeroempleado no debe ser totalmente mayusculas
      valores2 = valores2.toUpperCase();
      let cadena = valores2;
      cadena = cadena.substring(0, cadena.length - 1);
      valores2 = cadena;
      cadena = atributos2;
      cadena = cadena.substring(0, cadena.length - 1);
      atributos2 = encodeURIComponent(cadena);
      atributos2 = cadena;
      let logMessage = ''
      try {
        const response: any = await this._titularesService.addBajaMasivaD(atributos2, valores2, this.token);
        if (parseInt(response.code, 10) !== 0) {
          this.archivoError = true;
          this.datosArchivo += '<br style=\'color:red;background-color:green;\'>renglon No.' + ren + ' Code= ' + response.code + ': msg= ' + response.msg + '<br>';
          logMessage = '[INFO] ' + `Mensaje devuelto por el StoredProc: Código :${response.code}; Mensaje: ${response.msg}.`;
          this.rerporteCargaMasiva.push(this.generaLog('[INFO] ' + logMessage));
          this.agregarResultados(this.formatFecha(''), ren, logMessage, 1);
        } else {
          this.datosArchivo += '<br>renglon No.' + ren + ' Code= ' + response.code + ': msg= ' + response.msg + '<br>';
          logMessage = '[ERROR] ' + `Mensaje devuelto por el StoredProc: Código :${response.code}; Mensaje: ${response.msg}.`;
          this.rerporteCargaMasiva.push(this.generaLog(logMessage));
          this.agregarResultados(this.formatFecha(''), ren, logMessage, 0);
        }
        return 'bien';
      } catch (error) {
        this.archivoError = true;
        this.datosArchivo += '<br>renglon No.' + ren + ' Error de conexion<br>';
        logMessage = '[ERROR] ' + `Mensaje devuelto por el StoredProc: Ocurrió un error de conexión, intente más tarde.`;
        this.rerporteCargaMasiva.push(this.generaLog(logMessage));
        this.agregarResultados(this.formatFecha(''), ren, logMessage, 0);
        return 'fallo';
      }
    } else {
      return 'falta de datos requeridos';
    }


  }

  // Generar parametros extra para la baja de titular
  async mandarDatosBajaT(atributos: any, valores: any, ren: any) {
    const arrayAtributos = atributos.split(',');
    const arrayValores = valores.split(',');
    let logMessage = '';
    let fechaBaja = '';
    if (arrayAtributos.indexOf('EMNumeroEmpleado') !== -1) {
      if (arrayAtributos.indexOf('EMFechaBaja') !== -1) {
        const f = new Date(arrayValores[arrayAtributos.indexOf('EMFechaBaja')]);
        let mes;
        let dia;
        let y = f.getFullYear();
        let m = f.getMonth();
        let d = f.getDate();
        m = m + 1;
        if (m < 10) {
          mes = '0' + m;
        } else {
          mes = m;
        }
        if (d < 10) {
          dia = '0' + d;
        } else {
          dia = d;
        }
        fechaBaja = y + '-' + mes + '-' + dia;
      }
      let id = '0';
      let observaciones = 'Baja masiva';

      if (arrayAtributos.indexOf('Id') !== -1) {
        id = arrayValores[arrayAtributos.indexOf('Id')];
      }
      if (arrayAtributos.indexOf('EMObservaciones') !== -1) {
        observaciones = arrayValores[arrayAtributos.indexOf('EMObservaciones')];
      }
      let idEmpresaBajaMT = this.identity.idEmpresa;
      if (arrayAtributos.indexOf('EMIdEmpresa') !== -1) { 
        idEmpresaBajaMT = arrayValores[arrayAtributos.indexOf('EMIdEmpresa')]; // Se recupera idmpresa del registro
      }
      if (arrayAtributos.indexOf('EMFechaNacimiento') !== -1) {
        const f = new Date(arrayValores[arrayAtributos.indexOf('EMFechaNacimiento')]);
        let mes;
        let dia;
        let y = f.getFullYear();
        let m = f.getMonth();
        let d = f.getDate();
        m = m + 1;
        if (m < 10) {
          mes = '0' + m;
        } else {
          mes = m;
        }
        if (d < 10) {
          dia = '0' + d;
        } else {
          dia = d;
        }
        fechaBaja = y + '-' + mes + '-' + dia;

      }
      // Acción	Número de Empleado	Apellido Paterno	Apellido Materno	Primer Nombre	Segundo Nombre	Parentesco	Sexo	Fecha de Nacimiento	Edad	Estatus del asegurado
      this.dependienteDel.idEmpresa = idEmpresaBajaMT;
      this.dependienteDel.eMId = id;
      this.dependienteDel.eMObservaciones = observaciones;
      this.dependienteDel.eMUsuarioUMod = this.identity.id;
      this.dependienteDel.eMIdTitular = '1';
      this.dependienteDel.numeroEmpleado = arrayValores[arrayAtributos.indexOf('EMNumeroEmpleado')];
      this.dependienteDel.FechaBaja = fechaBaja;
      try {
        const response: any = await this._titularesService.bajaMasivatitular(this.dependienteDel, this.token);
        if (parseInt(response.code, 10) !== 0) {
          this.archivoError = true;
          this.datosArchivo += '<br style=\'color:red;background-color:green;\'>renglon No.' + ren + ' Code= ' + response.code + ': msg= ' + response.msg + '<br>';
        } else {
          this.datosArchivo += '<br>renglon No.' + ren + ' Code= ' + response.code + ': msg= ' + response.msg + '<br>';
        }
        return response;
      } catch (error) {
        this.archivoError = true;
        this.datosArchivo += '<br>renglon No.' + ren + ' Numero de Empleado No encontrado o ya fue dado de baja, intente con otro.<br>';
        return {
          code: 0,
          msg: 'Numero de Empleado No encontrado o ya fue dado de baja'
        };
      }
    } else {
      this.archivoError = true;
      this.datosArchivo += '<br>renglon No.' + ren + ' el número de Empleado es requerido <br>';
      return {
        code: 0,
        msg: 'El número de Empleado es requerido'
      };;
    }
  }
  // FIN OPERACIONES MASIVAS

  verificaDatos() {
    const operacion = $('#operacion').val();
    if (operacion == 0) {
      this.error = true;
      return false;
    } else {
      this.error = false;
    }
    if (this.input.files[0] == null) {
      this.errorEntrada = true;
      return false;
    } else {
      this.errorEntrada = false;
    }
    if (this.modoEjecucion == 0) {
      this.modalVerificarDatos('Seleciona el modo de operación a ejecutar.');
      return false;
    }
    return true;
  }

  protected modalVerificarDatos(mensaje: string) {
    this.errorEntrada = true;
  }

  resetFormulario2() {
    (<HTMLSelectElement>document.getElementById('operacion')).selectedIndex = 0;
    (<HTMLInputElement>document.getElementById('input')).value = '';
    (<HTMLInputElement>document.getElementById('formCheck-1')).checked = false;
    (<HTMLInputElement>document.getElementById('formCheck-2')).checked = true;
    this.parametroAcceso = null;
    this.accesoSistema = 1;
  }

  selectR(radio: any) {
    if (radio === 1) {
      (<HTMLInputElement>document.getElementById('formCheck-2')).checked = false;
      this.modoEjecucion = 1;
    } else {
      (<HTMLInputElement>document.getElementById('formCheck-1')).checked = false;
      this.modoEjecucion = 2;
    }
  }

  objeto(nombre: any) {
    return (<HTMLInputElement>document.getElementById(nombre));
  }

  normalizar(cadena: any) {
    const salida = cadena.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return salida;
  }

  buscaAtributo(cadena: any) {
    const arrayForm = [
      'EMIdEmpresa', 'EMIdPerfil', 'EMIdSexo', 'EMNumeroEmpleado', 'EMApellidoPaterno',
      'EMApellidoMaterno', 'EMNombre1', 'EMNombre2', 'EMFechaNacimiento', 'EMFechaIngresoEmpresa',
      'EMFechaAntiguedadGMM', 'EMOficina', 'EMArea', 'EMidCentroCostos', 'EMPuesto', 'EMrfc',
      'EMcurp', 'EMCorreoElectronico', 'EMSalarioBase', 'EMObservaciones', 'EMCalleFiscal',
      'EMColoniaFiscal', 'EMMunicipioDelegacionFiscal', 'EMEstadoFiscal', 'EMCodigoPostalFiscal',
      'EMPassword', 'EMCertificado', 'EMBeneficioMaximoM', 'EMFechaAlta', 'EMVIP', 'EMIdParentesco'
    ];
    let salida = '';
    switch (cadena) {
      case 'EMIDOficina':
        cadena = 'EMOficina';
        break;
      case 'EMSexo':
        cadena = 'EMIdSexo';
        break;
      case 'EMPrimerNombre':
        cadena = 'EMNombre1';
        break;
      case 'EMSegundoNombre':
        cadena = 'EMNombre2';
        break;
      case 'EMFechaIngresoempresa':
        cadena = 'EMFechaIngresoEmpresa';
        break;
      case 'EMFechaAntiguedad':
        cadena = 'EMFechaAntiguedadGMM';
        break;
      case 'EMSalario':
        cadena = 'EMSalarioBase';
        break;
      case 'EMParentesco':
        cadena = 'EMIdParentesco';
        break;
    }
    for (let i = 0; i < arrayForm.length; i++) {
      if (arrayForm[i] === cadena) {
        salida = arrayForm[i];
        break;
      }
    }
    return salida;
  }
  // Validacion de parametros y generacion de cadena de valores
  mandarDatosAltaT(atributos: any, valores: any, ren: any, resultado: number) {
    const arrayForm = atributos.split(',');
    const arrayAtributos = atributos.split(',');
    const arrayValores = valores.split(',');

    let atributos2 = '';
    let valores2 = '';
    for (let i = 0; i < arrayForm.length; i++) {
      let posicion = -1;
      for (let j = 0; j < arrayAtributos.length; j++) {
        if (arrayForm[i] === arrayAtributos[j]) {
          posicion = j;
          break;
        }
      }

      atributos2 += arrayForm[i] + ',';
      if (posicion !== -1) {
        const indice = arrayForm[i].indexOf('Fecha');
        if (indice > 0 && arrayValores[posicion] !== 'NULL') {
          try {
            const fecha = new Date(arrayValores[posicion]);
            let m = fecha.getMonth();
            const d = fecha.getDate();
            m = m + 1;
            let mes;
            let dia;
            if (m < 10) {
              mes = '0' + m;
            } else {
              mes = m;
            }
            if (d < 10) {
              dia = '0' + d;
            } else {
              dia = d;
            }
            valores2 += fecha.toISOString().substring(0, fecha.toISOString().length - 1) + ',';
          } catch (e) {
            this.archivoError = true;
          }
        } else {
          let entero = 0;
          if (arrayForm[i] !== 'EMSalarioBase') {
            entero = -1;

            if (entero === null) {
              entero = -1;
            }
          } else {
            entero = parseFloat(arrayValores[posicion]);
          }
          if (entero >= 0 && arrayForm[i] !== 'EMNumeroEmpleado' && arrayForm[i] !== 'EMCertificado' && arrayForm[i] !== 'EMCodigoPostal') {
            valores2 += entero + ',';
          } else {
            valores2 += '' + arrayValores[posicion].replace('+', ',') + ',';
          }
        }
      } else {
        valores2 += 'NULL,';
      }
    }
    // Convierte los valores a mayusculas, para el caso de numeroempleado no debe ser totalmente mayusculas
    valores2 = valores2.toUpperCase();
    this.capturaDatosT(atributos2, valores2, ren, resultado);
  }

  verReporte() {
    this.mostrarMensajeReporte = this.listaResultados.length > 0 ? false : true;
    this.mostrarReporte = !this.mostrarReporte;
    this.loadEditar = false;
  }

  ngDoCheck() {
    this.validarSesion();
  }

  validarSesion() {
    if (this.identity === null) {
      this.logout();
    }
  }

  async getPerfilParentesco() {
    try {
      this.parentescoPerfil.idEmpresa = this.identity.idEmpresa;
      this.parentescoPerfil.idPerfil = this.identity.idPerfil;
      const response = await this._dependienteService.getDependientesParentesco(this.parentescoPerfil, this.token);
      this.parentescoC = response;
    } catch (error) {
      error !== null ? this.status = 'error' : null;
    }
  }

  obtenerParentesco(parentesco: any) {
    let idParen = 0;
    if (parentesco === 'HIJO' || parentesco === 'HIJA') {
      parentesco = 'HIJO(A)';
    }
    if (parentesco === 'CONYUGE') {
      parentesco = 'CÓNYUGE';
    }
    if (parentesco !== 'TITULAR') {
      for (const paren of this.parentescoC) {
        if (paren.descripcion === parentesco) {
          idParen = paren.idParentesco;
          break;
        }
      }
    } else {
      idParen = 1;
    }
    return idParen;
  }

  obtenerPerfil(perfil: any) {
    let idPer = 0;
    for (const paren of this.comboPerfiles) {
      if (paren.nombrePerfil === perfil) {
        idPer = paren.idPerfil;
        break;
      }
    }
    return idPer;
  }

  async infoEmpleado() {
    try {
      if (this.identity.id) {
        const response = await this._empleadoService.datosEmpleado(this.identity);
        this.datosPerfil = response;
      }
    } catch (error) {
      error !== null ? this.status = 'error' : null;
    }
  }

  // PLANTILLAS DOCUMENTO ADMIN
  async plantillaFormulario() {
    try {
      this.formularioAtrib.IdEmpresa = this.identity.idEmpresa;
      this.formularioAtrib.IdPerfil = this.identity.idPerfil;
      this.formularioAtrib.Pantalla = 'ff_Admi_Altatitulares.aspx';
      const response = await this._dependienteService.getFormularioDependienteCotizar(this.formularioAtrib, this.token);
      if (response.body['data']) {
        this.atributosCrear = response.body['data'];
        this.atributosCrear = this.ordenarCampos(response.body['data'], 'cpOrden', 'asc');
        this.atributosCrear = this.ordenarCampos(response.body['data'], 'orden', 'asc');

        const hash = {};
        this.atributosCrear = this.atributosCrear.filter(function (current) {
          const exists = !hash[current.nombreCampo] || false;
          hash[current.nombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosCrear.length; index++) {
          if (this.atributosCrear[index]['caracteresValidos'] === null) {
            this.atributosCrear[index]['caracteresValidos'] = '';
          }
        }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage === 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
      if (errorMessage !== null) {
        this.status = 'error';
      }
    }
  }

  async plantillaFormularioDep() {
    try {
      this.formularioAtrib.IdEmpresa = this.identity.idEmpresa;
      this.formularioAtrib.IdPerfil = this.identity.idPerfil;
      this.formularioAtrib.Pantalla = 'ff_admi_altadependientes.aspx';
      const response = await this._dependienteService.getFormularioDependienteCotizar(this.formularioAtrib, this.token);
      if (response.body['data']) {
        this.atributosCrearDep = response.body['data'];
        this.atributosCrearDep = this.ordenarCampos(response.body['data'], 'cpOrden', 'asc');
        this.atributosCrearDep = this.ordenarCampos(response.body['data'], 'orden', 'asc');

        const hash = {};
        this.atributosCrearDep = this.atributosCrearDep.filter(function (current) {
          const exists = !hash[current.nombreCampo] || false;
          hash[current.nombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosCrearDep.length; index++) {
          if (this.atributosCrearDep[index]['caracteresValidos'] === null) {
            this.atributosCrearDep[index]['caracteresValidos'] = '';
          }

        }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage === 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
      if (errorMessage !== null) {
        this.status = 'error';
      }
    }
  }

  // baja
  async plantillaBajaTitulares() {
    try {
      this.formularioAtrib.IdEmpresa = this.identity.idEmpresa;
      this.formularioAtrib.IdPerfil = this.identity.idPerfil;
      this.formularioAtrib.Pantalla = 'ff_Admi_BajaTitulares.aspx';
      const response = await this._dependienteService.getDependientesFormAtr(this.formularioAtrib, this.token);
      if (response.body['data']) {
        this.atributosBajaT = response.body['data'];
        this.atributosBajaT = this.ordenarCampos(response.body['data'], 'cpOrden', 'asc');
        this.atributosBajaT = this.ordenarCampos(response.body['data'], 'orden', 'asc');

        const hash = {};
        this.atributosBajaT = this.atributosBajaT.filter(function (current) {
          const exists = !hash[current.nombreCampo] || false;
          hash[current.nombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosBajaT.length; index++) {
          if (this.atributosBajaT[index]['caracteresValidos'] === null) {
            this.atributosBajaT[index]['caracteresValidos'] = '';
          }
        }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage === 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
      if (errorMessage !== null) {
        this.status = 'error';
      }
    }
  }

  async plantillaBajaDependientes() {
    try {
      this.formularioAtrib.IdEmpresa = this.identity.idEmpresa;
      this.formularioAtrib.IdPerfil = this.identity.idPerfil;
      this.formularioAtrib.Pantalla = 'ff_Admi_BajaDependientes.aspx';
      const response = await this._dependienteService.getFormularioDependienteCotizar(this.formularioAtrib, this.token);
      if (response.body['data']) {
        this.atributosBajaD = response.body['data'];
        this.atributosBajaD = this.ordenarCampos(response.body['data'], 'cpOrden', 'asc');
        this.atributosBajaD = this.ordenarCampos(response.body['data'], 'orden', 'asc');

        const hash = {};
        this.atributosBajaD = this.atributosBajaD.filter(function (current) {
          const exists = !hash[current.nombreCampo] || false;
          hash[current.nombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosBajaD.length; index++) {
          if (this.atributosBajaD[index]['caracteresValidos'] === null) {
            this.atributosBajaD[index]['caracteresValidos'] = '';
          }
        }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage === 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
      if (errorMessage !== null) {
        this.status = 'error';
      }
    }
  }

  plantillaModTitulares() {
    try {
      this.formularioAtrib.IdEmpresa = this.identity.idEmpresa;
      this.formularioAtrib.IdPerfil = this.identity.idPerfil;
      this.formularioAtrib.Pantalla = 'ff_Admi_ActualizaTitulares.aspx';
      this.formularioAtrib.NumeroEmpleado = this.identity.numEmpleado;
      const response: any = this._dependienteService.getFormularioDependienteCotizar(this.formularioAtrib, this.token);
      if (response.body['data']) {
        this.atributosModificarT = response.body['data'];
        this.atributosModificarT = this.ordenarCampos(response.body['data'], 'cpOrden', 'asc');
        this.atributosModificarT = this.ordenarCampos(response.body['data'], 'orden', 'asc');

        const hash = {};
        this.atributosModificarT = this.atributosModificarT.filter(function (current) {
          const exists = !hash[current.nombreCampo] || false;
          hash[current.nombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosModificarT.length; index++) {
          if (this.atributosModificarT[index]['caracteresValidos'] === null) {
            this.atributosModificarT[index]['caracteresValidos'] = '';
          }

        }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage === 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
      if (errorMessage !== null) {
        this.status = 'error';
      }
    }
  }

  async plantillaModDependientes() {
    try {
      this.formularioAtrib.IdEmpresa = this.identity.idEmpresa;
      this.formularioAtrib.IdPerfil = this.identity.idPerfil;
      this.formularioAtrib.Pantalla = 'ff_Admi_ActualizaDependientes.aspx';
      this.formularioAtrib.NumeroEmpleado = this.identity.numEmpleado;
      const response = await this._dependienteService.getFormularioDependienteCotizar(this.formularioAtrib, this.token);
      if (response.body['data']) {
        this.atributosModificarD = response.body['data'];
        this.atributosModificarD = this.ordenarCampos(response.body['data'], 'cpOrden', 'asc');
        this.atributosModificarD = this.ordenarCampos(response.body['data'], 'orden', 'asc');

        const hash = {};
        this.atributosModificarD = this.atributosModificarD.filter(function (current) {
          const exists = !hash[current.nombreCampo] || false;
          hash[current.nombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosModificarD.length; index++) {
          if (this.atributosModificarD[index]['caracteresValidos'] === null) {
            this.atributosModificarD[index]['caracteresValidos'] = '';
          }
        }
      }
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage === 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
      if (errorMessage !== null) {
        this.status = 'error';
      }
    }
  }

  async plantillaSexo() {
    try {
      this.comboSexo = await this._dependienteService.getSexos(this.token);
    } catch (error) {
      error !== null ? this.status = 'error' : null;
    }
  }

  async plantillaPerfil() {
    try {
      this.comboPerfiles = await this._dependienteService.getPerfilesT(this.token, this.identity.idEmpresa);
    } catch (error) {
      error !== null ? this.status = 'error' : null;
    }
  }

  async plantillaOperacionesEmpresa() {
    try {
      const response = await this._titularesService.getOperacionesEmpresa(this.token, this.identity.idEmpresa);
      this.comboOperaciones = response;
      this.comboOperacionesBackup = [...this.comboOperaciones];
    } catch (error) {
      error !== null ? this.status = 'error' : null;
    }
  }

  get pantallaB3Habilitada(): boolean {
    return !this.configuracionFlujo.configurado
      || this.configuracionFlujo.flujoPantalla === 'B3';
  }

  get flujoPantallaActual(): string {
    return this.configuracionFlujo && this.configuracionFlujo.flujoPantalla === 'B2'
      ? 'B2' : 'B3';
  }

  get esFlujoB2(): boolean {
    return this.flujoPantallaActual === 'B2';
  }

  cambiarFlujoPantalla() {
    this.limpiaDatos();
    this.parametroAcceso = null;
  }

  async crearFormatoSegunFlujo(formato: any) {
    if (this.esFlujoB2) {
      await this.crearFormatoTxtB2(formato);
    } else {
      await this.crearFormato(formato);
    }
  }

  async descargarTxtOperacionSeleccionada() {
    const selector = <HTMLSelectElement>document.getElementById('operacion');
    const operacion = selector ? Number(selector.value) : 0;
    if (!operacion) {
      swal('Atención', 'Selecciona primero el tipo de operación.', 'warning');
      return;
    }
    await this.crearFormatoTxtB2(operacion);
  }

  seleccionarArchivoTxtB2() {
    const input = <HTMLInputElement>document.getElementById('inputTxtB2');
    if (input) input.click();
  }

  async mostrarArchivoTxtB2(event: any) {
    this.archivoTxtB2 = null;
    this.documentoTxtB2 = null;
    this.nombreArchivoTxtB2 = 'Ningun archivo seleccionado';
    const archivo: File = event && event.target && event.target.files
      ? event.target.files[0] : null;
    if (!archivo) return;
    if (!/\.txt$/i.test(archivo.name)) {
      swal('Archivo invalido', 'Selecciona un archivo con extension .txt.', 'warning');
      return;
    }
    if (archivo.size > 5 * 1024 * 1024) {
      swal('Archivo invalido', 'El TXT no puede exceder 5 MB.', 'warning');
      return;
    }
    try {
      const contenido = await this.leerArchivoTxt(archivo);
      this.documentoTxtB2 = CargaMasivaTxtParser.parse(contenido);
      this.archivoTxtB2 = archivo;
      this.nombreArchivoTxtB2 = archivo.name;
    } catch (error) {
      swal('TXT no valido', error && error.message
        ? error.message : 'No fue posible leer el archivo.', 'error');
    }
  }

  async iniciarOperacionTxtB2() {
    const selector = <HTMLSelectElement>document.getElementById('operacion');
    const idOperacion = selector ? Number(selector.value) : 0;
    if (!this.esFlujoB2 || !idOperacion || !this.archivoTxtB2 || this.procesandoTxtB2) {
      swal('Datos incompletos', 'Selecciona una operacion y un archivo TXT valido.', 'warning');
      return;
    }
    this.procesandoTxtB2 = true;
    this.mostrarReporte = false;
    this.listaResultados = [];
    this.rerporteCargaMasiva = [];
    this.iniciarTrazaCarga();
    this.rerporteCargaMasiva.push(this.generaLog('[B2] Archivo recibido y validado en navegador.'));
    swal({
      title: 'Procesando TXT',
      html: '<small>Se aplicaran las validaciones y el procedimiento configurados en B2.</small>',
      type: 'info',
      onOpen: () => swal.showLoading(),
      allowOutsideClick: false,
      allowEscapeKey: false
    });
    try {
      const modo: 'PRIMER_ERROR' | 'TODOS' = this.modoEjecucion === 1
        ? 'TODOS' : 'PRIMER_ERROR';
      const response: any = await this._titularesService.ejecutarCargaMasivaTxtB2(
        this.token, Number(this.identity.idEmpresa), idOperacion, modo, this.archivoTxtB2);
      this.idTrazaCarga = response.idTraza || this.idTrazaCarga;
      this.rerporteCargaMasiva = (response.log || []).map(linea => String(linea));
      for (const registro of (response.registros || [])) {
        this.agregarResultados(this.formatFecha(''), registro.renglon,
          registro.msg, registro.code);
      }
      this.estadoTrazaCarga = response.resultado === 'OK' ? 'COMPLETADA' : 'CON ERRORES';
      this.mostrarReporte = true;
      this.mostrarMensajeReporte = this.listaResultados.length === 0;
      await this.respaldarTrazaCarga(this.estadoTrazaCarga);
      swal(response.resultado === 'OK' ? 'Carga terminada' : 'Carga con errores',
        `${response.correctos || 0} correctos; ${response.errores || 0} con error.`,
        response.resultado === 'OK' ? 'success' : 'warning');
    } catch (error) {
      const respuesta = error && error.error ? error.error : null;
      if (respuesta && respuesta.idTraza) this.idTrazaCarga = respuesta.idTraza;
      const mensaje = respuesta && respuesta.mensaje
        ? respuesta.mensaje : 'No fue posible ejecutar la carga TXT B2.';
      this.rerporteCargaMasiva.push(this.generaLog('[ERROR] ' + mensaje));
      this.estadoTrazaCarga = 'ERROR';
      await this.respaldarTrazaCarga('ERROR').catch(() => this.cerrarTrazaEnNavegador());
      swal('Error', mensaje, 'error');
    } finally {
      this.procesandoTxtB2 = false;
    }
  }

  private leerArchivoTxt(archivo: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const lector = new FileReader();
      lector.onload = () => resolve(String(lector.result || ''));
      lector.onerror = () => reject(new Error('No fue posible leer el archivo TXT.'));
      lector.readAsText(archivo);
    });
  }

  /**
   * Genera una guía TXT con la gramática que consume el parser legacy B2.
   * Es un archivo de apoyo; la ejecución se realiza desde BF3 y el WS vuelve
   * a aplicar la plantilla, las validaciones y el procedimiento configurado
   * para B2 antes de procesar cada renglón.
   */
  async crearFormatoTxtB2(formato: any) {
    const operacion = this.datosOperacion(formato, 0);
    if (!operacion || !operacion.plantilla) {
      swal('Formato no disponible', 'No se encontró la plantilla de la operación seleccionada.', 'warning');
      return;
    }

    try {
      const response: any = await this._dependienteService.getDependientesFormAtrGen(
        operacion.plantilla, this.token);
      const ordenados = this.ordenarCampos(response || [], 'cpOrden', 'asc');
      const campos = [];
      const vistos = {};

      for (const atributo of ordenados) {
        const nombre = String(atributo.caNombreCampo || atributo.nombreCampo || '').trim();
        if (nombre && !vistos[nombre.toUpperCase()]) {
          vistos[nombre.toUpperCase()] = true;
          campos.push({ nombre: nombre, atributo: atributo });
        }
      }

      if (campos.length === 0) {
        throw new Error('La plantilla no contiene campos descargables.');
      }

      const valores = campos.map(campo => this.valorEjemploTxtB2(campo.nombre, campo.atributo));
      const lineas = [
        '# Documento de ejemplo para Carga Masiva B2',
        '# Operacion: ' + this.textoTxtSeguro(operacion.nombre || formato),
        '# Empresa: ' + Number(this.identity.idEmpresa),
        '# Sustituya los valores de ejemplo sin cambiar nombres, orden ni separador.',
        '@commonFields:',
        '',
        '@fieldNames:' + campos.map(campo => campo.nombre).join(','),
        '@data:',
        valores.join('|'),
        ''
      ];
      const contenido = lineas.join('\r\n');
      const nombre = 'B2_' + this.nombreArchivoSeguro(operacion.nombre || 'CargaMasiva')
        + '_Empresa_' + Number(this.identity.idEmpresa) + '.txt';
      saveAs(new Blob([contenido], { type: 'text/plain;charset=us-ascii' }), nombre);
    } catch (error) {
      swal('Error', 'No fue posible generar el ejemplo TXT de B2 para esta operación.', 'error');
    }
  }

  private valorEjemploTxtB2(nombre: string, atributo: any): string {
    const campo = nombre.toUpperCase();
    if (campo === 'EMIDEMPRESA' || campo === 'EMIDEMPRESAORIGEN') {
      return String(Number(this.identity.idEmpresa));
    }
    if (campo.indexOf('NUMEROEMPLEADO') >= 0) return 'DUMMY001';
    if (campo.indexOf('APELLIDOPATERNO') >= 0) return 'PRUEBA';
    if (campo.indexOf('APELLIDOMATERNO') >= 0) return 'USUARIO';
    if (campo === 'EMNOMBRE1' || campo === 'EMNOMBRE2') return 'DEMO';
    if (campo.indexOf('CORREO') >= 0 || campo.indexOf('EMAIL') >= 0) {
      return 'usuario.prueba@example.com';
    }
    if (campo.indexOf('FECHA') >= 0 || (atributo && atributo.caTipoDato === 'D')) {
      return '01/01/1990';
    }
    if (campo.indexOf('SEXO') >= 0) return 'M';
    if (campo.indexOf('RFC') >= 0) return 'XAXX010101000';
    if (campo.indexOf('CURP') >= 0) return 'XEXX010101HNEXXXA4';
    if (atributo && (atributo.caTipoDato === 'N' || atributo.caTipoDato === 'E'
        || atributo.caTipoDato === 'M')) return '0';
    return '';
  }

  private textoTxtSeguro(value: any): string {
    return String(value || '').replace(/[\r\n|]/g, ' ').replace(/[^\x20-\x7E]/g, '').trim();
  }

  private nombreArchivoSeguro(value: any): string {
    const limpio = this.textoTxtSeguro(value).replace(/[^A-Za-z0-9_-]+/g, '_');
    return limpio.replace(/^_+|_+$/g, '') || 'CargaMasiva';
  }

  async cargarConfiguracionFlujo() {
    if (!this.identity || !this.identity.idEmpresa) return;
    this.cargandoFlujo = true;
    try {
      const response: any = await this._titularesService.getConfiguracionFlujoCarga(
        this.token, Number(this.identity.idEmpresa));
      this.configuracionFlujo = {
        idEmpresa: Number(this.identity.idEmpresa),
        flujoPantalla: response && response.flujoPantalla || 'B3',
        flujoAutomatico: response && response.flujoAutomatico || 'B2',
        configurado: Boolean(response && response.configurado)
      };
    } catch (error) {
      this.configuracionFlujo = {
        idEmpresa: Number(this.identity.idEmpresa),
        flujoPantalla: 'B3', flujoAutomatico: 'B2', configurado: false
      };
      swal('Aviso', 'No fue posible consultar la parametrización B2/B3.', 'warning');
    } finally {
      this.cargandoFlujo = false;
    }
  }

  async guardarConfiguracionFlujo() {
    if (!this.identity || !this.identity.idEmpresa || this.guardandoFlujo) return;
    this.guardandoFlujo = true;
    try {
      const response: any = await this._titularesService.guardarConfiguracionFlujoCarga(
        this.token, Number(this.identity.idEmpresa), {
          flujoPantalla: this.configuracionFlujo.flujoPantalla,
          flujoAutomatico: this.configuracionFlujo.flujoAutomatico
        });
      this.configuracionFlujo = {
        ...this.configuracionFlujo,
        ...response,
        configurado: true
      };
      if (!this.pantallaB3Habilitada) this.limpiaDatos();
      swal('Configuración guardada', 'Los flujos de pantalla y proceso automático quedaron actualizados.', 'success');
    } catch (error) {
      swal('Error', 'No fue posible guardar la parametrización B2/B3.', 'error');
    } finally {
      this.guardandoFlujo = false;
    }
  }

  // plantilla generica
  async plantillaFormularioGen(plantilla: any) {
    try {
      const response: any = await this._dependienteService.getDependientesFormAtrGen(plantilla, this.token);
      this.obtenCatalogoPlantilla1(plantilla);
      this.atributosCrear2 = response[0];
      this.atributosCatalogo = response;
      this.atributosCrear2 = this.ordenarCampos(response, 'cpOrden', 'asc');
      this.atributosCrear2 = this.ordenarCampos(response, 'orden', 'asc');

      const hash = {};
      if (this.atributosCrear2[0].nombreCampo === undefined && this.atributosCrear2[0].caNombreCampo !== undefined) {
        this.atributosCrear2 = this.atributosCrear2.filter(function (current) {
          const exists = !hash[current.caNombreCampo] || false;
          hash[current.caNombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosCrear2.length; index++) {
          if (this.atributosCrear2[index]['caCaracteresValidos'] === null) {
            this.atributosCrear2[index]['caCaracteresValidos'] = '';
          }
        }
      } else {
        this.atributosCrear2 = this.atributosCrear2.filter(function (current) {
          const exists = !hash[current.nombreCampo] || false;
          hash[current.nombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosCrear2.length; index++) {
          if (this.atributosCrear2[index]['caracteresValidos'] === null) {
            this.atributosCrear2[index]['caracteresValidos'] = '';
          }
        }
      }
      return 1;
    } catch (error) {
      const errorMessage = <any>error;
      if (errorMessage === 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
      if (errorMessage !== null) {
        this.status = 'error';
      }
      return 0;
    }
  }
  // Crear archivo layout para descargar a partir de idPlantilla
  async plantillaFormularioGenImp(plantilla: any) {
    try {
      const response: any = await this._dependienteService.getDependientesFormAtrGen(plantilla, this.token);
      this.atributosCrear2 = response[0];
      this.atributosCatalogo = response;
      this.atributosCrear2 = this.ordenarCampos(response, 'cpOrden', 'asc');
      this.atributosCrear2 = this.ordenarCampos(response, 'orden', 'asc');


      const hash = {};
      if (this.atributosCrear2[0].nombreCampo === undefined && this.atributosCrear2[0].caNombreCampo !== undefined) {
        this.atributosCrear2 = this.atributosCrear2.filter(function (current) {
          const exists = !hash[current.caNombreCampo] || false;
          hash[current.caNombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosCrear2.length; index++) {
          if (this.atributosCrear2[index]['caCaracteresValidos'] === null) {
            this.atributosCrear2[index]['caCaracteresValidos'] = '';
          }
        }
      } else {
        this.atributosCrear2 = this.atributosCrear2.filter(function (current) {
          const exists = !hash[current.nombreCampo] || false;
          hash[current.nombreCampo] = true;
          return exists;
        });
        for (let index = 0; index < this.atributosCrear2.length; index++) {
          if (this.atributosCrear2[index]['caracteresValidos'] === null) {
            this.atributosCrear2[index]['caracteresValidos'] = '';
          }
        }
      }

      this.obtenCatalogoPlantilla(plantilla);
      return 1;
    } catch (error) {
      const errorMessage = <any>error;
      swal({
        title: '',
        html: '<small style="color: grey; text-align: justify;">Ocurrio un error al obtener la plantilla!</small>',
        type: 'error',
        timer: 3000,
      }
      );
      if (errorMessage === 'Unauthorized') {
        swal({
          title: '¡La sesión ha expirado!',
          html: '<small style="color: grey; text-align: justify;">Inicia sesión nuevamente.</small>',
          type: 'error',
          confirmButtonText: 'Aceptar',
        });
        this.logout();
      }
      if (errorMessage !== null) {
        this.status = 'error';
      }
      return 0;
    }

  }
  // FIN PLANTILLAS
  converDate(date) {
    return new Date(date.split('T')[0].split('-')) || null;
  }

  ordenarCampos(data, key, orden) {
    return data.sort(function (a, b) {
      const x = a[key], y = b[key];

      if (orden === 'asc') {
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
      }

      if (orden === 'desc') {
        return ((x > y) ? -1 : ((x < y) ? 1 : 0));
      }
    });
  }

  capturar(e = 0) {
    this.SexhasChanged = true;
    this.verSeleccion = this.opcionSeleccionado;
  }

  capturarPerfil(e = 0) {
    this.SexhasChanged = true;
    this.verSeleccion = this.opcionSeleccionado;
  }

  logout() {
    this._empleadoService.logout();
  }

  async titular() {
    try {
      this.titularAll = await this._empleadoService.getAllEmpleadoWS(this.identity.id, this.token);
      this.to = this.titularAll.emCorreoElectronico;
      if (this.titularAll.emUsuarioAdd === null) {
        this.titularAll.emUsuarioAdd = '';
      }
    } catch (error) {
      error !== null ? this.status = 'error' : null;
    }
  }

  fecha() {
    const y = new Date().getFullYear();
    let m = new Date().getMonth();
    const d = new Date().getDate();
    m = m + 1;
    let mes;
    let dia;
    if (m < 10) {
      mes = '0' + m;
    } else {
      mes = m;
    }
    if (d < 10) {
      dia = '0' + d;
    } else {
      dia = d;
    }
    const fechaactual = y + '-' + mes + '-' + dia;
    return fechaactual;
  }

  restaFechas = function (f1, f2) {
    const aFecha1 = f1.split('-');
    const aFecha2 = f2.split('-');
    const fFecha1 = Date.UTC(aFecha1[2], aFecha1[1] - 1, aFecha1[0]);
    const fFecha2 = Date.UTC(aFecha2[2], aFecha2[1] - 1, aFecha2[0]);
    const dif = fFecha2 - fFecha1;
    const dias = Math.floor(dif / (1000 * 60 * 60 * 24));
    return dias;
  };

  async getInformacionEmpresa() {
    try {
      await this._empresaService.getInfoEmpresa(this.identity.idEmpresa);
    } catch (error) {
      error !== null ? this.status = 'error' : null;
    }
  }

  // Pendiente
  contarRepetidos(array: any, buscar: any) {
    let contador = 0;
    for (let index = 0; index < array.length; index++) {
      if (array[index] === buscar) {
        contador++;
      }
    }
    return contador;
  }

  calcularEdad(fecha) {
    const hoy = new Date();
    const cumpleanos = new Date(fecha);
    let edad = hoy.getFullYear() - cumpleanos.getFullYear();
    const m = hoy.getMonth() - cumpleanos.getMonth();

    if (m < 0 || (m === 0 && hoy.getDate() < cumpleanos.getDate())) {
      edad--;
    }
    return edad;
  }
  // Fin pendiente

  ordenFecha(fecha) {
    if (fecha) {
      const separador = 't';
      const separador2 = '-';
      fecha = String(fecha);
      const fechaNacimiento = fecha.toLowerCase().split(separador);
      const fechaNacimiento2 = fechaNacimiento[0].split(separador2);
      fecha = fechaNacimiento2[2] + '/' + fechaNacimiento2[1] + '/' + fechaNacimiento2[0];
    } else {
      fecha = '';
    }
    return fecha;
  }

  formatDate(ddate) {
    const d = new Date(Date.parse(ddate)) || new Date(ddate);
    return d.getDay() + '-' + d.getMonth() + '-' + d.getFullYear();
  }

  async validaduplicado(param) {
    return await this._empleadoService.validarDuplicado(param);
  }

  async validaduplicadoNumeroEmpleado(param) {
    const resp: any = await this._empleadoService.validarDuplicadoNumeroEmpleado(param);
    return resp.emNumeroEmpleado;
  }

  ngOnDestroy() {
    if (this.idTrazaCarga && this.estadoTrazaCarga === 'EN PROCESO'
        && !this.trazaPersistida && !this.trazaRespaldando
        && this.rerporteCargaMasiva.length > 0) {
      this.rerporteCargaMasiva.push(this.generaLog('[INTERRUMPIDA] Se abandonó la pantalla durante el proceso.'));
      this.respaldarTrazaCarga('INTERRUMPIDA').catch(() => this.cerrarTrazaEnNavegador());
    } else if (!this.trazaRespaldando) {
      this.cerrarTrazaEnNavegador();
    }
    $('#modal-registro-dependientes').modal('hide');
    $('#modal-editar-dependientes').modal('hide');
  }

  mostrarAlert() {
    let timerInterval;
    swal({
      title: '',
      html: '<small style="color: grey; text-align: justify;">Procesando...</small>',
      onOpen: () => {
        swal.showLoading();
        timerInterval = setInterval(() => { }, 100);
      },
      onClose: () => clearInterval(timerInterval)
    });
  }

  // CREAR FORMATOS CARGA MASIVA layout/plantilla
  async crearFormato(formato: any) {
    const pl = await this.datosOperacion(formato, 0).plantilla;
    this.nombreDocumento = this.datosOperacion(formato, 0).nombre;
    this.atributosCrear2 = [];
    const resultado = await this.plantillaFormularioGenImp(pl);
    let timerInterval;
    swal({
      title: '',
      html: '<small style="color: grey; text-align: justify;">Procesando ...</small>',
      onOpen: () => {
        swal.showLoading();
        timerInterval = setInterval(() => { }, 100);
      },
      onClose: () => clearInterval(timerInterval),

    });
  }

  formatearTipo(tipo: any) {
    switch (tipo) {
      case 'T':
        return 'texto';
      case 'E':
        return 'número especifico';
      case 'N':
        return 'número';
      case 'D':
        return 'fecha dd/mm/yyyy';
      case 'M':
        return 'decimal';
      case 'S':
        return 'selección';
    }
  }

  imprimir() {
    let atributosMandar;
    let nombreArchivo;
    atributosMandar = this.atributosCrear2;
    nombreArchivo = this.nombreDocumento;

    let headers = [];
    let headersE = [];
    let headerOriginal = [];
    const aux = [];
    let data = [];
    for (const atributo of atributosMandar) {
      headerOriginal.push(atributo.caNombreCampo.trim());
      if (atributo.nombreCampo !== undefined && atributo.caNombreCampo === undefined) {
        if (parseInt(atributo.requerido, 10) === 1) {
          headers.push(atributo.etiqueta + '(Campo Requerido)');
        } else {
          headers.push(atributo.etiqueta);
        }
      } else {
        if (atributo.caDominio !== 'E') {
          const tipo = this.formatearTipo(atributo.caTipoDato);
          if (parseInt(atributo.cpRequerido, 10) === 1) {
            headers.push(atributo.caNombreCampo + '(Tipo de dato ' + tipo + ', Requerido)');
          } else {
            headers.push(atributo.caNombreCampo + '(Tipo de dato  ' + tipo + ')');
          }
        } else {
          const tipo = this.formatearTipo(atributo.caTipoDato);
          if (parseInt(atributo.cpRequerido, 10) === 1) {
            if (atributo.caNombreCampo === 'EMIdEmpresa' || atributo.caNombreCampo === 'EMIdEmpresaOrigen') {
              headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ')' + '#' + this.identity.idEmpresa);
            } else {
              headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ', Requerido)');
            }
          } else {
            if (atributo.caNombreCampo === 'EMIdEmpresa' || atributo.caNombreCampo === 'EMIdEmpresaOrigen') {
              headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ')' + '#' + this.identity.idEmpresa);
            } else {
              headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ')');
            }
          }
          data.push([...headersE]);
        }
      }
    }

    if (data[0] === undefined) {
      let timerInterval;
      swal({
        title: '',
        html: '<small style="color: grey; text-align: justify;">Procesando ...</small>',
        timer: 3000,
        onOpen: () => {
          swal.showLoading();
          timerInterval = setInterval(() => {

          }, 100);
        },
        onClose: () => {
          clearInterval(timerInterval);
          headers = [];
          headersE = [];
          headerOriginal = [];
          data = [];
          for (const atributo of atributosMandar) {
            headerOriginal.push(atributo.caNombreCampo.trim());
            if (atributo.nombreCampo !== undefined && atributo.caNombreCampo === undefined) {
              if (parseInt(atributo.requerido, 10) === 1) {
                headers.push(atributo.etiqueta + '(Campo Requerido)');
              } else {
                headers.push(atributo.etiqueta);
              }
            } else {
              if (atributo.caDominio !== 'E') {
                const tipo = this.formatearTipo(atributo.caTipoDato);
                if (parseInt(atributo.cpRequerido, 10) === 1) {
                  headers.push(atributo.caNombreCampo + '(Tipo de dato ' + tipo + ', Requerido)');
                } else {
                  headers.push(atributo.caNombreCampo + '(Tipo de dato  ' + tipo + ')');
                }
              } else {
                const tipo = this.formatearTipo(atributo.caTipoDato);
                if (parseInt(atributo.cpRequerido, 10) === 1) {
                  if (atributo.caNombreCampo === 'EMIdEmpresa' || atributo.caNombreCampo === 'EMIdEmpresaOrigen') {
                    headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ', Requerido)' + '#' + this.identity.idEmpresa);
                  } else {
                    headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ', Requerido)');
                  }
                } else {
                  //headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ')');
                  if (atributo.caNombreCampo === 'EMIdEmpresa' || atributo.caNombreCampo === 'EMIdEmpresaOrigen') {
                    headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ')' + '#' + this.identity.idEmpresa);
                  } else {
                    headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ')');
                  }
                }
                data.push([...headersE]);
              }
            }
          }
          
          this._excelService.crearArchivoExcelCatalogoEmpresa(headerOriginal, headers, this.catalogos, this.catalogos, this.catalogos, headers, data, nombreArchivo + this.identity.nomEmpresa, true);
        }
      });
    } else {

      this._excelService.crearArchivoExcelCatalogoEmpresa(headerOriginal, headers, this.catalogos, this.catalogos, this.catalogos, headers, headersE, nombreArchivo + '_' + this.identity.nomEmpresa + '_', true);
    }
  }
  // Limpiar pantalla al cambiar el tipo de operacion o inciar el proceso de carga masiva
  limpiaDatos() {
    this.borrarArchivo();
    const archivo = <HTMLInputElement>document.getElementById('input');
    if (archivo) {
      archivo.value = '';
    }
    this.renglones = null;
    this.mostrarReporte = false;
    this.archivoCargado = false;
    this.listaResultados = [];
  }

  cambiarOperacion() {
    this.limpiaDatos();
    this.archivoTxtB2 = null;
    this.documentoTxtB2 = null;
    this.nombreArchivoTxtB2 = 'Ningun archivo seleccionado';
    this.accesoSistema = 1;
    const operacion = this.datosOperacion((<HTMLSelectElement>document.getElementById('operacion')).value, 0);
    this.parametroAcceso = operacion && operacion.parametroAcceso ? operacion.parametroAcceso : null;
  }

  mostrarArchivoSeleccionado() {
    this.mostrarReporte = false;
    if ($('#input')[0].files.length > 0) {
      let nameForFile = $('#input')[0].files[0].name;
      nameForFile = nameForFile.length > 27 ? nameForFile.substring(0, 24) + '...' : nameForFile;
      $('#selectedFileName').text(nameForFile);
    }
    this.archivoCargado = false;
    this.listaResultados = [];
  }

  agregarResultados(tiempo, renglon, mensaje, codigo) {
    this.listaResultados.push({tiempo: tiempo, renglon: renglon, mensaje: mensaje, codigo: codigo });
  }

  datosOperacion(id: any, plantilla) {
    if (id > 0) {
      for (const dato of this.comboOperaciones) {
        if (dato.opcion == id) {
          this.datosOpe = dato;
          return dato;
        }
      }
    } else {
      for (const dato of this.comboOperaciones) {
        if (dato.plantilla == plantilla) {
          this.datosOpe = dato;
          return dato;
        }
      }
    }
  }

  async encripta(password: any) {
    try {
      const response = await this._empleadoService.getPasswordEncrypt(password);
      return response.encriptada;
    } catch (error) {
      return null;
    }
  }
  // Limpiar variables y componentes al finalizar el proceso de carga masiva
  pararOperacion() {
    this.parar = true;
    if (this.idTrazaCarga && this.estadoTrazaCarga === 'EN PROCESO'
        && !this.trazaPersistida && this.rerporteCargaMasiva.length > 0) {
      this.rerporteCargaMasiva.push(this.generaLog('[CANCELADA] El usuario solicitó detener la carga.'));
      this.respaldarTrazaCarga('CANCELADA').catch(() => {
        this.cerrarTrazaEnNavegador();
      });
    } else {
      this.cerrarTrazaEnNavegador();
    }
    this.limpiaDatos();
    this.resetFormulario2();
    this.datosArchivo = '<p>Reporte--</p><br>';
    $('#selectedFileName').text('Ningún archivo seleccionado');
  }
  // Limpiar campo de seleccion de archivo para carga masiva
  borrarArchivo(){
    $('#selectedFileName').text('Ningún archivo seleccionado');
  }


  buscarFormato() {
    const inputBuscarFormato = $('#inputBuscarFormato').val().toUpperCase();
    this.comboOperaciones = [...this.comboOperacionesBackup];
    const comboOperacioneshelper = [];
    this.comboOperaciones.forEach(operacion => {
      if (operacion.nombre.includes(inputBuscarFormato)) {
        comboOperacioneshelper.push(operacion);
      }
    });
    this.comboOperaciones = comboOperacioneshelper;
  }

  validarPlantilla() {
    let salida = true;
    if (this.atributosCrear2.length > 0 && this.renglones) {
      this.encabezados = [];
      const columnas = [];
      for (const encabezado of this.atributosCrear2) {
        if (encabezado.caDominio === 'E') {
          this.encabezados.push(encabezado);
        } else {
          if (encabezado.caNombreCampo.trim() !== 'EMUsuarioUMod'
            && encabezado.caNombreCampo.trim() !== 'EMUsuarioAdd') {
            columnas.push(encabezado);
          }
        }
      }
      const renCol = this.encabezados.length;

      let j = 0;
      // Valida que los encabezados del archivo cargado coincidan con el de la plantilla
       if (this.renglones[renCol].length >= columnas.length && this.renglones[renCol][columnas.length - 1] !== null) {
        for (const atributo of columnas) {
          if (atributo.caDominio === 'C') {
            const nom1 = atributo.caNombreCampo.trim();
            let nomEti = '';
            if (atributo.cpEtiqueta !== null) {
              nomEti = atributo.cpEtiqueta.trim();
            }
            const pos = this.renglones[renCol][j].indexOf('(');
            const pos2 = nomEti.indexOf('(');
            let nom2 = this.renglones[renCol][j].substring(0, pos);
            if (pos2 > 0) {
              nomEti = nomEti.substring(0, pos2).trim();
              nom2 = nom2.trim();
            }
            if (nom1 !== nom2 && nomEti.trim() !== nom2) {
              let ban = false;
              for (const catalogo of this.catalogos) {
                if (catalogo.length === 1 ) {
                  var hasKey = (catalogo[0][''] !== undefined);

                  if ( hasKey ) {
                    let n2 = catalogo[0][''].trim();
                    n2 = n2.replace('ff_CMC', '');
                    n2 = n2.replace('General', '');
                    if (nom2.toUpperCase() === n2.toUpperCase()) {
                      ban = true;
                    }
                  }
                }

              }
              if (!ban) {
                salida = false;
                break;
              }
            }
            j++;
          }
        }
      } else {
        salida = false;
      }
    } else {
      salida = false;
    }
    return salida;
  }

  // Envio de correo
  async getEncabezadoMail() {
    try {
      const response = await this._empleadoService.getPlantillaDatos(28);
      this.plantillaSend = response[0];
      this.plantillaSend = response[0];
      this.sujeto = this.plantillaSend['sujeto'].toString();
      this.sujeto = this.sujeto.replace('#NombreEmpresa', this.identity.nomEmpresa);
      this.bodyHTML = this.plantillaSend['plantilla'].toString();
    } catch (error) { }
  }

  async getMailAdmin() {
    try {
      const response = await this._empleadoService.getPlantillaDatosAdmin(this.identity.id, this.identity.idEmpresa);
      this.datosMail = response[0];
    } catch (error) { }
  }

  async enviarMailNotificacion(nomArchivoExcel: any, blob: any, to: string, subject: string, plantilla: string, reporteResultados: any) {
    let auxPlantilla = plantilla.toString();
    auxPlantilla += '<p style=\'text-align: left;\'>Buen día,<br>Se ha concluido el proceso de masivo de #operacion. A continuación se menciona el resultado del proceso y se adjunta el detalle de los resultados obtenidos. <br> Se han procesado #total empleados, #nCorrectos correctos, #nIncorrectos incorrectos.</p><br>';
    let strTable = `<div style="background-color: #007bff!important;color: #fff!important;width: 90%;border: 1px solid black;">
                        Reporte
                    </div>
            <table class="table table-lg text-center w-100 pt-0 mt-3" style="border: 1px solid black; width: 90.5%">
                        <thead>
                            <th style="color: #ffffff;font-size: 15px;background: linear-gradient( #000000,#000000);font-weight: normal;">Renglon</th>
                            <th style="color: #ffffff;font-size: 15px;background: linear-gradient( #000000,#000000);font-weight: normal;">Codigo</th>
                            <th style="color: #ffffff;font-size: 15px;background: linear-gradient( #000000,#000000);font-weight: normal;">Mensaje</th>
                        </thead>
                        <tbody>
                          #Cuerpo

                        </tbody>
                    </table></div>`;

    const operacion = this.datosOpe.nombre;
    auxPlantilla = auxPlantilla.replace('#operacion', operacion);
    let correctos = 0;
    let incorrectos = 0;
    
    // Obtener correctas incorrectas
    const total = reporteResultados.length;
    auxPlantilla = auxPlantilla.replace('#total', total + '');
    reporteResultados.forEach(reportData => {
      if (reportData.codigo === 1) {
        correctos++;
      } else {
        incorrectos++;
      }
    });

    let cuerpo = '';
    for (const resultado of this.listaResultados) {
      cuerpo += `<tr style=\'border: 1px solid #dee2e6;\'><td style=\'text-align: center;border: 1px solid black;\'>${resultado.renglon}</td>`;
      cuerpo += `<td style=\'text-align: center;border: 1px solid black;\'>${resultado.codigo}</td>`;
      cuerpo += `<td style=\'text-align: center;border: 1px solid black;\'>${resultado.mensaje}</td></tr>`;
    }
    auxPlantilla = auxPlantilla.replace('#nCorrectos', correctos + '');
    auxPlantilla = auxPlantilla.replace('#nIncorrectos', incorrectos + '');

    strTable = strTable.replace('#Cuerpo', cuerpo);
    if (this.boolEnvia) {
      this.destinatarios[0] = this.destinatarios[0];
    } else {
      this.destinatarios[0] = this.destinatarios[0] + this.correoAdmin;
    }
    to = this.destinatarios[0];
    let cc = 'beflex@mx.lockton.com';
    if (this.destinatarios[1].length > 0) {
      cc = this.destinatarios[1];
    }
    const bcc = this.destinatarios[2];
    if (blob) {
      const file = new File([blob], nomArchivoExcel);
      const form = new FormData();
      form.append('file', file);
      await this._empleadoService.sendMailUnificado(to, cc, bcc, subject, auxPlantilla, '', form, '', '', 28, this.token);
    }
  }

  crearArchivoPrueba(catalogoPos: any, headers: any, data: any, nombreArchivo: any) {
    const plantillaCompleta = this.atributosCatalogo;
    this._excelService.crearArchivoExcelNuevo3(this.catalogos, this.catalogos, nombreArchivo);
  }

  imprimirConCatalogo(formato: any) {
    let atributosMandar;
    let nombreArchivo;
    atributosMandar = this.atributosCrear2;
    nombreArchivo = this.nombreDocumento;
    let headersEtiquetas = [];
    let headers = [];
    let headersE = [];
    let headerOriginal = [];
    const aux = [];
    let data = [];
    const catalogo = [];
    const catalogoPos = [];
    let i = 0;

    for (const atributo of atributosMandar) {
      headerOriginal.push(atributo.caNombreCampo.trim());
      if (atributo.nombreCampo !== undefined && atributo.caNombreCampo === undefined) {
        if (parseInt(atributo.requerido, 10) === 1) {
          headers.push(atributo.etiqueta + '(Campo Requerido)');
        } else {
          headers.push(atributo.etiqueta);
        }
      } else {

        if (atributo.caDominio !== 'E') {
          const tipo = this.formatearTipo(atributo.caTipoDato);
          i = i + 1;
          if ((atributo.cpRangoValores !== null && atributo.cpRangoValores !== '') || atributo.caNombreCampo.trim() === 'EMIdPerfil'
              || atributo.caNombreCampo.trim() === 'EMIdEmpresa' 
              || atributo.caNombreCampo.trim() === 'EMIdEmpresaOrigen' 
              || this.catalogosPersonalizados.includes(atributo.caNombreCampo.trim())
              || atributo.caNombreCampo.trim() === 'EMIdPlan' 
              || atributo.caNombreCampo.trim() === 'EMEstadoFiscal'
              || atributo.caNombreCampo.trim() === 'EMRegimen'
              || atributo.caNombreCampo.trim() === 'EMOficina'
              || atributo.caNombreCampo.trim() === 'EMArea'
              || atributo.caNombreCampo.trim() === 'EMVIP'
              || atributo.caNombreCampo.trim() === 'EMTipoEmpleado'
              || atributo.caNombreCampo.trim() === 'EMidCentroCostos'
              || atributo.caNombreCampo.trim() === 'EMSeleccionUsuario'
              || atributo.caNombreCampo.trim() === 'CSIdCompensacion'
              || atributo.caNombreCampo.trim() === 'EMTipoCargaComp'
            ) {

            const nom = atributo.caNombreCampo.trim();
            catalogoPos.push(i);
            if (parseInt(atributo.cpRequerido, 10) === 1) {
              const nom = atributo.caNombreCampo.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
              let nom2 = '';
              if (atributo.cpEtiqueta !== null) {
                nom2 = atributo.cpEtiqueta.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                headersEtiquetas.push(nom2);
              } else {
                nom2 = atributo.caNombreCampo.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                headersEtiquetas.push(nom.replace('EMId', ''));
              }
              headers.push(nom.replace('EMId', ''));

            } else {
              const nom = atributo.caNombreCampo.trim();
              let nom2 = '';
              if (atributo.cpEtiqueta !== null) {
                nom2 = atributo.cpEtiqueta.trim();
              } else {
                nom2 = atributo.caNombreCampo.trim();
              }
              if (nom.indexOf('EMId') >= 0) {
                headers.push(nom.replace('EMId', '') + '(Tipo de dato  ' + tipo + ')');
                if (atributo.cpEtiqueta === null) {
                  nom2 = nom.replace('EMId', '') + '(Tipo de dato  ' + tipo + ')';
                }
              } else {
                headers.push(nom.replace('EM', '') + '(Tipo de dato  ' + tipo + ')');
                if (atributo.cpEtiqueta === null) {
                  nom2 = nom.replace('EM', '') + '(Tipo de dato  ' + tipo + ')';
                }
              }
              headersEtiquetas.push(nom2 + '(Tipo de dato  ' + tipo + ')');
            }
          } else {
            if (atributo.caNombreCampo.trim() !== 'EMUsuarioUMod' && atributo.caNombreCampo.trim() !== 'EMUsuarioAdd') {
              if (parseInt(atributo.cpRequerido, 10) === 1) {
                const nom = atributo.caNombreCampo.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                let nom2 = '';
                if (atributo.cpEtiqueta !== null) {
                  nom2 = atributo.cpEtiqueta.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                } else {
                  nom2 = atributo.caNombreCampo.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                }
                headersEtiquetas.push(nom2);
                headers.push(nom);

              } else {
                const nom = atributo.caNombreCampo.trim();
                let nom2 = '';
                if (atributo.cpEtiqueta !== null) {
                  nom2 = atributo.cpEtiqueta.trim();
                } else {
                  nom2 = atributo.caNombreCampo.trim();
                }
                headersEtiquetas.push(nom2 + '(Tipo de dato  ' + tipo + ')');
                headers.push(nom + '(Tipo de dato  ' + tipo + ')');
              }
            }
          }
        } else {
          const tipo = this.formatearTipo(atributo.caTipoDato);
          if (parseInt(atributo.cpRequerido, 10) === 1) {
            if (atributo.caNombreCampo === 'EMIdEmpresa' || atributo.caNombreCampo === 'EMIdEmpresaOrigen') {
              const nom = atributo.caNombreCampo.trim();
              headersE.push(nom + '(Campo tipo ' + tipo + ')' + '#' + this.identity.idEmpresa);
            } else {
              const nom = atributo.caNombreCampo.trim();
              headersE.push(nom + '(Campo tipo ' + tipo + ', Requerido)');
            }
          } else {
            if (atributo.caNombreCampo === 'EMIdEmpresa' || atributo.caNombreCampo === 'EMIdEmpresaOrigen') {
              headersE.push(
                  atributo.caNombreCampo +
                  '(Campo tipo ' + tipo + ')' +
                  '#' + this.identity.idEmpresa
                );
            } else {
              const nom = atributo.caNombreCampo.trim();
              headersE.push(nom + '(Campo tipo ' + tipo + ')');
            }
          }
          data.push([...headersE]);
        }
      }
    }

    const validacionesDependientes = this.construirValidacionesDependientesExcel();
    if (data[0] === undefined) {
      let timerInterval;
      swal({
        title: '',
        html: '<small style="color: grey; text-align: justify;">Procesando ...</small>',
        timer: 3000,
        onOpen: () => {
          swal.showLoading();
          timerInterval = setInterval(() => { }, 100);
        },
        onClose: () => {
          clearInterval(timerInterval);
          headersEtiquetas = [];
          headers = [];
          headersE = [];
          headerOriginal = [];
          const aux = [];
          data = [];
          const catalogo = [];
          const catalogoPos = [];
          let i = 0;
          for (const atributo of atributosMandar) {
            headerOriginal.push(atributo.caNombreCampo.trim());
            if (atributo.nombreCampo !== undefined && atributo.caNombreCampo === undefined) {
              if (parseInt(atributo.requerido, 10) === 1) {
                headers.push(atributo.etiqueta + '(Campo Requerido)');
              } else {
                headers.push(atributo.etiqueta);
              }

            } else {

              if (atributo.caDominio !== 'E') {
                const tipo = this.formatearTipo(atributo.caTipoDato);
                i = i + 1;
                if ((atributo.cpRangoValores !== null && atributo.cpRangoValores !== '') 
                  || atributo.caNombreCampo.trim() === 'EMIdPerfil' 
                  || atributo.caNombreCampo.trim() === 'EMIdEmpresa' 
                  || atributo.caNombreCampo.trim() === 'EMIdEmpresaOrigen'  
                  || this.catalogosPersonalizados.includes(atributo.caNombreCampo.trim()) 
                  || atributo.caNombreCampo.trim() === 'EMIdPlan' 
                  || atributo.caNombreCampo.trim() === 'EMEstadoFiscal'
                  || atributo.caNombreCampo.trim() === 'EMRegimen'
                  || atributo.caNombreCampo.trim() === 'EMOficina'
                  || atributo.caNombreCampo.trim() === 'EMArea'
                  || atributo.caNombreCampo.trim() === 'EMVIP'
                  || atributo.caNombreCampo.trim() === 'EMTipoEmpleado'
                  || atributo.caNombreCampo.trim() === 'EMidCentroCostos'
                  || atributo.caNombreCampo.trim() === 'EMSeleccionUsuario'
                  || atributo.caNombreCampo.trim() === 'CSIdCompensacion'
                  || atributo.caNombreCampo.trim() === 'EMTipoCargaComp'
                ) {
                  const nom = atributo.caNombreCampo.trim();
                  catalogo.push(nom);
                  catalogoPos.push(i);
                  if (parseInt(atributo.cpRequerido, 10) === 1) {
                    const nom = atributo.caNombreCampo.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                    let nom2 = '';
                    if (atributo.cpEtiqueta !== null) {
                      nom2 = atributo.cpEtiqueta.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                    } else {
                      nom2 = atributo.caNombreCampo.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                      nom2 = nom2.replace('EMId', '');
                    }
                    headersEtiquetas.push(nom2);
                    headers.push(nom.replace('EMId', ''));
                  } else {
                    const nom = atributo.caNombreCampo.trim();
                    let nom2 = '';
                    if (atributo.cpEtiqueta !== null) {
                      nom2 = atributo.cpEtiqueta.trim();
                    } else {
                      nom2 = atributo.caNombreCampo.trim();
                    }

                    if (nom.indexOf('EMId') >= 0) {
                      headers.push(nom.replace('EMId', '') + '(Tipo de dato  ' + tipo + ')');
                      if (atributo.cpEtiqueta === null) {
                        nom2 = nom.replace('EMId', '');
                      }
                    } else {
                      headers.push(nom.replace('EM', '') + '(Tipo de dato  ' + tipo + ')');
                      if (atributo.cpEtiqueta === null) {
                        nom2 = nom.replace('EM', '');
                      }
                    }
                    headersEtiquetas.push(nom2 + '(Tipo de dato  ' + tipo + ')');
                  }
                } else {
                  if (atributo.caNombreCampo.trim() !== 'EMUsuarioUMod' && atributo.caNombreCampo.trim() !== 'EMUsuarioAdd') {
                    if (parseInt(atributo.cpRequerido, 10) === 1) {
                      const nom = atributo.caNombreCampo.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                      let nom2 = '';
                      if (atributo.cpEtiqueta !== null) {
                        nom2 = atributo.cpEtiqueta.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                      } else {
                        nom2 = atributo.caNombreCampo.trim() + '(Tipo de dato ' + tipo + ', Requerido)';
                      }
                      headersEtiquetas.push(nom2);
                      headers.push(nom);

                    } else {
                      const nom = atributo.caNombreCampo.trim();
                      let nom2 = '';
                      if (atributo.cpEtiqueta !== null) {
                        nom2 = atributo.cpEtiqueta.trim();
                      } else {
                        nom2 = atributo.caNombreCampo.trim();
                      }
                      headers.push(nom + '(Tipo de dato  ' + tipo + ')');
                      headersEtiquetas.push(nom2 + '(Tipo de dato  ' + tipo + ')');
                    }
                  }
                }
              } else {
                const tipo = this.formatearTipo(atributo.caTipoDato);
                if (parseInt(atributo.cpRequerido, 10) === 1) {
                  if (atributo.caNombreCampo === 'EMIdEmpresa' || atributo.caNombreCampo === 'EMIdEmpresaOrigen') {
                    const nom = atributo.caNombreCampo.trim();
                    headersE.push(nom + '(Campo tipo ' + tipo + ')' + '#' + this.identity.idEmpresa);
                  } else {
                    const nom = atributo.caNombreCampo.trim();
                    headersE.push(nom + '(Campo tipo ' + tipo + ', Requerido)');
                  }
                } else {
                  if (atributo.caNombreCampo === 'EMIdEmpresa' || atributo.caNombreCampo === 'EMIdEmpresaOrigen') {
                    headersE.push(atributo.caNombreCampo + '(Campo tipo ' + tipo + ', Requerido)');
                  } else {
                    const nom = atributo.caNombreCampo.trim();
                    headersE.push(nom + '(Campo tipo ' + tipo + ')');
                  }
                }
                data.push([...headersE]);
              }
            }
          }

          this._excelService.crearArchivoExcelCatalogoEmpresa(
            headerOriginal, 
            headersEtiquetas,
            catalogo,
            this.catalogos,
            catalogoPos,
            headers,
            headersE,
            nombreArchivo + '_' + this.identity.nomEmpresa + '_',
            true,
            undefined,
            validacionesDependientes
          );
        }
      });
    } else {
      this._excelService.crearArchivoExcelCatalogoEmpresa(
        headerOriginal, 
        headersEtiquetas,
        catalogo,
        this.catalogos,
        catalogoPos,
        headers,
        headersE,
        nombreArchivo + '_' + this.identity.nomEmpresa + '_',
        true,
        undefined,
        validacionesDependientes
      );
    }
  }
  // Obtiene lista de catalogos pertenecientes a una plantilla, para su descarga
  async obtenCatalogoPlantilla(idPlantilla: any) {
    try {
      // Obtener catalogo por plantilla y empresa
      const response: any = await this._dependienteService.getDependientesFormAtrGenCatalogo(idPlantilla, this.token, this.identity.idEmpresa);
      if (response !== null) {
        if (response.length > 0) {
          let posicion = -1;
          const arDef = [];
          for (let i = 0; i < response.length; i++) {
            if (typeof (response[i]) === 'object') {
              posicion = i;
              arDef.push(response[i]);
            }
          }
          if (posicion >= 0) {
            if (arDef[arDef.length - 1].length === 1) {
              this.catalogos = [];
              const emp1 = [{ '': 'ff_CMCEmpresa' }];
              let emp2 = [];

              if (this.empresas.length > 1) {
                for (const empresa of this.empresas) {
                  let emp3 = {};
                  if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
                    emp3 = { 'key': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'value': empresa.IdEmpresa };
                  }else{
                    emp3 = { 'key': empresa.NomEmpresa, 'value': empresa.IdEmpresa };
                  }
                  emp2.push(emp3);
                }
              } else {
                emp2 = [{ 'key': this.identity.nomEmpresa, 'value': this.identity.idEmpresa }, { 'key': '', 'value': '' }];
              }
              this.catalogos.push(emp1);
              this.catalogos.push(emp2);
              this.catalogos.push(arDef[arDef.length - 1]);
              for (let i = 0; i < arDef.length - 1; i++) {
                this.catalogos.push(arDef[i]);
              }
              this.agregarCatalogoPartido(this.catalogoPerfil);
              this.agregarCatalogoPartido(this.catalogoRegimen);
              this.agregarCatalogoPartido(this.catalogoPlanes);
              this.agregarCatalogoPartido(this.catalogoEstados);
              this.agregarCatalogoPartido(this.catalogoOficina);
              this.agregarCatalogoPartido(this.catalogoArea);
              this.agregarCatalogoPartido(this.catalogoVIP);
              this.agregarCatalogoPartido(this.catalogoCentroCostos);
              this.agregarCatalogoPartido(this.catalogoTipoEmpleado);
              // Catalogo para opcion seleccion solicitud transferencia
              let co = 0;
              let catOpcionesSelec = [];
              let catOpcionesSelec2 = [];
              for (const plan of this.opcionSeleccionSolicitudCat) {
                co === 0 ? catOpcionesSelec.push(plan) : catOpcionesSelec2.push(plan);
                co++;
              }
              this.catalogos.push(catOpcionesSelec);
              this.catalogos.push(catOpcionesSelec2);
              co = 0;
              let catTipoCarga = [];
              let catTipoCarga2 = [];
              for (const tipoCarga of this.tipoCargaCompensacionCat) {
                co === 0 ? catTipoCarga.push(tipoCarga) : catTipoCarga2.push(tipoCarga);
                co++;
              }
              this.catalogos.push(catTipoCarga);
              this.catalogos.push(catTipoCarga2);
            } else {
              this.catalogos = [];
              const emp1 = [{ '': 'ff_CMCEmpresa' }];
              let emp2 = [];
              if (this.empresas.length > 1) {
                for (const empresa of this.empresas) {
                  let emp3 = {};
                  if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
                    emp3 = { 'key': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'value': empresa.IdEmpresa };
                  }else{
                    emp3 = { 'key': empresa.NomEmpresa, 'value': empresa.IdEmpresa };
                  }
                  emp2.push(emp3);
                }
              } else {
                emp2 = [{ 'key': this.identity.nomEmpresa, 'value': this.identity.idEmpresa }, { 'key': '', 'value': '' }];
              }
              this.catalogos.push(emp1);
              this.catalogos.push(emp2);
              for (let i = 0; i < arDef.length; i++) {
                this.catalogos.push(arDef[i]);
              }
              this.agregarCatalogoPartido(this.catalogoPerfil);
              this.agregarCatalogoPartido(this.catalogoRegimen);
              this.agregarCatalogoPartido(this.catalogoPlanes);
              this.agregarCatalogoPartido(this.catalogoEstados);
              this.agregarCatalogoPartido(this.catalogoOficina);
              this.agregarCatalogoPartido(this.catalogoArea);
              this.agregarCatalogoPartido(this.catalogoVIP);
              this.agregarCatalogoPartido(this.catalogoCentroCostos);
              this.agregarCatalogoPartido(this.catalogoTipoEmpleado);
              // Catalogo para opcion seleccion solicitud transferencia
              let co = 0;
              let catOpcionesSelec = [];
              let catOpcionesSelec2 = [];
              for (const plan of this.opcionSeleccionSolicitudCat) {
                co === 0 ? catOpcionesSelec.push(plan) : catOpcionesSelec2.push(plan);
                co++;
              }
              this.catalogos.push(catOpcionesSelec);
              this.catalogos.push(catOpcionesSelec2);
              co = 0;
              let catTipoCarga = [];
              let catTipoCarga2 = [];
              for (const tipoCarga of this.tipoCargaCompensacionCat) {
                co === 0 ? catTipoCarga.push(tipoCarga) : catTipoCarga2.push(tipoCarga);
                co++;
              }
              this.catalogos.push(catTipoCarga);
              this.catalogos.push(catTipoCarga2);
            }
          }
        }
      } else {
        this.catalogos = [];
        const emp1 = [{ '': 'ff_CMCEmpresa' }];
        let emp2 = [];
        if (this.empresas.length > 1) {
          for (const empresa of this.empresas) {
            let emp3 = {};
            if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
              emp3 = { 'key': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'value': empresa.IdEmpresa };
            }else{
              emp3 = { 'key': empresa.NomEmpresa, 'value': empresa.IdEmpresa };
            }
            emp2.push(emp3);
          }
        } else {
          emp2 = [{ 'key': this.identity.nomEmpresa, 'value': this.identity.idEmpresa }, { 'key': '', 'value': '' }];
        }
        this.catalogos.push(emp1);
        this.catalogos.push(emp2);
        this.agregarCatalogoPartido(this.catalogoPerfil);
        this.agregarCatalogoPartido(this.catalogoRegimen);
        this.agregarCatalogoPartido(this.catalogoPlanes);
        this.agregarCatalogoPartido(this.catalogoEstados);
        this.agregarCatalogoPartido(this.catalogoOficina);
        this.agregarCatalogoPartido(this.catalogoArea);
        this.agregarCatalogoPartido(this.catalogoVIP);
        this.agregarCatalogoPartido(this.catalogoCentroCostos);
        this.agregarCatalogoPartido(this.catalogoTipoEmpleado);
        // Catalogo para opcion seleccion solicitud transferencia
        let co = 0;
        let catOpcionesSelec = [];
        let catOpcionesSelec2 = [];
        for (const plan of this.opcionSeleccionSolicitudCat) {
          co === 0 ? catOpcionesSelec.push(plan) : catOpcionesSelec2.push(plan);
          co++;
        }
        this.catalogos.push(catOpcionesSelec);
        this.catalogos.push(catOpcionesSelec2);
        co = 0;
        let catTipoCarga = [];
        let catTipoCarga2 = [];
        for (const tipoCarga of this.tipoCargaCompensacionCat) {
          co === 0 ? catTipoCarga.push(tipoCarga) : catTipoCarga2.push(tipoCarga);
          co++;
        }
        this.catalogos.push(catTipoCarga);
        this.catalogos.push(catTipoCarga2);
      }
      this.getCatalogoPersonalizado(0, idPlantilla);
    } catch (error) {
      this.catalogos = [];
      const emp1 = [{ '': 'ff_CMCEmpresa' }];
      let emp2 = [];
      if (this.empresas.length > 1) {
        for (const empresa of this.empresas) {
          let emp3 = {};
          if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
            emp3 = { 'key': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'value': empresa.IdEmpresa };
          }else{
            emp3 = { 'key': empresa.NomEmpresa, 'value': empresa.IdEmpresa };
          }
          emp2.push(emp3);
        }
      } else {
        emp2 = [{ 'key': this.identity.nomEmpresa, 'value': this.identity.idEmpresa }, { 'key': '', 'value': '' }];
      }
      this.catalogos.push(emp1);
      this.catalogos.push(emp2);
      this.agregarCatalogoPartido(this.catalogoPerfil);
      this.agregarCatalogoPartido(this.catalogoRegimen);
      this.agregarCatalogoPartido(this.catalogoPlanes);
      this.agregarCatalogoPartido(this.catalogoEstados);
      this.agregarCatalogoPartido(this.catalogoOficina);
      this.agregarCatalogoPartido(this.catalogoArea);
      this.agregarCatalogoPartido(this.catalogoVIP);
      this.agregarCatalogoPartido(this.catalogoCentroCostos);
      this.agregarCatalogoPartido(this.catalogoTipoEmpleado);
      // Catalogo para opcion seleccion solicitud transferencia
      let co = 0;
      let catOpcionesSelec = [];
      let catOpcionesSelec2 = [];
      for (const plan of this.opcionSeleccionSolicitudCat) {
        co === 0 ? catOpcionesSelec.push(plan) : catOpcionesSelec2.push(plan);
        co++;
      }
      this.catalogos.push(catOpcionesSelec);
      this.catalogos.push(catOpcionesSelec2);
      co = 0;
      let catTipoCarga = [];
      let catTipoCarga2 = [];
      for (const tipoCarga of this.tipoCargaCompensacionCat) {
        co === 0 ? catTipoCarga.push(tipoCarga) : catTipoCarga2.push(tipoCarga);
        co++;
      }
      this.catalogos.push(catTipoCarga);
      this.catalogos.push(catTipoCarga2);
      this.getCatalogoPersonalizado(0, idPlantilla);
    }
  }
  // Creacion de plantilla para validacion en carga de documento
  async obtenCatalogoPlantilla1(idPlantilla: any) {
    try {
      // Obtener catalogo por id plantilla y empresa
      const response: any = await this._dependienteService.getDependientesFormAtrGenCatalogo(idPlantilla, this.token, this.identity.idEmpresa);
      if (response !== null) {
        if (response.length > 0) {
          let posicion = -1;
          const arDef = [];
          for (let i = 0; i < response.length; i++) {
            if (typeof (response[i]) === 'object') {
              posicion = i;
              arDef.push(response[i]);
            }
          }
          if (posicion >= 0) {
            if (arDef[arDef.length - 1].length === 1) {
              this.catalogos = [];
              const emp1 = [{ '': 'ff_CMCEmpresa' }];
              let emp2 = [];
              if (this.empresas.length > 1) {
                for (const empresa of this.empresas) {
                  let emp3 = {};
                  if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
                    emp3 = { 'key': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'value': empresa.IdEmpresa };
                  }else{
                    emp3 = { 'key': empresa.NomEmpresa, 'value': empresa.IdEmpresa };
                  }
                  emp2.push(emp3);
                }
              } else {
                emp2 = [{ 'key': this.identity.nomEmpresa, 'value': this.identity.idEmpresa }, { 'key': '', 'value': '' }];
              }
              this.catalogos.push(emp1);
              this.catalogos.push(emp2);
              this.catalogos.push(arDef[arDef.length - 1]);
              for (let i = 0; i < arDef.length - 1; i++) {
                this.catalogos.push(arDef[i]);
              }
              this.agregarCatalogoPartido(this.catalogoPerfil);
              this.agregarCatalogoPartido(this.catalogoRegimen);
              this.agregarCatalogoPartido(this.catalogoPlanes);
              this.agregarCatalogoPartido(this.catalogoEstados);
              this.agregarCatalogoPartido(this.catalogoOficina);
              this.agregarCatalogoPartido(this.catalogoArea);
              this.agregarCatalogoPartido(this.catalogoVIP);
              this.agregarCatalogoPartido(this.catalogoCentroCostos);
              this.agregarCatalogoPartido(this.catalogoTipoEmpleado);
              // Catalogo para opcion seleccion solicitud transferencia
              let co = 0;
              let catOpcionesSelec = [];
              let catOpcionesSelec2 = [];
              for (const plan of this.opcionSeleccionSolicitudCat) {
                co === 0 ? catOpcionesSelec.push(plan) : catOpcionesSelec2.push(plan);
                co++;
              }
              this.catalogos.push(catOpcionesSelec);
              this.catalogos.push(catOpcionesSelec2);
              co = 0;
              let catTipoCarga = [];
              let catTipoCarga2 = [];
              for (const tipoCarga of this.tipoCargaCompensacionCat) {
                co === 0 ? catTipoCarga.push(tipoCarga) : catTipoCarga2.push(tipoCarga);
                co++;
              }
              this.catalogos.push(catTipoCarga);
              this.catalogos.push(catTipoCarga2);
            } else {
              this.catalogos = [];

              const emp1 = [{ '': 'ff_CMCEmpresa' }];
              let emp2 = [];
              if (this.empresas.length > 1) {
                for (const empresa of this.empresas) {
                  let emp3 = {};
                  if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
                    emp3 = { 'key': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'value': empresa.IdEmpresa };
                  }else{
                    emp3 = { 'key': empresa.NomEmpresa, 'value': empresa.IdEmpresa };
                  }
                  emp2.push(emp3);
                }
              } else {
                emp2 = [{ 'key': this.identity.nomEmpresa, 'value': this.identity.idEmpresa }, { 'key': '', 'value': '' }];
              }
              this.catalogos.push(emp1);
              this.catalogos.push(emp2);
              for (let i = 0; i < arDef.length; i++) {
                this.catalogos.push(arDef[i]);
              }
              this.agregarCatalogoPartido(this.catalogoPerfil);
              this.agregarCatalogoPartido(this.catalogoRegimen);
              this.agregarCatalogoPartido(this.catalogoPlanes);
              this.agregarCatalogoPartido(this.catalogoEstados);
              this.agregarCatalogoPartido(this.catalogoOficina);
              this.agregarCatalogoPartido(this.catalogoArea);
              this.agregarCatalogoPartido(this.catalogoVIP);
              this.agregarCatalogoPartido(this.catalogoCentroCostos);
              this.agregarCatalogoPartido(this.catalogoTipoEmpleado);
              // Catalogo para opcion seleccion solicitud transferencia
              let co = 0;
              let catOpcionesSelec = [];
              let catOpcionesSelec2 = [];
              for (const plan of this.opcionSeleccionSolicitudCat) {
                co === 0 ? catOpcionesSelec.push(plan) : catOpcionesSelec2.push(plan);
                co++;
              }
              this.catalogos.push(catOpcionesSelec);
              this.catalogos.push(catOpcionesSelec2);
              co = 0;
              let catTipoCarga = [];
              let catTipoCarga2 = [];
              for (const tipoCarga of this.tipoCargaCompensacionCat) {
                co === 0 ? catTipoCarga.push(tipoCarga) : catTipoCarga2.push(tipoCarga);
                co++;
              }
              this.catalogos.push(catTipoCarga);
              this.catalogos.push(catTipoCarga2);
            }
          }
        }
      } else {
        this.catalogos = [];
        const emp1 = [{ '': 'ff_CMCEmpresa' }];
        let emp2 = [];
        if (this.empresas.length > 1) {
          for (const empresa of this.empresas) {
            let emp3 = {};
            if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
              emp3 = { 'key': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'value': empresa.IdEmpresa };
            }else{
              emp3 = { 'key': empresa.NomEmpresa, 'value': empresa.IdEmpresa };
            }
            emp2.push(emp3);
          }
        } else {
          emp2 = [{ 'key': this.identity.nomEmpresa, 'value': this.identity.idEmpresa }, { 'key': '', 'value': '' }];
        }
        this.catalogos.push(emp1);
        this.catalogos.push(emp2);
        this.agregarCatalogoPartido(this.catalogoPerfil);
        this.agregarCatalogoPartido(this.catalogoRegimen);
        this.agregarCatalogoPartido(this.catalogoPlanes);
        this.agregarCatalogoPartido(this.catalogoEstados);
        this.agregarCatalogoPartido(this.catalogoOficina);
        this.agregarCatalogoPartido(this.catalogoArea);
        this.agregarCatalogoPartido(this.catalogoVIP);
        this.agregarCatalogoPartido(this.catalogoCentroCostos);
        this.agregarCatalogoPartido(this.catalogoTipoEmpleado);
        // Catalogo para opcion seleccion solicitud transferencia
        let co = 0;
        let catOpcionesSelec = [];
        let catOpcionesSelec2 = [];
        for (const plan of this.opcionSeleccionSolicitudCat) {
          co === 0 ? catOpcionesSelec.push(plan) : catOpcionesSelec2.push(plan);
          co++;
        }
        this.catalogos.push(catOpcionesSelec);
        this.catalogos.push(catOpcionesSelec2);
        co = 0;
        let catTipoCarga = [];
        let catTipoCarga2 = [];
        for (const tipoCarga of this.tipoCargaCompensacionCat) {
          co === 0 ? catTipoCarga.push(tipoCarga) : catTipoCarga2.push(tipoCarga);
          co++;
        }
        this.catalogos.push(catTipoCarga);
        this.catalogos.push(catTipoCarga2);
      }
      this.getCatalogoPersonalizado2(0, idPlantilla);
    } catch (error) {
      this.catalogos = [];
      const emp1 = [{ '': 'ff_CMCEmpresa' }];
      let emp2 = [];
      if (this.empresas.length > 1) {
        for (const empresa of this.empresas) {
          let emp3 = {};
          if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
            emp3 = { 'key': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'value': empresa.IdEmpresa };
          }else{
            emp3 = { 'key': empresa.NomEmpresa, 'value': empresa.IdEmpresa };
          }
          emp2.push(emp3);
        }
      } else {
        emp2 = [{ 'key': this.identity.nomEmpresa, 'value': this.identity.idEmpresa }, { 'key': '', 'value': '' }];
      }
      this.catalogos.push(emp1);
      this.catalogos.push(emp2);
      this.agregarCatalogoPartido(this.catalogoPerfil);
      this.agregarCatalogoPartido(this.catalogoRegimen);
      this.agregarCatalogoPartido(this.catalogoPlanes);
      this.agregarCatalogoPartido(this.catalogoEstados);
      this.agregarCatalogoPartido(this.catalogoOficina);
      this.agregarCatalogoPartido(this.catalogoArea);
      this.agregarCatalogoPartido(this.catalogoVIP);
      this.agregarCatalogoPartido(this.catalogoCentroCostos);
      this.agregarCatalogoPartido(this.catalogoTipoEmpleado);
      // Catalogo para opcion seleccion solicitud transferencia
      let co = 0;
      let catOpcionesSelec = [];
      let catOpcionesSelec2 = [];
      for (const plan of this.opcionSeleccionSolicitudCat) {
        co === 0 ? catOpcionesSelec.push(plan) : catOpcionesSelec2.push(plan);
        co++;
      }
      this.catalogos.push(catOpcionesSelec);
      this.catalogos.push(catOpcionesSelec2);
      co = 0;
      let catTipoCarga = [];
      let catTipoCarga2 = [];
      for (const tipoCarga of this.tipoCargaCompensacionCat) {
        co === 0 ? catTipoCarga.push(tipoCarga) : catTipoCarga2.push(tipoCarga);
        co++;
      }
      this.catalogos.push(catTipoCarga);
      this.catalogos.push(catTipoCarga2);
      this.getCatalogoPersonalizado2(0, idPlantilla);
    }
  }

  colocarFechaAlNombre(nombreArch: any) {
    const f = new Date();
    let nombre = `${nombreArch}${f.getFullYear()}`;
    let mes;
    let m;
    m = (f.getMonth() < 10) ? `0${f.getMonth()}` : f.getMonth();
    mes = parseInt(m) + 1;
    nombre += (f.getMonth() < 10) ? `0${mes}` : mes;
    nombre += (f.getDate() < 10) ? `0${f.getDate()}` : f.getDate();
    nombre += (f.getHours() < 10) ? `0${f.getHours()}` : f.getHours();
    nombre += (f.getMinutes() < 10) ? `0${f.getMinutes()}` : f.getMinutes();
    nombre += (f.getSeconds() < 10) ? `0${f.getSeconds()}` : f.getSeconds();
    nombre += '.xlsx';
    return nombre;
  }

  async buscaPerfilesEmpresas() {
    this.catalogoPerfil = [];
    this.empresaPerfiles = [];
    const encabezadoPerfil = { '': 'ff_CMCPerfil' };
    this.catalogoPerfil.push(encabezadoPerfil);
    for (const empresa of this.empresas) {
      try {
        const response = await this._dependienteService.getPerfilesT(this.token, empresa.IdEmpresa);
        const response2: any[] = Object.values(response);
        const catalogoPerfilEmp = [];
        for (const per of response2) {
          // +"-"+empresa.NomEmpresa
          const perfil = { 'key': per.nombrePerfil, 'value': per.idPerfil };
          const dup = this.catalogoPerfil.find(element => element.key === per.nombrePerfil);
          if (!dup) {
            this.catalogoPerfil.push(perfil);
          }
          catalogoPerfilEmp.push(perfil);
        }
        const encPE = { 'Empresa': empresa.IdEmpresa, 'Perfiles': catalogoPerfilEmp };
        this.empresaPerfiles.push(encPE);
      } catch (error) { }
    }
  }

  async buscaRegimenesEmpresas() {
    this.catalogoRegimen = [];
    this.empresaRegimenes = [];
    const encabezadoRegimen = { '': 'ff_CMCRegimen' };
    this.catalogoRegimen.push(encabezadoRegimen);
    for (const empresa of this.empresas) {
      try {
        const response: any = await this._empleadoService.getVipAreas(empresa.IdEmpresa, 'EMRegimen');
        const response2: any[] = Object.values(response || {});
        const catalogoRegimenEmp = [];
        for (const reg of response2) {
          if (reg.TEDescripcion != null && reg.TEDescripcion.trim() !== '') {
            const regimen = { 'key': reg.TEDescripcion.trim(), 'value': reg.TEIdDetalle };
            const dup = this.catalogoRegimen.find(element => element.key === regimen.key);
            if (!dup) {
              this.catalogoRegimen.push(regimen);
            }
            const dupEmpresa = catalogoRegimenEmp.find(element => element.key === regimen.key);
            if (!dupEmpresa) {
              catalogoRegimenEmp.push(regimen);
            }
          }
        }
        const encRE = { 'Empresa': empresa.IdEmpresa, 'Regimenes': catalogoRegimenEmp };
        this.empresaRegimenes.push(encRE);
      } catch (error) { }
    }
  }

  async buscaOficinaEmpresas() {
    this.catalogoOficina = [];
    this.empresaOficina = [];
    const encabezadoOficina = { '': 'ff_CMCOficina' };
    this.catalogoOficina.push(encabezadoOficina);
    for (const empresa of this.empresas) {
      try {
        const response: any = await this._empleadoService.getVipAreas(empresa.IdEmpresa, 'EMOficina');
        const response2: any[] = Object.values(response || {});
        const catalogoOficinaEmp = [];
        for (const reg of response2) {
          if (reg.TEDescripcion != null && reg.TEDescripcion.trim() !== '') {
            const oficina = { 'key': reg.TEDescripcion.trim(), 'value': reg.TEIdDetalle };
            const dup = this.catalogoOficina.find(element => element.key === oficina.key);
            if (!dup) {
              this.catalogoOficina.push(oficina);
            }
            const dupEmpresa = catalogoOficinaEmp.find(element => element.key === oficina.key);
            if (!dupEmpresa) {
              catalogoOficinaEmp.push(oficina);
            }
          }
        }
        const encRE = { 'Empresa': empresa.IdEmpresa, 'Oficina': catalogoOficinaEmp };
        this.empresaOficina.push(encRE);
      } catch (error) { }
    }
  }
  async buscaAreaEmpresas() {
    this.catalogoArea = [];
    this.empresaArea = [];
    const encabezadoArea = { '': 'ff_CMCArea' };
    this.catalogoArea.push(encabezadoArea);
    for (const empresa of this.empresas) {
      try {
        const response: any = await this._empleadoService.getVipAreas(empresa.IdEmpresa, 'EMArea');
        const response2: any[] = Object.values(response || {});
        const catalogoAreaEmp = [];
        for (const reg of response2) {
          if (reg.TEDescripcion != null && reg.TEDescripcion.trim() !== '') {
            const area = { 'key': reg.TEDescripcion.trim(), 'value': reg.TEIdDetalle };
            const dup = this.catalogoArea.find(element => element.key === area.key);
            if (!dup) {
              this.catalogoArea.push(area);
            }
            const dupEmpresa = catalogoAreaEmp.find(element => element.key === area.key);
            if (!dupEmpresa) {
              catalogoAreaEmp.push(area);
            }
          }
        }
        const encRE = { 'Empresa': empresa.IdEmpresa, 'Area': catalogoAreaEmp };
        this.empresaArea.push(encRE);
      } catch (error) { }
    }
  }

  async buscaVIPEmpresas() {
    this.catalogoVIP = [];
    this.empresaVIP = [];
    const encabezadoVIP = { '': 'ff_CMCVIP' };
    this.catalogoVIP.push(encabezadoVIP);
    for (const empresa of this.empresas) {
      try {
        const response: any = await this._empleadoService.getVipAreas(empresa.IdEmpresa, 'EMVIP');
        const response2: any[] = Object.values(response || {});
        const catalogoVIPEmp = [];
        for (const reg of response2) {
          if (reg.TEDescripcion != null && reg.TEDescripcion.trim() !== '') {
            const vip = { 'key': reg.TEDescripcion.trim(), 'value': reg.TEIdDetalle };
            const dup = this.catalogoVIP.find(element => element.key === vip.key);
            if (!dup) {
              this.catalogoVIP.push(vip);
            }
            const dupEmpresa = catalogoVIPEmp.find(element => element.key === vip.key);
            if (!dupEmpresa) {
              catalogoVIPEmp.push(vip);
            }
          }
        }
        const encRE = { 'Empresa': empresa.IdEmpresa, 'VIP': catalogoVIPEmp };
        this.empresaVIP.push(encRE);
      } catch (error) { }
    }
  }

  async buscaCentroCostosEmpresas() {
    this.catalogoCentroCostos = [];
    this.empresaCentroCostos = [];
    const encabezadoCentroCostos = { '': 'ff_CMCCentroCostos' };
    this.catalogoCentroCostos.push(encabezadoCentroCostos);
    for (const empresa of this.empresas) {
      try {
        const response: any = await this._empleadoService.getVipAreas(empresa.IdEmpresa, 'EMidCentroCostos');
        const response2: any[] = Object.values(response || {});
        const catalogoCentroCostosEmp = [];
        for (const reg of response2) {
          if (reg.TEDescripcion != null && reg.TEDescripcion.trim() !== '') {
            const cc = { 'key': reg.TEDescripcion.trim(), 'value': reg.TEIdDetalle };
            const dup = this.catalogoCentroCostos.find(element => element.key === cc.key);
            if (!dup) {
              this.catalogoCentroCostos.push(cc);
            }
            const dupEmpresa = catalogoCentroCostosEmp.find(element => element.key === cc.key);
            if (!dupEmpresa) {
              catalogoCentroCostosEmp.push(cc);
            }
          }
        }
        const encRE = { 'Empresa': empresa.IdEmpresa, 'CentroCostos': catalogoCentroCostosEmp };
        this.empresaCentroCostos.push(encRE);
      } catch (error) { }
    }
  }

  async buscaTipoEmpleadoEmpresas() {
    this.catalogoTipoEmpleado = [];
    this.empresaTipoEmpleado = [];
    const encabezadoTipoEmpleado = { '': 'ff_CMCTipoEmpleado' };
    this.catalogoTipoEmpleado.push(encabezadoTipoEmpleado);
    for (const empresa of this.empresas) {
      try {
        const response: any = await this._empleadoService.getVipAreas(empresa.IdEmpresa, 'EMTipoEmpleado');
        const response2: any[] = Object.values(response || {});
        const catalogoTipoEmpleadoEmp = [];
        for (const reg of response2) {
          if (reg.TEDescripcion != null && reg.TEDescripcion.trim() !== '') {
            const tipo = { 'key': reg.TEDescripcion.trim(), 'value': reg.TEIdDetalle };
            const dup = this.catalogoTipoEmpleado.find(element => element.key === tipo.key);
            if (!dup) {
              this.catalogoTipoEmpleado.push(tipo);
            }
            const dupEmpresa = catalogoTipoEmpleadoEmp.find(element => element.key === tipo.key);
            if (!dupEmpresa) {
              catalogoTipoEmpleadoEmp.push(tipo);
            }
          }
        }
        const encRE = { 'Empresa': empresa.IdEmpresa, 'TipoEmpleado': catalogoTipoEmpleadoEmp };
        this.empresaTipoEmpleado.push(encRE);
      } catch (error) { }
    }
  }

  async buscaCatalogoCompensaciones() {
    this.catalogoCompensacion = [];
    this.empresaCompensacion = [];
    const encabezadoCompensacion = { '': 'ff_Compensacion' };
    this.catalogoCompensacion.push(encabezadoCompensacion);
    for (const empresa of this.empresas) {
      try {
        let parametro = {
          'IdEmpresa': empresa.IdEmpresa
        }
        const response: any = await this._empleadoService.obtenerCatalogoCompensacionEmpresa(parametro, this.token);
        const response2: any[] = Object.values(response || {});
        const catalogoCompensacionEmp = [];
        for (const reg of response2) {
          if (reg.CONombre != null && reg.CONombre.trim() !== '') {
            const compensacionVal = { 'key': reg.CONombre.trim(), 'value': reg.COidCompensacion };
            const dup = this.catalogoCompensacion.find(element => element.key === compensacionVal.key);
            if (!dup) {
              this.catalogoCompensacion.push(compensacionVal);
            }
            const dupEmpresa = catalogoCompensacionEmp.find(element => element.key === compensacionVal.key);
            if (!dupEmpresa) {
              catalogoCompensacionEmp.push(compensacionVal);
            }
          }
        }
        const encRE = { 'Empresa': empresa.IdEmpresa, 'Compensacion': catalogoCompensacionEmp };
        this.empresaCompensacion.push(encRE);
      } catch (error) { }
    }
  }

  // metodo para dividir cada seccion del catalogo como parametro (llave/valor)
  private agregarCatalogoPartido(catalogoOrigen: any[]) {
    if (!catalogoOrigen || catalogoOrigen.length === 0) {
      return;
    }
    let co = 0;
    const primeraParte = [];
    const segundaParte = [];
    for (const item of catalogoOrigen) {
      co === 0 ? primeraParte.push(item) : segundaParte.push(item);
      co++;
    }
    this.catalogos.push(primeraParte);
    this.catalogos.push(segundaParte);
  }

  private obtenerEtiquetaEmpresaExcel(idEmpresa: any) {
    if (!this.empresas || this.empresas.length === 0) {
      return '';
    }
    const empresa = this.empresas.find(item => parseInt(item.IdEmpresa, 10) === parseInt(idEmpresa, 10));
    if (!empresa) {
      return '';
    }
    return this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)
      ? `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`
      : empresa.NomEmpresa;
  }

  // Perfiles empleados
  private construirValidacionesDependientesExcel() { 
    const validaciones = [];
    if (this.empresaPerfiles && this.empresaPerfiles.length > 0) {
      for (const empresaPerfil of this.empresaPerfiles) {
        const etiquetaEmpresa = this.obtenerEtiquetaEmpresaExcel(empresaPerfil.Empresa);
        const opciones = empresaPerfil.Perfiles.map(perfil => perfil.key);
        if (etiquetaEmpresa !== '' && opciones.length > 0) {
          validaciones.push({
            parentHeader: 'EMIDEMPRESA',
            targetHeader: 'EMIDPERFIL',
            parentValue: etiquetaEmpresa,
            options: opciones
          });
        }
      }
    }
    // Regimen empleados
    if (this.empresaRegimenes && this.empresaRegimenes.length > 0) {
      for (const empresaRegimen of this.empresaRegimenes) {
        const etiquetaEmpresa = this.obtenerEtiquetaEmpresaExcel(empresaRegimen.Empresa);
        const opciones = empresaRegimen.Regimenes.map(regimen => regimen.key);
        if (etiquetaEmpresa !== '' && opciones.length > 0) {
          validaciones.push({
            parentHeader: 'EMIDEMPRESA',
            targetHeader: 'EMREGIMEN',
            parentValue: etiquetaEmpresa,
            options: opciones
          });
        }
      }
    }
    // Oficina
    if (this.empresaOficina && this.empresaOficina.length > 0) {
      for (const empresaOficina of this.empresaOficina) {
        const etiquetaEmpresa = this.obtenerEtiquetaEmpresaExcel(empresaOficina.Empresa);
        const opciones = empresaOficina.Oficina.map(oficina => oficina.key);
        if (etiquetaEmpresa !== '' && opciones.length > 0) {
          validaciones.push({
            parentHeader: 'EMIDEMPRESA',
            targetHeader: 'EMOFICINA',
            parentValue: etiquetaEmpresa,
            options: opciones
          });
        }
      }
    }
    // Area
    if (this.empresaArea && this.empresaArea.length > 0) {
      for (const empresaArea of this.empresaArea) {
        const etiquetaEmpresa = this.obtenerEtiquetaEmpresaExcel(empresaArea.Empresa);
        const opciones = empresaArea.Area.map(area => area.key);
        if (etiquetaEmpresa !== '' && opciones.length > 0) {
          validaciones.push({
            parentHeader: 'EMIDEMPRESA',
            targetHeader: 'EMAREA',
            parentValue: etiquetaEmpresa,
            options: opciones
          });
        }
      }
    }
    // Empleado VIP
    if (this.empresaVIP && this.empresaVIP.length > 0) {
      for (const empresaVIP of this.empresaVIP) {
        const etiquetaEmpresa = this.obtenerEtiquetaEmpresaExcel(empresaVIP.Empresa);
        const opciones = empresaVIP.VIP.map(vip => vip.key);
        if (etiquetaEmpresa !== '' && opciones.length > 0) {
          validaciones.push({
            parentHeader: 'EMIDEMPRESA',
            targetHeader: 'EMVIP',
            parentValue: etiquetaEmpresa,
            options: opciones
          });
        }
      }
    }
    // Centro Costos
    if (this.empresaCentroCostos && this.empresaCentroCostos.length > 0) {
      for (const empresaCentroCostos of this.empresaCentroCostos) {
        const etiquetaEmpresa = this.obtenerEtiquetaEmpresaExcel(empresaCentroCostos.Empresa);
        const opciones = empresaCentroCostos.CentroCostos.map(cc => cc.key);
        if (etiquetaEmpresa !== '' && opciones.length > 0) {
          validaciones.push({
            parentHeader: 'EMIDEMPRESA',
            targetHeader: 'EMIDCENTROCOSTOS',
            parentValue: etiquetaEmpresa,
            options: opciones
          });
        }
      }
    }
    // Regimen empleados
    if (this.empresaTipoEmpleado && this.empresaTipoEmpleado.length > 0) {
      for (const empresaTipoEmpleado of this.empresaTipoEmpleado) {
        const etiquetaEmpresa = this.obtenerEtiquetaEmpresaExcel(empresaTipoEmpleado.Empresa);
        const opciones = empresaTipoEmpleado.TipoEmpleado.map(tipo => tipo.key);
        if (etiquetaEmpresa !== '' && opciones.length > 0) {
          validaciones.push({
            parentHeader: 'EMIDEMPRESA',
            targetHeader: 'EMTIPOEMPLEADO',
            parentValue: etiquetaEmpresa,
            options: opciones
          });
        }
      }
    }

    // Compensacion empleados
    if (this.empresaCompensacion && this.empresaCompensacion.length > 0) {
      for (const empresaCompensacion of this.empresaCompensacion) {
        const etiquetaEmpresa = this.obtenerEtiquetaEmpresaExcel(empresaCompensacion.Empresa);
        const opciones = empresaCompensacion.Compensacion.map(comp => comp.key);
        if (etiquetaEmpresa !== '' && opciones.length > 0) {
          validaciones.push({
            parentHeader: 'EMIDEMPRESA',
            targetHeader: 'CSIDCOMPENSACION',
            parentValue: etiquetaEmpresa,
            options: opciones
          });
        }
      }
    }
    
    return validaciones;
  }

  async buscaPlanesCorporativo() {
    try {
      this.catalogoPlanes = [];
      const encabezadoPlan = { '': 'ff_CMCPlan' };
      this.catalogoPlanes.push(encabezadoPlan);
      const response = await this._dependienteService.getPlanesCor(this.token, this.identity.idCorporativo);
      const response2: any[] = Object.values(response);
      for (const per of response2) {
        const plan = { 'key': per.PLNombre, 'value': per.PLIdPlan };
        this.catalogoPlanes.push(plan);
      }
    } catch (error) { }
  }

  async getCatalogoPersonalizado(indice: any, idPlantilla: any) {
    const nombre = this.atributosCrear2[indice].caNombreCampo.trim();
    let nombre2 = nombre.replace('EMId', '');
    nombre2 = nombre2.replace('EM', '');
    const emp1 = [{ '': 'ff_CMC' + nombre2 }];
    const emp2 = [];

    for (let i = 0; i < this.empresas.length; i++) {
      try {
        const response: any = await this._empleadoService.getVipAreas(this.empresas[i].IdEmpresa, nombre);
        for (const encabezado of response) {
          const emp3 = { 'key': encabezado.TEDescripcion, 'value': encabezado.TEIdDetalle };
          const dup = emp2.find(element => element.key === encabezado.TEDescripcion);
          if (!dup) {
            emp2.push(emp3);
          }
        }
        const j = i + 1;
        if (j >= this.empresas.length) {
          if (emp2.length > 0) {
            this.catalogos.push(emp1);
            this.catalogos.push(emp2);
            this.catalogosPersonalizados.push(nombre);
          }
          indice++;
          if (indice < this.atributosCrear2.length) {
            this.getCatalogoPersonalizado(indice, idPlantilla);
          } else {
            this.imprimirConCatalogo(idPlantilla);
          }
        }
      } catch (error) {
        const j = i + 1;
        if (j >= this.empresas.length) {
          if (emp2.length > 0) {
            this.catalogos.push(emp1);
            this.catalogos.push(emp2);
            this.catalogosPersonalizados.push(nombre);
          }
          indice++;
          if (indice < this.atributosCrear2.length) {
            this.getCatalogoPersonalizado(indice, idPlantilla);
          } else {
            this.imprimirConCatalogo(idPlantilla);
          }
        }
      }
    }

  }

  // generar catalogos personalizados para la validacion y carga de datos
  getCatalogoPersonalizado2(indice: any, idPlantilla: any) {
    const nombre = this.atributosCrear2[indice].caNombreCampo.trim();
    let nombre2 = '';
    if (nombre.indexOf('EMId') >= 0) {
      nombre2 = nombre.replace('EMId', '');
    } else {
      nombre2 = nombre.replace('EM', '');
    }

    const emp1 = [{ '': 'ff_CMC' + nombre2 }];
    const emp2 = [];

    this.llamadasCatPer(emp1, emp2, 0, indice, idPlantilla, nombre);
  }

  async llamadasCatPer(emp1: any, emp2: any, posEmp: any, indice: any, idPlantilla: any, nombre: any) {
    if (posEmp < this.empresas.length) {
      try {
        const response: any = await this._empleadoService.getVipAreas(this.empresas[posEmp].IdEmpresa, nombre);
        for (const encabezado of response) {
          const emp3 = { 'key': encabezado.TEDescripcion, 'value': encabezado.TEIdDetalle };
          emp2.push(emp3);
        }
        posEmp++;
        this.llamadasCatPer(emp1, emp2, posEmp, indice, idPlantilla, nombre);
      } catch (error) {
        posEmp++;
        this.llamadasCatPer(emp1, emp2, posEmp, indice, idPlantilla, nombre);
      }
    } else {
      if (emp2.length > 0) {
        this.catalogos.push(emp1);
        this.catalogos.push(emp2);
        this.catalogosPersonalizados.push(nombre);
      }
      indice++;
      if (indice < this.atributosCrear2.length) {
        this.getCatalogoPersonalizado2(indice, idPlantilla);
      } else {
        swal({
          title: '',
          html: '<small style="color: grey; text-align: justify;">¡Catálogos cargados!</small>',
          type: 'success',
          confirmButtonText: 'Aceptar',
          timer: 3000,
        });
        this.plantillaActual = idPlantilla;
        this.iniciarOperacionesF1();
      }
    }
  }

  validarInput(parametro: string) {
    if (parametro.length > 0) {
      this.errorEntrada = false;
    } else {
      this.errorEntrada = false;
    }
  }

  async buscaAyuda() {
    try {
      const pagina: any = await this._menus.getAyudaMenu('557');
      const response = await this._menus.getAyudaEmpresaPagina(this.identity.idEmpresa, pagina.paNombreArchivo);
      this.iconoAyuda = 1;
      const textoayuda = response;
      this.textAyuda = textoayuda[0].paTextoAyuda;
    } catch (error) {
      this.iconoAyuda = 0;
    }
  }

  async getEstados() {
    try {
      this.catalogoEstados = [];
      const encabezadoEstado = { '': 'ff_CMCEstadoFiscal' };
      this.catalogoEstados.push(encabezadoEstado);
      const response = await this._empleadoService.getEstadosFiscal();
      this.estadosFiscales = response;
      this.ordenarEstados(this.estadosFiscales);
      let ini = 0;
      for (const per of this.estadosFiscales) {
        if (ini >= 1) {
          const estado = { 'key': per.esDescripcion, 'value': per.esIdEstado };
          this.catalogoEstados.push(estado);
        }
        ini++;
      }
    } catch (error) { }
  }

  ordenarEstados(obj) {
    obj.sort((a, b) => {
      return a.esDescripcion.localeCompare(b.esDescripcion);
    });
  }

  // envio grupo de correos
  async proc_LeeParametro() {
    try {
      this.boolEnvia = false;
      let salida = '';
      const response = await this._empleadoService.getParametro(this._empleadoService.getIdentity().idEmpresa, '113');
      salida = response['paValor'];
      const ArrayPlatilla = salida.split(',');
      for (const item in ArrayPlatilla) {
        if (parseInt(item, 10) === 8) {
          this.boolEnvia = true;
        }
      }
    } catch (error) {
      this.boolEnvia = false;
    }
  }

  async getGrupo() {
    try {
      this.destinatarios[0] = '';
      this.destinatarios[1] = '';
      this.destinatarios[2] = '';
      const response = await this._cifrasControlService.getGrupoCorreos(8, this.identity.idEmpresa, this.token);
      const response2 = [];
      response2.push(response);
      for (const row of response2[0]) {
        if (row !== null && row !== undefined) {
          if (row.gcCorreoCopia) {
            this.destinatarios[0] = row.adCorreoElectronico.trim().replace(':', '') + ',' + this.destinatarios[0];
          }
          if (row.gcCorreoCopiaOculta) {
            this.destinatarios[1] = row.adCorreoElectronico.trim() + ',' + this.destinatarios[1];
          }
          if (row.gcCorreoVisible) {
            this.destinatarios[2] = row.adCorreoElectronico.trim() + ',' + this.destinatarios[2];
          }
        }
      }
    } catch (error) { }
  }

  private iniciarTrazaCarga() {
    const empresa = this.identity && this.identity.idEmpresa ? Number(this.identity.idEmpresa) : 0;
    const aleatorio = Math.random().toString(36).substring(2, 8).toUpperCase();
    this.idTrazaCarga = `CM-${empresa}-${Date.now()}-${aleatorio}`;
    this.estadoTrazaCarga = 'EN PROCESO';
    this.fechaInicioReporte = this.formatFecha('');
    this.nombreReporteTxt = this.nombreArchivoSeguro(
      `ReporteCargaMasiva_${this.identity && this.identity.nomEmpresa ? this.identity.nomEmpresa : empresa}_${this.idTrazaCarga}`
    ) + '.txt';
    this.trazaPersistida = false;
    this.trazaRespaldando = false;
    sessionStorage.setItem('bf3CargaMasivaTraceId', this.idTrazaCarga);
  }

  private cerrarTrazaEnNavegador() {
    if (sessionStorage.getItem('bf3CargaMasivaTraceId') === this.idTrazaCarga) {
      sessionStorage.removeItem('bf3CargaMasivaTraceId');
    }
  }

  private async respaldarTrazaCarga(estado: string) {
    if (!this.idTrazaCarga || this.trazaPersistida || this.trazaRespaldando) return;
    this.trazaRespaldando = true;
    this.estadoTrazaCarga = estado;
    this.rerporteCargaMasiva.push(this.generaLog(`[${estado}] Fin de la traza de carga masiva.`));
    const blobFile = this.crearReporteTxt(this.rerporteCargaMasiva);
    this.nombreReporteTxt = this.nombreArchivoSeguro(
      `ReporteCargaMasiva_${this.identity.nomEmpresa}_${this.idTrazaCarga}`) + '.txt';
    try {
      const respaldado = await this.subirReporteFile(blobFile, this.nombreReporteTxt);
      this.trazaPersistida = respaldado;
    } finally {
      this.trazaRespaldando = false;
      this.cerrarTrazaEnNavegador();
    }
  }

  generaLog(message: string) {
    const now = new Date();

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');

    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    let timeStampString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    const traceId = this.idTrazaCarga || 'SIN-TRAZA';
    const flujo = this.flujoPantallaActual;
    const empresa = this.identity && this.identity.idEmpresa ? this.identity.idEmpresa : 0;
    let logMessage = `[${timeStampString}] [TRAZA:${traceId}] [FLUJO:${flujo}] [EMPRESA:${empresa}]: ${message}`;

    //console.log(logMessage);
    return logMessage;
  }

  // Agrega un espacio cada que encuentra la secuencia de caracteres MayusculaMinuscula
  formatAtributoNombre(nombreAtributo: string){
    nombreAtributo = nombreAtributo != null ? nombreAtributo : '[celda vacía]';
    return nombreAtributo.replace(/([A-Z])(?=[a-z])/g, ' $1').trim().replace(/\s+/g, ' ');
  }
  descargarReporteTxt(blobFile){
    if(blobFile && (this.listaResultados.length > 0 || this.rerporteCargaMasiva.length > 0)){
      const enlace = document.createElement('a');
      const url = URL.createObjectURL(blobFile);
      enlace.href = url;
      enlace.download = this.nombreReporteTxt;
      document.body.appendChild(enlace);
      enlace.click();
      document.body.removeChild(enlace);
      URL.revokeObjectURL(url);
    }else{
      swal({
        title: 'Sin datos',
        html: `<small style="color: grey;">No se encontraron datos para generar el reporte, realiza una carga para generar resultados.</small>`,
        type: 'error',
        showConfirmButton: true
      });
    }
  }

  crearReporteTxt(contenido) {
    // Generar plana de logs
    if(contenido.length > 0){
      let textoPlano = "### REGISTRO DE OPERACIÓN DE CARGA MASIVA ###\n";
      textoPlano += `Traza: ${this.idTrazaCarga || 'SIN-TRAZA'}\n`;
      textoPlano += `Flujo: ${this.flujoPantallaActual}\n`;
      textoPlano += `Empresa: ${this.identity && this.identity.idEmpresa ? this.identity.idEmpresa : 0}\n`;
      textoPlano += `Estado: ${this.estadoTrazaCarga}\n\n`;
      contenido.forEach(registroLog => {
        textoPlano = textoPlano + registroLog + "\n";
      });
      const blob = new Blob([textoPlano], { type: 'text/plain' });
      return blob;
    }
  }

  // Subir archivo
  async subirReporteFile(blobFile, nombrearchivo): Promise<boolean> {
    // Titulares/crearRegistroLog
    try {
      if (!blobFile) return false;
      const file = new File([blobFile], nombrearchivo, {type: blobFile.type})
      const rutaBase = `DocumentoEmpresa/${this.identity.idEmpresa}/CargaMasivaPoblacionesLog`;
      const nombreSinExt = file.name.replace(/\.[^/.]+$/, "");
      const ruta = `${rutaBase}/${file.name}`;
      const directorio = `directorio=${rutaBase}&nombre=${encodeURIComponent(nombreSinExt)}`;
  
      const operacion = $('#operacion').val();

      let bodyParams = {
        "idUsuario": this.identity.id,
        "idEmpresa": this.identity.idEmpresa,
        "tipoEjecucion": this.datosOpe && this.datosOpe.opcion
          ? this.datosOpe.opcion : this.flujoPantallaActual,
        "tipoCarga": operacion,
        "fechaInicio": this.fechaInicioReporte,
        "nombreArchivo": nombreSinExt,
        "rutaArchivo": ruta
      }
      
      let resp: any = await this._titularesService.addReporteLog(bodyParams);
      if (resp == 0) {
        console.log("No se pudo insertar el registro para el reporte de carga masiva: ", resp);
      }
  
      const formData = new FormData();
      formData.append('file', file);
      
      // console.log("Cargando documento por formData a: ", directorio);
      await $.ajax({
        url: `${GLOBAL.url2}file/upload2?${directorio}`,
        method: "POST",
        processData: false,
        contentType: false,
        data:formData
      });
      return resp != 0;
    } catch (error) {
      console.error("Error al subir reporte log:", error);
      return false;
    }
  }

  /*consulta de archivos de reportes para carga masiva */
  /*consulta de documentos */
  async consultaLog(){
    this.mostrarDatosTabla = true;
    this.pageE = 1;
    this.pageD = 1;
    this.pageSizeE = 5;
    this.pageSizeD = 5;
    this.busqueda.buscar = 'busqueda';
    // Datos prueba
    if (this.validarConsulta()) {
      this.generoConsulta = true;
      this.tablaArchivos = [];
      this.busqueda.fechaInicio = this.formatFecha(this.busqueda.fechaInicio);
      this.busqueda.fechaFin = this.formatFecha(this.busqueda.fechaFin);
      await this._titularesService.getReportesCargaMasiva(this.busqueda).then(response => {
        // this.tablaArchivos = [];
        if (response) {
          this.tablaArchivos = response;
          this.datosE = this.tablaArchivos;
          this.collectionSizeE = this.datosE.length;
          this.consultaSinDatos = this.collectionSizeE == 0 ? true : false;
        } else {
          this.datosE = this.tablaArchivos;
          this.consultaSinDatos = true;
          this.pageE = 1;
          this.pageSizeE = 5;
          this.collectionSizeE = 0;
        }
      }).catch( err => console.log(err));   // Obtener documentos por empleados
    } else {
      this.mostrarDatosTabla = false;
      this.consultaSinDatos = false;
    }

  }

  validarConsulta() {
    const regexpNumber = new RegExp('^[\u00F1\u00D1 A-ZÁ-Üa-zá-ü .]+$');
    const regexpNumber2 = new RegExp('^[a-zA-Z0-9]+$');
    let buscar = this.busqueda.buscar;
    if (buscar == "" || buscar == " ") {
      this.errorBus.buscar = true;
      this.leyenda = "Introduce tu búsqueda";
      return false;
    }
    if (this.busqueda.tipoOperacion != '1' && this.busqueda.tipoOperacion != '0' && buscar.length > 0) {
      if (regexpNumber.test(buscar)) {
        this.errorBus.buscar = false;
        this.leyenda = "";
        return true;
      } else {
        this.errorBus.buscar = false;
        this.leyenda = 'Ingresa sólo letras';
        return false;
      }
    } else {
      if ((this.busqueda.tipoOperacion == '1' || this.busqueda.tipoOperacion == '0') && buscar.length > 0) {
        if (regexpNumber2.test(buscar)) {
          if (regexpNumber2.test(buscar)) {
            this.errorBus.buscar = false;
            this.leyenda = "";
            return true;
          } else {
            this.errorBus.buscar = false;
            this.leyenda = 'Ingresa sólo letras y/o números';
            return false;
          }
        }
      }
    }
  }

  async getCatTextoLog(idPlantilla) {
    this.catalogoTextoLog = [];
    try {
      const response = await this._titularesService.getReporteTextoLog(idPlantilla);
      this.catalogoTextoLog = response;
    } catch (error) {
      console.log(error);
    }
  }
  replaceTextoLog(nombreAtributo){
    const econtrado = this.catalogoTextoLog.find(cat => cat.CMMNombreCampo === nombreAtributo.trim());
    if(econtrado){
      return econtrado.CMMTexto.trim();
    }else{
      return nombreAtributo.trim();
    }
  }

  formatFecha(fechaData: string) {
    let now: Date;
    if(fechaData === ''){
      now = new Date();
    }else{
      now = new Date(fechaData);
    }

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');

    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    let timeStampString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    //console.log(logMessage);
    return timeStampString;
  }

  sanitize(url:string){
    return this.sanitizer.bypassSecurityTrustUrl(url);
  }

  descargarReporteTxtUrl(dato){
    // sanitize(url+dato.rutaArchivo)
      this._HttpClient.get(this.url + dato.rutaArchivo, {responseType: 'blob'}).subscribe(
        (data: any) => {
          const blobFile = new Blob([data], {type: 'text/plain'});
          saveAs(blobFile, dato.nombreArchivo + '.txt')
        },
        (error:any) => {
          swal({
            title: 'Atención',
            html: `<small style="color: grey;">No se encontraron datos para descargar el reporte. <br>Intente de nuevo más tarde.</small>`,
            type: 'warning',
            showConfirmButton: true
          });
        }
      );
  }
  // Inicializar formulario de modal
  inicializarFormulario(){
    let idEmpresaDefault = 0;
    if(this.empresas.length > 0){
      // Buscar empresa del usuario
      let selectEmpresa = this.identity.idEmpresa;
      let empresaEncontrada = this.empresas.find(valEmpresa => valEmpresa.IdEmpresa === selectEmpresa);
      if(empresaEncontrada){
        idEmpresaDefault = selectEmpresa;
      }else{
        idEmpresaDefault = this.empresas[0].IdEmpresa;
      }
    }
    this.busqueda.idEmpresa = idEmpresaDefault.toString();
    // Asignar fecha inicio y fin por default 
    let actualFecha = new Date();
    let fechaFindDef = actualFecha.setDate(actualFecha.getDate() + 1);
    let fechaInicioDef = actualFecha.setDate(actualFecha.getDate() - 2);
    this.busqueda.fechaInicio = this.generarFechaTexto(new Date(fechaInicioDef));
    this.busqueda.fechaFin = this.generarFechaTexto(new Date(fechaFindDef));

    this.fechaInicioMax =this.generarFechaTexto(new Date(fechaFindDef));
    this.fechaFinMin =this.generarFechaTexto(new Date(fechaInicioDef));
    this.busqueda.tipoOperacion = "3";
    this.generoConsulta = false;
  }
  generarFechaTexto(fecha: Date){
    const year = fecha.getFullYear();
    const month = String(fecha.getMonth() + 1).padStart(2, '0');
    const day = String(fecha.getDate()).padStart(2, '0');

    const hours = String(fecha.getHours()).padStart(2, '0');
    const minutes = String(fecha.getMinutes()).padStart(2, '0');
    const seconds = String(fecha.getSeconds()).padStart(2, '0');
    let timeStampString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    return timeStampString;
  }
  actualizarLitmitesFecha(){
    this.fechaFinMin = this.formatFecha(this.busqueda.fechaInicio);
    this.fechaInicioMax = this.formatFecha(this.busqueda.fechaFin);
  }

  obtenerTipoCarga(idCarga){
    let carga = this.comboOperaciones.find(opera => opera.opcion ===idCarga);
    if(carga){
      return carga.nombre;
    }else{return  idCarga}
  }

  mostrarModalLogs(){
    this.inicializarFormulario();
    $('#modal-consultar-logs').modal('show');
  }
  
  validaDuplicidadEmpresa(nombreEmpresa, idEmpresa){
    let empresaObj = null;
    empresaObj = this.empresas.find(empresa => empresa.NomEmpresa === nombreEmpresa && empresa.IdEmpresa != idEmpresa);
    return empresaObj ? true : false;
  }

  async generaComboEmpresa(){
    this.comboEmpresaModal = [];
    if(this.empresas && this.empresas.length > 0){
      for (const empresa of this.empresas) {
        let empresaUnica = {}
        if(this.validaDuplicidadEmpresa(empresa.NomEmpresa, empresa.IdEmpresa)){
          empresaUnica = { 'NomEmpresa': `${empresa.IdEmpresa} - ${empresa.NomEmpresa}`, 'IdEmpresa': empresa.IdEmpresa };
        }else{
          empresaUnica = { 'NomEmpresa': empresa.NomEmpresa, 'IdEmpresa': empresa.IdEmpresa };
        }
        this.comboEmpresaModal.push(empresaUnica);
      }
    }
  }

  async ejecutarSeleccionUsuario(IdEmpleado,EMNumeroEmpleado,EMIdEmpresa,idSolicitud,EMSeleccionUsuario){
    if(EMSeleccionUsuario === 4 && idSolicitud != 0){
      this.imprimirSolicitudes(idSolicitud);
    }
    if(EMSeleccionUsuario === 1 && idSolicitud != 0){
      await this.defaultearEmpleadosSeleccionadosModal(IdEmpleado, EMNumeroEmpleado, EMIdEmpresa);
    }
  }

  public async imprimirSolicitudes(idSolicitud) {
      let RegSolicitudes = {idSolicitudes: [idSolicitud]};
      await this._cifrasControlService.AdminRegeneracionQueueInsert(false, RegSolicitudes,this.identity.id, this.token);
  }

  // Genearar defaulteo
  async defaultearEmpleadosSeleccionadosModal(idNumeroEmpleado, numeroEmpleado, idEmpresa){

    let idEmpleado = [idNumeroEmpleado];
    let numEmpleado = [numeroEmpleado];
    let empresas = [idEmpresa];

    let defaulteo = 'def3';
    await this._titularesService.obtenerVigenciaActual(idEmpresa).then(
      async response => {
        if(response){
          let idVigenciaVigente = response[0].idVigencia;
          await this._HttpClient.post(`${GLOBAL.url}titulares/defaultearMasivo`,
          {
              "idEmpleado":idEmpleado,
              "numEmpleado":numEmpleado,
              "idEmpresa": empresas,
              "idVigencia":0,
              "idVigenciaAnterior":0,
              "tipoDefaulteo":defaulteo,
              "tmpplanesseleccionados":'{"costo": null,"idempleado": -1,"nuevo": null,"tcidtarifacosto": -1}',
              "tmpplanesseleccionadosold":'{"costoOld": null,"idempleadoOld": -1,"nuevoOld": null,"tcidtarifacostoOld": -1}',
              "idAdmin":this.identity.id,
              "idVigenciaVigente": idVigenciaVigente
          }
          ).subscribe(response => {
              console.log("RESPUESTA DEFAULTEO MASIVO", response);
          }, error => {}) 
        }
      }
    )

    
  }

}
