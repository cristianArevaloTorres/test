export interface CargaMasivaTxtDocumento {
  campos: string[];
  camposComunes: { [nombre: string]: string };
  registros: Array<Array<string | null>>;
}

/**
 * Parser del contrato historico de Carga Masiva B2.
 *
 * Formato:
 *   @commonFields:
 *   Campo=Valor
 *
 *   @fieldNames:Campo1,Campo2
 *   @data:
 *   Valor1|Valor2
 *
 * El parser no ejecuta SQL ni interpreta valores; es una validacion inmediata
 * en navegador. El WS vuelve a leerlo y aplica la plantilla y los SP de B2.
 */
export class CargaMasivaTxtParser {
  public static readonly MAX_REGISTROS = 3000;

  static parse(contenido: string): CargaMasivaTxtDocumento {
    if (contenido === null || contenido === undefined) {
      throw new Error('El archivo TXT no contiene informacion.');
    }

    const limpio = String(contenido).replace(/^\uFEFF/, '').replace(/\u0000/g, '');
    const lineas = limpio.split(/\r\n|\n|\r/);
    const campoComun = this.buscarSeccion(lineas, 'commonFields', false);
    const nombres = this.buscarSeccion(lineas, 'fieldNames', true);
    const datos = this.buscarSeccion(lineas, 'data', true);

    if (datos.indice <= nombres.indice) {
      throw new Error('La seccion @data debe aparecer despues de @fieldNames.');
    }

    const campos = nombres.valor.split(',').map(campo => campo.trim());
    if (campos.length === 0 || campos.some(campo => !campo)) {
      throw new Error('La seccion @fieldNames contiene nombres vacios.');
    }

    const camposNormalizados: { [nombre: string]: boolean } = {};
    campos.forEach(campo => {
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(campo)) {
        throw new Error(`El nombre de campo ${campo} no es valido.`);
      }
      const llave = campo.toUpperCase();
      if (camposNormalizados[llave]) {
        throw new Error(`El campo ${campo} esta repetido en @fieldNames.`);
      }
      camposNormalizados[llave] = true;
    });

    const camposComunes: { [nombre: string]: string } = {};
    const comunesNormalizados: { [nombre: string]: boolean } = {};
    if (campoComun) {
      for (let i = campoComun.indice + 1; i < lineas.length; i++) {
        const linea = lineas[i].trim();
        if (!linea) break;
        if (linea.startsWith('@')) break;
        if (linea.startsWith('#')) continue;

        const separador = linea.indexOf('=');
        if (separador <= 0) {
          throw new Error(`Campo comun invalido en la linea ${i + 1}. Use Nombre=Valor.`);
        }
        const nombre = linea.substring(0, separador).trim();
        const valor = linea.substring(separador + 1).trim();
        if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(nombre)) {
          throw new Error(`El nombre de campo comun ${nombre} no es valido.`);
        }
        const llave = nombre.toUpperCase();
        if (comunesNormalizados[llave] || camposNormalizados[llave]) {
          throw new Error(`El campo ${nombre} esta repetido entre las secciones del TXT.`);
        }
        comunesNormalizados[llave] = true;
        camposComunes[nombre] = valor;
      }
    }

    const registros: Array<Array<string | null>> = [];
    for (let i = datos.indice + 1; i < lineas.length; i++) {
      const linea = lineas[i];
      if (!linea.trim()) break;
      const valores = linea.split('|');
      if (valores.length !== campos.length) {
        throw new Error(
          `La linea ${i + 1} tiene ${valores.length} valores y se esperaban ${campos.length}.`
        );
      }
      registros.push(valores.map(valor => valor === '' ? null : valor));
      if (registros.length > this.MAX_REGISTROS) {
        throw new Error(`El TXT supera el limite de ${this.MAX_REGISTROS} registros por carga.`);
      }
    }

    if (registros.length === 0) {
      throw new Error('La seccion @data no contiene registros.');
    }

    return { campos, camposComunes, registros };
  }

  private static buscarSeccion(
    lineas: string[], nombre: string, obligatoria: boolean
  ): { indice: number; valor: string } | null {
    const patron = new RegExp(`^\\s*@${nombre}\\s*:\\s*(.*)$`, 'i');
    for (let i = 0; i < lineas.length; i++) {
      const encontrada = patron.exec(lineas[i]);
      if (encontrada) {
        const valor = (encontrada[1] || '').trim();
        if (nombre.toLowerCase() === 'fieldnames' && !valor) {
          throw new Error('La seccion @fieldNames no contiene campos.');
        }
        return { indice: i, valor };
      }
    }
    if (obligatoria) {
      throw new Error(`El archivo no contiene la seccion @${nombre}: requerida.`);
    }
    return null;
  }
}
