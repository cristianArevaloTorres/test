import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CanActivateViaAuthGuard } from '../services/auth.guard';
import { CanDesActivateGuard } from './cambiopassword/can-des-activate.guard';
import { BComponent } from './beflex/beflex.component';
import { AdmAccesosComponent } from './adm-accesos/adm-accesos.component';
import { AdmCalculadoraRetiroComponent } from './adm-calculadora-retiro/adm-calculadora-retiro.component';
import { AsignarSubirComponent } from './adm-documentos/asignar-subir/asignar-subir.component';
import { DocExistenteComponent } from './adm-documentos/asignar-subir/doc-existente/doc-existente.component';
import { DocPersonalizadosComponent } from './adm-documentos/doc-personalizados/doc-personalizados.component';
import { AdmEyretiroComponent } from './adm-eyretiro/adm-eyretiro.component';
import { AseguradosComponent } from './adm-reportes/asegurados/asegurados.component';
import { BitacoraNavegacionComponent } from './adm-reportes/bitacora-navegacion/bitacora-navegacion.component';
import { CifrasControlComponent } from './adm-reportes/cifras-control/cifras-control.component';
import { CobranzaComponent } from './adm-reportes/cobranza/cobranza.component';
import { KPIComponent } from './adm-reportes/kpi/kpi.component';
import { ReporteBeneficiariosComponent } from './adm-reportes/reporte-beneficiarios/reporte-beneficiarios.component';
import { ReporteDefaulteoComponent } from './adm-reportes/reporte-defaulteo/reporte-defaulteo.component';
import { ReporteDefaulteoCasosEspecialesComponent } from './adm-reportes/reporte-defaulteo/reporte-defaulteo-casos-especiales/reporte-defaulteo-casos-especiales.component';
import { ReporteDocPersonalizadosComponent } from './adm-reportes/reporte-doc-personalizados/reporte-doc-personalizados.component';
import { ReporteSolicitudesComponent } from './adm-reportes/reporte-solicitudes/reporte-solicitudes.component';
import { ReporteCostosComponent } from './adm-reportes/reportecostos/reportecostos.component';
import { ReporteCasaHabitacionComponent } from './adm-reportes/reporte-casa-habitacion/reporte-casa-habitacion.component';
import { SabanaBeneficiosComponent } from './adm-reportes/sabana-beneficios/sabana-beneficios.component';
import { AdmTicketsComponent } from './adm-tickets/adm-tickets.component';
import { AdmDependientesComponent } from './administracion/adm-dependientes/adm-dependientes.component';
import { AdminSolicitudesComponent } from './adminsolicitudes/adminsolicitudes.component';
import { BeflexComponent } from './beflex.component';
import { BeneficiariosComponent } from './beneficiarios/beneficiarios.component';
import { BeMobileComponent } from './bemobile/bemobile.component';
import { EnvioNotificacionesComponent } from './bemobile/envio-notificaciones/envio-notificaciones.component';
import { AdminNotificacionesComponent } from './bemobile/admin-notificaciones/admin-notificaciones.component';
import { PreguntasComponent } from './buzon/preguntas/preguntas.component';
import { RespuestasComponent } from './buzon/respuestas/respuestas.component';
import { CalculadoraComponent } from './calculadora/calculadora.component';
import { CambioEmpresaComponent } from './cambioempresa/cambioempresa.component';
import { CambiopasswordComponent } from './cambiopassword/cambiopassword.component';
import { CargamasivaadmComponent } from './cargamasivaadm/cargamasivaadm.component';
import { CasaComponent } from './casa/casa.component';
import { CompensacionComponent } from './compensacion/compensacion.component';
import { ConfEnvioComponent } from './conf-envio/conf-envio.component';
import { ConfSubgruposComponent } from './conf-subgrupos/conf-subgrupos.component';
import { ConfiguracionComponent } from './configuracion/configuracion.component';
import { ConsultabeneficiosempleadoComponent } from './consultabeneficiosempleado/consultabeneficiosempleado.component';
import { ConsultaindicadoressiniestroComponent } from './consultaindicadoressiniestro/consultaindicadoressiniestro.component';
import { ConsultasiniestrosdetalleComponent } from './consultasiniestrosdetalle/consultasiniestrosdetalle.component';
import { ConsultatitularesdependientesComponent } from './consultatitularesdependientes/consultatitularesdependientes.component';
import { ConsultatitularestotalstatementComponent } from './consultatitularestotalstatement/consultatitularestotalstatement.component';
import { CotizadorComponent } from './cotizador/cotizador.component';
import { DependientesComponent } from './dependientes/dependientes.component';
import { DocumentosComponent } from './documentos/documentos.component';
import { facturacionComponent } from './facturacion/facturacion.component';
import { GeneracionCambiosCalificadosComponent } from './generacion-cambios-calificados/generacion-cambios-calificados.component';
import { BeneficiosmasterComponent } from './master/beneficiosmaster/beneficiosmaster.component';
import { DependientesmasterComponent } from './master/dependientesmaster/dependientesmaster.component';
import { MisdatosfiscalesmasterComponent } from './master/misdatosfiscalesmaster/misdatosfiscalesmaster.component';
import { RegistroBeneficiariosMasterComponent } from './master/registro-beneficiarios-master/registro-beneficiarios-master.component';
import { BajatitularesComponent } from './master/titularesmasteradm/bajatitulares/bajatitulares.component';
import { ModificaciontitularesComponent } from './master/titularesmasteradm/modificaciontitulares/modificaciontitulares.component';
import { TitularesmasteradmComponent } from './master/titularesmasteradm/titularesmasteradm.component';
import { MembresiasComponent } from './membresias/membresias.component';
import { MembresiasdosComponent } from './membresias/membresiasdos/membresiasdos.component';
import { MisdatosfiscalesComponent } from './misdatosfiscales/misdatosfiscales.component';
import { MisdocumentosComponent } from './misdocumentos/misdocumentos.component';
import { MisolicitudesdebeneficiosComponent } from './misolicitudesdebeneficios/misolicitudesdebeneficios.component';
import { SolicitudComponent } from './misolicitudesdebeneficios/solicitud/solicitud.component';
import { NoticiasComponent } from './noticias/noticias.component';
import { PerfilComponent } from './perfil/perfil.component';
import { PreViewBeMobileComponent } from './preview-bemobile/preview-bemobile.component';
import { PreviewCompensacionesComponent } from './preview-compensaciones/preview-compensaciones.component';
import { RegeneracionSolicitudComponent } from './regeneracionsolicitud/regeneracionsolicitud.component';
import { RegistrodebeneficiariosComponent } from './registrodebeneficiarios/registrodebeneficiarios.component';
import { SamiComponent } from './sami/sami.component';
import { SolicitudcambiocalificadoComponent } from './solicitudcambiocalificado/solicitudcambiocalificado.component';
import { SubMenuComponent } from './submenu/submenu.component';
import { TestingComponent } from './testing/testing.component';
import { MonitorComponent } from './tickets/monitor/monitor.component';
import { TicketsComponent } from './tickets/ticket.component';
import { VideosComponent } from './videos/videos.component';
import { DireccionamientoComponent } from '../home/direccionamiento/direccionamiento.component';
import { RedirectLizzyComponent } from '../home/redirect-lizzy/redirect-lizzy.component';
import { LogoutComponent } from '../logout/logout.component';
import { VerificacionComponent } from '../verificacion/verificacion.component';
import { HomeComponent } from '../home/home.component';
import { EnvioLocktonOne } from './adm-EnvioLocktonOne/adm-EnvioLocktonOne.component';
import { RegistroMascotasComponent } from './registro-mascotas/registro-mascotas.component';
import { ReporteAccesosBemobileComponent } from './adm-reportes/reporte-accesos-bemobile/reporte-accesos-bemobile.component';
import { ReporteBitacoraNotificacionesComponent } from './adm-reportes/reporte-bitacora-notificaciones/reporte-bitacora-notificaciones.component';
import { CambiosCalificadosComponent } from './adm-reportes/cambios-calificados/pages/cambios-calificados/cambios-calificados.component';
import { AsignacionPlanesComponent } from './adm-reportes/reporte-asignacion-planes/asignacion-planes.component';
import { ReporteContabilidadComponent } from './adm-reportes/reporte-contabilidad/reporte-contabilidad.component';
import { ReporteSaldosComponent } from './adm-reportes/reporte-saldos/reporte-saldos.component';
import { ReporteFacturasComponent } from './adm-reportes/reporte-facturas/reporte-facturas.component';
import { RegSolicitudesComponent } from './reg-solicitudes/reg-solicitudes.component'
import { AdmBonoAutoComponent } from './adm-bono-auto/adm-bono-auto.component';
import { DatosBancariosComponent } from './datosbancarios/datosbancarios.component';
import { ReporteDetalladoCobroComponent } from './reportedetalladocobro/reportedetalladocobro.component';

import { AdministracionTitularesComponent } from './adm-red-medica/adm-titulares.component';
import { ReportesRedMedicaComponent } from './adm-reportes/redMedica-reportes/redMedica.component';
import {CargaMasivaComponent} from './adm-red-medica/red-medica-cargaMasiva/adm-cargaMasiva.component'


import { AdmLocktonHubComponent } from './adm-lockton-hub/adm-lockton-hub.component';
import { AdmLinkPagoPTDCComponent } from './adm-link-pago-ptdc/adm-link-pago-ptdc.component';
import { ReporteCrearComponent } from './adm-reportes/reporte-crear/reporte-crear.component';
import { ReporteReconfigurarComponent } from './adm-reportes/reporte-reconfigurar/reporte-reconfigurar.component';
import { ReporteConfiguracionComponent } from './adm-reportes/reporte-configuracion/reporte-configuracion.component';
import { ReporteSeguimientoComponent } from './adm-reportes/reporte-seguimiento/reporte-seguimiento.component';
import { ReporteConfigurarExportacionComponent } from './adm-reportes/reporte-configurar-exportacion/reporte-configurar-exportacion.component';
import { BorradoPoblacionComponent } from './borrado-poblacion/borrado-poblacion.component';
import { ValidacionesPostEnrollmentComponent } from './adm-reportes/validaciones-post-enrollment/validaciones-post-enrollment.component';
import { ReporteEstadisticoComponent } from './adm-reportes/reporte-estadistico/reporte-estadistico.component';
import { ReseteoCuentaEmpleadoComponent } from './reseteo-usuario/reseteo-cuenta-empleado/reseteo-cuenta-empleado.component'
import { CompensacionEmpleadoComponent } from './adm-reportes/compensacion-empleado/compensacion-empleado.component';
import { MarketplaceComponent } from './beflex/marketplace/marketplace.component';

const routes: Routes = [
  {
    path: '',
    data: { breadcrumb: 'Home' },
    component: BComponent,
    canActivate: [CanActivateViaAuthGuard],
    children: [

      { path: 'logout', component: LogoutComponent },
      {
        path: 'home',
        component: HomeComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'home/direccionar/:idPage',
        data: { breadcrumb: 'Home' },
        component: DireccionamientoComponent,
        canActivate: [CanActivateViaAuthGuard],
      },


      {
        path: 'administracion',
        data: { breadcrumb: 'Administración' },
        canActivate: [CanActivateViaAuthGuard],
        children: [

          {
            path: '',
            component: SubMenuComponent,
            canActivate: [CanActivateViaAuthGuard],
          },

          {
            path: 'adm-link-pago',
            data: { breadcrumb: 'Administración Link de Pago' },
            component: AdmLinkPagoPTDCComponent,
            canActivate: [CanActivateViaAuthGuard]
          },

          {
            path: 'adm-lockton-hub',
            data: { breadcrumb: 'Administración Lockton Hub' },
            component: AdmLocktonHubComponent,
            canActivate: [CanActivateViaAuthGuard]
          },

          {
            path: 'adm-bono-auto',
            data: { breadcrumb: 'Administración bono auto' },
            component: AdmBonoAutoComponent,
            canActivate: [CanActivateViaAuthGuard]
          },
          {
            path: 'bemobile',
            data: { breadcrumb: 'beMobile' },
            component: BeMobileComponent,
            children: [
              {
                path: 'preview-bemobile',
                data: { breadcrumb: 'PreView BeMobile' },
                component: PreViewBeMobileComponent

              },
               {
                path: 'preview-compensaciones',
                data: { breadcrumb: 'PreView Compensaciones' },
                component: PreviewCompensacionesComponent
               
              },
              {
                path: 'envio',
                data: { breadcrumb: 'Envío de Notificaciones' },
                component: EnvioNotificacionesComponent
              },
              {
                path: 'administracion',
                data: { breadcrumb: 'Administración de Notificaciones' },
                component: AdminNotificacionesComponent
              },
            ],
          },

          {
            path: 'titulares',
            data: { breadcrumb: 'Administración de Titulares y Dependientes' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'alta',
                data: { breadcrumb: 'Alta de titulares' },
                component: TitularesmasteradmComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'baja',
                data: { breadcrumb: 'Baja de titulares' },
                component: BajatitularesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'modificacion',
                data: { breadcrumb: 'Modificación de titulares' },
                component: ModificaciontitularesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'consultatitularesdependientes',
                data: { breadcrumb: 'Consulta de titulares y dependientes' },
                component: ConsultatitularesdependientesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'compensacion',
                data: { breadcrumb: 'Mi Compensación' },
                component: ConsultatitularestotalstatementComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'consultatitularesdependientes',
                data: { breadcrumb: 'Consulta de titulares y dependientes' },
                component: ConsultatitularesdependientesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'administracion',
                data: { breadcrumb: 'Movimientos de Titulares y Dependientes' },
                component: AdmDependientesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'preview-bemobile',
                data: { breadcrumb: 'PreView BeMobile' },
                component: PreViewBeMobileComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'preview-compensaciones',
                data: { breadcrumb: 'Preview Compensaciones' },
                component: PreviewCompensacionesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'cargamasivapoblaciones',
                data: { breadcrumb: 'Carga masiva de poblaciones' },
                component: CargamasivaadmComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'beneficiarios',
                data: { breadcrumb: 'Administración de beneficiarios' },
                component: BeneficiariosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'gcambioscali',
                data: { breadcrumb: 'Generación de Cambios Calificados' },
                component: GeneracionCambiosCalificadosComponent,
                canActivate: [CanActivateViaAuthGuard],
                canDeactivate: [CanDesActivateGuard],
              },
              {
                path: 'borradopoblacion',
                data: { breadcrumb: 'Borrado de población' },
                component: BorradoPoblacionComponent,
                canActivate: [CanActivateViaAuthGuard]
              },
              {
                path: 'reseteousuario',
                data: { breadcrumb: 'Gestión de reseteo de cuentas de usuario del cotizador' },
                component: ReseteoCuentaEmpleadoComponent,
                canActivate: [CanActivateViaAuthGuard]
              },
            ],
          },

          {
            path: 'solicitudes',
            data: { breadcrumb: 'Administración de Solicitudes' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'administracion',
                data: { breadcrumb: 'Solicitudes de Beneficios' },
                component: AdminSolicitudesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'beneficiosempleado',
                data: { breadcrumb: 'Consulta última selección empleado' },
                component: ConsultabeneficiosempleadoComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'regeneracionsolicitud',
                data: { breadcrumb: 'Regeneración de solicitudes' },
                component: RegeneracionSolicitudComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'sami',
                data: { breadcrumb: 'Solicitud Excedente SAMI' },
                component: SamiComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'defaulteo',
                data: { breadcrumb: 'Crear y actualizar solicitudes' },
                component: ReporteDefaulteoComponent,
                canActivate: [CanActivateViaAuthGuard], // SHALOM
              },
              {
                path: 'defaulteo-casos-especiales',
                data: { breadcrumb: 'Crear y Actualizar Solicitudes Casos especiales' },
                component: ReporteDefaulteoCasosEspecialesComponent,
                canActivate: [CanActivateViaAuthGuard], // CREA 06 - casos especiales
              }
            ],
          },

          {
            path: 'dependientes',
            data: { breadcrumb: 'Administración de Dependientes' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'consultatitularesdependientes',
                data: { breadcrumb: 'Consulta de titulares y dependientes' },
                component: ConsultatitularesdependientesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'administracion',
                data: { breadcrumb: 'Movimientos de Titulares y Dependientes' },
                component: AdmDependientesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
            ],
          },
          {
            path: 'documentos',
            data: { breadcrumb: 'Administración de Documentos' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'asignarsubir',
                data: { breadcrumb: 'Subir y asignar documentos' },
                component: AsignarSubirComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'docexistente',
                data: { breadcrumb: 'Documentos existentes' },
                component: DocExistenteComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'docpersonalizados',
                data: {
                  breadcrumb: 'Administración de documentos personalizados',
                },
                component: DocPersonalizadosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
            ],
          },

          {
            path: 'passwords',
            data: { breadcrumb: 'Administración de passwords' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
            ],
          },

          {
            path: 'reportes',
            data: { breadcrumb: 'Reportes' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'kpi',
                data: { breadcrumb: 'Reporte de KPI\'s' },
                component: KPIComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'cobranza',
                data: { breadcrumb: 'Reporte de cobranza' },
                component: CobranzaComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'bitacoranavegacion',
                data: { breadcrumb: 'Reporte de Bitácora de Navegación' },
                component: BitacoraNavegacionComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'reporteaccesobemobile',
                data: { breadcrumb: 'Reporte Accesos Bemobile'},
                component: ReporteAccesosBemobileComponent,
                canActivate: [CanActivateViaAuthGuard]
              },
              {
                path: 'bitacoranotificaciones',
                data: { breadcrumb: 'Bitácora de Notificaciones'},
                component: ReporteBitacoraNotificacionesComponent,
                canActivate: [CanActivateViaAuthGuard]
              },
              {
                path: 'reportesolicitudes',
                data: { breadcrumb: 'Reporte de Accesos y Solicitudes' },
                component: ReporteSolicitudesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'reportedocpersonalizados',
                data: { breadcrumb: 'Reporte de documentos personalizados' },
                component: ReporteDocPersonalizadosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'beneficiarios',
                data: { breadcrumb: 'Reporte de beneficiarios' },
                component: ReporteBeneficiariosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'reportecostos',
                data: {
                  breadcrumb: 'Reporte comparativo de costos y créditos',
                },
                component: ReporteCostosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'reporte-casa-habitacion',
                data: {
                  breadcrumb: 'Reporte Casa Habitación',
                },
                component: ReporteCasaHabitacionComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'asegurados',
                data: { breadcrumb: 'Reportes de Población' },
                component: AseguradosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'sabana',
                data: { breadcrumb: 'Reporte de Sábana de Beneficios' },
                component: SabanaBeneficiosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'reporteLocktonOne',
                data: {
                  breadcrumb: 'Reporte sincronización LocktonOne',
                },
                component: EnvioLocktonOne,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'cambioscalificados',
                data: { breadcrumb: 'Reporte de Cambios Calificados' },
                component: CambiosCalificadosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'regeneracion',
                data: { breadcrumb: 'Regeneración de Solicitudes' },
                component: RegSolicitudesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'asignacionplanes',
                data: { breadcrumb: 'Reporte de Asignacion Planes' },
                component: AsignacionPlanesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'reportefactura',
                data: { breadcrumb: 'Reportes módulo de facturas' },
                canActivate: [CanActivateViaAuthGuard],
                children:
                [
                  {
                    path: '',
                    component: SubMenuComponent,
                    canActivate: [CanActivateViaAuthGuard],
                  },
                  {
                    path: 'reportefacturas',
                    data: { breadcrumb: 'Reportes Facturas' },
                    component: ReporteFacturasComponent,
                    canActivate: [CanActivateViaAuthGuard],
                  },
                  {
                    path: 'reportecontabilidad',
                    data: { breadcrumb: 'Reportes Contabilidad' },
                    component: ReporteContabilidadComponent,
                    canActivate: [CanActivateViaAuthGuard],
                  },
                  {
                    path: 'reportesaldos',
                    data: { breadcrumb: 'Reportes de saldos' },
                    component: ReporteSaldosComponent,
                    canActivate: [CanActivateViaAuthGuard],
                  },
                ]
              },
              {
                path: 'reporte-crear',
                data: { breadcrumb: 'Crear Nuevo Reporte' },
                component: ReporteCrearComponent,

              },
              {
                path: 'reporte-reconfigurar',
                data: { breadcrumb: 'Reconfigurar Reporte' },
                component: ReporteReconfigurarComponent,

              },
              {
                path: 'reporte-configuracion',
                data: { breadcrumb: 'Configuracion de Reportes' },
                component: ReporteConfiguracionComponent,

              },
              {
                path: 'reporte-estadistico',
                data: { breadcrumb: 'Reporte estadístico' },
                component: ReporteEstadisticoComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'validaciones-post-enrollment',
                data: { breadcrumb: 'Validaciones Post Enrollment' },
                component: ValidacionesPostEnrollmentComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'reporte-seguimiento',
                data: { breadcrumb: 'Seguimiento de Reportes' },
                component: ReporteSeguimientoComponent,

              },
              {
                path: 'reporte-configurar-exportacion',
                data: { breadcrumb: 'Configurar Exportación de Reportes' },
                component: ReporteConfigurarExportacionComponent,

              },
              {
                path: 'reporte-compensacion-empleado',
                data: { breadcrumb: 'Consultar reporte compensación empleado' },
                component: CompensacionEmpleadoComponent,
                canActivate: [CanActivateViaAuthGuard]
              },
            ],
          },

          {
            path: 'adm-accesos',
            data: { breadcrumb: 'Administración de Accesos' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'accesos',
                data: { breadcrumb: 'Reinicio de contraseñas y desbloqueo' },
                component: AdmAccesosComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
            ],
          },

          {
            path: 'adn',
            data: { breadcrumb: 'Tareas para ADN' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
            ],
          },

          {
            path: 'migracion',
            data: { breadcrumb: 'Migración Opera' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'configuracionenvio',
                data: { breadcrumb: 'Configuración periodos envío' },
                component: ConfEnvioComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'cifrascontrol',
                data: { breadcrumb: 'Cifras control' },
                component: CifrasControlComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'confsubgrupos',
                data: { breadcrumb: 'Configuración de subgrupos' },
                component: ConfSubgruposComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
            ],
          },

          {
            path: 'siniestros',
            data: { breadcrumb: 'Siniestros' },
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'consultadetalle',
                data: { breadcrumb: 'Consulta siniestros' },
                component: ConsultasiniestrosdetalleComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'consultaindicadores',
                data: { breadcrumb: 'Consulta indicadores siniestros' },
                component: ConsultaindicadoressiniestroComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
            ],
          },

          {
            path: 'subiryasignarfacturas',
            data: { breadcrumb: 'Módulo de facturas' },
            component: facturacionComponent,
            canActivate: [CanActivateViaAuthGuard],





          },

          {
            path: 'tickets',
            data: { breadcrumb: 'Módulo de tickets' },
            component: AdmTicketsComponent,
            canActivate: [CanActivateViaAuthGuard],
          },
          {
            path: 'calculadora-retiro',
            data: { breadcrumb: 'Módulo de calculadora retiro' },
            component: AdmCalculadoraRetiroComponent,
            canActivate: [CanActivateViaAuthGuard],
          },

          {
            path: 'ey-retiro',
            data: { breadcrumb: 'Módulo de EY retiro' },
            component: AdmEyretiroComponent,
            canActivate: [CanActivateViaAuthGuard],
          },
          {
            path: 'red-medica',
            data: { breadcrumb: 'Módulo de Administracion Red Médica'},
            canActivate: [CanActivateViaAuthGuard],
            children: [
              {
                path: '',
                component: SubMenuComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'administraciontitulares',
                data: { breadcrumb: 'Administracion de Titulares' },
                component: AdministracionTitularesComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'altaempleados',
                data: { breadcrumb: 'Alta de Titulares a la Red Médica' },

                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'cargamasiva',
                data: { breadcrumb: 'Carga Masiva a la Red Médica' },
                component: CargaMasivaComponent,
                canActivate: [CanActivateViaAuthGuard],
              },
              {
                path: 'reportes',
                data: { breadcrumb: 'Reportes Red Médica' },
                component: ReportesRedMedicaComponent,
                canActivate: [CanActivateViaAuthGuard],
              }
            ]
          }
        ],
      },

      {
        path: 'seguridad',
        data: { breadcrumb: 'Seguridad' },
        canActivate: [CanActivateViaAuthGuard],
        children: [
          {
            path: '',
            component: SubMenuComponent,
            canActivate: [CanActivateViaAuthGuard],
          },
          {
            path: 'cambioempresa',
            data: { breadcrumb: 'Cambio de empresa' },
            component: CambioEmpresaComponent,
            canActivate: [CanActivateViaAuthGuard],
          },
          {
            path: 'cambiopassword',
            data: { breadcrumb: 'Cambio de contraseña' },
            component: CambiopasswordComponent,
            canActivate: [CanActivateViaAuthGuard],
          },
        ],
      },


      {
        path: 'verificacion/:identificador/:empresa',
        component: VerificacionComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'beflex',
        component: BeflexComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'perfil',
        component: PerfilComponent,
        canActivate: [CanActivateViaAuthGuard],
      },




      {
        path: 'dependientes',
        component: DependientesComponent,
        canActivate: [CanActivateViaAuthGuard],
      },

      {
        path: 'configuracion',
        component: ConfiguracionComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'calculadora',
        component: CalculadoraComponent,
        canActivate: [CanActivateViaAuthGuard],
      },

      {
        path: 'facturacion',
        component: facturacionComponent,
        canActivate: [CanActivateViaAuthGuard],
      },

      {
        path: 'cotizador',
        component: CotizadorComponent,
        canActivate: [CanActivateViaAuthGuard],
      },

      {
        path: 'compensacion',
        component: CompensacionComponent,
        canActivate: [CanActivateViaAuthGuard],
      },

      {
        path: 'documentos',
        component: DocumentosComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'noticias',
        component: NoticiasComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'videos',
        component: VideosComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'misdocumentos',
        component: MisdocumentosComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'misdatosfiscales',
        component: MisdatosfiscalesComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'misolicitudesdebeneficios',
        component: MisolicitudesdebeneficiosComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'misolicitudesdebeneficios/solicitud/',
        component: SolicitudComponent,
        canActivate: [CanActivateViaAuthGuard],
      },

      {
        path: 'registrodebeneficiarios',
        component: RegistrodebeneficiariosComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'registroMascotas',
        component: RegistroMascotasComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'marketplace-gnp',
        component: MarketplaceComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'solicitudcambiocalificado',
        component: SolicitudcambiocalificadoComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'membresias',
        component: MembresiasComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'membresiasdos',
        component: MembresiasdosComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'tickets',
        component: TicketsComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'monitor',
        component: MonitorComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'buzon/preguntas',
        component: PreguntasComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'buzon/respuestas',
        component: RespuestasComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'lizzy',
        component: RedirectLizzyComponent,
        canActivate: [CanActivateViaAuthGuard],
      },




      {
        path: 'beflex/submenu',
        component: SubMenuComponent,
        canActivate: [CanActivateViaAuthGuard],
      },



      {
        path: 'testing',
        component: TestingComponent,
        canActivate: [CanActivateViaAuthGuard],
      },

      {
        path: 'dependientesmaster',
        component: DependientesmasterComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'misdatosfiscalesmaster',
        component: MisdatosfiscalesmasterComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'beneficiosmaster',
        component: BeneficiosmasterComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'beneficiariosMaster',
        component: RegistroBeneficiariosMasterComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'casahabitacion',
        component: CasaComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'datosbancarios',
        component: DatosBancariosComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      {
        path: 'reportedetalladocobro',
        component: ReporteDetalladoCobroComponent,
        canActivate: [CanActivateViaAuthGuard],
      },
      { path: '', pathMatch: 'full', redirectTo: 'home' },
      { path: '**', pathMatch: 'full', redirectTo: 'home' },
    ],
  },
];


@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ],
})
export class PagesRoutingModule { }
