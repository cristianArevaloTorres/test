# Complemento BF3: captura manual para Carga Masiva B2

## Alcance

Este complemento permite elegir entre dos orígenes para una operación B2 desde BF3:

1. Seleccionar y ejecutar un archivo TXT existente.
2. Capturar uno o varios registros directamente en la pantalla.

La captura manual usa los campos de la plantilla seleccionada. Al ejecutar, BF3 construye
el TXT temporalmente en memoria y lo envía al mismo servicio B2 ya implementado. Por lo
tanto, se conservan la metadata, validaciones y stored procedure configurados para la
empresa y la operación; no se replica ni modifica la lógica legacy.

## Instalación

Reemplazar solamente estos dos archivos dentro del proyecto Angular BF3:

- `src/app/beflex/cargamasivaadm/cargamasivaadm.component.ts`
- `src/app/beflex/cargamasivaadm/cargamasivaadm.component.html`

No se debe borrar ningún archivo. Este complemento no contiene cambios de Java, B2 ni SQL.
Requiere que el endpoint B2 de carga TXT entregado anteriormente ya se encuentre instalado.

## Uso

1. Seleccionar una operación de carga masiva.
2. Elegir **Cargar un archivo TXT existente** o **Capturar los registros en esta pantalla**.
3. En captura manual, completar los campos comunes y las filas de datos.
4. Usar **Agregar registro** para incluir filas adicionales.
5. Presionar **Ejecutar carga**.

Opcionalmente, **Descargar esta captura como TXT** permite guardar el contenido generado
sin ejecutarlo.

## Validaciones en pantalla

- Entre 1 y 3,000 registros.
- Campos requeridos completos.
- Ningún valor por registro puede contener `|` ni saltos de línea.
- La estructura y el orden se generan desde la plantilla de la operación.

Las validaciones funcionales definitivas y la ejecución se mantienen del lado B2.

## Verificación realizada

- TypeScript: `tsc --noEmit` correcto.
- Angular AOT producción: compilación correcta.
- No se realizaron operaciones sobre base de datos.
