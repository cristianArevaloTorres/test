package com.lockton.WSBeFlex.REST;

import com.lockton.WSBeFlex.Services.CargaMasivaB2.CargaMasivaB2Service;
import com.lockton.WSBeFlex.Services.CargaMasivaFlujoService;
import com.lockton.WSBeFlex.Services.GeneralesService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.UsuarioToken;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("beflex/carga-masiva/b2")
public class WSCargaMasivaB2 {
    private static final Log LOG = LogFactory.getLog(WSCargaMasivaB2.class);
    private final CargaMasivaB2Service service;
    private final CargaMasivaFlujoService flujoService;
    private final GeneralesService generalesService;
    private final JwtService jwtService;

    public WSCargaMasivaB2(CargaMasivaB2Service service,
                           CargaMasivaFlujoService flujoService,
                           GeneralesService generalesService,
                           JwtService jwtService) {
        this.service = service;
        this.flujoService = flujoService;
        this.generalesService = generalesService;
        this.jwtService = jwtService;
    }

    @PostMapping(value = "/ejecutar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> ejecutar(
            @RequestParam int idEmpresa,
            @RequestParam int idOperacion,
            @RequestParam String modo,
            @RequestParam("archivo") MultipartFile archivo,
            @RequestHeader(value = "authorization", required = false) String token,
            HttpServletRequest request) {
        UsuarioToken usuario = usuarioAutenticado(token);
        if (usuario == null) return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        if (!flujoService.tieneAccesoEmpresa(usuario.n, idEmpresa)) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        String idTraza = request.getHeader("X-Correlation-ID");
        if (idTraza == null || !idTraza.matches("[A-Za-z0-9._-]{8,100}")) {
            idTraza = UUID.randomUUID().toString();
        }
        try {
            return ResponseEntity.ok(service.ejecutar(
                    idEmpresa, idOperacion, modo, archivo, usuario.n, idTraza));
        } catch (IllegalArgumentException e) {
            return error(HttpStatus.BAD_REQUEST, idTraza, "PREPARACION_VALIDACION", e.getMessage());
        } catch (Exception e) {
            LOG.error("Fallo carga TXT B2. Traza=" + idTraza, e);
            return error(HttpStatus.CONFLICT, idTraza, "EJECUCION_SERVIDOR",
                    "La carga no pudo completarse. Consulte el log del WS con el identificador de traza.");
        }
    }

    private UsuarioToken usuarioAutenticado(String token) {
        try {
            if (token == null || !generalesService.validarTokenId(0, token, 4)) return null;
            UsuarioToken usuario = jwtService.getPayloadFromToken(token);
            return usuario != null && usuario.n > 0 ? usuario : null;
        } catch (Exception e) {
            return null;
        }
    }

    private ResponseEntity<Map<String, Object>> error(HttpStatus estado, String idTraza,
                                                       String etapa, String mensaje) {
        Map<String, Object> cuerpo = new LinkedHashMap<>();
        cuerpo.put("idTraza", idTraza);
        cuerpo.put("resultado", "ERROR");
        cuerpo.put("etapa", etapa);
        cuerpo.put("mensaje", mensaje);
        return new ResponseEntity<>(cuerpo, estado);
    }
}
