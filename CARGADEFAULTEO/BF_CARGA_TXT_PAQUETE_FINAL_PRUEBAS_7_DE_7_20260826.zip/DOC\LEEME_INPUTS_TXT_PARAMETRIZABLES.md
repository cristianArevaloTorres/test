# Inputs TXT B2 parametrizables para ejecutar desde BF3

## Parámetros

Use los mismos valores en los tres scripts:

```sql
DECLARE @IdEmpresa       INT         = 186;
DECLARE @ClaveUsuario    VARCHAR(50) = 'jvazquez';
DECLARE @IdEmpresaOrigen INT         = 187;
DECLARE @NumeroPrueba    INT         = 1;
```

Cambie únicamente `@NumeroPrueba` a `2`, `3`, etc. para preparar un lote
independiente.

## Causa del error «campo común inválido en la línea 7»

El parser Java terminaba `@commonFields` solamente al encontrar una línea
completamente vacía. Algunos editores o una copia desde SSMS eliminan esa línea;
entonces el comentario o `@fieldNames` siguiente se intentaba leer como
`Nombre=Valor` y aparecía el error.

El parser quedó homologado con el parser Angular:

- Acepta línea vacía o el siguiente encabezado `@...` como fin de campos comunes.
- Ignora comentarios que comienzan con `#` dentro de esa sección.
- Acepta finales de línea Windows, Unix y legacy (`CRLF`, `LF` o `CR`).
- Recorta espacios del nombre y valor común.

Este cambio de backend debe desplegarse junto con los scripts.

## Formato corregido

Los ejemplos vuelven a utilizar campos comunes, pero únicamente aquellos que
realmente aparecen en la plantilla activa:

```text
@commonFields:
EMEmpresa=S001

@fieldNames:EMNumeroEmpleado,EMPuestoDescripcion,...
@data:
18600000102|STAFF 5/8|DUMMY|ALTA|...
```

Para alta de titular el único campo común es `EMEmpresa`. No se agrega
`EMUsuarioUMod` porque la plantilla 507 no lo define. En conciliación sí se
incluye, porque la plantilla 539 contiene ese campo. Independientemente del
archivo, BF3 reemplaza el usuario de auditoría con el usuario autenticado.

## Qué datos se usan

Las cargas cambian información. Por seguridad, los empleados modificados son
dummies controlados:

| Operación | Insumo |
|---|---|
| 1 Alta dependiente | Titular dummy activo; se agrega un dependiente dummy. |
| 2 Alta titular | Número dummy nuevo que no existe. |
| 5 Conciliación | Empleado dummy con calendario, solicitud y estado de cuenta QA. |
| 13 Cambio de número | Titular dummy y nuevo número reservado. |
| 14 Reactivación | Titular dummy inactivo con fecha de baja. |
| 15 Transferencia | Titular dummy activo en la empresa origen. |
| 16 Compensación | Titular dummy activo. |

Empresa legacy, administrador, perfil, rol, vigencia, área, oficina, CECO y
compensación se consultan de registros reales que ya cumplen catálogos.

El generador también muestra candidatos existentes:

- `06B`: titulares activos que podrían recibir dependientes.
- `06C`: titulares inactivos que podrían reactivarse.
- `06D`: titulares existentes que podrían transferirse.
- `06E`: titulares activos aplicables a compensación.
- `06F`: cadenas existentes aplicables a conciliación de autos.

Son informativos y no se usan automáticamente porque modificarían empleados o
movimientos reales.

## Orden de ejecución

1. Ejecute `PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql`.
2. Ejecute `GENERAR_INPUTS_TXT_CARGA_MASIVA_EMPRESA_186.sql` con los mismos
   parámetros.
3. Revise `02_CATALOGO_INPUTS` para saber qué insumo usa cada carga.
4. Revise `04B_VALIDACIONES_POR_TIPO_DE_CARGA`; explica las validaciones del SP,
   plantilla y catálogos.
5. `05_VALIDACION_ESTRUCTURA_TXT` debe mostrar siete resultados `OK`.
6. `06_ESTADO_PRECONDICIONES` debe mostrar `LISTO`; alta titular debe mostrar
   `LISTO PARA ALTA`.
7. Copie el contenido de `03_CONTENIDO_TXT_LISTO`.
8. Si SSMS altera saltos internos, use `03B_LINEAS_TXT_SIN_SALTOS_OCULTOS` y
   copie cada fila en orden de `LineaNumero`, dejando cada una en una línea.
9. Ejecute el TXT desde BF3.
10. Ejecute `COMPROBAR_RESULTADOS_CARGA_MASIVA_POR_PRUEBA.sql`.

## Comprobación posterior

- Alta dependiente: dependiente activo y certificado del lote.
- Alta titular: exactamente un titular con el número nuevo.
- Conciliación: descuento por monto, periodo y CIS preparados.
- Cambio de número: desaparece el anterior y existe el nuevo.
- Reactivación: titular activo y sin fecha de baja.
- Transferencia: empleado en destino, fuera de origen y con log.
- Compensación: compensación activa por el monto esperado.

El bloque `09_RESUMEN_FINAL` debe terminar con `PruebasOK=7`,
`TotalPruebas=7` y resultado `OK`.

Los archivos de `EJEMPLOS_TXT_CARGA_186` son una fotografía para empresa 186,
prueba 1. El resultado del generador es la fuente correcta cuando cambian
empresa, usuario, configuración o número de prueba.

## Trazabilidad detallada del TXT B2 ejecutado desde BF3

El log conserva el contexto generado en el navegador y agrega las etapas del
servidor. Cada línea incluye fecha, identificador de traza, flujo, empresa y
etapa. Las etapas posibles son:

- `INICIO`: archivo, tamaño, usuario y modo de ejecución.
- `CONFIGURACION`: operación, plantilla y procedimiento almacenado resueltos
  desde la configuración B2.
- `ESTRUCTURA_TXT`: cantidad de registros, campos comunes y campos por
  registro. Sólo se muestran nombres de campos; no se imprime el contenido de
  las filas.
- `VALIDACIONES_B2`: total de campos activos, catálogos específicos y política
  de continuación de errores.
- `RENGLON_OK`: renglón procesado, SP, código devuelto y duración.
- `RENGLON_ERROR`: falla previa o durante la ejecución e indica la etapa exacta
  (`VALIDACION_CAMPOS`, `EJECUCION_SP` o `INTERPRETACION_RESPUESTA`).
- `RENGLON_ERROR_SP`: el TXT pasó las validaciones, pero el SP devolvió error.
- `RESUMEN`: total, procesados, correctos, errores, omitidos y duración total.

Si la petición falla antes de iniciar el recorrido, BF3 muestra
`PREPARACION_VALIDACION`; si ocurre una excepción no controlada del servidor,
muestra `EJECUCION_SERVIDOR`. El identificador de traza permite relacionar el
mensaje visible, el TXT descargable y el log técnico del WS.
