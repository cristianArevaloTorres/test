/*
  PRUEBA INTEGRAL Y REVERSIBLE DE CARGAS TXT B2 EJECUTADAS DESDE BF3

  Empresa: 186
  Usuario: jvazquez
  Lote:    prueba 1

  IMPORTANTE:
  - Ejecutar con SQLCMD (sqlcmd.exe o SSMS con Query > SQLCMD Mode).
  - Los tres SQL deben estar en la misma carpeta.
  - Usa exactamente los datos de EJEMPLOS_TXT_CARGA_186.
  - Abre una transaccion exterior, prepara los dummies, ejecuta los siete SP,
    valida sus efectos y finalmente hace ROLLBACK.
  - No deja titulares, dependientes, transferencias, conciliaciones ni
    compensaciones creadas por esta corrida.
*/
:on error exit

SET NOCOUNT ON;
SET XACT_ABORT ON;

IF DB_NAME() IS NULL
    THROW 52200, 'No fue posible identificar la base de datos.', 1;

/* Estado previo mínimo para demostrar que el ROLLBACK lo conserva. */
IF OBJECT_ID('tempdb..#EstadoAntes') IS NOT NULL DROP TABLE #EstadoAntes;
CREATE TABLE #EstadoAntes
(
    empleados INT NOT NULL,
    checksumEmpleados INT NULL,
    administradores INT NOT NULL,
    checksumAdministradores INT NULL
);

INSERT #EstadoAntes
    (empleados, checksumEmpleados, administradores, checksumAdministradores)
SELECT
    COUNT(*),
    CHECKSUM_AGG(BINARY_CHECKSUM(
        Id, EMIdEmpresa, EMIdEstatus, EMNumeroEmpleado, EMIdParentesco,
        EMFechaBaja, EMIdPerfil, EMIdRol, EMSalarioBase
    )),
    (SELECT COUNT(*) FROM dbo.ff_Administrador),
    (SELECT CHECKSUM_AGG(BINARY_CHECKSUM(
        ADIdAdministrador, ADIdEmpleado, ADClaveAcceso, ADIdEstatus
     )) FROM dbo.ff_Administrador)
FROM dbo.ff_Empleado
WHERE EMNumeroEmpleado IN
(
    '18600000101', '18600000102', '18600000103', '18600000104',
    '18600000105', '18600000106', '18600000107', '18600000108'
);

BEGIN TRANSACTION;

/* El esquema local vacío puede no traer usuarios. Se crea sólo dentro de la
   transacción para reproducir al usuario solicitado sin dejarlo registrado. */
IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Administrador
    WHERE ADClaveAcceso='jvazquez' AND ADIdEstatus=1
)
BEGIN
    /* COL_NAME evita depender de la codificacion de la letra en el nombre
       historico de la columna 7 (contrasena). */
    DECLARE @ColumnaPassword SYSNAME = COL_NAME(OBJECT_ID('dbo.ff_Administrador'), 7);
    DECLARE @SqlAdmin NVARCHAR(MAX) =
        N'INSERT dbo.ff_Administrador '
        + N'(ADIdEmpleado, ADApellidoPaterno, ADApellidoMaterno, ADNombres, '
        + N'ADClaveAcceso, ' + QUOTENAME(@ColumnaPassword) + N', ADIdAcceso, ADIdEstatus, '
        + N'ADCorreoElectronico, ADUsuarioAdd, ADFechaAdd, ADUsuarioUMod, ADFechaUMod) '
        + N'VALUES (0, ''PRUEBA'', ''TRANSACCIONAL'', ''JVazquez'', '
        + N'''jvazquez'', ''NO_UTILIZAR'', NULL, 1, '
        + N'''qa.transaccional@dummy.invalid'', 0, GETDATE(), 0, GETDATE());';
    EXEC sys.sp_executesql @SqlAdmin;
END;

IF (SELECT COUNT(*) FROM dbo.ff_Administrador
    WHERE ADClaveAcceso='jvazquez' AND ADIdEstatus=1) <> 1
    THROW 52208, 'No se pudo resolver un unico jvazquez transaccional.', 1;
GO

/* Este COMMIT es anidado: la transaccion exterior permanece abierta. */
:r .\PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql

IF @@TRANCOUNT <> 1
    THROW 52201, 'La preparacion no conservo la transaccion exterior.', 1;

DECLARE @IdEmpresa INT = 186;
DECLARE @IdEmpresaOrigen INT = 187;
DECLARE @Usuario INT;
DECLARE @TotalEsperado INT = 7;

SELECT @Usuario = ADIdAdministrador
FROM dbo.ff_Administrador
WHERE ADClaveAcceso = 'jvazquez' AND ADIdEstatus = 1;

IF @Usuario IS NULL
    THROW 52202, 'No se encontro al usuario activo jvazquez.', 1;

DECLARE @Resultados TABLE
(
    Orden INT NOT NULL PRIMARY KEY,
    IdOperacion INT NOT NULL,
    Operacion VARCHAR(100) NOT NULL,
    Archivo VARCHAR(100) NOT NULL,
    CamposComunes VARCHAR(500) NOT NULL,
    CodigoSP INT NULL,
    MensajeSP VARCHAR(2000) NULL,
    ValidacionNegocio VARCHAR(20) NOT NULL
);

BEGIN TRY
    /* ================================================================
       01 - ALTA DEPENDIENTE
       TXT: 01_ALTA_DEPENDIENTE_186.txt
       Comun: EMIdEmpresa=186
       F y H se convierten con los mismos catalogos de plantilla B2.
       ================================================================ */
    DECLARE @SexoF INT;
    DECLARE @ParentescoH INT;
    DECLARE @Sexo TABLE ([key] VARCHAR(32), [value] VARCHAR(32));
    DECLARE @Parentesco TABLE ([key] VARCHAR(32), [value] VARCHAR(32));
    INSERT @Sexo EXEC dbo.ff_CMCSexo;
    INSERT @Parentesco EXEC dbo.ff_CMCParentesco;
    SELECT @SexoF = TRY_CONVERT(INT, [value]) FROM @Sexo WHERE [key] = 'F';
    SELECT @ParentescoH = TRY_CONVERT(INT, [value]) FROM @Parentesco WHERE [key] = 'H';
    IF @SexoF IS NULL OR @ParentescoH IS NULL
        THROW 52203, 'No se resolvieron las equivalencias F/H de la operacion 1.', 1;

    DECLARE @R1 TABLE (Return_Code INT, Return_Msg VARCHAR(2000));
    INSERT @R1
    EXEC dbo.ff_XCMDependientesAltaCMM
        @EMIdEmpresa = 186,
        @EMIdSexo = @SexoF,
        @EMNumeroEmpleado = '18600000101',
        @EMApellidoPaterno = 'PRUEBA',
        @EMApellidoMaterno = 'DEPENDIENTE',
        @EMNombre1 = 'DUMMY',
        @EMNombre2 = 'CARGA',
        @EMFechaNacimiento = '2015-06-15',
        @EMFechaAntiguedadGMM = '2024-01-01',
        @EMIdParentesco = @ParentescoH,
        @EMFechaAlta = '2026-08-26',
        @EMObservaciones = 'QA CARGA B2 BF3 PRUEBA 1',
        @EMCertificado = '1860000010101';

    INSERT @Resultados
    SELECT 1, 1, 'ALTA DEPENDIENTE', '01_ALTA_DEPENDIENTE_186.txt',
           'EMIdEmpresa=186', Return_Code, Return_Msg,
           CASE WHEN Return_Code = 0 AND EXISTS
           (
               SELECT 1 FROM dbo.ff_Empleado
               WHERE EMIdEmpresa = 186
                 AND EMNumeroEmpleado = '18600000101'
                 AND EMIdParentesco <> 1
                 AND EMCertificado = '1860000010101'
           ) THEN 'OK' ELSE 'ERROR' END
    FROM @R1;

    /* ================================================================
       02 - ALTA TITULAR
       TXT: 02_ALTA_TITULAR_186.txt
       Comun: EMEmpresa=S001
       ================================================================ */
    DECLARE @SexoM INT;
    SELECT @SexoM = TRY_CONVERT(INT, [value]) FROM @Sexo WHERE [key] = 'M';
    IF @SexoM IS NULL THROW 52204, 'No se resolvio la equivalencia M.', 1;

    DECLARE @R2 TABLE (Return_Code INT, Return_Msg VARCHAR(2000));
    INSERT @R2
    EXEC dbo.ff_XCMTitularesAltaCMDeloitte
        @EMNumeroEmpleado = '18600000102',
        @EMPuestoDescripcion = 'STAFF 5/8',
        @EMNombre1 = 'DUMMY',
        @EMApellidoPaterno = 'ALTA',
        @EMApellidoMaterno = 'TITULAR',
        @EMFechaNacimiento = '1990-05-20',
        @EMIdSexo = @SexoM,
        @EMFechaIngresoEmpresa = '2026-08-26',
        @EMIdEstatus = 3,
        @EMFechaEstatus = '2026-08-26',
        @EMcurp = 'QACM000001HDFLRN01',
        @EMrfc = 'QAC000001AA1',
        @EMIdTransferido = 0,
        @EMEstadoFisical_text = 'CIUDAD DE MEXICO',
        @EMnss = '18600000102',
        @EMPuesto = 'STAFF 5/8',
        @EMCentroCostos_text = '35007',
        @EMOficina_text = 'MEX',
        @EMArea_text = 'MEX',
        @EMEmpresa = 'S001',
        @EMArchivoInformacion = 'STAFF',
        @EMCorreoElectronico = 'qacm.186.p1@dummy.mx',
        @EMCalleFisico = 'DOMICILIO DUMMY',
        @EMMunicipioDelegacionFiscal = '',
        @EMJefe = '0',
        @EMEstadoFisico_text = '',
        @EMColoniaFiscal = '',
        @EMColoniaFisico = '0',
        @EMMunicipioDelegacionFisico = '0',
        @EMSalarioBase = 4,
        @EMCodigoPostalFisico = '0';

    INSERT @Resultados
    SELECT 2, 2, 'ALTA TITULAR', '02_ALTA_TITULAR_186.txt',
           'EMEmpresa=S001', Return_Code, Return_Msg,
           CASE WHEN Return_Code = 0 AND EXISTS
           (
               SELECT 1 FROM dbo.ff_Empleado
               WHERE EMIdEmpresa = 186
                 AND EMNumeroEmpleado = '18600000102'
                 AND EMIdParentesco = 1
           ) THEN 'OK' ELSE 'ERROR' END
    FROM @R2;

    /* ================================================================
       05 - CONCILIACION AUTOS
       TXT: 05_CONCILIACION_AUTOS_186.txt
       Comunes: EMEmpresa=S001 y EMUsuarioUMod (BF3 usa el autenticado).
       ================================================================ */
    DECLARE @R5 TABLE (Return_Code INT, Return_Msg VARCHAR(2000));
    INSERT @R5
    EXEC dbo.ff_XCMDescuentosCMAutos
        @EMEmpresa = 'S001',
        @EMUsuarioUMod = @Usuario,
        @EMNumeroEmpleado = '18600000107',
        @Quincenaanio = 'QACM186P1',
        @SANumeroRegistroAseguradora = 'QACM-CIS-186-P1',
        @CDMontoConciliacion = 100.00;

    INSERT @Resultados
    SELECT 3, 5, 'CONCILIACION AUTOS', '05_CONCILIACION_AUTOS_186.txt',
           'EMEmpresa=S001; EMUsuarioUMod=usuario autenticado',
           Return_Code, Return_Msg,
           CASE WHEN Return_Code = 0 AND EXISTS
           (
               SELECT 1
               FROM dbo.fb_EdoCuentaDesglose D
               INNER JOIN dbo.fb_EdoCuentaAutos EC ON EC.ECIdEdoCuentaAutos = D.ECIdEdoCuentaAutos
               INNER JOIN dbo.fb_SolicitudAutos SA ON SA.SAidSolicitudAutos = EC.ECIdSolicitud
               WHERE SA.SANumeroRegistroAseguradora = 'QACM-CIS-186-P1'
                 AND SA.SAIdEmpresaTitular = 186
                 AND D.ECConciliado = 1
           ) THEN 'OK' ELSE 'ERROR' END
    FROM @R5;

    /* ================================================================
       13 - CAMBIO NUMERO DE EMPLEADO
       ================================================================ */
    DECLARE @R13 TABLE (codigo INT, mensaje VARCHAR(2000));
    INSERT @R13
    EXEC dbo.ff_ActualizaNumEmpleadoTitular
        @EMIdEmpresa = 186,
        @EMNumeroEmpleado = '18600000103',
        @EMNuevoNumeroEmpleado = '18600000104',
        @EMUsuarioUMod = @Usuario;

    INSERT @Resultados
    SELECT 4, 13, 'CAMBIO NUMERO DE EMPLEADO', '13_CAMBIO_NUMERO_EMPLEADO_186.txt',
           'EMIdEmpresa=186', codigo, mensaje,
           CASE WHEN codigo = 1
                  AND NOT EXISTS (SELECT 1 FROM dbo.ff_Empleado WHERE EMIdEmpresa=186 AND EMNumeroEmpleado='18600000103' AND EMIdTitular=1)
                  AND EXISTS (SELECT 1 FROM dbo.ff_Empleado WHERE EMIdEmpresa=186 AND EMNumeroEmpleado='18600000104' AND EMIdTitular=1)
                THEN 'OK' ELSE 'ERROR' END
    FROM @R13;

    /* ================================================================
       14 - REACTIVACION
       ================================================================ */
    DECLARE @R14 TABLE (codigo INT, mensaje VARCHAR(2000));
    INSERT @R14
    EXEC dbo.bf_ReactivacionEmpleadosTitular
        @EMIdEmpresa = 186,
        @EMNumeroEmpleado = '18600000105',
        @EMFechaReingreso = '2026-08-26',
        @EMUsuarioUMod = @Usuario;

    INSERT @Resultados
    SELECT 5, 14, 'REACTIVACION DE EMPLEADO', '14_REACTIVACION_EMPLEADO_186.txt',
           'EMIdEmpresa=186', codigo, mensaje,
           CASE WHEN codigo = 1 AND EXISTS
           (
               SELECT 1 FROM dbo.ff_Empleado
               WHERE EMIdEmpresa=186 AND EMNumeroEmpleado='18600000105'
                 AND EMIdEstatus=1 AND EMFechaBaja IS NULL
           ) THEN 'OK' ELSE 'ERROR' END
    FROM @R14;

    /* ================================================================
       15 - TRANSFERENCIA
       El adaptador legacy agrega IdEmpleado, idSolicitud y usuario al JSON.
       ================================================================ */
    DECLARE @IdTransferencia INT =
    (
        SELECT TOP (1) Id FROM dbo.ff_Empleado
        WHERE EMIdEmpresa = 187 AND EMNumeroEmpleado = '18600000108'
          AND EMIdParentesco = 1 AND EMIdEstatus = 1
    );
    IF @IdTransferencia IS NULL THROW 52205, 'Falta el dummy de transferencia.', 1;

    DECLARE @IdSolicitud INT = ISNULL
    (
        (SELECT TOP (1) SOIdSolicitud FROM dbo.ff_Solicitud
         WHERE SOIdEmpleado = @IdTransferencia AND SOIdEstatus = 1
           AND SOEstatusSolicitud IN (1,2,3)
         ORDER BY SOIdSolicitud DESC), 0
    );
    DECLARE @JsonTransferencia NVARCHAR(MAX) =
    (
        SELECT
            186 AS EMIdEmpresa,
            187 AS EMIdEmpresaOrigen,
            '18600000108' AS EMNumeroEmpleado,
            678 AS EMIdPerfil,
            20000.00 AS EMSalarioBase,
            'qacm.trans.p1@dummy.mx' AS EMCorreoElectronico,
            '2026-08-26' AS EMFecha_solicitud_movimiento,
            0 AS EMSeleccionUsuario,
            'QA TRANSFERENCIA B2 BF3' AS EMObservacionesTransferencia,
            @Usuario AS EMUsuarioUMod,
            @IdTransferencia AS IdEmpleado,
            @IdSolicitud AS idSolicitud
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    );

    EXEC dbo.ff_transferenciaMasivaEmpleado @parametrosCarga = @JsonTransferencia;

    INSERT @Resultados
    SELECT 6, 15, 'TRANSFERENCIA DE EMPLEADO', '15_TRANSFERENCIA_EMPLEADO_186.txt',
           'EMIdEmpresa=186',
           CASE WHEN EXISTS (SELECT 1 FROM dbo.ff_Empleado WHERE Id=@IdTransferencia AND EMIdEmpresa=186) THEN 200 ELSE 500 END,
           CASE WHEN EXISTS (SELECT 1 FROM dbo.ff_Empleado WHERE Id=@IdTransferencia AND EMIdEmpresa=186)
                THEN 'Usuario transferido correctamente.' ELSE 'No se completo la transferencia.' END,
           CASE WHEN EXISTS (SELECT 1 FROM dbo.ff_Empleado WHERE Id=@IdTransferencia AND EMIdEmpresa=186)
                  AND NOT EXISTS (SELECT 1 FROM dbo.ff_Empleado WHERE Id=@IdTransferencia AND EMIdEmpresa=187)
                THEN 'OK' ELSE 'ERROR' END;

    /* ================================================================
       16 - COMPENSACION
       ================================================================ */
    DECLARE @R16 TABLE (codigo INT, mensaje VARCHAR(2000));
    INSERT @R16
    EXEC dbo.ff_CargaMasivaCompensacionEmpleado
        @EMIdEmpresa = 186,
        @EMNumeroEmpleado = '18600000106',
        @CSIdCompensacion = 900001,
        @CSMontoCompensacion = 1500.00,
        @EMTipoCargaComp = 1,
        @EMUsuarioUMod = @Usuario;

    INSERT @Resultados
    SELECT 7, 16, 'CARGA MASIVA COMPENSACION', '16_COMPENSACION_EMPLEADO_186.txt',
           'EMIdEmpresa=186', codigo, mensaje,
           CASE WHEN codigo = 200 AND EXISTS
           (
               SELECT 1
               FROM dbo.bf_Compensacion_STEmpleado C
               INNER JOIN dbo.ff_Empleado E ON E.Id = C.CSIdEmpleado
               WHERE E.EMIdEmpresa=186 AND E.EMNumeroEmpleado='18600000106'
                 AND C.CSIdCompensacion=900001 AND C.CSIdEstatus=1
                 AND C.CSMontoCompensacion=1500.00
           ) THEN 'OK' ELSE 'ERROR' END
    FROM @R16;

    SELECT
        '01_RESULTADO_POR_CARGA' AS Bloque,
        Orden, IdOperacion, Operacion, Archivo, CamposComunes,
        CodigoSP, MensajeSP, ValidacionNegocio
    FROM @Resultados
    ORDER BY Orden;

    IF (SELECT COUNT(*) FROM @Resultados) <> @TotalEsperado
        THROW 52206, 'No se ejecutaron las siete operaciones esperadas.', 1;
    IF EXISTS (SELECT 1 FROM @Resultados WHERE ValidacionNegocio <> 'OK')
        THROW 52207, 'Una o mas cargas no superaron la validacion de negocio.', 1;

    SELECT
        '02_RESUMEN_ANTES_ROLLBACK' AS Bloque,
        COUNT(*) AS TotalCargas,
        SUM(CASE WHEN ValidacionNegocio='OK' THEN 1 ELSE 0 END) AS CargasOK,
        CASE WHEN COUNT(*)=7 AND MIN(ValidacionNegocio)='OK' AND MAX(ValidacionNegocio)='OK'
             THEN 'OK_7_DE_7' ELSE 'REVISAR' END AS Resultado
    FROM @Resultados;

    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* Comprobación de limpieza respecto del estado anterior. */
DECLARE @EmpleadosDespues INT;
DECLARE @ChecksumDespues INT;
DECLARE @AdministradoresDespues INT = (SELECT COUNT(*) FROM dbo.ff_Administrador);
DECLARE @ChecksumAdministradoresDespues INT =
(
    SELECT CHECKSUM_AGG(BINARY_CHECKSUM(
        ADIdAdministrador, ADIdEmpleado, ADClaveAcceso, ADIdEstatus
    ))
    FROM dbo.ff_Administrador
);
SELECT
    @EmpleadosDespues = COUNT(*),
    @ChecksumDespues = CHECKSUM_AGG(BINARY_CHECKSUM(
        Id, EMIdEmpresa, EMIdEstatus, EMNumeroEmpleado, EMIdParentesco,
        EMFechaBaja, EMIdPerfil, EMIdRol, EMSalarioBase
    ))
FROM dbo.ff_Empleado
WHERE EMNumeroEmpleado IN
(
    '18600000101', '18600000102', '18600000103', '18600000104',
    '18600000105', '18600000106', '18600000107', '18600000108'
);

SELECT
    '03_LIMPIEZA_FINAL' AS Bloque,
    A.empleados AS EmpleadosAntes,
    @EmpleadosDespues AS EmpleadosDespues,
    A.checksumEmpleados AS ChecksumAntes,
    @ChecksumDespues AS ChecksumDespues,
    A.administradores AS AdministradoresAntes,
    @AdministradoresDespues AS AdministradoresDespues,
    @@TRANCOUNT AS TransaccionesAbiertas,
    CASE WHEN A.empleados=@EmpleadosDespues
               AND ISNULL(A.checksumEmpleados,0)=ISNULL(@ChecksumDespues,0)
               AND A.administradores=@AdministradoresDespues
               AND ISNULL(A.checksumAdministradores,0)=ISNULL(@ChecksumAdministradoresDespues,0)
               AND @@TRANCOUNT=0
         THEN 'OK_SIN_RESIDUOS' ELSE 'REVISAR' END AS Resultado
FROM #EstadoAntes A;
GO
