# TXT listos para Carga masiva de poblaciones — empresa 186

Estos siete archivos reproducen las operaciones B2 activas configuradas para la empresa 186. No contienen marcadores: los datos ya están capturados.

Para ver en SQL la relación completa entre operación, plantilla, stored procedure, precondición, resultado esperado y contenido listo para copiar, ejecute `GENERAR_INPUTS_TXT_CARGA_MASIVA_EMPRESA_186.sql`.

Antes de cargarlos, ejecute `PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql` en la misma base que utiliza el WS local. El script crea o restablece únicamente los empleados reservados `186990001` a `186990008` y la cadena de conciliación dummy. Las columnas son `VARCHAR(20)`, pero los números de empleado contienen exclusivamente dígitos para ser compatibles con validaciones legacy.

| Archivo | Operación | Qué debe ocurrir |
|---|---:|---|
| `01_ALTA_DEPENDIENTE_186.txt` | 1 | Agrega el dependiente con certificado `18699000101` al titular existente `186990001`. El número capturado es el del titular. |
| `02_ALTA_TITULAR_186.txt` | 2 | Crea un titular nuevo con número `186990002`. |
| `05_CONCILIACION_AUTOS_186.txt` | 5 | Concilia $100 del registro de autos `QACM-CIS-186` en el periodo `QACM202699`. |
| `13_CAMBIO_NUMERO_EMPLEADO_186.txt` | 13 | Cambia `186990003` por `186990004`. |
| `14_REACTIVACION_EMPLEADO_186.txt` | 14 | Reactiva `186990005` con fecha 24/08/2026. |
| `15_TRANSFERENCIA_EMPLEADO_186.txt` | 15 | Transfiere `186990008` de la empresa 187 a la 186. |
| `16_COMPENSACION_EMPLEADO_186.txt` | 16 | Registra una compensación dummy de $1,500 para `186990006`. |

## Orden recomendado

Cada archivo es independiente, pero conviene ejecutarlos en el orden del nombre. Para repetir una prueba que modifica estado —alta, cambio, reactivación o transferencia— vuelva a ejecutar primero el script de preparación.

Las fechas del TXT usan obligatoriamente `dd/MM/yyyy`. Los campos `EMIdEmpresa`, `EMEmpresa` y `EMUsuarioUMod` están en `@commonFields`, igual que en el documento legado. BF3 sustituye `EMUsuarioUMod` por el ID del usuario autenticado antes de invocar el SP.

Estos archivos son para pruebas locales/QA. No deben cargarse en producción.
