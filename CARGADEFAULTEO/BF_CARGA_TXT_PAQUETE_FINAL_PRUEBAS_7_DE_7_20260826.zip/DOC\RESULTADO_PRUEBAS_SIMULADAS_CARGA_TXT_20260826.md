# Resultado de pruebas simuladas de carga TXT B2 desde BF3

Fecha: 26 de agosto de 2026  
Base local: `FlexiForbesv2`  
Empresa destino: `186`  
Empresa origen de transferencia: `187`  
Lote: prueba `1`

## Resultado general

Las siete operaciones configuradas fueron ejecutadas dentro de una transacción
exterior y validadas con sus reglas de negocio. La transacción terminó con
`ROLLBACK`.

| Operación | Archivo probado | Campos comunes | Código | Resultado |
|---|---|---|---:|---|
| 1 - Alta dependiente | `01_ALTA_DEPENDIENTE_186.txt` | `EMIdEmpresa` | 0 | OK |
| 2 - Alta titular | `02_ALTA_TITULAR_186.txt` | `EMEmpresa` | 0 | OK |
| 5 - Conciliación autos | `05_CONCILIACION_AUTOS_186.txt` | `EMEmpresa`, `EMUsuarioUMod` | 0 | OK |
| 13 - Cambio de número | `13_CAMBIO_NUMERO_EMPLEADO_186.txt` | `EMIdEmpresa` | 1 | OK |
| 14 - Reactivación | `14_REACTIVACION_EMPLEADO_186.txt` | `EMIdEmpresa` | 1 | OK |
| 15 - Transferencia | `15_TRANSFERENCIA_EMPLEADO_186.txt` | `EMIdEmpresa` | 200 | OK |
| 16 - Compensación | `16_COMPENSACION_EMPLEADO_186.txt` | `EMIdEmpresa` | 200 | OK |

Resumen SQL: `OK_7_DE_7`.

## Comprobaciones realizadas

- Alta dependiente: se creó el dependiente con el certificado esperado.
- Alta titular: se creó un titular nuevo para la empresa 186.
- Conciliación: el desglose quedó conciliado para el CIS, periodo y monto QA.
- Cambio de número: desapareció el número anterior y quedó el nuevo.
- Reactivación: el titular terminó activo y sin fecha de baja.
- Transferencia: el empleado pasó de la empresa 187 a la 186.
- Compensación: quedó activa la compensación por `1500.00`.
- Parser Java: los siete archivos produjeron un registro cada uno y conservaron
  los campos comunes esperados. Resultado `7/7 OK`.
- Pruebas Java del servicio y parser: `8` ejecutadas, `0` fallas, `0` errores.
- Frontend: `npx tsc -p src/tsconfig.app.json --noEmit` terminó correctamente.

## Limpieza

Antes y después de la simulación se compararon cantidad y checksum de los
empleados reservados. También se comparó la tabla de administradores, porque el
esquema local vacío necesitó un `jvazquez` transaccional.

Resultado final: `OK_SIN_RESIDUOS`.

- Empleados antes/después: `6 / 6`.
- Checksum empleados antes/después: idéntico.
- Administradores antes/después: `0 / 0`.
- Transacciones abiertas: `0`.

No se probaron descargas WSDL ni servicios que requieren VPN. Esta omisión no
afecta las validaciones locales de TXT, plantilla, SP, reglas de negocio, log o
frontend realizadas en esta corrida.
