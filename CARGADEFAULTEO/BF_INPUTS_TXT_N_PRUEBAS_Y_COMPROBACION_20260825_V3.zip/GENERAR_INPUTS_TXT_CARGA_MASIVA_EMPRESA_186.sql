/*
  GENERADOR PARAMETRIZABLE DE INPUTS TXT B2 PARA EJECUTAR DESDE BF3

  SOLO LECTURA: no inserta, actualiza ni elimina registros.

  Cambie solamente los parametros. Para el ejemplo solicitado:
      @IdEmpresa    = 186
      @ClaveUsuario = 'jvazquez'

  Los valores sujetos a validaciones se consultan en la BD. Solo los datos
  propios de QA (numeros reservados, nombres, RFC, CURP, correo y notas) son
  dummy. Para empresa 186, EMEmpresa se obtiene de
  ff_Empresa.EMIdEmpresaFlexiForbes (actualmente S001); no se deja fijo.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ========================== PARAMETROS ========================== */
DECLARE @IdEmpresa       INT         = 186;
DECLARE @ClaveUsuario    VARCHAR(50) = 'jvazquez';
DECLARE @IdEmpresaOrigen INT         = 187; -- Solo operacion 15.
DECLARE @NumeroPrueba    INT         = 1;   -- Cambie a 2, 3, 4... para otro lote.
/* =============================================================== */

DECLARE @CRLF VARCHAR(2) = CHAR(13) + CHAR(10);
DECLARE @HoyTexto VARCHAR(10) = CONVERT(VARCHAR(10), GETDATE(), 103);
DECLARE @Ahora DATETIME = GETDATE();

DECLARE @NombreEmpresa NVARCHAR(500);
DECLARE @ClaveEmpresaLegacy VARCHAR(150);
DECLARE @IdConfiguracion INT;
DECLARE @IdCorporativo INT;
DECLARE @IdUsuario INT;
DECLARE @IdRolDestino INT;
DECLARE @IdPerfilDestino INT;
DECLARE @IdVigencia INT;
DECLARE @IdEmpleadoReferencia INT;
DECLARE @Area VARCHAR(100);
DECLARE @Oficina VARCHAR(100);
DECLARE @CentroCostos VARCHAR(100);
DECLARE @Puesto VARCHAR(200);
DECLARE @IdCompensacion INT;
DECLARE @OrigenCompensacion VARCHAR(100);

/* Empresa + lote de seis digitos + escenario de dos digitos.
   Empresa 186/prueba 1: 18600000101 ... 18600000108.
   Empresa 186/prueba 2: 18600000201 ... 18600000208. */
DECLARE @Lote VARCHAR(6) = RIGHT('000000' + CONVERT(VARCHAR(6), @NumeroPrueba), 6);
DECLARE @Prefijo VARCHAR(18) = CONVERT(VARCHAR(10), @IdEmpresa) + @Lote;
DECLARE @N1 VARCHAR(20) = @Prefijo + '01';
DECLARE @N2 VARCHAR(20) = @Prefijo + '02';
DECLARE @N3 VARCHAR(20) = @Prefijo + '03';
DECLARE @N4 VARCHAR(20) = @Prefijo + '04';
DECLARE @N5 VARCHAR(20) = @Prefijo + '05';
DECLARE @N6 VARCHAR(20) = @Prefijo + '06';
DECLARE @N7 VARCHAR(20) = @Prefijo + '07';
DECLARE @N8 VARCHAR(20) = @Prefijo + '08';
DECLARE @Periodo VARCHAR(50) = 'QACM' + CONVERT(VARCHAR(10), @IdEmpresa) + 'P' + CONVERT(VARCHAR(6), @NumeroPrueba);
DECLARE @RegistroAutos VARCHAR(100) = 'QACM-CIS-' + CONVERT(VARCHAR(10), @IdEmpresa) + '-P' + CONVERT(VARCHAR(6), @NumeroPrueba);
DECLARE @CurpDummy VARCHAR(50) = 'QACM' + @Lote + 'HDFLRN01';
DECLARE @RfcDummy VARCHAR(20) = 'QAC' + @Lote + 'AA1';

IF OBJECT_ID('dbo.ff_Empresa', 'U') IS NULL
    THROW 51900, 'No existe dbo.ff_Empresa en la base seleccionada.', 1;

IF @NumeroPrueba NOT BETWEEN 1 AND 999999
    THROW 51899, '@NumeroPrueba debe estar entre 1 y 999999.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1
)
    THROW 51901, 'La empresa indicada no existe o esta inactiva.', 1;

SELECT
    @NombreEmpresa = E.EMNombre,
    @ClaveEmpresaLegacy = NULLIF(LTRIM(RTRIM(E.EMIdEmpresaFlexiForbes)), ''),
    @IdConfiguracion = E.EMIdConfiguracion,
    @IdCorporativo = E.EMIdCorporativo
FROM dbo.ff_Empresa E
WHERE E.EMIdEmpresa = @IdEmpresa;

IF @ClaveEmpresaLegacy IS NULL
    THROW 51902, 'La empresa no tiene EMIdEmpresaFlexiForbes; no se puede generar EMEmpresa.', 1;

IF NULLIF(LTRIM(RTRIM(@ClaveUsuario)), '') IS NULL
    THROW 51903, 'Capture @ClaveUsuario.', 1;

IF
(
    SELECT COUNT(*)
    FROM dbo.ff_Administrador A
    WHERE UPPER(LTRIM(RTRIM(A.ADClaveAcceso))) = UPPER(LTRIM(RTRIM(@ClaveUsuario)))
      AND A.ADIdEstatus = 1
) <> 1
    THROW 51904, 'La clave no identifica exactamente a un administrador activo.', 1;

SELECT @IdUsuario = A.ADIdAdministrador
FROM dbo.ff_Administrador A
WHERE UPPER(LTRIM(RTRIM(A.ADClaveAcceso))) = UPPER(LTRIM(RTRIM(@ClaveUsuario)))
  AND A.ADIdEstatus = 1;

/* Preferir rol default; si no existe, usar el mas frecuente en titulares. */
SELECT TOP (1) @IdRolDestino = R.ROIdRol
FROM dbo.ff_Rol R
WHERE R.ROIdEmpresa = @IdEmpresa
  AND R.ROIdEstatus = 1
  AND R.RODefault = 1
ORDER BY R.ROIdRol;

IF @IdRolDestino IS NULL
BEGIN
    SELECT TOP (1) @IdRolDestino = E.EMIdRol
    FROM dbo.ff_Empleado E
    INNER JOIN dbo.ff_Rol R
        ON R.ROIdRol = E.EMIdRol
       AND R.ROIdEmpresa = @IdEmpresa
       AND R.ROIdEstatus = 1
    WHERE E.EMIdEmpresa = @IdEmpresa
      AND E.EMIdEstatus = 1
      AND E.EMIdParentesco = 1
      AND E.EMIdTitular = 1
      AND E.EMIdRol IS NOT NULL
    GROUP BY E.EMIdRol
    ORDER BY COUNT(*) DESC, E.EMIdRol;
END;

IF @IdRolDestino IS NULL
    THROW 51905, 'No fue posible resolver un rol valido para la empresa.', 1;

/* Titular real usado unicamente como fuente de catalogos organizacionales.
   El SP Deloitte no recibe los IDs: busca TEDescripcion en los catalogos
   area/oficina/CECO. Por eso aqui se recuperan las descripciones reales. */
SELECT TOP (1)
    @IdEmpleadoReferencia = E.Id,
    @IdPerfilDestino = E.EMIdPerfil,
    @Area = A.TEDescripcion,
    @Oficina = O.TEDescripcion,
    @CentroCostos = C.TEDescripcion,
    @Puesto = COALESCE(NULLIF(LTRIM(RTRIM(E.EMPuesto)), ''), 'STAFF')
FROM dbo.ff_Empleado E
INNER JOIN dbo.ff_Perfil P
    ON P.PEIdPerfil = E.EMIdPerfil
   AND P.PEIdEmpresa = @IdEmpresa
   AND P.PEIdEstatus = 1
OUTER APPLY
(
    SELECT TOP (1) D.TEDescripcion
    FROM dbo.ff_TablaEncabezado H
    INNER JOIN dbo.ff_TablaEncabezadoDetalle D ON D.TEEnClave = H.ENClave
    WHERE H.ENIdEmpresa = @IdEmpresa AND H.ENIdEstatus = 1
      AND LOWER(H.ENEncabezado) = 'area' AND D.TEIdDetalle = E.EMArea
      AND D.TEIdEstatus = 1
) A
OUTER APPLY
(
    SELECT TOP (1) D.TEDescripcion
    FROM dbo.ff_TablaEncabezado H
    INNER JOIN dbo.ff_TablaEncabezadoDetalle D ON D.TEEnClave = H.ENClave
    WHERE H.ENIdEmpresa = @IdEmpresa AND H.ENIdEstatus = 1
      AND LOWER(H.ENEncabezado) = 'oficina' AND D.TEIdDetalle = E.EMOficina
      AND D.TEIdEstatus = 1
) O
OUTER APPLY
(
    SELECT TOP (1) D.TEDescripcion
    FROM dbo.ff_TablaEncabezado H
    INNER JOIN dbo.ff_TablaEncabezadoDetalle D ON D.TEEnClave = H.ENClave
    WHERE H.ENIdEmpresa = @IdEmpresa AND H.ENIdEstatus = 1
      AND UPPER(H.ENEncabezado) = 'CECO' AND D.TEIdDetalle = E.EMIdCentroCostos
      AND D.TEIdEstatus = 1
) C
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdEstatus = 1
  AND E.EMIdParentesco = 1
  AND E.EMIdTitular = 1
  AND E.EMIdPerfil IS NOT NULL
  AND E.EMArea IS NOT NULL
  AND E.EMOficina IS NOT NULL
  AND E.EMIdCentroCostos IS NOT NULL
  AND ISNULL(E.EMApellidoPaterno, '') NOT IN ('PRUEBA', 'ALTA')
  AND A.TEDescripcion IS NOT NULL
  AND O.TEDescripcion IS NOT NULL
  AND C.TEDescripcion IS NOT NULL
ORDER BY CASE WHEN E.EMIdRol = @IdRolDestino THEN 0 ELSE 1 END, E.Id DESC;

IF @IdEmpleadoReferencia IS NULL
    THROW 51906, 'No hay un titular activo completo para obtener perfil/area/oficina/centro de costos.', 1;

SELECT TOP (1) @IdVigencia = V.VIIdVigencia
FROM dbo.ff_Vigencia V
WHERE V.VIIdConfiguracion = @IdConfiguracion
  AND V.VIIdEstatus = 1
ORDER BY
    CASE WHEN CONVERT(DATE, @Ahora) BETWEEN CONVERT(DATE, V.VIVigenciaIni)
                                      AND CONVERT(DATE, V.VIVigenciaFin)
         THEN 0 ELSE 1 END,
    V.VIVigenciaIni DESC,
    V.VIIdVigencia DESC;

IF @IdVigencia IS NULL
    THROW 51907, 'No existe una vigencia activa para la configuracion de la empresa.', 1;

/* El ID de compensacion debe existir; ya no se inventa 900001. */
SELECT TOP (1)
    @IdCompensacion = C.CSIdCompensacion,
    @OrigenCompensacion = 'bf_Compensacion_STEmpleado (movimiento real)'
FROM dbo.bf_Compensacion_STEmpleado C
INNER JOIN dbo.ff_Empleado E ON E.Id = C.CSIdEmpleado
WHERE E.EMIdEmpresa = @IdEmpresa
  AND E.EMIdParentesco = 1
  AND C.CSIdCompensacion IS NOT NULL
ORDER BY C.CSFechaAdd DESC;

IF @IdCompensacion IS NULL
BEGIN
    SELECT TOP (1)
        @IdCompensacion = C.CCSIdConfiguracion,
        @OrigenCompensacion = 'bf_Compensacion_STConfiguracion (configuracion activa)'
    FROM dbo.bf_Compensacion_STConfiguracion C
    WHERE C.CCSIdVigencia = @IdVigencia
      AND C.CCSIdEstatus = 1
    ORDER BY C.CCSOrden, C.CCSIdConfiguracion;
END;

/* El SP ff_CargaMasivaCompensacionEmpleado no valida el ID contra catalogo;
   cuando la empresa no tiene una compensacion previa/configurada, este dato
   si puede ser dummy sin romper una validacion de BD. */
IF @IdCompensacion IS NULL
BEGIN
    SET @IdCompensacion = 900001;
    SET @OrigenCompensacion = 'DUMMY QA: EL SP NO VALIDA CATALOGO DE COMPENSACION';
END;

IF @IdEmpresaOrigen IS NULL OR @IdEmpresaOrigen = @IdEmpresa
    THROW 51909, '@IdEmpresaOrigen debe existir y ser distinta de @IdEmpresa.', 1;

IF NOT EXISTS
(
    SELECT 1 FROM dbo.ff_Empresa
    WHERE EMIdEmpresa = @IdEmpresaOrigen AND EMIdEstatus = 1
)
    THROW 51910, 'La empresa origen de transferencia no existe o esta inactiva.', 1;

DECLARE @Inputs TABLE
(
    Orden INT NOT NULL PRIMARY KEY,
    IdOperacion INT NOT NULL UNIQUE,
    Archivo VARCHAR(120) NOT NULL,
    ParaQueSirve VARCHAR(500) NOT NULL,
    Precondicion VARCHAR(800) NOT NULL,
    NumeroEmpleadoPrueba VARCHAR(100) NOT NULL,
    ResultadoEsperado VARCHAR(500) NOT NULL,
    CamposComunes VARCHAR(MAX) NOT NULL,
    CamposRegistro VARCHAR(MAX) NOT NULL,
    DatosRegistro VARCHAR(MAX) NOT NULL
);

INSERT @Inputs
(
    Orden, IdOperacion, Archivo, ParaQueSirve, Precondicion,
    NumeroEmpleadoPrueba, ResultadoEsperado,
    CamposComunes, CamposRegistro, DatosRegistro
)
VALUES
(
    1, 1, '01_ALTA_DEPENDIENTE_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'Agrega un dependiente a un titular existente.',
    'Debe existir activo el titular dummy ' + @N1 + ' en la empresa destino.',
    @N1, 'Se crea un dependiente del titular ' + @N1 + '.',
    'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa) + @CRLF +
        'EMUsuarioUMod=' + CONVERT(VARCHAR(20), @IdUsuario),
    'EMIdSexo,EMNumeroEmpleado,EMApellidoPaterno,EMApellidoMaterno,EMNombre1,EMNombre2,EMFechaNacimiento,EMFechaAntiguedadGMM,EMIdParentesco,EMFechaAlta,EMObservaciones,EMCertificado',
    'F|' + @N1 + '|PRUEBA|DEPENDIENTE|DUMMY|CARGA|15/06/2015|01/01/2024|H|' +
        @HoyTexto + '|QA CARGA B2 BF3 PRUEBA ' + CONVERT(VARCHAR(6), @NumeroPrueba) + '|' + @N1 + '01'
),
(
    2, 2, '02_ALTA_TITULAR_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'Crea un titular nuevo mediante la plantilla configurada.',
    'El numero dummy ' + @N2 + ' no debe existir antes de ejecutar la carga.',
    @N2, 'Se crea un titular nuevo con valores organizacionales tomados de la BD.',
    'EMEmpresa=' + @ClaveEmpresaLegacy + @CRLF +
        'EMUsuarioUMod=' + CONVERT(VARCHAR(20), @IdUsuario),
    'EMNumeroEmpleado,EMPuestoDescripcion,EMNombre1,EMApellidoPaterno,EMApellidoMaterno,EMFechaNacimiento,EMIdSexo,EMFechaIngresoEmpresa,EMIdEstatus,EMFechaBaja,EMFechaEstatus,EMcurp,EMrfc,EMIdTransferido,EMEstadoFisical_text,EMnss,EMPuesto,EMCentroCostos_text,EMOficina_text,EMArea_text,EMArchivoInformacion,EMCorreoElectronico,EMCalleFisico,EMMunicipioDelegacionFiscal,EMJefe,EMEstadoFisico_text,EMColoniaFiscal,EMColoniaFisico,EMMunicipioDelegacionFisico,EMSalarioBase,EMCodigoPostalFisico',
    @N2 + '|' + @Puesto + '|DUMMY|ALTA|TITULAR|20/05/1990|M|' + @HoyTexto +
        '|3||' + @HoyTexto + '|' + @CurpDummy + '|' + @RfcDummy + '|0|' + @Oficina + '|' + RIGHT('00000000000' + @N2, 11) + '|' +
        @Puesto + '|' + @CentroCostos + '|' + @Area + '|' + @Area + '|STAFF' +
        '|qacm.' + CONVERT(VARCHAR(10), @IdEmpresa) + '.p' + CONVERT(VARCHAR(6), @NumeroPrueba) + '@dummy.mx|DOMICILIO DUMMY||0|||0|0|4|0'
),
(
    3, 5, '05_CONCILIACION_AUTOS_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'Concilia un descuento contra una solicitud de autos preparada para QA.',
    'Debe existir la cadena dummy de calendario, solicitud y estado de cuenta para ' + @N7 + '.',
    @N7, 'Se concilian 100.00 en la cadena de autos preparada.',
    'EMEmpresa=' + @ClaveEmpresaLegacy + @CRLF +
        'EMUsuarioUMod=' + CONVERT(VARCHAR(20), @IdUsuario),
    'EMNumeroEmpleado,Quincenaanio,SANumeroRegistroAseguradora,CDMontoConciliacion',
    @N7 + '|' + @Periodo + '|' + @RegistroAutos + '|100.00'
),
(
    4, 13, '13_CAMBIO_NUMERO_EMPLEADO_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'Cambia el numero de un titular existente.',
    'Debe existir ' + @N3 + ' y no debe existir ' + @N4 + '.',
    @N3 + ' -> ' + @N4, 'El titular queda identificado con ' + @N4 + '.',
    'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa) + @CRLF +
        'EMUsuarioUMod=' + CONVERT(VARCHAR(20), @IdUsuario),
    'EMNumeroEmpleado,EMNuevoNumeroEmpleado', @N3 + '|' + @N4
),
(
    5, 14, '14_REACTIVACION_EMPLEADO_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'Reactiva a un titular dado de baja.',
    'Debe existir ' + @N5 + ' inactivo y con fecha de baja.',
    @N5, 'El titular y sus dependientes quedan activos.',
    'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa) + @CRLF +
        'EMUsuarioUMod=' + CONVERT(VARCHAR(20), @IdUsuario),
    'EMNumeroEmpleado,EMFechaReingreso', @N5 + '|' + @HoyTexto
),
(
    6, 15, '15_TRANSFERENCIA_EMPLEADO_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'Transfiere un titular de la empresa origen a la empresa destino.',
    'Debe existir activo ' + @N8 + ' en la empresa ' + CONVERT(VARCHAR(10), @IdEmpresaOrigen) + '.',
    @N8, 'El titular cambia a la empresa ' + CONVERT(VARCHAR(10), @IdEmpresa) + '.',
    'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa) + @CRLF +
        'EMUsuarioUMod=' + CONVERT(VARCHAR(20), @IdUsuario),
    'EMIdEmpresaOrigen,EMNumeroEmpleado,EMIdPerfil,EMSalarioBase,EMCorreoElectronico,EMFecha_solicitud_movimiento,EMSeleccionUsuario,EMObservacionesTransferencia',
    CONVERT(VARCHAR(20), @IdEmpresaOrigen) + '|' + @N8 + '|' +
        CONVERT(VARCHAR(20), @IdPerfilDestino) + '|20000.00|qacm.trans.p' + CONVERT(VARCHAR(6), @NumeroPrueba) + '@dummy.mx|' +
        @HoyTexto + '|0|QA TRANSFERENCIA B2 BF3'
),
(
    7, 16, '16_COMPENSACION_EMPLEADO_' + CONVERT(VARCHAR(10), @IdEmpresa) + '_P' + CONVERT(VARCHAR(6), @NumeroPrueba) + '.txt',
    'Agrega o actualiza una compensacion para un titular activo.',
    'Debe existir activo ' + @N6 + '; el ID de compensacion se obtuvo de la BD.',
    @N6, 'Se registra o actualiza una compensacion de 1500.00.',
    'EMIdEmpresa=' + CONVERT(VARCHAR(20), @IdEmpresa) + @CRLF +
        'EMUsuarioUMod=' + CONVERT(VARCHAR(20), @IdUsuario),
    'EMNumeroEmpleado,CSIdCompensacion,CSMontoCompensacion,EMTipoCargaComp',
    @N6 + '|' + CONVERT(VARCHAR(20), @IdCompensacion) + '|1500.00|1'
);

/* Todos los valores resueltos y su procedencia. */
SELECT *
FROM
(
    SELECT 1 Orden, 'IdEmpresa' Campo, CONVERT(VARCHAR(500), @IdEmpresa) Valor,
           'PARAMETRO VALIDADO EN ff_Empresa' Origen
    UNION ALL SELECT 2, 'NombreEmpresa', CONVERT(VARCHAR(500), @NombreEmpresa), 'ff_Empresa.EMNombre'
    UNION ALL SELECT 3, 'EMEmpresa', @ClaveEmpresaLegacy, 'ff_Empresa.EMIdEmpresaFlexiForbes'
    UNION ALL SELECT 4, 'ClaveUsuario', @ClaveUsuario, 'PARAMETRO VALIDADO EN ff_Administrador'
    UNION ALL SELECT 5, 'EMUsuarioUMod', CONVERT(VARCHAR(500), @IdUsuario), 'ff_Administrador.ADIdAdministrador'
    UNION ALL SELECT 6, 'IdConfiguracion', CONVERT(VARCHAR(500), @IdConfiguracion), 'ff_Empresa.EMIdConfiguracion'
    UNION ALL SELECT 7, 'IdCorporativo', CONVERT(VARCHAR(500), @IdCorporativo), 'ff_Empresa.EMIdCorporativo'
    UNION ALL SELECT 8, 'IdVigencia', CONVERT(VARCHAR(500), @IdVigencia), 'ff_Vigencia activa para la configuracion'
    UNION ALL SELECT 9, 'IdRolDestino', CONVERT(VARCHAR(500), @IdRolDestino), 'ff_Rol default o rol mas usado'
    UNION ALL SELECT 10, 'IdPerfilDestino', CONVERT(VARCHAR(500), @IdPerfilDestino), 'titular real activo de la empresa'
    UNION ALL SELECT 11, 'Area', @Area, 'titular real activo de la empresa'
    UNION ALL SELECT 12, 'Oficina', @Oficina, 'titular real activo de la empresa'
    UNION ALL SELECT 13, 'CentroCostos', @CentroCostos, 'titular real activo de la empresa'
    UNION ALL SELECT 14, 'Puesto', @Puesto, 'titular real activo de la empresa'
    UNION ALL SELECT 15, 'IdCompensacion', CONVERT(VARCHAR(500), @IdCompensacion), @OrigenCompensacion
    UNION ALL SELECT 16, 'NumeroPrueba', CONVERT(VARCHAR(500), @NumeroPrueba), 'PARAMETRO; IDENTIFICA EL LOTE QA'
    UNION ALL SELECT 17, 'NumerosEmpleado', @N1 + ' ... ' + @N8, 'DUMMY RESERVADO, SOLO DIGITOS'
) V
ORDER BY Orden;

/* Input contra configuracion activa, plantilla y SP. */
SELECT
    '02_CATALOGO_INPUTS' AS Bloque,
    I.Orden, I.IdOperacion, CO.CONombre AS TipoCarga,
    CO.CODescripcion AS DescripcionConfigurada,
    CE.CEIdOperacionEmpresa, CE.CEIdPlantilla,
    P.PLDescripcion AS Plantilla, CE.CEStoredProc AS StoredProcedure,
    CE.CEStoredProcAtributos, I.Archivo, I.NumeroEmpleadoPrueba,
    I.ParaQueSirve, I.Precondicion, I.ResultadoEsperado,
    CASE
        WHEN CE.CEIdOperacionEmpresa IS NULL THEN 'FALTA CONFIGURACION ACTIVA PARA LA EMPRESA'
        WHEN OBJECT_ID('dbo.' + CE.CEStoredProc, 'P') IS NULL THEN 'FALTA STORED PROCEDURE'
        WHEN P.PLIdPlantilla IS NULL THEN 'FALTA PLANTILLA'
        ELSE 'OK'
    END AS ResultadoConfiguracion
FROM @Inputs I
LEFT JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
OUTER APPLY
(
    SELECT TOP (1) X.*
    FROM dbo.ff_CargaMasivaOperacionEmpresa X
    WHERE X.CEIdEmpresa = @IdEmpresa
      AND X.CEIdOperacion = I.IdOperacion
      AND X.CEIdEstatus = 1
    ORDER BY X.CEIdOperacionEmpresa DESC
) CE
LEFT JOIN dbo.ff_Plantilla P
    ON P.PLIdPlantilla = CE.CEIdPlantilla AND P.PLIdEstatus = 1
ORDER BY I.Orden;

/* Texto final listo para copiar/pegar o guardar como TXT UTF-8. */
SELECT
    '03_CONTENIDO_TXT_LISTO' AS Bloque,
    I.Orden, I.IdOperacion, CO.CONombre AS TipoCarga,
    I.Archivo, I.NumeroEmpleadoPrueba,
    CAST('@commonFields:' + @CRLF + I.CamposComunes + @CRLF + @CRLF +
         '@fieldNames:' + I.CamposRegistro + @CRLF + '##' + @CRLF +
         '@data:' + @CRLF + I.DatosRegistro AS VARCHAR(MAX)) AS ContenidoTXT
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
ORDER BY I.Orden;

/* Campos y orden reales configurados en cada plantilla. */
SELECT
    '04_CAMPOS_REALES_PLANTILLA' AS Bloque,
    I.Orden, I.IdOperacion, CO.CONombre AS TipoCarga,
    CE.CEIdPlantilla, CP.CPOrden AS OrdenCampo,
    RTRIM(C.CANombreCampo) AS Campo, CP.CPRequerido AS Requerido,
    C.CATipoDato AS TipoDato, C.CALongitud AS Longitud
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
INNER JOIN dbo.ff_CargaMasivaOperacionEmpresa CE
    ON CE.CEIdEmpresa = @IdEmpresa
   AND CE.CEIdOperacion = I.IdOperacion
   AND CE.CEIdEstatus = 1
INNER JOIN dbo.ff_ConfiguracionPlantilla CP
    ON CP.PLIdPlantilla = CE.CEIdPlantilla AND CP.CPIdEstatus = 1
INNER JOIN dbo.ff_Campo C
    ON C.CAIdCampo = CP.CAIdCampo AND C.CAIdEstatus = 1
ORDER BY I.Orden, CP.CPOrden, CP.CPIdConfiguracionPlantilla;

/* Verifica que el numero y orden de valores coincidan con la plantilla BD. */
SELECT
    '05_VALIDACION_ESTRUCTURA_TXT' AS Bloque,
    I.Orden,
    I.IdOperacion,
    CO.CONombre AS TipoCarga,
    1 + LEN(I.CamposRegistro) - LEN(REPLACE(I.CamposRegistro, ',', '')) AS CamposTXT,
    1 + LEN(I.DatosRegistro) - LEN(REPLACE(I.DatosRegistro, '|', '')) AS ValoresTXT,
    X.CamposRegistroPlantilla,
    CASE
      WHEN 1 + LEN(I.CamposRegistro) - LEN(REPLACE(I.CamposRegistro, ',', ''))
         = 1 + LEN(I.DatosRegistro) - LEN(REPLACE(I.DatosRegistro, '|', ''))
       AND 1 + LEN(I.CamposRegistro) - LEN(REPLACE(I.CamposRegistro, ',', ''))
         = X.CamposRegistroPlantilla
      THEN 'OK'
      ELSE 'REVISAR CANTIDAD/ORDEN DE CAMPOS'
    END AS Resultado
FROM @Inputs I
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = I.IdOperacion
OUTER APPLY
(
    SELECT COUNT(*) AS CamposRegistroPlantilla
    FROM dbo.ff_CargaMasivaOperacionEmpresa CE
    INNER JOIN dbo.ff_ConfiguracionPlantilla CP
        ON CP.PLIdPlantilla = CE.CEIdPlantilla AND CP.CPIdEstatus = 1
    INNER JOIN dbo.ff_Campo C
        ON C.CAIdCampo = CP.CAIdCampo AND C.CAIdEstatus = 1
    WHERE CE.CEIdEmpresa = @IdEmpresa
      AND CE.CEIdOperacion = I.IdOperacion
      AND CE.CEIdEstatus = 1
      AND UPPER(LTRIM(RTRIM(C.CANombreCampo))) NOT IN
          ('EMIDEMPRESA', 'EMEMPRESA', 'EMUSUARIOADD', 'EMUSUARIOUMOD')
) X
ORDER BY I.Orden;

/* Estado de los dummies antes de probar. */
SELECT
    '06_ESTADO_PRECONDICIONES' AS Bloque,
    I.IdOperacion, I.NumeroEmpleadoPrueba, I.Precondicion,
    CASE I.IdOperacion
      WHEN 1 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N1 AND E.EMIdEstatus = 1
           AND E.EMIdParentesco = 1) THEN 'LISTO' ELSE 'FALTA PREPARAR' END
      WHEN 2 THEN CASE WHEN NOT EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N2) THEN 'LISTO PARA ALTA' ELSE 'YA EXISTE: RESTABLECER PRUEBA' END
      WHEN 5 THEN CASE WHEN EXISTS
          (SELECT 1
           FROM dbo.ff_Empleado E
           INNER JOIN dbo.fb_SolicitudAutos S
               ON S.SAIdEmpleadoTitular = E.Id
              AND S.SANumeroRegistroAseguradora = @RegistroAutos
           INNER JOIN dbo.fb_EdoCuentaAutos EC ON EC.ECIdSolicitud = S.SAIdSolicitudAutos
           INNER JOIN dbo.fb_EdoCuentaDesglose D ON D.ECIdEdoCuentaAutos = EC.ECIdEdoCuentaAutos
           INNER JOIN dbo.fb_CalendarioIngresoNomina CN
               ON CN.CNIdCalendarioIngresoNomina = D.ECIdCalendarioIngresoNomina
              AND CN.CNQuincenaAnioCalendario = @Periodo
           WHERE E.EMIdEmpresa = @IdEmpresa AND E.EMNumeroEmpleado = @N7)
          THEN 'LISTO' ELSE 'FALTA PREPARAR CADENA AUTOS' END
      WHEN 13 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N3) AND NOT EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N4) THEN 'LISTO' ELSE 'FALTA PREPARAR/RESTABLECER' END
      WHEN 14 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N5 AND E.EMIdEstatus <> 1) THEN 'LISTO' ELSE 'FALTA PREPARAR' END
      WHEN 15 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresaOrigen
           AND E.EMNumeroEmpleado = @N8 AND E.EMIdEstatus = 1) THEN 'LISTO' ELSE 'FALTA PREPARAR' END
      WHEN 16 THEN CASE WHEN EXISTS
          (SELECT 1 FROM dbo.ff_Empleado E WHERE E.EMIdEmpresa = @IdEmpresa
           AND E.EMNumeroEmpleado = @N6 AND E.EMIdEstatus = 1) THEN 'LISTO' ELSE 'FALTA PREPARAR' END
    END AS Estado
FROM @Inputs I
ORDER BY I.Orden;

/* Operaciones futuras/extra que aun no tengan un input preparado. */
SELECT
    '07_OPERACIONES_ACTIVAS_SIN_INPUT' AS Bloque,
    CE.CEIdOperacion, CO.CONombre AS TipoCarga,
    CE.CEIdPlantilla, CE.CEStoredProc
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
INNER JOIN dbo.ff_CargaMasivaOperacion CO ON CO.COIdOperacion = CE.CEIdOperacion
WHERE CE.CEIdEmpresa = @IdEmpresa
  AND CE.CEIdEstatus = 1
  AND NOT EXISTS (SELECT 1 FROM @Inputs I WHERE I.IdOperacion = CE.CEIdOperacion)
ORDER BY CE.CEIdOperacion;

SELECT
    '08_RESUMEN' AS Bloque,
    @IdEmpresa AS IdEmpresa, @NombreEmpresa AS Empresa,
    @NumeroPrueba AS NumeroPrueba,
    @ClaveUsuario AS Usuario, @IdUsuario AS IdUsuarioAuditoria,
    @ClaveEmpresaLegacy AS EMEmpresa,
    (SELECT COUNT(*) FROM dbo.ff_CargaMasivaOperacionEmpresa
     WHERE CEIdEmpresa = @IdEmpresa AND CEIdEstatus = 1) AS OperacionesActivasBD,
    (SELECT COUNT(*) FROM @Inputs) AS InputsPreparados,
    CASE WHEN NOT EXISTS
    (
        SELECT 1 FROM dbo.ff_CargaMasivaOperacionEmpresa CE
        WHERE CE.CEIdEmpresa = @IdEmpresa AND CE.CEIdEstatus = 1
          AND NOT EXISTS (SELECT 1 FROM @Inputs I WHERE I.IdOperacion = CE.CEIdOperacion)
    ) THEN 'OK: TODAS LAS OPERACIONES ACTIVAS TIENEN INPUT TXT'
      ELSE 'REVISAR: EXISTEN OPERACIONES ACTIVAS SIN INPUT' END AS Resultado;
GO
