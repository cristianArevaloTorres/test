# Inputs TXT parametrizables para Carga Masiva B2 desde BF3

## Qué cambió

Los scripts ya no dejan fijos datos que deben existir en la base. En la parte
superior únicamente se capturan:

```sql
DECLARE @IdEmpresa       INT         = 186;
DECLARE @ClaveUsuario    VARCHAR(50) = 'jvazquez';
DECLARE @IdEmpresaOrigen INT         = 187;
DECLARE @NumeroPrueba    INT         = 1;
```

`@NumeroPrueba` puede cambiarse de `1` hasta `999999`. Cada valor genera un
lote independiente. Por ejemplo:

- Prueba 1: `18600000101` a `18600000108`.
- Prueba 2: `18600000201` a `18600000208`.
- Prueba 25: `18600002501` a `18600002508`.

El periodo, CIS, serie, correo, RFC y CURP dummy también incluyen el número de
prueba, por lo que dos lotes preparados no se pisan entre sí. Reutilizar el
mismo número restablece únicamente ese lote.

Para la empresa 186, `EMEmpresa=S001` se obtiene automáticamente de
`ff_Empresa.EMIdEmpresaFlexiForbes`. El identificador que se coloca en
`EMUsuarioUMod` se obtiene de `ff_Administrador.ADIdAdministrador` buscando la
clave `jvazquez`.

También se consultan en la base el rol default, perfil, vigencia, corporativo,
área, oficina y centro de costos. En el alta Deloitte se envían las
descripciones reales de los catálogos `area`, `oficina` y `CECO`, que es lo que
busca el stored procedure; no se envían sus IDs internos.

Los números de empleado reservados, nombres, RFC, CURP, correo y observaciones
sí son dummy. Para la empresa 186 se utilizan `186990001` a `186990008`.

## Orden de ejecución

1. Abra `PREPARAR_DUMMIES_ARCHIVOS_CARGA_186.sql`.
2. Revise los tres parámetros y ejecute el script. Este paso sí modifica la BD
   y deja preparadas las precondiciones de prueba.
3. Abra `GENERAR_INPUTS_TXT_CARGA_MASIVA_EMPRESA_186.sql` con los mismos tres
   parámetros.
4. Ejecútelo y revise primero `05_VALIDACION_ESTRUCTURA_TXT`: las siete filas
   deben decir `OK`.
5. Revise `06_ESTADO_PRECONDICIONES`: todos los casos deben decir `LISTO`, salvo
   el alta de titular, que debe decir `LISTO PARA ALTA`.
6. Copie la celda `ContenidoTXT` del bloque `03_CONTENIDO_TXT_LISTO` y péguela
   en el editor TXT de BF3 o guárdela como archivo UTF-8.
7. Después de ejecutar cada carga, abra
   `COMPROBAR_RESULTADOS_CARGA_MASIVA_POR_PRUEBA.sql`, coloque el mismo
   `@NumeroPrueba` y revise `01_RESUMEN_REGLAS_NEGOCIO`.

## Comprobación de resultados

El comprobador es de solo lectura y valida una regla concreta por operación:

- Alta de dependiente: existe el dependiente activo y su certificado.
- Alta de titular: existe exactamente un titular con el número nuevo.
- Conciliación: existe el descuento activo por `100.00`, periodo y CIS.
- Cambio de número: desapareció el número anterior y existe el nuevo.
- Reactivación: el titular quedó activo y sin fecha de baja.
- Transferencia: el titular está en destino, no está en origen y existe el log.
- Compensación: existe activa por `1500.00` para el empleado e ID esperado.

Antes de ejecutar un TXT, su operación aparecerá como `PENDIENTE/REVISAR`.
Después de procesarlo correctamente debe cambiar a `OK`. El bloque
`09_RESUMEN_FINAL` debe terminar con `PruebasOK=7` y `TotalPruebas=7` cuando se
hayan ejecutado las siete cargas del lote.

## Qué valor es real y cuál es dummy

El primer resultado del generador enumera cada valor y su origen. En general:

- `EMEmpresa`, usuario de auditoría, rol, perfil, vigencia, área, oficina,
  centro de costos y corporativo: datos reales consultados en BD.
- Números `...990001` a `...990008`, datos personales, correo y observaciones:
  datos dummy reservados para QA.
- `CSIdCompensacion`: usa primero un movimiento/configuración real. Si no
  existe, usa `900001` como dummy porque
  `ff_CargaMasivaCompensacionEmpleado` no valida ese ID contra un catálogo.

La versión anterior con datos fijos se conservó únicamente como referencia en
`GENERAR_INPUTS_TXT_CARGA_MASIVA_EMPRESA_186_VERSION_FIJA_ANTERIOR.sql`; no debe
usarse para generar pruebas nuevas.
