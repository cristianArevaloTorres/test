import { Component, OnInit } from '@angular/core';
import { MenusService } from 'src/app/services/menus.service';
import { GLOBAL } from '../../../../services/global';
import { EmpleadoService } from '../../../../services/empleado.service';

@Component({
  selector: 'app-defaulteo-titulares',
  templateUrl: './defaulteo-titulares.component.html',
  styleUrls: ['./defaulteo-titulares.component.css']
})
export class DefaulteoTitularesComponent implements OnInit {

  public title: string;
  public banner;
  public urlWs;
  public identity;

  public id;
  public iconoAyuda;
  public textAyuda;

  constructor(
    private _menuService: MenusService,
    private _empleadoService: EmpleadoService
  ) {
    this.title = 'Defaulteo de solicitudes';
    this.urlWs = GLOBAL.url2;
  }

  ngOnInit() {
    this.banner = this._menuService.getbackground();
    this.identity = this._empleadoService.getIdentity();
    this.menuId();
  }

  menuId() {
    const informacion = JSON.parse(localStorage.getItem('MenuPadre'));
    if (informacion !== 'undefined') {
      this.id = informacion;
    } else {
      this.id = null;
    }
  }
}
