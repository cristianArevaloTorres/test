import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { EmpleadoService } from 'src/app/services/empleado.service';
import { DefaulteoAvanzadoService } from 'src/app/services/defaulteo-avanzado.service';
import { Subscription, interval, of } from 'rxjs';
import { startWith, switchMap, catchError } from 'rxjs/operators';
import swal from 'sweetalert2';

/**
 * Pantalla de defaulteo avanzado (Mejora-006).
 * Coexiste con la pantalla basica actual via toggle en ReporteDefaulteoComponent.
 *
 * Filtros poblados desde catalogos existentes para evitar que el admin tenga
 * que conocer IDs internos. Campos editables del Anexo: Nombre/Apellidos/Edad.
 */
@Component({
  selector: 'app-defaulteo-avanzado',
  templateUrl: './defaulteo-avanzado.component.html',
  styleUrls: ['./defaulteo-avanzado.component.css']
})
export class DefaulteoAvanzadoComponent implements OnInit, OnDestroy {

  /** Clave de localStorage para reanudar el polling tras un reload. */
  private static readonly LS_LOTE_ACTIVO = 'crea06_defaulteo_lote_activo';
  /** Cada cuanto consultamos el estado del lote (ms). */
  private static readonly POLL_MS = 3000;
  /** Polls seguidos con error de red antes de rendirse. */
  private static readonly MAX_ERRORES_POLL = 5;

  identity: any;
  token: string;
  idAdmin: number;
  idCorporativo: number;

  // Catalogos cargados desde backend
  catEmpresas:    any[] = [];
  catPerfiles:    any[] = [];
  catOficinas:    any[] = [];
  catPlanes:      any[] = [];
  catCoberturas:  any[] = [];
  catVigencias:   any[] = [];
  catSexos:       any[] = [];
  catParentescos: any[] = [];
  catTiposAsignacion: any[] = [];

  cargandoCatalogos = false;

  // Filtros (15 campos del documento + Anexo)
  filtros = this.filtrosVacios();

  // Acciones (RN004)
  acciones: any = {
    idPlanDestino: null,
    idCoberturaDestino: null,
    tipoAsignacionPlanes: null,
    // RF001.2 - Regla Scotiabank antiguedad plan de retiro (opt-in)
    aplicarReglaAntiguedad: false,
    mesesAntiguedadMinimos: 6
  };

  // Configuraciones guardadas
  configuraciones: any[] = [];
  configuracionSeleccionada: any = null;
  nombreNuevaConfig = '';
  descripcionNuevaConfig = '';

  // Resultados de busqueda
  empleados: any[] = [];
  seleccion = new Set<number>();
  buscando = false;

  // Resultados ejecucion
  ejecutando = false;
  ultimoResultado: any = null;

  // Estado del lote en curso (polling en background)
  idLogActivo: number | null = null;
  progreso: any = null;             // { estado, totalEmpleados, procesados, totalExitosos, totalErrores }
  private pollSub: Subscription | null = null;
  private erroresPoll = 0;

  constructor(
    private empleadoService: EmpleadoService,
    private service: DefaulteoAvanzadoService
  ) {}

  ngOnInit(): void {
    this.identity = this.empleadoService.getIdentity();
    if (this.identity) {
      this.idAdmin       = this.identity.id || this.identity.ADIdAdministrador
        || this.identity.EMid || this.identity.idEmpleado;
      this.idCorporativo = this.identity.idCorporativo || this.identity.EMidCorporativo;
    }
    this.token = this.empleadoService.getToken() || '';
    this.cargarConfiguraciones();
    this.cargarCatalogosIniciales();
    this.reanudarLoteActivo();
  }

  ngOnDestroy(): void {
    // Solo dejamos de observar; el lote sigue corriendo en el servidor.
    this.detenerPolling();
  }

  /** Mientras corre un lote, avisa si el usuario intenta cerrar/recargar la pestania. */
  @HostListener('window:beforeunload', ['$event'])
  avisarSiEnProceso(e: BeforeUnloadEvent): void {
    if (this.ejecutando) {
      e.preventDefault();
      e.returnValue = 'Hay un defaulteo en proceso. El lote seguira en el servidor aunque salgas.';
    }
  }

  /** Bloquea toda la pantalla mientras hay un lote corriendo (tema: no modificar nada en proceso). */
  get bloqueado(): boolean {
    return this.ejecutando;
  }

  /** % de avance para la barra de progreso (0-100). */
  get porcentajeProgreso(): number {
    const p = this.progreso;
    if (!p || !p.totalEmpleados) { return 0; }
    const pct = Math.floor(((p.procesados || 0) / p.totalEmpleados) * 100);
    return Math.max(0, Math.min(100, pct));
  }

  // -----------------------------------------------------------------------
  // Catalogos
  // -----------------------------------------------------------------------
  private cargarCatalogosIniciales(): void {
    if (!this.idCorporativo || !this.idAdmin) return;
    this.cargandoCatalogos = true;

    this.service.getEmpresas(this.idCorporativo, this.idAdmin, this.token).subscribe(
      (r: any) => { this.catEmpresas = this.aplanar(r); this.cargandoCatalogos = false; },
      ()        => { this.catEmpresas = []; this.cargandoCatalogos = false; }
    );

    this.service.getSexos(this.token).subscribe(
      (r: any) => this.catSexos = this.aplanar(r),
      ()        => this.catSexos = [
        { idSexo: 1, descripcion: 'Masculino' },
        { idSexo: 2, descripcion: 'Femenino' }
      ]
    );

    const tiposRespaldo = [
      { TDIdTipoDefaulteo: 1, Nombre: 'Tipo 1' },
      { TDIdTipoDefaulteo: 2, Nombre: 'Tipo 2' },
      { TDIdTipoDefaulteo: 3, Nombre: 'Tipo 3' }
    ];
    this.service.getTiposAsignacion(this.token).subscribe(
      (r: any) => {
        const tipos = this.aplanar(r)
          .filter(t => this.idTipoAsignacion(t) >= 1 && this.idTipoAsignacion(t) <= 3);
        this.catTiposAsignacion = tipos.length ? tipos : tiposRespaldo;
      },
      () => this.catTiposAsignacion = tiposRespaldo
    );
  }

  /** Cuando cambia la seleccion de empresas, recargar perfiles/oficinas/planes/vigencias
   *  UNIENDO los catalogos de TODAS las empresas seleccionadas (deduplicado por id). */
  onEmpresasChange(): void {
    const idsEmp = (this.filtros.idsEmpresa as number[]) || [];
    if (idsEmp.length === 0) {
      this.catPerfiles = []; this.catOficinas = []; this.catPlanes = [];
      this.catCoberturas = []; this.catVigencias = [];
      return;
    }

    this.catPerfiles = []; this.catOficinas = []; this.catPlanes = []; this.catVigencias = [];

    const dedup = (arr: any[], idFn: (x: any) => any) => {
      const seen = new Set<any>();
      return arr.filter(x => { const k = idFn(x); if (seen.has(k)) return false; seen.add(k); return true; });
    };

    idsEmp.forEach(idEmpresa => {
      const eid = Number(idEmpresa);

      this.service.getPerfiles(eid, this.token).subscribe(
        (r: any) => this.catPerfiles = dedup([...this.catPerfiles, ...this.aplanar(r)], (p: any) => this.idPerfil(p)),
        () => {}
      );
      this.service.getOficinas(eid, this.idAdmin, this.token).subscribe(
        (r: any) => this.catOficinas = dedup([...this.catOficinas, ...this.aplanar(r)], (o: any) => this.idOficina(o)),
        () => {}
      );
      this.service.getPlanes(eid, this.token).subscribe(
        (r: any) => this.catPlanes = dedup([...this.catPlanes, ...this.aplanar(r)], (p: any) => this.idPlan(p)),
        () => {}
      );
      this.service.getVigencias(eid, this.token).subscribe(
        (r: any) => this.catVigencias = dedup([...this.catVigencias, ...this.aplanar(r)], (v: any) => this.idVigencia(v)),
        () => {}
      );
    });
  }

  /** No-op: parentesco no se filtra desde UI (defaulteo solo aplica a titulares). */
  onPerfilesChange(): void { /* reservado para futura logica de cascada */ }

  onVigenciaChange(): void {
    this.acciones.idCoberturaDestino = null;
    this.cargarCoberturasAccion();
  }

  onPlanAccionChange(): void {
    this.acciones.idCoberturaDestino = null;
    this.cargarCoberturasAccion();
  }

  private cargarCoberturasAccion(): void {
    const idPlan = Number(this.acciones.idPlanDestino);
    const idVigencia = Number(this.filtros.idVigencia);
    if (!idPlan || !idVigencia) {
      this.catCoberturas = [];
      return;
    }
    this.service.getCoberturas(idPlan, idVigencia, this.token).subscribe(
      (r: any) => this.catCoberturas = this.aplanar(r),
      () => this.catCoberturas = []
    );
  }

  // -----------------------------------------------------------------------
  // Configuraciones guardadas
  // -----------------------------------------------------------------------
  cargarConfiguraciones(): void {
    this.service.listarConfiguraciones(this.token, this.idCorporativo, null, this.idAdmin).subscribe(
      (r: any) => { this.configuraciones = Array.isArray(r) ? this.aplanar(r) : []; },
      ()        => { this.configuraciones = []; }
    );
  }

  aplicarConfiguracion(c: any): void {
    if (!c) return;
    try {
      if (c.filtrosJson) {
        const parsed = JSON.parse(c.filtrosJson);
        this.filtros = { ...this.filtrosVacios(), ...parsed };
        this.onEmpresasChange();
      }
      if (c.accionesJson) {
        const guardadas = JSON.parse(c.accionesJson);
        this.acciones = {
          ...this.acciones,
          idPlanDestino: guardadas.idPlanDestino || null,
          idCoberturaDestino: guardadas.idCoberturaDestino || null,
          tipoAsignacionPlanes: guardadas.tipoAsignacionPlanes || null,
          aplicarReglaAntiguedad: Boolean(guardadas.aplicarReglaAntiguedad),
          mesesAntiguedadMinimos: guardadas.mesesAntiguedadMinimos || 6
        };
        this.cargarCoberturasAccion();
      }
      swal('Configuracion cargada', c.nombre, 'success');
    } catch (e) {
      swal('Error', 'JSON de configuracion invalido', 'error');
    }
  }

  guardarConfiguracion(): void {
    if (!this.nombreNuevaConfig) {
      swal('Falta nombre', 'Indica un nombre para la configuracion', 'warning');
      return;
    }
    const body = {
      id: null,
      nombre: this.nombreNuevaConfig,
      descripcion: this.descripcionNuevaConfig,
      idCorporativo: this.idCorporativo,
      idEmpresa: null,
      idAdmin: this.idAdmin,
      filtrosJson: JSON.stringify(this.filtros),
      accionesJson: JSON.stringify(this.acciones)
    };
    this.service.guardarConfiguracion(body, this.token).subscribe(
      (r: any) => {
        if (r && r.exito === false) {
          swal('Error', r.mensaje || 'No se pudo guardar', 'error');
          return;
        }
        swal('Guardado', 'Configuracion guardada (id ' + (r && r.id) + ')', 'success');
        this.nombreNuevaConfig = '';
        this.descripcionNuevaConfig = '';
        this.cargarConfiguraciones();
      },
      err => swal('Error', err.message || 'No se pudo guardar', 'error')
    );
  }

  eliminarConfiguracion(c: any): void {
    if (!c || !c.id) return;
    swal({
      title: 'Eliminar configuracion?',
      text: c.nombre,
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Eliminar'
    }).then(res => {
      if (!res || !res.value) return;
      this.service.eliminarConfiguracion(c.id, this.idAdmin, this.token).subscribe(
        () => { this.cargarConfiguraciones(); swal('Eliminada', '', 'success'); },
        err => swal('Error', err.message || 'No se pudo eliminar', 'error')
      );
    });
  }

  // -----------------------------------------------------------------------
  // Limpiar filtros (mantiene vigencia y empresa seleccionada)
  // -----------------------------------------------------------------------
  limpiarFiltros(): void {
    const vig = this.filtros.idVigencia;
    const emp = this.filtros.idsEmpresa;
    this.filtros = this.filtrosVacios();
    this.filtros.idVigencia = vig;
    this.filtros.idsEmpresa = emp;
    this.empleados = [];
    this.seleccion.clear();
    this.ultimoResultado = null;
  }

  // -----------------------------------------------------------------------
  // Busqueda
  // -----------------------------------------------------------------------
  buscar(): void {
    if (!this.idCorporativo) {
      swal('Faltan datos', 'No se detecto corporativo en la sesion', 'warning');
      return;
    }
    if (!this.filtros.idVigencia) {
      swal('Faltan datos', 'Selecciona una vigencia', 'warning');
      return;
    }
    if (!Array.isArray(this.filtros.idsEmpresa) || this.filtros.idsEmpresa.length === 0) {
      swal('Faltan datos', 'Selecciona al menos una empresa asignada.', 'warning');
      return;
    }
    // Convertir numeros de empleado (textarea) a array
    if (typeof this.filtros.numerosEmpleadoTexto === 'string' && this.filtros.numerosEmpleadoTexto.trim().length > 0) {
      this.filtros.numerosEmpleado = this.filtros.numerosEmpleadoTexto
        .split(/[,\n\r;]+/).map((s: string) => s.trim()).filter((s: string) => s.length > 0);

      // Aviso si los valores parecen ser placeholders (test, prueba, ejemplo)
      const sospechosos = this.filtros.numerosEmpleado.filter((s: string) =>
        /^(test|prueba|ejemplo|demo)$/i.test(s));
      if (sospechosos.length > 0) {
        const ok = window.confirm(
          'Detecte un numero de empleado sospechoso: "' + sospechosos.join(', ') + '".\n' +
          'Esto puede no encontrar resultados.\n\n' +
          '¿Quieres continuar la busqueda? (Cancela para revisar el filtro)');
        if (!ok) { this.buscando = false; return; }
      }
    } else {
      this.filtros.numerosEmpleado = null;
    }

    this.buscando = true;
    this.seleccion.clear();
    this.filtros.idCorporativo = this.idCorporativo;

    // Normalizar: arrays vacios -> null (sino el SP los toma como "sin filtro" igual,
    // pero conviene enviar payload limpio y consistente con el modelo Java)
    const v = (a: any) => Array.isArray(a) && a.length === 0 ? null : a;
    this.filtros.idsEmpresa     = v(this.filtros.idsEmpresa);
    this.filtros.idsPerfil      = v(this.filtros.idsPerfil);
    this.filtros.idsOficina     = v(this.filtros.idsOficina);
    this.filtros.idsSexo        = v(this.filtros.idsSexo);
    this.filtros.idsParentesco  = null; // ya no se filtra desde UI, SP exige titulares (parentesco=1)
    this.filtros.idsPlan        = v(this.filtros.idsPlan);

    try {
      this.filtros.idsArea      = this.normalizarListaIds(this.filtros.idsArea, 'Área');
      this.filtros.idsCobertura = this.normalizarListaIds(this.filtros.idsCobertura, 'Cobertura');
    } catch (e) {
      this.buscando = false;
      swal('Filtro inválido', e.message, 'warning');
      return;
    }

    this.service.buscar(this.filtros, this.token).subscribe(
      (r: any) => {
        this.empleados = this.aplanar(r);
        this.buscando = false;
      },
      err => {
        this.buscando = false;
        this.empleados = [];
        swal('Error', 'No se pudo realizar la busqueda', 'error');
      }
    );
  }

  // -----------------------------------------------------------------------
  // Seleccion
  // -----------------------------------------------------------------------
  toggleSeleccion(idEmpleado: number): void {
    if (this.seleccion.has(idEmpleado)) this.seleccion.delete(idEmpleado);
    else this.seleccion.add(idEmpleado);
  }

  toggleTodos(checked: boolean): void {
    this.seleccion.clear();
    if (checked) this.empleados.forEach(e => this.seleccion.add(e.idEmpleado));
  }

  estaSeleccionado(idEmpleado: number): boolean {
    return this.seleccion.has(idEmpleado);
  }

  // -----------------------------------------------------------------------
  // Ejecucion
  // -----------------------------------------------------------------------
  ejecutar(): void {
    if (this.seleccion.size === 0) {
      swal('Selecciona empleados', 'No hay empleados seleccionados', 'warning');
      return;
    }
    swal({
      title: 'Ejecutar defaulteo?',
      text: 'Se procesaran ' + this.seleccion.size + ' empleados. Esta accion queda registrada en bitacora.',
      type: 'question',
      showCancelButton: true,
      confirmButtonText: 'Ejecutar'
    }).then(res => {
      if (!res || !res.value) return;

      const seleccionados = this.empleados.filter(e => this.seleccion.has(e.idEmpleado));
      const ids  = seleccionados.map(e => e.idEmpleado);
      const nums = seleccionados.map(e => e.numeroEmpleado);

      // Empresa principal de los seleccionados (para auditar el lote)
      const idsEmp = this.filtros.idsEmpresa as number[];
      // Si el lote abarca varias empresas, la empresa se conserva por empleado.
      const idEmpresa = idsEmp && idsEmp.length === 1 ? Number(idsEmp[0]) : null;

      const req = {
        idCorporativo: this.idCorporativo,
        idEmpresa: idEmpresa,
        idVigencia: this.filtros.idVigencia,
        idAdmin: this.idAdmin,
        idEmpleado: ids,
        numEmpleado: nums,
        filtros: this.filtros,
        acciones: this.acciones
      };

      this.ejecutando = true;
      this.ultimoResultado = null;
      this.progreso = { estado: 'EN_PROCESO', totalEmpleados: ids.length, procesados: 0, totalExitosos: 0, totalErrores: 0 };

      // El backend ahora arranca el lote en background y responde de inmediato con idLog.
      this.service.ejecutar(req, this.token).subscribe(
        r => {
          if (!r || !r.idLog) {
            this.ejecutando = false;
            this.progreso = null;
            swal('Error', 'El servidor no devolvio el folio del lote', 'error');
            return;
          }
          this.idLogActivo = r.idLog;
          this.progreso = { ...this.progreso, ...r };
          localStorage.setItem(
            DefaulteoAvanzadoComponent.LS_LOTE_ACTIVO,
            JSON.stringify({ idLog: r.idLog, total: ids.length })
          );
          this.iniciarPolling(r.idLog);
        },
        err => {
          this.ejecutando = false;
          this.progreso = null;
          swal('Error', (err && err.message) || 'No se pudo iniciar el defaulteo', 'error');
        }
      );
    });
  }

  // -----------------------------------------------------------------------
  // Polling del estado del lote (corre en background en el servidor)
  // -----------------------------------------------------------------------
  private iniciarPolling(idLog: number): void {
    this.detenerPolling();
    this.erroresPoll = 0;
    this.pollSub = interval(DefaulteoAvanzadoComponent.POLL_MS).pipe(
      startWith(0),
      switchMap(() => this.service.consultarEstado(idLog, this.token).pipe(
        catchError(() => of(null))   // un error de red no rompe el polling
      ))
    ).subscribe((est: any) => {
      if (!est) {
        // Error transitorio de red: toleramos algunos y luego nos rendimos
        if (++this.erroresPoll >= DefaulteoAvanzadoComponent.MAX_ERRORES_POLL) {
          this.detenerPolling();
          this.ejecutando = false;
          swal('Sin conexion con el proceso',
               'No se pudo consultar el estado del lote (folio ' + idLog + '). '
               + 'El proceso puede seguir en el servidor; vuelve a entrar para reconectar.',
               'warning');
        }
        return;
      }
      this.erroresPoll = 0;
      this.progreso = est;

      if (est.estado && est.estado !== 'EN_PROCESO') {
        this.finalizarProceso(est);
      }
    });
  }

  private detenerPolling(): void {
    if (this.pollSub) {
      this.pollSub.unsubscribe();
      this.pollSub = null;
    }
  }

  private finalizarProceso(est: any): void {
    this.detenerPolling();
    this.ejecutando = false;
    this.idLogActivo = null;
    localStorage.removeItem(DefaulteoAvanzadoComponent.LS_LOTE_ACTIVO);

    this.ultimoResultado = {
      idLog:          est.idLog,
      totalEmpleados: est.totalEmpleados,
      totalExitosos:  est.totalExitosos,
      totalErrores:   est.totalErrores
    };

    if (est.estado === 'ERROR') {
      swal('El proceso fallo',
           'El lote (folio ' + est.idLog + ') termino con un error. Revisa el log de errores.',
           'error');
      return;
    }

    const errs = est.totalErrores || 0;
    swal(
      'Defaulteo finalizado',
      (est.totalExitosos || 0) + ' OK / ' + errs + ' con error',
      errs > 0 ? 'warning' : 'success'
    );

    // La lista representa trabajo pendiente. Al terminar se consulta de nuevo
    // para que las solicitudes Activas/Por Autorizar ya no permanezcan visibles
    // y los empleados con error sigan disponibles para reproceso.
    this.buscar();
  }

  /** Tras un reload, si habia un lote activo se reconecta al polling (resuelve "no se si sigue corriendo"). */
  private reanudarLoteActivo(): void {
    const raw = localStorage.getItem(DefaulteoAvanzadoComponent.LS_LOTE_ACTIVO);
    if (!raw) { return; }
    try {
      const info = JSON.parse(raw);
      if (info && info.idLog) {
        this.ejecutando = true;
        this.idLogActivo = info.idLog;
        this.progreso = { estado: 'EN_PROCESO', totalEmpleados: info.total || 0, procesados: 0, totalExitosos: 0, totalErrores: 0 };
        this.iniciarPolling(info.idLog);
      }
    } catch (e) {
      localStorage.removeItem(DefaulteoAvanzadoComponent.LS_LOTE_ACTIVO);
    }
  }

  descargarLogErrores(): void {
    if (!this.ultimoResultado || !this.ultimoResultado.idLog) return;
    const idLog = this.ultimoResultado.idLog;
    this.service.descargarLogErrores(idLog, this.token).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'defaulteo_log_errores_' + idLog + '.csv';
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  // -----------------------------------------------------------------------
  // Helpers
  // -----------------------------------------------------------------------
  private filtrosVacios(): any {
    return {
      idCorporativo: null,
      idVigencia: null,
      idsEmpresa: [], idsPerfil: [], idsOficina: [], idsArea: null,
      idsSexo: [], idsParentesco: [], idsPlan: [], idsCobertura: null,
      numerosEmpleado: null,
      numerosEmpleadoTexto: '',
      salarioMin: null, salarioMax: null, sumaAseguradaMin: null, sumaAseguradaMax: null,
      fechaIngresoIni: null, fechaIngresoFin: null,
      fechaAntiguedadIni: null, fechaAntiguedadFin: null,
      fechaNacimientoIni: null, fechaNacimientoFin: null,
      fechaVigenciaIni: null, fechaVigenciaFin: null,
      nombre: null, apellidoPaterno: null, apellidoMaterno: null,
      edadMin: null, edadMax: null,
      top: 1000
    };
  }

  private aplanar(res: any): any[] {
    if (Array.isArray(res)) {
      if (res.length === 0) return [];
      if (Array.isArray(res[0])) return res[0];
      return res;
    }
    if (res && typeof res === 'object') {
      for (const k of Object.keys(res)) {
        if (Array.isArray(res[k])) return res[k];
      }
    }
    return [];
  }

  private normalizarListaIds(valor: any, etiqueta: string): number[] | null {
    if (valor == null || valor === '') return null;
    const partes = Array.isArray(valor) ? valor : String(valor).split(/[,;\s]+/);
    const ids = partes
      .filter(v => v !== null && v !== undefined && String(v).trim() !== '')
      .map(v => Number(v));
    if (ids.some(id => !Number.isInteger(id) || id <= 0)) {
      throw new Error(`${etiqueta} solo admite IDs enteros positivos separados por coma.`);
    }
    return ids.length ? Array.from(new Set(ids)) : null;
  }

  // Helpers para mostrar etiquetas amigables en los dropdowns.
  // Shapes confirmados con los endpoints existentes:
  //   empresas    (preview-BeMobile/empresas)   -> { IdEmpresa, clave }
  //   perfiles    (perfil/empresa/:id)          -> { PEIdPerfil, PENombre }
  //   oficinas    (preview-BeMobile/oficinas)   -> { TEIdDetalle, TEDescripcion }
  //   planes      (preview-BeMobile/planes)     -> { PLidPlan, PLDescripcion }
  //   vigencias   (sabana/getVigenciasXEmpresa) -> { VIidVigencia, VINombre }
  //   sexos       (general/sexo)                -> { idSexo, descripcion }
  //   parentescos (parentesco/empresa/X/perfil/Y) -> { idParentesco, descripcion }
  labelEmpresa(e: any): string {
    const nombre = e.clave || e.NomEmpresa || e.EMRazonSocial || e.RazonSocial || e.razonSocial || e.nombre;
    const id = this.idEmpresa(e);
    if (!nombre) return 'Empresa ' + id;
    // Mostrar id para distinguir empresas con el mismo nombre
    return nombre + ' (id ' + id + ')';
  }
  idEmpresa(e: any): number { return e.IdEmpresa || e.id || e.EMidEmpresa || e.idEmpresa; }

  labelPerfil(p: any): string { return p.nombrePerfil || p.PENombre || p.PEDescripcion || p.descripcion || p.nombre || ('Perfil ' + (p.idPerfil || p.PEIdPerfil || p.id)); }
  idPerfil(p: any): number    { return p.idPerfil || p.PEIdPerfil || p.id; }

  labelOficina(o: any): string { return o.TEDescripcion || o.nombre || o.descripcion || ('Oficina ' + (o.TEIdDetalle || o.id)); }
  idOficina(o: any): number    { return o.TEIdDetalle || o.id || o.idOficina; }

  labelPlan(p: any): string { return p.PLDescripcion || p.PLNombre || p.nombre || ('Plan ' + (p.PLidPlan || p.id)); }
  idPlan(p: any): number    { return p.PLidPlan || p.id || p.idPlan; }

  labelCobertura(c: any): string { return c.PONombre || c.nombre || c.descripcion || ('Cobertura ' + this.idCobertura(c)); }
  idCobertura(c: any): number    { return c.POidPlanOpcion || c.idPlanOpcion || c.id; }

  labelTipoAsignacion(t: any): string { return t.Nombre || t.TDNombre || t.nombre || ('Tipo ' + this.idTipoAsignacion(t)); }
  idTipoAsignacion(t: any): number    { return Number(t.TDIdTipoDefaulteo || t.idTipoDefaulteo || t.id); }

  tituloTipoAsignacion(id: number): string {
    switch (Number(id)) {
      case 1: return 'Tipo 1 · Conservar selecciones anteriores';
      case 2: return 'Tipo 2 · Asignar plan básico';
      case 3: return 'Tipo 3 · Conservar y recalcular dependientes';
      default: return 'Tipo de defaulteo';
    }
  }

  descripcionTipoAsignacion(id: number): string {
    switch (Number(id)) {
      case 1:
        return 'Recupera beneficios de la vigencia anterior, conserva sólo los válidos y recalcula tarifas y reglas.';
      case 2:
        return 'Asigna el plan básico configurado para el perfil actual, aunque el empleado no tenga selección anterior.';
      case 3:
        return 'Conserva beneficios válidos y vuelve a calcularlos con los dependientes activos y la familia actual.';
      default:
        return '';
    }
  }

  labelVigencia(v: any): string { return v.VINombre || v.VINombreCompuesto || v.nombre || ('Vigencia ' + (v.VIidVigencia || v.id)); }
  idVigencia(v: any): number    { return v.VIidVigencia || v.id || v.idVigencia; }

  labelSexo(s: any): string { return s.descripcion || s.Descripcion || s.SXDescripcion || s.nombre || ('Sexo ' + (s.idSexo || s.id)); }
  idSexo(s: any): number    { return s.idSexo || s.id || s.SXidSexo; }

  labelParentesco(p: any): string { return p.descripcion || p.PADescripcion || p.nombre || ('Parentesco ' + (p.idParentesco || p.id)); }
  idParentesco(p: any): number    { return p.idParentesco || p.id || p.PAidParentesco; }
}
