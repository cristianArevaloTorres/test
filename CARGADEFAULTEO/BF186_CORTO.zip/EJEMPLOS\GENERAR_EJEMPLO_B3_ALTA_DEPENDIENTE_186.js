/* Ejecutar desde el proyecto Angular (donde existe node_modules/exceljs):
   node C:\REPOS\CARGADEFAULTEO\insumos\GENERAR_EJEMPLO_B3_ALTA_DEPENDIENTE_186.js
*/
const path = require('path');
const ExcelJS = require('exceljs');

const salida = path.join(__dirname, 'EJEMPLO_B3_ALTA_DEPENDIENTE_EMPRESA_186.xlsx');
const workbook = new ExcelJS.Workbook();
workbook.creator = 'BeFlex QA';
workbook.created = new Date('2026-08-23T00:00:00-06:00');

const catalogo = workbook.addWorksheet('Catalogo');
catalogo.state = 'veryHidden';
catalogo.addRow(['Empresa', 'IdEmpresa', '', 'Sexo', 'IdSexo', '', 'Parentesco', 'IdParentesco']);
catalogo.addRow(['GALAZ,YAMAZAKI,RUIZ URQUIZA, S.C.', 186, '', 'Masculino', 1, '', 'CÓNYUGE', 2]);
catalogo.addRow(['', '', '', 'Femenino', 2, '', 'HIJO(A)', 3]);

const poblacion = workbook.addWorksheet('Población');
const campos = [
  ['EMIdEmpresa', 'E'], ['EMIdSexo', 'E'], ['EMNumeroEmpleado', 'T'],
  ['EMApellidoPaterno', 'T'], ['EMApellidoMaterno', 'T'], ['EMNombre1', 'T'],
  ['EMNombre2', 'T'], ['EMFechaNacimiento', 'D'], ['EMFechaAntiguedadGMM', 'D'],
  ['EMIdParentesco', 'E'], ['EMFechaAlta', 'D'], ['EMObservaciones', 'T'],
  ['EMCertificado', 'T']
];
const encabezados = campos.map(([nombre, tipo]) => `${nombre}(Campo tipo ${tipo})`);
const filaEncabezado = poblacion.addRow(encabezados);
filaEncabezado.eachCell(cell => {
  cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '4F81BD' } };
  cell.font = { color: { argb: 'FFFFFF' }, bold: true, name: 'Calibri' };
});

poblacion.addRow([
  'GALAZ,YAMAZAKI,RUIZ URQUIZA, S.C.', 'Femenino', 'QADEF3D-186',
  'EJEMPLO', 'DUMMY', 'DEPENDIENTE', 'B3',
  '2014-06-15', '2024-01-01',
  'HIJO(A)', '2026-08-23', 'ARCHIVO DE EJEMPLO B3', 'QA-B3-001'
]);

for (let i = 1; i <= campos.length; i += 1) {
  poblacion.getColumn(i).width = Math.max(18, encabezados[i - 1].length + 2);
}
poblacion.views = [{ state: 'frozen', ySplit: 1 }];

poblacion.getCell('A2').dataValidation = { type: 'list', formulae: ['=Catalogo!$A$2:$A$2'] };
poblacion.getCell('B2').dataValidation = { type: 'list', formulae: ['=Catalogo!$D$2:$D$3'] };
poblacion.getCell('J2').dataValidation = { type: 'list', formulae: ['=Catalogo!$G$2:$G$3'] };

workbook.xlsx.writeFile(salida)
  .then(() => console.log(salida))
  .catch(error => { console.error(error); process.exitCode = 1; });
