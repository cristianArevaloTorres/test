/* Prueba reversible de las cuatro combinaciones y deja la configuracion recomendada:
   Pantalla manual=B3 (Excel), procesos automaticos=B2. */
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* 3043 viene de la auditoria de los registros de menu entregados para el rol 570. */
DECLARE @IdEmpresa INT=186,@IdUsuario INT=3043;

BEGIN TRY
    BEGIN TRANSACTION;

    PRINT 'CASO 1: pantalla B2 / automatico B2';
    EXEC dbo.bf_CargaMasivaFlujo_Guardar @IdEmpresa,'B2','B2',@IdUsuario;
    EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa,'PANTALLA';
    EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa,'AUTOMATICO';

    PRINT 'CASO 2: pantalla B2 / automatico B3';
    EXEC dbo.bf_CargaMasivaFlujo_Guardar @IdEmpresa,'B2','B3',@IdUsuario;
    EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa,'PANTALLA';
    EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa,'AUTOMATICO';

    PRINT 'CASO 3: pantalla B3 / automatico B2';
    EXEC dbo.bf_CargaMasivaFlujo_Guardar @IdEmpresa,'B3','B2',@IdUsuario;
    EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa,'PANTALLA';
    EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa,'AUTOMATICO';

    PRINT 'CASO 4: pantalla B3 / automatico B3';
    EXEC dbo.bf_CargaMasivaFlujo_Guardar @IdEmpresa,'B3','B3',@IdUsuario;
    EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa,'PANTALLA';
    EXEC dbo.bf_CargaMasivaFlujo_Resolver @IdEmpresa,'AUTOMATICO';

    BEGIN TRY
        EXEC dbo.bf_CargaMasivaFlujo_Guardar @IdEmpresa,'B4','B2',@IdUsuario;
        THROW 51410,'La validacion acepto indebidamente el flujo B4.',1;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER()=51410 THROW;
        PRINT 'CASO INVALIDO B4: RECHAZADO CORRECTAMENTE';
    END CATCH;

    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

/* Estado funcional recomendado para la prueba desde BF3. */
EXEC dbo.bf_CargaMasivaFlujo_Guardar @IdEmpresa,'B3','B2',@IdUsuario;
EXEC dbo.bf_CargaMasivaFlujo_Obtener @IdEmpresa;
