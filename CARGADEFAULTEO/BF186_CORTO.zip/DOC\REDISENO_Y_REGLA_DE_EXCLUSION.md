# Rediseño y regla de exclusión de Defaulteo BF3

## Flujo visible para el usuario

La pantalla quedó organizada como un proceso guiado:

1. buscar empleados por empresa, vigencia y criterio;
2. seleccionar las personas pendientes;
3. elegir Defaulteo 1, 2 o 3 con una explicación contextual;
4. generar las solicitudes;
5. consultar el resultado en **Administración de Solicitudes**.

## Significado de cada tipo

- **Defaulteo 1 — Traer selección vigente anterior:** reutiliza la última
  selección válida del empleado como punto de partida para la vigencia actual.
- **Defaulteo 2 — Asignar el plan básico:** aplica los planes básicos o espejo
  elegibles configurados para el perfil en la vigencia destino, aun cuando el
  empleado no tenga una solicitud anterior.
- **Defaulteo 3 — Solicitud con dependientes del titular:** reconstruye la
  solicitud actual considerando la información vigente del titular y sus
  dependientes aplicables.

La interfaz muestra la descripción completa antes de ejecutar, además de una
guía general desplegable.

## Regla para no generar solicitudes repetidas

Los procedimientos de búsqueda excluyen a cualquier empleado que, para la
vigencia solicitada, ya tenga una solicitud con estatus **Activa (1)** o **Por
Autorizar (3)** y con registro vigente. Por eso, después de una generación
exitosa el empleado deja de aparecer en Defaulteo.

Las solicitudes **Canceladas (4)** o **Rechazadas (5)** no bloquean al
empleado: vuelve a aparecer para permitir su corrección y reproceso.

El listado básico toma una sola solicitud histórica de referencia por
empleado. Esto evita que varias solicitudes rechazadas/canceladas produzcan
filas duplicadas. El flujo avanzado vuelve a consultar automáticamente al
terminar y conserva visibles únicamente los errores o candidatos pendientes.

## Validación local, empresa 186

- Filas devueltas: 2,819.
- Empleados únicos: 2,819.
- Duplicados: 0.
- Empleados con solicitud Activa/Por Autorizar dentro del resultado: 0.

El frontend B3 compiló en modo producción correctamente para ES2015 y ES5.
El instalador consolidado `ALL.sql` también se ejecutó completo y sin errores
sobre la base local `FlexiForbesv2`.

La compilación integral del backend requiere descargar varios WSDL de la red
interna. En el ambiente local no fue posible contactar
`172.17.0.59:2003`; este bloqueo es externo al cambio, que sólo agrega objetos
SQL y no modifica código Java en esta corrección.

El objeto obligatorio para esta regla se instala mediante
`DB/INSTALL/005.sql` o mediante el consolidado `DB/INSTALL/ALL.sql`.
