/*
  Verificacion final de objetos y datos QA para la empresa 186.
  Es de solo lectura y no depende de los comentarios del archivo MD.
*/
SET NOCOUNT ON;

SELECT DB_NAME() AS BaseActual, @@SERVERNAME AS Servidor, GETDATE() AS FechaRevision;

SELECT 'OBJETO' AS Grupo, V.Nombre,
       CASE WHEN OBJECT_ID(V.Nombre,V.Tipo) IS NOT NULL THEN 'OK' ELSE 'FALTA' END AS Resultado
FROM (VALUES
 ('dbo.bf_ConfiguracionFlujoCargaMasiva','U'),
 ('dbo.bf_CargaMasivaFlujo_Obtener','P'),
 ('dbo.bf_CargaMasivaFlujo_Guardar','P'),
 ('dbo.bf_CargaMasivaFlujo_Resolver','P'),
 ('dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3','P'),
 ('dbo.ff_IInsertaPlanesPerfilTmpTestMultivigenciaBF3','P'),
 ('dbo.ff_CreateSolicitudTest','P'),
 ('dbo.bf_ConfiguracionDefaulteo','U')) V(Nombre,Tipo)
ORDER BY V.Nombre;

SELECT 'FIRMA_IDCORPORATIVO' AS Grupo,P.name AS Nombre,
       CASE WHEN OBJECT_DEFINITION(P.object_id) LIKE '%IdCorporativoCompat%'
            THEN 'OK' ELSE 'FALTA PARCHE 004' END AS Resultado
FROM sys.procedures P
WHERE P.name IN
 ('ff_IInsertaPlanesFlexiblesTmp','ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3')
ORDER BY P.name;

SELECT 'FLUJO_EMPRESA_186' AS Grupo,CFIdEmpresa,CFFlujoPantalla,CFFlujoAutomatico,CFIdEstatus,
       CASE WHEN CFFlujoPantalla='B3' AND CFFlujoAutomatico='B2' AND CFIdEstatus=1
            THEN 'OK' ELSE 'REVISAR' END AS Resultado
FROM dbo.bf_ConfiguracionFlujoCargaMasiva
WHERE CFIdEmpresa=186;

SELECT 'OPERACIONES_CARGA_186' AS Grupo,CE.CEIdOperacionEmpresa,CE.CEIdOperacion,
       O.CONombre,CE.CEIdPlantilla,CE.CEStoredProc,
       CASE WHEN OBJECT_ID('dbo.'+CE.CEStoredProc,'P') IS NOT NULL THEN 'OK' ELSE 'FALTA SP' END Resultado
FROM dbo.ff_CargaMasivaOperacionEmpresa CE
JOIN dbo.ff_CargaMasivaOperacion O ON O.COIdOperacion=CE.CEIdOperacion
WHERE CE.CEIdEmpresa=186 AND CE.CEIdEstatus=1 AND O.COIdEstatus=1
ORDER BY CE.CEIdOperacionEmpresa;

DECLARE @MenuCarga int=(SELECT TOP(1) MEIdMenu FROM dbo.ff_Menu
                         WHERE MERutaLiga='/cargamasivapoblaciones' AND MEIdEstatus=1 ORDER BY MEIdMenu);
DECLARE @MenuDef int=(SELECT TOP(1) MEIdMenu FROM dbo.ff_Menu
                      WHERE MERutaLiga='administracion/solicitudes/defaulteo'
                        AND MEIdEstatus=1 ORDER BY MEIdMenu);
SELECT 'MENU_BF3' AS Grupo,D.MEIdMenu,D.MENombreMenu,D.MERutaLiga,D.MEMenuPadre,D.MEOrden,
       R.MRIdRol,R.MRImagenMenu,
       CASE WHEN D.MENombreMenu='Defaulteo'
                 AND D.MERutaLiga='administracion/solicitudes/defaulteo'
                 AND D.MEMenuPadre=C.MEMenuPadre
                 AND D.MEOrden=C.MEOrden+1 AND ISNULL(R.MRImagenMenu,'')=ISNULL(RC.MRImagenMenu,'')
            THEN 'OK' ELSE 'REVISAR' END Resultado
FROM dbo.ff_Menu D
JOIN dbo.ff_Menu C ON C.MEIdMenu=@MenuCarga
JOIN dbo.ff_MenuRol2 R ON R.MRIdMenu=D.MEIdMenu AND R.MRIdEstatus=1
LEFT JOIN dbo.ff_MenuRol2 RC ON RC.MRIdMenu=C.MEIdMenu AND RC.MRIdRol=R.MRIdRol AND RC.MRIdEstatus=1
WHERE D.MEIdMenu=@MenuDef
ORDER BY R.MRIdRol;

SELECT 'DUMMY_DEFAULTEO' AS Grupo,E.Id,E.EMNumeroEmpleado,E.EMIdPerfil,E.EMIdParentesco,E.EMIdTitular,
       CASE WHEN E.EMIdEstatus=1 THEN 'OK' ELSE 'REVISAR' END Resultado
FROM dbo.ff_Empleado E
WHERE E.EMNumeroEmpleado IN
 ('QADEF-RTRY-186','QADEF1-186','QADEF2-186','QADEF3C-186','QADEF3D-186')
ORDER BY E.Id;

DBCC CHECKCONSTRAINTS WITH ALL_CONSTRAINTS;
