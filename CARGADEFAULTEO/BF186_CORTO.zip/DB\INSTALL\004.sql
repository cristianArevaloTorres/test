/*
  Corrige la incompatibilidad de firma detectada en la cadena de defaulteo:
  ff_IInsertaPlanesFlexiblesTmpCreditos requiere @IdCorporativo como parametro 7,
  pero dos callers legados instalados lo invocan con seis parametros.

  El parche conserva la definicion instalada y solo sustituye esa invocacion.
  Es idempotente y falla de forma explicita si la firma esperada no existe.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Objetos TABLE (Nombre sysname PRIMARY KEY);
INSERT @Objetos(Nombre) VALUES
 ('ff_IInsertaPlanesFlexiblesTmp'),
 ('ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3');

DECLARE @Nombre sysname,@Def nvarchar(max),@PosProc int,@CallOld nvarchar(500),@CallNew nvarchar(1000);
DECLARE C CURSOR LOCAL FAST_FORWARD FOR SELECT Nombre FROM @Objetos ORDER BY Nombre;
OPEN C;
FETCH NEXT FROM C INTO @Nombre;
WHILE @@FETCH_STATUS=0
BEGIN
  SET @Def=OBJECT_DEFINITION(OBJECT_ID(N'dbo.'+@Nombre,N'P'));
  IF @Def IS NULL
    THROW 51501,'No existe uno de los procedimientos caller que debe corregirse.',1;

  IF CHARINDEX('IdCorporativoCompat',@Def)=0
  BEGIN
    SET @CallOld=N'exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp';
    IF CHARINDEX(@CallOld,@Def)=0
      THROW 51502,'No se encontro la invocacion de seis parametros esperada. Revise la version del procedimiento.',1;

    SET @CallNew=N'DECLARE @IdCorporativoCompat int =
      (SELECT TOP (1) EMIdCorporativo FROM dbo.ff_Empresa WHERE EMIdEmpresa=@idEmpresa);
exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp,@IdCorporativoCompat';
    SET @Def=REPLACE(@Def,@CallOld,@CallNew);

    SET @PosProc=CHARINDEX('PROCEDURE',UPPER(@Def));
    IF @PosProc=0 THROW 51503,'La definicion no contiene PROCEDURE.',1;
    SET @Def=STUFF(@Def,1,@PosProc-1,'ALTER ');
    EXEC sys.sp_executesql @Def;
  END;

  FETCH NEXT FROM C INTO @Nombre;
END;
CLOSE C;
DEALLOCATE C;

SELECT P.name,
       CASE WHEN OBJECT_DEFINITION(P.object_id) LIKE '%IdCorporativoCompat%'
            THEN 'OK' ELSE 'REVISAR' END Resultado
FROM sys.procedures P
WHERE P.name IN('ff_IInsertaPlanesFlexiblesTmp','ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3')
ORDER BY P.name;

