/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lockton.WSBeFlex.DAO;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.POJO.FfEmpleado;
import com.lockton.WSBeFlex.POJO.FfGetSolicitudXIdEmpleado;
import com.lockton.WSBeFlex.POJO.Especiales.FfCOpcionesCargaMasiva;
import com.lockton.WSBeFlex.POJO.Especiales.FfLogCargaMasiva;
import com.lockton.WSBeFlex.Services.FileService;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

/**
 *
 * @author JHON
 */
@Repository
public class JDBCFfCargaMasiva implements FfCargaMasivaDAO {
    
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    JDBCFfEmpleado empleado_dao;

    @Autowired
	FfSolicitudDAO ff_solicitud;

	@Autowired
	FileService file_service;

    private final ObjectMapper objectMapper = new ObjectMapper();
    
    @Override
    public List<FfCOpcionesCargaMasiva> opcionesCargaMasiva(int idEmpresa) {
       
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_CCMOperacionesEmpresaAdm");
            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("IdEmpresa", idEmpresa);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            ArrayList<FfCOpcionesCargaMasiva> datos=new ArrayList<FfCOpcionesCargaMasiva>();
            
            Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
            List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
            if (!listSP.isEmpty()) {
                    for (int i = 0; i < listSP.size(); i++) {
                            if (!(listSP.get(i) instanceof Integer)) {
                                    @SuppressWarnings("unchecked")
                                    List<Object> listValues = (List<Object>) listSP.get(i);
                                    if (!listValues.isEmpty()) {
                                            for (int j = 0; j < listValues.size(); j++) {
                                                
                                                    @SuppressWarnings("unchecked")
                                                    Map<String, Object> mapDatosValidos = (Map<String, Object>) listValues.get(j);
                                                    if (mapDatosValidos.containsKey("COIdOperacion") && mapDatosValidos.containsKey("CONombre")) {
                                                        FfCOpcionesCargaMasiva datosOp=new FfCOpcionesCargaMasiva();
                                                           datosOp.opcion= (int) mapDatosValidos.get("COIdOperacion");
                                                           datosOp.nombre= (String) mapDatosValidos.get("CONombre");
                                                           if (mapDatosValidos.containsKey("CEStoredProc") && mapDatosValidos.containsKey("CEIdPlantilla")) {
                                                               datosOp.sp=(String) mapDatosValidos.get("CEStoredProc");
                                                               datosOp.plantilla=(int) mapDatosValidos.get("CEIdPlantilla");
                                                               datosOp.parametroAcceso = obtenerParametroAcceso(datosOp.plantilla, datosOp.sp);
                                                           }
                                                           datos.add(datosOp);
                                                    }
                                            }
                                    }
                            }
                    }
            }
            return datos;
            
    }

    private String obtenerParametroAcceso(int idPlantilla, String procedimiento) {
        String sql = "SELECT CASE "
                + "WHEN EXISTS (SELECT 1 FROM sys.parameters "
                + "WHERE object_id = OBJECT_ID(LTRIM(RTRIM(?))) "
                + "AND name = '@EMIdAcceso') THEN 'EMIdAcceso' "
                + "WHEN EXISTS (SELECT 1 FROM sys.parameters "
                + "WHERE object_id = OBJECT_ID(LTRIM(RTRIM(?))) "
                + "AND name = '@Acceso') THEN 'Acceso' "
                + "WHEN EXISTS (SELECT 1 FROM dbo.ff_ConfiguracionPlantilla cp "
                + "JOIN dbo.ff_Campo c ON c.CAIdCampo = cp.CAIdCampo "
                + "WHERE cp.PLIdPlantilla = ? AND cp.CPIdEstatus = 1 "
                + "AND c.CAIdEstatus = 1 "
                + "AND LTRIM(RTRIM(c.CANombreCampo)) = 'EMIdAcceso') THEN 'EMIdAcceso' "
                + "ELSE NULL END";
        try {
            return jdbcTemplate.queryForObject(sql, String.class, procedimiento, procedimiento, idPlantilla);
        } catch (Exception ignored) {
            return null;
        }
    }

    @Override
    public FfLogCargaMasiva crearTitularM(String atributos, String valores) {
        String[] parametros=atributos.split(",");
        String[] valores1=valores.split(",");
        String sp="";

        String idEmpresa = "";
        for(int i =0; i<parametros.length;i++){
            if (parametros[i].equalsIgnoreCase("EMIdEmpresa")) {
                idEmpresa = valores1[i];
            }
            if(parametros[i].equalsIgnoreCase("Sp")){
                sp=valores1[i];
                break;
            }
        }
        sp = sp.replace(":", "");

        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("ff_cargaMasivaGen");
        Map<String, Object> inParamMap = new HashMap<String, Object>();
        String cadenaEtiquetas="";

        String numEmpleadoAux = "";
        for(int i =0; i<parametros.length;i++){
            if(!parametros[i].equalsIgnoreCase("Sp")){
                if(valores1[i].equalsIgnoreCase("NULL")){
                    valores1[i]=null;
                }
                if(valores1[i]==null){

                }else{
                    valores1[i]=valores1[i].replace("'", "");
                }

                if((parametros[i].indexOf("Fecha")>-1 || parametros[i].indexOf("fecha")>-1)
                        && valores1[i] != null && !"null".equalsIgnoreCase(valores1[i])){

                    valores1[i]=valores1[i].replace("T"," ");
                }

                String parametro="@"+parametros[i]+"=";
                if(valores1[i] == null || "null".equalsIgnoreCase(valores1[i])){
                    if(parametros[i].equalsIgnoreCase("EMNombre2")){
                        parametro+="''";
                    }else{
                        parametro+=valores1[i];
                    }
                }else{
                    parametro+="'"+valores1[i]+"'";
                }

                cadenaEtiquetas+=parametro+",";
            }
        }

        cadenaEtiquetas=cadenaEtiquetas.substring(0, cadenaEtiquetas.length()-1);
        inParamMap.put("etiquetas",cadenaEtiquetas);
        inParamMap.put("sp",sp);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        FfLogCargaMasiva salida= new FfLogCargaMasiva();
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
        if (!listSP.isEmpty()) {
            for (int i = 0; i < listSP.size(); i++) {
                if (!(listSP.get(i) instanceof Integer)) {
                    @SuppressWarnings("unchecked")
                    List<Object> listValues = (List<Object>) listSP.get(i);
                    if (!listValues.isEmpty()) {
                        for (int j = 0; j < listValues.size(); j++) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> mapDatosValidos = (Map<String, Object>) listValues.get(j);
                            if (mapDatosValidos.containsKey("Return_Code") && mapDatosValidos.containsKey("Return_Msg")) {
                                salida.setCode((int) mapDatosValidos.get("Return_Code"));
                                salida.setMsg((String) mapDatosValidos.get("Return_Msg"));

                            }
                        }
                    }
                }
            }
        }
        return salida;
    }

    private String obtenerCampoPassword(Integer idEmpresa){
        String sql = "select EMRazonSocial, CANombreCampo from ff_Empresa\n" +
                "inner join ff_Configuracion on COidConfiguracion = EMidConfiguracion and COidEstatus = 1\n" +
                "inner join ff_campo on CAIdCampo = COidCampoPassIni and  CAIdEstatus = 1\n" +
                "where EMidEmpresa = ? and EMidEstatus = 1";
        Map<String, Object> ffem = jdbcTemplate.queryForMap(sql ,idEmpresa);
        if (ffem.get("CANombreCampo") != null) {
            return ffem.get("CANombreCampo").toString();
        } else {
            return "EMNumeroEmpleado";
        }
    }
    
    @Override
    public FfLogCargaMasiva crearDependienteM(String atributos, String valores) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("ff_XCMDependientesAltaCMM_BF3");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
                String[] parametros=atributos.split(",");
                String[] valores1=valores.split(",");
                BigDecimal dato = null;
                for(int i =0; i<parametros.length;i++){ 
                    if("_NULL".equals(valores1[i]) || "NULL".equals(valores1[i])){
                        valores1[i]=null;
                    }
                    inParamMap.put(parametros[i],valores1[i]);  
                }
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
                FfLogCargaMasiva salida= new FfLogCargaMasiva();
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		if (!listSP.isEmpty()) {
			for (int i = 0; i < listSP.size(); i++) {
				if (!(listSP.get(i) instanceof Integer)) {
					@SuppressWarnings("unchecked")
					List<Object> listValues = (List<Object>) listSP.get(i);
					if (!listValues.isEmpty()) {
						for (int j = 0; j < listValues.size(); j++) {
							@SuppressWarnings("unchecked")
							Map<String, Object> mapDatosValidos = (Map<String, Object>) listValues.get(j);
							if (mapDatosValidos.containsKey("Return_Code") && mapDatosValidos.containsKey("Return_Msg")) {
                                                            salida.setCode((int) mapDatosValidos.get("Return_Code"));
                                                            salida.setMsg((String) mapDatosValidos.get("Return_Msg"));
                                                            
							}
						}
					}
				}
			}
		}
		return salida;
    }
    @Override
    public FfLogCargaMasiva bajaMasivaT(int idEmpresa, int eMId, String eMObservaciones, int eMUsuarioUMod, int eMIdTitular,
			String numeroEmpleado, String FechaBaja){
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("ff_XCMAseguradosBaja_Base");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
                
                inParamMap.put("EMIdEmpresa",idEmpresa);
                inParamMap.put("Id",eMId);
                inParamMap.put("EMObservaciones",eMObservaciones);
                inParamMap.put("EMUsuarioUMod",eMUsuarioUMod);
                inParamMap.put("EMIdTitular",eMIdTitular);
                inParamMap.put("EMNumeroEmpleado",numeroEmpleado);
                inParamMap.put("EMFechaBaja",FechaBaja);
               
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
                FfLogCargaMasiva salida= new FfLogCargaMasiva();
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		if (!listSP.isEmpty()) {
			for (int i = 0; i < listSP.size(); i++) {
				if (!(listSP.get(i) instanceof Integer)) {
					@SuppressWarnings("unchecked")
					List<Object> listValues = (List<Object>) listSP.get(i);
					if (!listValues.isEmpty()) {
						for (int j = 0; j < listValues.size(); j++) {
							@SuppressWarnings("unchecked")
							Map<String, Object> mapDatosValidos = (Map<String, Object>) listValues.get(j);
							if (mapDatosValidos.containsKey("Return_Code") && mapDatosValidos.containsKey("Return_Msg")) {
                                                            salida.setCode((int) mapDatosValidos.get("Return_Code"));
                                                            salida.setMsg((String) mapDatosValidos.get("Return_Msg"));
                                                            
							}
						}
					}
				}
			}
		}
		return salida;
    }

    @Override
    public FfLogCargaMasiva bajaMasivaD(String atributos, String valores) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_BajaMasivaDependientes");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
        String[] parametros=atributos.split(",");
        String[] valores1=valores.split(",");
        BigDecimal dato = null;
        for(int i =0; i<parametros.length;i++){ 
            inParamMap.put(parametros[i],valores1[i]);                 
            
        }
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
                FfLogCargaMasiva salida= new FfLogCargaMasiva();
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		if (!listSP.isEmpty()) {
			for (int i = 0; i < listSP.size(); i++) {
				if (!(listSP.get(i) instanceof Integer)) {
					@SuppressWarnings("unchecked")
					List<Object> listValues = (List<Object>) listSP.get(i);
					if (!listValues.isEmpty()) {
						for (int j = 0; j < listValues.size(); j++) {
							@SuppressWarnings("unchecked")
							Map<String, Object> mapDatosValidos = (Map<String, Object>) listValues.get(j);
							if (mapDatosValidos.containsKey("Return_Code") && mapDatosValidos.containsKey("Return_Msg")) {                                               
                                                            salida.setCode((int) mapDatosValidos.get("Return_Code"));
                                                            salida.setMsg((String) mapDatosValidos.get("Return_Msg"));
                                                            
							}
						}
					}
				}
			}
		}
		return salida;
    }

    @Override
    public FfLogCargaMasiva procesarCargaMasiva(String atributos, String valores) {
        String[] parametros=atributos.split(",");
        String[] valores1=valores.split(",");
        String sp="";

        String idEmpresa = "";
        for(int i =0; i<parametros.length;i++){
            if (parametros[i].equalsIgnoreCase("EMIdEmpresa")) {
                idEmpresa = valores1[i];
            }
            if(parametros[i].equalsIgnoreCase("Sp")){
                sp=valores1[i];
                break;
            }
        }
        sp = sp.replace(":", "");

        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("ff_cargaMasivaGen");
        Map<String, Object> inParamMap = new HashMap<String, Object>();
        String cadenaEtiquetas="";

        String numEmpleadoAux = "";
        // Limpieza de datos y generacion parametros
        for(int i =0; i<parametros.length;i++){
            if(!parametros[i].equalsIgnoreCase("Sp")){
                if(valores1[i].equalsIgnoreCase("NULL")){
                    valores1[i]=null;
                }
                if(valores1[i]==null){
                }else{
                    valores1[i]=valores1[i].replace("'", "");
                }
                if((parametros[i].indexOf("Fecha")>-1 || parametros[i].indexOf("fecha")>-1)
                        && valores1[i] != null && !"null".equalsIgnoreCase(valores1[i])){
                    valores1[i]=valores1[i].replace("T"," ");
                }
                String parametro="@"+parametros[i]+"=";
                if(valores1[i] == null || "null".equalsIgnoreCase(valores1[i])){
                    if(parametros[i].equalsIgnoreCase("EMNombre2")){
                        parametro+="''";
                    }else{
                        parametro+=valores1[i];
                    }
                }else{
                    parametro+="'"+valores1[i]+"'";
                }
                cadenaEtiquetas+=parametro+",";
            }
        }

        cadenaEtiquetas=cadenaEtiquetas.substring(0, cadenaEtiquetas.length()-1);
        inParamMap.put("etiquetas",cadenaEtiquetas);
        inParamMap.put("sp",sp);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        FfLogCargaMasiva salida= new FfLogCargaMasiva();
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        if(simpleJdbcCallResult.containsKey("#result-set-1")){
            List<Map<String,Object>> resultSet = (List<Map<String,Object>>) simpleJdbcCallResult.get("#result-set-1");
            if(resultSet.size() > 0){
                salida.setCode((int) resultSet.get(0).get("codigo"));
                salida.setMsg((String) resultSet.get(0).get("mensaje"));
            }else{
                salida.setCode(0);
                salida.setMsg("Sin respuesta del procedimiento almacenado");
            }
        }
        return salida;
    }

    @Override
    public Map<String, Object> procesarTransferenciaMasiva(Map<String, Object> parametros, String sp) {
        Map<String, Object> salida= new HashMap<String, Object>();
        try{
            int idEmpresa = Integer.parseInt(String.valueOf(parametros.get("EMIdEmpresaOrigen")));
            int idEmpresaDestino = Integer.parseInt(String.valueOf(parametros.get("EMIdEmpresa")));
            String numeroEmpleadoOrig = String.valueOf(parametros.get("EMNumeroEmpleado"));

            //Obtenemos todos los datos del Empleado por su ID
            FfEmpleado empleado = null;
			try{
                 empleado = empleado_dao.buscarEmpleadoPorNumero(idEmpresa, numeroEmpleadoOrig);
            }catch(Exception e){
                salida.put("code",0);
                salida.put("msg", "No existe el empleado " + numeroEmpleadoOrig +" para la empresa seleccionada, no se realiza acción");
            }
            if(empleado != null){
                //Obtenemos el Id Empleado
                int empladoId = empleado.getId();
    
                // Validar existencia de solicitud 
                List<FfGetSolicitudXIdEmpleado> solicitudesEmpleado = ff_solicitud.consultarSolicitudPorIdEmpleado(empladoId);
                int idSolicitud = 0;
                String nombreArchivo = null;
                String nombreArchivoDestino = null;
    
                // Buscar solicitud activa
                if(solicitudesEmpleado.size() > 0){
                    // Recuperar id de la ultima solicitud activa
                    FfGetSolicitudXIdEmpleado ultimaSolicitud = solicitudesEmpleado.get(0);
                    int soEstatus = ultimaSolicitud.getSoEstatusSolicitud();
                    int idEstatus = ultimaSolicitud.getSoIdEstatus();
                    // Validar que este en un estatus marcado como activo
                    if(idEstatus == 1 && (soEstatus == 1 || soEstatus == 2 || soEstatus == 3)){
                        idSolicitud = ultimaSolicitud.getSoIdSolicitud();
                    }
                }
    
                parametros.put("idSolicitud", idSolicitud);
                parametros.put("IdEmpleado", empladoId);

                // Convertir parametros a JSON
                String parametrosJson = objectMapper.writeValueAsString(parametros);
    
                // Ejecutar transferencia
                SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(sp);
                Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(new MapSqlParameterSource("parametrosCarga", parametrosJson));
                if(simpleJdbcCallResult.containsKey("#result-set-1")){
                    List<Map<String,Object>> resultSet = (List<Map<String,Object>>) simpleJdbcCallResult.get("#result-set-1");
                    if(resultSet.size() > 0){
                        salida = resultSet.get(0);
                    }else{
                        salida.put("code",0);
                        salida.put("msg","Sin respuesta del procedimiento almacenado");
                    }
                }
    
                // Mover PDF solicitud si existen
                if(solicitudesEmpleado.size() > 0){
                    // Buscar el pdf de cada solicitud para moverlo a la carpeta destino
                    for(FfGetSolicitudXIdEmpleado solicitudEmpeado: solicitudesEmpleado){
                        int idSolicitudActual = solicitudEmpeado.getSoIdSolicitud();
                        nombreArchivo = file_service.find(idEmpresa, idSolicitudActual, empladoId);
    
                        if(nombreArchivo != null && !nombreArchivo.isEmpty()){
                            nombreArchivoDestino = nombreArchivo.replaceFirst(String.valueOf(idEmpresa),String.valueOf(idEmpresaDestino));
    
                            // Crear repositorio si no existe
                            File archivo = new File(nombreArchivoDestino);
                            String directorio = archivo.getParent();
                            file_service.createFolderIfNotExists(directorio);
    
                            // Mover archivo de carpeta origen a carpeta destino
                            Path origen = Paths.get(nombreArchivo);
                            Path destino = Paths.get(nombreArchivoDestino);
    
                            try{
                                Files.move(origen, destino, StandardCopyOption.REPLACE_EXISTING);
                            }catch(Exception e){
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }catch(Exception e){
            salida.put("code",0);
            salida.put("msg", "Ocurrió un error al procesar la transferencia");
        }
        
        return salida;
    }
}
