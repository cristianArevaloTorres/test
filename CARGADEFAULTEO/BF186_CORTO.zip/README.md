# Paquete corto — Carga Masiva y Defaulteo 1/2/3

Este paquete evita la carpeta exterior y los nombres largos del ZIP anterior.
Para prevenir `MAX_PATH`, descomprima directamente en una ruta corta, por
ejemplo `C:\TMP\BF186`.

## SQL que puede ejecutar sin la nueva instalacion

`DB/AUX/INSUMOS_186.sql` consulta solamente tablas existentes de insumos para
la empresa 186. No usa la nueva configuracion B2/B3, logs nuevos ni stored
procedures agregados. La muestra base es de 500 titulares.

## SQL de instalacion

`DB/INSTALL/ALL.sql` es el instalador consolidado. Los archivos `001.sql`,
`002.sql` y `003.sql` son las mismas partes por separado. No los ejecute hasta
que se autorice instalar las nuevas configuraciones en la base destino.

Los SQL de `DB/AUX` no forman parte de la instalacion:

- `PRECHECK.sql`: diagnostico previo.
- `POSTCHECK.sql`: validacion posterior.
- `SIM_B2_B3.sql`: simulacion con rollback.
- `MENU_BF3_186.sql`: menu de BF3 servido por Java.
- `MENU_GENERIC.sql`: variante generica del menu.
- `PRUEBAS_FULL.sql`: consulta extensa posterior a la instalacion.
- `INSUMOS_186.sql`: fragmento pequeno anterior a la instalacion.

## Mapa de proyectos

Las rutas internas de cada proyecto se conservan debajo de una abreviatura:

| Carpeta corta | Proyecto destino |
|---|---|
| `SRC/WS` | `WSBeFlex-EmpAdm-defaulteoCargaMaisva` |
| `SRC/B3` | `BeFlex3-EmpAdm-defaulteoCargaMaisva` |
| `SRC/RPT` | `BeFlex3_Admin_API_Reportes-defaulteoCargaMaisva` |
| `SRC/B2` | `BeflexProduccion-QA` |

Ejemplo: `SRC/WS/src/main/java/...` se integra en `src/main/java/...` del
backend principal Java. No se incluye `global.ts`, porque contiene URLs de
ambiente y no es un cambio funcional de esta homologacion.

