/*
  Evita que el listado de Defaulteo muestre titulares que ya tienen una
  solicitud Activa o Por Autorizar en la vigencia seleccionada.

  Tambien evita duplicados en la operacion guiada: si existen solicitudes
  rechazadas/canceladas, solo se muestra la ultima como referencia. Esos
  titulares siguen siendo reprocesables por regla de negocio.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [dbo].[bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado]
(
	@IdsEmpresas varchar(max)
	,@IdAdministrador INT
	,@idAtributo1 varchar(100) 
	,@idAtributo2 varchar(100) 
	,@idTipoOperador1 varchar(100) 
	,@idTipoOperador2 varchar(100) 
	,@parametroBusqueda1 varchar(max) 
	,@parametroBusqueda2 varchar(max) 
	,@BusquedaAvanzada INT = 1
	,@idTipoOperadorAvanzado varchar(100) 
	,@idPerfiles varchar(max)
	,@Vigencia int
)
AS

BEGIN

	DECLARE  
		@campo varchar(70) 
		,@IdEmpleados_str varchar(max) = ''
		,@sql_str nvarchar(max) = ''
		,@sql_empresas nvarchar(max) = ''
	DECLARE @TablaSol TABLE(IDEmpleado INT)
	DECLARE @Empresas AS TABLE (ID INT)

	INSERT INTO @Empresas SELECT LTRIM(rtrim(value)) FROM STRING_SPLIT(@IdsEmpresas, ',')

	SET @sql_str = N'SELECT DISTINCT  
		EMPL.Id 
		,CAST(0 AS BIT) AS seleccion 
		,EMPL.EMIdEmpresa 
		,EMPL.EMNumeroEmpleado as numEmpleado 
		,P.EMNombre as nombreEmpresa 
		,ff_Perfil.PEDescripcion as perfil 
		,ff_Perfil.PEIdPerfil as idPerfil 
		,EMPL.EMApellidoPaterno as ApellidoPaterno  
		,EMPL.EMApellidoMaterno as ApellidoMaterno 
		,EMPL.EMNombre1 as Nombre1 
		,EMPL.EMNombre2 as Nombre2 
		,EMPL.EMFechaNacimiento as fechaNacimiento 
		,EMPL.EMEdad as edad 
		,ff_Parentesco.PADescripcion as parentesco 
		,EMPL.EMIdEmpresa as idEmpresa 
		,CASE WHEN ULT.SONumeroSolicitud IS NULL THEN ''''
              ELSE CONCAT(ULT.SONumeroSolicitud, ''-'', ULT.SOAnexoSolicitud)
         END AS NumeroSolicitud 
	FROM
        ff_Empleado EMPL WITH(NOLOCK)
        OUTER APPLY
        (
            SELECT TOP (1)
                SULT.SONumeroSolicitud,
                SULT.SOAnexoSolicitud
            FROM dbo.ff_Solicitud SULT WITH(NOLOCK)
            WHERE SULT.SOIdEmpleado = EMPL.Id
              AND SULT.SOIdVigencia = '+CAST(@Vigencia AS VARCHAR(max))+'
            ORDER BY SULT.SOFechaAdd DESC, SULT.SOIdSolicitud DESC
        ) ULT
        INNER JOIN ff_Perfil  
			ON ff_Perfil.PEIdPerfil = EMPL.EMidperfil 
			AND ff_Perfil.PEIdPerfil IN ('+@idPerfiles+') 
		INNER JOIN ff_Parentesco  
			ON ff_Parentesco.PAidParentesco = EMPL.EMIdParentesco  
		INNER JOIN ff_Empresa P  
			ON P.EMidEmpresa = EMPL.EMIdEmpresa 
	WHERE  '

	SET @sql_empresas = N' (EMPL.EMIdEmpresa in ('+@IdsEmpresas+')  
			AND EMPL.EMNumeroEmpleado NOT LIKE ''PR%'' 
			AND EMPL.EMIdEstatus = 1  
			AND EMPL.EMIdTitular = 1 '
			+ 
			' AND NOT EXISTS (
                    SELECT 1
                    FROM dbo.ff_Solicitud SOLACT WITH(NOLOCK)
                    WHERE SOLACT.SOIdEmpleado = EMPL.Id
                      AND SOLACT.SOIdEstatus IN (1,10)
                      AND SOLACT.SOEstatusSolicitud IN (1,3)
                      AND SOLACT.SOIdVigencia = '+CAST(@Vigencia AS VARCHAR(max))+'
                      AND SOLACT.SOIdEmpresa IN ('+@IdsEmpresas+')
                ) '

	-- Insertar filtros para empleado
	DECLARE
		@sql_where1 VARCHAR(MAX) = ''
		,@sql_where2 VARCHAR(MAX) = ''

	IF( LTRIM(RTRIM(@parametroBusqueda1)) = '')
	BEGIN
		SET @sql_where1 = @sql_empresas + ' )';
	END
	ELSE
	BEGIN
		set @sql_where1 = @sql_empresas + ' AND EMPL.' + @idAtributo1 +
			(CASE WHEN @idTipoOperador1 = 'igual' THEN  ' = ''' + @parametroBusqueda1 + ''''
				WHEN @idTipoOperador1 = 'contiene' THEN ' LIKE ''%' + @parametroBusqueda1 + '%'''
				WHEN @idTipoOperador1 = 'noigual' THEN ' <> ''' + UPPER(@parametroBusqueda1) + ''''
				WHEN @idTipoOperador1 = 'iniciapor' THEN ' LIKE ''' + @parametroBusqueda1 + '%'''
				WHEN @idTipoOperador1 = 'terminapor' THEN ' LIKE ''%' + @parametroBusqueda1 + ''''
				WHEN @idTipoOperador1 = 'nocontiene' THEN ' NOT LIKE ''%' + @parametroBusqueda1 + '%'''
				ELSE ' LIKE ''%' + @parametroBusqueda1 + '%'''
			END)
			+ ' ) '
		-- PRINT @sql_where1
		IF @BusquedaAvanzada = 1
		BEGIN
			set @sql_where2 = ' ' + @idTipoOperadorAvanzado + @sql_empresas +  ' AND EMPL.' + @idAtributo2 +
				(CASE WHEN @idTipoOperador2 = 'igual' THEN  ' = ''' + @parametroBusqueda2 + ''''
					WHEN @idTipoOperador2 = 'contiene' THEN ' LIKE ''%' + @parametroBusqueda2+ '%'''
					WHEN @idTipoOperador2 = 'noigual' THEN ' <> ''' + @parametroBusqueda2 + ''''
					WHEN @idTipoOperador2 = 'iniciapor' THEN ' LIKE ''' + @parametroBusqueda2 + '%'''
					WHEN @idTipoOperador2 = 'terminapor' THEN ' LIKE ''%' + @parametroBusqueda2 + ''''
					WHEN @idTipoOperador2 = 'nocontiene' THEN ' NOT LIKE ''%' + @parametroBusqueda2 + '%'''
					ELSE ' LIKE ''%' + @parametroBusqueda2 + '%'''
				END)
				+ ' ) '
		END
		-- PRINT @sql_where2
	END

	SET @sql_str= @sql_str + @sql_where1 + @sql_where2
	PRINT @sql_str

	EXECUTE sp_EXECUTESQL @sql_str 

END
GO

CREATE OR ALTER PROCEDURE [dbo].[bf_DefaulteoAvanzado_Buscar]
    @IdCorporativo         INT,
    @IdVigencia            INT,
    @IdsEmpresa            NVARCHAR(MAX) = NULL, -- CSV
    @IdsPerfil             NVARCHAR(MAX) = NULL, -- CSV
    @IdsOficina            NVARCHAR(MAX) = NULL, -- CSV
    @IdsArea               NVARCHAR(MAX) = NULL, -- CSV
    @IdsSexo               NVARCHAR(MAX) = NULL, -- CSV
    @IdsParentesco         NVARCHAR(MAX) = NULL, -- CSV
    @IdsPlan               NVARCHAR(MAX) = NULL, -- CSV (plan asignado actual)
    @IdsCobertura          NVARCHAR(MAX) = NULL, -- CSV
    @NumerosEmpleado       NVARCHAR(MAX) = NULL, -- CSV
    @SalarioMin            DECIMAL(18,2) = NULL,
    @SalarioMax            DECIMAL(18,2) = NULL,
    @SumaAseguradaMin      DECIMAL(18,2) = NULL,
    @SumaAseguradaMax      DECIMAL(18,2) = NULL,
    @FechaIngresoIni       DATETIME      = NULL,
    @FechaIngresoFin       DATETIME      = NULL,
    @FechaAntiguedadIni    DATETIME      = NULL,
    @FechaAntiguedadFin    DATETIME      = NULL,
    @FechaNacimientoIni    DATETIME      = NULL,
    @FechaNacimientoFin    DATETIME      = NULL,
    @FechaVigenciaIni      DATETIME      = NULL,
    @FechaVigenciaFin      DATETIME      = NULL,
    -- Filtros adicionales del Anexo del documento CREA06
    @Nombre                VARCHAR(150)  = NULL, -- LIKE
    @ApellidoPaterno       VARCHAR(150)  = NULL, -- LIKE
    @ApellidoMaterno       VARCHAR(150)  = NULL, -- LIKE
    @EdadMin               INT           = NULL,
    @EdadMax               INT           = NULL,
    @Top                   INT           = 1000
AS
BEGIN
    SET NOCOUNT ON;

    -- Normalizar CSVs a tablas temporales (solo si vienen poblados)
    DECLARE @tEmpresas    TABLE (Id INT);
    DECLARE @tPerfiles    TABLE (Id INT);
    DECLARE @tOficinas    TABLE (Id INT);
    DECLARE @tAreas       TABLE (Id INT);
    DECLARE @tSexos       TABLE (Id INT);
    DECLARE @tParentescos TABLE (Id INT);
    DECLARE @tPlanes      TABLE (Id INT);
    DECLARE @tCoberturas  TABLE (Id INT);
    DECLARE @tNumEmp      TABLE (NumeroEmpleado VARCHAR(50));

    IF (@IdsEmpresa     IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsEmpresa))) > 0)
        INSERT INTO @tEmpresas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsEmpresa, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsPerfil      IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsPerfil))) > 0)
        INSERT INTO @tPerfiles (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsPerfil, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsOficina     IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsOficina))) > 0)
        INSERT INTO @tOficinas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsOficina, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsArea        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsArea))) > 0)
        INSERT INTO @tAreas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsArea, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsSexo        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsSexo))) > 0)
        INSERT INTO @tSexos (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsSexo, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsParentesco  IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsParentesco))) > 0)
        INSERT INTO @tParentescos (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsParentesco, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsPlan        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsPlan))) > 0)
        INSERT INTO @tPlanes (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsPlan, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsCobertura   IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsCobertura))) > 0)
        INSERT INTO @tCoberturas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsCobertura, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@NumerosEmpleado IS NOT NULL AND LEN(LTRIM(RTRIM(@NumerosEmpleado))) > 0)
        INSERT INTO @tNumEmp (NumeroEmpleado) SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(@NumerosEmpleado, ',') WHERE LTRIM(RTRIM(value)) <> '';

    DECLARE @hayEmpresas    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tEmpresas)    THEN 1 ELSE 0 END;
    DECLARE @hayPerfiles    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tPerfiles)    THEN 1 ELSE 0 END;
    DECLARE @hayOficinas    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tOficinas)    THEN 1 ELSE 0 END;
    DECLARE @hayAreas       BIT = CASE WHEN EXISTS(SELECT 1 FROM @tAreas)       THEN 1 ELSE 0 END;
    DECLARE @haySexos       BIT = CASE WHEN EXISTS(SELECT 1 FROM @tSexos)       THEN 1 ELSE 0 END;
    DECLARE @hayParentescos BIT = CASE WHEN EXISTS(SELECT 1 FROM @tParentescos) THEN 1 ELSE 0 END;
    DECLARE @hayPlanes      BIT = CASE WHEN EXISTS(SELECT 1 FROM @tPlanes)      THEN 1 ELSE 0 END;
    DECLARE @hayCoberturas  BIT = CASE WHEN EXISTS(SELECT 1 FROM @tCoberturas)  THEN 1 ELSE 0 END;
    DECLARE @hayNumEmp      BIT = CASE WHEN EXISTS(SELECT 1 FROM @tNumEmp)      THEN 1 ELSE 0 END;

    SELECT TOP (@Top)
        e.Id                       AS idEmpleado,
        e.EMNumeroEmpleado         AS numeroEmpleado,
        e.EMApellidoPaterno        AS apellidoPaterno,
        e.EMApellidoMaterno        AS apellidoMaterno,
        e.EMNombre1                AS nombre1,
        e.EMNombre2                AS nombre2,
        e.EMFechaNacimiento        AS fechaNacimiento,
        e.EMEdad                   AS edad,
        e.EMFechaIngresoEmpresa    AS fechaIngreso,
        e.EMFechaAntiguedadGmm     AS fechaAntiguedad,
        e.EMIdEmpresa              AS idEmpresa,
        emp.EMRazonSocial          AS razonSocial,
        e.EMIdPerfil               AS idPerfil,
        per.PEDescripcion          AS perfil,
        e.EMOficina                AS idOficina,
        e.EMArea                   AS idArea,
        e.EMSalarioBase            AS salarioBase,
        e.EMIdSexo                 AS idSexo,
        e.EMIdParentesco           AS idParentesco,
        DATEDIFF(MONTH, e.EMFechaIngresoEmpresa, GETDATE()) AS mesesAntiguedad
    FROM ff_Empleado e
        INNER JOIN ff_Empresa emp ON emp.EMidEmpresa = e.EMIdEmpresa
        LEFT  JOIN ff_Perfil  per ON per.PEIdPerfil  = e.EMIdPerfil
    WHERE e.EMIdParentesco = 1  -- titular
      AND e.EMIdEstatus = 1
      AND emp.EMidCorporativo = @IdCorporativo
      -- No tiene solicitud activa en la vigencia
      AND NOT EXISTS (
          SELECT 1
            FROM ff_Solicitud s
           WHERE s.SOIdEmpleado = e.Id
             AND s.SOIdVigencia = @IdVigencia
             AND s.SOIdEstatus IN (1, 10)
             AND s.SOEstatusSolicitud IN (1, 3) -- 1=Autorizada / 3=Por Autorizar (ff_Estatus). FIX 21-jul: antes usaba SOIdEstatus, que se queda en 1 al rechazar y ocultaba de la busqueda a titulares con solicitud Rechazada.
      )
      AND (@hayEmpresas    = 0 OR e.EMIdEmpresa    IN (SELECT Id FROM @tEmpresas))
      AND (@hayPerfiles    = 0 OR e.EMIdPerfil     IN (SELECT Id FROM @tPerfiles))
      AND (@hayOficinas    = 0 OR e.EMOficina      IN (SELECT Id FROM @tOficinas))
      AND (@hayAreas       = 0 OR e.EMArea         IN (SELECT Id FROM @tAreas))
      AND (@haySexos       = 0 OR e.EMIdSexo       IN (SELECT Id FROM @tSexos))
      AND (@hayParentescos = 0 OR e.EMIdParentesco IN (SELECT Id FROM @tParentescos))
      AND (@hayNumEmp      = 0 OR e.EMNumeroEmpleado IN (SELECT NumeroEmpleado FROM @tNumEmp))
      AND (@SalarioMin         IS NULL OR e.EMSalarioBase         >= @SalarioMin)
      AND (@SalarioMax         IS NULL OR e.EMSalarioBase         <= @SalarioMax)
      AND (@FechaIngresoIni    IS NULL OR e.EMFechaIngresoEmpresa >= @FechaIngresoIni)
      AND (@FechaIngresoFin    IS NULL OR e.EMFechaIngresoEmpresa <= @FechaIngresoFin)
      AND (@FechaAntiguedadIni IS NULL OR e.EMFechaAntiguedadGmm  >= @FechaAntiguedadIni)
      AND (@FechaAntiguedadFin IS NULL OR e.EMFechaAntiguedadGmm  <= @FechaAntiguedadFin)
      AND (@FechaNacimientoIni IS NULL OR e.EMFechaNacimiento     >= @FechaNacimientoIni)
      AND (@FechaNacimientoFin IS NULL OR e.EMFechaNacimiento     <= @FechaNacimientoFin)
      -- Anexo: nombre / apellidos / edad
      AND (@Nombre          IS NULL OR LEN(LTRIM(RTRIM(@Nombre))) = 0
            OR e.EMNombre1 LIKE '%' + LTRIM(RTRIM(@Nombre)) + '%'
            OR e.EMNombre2 LIKE '%' + LTRIM(RTRIM(@Nombre)) + '%')
      AND (@ApellidoPaterno IS NULL OR LEN(LTRIM(RTRIM(@ApellidoPaterno))) = 0
            OR e.EMApellidoPaterno LIKE '%' + LTRIM(RTRIM(@ApellidoPaterno)) + '%')
      AND (@ApellidoMaterno IS NULL OR LEN(LTRIM(RTRIM(@ApellidoMaterno))) = 0
            OR e.EMApellidoMaterno LIKE '%' + LTRIM(RTRIM(@ApellidoMaterno)) + '%')
      AND (@EdadMin IS NULL OR e.EMEdad >= @EdadMin)
      AND (@EdadMax IS NULL OR e.EMEdad <= @EdadMax)
      -- Plan: el empleado tiene una opcion del perfil que pertenezca a uno de los planes elegidos
      AND (@hayPlanes      = 0 OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POidPlan IN (SELECT Id FROM @tPlanes)))
      -- Cobertura: en BeFlex la "cobertura" se materializa como ff_PlanOpcion
      AND (@hayCoberturas  = 0 OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND pp.PPidPlanOpcion IN (SELECT Id FROM @tCoberturas)))
      -- Suma asegurada: rango contra POValorSumaAsegurada de las opciones del perfil
      AND (@SumaAseguradaMin IS NULL OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POValorSumaAsegurada >= @SumaAseguradaMin))
      AND (@SumaAseguradaMax IS NULL OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POValorSumaAsegurada <= @SumaAseguradaMax))
      -- Fecha de vigencia: usar columnas reales VIVigenciaIni/VIVigenciaFin
      AND (@FechaVigenciaIni IS NULL OR EXISTS (
            SELECT 1 FROM ff_Vigencia v WHERE v.VIidVigencia = @IdVigencia AND v.VIVigenciaIni >= @FechaVigenciaIni))
      AND (@FechaVigenciaFin IS NULL OR EXISTS (
            SELECT 1 FROM ff_Vigencia v WHERE v.VIidVigencia = @IdVigencia AND v.VIVigenciaFin <= @FechaVigenciaFin))
    ORDER BY e.EMIdEmpresa, e.EMApellidoPaterno, e.EMApellidoMaterno, e.EMNombre1;
END
GO

