/* Prueba reversible de las etapas de insercion temporal y creacion de solicitud. */
SET NOCOUNT ON;
SET XACT_ABORT ON;
DECLARE @Empleado int=7314557,@Empresa int=186,@Origen int=481,@Destino int=633,@Admin int=3043;
DECLARE @Antes int=(SELECT COUNT(*) FROM dbo.ff_Solicitud WHERE SOIdEmpleado=@Empleado AND SOIdVigencia=@Destino AND SOIdEstatus=1);
DECLARE @TC int=(SELECT TOP 1 TCIdTarifaCosto FROM dbo.ff_TarifaCosto_hist
                 WHERE TCIdTarifa=918603 AND TCIdPlanOpcion=1775
                   AND TCIdParentesco=1 AND TCIdSexo=1 AND TCEdad=41 AND TCIdEstatus=1);
DECLARE @Costo money=(SELECT TCPrimaTotal FROM dbo.ff_TarifaCosto_hist WHERE TCIdTarifaCosto=@TC);
DECLARE @XML varchar(max)='<ROOT><TarifaCosto TCidTarifaCosto="'+CONVERT(varchar(20),@TC)
  +'" Costo="'+CONVERT(varchar(30),@Costo)+'" idEmpleado="'+CONVERT(varchar(20),@Empleado)
  +'"></TarifaCosto></ROOT>';

BEGIN TRY
  BEGIN TRANSACTION;
  EXEC dbo.ff_IInsertaPlanesPerfilTmpTestMultivigenciaBF3
       @idEmpleado=@Empleado,@PlanesSeleccionados=@XML,@idEmpresa=@Empresa,@idVigencia=@Origen;
  EXEC dbo.ff_CreateSolicitudTest @IdEmpleado=@Empleado,@idVigencia=@Destino,@IdAdmin=@Admin;
  DECLARE @Durante int=(SELECT COUNT(*) FROM dbo.ff_Solicitud WHERE SOIdEmpleado=@Empleado AND SOIdVigencia=@Destino AND SOIdEstatus=1);
  ROLLBACK TRANSACTION;
  DECLARE @Despues int=(SELECT COUNT(*) FROM dbo.ff_Solicitud WHERE SOIdEmpleado=@Empleado AND SOIdVigencia=@Destino AND SOIdEstatus=1);
  SELECT @TC TarifaCosto,@Antes Antes,@Durante Durante,@Despues Despues,
         CASE WHEN @Durante>@Antes AND @Despues=@Antes THEN 'OK' ELSE 'REVISAR' END Resultado;
END TRY
BEGIN CATCH
  IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
  THROW;
END CATCH;

