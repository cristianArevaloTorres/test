﻿/*
  INSTALACION COMPLETA - Carga Masiva B2/B3 y Defaulteo 1/2/3

  Ejecute este archivo en la base destino desde SSMS.
  Este archivo NO contiene USE [base] para evitar instalar por accidente en
  una base distinta. Confirme DB_NAME() antes de continuar.

  Contiene, en orden, los scripts 001, 002, 003, 004 y 005.
  NO contiene scripts de pruebas, diagnostico, permisos de menu ni datos.
*/
SELECT DB_NAME() AS baseDestino, @@SERVERNAME AS servidor;
GO

/* ==================== INICIO 001_catalogo_y_flujo_carga_masiva.sql ==================== */
/*
  Parametrizacion independiente B2/B3 para carga masiva.
  - Pantalla: decide cual interfaz puede ejecutar cargas.
  - Automatico: decide cual motor deben usar los procesos programados.
  Sin fila configurada, ambas pantallas siguen disponibles y el automatico
  conserva B2 para no romper integraciones existentes.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

SET XACT_ABORT ON;
GO

MERGE dbo.ff_TipoDefaulteo AS destino
USING (VALUES
    (0, 'Seleccionar el tipo de Default', 'Opcion inicial; no ejecuta ningun tipo de defaulteo.'),
    (1, 'Traer selecciones vigencia anterior', 'Replica las selecciones aprobadas de la vigencia anterior y las homologa a la vigencia destino.'),
    (2, 'Plan espejo ultima vigencia', 'Asigna los planes basicos o espejo elegibles de la vigencia destino.'),
    (3, 'Actualizacion de dependientes solicitud anterior', 'Conserva la seleccion previa de la solicitud destino y actualiza la composicion de dependientes.')
) AS origen (TDidTipoDefaulteo, TDNombre, TDDescripcion)
ON destino.TDidTipoDefaulteo = origen.TDidTipoDefaulteo
WHEN MATCHED THEN UPDATE SET
    TDNombre = origen.TDNombre,
    TDDescripcion = origen.TDDescripcion,
    TDidEstatus = 1,
    TDFechaUMod = GETDATE()
WHEN NOT MATCHED THEN INSERT
    (TDidTipoDefaulteo, TDNombre, TDDescripcion, TDidEstatus,
     TDUsuarioAdd, TDFechaAdd, TDFechaUMod)
VALUES
    (origen.TDidTipoDefaulteo, origen.TDNombre, origen.TDDescripcion, 1,
     0, GETDATE(), GETDATE());
GO

IF OBJECT_ID('dbo.bf_ConfiguracionFlujoCargaMasiva', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.bf_ConfiguracionFlujoCargaMasiva
    (
        CFIdEmpresa          INT         NOT NULL,
        CFFlujoPantalla      CHAR(2)     NOT NULL,
        CFFlujoAutomatico    CHAR(2)     NOT NULL,
        CFIdEstatus          INT         NOT NULL CONSTRAINT DF_bf_CargaFlujo_Estatus DEFAULT (1),
        CFUsuarioAdd         INT         NOT NULL,
        CFFechaAdd           DATETIME    NOT NULL CONSTRAINT DF_bf_CargaFlujo_FechaAdd DEFAULT (GETDATE()),
        CFUsuarioUMod        INT         NULL,
        CFFechaUMod          DATETIME    NULL,
        CONSTRAINT PK_bf_ConfiguracionFlujoCargaMasiva PRIMARY KEY (CFIdEmpresa),
        CONSTRAINT CK_bf_CargaFlujo_Pantalla CHECK (CFFlujoPantalla IN ('B2', 'B3')),
        CONSTRAINT CK_bf_CargaFlujo_Automatico CHECK (CFFlujoAutomatico IN ('B2', 'B3')),
        CONSTRAINT CK_bf_CargaFlujo_Estatus CHECK (CFIdEstatus IN (1, 2))
    );
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Obtener
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        @IdEmpresa AS idEmpresa,
        COALESCE(CFFlujoPantalla, 'B3') AS flujoPantalla,
        COALESCE(CFFlujoAutomatico, 'B2') AS flujoAutomatico,
        CONVERT(BIT, CASE WHEN CFIdEmpresa IS NULL THEN 0 ELSE 1 END) AS configurado,
        CFUsuarioAdd AS usuarioAdd,
        CFFechaAdd AS fechaAdd,
        CFUsuarioUMod AS usuarioUMod,
        CFFechaUMod AS fechaUmod
    FROM (SELECT 1 AS n) x
    LEFT JOIN dbo.bf_ConfiguracionFlujoCargaMasiva c
      ON c.CFIdEmpresa = @IdEmpresa
     AND c.CFIdEstatus = 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Guardar
    @IdEmpresa          INT,
    @FlujoPantalla      CHAR(2),
    @FlujoAutomatico    CHAR(2),
    @IdUsuario          INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @FlujoPantalla = UPPER(LTRIM(RTRIM(@FlujoPantalla)));
    SET @FlujoAutomatico = UPPER(LTRIM(RTRIM(@FlujoAutomatico)));

    IF @IdEmpresa <= 0 OR NOT EXISTS (
        SELECT 1 FROM dbo.ff_Empresa WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1)
        THROW 50001, 'La empresa indicada no existe o esta inactiva.', 1;
    IF @IdUsuario <= 0
        THROW 50002, 'El usuario es obligatorio.', 1;
    IF @FlujoPantalla NOT IN ('B2', 'B3') OR @FlujoAutomatico NOT IN ('B2', 'B3')
        THROW 50003, 'Los flujos permitidos son B2 y B3.', 1;

    BEGIN TRANSACTION;
    UPDATE dbo.bf_ConfiguracionFlujoCargaMasiva WITH (UPDLOCK, SERIALIZABLE)
       SET CFFlujoPantalla = @FlujoPantalla,
           CFFlujoAutomatico = @FlujoAutomatico,
           CFIdEstatus = 1,
           CFUsuarioUMod = @IdUsuario,
           CFFechaUMod = GETDATE()
     WHERE CFIdEmpresa = @IdEmpresa;

    IF @@ROWCOUNT = 0
        INSERT dbo.bf_ConfiguracionFlujoCargaMasiva
            (CFIdEmpresa, CFFlujoPantalla, CFFlujoAutomatico, CFIdEstatus,
             CFUsuarioAdd, CFFechaAdd)
        VALUES
            (@IdEmpresa, @FlujoPantalla, @FlujoAutomatico, 1,
             @IdUsuario, GETDATE());
    COMMIT TRANSACTION;

    EXEC dbo.bf_CargaMasivaFlujo_Obtener @IdEmpresa = @IdEmpresa;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_CargaMasivaFlujo_Resolver
    @IdEmpresa INT,
    @Canal     VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Canal = UPPER(LTRIM(RTRIM(@Canal)));

    IF @Canal NOT IN ('PANTALLA', 'AUTOMATICO')
        THROW 50004, 'El canal debe ser PANTALLA o AUTOMATICO.', 1;

    SELECT
        @IdEmpresa AS idEmpresa,
        @Canal AS canal,
        CASE
            WHEN c.CFIdEmpresa IS NULL AND @Canal = 'AUTOMATICO' THEN 'B2'
            WHEN c.CFIdEmpresa IS NULL THEN NULL
            WHEN @Canal = 'PANTALLA' THEN c.CFFlujoPantalla
            ELSE c.CFFlujoAutomatico
        END AS flujo,
        CONVERT(BIT, CASE WHEN c.CFIdEmpresa IS NULL THEN 0 ELSE 1 END) AS configurado
    FROM (SELECT 1 AS n) x
    LEFT JOIN dbo.bf_ConfiguracionFlujoCargaMasiva c
      ON c.CFIdEmpresa = @IdEmpresa
     AND c.CFIdEstatus = 1;
END;
GO

/* ===================== FIN 001_catalogo_y_flujo_carga_masiva.sql ====================== */

/* ==================== INICIO 002_reporte_historico_defaulteo.sql ==================== */
/* Reporte sin la tabla permanente compartida PruebaTemp del procedimiento legado. */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ReporteDefaulteo_Consultar
    @IdEmpresa  INT,
    @FechaInicio DATE,
    @FechaFin    DATE
AS
BEGIN
    SET NOCOUNT ON;

    IF @IdEmpresa <= 0
        THROW 50010, 'La empresa es obligatoria.', 1;
    IF @FechaInicio IS NULL OR @FechaFin IS NULL OR @FechaFin < @FechaInicio
        THROW 50011, 'El rango de fechas no es valido.', 1;

    ;WITH SeleccionesIndividuales AS
    (
        SELECT
            POS.POidEmpresa AS idEmpresa,
            POS.PONumeroEmpleado AS numeroEmpleado,
            POS.POTarifaNeta AS costo,
            POS.POUsuarioAdd AS idUsuario,
            CONVERT(DATE, SO.SOFechaAprovacion) AS fechaDefaulteo
        FROM dbo.ff_PlanOpcionSeleccion POS
        INNER JOIN dbo.ff_Solicitud SO
            ON SO.SOIdSolicitud = POS.POIdSolicitud
        WHERE POS.POIdEmpresa = @IdEmpresa
          AND POS.PODefaulteo = 1
          AND POS.POIdEstatus = 1
          AND SO.SOEstatusSolicitud = 1
          AND POS.POIdParentesco IS NOT NULL
          AND SO.SOFechaAprovacion >= @FechaInicio
          AND SO.SOFechaAprovacion < DATEADD(DAY, 1, @FechaFin)
    ),
    SeleccionesGrupo AS
    (
        SELECT DISTINCT
            POS.POidEmpresa AS idEmpresa,
            POS.PONumeroEmpleado AS numeroEmpleado,
            POS.POTarifaNeta AS costo,
            POS.POUsuarioAdd AS idUsuario,
            CONVERT(DATE, SO.SOFechaAprovacion) AS fechaDefaulteo,
            POS.POIdPlanOpcion,
            POS.POIdGrupoParentesco
        FROM dbo.ff_PlanOpcionSeleccion POS
        INNER JOIN dbo.ff_Solicitud SO
            ON SO.SOIdSolicitud = POS.POIdSolicitud
        WHERE POS.POIdEmpresa = @IdEmpresa
          AND POS.PODefaulteo = 1
          AND POS.POIdEstatus = 1
          AND SO.SOEstatusSolicitud = 1
          AND POS.POIdGrupoParentesco IS NOT NULL
          AND SO.SOFechaAprovacion >= @FechaInicio
          AND SO.SOFechaAprovacion < DATEADD(DAY, 1, @FechaFin)
    ),
    Selecciones AS
    (
        SELECT idEmpresa, numeroEmpleado, costo, idUsuario, fechaDefaulteo
        FROM SeleccionesIndividuales
        UNION ALL
        SELECT idEmpresa, numeroEmpleado, costo, idUsuario, fechaDefaulteo
        FROM SeleccionesGrupo
    )
    SELECT
        S.idEmpresa,
        S.numeroEmpleado,
        LTRIM(RTRIM(
            ISNULL(E.EMApellidoPaterno, '') + ' '
          + ISNULL(E.EMApellidoMaterno, '') + ' '
          + ISNULL(E.EMNombre1, '') + ' '
          + ISNULL(E.EMNombre2, ''))) AS nombreEmpleado,
        CONVERT(DECIMAL(18, 2), SUM(ISNULL(S.costo, 0))) AS costoAnual,
        S.idUsuario,
        S.fechaDefaulteo
    FROM Selecciones S
    INNER JOIN dbo.ff_Empleado E
      ON E.EMIdEmpresa = S.idEmpresa
     AND E.EMNumeroEmpleado = S.numeroEmpleado
     AND E.EMIdParentesco = 1
    GROUP BY
        S.idEmpresa, S.numeroEmpleado, S.idUsuario, S.fechaDefaulteo,
        E.EMApellidoPaterno, E.EMApellidoMaterno, E.EMNombre1, E.EMNombre2
    ORDER BY S.numeroEmpleado, S.fechaDefaulteo;
END;
GO

/* ===================== FIN 002_reporte_historico_defaulteo.sql ====================== */

/* ==================== INICIO 003_seguridad_y_vigencia_defaulteo_avanzado.sql ==================== */
/* Validacion de vigencia y aislamiento de configuraciones por administrador. */
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.bf_DefaulteoAvanzado_ResolverVigencia
    @IdEmpresa INT,
    @IdVigenciaSeleccionada INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdConfiguracion INT;
    DECLARE @IdVigenciaActual INT;
    DECLARE @IdVigenciaAnterior INT;
    DECLARE @EsValida BIT = 0;

    SELECT @IdConfiguracion = EMIdConfiguracion
    FROM dbo.ff_Empresa
    WHERE EMIdEmpresa = @IdEmpresa AND EMIdEstatus = 1;

    IF EXISTS (
        SELECT 1 FROM dbo.ff_Vigencia
        WHERE VIIdVigencia = @IdVigenciaSeleccionada
          AND VIIdConfiguracion = @IdConfiguracion
          AND VIIdEstatus = 1)
    BEGIN
        SET @EsValida = 1;
        SELECT @IdVigenciaAnterior = VIRenovada
        FROM dbo.ff_Vigencia
        WHERE VIIdVigencia = @IdVigenciaSeleccionada;
    END;

    SELECT TOP (1) @IdVigenciaActual = VIIdVigencia
    FROM dbo.ff_Vigencia
    WHERE VIIdConfiguracion = @IdConfiguracion
      AND VIIdEstatus = 1
      AND CONVERT(DATE, GETDATE()) BETWEEN CONVERT(DATE, VIVigenciaIni) AND CONVERT(DATE, VIVigenciaFin)
    ORDER BY VIVigenciaIni DESC, VIIdVigencia DESC;

    IF @IdVigenciaActual IS NULL
        SELECT TOP (1) @IdVigenciaActual = VIIdVigencia
        FROM dbo.ff_Vigencia
        WHERE VIIdConfiguracion = @IdConfiguracion AND VIIdEstatus = 1
        ORDER BY VIVigenciaIni DESC, VIIdVigencia DESC;

    SELECT
        @EsValida AS esValida,
        CONVERT(BIT, CASE WHEN @EsValida = 1 AND @IdVigenciaSeleccionada = @IdVigenciaActual THEN 1 ELSE 0 END) AS esActual,
        @IdVigenciaActual AS idVigenciaActual,
        @IdVigenciaAnterior AS idVigenciaAnterior;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Guardar
    @Id              INT           = NULL,
    @Nombre          VARCHAR(150),
    @Descripcion     VARCHAR(500)  = NULL,
    @IdCorporativo   INT           = NULL,
    @IdEmpresa       INT           = NULL,
    @IdAdmin         INT,
    @FiltrosJson     NVARCHAR(MAX),
    @AccionesJson    NVARCHAR(MAX) = NULL,
    @IdResult        INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @IdResult = 0;

    IF @Id IS NULL OR @Id = 0
    BEGIN
        INSERT INTO dbo.bf_ConfiguracionDefaulteo
            (CDNombre, CDDescripcion, CDIdCorporativo, CDIdEmpresa, CDIdAdmin,
             CDFiltrosJson, CDAccionesJson, CDIdEstatus, CDFechaAdd)
        VALUES
            (@Nombre, @Descripcion, @IdCorporativo, @IdEmpresa, @IdAdmin,
             @FiltrosJson, @AccionesJson, 1, GETDATE());
        SET @IdResult = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.bf_ConfiguracionDefaulteo
           SET CDNombre = @Nombre,
               CDDescripcion = @Descripcion,
               CDIdCorporativo = @IdCorporativo,
               CDIdEmpresa = @IdEmpresa,
               CDFiltrosJson = @FiltrosJson,
               CDAccionesJson = @AccionesJson,
               CDFechaUmod = GETDATE(),
               CDUsuarioUmod = @IdAdmin
         WHERE CDId = @Id
           AND CDIdAdmin = @IdAdmin
           AND CDIdEstatus = 1;
        IF @@ROWCOUNT = 1 SET @IdResult = @Id;
    END;
END;
GO

CREATE OR ALTER PROCEDURE dbo.bf_ConfiguracionDefaulteo_Eliminar
    @Id      INT,
    @IdAdmin INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.bf_ConfiguracionDefaulteo
       SET CDIdEstatus = 2,
           CDFechaUmod = GETDATE(),
           CDUsuarioUmod = @IdAdmin
     WHERE CDId = @Id
       AND CDIdAdmin = @IdAdmin
       AND CDIdEstatus = 1;
END;
GO

/* ===================== FIN 003_seguridad_y_vigencia_defaulteo_avanzado.sql ====================== */

/* ==================== INICIO 004_compatibilidad_idcorporativo_inserta_planes.sql ==================== */
/*
  Corrige la incompatibilidad de firma detectada en la cadena de defaulteo:
  ff_IInsertaPlanesFlexiblesTmpCreditos requiere @IdCorporativo como parametro 7,
  pero dos callers legados instalados lo invocan con seis parametros.

  El parche conserva la definicion instalada y solo sustituye esa invocacion.
  Es idempotente y falla de forma explicita si la firma esperada no existe.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Objetos TABLE (Nombre sysname PRIMARY KEY);
INSERT @Objetos(Nombre) VALUES
 ('ff_IInsertaPlanesFlexiblesTmp'),
 ('ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3');

DECLARE @Nombre sysname,@Def nvarchar(max),@PosProc int,@CallOld nvarchar(500),@CallNew nvarchar(1000);
DECLARE C CURSOR LOCAL FAST_FORWARD FOR SELECT Nombre FROM @Objetos ORDER BY Nombre;
OPEN C;
FETCH NEXT FROM C INTO @Nombre;
WHILE @@FETCH_STATUS=0
BEGIN
  SET @Def=OBJECT_DEFINITION(OBJECT_ID(N'dbo.'+@Nombre,N'P'));
  IF @Def IS NULL
    THROW 51501,'No existe uno de los procedimientos caller que debe corregirse.',1;

  IF CHARINDEX('IdCorporativoCompat',@Def)=0
  BEGIN
    SET @CallOld=N'exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp';
    IF CHARINDEX(@CallOld,@Def)=0
      THROW 51502,'No se encontro la invocacion de seis parametros esperada. Revise la version del procedimiento.',1;

    SET @CallNew=N'DECLARE @IdCorporativoCompat int =
      (SELECT TOP (1) EMIdCorporativo FROM dbo.ff_Empresa WHERE EMIdEmpresa=@idEmpresa);
exec dbo.ff_IInsertaPlanesFlexiblesTmpCreditos @idEmpleado,@idEmpresa,@NUMEROEMPLEADO,@idPerfil,@IdVigencia,@idplanopcionselecciontmp,@IdCorporativoCompat';
    SET @Def=REPLACE(@Def,@CallOld,@CallNew);

    SET @PosProc=CHARINDEX('PROCEDURE',UPPER(@Def));
    IF @PosProc=0 THROW 51503,'La definicion no contiene PROCEDURE.',1;
    SET @Def=STUFF(@Def,1,@PosProc-1,'ALTER ');
    EXEC sys.sp_executesql @Def;
  END;

  FETCH NEXT FROM C INTO @Nombre;
END;
CLOSE C;
DEALLOCATE C;

SELECT P.name,
       CASE WHEN OBJECT_DEFINITION(P.object_id) LIKE '%IdCorporativoCompat%'
            THEN 'OK' ELSE 'REVISAR' END Resultado
FROM sys.procedures P
WHERE P.name IN('ff_IInsertaPlanesFlexiblesTmp','ff_IInsertaPlanesFlexiblesTmpTestMultivigenciaBF3')
ORDER BY P.name;

/* ===================== FIN 004_compatibilidad_idcorporativo_inserta_planes.sql ====================== */

GO
/* =============== INICIO 005_exclusion_solicitudes_generadas_defaulteo.sql =============== */
/*
  Evita que el listado de Defaulteo muestre titulares que ya tienen una
  solicitud Activa o Por Autorizar en la vigencia seleccionada.

  Tambien evita duplicados en la operacion guiada: si existen solicitudes
  rechazadas/canceladas, solo se muestra la ultima como referencia. Esos
  titulares siguen siendo reprocesables por regla de negocio.
*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE [dbo].[bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado]
(
	@IdsEmpresas varchar(max)
	,@IdAdministrador INT
	,@idAtributo1 varchar(100) 
	,@idAtributo2 varchar(100) 
	,@idTipoOperador1 varchar(100) 
	,@idTipoOperador2 varchar(100) 
	,@parametroBusqueda1 varchar(max) 
	,@parametroBusqueda2 varchar(max) 
	,@BusquedaAvanzada INT = 1
	,@idTipoOperadorAvanzado varchar(100) 
	,@idPerfiles varchar(max)
	,@Vigencia int
)
AS

BEGIN

	DECLARE  
		@campo varchar(70) 
		,@IdEmpleados_str varchar(max) = ''
		,@sql_str nvarchar(max) = ''
		,@sql_empresas nvarchar(max) = ''
	DECLARE @TablaSol TABLE(IDEmpleado INT)
	DECLARE @Empresas AS TABLE (ID INT)

	INSERT INTO @Empresas SELECT LTRIM(rtrim(value)) FROM STRING_SPLIT(@IdsEmpresas, ',')

	SET @sql_str = N'SELECT DISTINCT  
		EMPL.Id 
		,CAST(0 AS BIT) AS seleccion 
		,EMPL.EMIdEmpresa 
		,EMPL.EMNumeroEmpleado as numEmpleado 
		,P.EMNombre as nombreEmpresa 
		,ff_Perfil.PEDescripcion as perfil 
		,ff_Perfil.PEIdPerfil as idPerfil 
		,EMPL.EMApellidoPaterno as ApellidoPaterno  
		,EMPL.EMApellidoMaterno as ApellidoMaterno 
		,EMPL.EMNombre1 as Nombre1 
		,EMPL.EMNombre2 as Nombre2 
		,EMPL.EMFechaNacimiento as fechaNacimiento 
		,EMPL.EMEdad as edad 
		,ff_Parentesco.PADescripcion as parentesco 
		,EMPL.EMIdEmpresa as idEmpresa 
		,CASE WHEN ULT.SONumeroSolicitud IS NULL THEN ''''
              ELSE CONCAT(ULT.SONumeroSolicitud, ''-'', ULT.SOAnexoSolicitud)
         END AS NumeroSolicitud 
	FROM
        ff_Empleado EMPL WITH(NOLOCK)
        OUTER APPLY
        (
            SELECT TOP (1)
                SULT.SONumeroSolicitud,
                SULT.SOAnexoSolicitud
            FROM dbo.ff_Solicitud SULT WITH(NOLOCK)
            WHERE SULT.SOIdEmpleado = EMPL.Id
              AND SULT.SOIdVigencia = '+CAST(@Vigencia AS VARCHAR(max))+'
            ORDER BY SULT.SOFechaAdd DESC, SULT.SOIdSolicitud DESC
        ) ULT
        INNER JOIN ff_Perfil  
			ON ff_Perfil.PEIdPerfil = EMPL.EMidperfil 
			AND ff_Perfil.PEIdPerfil IN ('+@idPerfiles+') 
		INNER JOIN ff_Parentesco  
			ON ff_Parentesco.PAidParentesco = EMPL.EMIdParentesco  
		INNER JOIN ff_Empresa P  
			ON P.EMidEmpresa = EMPL.EMIdEmpresa 
	WHERE  '

	SET @sql_empresas = N' (EMPL.EMIdEmpresa in ('+@IdsEmpresas+')  
			AND EMPL.EMNumeroEmpleado NOT LIKE ''PR%'' 
			AND EMPL.EMIdEstatus = 1  
			AND EMPL.EMIdTitular = 1 '
			+ 
			' AND NOT EXISTS (
                    SELECT 1
                    FROM dbo.ff_Solicitud SOLACT WITH(NOLOCK)
                    WHERE SOLACT.SOIdEmpleado = EMPL.Id
                      AND SOLACT.SOIdEstatus IN (1,10)
                      AND SOLACT.SOEstatusSolicitud IN (1,3)
                      AND SOLACT.SOIdVigencia = '+CAST(@Vigencia AS VARCHAR(max))+'
                      AND SOLACT.SOIdEmpresa IN ('+@IdsEmpresas+')
                ) '

	-- Insertar filtros para empleado
	DECLARE
		@sql_where1 VARCHAR(MAX) = ''
		,@sql_where2 VARCHAR(MAX) = ''

	IF( LTRIM(RTRIM(@parametroBusqueda1)) = '')
	BEGIN
		SET @sql_where1 = @sql_empresas + ' )';
	END
	ELSE
	BEGIN
		set @sql_where1 = @sql_empresas + ' AND EMPL.' + @idAtributo1 +
			(CASE WHEN @idTipoOperador1 = 'igual' THEN  ' = ''' + @parametroBusqueda1 + ''''
				WHEN @idTipoOperador1 = 'contiene' THEN ' LIKE ''%' + @parametroBusqueda1 + '%'''
				WHEN @idTipoOperador1 = 'noigual' THEN ' <> ''' + UPPER(@parametroBusqueda1) + ''''
				WHEN @idTipoOperador1 = 'iniciapor' THEN ' LIKE ''' + @parametroBusqueda1 + '%'''
				WHEN @idTipoOperador1 = 'terminapor' THEN ' LIKE ''%' + @parametroBusqueda1 + ''''
				WHEN @idTipoOperador1 = 'nocontiene' THEN ' NOT LIKE ''%' + @parametroBusqueda1 + '%'''
				ELSE ' LIKE ''%' + @parametroBusqueda1 + '%'''
			END)
			+ ' ) '
		-- PRINT @sql_where1
		IF @BusquedaAvanzada = 1
		BEGIN
			set @sql_where2 = ' ' + @idTipoOperadorAvanzado + @sql_empresas +  ' AND EMPL.' + @idAtributo2 +
				(CASE WHEN @idTipoOperador2 = 'igual' THEN  ' = ''' + @parametroBusqueda2 + ''''
					WHEN @idTipoOperador2 = 'contiene' THEN ' LIKE ''%' + @parametroBusqueda2+ '%'''
					WHEN @idTipoOperador2 = 'noigual' THEN ' <> ''' + @parametroBusqueda2 + ''''
					WHEN @idTipoOperador2 = 'iniciapor' THEN ' LIKE ''' + @parametroBusqueda2 + '%'''
					WHEN @idTipoOperador2 = 'terminapor' THEN ' LIKE ''%' + @parametroBusqueda2 + ''''
					WHEN @idTipoOperador2 = 'nocontiene' THEN ' NOT LIKE ''%' + @parametroBusqueda2 + '%'''
					ELSE ' LIKE ''%' + @parametroBusqueda2 + '%'''
				END)
				+ ' ) '
		END
		-- PRINT @sql_where2
	END

	SET @sql_str= @sql_str + @sql_where1 + @sql_where2
	PRINT @sql_str

	EXECUTE sp_EXECUTESQL @sql_str 

END
GO

CREATE OR ALTER PROCEDURE [dbo].[bf_DefaulteoAvanzado_Buscar]
    @IdCorporativo         INT,
    @IdVigencia            INT,
    @IdsEmpresa            NVARCHAR(MAX) = NULL, -- CSV
    @IdsPerfil             NVARCHAR(MAX) = NULL, -- CSV
    @IdsOficina            NVARCHAR(MAX) = NULL, -- CSV
    @IdsArea               NVARCHAR(MAX) = NULL, -- CSV
    @IdsSexo               NVARCHAR(MAX) = NULL, -- CSV
    @IdsParentesco         NVARCHAR(MAX) = NULL, -- CSV
    @IdsPlan               NVARCHAR(MAX) = NULL, -- CSV (plan asignado actual)
    @IdsCobertura          NVARCHAR(MAX) = NULL, -- CSV
    @NumerosEmpleado       NVARCHAR(MAX) = NULL, -- CSV
    @SalarioMin            DECIMAL(18,2) = NULL,
    @SalarioMax            DECIMAL(18,2) = NULL,
    @SumaAseguradaMin      DECIMAL(18,2) = NULL,
    @SumaAseguradaMax      DECIMAL(18,2) = NULL,
    @FechaIngresoIni       DATETIME      = NULL,
    @FechaIngresoFin       DATETIME      = NULL,
    @FechaAntiguedadIni    DATETIME      = NULL,
    @FechaAntiguedadFin    DATETIME      = NULL,
    @FechaNacimientoIni    DATETIME      = NULL,
    @FechaNacimientoFin    DATETIME      = NULL,
    @FechaVigenciaIni      DATETIME      = NULL,
    @FechaVigenciaFin      DATETIME      = NULL,
    -- Filtros adicionales del Anexo del documento CREA06
    @Nombre                VARCHAR(150)  = NULL, -- LIKE
    @ApellidoPaterno       VARCHAR(150)  = NULL, -- LIKE
    @ApellidoMaterno       VARCHAR(150)  = NULL, -- LIKE
    @EdadMin               INT           = NULL,
    @EdadMax               INT           = NULL,
    @Top                   INT           = 1000
AS
BEGIN
    SET NOCOUNT ON;

    -- Normalizar CSVs a tablas temporales (solo si vienen poblados)
    DECLARE @tEmpresas    TABLE (Id INT);
    DECLARE @tPerfiles    TABLE (Id INT);
    DECLARE @tOficinas    TABLE (Id INT);
    DECLARE @tAreas       TABLE (Id INT);
    DECLARE @tSexos       TABLE (Id INT);
    DECLARE @tParentescos TABLE (Id INT);
    DECLARE @tPlanes      TABLE (Id INT);
    DECLARE @tCoberturas  TABLE (Id INT);
    DECLARE @tNumEmp      TABLE (NumeroEmpleado VARCHAR(50));

    IF (@IdsEmpresa     IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsEmpresa))) > 0)
        INSERT INTO @tEmpresas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsEmpresa, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsPerfil      IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsPerfil))) > 0)
        INSERT INTO @tPerfiles (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsPerfil, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsOficina     IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsOficina))) > 0)
        INSERT INTO @tOficinas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsOficina, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsArea        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsArea))) > 0)
        INSERT INTO @tAreas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsArea, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsSexo        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsSexo))) > 0)
        INSERT INTO @tSexos (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsSexo, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsParentesco  IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsParentesco))) > 0)
        INSERT INTO @tParentescos (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsParentesco, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsPlan        IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsPlan))) > 0)
        INSERT INTO @tPlanes (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsPlan, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@IdsCobertura   IS NOT NULL AND LEN(LTRIM(RTRIM(@IdsCobertura))) > 0)
        INSERT INTO @tCoberturas (Id) SELECT TRY_CAST(LTRIM(RTRIM(value)) AS INT) FROM STRING_SPLIT(@IdsCobertura, ',') WHERE LTRIM(RTRIM(value)) <> '';
    IF (@NumerosEmpleado IS NOT NULL AND LEN(LTRIM(RTRIM(@NumerosEmpleado))) > 0)
        INSERT INTO @tNumEmp (NumeroEmpleado) SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(@NumerosEmpleado, ',') WHERE LTRIM(RTRIM(value)) <> '';

    DECLARE @hayEmpresas    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tEmpresas)    THEN 1 ELSE 0 END;
    DECLARE @hayPerfiles    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tPerfiles)    THEN 1 ELSE 0 END;
    DECLARE @hayOficinas    BIT = CASE WHEN EXISTS(SELECT 1 FROM @tOficinas)    THEN 1 ELSE 0 END;
    DECLARE @hayAreas       BIT = CASE WHEN EXISTS(SELECT 1 FROM @tAreas)       THEN 1 ELSE 0 END;
    DECLARE @haySexos       BIT = CASE WHEN EXISTS(SELECT 1 FROM @tSexos)       THEN 1 ELSE 0 END;
    DECLARE @hayParentescos BIT = CASE WHEN EXISTS(SELECT 1 FROM @tParentescos) THEN 1 ELSE 0 END;
    DECLARE @hayPlanes      BIT = CASE WHEN EXISTS(SELECT 1 FROM @tPlanes)      THEN 1 ELSE 0 END;
    DECLARE @hayCoberturas  BIT = CASE WHEN EXISTS(SELECT 1 FROM @tCoberturas)  THEN 1 ELSE 0 END;
    DECLARE @hayNumEmp      BIT = CASE WHEN EXISTS(SELECT 1 FROM @tNumEmp)      THEN 1 ELSE 0 END;

    SELECT TOP (@Top)
        e.Id                       AS idEmpleado,
        e.EMNumeroEmpleado         AS numeroEmpleado,
        e.EMApellidoPaterno        AS apellidoPaterno,
        e.EMApellidoMaterno        AS apellidoMaterno,
        e.EMNombre1                AS nombre1,
        e.EMNombre2                AS nombre2,
        e.EMFechaNacimiento        AS fechaNacimiento,
        e.EMEdad                   AS edad,
        e.EMFechaIngresoEmpresa    AS fechaIngreso,
        e.EMFechaAntiguedadGmm     AS fechaAntiguedad,
        e.EMIdEmpresa              AS idEmpresa,
        emp.EMRazonSocial          AS razonSocial,
        e.EMIdPerfil               AS idPerfil,
        per.PEDescripcion          AS perfil,
        e.EMOficina                AS idOficina,
        e.EMArea                   AS idArea,
        e.EMSalarioBase            AS salarioBase,
        e.EMIdSexo                 AS idSexo,
        e.EMIdParentesco           AS idParentesco,
        DATEDIFF(MONTH, e.EMFechaIngresoEmpresa, GETDATE()) AS mesesAntiguedad
    FROM ff_Empleado e
        INNER JOIN ff_Empresa emp ON emp.EMidEmpresa = e.EMIdEmpresa
        LEFT  JOIN ff_Perfil  per ON per.PEIdPerfil  = e.EMIdPerfil
    WHERE e.EMIdParentesco = 1  -- titular
      AND e.EMIdEstatus = 1
      AND emp.EMidCorporativo = @IdCorporativo
      -- No tiene solicitud activa en la vigencia
      AND NOT EXISTS (
          SELECT 1
            FROM ff_Solicitud s
           WHERE s.SOIdEmpleado = e.Id
             AND s.SOIdVigencia = @IdVigencia
             AND s.SOIdEstatus IN (1, 10)
             AND s.SOEstatusSolicitud IN (1, 3) -- 1=Autorizada / 3=Por Autorizar (ff_Estatus). FIX 21-jul: antes usaba SOIdEstatus, que se queda en 1 al rechazar y ocultaba de la busqueda a titulares con solicitud Rechazada.
      )
      AND (@hayEmpresas    = 0 OR e.EMIdEmpresa    IN (SELECT Id FROM @tEmpresas))
      AND (@hayPerfiles    = 0 OR e.EMIdPerfil     IN (SELECT Id FROM @tPerfiles))
      AND (@hayOficinas    = 0 OR e.EMOficina      IN (SELECT Id FROM @tOficinas))
      AND (@hayAreas       = 0 OR e.EMArea         IN (SELECT Id FROM @tAreas))
      AND (@haySexos       = 0 OR e.EMIdSexo       IN (SELECT Id FROM @tSexos))
      AND (@hayParentescos = 0 OR e.EMIdParentesco IN (SELECT Id FROM @tParentescos))
      AND (@hayNumEmp      = 0 OR e.EMNumeroEmpleado IN (SELECT NumeroEmpleado FROM @tNumEmp))
      AND (@SalarioMin         IS NULL OR e.EMSalarioBase         >= @SalarioMin)
      AND (@SalarioMax         IS NULL OR e.EMSalarioBase         <= @SalarioMax)
      AND (@FechaIngresoIni    IS NULL OR e.EMFechaIngresoEmpresa >= @FechaIngresoIni)
      AND (@FechaIngresoFin    IS NULL OR e.EMFechaIngresoEmpresa <= @FechaIngresoFin)
      AND (@FechaAntiguedadIni IS NULL OR e.EMFechaAntiguedadGmm  >= @FechaAntiguedadIni)
      AND (@FechaAntiguedadFin IS NULL OR e.EMFechaAntiguedadGmm  <= @FechaAntiguedadFin)
      AND (@FechaNacimientoIni IS NULL OR e.EMFechaNacimiento     >= @FechaNacimientoIni)
      AND (@FechaNacimientoFin IS NULL OR e.EMFechaNacimiento     <= @FechaNacimientoFin)
      -- Anexo: nombre / apellidos / edad
      AND (@Nombre          IS NULL OR LEN(LTRIM(RTRIM(@Nombre))) = 0
            OR e.EMNombre1 LIKE '%' + LTRIM(RTRIM(@Nombre)) + '%'
            OR e.EMNombre2 LIKE '%' + LTRIM(RTRIM(@Nombre)) + '%')
      AND (@ApellidoPaterno IS NULL OR LEN(LTRIM(RTRIM(@ApellidoPaterno))) = 0
            OR e.EMApellidoPaterno LIKE '%' + LTRIM(RTRIM(@ApellidoPaterno)) + '%')
      AND (@ApellidoMaterno IS NULL OR LEN(LTRIM(RTRIM(@ApellidoMaterno))) = 0
            OR e.EMApellidoMaterno LIKE '%' + LTRIM(RTRIM(@ApellidoMaterno)) + '%')
      AND (@EdadMin IS NULL OR e.EMEdad >= @EdadMin)
      AND (@EdadMax IS NULL OR e.EMEdad <= @EdadMax)
      -- Plan: el empleado tiene una opcion del perfil que pertenezca a uno de los planes elegidos
      AND (@hayPlanes      = 0 OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POidPlan IN (SELECT Id FROM @tPlanes)))
      -- Cobertura: en BeFlex la "cobertura" se materializa como ff_PlanOpcion
      AND (@hayCoberturas  = 0 OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND pp.PPidPlanOpcion IN (SELECT Id FROM @tCoberturas)))
      -- Suma asegurada: rango contra POValorSumaAsegurada de las opciones del perfil
      AND (@SumaAseguradaMin IS NULL OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POValorSumaAsegurada >= @SumaAseguradaMin))
      AND (@SumaAseguradaMax IS NULL OR EXISTS (
            SELECT 1
              FROM ff_PlanOpcionPerfil pp
              INNER JOIN ff_PlanOpcion po ON po.POidPlanOpcion = pp.PPidPlanOpcion
             WHERE pp.PPidPerfil = e.EMIdPerfil
               AND pp.PPidEstatus = 1
               AND po.POValorSumaAsegurada <= @SumaAseguradaMax))
      -- Fecha de vigencia: usar columnas reales VIVigenciaIni/VIVigenciaFin
      AND (@FechaVigenciaIni IS NULL OR EXISTS (
            SELECT 1 FROM ff_Vigencia v WHERE v.VIidVigencia = @IdVigencia AND v.VIVigenciaIni >= @FechaVigenciaIni))
      AND (@FechaVigenciaFin IS NULL OR EXISTS (
            SELECT 1 FROM ff_Vigencia v WHERE v.VIidVigencia = @IdVigencia AND v.VIVigenciaFin <= @FechaVigenciaFin))
    ORDER BY e.EMIdEmpresa, e.EMApellidoPaterno, e.EMApellidoMaterno, e.EMNombre1;
END
GO



/* ================= FIN 005_exclusion_solicitudes_generadas_defaulteo.sql ================= */
