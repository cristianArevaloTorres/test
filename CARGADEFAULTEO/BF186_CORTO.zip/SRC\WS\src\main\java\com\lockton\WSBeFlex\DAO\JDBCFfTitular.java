package com.lockton.WSBeFlex.DAO;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lockton.WSBeFlex.POJO.Especiales.*;
import com.lockton.WSBeFlex.POJO.FfEmpleado;
import com.lockton.WSBeFlex.POJO.FfEmpresa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import com.lockton.WSBeFlex.POJO.FfRol;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lockton.WSBeFlex.PlantillasTitulares;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.util.LinkedCaseInsensitiveMap;






/**
 * <p>
 * Esta clase implementa los métodos definidos en la interface
 * {@link com.lockton.WSBeFlex.DAO.FfCPlantillaTitularesDAO}
 * </p>
 * <p>
 * La anotacion @Repository nos
 * indica que es un Data Access Object, por lo tanto, es en esta clase donde se
 * realizan las sentencias CRUD.
 * </p>
 * <p>
 * Se utiliza un objeto de la clase JdbcTemplate
 * que ejecuta el flujo de trabajo central de JDBC, dejando el código de la
 * aplicación para proporcionar SQL y extraer resultados. Esta clase ejecuta
 * consultas o actualizaciones de SQL, inicia la iteración sobre ResultSets y
 * captura las excepciones JDBC.
 *
 * @see <a href=
 *      "https://docs.spring.io/spring/docs/current/javadoc-api/org/springframework/jdbc/core/JdbcTemplate.html">Class
 *      JdbcTemplate</a>
 * </p>
 *
 * @author Andrea Hernández / BigPink
 * @since 1.0
 */
@Repository
public class JDBCFfTitular implements FfTitularDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	JDBCFfEmpresa emp_dao;

	@Autowired
	FfCObtenPerfilDAO pef_dao;

	@Autowired
	FfEmpleadoDAO empleado;

	private final ObjectMapper objectMapper = new ObjectMapper();

	@SuppressWarnings("unchecked")
	@Override

	public List<Object> consultarPlantilla(Integer IdEmpresa, String Pantalla,
										   int IdPerfil, String busca,String campoBusca,int idAdm) {

		String nombreSP = "";
		for(PlantillasTitulares plantilla: PlantillasTitulares.values()){
			if(plantilla.getNombrePantalla().equals(Pantalla)){
				nombreSP = plantilla.getNombreSP();
			}
		}

		if(PlantillasTitulares.CONSULTA_BAJA_TITULARES.getNombreSP().equals(nombreSP)){
			busca = "%".concat(busca).concat("%");
		}

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		if(PlantillasTitulares.CONSULTA_BAJA_TITULARES.getNombreSP().equals(nombreSP)){
			if(emp_dao.isCorporativo(IdEmpresa)){
				inParamMap.put("IdEmpresa", "");
				inParamMap.put("IdCorporativo", IdEmpresa);
			}else{
				inParamMap.put("IdEmpresa", IdEmpresa);
				inParamMap.put("IdCorporativo", "");
			}
		} else {
			inParamMap.put("IdEmpresa", IdEmpresa);
		}
		inParamMap.put("Busca", busca);

		if(PlantillasTitulares.CONSULTA_BAJA_TITULARES.getNombreSP().equals(nombreSP)){
			inParamMap.put("Pantalla",  "ff_Admi_Consulta.aspx");
		}
		else{
			inParamMap.put("Pantalla", Pantalla);
		}
		inParamMap.put("IdPerfil", IdPerfil);
		inParamMap.put("CampoBusca", campoBusca);
		inParamMap.put("IdAdministrador", idAdm);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		listSP = listSP.isEmpty() ? listSP : new ArrayList<Object>((Collection<? extends Object>) listSP.get(0));
		if(PlantillasTitulares.CONSULTA_BAJA_TITULARES_FD.getNombreSP().equalsIgnoreCase(nombreSP)
				&& ((Map<String,String>)listSP.get(0)).containsKey("_c_perfil")){
			List<FfCObtenPerfil> perfiles = emp_dao.isCorporativo(IdEmpresa) ?
					pef_dao.obtenerPerfilesPorCorporativo(IdEmpresa, true) :
					pef_dao.obtenerPerfilesPorEmpresa(IdEmpresa, true);
			listSP.forEach((titular) -> {
				Map<String,Object> titularMap = (Map<String,Object>)titular;
				for (FfCObtenPerfil perfil : perfiles) {
					if (titularMap.get("_c_perfil") != null &&
							perfil.getIdPerfil() == Integer.parseInt(titularMap.get("_c_perfil").toString())) {
						titularMap.put("Perfil", perfil.getNombrePerfil());
						break;
					}
				}
				//titularMap.put("Perfil", perfiles.stream()
				//    .filter(perfil -> perfil.getIdPerfil().equals(Integer.valueOf(titularMap.get("_c_perfil").toString())))
				//    .findFirst()
				//    .get().getNombrePerfil());
			});
			// listSP = hardSorting(listSP);
		}
		if ( !listSP.isEmpty() && ((Map<String,String>)listSP.get(0)).containsKey("Perfil") ) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((registro) -> {
				if ( !((Map<String,String>)registro).get("Perfil").toString().equalsIgnoreCase("Administrador")) {
					tmp.add(registro);
				}
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		// Sorting teaks
		if (!listSP.isEmpty() && (PlantillasTitulares.CONSULTA_BAJA_TITULARES_FD.getNombreSP().equalsIgnoreCase(nombreSP))) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((titular)->{
				Map<String,Object> titularMap = (Map<String,Object>)titular;
				LinkedCaseInsensitiveMap<String> lcim = new LinkedCaseInsensitiveMap<String>();
				if (titularMap.size() > 1) {
					titularMap.forEach((k, v) -> {
						String key = k.trim();
						if (!"Empresa".equals(key) && !key.contains("_c_")) {
							lcim.putIfAbsent(key, v != null ? v.toString() : null);
							lcim.putIfAbsent("Empresa", titularMap.get("Empresa").toString());
						} else if (!"Empresa".equals(key)) {
							lcim.putIfAbsent(key, v != null ? v.toString() : null);
							if ("_c_EMNumeroEmpleado".equals(key)) {
								lcim.putIfAbsent("_c_emIdEmpresa", titularMap.get("_c_emIdEmpresa") != null ? titularMap.get("_c_emIdEmpresa").toString() : null);
								lcim.putIfAbsent("Número Empleado", v != null ? v.toString() : null);
							}
						}
					});
				}
				tmp.add(lcim);
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		return listSP;
	}

	public List<Object> obtenerIndicadoresPorRelacion(String idEmpresa){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_ConsultaIndicadoresporRelacion");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdEmpresa", idEmpresa);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}





	public List<Object> obtenerEmpresasVigenciasPorCorporativo(int idCorporativo){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_get2VigenciasPorCorporativo");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdEmpresa", idCorporativo);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}
	public List<Object> obtenerconfiguracionEnvio(int idCorporativo){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_ObtenerConfiguracionEnvio");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdCorporativo", idCorporativo);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}
	public List<Object> obtenerPlantillaYnotificacionCorreo(String idCorporativo, String idAdm){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_GetConfiguracionNotificacionBycorporativo");
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		int _idCorporativo = Integer.valueOf(idCorporativo);
		int _idAdm = Integer.valueOf(idAdm);


		inParamMap.put("IdCorporativo", _idCorporativo);
		inParamMap.put("IdAdministrador", _idAdm);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);



		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}
	public List<Object> insertarConfiguracionNotificacionEmpresa(String idEmpresa , String idTipoNotificacionCorreo, String idPlantilla, String numeroDias,
																 String orden, String idUsuario){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_InsertarConfiguracionNotificacionEmpresa");
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		int _idEmpresa = Integer.valueOf(idEmpresa);
		int _idTipoNotificacionCorreo = Integer.valueOf(idTipoNotificacionCorreo);
		int _idPlantilla = Integer.valueOf(idPlantilla);
		int _numeroDias = Integer.valueOf(numeroDias);
		int _orden = Integer.valueOf(orden);
		int _idUsuario = Integer.valueOf(idUsuario);

		inParamMap.put("IdEmpresa", _idEmpresa);
		inParamMap.put("IdTipoNotificacionCorreo", _idTipoNotificacionCorreo);
		inParamMap.put("IdPlantilla", _idPlantilla);
		inParamMap.put("NumeroDias", _numeroDias);
		inParamMap.put("Orden", _orden);
		inParamMap.put("IdUsuario", _idUsuario);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}


	public List<Object> insertarConfiguracionEnvio(String idConfiguracionNotificacion , String idVigencia, String diaInicial, boolean envioAdministradores,
												   String idPeriodicidad){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_InsertaConfiguracionEnvio");
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		int _idConfiguracionNotificacion = Integer.valueOf(idConfiguracionNotificacion);
		int _idVigencia = Integer.valueOf(idVigencia);
		String _diaInicial = diaInicial;
		boolean _envioAdministradores = envioAdministradores;
		int _idPeriodicidad = Integer.valueOf(idPeriodicidad);

		inParamMap.put("IdConfiguracionNotificacion", _idConfiguracionNotificacion);
		inParamMap.put("IdVigencia", _idVigencia);
		inParamMap.put("DiaInicial", _diaInicial);
		inParamMap.put("EnvioAdministradores", _envioAdministradores);
		inParamMap.put("IdPeriodicidad", _idPeriodicidad);



		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}
	public List<Object> eliminarConfiguracionMantenimiento(String idConfiguracionEnvio ){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_EliminarConfiguracionEnvioMantenimiento");
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		int _idConfiguracionEnvio = Integer.valueOf(idConfiguracionEnvio);


		inParamMap.put("IdConfiguracionEnvio", _idConfiguracionEnvio);




		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}



	public List<Object> insertarConfiguracionMantenimiento(String idConfiguracionEnvio, String fecha ){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_InsertaConfiguracionEnvioMantenimiento");
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		int _idConfiguracionEnvio = Integer.valueOf(idConfiguracionEnvio);
		String _fecha = fecha;


		inParamMap.put("IdConfiguracionEnvio", _idConfiguracionEnvio);
		inParamMap.put("Fecha", _fecha);




		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}
	public List<Object> eliminarConfiguracion(String idConfiguracionEnvio){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_BajaConfiguracionEnvio");
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		int _idConfiguracionEnvio = Integer.valueOf(idConfiguracionEnvio);




		inParamMap.put("IdConfiguracionEnvio", _idConfiguracionEnvio);





		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}
	public List<Object> editarConfiguracion(String idEmpresa , String idCorporativo){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_ObtenerPantallaConfiguracionEnvio");
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		if (!"0".equals(idEmpresa) ){
			inParamMap.put("IdCorporativo",null);
			inParamMap.put("idempresa",Integer.parseInt( idEmpresa) );
		}
		if(!"0".equals(idCorporativo)){
			inParamMap.put("IdCorporativo", Integer.parseInt(idCorporativo));
			inParamMap.put("idempresa",null );
		}
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}

	private List<Object> hardSorting(List<Object> inputList){
		List<Object> newList = new ArrayList();
		inputList.forEach((titular) -> {
			Map<String,Object> newMap = new LinkedHashMap<>();
			Map<String,Object> titularMap = (Map<String,Object>)titular;
			List<String> keys = new ArrayList(titularMap.keySet());
			for(int i = 0; keys.size()-1 > i; i++){
				if(i == 6){
					newMap.put(keys.get(keys.size()-1).equals("EMIdPerfilNombre") ?
							"Perfil" : keys.get(keys.size()-1), titularMap.get(keys.get(keys.size()-1)));
				}

				newMap.put(keys.get(i), titularMap.get(keys.get(i)));
			}
			newList.add(newMap);
		});
		// Collections.sort(newList, mapComparator);
		return newList;
	}


	public List<Object> obtenerLeyendaEmpresa(String idVigencia){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_obtenerLeyendaXVigencia");
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		int _idVigencia = Integer.valueOf(idVigencia);

		inParamMap.put("idVigencia", _idVigencia);


		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}

	public List<Object> obtenerReporteBitacora( String tipoReporte,String fechaInicio,  String fechaFinal,String idEmpresa, String idEmpleado, String idPerfil, String CampoBusca, String Busca){
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_obtenerReporteBitacora");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		List<Object> listSP = new ArrayList<>();

		int _tipoReporte = Integer.valueOf(tipoReporte);

		inParamMap.put("tipoReporte", _tipoReporte);
		inParamMap.put("fechaInicio", fechaInicio);
		inParamMap.put("fechaFinal", fechaFinal);

		Map<String, Object> simpleJdbcCallResult;
		if (idEmpleado.equals("NA")) {
			String[] empresas = idEmpresa.split(",");
			if (empresas.length <= 1){
				empresas = idEmpresa.split("_");
			}
			for (String empresa : empresas) {
				int _idEmpresa = Integer.valueOf(empresa);
				inParamMap.put("idEmpresa", _idEmpresa);
				List<Object> empleados = new ArrayList<>();
				if (tipoReporte.equals("0")) {
					empleados = obtenerEmpleadosBitacora(
							empresa,"ff_admi_Consulta.aspx",idPerfil,CampoBusca, Busca, "1");
				} else {
					empleados = obtenerEmpleadosBitacora(
							empresa,"ff_admi_Consulta.aspx",idPerfil,CampoBusca, Busca, "0");
				}
				ArrayList empleadosMap = (ArrayList) empleados.get(0);
				for (Object empleado : empleadosMap) {
					inParamMap.put("idEmpleado", ((LinkedCaseInsensitiveMap) empleado).get("idempleadox"));
					SqlParameterSource in = new MapSqlParameterSource(inParamMap);
					simpleJdbcCallResult = simpleJdbcCall.execute(in);
					List<Object> result = new ArrayList<>(simpleJdbcCallResult.values());
					listSP.addAll((ArrayList) result.get(0));
				}
			}

			ArrayList<ArrayList<Object>> biDemArrList = new ArrayList<ArrayList<Object>>();
			//List<Object> listSP = new ArrayList<>();

			biDemArrList.add((ArrayList)(listSP));

			biDemArrList.set( 0, (ArrayList)(listSP));
			listSP =  (List) biDemArrList;

		} else {
			int _idEmpresa = Integer.valueOf(idEmpresa);
			int _idEmpleado = Integer.valueOf(idEmpleado);
			inParamMap.put("idEmpresa", _idEmpresa);
			inParamMap.put("idEmpleado", _idEmpleado);
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			simpleJdbcCallResult = simpleJdbcCall.execute(in);
			listSP.addAll(simpleJdbcCallResult.values());
		}
		return listSP;
	}

	public List<Object> obtenerEmpleadosBitacora( String IdEmpresa,String Pantalla,  String IdPerfil, String CampoBusca, String Busca, String idAdm){
		//String spAdm  = "bf_BuscarAdministradoresV3";
		//String spEmp = "ff_BuscarEmpleadosPorEmpresaBitacora";

		String spAdm  = "bf_BuscarAdministradoresV3_BF3";
		String spEmp = "ff_BuscarEmpleadosPorEmpresaBitacora_BF3";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;

		if( "0".equals(idAdm)){
			simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spEmp);
			inParamMap = new HashMap<String, Object>();

			int _idPerfil = Integer.valueOf(IdPerfil);
			int _idAdministrador = Integer.valueOf(idAdm);

			inParamMap.put("IdEmpresa", IdEmpresa);
			inParamMap.put("Pantalla", Pantalla);
			inParamMap.put("IdPerfil", _idPerfil);
			inParamMap.put("CampoBusca", CampoBusca);
			inParamMap.put("Busca", Busca);
			inParamMap.put("IdAdministrador", _idAdministrador);
		}else{
			simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(spAdm);
			inParamMap = new HashMap<String, Object>();

			int _idEmpresa = Integer.valueOf(IdEmpresa);

			inParamMap.put("BuscaStr", Busca);
			inParamMap.put("IdEmpresa", IdEmpresa);
			inParamMap.put("TipoBuscar", CampoBusca);
		}
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}


	@Override
	public List<Object> buscarTitularPorNumeroEmpleado(String numeroEmpleado, String idEmpresa) {
		String sp = "ff_CLeeDatosTitular_BF3";
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(sp);
		Map<String, Object> inParamMap = inParamMap = new HashMap<String, Object>();;

		inParamMap.put("IdEmpleado", numeroEmpleado);
		inParamMap.put("IdEmpresa", Integer.valueOf(idEmpresa));

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}

	@Override
	public List<Map<String, Object>> bajaTitularDatosMail(List<Map<String, Object>> datos) {
		try {
			// Convertir la lista a JSON
			String d1 = objectMapper.writeValueAsString(datos);

			// Ejecutar el procedimiento almacenado
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withProcedureName("ff_bajaTitularDatosMail")
					.returningResultSet("result", (rs, rowNum) -> {
						Map<String, Object> row = new HashMap<>();
						row.put("to", rs.getString("to"));
						row.put("cc", rs.getString("cc"));
						row.put("bcc", rs.getString("bcc"));
						row.put("subject", rs.getString("subject"));
						row.put("html", rs.getString("html"));
						row.put("txt", rs.getString("txt"));
						return row;
					});

			Map<String, Object> result = simpleJdbcCall
					.execute(new MapSqlParameterSource("datos", d1));

			List<Map<String, Object>> resultList = (List<Map<String, Object>>) result.get("result");

			return (resultList != null && !resultList.isEmpty()) ? resultList : new ArrayList<>();

		} catch (Exception e) {
			throw new RuntimeException("Error al ejecutar el procedimiento almacenado", e);
		}
	}

	@Override
	public List<Map<String, Object>> datosMailDependiente(List<Map<String, Object>> datos) {
		try {
			// Convertir la lista a JSON
			String d1 = objectMapper.writeValueAsString(datos);

			// Ejecutar el procedimiento almacenado
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withProcedureName("ff_bajaDependienteDatosMail")
					.returningResultSet("result", (rs, rowNum) -> {
						Map<String, Object> row = new HashMap<>();
						row.put("to", rs.getString("to"));
						row.put("cc", rs.getString("cc"));
						row.put("bcc", rs.getString("bcc"));
						row.put("subject", rs.getString("subject"));
						row.put("html", rs.getString("html"));
						row.put("txt", rs.getString("txt"));
						return row;
					});

			Map<String, Object> result = simpleJdbcCall
					.execute(new MapSqlParameterSource("datos", d1));

			List<Map<String, Object>> resultList = (List<Map<String, Object>>) result.get("result");

			return (resultList != null && !resultList.isEmpty()) ? resultList : new ArrayList<>();

		} catch (Exception e) {
			throw new RuntimeException("Error al ejecutar el procedimiento almacenado", e);
		}
	}	


	public List<Object> obtenerConfiguracionTotalStatement(String idParametro,String idEmpresa,  String idPerfil){


		String nombreSP  = "ff_BuscarPerfilTotalStateMentV3";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;




		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		inParamMap = new HashMap<String, Object>();


		int  _idParametro = Integer.valueOf( idParametro);
		int  _idEmpresa = Integer.valueOf( idEmpresa);
		int  _idPerfil = Integer.valueOf( idPerfil);

		inParamMap.put("parametro", _idParametro);
		inParamMap.put("idEmpresa", _idEmpresa);
		inParamMap.put("idPerfil", _idPerfil);






		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}


	public List<Object> obtenerReporteSolicitudesEmpleado(  String idCorporativo , String idEmpresa,String idPerfil, String idVigencia, String fechaInicio, String fechaFinal){


		String nombreSP  = "ObtenerEstadisticasPorEmpresaV3";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;




		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		inParamMap = new HashMap<String, Object>();


		int  _idCorporativo = Integer.valueOf( idCorporativo);
		int  _idEmpresa = Integer.valueOf( idEmpresa);
		int  _idPerfil= Integer.valueOf( idPerfil);
		int  _idVigencia = Integer.valueOf( idVigencia);

		inParamMap.put("IdCorporativo",_idCorporativo);

		inParamMap.put("IdEmpresa",_idEmpresa);
		inParamMap.put("IdPerfil",_idPerfil);
		inParamMap.put("IdVigencia",_idVigencia);




		inParamMap.put("FechaInicio", fechaInicio);
		inParamMap.put("FechaFin", fechaFinal);






		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}




	public List<Object> obtenerGridDefaulteo(   String idCorporativo,  String idEmpresa,  String numEmpleado,  String apellidoPaterno,String apellidoMaterno, String nombreUno, String nombreDos){


		String nombreSP  = "bf_DefaulteoEmpleadosV3";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;

		if("null".equals(numEmpleado))
			numEmpleado = null;

		if("null".equals(apellidoPaterno))
			apellidoPaterno = null;

		if("null".equals(apellidoMaterno))
			apellidoMaterno = null;

		if("null".equals(nombreUno))
			nombreUno = null;

		if("null".equals(nombreDos))
			nombreDos = null;





		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		inParamMap = new HashMap<String, Object>();


		int  _idCorporativo = Integer.valueOf( idCorporativo);
		int  _idEmpresa = Integer.valueOf( idEmpresa);


		inParamMap.put("IdCorporativo",_idCorporativo);

		inParamMap.put("IdEmpresa",_idEmpresa);
		inParamMap.put("NumeroEmpleado",numEmpleado);
		inParamMap.put("ApellidoPaterno",apellidoPaterno);
		inParamMap.put("ApellidoMaterno",apellidoMaterno);




		inParamMap.put("Nombre1", nombreUno);
		inParamMap.put("Nombre2", nombreDos);







		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}

	public List<Object> obtenerPlanesDefault(   ){


		String nombreSP  = "bf_tiposPlanesDefaultV3";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;



		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute();
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}



	public List<Object> verificarUsuarioBitacora( String idUsuario  ){


		String nombreSP  = "verificarTipoAdmBF3";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;





		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		inParamMap = new HashMap<String, Object>();


		int  _idUsuario = Integer.valueOf( idUsuario);



		inParamMap.put("idUsuario",_idUsuario);








		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}

	public List<Object> obtenerPlanesVigenciaAnterior(  String idUsuario,  String idVigencia,  String idEmpresa  ){


		String nombreSP  = "ff_solicitudSeleccionVigencia";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;





		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		inParamMap = new HashMap<String, Object>();


		int  _idUsuario = Integer.valueOf( idUsuario);
		int  _idVigencia = Integer.valueOf( idVigencia);
		int  _idEmpresa = Integer.valueOf( idEmpresa);



		inParamMap.put("idEmpleado",_idUsuario);
		inParamMap.put("vigencia",_idVigencia);
		inParamMap.put("idEmpresa",_idEmpresa);








		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}



	public List<Object> verificarSolicitudDefaulteada(  String idAdm , String idEmpleadoDefaulteado ){


		String nombreSP  = "verificarSolicitudDefaulteadaB3";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;





		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		inParamMap = new HashMap<String, Object>();


		int  _idAdm = Integer.valueOf( idAdm);
		int  _idEmpleadoDefaulteado = Integer.valueOf( idEmpleadoDefaulteado);




		inParamMap.put("idEmpleado",_idEmpleadoDefaulteado);
		inParamMap.put("idAdm",_idAdm);









		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}



	@Override
	public List<Object> obtenerGridDefaulteoMultivigencia(   String idCorporativo,  String idEmpresa,  String numEmpleado,  String apellidoPaterno,String apellidoMaterno, String nombreUno, String nombreDos,String vigencia,int idAdministrador){


		String nombreSP  = "bf_DefaulteoEmpleadosBF3Multivigencia";
		SimpleJdbcCall simpleJdbcCall = null;
		Map<String, Object> inParamMap = null;

		if("null".equals(numEmpleado))
			numEmpleado = null;

		if("null".equals(apellidoPaterno))
			apellidoPaterno = null;

		if("null".equals(apellidoMaterno))
			apellidoMaterno = null;

		if("null".equals(nombreUno))
			nombreUno = null;

		if("null".equals(nombreDos))
			nombreDos = null;





		simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		inParamMap = new HashMap<String, Object>();


		int  _idCorporativo = Integer.valueOf( idCorporativo);
		int  _idEmpresa = Integer.valueOf( idEmpresa);
		int  _idvigencia = Integer.valueOf(vigencia);


		inParamMap.put("IdCorporativo",_idCorporativo);

		inParamMap.put("IdEmpresa",_idEmpresa);
		inParamMap.put("NumeroEmpleado",numEmpleado);
		inParamMap.put("ApellidoPaterno",apellidoPaterno);
		inParamMap.put("ApellidoMaterno",apellidoMaterno);
		inParamMap.put("Vigencia",_idvigencia);
		inParamMap.put("Nombre1", nombreUno);
		inParamMap.put("Nombre2", nombreDos);
		inParamMap.put("idAdministrador", idAdministrador);







		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		return listSP;
	}

	public List<Object> consultarTitularesCorpEmp(Integer IdEmpresa, String Pantalla,
												  int IdPerfil, String busca,String campoBusca,int idAdm) {

		String nombreSP = "";
		for(PlantillasTitulares plantilla: PlantillasTitulares.values()){
			if(plantilla.getNombrePantalla().equals(Pantalla)){
				nombreSP = plantilla.getNombreSP();
			}
		}

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		if(emp_dao.isCorporativo(IdEmpresa)){
			inParamMap.put("IdEmpresa", "");
			inParamMap.put("IdCorporativo", IdEmpresa);
		}else{
			inParamMap.put("IdEmpresa", IdEmpresa);
			inParamMap.put("IdCorporativo", "");
		}

		inParamMap.put("Busca", busca);
		inParamMap.put("Pantalla",  "ff_Admi_Consulta.aspx");
		inParamMap.put("IdPerfil", IdPerfil);
		inParamMap.put("CampoBusca", campoBusca);
		inParamMap.put("IdAdministrador", idAdm);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		listSP = listSP.isEmpty() ? listSP : new ArrayList<Object>((Collection<? extends Object>) listSP.get(0));

		if ( !listSP.isEmpty() && ((Map<String,String>)listSP.get(0)).containsKey("Perfil") ) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((registro) -> {
				if ( !((Map<String,String>)registro).get("Perfil").toString().equalsIgnoreCase("Administrador")) {
					tmp.add(registro);
				}
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		return listSP;
	}


	public List<Object> defaultearEmpleadosMasivo(FFDefaulteo datos){

		int[] empleados =  datos.getIdEmpleado();
		int[] empresas = datos.getIdEmpresa();
		String[] numEmpleados =  datos.getNumEmpleado();
		String nombreSp = "";
		List<Object> defaulteados = new ArrayList<>();
		int idAdmin = datos.getIdAdmin();


		for(int j = 0; j < empleados.length; j++ ){
			boolean noDefaulteado = false;
			String msjAdvertencia = "";





			if(datos.getIdVigencia() == 0){
				nombreSp = "ff_CBuscaPlanesPerfil_V31Test";
			}else{
				nombreSp = "ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3";
			}





			SimpleJdbcCall simpleJdbcCall = null;
			Map<String, Object> inParamMap =  new HashMap<String, Object>();


			inParamMap.put("idempresa",empresas[j]);
			inParamMap.put("idempleado",empleados[j]);
			inParamMap.put("tmpplanesseleccionados","{\"costo\": null,\"idempleado\": -1,\"nuevo\": null,\"tcidtarifacosto\": -1}");
			inParamMap.put("tmpplanesseleccionadosold","{\"costo\": null,\"idempleado\": -1,\"nuevo\": null,\"tcidtarifacosto\": -1}");
			inParamMap.put("transfer",datos.getTipoDefaulteo());

			if(datos.getIdVigencia() != 0){
				inParamMap.put("idVigenciaD",datos.getIdVigenciaAnterior());
			}



			SqlParameterSource in = new MapSqlParameterSource(inParamMap);

			simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSp);

			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
			List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
			//List<Object> listDatosValidos = (List<Object>) listSP.get(15) ;

			String xml = "<ROOT>";
			boolean tienePlanesSeleccionados = false;
			for(int k = 0; k < listSP.size(); k++){

				if (!(listSP.get(k) instanceof Integer)) {

					List<Object> listDatosValidos = (List<Object>) listSP.get(k) ;
					for (int i = 0; i < listDatosValidos.size(); i++) {

						Map<String, Object> mapDatosValidos = (Map<String, Object>) listDatosValidos.get(i);
						if (mapDatosValidos.containsKey("Checked")) {
							if (String.valueOf(mapDatosValidos.get("Checked")).equalsIgnoreCase("true")) {

								String idEmpleado = String.valueOf(mapDatosValidos.get("id")) ;
								String TCidTarifaCosto = String.valueOf(mapDatosValidos.get("TCidTarifaCosto"));
								String TCPrimaTotal =  String.valueOf(mapDatosValidos.get("TCPrimaTotal"));

								xml += "<TarifaCosto TCidTarifaCosto=\"" + TCidTarifaCosto + "\" Costo=\"" + TCPrimaTotal + "\" idEmpleado=\"" + idEmpleado + "\"></TarifaCosto>";
								tienePlanesSeleccionados = true;
							}
						}

						if (mapDatosValidos.containsKey("descripcionMensaje")) {

							if(!String.valueOf(mapDatosValidos.get("descripcionMensaje")).isEmpty() ){
								noDefaulteado = true;
								msjAdvertencia = String.valueOf(mapDatosValidos.get("descripcionMensaje"));
							}
						}

					}
				}
			}

			xml += "</ROOT>";
			if (!tienePlanesSeleccionados && !noDefaulteado) {
				noDefaulteado = true;
				msjAdvertencia = "El motor no devolvio planes elegibles para el empleado y la vigencia seleccionada.";
			}
			DatosInicialesBuscaPlanesPerfilV2 datosIniciales = null;
			EmpleadoDatosPrincipales datosPrincipalesEmpleado = empleado.buscarDatosPrincipales(empleados[j]);
			if(empresas[j] == 369){
				datosIniciales = buscarDatosIniciales(empleados[j]);

			}
			if(noDefaulteado != true){
				if(datos.getIdVigencia() == 0 && empresas[j] != 369){
					nombreSp = "ff_IInsertaPlanesPerfilTmp";
				}else if(datos.getIdVigencia() != 0 && empresas[j] != 369){
					nombreSp = "ff_IInsertaPlanesPerfilTmpTestMultivigenciaBF3";
				}else if(datos.getIdVigencia() == 0 && empresas[j] == 369){
					nombreSp = "ff_IInsertaPlanesPerfilTmp_V2";
				}else{
					nombreSp = "ff_IInsertaPlanesPerfilTmp_V2TestMultivigenciaBF3";
				}

				simpleJdbcCall = null;
				inParamMap =  new HashMap<String, Object>();

				inParamMap.put("idEmpleado",empleados[j]);
				inParamMap.put("PlanesSeleccionados",xml);
				inParamMap.put("idEmpresa",empresas[j]);
				if(datos.getIdVigencia() != 0 && empresas[j] != 369){
					inParamMap.put("idVigencia",datos.getIdVigenciaAnterior());
				}else if(empresas[j] == 369){
					inParamMap.put("IdPerfil",datosPrincipalesEmpleado.getIdPerfil());
					inParamMap.put("IdPeriodicidadPago",datosIniciales.getIdPeriocidadPago());
					inParamMap.put("IdVigencia",datosIniciales.getIdVigencia());
					inParamMap.put("NumeroEmpleado",datosPrincipalesEmpleado.getNumeroEmpleado());
					inParamMap.put("CantidadPago",datosIniciales.getCantidadPago());
					inParamMap.put("IdConfiguracion",datosIniciales.getIdConfiguracion());
					inParamMap.put("PeridicidadNombre",datosIniciales.getPeriocidadNombre());

				}

				if(empresas[j] == 369 && datos.getIdVigencia() != 0 ){
					inParamMap.put("idVigenciaDefaulteo",datos.getIdVigenciaAnterior());

				}
				in = new MapSqlParameterSource(inParamMap);
				simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSp);
				simpleJdbcCallResult = simpleJdbcCall.execute(in);
				listSP = new ArrayList<Object>(simpleJdbcCallResult.values());




            /* if(datos.getIdVigencia() == 0){
             nombreSp = "ff_CreateSolicitud";
            }else{
             nombreSp = "ff_CreateSolicitudTest";
            }*/

				nombreSp = "ff_CreateSolicitudTest";
				simpleJdbcCall = null;

				inParamMap =  new HashMap<String, Object>();

				inParamMap.put("IdEmpleado",empleados[j]);
				inParamMap.put("idAdmin",idAdmin);

				if(datos.getIdVigencia() != 0){
					inParamMap.put("idVigencia",datos.getIdVigencia());
				}else{
					inParamMap.put("idVigencia",datos.getIdVigenciaVigente());
				}

				in = new MapSqlParameterSource(inParamMap);
				simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSp);
				simpleJdbcCallResult = simpleJdbcCall.execute(in);
				listSP = new ArrayList<Object>(simpleJdbcCallResult.values());

				int solicitudCreada=0;
				datosPrincipalesEmpleado = empleado.buscarDatosPrincipales(empleados[j]);
				FfEmpresa empresa = emp_dao.buscar(datosPrincipalesEmpleado.getIdEmpresa());
				if(datos.getIdVigencia() == 0){

					datosIniciales = buscarDatosIniciales(empleados[j]);
					solicitudCreada = validaSolicitudExistente2(empresas[j],empleados[j],datosIniciales.getIdVigencia());
				}else{
					solicitudCreada = validaSolicitudExistente2(empresas[j],empleados[j],datos.getIdVigencia());
				}

				if(solicitudCreada == 1){
					defaulteados.add(empresa.getEMNombre() + "_" + datosPrincipalesEmpleado.getNumeroEmpleado() + "_ok");
				}else{
					defaulteados.add(empresa.getEMNombre() + "_" +  datosPrincipalesEmpleado.getNumeroEmpleado() + "_error");
				}



			}else{
				FfEmpresa empresa = emp_dao.buscar(datosPrincipalesEmpleado.getIdEmpresa());
				defaulteados.add(empresa.getEMNombre() + "_" + datosPrincipalesEmpleado.getNumeroEmpleado() + "_error" + " " + msjAdvertencia);
				noDefaulteado = false;
				msjAdvertencia = "";
			}




		}


		return defaulteados;

	}

	// CREA06 casos especiales: VARIANTE del defaulteo masivo que respeta condiciones especiales
	// (forzar coberturas/planes). NO modifica defaultearEmpleadosMasivo (el flujo basico) para no
	// arriesgar regresiones. Ademas de las coberturas Checked=true que el SP marca por defecto,
	// inyecta en el XML de TarifaCosto las coberturas forzadas que aparezcan ELEGIBLES en el
	// result-set del SP (las no elegibles no aparecen -> se reportan como omitidas).
	//   forzarCob  = conjunto de POidPlanOpcion (coberturas) a forzar individualmente.
	//   forzarPlan = conjunto de POidPlan a forzar completos (todas sus coberturas elegibles).
	// Devuelve List<Map>: { resultado, forzadasAplicadas, forzadasOmitidas, planesOmitidos } por empleado.
	@SuppressWarnings("unchecked")
	public List<Object> defaultearEmpleadosMasivoCasosEspeciales(FFDefaulteo datos, java.util.Set<Integer> forzarCob, java.util.Set<Integer> forzarPlan){

		int[] empleados =  datos.getIdEmpleado();
		int[] empresas = datos.getIdEmpresa();
		String nombreSp = "";
		List<Object> defaulteados = new ArrayList<>();
		int idAdmin = datos.getIdAdmin();

		if (forzarCob == null) { forzarCob = new java.util.HashSet<Integer>(); }
		if (forzarPlan == null) { forzarPlan = new java.util.HashSet<Integer>(); }

		// CREA06 RF026-029: bloqueo del plan de retiro por antiguedad (<6m) para corporativos configurados.
		// Caches por lote: idEmpresa->idCorporativo y idCorporativo->set de coberturas de retiro (bf_WizardConfig).
		final int MESES_MIN_RETIRO = 6;
		java.util.Map<Integer, java.util.Set<Integer>> retiroCobPorCorp = new java.util.HashMap<Integer, java.util.Set<Integer>>();
		java.util.Map<Integer, Integer> corpPorEmpresa = new java.util.HashMap<Integer, Integer>();

		for(int j = 0; j < empleados.length; j++ ){
			boolean noDefaulteado = false;
			String msjAdvertencia = "";
			// CREA06: motivo de fallo del empleado preservado (msjAdvertencia se limpia mas abajo).
			String motivoFalloEmpleado = null;

			// Tracking por empleado de condiciones especiales aplicadas/omitidas.
			java.util.Set<Integer> aplicadasCobEmp = new java.util.HashSet<Integer>();
			java.util.Set<Integer> planesAplicadosEmp = new java.util.HashSet<Integer>();

			// CREA06 RF026: este empleado debe bloquear el plan de retiro si tiene menos de 6 meses (corp configurado)
			java.util.Set<Integer> retiroBloqueadoEmp = new java.util.HashSet<Integer>();
			java.util.Set<Integer> retiroCobsEmp = java.util.Collections.<Integer>emptySet();
			int mesesAntEmp = -1;
			try {
				Integer corp = corpPorEmpresa.get(empresas[j]);
				if (corp == null) {
					// CREA06: SP en vez de query en duro (bf_DefaulteoAvanzado_GetCorporativoEmpresa).
					Map<String, Object> outCorp = new SimpleJdbcCall(jdbcTemplate)
						.withProcedureName("bf_DefaulteoAvanzado_GetCorporativoEmpresa")
						.execute(new MapSqlParameterSource("IdEmpresa", empresas[j]));
					Map<String, Object> rowCorp = primeraFilaCE(outCorp);
					Integer corpVal = (rowCorp != null) ? toInt(rowCorp.get("idCorporativo")) : null;
					corp = (corpVal != null) ? corpVal : Integer.valueOf(-1);
					corpPorEmpresa.put(empresas[j], corp);
				}
				java.util.Set<Integer> rc = retiroCobPorCorp.get(corp);
				if (rc == null) {
					rc = new java.util.HashSet<Integer>();
					// CREA06: SP en vez de query en duro (bf_DefaulteoAvanzado_GetWizardConfigValor).
					Map<String, Object> outCfg = new SimpleJdbcCall(jdbcTemplate)
						.withProcedureName("bf_DefaulteoAvanzado_GetWizardConfigValor")
						.execute(new MapSqlParameterSource("Clave", "CREA06:coberturasRetiro:" + corp));
					Map<String, Object> rowCfg = primeraFilaCE(outCfg);
					Object cfgVal = (rowCfg != null) ? rowCfg.get("valor") : null;
					if (cfgVal != null) {
						for (String s : cfgVal.toString().split(",")) {
							try { rc.add(Integer.valueOf(s.trim())); } catch (Exception ig) { /* token no numerico */ }
						}
					}
					retiroCobPorCorp.put(corp, rc);
				}
				retiroCobsEmp = rc;
				if (!retiroCobsEmp.isEmpty()) {
					// CREA06: SP en vez de query en duro (bf_DefaulteoAvanzado_GetMesesAntiguedad).
					// Sin fila (EMFechaIngresoEmpresa NULL) => -1, igual que el WHERE original.
					Map<String, Object> outMa = new SimpleJdbcCall(jdbcTemplate)
						.withProcedureName("bf_DefaulteoAvanzado_GetMesesAntiguedad")
						.execute(new MapSqlParameterSource("IdEmpleado", empleados[j]));
					Map<String, Object> rowMa = primeraFilaCE(outMa);
					Integer meses = (rowMa != null) ? toInt(rowMa.get("meses")) : null;
					mesesAntEmp = (meses != null) ? meses : -1;
				}
			} catch (Exception exRetiro) { /* sin config/fecha => no se bloquea */ }
			boolean bloquearRetiro = (mesesAntEmp >= 0 && mesesAntEmp < MESES_MIN_RETIRO && !retiroCobsEmp.isEmpty());

			if(datos.getIdVigencia() == 0){
				nombreSp = "ff_CBuscaPlanesPerfil_V31Test";
			}else{
				nombreSp = "ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3";
			}

			SimpleJdbcCall simpleJdbcCall = null;
			Map<String, Object> inParamMap =  new HashMap<String, Object>();

			inParamMap.put("idempresa",empresas[j]);
			inParamMap.put("idempleado",empleados[j]);
			inParamMap.put("tmpplanesseleccionados","{\"costo\": null,\"idempleado\": -1,\"nuevo\": null,\"tcidtarifacosto\": -1}");
			inParamMap.put("tmpplanesseleccionadosold","{\"costo\": null,\"idempleado\": -1,\"nuevo\": null,\"tcidtarifacosto\": -1}");
			inParamMap.put("transfer",datos.getTipoDefaulteo());

			if(datos.getIdVigencia() != 0){
				inParamMap.put("idVigenciaD",datos.getIdVigenciaAnterior());
			}

			SqlParameterSource in = new MapSqlParameterSource(inParamMap);

			simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSp);

			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
			List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());

			String xml = "<ROOT>";
			boolean tienePlanesSeleccionados = false;
			for(int k = 0; k < listSP.size(); k++){

				if (!(listSP.get(k) instanceof Integer)) {

					List<Object> listDatosValidos = (List<Object>) listSP.get(k) ;
					for (int i = 0; i < listDatosValidos.size(); i++) {

						Map<String, Object> mapDatosValidos = (Map<String, Object>) listDatosValidos.get(i);
						if (mapDatosValidos.containsKey("Checked")) {

							boolean checked = String.valueOf(mapDatosValidos.get("Checked")).equalsIgnoreCase("true");
							Integer poId   = toInt(mapDatosValidos.get("POidPlanOpcion"));
							Integer planId = toInt(mapDatosValidos.get("POidPlan"));
							boolean forzadaCob  = poId != null && forzarCob.contains(poId);
							boolean forzadaPlan = planId != null && forzarPlan.contains(planId);

							if (checked || forzadaCob || forzadaPlan) {

								// CREA06 RF026: NO asignar el plan de retiro a empleados con <6 meses (corp configurado).
								// Cubre tanto el retiro forzado como el copiado por renovacion (Checked).
								if (bloquearRetiro && poId != null && retiroCobsEmp.contains(poId)) {
									retiroBloqueadoEmp.add(poId);
								} else {
									String idEmpleado = String.valueOf(mapDatosValidos.get("id")) ;
									String TCidTarifaCosto = String.valueOf(mapDatosValidos.get("TCidTarifaCosto"));
									String TCPrimaTotal =  String.valueOf(mapDatosValidos.get("TCPrimaTotal"));

									xml += "<TarifaCosto TCidTarifaCosto=\"" + TCidTarifaCosto + "\" Costo=\"" + TCPrimaTotal + "\" idEmpleado=\"" + idEmpleado + "\"></TarifaCosto>";
									tienePlanesSeleccionados = true;

									// Solo contamos como "forzada aplicada" lo que se inyecto por la condicion
									// especial (no lo que el SP ya traia Checked por defecto).
									if (forzadaCob && poId != null)  { aplicadasCobEmp.add(poId); }
									if (forzadaPlan && planId != null){ planesAplicadosEmp.add(planId); if (poId != null) { aplicadasCobEmp.add(poId); } }
								}
							}
						}

						if (mapDatosValidos.containsKey("descripcionMensaje")) {

							if(!String.valueOf(mapDatosValidos.get("descripcionMensaje")).isEmpty() ){
								noDefaulteado = true;
								msjAdvertencia = String.valueOf(mapDatosValidos.get("descripcionMensaje"));
							}
						}

					}
				}
			}

			xml += "</ROOT>";
			if (!tienePlanesSeleccionados && !noDefaulteado) {
				noDefaulteado = true;
				msjAdvertencia = "El motor no devolvio planes elegibles para el empleado y la vigencia seleccionada.";
			}
			DatosInicialesBuscaPlanesPerfilV2 datosIniciales = null;
			EmpleadoDatosPrincipales datosPrincipalesEmpleado = null;
			if(empresas[j] == 369){
				datosIniciales = buscarDatosIniciales(empleados[j]);
				datosPrincipalesEmpleado = empleado.buscarDatosPrincipales(empleados[j]);

			}

			String resultadoStr;
			if(noDefaulteado != true){
				if(datos.getIdVigencia() == 0 && empresas[j] != 369){
					nombreSp = "ff_IInsertaPlanesPerfilTmp";
				}else if(datos.getIdVigencia() != 0 && empresas[j] != 369){
					nombreSp = "ff_IInsertaPlanesPerfilTmpTestMultivigenciaBF3";
				}else if(datos.getIdVigencia() == 0 && empresas[j] == 369){
					nombreSp = "ff_IInsertaPlanesPerfilTmp_V2";
				}else{
					nombreSp = "ff_IInsertaPlanesPerfilTmp_V2TestMultivigenciaBF3";
				}

				simpleJdbcCall = null;
				inParamMap =  new HashMap<String, Object>();

				inParamMap.put("idEmpleado",empleados[j]);
				inParamMap.put("PlanesSeleccionados",xml);
				inParamMap.put("idEmpresa",empresas[j]);
				if(datos.getIdVigencia() != 0 && empresas[j] != 369){
					inParamMap.put("idVigencia",datos.getIdVigenciaAnterior());
				}else if(empresas[j] == 369){
					inParamMap.put("IdPerfil",datosPrincipalesEmpleado.getIdPerfil());
					inParamMap.put("IdPeriodicidadPago",datosIniciales.getIdPeriocidadPago());
					inParamMap.put("IdVigencia",datosIniciales.getIdVigencia());
					inParamMap.put("NumeroEmpleado",datosPrincipalesEmpleado.getNumeroEmpleado());
					inParamMap.put("CantidadPago",datosIniciales.getCantidadPago());
					inParamMap.put("IdConfiguracion",datosIniciales.getIdConfiguracion());
					inParamMap.put("PeridicidadNombre",datosIniciales.getPeriocidadNombre());

				}

				if(empresas[j] == 369 && datos.getIdVigencia() != 0 ){
					inParamMap.put("idVigenciaDefaulteo",datos.getIdVigenciaAnterior());

				}
				in = new MapSqlParameterSource(inParamMap);
				simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSp);
				simpleJdbcCallResult = simpleJdbcCall.execute(in);
				listSP = new ArrayList<Object>(simpleJdbcCallResult.values());

				nombreSp = "ff_CreateSolicitudTest";
				simpleJdbcCall = null;

				inParamMap =  new HashMap<String, Object>();

				inParamMap.put("IdEmpleado",empleados[j]);
				inParamMap.put("idAdmin",idAdmin);

				if(datos.getIdVigencia() != 0){
					inParamMap.put("idVigencia",datos.getIdVigencia());
				}else{
					inParamMap.put("idVigencia",datos.getIdVigenciaVigente());
				}

				in = new MapSqlParameterSource(inParamMap);
				simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSp);
				simpleJdbcCallResult = simpleJdbcCall.execute(in);
				listSP = new ArrayList<Object>(simpleJdbcCallResult.values());

				int solicitudCreada=0;
				datosPrincipalesEmpleado = empleado.buscarDatosPrincipales(empleados[j]);
				FfEmpresa empresa = emp_dao.buscar(datosPrincipalesEmpleado.getIdEmpresa());
				if(datos.getIdVigencia() == 0){

					datosIniciales = buscarDatosIniciales(empleados[j]);
					solicitudCreada = validaSolicitudExistente2(empresas[j],empleados[j],datosIniciales.getIdVigencia());
				}else{
					solicitudCreada = validaSolicitudExistente2(empresas[j],empleados[j],datos.getIdVigencia());
				}

				if(solicitudCreada == 1){
					resultadoStr = empresa.getEMNombre() + "_" + datosPrincipalesEmpleado.getNumeroEmpleado() + "_ok";
				}else{
					resultadoStr = empresa.getEMNombre() + "_" +  datosPrincipalesEmpleado.getNumeroEmpleado() + "_error";
				}

			}else{
				datosPrincipalesEmpleado = empleado.buscarDatosPrincipales(empleados[j]);
				FfEmpresa empresa = emp_dao.buscar(datosPrincipalesEmpleado.getIdEmpresa());
				resultadoStr = empresa.getEMNombre() + "_" + datosPrincipalesEmpleado.getNumeroEmpleado() + "_error" + " " + msjAdvertencia;
				motivoFalloEmpleado = msjAdvertencia;
				noDefaulteado = false;
				msjAdvertencia = "";
			}

			// Coberturas/planes forzados que NO aparecieron elegibles para este empleado -> omitidos por reglas.
			java.util.Set<Integer> omitCob = new java.util.HashSet<Integer>(forzarCob);
			omitCob.removeAll(aplicadasCobEmp);
			// El retiro bloqueado por antiguedad NO es "no elegible": se reporta aparte con su motivo.
			omitCob.removeAll(retiroBloqueadoEmp);
			java.util.Set<Integer> omitPlan = new java.util.HashSet<Integer>(forzarPlan);
			omitPlan.removeAll(planesAplicadosEmp);

			// CREA06: adjuntar el MOTIVO de cada omision (no aparece elegible en el cotizador del empleado).
			// Si el empleado completo no se defaulteo, el motivo es ese error de negocio; si no, es no-elegibilidad.
			boolean fallo = (motivoFalloEmpleado != null && !motivoFalloEmpleado.trim().isEmpty());
			String motivoCob  = fallo
				? ("No se genero la solicitud: " + motivoFalloEmpleado.trim())
				: "No elegible para el perfil/condiciones del empleado (candado del cotizador)";
			String motivoPlan = fallo
				? ("No se genero la solicitud: " + motivoFalloEmpleado.trim())
				: "El plan no tiene coberturas elegibles para el empleado";
			// CREA06: resolver el NOMBRE legible (plan + opcion) de las coberturas aplicadas/omitidas para el
			// log. Antes el front solo tenia el nombre de las coberturas FORZADAS en la UI; las coberturas por
			// default salian como "Cobertura <id>". El SP bf_DefaulteoAvanzado_GetNombresPlanOpcion ahora
			// devuelve POidPlanOpcion + PLNombre + PONombre; se mandan plan y opcion por separado y el front
			// los une (evita caracteres no-ASCII en el string de Java).
			java.util.Map<Integer,String> planDeCob   = new java.util.HashMap<Integer,String>();
			java.util.Map<Integer,String> opcionDeCob  = new java.util.HashMap<Integer,String>();
			java.util.Set<Integer> idsParaNombre = new java.util.HashSet<Integer>(aplicadasCobEmp);
			idsParaNombre.addAll(omitCob);
			if (!idsParaNombre.isEmpty()) {
				try {
					StringBuilder idsCob = new StringBuilder();
					for (Integer id : idsParaNombre) { if (idsCob.length() > 0) { idsCob.append(','); } idsCob.append(id.intValue()); }
					Map<String, Object> outCob = new SimpleJdbcCall(jdbcTemplate)
						.withProcedureName("bf_DefaulteoAvanzado_GetNombresPlanOpcion")
						.execute(new MapSqlParameterSource("Ids", idsCob.toString()));
					for (Map<String,Object> r : primerResultSetCE(outCob)) {
						Integer idc = toInt(r.get("POidPlanOpcion"));
						if (idc == null) { continue; }
						if (r.get("PLNombre") != null) { planDeCob.put(idc,  String.valueOf(r.get("PLNombre")).trim()); }
						if (r.get("PONombre") != null) { opcionDeCob.put(idc, String.valueOf(r.get("PONombre")).trim()); }
					}
				} catch (Exception exNom) { /* si falla la resolucion de nombre, el front cae al id */ }
			}
			List<Object> omitCobDet = new ArrayList<Object>();
			for (Integer idc : omitCob) {
				Map<String,Object> o = new HashMap<String,Object>();
				o.put("id", idc); o.put("motivo", motivoCob);
				if (planDeCob.get(idc)  != null) { o.put("nombrePlan",      planDeCob.get(idc)); }
				if (opcionDeCob.get(idc) != null) { o.put("nombreCobertura", opcionDeCob.get(idc)); }
				omitCobDet.add(o);
			}
			List<Object> omitPlanDet = new ArrayList<Object>();
			for (Integer idp : omitPlan) {
				Map<String,Object> o = new HashMap<String,Object>();
				o.put("id", idp); o.put("motivo", motivoPlan);
				omitPlanDet.add(o);
			}

			Map<String,Object> resEmp = new HashMap<String,Object>();
			resEmp.put("resultado", resultadoStr);
			List<Object> aplicadasDet = new ArrayList<Object>();
			for (Integer idc : aplicadasCobEmp) {
				Map<String,Object> a = new HashMap<String,Object>();
				a.put("id", idc);
				if (planDeCob.get(idc)  != null) { a.put("nombrePlan",      planDeCob.get(idc)); }
				if (opcionDeCob.get(idc) != null) { a.put("nombreCobertura", opcionDeCob.get(idc)); }
				aplicadasDet.add(a);
			}
			resEmp.put("forzadasAplicadas", aplicadasDet);
			resEmp.put("forzadasOmitidas", omitCobDet);
			resEmp.put("planesOmitidos", omitPlanDet);
			// CREA06 RF026: plan de retiro NO asignado por antiguedad (<6m). Nombres para el banner del grid.
			if (!retiroBloqueadoEmp.isEmpty()) {
				resEmp.put("mesesAntiguedad", mesesAntEmp);
				java.util.List<String> retiroNombres = new java.util.ArrayList<String>();
				try {
					StringBuilder ids = new StringBuilder();
					for (Integer id : retiroBloqueadoEmp) { if (ids.length() > 0) { ids.append(','); } ids.append(id.intValue()); }
					// CREA06: SP en vez de query en duro con IN concatenado (bf_DefaulteoAvanzado_GetNombresPlanOpcion).
					Map<String, Object> outNom = new SimpleJdbcCall(jdbcTemplate)
						.withProcedureName("bf_DefaulteoAvanzado_GetNombresPlanOpcion")
						.execute(new MapSqlParameterSource("Ids", ids.toString()));
					for (Map<String,Object> r : primerResultSetCE(outNom)) { retiroNombres.add(String.valueOf(r.get("PONombre"))); }
				} catch (Exception ig) { /* si falla el nombre, igual reportamos ids */ }
				resEmp.put("retiroBloqueadoNombres", retiroNombres);
			}
			defaulteados.add(resEmp);

		}

		return defaulteados;

	}

	// Helper: parseo defensivo de Object -> Integer (null si no es numerico).
	private static Integer toInt(Object o){
		if (o == null) { return null; }
		try { return Integer.valueOf(String.valueOf(o).trim()); } catch (Exception e) { return null; }
	}

	/** CREA06: primer result set (List<Map>) de un SimpleJdbcCall; lista vacia si no hay. */
	@SuppressWarnings("unchecked")
	private static List<Map<String, Object>> primerResultSetCE(Map<String, Object> out){
		if (out != null) {
			for (Object v : out.values()) {
				if (v instanceof List) { return (List<Map<String, Object>>) v; }
			}
		}
		return new ArrayList<Map<String, Object>>();
	}

	/** CREA06: primera fila del primer result set de un SimpleJdbcCall; null si no hay. */
	private static Map<String, Object> primeraFilaCE(Map<String, Object> out){
		List<Map<String, Object>> rs = primerResultSetCE(out);
		return (rs != null && !rs.isEmpty()) ? rs.get(0) : null;
	}


	public DatosInicialesBuscaPlanesPerfilV2 buscarDatosIniciales(int idEmpleado) {
		String sql = "declare " + "@IdEmpleado int, " + "@IdEmpresa int, " + "@IdPerfil int, "
				+ "@NumeroEmpleado varchar(20), " + "@XmlAnterior varchar(max), " + "@XmlNuevo varchar(max) "
				+ "Set @IdEmpleado = ? " + "select top 1 @IdEmpresa = EMIdEmpresa, @IdPerfil = EMIdPerfil, "
				+ "@NumeroEmpleado = EMNumeroEmpleado " + "from dbo.ff_Empleado " + "where Id = @IdEmpleado "
				+ "declare @tmpDatosIniciales TABLE( " + "IdVigencia int, " + "	IdVigenciaAnterior int, "
				+ "	NucleoFamiliarForzoso char(1)," + "	IdEstatusVigencia int,  " + "	FechaInicioVigencia datetime, "
				+ "	IdTarifaPorVigencia int,  " + "	GrupoParentescoTitular int ,  " + "	NumeroOficinaEmpleado int , "
				+ "	FechaIngresoEmpleado datetime, " + "	SalarioBase money, " + "	AntiguedadEmpleado money, "
				+ "	IdConfiguracion int, " + "	PeridicidadNombre VARCHAR(150), " + "	CantidadPago INT, "
				+ "	IdCorporativo int, " + "	AniosAntiguedad int, " + "	IdPeriodicidadPago int, "
				+ "	DistribuirSobrante int " + "	) " + "insert into @tmpDatosIniciales "
				+ "execute ff_CEDatosIniciales @IdEmpleado,@IdEmpresa,@IdPerfil " + "Select * from @tmpDatosIniciales "
				+ "declare " + "	@IdVigencia int, " + "	@IdVigenciaAnterior int = null, "
				+ "	@NucleoFamiliarForzoso char(1),  " + "	@IdEstatusVigencia int, "
				+ "	@FechaInicioVigencia datetime,  " + "	@IdTarifaPorVigencia int, "
				+ "	@GrupoParentescoTitular int = null, " + "	@NumeroOficinaEmpleado int = null, "
				+ "	@FechaIngresoEmpleado datetime = null, " + "	@SalarioBase money = null, "
				+ "	@AntiguedadEmpleado money = null, " + "	@IdConfiguracion int, "
				+ "	@PeridicidadNombre VARCHAR(150), " + "	@CantidadPago INT, " + "	@IdCorporativo int, "
				+ "	@AniosAntiguedad int, " + "	@IdPeriodicidadPago int, " + "	@DistribuirSobrante int " +

				"	   select " + "	@IdVigencia = IdVigencia, " + "	@IdVigenciaAnterior = IdVigenciaAnterior, "
				+ "	@NucleoFamiliarForzoso = NucleoFamiliarForzoso, " + "	@IdEstatusVigencia = IdEstatusVigencia, "
				+ "	@FechaInicioVigencia = FechaInicioVigencia, " + "	@IdTarifaPorVigencia = IdTarifaPorVigencia, "
				+ "	@GrupoParentescoTitular  = GrupoParentescoTitular, "
				+ "	@NumeroOficinaEmpleado  = NumeroOficinaEmpleado, "
				+ "	@FechaIngresoEmpleado = FechaIngresoEmpleado, " + "	@SalarioBase = SalarioBase, "
				+ "	@AntiguedadEmpleado  = AntiguedadEmpleado, " + "	@IdConfiguracion = IdConfiguracion, "
				+ "	@PeridicidadNombre = PeridicidadNombre, " + "	@CantidadPago =CantidadPago, "
				+ "	@IdCorporativo  = IdCorporativo, " + "	@AniosAntiguedad = AniosAntiguedad, "
				+ "	@IdPeriodicidadPago = IdPeriodicidadPago, " + "	@DistribuirSobrante = DistribuirSobrante "
				+ "	From @tmpDatosIniciales ";
		DatosInicialesBuscaPlanesPerfilV2 datosIniciales = jdbcTemplate.queryForObject(sql,
				new DatosInicialesBuscaPlanesPerfilV2RM(), idEmpleado);
		return datosIniciales;
	}

	public Integer validaSolicitudExistente2(int idEmpresa, int idEmpleado, int idVigencia) {
		Integer solicitudes = 0;
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("bf_ValidaSolicitudExistente2");

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdEmpresa", idEmpresa);
		inParamMap.put("IdEmpleado", idEmpleado);
		inParamMap.put("idVigencia", idVigencia);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> resultPA = new ArrayList<Object>(simpleJdbcCallResult.values());
		for (int i = 0; i < resultPA.size(); i++) {
			if (resultPA.get(i).getClass().getName() != "java.lang.Integer") {
				@SuppressWarnings("unchecked")
				List<Object> listDatosValidos = (List<Object>) resultPA.get(i);
				for (int j = 0; j < listDatosValidos.size(); j++) {
					@SuppressWarnings("unchecked")
					Map<String, Object> mapDatosValidos = (Map<String, Object>) listDatosValidos.get(j);
					solicitudes = (Integer) (mapDatosValidos.get("Solicitudes"));
				}
			}
		}

		return solicitudes;
	}

	// CREA06 casos especiales (incidencias 2-4): validacion previa por empleado via SP bf_ValidarEmpleadoCasoEspecial
	// (existencia del empleado + empresa real + pertenencia a la empresa del layout + solicitud activa/autorizada en la
	// vigencia destino: ff_Solicitud SOIdEstatus IN (1,3), excluyendo Rechazada). Devuelve una fila con
	// Existe/EmpresaReal/PerteneceEmpresa/YaTieneSolicitud. NO se atrapa la excepcion del execute: si el SP no
	// esta desplegado, se propaga y el llamador (LogicaFfTitular) deja pasar al empleado (no bloquea por validacion).
	@Override
	public Map<String,Object> validarEmpleadoCasoEspecial(int idEmpleado, int idEmpresaLayout, int idVigencia) {
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("bf_ValidarEmpleadoCasoEspecial");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdEmpleado", idEmpleado);
		inParamMap.put("IdEmpresa",  idEmpresaLayout);
		inParamMap.put("IdVigencia", idVigencia);
		Map<String, Object> out = simpleJdbcCall.execute(new MapSqlParameterSource(inParamMap));

		Map<String, Object> fila = primeraFilaCE(out);
		Map<String,Object> r = new HashMap<String,Object>();
		Object empresaReal = (fila != null) ? fila.get("EmpresaReal") : null;
		r.put("existe",           esBitVerdadero(fila != null ? fila.get("Existe") : null));
		r.put("empresaReal",      (empresaReal instanceof Number) ? ((Number) empresaReal).intValue() : null);
		r.put("perteneceEmpresa", esBitVerdadero(fila != null ? fila.get("PerteneceEmpresa") : null));
		r.put("yaTieneSolicitud", esBitVerdadero(fila != null ? fila.get("YaTieneSolicitud") : null));
		return r;
	}

	// Normaliza un BIT de SQL Server (puede llegar como Boolean, Number 0/1 o "0"/"1") a boolean.
	private static boolean esBitVerdadero(Object v) {
		if (v == null) { return false; }
		if (v instanceof Boolean) { return ((Boolean) v).booleanValue(); }
		if (v instanceof Number) { return ((Number) v).intValue() != 0; }
		return "1".equals(String.valueOf(v).trim());
	}

	@Override
	public List<Object> getConfPassword(int idEmpresa) {
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("ff_CObtenPasswordEmpresa");
		Map<String, Object> inParamMap = new HashMap<>();
		inParamMap.put("IdEmpresa", idEmpresa);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		return new ArrayList<>(simpleJdbcCallResult.values());
	}

	@Override
    public List<Object> getIdEyRetiro(int idAdm) {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("bf_ObtenerIdAdministrador");
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("Id", idAdm);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        return new ArrayList<>(simpleJdbcCallResult.values());
    }

	// INC002/RF019: Obtener datos de ultima solicitud para lista de empleados
	@Override
	public List<Map<String, Object>> obtenerUltimasSolicitudesEmpleados(String idEmpleados) {
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("ff_GetUltimaSolicitudPorEmpleados")
				.returningResultSet("result", (rs, rowNum) -> {
					Map<String, Object> row = new HashMap<>();
					row.put("IdEmpleado", rs.getInt("IdEmpleado"));
					row.put("IdSolicitud", rs.getObject("IdSolicitud"));
					row.put("NumeroSolicitud", rs.getObject("NumeroSolicitud"));
					row.put("Anexo", rs.getObject("Anexo"));
					row.put("EstatusSolicitud", rs.getString("EstatusSolicitud"));
					row.put("AdministradorSolicitud", rs.getString("AdministradorSolicitud"));
					row.put("SOIdEstatus", rs.getString("SOIdEstatus"));
					row.put("SOIdEmpresa", rs.getString("SOIdEmpresa"));
					row.put("SOUsuarioAdd", rs.getString("SOUsuarioAdd"));
					return row;
				});

		Map<String, Object> inParamMap = new HashMap<>();
		inParamMap.put("IdEmpleados", idEmpleados);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> result = simpleJdbcCall.execute(in);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> resultList = (List<Map<String, Object>>) result.get("result");

		return (resultList != null) ? resultList : new ArrayList<>();
	}
	@Override
	public List<Object> consultarTitularesAvanzado(Integer IdCorporativo,String IdEmpresas,String Busca,String Operador1,String CampoBusca,Integer BusquedaAvanzada,String OperadorAvanzado,String Busca2,String Operador2,String CampoBusca2,int idAdm) {

		String nombreSP = "ff_ConsultaEmpleadosEmpresa";
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		inParamMap.put("IdCorporativo", IdCorporativo);
		inParamMap.put("IdEmpresas", IdEmpresas);
		inParamMap.put("Busca", Busca);
		inParamMap.put("Operador1", Operador1);
		inParamMap.put("CampoBusca", CampoBusca);
		inParamMap.put("BusquedaAvanzada", BusquedaAvanzada);
		inParamMap.put("OperadorAvanzado", OperadorAvanzado);
		inParamMap.put("Busca2", Busca2);
		inParamMap.put("Operador2", Operador2);
		inParamMap.put("CampoBusca2", CampoBusca2);
		inParamMap.put("idAdm", idAdm);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		listSP = listSP.isEmpty() ? listSP : new ArrayList<Object>((Collection<? extends Object>) listSP.get(0));

		if ( !listSP.isEmpty() && ((Map<String,String>)listSP.get(0)).containsKey("Perfil") ) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((registro) -> {
				if ( !((Map<String,String>)registro).get("Perfil").toString().equalsIgnoreCase("Administrador")) {
					tmp.add(registro);
				}
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		return listSP;
	}
	
	@Override
	public List<Object> consultarDependientesAvanzado(Integer IdCorporativo,String IdEmpresas,String Busca,String Operador1,String CampoBusca,Integer BusquedaAvanzada,String OperadorAvanzado,String Busca2,String Operador2,String CampoBusca2,int idAdm) {

		String nombreSP = "ff_ConsultaEmpleadoDependienteEmpresa";
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		Map<String, Object> inParamMap = new HashMap<String, Object>();

		inParamMap.put("IdCorporativo", IdCorporativo);
		inParamMap.put("IdEmpresas", IdEmpresas);
		inParamMap.put("Busca", Busca);
		inParamMap.put("Operador1", Operador1);
		inParamMap.put("CampoBusca", CampoBusca);
		inParamMap.put("BusquedaAvanzada", BusquedaAvanzada);
		inParamMap.put("OperadorAvanzado", OperadorAvanzado);
		inParamMap.put("Busca2", Busca2);
		inParamMap.put("Operador2", Operador2);
		inParamMap.put("CampoBusca2", CampoBusca2);
		inParamMap.put("idAdm", idAdm);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> listSP = new ArrayList<Object>(simpleJdbcCallResult.values());
		listSP = listSP.isEmpty() ? listSP : new ArrayList<Object>((Collection<? extends Object>) listSP.get(0));

		if ( !listSP.isEmpty() && ((Map<String,String>)listSP.get(0)).containsKey("Perfil") ) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((registro) -> {
				if ( !((Map<String,String>)registro).get("Perfil").toString().equalsIgnoreCase("Administrador")) {
					tmp.add(registro);
				}
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		return listSP;
	}

	@Override
	public List<Object> busquedaDefaulteoAvanzada(Map<String,Object> parametros){
		List<Object> listSP = new ArrayList<Object>();

		// CREA06 casos especiales: si viene CasosEspeciales=1, usar el SP v2 (3 columnas extra)
		boolean casosEspeciales = parametros.get("CasosEspeciales") != null && "1".equals(parametros.get("CasosEspeciales").toString());
		String nombreSP = casosEspeciales ? "bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado_V2" : "bf_DefaulteoEmpleadosBF3MultivigenciaAvanzado";
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		
		// Generar objeto de parametros
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdsEmpresas",parametros.get("IdsEmpresas").toString());
		inParamMap.put("idAtributo1",parametros.get("idAtributo1").toString());
		inParamMap.put("idAtributo2",parametros.get("idAtributo2").toString());
		inParamMap.put("idTipoOperador1",parametros.get("idTipoOperador1").toString());
		inParamMap.put("idTipoOperador2",parametros.get("idTipoOperador2").toString());
		inParamMap.put("parametroBusqueda1",parametros.get("parametroBusqueda1").toString());
		inParamMap.put("parametroBusqueda2",parametros.get("parametroBusqueda2").toString());
		inParamMap.put("idTipoOperadorAvanzado",parametros.get("idTipoOperadorAvanzado").toString());
		inParamMap.put("idPerfiles",parametros.get("idPerfiles").toString());
		inParamMap.put("BusquedaAvanzada",parametros.get("BusquedaAvanzada").toString());
		inParamMap.put("IdAdministrador",parametros.get("IdAdministrador").toString());
		inParamMap.put("Vigencia",parametros.get("Vigencia").toString());
		
		// Obtener resultados
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		
		if(simpleJdbcCallResult.containsKey("#result-set-1")){
			listSP = (List<Object>) simpleJdbcCallResult.get("#result-set-1");
		}
		
		return listSP;
	}

	@Override
	public List<Object> getCoberturasPorPlanVigencia(int idPlan, int idVigencia){
		// CREA06: SP en vez de query en duro (bf_DefaulteoAvanzado_GetCoberturasPorPlanVigencia).
		Map<String, Object> in = new HashMap<String, Object>();
		in.put("IdPlan", idPlan);
		in.put("IdVigencia", idVigencia);
		Map<String, Object> out = new SimpleJdbcCall(jdbcTemplate)
			.withProcedureName("bf_DefaulteoAvanzado_GetCoberturasPorPlanVigencia")
			.execute(new MapSqlParameterSource(in));
		return new ArrayList<Object>(primerResultSetCE(out));
	}

	@Override
	public Integer getUltimoIdSolicitud(int idEmpleado, int idVigencia){
		// CREA06: SP en vez de query en duro (bf_DefaulteoAvanzado_GetUltimoIdSolicitud).
		try {
			Map<String, Object> in = new HashMap<String, Object>();
			in.put("IdEmpleado", idEmpleado);
			in.put("IdVigencia", idVigencia);
			Map<String, Object> out = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("bf_DefaulteoAvanzado_GetUltimoIdSolicitud")
				.execute(new MapSqlParameterSource(in));
			Map<String, Object> row = primeraFilaCE(out);
			return (row != null) ? toInt(row.get("idSolicitud")) : null;
		} catch (Exception e) { return null; }
	}

	@Override
	public List<Object> buscaTitularesAvanzado(Map<String, Object> parametros){
		List<Object> listSP = new ArrayList<Object>();

		String nombreSP = "ff_CPlantillaConsultaTitularesTotalStatementAvanzado";
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		// Recupear id de empresas y perfiles
		String idEmpresasValue = parametros.get("listaEmpresas").toString();
		String[] empresasList = idEmpresasValue.split(",");

		String idPerfilesValue = parametros.get("IdPerfil").toString();
		String[] perfilesList = idPerfilesValue.split(",");
		// Generar objeto de parametros
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdEmpresa", "");
		inParamMap.put("IdPerfil", "");
		inParamMap.put("Pantalla", parametros.get("Pantalla").toString());
		inParamMap.put("IdAdministrador", parametros.get("IdAdministrador").toString());
		inParamMap.put("perfiles", parametros.get("perfiles").toString());
		inParamMap.put("idAtributo1", parametros.get("idAtributo1").toString());
		inParamMap.put("idAtributo2", parametros.get("idAtributo2").toString());
		inParamMap.put("idTipoOperador1", parametros.get("idTipoOperador1").toString());
		inParamMap.put("idTipoOperador2", parametros.get("idTipoOperador2").toString());
		inParamMap.put("parametroBusqueda1", parametros.get("parametroBusqueda1").toString());
		inParamMap.put("parametroBusqueda2", parametros.get("parametroBusqueda2").toString());
		inParamMap.put("BusquedaAvanzada", parametros.get("BusquedaAvanzada").toString());
		inParamMap.put("idTipoOperadorAvanzado", parametros.get("idTipoOperadorAvanzado").toString());
		// Recorrer empresas y obtener resultados
		for(int index=0; index < empresasList.length; index++){
			String idEmpresa = empresasList[index];
			String idPerfil = perfilesList[index];

			inParamMap.put("IdEmpresa", idEmpresa);
			inParamMap.put("IdPerfil", idPerfil);
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
			List<Object> empresaResult = new ArrayList<Object>();
			if(simpleJdbcCallResult.containsKey("#result-set-1")){
				empresaResult = (List<Object>) simpleJdbcCallResult.get("#result-set-1");
			}
			// Agregar resultados a lista final
			if(!empresaResult.isEmpty()){
				listSP.addAll(empresaResult);
			}
		}
		
		// Si el resultado tiene la propiedad Perfil, descartar aquellos con valor Administrador
		if ( !listSP.isEmpty() && ((Map<String,String>)listSP.get(0)).containsKey("Perfil") ) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((registro) -> {
				if ( !((Map<String,String>)registro).get("Perfil").toString().equalsIgnoreCase("Administrador")) {
					tmp.add(registro);
				}
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		// Si el SP no pertenece a baja de titulares, ordenar registros
		if (!listSP.isEmpty() && (PlantillasTitulares.CONSULTA_BAJA_TITULARES_FD.getNombreSP().equalsIgnoreCase(nombreSP))) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((titular)->{
				Map<String,Object> titularMap = (Map<String,Object>)titular;
				LinkedCaseInsensitiveMap<String> lcim = new LinkedCaseInsensitiveMap<String>();
				if (titularMap.size() > 1) {
					titularMap.forEach((k, v) -> {
						String key = k.trim();
						if (!"Empresa".equals(key) && !key.contains("_c_")) {
							lcim.putIfAbsent(key, v != null ? v.toString() : null);
							lcim.putIfAbsent("Empresa", titularMap.get("Empresa").toString());
						} else if (!"Empresa".equals(key)) {
							lcim.putIfAbsent(key, v != null ? v.toString() : null);
							if ("_c_EMNumeroEmpleado".equals(key)) {
								lcim.putIfAbsent("_c_emIdEmpresa", titularMap.get("_c_emIdEmpresa") != null ? titularMap.get("_c_emIdEmpresa").toString() : null);
								lcim.putIfAbsent("Número Empleado", v != null ? v.toString() : null);
							}
						}
					});
				}
				tmp.add(lcim);
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		return listSP;
	}

	@Override
	public List<Object> buscaTitularesMovimientosAvanzado(Map<String, Object> parametros){
		List<Object> listSP = new ArrayList<Object>();

		Integer IdCorporativo = (Integer)parametros.get("IdCorporativo");

		// Generar consulta
		String nombreSP = "ff_CPlantillaBajaTitulares_bf3_Avanzado";

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		parametros.put("Pantalla",  "ff_Admi_Consulta.aspx");

		SqlParameterSource in = new MapSqlParameterSource(parametros);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		
		if(simpleJdbcCallResult.containsKey("#result-set-1")){
			listSP = (List<Object>) simpleJdbcCallResult.get("#result-set-1");
		}
		// Obtener perfiles
		if( ((Map<String,String>)listSP.get(0)).containsKey("_c_perfil") ){
			List<FfCObtenPerfil> perfiles = pef_dao.obtenerPerfilesPorCorporativo(IdCorporativo, true);
			listSP.forEach((titular) -> {
				Map<String,Object> titularMap = (Map<String,Object>)titular;
				for (FfCObtenPerfil perfil : perfiles) {
					if (titularMap.get("_c_perfil") != null &&
							perfil.getIdPerfil() == Integer.parseInt(titularMap.get("_c_perfil").toString())) {
						titularMap.put("Perfil", perfil.getNombrePerfil());
						break;
					}
				}
			});
		}
		// Omitir perfiles administrador
		if ( !listSP.isEmpty() && ((Map<String,String>)listSP.get(0)).containsKey("Perfil") ) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((registro) -> {
				if ( !((Map<String,String>)registro).get("Perfil").toString().equalsIgnoreCase("Administrador")) {
					tmp.add(registro);
				}
			});
			listSP.clear();
			listSP.addAll(tmp);
		}

		// Ordenar y obtener perfiles
		if (!listSP.isEmpty()) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((titular)->{
				Map<String,Object> titularMap = (Map<String,Object>)titular;
				LinkedCaseInsensitiveMap<String> lcim = new LinkedCaseInsensitiveMap<String>();
				if (titularMap.size() > 1) {
					titularMap.forEach((k, v) -> {
						String key = k.trim();
						if (!"Empresa".equals(key) && !key.contains("_c_")) {
							lcim.putIfAbsent(key, v != null ? v.toString() : null);
							lcim.putIfAbsent("Empresa", titularMap.get("Empresa").toString());
						} else if (!"Empresa".equals(key)) {
							lcim.putIfAbsent(key, v != null ? v.toString() : null);
							if ("_c_EMNumeroEmpleado".equals(key)) {
								lcim.putIfAbsent("_c_emIdEmpresa", titularMap.get("_c_emIdEmpresa") != null ? titularMap.get("_c_emIdEmpresa").toString() : null);
								lcim.putIfAbsent("Número Empleado", v != null ? v.toString() : null);
							}
						}
					});
				}
				tmp.add(lcim);
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		return listSP;
	}

	// Buscar titulares total statement sin id perfiles
	@Override
	public List<Object> buscaTitularesStatement(Map<String, Object> parametros){ 
		List<Object> listSP = new ArrayList<Object>();

		String nombreSP = "ff_ConsultaTitularesStatementAvanzado";
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(nombreSP);
		// Generar objeto de parametros
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("IdCorporativo", parametros.get("IdCorporativo").toString());
		inParamMap.put("IdEmpresa", parametros.get("IdEmpresa").toString());
		inParamMap.put("IdPerfil", parametros.get("IdPerfil").toString());
		inParamMap.put("Pantalla", parametros.get("Pantalla").toString());
		inParamMap.put("IdAdministrador", parametros.get("IdAdministrador").toString());
		inParamMap.put("IdEmpresas", parametros.get("IdEmpresas").toString());
		// inParamMap.put("perfiles", parametros.get("perfiles").toString());
		inParamMap.put("idAtributo1", parametros.get("idAtributo1").toString());
		inParamMap.put("idAtributo2", parametros.get("idAtributo2").toString());
		inParamMap.put("idTipoOperador1", parametros.get("idTipoOperador1").toString());
		inParamMap.put("idTipoOperador2", parametros.get("idTipoOperador2").toString());
		inParamMap.put("parametroBusqueda1", parametros.get("parametroBusqueda1").toString());
		inParamMap.put("parametroBusqueda2", parametros.get("parametroBusqueda2").toString());
		inParamMap.put("BusquedaAvanzada", parametros.get("BusquedaAvanzada").toString());
		inParamMap.put("idTipoOperadorAvanzado", parametros.get("idTipoOperadorAvanzado").toString());
		// Recorrer empresas y obtener resultados
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		List<Object> empresaResult = new ArrayList<Object>();
		if(simpleJdbcCallResult.containsKey("#result-set-1")){
			listSP = (List<Object>) simpleJdbcCallResult.get("#result-set-1");
		}
		
		// Si el resultado tiene la propiedad Perfil, descartar aquellos con valor Administrador
		if ( !listSP.isEmpty() && ((Map<String,String>)listSP.get(0)).containsKey("Perfil") ) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((registro) -> {
				if ( !((Map<String,String>)registro).get("Perfil").toString().equalsIgnoreCase("Administrador")) {
					tmp.add(registro);
				}
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		// Si el SP no pertenece a baja de titulares, ordenar registros
		if (!listSP.isEmpty() && (PlantillasTitulares.CONSULTA_BAJA_TITULARES_FD.getNombreSP().equalsIgnoreCase(nombreSP))) {
			List<Object> tmp = new ArrayList<>();
			listSP.forEach((titular)->{
				Map<String,Object> titularMap = (Map<String,Object>)titular;
				LinkedCaseInsensitiveMap<String> lcim = new LinkedCaseInsensitiveMap<String>();
				if (titularMap.size() > 1) {
					titularMap.forEach((k, v) -> {
						String key = k.trim();
						if (!"Empresa".equals(key) && !key.contains("_c_")) {
							lcim.putIfAbsent(key, v != null ? v.toString() : null);
							lcim.putIfAbsent("Empresa", titularMap.get("Empresa").toString());
						} else if (!"Empresa".equals(key)) {
							lcim.putIfAbsent(key, v != null ? v.toString() : null);
							if ("_c_EMNumeroEmpleado".equals(key)) {
								lcim.putIfAbsent("_c_emIdEmpresa", titularMap.get("_c_emIdEmpresa") != null ? titularMap.get("_c_emIdEmpresa").toString() : null);
								lcim.putIfAbsent("Número Empleado", v != null ? v.toString() : null);
							}
						}
					});
				}
				tmp.add(lcim);
			});
			listSP.clear();
			listSP.addAll(tmp);
		}
		return listSP;
	}

}
