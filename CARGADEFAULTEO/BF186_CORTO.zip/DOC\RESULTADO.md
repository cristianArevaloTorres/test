# Validacion final - empresa 186

Fecha: 23 de agosto de 2026.

Ambiente validado: `(localdb)\MSSQLLocalDB`, base `FlexiForbesv2`.

## Resultado ejecutivo

La homologacion de carga masiva B2/B3 y defaulteo 1/2/3 quedo revisada y se
corrigieron defectos reales de frontend, backend y SQL. La configuracion local
final permite la pantalla B3 (Excel) y conserva B2 para procesos automaticos.

El menu BF3 muestra **Defaulteo** al mismo nivel de Carga Masiva, inmediatamente
despues de esta, para el rol 570 y con la misma imagen
`Boton_CARGA MASIVA.png`.

## Matriz de pruebas

| Area | Escenario | Resultado |
|---|---|---|
| Selector de flujo | B2/B2 | OK; guardado y resolucion comprobados con rollback |
| Selector de flujo | B2/B3 | OK; guardado y resolucion comprobados con rollback |
| Selector de flujo | B3/B2 | OK; guardado y resolucion comprobados con rollback |
| Selector de flujo | B3/B3 | OK; guardado y resolucion comprobados con rollback |
| Selector de flujo | Valor invalido B4 | OK; rechazado por SQL |
| Estado final empresa 186 | Pantalla B3 / automatico B2 | OK |
| Carga masiva | 7 operaciones activas y sus SP | OK; todos los objetos existen |
| Carga masiva | Alta de dependiente mediante `ff_XCMDependientesAltaCMM` | OK; inserto 1 fila y el rollback dejo 0 residuos |
| Archivo B2 | TXT con `@fieldNames:` y `@data:` | OK; ejemplo incluido |
| Archivo B3 | Excel plantilla 182, hoja `Poblacion` y catalogo oculto | OK; lectura y columnas validadas |
| Defaulteo 1 | Empleado `QADEF1-186` con solicitud/seleccion previa | Rama `def1` ejecutada |
| Defaulteo 2 | Empleado `QADEF2-186` con plan basico | Rama `def2` ejecutada |
| Defaulteo 3 | `QADEF3C-186`, sin dependientes | Rama `def3` ejecutada |
| Defaulteo 3 | `QADEF3D-186`, con dependiente | Rama `def3` ejecutada |
| Reintento | `QADEF-RTRY-186`, solicitud activa en destino | OK; queda fuera de los procesables |
| Persistencia defaulteo | Insercion temporal + creacion de solicitud | OK; `Durante=1`, `Despues=0` por rollback |
| Integridad | `DBCC CHECKCONSTRAINTS` | OK; sin errores |
| Menu BF3 | Hermano de Carga Masiva, orden +1, rol e imagen | OK |

## Correcciones aplicadas

1. Se corrigio en B3 la autorizacion de la plantilla legada 507, que solo trae
   `EMEmpresa` y antes podia terminar comparando contra empresa `0`.
2. Se corrigieron comparaciones de cadenas y tipos en Java que usaban identidad
   de objeto (`==`/`!=`) en lugar de valor.
3. El endpoint masivo de defaulteo ahora exige token, valida empresas y
   empleados asignados, y toma el administrador desde el JWT.
4. El motor Java ya no continua como exito si SQL no devuelve ningun plan
   elegible; devuelve una advertencia/error verificable.
5. Se corrigio la firma SQL de dos procedimientos legados que llamaban
   `ff_IInsertaPlanesFlexiblesTmpCreditos` sin el septimo parametro
   `@IdCorporativo`. El parche idempotente es el instalador `004.sql`.
6. Los folios dummy se normalizaron a valores numericos porque
   `ff_CreateSolicitudTest` ejecuta `CONVERT(int, SONumeroSolicitud)`.
7. Los dummy se movieron a la pareja real de negocio tipo 1 `481 -> 633` y se
   agregaron tarifa historica, perfiles, elegibilidad, plan basico y calendario.

## Observacion importante sobre el fragmento local

El procedimiento V31 entra correctamente a las ramas `def1`, `def2` y `def3`,
pero el fragmento local no produce una fila final `Checked=true` en su resultset
visual. La elegibilidad previa llega hasta tarifa y la cadena de persistencia se
probo correctamente pasando esa tarifa de manera controlada.

Por seguridad se corrigio Java para que esta condicion no pueda registrarse
como solicitud exitosa. La aceptacion completamente end-to-end debe repetirse
en QA con el catalogo completo de planes, compensaciones y candados de la
empresa. No se implemento un fallback que asigne planes sin respetar el motor.

## Compilacion y pruebas de codigo

- Angular: `npx tsc -p src/tsconfig.app.json --noEmit` termino correctamente.
- Bundle Angular legado: llega a la fase de bundle, pero los workers fallan con
  `Call retries were exceeded` bajo Node 24; requiere la version de Node del
  proyecto para cerrar el empaquetado Webpack.
- API de reportes Java: compilacion correcta; 14 pruebas, 0 fallas y 0 errores.
- Backend Java principal: Maven no puede generar clientes SOAP porque el WSDL
  interno `172.17.0.59:2003` no es accesible desde este equipo. Al saltar esa
  fase faltan precisamente las clases generadas.
- B2 .NET: el equipo no tiene instalado el targeting pack de .NET Framework 4.0
  y MSBuild termina con `MSB3644`.

## Archivos para repetir la validacion

- `DB/PRUEBAS/TEST_FLUJOS_B2_B3_186.sql`
- `DB/PRUEBAS/DUMMY_DEF_123_186.sql`
- `DB/PRUEBAS/TEST_MOTOR_DEF_123_186.sql`
- `DB/PRUEBAS/TEST_TRANSACCION_DEF_186.sql`
- `DB/PRUEBAS/VERIFICACION_FINAL_186.sql`
- `DB/PRUEBAS/MENU_DEF_NIVEL_CM_186.sql`
- `EJEMPLOS/EJEMPLO_B2_ALTA_DEPENDIENTE_EMPRESA_186.txt`
- `EJEMPLOS/EJEMPLO_B3_ALTA_DEPENDIENTE_EMPRESA_186.xlsx`

Los scripts de prueba y datos estan separados del instalador. El instalador
consolidado es `DB/INSTALL/ALL.sql`.
