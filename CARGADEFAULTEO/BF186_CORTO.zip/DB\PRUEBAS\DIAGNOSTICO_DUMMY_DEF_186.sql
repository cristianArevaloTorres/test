SET NOCOUNT ON;
DECLARE @IdEmpresa int=186,@IdEmpleado int=7314557,@IdVigencia int=481;
DECLARE @Numero varchar(20),@Perfil int,@Tarifa int;
SELECT @Numero=EMNumeroEmpleado,@Perfil=EMIdPerfil FROM dbo.ff_Empleado WHERE Id=@IdEmpleado AND EMIdTitular=1 AND EMIdEstatus=1;
SELECT @Tarifa=TAIdTarifa FROM dbo.ff_Tarifa WHERE TAIdVigencia=@IdVigencia;

CREATE TABLE #V(PlanOpcion int,IdEmpleado int,Paso int);
INSERT #V SELECT PV.VCIdPlanOpcion,0,2
FROM dbo.ff_PlanOpcionVigencia PV
JOIN dbo.ff_Vigencia V ON V.VIIdVigencia=PV.VCIdVigencia AND V.VITipoNegocio=1
JOIN dbo.ff_Empresa E ON E.EMIdConfiguracion=V.VIIdConfiguracion
JOIN dbo.ff_PlanOpcionPerfil PP ON PP.PPIdPlanOpcion=PV.VCIdPlanOpcion
WHERE E.EMIdEmpresa=@IdEmpresa AND PV.VCIdVigencia=@IdVigencia
  AND PV.VCIdEstatus=2 AND PP.PPIdEstatus=1 AND PP.PPIdPerfil=@Perfil;
SELECT '01 perfil/vigencia' Paso,COUNT(*) Cantidad FROM #V;

INSERT #V SELECT DISTINCT S.PSIdPlanOpcion,E.Id,3
FROM dbo.ff_Empleado E
JOIN #V V ON E.EMNumeroEmpleado=@Numero AND E.EMIdEmpresa=@IdEmpresa
JOIN dbo.ff_PlanOpcionSexo S ON S.PSIdPlanOpcion=V.PlanOpcion AND S.PSIdSexo=E.EMIdSexo
WHERE E.EMIdEstatus=1;
DELETE #V WHERE Paso=2;
SELECT '02 sexo' Paso,COUNT(*) Cantidad FROM #V;

CREATE TABLE #E(Id int,Parentesco int,Sexo int,Edad int);
INSERT #E SELECT Id,EMIdParentesco,EMIdSexo,dbo.regresaedadempleado(Id)
FROM dbo.ff_Empleado WHERE EMIdEmpresa=@IdEmpresa AND EMIdEstatus=1 AND EMNumeroEmpleado=@Numero;
SELECT '03 familia' Paso,COUNT(*) Cantidad FROM #E;

CREATE TABLE #EP(PlanOpcion int,IdEmpleado int,Parentesco int,Sexo int,Edad int);
INSERT #EP
SELECT P.PPIdPlanOpcion,E.Id,E.Parentesco,E.Sexo,E.Edad
FROM #E E JOIN dbo.ff_PlanOpcionParentescoEdad P ON P.PPIdParentesco=E.Parentesco
WHERE E.Edad BETWEEN P.PPEdadMin AND P.PPEdadMax AND P.PPIdEstatus=1
  AND EXISTS(SELECT 1 FROM #V V WHERE V.PlanOpcion=P.PPIdPlanOpcion AND V.IdEmpleado=E.Id);
SELECT '04 parentesco/edad' Paso,COUNT(*) Cantidad FROM #EP;

SELECT '05 tarifa final' Paso,COUNT(*) Cantidad
FROM #E E JOIN #EP P ON P.IdEmpleado=E.Id
JOIN dbo.ff_TarifaCosto_hist T ON T.TCIdPlanOpcion=P.PlanOpcion
 AND T.TCIdParentesco=E.Parentesco AND T.TCIdSexo=E.Sexo AND T.TCEdad=E.Edad
 AND T.TCIdTarifa=@Tarifa AND T.TCIdEstatus=1
JOIN dbo.ff_Tarifa TA ON TA.TAIdTarifa=T.TCIdTarifa AND TA.TAIdEstatus=2 AND TA.TAIdVigencia=@IdVigencia;

