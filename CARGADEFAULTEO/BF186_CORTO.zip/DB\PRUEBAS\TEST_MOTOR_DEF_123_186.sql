/* Ejecuta la etapa de cálculo real V31 para los cuatro dummy procesables.
   idVigenciaD recibe la vigencia seleccionada para procesar (481), igual que
   el adaptador legado usado por BF3.
   No inserta solicitudes: es una prueba de solo lectura del motor. */
SET NOCOUNT ON;
DECLARE @Actual NVARCHAR(MAX)=N'{"costo":null,"idempleado":-1,"nuevo":null,"tcidtarifacosto":-1}';
DECLARE @Anterior NVARCHAR(MAX)=N'{"costoOld":null,"idempleadoOld":-1,"nuevoOld":null,"tcidtarifacostoOld":-1}';

PRINT 'TIPO 1 / QADEF1-186';
EXEC dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3
  @idempresa=186,@idempleado=7314557,@tmpplanesseleccionados=@Actual,
  @tmpplanesseleccionadosold=@Anterior,@transfer='def1',@idVigenciaD=481;

PRINT 'TIPO 2 / QADEF2-186';
EXEC dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3
  @idempresa=186,@idempleado=7314558,@tmpplanesseleccionados=@Actual,
  @tmpplanesseleccionadosold=@Anterior,@transfer='def2',@idVigenciaD=481;

PRINT 'TIPO 3 SIN DEPENDIENTES / QADEF3C-186';
EXEC dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3
  @idempresa=186,@idempleado=7314559,@tmpplanesseleccionados=@Actual,
  @tmpplanesseleccionadosold=@Anterior,@transfer='def3',@idVigenciaD=481;

PRINT 'TIPO 3 CON DEPENDIENTES / QADEF3D-186';
EXEC dbo.ff_CBuscaPlanesPerfil_V31TesMultivigenciaBF3
  @idempresa=186,@idempleado=7314560,@tmpplanesseleccionados=@Actual,
  @tmpplanesseleccionadosold=@Anterior,@transfer='def3',@idVigenciaD=481;
