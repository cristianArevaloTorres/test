package com.lockton.WSBeFlex.REST;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.lockton.WSBeFlex.POJO.Especiales.CBuscaTitularesTmp;
import com.lockton.WSBeFlex.POJO.Especiales.FfObtenPlantilla;
import com.lockton.WSBeFlex.Services.Autorizacion;
import com.lockton.WSBeFlex.Services.FfCObtenPlantillaService;
import com.lockton.WSBeFlex.Services.FfTitularService;
import mx.com.lockton.WS_PowerBI.IWSPowerBI;
import mx.com.lockton.WS_PowerBI.WSPowerBI;
import com.lockton.WSBeFlex.POJO.FfEmpleado;
import com.lockton.WSBeFlex.POJO.FfEmpleadoAdm;
import com.lockton.WSBeFlex.Services.GeneralesService;
import com.lockton.WSBeFlex.Services.FfDefaulteoAvanzadoService;
import com.lockton.WSBeFlex.Services.JwtService;
import com.lockton.WSBeFlex.Services.UsuarioToken;
import com.lockton.WSBeFlex.POJO.Especiales.FFDefaulteo;

/**
 * <p>
 * Esta clase contiene los métodos que devolverán la respuesta al cliente, por
 * medio de las rutas finales. Estas rutas de operación corresponden a cada
 * metodo de petición HTTP.
 * </p>
 *
 * <p>
 * La anotacién <b>@RestController</b>, usada en esta clase, indica que los
 * datos devueltos por cada método se escribirán directamente en el cuerpo de la
 * respuesta en lugar de representar una plantilla.
 * </p>
 *
 * <p>
 * La anotación <b>@RequestMapping</b>, al principio de la clase, asigna la
 * solicitud web a nivel clase, es decir, el valor "beflex/plantilla" sera el
 * comienzo de la ruta final en todos los métodos de esta clase.
 * </p>
 *
 * <p>
 * Se usa la anotación <b>@Autowired</b> para hacer la inyección de dependencias
 * de los bean servicios
 * {@link com.lockton.WSBeFlex.Services.FfCObtenPlantillaService} y
 * {@link com.lockton.WSBeFlex.Services.FfCPlantillaDependientesService}, que es
 * en donde se realizan la lógica de negocio y esta a su vez, realiza la
 * petición mediante inyección de dependencias a los bean repositorio {@link com.lockton.WSBeFlex.DAO.FfCObtenPlantillaDAO},
 * {@link com.lockton.WSBeFlex.DAO.FfCPlantillaDependientesDAO} y
 * {@link com.lockton.WSBeFlex.DAO.DocumentoDAO}, que hace la petición a la base
 * de datos.
 * </p>
 *
 * @author Andrea Hernández / BigPink
 * @since 1.0
 */
@RestController
@RequestMapping("beflex/titulares")
public class WSTitulares {

    private static final Log bitacora = LogFactory.getLog(WSPlantilla.class);

    @Autowired
    FfCObtenPlantillaService ffcps;

    @Autowired
    FfTitularService ff_tis;

    @Autowired
    GeneralesService general_Serv;

    @Autowired
    JwtService jwtService;

    @Autowired
    FfDefaulteoAvanzadoService defaulteoSeguridad;

    // CREA06 Casos Especiales (async): runner en background + registro de avance/resultado para el polling.
    @Autowired
    com.lockton.WSBeFlex.Services.CasosEspecialesAsyncRunner casosRunner;

    @Autowired
    com.lockton.WSBeFlex.Services.ProgresoDefaulteoRegistry progresoCasos;

    @GetMapping("/consultarBitacora")
    public ResponseEntity<List<Object>> obtenerEmpleadosPorEmpresaBitacora(@RequestParam String IdEmpresa,
            @RequestParam String Pantalla, @RequestParam String IdPerfil, @RequestParam String CampoBusca,
            @RequestParam String Busca, @RequestParam String idAdm) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerEmpleadosBitacora(IdEmpresa, Pantalla, IdPerfil, CampoBusca, Busca, idAdm);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    /**
     *
     * <p>
     * @param IdEmpresa asociada al parametro <b>IdEmpresa</b> del PA
     * <i>ff_CPlantillaDependientes</i>. Variable obtenida como parametro.
     * @param Pantalla asociada al parametro <b>Pantalla</b> del PA
     * <i>ff_CPlantillaDependientes</i>.Variable obtenida como parametro.
     * @param IdPerfil asociada al parametro <b>IdPerfil</b> del PA
     * <i>ff_CPlantillaDependientes</i>. Variable obtenida como parametro.
     * @return Lista de objetos dobtenida de la respuesta del PA
     * <i>ff_CPlantillaDependientes</i> desde el servicio
     * {@link com.lockton.WSBeFlex.Services.FfTitularService#consultarTitulares(Integer, String, int, String,String,int,String)}
     * </p>
     */
    @GetMapping("/consultar")
    public ResponseEntity<List<Object>> consultarTitulares(
            @RequestParam Integer IdEmpresa, @RequestParam String Pantalla, @RequestParam int IdPerfil,
            @RequestParam String Busca, @RequestParam String CampoBusca, @RequestParam int idAdm, @RequestHeader("authorization") String token) {

        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.buscaTitularesTmp(IdEmpresa, Pantalla, IdPerfil, Busca, CampoBusca, idAdm);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    /**
     *
     * <p>
     * @param idCorporativo valor para obtener sus correspondientes indicadores
     * afiliados al corporativo
     * @return un arreglo con todos los indicadores para las graficas
     * </p>
     */
    @GetMapping("/reportes/kpis")
    public ResponseEntity<List<Object>> obtenerIndicadoresPorRelacion(@RequestParam String idCorporativo) {

        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerIndicadoresPorRelacion(idCorporativo);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
    }

    /**
     *
     * <p>
     * @param aIdCorporativo corporativo de la grafica
     * @param aWorkspaceId Id del workspace de la grafica
     * @param aReportId id del reportId de la grafica
     * @param aJQuery true cuando el front no ocupa jquery de lo contrario false
     * @return el reporte
     * </p>
     */
    @GetMapping("/reportes/kpis/obtenerreporte")
    public ResponseEntity<String> obtenerReporte(@RequestParam String aIdCorporativo, @RequestParam String aWorkspaceId, @RequestParam String aReportId, @RequestParam boolean aJQuery) {
        java.lang.String result = "";
        try {
            WSPowerBI service = new WSPowerBI();
            IWSPowerBI port = service.getBasicHttpBindingIWSPowerBI();
            java.lang.Integer _aIdCorporativo = Integer.valueOf(aIdCorporativo);
            java.lang.String _aWorkspaceId = aWorkspaceId;
            java.lang.String _aReportId = aReportId;
            java.lang.Boolean _aJQuery = aJQuery;
            result = port.obtenerReporte(_aIdCorporativo, _aWorkspaceId, _aReportId, _aJQuery);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
        }
        if (result.isEmpty()) {
            return new ResponseEntity<String>(result, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<String>(result, HttpStatus.OK);

    }

    @GetMapping("/configuracionEnvio/vigenciasPorCorporativo")
    public ResponseEntity<List<Object>> obtenerEmpresasVigenciasPorCorporativo(@RequestParam int idCorporativo, @RequestHeader("authorization") String token) {
        List<Object> datosReporte = null;

        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                datosReporte = ff_tis.obtenerEmpresasVigenciasPorCorporativo(idCorporativo);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (datosReporte.isEmpty()) {
                return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.UNAUTHORIZED);
        }

    }

    @GetMapping("/configuracionEnvio/configuracion")
    public ResponseEntity<List<Object>> obtenerconfiguracionEnvio(@RequestParam int idCorporativo) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerconfiguracionEnvio(idCorporativo);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/configuracionEnvio/obtenerPlantillaNotificacionCorreo")
    public ResponseEntity<List<Object>> obtenerPlantillaYnotificacionCorreo(@RequestParam String idCorporativo, @RequestParam String idAdm, @RequestHeader("authorization") String token) {
        List<Object> datosReporte = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                datosReporte = ff_tis.obtenerPlantillaYnotificacionCorreo(idCorporativo, idAdm);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (datosReporte.isEmpty()) {
                return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/configuracionEnvio/insertarConfiguracionNotificacionEmpresa")
    public ResponseEntity<List<Object>> insertarConfiguracionNotificacionEmpresa(@RequestParam String idEmpresa, @RequestParam String idTipoNotificacion, @RequestParam String idPlantilla, @RequestParam String numeroDias,
            @RequestParam String orden, @RequestParam String idUsuario, @RequestHeader("authorization") String token) {
        List<Object> datosReporte = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                datosReporte = ff_tis.insertarConfiguracionNotificacionEmpresa(idEmpresa, idTipoNotificacion, idPlantilla, numeroDias,
                        orden, idUsuario);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (datosReporte.isEmpty()) {
                return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/configuracionEnvio/insertarConfiguracionEnvio")
    public ResponseEntity<List<Object>> insertarConfiguracionEnvio(@RequestParam String idConfiguracion, @RequestParam String idVigencia, @RequestParam String diaInicial, @RequestParam boolean envioAdministradores,
            @RequestParam String idPeriodicidad, @RequestHeader("authorization") String token) {
        List<Object> datosReporte = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                datosReporte = ff_tis.insertarConfiguracionEnvio(idConfiguracion, idVigencia, diaInicial, envioAdministradores,
                        idPeriodicidad);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (datosReporte.isEmpty()) {
                return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/configuracionEnvio/eliminarConfiguracionMantenimiento")
    public ResponseEntity<List<Object>> eliminarConfiguracionMantenimiento(@RequestParam String idConfiguracionEnvio, @RequestHeader("authorization") String token) {
        List<Object> datosReporte = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                datosReporte = ff_tis.eliminarConfiguracionMantenimiento(idConfiguracionEnvio);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (datosReporte.isEmpty()) {
                return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/configuracionEnvio/insertarConfiguracionMantenimiento")
    public ResponseEntity<List<Object>> insertarConfiguracionMantenimiento(@RequestParam String idConfiguracionEnvio, @RequestParam String fecha, @RequestHeader("authorization") String token) {
        List<Object> datosReporte = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                datosReporte = ff_tis.insertarConfiguracionMantenimiento(idConfiguracionEnvio, fecha);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (datosReporte.isEmpty()) {
                return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/configuracionEnvio/eliminar")
    public ResponseEntity<List<Object>> eliminarConfiguracion(@RequestParam String idConfiguracionEnvio, @RequestHeader("authorization") String token) {
        List<Object> datosReporte = null;
        List<Object> ffem = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                datosReporte = ff_tis.eliminarConfiguracion(idConfiguracionEnvio);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (datosReporte.isEmpty()) {
                return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/configuracionEnvio/editarConfiguracion")
    public ResponseEntity<List<Object>> editarConfiguracion(@RequestParam String idEmpresa, @RequestParam String idCorporativo, @RequestHeader("authorization") String token) {
        List<Object> datosReporte = null;
        List<Object> ffem = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                datosReporte = ff_tis.editarConfiguracion(idEmpresa, idCorporativo);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (datosReporte.isEmpty()) {
                return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/obtenerLeyendaEmpresa")
    public ResponseEntity<List<Object>> obtenerLeyendaEmpresa(@RequestParam String idVigencia) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerLeyendaEmpresa(idVigencia);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/bitacoraNavegacion")
    public ResponseEntity<List<Object>> obtenerReporteBitacoraNav(
            @RequestParam String tipoReporte, @RequestParam String fechaInicio,
            @RequestParam String fechaFinal, @RequestParam String idEmpresa,
            @RequestParam String idEmpleado, @RequestParam String idPerfil,
            @RequestParam String CampoBusca, @RequestParam String Busca) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerReporteBitacora(tipoReporte, fechaInicio, fechaFinal, idEmpresa, idEmpleado, idPerfil, CampoBusca, Busca);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/consultarTitular")
    public ResponseEntity<List<Object>> buscarTitularPorNumeroEmpleado(@RequestParam String numeroEmpleado, @RequestParam String idEmpresa, @RequestHeader("authorization") String token) {
        List<Object> ffem = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                ffem = ff_tis.buscarTitularPorNumeroEmpleado(numeroEmpleado, idEmpresa);
                return new ResponseEntity<List<Object>>(ffem, HttpStatus.OK);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/datosMailTitular")
    public ResponseEntity<List<Map<String, Object>>> bajaTitularDatosMail(@RequestBody List<Map<String, Object>> datos) {
        try {
            List<Map<String, Object>> response = ff_tis.bajaTitularDatosMail(datos);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            List<Map<String, Object>> errorResponse = new ArrayList<>();
            Map<String, Object> errorMap = new HashMap<>();
            errorMap.put("error", "Error al procesar los planes");
            errorResponse.add(errorMap);
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    @PostMapping("/datosMailDependiente")
    public ResponseEntity<List<Map<String, Object>>> datosMailDependiente(@RequestBody List<Map<String, Object>> datos) {
        try {
            List<Map<String, Object>> response = ff_tis.datosMailDependiente(datos);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            List<Map<String, Object>> errorResponse = new ArrayList<>();
            Map<String, Object> errorMap = new HashMap<>();
            errorMap.put("error", "Error al procesar los planes");
            errorResponse.add(errorMap);
            return ResponseEntity.status(500).body(errorResponse);
        }
    }    

    @GetMapping("/obtenerConfiguracionTotalStatement")
    public ResponseEntity<List<Object>> obtenerReporteBitacoraNav(@RequestParam String idParametro, @RequestParam String idEmpresa, @RequestParam String idPerfil) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerConfiguracionTotalStatement(idParametro, idEmpresa, idPerfil);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/reporteSolicitudesV3")
    public ResponseEntity<List<Object>> obtenerReporteSolicitudesEmpleado(@RequestParam String idCorporativo, @RequestParam String idEmpresa, @RequestParam String idPerfil,
            @RequestParam String idVigencia, @RequestParam String fechaInicio, @RequestParam String fechaFinal) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerReporteSolicitudesEmpleado(idCorporativo, idEmpresa, idPerfil, idVigencia, fechaInicio, fechaFinal);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/defaulteo")
    public ResponseEntity<List<Object>> obtenerGridDefaulteo(@RequestParam String idCorporativo, @RequestParam String idEmpresa, @RequestParam String numEmpleado, @RequestParam String apellidoPaterno, @RequestParam String apellidoMaterno, @RequestParam String nombreUno, @RequestParam String nombreDos) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerGridDefaulteo(idCorporativo, idEmpresa, numEmpleado, apellidoPaterno, apellidoMaterno, nombreUno, nombreDos);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/tiposPlanesDefault")
    public ResponseEntity<List<Object>> obtenerPlanesDefault() {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerPlanesDefault();
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/verificarUsuarioBitacora")
    public ResponseEntity<List<Object>> veriricarTipoUsuarioBitacora(@RequestParam String idUsuario) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.verificarUsuarioBitacora(idUsuario);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/planesVigenciaAnterior")
    public ResponseEntity<List<Object>> obtenerPlanesVigenciaAnterior(@RequestParam String idUsuario, @RequestParam String idVigencia, @RequestParam String idEmpresa) {
        List<Object> datosReporte = null;
        try {
            datosReporte = ff_tis.obtenerPlanesVigenciaAnterior(idUsuario, idVigencia, idEmpresa);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    /*
        *Metodo utilizado para verificar la solicitud creada en el modulo de defaulteo, y agregarle el adminsitrador que defualteo
     */
    @GetMapping("/verificarSolicitudDefaulteada")
    public ResponseEntity<List<Object>> verificarSolicitudDefaulteada(@RequestParam String idAdm, @RequestParam String idEmpleadoDefaulteado) {
        List<Object> datosReporte = null;
        try {

            datosReporte = ff_tis.verificarSolicitudDefaulteada(idAdm, idEmpleadoDefaulteado);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    @GetMapping("/defaulteoMultivigencia")
    public ResponseEntity<List<Object>> obtenerGridDefaulteoMultivigencia(@RequestParam String idCorporativo, @RequestParam String idEmpresa, @RequestParam String numEmpleado, @RequestParam String apellidoPaterno, @RequestParam String apellidoMaterno, @RequestParam String nombreUno, @RequestParam String nombreDos, @RequestParam String vigencia, @RequestParam int idAdministrador) {
        List<Object> datosReporte = null;
        try {

            datosReporte = ff_tis.obtenerGridDefaulteoMultivigencia(idCorporativo, idEmpresa, numEmpleado, apellidoPaterno, apellidoMaterno, nombreUno, nombreDos, vigencia, idAdministrador);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
        }
        if (datosReporte.isEmpty()) {
            return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<Object>>(datosReporte, HttpStatus.OK);

    }

    /**
     *
     * <p>
     * @param IdEmpresa asociada al parametro <b>IdEmpresa o Corporativo</b> del
     * PA <i>ff_CPlantillaConsultaTitularesEmpresaCorporativo</i>. Variable
     * obtenida como parametro.
     * @param Pantalla asociada al parametro <b>Pantalla</b> del PA
     * <i>ff_CPlantillaConsultaTitularesEmpresaCorporativo</i>.Variable obtenida
     * como parametro.
     * @param IdPerfil asociada al parametro <b>IdPerfil</b> del PA
     * <i>ff_CPlantillaConsultaTitularesEmpresaCorporativo</i>. Variable
     * obtenida como parametro.
     * @return Lista de objetos dobtenida de la respuesta del PA
     * <i>ff_CPlantillaConsultaTitularesEmpresaCorporativo</i> desde el servicio
     * {@link com.lockton.WSBeFlex.Services.FfTitularService#consultarCorpEmp(Integer, String, int, String,String,int)}
     * </p>
     */
    @GetMapping("/consultarCorpEmp")
    public ResponseEntity<List<Object>> consultarTitularesCorpEmp(
            @RequestParam Integer IdEmpresa, @RequestParam String Pantalla, @RequestParam int IdPerfil, @RequestParam String Busca,
            @RequestParam String CampoBusca, @RequestParam int idAdm, @RequestHeader("authorization") String token) {

        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.consultarTitularesCorpEmp(IdEmpresa, Pantalla, IdPerfil, Busca, CampoBusca, idAdm);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/defaultearMasivo")
    public ResponseEntity<List<Object>> defaultearEmpleadosMasivo(
            @RequestBody FFDefaulteo datos,
            @RequestHeader(value = "authorization", required = false) String token) {
        UsuarioToken usuario;
        try {
            if (token == null || !general_Serv.validarTokenId(0, token, 4)) {
                return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
            }
            usuario = jwtService.getPayloadFromToken(token);
        } catch (Exception e) {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
        if (usuario == null || usuario.n <= 0 || datos == null
                || datos.getIdEmpleado() == null || datos.getIdEmpleado().length == 0
                || datos.getIdEmpresa() == null
                || datos.getIdEmpresa().length != datos.getIdEmpleado().length
                || !defaulteoSeguridad.tieneAccesoEmpresas(usuario.n, datos.getIdEmpresa())
                || !defaulteoSeguridad.tieneAccesoEmpleados(usuario.n, datos.getIdEmpleado())) {
            return new ResponseEntity<List<Object>>(HttpStatus.FORBIDDEN);
        }
        datos.setIdAdmin(usuario.n);
        List<Object> l_titulares = null;
        try {
            l_titulares = ff_tis.defaultearEmpleadosMasivo(datos);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<List<Object>>(HttpStatus.CONFLICT);
        }
        return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
    }

    @GetMapping("/getConfPassword")
    public ResponseEntity<List<Object>> getConfPassword(@RequestParam int idEmpresa, @RequestHeader("authorization") String token) {
        List<Object> lista;
        if (!general_Serv.validarTokenId(0, token, 4)) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
        try {
            lista = ff_tis.getConfPassword(idEmpresa);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return lista.isEmpty() ? new ResponseEntity<>(lista, HttpStatus.NO_CONTENT) : new ResponseEntity<>(lista, HttpStatus.OK);
    }

    @GetMapping("/getIdEyRetiro")
    public ResponseEntity<List<Object>> getIdEyRetiro(@RequestParam int idAdm, @RequestHeader("authorization") String token) {
        List<Object> lista;
        if (!general_Serv.validarTokenId(0, token, 4)) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
        try {
            lista = ff_tis.getIdEyRetiro(idAdm);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return lista.isEmpty() ? new ResponseEntity<>(lista, HttpStatus.NO_CONTENT) : new ResponseEntity<>(lista, HttpStatus.OK);
    }

    /**
     * INC002/RF019: Obtiene datos de la ultima solicitud para una lista de empleados
     * @param idEmpleados Lista de IDs de empleados separados por coma (ej: "1,2,3,4")
     * @param token Token de autorizacion
     * @return Lista con datos de la ultima solicitud de cada empleado
     */
    @GetMapping("/obtenerUltimasSolicitudes")
    public ResponseEntity<List<Map<String, Object>>> obtenerUltimasSolicitudesEmpleados(
            @RequestParam String idEmpleados, @RequestHeader("authorization") String token) {
        List<Map<String, Object>> lista;
        if (!general_Serv.validarTokenId(0, token, 4)) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
        try {
            System.out.println("INC002: Llamando SP con idEmpleados: " + idEmpleados);
            lista = ff_tis.obtenerUltimasSolicitudesEmpleados(idEmpleados);
            System.out.println("INC002: SP ejecutado correctamente, registros: " + (lista != null ? lista.size() : 0));
        } catch (Exception e) {
            System.out.println("INC002 ERROR: " + e.getClass().getName() + " - " + e.getMessage());
            e.printStackTrace();
            bitacora.error("Error al obtener ultimas solicitudes: " + e.getMessage());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(lista, HttpStatus.OK);
    }

    @GetMapping("/consultarTitularAvanzado")
    public ResponseEntity<List<Object>> consultarTitularAvanzado(
              @RequestParam Integer IdCorporativo
            , @RequestParam String IdEmpresas
            , @RequestParam String Busca
            , @RequestParam String Operador1
            , @RequestParam String CampoBusca
            , @RequestParam Integer BusquedaAvanzada
            , @RequestParam String OperadorAvanzado
            , @RequestParam String Busca2
            , @RequestParam String Operador2
            , @RequestParam String CampoBusca2
            , @RequestParam int idAdm
            , @RequestHeader("authorization") String token) {

        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.consultarTitularesAvanzado(IdCorporativo,IdEmpresas,Busca,Operador1,CampoBusca,BusquedaAvanzada,OperadorAvanzado,Busca2,Operador2,CampoBusca2,idAdm);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/consultarDependienteAvanzado")
    public ResponseEntity<List<Object>> consultarDependienteAvanzado(
              @RequestParam Integer IdCorporativo
            , @RequestParam String IdEmpresas
            , @RequestParam String Busca
            , @RequestParam String Operador1
            , @RequestParam String CampoBusca
            , @RequestParam Integer BusquedaAvanzada
            , @RequestParam String OperadorAvanzado
            , @RequestParam String Busca2
            , @RequestParam String Operador2
            , @RequestParam String CampoBusca2
            , @RequestParam int idAdm
            , @RequestHeader("authorization") String token) {

        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.consultarDependientesAvanzado(IdCorporativo,IdEmpresas,Busca,Operador1,CampoBusca,BusquedaAvanzada,OperadorAvanzado,Busca2,Operador2,CampoBusca2,idAdm);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/coberturas/plan/{idPlan}/vigencia/{idVigencia}")
    public ResponseEntity<List<Object>> getCoberturasPorPlanVigencia(@PathVariable int idPlan, @PathVariable int idVigencia, @RequestHeader("authorization") String token) {
        List<Object> coberturas = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                coberturas = ff_tis.getCoberturasPorPlanVigencia(idPlan, idVigencia);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<List<Object>>(coberturas, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/ejecutarDefaulteoCasosEspeciales")
    public ResponseEntity<Map<String, Object>> ejecutarDefaulteoCasosEspeciales(@RequestBody Map<String, Object> req, @RequestHeader("authorization") String token) {
        if (!general_Serv.validarTokenId(0, token, 4)) {
            return new ResponseEntity<Map<String, Object>>(HttpStatus.UNAUTHORIZED);
        }
        try {
            Map<String, Object> res = ff_tis.ejecutarDefaulteoCasosEspeciales(req);
            return new ResponseEntity<Map<String, Object>>(res, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<Map<String, Object>>(HttpStatus.CONFLICT);
        }
    }

    // CREA06 Casos Especiales (async): arranca el lote en BACKGROUND y responde 202 con
    // { idLog, estado:"EN_PROCESO", total }. Evita el timeout del gateway/CDN con lotes grandes
    // (cada empleado exitoso genera su PDF via FOP). El front consulta GET /estadoDefaulteoCasosEspeciales/{idLog}.
    @PostMapping("/ejecutarDefaulteoCasosEspecialesAsync")
    public ResponseEntity<Map<String, Object>> ejecutarDefaulteoCasosEspecialesAsync(@RequestBody Map<String, Object> req, @RequestHeader("authorization") String token) {
        if (!general_Serv.validarTokenId(0, token, 4)) {
            return new ResponseEntity<Map<String, Object>>(HttpStatus.UNAUTHORIZED);
        }
        try {
            int idLog = ff_tis.iniciarLoteCasosEspeciales(req);
            Map<String, Object> resp = new java.util.HashMap<String, Object>();
            if (idLog <= 0) {
                resp.put("estado", "ERROR");
                resp.put("mensaje", "No se pudo iniciar el lote de defaulteo");
                return new ResponseEntity<Map<String, Object>>(resp, HttpStatus.CONFLICT);
            }
            casosRunner.procesarLote(idLog, req);
            Object layout = req.get("layout");
            int total = (layout instanceof java.util.List) ? ((java.util.List<?>) layout).size() : 0;
            resp.put("idLog", idLog);
            resp.put("estado", "EN_PROCESO");
            resp.put("total", total);
            return new ResponseEntity<Map<String, Object>>(resp, HttpStatus.ACCEPTED);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<Map<String, Object>>(HttpStatus.CONFLICT);
        }
    }

    // CREA06 Casos Especiales (async): estado del lote (polling). Mientras EN_PROCESO devuelve el avance;
    // al terminar incluye "resultado" = { total, exitosos, errores, detalle } para que el grid lo pinte.
    @GetMapping("/estadoDefaulteoCasosEspeciales/{idLog}")
    public ResponseEntity<Map<String, Object>> estadoDefaulteoCasosEspeciales(@PathVariable int idLog, @RequestHeader("authorization") String token) {
        if (!general_Serv.validarTokenId(0, token, 4)) {
            return new ResponseEntity<Map<String, Object>>(HttpStatus.UNAUTHORIZED);
        }
        try {
            Map<String, Object> snap = progresoCasos.snapshot(idLog);
            if (snap == null) {
                // El lote ya no esta en memoria (JVM reiniciado o TTL vencido). El front lo tratara como desconocido.
                snap = new java.util.HashMap<String, Object>();
                snap.put("idLog", idLog);
                snap.put("estado", "DESCONOCIDO");
                snap.put("enMemoria", Boolean.FALSE);
            }
            return new ResponseEntity<Map<String, Object>>(snap, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<Map<String, Object>>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // CREA06 R2 (minuta 22-jun): deteccion previa al cargar el layout -> { total, noSeProcesan, detalle }.
    @PostMapping("/detectarCambioPerfilCasosEspeciales")
    public ResponseEntity<Map<String, Object>> detectarCambioPerfilCasosEspeciales(@RequestBody Map<String, Object> req, @RequestHeader("authorization") String token) {
        if (!general_Serv.validarTokenId(0, token, 4)) {
            return new ResponseEntity<Map<String, Object>>(HttpStatus.UNAUTHORIZED);
        }
        try {
            Map<String, Object> res = ff_tis.detectarCambioPerfilLayoutCasosEspeciales(req);
            return new ResponseEntity<Map<String, Object>>(res, HttpStatus.OK);
        } catch (Exception e) {
            bitacora.error(e.getMessage());
            return new ResponseEntity<Map<String, Object>>(HttpStatus.CONFLICT);
        }
    }

    @PostMapping("/busquedaMultivigenciaAvanzada")
    public ResponseEntity<List<Object>> busquedaMultivigenciaAvanzada(@RequestBody Map<String, Object> requestBody
         ,@RequestHeader("authorization") String token
    ) {
        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.busquedaDefaulteoAvanzada(requestBody);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.CONFLICT);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/consultaCambiosCaliAvanzada")
    public ResponseEntity<List<Object>> consultarTitularesAvanzado(@RequestBody Map<String, Object> requestBody
        ,@RequestHeader("authorization") String token
    ) {
        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.buscaTitularesAvanzado(requestBody);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.CONFLICT);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/consultarTitularMovimientosAvanzado")
    public ResponseEntity<List<Object>> consultarTitularMovimientosAvanzado(@RequestBody Map<String, Object> requestBody, @RequestHeader("authorization") String token) {
        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.buscaTitularesMovimientosAvanzado(requestBody);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.NOT_FOUND);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/consultarTitularGeneralAvanzado")
    public ResponseEntity<List<Object>> consultarTitularGeneralAvanzado(@RequestBody Map<String, Object> requestBody
        ,@RequestHeader("authorization") String token
    ) {
        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.buscaTitularesAvanzado(requestBody);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.CONFLICT);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/consultarTitularStatementAvanzado")
    public ResponseEntity<List<Object>> consultarTitularStatementAvanzado(@RequestBody Map<String, Object> requestBody // ff_CPlantillaConsultaTitularesTotalStatementAvanzado
        ,@RequestHeader("authorization") String token
    ) {
        List<Object> l_titulares = null;
        if (general_Serv.validarTokenId(0, token, 4)) {
            try {
                l_titulares = ff_tis.buscaTitularesStatement(requestBody);
            } catch (Exception e) {
                bitacora.error(e.getMessage());
                return new ResponseEntity<List<Object>>(HttpStatus.CONFLICT);
            }
            if (l_titulares.isEmpty()) {
                return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<List<Object>>(l_titulares, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Object>>(HttpStatus.UNAUTHORIZED);
        }
    }

}
