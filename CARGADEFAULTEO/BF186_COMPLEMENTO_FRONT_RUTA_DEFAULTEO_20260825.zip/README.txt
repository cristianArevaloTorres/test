COMPLEMENTO FRONT BF3 - RUTA DEFAULTEO
======================================

CAUSA CORREGIDA
Los paquetes anteriores incluyeron la pantalla de Defaulteo, pero omitieron
los archivos centrales que registran la ruta y los componentes en Angular.
Por eso el icono aparecia y, al hacer clic, la ruta comodin enviaba a home.

ARCHIVOS INCLUIDOS
- SRC/B3/src/app/beflex/pages-routing.module.ts
- SRC/B3/src/app/beflex/pages.module.ts
- SRC/B3/src/app/beflex/components.module.ts

INSTALACION
1. Este complemento se aplica encima del ultimo SRC de BF3 que ya copiaste.
2. Desde SRC/B3, copie la carpeta src sobre la raiz del proyecto BF3.
3. Confirme el reemplazo de los tres archivos indicados arriba.
4. No es necesario borrar archivos ni ejecutar SQL.
5. Detenga y vuelva a iniciar ng serve, o genere y despliegue un build nuevo.
6. Cierre sesion, vuelva a ingresar y haga una recarga forzada del navegador.

VALIDACION
URL esperada:
http://localhost:4200/#/pages/administracion/solicitudes/defaulteo

El menu en BD debe conservar:
administracion/solicitudes/defaulteo

COMPILACION VALIDADA
Se ejecuto correctamente:
  npm run build -- --source-map=false

En Node moderno, Angular 11 puede requerir temporalmente:
  PowerShell: $env:NODE_OPTIONS='--openssl-legacy-provider'

Este complemento no contiene cambios de backend ni de base de datos.
