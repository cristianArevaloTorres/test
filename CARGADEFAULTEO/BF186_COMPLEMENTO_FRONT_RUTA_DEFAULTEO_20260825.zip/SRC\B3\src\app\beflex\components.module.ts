import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DependientesComponent } from './dependientes/dependientes.component';
import { DependientesmasterComponent } from './master/dependientesmaster/dependientesmaster.component';
import { MisdatosfiscalesmasterComponent } from './master/misdatosfiscalesmaster/misdatosfiscalesmaster.component';
import { BeneficiosmasterComponent } from './master/beneficiosmaster/beneficiosmaster.component';
import { RegistroBeneficiariosMasterComponent } from './master/registro-beneficiarios-master/registro-beneficiarios-master.component';
import { ReporteMovimientosAltasComponent } from './adm-reportes/reporte-movimientos-altas/reporte-movimientos-altas.component';
import { TablaDefaulteoComponent } from './adm-reportes/reporte-defaulteo/tabla-defaulteo/tabla-defaulteo.component';
import { DefaulteoAvanzadoComponent } from './adm-reportes/reporte-defaulteo/defaulteo-avanzado/defaulteo-avanzado.component';
import { ReporteHistoricoDefaulteoComponent } from './adm-reportes/reporte-defaulteo/reporte-historico-defaulteo/reporte-historico-defaulteo.component';
import { TablaDefaulteoCasosEspecialesComponent } from './adm-reportes/reporte-defaulteo/tabla-defaulteo-casos-especiales/tabla-defaulteo-casos-especiales.component';
import { TablaBeneficiariosComponent } from './beneficiarios/tabla-beneficiarios/tabla-beneficiarios.component';
import { TablabeneficiosempleadoComponent } from './consultabeneficiosempleado/tablabeneficiosempleado/tablabeneficiosempleado.component';
import { TablatitularesdependientesComponent } from './consultatitularesdependientes/tablatitularesdependientes/tablatitularesdependientes.component';
import { CompensacionAdmComponent } from './compensacion-adm/compensacion-adm.component';
import { TablaTitularesComponent } from './consultatitularestotalstatement/tabla-titulares/tabla-titulares.component';
import { AltaTitularesComponent } from './generacion-cambios-calificados/altatitulares/altatitulares.component';
import { InfoTitularComponent } from './generacion-cambios-calificados/info-titular/info-titular.component';
import { PlanescoberturasComponent } from './generacion-cambios-calificados/planes-coberturas/planescoberturas.component';
import { TablamodificaciontitularesComponentCalificados } from './generacion-cambios-calificados/tablamodificaciontitularescalificados/tablamodificaciontitularescalificados.component';
import { RegistroBeneficiariosCalificadosComponent } from './generacion-cambios-calificados/registro-beneficiarios-calificados/registro-beneficiarios-calificados.component';
import { TablabajatitularesComponent } from './master/titularesmasteradm/bajatitulares/tablabajatitulares/tablabajatitulares.component';
import { TablamodificaciontitularesComponent } from './master/titularesmasteradm/modificaciontitulares/tablamodificaciontitulares/tablamodificaciontitulares.component';
import { TablaPreviewBeMobileComponent } from './preview-bemobile/tablapreview-bemobile/tablapreview-bemobile.component';
import { TablaRegeneracionSolicitudComponent } from './regeneracionsolicitud/tablaregeneracionsolicitud/tablaregeneracionsolicitud.component';
import { CasaComponent } from './casa/casa.component';
import { ConsultatitularesdependientesComponent } from './consultatitularesdependientes/consultatitularesdependientes.component';
import { BeneficiosComponent } from './cotizador/beneficios/beneficios.component';
import { CotizadorComponent } from './cotizador/cotizador.component';
import { BonoautomasterComponent } from './master/bonoautomaster/bonoautomaster.component';
import { RedirectLizzyComponent } from '../home/redirect-lizzy/redirect-lizzy.component';
import { TitularesmasteradmComponent } from './master/titularesmasteradm/titularesmasteradm.component';
import { PlanScotiabankComponent } from './plan-scotiabank/plan-scotiabank.component';
import { AdmBonoAutoTablaComponent } from './adm-bono-auto/adm-bono-auto-tabla/adm-bono-auto-tabla.component';
import {TablaBajaDocumentos} from './adm-reportes/reporte-doc-personalizados/tabla-baja-documentos/tabla-baja-documentos.component';


@NgModule({
  declarations: [
    DependientesComponent,
    DependientesmasterComponent,
    MisdatosfiscalesmasterComponent,
    BeneficiosmasterComponent,
    RegistroBeneficiariosMasterComponent,
    ReporteMovimientosAltasComponent,
    TablaDefaulteoComponent,
    DefaulteoAvanzadoComponent,
    ReporteHistoricoDefaulteoComponent,
    TablaDefaulteoCasosEspecialesComponent,
    TablaBeneficiariosComponent,
    TablabeneficiosempleadoComponent,
    TablatitularesdependientesComponent,
    CompensacionAdmComponent,
    TablaTitularesComponent,
    AltaTitularesComponent,
    InfoTitularComponent,
    PlanescoberturasComponent,
    TablamodificaciontitularesComponentCalificados,
    RegistroBeneficiariosCalificadosComponent,
    TablabajatitularesComponent,
    TablamodificaciontitularesComponent,
    TablaPreviewBeMobileComponent,
    TablaRegeneracionSolicitudComponent,
    CasaComponent,
    ConsultatitularesdependientesComponent,
    BeneficiosComponent,
    CotizadorComponent,
    BonoautomasterComponent,
    RedirectLizzyComponent,
    TitularesmasteradmComponent,
    PlanScotiabankComponent,
    TablaBajaDocumentos,
    AdmBonoAutoTablaComponent

  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ],
  exports: [
    DependientesComponent,
    DependientesmasterComponent,
    MisdatosfiscalesmasterComponent,
    BeneficiosmasterComponent,
    RegistroBeneficiariosMasterComponent,
    ReporteMovimientosAltasComponent,
    TablaDefaulteoComponent,
    DefaulteoAvanzadoComponent,
    ReporteHistoricoDefaulteoComponent,
    TablaDefaulteoCasosEspecialesComponent,
    TablaBeneficiariosComponent,
    TablabeneficiosempleadoComponent,
    TablatitularesdependientesComponent,
    CompensacionAdmComponent,
    TablaTitularesComponent,
    AltaTitularesComponent,
    InfoTitularComponent,
    PlanescoberturasComponent,
    TablamodificaciontitularesComponentCalificados,
    RegistroBeneficiariosCalificadosComponent,
    TablabajatitularesComponent,
    TablamodificaciontitularesComponent,
    TablaPreviewBeMobileComponent,
    TablaRegeneracionSolicitudComponent,
    CasaComponent,
    ConsultatitularesdependientesComponent,
    BeneficiosComponent,
    CotizadorComponent,
    BonoautomasterComponent,
    RedirectLizzyComponent,
    TitularesmasteradmComponent,
    TablaBajaDocumentos,
    AdmBonoAutoTablaComponent
   
  ]
})
export class ComponentsModule { }
