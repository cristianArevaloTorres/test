import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BComponent } from './beflex/beflex.component';
import { AdmAccesosComponent } from './adm-accesos/adm-accesos.component';
import { AdmCalculadoraRetiroComponent } from './adm-calculadora-retiro/adm-calculadora-retiro.component';
import { AsignarSubirComponent } from './adm-documentos/asignar-subir/asignar-subir.component';
import { DocExistenteComponent } from './adm-documentos/asignar-subir/doc-existente/doc-existente.component';
import { DocPersonalizadosComponent } from './adm-documentos/doc-personalizados/doc-personalizados.component';
import { AdmEyretiroComponent } from './adm-eyretiro/adm-eyretiro.component';
import { AseguradosComponent } from './adm-reportes/asegurados/asegurados.component';
import { BitacoraNavegacionComponent } from './adm-reportes/bitacora-navegacion/bitacora-navegacion.component';
import { CifrasControlComponent } from './adm-reportes/cifras-control/cifras-control.component';
import { CobranzaComponent } from './adm-reportes/cobranza/cobranza.component';
import { KPIComponent } from './adm-reportes/kpi/kpi.component';
import { ReporteBeneficiariosComponent } from './adm-reportes/reporte-beneficiarios/reporte-beneficiarios.component';
import { ReporteDefaulteoComponent } from './adm-reportes/reporte-defaulteo/reporte-defaulteo.component';
import { ReporteDefaulteoCasosEspecialesComponent } from './adm-reportes/reporte-defaulteo/reporte-defaulteo-casos-especiales/reporte-defaulteo-casos-especiales.component';
import { ReporteDocPersonalizadosComponent } from './adm-reportes/reporte-doc-personalizados/reporte-doc-personalizados.component';
import { ReporteSolicitudesComponent } from './adm-reportes/reporte-solicitudes/reporte-solicitudes.component';
import { ReporteCostosComponent } from './adm-reportes/reportecostos/reportecostos.component';
import { ReporteCasaHabitacionComponent } from './adm-reportes/reporte-casa-habitacion/reporte-casa-habitacion.component';
import { SabanaBeneficiosComponent } from './adm-reportes/sabana-beneficios/sabana-beneficios.component';
import { AdmTicketsComponent } from './adm-tickets/adm-tickets.component';
import { AdmDependientesComponent } from './administracion/adm-dependientes/adm-dependientes.component';
import { AdminSolicitudesComponent } from './adminsolicitudes/adminsolicitudes.component';
import { BeflexComponent } from './beflex.component';
import { BeneficiariosComponent } from './beneficiarios/beneficiarios.component';
import { PreguntasComponent } from './buzon/preguntas/preguntas.component';
import { RespuestasComponent } from './buzon/respuestas/respuestas.component';
import { CalculadoraComponent } from './calculadora/calculadora.component';
import { CambioEmpresaComponent } from './cambioempresa/cambioempresa.component';
import { CambiopasswordComponent } from './cambiopassword/cambiopassword.component';
import { CargamasivaadmComponent } from './cargamasivaadm/cargamasivaadm.component';
import { CompensacionComponent } from './compensacion/compensacion.component';
import { ConfEnvioComponent } from './conf-envio/conf-envio.component';
import { ConfSubgruposComponent } from './conf-subgrupos/conf-subgrupos.component';
import { ConfiguracionComponent } from './configuracion/configuracion.component';
import { ConsultabeneficiosempleadoComponent } from './consultabeneficiosempleado/consultabeneficiosempleado.component';
import { ConsultaindicadoressiniestroComponent } from './consultaindicadoressiniestro/consultaindicadoressiniestro.component';
import { ConsultasiniestrosdetalleComponent } from './consultasiniestrosdetalle/consultasiniestrosdetalle.component';
import { ConsultatitularestotalstatementComponent } from './consultatitularestotalstatement/consultatitularestotalstatement.component';
import { DocumentosComponent } from './documentos/documentos.component';
import { facturacionComponent } from './facturacion/facturacion.component';
import { GeneracionCambiosCalificadosComponent } from './generacion-cambios-calificados/generacion-cambios-calificados.component';
import { BajatitularesComponent } from './master/titularesmasteradm/bajatitulares/bajatitulares.component';
import { ModificaciontitularesComponent } from './master/titularesmasteradm/modificaciontitulares/modificaciontitulares.component';
import { TitularesmasteradmComponent } from './master/titularesmasteradm/titularesmasteradm.component';
import { MembresiasComponent } from './membresias/membresias.component';
import { MembresiasdosComponent } from './membresias/membresiasdos/membresiasdos.component';
import { MisdatosfiscalesComponent } from './misdatosfiscales/misdatosfiscales.component';
import { MisdocumentosComponent } from './misdocumentos/misdocumentos.component';
import { MisolicitudesdebeneficiosComponent } from './misolicitudesdebeneficios/misolicitudesdebeneficios.component';
import { SolicitudComponent } from './misolicitudesdebeneficios/solicitud/solicitud.component';
import { NoticiasComponent } from './noticias/noticias.component';
import { PerfilComponent } from './perfil/perfil.component';
import { PreViewBeMobileComponent } from './preview-bemobile/preview-bemobile.component';
import { PreviewCompensacionesComponent } from './preview-compensaciones/preview-compensaciones.component';
import { RegeneracionSolicitudComponent } from './regeneracionsolicitud/regeneracionsolicitud.component';
import { RegistrodebeneficiariosComponent } from './registrodebeneficiarios/registrodebeneficiarios.component';
import { SamiComponent } from './sami/sami.component';
import { SolicitudcambiocalificadoComponent } from './solicitudcambiocalificado/solicitudcambiocalificado.component';
import { SubMenuComponent } from './submenu/submenu.component';
import { TestingComponent } from './testing/testing.component';
import { MonitorComponent } from './tickets/monitor/monitor.component';
import { TicketsComponent } from './tickets/ticket.component';
import { VideosComponent } from './videos/videos.component';
import { DireccionamientoComponent } from '../home/direccionamiento/direccionamiento.component';
import { LogoutComponent } from '../logout/logout.component';
import { VerificacionComponent } from '../verificacion/verificacion.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PagesRoutingModule } from './pages-routing.module';
import { SharedModule } from '../shared/shared.module';
import { ComponentsModule } from './components.module';
import { RouterModule } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { EnvioLocktonOne } from './adm-EnvioLocktonOne/adm-EnvioLocktonOne.component';
import { RegistroMascotasComponent } from './registro-mascotas/registro-mascotas.component';
import { ReporteAccesosBemobileComponent } from './adm-reportes/reporte-accesos-bemobile/reporte-accesos-bemobile.component';
import { ReporteBitacoraNotificacionesComponent } from './adm-reportes/reporte-bitacora-notificaciones/reporte-bitacora-notificaciones.component';
import { CambiosCalificadosComponent } from './adm-reportes/cambios-calificados/pages/cambios-calificados/cambios-calificados.component';
import { AsignacionPlanesComponent } from './adm-reportes/reporte-asignacion-planes/asignacion-planes.component';
import { AdmBonoAutoComponent } from './adm-bono-auto/adm-bono-auto.component';
import { ReporteFacturasComponent } from './adm-reportes/reporte-facturas/reporte-facturas.component';
import { ReporteSaldosComponent } from './adm-reportes/reporte-saldos/reporte-saldos.component';
import { ReporteContabilidadComponent } from './adm-reportes/reporte-contabilidad/reporte-contabilidad.component';
import { BeMobileComponent } from './bemobile/bemobile.component';
import { EnvioNotificacionesComponent } from './bemobile/envio-notificaciones/envio-notificaciones.component';
import { AdminNotificacionesComponent } from './bemobile/admin-notificaciones/admin-notificaciones.component';
import { RegSolicitudesComponent } from './reg-solicitudes/reg-solicitudes.component'
import { DatosBancariosComponent } from './datosbancarios/datosbancarios.component';
import { ReporteDetalladoCobroComponent } from './reportedetalladocobro/reportedetalladocobro.component';
import { AdmLocktonHubComponent } from './adm-lockton-hub/adm-lockton-hub.component';
import { AdmLinkPagoPTDCComponent } from './adm-link-pago-ptdc/adm-link-pago-ptdc.component';
import { ReporteCrearComponent } from './adm-reportes/reporte-crear/reporte-crear.component';
import { ReporteReconfigurarComponent } from './adm-reportes/reporte-reconfigurar/reporte-reconfigurar.component';
import { ReporteConfiguracionComponent } from './adm-reportes/reporte-configuracion/reporte-configuracion.component';
import { ReporteSeguimientoComponent } from './adm-reportes/reporte-seguimiento/reporte-seguimiento.component';
import { ReporteConfigurarExportacionComponent } from './adm-reportes/reporte-configurar-exportacion/reporte-configurar-exportacion.component';
import { BorradoPoblacionComponent } from './borrado-poblacion/borrado-poblacion.component';
import { ValidacionesPostEnrollmentComponent } from './adm-reportes/validaciones-post-enrollment/validaciones-post-enrollment.component';
import { ReporteEstadisticoComponent } from './adm-reportes/reporte-estadistico/reporte-estadistico.component';
import { ReseteoCuentaEmpleadoComponent } from './reseteo-usuario/reseteo-cuenta-empleado/reseteo-cuenta-empleado.component';
import { CompensacionEmpleadoComponent } from './adm-reportes/compensacion-empleado/compensacion-empleado.component';
import { MarketplaceComponent } from './beflex/marketplace/marketplace.component';


@NgModule({
  declarations: [
    BComponent,
    AdmAccesosComponent,
    AdmCalculadoraRetiroComponent,
    AsignarSubirComponent,
    DocExistenteComponent,
    DocPersonalizadosComponent,
    AdmEyretiroComponent,
    AseguradosComponent,
    BitacoraNavegacionComponent,
    CifrasControlComponent,
    CobranzaComponent,
    KPIComponent,
    ReporteBeneficiariosComponent,
    ReporteDefaulteoComponent,
    ReporteDefaulteoCasosEspecialesComponent,
    ReporteDocPersonalizadosComponent,
    ReporteSolicitudesComponent,
    ReporteCostosComponent,
    ReporteCasaHabitacionComponent,
    SabanaBeneficiosComponent,
    AdmTicketsComponent,
    AdmDependientesComponent,
    AdminSolicitudesComponent,
    BeflexComponent,
    BeneficiariosComponent,
    PreguntasComponent,
    RespuestasComponent,
    CalculadoraComponent,
    CambioEmpresaComponent,
    CambiopasswordComponent,
    CargamasivaadmComponent,

    CompensacionComponent,
    ConfEnvioComponent,
    ConfSubgruposComponent,
    ConfiguracionComponent,
    ConsultabeneficiosempleadoComponent,
    ConsultaindicadoressiniestroComponent,
    ConsultasiniestrosdetalleComponent,
    ConsultatitularestotalstatementComponent,
    HomeComponent,
    DocumentosComponent,
    facturacionComponent,
    GeneracionCambiosCalificadosComponent,
    BajatitularesComponent,
    ModificaciontitularesComponent,
    MembresiasComponent,
    MembresiasdosComponent,
    MisdatosfiscalesComponent,
    MisdocumentosComponent,
    MisolicitudesdebeneficiosComponent,
    SolicitudComponent,
    NoticiasComponent,
    PerfilComponent,
    PreViewBeMobileComponent,
    RegeneracionSolicitudComponent,
    RegistrodebeneficiariosComponent,
    RegistroMascotasComponent,
    SamiComponent,
    SolicitudcambiocalificadoComponent,
    SubMenuComponent,
    TestingComponent,
    MonitorComponent,
    TicketsComponent,
    VideosComponent,
    DireccionamientoComponent,
    LogoutComponent,
    VerificacionComponent,
    EnvioLocktonOne,
    ReporteAccesosBemobileComponent,
    ReporteBitacoraNotificacionesComponent,
    CambiosCalificadosComponent,
    AsignacionPlanesComponent,
    AdmBonoAutoComponent,
    ReporteFacturasComponent,
    ReporteSaldosComponent,
    ReporteContabilidadComponent,
    BeMobileComponent,
    EnvioNotificacionesComponent,
    AdminNotificacionesComponent,
    RegSolicitudesComponent,
    DatosBancariosComponent,
    ReporteDetalladoCobroComponent,
    AdmLocktonHubComponent,
    AdmLinkPagoPTDCComponent,
    ReporteCrearComponent,
    ReporteReconfigurarComponent,
    ReporteConfiguracionComponent,
    ReporteSeguimientoComponent,
    ReporteConfigurarExportacionComponent,
    BorradoPoblacionComponent,
    ValidacionesPostEnrollmentComponent,
    ReporteEstadisticoComponent,
    ReseteoCuentaEmpleadoComponent,
    CompensacionEmpleadoComponent,
    PreviewCompensacionesComponent,
    MarketplaceComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    PagesRoutingModule,
    ComponentsModule,
    RouterModule
  ]
})
export class PagesModule { }
